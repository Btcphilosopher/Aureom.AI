"""Compute inventory tracking (sections 8 + 29 utilisation engine).

All figures come from the `InventoryItem` rows in the database (backed,
in the demo, by the synthetic data generator) — nothing here hard-codes
counts.
"""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(slots=True)
class InventorySnapshot:
    datacenter_id: str
    hardware_id: str
    installed: int
    available: int
    reserved: int
    running: int
    offline: int

    @property
    def utilisation_pct(self) -> float:
        if self.installed == 0:
            return 0.0
        return round(100.0 * self.running / self.installed, 4)

    @property
    def available_pct(self) -> float:
        if self.installed == 0:
            return 0.0
        return round(100.0 * self.available / self.installed, 4)

    @property
    def reserved_pct(self) -> float:
        if self.installed == 0:
            return 0.0
        return round(100.0 * self.reserved / self.installed, 4)

    @property
    def offline_pct(self) -> float:
        if self.installed == 0:
            return 0.0
        return round(100.0 * self.offline / self.installed, 4)

    def as_dict(self) -> dict:
        return {
            "datacenter_id": self.datacenter_id,
            "hardware_id": self.hardware_id,
            "installed": self.installed,
            "available": self.available,
            "reserved": self.reserved,
            "running": self.running,
            "offline": self.offline,
            "utilisation_pct": self.utilisation_pct,
            "available_pct": self.available_pct,
            "reserved_pct": self.reserved_pct,
            "offline_pct": self.offline_pct,
        }

    @classmethod
    def from_orm_row(cls, row) -> "InventorySnapshot":
        return cls(
            datacenter_id=row.datacenter_id,
            hardware_id=row.hardware_id,
            installed=row.installed_quantity,
            available=row.available_quantity,
            reserved=row.reserved_quantity,
            running=row.running_quantity,
            offline=row.offline_quantity,
        )


class UtilisationEngine:
    """Aggregates utilisation across a set of inventory snapshots
    (section 29)."""

    @staticmethod
    def aggregate(snapshots: list[InventorySnapshot]) -> dict:
        installed = sum(s.installed for s in snapshots)
        available = sum(s.available for s in snapshots)
        reserved = sum(s.reserved for s in snapshots)
        running = sum(s.running for s in snapshots)
        offline = sum(s.offline for s in snapshots)
        utilisation = round(100.0 * running / installed, 4) if installed else 0.0
        return {
            "installed_capacity": installed,
            "available_capacity": available,
            "reserved_capacity": reserved,
            "running_capacity": running,
            "idle_capacity": max(installed - running - reserved - offline, 0),
            "offline_capacity": offline,
            "utilisation_pct": utilisation,
        }
