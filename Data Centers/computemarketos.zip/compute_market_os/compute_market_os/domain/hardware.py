"""Hardware model and the Compute Performance Index (CPI).

Section 4 (hardware model) + section 5 (Compute Performance Index).

The CPI deliberately never collapses to "theoretical FLOPS". It blends
whichever raw benchmark fields a `BenchmarkProfile` names (FP32/FP16/BF16/
FP8/INT8, memory bandwidth, inference throughput, effective training
throughput, ...) using configurable weights loaded from
`config/benchmarks.yaml`. Vendors/models are entirely data-driven — nothing
here hard-codes NVIDIA/AMD/Google etc.
"""

from __future__ import annotations

import dataclasses
import functools
from typing import Any

from compute_market_os.core.config import load_yaml_config


@dataclasses.dataclass(slots=True, frozen=True)
class ComputeHardware:
    id: str
    manufacturer: str
    model: str
    category: str
    memory_gb: float
    memory_bandwidth_gbps: float
    power_watts: float
    benchmarks: dict[str, float] = dataclasses.field(default_factory=dict)

    @property
    def compute_score(self) -> float:
        """A simple, transparent composite score (NOT the CPI).

        Provided as a cheap default ranking signal when no benchmark
        profile is specified. It averages whatever throughput-shaped
        benchmark fields are present alongside memory bandwidth — it is
        intentionally not "theoretical peak FLOPS".
        """
        fields = [
            self.benchmarks.get("bf16_tflops", 0.0),
            self.benchmarks.get("fp32_tflops", 0.0),
            self.memory_bandwidth_gbps / 100.0,
        ]
        nonzero = [f for f in fields if f > 0]
        return sum(nonzero) / len(nonzero) if nonzero else 0.0


@dataclasses.dataclass(slots=True, frozen=True)
class BenchmarkProfile:
    name: str
    description: str
    weights: dict[str, float]


@functools.lru_cache
def load_hardware_catalog() -> dict[str, ComputeHardware]:
    raw = load_yaml_config("hardware")
    catalog: dict[str, ComputeHardware] = {}
    for entry in raw.get("hardware", []):
        hw = ComputeHardware(
            id=entry["id"],
            manufacturer=entry["manufacturer"],
            model=entry["model"],
            category=entry["category"],
            memory_gb=float(entry["memory_gb"]),
            memory_bandwidth_gbps=float(entry["memory_bandwidth_gbps"]),
            power_watts=float(entry["power_watts"]),
            benchmarks={k: float(v) for k, v in entry.get("benchmarks", {}).items()},
        )
        catalog[hw.id] = hw
    return catalog


@functools.lru_cache
def load_benchmark_profiles() -> dict[str, BenchmarkProfile]:
    raw = load_yaml_config("benchmarks")
    profiles: dict[str, BenchmarkProfile] = {}
    for name, entry in raw.get("profiles", {}).items():
        profiles[name] = BenchmarkProfile(
            name=name,
            description=entry.get("description", ""),
            weights={k: float(v) for k, v in entry.get("weights", {}).items()},
        )
    return profiles


class ComputePerformanceIndex:
    """Computes a normalised CPI score for a hardware SKU under a named
    benchmark profile (e.g. "llm_training", "llm_inference").

    CPI(hw, profile) = Σ weight_i * raw_field_i(hw)

    The result is a raw weighted score in mixed units — it is meaningful
    for *ranking* hardware within the same profile, and for computing
    performance-adjusted prices (£ / CPI-unit), not as an absolute
    cross-profile figure.
    """

    def __init__(self, profiles: dict[str, BenchmarkProfile] | None = None) -> None:
        self._profiles = profiles or load_benchmark_profiles()

    def profile(self, name: str) -> BenchmarkProfile:
        if name not in self._profiles:
            raise KeyError(f"Unknown benchmark profile: {name!r}")
        return self._profiles[name]

    def score(self, hardware: ComputeHardware, profile_name: str = "general_purpose") -> float:
        profile = self.profile(profile_name)
        total = 0.0
        for field, weight in profile.weights.items():
            if field == "memory_bandwidth_gbps":
                value = hardware.memory_bandwidth_gbps
            else:
                value = hardware.benchmarks.get(field, 0.0)
            total += weight * value
        return total

    def rank(
        self, hardware_list: list[ComputeHardware], profile_name: str = "general_purpose"
    ) -> list[tuple[ComputeHardware, float]]:
        scored = [(hw, self.score(hw, profile_name)) for hw in hardware_list]
        return sorted(scored, key=lambda pair: pair[1], reverse=True)

    def price_per_cpi_unit(
        self, hardware: ComputeHardware, price_per_hour: float, profile_name: str = "general_purpose"
    ) -> float | None:
        """£ / benchmark-unit — the performance-adjusted price (section 21)."""
        score = self.score(hardware, profile_name)
        if score <= 0:
            return None
        return price_per_hour / score
