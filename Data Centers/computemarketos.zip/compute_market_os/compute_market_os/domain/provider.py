"""Provider engine (section 6).

`ComputeProvider` is the in-memory/domain-level representation used by
the pricing, optimisation, and simulation engines. It is intentionally
decoupled from the SQLAlchemy `Provider` row — `from_orm_row` bridges
the two so the rest of the codebase never has to import SQLAlchemy just
to reason about a provider.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.core.enums import ProviderType


@dataclasses.dataclass(slots=True)
class ComputeProvider:
    id: str
    name: str
    provider_type: ProviderType
    country: str
    region: str
    reliability: float = 0.99
    pricing_model: dict = dataclasses.field(default_factory=dict)
    datacenter_ids: list[str] = dataclasses.field(default_factory=list)

    @classmethod
    def from_orm_row(cls, row) -> "ComputeProvider":
        return cls(
            id=row.id,
            name=row.name,
            provider_type=ProviderType(row.provider_type),
            country=row.country,
            region=row.region,
            reliability=row.reliability,
            pricing_model=row.pricing_model or {},
            datacenter_ids=[dc.id for dc in getattr(row, "datacenters", [])],
        )
