"""The normalised compute commodity model (section 3).

`ComputeUnit` is the vendor-neutral economic object the whole exchange
trades — never hard-coded to one accelerator family.
"""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(slots=True)
class ComputeUnit:
    accelerator: str          # e.g. "GPU", "CPU", "TPU", "AI_ACCELERATOR"
    model: str                # e.g. "H100", "MI300X", "TPU v5p"
    quantity: int
    memory_gb: float
    region: str
    availability_hours: float
    hardware_id: str | None = None
    provider_id: str | None = None
    datacenter_id: str | None = None
    price_per_unit_hour: float | None = None

    @property
    def total_gpu_hours(self) -> float:
        return self.quantity * self.availability_hours

    @property
    def total_memory_gb(self) -> float:
        return self.quantity * self.memory_gb
