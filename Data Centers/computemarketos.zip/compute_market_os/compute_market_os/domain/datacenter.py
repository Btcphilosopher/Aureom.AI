"""Datacenter model and physical power constraint (sections 7 + 38).

`PowerConstraint` is the enforcement point that stops the market from
selling more compute than a datacenter can physically power and cool —
used by the reservation ledger and matching engine before any capacity
is committed.
"""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(slots=True)
class DataCenter:
    id: str
    provider_id: str
    code: str
    region: str
    location: str
    latitude: float
    longitude: float
    power_capacity_mw: float
    it_load_mw: float
    cooling_capacity_mw: float
    network_capacity_tbps: float
    pue: float = 1.35
    availability: float = 0.999

    @property
    def cooling_load_mw(self) -> float:
        """Cooling overhead implied by PUE: (PUE - 1) * IT load."""
        return max(self.pue - 1.0, 0.0) * self.it_load_mw

    @property
    def total_power_draw_mw(self) -> float:
        return self.it_load_mw + self.cooling_load_mw

    @property
    def available_power_mw(self) -> float:
        return max(self.power_capacity_mw - self.total_power_draw_mw, 0.0)

    @classmethod
    def from_orm_row(cls, row) -> "DataCenter":
        return cls(
            id=row.id,
            provider_id=row.provider_id,
            code=row.code,
            region=row.region,
            location=row.location,
            latitude=row.latitude,
            longitude=row.longitude,
            power_capacity_mw=row.power_capacity_mw,
            it_load_mw=row.it_load_mw,
            cooling_capacity_mw=row.cooling_capacity_mw,
            network_capacity_tbps=row.network_capacity_tbps,
            pue=row.pue,
            availability=row.availability,
        )


@dataclasses.dataclass(slots=True)
class PowerConstraintResult:
    allowed: bool
    available_power_mw: float
    requested_power_mw: float
    reason: str = ""


class PowerConstraint:
    """Prevents capacity sales/allocations that would exceed a datacenter's
    physical power (and, via PUE, cooling) envelope.

    A hardware unit's power draw is `power_watts` from the catalog; the
    incremental IT load of allocating `quantity` units for a workload is
    `quantity * power_watts` (converted to MW), multiplied by the
    datacenter's PUE to get the *total* facility draw including cooling.
    """

    def check(
        self,
        datacenter: DataCenter,
        additional_units: int,
        unit_power_watts: float,
    ) -> PowerConstraintResult:
        additional_it_mw = (additional_units * unit_power_watts) / 1_000_000.0
        additional_total_mw = additional_it_mw * datacenter.pue
        available = datacenter.available_power_mw
        allowed = additional_total_mw <= available + 1e-9
        reason = (
            ""
            if allowed
            else (
                f"Requested {additional_total_mw:.4f} MW (incl. PUE {datacenter.pue}) "
                f"exceeds available power {available:.4f} MW at {datacenter.code}"
            )
        )
        return PowerConstraintResult(
            allowed=allowed,
            available_power_mw=available,
            requested_power_mw=additional_total_mw,
            reason=reason,
        )
