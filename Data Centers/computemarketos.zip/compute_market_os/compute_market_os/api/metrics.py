"""Prometheus metrics (section 71)."""

from __future__ import annotations

import time

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

HTTP_REQUESTS = Counter(
    "cmos_http_requests_total", "Total HTTP requests", ["method", "path", "status_code"]
)
HTTP_LATENCY = Histogram(
    "cmos_http_request_latency_seconds", "HTTP request latency", ["method", "path"]
)
ORDER_MATCHING_LATENCY = Histogram(
    "cmos_order_matching_latency_seconds", "Latency of a single order-book match sweep"
)
DB_QUERY_LATENCY = Histogram("cmos_db_query_latency_seconds", "Database query latency", ["operation"])
MARKET_EVENTS = Counter("cmos_market_events_total", "Market events published", ["event_type"])
TRADES_EXECUTED = Counter("cmos_trades_executed_total", "Trades executed", ["hardware_id", "region"])


class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        path = request.url.path
        HTTP_REQUESTS.labels(request.method, path, response.status_code).inc()
        HTTP_LATENCY.labels(request.method, path).observe(elapsed)
        return response


def metrics_response() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
