"""Process-wide engine singletons used by the API layer.

The exchange engines (order books, auctions, spot ticker, ...) are
stateful and live in process memory for this reference implementation
(see the scale note in market/orderbook.py for how that maps onto
Redis/Postgres at production scale). One process == one market — a
multi-worker deployment needs a shared backing store, not more of these
singletons.
"""

from __future__ import annotations

import functools

from compute_market_os.ai_markets.inference_market import InferenceMarket
from compute_market_os.analyst.market_analyst import ComputeMarketAnalyst
from compute_market_os.core.events import EventBus, default_bus
from compute_market_os.market.auction_engine import AuctionEngine
from compute_market_os.market.forward_market import ForwardMarket
from compute_market_os.market.market import ComputeMarket
from compute_market_os.market.reservation_market import ReservationMarket
from compute_market_os.market.spot_market import SpotMarket
from compute_market_os.ops.billing import BillingEngine
from compute_market_os.simulation.outage_engine import OutageEngine
from compute_market_os.ops.settlement_engine import SettlementEngine
from compute_market_os.ops.sla_engine import SLAEngine
from compute_market_os.ops.surveillance import MarketSurveillanceEngine
from compute_market_os.ops.usage_meter import UsageMeter
from compute_market_os.optimisation.arbitrage_engine import ComputeArbitrageEngine
from compute_market_os.optimisation.buyer_optimizer import BuyerOptimizer
from compute_market_os.optimisation.cluster_optimizer import ClusterOptimizer
from compute_market_os.optimisation.elasticity_engine import ElasticityEngine
from compute_market_os.optimisation.equilibrium_engine import MarketEquilibriumEngine
from compute_market_os.optimisation.network_latency_engine import NetworkLatencyEngine
from compute_market_os.optimisation.provider_optimizer import ProviderOptimizer
from compute_market_os.optimisation.revenue_optimizer import ProviderRevenueOptimizer
from compute_market_os.pricing.carbon_engine import CarbonAwareScheduler
from compute_market_os.pricing.forward_curve import ComputeForwardCurve
from compute_market_os.pricing.index import ComputePriceIndexEngine
from compute_market_os.pricing.pricing_engine import PricingEngine


@functools.lru_cache
def get_event_bus() -> EventBus:
    return default_bus


@functools.lru_cache
def get_market() -> ComputeMarket:
    return ComputeMarket(event_bus=get_event_bus())


@functools.lru_cache
def get_pricing_engine() -> PricingEngine:
    return PricingEngine()


@functools.lru_cache
def get_spot_market() -> SpotMarket:
    return SpotMarket(pricing_engine=get_pricing_engine(), event_bus=get_event_bus())


@functools.lru_cache
def get_forward_market() -> ForwardMarket:
    return ForwardMarket()


@functools.lru_cache
def get_reservation_market() -> ReservationMarket:
    return ReservationMarket()


@functools.lru_cache
def get_auction_engine() -> AuctionEngine:
    return AuctionEngine()


@functools.lru_cache
def get_inference_market() -> InferenceMarket:
    return InferenceMarket()


@functools.lru_cache
def get_network_latency_engine() -> NetworkLatencyEngine:
    return NetworkLatencyEngine()


@functools.lru_cache
def get_carbon_scheduler() -> CarbonAwareScheduler:
    return CarbonAwareScheduler()


@functools.lru_cache
def get_forward_curve() -> ComputeForwardCurve:
    return ComputeForwardCurve(pricing_engine=get_pricing_engine())


@functools.lru_cache
def get_index_engine() -> ComputePriceIndexEngine:
    return ComputePriceIndexEngine()


@functools.lru_cache
def get_buyer_optimizer() -> BuyerOptimizer:
    return BuyerOptimizer()


@functools.lru_cache
def get_provider_optimizer() -> ProviderOptimizer:
    return ProviderOptimizer(pricing_engine=get_pricing_engine())


@functools.lru_cache
def get_revenue_optimizer() -> ProviderRevenueOptimizer:
    return ProviderRevenueOptimizer()


@functools.lru_cache
def get_cluster_optimizer() -> ClusterOptimizer:
    return ClusterOptimizer()


@functools.lru_cache
def get_arbitrage_engine() -> ComputeArbitrageEngine:
    return ComputeArbitrageEngine(latency_engine=get_network_latency_engine())


@functools.lru_cache
def get_equilibrium_engine() -> MarketEquilibriumEngine:
    return MarketEquilibriumEngine()


@functools.lru_cache
def get_elasticity_engine() -> ElasticityEngine:
    return ElasticityEngine()


@functools.lru_cache
def get_outage_engine() -> OutageEngine:
    return OutageEngine()


@functools.lru_cache
def get_sla_engine() -> SLAEngine:
    return SLAEngine()


@functools.lru_cache
def get_usage_meter() -> UsageMeter:
    return UsageMeter()


@functools.lru_cache
def get_billing_engine() -> BillingEngine:
    return BillingEngine()


@functools.lru_cache
def get_settlement_engine() -> SettlementEngine:
    return SettlementEngine(usage_meter=get_usage_meter(), billing_engine=get_billing_engine())


@functools.lru_cache
def get_surveillance_engine() -> MarketSurveillanceEngine:
    return MarketSurveillanceEngine()


@functools.lru_cache
def get_analyst() -> ComputeMarketAnalyst:
    return ComputeMarketAnalyst(equilibrium_engine=get_equilibrium_engine(), latency_engine=get_network_latency_engine())
