"""Real-time WebSockets (section 50).

/ws/market /ws/orderbook /ws/prices /ws/capacity /ws/trades /ws/datacenters

Each socket subscribes to a filtered slice of the internal EventBus and
pushes JSON-encoded MarketEvents as they're published — price updates,
capacity changes, new orders, executed trades, outages.
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from compute_market_os.core.events import EventBus, EventType, MarketEvent, default_bus

router = APIRouter()

_CHANNEL_EVENTS: dict[str, list[EventType] | None] = {
    "market": None,  # None == all event types
    "orderbook": [EventType.ORDER_SUBMITTED, EventType.ORDER_CANCELLED, EventType.ORDER_MATCHED, EventType.TRADE_EXECUTED],
    "prices": [EventType.PRICE_UPDATED],
    "capacity": [EventType.CAPACITY_ADDED, EventType.CAPACITY_REMOVED, EventType.RESERVATION_CREATED],
    "trades": [EventType.TRADE_EXECUTED],
    "datacenters": [EventType.OUTAGE_DETECTED, EventType.CAPACITY_ADDED, EventType.CAPACITY_REMOVED],
}


async def _serve_channel(websocket: WebSocket, channel: str, event_bus: EventBus) -> None:
    await websocket.accept()
    loop = asyncio.get_event_loop()
    queue: asyncio.Queue[MarketEvent] = asyncio.Queue()

    def handler(event: MarketEvent) -> None:
        loop.call_soon_threadsafe(queue.put_nowait, event)

    event_types = _CHANNEL_EVENTS[channel]
    if event_types is None:
        event_bus.subscribe_all(handler)
    else:
        for et in event_types:
            event_bus.subscribe(et, handler)

    try:
        # replay a little recent history so a new connection isn't blank
        for event in event_bus.history(limit=20):
            if event_types is None or event.type in event_types:
                await websocket.send_json(event.to_dict())

        while True:
            event = await queue.get()
            await websocket.send_json(event.to_dict())
    except WebSocketDisconnect:
        pass
    finally:
        if event_types is None:
            event_bus.unsubscribe_all(handler)
        else:
            for et in event_types:
                event_bus.unsubscribe(et, handler)


@router.websocket("/ws/market")
async def ws_market(websocket: WebSocket):
    await _serve_channel(websocket, "market", default_bus)


@router.websocket("/ws/orderbook")
async def ws_orderbook(websocket: WebSocket):
    await _serve_channel(websocket, "orderbook", default_bus)


@router.websocket("/ws/prices")
async def ws_prices(websocket: WebSocket):
    await _serve_channel(websocket, "prices", default_bus)


@router.websocket("/ws/capacity")
async def ws_capacity(websocket: WebSocket):
    await _serve_channel(websocket, "capacity", default_bus)


@router.websocket("/ws/trades")
async def ws_trades(websocket: WebSocket):
    await _serve_channel(websocket, "trades", default_bus)


@router.websocket("/ws/datacenters")
async def ws_datacenters(websocket: WebSocket):
    await _serve_channel(websocket, "datacenters", default_bus)
