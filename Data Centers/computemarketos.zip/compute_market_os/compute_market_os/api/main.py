"""Compute Market OS — FastAPI application entrypoint.

SIMULATED MARKET — bundled synthetic data is for demonstration only and
is NOT live market data.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from compute_market_os import __version__
from compute_market_os.api import websockets as ws
from compute_market_os.api.metrics import MetricsMiddleware
from compute_market_os.api.routers import (
    auctions,
    capacity,
    contracts,
    datacenters,
    forecast,
    hardware,
    health,
    index,
    inference,
    market,
    optimise,
    orderbook,
    prices,
    providers,
    regions,
    training,
)
from compute_market_os.core.config import get_settings
from compute_market_os.core.database import SessionLocal, init_db
from compute_market_os.core.seed import seed_hardware_catalog

logging.basicConfig(level=get_settings().log_level)
logger = logging.getLogger("compute_market_os")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    with SessionLocal() as session:
        created = seed_hardware_catalog(session)
        if created:
            logger.info("seeded %d hardware SKUs into the database", created)
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="Compute Market OS",
        description=(
            "Compute Capacity Exchange & Pricing Engine — a programmable market "
            "for GPU/CPU/TPU/accelerator capacity. SIMULATED MARKET, not live data."
        ),
        version=__version__,
        lifespan=lifespan,
    )
    app.add_middleware(MetricsMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    for router_module in (
        health,
        hardware,
        regions,
        providers,
        datacenters,
        capacity,
        market,
        orderbook,
        prices,
        contracts,
        auctions,
        inference,
        training,
        forecast,
        index,
        optimise,
    ):
        app.include_router(router_module.router)

    app.include_router(ws.router)

    @app.get("/")
    def root():
        return {
            "name": "Compute Market OS",
            "version": __version__,
            "disclaimer": "SIMULATED MARKET — NOT LIVE MARKET DATA",
            "docs": "/docs",
        }

    return app


app = create_app()
