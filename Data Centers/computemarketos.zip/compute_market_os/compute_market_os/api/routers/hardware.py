"""GET /api/hardware (section 49)."""

from __future__ import annotations

import dataclasses

from fastapi import APIRouter, HTTPException

from compute_market_os.core.schemas import HardwareOut
from compute_market_os.domain.hardware import load_hardware_catalog

router = APIRouter(prefix="/api/hardware", tags=["hardware"])


@router.get("", response_model=list[HardwareOut])
def list_hardware(category: str | None = None):
    catalog = load_hardware_catalog()
    items = list(catalog.values())
    if category:
        items = [hw for hw in items if hw.category == category]
    return [HardwareOut(**dataclasses.asdict(hw)) for hw in items]


@router.get("/{hardware_id}", response_model=HardwareOut)
def get_hardware(hardware_id: str):
    catalog = load_hardware_catalog()
    hw = catalog.get(hardware_id)
    if hw is None:
        raise HTTPException(status_code=404, detail="hardware not found")
    return HardwareOut(**dataclasses.asdict(hw))
