"""GET /api/regions (section 49) — backs the regional price curve (section
33) and the network latency graph (section 26)."""

from __future__ import annotations

from fastapi import APIRouter

from compute_market_os.api.state import get_network_latency_engine
from compute_market_os.core.config import load_yaml_config

router = APIRouter(prefix="/api/regions", tags=["regions"])


@router.get("")
def list_regions():
    return load_yaml_config("regions")["regions"]


@router.get("/{region_code}/routes")
def region_routes(region_code: str):
    engine = get_network_latency_engine()
    routes = {}
    for other in engine.regions():
        if other == region_code:
            continue
        route = engine.route(region_code, other)
        if route:
            routes[other] = {
                "latency_ms": route.latency_ms,
                "bottleneck_bandwidth_gbps": route.bottleneck_bandwidth_gbps,
                "cost_per_gb": route.total_cost_per_gb,
                "availability": route.availability,
                "path": route.path,
            }
    return {"region": region_code, "routes": routes}
