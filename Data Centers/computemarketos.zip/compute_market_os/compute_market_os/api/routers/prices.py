"""GET /api/prices (sections 14-17, 49, 66)."""

from __future__ import annotations

from fastapi import APIRouter, Query

from compute_market_os.api.state import get_market, get_pricing_engine, get_spot_market
from compute_market_os.pricing.vwap import vwap_by

router = APIRouter(prefix="/api/prices", tags=["prices"])


@router.get("")
def current_prices():
    spot_market = get_spot_market()
    return [
        {"hardware_id": hw, "region": region, "price_per_hour": price}
        for (hw, region), price in spot_market.all_current_prices().items()
    ]


@router.get("/quote")
def price_quote(
    hardware_id: str,
    utilisation: float = Query(ge=0.0, le=1.0),
    segment: str = "spot",
    duration_hours: float | None = None,
    days_ahead: float | None = None,
    electricity_price_per_kwh: float | None = None,
    pue: float | None = None,
):
    engine = get_pricing_engine()
    kwargs = dict(electricity_price_per_kwh=electricity_price_per_kwh, pue=pue)
    segment = segment.lower()
    if segment == "spot":
        price = engine.spot_price(hardware_id, utilisation, **kwargs)
    elif segment == "on_demand":
        price = engine.on_demand_price(hardware_id, utilisation, **kwargs)
    elif segment == "reservation":
        price = engine.reservation_price(hardware_id, utilisation, duration_hours=duration_hours or 720, **kwargs)
    elif segment == "forward":
        price = engine.forward_price(hardware_id, utilisation, days_ahead=days_ahead or 30, **kwargs)
    elif segment == "auction_reserve":
        price = engine.auction_reserve_price(hardware_id, utilisation, **kwargs)
    else:
        return {"error": f"unknown segment {segment!r}"}
    breakdown = engine.compute_price(hardware_id, utilisation, **kwargs)
    return {"segment": segment, "price_per_hour": price, "breakdown": breakdown.as_dict()}


@router.get("/vwap")
def vwap(hardware_id: str | None = None, region: str | None = None, provider_id: str | None = None):
    market = get_market()
    value = vwap_by(market.trade_tape, hardware_id=hardware_id, region=region, provider_id=provider_id)
    return {"hardware_id": hardware_id, "region": region, "provider_id": provider_id, "vwap": value}
