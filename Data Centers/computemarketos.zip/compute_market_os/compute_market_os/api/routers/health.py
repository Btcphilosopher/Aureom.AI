"""Health / readiness / metrics endpoints (section 71)."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.metrics import metrics_response
from compute_market_os import __version__

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {"status": "ok", "version": __version__}


@router.get("/ready")
def ready(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:  # noqa: BLE001
        db_ok = False
    return {"status": "ready" if db_ok else "not_ready", "database": db_ok}


@router.get("/metrics")
def metrics():
    return metrics_response()
