"""GET /api/datacenters (sections 7, 8, 49)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.core import models
from compute_market_os.core.schemas import DataCenterOut, InventoryOut
from compute_market_os.domain.datacenter import DataCenter

router = APIRouter(prefix="/api/datacenters", tags=["datacenters"])


@router.get("", response_model=list[DataCenterOut])
def list_datacenters(region: str | None = None, provider_id: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.DataCenter)
    if region:
        query = query.filter(models.DataCenter.region == region)
    if provider_id:
        query = query.filter(models.DataCenter.provider_id == provider_id)
    return query.all()


@router.get("/{datacenter_id}", response_model=DataCenterOut)
def get_datacenter(datacenter_id: str, db: Session = Depends(get_db)):
    dc = db.get(models.DataCenter, datacenter_id)
    if dc is None:
        raise HTTPException(status_code=404, detail="datacenter not found")
    return dc


@router.get("/{datacenter_id}/inventory", response_model=list[InventoryOut])
def datacenter_inventory(datacenter_id: str, db: Session = Depends(get_db)):
    return db.query(models.InventoryItem).filter(models.InventoryItem.datacenter_id == datacenter_id).all()


@router.get("/{datacenter_id}/power")
def datacenter_power(datacenter_id: str, db: Session = Depends(get_db)):
    """Section 38: reports the physical power envelope and how much
    headroom remains before PowerConstraint would refuse new capacity."""
    row = db.get(models.DataCenter, datacenter_id)
    if row is None:
        raise HTTPException(status_code=404, detail="datacenter not found")
    dc = DataCenter.from_orm_row(row)
    return {
        "datacenter_id": dc.id,
        "power_capacity_mw": dc.power_capacity_mw,
        "it_load_mw": dc.it_load_mw,
        "cooling_load_mw": round(dc.cooling_load_mw, 4),
        "total_power_draw_mw": round(dc.total_power_draw_mw, 4),
        "available_power_mw": round(dc.available_power_mw, 4),
        "pue": dc.pue,
    }
