"""GET /api/providers + provider capacity publishing (sections 6, 49, 77)."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.core import models
from compute_market_os.core.events import EventType, default_bus
from compute_market_os.core.schemas import ProviderOut

router = APIRouter(prefix="/api/providers", tags=["providers"])


@router.get("", response_model=list[ProviderOut])
def list_providers(region: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Provider)
    if region:
        query = query.filter(models.Provider.region == region)
    return query.all()


@router.get("/{provider_id}", response_model=ProviderOut)
def get_provider(provider_id: str, db: Session = Depends(get_db)):
    provider = db.get(models.Provider, provider_id)
    if provider is None:
        raise HTTPException(status_code=404, detail="provider not found")
    return provider


class PublishCapacityRequest(BaseModel):
    datacenter: str  # datacenter code
    hardware: str    # hardware id
    quantity: int = Field(gt=0)
    available_from: dt.date
    available_until: dt.date
    price_per_gpu_hour: float


@router.post("/{provider_id}/capacity")
def publish_capacity(provider_id: str, payload: PublishCapacityRequest, db: Session = Depends(get_db)):
    """Section 77: provider.publish_capacity(...) — automatically updates
    the market's inventory (installed + available quantity) for the given
    (datacenter, hardware) pair."""
    provider = db.get(models.Provider, provider_id)
    if provider is None:
        raise HTTPException(status_code=404, detail="provider not found")

    datacenter = db.query(models.DataCenter).filter(
        models.DataCenter.code == payload.datacenter, models.DataCenter.provider_id == provider_id
    ).first()
    if datacenter is None:
        raise HTTPException(status_code=404, detail="datacenter not found for this provider")

    hardware = db.get(models.Hardware, payload.hardware)
    if hardware is None:
        raise HTTPException(status_code=404, detail="hardware not found")

    inventory = (
        db.query(models.InventoryItem)
        .filter(models.InventoryItem.datacenter_id == datacenter.id, models.InventoryItem.hardware_id == hardware.id)
        .with_for_update(read=False)
        .first()
    )
    if inventory is None:
        inventory = models.InventoryItem(
            datacenter_id=datacenter.id,
            hardware_id=hardware.id,
            installed_quantity=0,
            available_quantity=0,
        )
        db.add(inventory)

    inventory.installed_quantity += payload.quantity
    inventory.available_quantity += payload.quantity
    db.commit()

    default_bus.emit(
        EventType.CAPACITY_ADDED,
        provider_id=provider_id,
        datacenter_id=datacenter.id,
        hardware_id=hardware.id,
        quantity=payload.quantity,
        price_per_gpu_hour=payload.price_per_gpu_hour,
        available_from=payload.available_from.isoformat(),
        available_until=payload.available_until.isoformat(),
    )
    return {
        "provider_id": provider_id,
        "datacenter_id": datacenter.id,
        "hardware_id": hardware.id,
        "installed_quantity": inventory.installed_quantity,
        "available_quantity": inventory.available_quantity,
    }
