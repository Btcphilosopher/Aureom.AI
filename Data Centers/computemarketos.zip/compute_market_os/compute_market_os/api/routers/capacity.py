"""GET /api/capacity + the capacity reservation ledger (sections 8, 29, 38,
39, 49).

Reservations run inside a single DB transaction with a row-level lock
(`SELECT ... FOR UPDATE` via `with_for_update()`) on the inventory row, so
concurrent reservation requests against the same (datacenter, hardware)
pair cannot double-sell capacity, and every reservation is checked against
the datacenter's physical `PowerConstraint` before it is committed.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import get_reservation_market, get_spot_market
from compute_market_os.core import models
from compute_market_os.core.events import EventType, default_bus
from compute_market_os.core.schemas import ReservationCreate, ReservationOut
from compute_market_os.domain.datacenter import DataCenter, PowerConstraint
from compute_market_os.domain.inventory import InventorySnapshot, UtilisationEngine

router = APIRouter(prefix="/api/capacity", tags=["capacity"])


@router.get("")
def capacity_summary(hardware_id: str | None = None, region: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.InventoryItem).join(models.DataCenter)
    if hardware_id:
        query = query.filter(models.InventoryItem.hardware_id == hardware_id)
    if region:
        query = query.filter(models.DataCenter.region == region)
    snapshots = [InventorySnapshot.from_orm_row(row) for row in query.all()]
    return UtilisationEngine.aggregate(snapshots)


@router.get("/breakdown")
def capacity_breakdown(hardware_id: str | None = None, region: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.InventoryItem).join(models.DataCenter)
    if hardware_id:
        query = query.filter(models.InventoryItem.hardware_id == hardware_id)
    if region:
        query = query.filter(models.DataCenter.region == region)
    return [InventorySnapshot.from_orm_row(row).as_dict() for row in query.all()]


@router.post("/reservations", response_model=ReservationOut)
def create_reservation(payload: ReservationCreate, db: Session = Depends(get_db)):
    datacenter_row = db.get(models.DataCenter, payload.datacenter_id)
    if datacenter_row is None:
        raise HTTPException(status_code=404, detail="datacenter not found")
    hardware_row = db.get(models.Hardware, payload.hardware_id)
    if hardware_row is None:
        raise HTTPException(status_code=404, detail="hardware not found")

    inventory = (
        db.query(models.InventoryItem)
        .filter(
            models.InventoryItem.datacenter_id == payload.datacenter_id,
            models.InventoryItem.hardware_id == payload.hardware_id,
        )
        .with_for_update(read=False)
        .first()
    )
    if inventory is None or inventory.available_quantity < payload.quantity:
        raise HTTPException(status_code=409, detail="insufficient available capacity for this reservation")

    power_check = PowerConstraint().check(
        DataCenter.from_orm_row(datacenter_row), payload.quantity, hardware_row.power_watts
    )
    if not power_check.allowed:
        raise HTTPException(status_code=409, detail=power_check.reason)

    reservation_market = get_reservation_market()
    spot_market = get_spot_market()
    utilisation = 1.0 - (inventory.available_quantity / inventory.installed_quantity) if inventory.installed_quantity else 0.7
    spot_price = spot_market.tick(payload.hardware_id, datacenter_row.region, utilisation).price

    domain_reservation = reservation_market.reserve(
        provider_id=payload.provider_id,
        datacenter_id=payload.datacenter_id,
        hardware_id=payload.hardware_id,
        quantity=payload.quantity,
        start_time=payload.start_time,
        end_time=payload.end_time,
        spot_price_per_hour=spot_price,
        buyer_id=payload.buyer_id,
        daily_window_start_hour=payload.daily_window_start_hour,
        daily_window_end_hour=payload.daily_window_end_hour,
    )

    inventory.available_quantity -= payload.quantity
    inventory.reserved_quantity += payload.quantity

    row = models.Reservation(
        id=domain_reservation.id,
        buyer_id=payload.buyer_id,
        provider_id=payload.provider_id,
        datacenter_id=payload.datacenter_id,
        hardware_id=payload.hardware_id,
        quantity=payload.quantity,
        start_time=payload.start_time,
        end_time=payload.end_time,
        daily_window_start_hour=payload.daily_window_start_hour,
        daily_window_end_hour=payload.daily_window_end_hour,
        base_price_per_hour=domain_reservation.base_price_per_hour,
        premium_fraction=domain_reservation.premium_fraction,
        total_price_per_hour=domain_reservation.total_price_per_hour,
    )
    db.add(row)
    db.commit()

    default_bus.emit(
        EventType.RESERVATION_CREATED,
        reservation_id=row.id,
        datacenter_id=payload.datacenter_id,
        hardware_id=payload.hardware_id,
        quantity=payload.quantity,
    )
    return row


@router.get("/reservations", response_model=list[ReservationOut])
def list_reservations(provider_id: str | None = None, hardware_id: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Reservation)
    if provider_id:
        query = query.filter(models.Reservation.provider_id == provider_id)
    if hardware_id:
        query = query.filter(models.Reservation.hardware_id == hardware_id)
    return query.all()


@router.delete("/reservations/{reservation_id}")
def cancel_reservation(reservation_id: str, db: Session = Depends(get_db)):
    row = (
        db.query(models.Reservation)
        .filter(models.Reservation.id == reservation_id)
        .with_for_update(read=False)
        .first()
    )
    if row is None:
        raise HTTPException(status_code=404, detail="reservation not found")
    if row.status != "active":
        raise HTTPException(status_code=409, detail=f"reservation is already {row.status}")

    inventory = (
        db.query(models.InventoryItem)
        .filter(
            models.InventoryItem.datacenter_id == row.datacenter_id,
            models.InventoryItem.hardware_id == row.hardware_id,
        )
        .with_for_update(read=False)
        .first()
    )
    if inventory is not None:
        inventory.available_quantity += row.quantity
        inventory.reserved_quantity = max(inventory.reserved_quantity - row.quantity, 0)

    row.status = "cancelled"
    db.commit()
    return {"reservation_id": reservation_id, "status": "cancelled"}
