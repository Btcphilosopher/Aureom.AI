"""POST /api/inference (sections 22-23, 49)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from compute_market_os.ai_markets.inference_market import InferenceOffer
from compute_market_os.api.state import get_inference_market
from compute_market_os.core.schemas import InferenceOfferCreate, InferenceRequest

router = APIRouter(prefix="/api/inference", tags=["inference"])


@router.post("/offers")
def publish_offer(payload: InferenceOfferCreate):
    market = get_inference_market()
    market.publish_offer(
        InferenceOffer(
            provider_id=payload.provider_id,
            model_name=payload.model_name,
            quantisation=payload.quantisation,
            hardware_id=payload.hardware_id,
            region=payload.region,
            tokens_per_second=payload.tokens_per_second,
            first_token_latency_ms=payload.first_token_latency_ms,
            price_per_1m_input_tokens=payload.price_per_1m_input_tokens,
            price_per_1m_output_tokens=payload.price_per_1m_output_tokens,
        )
    )
    return {"status": "published"}


@router.get("/offers")
def list_offers(model_name: str, region: str | None = None):
    market = get_inference_market()
    return market.offers_for_model(model_name, region)


@router.post("/quote")
def quote(payload: InferenceRequest):
    market = get_inference_market()
    quotes = market.quote(
        model_name=payload.model_name,
        input_tokens=payload.est_input_tokens,
        output_tokens=payload.est_output_tokens,
        max_latency_ms=payload.max_latency_ms,
        region=payload.region,
        budget=payload.budget,
    )
    if not quotes:
        raise HTTPException(status_code=404, detail="no inference offers found for this model/region")
    return quotes


@router.post("/best")
def best(payload: InferenceRequest):
    market = get_inference_market()
    result = market.best_offer(
        model_name=payload.model_name,
        input_tokens=payload.est_input_tokens,
        output_tokens=payload.est_output_tokens,
        max_latency_ms=payload.max_latency_ms,
        region=payload.region,
        budget=payload.budget,
    )
    if result is None:
        raise HTTPException(status_code=404, detail="no compliant inference offer found")
    return result
