"""GET /api/market + order submission/matching (sections 9, 12, 49, 75)."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import get_forward_market, get_market
from compute_market_os.core import models
from compute_market_os.core.schemas import MarketSummary, OrderCreate, OrderOut, TradeOut
from compute_market_os.domain.inventory import InventorySnapshot, UtilisationEngine
from compute_market_os.market.order import next_order_id
from compute_market_os.pricing.vwap import calculate_vwap

router = APIRouter(prefix="/api/market", tags=["market"])


@router.get("", response_model=MarketSummary)
def market_summary(db: Session = Depends(get_db)):
    market = get_market()
    forward_market = get_forward_market()

    snapshots = [InventorySnapshot.from_orm_row(row) for row in db.query(models.InventoryItem).all()]
    utilisation_stats = UtilisationEngine.aggregate(snapshots)

    all_trades = market.trade_tape
    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=24)
    recent_trades = [t for t in all_trades if t.timestamp >= cutoff]
    older_trades = [t for t in all_trades if t.timestamp < cutoff]

    trade_volume_24h = sum(t.quantity * t.duration_hours for t in recent_trades)
    average_price_24h = calculate_vwap(recent_trades) or 0.0
    previous_vwap = calculate_vwap(older_trades)
    price_change_pct = (
        (average_price_24h - previous_vwap) / previous_vwap if previous_vwap else 0.0
    )

    open_orders = [
        o for book in market.all_books() for o in book.all_orders() if o.status.value in ("open", "partially_filled")
    ]
    demand = sum(o.remaining_quantity for o in open_orders if o.side.value == "BUY")
    supply = utilisation_stats["available_capacity"]

    return MarketSummary(
        global_compute_price=round(average_price_24h, 4),
        supply=supply,
        demand=demand,
        utilisation=utilisation_stats["utilisation_pct"] / 100.0,
        open_interest=forward_market.open_interest_gpu_hours(),
        trade_volume_24h=round(trade_volume_24h, 2),
        average_price_24h=round(average_price_24h, 4),
        price_change_24h_pct=round(price_change_pct, 4),
    )


@router.post("/orders", response_model=OrderOut)
def submit_order(payload: OrderCreate, db: Session = Depends(get_db)):
    market = get_market()
    try:
        order = market.submit_order(
            side=payload.side,
            hardware=payload.hardware_id,
            region=payload.region,
            quantity=payload.quantity,
            duration_hours=payload.duration_hours,
            limit_price=payload.limit_price,
            order_type=payload.order_type,
            min_memory_gb=payload.min_memory_gb,
            min_performance_score=payload.min_performance_score,
            max_latency_ms=payload.max_latency_ms,
            buyer_id=payload.buyer_id,
            provider_id=payload.provider_id,
            start_time=payload.start_time,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    row = models.Order(
        id=order.id,
        side=order.side.value,
        order_type=order.order_type.value,
        market_segment=payload.market_segment,
        hardware_id=order.hardware_id,
        region=order.region,
        quantity=order.quantity,
        duration_hours=order.duration_hours,
        limit_price=order.limit_price,
        min_performance_score=order.min_performance_score,
        min_memory_gb=order.min_memory_gb,
        max_latency_ms=order.max_latency_ms,
        start_time=order.start_time,
        status=order.status.value,
        buyer_id=order.buyer_id,
        provider_id=order.provider_id,
    )
    db.add(row)
    db.commit()
    return row


@router.delete("/orders/{order_id}")
def cancel_order(order_id: str, hardware_id: str, region: str, db: Session = Depends(get_db)):
    market = get_market()
    ok = market.cancel_order(hardware_id, region, order_id)
    if not ok:
        raise HTTPException(status_code=404, detail="order not found or already resolved")
    row = db.get(models.Order, order_id)
    if row is not None:
        row.status = "cancelled"
        row.cancelled_at = dt.datetime.now(dt.timezone.utc)
        db.commit()
    return {"order_id": order_id, "status": "cancelled"}


@router.post("/match", response_model=list[TradeOut])
def match(hardware_id: str | None = None, region: str | None = None, db: Session = Depends(get_db)):
    market = get_market()
    trades = market.match(hardware=hardware_id, region=region) if hardware_id and region else market.match()

    rows = []
    for trade in trades:
        row = models.Trade(
            id=trade.id,
            buy_order_id=trade.buy_order.id,
            sell_order_id=trade.sell_order.id,
            hardware_id=trade.hardware_id,
            region=trade.region,
            quantity=trade.quantity,
            price=trade.price,
            duration_hours=trade.duration_hours,
            buyer_id=trade.buyer_id,
            seller_provider_id=trade.seller_provider_id,
        )
        db.add(row)
        rows.append(row)
        for order in (trade.buy_order, trade.sell_order):
            order_row = db.get(models.Order, order.id)
            if order_row is not None:
                order_row.filled_quantity = order.filled_quantity
                order_row.status = order.status.value
    db.commit()
    return rows


@router.get("/trades", response_model=list[TradeOut])
def recent_trades(hardware_id: str | None = None, region: str | None = None, limit: int = 100, db: Session = Depends(get_db)):
    query = db.query(models.Trade)
    if hardware_id:
        query = query.filter(models.Trade.hardware_id == hardware_id)
    if region:
        query = query.filter(models.Trade.region == region)
    return query.order_by(models.Trade.executed_at.desc()).limit(limit).all()
