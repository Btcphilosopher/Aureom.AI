"""GET /api/orderbook (sections 11, 49)."""

from __future__ import annotations

from fastapi import APIRouter

from compute_market_os.api.state import get_market
from compute_market_os.core.schemas import OrderBookSnapshot

router = APIRouter(prefix="/api/orderbook", tags=["orderbook"])


@router.get("", response_model=OrderBookSnapshot)
def orderbook(hardware_id: str, region: str, levels: int = 25):
    market = get_market()
    return market.orderbook_snapshot(hardware_id, region, levels)


@router.get("/all")
def all_orderbooks():
    market = get_market()
    return [book.snapshot() for book in market.all_books()]
