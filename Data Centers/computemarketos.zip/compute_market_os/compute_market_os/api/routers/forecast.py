"""GET/POST /api/forecast (sections 30, 31, 49, 60)."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import get_forward_curve
from compute_market_os.core import models
from compute_market_os.forecasting.capacity_forecast import CapacityForecastEngine
from compute_market_os.forecasting.price_forecast import PriceForecastEngine

router = APIRouter(prefix="/api/forecast", tags=["forecast"])

_price_forecaster = PriceForecastEngine()
_capacity_forecaster = CapacityForecastEngine()


@router.get("/price")
def forecast_price(hardware_id: str, region: str, db: Session = Depends(get_db)):
    rows = (
        db.execute(
            select(models.PricePoint)
            .where(models.PricePoint.hardware_id == hardware_id, models.PricePoint.region == region)
            .order_by(models.PricePoint.timestamp)
        )
        .scalars()
        .all()
    )
    if len(rows) < _price_forecaster.MIN_OBSERVATIONS:
        raise HTTPException(
            status_code=422,
            detail=f"need at least {_price_forecaster.MIN_OBSERVATIONS} historical price points for {hardware_id}/{region}, have {len(rows)}",
        )
    prices = [r.price for r in rows]
    timestamps = [r.timestamp for r in rows]
    points = _price_forecaster.forecast(prices, timestamps)
    return [dataclasses_as_dict(p) for p in points]


class CapacityForecastRequest(BaseModel):
    history_demand: list[float]
    history_supply: list[float]
    history_timestamps: list[dt.datetime]
    horizon_hours: list[float]
    known_future_reservations: dict[float, float] | None = None
    planned_capacity_additions: dict[float, float] | None = None


@router.post("/capacity")
def forecast_capacity(payload: CapacityForecastRequest):
    try:
        points = _capacity_forecaster.forecast(
            history_demand=payload.history_demand,
            history_supply=payload.history_supply,
            history_timestamps=payload.history_timestamps,
            horizon_hours=payload.horizon_hours,
            known_future_reservations=payload.known_future_reservations,
            planned_capacity_additions=payload.planned_capacity_additions,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return [dataclasses_as_dict(p) for p in points]


@router.get("/curve")
def forward_curve(hardware_id: str, utilisation: float = 0.75):
    curve_engine = get_forward_curve()
    points = curve_engine.curve_for_hardware(hardware_id, utilisation)
    return [dataclasses_as_dict(p) for p in points]


def dataclasses_as_dict(obj) -> dict:
    import dataclasses

    d = dataclasses.asdict(obj)
    for k, v in d.items():
        if isinstance(v, dt.datetime):
            d[k] = v.isoformat()
    return d
