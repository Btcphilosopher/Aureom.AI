"""POST /api/training (section 24, 49)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from compute_market_os.ai_markets.training_market import TrainingMarket
from compute_market_os.api.state import get_pricing_engine
from compute_market_os.core.schemas import TrainingRequest
from compute_market_os.domain.hardware import load_hardware_catalog

router = APIRouter(prefix="/api/training", tags=["training"])

_training_market = TrainingMarket()


@router.post("/estimate")
def estimate(payload: TrainingRequest, utilisation: float = 0.75):
    catalog = load_hardware_catalog()
    hardware = catalog.get(payload.hardware_id)
    if hardware is None:
        raise HTTPException(status_code=404, detail="hardware not found")

    pricing_engine = get_pricing_engine()
    price_per_gpu_hour = pricing_engine.on_demand_price(payload.hardware_id, utilisation)

    estimate_result = _training_market.estimate(
        model_name=payload.model_name,
        model_params_billion=payload.model_params_billion,
        tokens_billion=payload.tokens_billion,
        hardware=hardware,
        gpu_count=payload.gpu_count,
        price_per_gpu_hour=price_per_gpu_hour,
    )
    result = {
        "model_name": estimate_result.model_name,
        "gpu_count": estimate_result.gpu_count,
        "total_flops": estimate_result.total_flops,
        "parallel_efficiency": estimate_result.parallel_efficiency,
        "estimated_training_hours": estimate_result.estimated_training_hours,
        "estimated_gpu_hours": estimate_result.estimated_gpu_hours,
        "estimated_cost": estimate_result.estimated_cost,
        "price_per_gpu_hour": estimate_result.price_per_gpu_hour,
    }
    if payload.budget is not None:
        result["within_budget"] = estimate_result.estimated_cost <= payload.budget
    return result
