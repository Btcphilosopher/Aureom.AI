"""GET/POST /api/auctions (sections 19-21, 49)."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import get_auction_engine
from compute_market_os.core import models
from compute_market_os.core.enums import AuctionStatus
from compute_market_os.core.events import EventType, default_bus
from compute_market_os.core.schemas import AuctionCreate, AuctionOut, BidCreate
from compute_market_os.market.auction_engine import Auction, Bid

router = APIRouter(prefix="/api/auctions", tags=["auctions"])

# Live domain Auction objects, keyed by id — mirrored into the DB for
# durability/history, matched against for clearing logic.
_live_auctions: dict[str, Auction] = {}


@router.get("", response_model=list[AuctionOut])
def list_auctions(status: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Auction)
    if status:
        query = query.filter(models.Auction.status == status)
    return query.all()


@router.post("", response_model=AuctionOut)
def create_auction(payload: AuctionCreate, db: Session = Depends(get_db)):
    engine = get_auction_engine()
    reserve_price = payload.reserve_price if payload.reserve_price is not None else 0.0
    auction = engine.create_auction(
        auction_type=payload.auction_type,
        hardware_id=payload.hardware_id,
        region=payload.region,
        quantity_offered=payload.quantity_gpu_hours,
        reserve_price=reserve_price,
        provider_id=payload.provider_id,
    )
    _live_auctions[auction.id] = auction

    closes_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=payload.duration_minutes)
    row = models.Auction(
        id=auction.id,
        auction_type=payload.auction_type,
        hardware_id=payload.hardware_id,
        region=payload.region,
        quantity_gpu_hours=payload.quantity_gpu_hours,
        provider_id=payload.provider_id,
        reserve_price=reserve_price,
        status=AuctionStatus.OPEN.value,
        closes_at=closes_at,
    )
    db.add(row)
    db.commit()
    return row


def _get_live_auction(auction_id: str) -> Auction:
    auction = _live_auctions.get(auction_id)
    if auction is None:
        raise HTTPException(status_code=404, detail="auction not found or not tracked by the live auction engine")
    return auction


@router.post("/{auction_id}/bids")
def submit_bid(auction_id: str, payload: BidCreate, db: Session = Depends(get_db)):
    engine = get_auction_engine()
    auction = _get_live_auction(auction_id)
    bid = Bid(
        bidder_id=payload.bidder_id,
        price=payload.price,
        quantity=payload.quantity,
        performance_score=payload.performance_score,
    )
    try:
        engine.submit_bid(auction, bid)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    row = models.AuctionBid(
        auction_id=auction_id,
        bidder_id=payload.bidder_id,
        price=payload.price,
        quantity=payload.quantity,
        performance_score=payload.performance_score,
    )
    db.add(row)
    db.commit()
    return {"auction_id": auction_id, "bidder_id": payload.bidder_id, "accepted": True}


@router.post("/{auction_id}/clear")
def clear_auction(auction_id: str, db: Session = Depends(get_db)):
    engine = get_auction_engine()
    auction = _get_live_auction(auction_id)
    result = engine.clear(auction)

    row = db.get(models.Auction, auction_id)
    if row is not None:
        row.status = result.status.value
        row.clearing_price = result.clearing_price
        row.winning_bidder_id = result.winners[0]["bidder_id"] if result.winners else None
        row.cleared_at = dt.datetime.now(dt.timezone.utc)
        db.commit()

    default_bus.emit(EventType.AUCTION_CLEARED, auction_id=auction_id, clearing_price=result.clearing_price, status=result.status.value)
    return {
        "auction_id": auction_id,
        "status": result.status.value,
        "clearing_price": result.clearing_price,
        "total_quantity_cleared": result.total_quantity_cleared,
        "winners": result.winners,
        "best_bid": result.best_bid.bidder_id if result.best_bid else None,
        "second_best_bid": result.second_best_bid.bidder_id if result.second_best_bid else None,
        "performance_adjusted_best": result.performance_adjusted_best.bidder_id if result.performance_adjusted_best else None,
        "reason": result.reason,
    }
