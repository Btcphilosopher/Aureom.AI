"""POST /api/optimise — buyer/provider optimisers, arbitrage, equilibrium
(sections 35-37, 63-64, 76)."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import (
    get_arbitrage_engine,
    get_buyer_optimizer,
    get_carbon_scheduler,
    get_equilibrium_engine,
    get_pricing_engine,
    get_provider_optimizer,
)
from compute_market_os.core import models
from compute_market_os.core.schemas import BuyerRequest
from compute_market_os.domain.hardware import ComputePerformanceIndex, load_hardware_catalog
from compute_market_os.optimisation.buyer_optimizer import CapacityOffer
from compute_market_os.optimisation.equilibrium_engine import LinearCurve

router = APIRouter(prefix="/api/optimise", tags=["optimise"])


def _offers_from_inventory(db: Session, hardware_id: str, region: str | None, cpi_profile: str) -> list[CapacityOffer]:
    catalog = load_hardware_catalog()
    hw = catalog.get(hardware_id)
    cpi = ComputePerformanceIndex()
    score = cpi.score(hw, cpi_profile) if hw else 0.0

    query = db.query(models.InventoryItem, models.DataCenter, models.Provider).join(
        models.DataCenter, models.InventoryItem.datacenter_id == models.DataCenter.id
    ).join(models.Provider, models.DataCenter.provider_id == models.Provider.id).filter(
        models.InventoryItem.hardware_id == hardware_id, models.InventoryItem.available_quantity > 0
    )
    if region:
        query = query.filter(models.DataCenter.region == region)

    offers = []
    for inventory, datacenter, provider in query.all():
        utilisation = (
            1.0 - inventory.available_quantity / inventory.installed_quantity if inventory.installed_quantity else 0.7
        )
        price = get_pricing_engine().spot_price(hardware_id, max(min(utilisation, 0.98), 0.02))
        carbon = get_carbon_scheduler().estimate(hw, datacenter.region, datacenter.pue) if hw else None
        offers.append(
            CapacityOffer(
                provider_id=provider.id,
                datacenter_id=datacenter.id,
                hardware_id=hardware_id,
                region=datacenter.region,
                quantity_available=inventory.available_quantity,
                price_per_hour=price,
                performance_score=score,
                carbon_kgco2e_per_hour=carbon.kgco2e_per_gpu_hour if carbon else None,
                reliability=provider.reliability,
            )
        )
    return offers


@router.post("/buyer")
def buyer_optimise(payload: BuyerRequest, db: Session = Depends(get_db)):
    optimizer = get_buyer_optimizer()
    offers = _offers_from_inventory(db, payload.hardware_id, payload.region, payload.workload or "general_purpose")
    recommendations = optimizer.find_compute(
        offers=offers,
        quantity=payload.quantity,
        duration_hours=payload.duration_hours,
        max_price_per_hour=payload.max_price_per_hour,
        min_memory_gb=payload.min_memory_gb,
        max_latency_ms=payload.max_latency_ms,
        max_carbon_intensity_total=payload.max_carbon_intensity,
        budget=payload.budget,
    )
    return {
        label: {
            "provider_id": rec.offer.provider_id,
            "datacenter_id": rec.offer.datacenter_id,
            "region": rec.offer.region,
            "price_per_hour": rec.price_per_hour,
            "total_cost": rec.total_cost,
            "estimated_performance_score": rec.estimated_performance_score,
            "estimated_latency_ms": rec.estimated_latency_ms,
            "estimated_carbon_kgco2e": rec.estimated_carbon_kgco2e,
            "value_score": rec.value_score,
        }
        for label, rec in recommendations.items()
    }


class ProviderOptimiseRequest(BaseModel):
    hardware_id: str
    available_units: int
    utilisation: float
    desired_margin_fraction: float = 0.18
    electricity_price_per_kwh: float | None = None
    pue: float | None = None


@router.post("/provider")
def provider_optimise(payload: ProviderOptimiseRequest):
    optimizer = get_provider_optimizer()
    recommendation = optimizer.recommend(
        hardware_id=payload.hardware_id,
        available_units=payload.available_units,
        utilisation=payload.utilisation,
        desired_margin_fraction=payload.desired_margin_fraction,
        electricity_price_per_kwh=payload.electricity_price_per_kwh,
        pue=payload.pue,
    )
    return recommendation


class ArbitrageRequest(BaseModel):
    hardware_id: str
    region_a: str
    price_a: float
    region_b: str
    price_b: float
    data_movement_gb: float = 0.0
    workload_migratable: bool = True
    runtime_hours: float = 1.0


@router.post("/arbitrage")
def arbitrage(payload: ArbitrageRequest):
    engine = get_arbitrage_engine()
    return engine.evaluate(
        hardware_id=payload.hardware_id,
        region_a=payload.region_a,
        price_a=payload.price_a,
        region_b=payload.region_b,
        price_b=payload.price_b,
        data_movement_gb=payload.data_movement_gb,
        workload_migratable=payload.workload_migratable,
        runtime_hours=payload.runtime_hours,
    )


class EquilibriumRequest(BaseModel):
    demand_intercept: float
    demand_slope: float
    supply_intercept: float
    supply_slope: float
    demand_shock_pct: float | None = None


@router.post("/equilibrium")
def equilibrium(payload: EquilibriumRequest):
    engine = get_equilibrium_engine()
    demand = LinearCurve(payload.demand_intercept, payload.demand_slope)
    supply = LinearCurve(payload.supply_intercept, payload.supply_slope)
    baseline = engine.solve(demand, supply)
    result = {"baseline": {"price": baseline.price, "quantity": baseline.quantity}}
    if payload.demand_shock_pct is not None:
        shocked_demand = engine.apply_demand_shock(demand, payload.demand_shock_pct)
        shocked = engine.solve(shocked_demand, supply)
        result["shocked"] = {"price": shocked.price, "quantity": shocked.quantity}
    return result
