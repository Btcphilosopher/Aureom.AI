"""GET /api/index — Compute Price Index (sections 32, 49, 67)."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, HTTPException

from compute_market_os.api.state import get_index_engine, get_pricing_engine, get_spot_market
from compute_market_os.core.schemas import IndexOut

router = APIRouter(prefix="/api/index", tags=["index"])


@router.get("")
def list_indices():
    return get_index_engine().available_indices()


@router.get("/{index_code}", response_model=IndexOut)
def get_index(index_code: str, utilisation: float = 0.75):
    engine = get_index_engine()
    pricing_engine = get_pricing_engine()
    spot_market = get_spot_market()
    try:
        basket = engine.basket(index_code)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    region = basket.get("region")
    component_prices: dict[str, float] = {}
    for component in basket["weights"]:
        if component.startswith("hw-"):
            cached = spot_market.current_price(component, region) if region else None
            component_prices[component] = cached if cached is not None else pricing_engine.spot_price(component, utilisation)
        # non-hardware components (e.g. "inference", "storage") are left
        # for the caller to supply via richer integrations; they're
        # reported as missing rather than guessed.

    result = engine.compute(index_code, component_prices)
    return IndexOut(
        index_code=result.index_code,
        value=result.value,
        components=result.components,
        timestamp=dt.datetime.now(dt.timezone.utc),
    )
