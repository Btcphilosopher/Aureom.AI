"""GET/POST /api/contracts — forward + long-term contracts (sections 17,
45, 49)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from compute_market_os.api.deps import get_db
from compute_market_os.api.state import get_forward_market
from compute_market_os.core import models
from compute_market_os.core.events import EventType, default_bus
from compute_market_os.core.schemas import ContractCreate, ContractOut

router = APIRouter(prefix="/api/contracts", tags=["contracts"])


@router.get("", response_model=list[ContractOut])
def list_contracts(provider_id: str | None = None, status: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.ComputeContract)
    if provider_id:
        query = query.filter(models.ComputeContract.provider_id == provider_id)
    if status:
        query = query.filter(models.ComputeContract.status == status)
    return query.all()


@router.get("/{contract_id}", response_model=ContractOut)
def get_contract(contract_id: str, db: Session = Depends(get_db)):
    row = db.get(models.ComputeContract, contract_id)
    if row is None:
        raise HTTPException(status_code=404, detail="contract not found")
    return row


@router.post("", response_model=ContractOut)
def create_contract(payload: ContractCreate, db: Session = Depends(get_db)):
    if payload.delivery_end <= payload.delivery_start:
        raise HTTPException(status_code=422, detail="delivery_end must be after delivery_start")

    forward_market = get_forward_market()
    domain_contract = forward_market.create_contract(
        hardware_id=payload.hardware_id,
        region=payload.region,
        gpu_hours=payload.quantity * (payload.delivery_end - payload.delivery_start).total_seconds() / 3600.0,
        strike_price_per_hour=payload.strike_price_per_hour,
        delivery_start=payload.delivery_start,
        delivery_end=payload.delivery_end,
        buyer_id=payload.buyer_id,
        provider_id=payload.provider_id,
    )

    row = models.ComputeContract(
        id=domain_contract.id,
        contract_type=payload.contract_type,
        buyer_id=payload.buyer_id,
        provider_id=payload.provider_id,
        hardware_id=payload.hardware_id,
        quantity=payload.quantity,
        region=payload.region,
        delivery_start=payload.delivery_start,
        delivery_end=payload.delivery_end,
        strike_price_per_hour=payload.strike_price_per_hour,
        gpu_hours_total=domain_contract.gpu_hours,
        sla_tier=payload.sla_tier,
        status="pending",
    )
    db.add(row)
    db.commit()

    default_bus.emit(EventType.CONTRACT_CREATED, contract_id=row.id, hardware_id=payload.hardware_id, region=payload.region)
    return row


@router.post("/{contract_id}/deliver")
def deliver_contract(contract_id: str, gpu_hours: float, db: Session = Depends(get_db)):
    forward_market = get_forward_market()
    row = db.get(models.ComputeContract, contract_id)
    if row is None:
        raise HTTPException(status_code=404, detail="contract not found")
    if forward_market.get(contract_id) is None:
        raise HTTPException(status_code=409, detail="contract not tracked by the live forward market (process restarted?)")

    try:
        domain_contract = forward_market.deliver(contract_id, gpu_hours)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    row.gpu_hours_delivered = domain_contract.gpu_hours_delivered
    row.status = domain_contract.status
    db.commit()
    return {"contract_id": contract_id, "gpu_hours_delivered": row.gpu_hours_delivered, "status": row.status}


@router.get("/{contract_id}/settlement")
def settle_contract(contract_id: str, market_price_per_hour: float | None = None):
    forward_market = get_forward_market()
    if forward_market.get(contract_id) is None:
        raise HTTPException(status_code=404, detail="contract not tracked by the live forward market")
    return forward_market.settle(contract_id, market_price_per_hour)
