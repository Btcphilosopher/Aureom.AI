"""ComputeArbitrageEngine (section 34).

A raw price gap between two regions is never treated as automatically
exploitable. The net opportunity accounts for:
  - network transfer time/cost to move data/workload between regions
  - route availability (reliability of the path)
  - workload suitability (does the workload even tolerate the added
    latency / a migration at all — caller-supplied flag)

Net opportunity is only reported as positive when it clears after these
costs; otherwise the engine explicitly reports it as NOT exploitable.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.optimisation.network_latency_engine import NetworkLatencyEngine


@dataclasses.dataclass(slots=True, frozen=True)
class ArbitrageOpportunity:
    hardware_id: str
    region_a: str
    region_b: str
    price_a: float
    price_b: float
    raw_price_gap_per_hour: float
    data_movement_gb: float
    transfer_cost: float | None
    transfer_time_seconds: float | None
    route_availability: float | None
    workload_migratable: bool
    net_gap_per_gpu_hour: float | None
    exploitable: bool
    reason: str


class ComputeArbitrageEngine:
    def __init__(self, latency_engine: NetworkLatencyEngine | None = None) -> None:
        self.latency_engine = latency_engine or NetworkLatencyEngine()

    def evaluate(
        self,
        hardware_id: str,
        region_a: str,
        price_a: float,
        region_b: str,
        price_b: float,
        data_movement_gb: float = 0.0,
        workload_migratable: bool = True,
        min_route_availability: float = 0.98,
        runtime_hours: float = 1.0,
    ) -> ArbitrageOpportunity:
        cheaper, pricier = (region_a, region_b) if price_a < price_b else (region_b, region_a)
        raw_gap = abs(price_a - price_b)

        if not workload_migratable:
            return ArbitrageOpportunity(
                hardware_id, region_a, region_b, price_a, price_b, round(raw_gap, 6),
                data_movement_gb, None, None, None, False, None, False,
                reason="workload is not migratable between regions",
            )

        route = self.latency_engine.route(pricier, cheaper)
        if route is None:
            return ArbitrageOpportunity(
                hardware_id, region_a, region_b, price_a, price_b, round(raw_gap, 6),
                data_movement_gb, None, None, None, workload_migratable, None, False,
                reason="no known network route between regions",
            )

        transfer_cost = self.latency_engine.transfer_cost(pricier, cheaper, data_movement_gb) or 0.0
        transfer_time = self.latency_engine.transfer_time_seconds(pricier, cheaper, data_movement_gb) or 0.0

        # amortise one-off transfer cost over the runtime as an hourly cost.
        amortised_transfer_cost_per_hour = transfer_cost / runtime_hours if runtime_hours > 0 else transfer_cost
        net_gap = raw_gap - amortised_transfer_cost_per_hour

        exploitable = net_gap > 0 and route.availability >= min_route_availability
        reason = (
            "net price gap clears transfer cost and route meets availability threshold"
            if exploitable
            else (
                "route availability below threshold"
                if route.availability < min_route_availability
                else "transfer cost erases the price gap"
            )
        )
        return ArbitrageOpportunity(
            hardware_id=hardware_id,
            region_a=region_a,
            region_b=region_b,
            price_a=price_a,
            price_b=price_b,
            raw_price_gap_per_hour=round(raw_gap, 6),
            data_movement_gb=data_movement_gb,
            transfer_cost=round(transfer_cost, 4),
            transfer_time_seconds=round(transfer_time, 2),
            route_availability=route.availability,
            workload_migratable=workload_migratable,
            net_gap_per_gpu_hour=round(net_gap, 6),
            exploitable=exploitable,
            reason=reason,
        )
