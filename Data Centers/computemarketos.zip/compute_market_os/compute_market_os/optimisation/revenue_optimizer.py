"""ProviderRevenueOptimizer (section 37).

Maximises revenue = Σ price_segment * units_segment subject to:
  - total capacity available
  - a physical power budget (each unit draws `unit_power_mw`)
  - per-segment availability/contract caps

Solved as a small linear program with SciPy (`scipy.optimize.linprog`,
which minimises — so the objective is negated).
"""

from __future__ import annotations

import dataclasses

import numpy as np
from scipy.optimize import linprog


@dataclasses.dataclass(slots=True, frozen=True)
class MarketSegmentOffer:
    name: str
    price_per_hour: float
    max_units: int | None = None  # None = unbounded by this segment, still bounded by total capacity


@dataclasses.dataclass(slots=True, frozen=True)
class RevenueAllocation:
    allocation: dict[str, float]
    expected_revenue_per_hour: float
    capacity_used: float
    power_used_mw: float
    feasible: bool
    message: str = ""


class ProviderRevenueOptimizer:
    def optimise(
        self,
        segments: list[MarketSegmentOffer],
        total_capacity_units: int,
        unit_power_mw: float,
        available_power_mw: float,
    ) -> RevenueAllocation:
        n = len(segments)
        if n == 0:
            return RevenueAllocation({}, 0.0, 0.0, 0.0, False, "no segments supplied")

        c = [-s.price_per_hour for s in segments]  # negate: linprog minimises

        A_ub = [[1.0] * n]                          # Σ units <= total capacity
        b_ub = [float(total_capacity_units)]
        if unit_power_mw > 0:
            A_ub.append([unit_power_mw] * n)         # Σ units * power <= available power
            b_ub.append(float(available_power_mw))

        bounds = [(0, s.max_units if s.max_units is not None else total_capacity_units) for s in segments]

        result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not result.success:
            return RevenueAllocation({}, 0.0, 0.0, 0.0, False, result.message)

        allocation = {s.name: round(float(x), 3) for s, x in zip(segments, result.x)}
        capacity_used = float(np.sum(result.x))
        power_used = capacity_used * unit_power_mw
        revenue = -float(result.fun)
        return RevenueAllocation(
            allocation=allocation,
            expected_revenue_per_hour=round(revenue, 2),
            capacity_used=round(capacity_used, 3),
            power_used_mw=round(power_used, 6),
            feasible=True,
        )
