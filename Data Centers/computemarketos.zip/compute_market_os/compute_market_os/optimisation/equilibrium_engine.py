"""MarketEquilibriumEngine (section 63).

Finds equilibrium price/quantity given linear supply/demand curves that
the caller configures:

    Qd(P) = demand_intercept  - demand_slope  * P
    Qs(P) = supply_intercept  + supply_slope  * P

Equilibrium: Qd(P*) = Qs(P*)
    P* = (demand_intercept - supply_intercept) / (demand_slope + supply_slope)
    Q* = Qd(P*)

Also powers the demand-shock scenario in section 64 by re-solving after
shifting the demand intercept.
"""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(slots=True, frozen=True)
class LinearCurve:
    intercept: float
    slope: float  # demand: Qd = intercept - slope*P (slope > 0); supply: Qs = intercept + slope*P (slope > 0)

    def quantity_at(self, price: float, is_demand: bool) -> float:
        return self.intercept - self.slope * price if is_demand else self.intercept + self.slope * price


@dataclasses.dataclass(slots=True, frozen=True)
class EquilibriumResult:
    price: float
    quantity: float
    demand_curve: LinearCurve
    supply_curve: LinearCurve


class MarketEquilibriumEngine:
    def solve(self, demand: LinearCurve, supply: LinearCurve) -> EquilibriumResult:
        denom = demand.slope + supply.slope
        if denom <= 0:
            raise ValueError("demand.slope + supply.slope must be positive for a unique equilibrium")
        price = (demand.intercept - supply.intercept) / denom
        price = max(price, 0.0)
        quantity = max(demand.quantity_at(price, is_demand=True), 0.0)
        return EquilibriumResult(price=round(price, 6), quantity=round(quantity, 4), demand_curve=demand, supply_curve=supply)

    def apply_demand_shock(self, demand: LinearCurve, pct_change: float) -> LinearCurve:
        """Shift demand intercept by pct_change (e.g. +0.40 for a +40%
        demand shock) while keeping the same slope (elasticity)."""
        return LinearCurve(intercept=demand.intercept * (1 + pct_change), slope=demand.slope)
