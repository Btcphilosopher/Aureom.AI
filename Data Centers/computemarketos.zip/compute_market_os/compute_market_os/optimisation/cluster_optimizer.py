"""ClusterOptimizer (section 25).

Compares candidate cluster sizes (8/16/.../128+ GPUs) for a training
workload, accounting for parallel efficiency loss from communication
overhead as the cluster scales — never assumes linear scaling.

Model (transparent, configurable, documented — not a hardware-vendor
scaling law):

  parallel_efficiency(n) = 1 / (1 + comm_overhead_coefficient * log2(n))

  effective_throughput(n) = n * per_gpu_tflops * parallel_efficiency(n)

  training_time_hours = total_training_flops / (effective_throughput * 3600)

`comm_overhead_coefficient` depends on interconnect quality (e.g. NVLink/
InfiniBand vs Ethernet) and is passed in by the caller rather than
hard-coded, since it is workload/topology specific.
"""

from __future__ import annotations

import dataclasses
import math

from compute_market_os.domain.hardware import ComputeHardware


@dataclasses.dataclass(slots=True, frozen=True)
class ClusterOption:
    gpu_count: int
    parallel_efficiency: float
    effective_tflops: float
    training_time_hours: float
    total_gpu_hours: float
    total_cost: float


class ClusterOptimizer:
    DEFAULT_CANDIDATE_SIZES = (8, 16, 32, 64, 128)

    def compare(
        self,
        hardware: ComputeHardware,
        total_training_pflop_s_days: float,  # total compute budget, in PFLOP/s-days (common training-compute unit)
        price_per_gpu_hour: float,
        comm_overhead_coefficient: float = 0.06,
        candidate_sizes: tuple[int, ...] | None = None,
        tflops_field: str = "training_tflops_effective",
    ) -> list[ClusterOption]:
        per_gpu_tflops = hardware.benchmarks.get(tflops_field, hardware.compute_score)
        if per_gpu_tflops <= 0:
            raise ValueError(f"hardware {hardware.id} has no usable throughput for field {tflops_field!r}")

        total_flops = total_training_pflop_s_days * 1e15 * 86400  # PFLOP/s-days -> FLOPs

        options = []
        for n in candidate_sizes or self.DEFAULT_CANDIDATE_SIZES:
            efficiency = 1.0 / (1.0 + comm_overhead_coefficient * math.log2(max(n, 1)))
            effective_tflops = n * per_gpu_tflops * efficiency
            effective_flops_per_sec = effective_tflops * 1e12
            training_seconds = total_flops / effective_flops_per_sec
            training_hours = training_seconds / 3600.0
            total_gpu_hours = training_hours * n
            total_cost = total_gpu_hours * price_per_gpu_hour
            options.append(
                ClusterOption(
                    gpu_count=n,
                    parallel_efficiency=round(efficiency, 4),
                    effective_tflops=round(effective_tflops, 2),
                    training_time_hours=round(training_hours, 3),
                    total_gpu_hours=round(total_gpu_hours, 2),
                    total_cost=round(total_cost, 2),
                )
            )
        return options

    def best_for_deadline(self, options: list[ClusterOption], deadline_hours: float) -> ClusterOption | None:
        feasible = [o for o in options if o.training_time_hours <= deadline_hours]
        if not feasible:
            return None
        return min(feasible, key=lambda o: o.total_cost)

    def cheapest(self, options: list[ClusterOption]) -> ClusterOption:
        return min(options, key=lambda o: o.total_cost)

    def fastest(self, options: list[ClusterOption]) -> ClusterOption:
        return min(options, key=lambda o: o.training_time_hours)
