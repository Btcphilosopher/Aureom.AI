"""ProviderOptimizer (section 36).

Recommends spot price, reservation price, auction reserve, and a capacity
allocation split given a provider's inventory, energy cost, desired
margin, and availability — built directly on the PricingEngine so the
recommendation always traces back to the same cost model buyers see.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.pricing.pricing_engine import PricingEngine


@dataclasses.dataclass(slots=True, frozen=True)
class ProviderPriceRecommendation:
    hardware_id: str
    spot_price_per_hour: float
    reservation_price_per_hour: float
    auction_reserve_price_per_hour: float
    on_demand_price_per_hour: float
    recommended_margin_fraction: float
    allocation: dict[str, int]  # segment -> unit count


class ProviderOptimizer:
    def __init__(self, pricing_engine: PricingEngine | None = None) -> None:
        self.pricing_engine = pricing_engine or PricingEngine()

    def recommend(
        self,
        hardware_id: str,
        available_units: int,
        utilisation: float,
        desired_margin_fraction: float,
        electricity_price_per_kwh: float | None = None,
        pue: float | None = None,
        spot_allocation_fraction: float = 0.5,
        reservation_allocation_fraction: float = 0.35,
        auction_allocation_fraction: float = 0.15,
    ) -> ProviderPriceRecommendation:
        total_fraction = spot_allocation_fraction + reservation_allocation_fraction + auction_allocation_fraction
        if abs(total_fraction - 1.0) > 1e-6:
            raise ValueError("allocation fractions must sum to 1.0")

        kwargs = dict(
            electricity_price_per_kwh=electricity_price_per_kwh,
            pue=pue,
            margin_fraction=desired_margin_fraction,
        )
        spot = self.pricing_engine.spot_price(hardware_id, utilisation, **kwargs)
        on_demand = self.pricing_engine.on_demand_price(hardware_id, utilisation, **kwargs)
        reservation = self.pricing_engine.reservation_price(hardware_id, utilisation, duration_hours=720, **kwargs)
        auction_reserve = self.pricing_engine.auction_reserve_price(hardware_id, utilisation, **kwargs)

        allocation = {
            "SPOT": int(round(available_units * spot_allocation_fraction)),
            "RESERVED": int(round(available_units * reservation_allocation_fraction)),
            "AUCTION": int(round(available_units * auction_allocation_fraction)),
        }
        # Reconcile rounding drift back onto SPOT so allocations sum exactly.
        drift = available_units - sum(allocation.values())
        allocation["SPOT"] += drift

        return ProviderPriceRecommendation(
            hardware_id=hardware_id,
            spot_price_per_hour=spot,
            reservation_price_per_hour=reservation,
            auction_reserve_price_per_hour=auction_reserve,
            on_demand_price_per_hour=on_demand,
            recommended_margin_fraction=desired_margin_fraction,
            allocation=allocation,
        )
