"""ElasticityEngine (section 62).

Price elasticity is computed only from historical (price, quantity) data
the caller supplies — never fabricated. Uses a log-log OLS regression
(scipy.stats.linregress): for Q = a * P^b, ln(Q) = ln(a) + b*ln(P), so the
regression slope *is* the elasticity.
"""

from __future__ import annotations

import dataclasses
import math

from scipy import stats


@dataclasses.dataclass(slots=True, frozen=True)
class ElasticityResult:
    elasticity: float
    r_squared: float
    n_observations: int
    interpretation: str


class ElasticityEngine:
    MIN_OBSERVATIONS = 3

    def _log_log_regression(self, prices: list[float], quantities: list[float]) -> ElasticityResult:
        if len(prices) != len(quantities):
            raise ValueError("prices and quantities must be the same length")
        pairs = [(p, q) for p, q in zip(prices, quantities) if p > 0 and q > 0]
        if len(pairs) < self.MIN_OBSERVATIONS:
            raise ValueError(
                f"need at least {self.MIN_OBSERVATIONS} positive (price, quantity) observations, "
                f"got {len(pairs)} — elasticity is never fabricated from insufficient data"
            )
        log_p = [math.log(p) for p, _ in pairs]
        log_q = [math.log(q) for _, q in pairs]
        regression = stats.linregress(log_p, log_q)
        return ElasticityResult(
            elasticity=round(regression.slope, 4),
            r_squared=round(regression.rvalue**2, 4),
            n_observations=len(pairs),
            interpretation="elastic" if abs(regression.slope) > 1 else "inelastic",
        )

    def price_elasticity_of_demand(self, prices: list[float], quantities_demanded: list[float]) -> ElasticityResult:
        return self._log_log_regression(prices, quantities_demanded)

    def price_elasticity_of_supply(self, prices: list[float], quantities_supplied: list[float]) -> ElasticityResult:
        return self._log_log_regression(prices, quantities_supplied)
