"""BuyerOptimizer (sections 35 + 76).

Ranks candidate capacity offers against a buyer's request under each
optimisation goal (BEST_PRICE, FASTEST, BEST_PERFORMANCE, LOWEST_CARBON,
BEST_VALUE, BEST_LATENCY). Every ranking is computed from the
`CapacityOffer` list supplied by the caller (typically assembled from the
DB/inventory in the API layer) — nothing here invents supply.
"""

from __future__ import annotations

import dataclasses

from ortools.sat.python import cp_model

from compute_market_os.core.enums import OptimisationGoal


@dataclasses.dataclass(slots=True, frozen=True)
class CapacityOffer:
    provider_id: str
    datacenter_id: str
    hardware_id: str
    region: str
    quantity_available: int
    price_per_hour: float
    performance_score: float = 0.0
    latency_ms: float | None = None
    carbon_kgco2e_per_hour: float | None = None
    reliability: float = 0.99


@dataclasses.dataclass(slots=True, frozen=True)
class Recommendation:
    label: str
    offer: CapacityOffer
    quantity: int
    duration_hours: float
    price_per_hour: float
    total_cost: float
    estimated_performance_score: float
    estimated_latency_ms: float | None
    estimated_carbon_kgco2e: float | None
    value_score: float
    notes: str = ""


@dataclasses.dataclass(slots=True, frozen=True)
class MultiSourceAllocation:
    feasible: bool
    allocation: list[dict]  # [{provider_id, datacenter_id, region, units, price_per_hour}, ...]
    total_units: int
    total_cost: float
    message: str = ""


class BuyerOptimizer:
    def allocate_multi_source(
        self,
        offers: list[CapacityOffer],
        quantity: int,
        duration_hours: float,
        max_sources: int | None = None,
    ) -> MultiSourceAllocation:
        """When no single offer covers the full requested quantity, solve
        a small integer program (OR-Tools CP-SAT) for the cheapest
        combination of offers that together cover it — a multi-source
        capacity allocation, e.g. splitting a 512-GPU request across three
        providers in the same region."""
        if not offers:
            return MultiSourceAllocation(False, [], 0, 0.0, "no offers supplied")
        if sum(o.quantity_available for o in offers) < quantity:
            return MultiSourceAllocation(False, [], 0, 0.0, "combined available capacity is below requested quantity")

        model = cp_model.CpModel()
        # Prices are floats; CP-SAT needs integers, so scale to integer
        # "cost units" (hundredths of a currency unit) for the objective.
        scale = 100
        units = [model.NewIntVar(0, o.quantity_available, f"x{i}") for i, o in enumerate(offers)]

        model.Add(sum(units) >= quantity)
        if max_sources is not None:
            used = [model.NewBoolVar(f"used{i}") for i in range(len(offers))]
            for u, x, offer in zip(used, units, offers):
                model.Add(x > 0).OnlyEnforceIf(u)
                model.Add(x == 0).OnlyEnforceIf(u.Not())
            model.Add(sum(used) <= max_sources)

        model.Minimize(
            sum(int(round(o.price_per_hour * duration_hours * scale)) * x for o, x in zip(offers, units))
        )

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 5.0
        status = solver.Solve(model)

        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return MultiSourceAllocation(False, [], 0, 0.0, "solver found no feasible allocation")

        allocation = []
        total_units = 0
        total_cost = 0.0
        for offer, x in zip(offers, units):
            taken = solver.Value(x)
            if taken <= 0:
                continue
            cost = round(taken * offer.price_per_hour * duration_hours, 2)
            allocation.append(
                {
                    "provider_id": offer.provider_id,
                    "datacenter_id": offer.datacenter_id,
                    "region": offer.region,
                    "units": taken,
                    "price_per_hour": offer.price_per_hour,
                    "cost": cost,
                }
            )
            total_units += taken
            total_cost += cost

        return MultiSourceAllocation(True, allocation, total_units, round(total_cost, 2))

    def find_compute(
        self,
        offers: list[CapacityOffer],
        quantity: int,
        duration_hours: float,
        max_price_per_hour: float | None = None,
        min_memory_gb: float | None = None,  # informational filter, applied by caller upstream typically
        max_latency_ms: float | None = None,
        max_carbon_intensity_total: float | None = None,
        budget: float | None = None,
    ) -> dict[str, Recommendation]:
        feasible = [
            o
            for o in offers
            if o.quantity_available >= quantity
            and (max_price_per_hour is None or o.price_per_hour <= max_price_per_hour)
            and (max_latency_ms is None or o.latency_ms is None or o.latency_ms <= max_latency_ms)
        ]
        if budget is not None:
            feasible = [o for o in feasible if o.price_per_hour * quantity * duration_hours <= budget]
        if max_carbon_intensity_total is not None:
            feasible = [
                o
                for o in feasible
                if o.carbon_kgco2e_per_hour is None
                or o.carbon_kgco2e_per_hour * quantity * duration_hours <= max_carbon_intensity_total
            ]
        if not feasible:
            return {}

        def to_rec(label: str, offer: CapacityOffer) -> Recommendation:
            total_cost = round(offer.price_per_hour * quantity * duration_hours, 2)
            carbon_total = (
                round(offer.carbon_kgco2e_per_hour * quantity * duration_hours, 4)
                if offer.carbon_kgco2e_per_hour is not None
                else None
            )
            # BEST_VALUE composite: performance per £, reliability-weighted.
            value_score = (
                (offer.performance_score * offer.reliability) / offer.price_per_hour
                if offer.price_per_hour > 0
                else 0.0
            )
            return Recommendation(
                label=label,
                offer=offer,
                quantity=quantity,
                duration_hours=duration_hours,
                price_per_hour=offer.price_per_hour,
                total_cost=total_cost,
                estimated_performance_score=offer.performance_score,
                estimated_latency_ms=offer.latency_ms,
                estimated_carbon_kgco2e=carbon_total,
                value_score=round(value_score, 6),
            )

        results: dict[str, Recommendation] = {}
        results[OptimisationGoal.BEST_PRICE.value] = to_rec(
            OptimisationGoal.BEST_PRICE.value, min(feasible, key=lambda o: o.price_per_hour)
        )
        results[OptimisationGoal.BEST_PERFORMANCE.value] = to_rec(
            OptimisationGoal.BEST_PERFORMANCE.value, max(feasible, key=lambda o: o.performance_score)
        )
        latency_candidates = [o for o in feasible if o.latency_ms is not None]
        if latency_candidates:
            results[OptimisationGoal.BEST_LATENCY.value] = to_rec(
                OptimisationGoal.BEST_LATENCY.value, min(latency_candidates, key=lambda o: o.latency_ms)
            )
            results[OptimisationGoal.FASTEST.value] = results[OptimisationGoal.BEST_LATENCY.value]
        carbon_candidates = [o for o in feasible if o.carbon_kgco2e_per_hour is not None]
        if carbon_candidates:
            results[OptimisationGoal.LOWEST_CARBON.value] = to_rec(
                OptimisationGoal.LOWEST_CARBON.value,
                min(carbon_candidates, key=lambda o: o.carbon_kgco2e_per_hour),
            )
        best_value_offer = max(
            feasible,
            key=lambda o: (o.performance_score * o.reliability) / o.price_per_hour if o.price_per_hour > 0 else 0.0,
        )
        results[OptimisationGoal.BEST_VALUE.value] = to_rec(OptimisationGoal.BEST_VALUE.value, best_value_offer)
        return results
