"""NetworkLatencyEngine (section 26).

Represents regions as a NetworkX graph (nodes = regions, edges = latency /
bandwidth / cost / availability) loaded from config/regions.yaml, and
optimises compute placement across candidate regions given latency, cost,
and capacity constraints.
"""

from __future__ import annotations

import dataclasses
import functools

import networkx as nx

from compute_market_os.core.config import load_yaml_config


@dataclasses.dataclass(slots=True, frozen=True)
class RouteInfo:
    path: list[str]
    latency_ms: float
    bottleneck_bandwidth_gbps: float
    total_cost_per_gb: float
    availability: float


@functools.lru_cache
def build_region_graph() -> nx.Graph:
    raw = load_yaml_config("regions")
    graph = nx.Graph()
    for region in raw.get("regions", []):
        graph.add_node(
            region["code"],
            name=region["name"],
            country=region["country"],
            latitude=region["latitude"],
            longitude=region["longitude"],
            grid_carbon_intensity_gco2_per_kwh=region["grid_carbon_intensity_gco2_per_kwh"],
            electricity_price_per_kwh=region["electricity_price_per_kwh"],
        )
    for a, b, latency_ms, bandwidth_gbps, cost_per_gb, availability in raw.get("edges", []):
        graph.add_edge(
            a,
            b,
            latency_ms=latency_ms,
            bandwidth_gbps=bandwidth_gbps,
            cost_per_gb=cost_per_gb,
            availability=availability,
        )
    return graph


class NetworkLatencyEngine:
    def __init__(self, graph: nx.Graph | None = None) -> None:
        self.graph = graph if graph is not None else build_region_graph()

    def regions(self) -> list[str]:
        return list(self.graph.nodes)

    def route(self, source: str, target: str) -> RouteInfo | None:
        if source == target:
            return RouteInfo(path=[source], latency_ms=0.0, bottleneck_bandwidth_gbps=float("inf"), total_cost_per_gb=0.0, availability=1.0)
        if source not in self.graph or target not in self.graph:
            return None
        try:
            path = nx.shortest_path(self.graph, source, target, weight="latency_ms")
        except nx.NetworkXNoPath:
            return None
        latency = 0.0
        bandwidth = float("inf")
        cost = 0.0
        availability = 1.0
        for a, b in zip(path, path[1:]):
            edge = self.graph.edges[a, b]
            latency += edge["latency_ms"]
            bandwidth = min(bandwidth, edge["bandwidth_gbps"])
            cost += edge["cost_per_gb"]
            availability *= edge["availability"]
        return RouteInfo(
            path=path,
            latency_ms=round(latency, 3),
            bottleneck_bandwidth_gbps=bandwidth,
            total_cost_per_gb=round(cost, 6),
            availability=round(availability, 6),
        )

    def transfer_time_seconds(self, source: str, target: str, data_gb: float) -> float | None:
        route = self.route(source, target)
        if route is None or route.bottleneck_bandwidth_gbps <= 0:
            return None
        return round((data_gb * 8) / route.bottleneck_bandwidth_gbps + route.latency_ms / 1000.0, 4)

    def transfer_cost(self, source: str, target: str, data_gb: float) -> float | None:
        route = self.route(source, target)
        if route is None:
            return None
        return round(route.total_cost_per_gb * data_gb, 4)

    def rank_regions_by_latency(self, origin: str, candidates: list[str]) -> list[tuple[str, float]]:
        scored = []
        for region in candidates:
            route = self.route(origin, region)
            if route is not None:
                scored.append((region, route.latency_ms))
        return sorted(scored, key=lambda pair: pair[1])

    def within_latency_budget(self, origin: str, candidates: list[str], max_latency_ms: float) -> list[str]:
        return [r for r, latency in self.rank_regions_by_latency(origin, candidates) if latency <= max_latency_ms]
