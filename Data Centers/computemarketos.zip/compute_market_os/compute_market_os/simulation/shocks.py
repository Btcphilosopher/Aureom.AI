"""Market shocks (section 42) + the demonstration demand-shock scenario
(section 64).

A shock mutates the simulation's demand/supply/cost parameters; the
market itself (equilibrium engine, pricing engine, matching engine) then
recomputes price/utilisation/capacity from those mutated inputs — the
shock module never writes a "final result" directly, per the spec's
"do not hard-code the final result" instruction.
"""

from __future__ import annotations

import dataclasses
import enum


class ShockType(str, enum.Enum):
    GPU_SHORTAGE = "gpu_shortage"
    POWER_SHORTAGE = "power_shortage"
    DATACENTER_OUTAGE = "datacenter_outage"
    NETWORK_OUTAGE = "network_outage"
    AI_DEMAND_SPIKE = "ai_demand_spike"
    ELECTRICITY_PRICE_SPIKE = "electricity_price_spike"
    NEW_GPU_LAUNCH = "new_gpu_launch"
    REGIONAL_DEMAND_SURGE = "regional_demand_surge"


@dataclasses.dataclass(slots=True, frozen=True)
class MarketShock:
    shock_type: ShockType
    magnitude: float  # interpretation depends on shock_type (e.g. +0.40 = +40%)
    hardware_id: str | None = None
    region: str | None = None
    at_tick: int = 0
    description: str = ""


@dataclasses.dataclass(slots=True)
class MarketState:
    """Mutable simulation state a shock is applied to. Kept intentionally
    small/explicit so its effect is auditable — nothing here is hidden
    inside a black-box model."""

    demand_multiplier: float = 1.0
    supply_multiplier: float = 1.0
    electricity_price_multiplier: float = 1.0
    utilisation_offset: float = 0.0
    capacity_offline_fraction: float = 0.0
    performance_multiplier: float = 1.0  # e.g. a new, faster GPU generation


def apply_shock(state: MarketState, shock: MarketShock) -> MarketState:
    if shock.shock_type == ShockType.GPU_SHORTAGE:
        state.supply_multiplier *= max(1 - shock.magnitude, 0.0)
    elif shock.shock_type == ShockType.POWER_SHORTAGE:
        state.supply_multiplier *= max(1 - shock.magnitude, 0.0)
        state.capacity_offline_fraction = min(state.capacity_offline_fraction + shock.magnitude, 1.0)
    elif shock.shock_type == ShockType.DATACENTER_OUTAGE:
        state.capacity_offline_fraction = min(state.capacity_offline_fraction + shock.magnitude, 1.0)
        state.supply_multiplier *= max(1 - shock.magnitude, 0.0)
    elif shock.shock_type == ShockType.NETWORK_OUTAGE:
        state.utilisation_offset -= shock.magnitude * 0.5  # workloads can't be placed efficiently
    elif shock.shock_type == ShockType.AI_DEMAND_SPIKE:
        state.demand_multiplier *= 1 + shock.magnitude
    elif shock.shock_type == ShockType.ELECTRICITY_PRICE_SPIKE:
        state.electricity_price_multiplier *= 1 + shock.magnitude
    elif shock.shock_type == ShockType.NEW_GPU_LAUNCH:
        state.performance_multiplier *= 1 + shock.magnitude
        state.supply_multiplier *= 1 + shock.magnitude * 0.5  # some buyers migrate to the new SKU, freeing old capacity
    elif shock.shock_type == ShockType.REGIONAL_DEMAND_SURGE:
        state.demand_multiplier *= 1 + shock.magnitude
    return state
