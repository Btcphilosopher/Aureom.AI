"""ComputeMarketSimulation (sections 40-42, 64).

A SimPy discrete-event simulation: buyer/provider agents periodically
submit orders into a real `ComputeMarket` (the same engine the API uses),
a recorder process snapshots order-book/price/utilisation state on every
tick, and scheduled `MarketShock`s mutate the underlying demand/supply
parameters mid-run — so price and utilisation are *computed* by the
matching/pricing engines reacting to the shock, never hard-coded.

SIMULATED MARKET — output is synthetic and for demonstration only.
"""

from __future__ import annotations

import dataclasses
import datetime as dt

import numpy as np
import pandas as pd
import simpy

from compute_market_os.domain.hardware import load_hardware_catalog
from compute_market_os.market.market import ComputeMarket
from compute_market_os.market.spot_market import SpotMarket
from compute_market_os.simulation.agents import (
    BuyerAgent,
    ProviderAgent,
    generate_buyer_agents,
    generate_provider_agents,
)
from compute_market_os.simulation.shocks import MarketShock, MarketState, apply_shock


@dataclasses.dataclass(slots=True)
class SimulationResult:
    price_history: pd.DataFrame
    utilisation_history: pd.DataFrame
    trade_count: int
    orders_submitted: int
    shocks_applied: list[str]


class ComputeMarketSimulation:
    def __init__(
        self,
        hardware_ids: list[str] | None = None,
        regions: list[str] | None = None,
        base_installed_capacity: int = 4000,
        seed: int = 42,
    ) -> None:
        self.rng = np.random.default_rng(seed)
        catalog = load_hardware_catalog()
        self.hardware_ids = hardware_ids or list(catalog.keys())
        self.regions = regions or ["TPE", "SIN", "IAD", "FRA"]
        self.base_installed_capacity = base_installed_capacity

        self.market = ComputeMarket()
        self.spot_market = SpotMarket()
        self.state = MarketState()
        self._scheduled_shocks: list[MarketShock] = []

        self.buyers: list[BuyerAgent] = []
        self.providers: list[ProviderAgent] = []

        self._price_rows: list[dict] = []
        self._util_rows: list[dict] = []
        self._orders_submitted = 0

    # -- setup -----------------------------------------------------------------

    def generate_participants(self, num_buyers: int, num_providers: int) -> None:
        self.buyers = generate_buyer_agents(num_buyers, self.rng, region_pool=self.regions)
        self.providers = generate_provider_agents(num_providers, self.rng)

    def schedule_shock(self, shock: MarketShock) -> None:
        self._scheduled_shocks.append(shock)

    # -- processes ---------------------------------------------------------------

    def _installed_capacity(self, hardware_id: str, region: str) -> int:
        return max(int(self.base_installed_capacity * self.state.supply_multiplier), 1)

    def _current_utilisation(self, hardware_id: str, region: str) -> float:
        book = self.market.book(hardware_id, region)
        traded = sum(t.quantity for t in self.market.recent_trades(hardware_id, region, limit=10_000))
        installed = self._installed_capacity(hardware_id, region)
        base = min(traded / installed, 1.0) if installed else 0.0
        return float(np.clip(base + self.state.utilisation_offset, 0.02, 0.98))

    def _buyer_process(self, env: simpy.Environment, agent: BuyerAgent):
        while True:
            interarrival = self.rng.exponential(3.0)
            yield env.timeout(interarrival)

            hardware_id = self.hardware_ids[self.rng.integers(0, len(self.hardware_ids))]
            region = agent.preferred_region or self.regions[self.rng.integers(0, len(self.regions))]
            quantity = max(int(agent.demand_gpus * self.state.demand_multiplier / 4), 1)
            duration = float(self.rng.choice([4, 8, 24, 72, 168]))

            utilisation = self._current_utilisation(hardware_id, region)
            tick = self.spot_market.tick(hardware_id, region, utilisation)
            willing_price = tick.price * (1 + (1 - agent.price_sensitivity) * 0.1)

            self.market.submit_order(
                side="BUY",
                hardware=hardware_id,
                region=region,
                quantity=quantity,
                duration_hours=duration,
                limit_price=round(willing_price, 4),
                buyer_id=agent.id,
            )
            self._orders_submitted += 1

    def _provider_process(self, env: simpy.Environment, agent: ProviderAgent):
        while True:
            interarrival = self.rng.exponential(2.5)
            yield env.timeout(interarrival)

            hardware_id = self.hardware_ids[self.rng.integers(0, len(self.hardware_ids))]
            region = self.regions[self.rng.integers(0, len(self.regions))]
            quantity = max(int(self.rng.integers(4, 64) * self.state.supply_multiplier), 1)
            duration = float(self.rng.choice([4, 8, 24, 72, 168]))

            utilisation = self._current_utilisation(hardware_id, region)
            tick = self.spot_market.tick(hardware_id, region, utilisation)
            ask_price = tick.price * (1 + agent.margin_fraction * 0.3)

            self.market.submit_order(
                side="SELL",
                hardware=hardware_id,
                region=region,
                quantity=quantity,
                duration_hours=duration,
                limit_price=round(ask_price, 4),
                provider_id=agent.provider_id or agent.id,
            )
            self._orders_submitted += 1

    def _shock_process(self, env: simpy.Environment, shock: MarketShock):
        yield env.timeout(shock.at_tick)
        apply_shock(self.state, shock)

    def _recorder_process(self, env: simpy.Environment, tick_interval: float):
        while True:
            trades = self.market.match()
            for hardware_id in self.hardware_ids:
                for region in self.regions:
                    book = self.market.book(hardware_id, region)
                    if book.depth() == 0 and not self.market.recent_trades(hardware_id, region, limit=1):
                        continue
                    utilisation = self._current_utilisation(hardware_id, region)
                    snapshot = book.snapshot()
                    self._price_rows.append(
                        {
                            "sim_time": env.now,
                            "hardware_id": hardware_id,
                            "region": region,
                            "best_bid": snapshot.best_bid,
                            "best_ask": snapshot.best_ask,
                            "mid_price": snapshot.mid_price,
                            "spread": snapshot.spread,
                        }
                    )
                    self._util_rows.append(
                        {
                            "sim_time": env.now,
                            "hardware_id": hardware_id,
                            "region": region,
                            "utilisation": utilisation,
                            "depth": snapshot.depth,
                        }
                    )
            yield env.timeout(tick_interval)

    # -- run ------------------------------------------------------------------

    def run(self, duration_hours: float = 168.0, tick_interval_hours: float = 1.0) -> SimulationResult:
        env = simpy.Environment()
        for agent in self.buyers:
            env.process(self._buyer_process(env, agent))
        for agent in self.providers:
            env.process(self._provider_process(env, agent))
        for shock in self._scheduled_shocks:
            env.process(self._shock_process(env, shock))
        env.process(self._recorder_process(env, tick_interval_hours))

        env.run(until=duration_hours)

        # final sweep so nothing is left unmatched at the end of the run
        self.market.match()

        return SimulationResult(
            price_history=pd.DataFrame(self._price_rows),
            utilisation_history=pd.DataFrame(self._util_rows),
            trade_count=len(self.market.trade_tape),
            orders_submitted=self._orders_submitted,
            shocks_applied=[s.shock_type.value for s in self._scheduled_shocks],
        )
