"""OutageEngine (section 43).

Generates outage events and automatically removes affected capacity from
the market's tradeable inventory. This module only ever *marks* capacity
offline in the market model — it never issues, simulates, or recommends
any real physical-control action (power cycling, breaker operation,
cooling valve control, etc.), per the spec's explicit safety instruction.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.enums import OutageType

_id_counter = itertools.count(1)


@dataclasses.dataclass(slots=True)
class OutageEvent:
    datacenter_id: str
    outage_type: OutageType
    capacity_removed: int
    hardware_id: str | None = None
    description: str = ""
    id: str = dataclasses.field(default_factory=lambda: f"otg-{next(_id_counter):09d}")
    started_at: dt.datetime = dataclasses.field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    resolved_at: dt.datetime | None = None
    status: str = "active"

    def resolve(self) -> None:
        self.status = "resolved"
        self.resolved_at = dt.datetime.now(dt.timezone.utc)


class OutageEngine:
    """Tracks active/resolved outages and computes the *capacity impact*
    (how many units should be pulled from `InventoryItem.available_quantity`
    / moved to `offline_quantity`). Applying that impact to the database is
    the caller's responsibility (see ops layer / API service functions) so
    this engine stays a pure, testable decision component."""

    def __init__(self) -> None:
        self._events: dict[str, OutageEvent] = {}

    def trigger(
        self,
        datacenter_id: str,
        outage_type: str,
        capacity_removed: int,
        hardware_id: str | None = None,
        description: str = "",
    ) -> OutageEvent:
        event = OutageEvent(
            datacenter_id=datacenter_id,
            outage_type=OutageType(outage_type),
            capacity_removed=capacity_removed,
            hardware_id=hardware_id,
            description=description,
        )
        self._events[event.id] = event
        return event

    def resolve(self, outage_id: str) -> OutageEvent | None:
        event = self._events.get(outage_id)
        if event is None or event.status != "active":
            return None
        event.resolve()
        return event

    def active_outages(self, datacenter_id: str | None = None) -> list[OutageEvent]:
        return [
            e
            for e in self._events.values()
            if e.status == "active" and (datacenter_id is None or e.datacenter_id == datacenter_id)
        ]

    def total_capacity_offline(self, datacenter_id: str, hardware_id: str | None = None) -> int:
        return sum(
            e.capacity_removed
            for e in self.active_outages(datacenter_id)
            if hardware_id is None or e.hardware_id in (None, hardware_id)
        )
