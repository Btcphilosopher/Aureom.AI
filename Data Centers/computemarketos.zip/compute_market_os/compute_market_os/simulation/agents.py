"""Simulation agents (sections 41).

Buyer archetypes: AI startup, research lab, bank, game company, video
company, enterprise, university.
Provider archetypes: GPU cloud, hyperscaler, datacenter, enterprise.

Each agent carries budget/demand/risk-tolerance/price-sensitivity/latency
preference so the market simulator can generate heterogeneous order flow.
All randomness goes through a caller-supplied `numpy.random.Generator` so
simulations are reproducible.
"""

from __future__ import annotations

import dataclasses

import numpy as np

BUYER_ARCHETYPES: dict[str, dict] = {
    "ai_startup": dict(budget_range=(5_000, 60_000), demand_gpus=(8, 64), risk_tolerance=0.8, price_sensitivity=0.7, latency_preference_ms=200),
    "research_lab": dict(budget_range=(20_000, 250_000), demand_gpus=(32, 512), risk_tolerance=0.5, price_sensitivity=0.4, latency_preference_ms=300),
    "bank": dict(budget_range=(50_000, 400_000), demand_gpus=(8, 128), risk_tolerance=0.15, price_sensitivity=0.3, latency_preference_ms=50),
    "game_company": dict(budget_range=(10_000, 120_000), demand_gpus=(16, 128), risk_tolerance=0.5, price_sensitivity=0.6, latency_preference_ms=40),
    "video_company": dict(budget_range=(15_000, 150_000), demand_gpus=(16, 256), risk_tolerance=0.4, price_sensitivity=0.5, latency_preference_ms=80),
    "enterprise": dict(budget_range=(20_000, 300_000), demand_gpus=(8, 96), risk_tolerance=0.3, price_sensitivity=0.5, latency_preference_ms=100),
    "university": dict(budget_range=(5_000, 80_000), demand_gpus=(8, 64), risk_tolerance=0.6, price_sensitivity=0.8, latency_preference_ms=500),
}

PROVIDER_ARCHETYPES: dict[str, dict] = {
    "gpu_cloud": dict(margin_range=(0.10, 0.25), reliability_range=(0.98, 0.995)),
    "hyperscaler": dict(margin_range=(0.20, 0.40), reliability_range=(0.995, 0.9995)),
    "datacenter": dict(margin_range=(0.08, 0.20), reliability_range=(0.97, 0.99)),
    "enterprise": dict(margin_range=(0.05, 0.15), reliability_range=(0.95, 0.985)),
}


@dataclasses.dataclass(slots=True)
class BuyerAgent:
    id: str
    archetype: str
    budget: float
    demand_gpus: int
    risk_tolerance: float
    price_sensitivity: float
    latency_preference_ms: float
    preferred_region: str | None = None


@dataclasses.dataclass(slots=True)
class ProviderAgent:
    id: str
    archetype: str
    margin_fraction: float
    reliability: float
    provider_id: str | None = None  # linked ComputeProvider.id when backed by DB seed data


def generate_buyer_agents(n: int, rng: np.random.Generator, region_pool: list[str] | None = None) -> list[BuyerAgent]:
    archetypes = list(BUYER_ARCHETYPES.keys())
    agents = []
    for i in range(n):
        archetype = archetypes[rng.integers(0, len(archetypes))]
        spec = BUYER_ARCHETYPES[archetype]
        budget = float(rng.uniform(*spec["budget_range"]))
        demand = int(rng.integers(spec["demand_gpus"][0], spec["demand_gpus"][1] + 1))
        region = None
        if region_pool:
            region = region_pool[rng.integers(0, len(region_pool))]
        agents.append(
            BuyerAgent(
                id=f"buyer-{i:05d}",
                archetype=archetype,
                budget=round(budget, 2),
                demand_gpus=demand,
                risk_tolerance=spec["risk_tolerance"],
                price_sensitivity=spec["price_sensitivity"],
                latency_preference_ms=spec["latency_preference_ms"],
                preferred_region=region,
            )
        )
    return agents


def generate_provider_agents(n: int, rng: np.random.Generator, provider_ids: list[str] | None = None) -> list[ProviderAgent]:
    archetypes = list(PROVIDER_ARCHETYPES.keys())
    agents = []
    for i in range(n):
        archetype = archetypes[rng.integers(0, len(archetypes))]
        spec = PROVIDER_ARCHETYPES[archetype]
        agents.append(
            ProviderAgent(
                id=f"provider-agent-{i:05d}",
                archetype=archetype,
                margin_fraction=round(float(rng.uniform(*spec["margin_range"])), 4),
                reliability=round(float(rng.uniform(*spec["reliability_range"])), 4),
                provider_id=provider_ids[i % len(provider_ids)] if provider_ids else None,
            )
        )
    return agents
