"""CapacityForecastEngine (section 30).

Forecasts future demand, supply, and utilisation from historical market
data plus known future commitments (reservations already on the books,
planned capacity additions the provider has told the market about) and a
simple weekly seasonality profile estimated from the history itself —
never fabricated.
"""

from __future__ import annotations

import dataclasses
import datetime as dt

import numpy as np


@dataclasses.dataclass(slots=True, frozen=True)
class CapacityForecastPoint:
    target_time: dt.datetime
    forecast_demand: float
    forecast_supply: float
    forecast_utilisation: float


class CapacityForecastEngine:
    MIN_OBSERVATIONS = 8

    def _trend_and_seasonality(self, series: list[float], timestamps: list[dt.datetime]):
        values = np.asarray(series, dtype=float)
        x = np.arange(len(values), dtype=float)
        # Linear trend via least squares.
        slope, intercept = np.polyfit(x, values, 1)
        detrended = values - (slope * x + intercept)

        # Day-of-week seasonal index (mean detrended value per weekday),
        # only if we have enough history to estimate it meaningfully.
        weekday_effect = {d: 0.0 for d in range(7)}
        if len(timestamps) == len(values) and len(values) >= 14:
            buckets: dict[int, list[float]] = {d: [] for d in range(7)}
            for ts, val in zip(timestamps, detrended):
                buckets[ts.weekday()].append(val)
            for d, vals in buckets.items():
                if vals:
                    weekday_effect[d] = float(np.mean(vals))
        return slope, intercept, weekday_effect

    def forecast(
        self,
        history_demand: list[float],
        history_supply: list[float],
        history_timestamps: list[dt.datetime],
        horizon_hours: list[float],
        known_future_reservations: dict[float, float] | None = None,  # hours_ahead -> demand already committed
        planned_capacity_additions: dict[float, float] | None = None,  # hours_ahead -> supply coming online
    ) -> list[CapacityForecastPoint]:
        if len(history_demand) < self.MIN_OBSERVATIONS or len(history_supply) < self.MIN_OBSERVATIONS:
            raise ValueError(
                f"need at least {self.MIN_OBSERVATIONS} historical observations for demand and supply"
            )
        known_future_reservations = known_future_reservations or {}
        planned_capacity_additions = planned_capacity_additions or {}

        d_slope, d_intercept, d_seasonal = self._trend_and_seasonality(history_demand, history_timestamps)
        s_slope, s_intercept, s_seasonal = self._trend_and_seasonality(history_supply, history_timestamps)

        n = len(history_demand)
        now = history_timestamps[-1]
        points = []
        for hours_ahead in horizon_hours:
            # Approximate future step index assuming roughly-uniform sampling.
            span_hours = max((history_timestamps[-1] - history_timestamps[0]).total_seconds() / 3600.0, 1e-6)
            steps_per_hour = max((n - 1) / span_hours, 1e-6)
            future_step = n - 1 + hours_ahead * steps_per_hour
            target_time = now + dt.timedelta(hours=hours_ahead)

            demand_trend = d_slope * future_step + d_intercept + d_seasonal.get(target_time.weekday(), 0.0)
            supply_trend = s_slope * future_step + s_intercept + s_seasonal.get(target_time.weekday(), 0.0)

            demand = max(demand_trend + known_future_reservations.get(hours_ahead, 0.0), 0.0)
            supply = max(supply_trend + planned_capacity_additions.get(hours_ahead, 0.0), 0.0)
            utilisation = min(demand / supply, 1.0) if supply > 0 else 1.0

            points.append(
                CapacityForecastPoint(
                    target_time=target_time,
                    forecast_demand=round(demand, 2),
                    forecast_supply=round(supply, 2),
                    forecast_utilisation=round(utilisation, 4),
                )
            )
        return points
