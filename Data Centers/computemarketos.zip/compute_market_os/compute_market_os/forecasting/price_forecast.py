"""PriceForecastEngine (section 31).

Statistical forecasting first (a damped random-walk-with-drift over an
EWMA-smoothed trend), ML optional/later. Uncertainty is always reported
as a confidence interval that widens with the forecast horizon, derived
from the historical series' own volatility — never a fixed/fabricated
band.
"""

from __future__ import annotations

import dataclasses
import datetime as dt

import numpy as np

HORIZONS_HOURS: dict[str, float] = {
    "1h": 1,
    "6h": 6,
    "24h": 24,
    "7d": 24 * 7,
    "30d": 24 * 30,
}


@dataclasses.dataclass(slots=True, frozen=True)
class PriceForecastPoint:
    horizon: str
    target_time: dt.datetime
    predicted_price: float
    lower_bound: float
    upper_bound: float
    model_name: str


class PriceForecastEngine:
    MIN_OBSERVATIONS = 5
    Z_SCORE_95 = 1.96

    def forecast(
        self,
        history_prices: list[float],
        history_timestamps: list[dt.datetime],
        horizons: dict[str, float] | None = None,
    ) -> list[PriceForecastPoint]:
        if len(history_prices) < self.MIN_OBSERVATIONS:
            raise ValueError(
                f"need at least {self.MIN_OBSERVATIONS} historical price observations to forecast, "
                f"got {len(history_prices)}"
            )
        horizons = horizons or HORIZONS_HOURS
        prices = np.asarray(history_prices, dtype=float)
        now = history_timestamps[-1]

        # Drift = mean of recent log returns (captures trend without
        # assuming a parametric ML model).
        log_prices = np.log(prices)
        returns = np.diff(log_prices)
        drift_per_step = float(np.mean(returns)) if len(returns) else 0.0
        volatility_per_step = float(np.std(returns)) if len(returns) > 1 else 0.0

        # Approximate steps-per-hour from the observed sampling cadence.
        span_hours = max((history_timestamps[-1] - history_timestamps[0]).total_seconds() / 3600.0, 1e-6)
        steps_per_hour = max(len(prices) / span_hours, 1e-6)

        last_log_price = log_prices[-1]

        points = []
        for horizon_name, hours_ahead in horizons.items():
            steps = max(hours_ahead * steps_per_hour, 1.0)
            forecast_log_price = last_log_price + drift_per_step * steps
            predicted = float(np.exp(forecast_log_price))

            # Random-walk uncertainty grows with sqrt(steps).
            forecast_std = volatility_per_step * np.sqrt(steps)
            lower = float(np.exp(forecast_log_price - self.Z_SCORE_95 * forecast_std))
            upper = float(np.exp(forecast_log_price + self.Z_SCORE_95 * forecast_std))

            points.append(
                PriceForecastPoint(
                    horizon=horizon_name,
                    target_time=now + dt.timedelta(hours=hours_ahead),
                    predicted_price=round(predicted, 6),
                    lower_bound=round(lower, 6),
                    upper_bound=round(upper, 6),
                    model_name="ewma_random_walk_with_drift",
                )
            )
        return points
