"""ForwardMarket (section 17).

A compute-capacity forward contract — "10,000 GPU-hours of H100 in Taiwan,
Q4 2026, at a maximum price" — is a *delivery commitment*, not a financial
derivative. No cash-settlement/derivative behaviour is implemented unless a
caller explicitly opts in via `cash_settled=True` on `settle()`, and even
then this module only produces a settlement number — it does not represent
legal or regulatory advice.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

_id_counter = itertools.count(1)


@dataclasses.dataclass(slots=True)
class ForwardContract:
    hardware_id: str
    region: str
    gpu_hours: float
    strike_price_per_hour: float
    delivery_start: dt.datetime
    delivery_end: dt.datetime
    buyer_id: str | None = None
    provider_id: str | None = None
    id: str = dataclasses.field(default_factory=lambda: f"fwd-{next(_id_counter):09d}")
    gpu_hours_delivered: float = 0.0
    status: str = "pending"  # pending -> active -> completed | breached | cancelled

    @property
    def remaining_gpu_hours(self) -> float:
        return max(self.gpu_hours - self.gpu_hours_delivered, 0.0)

    @property
    def notional_value(self) -> float:
        return self.gpu_hours * self.strike_price_per_hour

    def deliver(self, gpu_hours: float) -> None:
        if gpu_hours <= 0:
            raise ValueError("gpu_hours must be positive")
        if gpu_hours > self.remaining_gpu_hours + 1e-9:
            raise ValueError("delivery exceeds remaining contract capacity")
        self.gpu_hours_delivered += gpu_hours
        if self.status == "pending":
            self.status = "active"
        if self.remaining_gpu_hours <= 1e-9:
            self.status = "completed"


class ForwardMarket:
    """Tracks open forward contracts and their delivery/settlement state."""

    def __init__(self) -> None:
        self._contracts: dict[str, ForwardContract] = {}

    def create_contract(
        self,
        hardware_id: str,
        region: str,
        gpu_hours: float,
        strike_price_per_hour: float,
        delivery_start: dt.datetime,
        delivery_end: dt.datetime,
        buyer_id: str | None = None,
        provider_id: str | None = None,
    ) -> ForwardContract:
        contract = ForwardContract(
            hardware_id=hardware_id,
            region=region,
            gpu_hours=gpu_hours,
            strike_price_per_hour=strike_price_per_hour,
            delivery_start=delivery_start,
            delivery_end=delivery_end,
            buyer_id=buyer_id,
            provider_id=provider_id,
        )
        self._contracts[contract.id] = contract
        return contract

    def get(self, contract_id: str) -> ForwardContract | None:
        return self._contracts.get(contract_id)

    def deliver(self, contract_id: str, gpu_hours: float) -> ForwardContract:
        contract = self._contracts[contract_id]
        contract.deliver(gpu_hours)
        return contract

    def settle(self, contract_id: str, market_price_per_hour: float | None = None) -> dict:
        """Produce a settlement summary. If `market_price_per_hour` is
        supplied, also reports the *physical* delivery variance versus the
        contract strike (informational only — this is a capacity delivery
        contract, not a cash-settled derivative)."""
        contract = self._contracts[contract_id]
        summary = {
            "contract_id": contract.id,
            "hardware_id": contract.hardware_id,
            "region": contract.region,
            "gpu_hours_contracted": contract.gpu_hours,
            "gpu_hours_delivered": contract.gpu_hours_delivered,
            "delivery_shortfall_gpu_hours": contract.remaining_gpu_hours,
            "strike_price_per_hour": contract.strike_price_per_hour,
            "amount_due": contract.gpu_hours_delivered * contract.strike_price_per_hour,
            "status": contract.status,
        }
        if market_price_per_hour is not None:
            summary["reference_market_price_per_hour"] = market_price_per_hour
            summary["price_variance_per_hour"] = round(
                market_price_per_hour - contract.strike_price_per_hour, 6
            )
        return summary

    def open_interest_gpu_hours(self, hardware_id: str | None = None, region: str | None = None) -> float:
        total = 0.0
        for c in self._contracts.values():
            if hardware_id and c.hardware_id != hardware_id:
                continue
            if region and c.region != region:
                continue
            if c.status in ("pending", "active"):
                total += c.remaining_gpu_hours
        return total
