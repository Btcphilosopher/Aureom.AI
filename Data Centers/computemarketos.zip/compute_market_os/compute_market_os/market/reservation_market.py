"""ReservationMarket (section 18): reserve capacity for a fixed window and
calculate the reservation premium over spot.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.config import load_yaml_config

_id_counter = itertools.count(1)


@dataclasses.dataclass(slots=True)
class Reservation:
    provider_id: str
    datacenter_id: str
    hardware_id: str
    quantity: int
    start_time: dt.datetime
    end_time: dt.datetime
    base_price_per_hour: float
    premium_fraction: float
    buyer_id: str | None = None
    daily_window_start_hour: int | None = None
    daily_window_end_hour: int | None = None
    id: str = dataclasses.field(default_factory=lambda: f"res-{next(_id_counter):09d}")
    status: str = "active"

    @property
    def duration_hours(self) -> float:
        return (self.end_time - self.start_time).total_seconds() / 3600.0

    @property
    def total_price_per_hour(self) -> float:
        return round(self.base_price_per_hour * (1 + self.premium_fraction), 6)

    @property
    def total_cost(self) -> float:
        return round(self.total_price_per_hour * self.quantity * self.duration_hours, 2)


class ReservationMarket:
    """Calculates reservation premiums (section 18) and tracks reservations
    against a capacity ledger owned by the caller (see
    ops.settlement / the capacity reservation ledger in the API layer,
    which enforces the PowerConstraint before committing a reservation)."""

    def __init__(self) -> None:
        cfg = load_yaml_config("pricing")["market_dynamics"]["reservation"]
        self.base_premium_fraction: float = cfg["premium_fraction_of_spot"]
        self.long_duration_discount_per_30_days: float = cfg["long_duration_discount_per_30_days"]
        self.max_discount_fraction: float = cfg["max_discount_fraction"]
        self._reservations: dict[str, Reservation] = {}

    def premium_fraction(self, duration_hours: float) -> float:
        """Longer reservations earn a volume/commitment discount, but the
        reservation premium never turns negative beyond the configured cap."""
        months_equivalent = duration_hours / (24 * 30)
        discount = min(
            months_equivalent * self.long_duration_discount_per_30_days,
            self.max_discount_fraction,
        )
        return round(max(self.base_premium_fraction - discount, -self.max_discount_fraction), 6)

    def reserve(
        self,
        provider_id: str,
        datacenter_id: str,
        hardware_id: str,
        quantity: int,
        start_time: dt.datetime,
        end_time: dt.datetime,
        spot_price_per_hour: float,
        buyer_id: str | None = None,
        daily_window_start_hour: int | None = None,
        daily_window_end_hour: int | None = None,
    ) -> Reservation:
        if end_time <= start_time:
            raise ValueError("end_time must be after start_time")
        duration_hours = (end_time - start_time).total_seconds() / 3600.0
        reservation = Reservation(
            provider_id=provider_id,
            datacenter_id=datacenter_id,
            hardware_id=hardware_id,
            quantity=quantity,
            start_time=start_time,
            end_time=end_time,
            base_price_per_hour=spot_price_per_hour,
            premium_fraction=self.premium_fraction(duration_hours),
            buyer_id=buyer_id,
            daily_window_start_hour=daily_window_start_hour,
            daily_window_end_hour=daily_window_end_hour,
        )
        self._reservations[reservation.id] = reservation
        return reservation

    def cancel(self, reservation_id: str) -> bool:
        reservation = self._reservations.get(reservation_id)
        if reservation is None or reservation.status != "active":
            return False
        reservation.status = "cancelled"
        return True

    def get(self, reservation_id: str) -> Reservation | None:
        return self._reservations.get(reservation_id)

    def active_for(self, provider_id: str | None = None, hardware_id: str | None = None) -> list[Reservation]:
        return [
            r
            for r in self._reservations.values()
            if r.status == "active"
            and (provider_id is None or r.provider_id == provider_id)
            and (hardware_id is None or r.hardware_id == hardware_id)
        ]
