"""AuctionEngine (sections 19-21).

Supports:
  - english          — ascending open-outcry; highest bid wins at the price
                        of the second-highest bid + one tick (second-price
                        style, standard for English auction simulations).
  - sealed_bid        — highest sealed bid wins; clears at that bid's price
                        (first-price) or, if configured, at the market
                        clearing price where supply meets cumulative demand.
  - reverse           — buyer wants capacity, providers compete to supply
                        it at the *lowest* price (section 20).
  - capacity_auction   — multi-unit uniform-price clearing: bids are
                        stacked by price until the offered quantity is
                        exhausted; every winner pays the clearing price.

Every auction can also report a *performance-adjusted* ranking (section 21)
when bids carry a `performance_score` (e.g. a CPI score) — bids are then
ranked by £ / performance-unit rather than raw price.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.enums import AuctionStatus, AuctionType

_id_counter = itertools.count(1)


@dataclasses.dataclass(slots=True)
class Bid:
    bidder_id: str
    price: float
    quantity: float
    performance_score: float | None = None
    submitted_at: dt.datetime = dataclasses.field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc)
    )

    @property
    def price_per_performance(self) -> float | None:
        if not self.performance_score:
            return None
        return self.price / self.performance_score


@dataclasses.dataclass(slots=True)
class ClearingResult:
    status: AuctionStatus
    clearing_price: float | None
    total_quantity_cleared: float
    winners: list[dict]
    best_bid: Bid | None = None
    second_best_bid: Bid | None = None
    performance_adjusted_best: Bid | None = None
    reason: str = ""


@dataclasses.dataclass(slots=True)
class Auction:
    auction_type: AuctionType
    hardware_id: str
    region: str
    quantity_offered: float          # GPU-hours (or units, per auction convention)
    reserve_price: float
    provider_id: str | None = None
    id: str = dataclasses.field(default_factory=lambda: f"auc-{next(_id_counter):09d}")
    status: AuctionStatus = AuctionStatus.OPEN
    bids: list[Bid] = dataclasses.field(default_factory=list)


class AuctionEngine:
    def create_auction(
        self,
        auction_type: str,
        hardware_id: str,
        region: str,
        quantity_offered: float,
        reserve_price: float,
        provider_id: str | None = None,
    ) -> Auction:
        return Auction(
            auction_type=AuctionType(auction_type),
            hardware_id=hardware_id,
            region=region,
            quantity_offered=quantity_offered,
            reserve_price=reserve_price,
            provider_id=provider_id,
        )

    def submit_bid(self, auction: Auction, bid: Bid) -> None:
        if auction.status != AuctionStatus.OPEN:
            raise ValueError(f"auction {auction.id} is not open")
        auction.bids.append(bid)

    def clear(self, auction: Auction) -> ClearingResult:
        if auction.auction_type == AuctionType.REVERSE:
            result = self._clear_reverse(auction)
        elif auction.auction_type == AuctionType.ENGLISH:
            result = self._clear_english(auction)
        elif auction.auction_type == AuctionType.CAPACITY_AUCTION:
            result = self._clear_capacity(auction)
        else:  # SEALED_BID
            result = self._clear_sealed_bid(auction)

        auction.status = result.status
        return result

    # -- forward auctions (buyer is the highest bidder) -----------------------

    def _eligible_forward_bids(self, auction: Auction) -> list[Bid]:
        return sorted(
            (b for b in auction.bids if b.price >= auction.reserve_price),
            key=lambda b: b.price,
            reverse=True,
        )

    def _performance_adjusted_best(self, bids: list[Bid]) -> Bid | None:
        scored = [b for b in bids if b.price_per_performance is not None]
        if not scored:
            return None
        return min(scored, key=lambda b: b.price_per_performance)

    def _clear_english(self, auction: Auction) -> ClearingResult:
        eligible = self._eligible_forward_bids(auction)
        if not eligible:
            return ClearingResult(AuctionStatus.FAILED, None, 0.0, [], reason="no bids met reserve price")
        best = eligible[0]
        second = eligible[1] if len(eligible) > 1 else None
        # Second-price style clearing: winner pays just above the runner-up.
        clearing_price = round((second.price + 0.01), 6) if second else best.price
        clearing_price = min(clearing_price, best.price)
        return ClearingResult(
            AuctionStatus.CLEARED,
            clearing_price,
            min(best.quantity, auction.quantity_offered),
            [{"bidder_id": best.bidder_id, "price": clearing_price, "quantity": min(best.quantity, auction.quantity_offered)}],
            best_bid=best,
            second_best_bid=second,
            performance_adjusted_best=self._performance_adjusted_best(eligible),
        )

    def _clear_sealed_bid(self, auction: Auction) -> ClearingResult:
        eligible = self._eligible_forward_bids(auction)
        if not eligible:
            return ClearingResult(AuctionStatus.FAILED, None, 0.0, [], reason="no bids met reserve price")
        best = eligible[0]
        second = eligible[1] if len(eligible) > 1 else None
        return ClearingResult(
            AuctionStatus.CLEARED,
            best.price,
            min(best.quantity, auction.quantity_offered),
            [{"bidder_id": best.bidder_id, "price": best.price, "quantity": min(best.quantity, auction.quantity_offered)}],
            best_bid=best,
            second_best_bid=second,
            performance_adjusted_best=self._performance_adjusted_best(eligible),
        )

    def _clear_capacity(self, auction: Auction) -> ClearingResult:
        """Uniform-price multi-unit clearing (section 19 example): stack
        bids best price first until the offered quantity is exhausted;
        every winner pays the price of the last (marginal) unit accepted."""
        eligible = self._eligible_forward_bids(auction)
        if not eligible:
            return ClearingResult(AuctionStatus.FAILED, None, 0.0, [], reason="no bids met reserve price")
        remaining = auction.quantity_offered
        winners: list[dict] = []
        clearing_price = auction.reserve_price
        for bid in eligible:
            if remaining <= 0:
                break
            take = min(bid.quantity, remaining)
            winners.append({"bidder_id": bid.bidder_id, "price": bid.price, "quantity": take})
            clearing_price = bid.price
            remaining -= take
        total = sum(w["quantity"] for w in winners)
        # Uniform-price: everyone actually pays the marginal clearing price.
        for w in winners:
            w["price"] = clearing_price
        return ClearingResult(
            AuctionStatus.CLEARED,
            clearing_price,
            total,
            winners,
            best_bid=eligible[0],
            second_best_bid=eligible[1] if len(eligible) > 1 else None,
            performance_adjusted_best=self._performance_adjusted_best(eligible),
        )

    # -- reverse auction (buyer posts demand, providers undercut) -----------

    def _clear_reverse(self, auction: Auction) -> ClearingResult:
        """Section 20: buyer specifies GPU-hours needed; providers submit
        asking prices; lowest compliant (>= 0, and here <= reserve as a
        buyer-side maximum-price ceiling) bid wins."""
        eligible = sorted(
            (b for b in auction.bids if b.price <= auction.reserve_price),
            key=lambda b: b.price,
        )
        if not eligible:
            return ClearingResult(AuctionStatus.FAILED, None, 0.0, [], reason="no provider bid within buyer's ceiling")
        best = eligible[0]
        second = eligible[1] if len(eligible) > 1 else None
        return ClearingResult(
            AuctionStatus.CLEARED,
            best.price,
            min(best.quantity, auction.quantity_offered),
            [{"bidder_id": best.bidder_id, "price": best.price, "quantity": min(best.quantity, auction.quantity_offered)}],
            best_bid=best,
            second_best_bid=second,
            performance_adjusted_best=self._performance_adjusted_best(eligible),
        )
