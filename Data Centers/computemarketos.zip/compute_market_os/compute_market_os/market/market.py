"""ComputeMarket — the top-level orchestrator (sections 9 + 75).

Example (matches section 75 of the spec exactly):

    market = ComputeMarket()
    market.submit_order(side="BUY", hardware="H100", region="Taiwan",
                         quantity=32, duration_hours=24, limit_price=2.40)
    market.submit_order(side="SELL", hardware="H100", region="Taiwan",
                         quantity=64, duration_hours=24, limit_price=2.20)
    trades = market.match()

`hardware=` accepts either a catalog id (e.g. "hw-h100-sxm") or a model
name (e.g. "H100") resolved via the hardware catalog.
"""

from __future__ import annotations

from compute_market_os.core.enums import OrderSide, OrderStatus, OrderType
from compute_market_os.core.events import EventBus, EventType, default_bus
from compute_market_os.domain.hardware import load_hardware_catalog
from compute_market_os.market.matching_engine import MatchingEngine, Trade
from compute_market_os.market.order import Order
from compute_market_os.market.orderbook import OrderBook


def resolve_hardware_id(hardware: str) -> str:
    catalog = load_hardware_catalog()
    if hardware in catalog:
        return hardware
    for hw in catalog.values():
        if hw.model.lower() == hardware.lower() or hw.model.replace(" ", "").lower() == hardware.replace(" ", "").lower():
            return hw.id
    raise KeyError(f"Unknown hardware: {hardware!r}")


class ComputeMarket:
    """Holds one OrderBook per (hardware_id, region) key and the running
    trade tape. Pure in-memory engine — the API layer persists orders and
    trades emitted here into PostgreSQL and republishes them over
    WebSockets."""

    def __init__(self, event_bus: EventBus | None = None) -> None:
        self.event_bus = event_bus or default_bus
        self.matching_engine = MatchingEngine(event_bus=self.event_bus)
        self._books: dict[tuple[str, str], OrderBook] = {}
        self.trade_tape: list[Trade] = []

    def book(self, hardware_id: str, region: str) -> OrderBook:
        key = (hardware_id, region)
        if key not in self._books:
            self._books[key] = OrderBook(hardware_id, region)
        return self._books[key]

    def all_books(self) -> list[OrderBook]:
        return list(self._books.values())

    def submit_order(
        self,
        side: str,
        hardware: str,
        region: str,
        quantity: int,
        duration_hours: float,
        limit_price: float | None = None,
        order_type: str = "limit",
        min_memory_gb: float | None = None,
        min_performance_score: float | None = None,
        max_latency_ms: float | None = None,
        buyer_id: str | None = None,
        provider_id: str | None = None,
        start_time=None,
    ) -> Order:
        hardware_id = resolve_hardware_id(hardware)
        order = Order(
            side=OrderSide(side.upper()),
            hardware_id=hardware_id,
            region=region,
            quantity=quantity,
            duration_hours=duration_hours,
            limit_price=limit_price,
            order_type=OrderType(order_type),
            min_memory_gb=min_memory_gb,
            min_performance_score=min_performance_score,
            max_latency_ms=max_latency_ms,
            buyer_id=buyer_id,
            provider_id=provider_id,
            start_time=start_time,
        )
        self.book(hardware_id, region).add(order)
        self.event_bus.emit(
            EventType.ORDER_SUBMITTED,
            order_id=order.id,
            side=order.side.value,
            hardware_id=hardware_id,
            region=region,
            quantity=quantity,
            limit_price=limit_price,
        )
        return order

    def cancel_order(self, hardware: str, region: str, order_id: str) -> bool:
        hardware_id = resolve_hardware_id(hardware)
        ok = self.book(hardware_id, region).cancel(order_id)
        if ok:
            self.event_bus.emit(EventType.ORDER_CANCELLED, order_id=order_id)
        return ok

    def match(self, hardware: str | None = None, region: str | None = None) -> list[Trade]:
        """Run the matching engine. With no arguments, sweeps every book in
        the market (used by the example API in section 75); pass
        hardware/region to sweep a single book."""
        trades: list[Trade] = []
        if hardware is not None and region is not None:
            books = [self.book(resolve_hardware_id(hardware), region)]
        else:
            books = self.all_books()
        for book in books:
            trades.extend(self.matching_engine.match_book(book))
        self.trade_tape.extend(trades)
        return trades

    def orderbook_snapshot(self, hardware: str, region: str, levels: int = 25):
        return self.book(resolve_hardware_id(hardware), region).snapshot(levels)

    def recent_trades(self, hardware: str | None = None, region: str | None = None, limit: int = 100) -> list[Trade]:
        trades = self.trade_tape
        if hardware is not None:
            hardware_id = resolve_hardware_id(hardware)
            trades = [t for t in trades if t.hardware_id == hardware_id]
        if region is not None:
            trades = [t for t in trades if t.region == region]
        return trades[-limit:]
