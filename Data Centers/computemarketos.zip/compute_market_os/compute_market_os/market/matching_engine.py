"""MatchingEngine (sections 12 + 13).

Implements price-time priority with compute-specific compatibility checks
(region and hardware are already guaranteed by the order book key; here we
additionally enforce duration/start-time alignment and the buyer's stated
minimum requirements against the seller's advertised hardware before a
trade can execute — section 12: "Do not match incompatible capacity.").
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.enums import OrderSide
from compute_market_os.core.events import EventBus, EventType, default_bus
from compute_market_os.domain.hardware import ComputeHardware, load_hardware_catalog
from compute_market_os.market.order import Order
from compute_market_os.market.orderbook import OrderBook

_trade_id_counter = itertools.count(1)


def next_trade_id() -> str:
    return f"trd-{next(_trade_id_counter):09d}"


@dataclasses.dataclass(slots=True)
class Trade:
    buy_order: Order
    sell_order: Order
    hardware_id: str
    region: str
    quantity: int
    price: float
    duration_hours: float
    id: str = dataclasses.field(default_factory=next_trade_id)
    timestamp: dt.datetime = dataclasses.field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc)
    )

    @property
    def buyer_id(self) -> str | None:
        return self.buy_order.buyer_id

    @property
    def seller_provider_id(self) -> str | None:
        return self.sell_order.provider_id

    @property
    def notional(self) -> float:
        return self.price * self.quantity * self.duration_hours


class MatchingEngine:
    """Continuous double-auction matching engine for one OrderBook at a
    time. Compute-aware: a SELL order represents advertised capacity for a
    specific hardware SKU, and a match is only executed if the resting
    capacity meets the buy order's stated minimums.
    """

    def __init__(
        self,
        event_bus: EventBus | None = None,
        hardware_catalog: dict[str, ComputeHardware] | None = None,
    ) -> None:
        self.event_bus = event_bus or default_bus
        self._hardware_catalog = hardware_catalog

    def _catalog(self) -> dict[str, ComputeHardware]:
        if self._hardware_catalog is None:
            self._hardware_catalog = load_hardware_catalog()
        return self._hardware_catalog

    def _capacity_compatible(self, buy: Order, sell: Order) -> bool:
        if not buy.is_compatible_with(sell):
            return False
        hw = self._catalog().get(sell.hardware_id)
        if hw is None:
            return True  # unknown SKU in tests — do not block on missing catalog data
        if buy.min_memory_gb is not None and hw.memory_gb < buy.min_memory_gb:
            return False
        if buy.min_performance_score is not None and hw.compute_score < buy.min_performance_score:
            return False
        return True

    def _clearing_price(self, buy: Order, sell: Order) -> float | None:
        if buy.is_market_order and sell.is_market_order:
            return None  # two market orders can never establish a price
        if buy.is_market_order:
            return sell.limit_price
        if sell.is_market_order:
            return buy.limit_price
        # both limit orders resting/crossing: the earlier-arrived order
        # (the "maker") sets the execution price.
        maker = buy if buy.sequence < sell.sequence else sell
        return maker.limit_price

    def _execute(self, buy: Order, sell: Order, book: OrderBook) -> Trade | None:
        if not self._capacity_compatible(buy, sell):
            return None
        price = self._clearing_price(buy, sell)
        if price is None:
            return None
        quantity = min(buy.remaining_quantity, sell.remaining_quantity)
        if quantity <= 0:
            return None
        duration = min(buy.duration_hours, sell.duration_hours)

        buy.fill(quantity)
        sell.fill(quantity)
        book.touch(buy)
        book.touch(sell)

        trade = Trade(
            buy_order=buy,
            sell_order=sell,
            hardware_id=book.hardware_id,
            region=book.region,
            quantity=quantity,
            price=price,
            duration_hours=duration,
        )
        self.event_bus.emit(
            EventType.TRADE_EXECUTED,
            trade_id=trade.id,
            hardware_id=trade.hardware_id,
            region=trade.region,
            quantity=trade.quantity,
            price=trade.price,
            duration_hours=trade.duration_hours,
            buyer_id=trade.buyer_id,
            seller_provider_id=trade.seller_provider_id,
        )
        return trade

    def match_book(self, book: OrderBook) -> list[Trade]:
        """Sweep one order book to exhaustion: resolve resting market
        orders first (against best opposite limit price), then resolve any
        crossed limit-vs-limit levels in price-time priority."""
        trades: list[Trade] = []

        # 1) Market buy orders vs best resting ask.
        for buy in book.active_market_orders(OrderSide.BUY):
            while buy.remaining_quantity > 0:
                asks = book.ask_levels_best_first()
                if not asks:
                    break
                sell = self._first_active(asks[0].orders)
                if sell is None:
                    break
                trade = self._execute(buy, sell, book)
                if trade is None:
                    break
                trades.append(trade)

        # 2) Market sell orders vs best resting bid.
        for sell in book.active_market_orders(OrderSide.SELL):
            while sell.remaining_quantity > 0:
                bids = book.bid_levels_best_first()
                if not bids:
                    break
                buy = self._first_active(bids[0].orders)
                if buy is None:
                    break
                trade = self._execute(buy, sell, book)
                if trade is None:
                    break
                trades.append(trade)

        # 3) Crossed limit order book.
        while True:
            bids = book.bid_levels_best_first()
            asks = book.ask_levels_best_first()
            if not bids or not asks:
                break
            if bids[0].price < asks[0].price:
                break  # no more crosses
            buy = self._first_active(bids[0].orders)
            sell = self._first_active(asks[0].orders)
            if buy is None or sell is None:
                break
            trade = self._execute(buy, sell, book)
            if trade is None:
                # incompatible pair at this price — nothing more we can
                # safely clear at this level without violating section 12
                break
            trades.append(trade)

        return trades

    @staticmethod
    def _first_active(orders: list[Order]) -> Order | None:
        for o in orders:
            if o.remaining_quantity > 0 and o.status.value not in ("cancelled",):
                return o
        return None
