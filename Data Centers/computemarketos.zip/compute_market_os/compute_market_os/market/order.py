"""In-memory order representation used by the OrderBook / MatchingEngine.

Deliberately decoupled from the SQLAlchemy `Order` row so the core
matching logic is pure, synchronous, and trivially unit-testable. The API
layer (compute_market_os.api.routers.*) is responsible for persisting
orders/trades produced here into the database.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.enums import OrderSide, OrderStatus, OrderType

_id_counter = itertools.count(1)


def next_order_id() -> str:
    return f"ord-{next(_id_counter):09d}"


@dataclasses.dataclass(slots=True)
class Order:
    side: OrderSide
    hardware_id: str
    region: str
    quantity: int
    duration_hours: float
    limit_price: float | None = None
    order_type: OrderType = OrderType.LIMIT
    min_memory_gb: float | None = None
    min_performance_score: float | None = None
    max_latency_ms: float | None = None
    start_time: dt.datetime | None = None
    buyer_id: str | None = None
    provider_id: str | None = None
    id: str = dataclasses.field(default_factory=next_order_id)
    filled_quantity: int = 0
    status: OrderStatus = OrderStatus.OPEN
    created_at: dt.datetime = dataclasses.field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc)
    )
    sequence: int = dataclasses.field(default_factory=lambda: next(_id_counter))

    @property
    def remaining_quantity(self) -> int:
        return self.quantity - self.filled_quantity

    @property
    def is_market_order(self) -> bool:
        return self.order_type == OrderType.MARKET or self.limit_price is None

    def is_compatible_with(self, other: "Order") -> bool:
        """Compute-specific matching constraints beyond price/time
        (section 12/13): region + hardware are the order-book key so are
        already guaranteed equal; here we check duration/start alignment
        and any minimum requirements the buy side has stated."""
        if self.side == other.side:
            return False
        buy, sell = (self, other) if self.side == OrderSide.BUY else (other, self)

        if buy.duration_hours > sell.duration_hours:
            return False
        if buy.start_time and sell.start_time and buy.start_time < sell.start_time:
            return False
        return True

    def fill(self, quantity: int) -> None:
        if quantity <= 0 or quantity > self.remaining_quantity:
            raise ValueError("fill quantity out of range")
        self.filled_quantity += quantity
        self.status = (
            OrderStatus.FILLED if self.remaining_quantity == 0 else OrderStatus.PARTIALLY_FILLED
        )

    def cancel(self) -> None:
        if self.status in (OrderStatus.FILLED, OrderStatus.CANCELLED):
            return
        self.status = OrderStatus.CANCELLED
