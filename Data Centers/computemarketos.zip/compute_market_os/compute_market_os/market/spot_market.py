"""SpotMarket (section 16).

Generates a spot price at configurable intervals, driven by the
PricingEngine's scarcity curve (supply/demand/utilisation) and smoothed
with an EWMA so prices don't whipsaw tick to tick. All coefficients come
from config/pricing.yaml (`market_dynamics.spot`).
"""

from __future__ import annotations

import dataclasses
import datetime as dt

from compute_market_os.core.config import load_yaml_config
from compute_market_os.core.events import EventBus, EventType, default_bus
from compute_market_os.pricing.pricing_engine import PricingEngine, PriceBreakdown


@dataclasses.dataclass(slots=True)
class SpotPriceTick:
    hardware_id: str
    region: str
    price: float
    utilisation: float
    breakdown: PriceBreakdown
    timestamp: dt.datetime = dataclasses.field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc)
    )


class SpotMarket:
    def __init__(self, pricing_engine: PricingEngine | None = None, event_bus: EventBus | None = None) -> None:
        self.pricing_engine = pricing_engine or PricingEngine()
        self.event_bus = event_bus or default_bus
        cfg = load_yaml_config("pricing")["market_dynamics"]["spot"]
        self.smoothing_alpha: float = cfg["smoothing_alpha"]
        self.max_move_fraction: float = cfg["max_move_fraction_per_tick"]
        self.update_interval_seconds: int = cfg["update_interval_seconds"]
        self._last_price: dict[tuple[str, str], float] = {}

    def tick(
        self,
        hardware_id: str,
        region: str,
        utilisation: float,
        electricity_price_per_kwh: float | None = None,
        pue: float | None = None,
    ) -> SpotPriceTick:
        breakdown = self.pricing_engine.compute_price(
            hardware_id=hardware_id,
            utilisation=utilisation,
            electricity_price_per_kwh=electricity_price_per_kwh,
            pue=pue,
        )
        raw_price = breakdown.total_price_per_hour

        key = (hardware_id, region)
        previous = self._last_price.get(key)
        if previous is None:
            smoothed = raw_price
        else:
            ewma = self.smoothing_alpha * raw_price + (1 - self.smoothing_alpha) * previous
            # Clamp the tick-over-tick move so a single demand spike can't
            # teleport the price.
            max_delta = previous * self.max_move_fraction
            smoothed = max(min(ewma, previous + max_delta), previous - max_delta)
        self._last_price[key] = smoothed

        self.event_bus.emit(
            EventType.PRICE_UPDATED,
            hardware_id=hardware_id,
            region=region,
            market_segment="SPOT",
            price=round(smoothed, 4),
            utilisation=utilisation,
        )
        return SpotPriceTick(
            hardware_id=hardware_id,
            region=region,
            price=round(smoothed, 4),
            utilisation=utilisation,
            breakdown=breakdown,
        )

    def current_price(self, hardware_id: str, region: str) -> float | None:
        return self._last_price.get((hardware_id, region))

    def all_current_prices(self) -> dict[tuple[str, str], float]:
        return dict(self._last_price)
