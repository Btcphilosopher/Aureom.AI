"""OrderBook (section 11).

One OrderBook instance represents a single (hardware_id, region) market,
e.g. "H100 / Taiwan". Bids and asks are kept in price-time priority order.

Scale note (section 70): for the demo/tests this book lives in process
memory. At the 1M+ compute-unit / millions-of-orders scale the project
brief targets, the book for an actively-traded key would be materialised
from Redis (sorted sets keyed by price) with PostgreSQL as the durable
order log — the interface below (`add`, `cancel`, `best_bid`, `depth`,
`snapshot`) is written so that swap is an implementation detail behind
the same API.
"""

from __future__ import annotations

import bisect
import dataclasses

from compute_market_os.core.enums import OrderSide, OrderStatus
from compute_market_os.market.order import Order


@dataclasses.dataclass(slots=True)
class PriceLevel:
    price: float
    orders: list[Order] = dataclasses.field(default_factory=list)

    @property
    def total_quantity(self) -> int:
        return sum(o.remaining_quantity for o in self.orders)


class OrderBook:
    def __init__(self, hardware_id: str, region: str) -> None:
        self.hardware_id = hardware_id
        self.region = region
        # bids: highest price first; asks: lowest price first.
        self._bid_prices: list[float] = []   # ascending; we read reversed for best-first
        self._ask_prices: list[float] = []   # ascending
        self._bid_levels: dict[float, PriceLevel] = {}
        self._ask_levels: dict[float, PriceLevel] = {}
        self._orders_by_id: dict[str, Order] = {}
        # Market orders carry no price so they cannot sit in a price level;
        # they queue here in arrival order and are matched by the
        # MatchingEngine against the best resting opposite-side price.
        self._market_buy: list[Order] = []
        self._market_sell: list[Order] = []

    # -- mutation ----------------------------------------------------------

    def add(self, order: Order) -> None:
        if order.hardware_id != self.hardware_id or order.region != self.region:
            raise ValueError("order does not belong to this book (hardware/region mismatch)")
        self._orders_by_id[order.id] = order
        if order.is_market_order:
            queue = self._market_buy if order.side == OrderSide.BUY else self._market_sell
            queue.append(order)
            return
        prices, levels = self._side_storage(order.side)
        price = order.limit_price
        level = levels.get(price)
        if level is None:
            level = PriceLevel(price=price)
            levels[price] = level
            bisect.insort(prices, price)
        level.orders.append(order)

    def cancel(self, order_id: str) -> bool:
        order = self._orders_by_id.get(order_id)
        if order is None or order.status in (OrderStatus.FILLED, OrderStatus.CANCELLED):
            return False
        order.cancel()
        self._purge_price_level(order)
        return True

    def _purge_price_level(self, order: Order) -> None:
        if order.limit_price is None:
            return
        prices, levels = self._side_storage(order.side)
        level = levels.get(order.limit_price)
        if not level:
            return
        level.orders = [o for o in level.orders if o.status not in (OrderStatus.FILLED, OrderStatus.CANCELLED)]
        if not level.orders:
            del levels[order.limit_price]
            idx = bisect.bisect_left(prices, order.limit_price)
            if idx < len(prices) and prices[idx] == order.limit_price:
                prices.pop(idx)

    def touch(self, order: Order) -> None:
        """Called by the matching engine after (partially) filling an order
        resting on the book, to drop it from its price level once filled."""
        if order.status == OrderStatus.FILLED:
            self._purge_price_level(order)

    def _side_storage(self, side: OrderSide):
        if side == OrderSide.BUY:
            return self._bid_prices, self._bid_levels
        return self._ask_prices, self._ask_levels

    # -- read side -----------------------------------------------------------

    def bid_levels_best_first(self) -> list[PriceLevel]:
        return [self._bid_levels[p] for p in reversed(self._bid_prices) if self._bid_levels[p].total_quantity > 0]

    def ask_levels_best_first(self) -> list[PriceLevel]:
        return [self._ask_levels[p] for p in self._ask_prices if self._ask_levels[p].total_quantity > 0]

    def best_bid(self) -> float | None:
        levels = self.bid_levels_best_first()
        return levels[0].price if levels else None

    def best_ask(self) -> float | None:
        levels = self.ask_levels_best_first()
        return levels[0].price if levels else None

    def spread(self) -> float | None:
        bid, ask = self.best_bid(), self.best_ask()
        if bid is None or ask is None:
            return None
        return round(ask - bid, 6)

    def mid_price(self) -> float | None:
        bid, ask = self.best_bid(), self.best_ask()
        if bid is None or ask is None:
            return bid if bid is not None else ask
        return round((bid + ask) / 2, 6)

    def depth(self) -> int:
        """Total resting quantity on both sides."""
        return sum(l.total_quantity for l in self.bid_levels_best_first()) + sum(
            l.total_quantity for l in self.ask_levels_best_first()
        )

    def liquidity(self, levels: int = 5) -> float:
        """Notional value resting within the top N levels each side —
        a simple, transparent liquidity proxy."""
        total = 0.0
        for level in self.bid_levels_best_first()[:levels]:
            total += level.price * level.total_quantity
        for level in self.ask_levels_best_first()[:levels]:
            total += level.price * level.total_quantity
        return round(total, 2)

    def snapshot(self, levels: int = 25):
        from compute_market_os.core.schemas import OrderBookLevel, OrderBookSnapshot

        bids = [
            OrderBookLevel(price=l.price, quantity=l.total_quantity, order_count=len(l.orders))
            for l in self.bid_levels_best_first()[:levels]
        ]
        asks = [
            OrderBookLevel(price=l.price, quantity=l.total_quantity, order_count=len(l.orders))
            for l in self.ask_levels_best_first()[:levels]
        ]
        return OrderBookSnapshot(
            hardware_id=self.hardware_id,
            region=self.region,
            bids=bids,
            asks=asks,
            best_bid=self.best_bid(),
            best_ask=self.best_ask(),
            spread=self.spread(),
            mid_price=self.mid_price(),
            depth=self.depth(),
            liquidity=self.liquidity(),
        )

    def active_market_orders(self, side: OrderSide) -> list[Order]:
        queue = self._market_buy if side == OrderSide.BUY else self._market_sell
        active = [o for o in queue if o.status not in (OrderStatus.FILLED, OrderStatus.CANCELLED)]
        # opportunistically prune fully resolved entries
        if side == OrderSide.BUY:
            self._market_buy = active
        else:
            self._market_sell = active
        return sorted(active, key=lambda o: o.sequence)

    def get_order(self, order_id: str) -> Order | None:
        return self._orders_by_id.get(order_id)

    def all_orders(self) -> list[Order]:
        return list(self._orders_by_id.values())
