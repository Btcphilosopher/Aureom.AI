"""InferenceMarket (sections 22-23).

Providers advertise inference capacity (model, quantisation, hardware,
throughput, latency, price); buyers request a model/token budget/latency
ceiling/region/budget and the market ranks compliant offers.
"""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(slots=True, frozen=True)
class InferenceOffer:
    provider_id: str
    model_name: str
    quantisation: str
    hardware_id: str
    region: str
    tokens_per_second: float
    first_token_latency_ms: float
    price_per_1m_input_tokens: float
    price_per_1m_output_tokens: float

    def average_latency_ms(self, output_tokens: float) -> float:
        """First-token latency plus decode time for the remaining tokens
        at the advertised steady-state throughput."""
        if self.tokens_per_second <= 0:
            return self.first_token_latency_ms
        decode_ms = (max(output_tokens - 1, 0) / self.tokens_per_second) * 1000.0
        return self.first_token_latency_ms + decode_ms

    def cost(self, input_tokens: float, output_tokens: float) -> float:
        return (
            (input_tokens / 1_000_000.0) * self.price_per_1m_input_tokens
            + (output_tokens / 1_000_000.0) * self.price_per_1m_output_tokens
        )


@dataclasses.dataclass(slots=True, frozen=True)
class InferenceQuote:
    offer: InferenceOffer
    input_tokens: float
    output_tokens: float
    estimated_cost: float
    estimated_latency_ms: float
    within_budget: bool
    within_latency: bool


class InferenceMarket:
    def __init__(self) -> None:
        self._offers: list[InferenceOffer] = []

    def publish_offer(self, offer: InferenceOffer) -> None:
        self._offers.append(offer)

    def offers_for_model(self, model_name: str, region: str | None = None) -> list[InferenceOffer]:
        return [
            o for o in self._offers if o.model_name == model_name and (region is None or o.region == region)
        ]

    def quote(
        self,
        model_name: str,
        input_tokens: float,
        output_tokens: float,
        max_latency_ms: float | None = None,
        region: str | None = None,
        budget: float | None = None,
    ) -> list[InferenceQuote]:
        quotes = []
        for offer in self.offers_for_model(model_name, region):
            cost = offer.cost(input_tokens, output_tokens)
            latency = offer.average_latency_ms(output_tokens)
            quotes.append(
                InferenceQuote(
                    offer=offer,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    estimated_cost=round(cost, 6),
                    estimated_latency_ms=round(latency, 2),
                    within_budget=budget is None or cost <= budget,
                    within_latency=max_latency_ms is None or latency <= max_latency_ms,
                )
            )
        return quotes

    def best_offer(
        self,
        model_name: str,
        input_tokens: float,
        output_tokens: float,
        max_latency_ms: float | None = None,
        region: str | None = None,
        budget: float | None = None,
    ) -> InferenceQuote | None:
        compliant = [
            q
            for q in self.quote(model_name, input_tokens, output_tokens, max_latency_ms, region, budget)
            if q.within_budget and q.within_latency
        ]
        if not compliant:
            return None
        return min(compliant, key=lambda q: q.estimated_cost)
