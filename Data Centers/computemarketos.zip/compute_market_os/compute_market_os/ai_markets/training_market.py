"""TrainingMarket (section 24).

Estimates training time / GPU-hours / cost for a requested model+cluster
configuration. FLOPs are estimated with the standard dense-transformer
approximation `FLOPs ≈ 6 * N_params * N_tokens` (the widely used
Kaplan/Chinchilla-style rule of thumb for one forward+backward pass per
token) — documented as an approximation, not a vendor benchmark, and
effective throughput comes from the hardware's `training_tflops_effective`
benchmark field (section 5: never assume theoretical FLOPS = delivered
performance) combined with the ClusterOptimizer's parallel-efficiency
model for the requested GPU count.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.domain.hardware import ComputeHardware
from compute_market_os.optimisation.cluster_optimizer import ClusterOptimizer


@dataclasses.dataclass(slots=True, frozen=True)
class TrainingEstimate:
    model_name: str
    gpu_count: int
    total_flops: float
    parallel_efficiency: float
    estimated_training_hours: float
    estimated_gpu_hours: float
    estimated_cost: float
    price_per_gpu_hour: float


class TrainingMarket:
    FLOPS_PER_PARAM_PER_TOKEN = 6.0  # forward + backward pass, standard dense-transformer approximation

    def __init__(self, cluster_optimizer: ClusterOptimizer | None = None) -> None:
        self.cluster_optimizer = cluster_optimizer or ClusterOptimizer()

    def estimate(
        self,
        model_name: str,
        model_params_billion: float,
        tokens_billion: float,
        hardware: ComputeHardware,
        gpu_count: int,
        price_per_gpu_hour: float,
        comm_overhead_coefficient: float = 0.06,
    ) -> TrainingEstimate:
        total_flops = self.FLOPS_PER_PARAM_PER_TOKEN * (model_params_billion * 1e9) * (tokens_billion * 1e9)
        total_pflop_s_days = total_flops / (1e15 * 86400)

        options = self.cluster_optimizer.compare(
            hardware=hardware,
            total_training_pflop_s_days=total_pflop_s_days,
            price_per_gpu_hour=price_per_gpu_hour,
            comm_overhead_coefficient=comm_overhead_coefficient,
            candidate_sizes=(gpu_count,),
        )
        option = options[0]
        return TrainingEstimate(
            model_name=model_name,
            gpu_count=gpu_count,
            total_flops=total_flops,
            parallel_efficiency=option.parallel_efficiency,
            estimated_training_hours=option.training_time_hours,
            estimated_gpu_hours=option.total_gpu_hours,
            estimated_cost=option.total_cost,
            price_per_gpu_hour=price_per_gpu_hour,
        )
