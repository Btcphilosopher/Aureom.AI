"""Synthetic demonstration market (section 73).

SIMULATED MARKET — NOT LIVE MARKET DATA.

Generates: 10 providers, 20 datacenters, 5 regions, 6 accelerator types,
10,000+ GPU units of installed inventory, with self-consistent power/
cooling envelopes (so the PowerConstraint never has to be violated to
explain the seeded state) and inventory splits that sum correctly
(installed = available + reserved + running + offline).
"""

from __future__ import annotations

import numpy as np
from sqlalchemy.orm import Session

from compute_market_os.core import models
from compute_market_os.core.seed import seed_hardware_catalog
from compute_market_os.domain.hardware import load_hardware_catalog

DEMO_REGIONS = ["TPE", "SIN", "TOK", "IAD", "FRA"]
DEMO_HARDWARE_IDS = ["hw-h100-sxm", "hw-a100-80g", "hw-b200", "hw-mi300x", "hw-tpu-v5p", "hw-epyc-9654"]

PROVIDER_NAMES = [
    ("Nimbus GPU Cloud", "gpu_cloud"),
    ("Helios Hyperscale", "hyperscaler"),
    ("Pacific Rim Datacenters", "enterprise_datacenter"),
    ("QuantEdge AI Cloud", "ai_cloud"),
    ("Northstar Colocation", "colocation_provider"),
    ("Meridian Compute", "gpu_cloud"),
    ("Ironclad Systems", "private_operator"),
    ("Tsinghua-Delta University Cluster", "university_cluster"),
    ("Vantage Edge Compute", "edge_provider"),
    ("Solaris Enterprise IT", "enterprise_datacenter"),
]

COUNTRY_BY_REGION = {"TPE": "TW", "SIN": "SG", "TOK": "JP", "IAD": "US", "FRA": "DE"}


def generate_demo_market(session: Session, seed: int = 42, target_total_gpus: int = 12000) -> dict:
    rng = np.random.default_rng(seed)

    seed_hardware_catalog(session)
    catalog = load_hardware_catalog()

    providers = []
    for name, provider_type in PROVIDER_NAMES:
        region = DEMO_REGIONS[rng.integers(0, len(DEMO_REGIONS))]
        provider = models.Provider(
            name=name,
            provider_type=provider_type,
            country=COUNTRY_BY_REGION[region],
            region=region,
            reliability=round(float(rng.uniform(0.97, 0.9995)), 4),
            pricing_model={"strategy": "cost_plus_scarcity"},
        )
        session.add(provider)
        providers.append(provider)
    session.flush()

    datacenters = []
    for i in range(20):
        provider = providers[i % len(providers)]
        region = provider.region if rng.random() < 0.7 else DEMO_REGIONS[rng.integers(0, len(DEMO_REGIONS))]
        dc = models.DataCenter(
            provider_id=provider.id,
            code=f"{region}-{i:02d}",
            region=region,
            location=f"{region} Metro Campus {i:02d}",
            latitude=float(rng.uniform(-60, 65)),
            longitude=float(rng.uniform(-180, 180)),
            power_capacity_mw=0.0,   # filled in after inventory is sized
            it_load_mw=0.0,
            cooling_capacity_mw=0.0,
            network_capacity_tbps=round(float(rng.uniform(2, 40)), 2),
            pue=round(float(rng.uniform(1.15, 1.5)), 3),
            availability=round(float(rng.uniform(0.985, 0.9999)), 4),
        )
        session.add(dc)
        datacenters.append(dc)
    session.flush()

    # distribute target_total_gpus (for GPU/AI_ACCELERATOR/TPU categories)
    # plus a comparable pool of CPU units across datacenters x hardware SKUs.
    inventory_rows = []
    installed_gpu_total = 0
    for dc in datacenters:
        total_it_watts = 0.0
        n_skus = int(rng.integers(2, len(DEMO_HARDWARE_IDS) + 1))
        chosen_skus = rng.choice(DEMO_HARDWARE_IDS, size=n_skus, replace=False)
        for hw_id in chosen_skus:
            hw = catalog[hw_id]
            base = int(target_total_gpus / (len(datacenters) * len(DEMO_HARDWARE_IDS) / n_skus))
            installed = max(int(rng.integers(max(base // 2, 8), base * 2 + 8)), 8)
            if hw.category != "CPU":
                installed_gpu_total += installed

            offline = int(installed * float(rng.uniform(0.0, 0.05)))
            reserved = int(installed * float(rng.uniform(0.10, 0.45)))
            running = int((installed - offline - reserved) * float(rng.uniform(0.2, 0.75)))
            available = max(installed - offline - reserved - running, 0)

            inventory_rows.append(
                models.InventoryItem(
                    datacenter_id=dc.id,
                    hardware_id=hw_id,
                    installed_quantity=installed,
                    available_quantity=available,
                    reserved_quantity=reserved,
                    running_quantity=running,
                    offline_quantity=offline,
                )
            )
            total_it_watts += running * hw.power_watts + reserved * hw.power_watts * 0.3

        it_load_mw = total_it_watts / 1_000_000.0
        dc.it_load_mw = round(it_load_mw, 4)
        dc.cooling_capacity_mw = round(it_load_mw * (dc.pue - 1.0) * 1.3 + 0.05, 4)
        # Headroom above current draw so publish_capacity/reservation demos
        # have room to grow without immediately hitting PowerConstraint.
        dc.power_capacity_mw = round(it_load_mw * dc.pue * float(rng.uniform(1.4, 2.2)) + 0.5, 4)

    session.add_all(inventory_rows)
    session.commit()

    return {
        "disclaimer": "SIMULATED MARKET — NOT LIVE MARKET DATA",
        "providers": len(providers),
        "datacenters": len(datacenters),
        "regions": len(DEMO_REGIONS),
        "accelerator_types": len(DEMO_HARDWARE_IDS),
        "installed_gpu_units": installed_gpu_total,
        "inventory_rows": len(inventory_rows),
    }
