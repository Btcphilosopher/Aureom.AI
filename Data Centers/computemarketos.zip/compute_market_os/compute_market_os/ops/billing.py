"""Billing (section 48).

Supports pay-as-you-go, reserved, spot, auction, and contract line items;
calculates subtotal / tax / discount / credit / total. Tax rate is
configurable (config/markets.yaml `billing.default_tax_fraction`), never
hard-coded.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.config import load_yaml_config

_id_counter = itertools.count(1)

BILLING_MODES = ("pay_as_you_go", "reserved", "spot", "auction", "contract")


@dataclasses.dataclass(slots=True, frozen=True)
class LineItem:
    description: str
    billing_mode: str
    quantity: float
    unit_price: float

    @property
    def amount(self) -> float:
        return round(self.quantity * self.unit_price, 6)

    def as_dict(self) -> dict:
        return {
            "description": self.description,
            "billing_mode": self.billing_mode,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "amount": self.amount,
        }


@dataclasses.dataclass(slots=True, frozen=True)
class Invoice:
    buyer_id: str | None
    period_start: dt.datetime
    period_end: dt.datetime
    line_items: list[LineItem]
    subtotal: float
    tax: float
    discount: float
    credit: float
    total: float
    invoice_number: str = dataclasses.field(default_factory=lambda: f"CMOS-INV-{next(_id_counter):09d}")

    def as_dict(self) -> dict:
        return {
            "invoice_number": self.invoice_number,
            "buyer_id": self.buyer_id,
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "line_items": [li.as_dict() for li in self.line_items],
            "subtotal": self.subtotal,
            "tax": self.tax,
            "discount": self.discount,
            "credit": self.credit,
            "total": self.total,
        }


class BillingEngine:
    def __init__(self) -> None:
        self._cfg = load_yaml_config("markets")["billing"]

    def build_invoice(
        self,
        buyer_id: str | None,
        period_start: dt.datetime,
        period_end: dt.datetime,
        line_items: list[LineItem],
        discount_fraction: float = 0.0,
        credit_amount: float = 0.0,
        tax_fraction: float | None = None,
    ) -> Invoice:
        for li in line_items:
            if li.billing_mode not in BILLING_MODES:
                raise ValueError(f"unknown billing_mode {li.billing_mode!r}; expected one of {BILLING_MODES}")

        subtotal = round(sum(li.amount for li in line_items), 2)
        discount = round(subtotal * discount_fraction, 2)
        tax_fraction = tax_fraction if tax_fraction is not None else self._cfg["default_tax_fraction"]
        taxable_base = max(subtotal - discount, 0.0)
        tax = round(taxable_base * tax_fraction, 2)
        total = round(taxable_base + tax - credit_amount, 2)

        return Invoice(
            buyer_id=buyer_id,
            period_start=period_start,
            period_end=period_end,
            line_items=line_items,
            subtotal=subtotal,
            tax=tax,
            discount=discount,
            credit=credit_amount,
            total=max(total, 0.0),
        )
