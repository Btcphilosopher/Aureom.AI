"""SettlementEngine (section 46).

Turns metered usage (UsageMeter records) plus network/storage add-ons and
any SLA credits into a billed invoice via BillingEngine — the single path
from "what was consumed" to "what is owed".
"""

from __future__ import annotations

import datetime as dt

from compute_market_os.ops.billing import BillingEngine, Invoice, LineItem
from compute_market_os.ops.sla_engine import SLAAssessment
from compute_market_os.ops.usage_meter import UsageMeter

_METRIC_LABELS = {
    "gpu_hours": ("GPU compute", "spot"),
    "cpu_hours": ("CPU compute", "spot"),
    "ram_gb_hours": ("Memory", "pay_as_you_go"),
    "storage_gb_hours": ("Storage", "pay_as_you_go"),
    "network_gb": ("Network egress", "pay_as_you_go"),
    "tokens": ("Inference tokens", "pay_as_you_go"),
    "compute_seconds": ("Compute-seconds", "pay_as_you_go"),
}


class SettlementEngine:
    def __init__(self, usage_meter: UsageMeter, billing_engine: BillingEngine | None = None) -> None:
        self.usage_meter = usage_meter
        self.billing_engine = billing_engine or BillingEngine()

    def settle(
        self,
        buyer_id: str,
        period_start: dt.datetime,
        period_end: dt.datetime,
        sla_assessments: list[SLAAssessment] | None = None,
        discount_fraction: float = 0.0,
        tax_fraction: float | None = None,
    ) -> Invoice:
        records = self.usage_meter.records_for(buyer_id, period_start, period_end)
        line_items = []
        for record in records:
            if record.amount == 0:
                continue
            label, mode = _METRIC_LABELS.get(record.metric, (record.metric, "pay_as_you_go"))
            line_items.append(
                LineItem(
                    description=f"{label} ({record.hardware_id or 'n/a'})",
                    billing_mode=mode,
                    quantity=record.quantity,
                    unit_price=record.unit_price,
                )
            )

        credit_amount = round(sum(a.credit_amount for a in (sla_assessments or [])), 2)

        return self.billing_engine.build_invoice(
            buyer_id=buyer_id,
            period_start=period_start,
            period_end=period_end,
            line_items=line_items,
            discount_fraction=discount_fraction,
            credit_amount=credit_amount,
            tax_fraction=tax_fraction,
        )
