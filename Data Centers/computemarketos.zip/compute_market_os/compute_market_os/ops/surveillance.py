"""MarketSurveillanceEngine (sections 55-56).

Detects *patterns* that warrant human review — wash trading, spoofing-like
order behaviour, capacity double-booking, abnormal price moves, rapid
cancellation. It never accuses anyone of wrongdoing: output is always one
of NORMAL / WATCH / ANOMALY / CRITICAL with a stated reason and the
evidence that produced it, for a human reviewer to judge.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
from collections import Counter, defaultdict

from compute_market_os.core.config import load_yaml_config
from compute_market_os.core.enums import SurveillanceLevel


@dataclasses.dataclass(slots=True, frozen=True)
class SurveillanceFlag:
    level: SurveillanceLevel
    reason: str
    evidence: dict
    timestamp: dt.datetime = dataclasses.field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    related_actor_id: str | None = None


class MarketSurveillanceEngine:
    def __init__(self) -> None:
        self._cfg = load_yaml_config("markets")["surveillance"]

    # -- rapid cancellation --------------------------------------------------

    def check_rapid_cancellations(self, actor_id: str, cancellation_times: list[dt.datetime]) -> SurveillanceFlag | None:
        window = dt.timedelta(seconds=self._cfg["rapid_cancel_window_seconds"])
        threshold = self._cfg["rapid_cancel_threshold_count"]
        times = sorted(cancellation_times)
        for i in range(len(times)):
            count = sum(1 for t in times[i:] if t - times[i] <= window)
            if count >= threshold:
                return SurveillanceFlag(
                    level=SurveillanceLevel.WATCH,
                    reason=f"{count} order cancellations by {actor_id} within {window}",
                    evidence={"actor_id": actor_id, "cancellations_in_window": count, "window_seconds": window.total_seconds()},
                    related_actor_id=actor_id,
                )
        return None

    # -- wash trading ---------------------------------------------------------

    def check_wash_trading(self, trades: list, lookback_minutes: int | None = None) -> SurveillanceFlag | None:
        """Flags when the same actor appears as both buyer and seller
        across trades in the lookback window — the classic wash-trading
        signature — without asserting intent."""
        lookback_minutes = lookback_minutes or self._cfg["wash_trade_lookback_minutes"]
        cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=lookback_minutes)
        recent = [t for t in trades if getattr(t, "timestamp", cutoff) >= cutoff]

        self_trade_actors = Counter()
        for t in recent:
            buyer = getattr(t, "buyer_id", None)
            seller = getattr(t, "seller_provider_id", None)
            if buyer is not None and buyer == seller:
                self_trade_actors[buyer] += 1

        if not self_trade_actors:
            return None
        actor, count = self_trade_actors.most_common(1)[0]
        level = SurveillanceLevel.CRITICAL if count >= 5 else SurveillanceLevel.ANOMALY
        return SurveillanceFlag(
            level=level,
            reason=f"actor {actor} appears as both buyer and seller in {count} trade(s) within {lookback_minutes} minutes",
            evidence={"actor_id": actor, "self_trade_count": count, "lookback_minutes": lookback_minutes},
            related_actor_id=actor,
        )

    # -- abnormal price movement ------------------------------------------------

    def check_abnormal_price_move(self, price_history: list[tuple[dt.datetime, float]]) -> SurveillanceFlag | None:
        window = dt.timedelta(minutes=self._cfg["abnormal_price_window_minutes"])
        threshold = self._cfg["abnormal_price_move_fraction"]
        if len(price_history) < 2:
            return None
        history = sorted(price_history, key=lambda p: p[0])
        latest_ts, latest_price = history[-1]
        baseline = next((p for ts, p in reversed(history[:-1]) if latest_ts - ts >= window), history[0][1])
        if baseline <= 0:
            return None
        move = (latest_price - baseline) / baseline
        if abs(move) >= threshold:
            level = SurveillanceLevel.ANOMALY if abs(move) < threshold * 2 else SurveillanceLevel.CRITICAL
            return SurveillanceFlag(
                level=level,
                reason=f"price moved {move:+.2%} within {window}",
                evidence={"baseline_price": baseline, "latest_price": latest_price, "move_fraction": round(move, 4)},
            )
        return None

    # -- capacity double booking -----------------------------------------------

    def check_capacity_double_booking(
        self, reservations: list, installed_capacity: int, datacenter_id: str, hardware_id: str
    ) -> SurveillanceFlag | None:
        """Flags overlapping active reservations whose combined quantity
        exceeds installed capacity for a (datacenter, hardware) pair —
        this should be structurally prevented by the reservation ledger's
        row-level locking, so a flag here indicates that safeguard was
        bypassed and needs investigation."""
        relevant = [
            r
            for r in reservations
            if getattr(r, "datacenter_id", None) == datacenter_id
            and getattr(r, "hardware_id", None) == hardware_id
            and getattr(r, "status", "active") == "active"
        ]
        # sweep-line over start/end events to find peak concurrent quantity
        events: list[tuple[dt.datetime, int]] = []
        for r in relevant:
            events.append((r.start_time, r.quantity))
            events.append((r.end_time, -r.quantity))
        events.sort(key=lambda e: e[0])
        running = 0
        peak = 0
        for _, delta in events:
            running += delta
            peak = max(peak, running)
        if peak > installed_capacity:
            return SurveillanceFlag(
                level=SurveillanceLevel.CRITICAL,
                reason=f"peak concurrent reservations ({peak}) exceed installed capacity ({installed_capacity})",
                evidence={"datacenter_id": datacenter_id, "hardware_id": hardware_id, "peak_reserved": peak, "installed_capacity": installed_capacity},
            )
        return None

    # -- aggregate --------------------------------------------------------------

    def summarise(self, flags: list[SurveillanceFlag]) -> SurveillanceLevel:
        if not flags:
            return SurveillanceLevel.NORMAL
        order = [SurveillanceLevel.NORMAL, SurveillanceLevel.WATCH, SurveillanceLevel.ANOMALY, SurveillanceLevel.CRITICAL]
        return max(flags, key=lambda f: order.index(f.level)).level
