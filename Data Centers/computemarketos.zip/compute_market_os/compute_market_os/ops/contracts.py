"""ComputeContract (section 45) — pure domain wrapper with status
transitions, independent of the SQLAlchemy row used for persistence."""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools

from compute_market_os.core.enums import ContractStatus

_id_counter = itertools.count(1)


@dataclasses.dataclass(slots=True)
class ComputeContract:
    buyer_id: str | None
    provider_id: str
    hardware_id: str
    quantity: int
    region: str
    start: dt.datetime
    end: dt.datetime
    price_per_hour: float
    sla_tier: str = "STANDARD"
    id: str = dataclasses.field(default_factory=lambda: f"con-{next(_id_counter):09d}")
    status: ContractStatus = ContractStatus.PENDING

    @property
    def duration_hours(self) -> float:
        return (self.end - self.start).total_seconds() / 3600.0

    @property
    def total_gpu_hours(self) -> float:
        return self.quantity * self.duration_hours

    @property
    def total_value(self) -> float:
        return round(self.total_gpu_hours * self.price_per_hour, 2)

    def activate(self) -> None:
        if self.status != ContractStatus.PENDING:
            raise ValueError(f"cannot activate contract in status {self.status}")
        self.status = ContractStatus.ACTIVE

    def complete(self) -> None:
        if self.status != ContractStatus.ACTIVE:
            raise ValueError(f"cannot complete contract in status {self.status}")
        self.status = ContractStatus.COMPLETED

    def breach(self, reason: str = "") -> None:
        self.status = ContractStatus.BREACHED

    def cancel(self) -> None:
        if self.status in (ContractStatus.COMPLETED, ContractStatus.BREACHED):
            raise ValueError(f"cannot cancel contract in status {self.status}")
        self.status = ContractStatus.CANCELLED
