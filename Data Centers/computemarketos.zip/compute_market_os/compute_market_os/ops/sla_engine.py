"""SLAEngine (section 44).

Tiers (STANDARD / PREMIUM / BEST_EFFORT) and their uptime/latency targets
and credit fractions come from config/markets.yaml (`sla_tiers`) — never
hard-coded here.
"""

from __future__ import annotations

import dataclasses
import datetime as dt

from compute_market_os.core.config import load_yaml_config


@dataclasses.dataclass(slots=True, frozen=True)
class SLAAssessment:
    tier: str
    period_start: dt.datetime
    period_end: dt.datetime
    uptime_target: float
    uptime_actual: float
    latency_target_ms: float
    latency_actual_ms: float
    compliant: bool
    breach_reasons: list[str]
    credit_fraction: float
    credit_amount: float


class SLAEngine:
    def __init__(self) -> None:
        self._tiers = load_yaml_config("markets")["sla_tiers"]

    def tier_config(self, tier: str) -> dict:
        if tier not in self._tiers:
            raise KeyError(f"Unknown SLA tier: {tier!r}")
        return self._tiers[tier]

    def assess(
        self,
        tier: str,
        period_start: dt.datetime,
        period_end: dt.datetime,
        uptime_actual: float,
        latency_actual_ms: float,
        period_charge: float,
    ) -> SLAAssessment:
        cfg = self.tier_config(tier)
        uptime_target = cfg["uptime_target"]
        latency_target = cfg["latency_target_ms"]
        credit_fraction_per_breach = cfg["credit_per_breach_fraction"]

        breaches = []
        if uptime_actual < uptime_target:
            breaches.append(f"uptime {uptime_actual:.4%} below target {uptime_target:.4%}")
        if latency_actual_ms > latency_target:
            breaches.append(f"latency {latency_actual_ms:.1f}ms above target {latency_target:.1f}ms")

        compliant = not breaches
        credit_fraction = 0.0 if compliant else min(credit_fraction_per_breach * len(breaches), 1.0)
        credit_amount = round(period_charge * credit_fraction, 2)

        return SLAAssessment(
            tier=tier,
            period_start=period_start,
            period_end=period_end,
            uptime_target=uptime_target,
            uptime_actual=uptime_actual,
            latency_target_ms=latency_target,
            latency_actual_ms=latency_actual_ms,
            compliant=compliant,
            breach_reasons=breaches,
            credit_fraction=credit_fraction,
            credit_amount=credit_amount,
        )
