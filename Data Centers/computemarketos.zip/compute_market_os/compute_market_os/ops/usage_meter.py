"""UsageMeter (section 47).

Records metered consumption: compute seconds, GPU-hours, CPU-hours,
RAM GB-hours, storage GB-hours, network GB, tokens.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import itertools
from collections import defaultdict

_id_counter = itertools.count(1)

METRICS = (
    "compute_seconds",
    "gpu_hours",
    "cpu_hours",
    "ram_gb_hours",
    "storage_gb_hours",
    "network_gb",
    "tokens",
)


@dataclasses.dataclass(slots=True, frozen=True)
class UsageRecord:
    buyer_id: str
    metric: str
    quantity: float
    unit_price: float = 0.0
    contract_id: str | None = None
    reservation_id: str | None = None
    hardware_id: str | None = None
    id: str = dataclasses.field(default_factory=lambda: f"usg-{next(_id_counter):09d}")
    recorded_at: dt.datetime = dataclasses.field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))

    @property
    def amount(self) -> float:
        return round(self.quantity * self.unit_price, 6)


class UsageMeter:
    def __init__(self) -> None:
        self._records: list[UsageRecord] = []

    def record(
        self,
        buyer_id: str,
        metric: str,
        quantity: float,
        unit_price: float = 0.0,
        contract_id: str | None = None,
        reservation_id: str | None = None,
        hardware_id: str | None = None,
    ) -> UsageRecord:
        if metric not in METRICS:
            raise ValueError(f"unknown usage metric {metric!r}; expected one of {METRICS}")
        record = UsageRecord(
            buyer_id=buyer_id,
            metric=metric,
            quantity=quantity,
            unit_price=unit_price,
            contract_id=contract_id,
            reservation_id=reservation_id,
            hardware_id=hardware_id,
        )
        self._records.append(record)
        return record

    def records_for(
        self,
        buyer_id: str,
        period_start: dt.datetime | None = None,
        period_end: dt.datetime | None = None,
    ) -> list[UsageRecord]:
        records = [r for r in self._records if r.buyer_id == buyer_id]
        if period_start:
            records = [r for r in records if r.recorded_at >= period_start]
        if period_end:
            records = [r for r in records if r.recorded_at < period_end]
        return records

    def summarise(
        self, buyer_id: str, period_start: dt.datetime | None = None, period_end: dt.datetime | None = None
    ) -> dict[str, float]:
        totals: dict[str, float] = defaultdict(float)
        for r in self.records_for(buyer_id, period_start, period_end):
            totals[r.metric] += r.quantity
        return dict(totals)
