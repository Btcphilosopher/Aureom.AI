"""Compute Market OS — a programmable Compute Capacity Exchange.

SIMULATED MARKET — the bundled configuration and synthetic data generator
produce demonstration data only. This is not a source of live market prices.
"""

__version__ = "0.1.0"
