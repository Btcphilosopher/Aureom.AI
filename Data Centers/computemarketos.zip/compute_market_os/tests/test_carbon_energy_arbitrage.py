from compute_market_os.domain.hardware import load_hardware_catalog
from compute_market_os.optimisation.arbitrage_engine import ComputeArbitrageEngine
from compute_market_os.pricing.carbon_engine import CarbonAwareScheduler
from compute_market_os.pricing.energy_cost_engine import EnergyCostEngine


def test_energy_cost_scales_with_pue():
    catalog = load_hardware_catalog()
    hw = catalog["hw-h100-sxm"]
    engine = EnergyCostEngine()
    low_pue = engine.cost_per_unit_hour(hw, electricity_price_per_kwh=0.15, pue=1.1)
    high_pue = engine.cost_per_unit_hour(hw, electricity_price_per_kwh=0.15, pue=1.6)
    assert high_pue.total_energy_cost_per_hour > low_pue.total_energy_cost_per_hour
    assert low_pue.raw_energy_cost_per_hour == high_pue.raw_energy_cost_per_hour  # IT power draw is PUE-independent


def test_carbon_estimate_uses_regional_grid_intensity():
    catalog = load_hardware_catalog()
    hw = catalog["hw-h100-sxm"]
    scheduler = CarbonAwareScheduler()
    tpe = scheduler.estimate(hw, "TPE")   # higher grid intensity
    pdx = scheduler.estimate(hw, "PDX")   # much cleaner grid (hydro-heavy)
    assert tpe is not None and pdx is not None
    assert tpe.kgco2e_per_gpu_hour > pdx.kgco2e_per_gpu_hour


def test_carbon_filter_respects_max_intensity():
    scheduler = CarbonAwareScheduler()
    within_limit = scheduler.filter_regions_within_limit(["TPE", "PDX", "FRA"], max_intensity_gco2_per_kwh=200)
    assert "PDX" in within_limit
    assert "TPE" not in within_limit


def test_arbitrage_not_exploitable_when_transfer_cost_erases_gap():
    engine = ComputeArbitrageEngine()
    result = engine.evaluate(
        hardware_id="hw-h100-sxm", region_a="TPE", price_a=2.00, region_b="LON", price_b=2.05,
        data_movement_gb=100_000, runtime_hours=1,
    )
    assert result.exploitable is False


def test_arbitrage_exploitable_with_large_gap_and_small_transfer():
    engine = ComputeArbitrageEngine()
    result = engine.evaluate(
        hardware_id="hw-h100-sxm", region_a="TPE", price_a=1.50, region_b="SIN", price_b=3.50,
        data_movement_gb=1, runtime_hours=168,
    )
    assert result.exploitable is True
    assert result.net_gap_per_gpu_hour > 0


def test_arbitrage_blocked_when_workload_not_migratable():
    engine = ComputeArbitrageEngine()
    result = engine.evaluate(
        hardware_id="hw-h100-sxm", region_a="TPE", price_a=1.00, region_b="SIN", price_b=5.00,
        workload_migratable=False,
    )
    assert result.exploitable is False
    assert "not migratable" in result.reason
