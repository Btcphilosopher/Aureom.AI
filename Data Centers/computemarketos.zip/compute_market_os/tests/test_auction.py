from compute_market_os.core.enums import AuctionStatus
from compute_market_os.market.auction_engine import AuctionEngine, Bid


def test_capacity_auction_uniform_price_clearing():
    engine = AuctionEngine()
    auction = engine.create_auction("capacity_auction", "hw-h100-sxm", "TPE", quantity_offered=1000, reserve_price=1.5)
    engine.submit_bid(auction, Bid("buyer-A", price=2.20, quantity=400))
    engine.submit_bid(auction, Bid("buyer-B", price=2.15, quantity=350))
    engine.submit_bid(auction, Bid("buyer-C", price=2.05, quantity=600))

    result = engine.clear(auction)
    assert result.status == AuctionStatus.CLEARED
    # 400 + 350 + 250 (partial C) = 1000, marginal price is buyer-C's bid
    assert result.clearing_price == 2.05
    assert result.total_quantity_cleared == 1000
    assert all(w["price"] == 2.05 for w in result.winners)


def test_sealed_bid_rejects_bids_below_reserve():
    engine = AuctionEngine()
    auction = engine.create_auction("sealed_bid", "hw-h100-sxm", "TPE", quantity_offered=100, reserve_price=2.0)
    engine.submit_bid(auction, Bid("buyer-A", price=1.50, quantity=100))
    result = engine.clear(auction)
    assert result.status == AuctionStatus.FAILED
    assert result.winners == []


def test_reverse_auction_lowest_compliant_bid_wins():
    engine = AuctionEngine()
    auction = engine.create_auction("reverse", "hw-h100-sxm", "TPE", quantity_offered=1000, reserve_price=2.10)
    engine.submit_bid(auction, Bid("provider-A", price=1.95, quantity=1000))
    engine.submit_bid(auction, Bid("provider-B", price=2.05, quantity=1000))
    engine.submit_bid(auction, Bid("provider-C", price=2.50, quantity=1000))  # exceeds buyer ceiling

    result = engine.clear(auction)
    assert result.status == AuctionStatus.CLEARED
    assert result.best_bid.bidder_id == "provider-A"
    assert result.second_best_bid.bidder_id == "provider-B"
    assert result.clearing_price == 1.95


def test_performance_adjusted_ranking():
    engine = AuctionEngine()
    auction = engine.create_auction("sealed_bid", "hw-h100-sxm", "TPE", quantity_offered=100, reserve_price=0.0)
    engine.submit_bid(auction, Bid("buyer-A", price=3.00, quantity=100, performance_score=100))  # 0.03 / unit
    engine.submit_bid(auction, Bid("buyer-B", price=2.00, quantity=100, performance_score=50))   # 0.04 / unit
    result = engine.clear(auction)
    assert result.performance_adjusted_best.bidder_id == "buyer-A"


def test_english_auction_second_price_style():
    engine = AuctionEngine()
    auction = engine.create_auction("english", "hw-h100-sxm", "TPE", quantity_offered=100, reserve_price=1.0)
    engine.submit_bid(auction, Bid("buyer-A", price=3.00, quantity=100))
    engine.submit_bid(auction, Bid("buyer-B", price=2.50, quantity=100))
    result = engine.clear(auction)
    assert result.best_bid.bidder_id == "buyer-A"
    assert result.clearing_price == 2.51
