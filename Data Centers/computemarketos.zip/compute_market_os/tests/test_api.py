import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    from compute_market_os.api.main import app

    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_hardware_catalog_served(client):
    r = client.get("/api/hardware")
    assert r.status_code == 200
    assert len(r.json()) >= 6


def test_submit_order_and_orderbook(client):
    r = client.post(
        "/api/market/orders",
        json={"side": "BUY", "hardware_id": "hw-h100-sxm", "region": "TPE-API-1", "quantity": 16, "duration_hours": 24, "limit_price": 2.0},
    )
    assert r.status_code == 200
    order_id = r.json()["id"]

    r = client.get("/api/orderbook", params={"hardware_id": "hw-h100-sxm", "region": "TPE-API-1"})
    assert r.status_code == 200
    assert r.json()["best_bid"] == 2.0

    r = client.delete(f"/api/market/orders/{order_id}", params={"hardware_id": "hw-h100-sxm", "region": "TPE-API-1"})
    assert r.status_code == 200


def test_double_booking_prevented_by_reservation_ledger(client):
    """Section 39/69: two concurrent reservations for the same capacity
    must not both succeed once availability is exhausted."""
    from compute_market_os.core import models
    from compute_market_os.core.database import SessionLocal

    with SessionLocal() as session:
        provider = models.Provider(name="Test Provider", provider_type="gpu_cloud", country="TW", region="TPE")
        session.add(provider)
        session.flush()
        dc = models.DataCenter(
            provider_id=provider.id, code="TW-TEST-DBL", region="TPE", location="x",
            latitude=0, longitude=0, power_capacity_mw=100, it_load_mw=0,
            cooling_capacity_mw=50, network_capacity_tbps=10, pue=1.3,
        )
        session.add(dc)
        session.flush()
        inventory = models.InventoryItem(
            datacenter_id=dc.id, hardware_id="hw-h100-sxm",
            installed_quantity=10, available_quantity=10,
        )
        session.add(inventory)
        session.commit()
        provider_id, dc_id = provider.id, dc.id

    payload = {
        "provider_id": provider_id,
        "datacenter_id": dc_id,
        "hardware_id": "hw-h100-sxm",
        "quantity": 8,
        "start_time": "2026-10-01T00:00:00Z",
        "end_time": "2026-10-02T00:00:00Z",
    }
    r1 = client.post("/api/capacity/reservations", json=payload)
    assert r1.status_code == 200, r1.text

    # A second reservation for 8 more units should fail: only 2 remain available.
    r2 = client.post("/api/capacity/reservations", json=payload)
    assert r2.status_code == 409


def test_auction_lifecycle(client):
    r = client.post(
        "/api/auctions",
        json={"auction_type": "capacity_auction", "hardware_id": "hw-h100-sxm", "region": "TPE-AUC", "quantity_gpu_hours": 100, "reserve_price": 1.0},
    )
    assert r.status_code == 200
    auction_id = r.json()["id"]

    r = client.post(f"/api/auctions/{auction_id}/bids", json={"bidder_id": "buyer-A", "price": 2.0, "quantity": 100})
    assert r.status_code == 200

    r = client.post(f"/api/auctions/{auction_id}/clear")
    assert r.status_code == 200
    assert r.json()["status"] == "cleared"


def test_market_summary_endpoint(client):
    r = client.get("/api/market")
    assert r.status_code == 200
    assert "SIMULATED MARKET" in r.json()["disclaimer"]
