from compute_market_os.simulation.outage_engine import OutageEngine


def test_trigger_and_resolve_outage():
    engine = OutageEngine()
    event = engine.trigger("dc-1", "gpu_failure", capacity_removed=16, hardware_id="hw-h100-sxm")
    assert event.status == "active"
    assert engine.total_capacity_offline("dc-1", "hw-h100-sxm") == 16

    resolved = engine.resolve(event.id)
    assert resolved.status == "resolved"
    assert engine.total_capacity_offline("dc-1", "hw-h100-sxm") == 0


def test_active_outages_filtered_by_datacenter():
    engine = OutageEngine()
    engine.trigger("dc-1", "power_event", capacity_removed=100)
    engine.trigger("dc-2", "network_outage", capacity_removed=50)
    assert len(engine.active_outages("dc-1")) == 1
    assert len(engine.active_outages()) == 2


def test_resolve_unknown_outage_returns_none():
    engine = OutageEngine()
    assert engine.resolve("does-not-exist") is None
