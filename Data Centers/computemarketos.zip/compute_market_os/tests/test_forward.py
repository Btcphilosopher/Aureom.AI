import datetime as dt

import pytest

from compute_market_os.market.forward_market import ForwardMarket


def test_create_and_deliver_contract():
    market = ForwardMarket()
    start = dt.datetime(2026, 10, 1, tzinfo=dt.timezone.utc)
    end = dt.datetime(2026, 12, 31, tzinfo=dt.timezone.utc)
    contract = market.create_contract(
        hardware_id="hw-h100-sxm", region="TPE", gpu_hours=10_000, strike_price_per_hour=2.00,
        delivery_start=start, delivery_end=end,
    )
    assert contract.status == "pending"
    market.deliver(contract.id, 4_000)
    assert market.get(contract.id).status == "active"
    assert market.get(contract.id).remaining_gpu_hours == 6_000

    market.deliver(contract.id, 6_000)
    assert market.get(contract.id).status == "completed"


def test_delivery_cannot_exceed_contract():
    market = ForwardMarket()
    contract = market.create_contract(
        "hw-h100-sxm", "TPE", 100, 2.0, dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1)
    )
    with pytest.raises(ValueError):
        market.deliver(contract.id, 200)


def test_settlement_reports_shortfall():
    market = ForwardMarket()
    contract = market.create_contract(
        "hw-h100-sxm", "TPE", 1000, 2.0, dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1)
    )
    market.deliver(contract.id, 400)
    summary = market.settle(contract.id, market_price_per_hour=2.5)
    assert summary["gpu_hours_delivered"] == 400
    assert summary["delivery_shortfall_gpu_hours"] == 600
    assert summary["amount_due"] == 800  # 400 * 2.0
    assert summary["price_variance_per_hour"] == 0.5


def test_open_interest_excludes_completed_contracts():
    market = ForwardMarket()
    c1 = market.create_contract("hw-h100-sxm", "TPE", 100, 2.0, dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1))
    c2 = market.create_contract("hw-h100-sxm", "TPE", 200, 2.0, dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1))
    market.deliver(c1.id, 100)  # completes
    assert market.open_interest_gpu_hours("hw-h100-sxm", "TPE") == 200
