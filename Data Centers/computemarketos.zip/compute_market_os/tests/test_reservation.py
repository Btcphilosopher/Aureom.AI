import datetime as dt

from compute_market_os.domain.datacenter import DataCenter, PowerConstraint
from compute_market_os.market.reservation_market import ReservationMarket


def test_reservation_premium_decreases_with_duration():
    market = ReservationMarket()
    short = market.premium_fraction(duration_hours=24)
    long = market.premium_fraction(duration_hours=24 * 90)
    assert long < short


def test_reserve_computes_total_price_and_cost():
    market = ReservationMarket()
    start = dt.datetime(2026, 9, 1, tzinfo=dt.timezone.utc)
    end = start + dt.timedelta(hours=24)
    reservation = market.reserve(
        provider_id="prov-1",
        datacenter_id="dc-1",
        hardware_id="hw-h100-sxm",
        quantity=10,
        start_time=start,
        end_time=end,
        spot_price_per_hour=2.00,
    )
    assert reservation.duration_hours == 24
    assert reservation.total_price_per_hour == round(2.00 * (1 + reservation.premium_fraction), 6)
    assert reservation.total_cost == round(reservation.total_price_per_hour * 10 * 24, 2)


def test_cancel_reservation():
    market = ReservationMarket()
    start = dt.datetime(2026, 9, 1, tzinfo=dt.timezone.utc)
    end = start + dt.timedelta(hours=24)
    reservation = market.reserve("prov-1", "dc-1", "hw-h100-sxm", 10, start, end, spot_price_per_hour=2.0)
    assert market.cancel(reservation.id) is True
    assert market.get(reservation.id).status == "cancelled"
    assert market.cancel(reservation.id) is False


def test_power_constraint_blocks_oversized_reservation():
    dc = DataCenter(
        id="dc-1", provider_id="prov-1", code="TW-01", region="TPE", location="x",
        latitude=0.0, longitude=0.0, power_capacity_mw=1.0, it_load_mw=0.9,
        cooling_capacity_mw=0.5, network_capacity_tbps=10, pue=1.3,
    )
    result = PowerConstraint().check(dc, additional_units=1000, unit_power_watts=700)
    assert result.allowed is False
    assert "exceeds available power" in result.reason


def test_power_constraint_allows_within_headroom():
    dc = DataCenter(
        id="dc-1", provider_id="prov-1", code="TW-01", region="TPE", location="x",
        latitude=0.0, longitude=0.0, power_capacity_mw=10.0, it_load_mw=1.0,
        cooling_capacity_mw=5, network_capacity_tbps=10, pue=1.3,
    )
    result = PowerConstraint().check(dc, additional_units=10, unit_power_watts=700)
    assert result.allowed is True
