import datetime as dt

from compute_market_os.core.enums import OrderSide, OrderType
from compute_market_os.market.order import Order
from compute_market_os.market.orderbook import OrderBook


def make_order(side, price, qty, hardware_id="hw-h100-sxm", region="TPE", duration=24.0, **kwargs):
    return Order(
        side=OrderSide(side),
        hardware_id=hardware_id,
        region=region,
        quantity=qty,
        duration_hours=duration,
        limit_price=price,
        **kwargs,
    )


def test_best_bid_ask_and_spread():
    book = OrderBook("hw-h100-sxm", "TPE")
    book.add(make_order("BUY", 2.00, 10))
    book.add(make_order("BUY", 2.10, 5))
    book.add(make_order("SELL", 2.30, 8))
    book.add(make_order("SELL", 2.25, 4))

    assert book.best_bid() == 2.10
    assert book.best_ask() == 2.25
    assert book.spread() == round(2.25 - 2.10, 6)
    assert book.mid_price() == round((2.10 + 2.25) / 2, 6)


def test_depth_and_liquidity():
    book = OrderBook("hw-h100-sxm", "TPE")
    book.add(make_order("BUY", 2.00, 10))
    book.add(make_order("SELL", 2.30, 8))
    assert book.depth() == 18
    assert book.liquidity() == round(2.00 * 10 + 2.30 * 8, 2)


def test_cancel_removes_order_from_book():
    book = OrderBook("hw-h100-sxm", "TPE")
    order = make_order("BUY", 2.00, 10)
    book.add(order)
    assert book.best_bid() == 2.00
    assert book.cancel(order.id) is True
    assert book.best_bid() is None
    assert book.cancel(order.id) is False  # already cancelled


def test_snapshot_respects_level_limit():
    book = OrderBook("hw-h100-sxm", "TPE")
    for i in range(5):
        book.add(make_order("BUY", 2.00 + i * 0.01, 1))
    snapshot = book.snapshot(levels=2)
    assert len(snapshot.bids) == 2
    assert snapshot.bids[0].price == 2.04  # highest bid first


def test_market_order_does_not_rest_on_price_levels():
    book = OrderBook("hw-h100-sxm", "TPE")
    market_buy = make_order("BUY", None, 10, order_type=OrderType.MARKET)
    book.add(market_buy)
    assert book.best_bid() is None
    assert book.active_market_orders(OrderSide.BUY) == [market_buy]


def test_book_rejects_mismatched_hardware_or_region():
    book = OrderBook("hw-h100-sxm", "TPE")
    wrong = make_order("BUY", 2.0, 5, hardware_id="hw-a100-80g")
    try:
        book.add(wrong)
        assert False, "expected ValueError"
    except ValueError:
        pass
