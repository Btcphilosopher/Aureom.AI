import datetime as dt

import numpy as np
import pytest

from compute_market_os.forecasting.capacity_forecast import CapacityForecastEngine
from compute_market_os.forecasting.price_forecast import PriceForecastEngine


def _synthetic_price_series(n=48, seed=1):
    rng = np.random.default_rng(seed)
    now = dt.datetime.now(dt.timezone.utc)
    prices = list(2.0 * np.exp(np.cumsum(rng.normal(0.0005, 0.01, n))))
    timestamps = [now - dt.timedelta(hours=n - i) for i in range(n)]
    return prices, timestamps


def test_price_forecast_widens_uncertainty_with_horizon():
    engine = PriceForecastEngine()
    prices, timestamps = _synthetic_price_series()
    points = engine.forecast(prices, timestamps)
    by_horizon = {p.horizon: p for p in points}
    width_1h = by_horizon["1h"].upper_bound - by_horizon["1h"].lower_bound
    width_30d = by_horizon["30d"].upper_bound - by_horizon["30d"].lower_bound
    assert width_30d > width_1h


def test_price_forecast_requires_minimum_observations():
    engine = PriceForecastEngine()
    with pytest.raises(ValueError):
        engine.forecast([1.0, 2.0], [dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc)])


def test_capacity_forecast_utilisation_bounded():
    engine = CapacityForecastEngine()
    now = dt.datetime.now(dt.timezone.utc)
    timestamps = [now - dt.timedelta(days=20 - i) for i in range(20)]
    demand = [1000 + i * 5 for i in range(20)]
    supply = [1500 for _ in range(20)]
    points = engine.forecast(demand, supply, timestamps, horizon_hours=[24, 24 * 7])
    for p in points:
        assert 0.0 <= p.forecast_utilisation <= 1.0


def test_capacity_forecast_reflects_known_reservations():
    engine = CapacityForecastEngine()
    now = dt.datetime.now(dt.timezone.utc)
    timestamps = [now - dt.timedelta(days=10 - i) for i in range(10)]
    demand = [500] * 10
    supply = [1000] * 10
    baseline = engine.forecast(demand, supply, timestamps, horizon_hours=[24])[0]
    boosted = engine.forecast(
        demand, supply, timestamps, horizon_hours=[24], known_future_reservations={24: 400}
    )[0]
    assert boosted.forecast_demand > baseline.forecast_demand
