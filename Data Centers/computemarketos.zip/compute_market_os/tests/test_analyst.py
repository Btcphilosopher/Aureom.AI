import datetime as dt

from compute_market_os.analyst.market_analyst import ComputeMarketAnalyst
from compute_market_os.domain.inventory import InventorySnapshot
from compute_market_os.optimisation.buyer_optimizer import CapacityOffer
from compute_market_os.optimisation.equilibrium_engine import LinearCurve


def test_cheapest_available_region():
    analyst = ComputeMarketAnalyst()
    offers = [
        CapacityOffer("prov-A", "dc-A", "hw-h100-sxm", "TPE", 50, price_per_hour=2.5),
        CapacityOffer("prov-B", "dc-B", "hw-h100-sxm", "SIN", 50, price_per_hour=1.9),
    ]
    answer = analyst.cheapest_available_region(offers)
    assert "SIN" in answer.answer
    assert answer.evidence["region"] == "SIN"


def test_scarce_regions_from_inventory():
    analyst = ComputeMarketAnalyst()
    snapshots = [
        InventorySnapshot("dc-1", "hw-h100-sxm", installed=100, available=2, reserved=8, running=90, offline=0),
        InventorySnapshot("dc-2", "hw-h100-sxm", installed=100, available=60, reserved=20, running=20, offline=0),
    ]
    answer = analyst.scarce_regions(snapshots, utilisation_threshold=85)
    assert "dc-1" in answer.answer
    assert "dc-2" not in answer.answer


def test_demand_shock_impact_is_computed_not_hardcoded():
    analyst = ComputeMarketAnalyst()
    demand = LinearCurve(intercept=1000, slope=200)
    supply = LinearCurve(intercept=100, slope=150)
    answer = analyst.demand_shock_impact(demand, supply, pct_change=0.40)
    assert answer.evidence["shocked_price"] > answer.evidence["baseline_price"]


def test_why_did_price_move_reports_direction():
    analyst = ComputeMarketAnalyst()
    now = dt.datetime.now(dt.timezone.utc)
    prices = [(now - dt.timedelta(hours=1), 2.00), (now, 2.30)]
    answer = analyst.why_did_price_move(prices, [])
    assert "increased" in answer.answer
    assert answer.evidence["pct_change"] > 0
