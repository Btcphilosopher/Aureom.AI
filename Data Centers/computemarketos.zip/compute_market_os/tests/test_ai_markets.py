from compute_market_os.ai_markets.inference_market import InferenceMarket, InferenceOffer
from compute_market_os.ai_markets.training_market import TrainingMarket
from compute_market_os.domain.hardware import load_hardware_catalog


def test_inference_market_best_offer_within_constraints():
    market = InferenceMarket()
    market.publish_offer(
        InferenceOffer("prov-A", "llama-70b", "fp16", "hw-h100-sxm", "TPE", tokens_per_second=80, first_token_latency_ms=100, price_per_1m_input_tokens=1.0, price_per_1m_output_tokens=3.0)
    )
    market.publish_offer(
        InferenceOffer("prov-B", "llama-70b", "fp8", "hw-h100-sxm", "TPE", tokens_per_second=150, first_token_latency_ms=60, price_per_1m_input_tokens=0.8, price_per_1m_output_tokens=2.5)
    )
    best = market.best_offer("llama-70b", input_tokens=1000, output_tokens=500, max_latency_ms=10_000)
    assert best is not None
    assert best.offer.provider_id == "prov-B"  # cheaper offer


def test_inference_market_respects_latency_ceiling():
    market = InferenceMarket()
    market.publish_offer(
        InferenceOffer("prov-slow", "m", "fp16", "hw-h100-sxm", "TPE", tokens_per_second=5, first_token_latency_ms=2000, price_per_1m_input_tokens=0.1, price_per_1m_output_tokens=0.1)
    )
    best = market.best_offer("m", input_tokens=100, output_tokens=1000, max_latency_ms=100)
    assert best is None  # too slow to meet latency ceiling


def test_training_market_estimate_scales_with_gpu_count():
    catalog = load_hardware_catalog()
    hw = catalog["hw-h100-sxm"]
    market = TrainingMarket()
    small = market.estimate("demo", model_params_billion=7, tokens_billion=300, hardware=hw, gpu_count=8, price_per_gpu_hour=2.0)
    large = market.estimate("demo", model_params_billion=7, tokens_billion=300, hardware=hw, gpu_count=64, price_per_gpu_hour=2.0)
    assert large.estimated_training_hours < small.estimated_training_hours
    assert large.parallel_efficiency < small.parallel_efficiency
