from compute_market_os.simulation.market_simulator import ComputeMarketSimulation
from compute_market_os.simulation.shocks import MarketShock, MarketState, ShockType, apply_shock


def test_market_shock_ai_demand_spike_increases_demand_multiplier():
    state = MarketState()
    apply_shock(state, MarketShock(ShockType.AI_DEMAND_SPIKE, magnitude=0.40))
    assert state.demand_multiplier == 1.40


def test_market_shock_gpu_shortage_reduces_supply():
    state = MarketState()
    apply_shock(state, MarketShock(ShockType.GPU_SHORTAGE, magnitude=0.3))
    assert state.supply_multiplier == 0.7


def test_simulation_runs_and_produces_activity():
    sim = ComputeMarketSimulation(
        hardware_ids=["hw-h100-sxm", "hw-epyc-9654"], regions=["TPE", "SIN"], seed=1
    )
    sim.generate_participants(num_buyers=20, num_providers=10)
    result = sim.run(duration_hours=48)

    assert result.orders_submitted > 0
    assert isinstance(result.trade_count, int)
    assert not result.price_history.empty


def test_simulation_applies_scheduled_shock():
    sim = ComputeMarketSimulation(hardware_ids=["hw-h100-sxm"], regions=["TPE"], seed=2)
    sim.generate_participants(num_buyers=10, num_providers=5)
    sim.schedule_shock(MarketShock(ShockType.AI_DEMAND_SPIKE, magnitude=0.5, at_tick=5))
    result = sim.run(duration_hours=24)
    assert "ai_demand_spike" in result.shocks_applied
    assert sim.state.demand_multiplier == 1.5
