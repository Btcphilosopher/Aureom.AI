"""Property-based tests for the matching engine's core invariants
(section 69)."""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from compute_market_os.market.market import ComputeMarket

prices = st.floats(min_value=0.5, max_value=10.0, allow_nan=False, allow_infinity=False)
quantities = st.integers(min_value=1, max_value=200)


@given(
    buy_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
    sell_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
)
@settings(max_examples=60, deadline=None)
def test_never_matches_below_ask_or_above_bid(buy_orders, sell_orders):
    """No trade should ever execute at a price outside [best resting
    counterparty price, aggressor's limit] — concretely: every trade price
    must be between the two matched orders' limit prices (inclusive)."""
    market = ComputeMarket()
    for price, qty in buy_orders:
        market.submit_order(side="BUY", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4))
    for price, qty in sell_orders:
        market.submit_order(side="SELL", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4))

    trades = market.match()
    for t in trades:
        lo = min(t.buy_order.limit_price, t.sell_order.limit_price)
        hi = max(t.buy_order.limit_price, t.sell_order.limit_price)
        assert lo - 1e-9 <= t.price <= hi + 1e-9


@given(
    buy_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
    sell_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
)
@settings(max_examples=60, deadline=None)
def test_filled_quantity_never_exceeds_order_quantity(buy_orders, sell_orders):
    market = ComputeMarket()
    submitted = []
    for price, qty in buy_orders:
        submitted.append(market.submit_order(side="BUY", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4)))
    for price, qty in sell_orders:
        submitted.append(market.submit_order(side="SELL", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4)))

    market.match()
    for order in submitted:
        assert 0 <= order.filled_quantity <= order.quantity


@given(
    buy_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
    sell_orders=st.lists(st.tuples(prices, quantities), min_size=1, max_size=6),
)
@settings(max_examples=60, deadline=None)
def test_total_traded_quantity_conserved(buy_orders, sell_orders):
    """Every unit bought was sold: total buy-side fill == total sell-side
    fill == sum of trade quantities."""
    market = ComputeMarket()
    for price, qty in buy_orders:
        market.submit_order(side="BUY", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4))
    for price, qty in sell_orders:
        market.submit_order(side="SELL", hardware="H100 SXM", region="TPE", quantity=qty, duration_hours=24, limit_price=round(price, 4))

    trades = market.match()
    traded_qty = sum(t.quantity for t in trades)

    # Each order object may appear in multiple trades (partial fills); dedupe
    # by id before summing so every order's filled_quantity is counted once.
    unique_buy_orders = {t.buy_order.id: t.buy_order for t in trades}
    unique_sell_orders = {t.sell_order.id: t.sell_order for t in trades}
    buy_filled = sum(order.filled_quantity for order in unique_buy_orders.values())
    sell_filled = sum(order.filled_quantity for order in unique_sell_orders.values())

    assert traded_qty >= 0
    assert buy_filled == traded_qty
    assert sell_filled == traded_qty
    assert buy_filled <= sum(qty for _, qty in buy_orders)
    assert sell_filled <= sum(qty for _, qty in sell_orders)
