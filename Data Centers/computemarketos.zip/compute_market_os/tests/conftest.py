import os
import tempfile

# A single file-backed sqlite DB for the whole test session — set before any
# compute_market_os module is imported, since compute_market_os.core.database
# binds its engine/SessionLocal at import time. (Plain ":memory:" sqlite is
# deliberately avoided here: without StaticPool it hands each new connection
# a *fresh, empty* in-memory database, which breaks anything that opens more
# than one session against "the same" DB — exactly what the API layer does.)
_TEST_DB_PATH = os.path.join(tempfile.gettempdir(), "compute_market_os_test.db")
if os.path.exists(_TEST_DB_PATH):
    os.remove(_TEST_DB_PATH)
os.environ["DATABASE_URL"] = f"sqlite:///{_TEST_DB_PATH}"

import pytest

from compute_market_os.core.config import get_settings, reload_configs


@pytest.fixture(autouse=True, scope="session")
def _clear_config_cache():
    get_settings.cache_clear()
    reload_configs()
    yield
