import pytest

from compute_market_os.pricing.pricing_engine import PricingEngine


@pytest.fixture
def engine():
    return PricingEngine()


def test_price_components_sum_to_total(engine):
    breakdown = engine.compute_price("hw-h100-sxm", utilisation=0.7, electricity_price_per_kwh=0.15)
    cost_plus = (
        breakdown.hardware_cost_per_hour
        + breakdown.energy_cost_per_hour
        + breakdown.cooling_cost_per_hour
        + breakdown.network_cost_per_hour
        + breakdown.operations_cost_per_hour
        + breakdown.risk_premium_per_hour
        + breakdown.margin_per_hour
    )
    assert breakdown.cost_plus_price_per_hour == pytest.approx(cost_plus, rel=1e-6)
    assert breakdown.total_price_per_hour == pytest.approx(cost_plus * breakdown.scarcity_multiplier, rel=1e-6)


def test_higher_utilisation_increases_price(engine):
    low = engine.compute_price("hw-h100-sxm", utilisation=0.2, electricity_price_per_kwh=0.15)
    high = engine.compute_price("hw-h100-sxm", utilisation=0.95, electricity_price_per_kwh=0.15)
    assert high.total_price_per_hour > low.total_price_per_hour
    assert high.scarcity_multiplier > low.scarcity_multiplier


def test_scarcity_multiplier_bounded_by_config(engine):
    cfg = engine._dynamics_cfg["scarcity_curve"]
    assert engine.scarcity_multiplier(0.0) >= cfg["min_scarcity_multiplier"]
    assert engine.scarcity_multiplier(1.0) <= cfg["max_scarcity_multiplier"]


def test_unknown_hardware_raises(engine):
    with pytest.raises(KeyError):
        engine.compute_price("hw-does-not-exist", utilisation=0.5)


def test_reservation_price_includes_premium(engine):
    spot = engine.spot_price("hw-h100-sxm", utilisation=0.7, electricity_price_per_kwh=0.15)
    reservation = engine.reservation_price("hw-h100-sxm", utilisation=0.7, duration_hours=24, electricity_price_per_kwh=0.15)
    # short reservations pay close to the configured premium over spot
    assert reservation > spot * 0.95


def test_forward_price_grows_with_horizon(engine):
    near = engine.forward_price("hw-h100-sxm", utilisation=0.7, days_ahead=1, electricity_price_per_kwh=0.15)
    far = engine.forward_price("hw-h100-sxm", utilisation=0.7, days_ahead=180, electricity_price_per_kwh=0.15)
    assert far > near
