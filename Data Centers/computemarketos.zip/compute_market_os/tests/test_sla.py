import datetime as dt

from compute_market_os.ops.sla_engine import SLAEngine


def test_compliant_sla_has_no_credit():
    engine = SLAEngine()
    start = dt.datetime.now(dt.timezone.utc)
    end = start + dt.timedelta(days=30)
    assessment = engine.assess("STANDARD", start, end, uptime_actual=0.999, latency_actual_ms=30, period_charge=1000)
    assert assessment.compliant is True
    assert assessment.credit_amount == 0.0


def test_breach_generates_credit():
    engine = SLAEngine()
    start = dt.datetime.now(dt.timezone.utc)
    end = start + dt.timedelta(days=30)
    assessment = engine.assess("PREMIUM", start, end, uptime_actual=0.90, latency_actual_ms=200, period_charge=1000)
    assert assessment.compliant is False
    assert len(assessment.breach_reasons) == 2  # both uptime and latency breached
    assert assessment.credit_amount > 0


def test_unknown_tier_raises():
    import pytest

    engine = SLAEngine()
    with pytest.raises(KeyError):
        engine.tier_config("NOT_A_TIER")
