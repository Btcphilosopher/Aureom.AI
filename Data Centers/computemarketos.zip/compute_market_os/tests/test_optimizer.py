import pytest

from compute_market_os.domain.hardware import load_hardware_catalog
from compute_market_os.optimisation.buyer_optimizer import BuyerOptimizer, CapacityOffer
from compute_market_os.optimisation.cluster_optimizer import ClusterOptimizer
from compute_market_os.optimisation.elasticity_engine import ElasticityEngine
from compute_market_os.optimisation.equilibrium_engine import LinearCurve, MarketEquilibriumEngine
from compute_market_os.optimisation.network_latency_engine import NetworkLatencyEngine
from compute_market_os.optimisation.revenue_optimizer import MarketSegmentOffer, ProviderRevenueOptimizer


def test_buyer_optimizer_ranks_goals():
    offers = [
        CapacityOffer("prov-A", "dc-A", "hw-h100-sxm", "TPE", 100, price_per_hour=2.00, performance_score=50, latency_ms=20, carbon_kgco2e_per_hour=0.3, reliability=0.99),
        CapacityOffer("prov-B", "dc-B", "hw-h100-sxm", "TPE", 100, price_per_hour=2.50, performance_score=80, latency_ms=10, carbon_kgco2e_per_hour=0.1, reliability=0.999),
    ]
    optimizer = BuyerOptimizer()
    result = optimizer.find_compute(offers, quantity=32, duration_hours=24)
    assert result["BEST_PRICE"].offer.provider_id == "prov-A"
    assert result["BEST_PERFORMANCE"].offer.provider_id == "prov-B"
    assert result["LOWEST_CARBON"].offer.provider_id == "prov-B"
    assert result["BEST_LATENCY"].offer.provider_id == "prov-B"


def test_buyer_optimizer_filters_infeasible_offers():
    offers = [CapacityOffer("prov-A", "dc-A", "hw-h100-sxm", "TPE", 4, price_per_hour=2.00, performance_score=50)]
    optimizer = BuyerOptimizer()
    result = optimizer.find_compute(offers, quantity=100, duration_hours=24)  # not enough quantity available
    assert result == {}


def test_multi_source_allocation_covers_quantity():
    offers = [
        CapacityOffer("prov-A", "dc-A", "hw-h100-sxm", "TPE", 50, price_per_hour=2.00),
        CapacityOffer("prov-B", "dc-B", "hw-h100-sxm", "TPE", 60, price_per_hour=2.50),
    ]
    optimizer = BuyerOptimizer()
    allocation = optimizer.allocate_multi_source(offers, quantity=90, duration_hours=24)
    assert allocation.feasible is True
    assert allocation.total_units >= 90
    # cheapest source should be exhausted first
    a_alloc = next(a for a in allocation.allocation if a["provider_id"] == "prov-A")
    assert a_alloc["units"] == 50


def test_cluster_optimizer_efficiency_decreases_with_scale():
    catalog = load_hardware_catalog()
    hw = catalog["hw-h100-sxm"]
    optimizer = ClusterOptimizer()
    options = optimizer.compare(hw, total_training_pflop_s_days=50, price_per_gpu_hour=2.0)
    efficiencies = [o.parallel_efficiency for o in options]
    assert efficiencies == sorted(efficiencies, reverse=True)  # monotonically decreasing with GPU count


def test_network_latency_engine_route_and_within_budget():
    engine = NetworkLatencyEngine()
    route = engine.route("TPE", "SIN")
    assert route is not None
    assert route.latency_ms > 0
    within = engine.within_latency_budget("TPE", ["SIN", "IAD"], max_latency_ms=50)
    assert "SIN" in within


def test_equilibrium_engine_demand_shock_raises_price_and_quantity():
    engine = MarketEquilibriumEngine()
    demand = LinearCurve(intercept=1000, slope=200)
    supply = LinearCurve(intercept=100, slope=150)
    baseline = engine.solve(demand, supply)
    shocked_demand = engine.apply_demand_shock(demand, 0.40)
    shocked = engine.solve(shocked_demand, supply)
    assert shocked.price > baseline.price
    assert shocked.quantity > baseline.quantity


def test_elasticity_engine_requires_minimum_observations():
    engine = ElasticityEngine()
    with pytest.raises(ValueError):
        engine.price_elasticity_of_demand([1.0, 2.0], [10.0, 8.0])


def test_elasticity_engine_computes_from_real_data():
    engine = ElasticityEngine()
    prices = [1.0, 1.2, 1.5, 2.0, 2.5]
    quantities = [100, 90, 75, 55, 40]  # downward-sloping demand
    result = engine.price_elasticity_of_demand(prices, quantities)
    assert result.elasticity < 0  # demand falls as price rises
    assert result.n_observations == 5


def test_revenue_optimizer_respects_power_constraint():
    optimizer = ProviderRevenueOptimizer()
    segments = [
        MarketSegmentOffer("SPOT", price_per_hour=2.5),
        MarketSegmentOffer("RESERVED", price_per_hour=2.0),
    ]
    result = optimizer.optimise(segments, total_capacity_units=1000, unit_power_mw=0.0007, available_power_mw=0.5)
    assert result.feasible is True
    assert result.power_used_mw <= 0.5 + 1e-6
    assert result.capacity_used <= 1000
