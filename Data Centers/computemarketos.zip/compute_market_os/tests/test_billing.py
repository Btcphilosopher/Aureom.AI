import datetime as dt

import pytest

from compute_market_os.ops.billing import BillingEngine, LineItem
from compute_market_os.ops.settlement_engine import SettlementEngine
from compute_market_os.ops.usage_meter import UsageMeter


def test_invoice_totals():
    engine = BillingEngine()
    start = dt.datetime(2026, 9, 1, tzinfo=dt.timezone.utc)
    end = start + dt.timedelta(days=30)
    items = [
        LineItem("H100 GPU compute", "spot", quantity=720, unit_price=2.0),
        LineItem("Network egress", "pay_as_you_go", quantity=500, unit_price=0.02),
    ]
    invoice = engine.build_invoice("buyer-1", start, end, items, discount_fraction=0.1, tax_fraction=0.2)
    expected_subtotal = round(720 * 2.0 + 500 * 0.02, 2)
    expected_discount = round(expected_subtotal * 0.1, 2)
    expected_tax = round((expected_subtotal - expected_discount) * 0.2, 2)
    assert invoice.subtotal == expected_subtotal
    assert invoice.discount == expected_discount
    assert invoice.tax == expected_tax
    assert invoice.total == round(expected_subtotal - expected_discount + expected_tax, 2)


def test_invoice_rejects_unknown_billing_mode():
    engine = BillingEngine()
    items = [LineItem("bad", "not_a_mode", 1, 1)]
    with pytest.raises(ValueError):
        engine.build_invoice(None, dt.datetime.now(dt.timezone.utc), dt.datetime.now(dt.timezone.utc), items)


def test_settlement_engine_bills_recorded_usage():
    meter = UsageMeter()
    start = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=1)
    meter.record("buyer-1", "gpu_hours", quantity=24, unit_price=2.0, hardware_id="hw-h100-sxm")
    meter.record("buyer-1", "network_gb", quantity=100, unit_price=0.02)
    end = dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=1)

    settlement = SettlementEngine(meter)
    invoice = settlement.settle("buyer-1", start, end)
    assert invoice.subtotal == round(24 * 2.0 + 100 * 0.02, 2)
    assert invoice.total > 0


def test_settlement_applies_sla_credit():
    from compute_market_os.ops.sla_engine import SLAAssessment

    meter = UsageMeter()
    start = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=1)
    meter.record("buyer-1", "gpu_hours", quantity=100, unit_price=2.0)
    end = dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=1)

    assessment = SLAAssessment(
        tier="STANDARD", period_start=start, period_end=end, uptime_target=0.995, uptime_actual=0.98,
        latency_target_ms=50, latency_actual_ms=80, compliant=False, breach_reasons=["uptime"],
        credit_fraction=0.05, credit_amount=10.0,
    )
    settlement = SettlementEngine(meter)
    invoice = settlement.settle("buyer-1", start, end, sla_assessments=[assessment])
    assert invoice.credit == 10.0
    assert invoice.total == round(invoice.subtotal + invoice.tax - 10.0, 2)
