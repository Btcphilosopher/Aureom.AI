import datetime as dt
from types import SimpleNamespace

from compute_market_os.pricing.index import ComputePriceIndexEngine
from compute_market_os.pricing.vwap import calculate_vwap, vwap_by


def _trade(price, quantity, duration_hours=1.0, hardware_id="hw-h100-sxm", region="TPE", ts=None):
    return SimpleNamespace(
        price=price, quantity=quantity, duration_hours=duration_hours,
        hardware_id=hardware_id, region=region, seller_provider_id="prov-1",
        timestamp=ts or dt.datetime.now(dt.timezone.utc),
    )


def test_vwap_weights_by_volume():
    trades = [_trade(2.0, 100), _trade(4.0, 10)]
    vwap = calculate_vwap(trades)
    expected = (2.0 * 100 + 4.0 * 10) / (100 + 10)
    assert vwap == round(expected, 6)


def test_vwap_returns_none_for_no_trades():
    assert calculate_vwap([]) is None


def test_vwap_by_filters_by_hardware_and_region():
    trades = [_trade(2.0, 100, hardware_id="hw-h100-sxm", region="TPE"), _trade(9.0, 100, hardware_id="hw-a100-80g", region="SIN")]
    result = vwap_by(trades, hardware_id="hw-h100-sxm", region="TPE")
    assert result == 2.0


def test_compute_price_index_weighted_sum():
    engine = ComputePriceIndexEngine()
    result = engine.compute("CPI-TW", {"hw-h100-sxm": 2.0, "hw-a100-80g": 1.0, "hw-epyc-9654": 0.1})
    basket = engine.basket("CPI-TW")
    expected = sum(basket["weights"][k] * v for k, v in {"hw-h100-sxm": 2.0, "hw-a100-80g": 1.0, "hw-epyc-9654": 0.1}.items())
    assert result.value == round(expected, 6)
    assert "inference" in result.missing_components
    assert "storage" in result.missing_components
