from compute_market_os.market.market import ComputeMarket


def test_section_75_example_flow():
    market = ComputeMarket()
    market.submit_order(side="BUY", hardware="H100 SXM", region="Taiwan", quantity=32, duration_hours=24, limit_price=2.40)
    market.submit_order(side="SELL", hardware="H100 SXM", region="Taiwan", quantity=64, duration_hours=24, limit_price=2.20)

    trades = market.match()

    assert len(trades) == 1
    trade = trades[0]
    assert trade.quantity == 32
    assert trade.price == 2.40  # price-time priority: the earlier-submitted order (the buy) is the maker
    assert trade.hardware_id == "hw-h100-sxm"
    assert trade.region == "Taiwan"

    snapshot = market.orderbook_snapshot("H100 SXM", "Taiwan")
    assert snapshot.best_bid is None  # buy order fully filled
    assert snapshot.best_ask == 2.20
    assert snapshot.depth == 32  # 32 GPUs still unfilled on the ask side


def test_no_match_when_incompatible_region():
    market = ComputeMarket()
    market.submit_order(side="BUY", hardware="H100 SXM", region="Taiwan", quantity=8, duration_hours=24, limit_price=3.00)
    market.submit_order(side="SELL", hardware="H100 SXM", region="Singapore", quantity=8, duration_hours=24, limit_price=1.00)
    trades = market.match()
    assert trades == []


def test_no_match_when_buy_duration_exceeds_sell_availability():
    market = ComputeMarket()
    market.submit_order(side="BUY", hardware="H100 SXM", region="Taiwan", quantity=8, duration_hours=72, limit_price=3.00)
    market.submit_order(side="SELL", hardware="H100 SXM", region="Taiwan", quantity=8, duration_hours=24, limit_price=1.00)
    trades = market.match()
    assert trades == []  # sell only offers 24h, buyer needs 72h


def test_min_memory_requirement_blocks_incompatible_hardware():
    market = ComputeMarket()
    # A100 80GB has 80GB memory; request > 80GB should not match.
    market.submit_order(
        side="BUY", hardware="A100 80GB", region="Taiwan", quantity=4, duration_hours=24,
        limit_price=5.00, min_memory_gb=200,
    )
    market.submit_order(side="SELL", hardware="A100 80GB", region="Taiwan", quantity=4, duration_hours=24, limit_price=1.00)
    trades = market.match()
    assert trades == []


def test_market_order_takes_best_available_price():
    market = ComputeMarket()
    market.submit_order(side="SELL", hardware="H100 SXM", region="Taiwan", quantity=16, duration_hours=24, limit_price=2.00)
    market.submit_order(side="BUY", hardware="H100 SXM", region="Taiwan", quantity=8, duration_hours=24, order_type="market")
    trades = market.match()
    assert len(trades) == 1
    assert trades[0].price == 2.00
    assert trades[0].quantity == 8


def test_partial_fill_across_multiple_sell_orders():
    market = ComputeMarket()
    market.submit_order(side="SELL", hardware="H100 SXM", region="Taiwan", quantity=10, duration_hours=24, limit_price=2.00)
    market.submit_order(side="SELL", hardware="H100 SXM", region="Taiwan", quantity=10, duration_hours=24, limit_price=2.00)
    market.submit_order(side="BUY", hardware="H100 SXM", region="Taiwan", quantity=15, duration_hours=24, limit_price=2.00)
    trades = market.match()
    assert sum(t.quantity for t in trades) == 15
    assert len(trades) == 2  # filled from both resting sell orders, time priority
