import datetime as dt
from types import SimpleNamespace

from compute_market_os.core.enums import SurveillanceLevel
from compute_market_os.ops.surveillance import MarketSurveillanceEngine


def test_rapid_cancellation_flagged():
    engine = MarketSurveillanceEngine()
    now = dt.datetime.now(dt.timezone.utc)
    times = [now + dt.timedelta(seconds=i) for i in range(10)]
    flag = engine.check_rapid_cancellations("actor-1", times)
    assert flag is not None
    assert flag.level == SurveillanceLevel.WATCH


def test_no_flag_for_sparse_cancellations():
    engine = MarketSurveillanceEngine()
    now = dt.datetime.now(dt.timezone.utc)
    times = [now, now + dt.timedelta(minutes=5), now + dt.timedelta(minutes=10)]
    assert engine.check_rapid_cancellations("actor-1", times) is None


def test_wash_trading_flag_when_actor_is_both_sides():
    engine = MarketSurveillanceEngine()
    trades = [
        SimpleNamespace(buyer_id="actor-x", seller_provider_id="actor-x", timestamp=dt.datetime.now(dt.timezone.utc))
        for _ in range(6)
    ]
    flag = engine.check_wash_trading(trades)
    assert flag is not None
    assert flag.level == SurveillanceLevel.CRITICAL


def test_abnormal_price_move_detected():
    engine = MarketSurveillanceEngine()
    now = dt.datetime.now(dt.timezone.utc)
    history = [(now - dt.timedelta(minutes=4), 2.00), (now, 2.60)]  # +30% within window
    flag = engine.check_abnormal_price_move(history)
    assert flag is not None


def test_capacity_double_booking_detected():
    engine = MarketSurveillanceEngine()
    now = dt.datetime.now(dt.timezone.utc)
    reservations = [
        SimpleNamespace(datacenter_id="dc-1", hardware_id="hw-h100-sxm", status="active", quantity=60, start_time=now, end_time=now + dt.timedelta(hours=10)),
        SimpleNamespace(datacenter_id="dc-1", hardware_id="hw-h100-sxm", status="active", quantity=60, start_time=now, end_time=now + dt.timedelta(hours=10)),
    ]
    flag = engine.check_capacity_double_booking(reservations, installed_capacity=100, datacenter_id="dc-1", hardware_id="hw-h100-sxm")
    assert flag is not None
    assert flag.level == SurveillanceLevel.CRITICAL


def test_summarise_returns_highest_level():
    engine = MarketSurveillanceEngine()
    from compute_market_os.ops.surveillance import SurveillanceFlag

    flags = [
        SurveillanceFlag(SurveillanceLevel.WATCH, "r1", {}),
        SurveillanceFlag(SurveillanceLevel.CRITICAL, "r2", {}),
    ]
    assert engine.summarise(flags) == SurveillanceLevel.CRITICAL
    assert engine.summarise([]) == SurveillanceLevel.NORMAL
