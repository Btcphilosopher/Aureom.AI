# SilicaFlux ThermalStack — Physics Formulation, Assumptions & Limitations

## 1. Governing Equations & Numerical Discretisation
SilicaFlux ThermalStack solves the three-dimensional transient and steady-state anisotropic heat conduction equation over a heterogeneous, layered finite-volume mesh:

$$\rho(\mathbf{x}) c_p(\mathbf{x}) \frac{\partial T}{\partial t} = \nabla \cdot (\mathbf{K}(\mathbf{x}, T) \nabla T) + q(\mathbf{x}, T)$$

- **Coordinate System:** $X$ = package width (mm), $Y$ = package depth (mm), $Z$ = vertical stack height (mm).
- **Convention:** The Logic Base Die is modeled explicitly as a separate active buffer/PHY silicon layer (`kind = 'base_die'`, `dramDieIndex = null`) and is **never** counted inside the 8, 12, or 16 DRAM dies.
- **Conservative Interface Fluxes:** Across any two adjacent control volumes $(L, R)$ sharing area $A$ with optional interfacial contact thermal resistance $R_{\text{contact}}''$ ($\text{m}^2\cdot\text{K/W}$):

$$G_{\text{face}} = \frac{A}{\frac{\Delta n_L}{2 k_L} + R_{\text{contact}}'' + \frac{\Delta n_R}{2 k_R}}$$

  Internal face fluxes are strictly equal-and-opposite, guaranteeing global energy conservation ($P_{\text{gen}} = Q_{\text{rejected}} + dE/dt$).
- **Linear Solvers:** SSOR-Preconditioned Conjugate Gradient (`SSOR-PCG`) for symmetric positive-definite diagonal tensor systems, and Jacobi-Preconditioned `BiCGSTAB` when off-diagonal tensor cross-terms are active.
- **Transient Integration:** Implicit Backward Euler or Crank–Nicolson with volumetric heat capacity $\rho c_p V$.

## 2. TSV Thermal Modelling
- **Mode A (Homogenised TSV Region):** Uses parallel thermal resistance along $Z$ ($k_{zz,\text{eff}} = f_{\text{Cu}} k_{\text{Cu}} + f_{\text{liner}} k_{\text{liner}} + f_{\text{Si}} k_{\text{Si}}$) and 2D concentric-cylinder Maxwell–Eucken effective medium transverse conductivity ($k_{xx,\text{eff}}, k_{yy,\text{eff}}$) accounting for the $\text{SiO}_2$ liner barrier.
- **Mode B (Explicit Cutaway Model):** Resolves discrete Cu conductor cores and $\text{SiO}_2$ liner cells directly on local grid cells to cross-check homogenisation assumptions.

## 3. Literature Grounding & Modeling Boundaries
- Informed by *Electronics* 2025 (14(13):2682) on hybrid bonding vs NCF interfaces, *JSTS* 2025 (25(2):142) on 8H/12H/16H stack dissipation scaling, *Microelectronics Reliability* 2026 (116286) on selective high-$k$ NCF thermal management, and *IEEE IEDM* 2025 on 3D HBM-on-GPU/accelerator thermal bottlenecks.
- All default package dimensions and per-die power maps are documented **illustrative engineering profiles** unless supplied by vendor CAD/JEDEC data or SilicaFlux PowerGrid.

## 4. Known Limitations & Decoupled Extensions
1. **Fluid Mechanics:** Cooling modes (`forced_air`, `cold_plate`, `liquid_microchannel`, `dual_sided`) use physically justified convective heat transfer coefficients $h$ ($\text{W/m}^2\text{K}$) rather than solving 3D Navier–Stokes conjugate heat transfer.
2. **Fault & Delamination Scenarios:** Edge-void and partial-delamination cases apply explicitly flagged assumed contact-resistance multipliers.
3. **Electrothermal Feedback:** Optional temperature-dependent leakage/throttling uses an illustrative linear coupling model; a thermal solver alone does not predict electrical circuit timing or DRAM retention.
4. **Thermo-Mechanical Reliability:** Thermal gradients and die-to-die $\Delta T$ are screening indicators only. Die warpage, Cu protrusion, crack initiation, and electromigration lifetime require coupling the exported 3D $T(x,y,z)$ field into a structural FEA / reliability solver.

## 5. SilicaFlux-HPC Integration Roadmap
Structured JSON/CSV/HDF5-compatible interfaces are prepared for future coupling with:
- **SilicaFlux PowerGrid:** Spatially resolved 2D/3D power density maps per die.
- **SilicaFlux BandwidthLab / MemoryCore / DataFabric:** Workload traffic traces mapped via calibrated energy-per-bit models to time-dependent `timeTrace` inputs.
- **SilicaFlux FloorplanLab:** Package and co-packaged accelerator die coordinates.
