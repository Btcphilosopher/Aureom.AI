import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import {
  compareCoolingStrategies,
  compareStackHeights,
  runParameterSweep,
  runParetoOptimisation,
  runSimulation,
  runUncertaintyStudy,
  SweepParameterKey,
} from './simulation/analysis';
import {
  benchmarkMeshResolutions,
  compareTsvExplicitVsHomogenized,
  EXPERIMENTS_CATALOG,
  generateMarkdownEngineeringReport,
} from './simulation/experiments';
import {
  buildPackageGeometry,
  createPresetConfig,
  validateSimulationConfig,
} from './simulation/geometry';
import {
  MATERIALS_DATABASE,
  MATERIALS_DATABASE_VERSION,
  validateConductivityTensor,
} from './simulation/materials';
import { generateStructuredMesh3D } from './simulation/mesh3d';
import { SimulationConfig, SimulationResult, StackPresetId } from './simulation/types';
import { runAllValidationTests } from './simulation/validation';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '4mb' }));

const angularApp = new AngularNodeAppEngine();

interface JobRecord {
  jobId: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  studyType: 'steady_state' | 'transient';
  createdAtIso: string;
  completedAtIso?: string;
  cancelled: boolean;
  error?: string;
  result?: SimulationResult;
}

const JOB_STORE = new Map<string, JobRecord>();
const MAX_STORED_JOBS = 40;

function trimJobStore(): void {
  if (JOB_STORE.size <= MAX_STORED_JOBS) return;
  const oldestKey = JOB_STORE.keys().next().value;
  if (oldestKey) JOB_STORE.delete(oldestKey);
}

// 1. Health & Capabilities
app.get('/api/health', (_req, res) => {
  res.json({
    service: 'SilicaFlux ThermalStack Engine',
    materialsVersion: MATERIALS_DATABASE_VERSION,
    status: 'ready',
  });
});

// 2. Materials Database & Validation
app.get('/api/materials', (_req, res) => {
  res.json({
    version: MATERIALS_DATABASE_VERSION,
    materials: MATERIALS_DATABASE,
  });
});

app.post('/api/materials/validate', (req, res) => {
  try {
    const { conductivity, densityKgM3, specificHeatJKgK, name } = req.body ?? {};
    if (
      typeof densityKgM3 !== 'number' ||
      densityKgM3 <= 0 ||
      typeof specificHeatJKgK !== 'number' ||
      specificHeatJKgK <= 0
    ) {
      throw new Error('Density and specific heat capacity must be strictly positive numbers.');
    }
    validateConductivityTensor(conductivity, name ?? 'custom_material');
    res.json({ valid: true, message: 'Material tensor is symmetric positive-definite and physically admissible.' });
  } catch (err) {
    res.status(400).json({
      valid: false,
      error: err instanceof Error ? err.message : 'Invalid material parameters.',
    });
  }
});

// 3. Presets & Experiments Catalog
app.get('/api/presets', (_req, res) => {
  const presets: Record<StackPresetId, SimulationConfig> = {
    'HBM-8H': createPresetConfig('HBM-8H'),
    'HBM-12H': createPresetConfig('HBM-12H'),
    'HBM-16H': createPresetConfig('HBM-16H'),
  };
  const experiments = EXPERIMENTS_CATALOG.map((exp) => ({
    id: exp.id,
    code: exp.code,
    title: exp.title,
    question: exp.question,
    reproductionCommand: exp.reproductionCommand,
    limitations: exp.limitations,
    config: exp.buildConfig(),
  }));
  res.json({ presets, experiments });
});

// 4. Geometry Build
app.post('/api/geometry/build', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    const geometry = buildPackageGeometry(config);
    res.json({ valid: true, geometry });
  } catch (err) {
    res.status(400).json({
      valid: false,
      error: err instanceof Error ? err.message : 'Geometry validation failed.',
    });
  }
});

// 5. Mesh Generation
app.post('/api/mesh/generate', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    const geometry = buildPackageGeometry(config);
    const mesh = generateStructuredMesh3D(config, geometry);
    res.json({
      valid: true,
      geometry,
      stats: mesh.stats,
      xCentersMm: Array.from(mesh.xCenters, (v) => v * 1e3),
      yCentersMm: Array.from(mesh.yCenters, (v) => v * 1e3),
      zCentersMm: Array.from(mesh.zCenters, (v) => v * 1e3),
    });
  } catch (err) {
    res.status(400).json({
      valid: false,
      error: err instanceof Error ? err.message : 'Mesh generation failed.',
    });
  }
});

// 6. Submit Steady-State or Transient Simulation (Background Worker Job)
function submitSimulationJob(
  config: SimulationConfig,
  studyType: 'steady_state' | 'transient',
): JobRecord {
  const safeCfg: SimulationConfig = {
    ...config,
    solver: { ...config.solver, studyType },
  };
  validateSimulationConfig(safeCfg);

  const jobId = `sf-${studyType === 'transient' ? 'tr' : 'ss'}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  const record: JobRecord = {
    jobId,
    status: 'queued',
    studyType,
    createdAtIso: new Date().toISOString(),
    cancelled: false,
  };
  JOB_STORE.set(jobId, record);
  trimJobStore();

  // Execute asynchronously off the request thread via setImmediate
  setImmediate(() => {
    if (record.cancelled) {
      record.status = 'cancelled';
      return;
    }
    record.status = 'running';
    try {
      const result = runSimulation(jobId, safeCfg, () => record.cancelled);
      if (record.cancelled) {
        record.status = 'cancelled';
        return;
      }
      record.result = result;
      record.status = 'completed';
      record.completedAtIso = new Date().toISOString();
    } catch (err) {
      record.status = record.cancelled ? 'cancelled' : 'failed';
      record.error = err instanceof Error ? err.message : 'Numerical solver failed.';
      record.completedAtIso = new Date().toISOString();
    }
  });

  return record;
}

app.post('/api/simulations/steady', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    const record = submitSimulationJob(config, 'steady_state');
    res.status(202).json({
      jobId: record.jobId,
      status: record.status,
      studyType: record.studyType,
    });
  } catch (err) {
    res.status(400).json({
      error: err instanceof Error ? err.message : 'Invalid steady-state simulation configuration.',
    });
  }
});

app.post('/api/simulations/transient', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    const record = submitSimulationJob(config, 'transient');
    res.status(202).json({
      jobId: record.jobId,
      status: record.status,
      studyType: record.studyType,
    });
  } catch (err) {
    res.status(400).json({
      error: err instanceof Error ? err.message : 'Invalid transient simulation configuration.',
    });
  }
});

app.get('/api/jobs/:id', (req, res) => {
  const job = JOB_STORE.get(req.params.id);
  if (!job) {
    res.status(404).json({ error: `Job "${req.params.id}" not found.` });
    return;
  }
  res.json({
    jobId: job.jobId,
    status: job.status,
    studyType: job.studyType,
    createdAtIso: job.createdAtIso,
    completedAtIso: job.completedAtIso,
    error: job.error,
    result: job.status === 'completed' ? job.result : undefined,
  });
});

app.post('/api/jobs/:id/cancel', (req, res) => {
  const job = JOB_STORE.get(req.params.id);
  if (!job) {
    res.status(404).json({ error: `Job "${req.params.id}" not found.` });
    return;
  }
  job.cancelled = true;
  if (job.status === 'queued') job.status = 'cancelled';
  res.json({ jobId: job.jobId, status: job.status });
});

app.get('/api/simulations/:id/layers', (req, res) => {
  const job = JOB_STORE.get(req.params.id);
  if (!job?.result) {
    res.status(404).json({ error: `Completed simulation "${req.params.id}" not found.` });
    return;
  }
  res.json({
    jobId: job.jobId,
    layers: job.result.layers,
    summary: job.result.summary,
  });
});

app.get('/api/simulations/:id/field', (req, res) => {
  const job = JOB_STORE.get(req.params.id);
  if (!job?.result) {
    res.status(404).json({ error: `Completed simulation "${req.params.id}" not found.` });
    return;
  }
  res.json({
    jobId: job.jobId,
    field3D: job.result.field3D,
    hotspot: job.result.hotspot,
  });
});

// 7. Comparisons, Sweeps, Optimisation, Uncertainty, TSV, Validation, Benchmarks, Reports
app.post('/api/compare/stack-heights', (req, res) => {
  try {
    const { config, totalPowerW, perDiePowerW } = req.body as {
      config: SimulationConfig;
      totalPowerW?: number;
      perDiePowerW?: number;
    };
    res.json(compareStackHeights(config, totalPowerW ?? 28.0, perDiePowerW ?? 2.2));
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Stack comparison failed.' });
  }
});

app.post('/api/compare/cooling', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    res.json({ strategies: compareCoolingStrategies(config) });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Cooling comparison failed.' });
  }
});

app.post('/api/sweep', (req, res) => {
  try {
    const { config, parameter, values } = req.body as {
      config: SimulationConfig;
      parameter: SweepParameterKey;
      values: number[];
    };
    if (!Array.isArray(values) || values.length === 0 || values.length > 25) {
      throw new Error('Sweep values array must contain between 1 and 25 numeric points.');
    }
    res.json({
      parameter,
      points: runParameterSweep(config, parameter, values),
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Parameter sweep failed.' });
  }
});

app.post('/api/optimize', (req, res) => {
  try {
    const { config, constraints } = req.body as {
      config: SimulationConfig;
      constraints?: { maxPackageHeightMm?: number; maxTsvFraction?: number; maxCoolingH?: number };
    };
    res.json(
      runParetoOptimisation(config, {
        maxPackageHeightMm: constraints?.maxPackageHeightMm ?? 3.5,
        maxTsvFraction: constraints?.maxTsvFraction ?? 0.2,
        maxCoolingH: constraints?.maxCoolingH ?? 12000,
      }),
    );
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Optimisation failed.' });
  }
});

app.post('/api/uncertainty', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    res.json(runUncertaintyStudy(config));
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Uncertainty analysis failed.' });
  }
});

app.post('/api/tsv/compare-explicit', (req, res) => {
  try {
    const config = req.body as SimulationConfig;
    res.json(compareTsvExplicitVsHomogenized(config));
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'TSV comparison failed.' });
  }
});

app.post('/api/validation/run', (_req, res) => {
  const outcomes = runAllValidationTests();
  const passedCount = outcomes.filter((o) => o.passed).length;
  res.json({
    totalTests: outcomes.length,
    passedCount,
    allPassed: passedCount === outcomes.length,
    outcomes,
  });
});

app.post('/api/benchmarks/run', (req, res) => {
  try {
    const config = (req.body as SimulationConfig) ?? createPresetConfig('HBM-12H');
    res.json({ benchmarks: benchmarkMeshResolutions(config) });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Benchmark failed.' });
  }
});

app.post('/api/report', (req, res) => {
  try {
    const { jobId, config } = req.body as { jobId?: string; config?: SimulationConfig };
    let result = jobId ? JOB_STORE.get(jobId)?.result : undefined;
    if (!result && config) {
      result = runSimulation(`rep-${Date.now().toString(36)}`, config);
    }
    if (!result) {
      res.status(404).json({ error: 'No completed simulation result available for report generation.' });
      return;
    }
    const markdown = generateMarkdownEngineeringReport(result);
    res.json({
      jobId: result.jobId,
      markdown,
      hdf5SchemaMetadata: {
        format: 'HDF5-compatible JSON/Dataset Schema v1.2',
        groups: ['/metadata', '/geometry/layers', '/mesh/edges', '/fields/temperature_K', '/fields/gradient_K_per_mm', '/diagnostics'],
        dimensions: [result.field3D.nz, result.field3D.ny, result.field3D.nx],
      },
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Report generation failed.' });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`SilicaFlux ThermalStack server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
