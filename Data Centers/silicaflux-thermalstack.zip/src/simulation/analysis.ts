import { RawFvmSolveOutput, solveSteadyStateFvm, solveTransientFvm } from './fvmSolver';
import { applyCoolingPreset, applySpreaderPreset, createPresetConfig } from './geometry';
import { getMaterialOrThrow } from './materials';
import {
  CoolingMode,
  HotspotReport,
  LayerThermalSummary,
  ResistanceContribution,
  SimulationConfig,
  SimulationResult,
  SpreaderPreset,
  StackPresetId,
} from './types';

export function buildSimulationResult(
  jobId: string,
  config: SimulationConfig,
  raw: RawFvmSolveOutput,
): SimulationResult {
  const { geometry, mesh, temperaturesK, diagnostics, transientSteps, timeConstantS } = raw;
  const { nx, ny, nz, nCells, xCenters, yCenters, zCenters, dx, dy, dz } = mesh;

  let peakTempK = -Infinity;
  let minTempK = Infinity;
  let sumTempVol = 0;
  let sumVol = 0;

  let peakDramTempK = -Infinity;
  let sumDramTemp = 0;
  let countDram = 0;
  let baseSum = 0;
  let baseCount = 0;
  let baseMax = -Infinity;
  let accelPeak: number | null = geometry.acceleratorBox ? -Infinity : null;

  let hotI = 0;
  let hotJ = 0;
  let hotK = 0;

  const gradMagKPerMm = new Array<number>(nCells).fill(0);
  let maxThroughPlaneGrad = 0;
  let maxInPlaneGrad = 0;
  let volAboveThreshM3 = 0;

  // Per-cell gradient & summary stats
  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const c = k * ny * nx + j * nx + i;
        const T = temperaturesK[c];
        const vol = dx[i] * dy[j] * dz[k];

        if (T > peakTempK) {
          peakTempK = T;
          hotI = i;
          hotJ = j;
          hotK = k;
        }
        if (T < minTempK) minTempK = T;
        sumTempVol += T * vol;
        sumVol += vol;

        if (T >= config.solver.hotspotThresholdK) {
          volAboveThreshM3 += vol;
        }

        const dIdx = mesh.cellDramDieIndex[c];
        if (dIdx >= 0) {
          if (T > peakDramTempK) peakDramTempK = T;
          sumDramTemp += T;
          countDram++;
        }
        if (mesh.cellRegionType[c] === 4) {
          baseSum += T;
          baseCount++;
          if (T > baseMax) baseMax = T;
        }
        if (mesh.cellRegionType[c] === 9 && accelPeak !== null && T > accelPeak) {
          accelPeak = T;
        }

        // Gradient in K/mm
        const iL = Math.max(0, i - 1);
        const iR = Math.min(nx - 1, i + 1);
        const dTdx =
          iR > iL
            ? (temperaturesK[k * ny * nx + j * nx + iR] -
                temperaturesK[k * ny * nx + j * nx + iL]) /
              ((xCenters[iR] - xCenters[iL]) * 1e3)
            : 0;
        const jL = Math.max(0, j - 1);
        const jR = Math.min(ny - 1, j + 1);
        const dTdy =
          jR > jL
            ? (temperaturesK[k * ny * nx + jR * nx + i] -
                temperaturesK[k * ny * nx + jL * nx + i]) /
              ((yCenters[jR] - yCenters[jL]) * 1e3)
            : 0;
        const kL = Math.max(0, k - 1);
        const kR = Math.min(nz - 1, k + 1);
        const dTdz =
          kR > kL
            ? (temperaturesK[kR * ny * nx + j * nx + i] -
                temperaturesK[kL * ny * nx + j * nx + i]) /
              ((zCenters[kR] - zCenters[kL]) * 1e3)
            : 0;

        const inPlaneG = Math.hypot(dTdx, dTdy);
        const throughPlaneG = Math.abs(dTdz);
        gradMagKPerMm[c] = Math.hypot(inPlaneG, throughPlaneG);
        if (inPlaneG > maxInPlaneGrad) maxInPlaneGrad = inPlaneG;
        if (throughPlaneG > maxThroughPlaneGrad) maxThroughPlaneGrad = throughPlaneG;
      }
    }
  }

  // Layer-by-layer thermal metrics
  const layerStats: LayerThermalSummary[] = geometry.layers.map((layer, lIdx) => {
    let minT = Infinity;
    let maxT = -Infinity;
    let sumT = 0;
    let count = 0;
    let powerW = 0;
    let maxInPlane = 0;
    let maxThrough = 0;

    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const c = k * ny * nx + j * nx + i;
          if (mesh.cellLayerIndex[c] !== lIdx) continue;
          // Exclude outer mold cells when reporting die/layer metrics
          if (mesh.cellRegionType[c] === 0 && layer.kind !== 'substrate') continue;
          const T = temperaturesK[c];
          if (T < minT) minT = T;
          if (T > maxT) maxT = T;
          sumT += T;
          count++;
          powerW += mesh.cellHeatSourceW[c];

          const iL = Math.max(0, i - 1);
          const iR = Math.min(nx - 1, i + 1);
          const dTdx =
            iR > iL
              ? (temperaturesK[k * ny * nx + j * nx + iR] -
                  temperaturesK[k * ny * nx + j * nx + iL]) /
                ((xCenters[iR] - xCenters[iL]) * 1e3)
              : 0;
          const jL = Math.max(0, j - 1);
          const jR = Math.min(ny - 1, j + 1);
          const dTdy =
            jR > jL
              ? (temperaturesK[k * ny * nx + jR * nx + i] -
                  temperaturesK[k * ny * nx + jL * nx + i]) /
                ((yCenters[jR] - yCenters[jL]) * 1e3)
              : 0;
          maxInPlane = Math.max(maxInPlane, Math.hypot(dTdx, dTdy));
          if (k > 0 && k < nz - 1) {
            const dTdz =
              (temperaturesK[(k + 1) * ny * nx + j * nx + i] -
                temperaturesK[(k - 1) * ny * nx + j * nx + i]) /
              ((zCenters[k + 1] - zCenters[k - 1]) * 1e3);
            maxThrough = Math.max(maxThrough, Math.abs(dTdz));
          }
        }
      }
    }

    const mat = getMaterialOrThrow(layer.materialId);
    return {
      layerId: layer.id,
      name: layer.name,
      kind: layer.kind,
      dramDieIndex: layer.dramDieIndex,
      zCenterUm: 0.5 * (layer.zMinM + layer.zMaxM) * 1e6,
      thicknessUm: layer.thicknessM * 1e6,
      materialName: mat.name,
      powerW,
      minTempK: count > 0 ? minT : minTempK,
      avgTempK: count > 0 ? sumT / count : minTempK,
      maxTempK: count > 0 ? maxT : minTempK,
      inPlaneGradientKPerMm: maxInPlane,
      throughPlaneGradientKPerMm: maxThrough,
    };
  });

  const dramLayers = layerStats.filter((l) => l.kind === 'dram_die');
  const topDram = dramLayers[dramLayers.length - 1];
  const botDram = dramLayers[0];
  const topToBottomDeltaK =
    topDram && botDram ? botDram.avgTempK - topDram.avgTempK : 0;
  const dramMaxAvgs = dramLayers.map((l) => l.avgTempK);
  const dieToDieDeltaK =
    dramMaxAvgs.length > 0
      ? Math.max(...dramMaxAvgs) - Math.min(...dramMaxAvgs)
      : 0;

  // Hotspot report
  const hotC = hotK * ny * nx + hotJ * nx + hotI;
  const hotZ = zCenters[hotK];
  let nearestIfaceName = 'Top Cooling Boundary';
  let nearestIfaceDistUm = Math.abs(geometry.totalHeightM - hotZ) * 1e6;
  for (const layer of geometry.layers) {
    const distTop = Math.abs(layer.zMaxM - hotZ) * 1e6;
    if (distTop < nearestIfaceDistUm) {
      nearestIfaceDistUm = distTop;
      nearestIfaceName = layer.interfaceAboveId ?? layer.name;
    }
  }

  const hotLayer = geometry.layers[mesh.cellLayerIndex[hotC]];
  const hotspot: HotspotReport = {
    positionMm: [xCenters[hotI] * 1e3, yCenters[hotJ] * 1e3, zCenters[hotK] * 1e3],
    cellIndices: [hotI, hotJ, hotK],
    associatedRegion:
      mesh.cellRegionType[hotC] === 9
        ? 'SilicaFlux-HPC Accelerator Die'
        : hotLayer.name,
    associatedDramDieIndex:
      mesh.cellDramDieIndex[hotC] >= 0 ? mesh.cellDramDieIndex[hotC] : null,
    peakTempK,
    peakTempC: peakTempK - 273.15,
    localGradientKPerMm: gradMagKPerMm[hotC],
    volumeAboveThresholdMm3: volAboveThreshM3 * 1e9,
    thresholdK: config.solver.hotspotThresholdK,
    distanceToCoolingMm: Math.abs(geometry.totalHeightM - hotZ) * 1e3,
    nearestInterfaceName: nearestIfaceName,
    nearestInterfaceDistanceUm: nearestIfaceDistUm,
  };

  // Thermal resistance breakdown from layer average delta-Ts along primary vertical heat path
  const totalP = Math.max(diagnostics.totalHeatGenW, 1e-9);
  const effectiveRthTotalKPerW = (peakTempK - config.cooling.tAmbientK) / totalP;
  const resistanceBreakdown = computeResistanceBreakdown(
    config,
    layerStats,
    diagnostics.boundaryHeatFluxW.top,
    peakTempK,
    effectiveRthTotalKPerW,
  );

  // Sample heat-flux vectors (q = -K grad T) on a clean stride for 3D quiver rendering
  const fluxVectorsSample: SimulationResult['field3D']['fluxVectorsSample'] = [];
  const strideX = Math.max(1, Math.floor(nx / 5));
  const strideY = Math.max(1, Math.floor(ny / 5));
  const strideZ = Math.max(1, Math.floor(nz / 6));
  for (let k = 1; k < nz - 1; k += strideZ) {
    for (let j = 1; j < ny - 1; j += strideY) {
      for (let i = 1; i < nx - 1; i += strideX) {
        const c = k * ny * nx + j * nx + i;
        const dTdx =
          (temperaturesK[k * ny * nx + j * nx + (i + 1)] -
            temperaturesK[k * ny * nx + j * nx + (i - 1)]) /
          (xCenters[i + 1] - xCenters[i - 1]);
        const dTdy =
          (temperaturesK[k * ny * nx + (j + 1) * nx + i] -
            temperaturesK[k * ny * nx + (j - 1) * nx + i]) /
          (yCenters[j + 1] - yCenters[j - 1]);
        const dTdz =
          (temperaturesK[(k + 1) * ny * nx + j * nx + i] -
            temperaturesK[(k - 1) * ny * nx + j * nx + i]) /
          (zCenters[k + 1] - zCenters[k - 1]);
        fluxVectorsSample.push({
          xMm: xCenters[i] * 1e3,
          yMm: yCenters[j] * 1e3,
          zMm: zCenters[k] * 1e3,
          qx: -mesh.cellKxx[c] * dTdx,
          qy: -mesh.cellKyy[c] * dTdy,
          qz: -mesh.cellKzz[c] * dTdz,
        });
      }
    }
  }

  let transientSection: SimulationResult['transient'];
  if (transientSteps && transientSteps.length > 0) {
    transientSection = {
      steps: transientSteps,
      estimatedTimeConstantS: timeConstantS ?? config.solver.totalTimeSeconds * 0.35,
      maxTempInIntervalK: Math.max(...transientSteps.map((s) => s.peakTempK)),
    };
  }

  // Transient heating rate & cycle amplitude for reliability screening
  let maxHeatingRate: number | null = null;
  let cycleAmp: number | null = null;
  if (transientSteps && transientSteps.length > 1) {
    maxHeatingRate = 0;
    const peaks = transientSteps.map((s) => s.peakTempK);
    cycleAmp = Math.max(...peaks) - Math.min(...peaks);
    for (let s = 1; s < transientSteps.length; s++) {
      const dtS = Math.max(transientSteps[s].timeS - transientSteps[s - 1].timeS, 1e-6);
      maxHeatingRate = Math.max(
        maxHeatingRate,
        Math.abs(transientSteps[s].peakTempK - transientSteps[s - 1].peakTempK) / dtS,
      );
    }
  }

  const disclaimers = [
    'Results are conditional on the configured geometry, anisotropic material database (v1.2.0-SF), contact thermal resistances, power map, and cooling boundary coefficients.',
    config.heatSources.electrothermalEnabled
      ? 'Electrothermal feedback uses an illustrative linear leakage/throttling model; calibrate against foundry silicon PDK/measured I-V curves for sign-off.'
      : 'Pure thermal conduction mode: electrical power inputs are prescribed rather than predicted from circuit simulation.',
    config.interfaces.some((i) => i.assumedFaultModel)
      ? 'One or more thermal interfaces use an assumed fault/delamination contact resistance model rather than physical metrology.'
      : 'Nominal contact resistances represent literature-derived effective area-specific values.',
  ];

  return {
    jobId,
    timestampIso: new Date().toISOString(),
    config,
    geometry,
    meshStats: mesh.stats,
    diagnostics,
    summary: {
      peakTempK,
      peakTempC: peakTempK - 273.15,
      minTempK,
      avgTempK: sumTempVol / Math.max(sumVol, 1e-18),
      peakDramTempK,
      avgDramTempK: countDram > 0 ? sumDramTemp / countDram : peakTempK,
      baseDieAvgTempK: baseCount > 0 ? baseSum / baseCount : peakTempK,
      baseDieMaxTempK: baseCount > 0 ? baseMax : peakTempK,
      topToBottomDeltaK,
      dieToDieDeltaK,
      acceleratorPeakTempK: accelPeak,
      effectiveRthTotalKPerW,
      maxThroughPlaneGradientKPerMm: maxThroughPlaneGrad,
      maxInPlaneGradientKPerMm: maxInPlaneGrad,
    },
    layers: layerStats,
    hotspot,
    resistanceBreakdown,
    reliabilityScreening: {
      throughPlaneGradKPerMm: maxThroughPlaneGrad,
      inPlaneGradKPerMm: maxInPlaneGrad,
      dieToDieDeltaK,
      transientHeatingRateKPerS: maxHeatingRate,
      cycleAmplitudeK: cycleAmp,
      disclaimer:
        'Temperature gradients and die-to-die deltas are thermal screening indicators only. They do NOT independently establish die warpage, crack initiation, copper protrusion, bond delamination, or electromigration lifetime without coupled thermo-mechanical FEA and electrical EM models.',
      structuralExtensionSchema: {
        requiredInputs: [
          '3D Temperature Field T(x,y,z) [K]',
          'Coefficients of Thermal Expansion (CTE) [ppm/K]',
          'Orthotropic Elastic Moduli E [GPa] & Poisson Ratios',
          'Interfacial Cohesive-Zone Adhesion Energy [J/m2]',
          'Process-Induced Residual Stress State [MPa]',
        ],
        expectedOutputs: [
          '3D Displacement Field u(x,y,z) [um]',
          'Von Mises & Principal Stress Fields [MPa]',
          'Package / Die Warpage Profile [um]',
          'Bonding Interface Normal & Shear Traction [MPa]',
        ],
        status: 'Schema interface defined; external coupled structural FEA solver decoupled from thermal baseline.',
      },
    },
    field3D: {
      nx,
      ny,
      nz,
      xCentersMm: Array.from(xCenters, (v) => v * 1e3),
      yCentersMm: Array.from(yCenters, (v) => v * 1e3),
      zCentersMm: Array.from(zCenters, (v) => v * 1e3),
      temperaturesK: Array.from(temperaturesK),
      gradMagKPerMm,
      fluxVectorsSample,
    },
    transient: transientSection,
    disclaimers,
  };
}

function computeResistanceBreakdown(
  config: SimulationConfig,
  layers: LayerThermalSummary[],
  _topHeatFluxW: number,
  peakTempK: number,
  totalEffectiveRth: number,
): ResistanceContribution[] {

  const dramSumDelta = layers
    .filter((l) => l.kind === 'dram_die')
    .reduce((acc, l) => acc + Math.max(0, l.maxTempK - l.minTempK) * 0.25, 0);
  const bondAvgT = layers.filter((l) => l.kind === 'bonding');
  const baseLayer = layers.find((l) => l.kind === 'base_die');
  const timLayer = layers.find((l) => l.kind === 'tim');
  const spreaderLayer = layers.find((l) => l.kind === 'heat_spreader');

  const topDram = layers.filter((l) => l.kind === 'dram_die').slice(-1)[0];
  const coolingDelta = spreaderLayer
    ? Math.max(0, spreaderLayer.avgTempK - config.cooling.tAmbientK)
    : 0;
  const spreaderDelta =
    spreaderLayer && timLayer
      ? Math.max(0, timLayer.avgTempK - spreaderLayer.avgTempK)
      : 0;
  const timDelta =
    timLayer && topDram ? Math.max(0, topDram.avgTempK - timLayer.avgTempK) : 0;
  const stackInternalDelta =
    baseLayer && topDram ? Math.max(0, baseLayer.avgTempK - topDram.avgTempK) : dramSumDelta;

  const bondFraction = bondAvgT.length > 0 ? 0.68 : 0.4;
  const bondingAndContactDelta = stackInternalDelta * bondFraction;
  const siliconAndTsvDelta = stackInternalDelta * (1 - bondFraction);
  const lateralSpreadingDelta = Math.max(
    0,
    peakTempK -
      config.cooling.tAmbientK -
      (coolingDelta + spreaderDelta + timDelta + bondingAndContactDelta + siliconAndTsvDelta),
  );

  const rawItems = [
    {
      component: 'DRAM Bonding Films & Contact Interfaces',
      deltaTK: bondingAndContactDelta,
      note: 'Vertical temperature drop across NCF/hybrid-bond layers and die-to-bond contact resistances.',
    },
    {
      component: 'Silicon Dies & TSV Effective Path',
      deltaTK: siliconAndTsvDelta,
      note: 'Conduction drop across thinned DRAM silicon and base logic die with TSV regions.',
    },
    {
      component: 'TIM1 & Die-to-Lid Interface',
      deltaTK: timDelta,
      note: 'Vertical resistance from top DRAM die through TIM1 bondline into heat spreader.',
    },
    {
      component: 'Heat Spreader (3D Spreading)',
      deltaTK: spreaderDelta,
      note: 'Effective spreading + conduction resistance through IHS lid.',
    },
    {
      component: 'Cooling Boundary (Convection / Cold Plate)',
      deltaTK: coolingDelta,
      note: 'Surface-to-ambient/coolant temperature rise (1 / (h_eff * A_eff)).',
    },
    {
      component: '3D Lateral Hotspot & Interposer Coupling',
      deltaTK: lateralSpreadingDelta,
      note: 'Non-1D lateral spreading around local hotspots and base/accelerator coupling.',
    },
  ];

  const sumD = Math.max(
    rawItems.reduce((a, b) => a + b.deltaTK, 0),
    1e-9,
  );
  return rawItems.map((item) => ({
    component: item.component,
    deltaTK: item.deltaTK,
    effectiveRKPerW: (item.deltaTK / sumD) * totalEffectiveRth,
    fractionPct: (item.deltaTK / sumD) * 100,
    note: item.note,
  }));
}

export function runSimulation(
  jobId: string,
  config: SimulationConfig,
  shouldCancel?: () => boolean,
): SimulationResult {
  const raw =
    config.solver.studyType === 'transient'
      ? solveTransientFvm(config, undefined, shouldCancel)
      : solveSteadyStateFvm(config, undefined, shouldCancel);
  return buildSimulationResult(jobId, config, raw);
}

export interface StackHeightComparisonOutput {
  modeAEqualTotalPower: {
    totalTargetPowerW: number;
    results: {
      preset: StackPresetId;
      dramCount: number;
      perDiePowerW: number;
      dramThickUm: number;
      totalStackHeightUm: number;
      peakTempC: number;
      avgDramTempC: number;
      baseDieTempC: number;
      dieToDieDeltaK: number;
      rthKPerW: number;
    }[];
  };
  modeBEqualPerDiePower: {
    perDiePowerW: number;
    results: {
      preset: StackPresetId;
      dramCount: number;
      totalStackPowerW: number;
      dramThickUm: number;
      totalStackHeightUm: number;
      peakTempC: number;
      avgDramTempC: number;
      baseDieTempC: number;
      dieToDieDeltaK: number;
      rthKPerW: number;
    }[];
  };
  note: string;
}

export function compareStackHeights(
  baseConfig: SimulationConfig,
  totalPowerW = 28.0,
  perDiePowerW = 2.2,
): StackHeightComparisonOutput {
  const presets: StackPresetId[] = ['HBM-8H', 'HBM-12H', 'HBM-16H'];
  const modeAResults = [];
  const modeBResults = [];

  for (const preset of presets) {
    const pCfg = createPresetConfig(preset);
    // Carry over user's cooling, bonding material, TSV, and interface settings so comparison is controlled
    pCfg.geometry.bondingMaterialId = baseConfig.geometry.bondingMaterialId;
    pCfg.geometry.timMaterialId = baseConfig.geometry.timMaterialId;
    pCfg.geometry.spreaderMaterialId = baseConfig.geometry.spreaderMaterialId;
    pCfg.geometry.spreaderThicknessUm = baseConfig.geometry.spreaderThicknessUm;
    pCfg.tsv = { ...baseConfig.tsv };
    pCfg.interfaces = baseConfig.interfaces.map((i) => ({ ...i }));
    pCfg.cooling = { ...baseConfig.cooling };
    pCfg.mesh = { ...baseConfig.mesh, nx: 10, ny: 10 };

    const dramCount = pCfg.geometry.dramDieCount;

    // Mode A: Equal total stack power (dram + base fixed)
    const baseP = baseConfig.heatSources.baseDiePowerW + baseConfig.heatSources.phyPowerW;
    const dramTotalBudget = Math.max(totalPowerW - baseP, 4.0);
    const modeAPerDie = dramTotalBudget / dramCount;
    const cfgA: SimulationConfig = {
      ...pCfg,
      heatSources: {
        ...baseConfig.heatSources,
        dramPowersW: Array.from({ length: dramCount }, () => modeAPerDie),
      },
    };
    const resA = runSimulation(`cmp-modeA-${preset}`, cfgA);
    modeAResults.push({
      preset,
      dramCount,
      perDiePowerW: modeAPerDie,
      dramThickUm: cfgA.geometry.dramDieThicknessUm,
      totalStackHeightUm: resA.geometry.totalHeightM * 1e6,
      peakTempC: resA.summary.peakTempC,
      avgDramTempC: resA.summary.avgDramTempK - 273.15,
      baseDieTempC: resA.summary.baseDieAvgTempK - 273.15,
      dieToDieDeltaK: resA.summary.dieToDieDeltaK,
      rthKPerW: resA.summary.effectiveRthTotalKPerW,
    });

    // Mode B: Equal power per DRAM die
    const cfgB: SimulationConfig = {
      ...pCfg,
      heatSources: {
        ...baseConfig.heatSources,
        dramPowersW: Array.from({ length: dramCount }, () => perDiePowerW),
      },
    };
    const resB = runSimulation(`cmp-modeB-${preset}`, cfgB);
    modeBResults.push({
      preset,
      dramCount,
      totalStackPowerW: dramCount * perDiePowerW + baseP,
      dramThickUm: cfgB.geometry.dramDieThicknessUm,
      totalStackHeightUm: resB.geometry.totalHeightM * 1e6,
      peakTempC: resB.summary.peakTempC,
      avgDramTempC: resB.summary.avgDramTempK - 273.15,
      baseDieTempC: resB.summary.baseDieAvgTempK - 273.15,
      dieToDieDeltaK: resB.summary.dieToDieDeltaK,
      rthKPerW: resB.summary.effectiveRthTotalKPerW,
    });
  }

  return {
    modeAEqualTotalPower: { totalTargetPowerW: totalPowerW, results: modeAResults },
    modeBEqualPerDiePower: { perDiePowerW, results: modeBResults },
    note: 'Die thickness and bonding-layer thickness scale with stack height (8H: 50/16 um, 12H: 36/12 um, 16H: 28/10 um) to respect package height envelopes; stack-height differences therefore combine die-count, interface-count, and thinning effects.',
  };
}

export function compareCoolingStrategies(baseConfig: SimulationConfig) {
  const modes: { mode: CoolingMode; spreader: SpreaderPreset; label: string }[] = [
    { mode: 'natural_convection', spreader: 'conventional_cu', label: 'Natural Convection (h=18)' },
    { mode: 'forced_air', spreader: 'conventional_cu', label: 'Forced Air + Cu Lid (h=450)' },
    { mode: 'cold_plate', spreader: 'conventional_cu', label: 'Cold Plate + Cu Lid (h=3500)' },
    { mode: 'cold_plate', spreader: 'diamond_cu_bridge', label: 'Cold Plate + Diamond-Cu Lid' },
    { mode: 'dual_sided', spreader: 'conventional_cu', label: 'Dual-Sided Cooling (Top 4500 / Bot 2200)' },
    { mode: 'liquid_microchannel', spreader: 'integrated_cold_plate', label: 'Microchannel Liquid (h=12000)' },
  ];

  return modes.map((entry, idx) => {
    const cfg: SimulationConfig = {
      ...baseConfig,
      geometry: applySpreaderPreset(baseConfig.geometry, entry.spreader),
      cooling: applyCoolingPreset(baseConfig.cooling, entry.mode),
      mesh: { ...baseConfig.mesh, nx: 10, ny: 10 },
    };
    const res = runSimulation(`cooling-cmp-${idx}`, cfg);
    return {
      label: entry.label,
      mode: entry.mode,
      spreader: entry.spreader,
      hTopWm2K: cfg.cooling.hTopWm2K,
      hBottomWm2K: cfg.cooling.hBottomWm2K,
      peakTempC: res.summary.peakTempC,
      avgDramTempC: res.summary.avgDramTempK - 273.15,
      baseDieTempC: res.summary.baseDieAvgTempK - 273.15,
      dieToDieDeltaK: res.summary.dieToDieDeltaK,
      effectiveRthKPerW: res.summary.effectiveRthTotalKPerW,
      topHeatRejectionPct:
        (res.diagnostics.boundaryHeatFluxW.top /
          Math.max(res.diagnostics.totalHeatRejectionW, 1e-9)) *
        100,
    };
  });
}

export type SweepParameterKey =
  | 'dram_die_count'
  | 'dram_die_thickness_um'
  | 'bonding_thickness_um'
  | 'bonding_k_wm_k'
  | 'contact_resistance_mm2kw'
  | 'tsv_cu_fraction'
  | 'base_die_power_w'
  | 'dram_per_die_power_w'
  | 'spreader_thickness_um'
  | 'tim_k_wm_k'
  | 'h_top_wm2k'
  | 't_ambient_c'
  | 'accelerator_power_w';

export function runParameterSweep(
  baseConfig: SimulationConfig,
  parameter: SweepParameterKey,
  values: number[],
) {
  return values.map((val, idx) => {
    const cfg: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
    cfg.mesh = { ...cfg.mesh, nx: 9, ny: 9 };

    switch (parameter) {
      case 'dram_die_count': {
        const count = (val === 8 || val === 12 || val === 16 ? val : 12) as 8 | 12 | 16;
        cfg.geometry.dramDieCount = count;
        cfg.geometry.stackPreset = count === 8 ? 'HBM-8H' : count === 12 ? 'HBM-12H' : 'HBM-16H';
        const pEach = cfg.heatSources.dramPowersW[0] ?? 2.2;
        cfg.heatSources.dramPowersW = Array.from({ length: count }, () => pEach);
        break;
      }
      case 'dram_die_thickness_um':
        cfg.geometry.dramDieThicknessUm = val;
        break;
      case 'bonding_thickness_um':
        cfg.geometry.bondingThicknessUm = val;
        break;
      case 'bonding_k_wm_k':
        // Temporarily map to high_k vs standard NCF or hybrid via layer override / material selection
        cfg.geometry.bondingMaterialId =
          val >= 10 ? 'hybrid_bond_effective' : val >= 1.2 ? 'ncf_high_k' : 'ncf_standard';
        break;
      case 'contact_resistance_mm2kw':
        for (const iface of cfg.interfaces) {
          if (iface.id === 'die_to_bond') iface.rContactAreaM2KW = val * 1e-6;
        }
        break;
      case 'tsv_cu_fraction':
        cfg.tsv.cuFraction = val;
        break;
      case 'base_die_power_w':
        cfg.heatSources.baseDiePowerW = val;
        break;
      case 'dram_per_die_power_w':
        cfg.heatSources.dramPowersW = cfg.heatSources.dramPowersW.map(() => val);
        break;
      case 'spreader_thickness_um':
        cfg.geometry.spreaderThicknessUm = val;
        break;
      case 'tim_k_wm_k':
        cfg.geometry.timMaterialId = val > 20 ? 'tim_indium_solder' : 'tim_polymer_gel';
        break;
      case 'h_top_wm2k':
        cfg.cooling.hTopWm2K = val;
        break;
      case 't_ambient_c':
        cfg.cooling.tAmbientK = val + 273.15;
        break;
      case 'accelerator_power_w':
        cfg.geometry.includeAccelerator = true;
        cfg.heatSources.acceleratorPowerW = val;
        break;
    }

    const res = runSimulation(`sweep-${parameter}-${idx}`, cfg);
    return {
      paramValue: val,
      peakTempC: res.summary.peakTempC,
      avgDramTempC: res.summary.avgDramTempK - 273.15,
      baseDieTempC: res.summary.baseDieAvgTempK - 273.15,
      dieToDieDeltaK: res.summary.dieToDieDeltaK,
      rthKPerW: res.summary.effectiveRthTotalKPerW,
    };
  });
}

export interface UncertaintyResult {
  samplesCount: number;
  meanPeakTempC: number;
  stdPeakTempC: number;
  p05PeakTempC: number;
  p95PeakTempC: number;
  sensitivities: {
    parameter: string;
    nominal: string;
    perturbation: string;
    deltaPeakTempK: number;
    normalizedSensitivity: number;
  }[];
  note: string;
}

export function runUncertaintyStudy(baseConfig: SimulationConfig): UncertaintyResult {
  const nominalRes = runSimulation('unc-nominal', {
    ...baseConfig,
    mesh: { ...baseConfig.mesh, nx: 9, ny: 9 },
  });
  const nomPeak = nominalRes.summary.peakTempK;

  // Deterministic +/-15% / +/-25% one-at-a-time sensitivity + reproducible quasi-Monte Carlo sample
  const factors: {
    name: string;
    nominalLabel: string;
    pertLabel: string;
    mutate: (c: SimulationConfig, sign: number) => void;
  }[] = [
    {
      name: 'Die-to-Bond Contact Resistance',
      nominalLabel: `${(baseConfig.interfaces[0].rContactAreaM2KW * 1e6).toFixed(1)} mm²·K/W`,
      pertLabel: '±35% assumed range',
      mutate: (c, s) => {
        c.interfaces[0].rContactAreaM2KW *= 1 + 0.35 * s;
      },
    },
    {
      name: 'Bonding Layer Thickness',
      nominalLabel: `${baseConfig.geometry.bondingThicknessUm} µm`,
      pertLabel: '±20% process tolerance',
      mutate: (c, s) => {
        c.geometry.bondingThicknessUm *= 1 + 0.2 * s;
      },
    },
    {
      name: 'Cooling Convection Coefficient (h_top)',
      nominalLabel: `${baseConfig.cooling.hTopWm2K} W/(m²·K)`,
      pertLabel: '±20% flow variation',
      mutate: (c, s) => {
        c.cooling.hTopWm2K *= 1 + 0.2 * s;
      },
    },
    {
      name: 'TSV Cu Volume Fraction',
      nominalLabel: `${(baseConfig.tsv.cuFraction * 100).toFixed(1)}%`,
      pertLabel: '±25% layout density',
      mutate: (c, s) => {
        c.tsv.cuFraction = Math.min(0.4, Math.max(0.01, c.tsv.cuFraction * (1 + 0.25 * s)));
      },
    },
    {
      name: 'Base & DRAM Power Uncertainty',
      nominalLabel: `${nominalRes.diagnostics.totalHeatGenW.toFixed(1)} W`,
      pertLabel: '±10% workload uncertainty',
      mutate: (c, s) => {
        c.heatSources.baseDiePowerW *= 1 + 0.1 * s;
        c.heatSources.dramPowersW = c.heatSources.dramPowersW.map((p) => p * (1 + 0.1 * s));
      },
    },
  ];

  const sensitivities = factors.map((f) => {
    const cfgPlus: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
    cfgPlus.mesh = { ...cfgPlus.mesh, nx: 9, ny: 9 };
    f.mutate(cfgPlus, 1);
    const resPlus = runSimulation(`sens-p-${f.name}`, cfgPlus);

    const cfgMinus: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
    cfgMinus.mesh = { ...cfgMinus.mesh, nx: 9, ny: 9 };
    f.mutate(cfgMinus, -1);
    const resMinus = runSimulation(`sens-m-${f.name}`, cfgMinus);

    const swing = Math.abs(resPlus.summary.peakTempK - resMinus.summary.peakTempK);
    return {
      parameter: f.name,
      nominal: f.nominalLabel,
      perturbation: f.pertLabel,
      deltaPeakTempK: swing,
      normalizedSensitivity: swing / Math.max(nomPeak - baseConfig.cooling.tAmbientK, 1),
    };
  });
  sensitivities.sort((a, b) => b.deltaPeakTempK - a.deltaPeakTempK);

  // Reproducible seeded LCG Monte Carlo (N = 24)
  let seed = 421337;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296 - 0.5;
  };
  const samples: number[] = [];
  for (let m = 0; m < 24; m++) {
    const cfg: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
    cfg.mesh = { ...cfg.mesh, nx: 8, ny: 8 };
    for (const f of factors) {
      f.mutate(cfg, rand() * 2);
    }
    const r = runSimulation(`mc-${m}`, cfg);
    samples.push(r.summary.peakTempC);
  }
  samples.sort((a, b) => a - b);
  const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
  const variance = samples.reduce((a, b) => a + (b - mean) ** 2, 0) / samples.length;

  return {
    samplesCount: samples.length,
    meanPeakTempC: mean,
    stdPeakTempC: Math.sqrt(variance),
    p05PeakTempC: samples[Math.floor(0.05 * samples.length)],
    p95PeakTempC: samples[Math.min(samples.length - 1, Math.floor(0.95 * samples.length))],
    sensitivities,
    note: 'Assumed parameter distributions used for sensitivity ranking; distinct from numerical discretization error.',
  };
}

export interface ParetoCandidate {
  id: string;
  label: string;
  bondingMaterialId: string;
  spreaderThicknessUm: number;
  tsvCuFraction: number;
  hTopWm2K: number;
  peakTempC: number;
  dieToDieDeltaK: number;
  packageThicknessMm: number;
  coolingPowerProxyW: number;
  isParetoOptimal: boolean;
}

export function runParetoOptimisation(
  baseConfig: SimulationConfig,
  constraints: { maxPackageHeightMm: number; maxTsvFraction: number; maxCoolingH: number },
): { candidates: ParetoCandidate[]; optimal: ParetoCandidate } {
  // Multi-objective design space search across bonding tech, TSV density, spreader thickness & cooling effort
  const bondingOpts = ['ncf_standard', 'ncf_high_k', 'hybrid_bond_effective'];
  const tsvOpts = [0.04, 0.08, Math.min(0.16, constraints.maxTsvFraction)];
  const spreaderThicks = [800, 1400, 2000];
  const coolingHs = [1200, 3500, Math.min(10000, constraints.maxCoolingH)];

  const rawList: ParetoCandidate[] = [];
  let idx = 0;

  for (const bond of bondingOpts) {
    for (const tsv of tsvOpts) {
      for (const spThick of spreaderThicks) {
        const hTop = coolingHs[idx % coolingHs.length];
        const cfg: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
        cfg.geometry.bondingMaterialId = bond;
        cfg.tsv.cuFraction = tsv;
        cfg.geometry.spreaderThicknessUm = spThick;
        cfg.cooling.hTopWm2K = hTop;
        cfg.mesh = { ...cfg.mesh, nx: 8, ny: 8 };

        const res = runSimulation(`opt-${idx}`, cfg);
        const totalHeightMm = res.geometry.totalHeightM * 1e3;
        if (totalHeightMm <= constraints.maxPackageHeightMm) {
          // Explicit pumping/fan power proxy model: P_cool ~ (h / 1000)^1.4 * 2.5 W
          const coolingPowerProxyW = Math.pow(hTop / 1000, 1.4) * 2.5;
          rawList.push({
            id: `cand-${idx}`,
            label: `${bond === 'hybrid_bond_effective' ? 'Hybrid' : bond === 'ncf_high_k' ? 'Hi-k NCF' : 'Std NCF'} · TSV ${(tsv * 100).toFixed(0)}% · IHS ${(spThick / 1000).toFixed(1)}mm · h=${hTop}`,
            bondingMaterialId: bond,
            spreaderThicknessUm: spThick,
            tsvCuFraction: tsv,
            hTopWm2K: hTop,
            peakTempC: res.summary.peakTempC,
            dieToDieDeltaK: res.summary.dieToDieDeltaK,
            packageThicknessMm: totalHeightMm,
            coolingPowerProxyW,
            isParetoOptimal: false,
          });
        }
        idx++;
      }
    }
  }

  // Compute non-dominated Pareto frontier minimizing (peakTempC, coolingPowerProxyW, packageThicknessMm)
  for (let i = 0; i < rawList.length; i++) {
    let dominated = false;
    for (let j = 0; j < rawList.length; j++) {
      if (i === j) continue;
      const a = rawList[j];
      const b = rawList[i];
      if (
        a.peakTempC <= b.peakTempC &&
        a.coolingPowerProxyW <= b.coolingPowerProxyW &&
        a.packageThicknessMm <= b.packageThicknessMm &&
        (a.peakTempC < b.peakTempC ||
          a.coolingPowerProxyW < b.coolingPowerProxyW ||
          a.packageThicknessMm < b.packageThicknessMm)
      ) {
        dominated = true;
        break;
      }
    }
    rawList[i].isParetoOptimal = !dominated;
  }

  const optimal =
    rawList
      .filter((c) => c.isParetoOptimal)
      .sort((a, b) => a.peakTempC - b.peakTempC)[0] ?? rawList[0];

  return { candidates: rawList, optimal };
}
