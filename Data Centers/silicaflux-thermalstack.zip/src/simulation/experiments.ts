import {
  buildSimulationResult,
  compareStackHeights,
  runSimulation,
} from './analysis';
import { solveSteadyStateFvm } from './fvmSolver';
import { applyCoolingPreset, createPresetConfig } from './geometry';
import { computeHomogenizedTsvProperties, getMaterialOrThrow } from './materials';
import { SimulationConfig, SimulationResult } from './types';

export interface ExperimentDescriptor {
  id: string;
  code: string;
  title: string;
  question: string;
  reproductionCommand: string;
  limitations: string;
  buildConfig: () => SimulationConfig;
}

export const EXPERIMENTS_CATALOG: ExperimentDescriptor[] = [
  {
    id: 'exp_a_8h_baseline',
    code: 'EXPERIMENT A',
    title: '8-High HBM Baseline',
    question: 'Baseline thermal gradient and peak DRAM temperature for an 8-high stack under cold-plate cooling.',
    reproductionCommand: 'POST /api/simulations/steady (preset: HBM-8H, experimentId: exp_a_8h_baseline)',
    limitations: 'Uses illustrative die dimensions (11x11 mm, 50 um DRAM) and uniform 2.2 W/die power.',
    buildConfig: () =>
      createPresetConfig('HBM-8H', {
        experimentId: 'exp_a_8h_baseline',
        description: 'Experiment A: 8-High HBM baseline with microbump+NCF bonding and cold-plate cooling.',
      }),
  },
  {
    id: 'exp_b_12h_baseline',
    code: 'EXPERIMENT B',
    title: '12-High HBM Baseline',
    question: 'Thermal profile of a 12-high DRAM stack with thinner 36 um dies and 12 um bonding layers.',
    reproductionCommand: 'POST /api/simulations/steady (preset: HBM-12H, experimentId: exp_b_12h_baseline)',
    limitations: 'Uses illustrative 12H geometry and prescribed 2.2 W/die + 6.5 W base die.',
    buildConfig: () =>
      createPresetConfig('HBM-12H', {
        experimentId: 'exp_b_12h_baseline',
        description: 'Experiment B: 12-High HBM baseline under identical cooling and bonding assumptions.',
      }),
  },
  {
    id: 'exp_c_16h_baseline',
    code: 'EXPERIMENT C',
    title: '16-High HBM Baseline',
    question: 'Thermal limits of a 16-high stack showing cumulative vertical thermal resistance across 16 bonding interfaces.',
    reproductionCommand: 'POST /api/simulations/steady (preset: HBM-16H, experimentId: exp_c_16h_baseline)',
    limitations: 'Thinned 28 um silicon assumes defect-free wafer thinning; mechanical warpage not solved.',
    buildConfig: () =>
      createPresetConfig('HBM-16H', {
        experimentId: 'exp_c_16h_baseline',
        description: 'Experiment C: 16-High HBM baseline with 16 DRAM dies + logic base.',
      }),
  },
  {
    id: 'exp_d_equal_total_power',
    code: 'EXPERIMENT D',
    title: 'Equal Total Stack Power (8H vs 12H vs 16H)',
    question: 'How does stack height + interface count affect peak temperature at identical 28 W total memory power?',
    reproductionCommand: 'POST /api/compare/stack-heights (totalPowerW: 28.0)',
    limitations: 'Die thinning changes concurrently with die count to maintain package Z-height.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-16H', {
        experimentId: 'exp_d_equal_total_power',
        description: 'Experiment D: Equal total 28 W stack power normalized across 16 DRAM dies.',
      });
      const perDie = (28.0 - 8.5) / 16;
      cfg.heatSources.dramPowersW = Array(16).fill(perDie);
      return cfg;
    },
  },
  {
    id: 'exp_e_equal_per_die_power',
    code: 'EXPERIMENT E',
    title: 'Equal Power Per DRAM Die (2.5 W/die)',
    question: 'What happens when capacity scaling adds active dies at constant 2.5 W per DRAM die?',
    reproductionCommand: 'POST /api/compare/stack-heights (perDiePowerW: 2.5)',
    limitations: 'Assumes constant per-die power independent of bandwidth distribution.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-12H', {
        experimentId: 'exp_e_equal_per_die_power',
        description: 'Experiment E: 12H stack at 2.5 W per DRAM die.',
      });
      cfg.heatSources.dramPowersW = Array(12).fill(2.5);
      return cfg;
    },
  },
  {
    id: 'exp_f_interface_resistance',
    code: 'EXPERIMENT F',
    title: 'Degraded Bonding Interface Contact Resistance',
    question: 'How strongly does elevated die-to-bond contact resistance (or edge delamination fault) raise bottom-die temperature?',
    reproductionCommand: 'POST /api/sweep (parameter: contact_resistance_mm2kw)',
    limitations: 'Partial delamination uses an assumed 4x outer-ring fault multiplier rather than acoustic microscopy.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-12H', {
        experimentId: 'exp_f_interface_resistance',
        description: 'Experiment F: Assumed interface degradation & edge-void fault scenario.',
      });
      cfg.interfaces[0].rContactAreaM2KW = 18e-6;
      cfg.interfaces[0].qualityMode = 'nonuniform_edge_void';
      cfg.interfaces[0].assumedFaultModel = true;
      cfg.interfaces[0].nonuniformFactor = 4.0;
      return cfg;
    },
  },
  {
    id: 'exp_g_tsv_distribution',
    code: 'EXPERIMENT G',
    title: 'TSV Density & Distribution (High-Density Cu Spine)',
    question: 'How much does increasing TSV Cu area fraction from 4% to 18% improve vertical heat conduction?',
    reproductionCommand: 'POST /api/simulations/steady (experimentId: exp_g_tsv_distribution)',
    limitations: 'Homogenized TSV model assumes uniform SiO2 liner thickness and intact microbump landing pads.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-12H', {
        experimentId: 'exp_g_tsv_distribution',
        description: 'Experiment G: High-density 18% Cu TSV central spine configuration.',
      });
      cfg.tsv.cuFraction = 0.18;
      cfg.tsv.placement = 'central_spine';
      return cfg;
    },
  },
  {
    id: 'exp_h_cooling',
    code: 'EXPERIMENT H',
    title: 'Dual-Sided + Diamond-Cu Heat Spreader Cooling',
    question: 'Can dual-sided cooling and a Diamond-Cu lid break the 16H thermal bottleneck?',
    reproductionCommand: 'POST /api/compare/cooling (preset: HBM-16H)',
    limitations: 'Bottom cooling assumes simplified effective h_bottom=2200 W/(m2*K) without full PCB/socket geometry.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-16H', {
        experimentId: 'exp_h_cooling',
        description: 'Experiment H: Dual-sided cooling with Diamond-Cu heat spreader on HBM-16H.',
      });
      cfg.geometry.spreaderMaterialId = 'spreader_diamond_cu';
      cfg.cooling = applyCoolingPreset(cfg.cooling, 'dual_sided');
      return cfg;
    },
  },
  {
    id: 'exp_i_base_die_hotspot',
    code: 'EXPERIMENT I',
    title: 'Logic Base Die High-Power Hotspot',
    question: 'How does concentrating 16 W in the logic base die + PHY affect the overlying DRAM dies?',
    reproductionCommand: 'POST /api/simulations/steady (experimentId: exp_i_base_die_hotspot)',
    limitations: 'Spatial Gaussian hotspot shape is illustrative unless supplied by SilicaFlux PowerGrid.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-12H', {
        experimentId: 'exp_i_base_die_hotspot',
        description: 'Experiment I: 12H stack with 14 W base logic + 4 W PHY hotspot.',
      });
      cfg.heatSources.mode = 'spatial_hotspot';
      cfg.heatSources.baseDiePowerW = 14.0;
      cfg.heatSources.phyPowerW = 4.0;
      cfg.heatSources.hotspotPeakRatio = 2.2;
      return cfg;
    },
  },
  {
    id: 'exp_j_silicaflux_hpc',
    code: 'EXPERIMENT J',
    title: 'SilicaFlux-HPC Co-Packaged Accelerator Thermal Crosstalk',
    question: 'How strongly does an adjacent 180 W SilicaFlux-HPC compute die heat the HBM-12H stack across a shared interposer & IHS?',
    reproductionCommand: 'POST /api/simulations/steady (experimentId: exp_j_silicaflux_hpc)',
    limitations: 'Represents one HBM stack adjacent to accelerator die; full 4- or 8-stack reticle requires symmetry scaling.',
    buildConfig: () => {
      const cfg = createPresetConfig('HBM-12H', {
        experimentId: 'exp_j_silicaflux_hpc',
        description: 'Experiment J: HBM-12H co-packaged with 180 W SilicaFlux-HPC accelerator die.',
        includeAccelerator: true,
      });
      cfg.heatSources.acceleratorPowerW = 180;
      cfg.mesh.nx = 14;
      cfg.mesh.ny = 12;
      return cfg;
    },
  },
];

export function compareTsvExplicitVsHomogenized(baseConfig: SimulationConfig) {
  const cfgHom: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
  cfgHom.tsv.mode = 'homogenized';
  cfgHom.mesh = { ...cfgHom.mesh, nx: 12, ny: 12 };
  const resHom = runSimulation('tsv-hom', cfgHom);

  const cfgExp: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
  cfgExp.tsv.mode = 'explicit_cutaway';
  cfgExp.mesh = { ...cfgExp.mesh, nx: 12, ny: 12 };
  const resExp = runSimulation('tsv-exp', cfgExp);

  const props = computeHomogenizedTsvProperties(
    baseConfig.tsv,
    getMaterialOrThrow(baseConfig.geometry.dramMaterialId),
    getMaterialOrThrow('copper_electroplated'),
    getMaterialOrThrow(baseConfig.tsv.linerMaterialId),
  );

  return {
    homogenizedProperties: props,
    homogenized: {
      peakTempC: resHom.summary.peakTempC,
      avgDramTempC: resHom.summary.avgDramTempK - 273.15,
      baseDieTempC: resHom.summary.baseDieAvgTempK - 273.15,
      effectiveRthKPerW: resHom.summary.effectiveRthTotalKPerW,
    },
    explicitCutaway: {
      peakTempC: resExp.summary.peakTempC,
      avgDramTempC: resExp.summary.avgDramTempK - 273.15,
      baseDieTempC: resExp.summary.baseDieAvgTempK - 273.15,
      effectiveRthKPerW: resExp.summary.effectiveRthTotalKPerW,
    },
    deltaPeakK: Math.abs(resHom.summary.peakTempC - resExp.summary.peakTempC),
    note: 'Mode B explicitly resolves Cu-filled TSV cores and SiO2 liner walls on local cutaway grid cells while Mode A uses directional effective tensors.',
  };
}

export function benchmarkMeshResolutions(baseConfig: SimulationConfig) {
  const grids = [
    { label: 'Coarse (6x6)', nx: 6, ny: 6, nzPerDie: 1 },
    { label: 'Baseline (10x10)', nx: 10, ny: 10, nzPerDie: 1 },
    { label: 'Standard (12x12)', nx: 12, ny: 12, nzPerDie: 1 },
    { label: 'Fine (16x16)', nx: 16, ny: 16, nzPerDie: 2 },
  ];

  return grids.map((g, idx) => {
    const cfg: SimulationConfig = JSON.parse(JSON.stringify(baseConfig));
    cfg.mesh.nx = g.nx;
    cfg.mesh.ny = g.ny;
    cfg.mesh.nzPerDramDie = g.nzPerDie;
    const raw = solveSteadyStateFvm(cfg);
    const res = buildSimulationResult(`bench-${idx}`, cfg, raw);
    const payloadBytes = JSON.stringify(res.field3D).length;
    return {
      label: g.label,
      cellCount: res.meshStats.numCells,
      matrixSize: res.diagnostics.matrixSize,
      nnz: res.diagnostics.nnz,
      estimatedMemoryMb: res.meshStats.estimatedMemoryMb,
      assemblyTimeMs: res.diagnostics.assemblyTimeMs,
      solveTimeMs: res.diagnostics.solveTimeMs,
      iterations: res.diagnostics.iterations,
      peakTempC: res.summary.peakTempC,
      energyErrorPct: res.diagnostics.energyBalanceErrorPct,
      fieldPayloadKb: payloadBytes / 1024,
    };
  });
}

export function generateMarkdownEngineeringReport(result: SimulationResult): string {
  const s = result.summary;
  const d = result.diagnostics;
  const h = result.hotspot;
  const lines = [
    `# SilicaFlux ThermalStack — Engineering Simulation Report`,
    ``,
    `- **Job ID:** \`${result.jobId}\``,
    `- **Timestamp:** ${result.timestampIso}`,
    `- **Experiment ID:** \`${result.config.experimentId}\``,
    `- **Configuration:** ${result.config.geometry.stackPreset} (${result.geometry.dramDieCount} DRAM dies + separate Logic Base Die)`,
    `- **Study Type:** ${result.config.solver.studyType}`,
    ``,
    `## 1. Executive Thermal Summary`,
    `| Metric | Value | Units |`,
    `|---|---:|---|`,
    `| Peak Package Temperature | ${s.peakTempC.toFixed(2)} | °C (${s.peakTempK.toFixed(2)} K) |`,
    `| Peak DRAM Die Temperature | ${(s.peakDramTempK - 273.15).toFixed(2)} | °C |`,
    `| Average DRAM Temperature | ${(s.avgDramTempK - 273.15).toFixed(2)} | °C |`,
    `| Logic Base Die Average | ${(s.baseDieAvgTempK - 273.15).toFixed(2)} | °C |`,
    `| Top-to-Bottom DRAM Delta | ${s.topToBottomDeltaK.toFixed(2)} | K |`,
    `| Effective Total Thermal Resistance | ${s.effectiveRthTotalKPerW.toFixed(3)} | K/W |`,
    `| Peak Hotspot Location (X, Y, Z) | (${h.positionMm.map((v) => v.toFixed(2)).join(', ')}) | mm |`,
    ``,
    `## 2. Solver Convergence & Energy Conservation`,
    `- **Solver Method:** ${d.method}`,
    `- **Control Volumes / Matrix Size:** ${d.matrixSize} cells (${d.nnz} non-zeros)`,
    `- **Iterations / Relative Residual:** ${d.iterations} / ${d.residualNorm.toExponential(2)}`,
    `- **Assembly / Solve Time:** ${d.assemblyTimeMs.toFixed(1)} ms / ${d.solveTimeMs.toFixed(1)} ms`,
    `- **Total Heat Generation:** ${d.totalHeatGenW.toFixed(4)} W`,
    `- **Total Boundary Rejection:** ${d.totalHeatRejectionW.toFixed(4)} W`,
    `- **Global Energy-Balance Error:** ${d.energyBalanceErrorPct.toExponential(3)} %`,
    ``,
    `## 3. Per-Die Temperature Table`,
    `| Layer | Type | Z Center (µm) | Power (W) | Min (°C) | Avg (°C) | Max (°C) |`,
    `|---|---|---:|---:|---:|---:|---:|`,
    ...result.layers
      .filter((l) => l.kind === 'dram_die' || l.kind === 'base_die' || l.kind === 'heat_spreader')
      .map(
        (l) =>
          `| ${l.name} | ${l.kind} | ${l.zCenterUm.toFixed(1)} | ${l.powerW.toFixed(2)} | ${(l.minTempK - 273.15).toFixed(2)} | ${(l.avgTempK - 273.15).toFixed(2)} | ${(l.maxTempK - 273.15).toFixed(2)} |`,
      ),
    ``,
    `## 4. Model Assumptions, Screening Caveats & Limitations`,
    ...result.disclaimers.map((disc) => `- ${disc}`),
    `- **Reliability Screening Caveat:** ${result.reliabilityScreening.disclaimer}`,
    ``,
  ];
  return lines.join('\n');
}

export { compareStackHeights };
