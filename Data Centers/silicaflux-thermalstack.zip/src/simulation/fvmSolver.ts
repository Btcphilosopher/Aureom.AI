import { buildPackageGeometry } from './geometry';
import { assignVolumetricHeatSources, generateStructuredMesh3D } from './mesh3d';
import { solveBiCGSTAB, solvePCG, SparseCSR } from './sparseSolver';
import {
  BuiltPackageGeometry,
  Mesh3D,
  SimulationConfig,
  SolverDiagnostics,
  TransientStepSnapshot,
} from './types';

const STEFAN_BOLTZMANN = 5.670374419e-8;

export interface BoundaryConditionOverrides {
  // Optional overrides for analytical validation tests (fixed temperature or fixed flux on faces)
  fixedTempWestK?: number;
  fixedTempEastK?: number;
  fixedTempSouthK?: number;
  fixedTempNorthK?: number;
  fixedTempBottomK?: number;
  fixedTempTopK?: number;
  fixedFluxBottomWm2?: number; // positive = heat entering domain at z=0
  fixedFluxTopWm2?: number;
}

export interface RawFvmSolveOutput {
  geometry: BuiltPackageGeometry;
  mesh: Mesh3D;
  temperaturesK: Float64Array;
  diagnostics: SolverDiagnostics;
  transientSteps?: TransientStepSnapshot[];
  timeConstantS?: number;
}

interface AssembledSystem {
  matrix: SparseCSR;
  rhs: Float64Array;
  bcTopG: Float64Array; // Conductance on top face of each (i, j) column
  bcTopTinf: Float64Array;
  bcTopFluxW: Float64Array;
  bcBottomG: Float64Array;
  bcBottomTinf: Float64Array;
  bcBottomFluxW: Float64Array;
  bcSideG: {
    west: Float64Array;
    east: Float64Array;
    south: Float64Array;
    north: Float64Array;
  };
  bcSideTinf: {
    west: number;
    east: number;
    south: number;
    north: number;
  };
  hasOffDiagonalK: boolean;
  assemblyTimeMs: number;
}

function assembleFvmMatrix(
  config: SimulationConfig,
  mesh: Mesh3D,
  prevTempK?: Float64Array,
  transientAccumFactor?: number, // 1/dt for Backward Euler, 2/dt for Crank-Nicolson
  transientPrevRhs?: Float64Array,
  bcOverrides?: BoundaryConditionOverrides,
): AssembledSystem {
  const t0 = performance.now();
  const { nx, ny, nz, nCells, dx, dy, dz, cellKxx, cellKyy, cellKzz, cellKxy, cellKxz, cellKyz } =
    mesh;
  const cooling = config.cooling;

  let hasOffDiagonalK = false;
  for (let c = 0; c < nCells; c++) {
    if (
      Math.abs(cellKxy[c]) > 1e-12 ||
      Math.abs(cellKxz[c]) > 1e-12 ||
      Math.abs(cellKyz[c]) > 1e-12
    ) {
      hasOffDiagonalK = true;
      break;
    }
  }

  // Max 7 non-zeros per row for structured 3D FVM
  const rowPtr = new Int32Array(nCells + 1);
  const colIdx = new Int32Array(nCells * 7);
  const values = new Float64Array(nCells * 7);
  const diagIdx = new Int32Array(nCells);
  const rhs = new Float64Array(nCells);

  const bcTopG = new Float64Array(nx * ny);
  const bcTopTinf = new Float64Array(nx * ny);
  const bcTopFluxW = new Float64Array(nx * ny);
  const bcBottomG = new Float64Array(nx * ny);
  const bcBottomTinf = new Float64Array(nx * ny);
  const bcBottomFluxW = new Float64Array(nx * ny);
  const bcWestG = new Float64Array(ny * nz);
  const bcEastG = new Float64Array(ny * nz);
  const bcSouthG = new Float64Array(nx * nz);
  const bcNorthG = new Float64Array(nx * nz);

  const radLinearH = (tSurfGuess: number): number => {
    if (!cooling.enableRadiation || cooling.radiationEmissivity <= 0) return 0;
    const tA = cooling.tAmbientK;
    return (
      cooling.radiationEmissivity *
      STEFAN_BOLTZMANN *
      (tSurfGuess * tSurfGuess + tA * tA) *
      (tSurfGuess + tA)
    );
  };

  let nnz = 0;

  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const c = k * ny * nx + j * nx + i;
        rowPtr[c] = nnz;

        const vol = dx[i] * dy[j] * dz[k];
        const areaX = dy[j] * dz[k];
        const areaY = dx[i] * dz[k];
        const areaZ = dx[i] * dy[j];

        let diag = 0;
        let bVal = mesh.cellHeatSourceW[c];

        if (transientAccumFactor && transientAccumFactor > 0 && prevTempK) {
          const cap = mesh.cellRhoCp[c] * vol * transientAccumFactor;
          diag += cap;
          bVal += cap * prevTempK[c];
          if (transientPrevRhs) {
            bVal += transientPrevRhs[c];
          }
        }

        // Collect neighbors in strict ascending column order so SSOR-PCG works cleanly!
        // Order: k-1 (bottom), j-1 (south), i-1 (west), c (self), i+1 (east), j+1 (north), k+1 (top)

        // 1. Z-minus (k - 1)
        if (k > 0) {
          const nb = (k - 1) * ny * nx + j * nx + i;
          const rContactBase = mesh.zInterfaceRContact[k - 1];
          const faultArr = mesh.zInterfaceFaultFactor[k - 1];
          const rContact = faultArr ? rContactBase * faultArr[j * nx + i] : rContactBase;
          const g =
            areaZ /
            (dz[k - 1] / (2 * cellKzz[nb]) + rContact + dz[k] / (2 * cellKzz[c]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          // Bottom boundary (z = 0)
          const idx2d = j * nx + i;
          if (bcOverrides?.fixedTempBottomK !== undefined) {
            const gBc = areaZ / (dz[0] / (2 * cellKzz[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempBottomK;
            bcBottomG[idx2d] = gBc;
            bcBottomTinf[idx2d] = bcOverrides.fixedTempBottomK;
          } else if (bcOverrides?.fixedFluxBottomWm2 !== undefined) {
            const qIn = bcOverrides.fixedFluxBottomWm2 * areaZ;
            bVal += qIn;
            bcBottomFluxW[idx2d] = qIn;
          } else if (cooling.hBottomWm2K > 0) {
            const hEff =
              cooling.hBottomWm2K + radLinearH(prevTempK ? prevTempK[c] : cooling.tAmbientK);
            const gBc = areaZ / (dz[0] / (2 * cellKzz[c]) + 1.0 / hEff);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcBottomG[idx2d] = gBc;
            bcBottomTinf[idx2d] = cooling.tAmbientK;
          }
        }

        // 2. Y-minus (j - 1)
        if (j > 0) {
          const nb = k * ny * nx + (j - 1) * nx + i;
          const g = areaY / (dy[j - 1] / (2 * cellKyy[nb]) + dy[j] / (2 * cellKyy[c]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          const idx2d = k * nx + i;
          if (bcOverrides?.fixedTempSouthK !== undefined) {
            const gBc = areaY / (dy[0] / (2 * cellKyy[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempSouthK;
            bcSouthG[idx2d] = gBc;
          } else if (cooling.hSideWm2K > 0) {
            const gBc = areaY / (dy[0] / (2 * cellKyy[c]) + 1.0 / cooling.hSideWm2K);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcSouthG[idx2d] = gBc;
          }
        }

        // 3. X-minus (i - 1)
        if (i > 0) {
          const nb = k * ny * nx + j * nx + (i - 1);
          const g = areaX / (dx[i - 1] / (2 * cellKxx[nb]) + dx[i] / (2 * cellKxx[c]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          const idx2d = k * ny + j;
          if (bcOverrides?.fixedTempWestK !== undefined) {
            const gBc = areaX / (dx[0] / (2 * cellKxx[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempWestK;
            bcWestG[idx2d] = gBc;
          } else if (cooling.hSideWm2K > 0) {
            const gBc = areaX / (dx[0] / (2 * cellKxx[c]) + 1.0 / cooling.hSideWm2K);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcWestG[idx2d] = gBc;
          }
        }

        // 4. Diagonal (self c) - placeholder updated after +1 neighbors
        const selfPos = nnz;
        diagIdx[c] = selfPos;
        colIdx[nnz] = c;
        values[nnz] = 0;
        nnz++;

        // 5. X-plus (i + 1)
        if (i < nx - 1) {
          const nb = k * ny * nx + j * nx + (i + 1);
          const g = areaX / (dx[i] / (2 * cellKxx[c]) + dx[i + 1] / (2 * cellKxx[nb]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          const idx2d = k * ny + j;
          if (bcOverrides?.fixedTempEastK !== undefined) {
            const gBc = areaX / (dx[nx - 1] / (2 * cellKxx[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempEastK;
            bcEastG[idx2d] = gBc;
          } else if (cooling.hSideWm2K > 0) {
            const gBc = areaX / (dx[nx - 1] / (2 * cellKxx[c]) + 1.0 / cooling.hSideWm2K);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcEastG[idx2d] = gBc;
          }
        }

        // 6. Y-plus (j + 1)
        if (j < ny - 1) {
          const nb = k * ny * nx + (j + 1) * nx + i;
          const g = areaY / (dy[j] / (2 * cellKyy[c]) + dy[j + 1] / (2 * cellKyy[nb]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          const idx2d = k * nx + i;
          if (bcOverrides?.fixedTempNorthK !== undefined) {
            const gBc = areaY / (dy[ny - 1] / (2 * cellKyy[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempNorthK;
            bcNorthG[idx2d] = gBc;
          } else if (cooling.hSideWm2K > 0) {
            const gBc = areaY / (dy[ny - 1] / (2 * cellKyy[c]) + 1.0 / cooling.hSideWm2K);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcNorthG[idx2d] = gBc;
          }
        }

        // 7. Z-plus (k + 1)
        if (k < nz - 1) {
          const nb = (k + 1) * ny * nx + j * nx + i;
          const rContactBase = mesh.zInterfaceRContact[k];
          const faultArr = mesh.zInterfaceFaultFactor[k];
          const rContact = faultArr ? rContactBase * faultArr[j * nx + i] : rContactBase;
          const g =
            areaZ /
            (dz[k] / (2 * cellKzz[c]) + rContact + dz[k + 1] / (2 * cellKzz[nb]));
          colIdx[nnz] = nb;
          values[nnz] = -g;
          nnz++;
          diag += g;
        } else {
          // Top boundary (z = H)
          const idx2d = j * nx + i;
          if (bcOverrides?.fixedTempTopK !== undefined) {
            const gBc = areaZ / (dz[nz - 1] / (2 * cellKzz[c]));
            diag += gBc;
            bVal += gBc * bcOverrides.fixedTempTopK;
            bcTopG[idx2d] = gBc;
            bcTopTinf[idx2d] = bcOverrides.fixedTempTopK;
          } else if (bcOverrides?.fixedFluxTopWm2 !== undefined) {
            const qIn = bcOverrides.fixedFluxTopWm2 * areaZ;
            bVal += qIn;
            bcTopFluxW[idx2d] = qIn;
          } else if (cooling.mode === 'fixed_temp_idealized' && cooling.fixedTopTempK) {
            const gBc = areaZ / (dz[nz - 1] / (2 * cellKzz[c]));
            diag += gBc;
            bVal += gBc * cooling.fixedTopTempK;
            bcTopG[idx2d] = gBc;
            bcTopTinf[idx2d] = cooling.fixedTopTempK;
          } else if (cooling.hTopWm2K > 0) {
            const hEff =
              cooling.hTopWm2K + radLinearH(prevTempK ? prevTempK[c] : cooling.tAmbientK);
            const gBc = areaZ / (dz[nz - 1] / (2 * cellKzz[c]) + 1.0 / hEff);
            diag += gBc;
            bVal += gBc * cooling.tAmbientK;
            bcTopG[idx2d] = gBc;
            bcTopTinf[idx2d] = cooling.tAmbientK;
          }
        }

        values[selfPos] = diag;
        rhs[c] = bVal;
      }
    }
  }
  rowPtr[nCells] = nnz;

  return {
    matrix: {
      n: nCells,
      rowPtr,
      colIdx: colIdx.subarray(0, nnz),
      values: values.subarray(0, nnz),
      diagIdx,
    },
    rhs,
    bcTopG,
    bcTopTinf,
    bcTopFluxW,
    bcBottomG,
    bcBottomTinf,
    bcBottomFluxW,
    bcSideG: {
      west: bcWestG,
      east: bcEastG,
      south: bcSouthG,
      north: bcNorthG,
    },
    bcSideTinf: {
      west: bcOverrides?.fixedTempWestK ?? cooling.tAmbientK,
      east: bcOverrides?.fixedTempEastK ?? cooling.tAmbientK,
      south: bcOverrides?.fixedTempSouthK ?? cooling.tAmbientK,
      north: bcOverrides?.fixedTempNorthK ?? cooling.tAmbientK,
    },
    hasOffDiagonalK,
    assemblyTimeMs: performance.now() - t0,
  };
}

/**
 * Adds explicit conservative off-diagonal cross-diffusion flux divergence (when kxy/kxz/kyz != 0)
 * using deferred-correction / central face gradients.
 */
function computeOffDiagonalFluxRhs(
  mesh: Mesh3D,
  tempK: Float64Array,
): Float64Array {
  const { nx, ny, nz, nCells, xCenters, yCenters, zCenters, dx, dy, dz, cellKxy, cellKxz, cellKyz } =
    mesh;
  const src = new Float64Array(nCells);

  // Compute cell gradients via central differences
  const dTdx = new Float64Array(nCells);
  const dTdy = new Float64Array(nCells);
  const dTdz = new Float64Array(nCells);

  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const c = k * ny * nx + j * nx + i;
        if (nx > 1) {
          const iL = Math.max(0, i - 1);
          const iR = Math.min(nx - 1, i + 1);
          const dist = xCenters[iR] - xCenters[iL];
          dTdx[c] =
            dist > 0
              ? (tempK[k * ny * nx + j * nx + iR] - tempK[k * ny * nx + j * nx + iL]) / dist
              : 0;
        }
        if (ny > 1) {
          const jL = Math.max(0, j - 1);
          const jR = Math.min(ny - 1, j + 1);
          const dist = yCenters[jR] - yCenters[jL];
          dTdy[c] =
            dist > 0
              ? (tempK[k * ny * nx + jR * nx + i] - tempK[k * ny * nx + jL * nx + i]) / dist
              : 0;
        }
        if (nz > 1) {
          const kL = Math.max(0, k - 1);
          const kR = Math.min(nz - 1, k + 1);
          const dist = zCenters[kR] - zCenters[kL];
          dTdz[c] =
            dist > 0
              ? (tempK[kR * ny * nx + j * nx + i] - tempK[kL * ny * nx + j * nx + i]) / dist
              : 0;
        }
      }
    }
  }

  // Accumulate conservative face cross-fluxes (equal & opposite on internal faces)
  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const c = k * ny * nx + j * nx + i;
        if (i < nx - 1) {
          const nb = k * ny * nx + j * nx + (i + 1);
          const areaX = dy[j] * dz[k];
          const kxyFace = 0.5 * (cellKxy[c] + cellKxy[nb]);
          const kxzFace = 0.5 * (cellKxz[c] + cellKxz[nb]);
          const flux =
            areaX *
            (kxyFace * 0.5 * (dTdy[c] + dTdy[nb]) + kxzFace * 0.5 * (dTdz[c] + dTdz[nb]));
          src[c] += flux;
          src[nb] -= flux;
        }
        if (j < ny - 1) {
          const nb = k * ny * nx + (j + 1) * nx + i;
          const areaY = dx[i] * dz[k];
          const kxyFace = 0.5 * (cellKxy[c] + cellKxy[nb]);
          const kyzFace = 0.5 * (cellKyz[c] + cellKyz[nb]);
          const flux =
            areaY *
            (kxyFace * 0.5 * (dTdx[c] + dTdx[nb]) + kyzFace * 0.5 * (dTdz[c] + dTdz[nb]));
          src[c] += flux;
          src[nb] -= flux;
        }
        if (k < nz - 1) {
          const nb = (k + 1) * ny * nx + j * nx + i;
          const areaZ = dx[i] * dy[j];
          const kxzFace = 0.5 * (cellKxz[c] + cellKxz[nb]);
          const kyzFace = 0.5 * (cellKyz[c] + cellKyz[nb]);
          const flux =
            areaZ *
            (kxzFace * 0.5 * (dTdx[c] + dTdx[nb]) + kyzFace * 0.5 * (dTdy[c] + dTdy[nb]));
          src[c] += flux;
          src[nb] -= flux;
        }
      }
    }
  }
  return src;
}

function computeBoundaryAccounting(
  mesh: Mesh3D,
  sys: AssembledSystem,
  tempK: Float64Array,
  storedEnergyRateW = 0,
): {
  totalHeatGenW: number;
  totalHeatRejectionW: number;
  energyBalanceErrorPct: number;
  boundaryHeatFluxW: SolverDiagnostics['boundaryHeatFluxW'];
} {
  const { nx, ny, nz, nCells } = mesh;
  let totalHeatGenW = 0;
  for (let c = 0; c < nCells; c++) {
    totalHeatGenW += mesh.cellHeatSourceW[c];
  }

  let top = 0;
  let bottom = 0;
  let west = 0;
  let east = 0;
  let south = 0;
  let north = 0;

  // Positive boundaryHeatFluxW means heat leaving the domain across that boundary
  for (let j = 0; j < ny; j++) {
    for (let i = 0; i < nx; i++) {
      const idx2d = j * nx + i;
      const cBot = j * nx + i;
      const cTop = (nz - 1) * ny * nx + j * nx + i;
      bottom +=
        sys.bcBottomG[idx2d] * (tempK[cBot] - sys.bcBottomTinf[idx2d]) -
        sys.bcBottomFluxW[idx2d];
      top +=
        sys.bcTopG[idx2d] * (tempK[cTop] - sys.bcTopTinf[idx2d]) -
        sys.bcTopFluxW[idx2d];
    }
  }

  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      const idx2d = k * ny + j;
      const cW = k * ny * nx + j * nx;
      const cE = k * ny * nx + j * nx + (nx - 1);
      west += sys.bcSideG.west[idx2d] * (tempK[cW] - sys.bcSideTinf.west);
      east += sys.bcSideG.east[idx2d] * (tempK[cE] - sys.bcSideTinf.east);
    }
    for (let i = 0; i < nx; i++) {
      const idx2d = k * nx + i;
      const cS = k * ny * nx + i;
      const cN = k * ny * nx + (ny - 1) * nx + i;
      south += sys.bcSideG.south[idx2d] * (tempK[cS] - sys.bcSideTinf.south);
      north += sys.bcSideG.north[idx2d] * (tempK[cN] - sys.bcSideTinf.north);
    }
  }

  const totalHeatRejectionW = top + bottom + west + east + south + north;
  const denom = Math.max(Math.abs(totalHeatGenW), Math.abs(totalHeatRejectionW), 1e-12);
  const energyBalanceErrorPct =
    (Math.abs(totalHeatGenW - totalHeatRejectionW - storedEnergyRateW) / denom) * 100;

  return {
    totalHeatGenW,
    totalHeatRejectionW,
    energyBalanceErrorPct,
    boundaryHeatFluxW: { top, bottom, west, east, south, north },
  };
}

export function solveSteadyStateFvm(
  config: SimulationConfig,
  bcOverrides?: BoundaryConditionOverrides,
  shouldCancel?: () => boolean,
): RawFvmSolveOutput {
  const geometry = buildPackageGeometry(config, Boolean(bcOverrides));
  let mesh = generateStructuredMesh3D(config, geometry);

  const nCells = mesh.nCells;
  let tempK = new Float64Array(nCells).fill(config.cooling.tAmbientK + 15);
  let lastSys = assembleFvmMatrix(config, mesh, tempK, undefined, undefined, bcOverrides);

  const needsNonlinear =
    config.solver.useTempDependentK ||
    config.heatSources.electrothermalEnabled ||
    config.cooling.enableRadiation ||
    lastSys.hasOffDiagonalK;

  const maxNL = needsNonlinear ? Math.max(1, config.solver.nonlinearMaxIters) : 1;
  const omega = config.solver.nonlinearUnderRelaxation;

  let totalSolveMs = 0;
  let totalAssemblyMs = 0;
  let totalLinIters = 0;
  let lastReport = solvePCG(
    lastSys.matrix,
    lastSys.rhs,
    tempK,
    config.solver.relativeTolerance,
    config.solver.maxIterations,
    shouldCancel,
  );
  totalAssemblyMs += lastSys.assemblyTimeMs;
  totalSolveMs += lastReport.solveTimeMs;
  totalLinIters += lastReport.iterations;

  if (!needsNonlinear) {
    tempK.set(lastReport.x);
  } else {
    tempK = new Float64Array(lastReport.x);
    let nlIter = 1;
    for (nlIter = 2; nlIter <= maxNL; nlIter++) {
      if (shouldCancel && shouldCancel()) {
        throw new Error('Simulation job cancelled by user.');
      }
      mesh = generateStructuredMesh3D(config, geometry, tempK);
      if (config.heatSources.electrothermalEnabled) {
        assignVolumetricHeatSources(
          config,
          geometry,
          mesh.nx,
          mesh.ny,
          mesh.nz,
          mesh.xCenters,
          mesh.yCenters,
          mesh.dx,
          mesh.dy,
          mesh.dz,
          mesh.cellRegionType,
          mesh.cellDramDieIndex,
          mesh.cellHeatSourceW,
          undefined,
          tempK,
        );
      }
      lastSys = assembleFvmMatrix(config, mesh, tempK, undefined, undefined, bcOverrides);
      if (lastSys.hasOffDiagonalK) {
        const cross = computeOffDiagonalFluxRhs(mesh, tempK);
        for (let c = 0; c < nCells; c++) lastSys.rhs[c] += cross[c];
      }

      const solverFn = lastSys.hasOffDiagonalK ? solveBiCGSTAB : solvePCG;
      lastReport = solverFn(
        lastSys.matrix,
        lastSys.rhs,
        tempK,
        config.solver.relativeTolerance,
        config.solver.maxIterations,
        shouldCancel,
      );
      totalAssemblyMs += lastSys.assemblyTimeMs;
      totalSolveMs += lastReport.solveTimeMs;
      totalLinIters += lastReport.iterations;

      let maxDiff = 0;
      for (let c = 0; c < nCells; c++) {
        const updated = omega * lastReport.x[c] + (1 - omega) * tempK[c];
        maxDiff = Math.max(maxDiff, Math.abs(updated - tempK[c]));
        tempK[c] = updated;
      }
      if (maxDiff < 1e-4) {
        break;
      }
    }
  }

  // Final consistent system check for exact boundary flux accounting
  const accounting = computeBoundaryAccounting(mesh, lastSys, tempK, 0);

  const diagnostics: SolverDiagnostics = {
    method: lastReport.method,
    matrixSize: nCells,
    nnz: lastSys.matrix.values.length,
    residualNorm: lastReport.residualNorm,
    tolerance: config.solver.relativeTolerance,
    iterations: totalLinIters,
    nonlinearIterations: needsNonlinear ? Math.min(maxNL, config.solver.nonlinearMaxIters) : 1,
    assemblyTimeMs: totalAssemblyMs,
    solveTimeMs: totalSolveMs,
    totalHeatGenW: accounting.totalHeatGenW,
    totalHeatRejectionW: accounting.totalHeatRejectionW,
    storedEnergyRateW: 0,
    energyBalanceErrorPct: accounting.energyBalanceErrorPct,
    boundaryHeatFluxW: accounting.boundaryHeatFluxW,
    converged: lastReport.converged && Number.isFinite(accounting.energyBalanceErrorPct),
  };

  return {
    geometry,
    mesh,
    temperaturesK: tempK,
    diagnostics,
  };
}

export function solveTransientFvm(
  config: SimulationConfig,
  bcOverrides?: BoundaryConditionOverrides,
  shouldCancel?: () => boolean,
): RawFvmSolveOutput {
  const geometry = buildPackageGeometry(config);
  const mesh = generateStructuredMesh3D(config, geometry);
  const { nx, ny, nz, nCells, dx, dy, dz, cellHeatSourceW, cellRhoCp, cellRegionType, cellDramDieIndex } =
    mesh;

  const dt = Math.max(config.solver.dtSeconds, 1e-4);
  const nSteps = Math.max(1, Math.min(200, Math.round(config.solver.totalTimeSeconds / dt)));
  const isCN = config.solver.timeIntegration === 'crank_nicolson';
  const accumFactor = isCN ? 2.0 / dt : 1.0 / dt;

  const tempK = new Float64Array(nCells).fill(config.solver.initialTempK);
  const snapshots: TransientStepSnapshot[] = [];

  let totalAssemblyMs = 0;
  let totalSolveMs = 0;
  let totalIters = 0;
  let lastResidual = 0;
  let lastSys: AssembledSystem | null = null;
  let storedEnergyRateW = 0;

  const interpolatePowerScale = (tS: number) => {
    const trace = config.heatSources.timeTrace;
    if (!trace || trace.timesS.length === 0) {
      return { dram: 1, base: 1, accel: 1 };
    }
    if (tS <= trace.timesS[0]) {
      return {
        dram: trace.dramScale[0],
        base: trace.baseScale[0],
        accel: trace.accelScale[0],
      };
    }
    const last = trace.timesS.length - 1;
    if (tS >= trace.timesS[last]) {
      return {
        dram: trace.dramScale[last],
        base: trace.baseScale[last],
        accel: trace.accelScale[last],
      };
    }
    for (let k = 0; k < last; k++) {
      if (tS >= trace.timesS[k] && tS <= trace.timesS[k + 1]) {
        const u = (tS - trace.timesS[k]) / Math.max(trace.timesS[k + 1] - trace.timesS[k], 1e-12);
        return {
          dram: trace.dramScale[k] + u * (trace.dramScale[k + 1] - trace.dramScale[k]),
          base: trace.baseScale[k] + u * (trace.baseScale[k + 1] - trace.baseScale[k]),
          accel: trace.accelScale[k] + u * (trace.accelScale[k + 1] - trace.accelScale[k]),
        };
      }
    }
    return { dram: 1, base: 1, accel: 1 };
  };

  const makeSnapshot = (
    timeS: number,
    currT: Float64Array,
    sys: AssembledSystem | null,
    storedRateW: number,
  ): TransientStepSnapshot => {
    let peakTempK = -Infinity;
    let hotI = 0;
    let hotJ = 0;
    let hotK = 0;
    let dramSum = 0;
    let dramCount = 0;
    let baseSum = 0;
    let baseCount = 0;
    let accelMax: number | null = geometry.acceleratorBox ? -Infinity : null;
    const perDramMax = new Array<number>(geometry.dramDieCount).fill(-Infinity);

    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const c = k * ny * nx + j * nx + i;
          const T = currT[c];
          if (T > peakTempK) {
            peakTempK = T;
            hotI = i;
            hotJ = j;
            hotK = k;
          }
          const dIdx = cellDramDieIndex[c];
          if (dIdx >= 0) {
            dramSum += T;
            dramCount++;
            if (T > perDramMax[dIdx]) perDramMax[dIdx] = T;
          }
          if (cellRegionType[c] === 4) {
            baseSum += T;
            baseCount++;
          }
          if (cellRegionType[c] === 9 && accelMax !== null && T > accelMax) {
            accelMax = T;
          }
        }
      }
    }

    const midJ = Math.floor(ny / 2);
    const xzMidSliceK: number[][] = [];
    for (let k = 0; k < nz; k++) {
      const row: number[] = [];
      for (let i = 0; i < nx; i++) {
        row.push(currT[k * ny * nx + midJ * nx + i]);
      }
      xzMidSliceK.push(row);
    }

    const xyHotSliceK: number[][] = [];
    for (let j = 0; j < ny; j++) {
      const row: number[] = [];
      for (let i = 0; i < nx; i++) {
        row.push(currT[hotK * ny * nx + j * nx + i]);
      }
      xyHotSliceK.push(row);
    }

    const acc = sys
      ? computeBoundaryAccounting(mesh, sys, currT, storedRateW)
      : {
          totalHeatGenW: 0,
          totalHeatRejectionW: 0,
          energyBalanceErrorPct: 0,
        };

    return {
      timeS,
      peakTempK,
      avgDramTempK: dramCount > 0 ? dramSum / dramCount : peakTempK,
      baseDieTempK: baseCount > 0 ? baseSum / baseCount : peakTempK,
      accelPeakTempK: accelMax,
      totalPowerW: acc.totalHeatGenW,
      heatRejectedW: acc.totalHeatRejectionW,
      energyBalanceErrorPct: acc.energyBalanceErrorPct,
      hotspotMm: [
        mesh.xCenters[hotI] * 1e3,
        mesh.yCenters[hotJ] * 1e3,
        mesh.zCenters[hotK] * 1e3,
      ],
      perDramMaxTempK: perDramMax,
      xzMidSliceK,
      xyHotSliceK,
    };
  };

  // Initial state t = 0
  snapshots.push(makeSnapshot(0, tempK, null, 0));

  for (let step = 1; step <= nSteps; step++) {
    if (shouldCancel && shouldCancel()) {
      throw new Error('Transient simulation cancelled by user.');
    }
    const timeS = step * dt;
    const scale = interpolatePowerScale(timeS);
    assignVolumetricHeatSources(
      config,
      geometry,
      nx,
      ny,
      nz,
      mesh.xCenters,
      mesh.yCenters,
      dx,
      dy,
      dz,
      cellRegionType,
      cellDramDieIndex,
      cellHeatSourceW,
      scale,
    );

    let cnPrevRhs: Float64Array | undefined;
    if (isCN) {
      // Crank-Nicolson: add explicit flux divergence from previous step (L T^n + q^n)
      const prevSys = assembleFvmMatrix(config, mesh, tempK, undefined, undefined, bcOverrides);
      cnPrevRhs = new Float64Array(nCells);
      const AoldT = new Float64Array(nCells);
      const { rowPtr, colIdx, values } = prevSys.matrix;
      for (let i = 0; i < nCells; i++) {
        let sum = 0;
        for (let p = rowPtr[i]; p < rowPtr[i + 1]; p++) {
          sum += values[p] * tempK[colIdx[p]];
        }
        AoldT[i] = sum;
        cnPrevRhs[i] = prevSys.rhs[i] - AoldT[i];
      }
    }

    const sys = assembleFvmMatrix(
      config,
      mesh,
      tempK,
      accumFactor,
      cnPrevRhs,
      bcOverrides,
    );
    const report = solvePCG(
      sys.matrix,
      sys.rhs,
      tempK,
      config.solver.relativeTolerance,
      config.solver.maxIterations,
      shouldCancel,
    );

    // Stored energy rate dE/dt = sum(rho*cp*V * (T_new - T_old)/dt)
    storedEnergyRateW = 0;
    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const c = k * ny * nx + j * nx + i;
          const vol = dx[i] * dy[j] * dz[k];
          storedEnergyRateW += (cellRhoCp[c] * vol * (report.x[c] - tempK[c])) / dt;
        }
      }
    }

    tempK.set(report.x);
    lastSys = sys;
    totalAssemblyMs += sys.assemblyTimeMs;
    totalSolveMs += report.solveTimeMs;
    totalIters += report.iterations;
    lastResidual = report.residualNorm;

    // Record snapshot (thin if > 50 steps so payload stays crisp)
    if (nSteps <= 50 || step % Math.ceil(nSteps / 50) === 0 || step === nSteps) {
      snapshots.push(makeSnapshot(timeS, tempK, sys, storedEnergyRateW));
    }
  }

  // Estimate dominant thermal time constant tau from peak temp trajectory
  const t0Peak = snapshots[0].peakTempK;
  const tEndPeak = snapshots[snapshots.length - 1].peakTempK;
  let timeConstantS = config.solver.totalTimeSeconds * 0.35;
  if (Math.abs(tEndPeak - t0Peak) > 0.1) {
    const target63 = t0Peak + 0.632 * (tEndPeak - t0Peak);
    for (const s of snapshots) {
      if (
        (tEndPeak > t0Peak && s.peakTempK >= target63) ||
        (tEndPeak < t0Peak && s.peakTempK <= target63)
      ) {
        timeConstantS = Math.max(s.timeS, dt);
        break;
      }
    }
  }

  const finalAccounting = lastSys
    ? computeBoundaryAccounting(mesh, lastSys, tempK, storedEnergyRateW)
    : {
        totalHeatGenW: 0,
        totalHeatRejectionW: 0,
        energyBalanceErrorPct: 0,
        boundaryHeatFluxW: { top: 0, bottom: 0, west: 0, east: 0, south: 0, north: 0 },
      };

  const diagnostics: SolverDiagnostics = {
    method: isCN ? 'Crank-Nicolson + SSOR-PCG' : 'Backward-Euler + SSOR-PCG',
    matrixSize: nCells,
    nnz: lastSys ? lastSys.matrix.values.length : 0,
    residualNorm: lastResidual,
    tolerance: config.solver.relativeTolerance,
    iterations: totalIters,
    nonlinearIterations: nSteps,
    assemblyTimeMs: totalAssemblyMs,
    solveTimeMs: totalSolveMs,
    totalHeatGenW: finalAccounting.totalHeatGenW,
    totalHeatRejectionW: finalAccounting.totalHeatRejectionW,
    storedEnergyRateW,
    energyBalanceErrorPct: finalAccounting.energyBalanceErrorPct,
    boundaryHeatFluxW: finalAccounting.boundaryHeatFluxW,
    converged: Number.isFinite(finalAccounting.energyBalanceErrorPct),
  };

  return {
    geometry,
    mesh,
    temperaturesK: tempK,
    diagnostics,
    transientSteps: snapshots,
    timeConstantS,
  };
}
