import {
  computeHomogenizedTsvProperties,
  evaluateMaterialKAtTemp,
  getMaterialOrThrow,
} from './materials';
import {
  BuiltPackageGeometry,
  Mesh3D,
  SimulationConfig,
} from './types';

function makeNonuniform1DGrid(
  domainSize: number,
  nCells: number,
  focusCenter: number,
  focusHalfWidth: number,
  nonuniform: boolean,
): Float64Array {
  const edges = new Float64Array(nCells + 1);
  if (!nonuniform || nCells < 6) {
    for (let i = 0; i <= nCells; i++) {
      edges[i] = (domainSize * i) / nCells;
    }
    return edges;
  }

  // Smoothly cluster ~60% of cells around the HBM / TSV / hotspot region using density weights
  const weights = new Float64Array(nCells);
  let sumW = 0;
  for (let i = 0; i < nCells; i++) {
    const u = (i + 0.5) / nCells;
    const xGuess = u * domainSize;
    const dist = Math.abs(xGuess - focusCenter);
    const insideFocus = dist <= focusHalfWidth;
    // Finer spacing (smaller dx -> smaller weight) near active die & TSV center
    const w = insideFocus ? 0.55 + 0.35 * (dist / Math.max(focusHalfWidth, 1e-9)) : 1.45;
    weights[i] = w;
    sumW += w;
  }
  edges[0] = 0;
  let accum = 0;
  for (let i = 0; i < nCells; i++) {
    accum += (weights[i] / sumW) * domainSize;
    edges[i + 1] = accum;
  }
  edges[nCells] = domainSize;
  return edges;
}

export function generateStructuredMesh3D(
  config: SimulationConfig,
  geometry: BuiltPackageGeometry,
  tempEstimateFieldK?: Float64Array,
): Mesh3D {
  const { nx, ny, nzPerDramDie, nzPerBond, nzBaseDie, nzInterposer, nzTim, nzSpreader, nonuniformXY } =
    config.mesh;

  const hbmCenterX = 0.5 * (geometry.hbmBox.xMin + geometry.hbmBox.xMax);
  const hbmCenterY = 0.5 * (geometry.hbmBox.yMin + geometry.hbmBox.yMax);
  const hbmHalfW = 0.5 * (geometry.hbmBox.xMax - geometry.hbmBox.xMin);
  const hbmHalfD = 0.5 * (geometry.hbmBox.yMax - geometry.hbmBox.yMin);

  const xEdges = makeNonuniform1DGrid(
    geometry.domainWidthM,
    nx,
    geometry.acceleratorBox
      ? 0.5 * (geometry.hbmBox.xMin + geometry.acceleratorBox.xMax)
      : hbmCenterX,
    geometry.acceleratorBox
      ? 0.5 * (geometry.acceleratorBox.xMax - geometry.hbmBox.xMin)
      : hbmHalfW,
    nonuniformXY,
  );
  const yEdges = makeNonuniform1DGrid(
    geometry.domainDepthM,
    ny,
    hbmCenterY,
    hbmHalfD,
    nonuniformXY,
  );

  // Build layer-aligned Z edges
  const zEdgeList: number[] = [0];
  const zLayerIndexList: number[] = [];

  for (let lIdx = 0; lIdx < geometry.layers.length; lIdx++) {
    const layer = geometry.layers[lIdx];
    let nSub = 1;
    switch (layer.kind) {
      case 'substrate':
        nSub = 2;
        break;
      case 'interposer':
        nSub = Math.max(1, nzInterposer);
        break;
      case 'package_link':
        nSub = 1;
        break;
      case 'base_die':
        nSub = Math.max(1, nzBaseDie);
        break;
      case 'bonding':
        nSub = Math.max(1, nzPerBond);
        break;
      case 'dram_die':
        nSub = Math.max(1, nzPerDramDie);
        break;
      case 'tim':
        nSub = Math.max(1, nzTim);
        break;
      case 'heat_spreader':
        nSub = Math.max(1, nzSpreader);
        break;
    }
    const dz = layer.thicknessM / nSub;
    const zStart = layer.zMinM;
    for (let s = 1; s <= nSub; s++) {
      zEdgeList.push(s === nSub ? layer.zMaxM : zStart + s * dz);
      zLayerIndexList.push(lIdx);
    }
  }

  const nz = zLayerIndexList.length;
  const zEdges = Float64Array.from(zEdgeList);

  const xCenters = new Float64Array(nx);
  const dx = new Float64Array(nx);
  for (let i = 0; i < nx; i++) {
    dx[i] = xEdges[i + 1] - xEdges[i];
    xCenters[i] = 0.5 * (xEdges[i] + xEdges[i + 1]);
  }

  const yCenters = new Float64Array(ny);
  const dy = new Float64Array(ny);
  for (let j = 0; j < ny; j++) {
    dy[j] = yEdges[j + 1] - yEdges[j];
    yCenters[j] = 0.5 * (yEdges[j] + yEdges[j + 1]);
  }

  const zCenters = new Float64Array(nz);
  const dz = new Float64Array(nz);
  for (let k = 0; k < nz; k++) {
    dz[k] = zEdges[k + 1] - zEdges[k];
    zCenters[k] = 0.5 * (zEdges[k] + zEdges[k + 1]);
  }

  const nCells = nx * ny * nz;
  const cellLayerIndex = new Int32Array(nCells);
  const cellRegionType = new Uint8Array(nCells);
  const cellDramDieIndex = new Int16Array(nCells).fill(-1);
  const cellMaterialIds = new Array<string>(nCells);
  const cellKxx = new Float64Array(nCells);
  const cellKyy = new Float64Array(nCells);
  const cellKzz = new Float64Array(nCells);
  const cellKxy = new Float64Array(nCells);
  const cellKxz = new Float64Array(nCells);
  const cellKyz = new Float64Array(nCells);
  const cellRhoCp = new Float64Array(nCells);
  const cellHeatSourceW = new Float64Array(nCells);

  const siMat = getMaterialOrThrow(config.geometry.dramMaterialId);
  const cuMat = getMaterialOrThrow('copper_electroplated');
  const linerMat = getMaterialOrThrow(config.tsv.linerMaterialId);
  const moldMat = getMaterialOrThrow(config.geometry.moldMaterialId);

  const materialCellCounts: Record<string, number> = {};
  const countMat = (id: string) => {
    materialCellCounts[id] = (materialCellCounts[id] ?? 0) + 1;
  };

  // Precompute TSV geometry mask
  const hbmW = geometry.hbmBox.xMax - geometry.hbmBox.xMin;
  const hbmD = geometry.hbmBox.yMax - geometry.hbmBox.yMin;
  const tsvW = hbmW * config.tsv.tsvRegionWidthFraction;
  const tsvD = hbmD * config.tsv.tsvRegionDepthFraction;

  const isInTsvZone = (xc: number, yc: number): boolean => {
    if (
      xc < geometry.hbmBox.xMin ||
      xc > geometry.hbmBox.xMax ||
      yc < geometry.hbmBox.yMin ||
      yc > geometry.hbmBox.yMax
    ) {
      return false;
    }
    if (config.tsv.placement === 'distributed') {
      return true;
    }
    if (config.tsv.placement === 'peripheral_ring') {
      const rx = Math.abs(xc - hbmCenterX) / (hbmW * 0.5);
      const ry = Math.abs(yc - hbmCenterY) / (hbmD * 0.5);
      return rx > 0.72 || ry > 0.72;
    }
    // central_spine
    return (
      Math.abs(xc - hbmCenterX) <= tsvW * 0.5 &&
      Math.abs(yc - hbmCenterY) <= tsvD * 0.5
    );
  };

  const tsvHomogenized = computeHomogenizedTsvProperties(
    config.tsv,
    siMat,
    cuMat,
    linerMat,
    330,
    config.solver.useTempDependentK,
  );

  // Assign cell properties & materials
  for (let k = 0; k < nz; k++) {
    const lIdx = zLayerIndexList[k];
    const layer = geometry.layers[lIdx];
    const layerMat = getMaterialOrThrow(layer.materialId);
    const layerHalfW = layer.widthM * 0.5;
    const layerHalfD = layer.depthM * 0.5;

    for (let j = 0; j < ny; j++) {
      const yc = yCenters[j];
      for (let i = 0; i < nx; i++) {
        const xc = xCenters[i];
        const idx = k * ny * nx + j * nx + i;
        cellLayerIndex[idx] = lIdx;

        const tEst = tempEstimateFieldK ? tempEstimateFieldK[idx] : 325;

        // Check if inside optional Accelerator die
        const acc = geometry.acceleratorBox;
        const inAccel =
          acc !== null &&
          xc >= acc.xMin &&
          xc <= acc.xMax &&
          yc >= acc.yMin &&
          yc <= acc.yMax &&
          zCenters[k] >= acc.zMin &&
          zCenters[k] <= acc.zMax;

        const inLayerFootprint =
          Math.abs(xc - layer.xCenterM) <= layerHalfW &&
          Math.abs(yc - layer.yCenterM) <= layerHalfD;

        if (inAccel) {
          const accMat = getMaterialOrThrow(config.geometry.acceleratorMaterialId);
          const kEval = evaluateMaterialKAtTemp(accMat, tEst, config.solver.useTempDependentK);
          cellRegionType[idx] = 9;
          cellMaterialIds[idx] = accMat.id;
          cellKxx[idx] = kEval.kxx;
          cellKyy[idx] = kEval.kyy;
          cellKzz[idx] = kEval.kzz;
          cellKxy[idx] = kEval.kxy ?? 0;
          cellKxz[idx] = kEval.kxz ?? 0;
          cellKyz[idx] = kEval.kyz ?? 0;
          cellRhoCp[idx] = accMat.densityKgM3 * accMat.specificHeatJKgK;
          countMat(accMat.id);
        } else if (!inLayerFootprint) {
          // Mold compound EMC fills around HBM/interposer outside footprint
          const kMold = evaluateMaterialKAtTemp(moldMat, tEst, config.solver.useTempDependentK);
          cellRegionType[idx] = 0;
          cellMaterialIds[idx] = moldMat.id;
          cellKxx[idx] = kMold.kxx;
          cellKyy[idx] = kMold.kyy;
          cellKzz[idx] = kMold.kzz;
          cellRhoCp[idx] = moldMat.densityKgM3 * moldMat.specificHeatJKgK;
          countMat(moldMat.id);
        } else {
          // Inside layer footprint
          const regionCode =
            layer.kind === 'substrate'
              ? 1
              : layer.kind === 'interposer'
                ? 2
                : layer.kind === 'package_link'
                  ? 3
                  : layer.kind === 'base_die'
                    ? 4
                    : layer.kind === 'bonding'
                      ? 5
                      : layer.kind === 'dram_die'
                        ? 6
                        : layer.kind === 'tim'
                          ? 7
                          : 8;
          cellRegionType[idx] = regionCode;
          if (layer.dramDieIndex !== null) {
            cellDramDieIndex[idx] = layer.dramDieIndex;
          }

          if (layer.hasTsvRegion && isInTsvZone(xc, yc) && config.tsv.cuFraction > 0) {
            if (config.tsv.mode === 'explicit_cutaway') {
              // Discrete Cu TSV cores (~11% area fraction on 3x3 pitch) surrounded by silicon + thin liner effective wall
              const isCuCore = i % 3 === 1 && j % 3 === 1;
              const isLinerAdj = !isCuCore && i % 3 === 1 && j % 3 === 0;
              if (isCuCore) {
                const kEval = evaluateMaterialKAtTemp(cuMat, tEst, config.solver.useTempDependentK);
                cellRegionType[idx] = 10;
                cellMaterialIds[idx] = cuMat.id;
                cellKxx[idx] = kEval.kxx;
                cellKyy[idx] = kEval.kyy;
                cellKzz[idx] = kEval.kzz;
                cellRhoCp[idx] = cuMat.densityKgM3 * cuMat.specificHeatJKgK;
                countMat(cuMat.id);
              } else if (isLinerAdj) {
                // Thin SiO2 liner + Si composite cell around Cu core
                const kSi = evaluateMaterialKAtTemp(layerMat, tEst, config.solver.useTempDependentK);
                const kLin = evaluateMaterialKAtTemp(linerMat, tEst, config.solver.useTempDependentK);
                cellRegionType[idx] = 11;
                cellMaterialIds[idx] = linerMat.id;
                cellKxx[idx] = 2 / (1 / kSi.kxx + 0.15 / kLin.kxx);
                cellKyy[idx] = 2 / (1 / kSi.kyy + 0.15 / kLin.kyy);
                cellKzz[idx] = 0.9 * kSi.kzz + 0.1 * kLin.kzz;
                cellRhoCp[idx] = layerMat.densityKgM3 * layerMat.specificHeatJKgK;
                countMat(linerMat.id);
              } else {
                const kEval = evaluateMaterialKAtTemp(layerMat, tEst, config.solver.useTempDependentK);
                cellMaterialIds[idx] = layerMat.id;
                cellKxx[idx] = kEval.kxx;
                cellKyy[idx] = kEval.kyy;
                cellKzz[idx] = kEval.kzz;
                cellRhoCp[idx] = layerMat.densityKgM3 * layerMat.specificHeatJKgK;
                countMat(layerMat.id);
              }
            } else {
              const tsvEval = computeHomogenizedTsvProperties(
                config.tsv,
                layerMat,
                cuMat,
                linerMat,
                tEst,
                config.solver.useTempDependentK,
              );
              cellMaterialIds[idx] = `${layerMat.id}+tsv`;
              cellKxx[idx] = tsvEval.kxx;
              cellKyy[idx] = tsvEval.kyy;
              cellKzz[idx] = tsvEval.kzz;
              cellRhoCp[idx] = tsvEval.rhoCp;
              countMat(`${layerMat.id}+tsv`);
            }
          } else {
            const kEval = evaluateMaterialKAtTemp(layerMat, tEst, config.solver.useTempDependentK);
            cellMaterialIds[idx] = layerMat.id;
            cellKxx[idx] = kEval.kxx;
            cellKyy[idx] = kEval.kyy;
            cellKzz[idx] = kEval.kzz;
            cellKxy[idx] = kEval.kxy ?? 0;
            cellKxz[idx] = kEval.kxz ?? 0;
            cellKyz[idx] = kEval.kyz ?? 0;
            cellRhoCp[idx] = layerMat.densityKgM3 * layerMat.specificHeatJKgK;
            countMat(layerMat.id);
          }
        }
      }
    }
  }

  // Assign interface contact resistances on Z-faces between distinct physical layers
  const ifaceMap = new Map(config.interfaces.map((iface) => [iface.id, iface]));
  const zInterfaceRContact = new Float64Array(Math.max(0, nz - 1));
  const zInterfaceFaultFactor: Float64Array[] = new Array(Math.max(0, nz - 1));

  for (let k = 0; k < nz - 1; k++) {
    const lBelow = zLayerIndexList[k];
    const lAbove = zLayerIndexList[k + 1];
    if (lBelow !== lAbove) {
      const layerBelow = geometry.layers[lBelow];
      const iface = layerBelow.interfaceAboveId
        ? ifaceMap.get(layerBelow.interfaceAboveId)
        : undefined;
      if (iface && iface.qualityMode !== 'ideal_zero') {
        zInterfaceRContact[k] = iface.rContactAreaM2KW;
        if (
          iface.qualityMode === 'nonuniform_edge_void' ||
          iface.qualityMode === 'partial_delamination_fault'
        ) {
          const factors = new Float64Array(nx * ny);
          const mult =
            iface.qualityMode === 'partial_delamination_fault'
              ? iface.nonuniformFactor ?? 8.0
              : iface.nonuniformFactor ?? 3.5;
          for (let j = 0; j < ny; j++) {
            for (let i = 0; i < nx; i++) {
              const rx = (xCenters[i] - hbmCenterX) / Math.max(hbmHalfW, 1e-9);
              const ry = (yCenters[j] - hbmCenterY) / Math.max(hbmHalfD, 1e-9);
              const rEdge = Math.sqrt(rx * rx + ry * ry);
              factors[j * nx + i] = rEdge > 0.65 ? mult : 1.0;
            }
          }
          zInterfaceFaultFactor[k] = factors;
        }
      }
    }
  }

  // Distribute volumetric heat sources conservatively (Integral q dV = exact target power!)
  assignVolumetricHeatSources(
    config,
    geometry,
    nx,
    ny,
    nz,
    xCenters,
    yCenters,
    dx,
    dy,
    dz,
    cellRegionType,
    cellDramDieIndex,
    cellHeatSourceW,
  );

  // Compute mesh quality & memory stats
  let minDx = Infinity;
  let maxDx = 0;
  for (let i = 0; i < nx; i++) {
    minDx = Math.min(minDx, dx[i]);
    maxDx = Math.max(maxDx, dx[i]);
  }
  let minDy = Infinity;
  let maxDy = 0;
  for (let j = 0; j < ny; j++) {
    minDy = Math.min(minDy, dy[j]);
    maxDy = Math.max(maxDy, dy[j]);
  }
  let minDz = Infinity;
  let maxDz = 0;
  for (let k = 0; k < nz; k++) {
    minDz = Math.min(minDz, dz[k]);
    maxDz = Math.max(maxDz, dz[k]);
  }
  const minDim = Math.min(minDx, minDy, minDz);
  const maxDim = Math.max(maxDx, maxDy, maxDz);
  const maxAspectRatio = maxDim / Math.max(minDim, 1e-12);
  // 7-point CSR (~7 nnz/row * 12 bytes + vectors)
  const estimatedMemoryMb = (nCells * 7 * 16 + nCells * 64) / (1024 * 1024);

  void tsvHomogenized;

  return {
    nx,
    ny,
    nz,
    nCells,
    xEdges,
    yEdges,
    zEdges,
    xCenters,
    yCenters,
    zCenters,
    dx,
    dy,
    dz,
    cellLayerIndex,
    cellRegionType,
    cellDramDieIndex,
    cellMaterialIds,
    cellKxx,
    cellKyy,
    cellKzz,
    cellKxy,
    cellKxz,
    cellKyz,
    cellRhoCp,
    cellHeatSourceW,
    zInterfaceRContact,
    zInterfaceFaultFactor,
    stats: {
      numCells: nCells,
      minDxUm: minDx * 1e6,
      maxDxUm: maxDx * 1e6,
      minDyUm: minDy * 1e6,
      maxDyUm: maxDy * 1e6,
      minDzUm: minDz * 1e6,
      maxDzUm: maxDz * 1e6,
      maxAspectRatio,
      estimatedMemoryMb,
      boundaryFacesCount: 2 * (nx * ny + nx * nz + ny * nz),
      materialCellCounts,
    },
  };
}

export function assignVolumetricHeatSources(
  config: SimulationConfig,
  geometry: BuiltPackageGeometry,
  nx: number,
  ny: number,
  nz: number,
  xCenters: Float64Array,
  yCenters: Float64Array,
  dx: Float64Array,
  dy: Float64Array,
  dz: Float64Array,
  cellRegionType: Uint8Array,
  cellDramDieIndex: Int16Array,
  cellHeatSourceW: Float64Array,
  powerScale?: { dram: number; base: number; accel: number },
  tempFieldK?: Float64Array,
): void {
  cellHeatSourceW.fill(0);
  const hs = config.heatSources;
  const dramScale = powerScale?.dram ?? 1.0;
  const baseScale = powerScale?.base ?? 1.0;
  const accelScale = powerScale?.accel ?? 1.0;

  const hbmXMin = geometry.hbmBox.xMin;
  const hbmW = geometry.hbmBox.xMax - geometry.hbmBox.xMin;
  const hbmYMin = geometry.hbmBox.yMin;
  const hbmD = geometry.hbmBox.yMax - geometry.hbmBox.yMin;

  // Helper to apply electrothermal leakage/throttling multiplier if enabled
  const electrothermalMult = (cellIdx: number): number => {
    if (!hs.electrothermalEnabled || !tempFieldK) return 1.0;
    const T = tempFieldK[cellIdx];
    const leakage = Math.max(0.7, 1.0 + hs.leakageAlphaPerK * (T - 318.15));
    const throttle =
      T > hs.throttleThresholdK
        ? Math.max(0.35, 1.0 - hs.throttleSlopePerK * (T - hs.throttleThresholdK))
        : 1.0;
    return leakage * throttle;
  };

  // Spatial hotspot weight inside HBM footprint
  const hotspotWeightXY = (xc: number, yc: number): number => {
    if (hs.mode !== 'spatial_hotspot' || hs.hotspotPeakRatio <= 1.0) {
      return 1.0;
    }
    const u = (xc - hbmXMin) / Math.max(hbmW, 1e-9);
    const v = (yc - hbmYMin) / Math.max(hbmD, 1e-9);
    const du = u - hs.hotspotCenterNormXY[0];
    const dv = v - hs.hotspotCenterNormXY[1];
    const sig2 = Math.max(hs.hotspotSigmaNorm, 0.08) ** 2;
    const gauss = Math.exp(-(du * du + dv * dv) / (2 * sig2));
    return 1.0 + (hs.hotspotPeakRatio - 1.0) * gauss;
  };

  // 1. DRAM dies (strictly normalized per die so Integral(q dV) == P_die)
  for (let d = 0; d < geometry.dramDieCount; d++) {
    const targetP = (hs.dramPowersW[d] ?? 0) * dramScale;
    if (targetP <= 0) continue;

    let weightVolSum = 0;
    const cellIndices: number[] = [];
    const cellWeights: number[] = [];

    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const idx = k * ny * nx + j * nx + i;
          if (cellDramDieIndex[idx] === d) {
            const vol = dx[i] * dy[j] * dz[k];
            const w = hotspotWeightXY(xCenters[i], yCenters[j]) * electrothermalMult(idx);
            cellIndices.push(idx);
            cellWeights.push(w * vol);
            weightVolSum += w * vol;
          }
        }
      }
    }
    if (weightVolSum > 0) {
      for (let m = 0; m < cellIndices.length; m++) {
        cellHeatSourceW[cellIndices[m]] += targetP * (cellWeights[m] / weightVolSum);
      }
    }
  }

  // 2. Logic Base Die + PHY (PHY concentrated near HBM edge / central spine)
  const targetBaseP = (hs.baseDiePowerW + hs.phyPowerW) * baseScale;
  if (targetBaseP > 0) {
    let weightVolSum = 0;
    const cellIndices: number[] = [];
    const cellWeights: number[] = [];
    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const idx = k * ny * nx + j * nx + i;
          if (cellRegionType[idx] === 4) {
            const vol = dx[i] * dy[j] * dz[k];
            // If PHY power is present, weight PHY side slightly higher
            const u = (xCenters[i] - hbmXMin) / Math.max(hbmW, 1e-9);
            const phyBoost = hs.phyPowerW > 0 && u > 0.65 ? 1.5 : 1.0;
            const w = phyBoost * hotspotWeightXY(xCenters[i], yCenters[j]) * electrothermalMult(idx);
            cellIndices.push(idx);
            cellWeights.push(w * vol);
            weightVolSum += w * vol;
          }
        }
      }
    }
    if (weightVolSum > 0) {
      for (let m = 0; m < cellIndices.length; m++) {
        cellHeatSourceW[cellIndices[m]] += targetBaseP * (cellWeights[m] / weightVolSum);
      }
    }
  }

  // 3. Optional Accelerator die (non-uniform hotspot map unless disabled)
  if (geometry.acceleratorBox && hs.acceleratorPowerW > 0) {
    const acc = geometry.acceleratorBox;
    const accW = acc.xMax - acc.xMin;
    const accD = acc.yMax - acc.yMin;
    const targetAccP = hs.acceleratorPowerW * accelScale;
    let weightVolSum = 0;
    const cellIndices: number[] = [];
    const cellWeights: number[] = [];

    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const idx = k * ny * nx + j * nx + i;
          if (cellRegionType[idx] === 9) {
            const vol = dx[i] * dy[j] * dz[k];
            let spatialW = 1.0;
            if (hs.acceleratorHotspotMap) {
              const u = (xCenters[i] - acc.xMin) / Math.max(accW, 1e-9);
              const v = (yCenters[j] - acc.yMin) / Math.max(accD, 1e-9);
              // Dual tensor-core hotspot clusters on accelerator die
              const g1 = Math.exp(-(((u - 0.32) ** 2 + (v - 0.48) ** 2) / 0.045));
              const g2 = Math.exp(-(((u - 0.68) ** 2 + (v - 0.55) ** 2) / 0.05));
              spatialW = 0.65 + 1.2 * (g1 + g2);
            }
            const w = spatialW * electrothermalMult(idx);
            cellIndices.push(idx);
            cellWeights.push(w * vol);
            weightVolSum += w * vol;
          }
        }
      }
    }
    if (weightVolSum > 0) {
      for (let m = 0; m < cellIndices.length; m++) {
        cellHeatSourceW[cellIndices[m]] += targetAccP * (cellWeights[m] / weightVolSum);
      }
    }
  }
}
