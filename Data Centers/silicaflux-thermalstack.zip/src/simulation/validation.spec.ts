import { describe, expect, it } from 'vitest';
import {
  compareCoolingStrategies,
  compareStackHeights,
  runParameterSweep,
  runParetoOptimisation,
  runSimulation,
  runUncertaintyStudy,
} from './analysis';
import { EXPERIMENTS_CATALOG } from './experiments';
import { createPresetConfig } from './geometry';
import { runAllValidationTests } from './validation';

describe('SilicaFlux ThermalStack — 20 Mandatory Numerical & Analytical Validation Tests', () => {
  const outcomes = runAllValidationTests();

  for (const outcome of outcomes) {
    it(`${outcome.testId}: ${outcome.title}`, () => {
      expect(outcome.passed, `${outcome.details} (err=${outcome.relativeError})`).toBe(true);
    });
  }
});

describe('SilicaFlux ThermalStack — Experiments A–J & Engineering Studies', () => {
  it('runs Experiments A-J with global energy balance < 0.05%', () => {
    for (const exp of EXPERIMENTS_CATALOG) {
      const cfg = exp.buildConfig();
      const res = runSimulation(`test-${exp.id}`, cfg);
      expect(res.diagnostics.converged).toBe(true);
      expect(res.diagnostics.energyBalanceErrorPct).toBeLessThan(0.05);
      expect(res.summary.peakTempC).toBeGreaterThan(25);
    }
  }, 30000);

  it('executes controlled 8H/12H/16H Mode A and Mode B comparisons', () => {
    const base = createPresetConfig('HBM-12H');
    const cmp = compareStackHeights(base, 28.0, 2.2);
    expect(cmp.modeAEqualTotalPower.results).toHaveLength(3);
    expect(cmp.modeBEqualPerDiePower.results).toHaveLength(3);
    // In Mode B (equal power per die), 16H has 2x DRAM power of 8H -> higher peak temp
    const t8B = cmp.modeBEqualPerDiePower.results[0].peakTempC;
    const t16B = cmp.modeBEqualPerDiePower.results[2].peakTempC;
    expect(t16B).toBeGreaterThan(t8B);
  }, 15000);

  it('runs cooling comparison, parameter sweep, uncertainty study, and Pareto optimisation', () => {
    const base = createPresetConfig('HBM-12H');
    const cooling = compareCoolingStrategies(base);
    expect(cooling.length).toBeGreaterThanOrEqual(5);
    expect(cooling[0].peakTempC).toBeGreaterThan(cooling[cooling.length - 1].peakTempC);

    const sweep = runParameterSweep(base, 'contact_resistance_mm2kw', [2, 8, 16]);
    expect(sweep[2].peakTempC).toBeGreaterThan(sweep[0].peakTempC);

    const unc = runUncertaintyStudy(base);
    expect(unc.samplesCount).toBe(24);
    expect(unc.p95PeakTempC).toBeGreaterThanOrEqual(unc.p05PeakTempC);

    const opt = runParetoOptimisation(base, {
      maxPackageHeightMm: 3.0,
      maxTsvFraction: 0.16,
      maxCoolingH: 8000,
    });
    expect(opt.candidates.length).toBeGreaterThan(0);
    expect(opt.optimal.isParetoOptimal).toBe(true);
  }, 60000);
});
