export type StackPresetId = 'HBM-8H' | 'HBM-12H' | 'HBM-16H';

export type StudyType = 'steady_state' | 'transient';

export type CoolingMode =
  | 'natural_convection'
  | 'forced_air'
  | 'cold_plate'
  | 'liquid_microchannel'
  | 'dual_sided'
  | 'fixed_temp_idealized';

export type SpreaderPreset =
  | 'conventional_cu'
  | 'thick_cu'
  | 'alsic_composite'
  | 'extended_cu'
  | 'diamond_cu_bridge'
  | 'integrated_cold_plate';

export type TsvFidelityMode = 'homogenized' | 'explicit_cutaway';

export type TsvPlacement = 'central_spine' | 'distributed' | 'peripheral_ring';

export type InterfaceQualityMode =
  | 'nominal'
  | 'degraded_2x'
  | 'nonuniform_edge_void'
  | 'partial_delamination_fault'
  | 'ideal_zero';

export type HeatSourceMode =
  | 'uniform'
  | 'per_die'
  | 'spatial_hotspot'
  | 'workload_trace';

export type WorkloadScenario =
  | 'sustained_read'
  | 'sustained_write'
  | 'mixed_traffic'
  | 'tensor_hbw'
  | 'burst_activity'
  | 'refresh_dominated'
  | 'uneven_die_activity'
  | 'idle';

export interface ConductivityTensor {
  kxx: number;
  kyy: number;
  kzz: number;
  kxy?: number;
  kxz?: number;
  kyz?: number;
}

export interface TempDependenceModel {
  model: 'constant' | 'power_law' | 'linear';
  tRefK: number;
  exponent?: number; // k(T) = kRef * (T / tRef)^exponent
  betaPerK?: number; // k(T) = kRef * (1 + beta * (T - tRef))
}

export interface MaterialRecord {
  id: string;
  version: string;
  name: string;
  category:
    | 'semiconductor'
    | 'metal'
    | 'dielectric'
    | 'polymer_bond'
    | 'tim'
    | 'spreader'
    | 'composite_effective';
  densityKgM3: number;
  specificHeatJKgK: number;
  conductivity: ConductivityTensor;
  tempDependence?: TempDependenceModel;
  validTempRangeK: [number, number];
  uncertaintyPct: number;
  source: string;
  notes: string;
}

export interface InterfaceSpec {
  id: string;
  name: string;
  layerBelow: string;
  layerAbove: string;
  rContactAreaM2KW: number; // m^2*K/W
  qualityMode: InterfaceQualityMode;
  assumedFaultModel: boolean;
  nonuniformFactor?: number;
  notes: string;
}

export interface TsvConfig {
  mode: TsvFidelityMode;
  cuFraction: number; // 0.0 - 0.35
  tsvDiameterUm: number;
  tsvPitchUm: number;
  linerThicknessUm: number;
  linerMaterialId: string;
  placement: TsvPlacement;
  tsvRegionWidthFraction: number; // fraction of die X width occupied by TSV spine/array
  tsvRegionDepthFraction: number; // fraction of die Y depth
}

export interface LayerOverride {
  dramDieIndex: number; // 0..N-1 (0 is bottom-most DRAM die closest to logic base)
  thicknessUm?: number;
  materialId?: string;
  bondThicknessUm?: number;
  bondMaterialId?: string;
}

export interface GeometryConfig {
  stackPreset: StackPresetId;
  dramDieCount: 8 | 12 | 16;
  dieWidthMm: number;
  dieDepthMm: number;
  dramDieThicknessUm: number;
  bondingThicknessUm: number;
  baseDieThicknessUm: number;
  basePackageLinkThicknessUm: number;
  interposerThicknessUm: number;
  substrateThicknessUm: number;
  timThicknessUm: number;
  spreaderThicknessUm: number;
  spreaderWidthMm: number;
  spreaderDepthMm: number;
  moldOverhangMm: number;
  microbumpMetalFraction: number;
  // Materials
  dramMaterialId: string;
  bondingMaterialId: string;
  underfillMaterialId: string;
  baseDieMaterialId: string;
  interposerMaterialId: string;
  substrateMaterialId: string;
  timMaterialId: string;
  spreaderMaterialId: string;
  moldMaterialId: string;
  layerOverrides: LayerOverride[];
  // Optional neighbouring SilicaFlux-HPC Accelerator die
  includeAccelerator: boolean;
  acceleratorWidthMm: number;
  acceleratorDepthMm: number;
  acceleratorThicknessUm: number;
  acceleratorGapMm: number;
  acceleratorMaterialId: string;
}

export interface HeatSourceConfig {
  mode: HeatSourceMode;
  workload: WorkloadScenario;
  dramPowersW: number[]; // length == dramDieCount
  baseDiePowerW: number;
  phyPowerW: number;
  acceleratorPowerW: number;
  hotspotPeakRatio: number; // 1.0 = uniform in-plane, >1.0 = localized quadrant/hotspot concentration
  hotspotCenterNormXY: [number, number]; // [0..1, 0..1]
  hotspotSigmaNorm: number;
  acceleratorHotspotMap: boolean;
  electrothermalEnabled: boolean;
  leakageAlphaPerK: number; // illustrative temperature-dependent leakage coefficient
  throttleThresholdK: number;
  throttleSlopePerK: number;
  timeTrace?: {
    timesS: number[];
    dramScale: number[];
    baseScale: number[];
    accelScale: number[];
  };
}

export interface CoolingConfig {
  mode: CoolingMode;
  spreaderPreset: SpreaderPreset;
  tAmbientK: number;
  hTopWm2K: number;
  hBottomWm2K: number;
  hSideWm2K: number;
  fixedTopTempK?: number;
  radiationEmissivity: number;
  enableRadiation: boolean;
}

export interface MeshConfig {
  nx: number;
  ny: number;
  nzPerDramDie: number;
  nzPerBond: number;
  nzBaseDie: number;
  nzInterposer: number;
  nzTim: number;
  nzSpreader: number;
  nonuniformXY: boolean;
  refinementFactor: number;
}

export interface SolverConfig {
  studyType: StudyType;
  relativeTolerance: number;
  maxIterations: number;
  useTempDependentK: boolean;
  nonlinearUnderRelaxation: number;
  nonlinearMaxIters: number;
  timeIntegration: 'backward_euler' | 'crank_nicolson';
  dtSeconds: number;
  totalTimeSeconds: number;
  initialTempK: number;
  hotspotThresholdK: number;
}

export interface SimulationConfig {
  project: string;
  experimentId: string;
  description: string;
  geometry: GeometryConfig;
  tsv: TsvConfig;
  interfaces: InterfaceSpec[];
  heatSources: HeatSourceConfig;
  cooling: CoolingConfig;
  mesh: MeshConfig;
  solver: SolverConfig;
}

export interface LayerGeometryRegion {
  id: string;
  name: string;
  kind:
    | 'substrate'
    | 'interposer'
    | 'package_link'
    | 'base_die'
    | 'bonding'
    | 'dram_die'
    | 'tim'
    | 'heat_spreader';
  dramDieIndex: number | null; // null for non-DRAM layers (base_die is never counted as DRAM!)
  zMinM: number;
  zMaxM: number;
  thicknessM: number;
  widthM: number;
  depthM: number;
  materialId: string;
  xCenterM: number;
  yCenterM: number;
  hasTsvRegion: boolean;
  interfaceAboveId?: string;
}

export interface BuiltPackageGeometry {
  stackPreset: StackPresetId;
  dramDieCount: number;
  totalHeightM: number;
  domainWidthM: number;
  domainDepthM: number;
  hbmBox: { xMin: number; xMax: number; yMin: number; yMax: number; zMin: number; zMax: number };
  acceleratorBox: {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
    zMin: number;
    zMax: number;
  } | null;
  layers: LayerGeometryRegion[];
  notes: string[];
}

export interface Mesh3D {
  nx: number;
  ny: number;
  nz: number;
  nCells: number;
  xEdges: Float64Array;
  yEdges: Float64Array;
  zEdges: Float64Array;
  xCenters: Float64Array;
  yCenters: Float64Array;
  zCenters: Float64Array;
  dx: Float64Array;
  dy: Float64Array;
  dz: Float64Array;
  cellLayerIndex: Int32Array;
  cellRegionType: Uint8Array; // 0=ambient/mold, 1=substrate, 2=interposer, 3=pkg_link, 4=base_die, 5=bond, 6=dram, 7=tim, 8=spreader, 9=accelerator, 10=tsv_cu, 11=tsv_liner
  cellDramDieIndex: Int16Array; // -1 if not a DRAM die
  cellMaterialIds: string[];
  cellKxx: Float64Array;
  cellKyy: Float64Array;
  cellKzz: Float64Array;
  cellKxy: Float64Array;
  cellKxz: Float64Array;
  cellKyz: Float64Array;
  cellRhoCp: Float64Array;
  cellHeatSourceW: Float64Array; // total Watts in cell (q_vol * V_cell)
  zInterfaceRContact: Float64Array; // length nz-1, contact resistance on top face of k
  zInterfaceFaultFactor: Float64Array[]; // optional spatially varying contact factor
  stats: {
    numCells: number;
    minDxUm: number;
    maxDxUm: number;
    minDyUm: number;
    maxDyUm: number;
    minDzUm: number;
    maxDzUm: number;
    maxAspectRatio: number;
    estimatedMemoryMb: number;
    boundaryFacesCount: number;
    materialCellCounts: Record<string, number>;
  };
}

export interface LayerThermalSummary {
  layerId: string;
  name: string;
  kind: LayerGeometryRegion['kind'];
  dramDieIndex: number | null;
  zCenterUm: number;
  thicknessUm: number;
  materialName: string;
  powerW: number;
  minTempK: number;
  avgTempK: number;
  maxTempK: number;
  inPlaneGradientKPerMm: number;
  throughPlaneGradientKPerMm: number;
}

export interface HotspotReport {
  positionMm: [number, number, number];
  cellIndices: [number, number, number];
  associatedRegion: string;
  associatedDramDieIndex: number | null;
  peakTempK: number;
  peakTempC: number;
  localGradientKPerMm: number;
  volumeAboveThresholdMm3: number;
  thresholdK: number;
  distanceToCoolingMm: number;
  nearestInterfaceName: string;
  nearestInterfaceDistanceUm: number;
}

export interface ResistanceContribution {
  component: string;
  deltaTK: number;
  effectiveRKPerW: number;
  fractionPct: number;
  note: string;
}

export interface SolverDiagnostics {
  method: string;
  matrixSize: number;
  nnz: number;
  residualNorm: number;
  tolerance: number;
  iterations: number;
  nonlinearIterations: number;
  assemblyTimeMs: number;
  solveTimeMs: number;
  totalHeatGenW: number;
  totalHeatRejectionW: number;
  storedEnergyRateW: number;
  energyBalanceErrorPct: number;
  boundaryHeatFluxW: {
    top: number;
    bottom: number;
    west: number;
    east: number;
    south: number;
    north: number;
  };
  converged: boolean;
  failureReason?: string;
}

export interface TransientStepSnapshot {
  timeS: number;
  peakTempK: number;
  avgDramTempK: number;
  baseDieTempK: number;
  accelPeakTempK: number | null;
  totalPowerW: number;
  heatRejectedW: number;
  energyBalanceErrorPct: number;
  hotspotMm: [number, number, number];
  perDramMaxTempK: number[];
  // Downsampled or full 3D slice temperatures for playback
  xzMidSliceK: number[][]; // [nz][nx]
  xyHotSliceK: number[][]; // [ny][nx]
}

export interface SimulationResult {
  jobId: string;
  timestampIso: string;
  config: SimulationConfig;
  geometry: BuiltPackageGeometry;
  meshStats: Mesh3D['stats'];
  diagnostics: SolverDiagnostics;
  summary: {
    peakTempK: number;
    peakTempC: number;
    minTempK: number;
    avgTempK: number;
    peakDramTempK: number;
    avgDramTempK: number;
    baseDieAvgTempK: number;
    baseDieMaxTempK: number;
    topToBottomDeltaK: number;
    dieToDieDeltaK: number;
    acceleratorPeakTempK: number | null;
    effectiveRthTotalKPerW: number;
    maxThroughPlaneGradientKPerMm: number;
    maxInPlaneGradientKPerMm: number;
  };
  layers: LayerThermalSummary[];
  hotspot: HotspotReport;
  resistanceBreakdown: ResistanceContribution[];
  reliabilityScreening: {
    throughPlaneGradKPerMm: number;
    inPlaneGradKPerMm: number;
    dieToDieDeltaK: number;
    transientHeatingRateKPerS: number | null;
    cycleAmplitudeK: number | null;
    disclaimer: string;
    structuralExtensionSchema: {
      requiredInputs: string[];
      expectedOutputs: string[];
      status: string;
    };
  };
  // Compact 3D field payload for Three.js & slice heatmaps
  field3D: {
    nx: number;
    ny: number;
    nz: number;
    xCentersMm: number[];
    yCentersMm: number[];
    zCentersMm: number[];
    temperaturesK: number[]; // flattened k * ny * nx + j * nx + i
    gradMagKPerMm: number[];
    fluxVectorsSample: {
      xMm: number;
      yMm: number;
      zMm: number;
      qx: number;
      qy: number;
      qz: number;
    }[];
  };
  transient?: {
    steps: TransientStepSnapshot[];
    estimatedTimeConstantS: number;
    maxTempInIntervalK: number;
  };
  disclaimers: string[];
}

export interface ValidationTestOutcome {
  testId: string;
  title: string;
  passed: boolean;
  metricName: string;
  computedValue: number;
  referenceValue: number;
  relativeError: number;
  tolerance: number;
  details: string;
}
