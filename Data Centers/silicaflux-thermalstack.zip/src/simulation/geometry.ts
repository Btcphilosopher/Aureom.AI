import { getMaterialOrThrow, validateConductivityTensor } from './materials';
import {
  BuiltPackageGeometry,
  CoolingConfig,
  GeometryConfig,
  InterfaceSpec,
  LayerGeometryRegion,
  SimulationConfig,
  SpreaderPreset,
  StackPresetId,
} from './types';

export function buildPackageGeometry(
  config: SimulationConfig,
  hasBoundaryOverrides = false,
): BuiltPackageGeometry {
  const g = config.geometry;
  validateSimulationConfig(config, hasBoundaryOverrides);

  const umToM = 1e-6;
  const mmToM = 1e-3;

  const layers: LayerGeometryRegion[] = [];
  let zCursor = 0;

  const dieW = g.dieWidthMm * mmToM;
  const dieD = g.dieDepthMm * mmToM;
  const accelW = g.includeAccelerator ? g.acceleratorWidthMm * mmToM : 0;
  const accelD = g.includeAccelerator ? g.acceleratorDepthMm * mmToM : 0;
  const accelGap = g.includeAccelerator ? g.acceleratorGapMm * mmToM : 0;

  // Center HBM & optional Accelerator side-by-side along X
  const totalFootprintW = g.includeAccelerator
    ? dieW + accelGap + accelW + 2 * g.moldOverhangMm * mmToM
    : dieW + 2 * g.moldOverhangMm * mmToM;
  const totalFootprintD =
    Math.max(dieD, accelD) + 2 * g.moldOverhangMm * mmToM;

  const domainWidthM = Math.max(g.spreaderWidthMm * mmToM, totalFootprintW);
  const domainDepthM = Math.max(g.spreaderDepthMm * mmToM, totalFootprintD);

  const hbmXCenter = g.includeAccelerator
    ? domainWidthM * 0.5 - (accelGap + accelW) * 0.5
    : domainWidthM * 0.5;
  const hbmYCenter = domainDepthM * 0.5;

  const pushLayer = (
    partial: Omit<LayerGeometryRegion, 'zMinM' | 'zMaxM'>,
  ) => {
    const zMinM = zCursor;
    const zMaxM = zCursor + partial.thicknessM;
    layers.push({
      ...partial,
      zMinM,
      zMaxM,
    });
    zCursor = zMaxM;
  };

  // 1. Organic package substrate (bottom)
  pushLayer({
    id: 'substrate',
    name: 'Organic Package Substrate',
    kind: 'substrate',
    dramDieIndex: null,
    thicknessM: g.substrateThicknessUm * umToM,
    widthM: domainWidthM,
    depthM: domainDepthM,
    materialId: g.substrateMaterialId,
    xCenterM: domainWidthM * 0.5,
    yCenterM: domainDepthM * 0.5,
    hasTsvRegion: false,
    interfaceAboveId: 'substrate_to_interposer',
  });

  // 2. Silicon Interposer
  pushLayer({
    id: 'interposer',
    name: 'Silicon Interposer (2.5D)',
    kind: 'interposer',
    dramDieIndex: null,
    thicknessM: g.interposerThicknessUm * umToM,
    widthM: domainWidthM - g.moldOverhangMm * mmToM,
    depthM: domainDepthM - g.moldOverhangMm * mmToM,
    materialId: g.interposerMaterialId,
    xCenterM: domainWidthM * 0.5,
    yCenterM: domainDepthM * 0.5,
    hasTsvRegion: true,
    interfaceAboveId: 'base_to_interposer',
  });

  // 3. Package-level connection layer (C4/microbump + underfill between interposer & base die)
  pushLayer({
    id: 'package_link',
    name: 'Base-to-Interposer Microbump + Underfill',
    kind: 'package_link',
    dramDieIndex: null,
    thicknessM: g.basePackageLinkThicknessUm * umToM,
    widthM: dieW,
    depthM: dieD,
    materialId: g.underfillMaterialId,
    xCenterM: hbmXCenter,
    yCenterM: hbmYCenter,
    hasTsvRegion: false,
    interfaceAboveId: 'link_to_base_die',
  });

  // 4. Logic Base Die (explicitly NOT counted as a DRAM die)
  const hbmZStart = zCursor;
  pushLayer({
    id: 'base_die',
    name: 'Logic Base Die (Buffer / PHY)',
    kind: 'base_die',
    dramDieIndex: null,
    thicknessM: g.baseDieThicknessUm * umToM,
    widthM: dieW,
    depthM: dieD,
    materialId: g.baseDieMaterialId,
    xCenterM: hbmXCenter,
    yCenterM: hbmYCenter,
    hasTsvRegion: true,
    interfaceAboveId: 'base_to_bond_0',
  });

  // 5. DRAM Stack: N pairs of [Bonding Layer + DRAM Silicon Die]
  const overrideMap = new Map(g.layerOverrides.map((o) => [o.dramDieIndex, o]));
  for (let d = 0; d < g.dramDieCount; d++) {
    const ov = overrideMap.get(d);
    const bondThickUm = ov?.bondThicknessUm ?? g.bondingThicknessUm;
    const bondMatId = ov?.bondMaterialId ?? g.bondingMaterialId;
    const dieThickUm = ov?.thicknessUm ?? g.dramDieThicknessUm;
    const dieMatId = ov?.materialId ?? g.dramMaterialId;

    pushLayer({
      id: `bond_${d}`,
      name: `Bonding Layer ${d} (${d === 0 ? 'Base→DRAM0' : `DRAM${d - 1}→DRAM${d}`})`,
      kind: 'bonding',
      dramDieIndex: null,
      thicknessM: bondThickUm * umToM,
      widthM: dieW,
      depthM: dieD,
      materialId: bondMatId,
      xCenterM: hbmXCenter,
      yCenterM: hbmYCenter,
      hasTsvRegion: false,
      interfaceAboveId: 'die_to_bond',
    });

    pushLayer({
      id: `dram_${d}`,
      name: `DRAM Die ${d}`,
      kind: 'dram_die',
      dramDieIndex: d,
      thicknessM: dieThickUm * umToM,
      widthM: dieW,
      depthM: dieD,
      materialId: dieMatId,
      xCenterM: hbmXCenter,
      yCenterM: hbmYCenter,
      hasTsvRegion: d < g.dramDieCount - 1, // top DRAM die often lacks through-TSVs
      interfaceAboveId:
        d === g.dramDieCount - 1 ? 'die_to_tim' : 'die_to_bond',
    });
  }
  const hbmZEnd = zCursor;

  // 6. Thermal Interface Material (TIM1)
  pushLayer({
    id: 'tim1',
    name: 'Thermal Interface Material (TIM1)',
    kind: 'tim',
    dramDieIndex: null,
    thicknessM: g.timThicknessUm * umToM,
    widthM: g.includeAccelerator ? domainWidthM - g.moldOverhangMm * mmToM : dieW,
    depthM: g.includeAccelerator ? domainDepthM - g.moldOverhangMm * mmToM : dieD,
    materialId: g.timMaterialId,
    xCenterM: g.includeAccelerator ? domainWidthM * 0.5 : hbmXCenter,
    yCenterM: domainDepthM * 0.5,
    hasTsvRegion: false,
    interfaceAboveId: 'tim_to_spreader',
  });

  // 7. Heat Spreader / Cold Plate Lid
  pushLayer({
    id: 'heat_spreader',
    name: 'Integrated Heat Spreader (IHS)',
    kind: 'heat_spreader',
    dramDieIndex: null,
    thicknessM: g.spreaderThicknessUm * umToM,
    widthM: g.spreaderWidthMm * mmToM,
    depthM: g.spreaderDepthMm * mmToM,
    materialId: g.spreaderMaterialId,
    xCenterM: domainWidthM * 0.5,
    yCenterM: domainDepthM * 0.5,
    hasTsvRegion: false,
    interfaceAboveId: 'spreader_to_cooler',
  });

  const hbmBox = {
    xMin: hbmXCenter - dieW * 0.5,
    xMax: hbmXCenter + dieW * 0.5,
    yMin: hbmYCenter - dieD * 0.5,
    yMax: hbmYCenter + dieD * 0.5,
    zMin: hbmZStart,
    zMax: hbmZEnd,
  };

  let acceleratorBox: BuiltPackageGeometry['acceleratorBox'] = null;
  if (g.includeAccelerator) {
    const accXCenter = hbmBox.xMax + accelGap + accelW * 0.5;
    const accYCenter = domainDepthM * 0.5;
    const accZMin = hbmZStart;
    const accZMax = Math.min(
      hbmZEnd,
      accZMin + g.acceleratorThicknessUm * umToM,
    );
    acceleratorBox = {
      xMin: accXCenter - accelW * 0.5,
      xMax: accXCenter + accelW * 0.5,
      yMin: accYCenter - accelD * 0.5,
      yMax: accYCenter + accelD * 0.5,
      zMin: accZMin,
      zMax: accZMax,
    };
  }

  return {
    stackPreset: g.stackPreset,
    dramDieCount: g.dramDieCount,
    totalHeightM: zCursor,
    domainWidthM,
    domainDepthM,
    hbmBox,
    acceleratorBox,
    layers,
    notes: [
      `Coordinate convention: X = package width (${(domainWidthM * 1e3).toFixed(2)} mm), Y = package depth (${(domainDepthM * 1e3).toFixed(2)} mm), Z = vertical stack height (${(zCursor * 1e3).toFixed(3)} mm).`,
      `Convention: Logic Base Die is modeled separately and NEVER counted in the ${g.dramDieCount} DRAM dies.`,
      `Dimensions represent documented illustrative engineering geometry profiles; supply vendor CAD/JEDEC dimensions for production sign-off.`,
    ],
  };
}

export function validateSimulationConfig(
  config: SimulationConfig,
  hasBoundaryOverrides = false,
): void {
  const g = config.geometry;
  if (![8, 12, 16].includes(g.dramDieCount)) {
    throw new Error(`Invalid dramDieCount (${g.dramDieCount}); must be 8, 12, or 16.`);
  }
  const positiveDims: [string, number][] = [
    ['dieWidthMm', g.dieWidthMm],
    ['dieDepthMm', g.dieDepthMm],
    ['dramDieThicknessUm', g.dramDieThicknessUm],
    ['bondingThicknessUm', g.bondingThicknessUm],
    ['baseDieThicknessUm', g.baseDieThicknessUm],
    ['basePackageLinkThicknessUm', g.basePackageLinkThicknessUm],
    ['interposerThicknessUm', g.interposerThicknessUm],
    ['substrateThicknessUm', g.substrateThicknessUm],
    ['timThicknessUm', g.timThicknessUm],
    ['spreaderThicknessUm', g.spreaderThicknessUm],
    ['spreaderWidthMm', g.spreaderWidthMm],
    ['spreaderDepthMm', g.spreaderDepthMm],
  ];
  for (const [key, val] of positiveDims) {
    if (!Number.isFinite(val) || val <= 0) {
      throw new Error(`Geometry dimension "${key}" must be strictly positive (got ${val}).`);
    }
  }
  if (g.spreaderWidthMm < g.dieWidthMm || g.spreaderDepthMm < g.dieDepthMm) {
    throw new Error('Heat spreader footprint cannot be smaller than the HBM die footprint.');
  }

  // Validate materials
  const matIds = [
    g.dramMaterialId,
    g.bondingMaterialId,
    g.underfillMaterialId,
    g.baseDieMaterialId,
    g.interposerMaterialId,
    g.substrateMaterialId,
    g.timMaterialId,
    g.spreaderMaterialId,
    g.moldMaterialId,
    config.tsv.linerMaterialId,
  ];
  if (g.includeAccelerator) {
    matIds.push(g.acceleratorMaterialId);
  }
  for (const id of matIds) {
    const mat = getMaterialOrThrow(id);
    if (mat.densityKgM3 <= 0 || mat.specificHeatJKgK <= 0) {
      throw new Error(`Material "${id}" has non-physical density or specific heat.`);
    }
    validateConductivityTensor(mat.conductivity, mat.name);
  }

  // Validate TSV parameters
  if (config.tsv.cuFraction < 0 || config.tsv.cuFraction > 0.45) {
    throw new Error(`TSV Cu volume fraction (${config.tsv.cuFraction}) out of physical range [0, 0.45].`);
  }

  // Validate heat sources
  if (config.heatSources.dramPowersW.length !== g.dramDieCount) {
    throw new Error(
      `dramPowersW length (${config.heatSources.dramPowersW.length}) must match dramDieCount (${g.dramDieCount}).`,
    );
  }
  for (const p of config.heatSources.dramPowersW) {
    if (!Number.isFinite(p) || p < 0) {
      throw new Error(`Negative or non-finite DRAM power input (${p} W).`);
    }
  }
  if (config.heatSources.baseDiePowerW < 0 || config.heatSources.phyPowerW < 0) {
    throw new Error('Base die and PHY power inputs cannot be negative.');
  }

  // Validate cooling / boundary conditions (reject thermally unconstrained steady state!)
  const c = config.cooling;
  if (c.tAmbientK < 150 || c.tAmbientK > 450) {
    throw new Error(`Ambient/coolant temperature (${c.tAmbientK} K) out of admissible range [150, 450] K.`);
  }
  if (c.hTopWm2K < 0 || c.hBottomWm2K < 0 || c.hSideWm2K < 0) {
    throw new Error('Heat-transfer coefficients h cannot be negative.');
  }
  const hasCoolingSink =
    c.mode === 'fixed_temp_idealized' ||
    c.hTopWm2K > 0 ||
    c.hBottomWm2K > 0 ||
    c.hSideWm2K > 0;
  const totalPower =
    config.heatSources.dramPowersW.reduce((a, b) => a + b, 0) +
    config.heatSources.baseDiePowerW +
    config.heatSources.phyPowerW +
    (g.includeAccelerator ? config.heatSources.acceleratorPowerW : 0);

  if (
    !hasBoundaryOverrides &&
    config.solver.studyType === 'steady_state' &&
    !hasCoolingSink &&
    totalPower > 0
  ) {
    throw new Error(
      'Thermally unconstrained steady-state model rejected: all boundaries are adiabatic (h=0) with positive heat generation.',
    );
  }

  // Validate interfaces
  for (const iface of config.interfaces) {
    if (!Number.isFinite(iface.rContactAreaM2KW) || iface.rContactAreaM2KW < 0) {
      throw new Error(`Interface "${iface.id}" has invalid negative contact resistance.`);
    }
  }

  // Validate mesh
  if (config.mesh.nx < 3 || config.mesh.ny < 3) {
    throw new Error('Mesh nx and ny must be >= 3.');
  }
  if (config.mesh.nx * config.mesh.ny > 3600) {
    throw new Error('In-plane mesh resolution exceeds resource safety cap (nx * ny <= 3600).');
  }
}

export function applySpreaderPreset(
  geom: GeometryConfig,
  preset: SpreaderPreset,
): GeometryConfig {
  const next = { ...geom };
  switch (preset) {
    case 'conventional_cu':
      next.spreaderMaterialId = 'spreader_copper';
      next.spreaderThicknessUm = 1000;
      break;
    case 'thick_cu':
      next.spreaderMaterialId = 'spreader_copper';
      next.spreaderThicknessUm = 2200;
      break;
    case 'alsic_composite':
      next.spreaderMaterialId = 'spreader_alsic';
      next.spreaderThicknessUm = 1200;
      break;
    case 'extended_cu':
      next.spreaderMaterialId = 'spreader_copper';
      next.spreaderThicknessUm = 1400;
      next.spreaderWidthMm = Math.max(geom.spreaderWidthMm, 26);
      next.spreaderDepthMm = Math.max(geom.spreaderDepthMm, 26);
      break;
    case 'diamond_cu_bridge':
      next.spreaderMaterialId = 'spreader_diamond_cu';
      next.spreaderThicknessUm = 1200;
      break;
    case 'integrated_cold_plate':
      next.spreaderMaterialId = 'spreader_copper';
      next.spreaderThicknessUm = 1800;
      break;
  }
  return next;
}

export function applyCoolingPreset(
  cooling: CoolingConfig,
  mode: CoolingConfig['mode'],
): CoolingConfig {
  const next = { ...cooling, mode };
  switch (mode) {
    case 'natural_convection':
      next.hTopWm2K = 18;
      next.hBottomWm2K = 5;
      next.hSideWm2K = 5;
      break;
    case 'forced_air':
      next.hTopWm2K = 450;
      next.hBottomWm2K = 25;
      next.hSideWm2K = 20;
      break;
    case 'cold_plate':
      next.hTopWm2K = 3500;
      next.hBottomWm2K = 40;
      next.hSideWm2K = 25;
      break;
    case 'liquid_microchannel':
      next.hTopWm2K = 12000;
      next.hBottomWm2K = 50;
      next.hSideWm2K = 30;
      break;
    case 'dual_sided':
      next.hTopWm2K = 4500;
      next.hBottomWm2K = 2200;
      next.hSideWm2K = 40;
      break;
    case 'fixed_temp_idealized':
      next.fixedTopTempK = cooling.fixedTopTempK ?? 310;
      next.hTopWm2K = 1e6;
      next.hBottomWm2K = 40;
      next.hSideWm2K = 20;
      break;
  }
  return next;
}

export function createDefaultInterfaces(): InterfaceSpec[] {
  return [
    {
      id: 'die_to_bond',
      name: 'DRAM Silicon ↔ Bonding Film',
      layerBelow: 'DRAM / Base Silicon',
      layerAbove: 'NCF / Hybrid Bond',
      rContactAreaM2KW: 4.5e-6,
      qualityMode: 'nominal',
      assumedFaultModel: false,
      notes: 'Nominal adhesive/microbump interface contact resistance (4.5 mm²·K/W).',
    },
    {
      id: 'base_to_interposer',
      name: 'Logic Base Die ↔ Interposer',
      layerBelow: 'Silicon Interposer',
      layerAbove: 'Logic Base Die',
      rContactAreaM2KW: 6.0e-6,
      qualityMode: 'nominal',
      assumedFaultModel: false,
      notes: 'Effective C4/microbump contact resistance excluding explicit underfill layer thickness.',
    },
    {
      id: 'die_to_tim',
      name: 'Top DRAM Die ↔ TIM1',
      layerBelow: 'Top DRAM Die',
      layerAbove: 'TIM1',
      rContactAreaM2KW: 5.5e-6,
      qualityMode: 'nominal',
      assumedFaultModel: false,
      notes: 'Silicon-to-TIM1 interfacial wetting resistance (5.5 mm²·K/W).',
    },
    {
      id: 'tim_to_spreader',
      name: 'TIM1 ↔ Heat Spreader',
      layerBelow: 'TIM1',
      layerAbove: 'Heat Spreader',
      rContactAreaM2KW: 4.0e-6,
      qualityMode: 'nominal',
      assumedFaultModel: false,
      notes: 'TIM1-to-lid interfacial resistance (4.0 mm²·K/W).',
    },
    {
      id: 'spreader_to_cooler',
      name: 'Heat Spreader ↔ Cooling Assembly',
      layerBelow: 'Heat Spreader',
      layerAbove: 'TIM2 / Cold Plate',
      rContactAreaM2KW: 8.0e-6,
      qualityMode: 'nominal',
      assumedFaultModel: false,
      notes: 'Package lid to cold plate interface (8.0 mm²·K/W).',
    },
  ];
}

export function createPresetConfig(
  preset: StackPresetId = 'HBM-12H',
  options?: {
    experimentId?: string;
    description?: string;
    includeAccelerator?: boolean;
  },
): SimulationConfig {
  const dramCount: 8 | 12 | 16 =
    preset === 'HBM-8H' ? 8 : preset === 'HBM-12H' ? 12 : 16;

  // Illustrative thinned die profiles for 8H/12H/16H under fixed ~720-775 um package constraints
  const dieThickUm = preset === 'HBM-8H' ? 50 : preset === 'HBM-12H' ? 36 : 28;
  const bondThickUm = preset === 'HBM-8H' ? 16 : preset === 'HBM-12H' ? 12 : 10;

  // Documented hypothetical power inputs (e.g., ~2.2 W per DRAM die + 6.5 W logic base)
  const dramPowersW = Array.from({ length: dramCount }, () => 2.2);

  return {
    project: 'SilicaFlux-HPC ThermalStack',
    experimentId: options?.experimentId ?? `baseline-${preset.toLowerCase()}`,
    description:
      options?.description ??
      `Baseline ${preset} thermal digital twin configuration with documented illustrative geometry and power inputs.`,
    geometry: {
      stackPreset: preset,
      dramDieCount: dramCount,
      dieWidthMm: 11.0, // illustrative HBM3/3E-class footprint (11 x 11 mm)
      dieDepthMm: 11.0,
      dramDieThicknessUm: dieThickUm,
      bondingThicknessUm: bondThickUm,
      baseDieThicknessUm: 80,
      basePackageLinkThicknessUm: 25,
      interposerThicknessUm: 100,
      substrateThicknessUm: 320,
      timThicknessUm: 45,
      spreaderThicknessUm: 1000,
      spreaderWidthMm: options?.includeAccelerator ? 28.0 : 18.0,
      spreaderDepthMm: options?.includeAccelerator ? 22.0 : 18.0,
      moldOverhangMm: 2.0,
      microbumpMetalFraction: 0.08,
      dramMaterialId: 'silicon_crystalline',
      bondingMaterialId: 'microbump_ncf_effective',
      underfillMaterialId: 'underfill_epoxy',
      baseDieMaterialId: 'silicon_crystalline',
      interposerMaterialId: 'silicon_crystalline',
      substrateMaterialId: 'organic_substrate',
      timMaterialId: 'tim_polymer_gel',
      spreaderMaterialId: 'spreader_copper',
      moldMaterialId: 'mold_compound_emc',
      layerOverrides: [],
      includeAccelerator: options?.includeAccelerator ?? false,
      acceleratorWidthMm: 12.0,
      acceleratorDepthMm: 16.0,
      acceleratorThicknessUm: 620,
      acceleratorGapMm: 1.5,
      acceleratorMaterialId: 'silicon_crystalline',
    },
    tsv: {
      mode: 'homogenized',
      cuFraction: 0.08,
      tsvDiameterUm: 6.0,
      tsvPitchUm: 24.0,
      linerThicknessUm: 0.4,
      linerMaterialId: 'silicon_dioxide',
      placement: 'central_spine',
      tsvRegionWidthFraction: 0.24,
      tsvRegionDepthFraction: 0.85,
    },
    interfaces: createDefaultInterfaces(),
    heatSources: {
      mode: 'per_die',
      workload: 'tensor_hbw',
      dramPowersW,
      baseDiePowerW: 6.5,
      phyPowerW: 2.0,
      acceleratorPowerW: 160.0,
      hotspotPeakRatio: 1.35,
      hotspotCenterNormXY: [0.68, 0.52],
      hotspotSigmaNorm: 0.24,
      acceleratorHotspotMap: true,
      electrothermalEnabled: false,
      leakageAlphaPerK: 0.0045,
      throttleThresholdK: 368.15,
      throttleSlopePerK: 0.02,
    },
    cooling: {
      mode: 'cold_plate',
      spreaderPreset: 'conventional_cu',
      tAmbientK: 298.15,
      hTopWm2K: 3500,
      hBottomWm2K: 45,
      hSideWm2K: 25,
      radiationEmissivity: 0.85,
      enableRadiation: false,
    },
    mesh: {
      nx: 12,
      ny: 12,
      nzPerDramDie: 1,
      nzPerBond: 1,
      nzBaseDie: 2,
      nzInterposer: 2,
      nzTim: 1,
      nzSpreader: 2,
      nonuniformXY: true,
      refinementFactor: 1.0,
    },
    solver: {
      studyType: 'steady_state',
      relativeTolerance: 1e-8,
      maxIterations: 4000,
      useTempDependentK: true,
      nonlinearUnderRelaxation: 0.75,
      nonlinearMaxIters: 16,
      timeIntegration: 'backward_euler',
      dtSeconds: 0.02,
      totalTimeSeconds: 0.5,
      initialTempK: 298.15,
      hotspotThresholdK: 358.15,
    },
  };
}
