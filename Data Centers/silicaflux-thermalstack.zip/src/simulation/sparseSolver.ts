export interface SparseCSR {
  n: number;
  rowPtr: Int32Array;
  colIdx: Int32Array;
  values: Float64Array;
  diagIdx: Int32Array;
}

export interface LinearSolveReport {
  x: Float64Array;
  iterations: number;
  residualNorm: number;
  converged: boolean;
  solveTimeMs: number;
  method: string;
}

export function matVecCSR(A: SparseCSR, x: Float64Array, y: Float64Array): void {
  const { n, rowPtr, colIdx, values } = A;
  for (let i = 0; i < n; i++) {
    let sum = 0;
    const start = rowPtr[i];
    const end = rowPtr[i + 1];
    for (let p = start; p < end; p++) {
      sum += values[p] * x[colIdx[p]];
    }
    y[i] = sum;
  }
}

export function dotProduct(a: Float64Array, b: Float64Array): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) {
    s += a[i] * b[i];
  }
  return s;
}

export function norm2(a: Float64Array): number {
  return Math.sqrt(dotProduct(a, a));
}

/**
 * Symmetric Gauss-Seidel / SSOR Preconditioned Conjugate Gradient (PCG)
 * for symmetric positive-definite finite-volume conduction matrices.
 */
export function solvePCG(
  A: SparseCSR,
  b: Float64Array,
  x0?: Float64Array,
  relTol = 1e-8,
  maxIters = 4000,
  shouldCancel?: () => boolean,
): LinearSolveReport {
  const t0 = performance.now();
  const n = A.n;
  const x = x0 ? new Float64Array(x0) : new Float64Array(n);
  const r = new Float64Array(n);
  const z = new Float64Array(n);
  const p = new Float64Array(n);
  const Ap = new Float64Array(n);
  const invDiag = new Float64Array(n);

  for (let i = 0; i < n; i++) {
    const d = A.values[A.diagIdx[i]];
    invDiag[i] = Math.abs(d) > 1e-30 ? 1.0 / d : 1.0;
  }

  // r = b - A * x
  matVecCSR(A, x, Ap);
  for (let i = 0; i < n; i++) {
    r[i] = b[i] - Ap[i];
  }

  const bNorm = Math.max(norm2(b), 1e-15);
  let rNorm = norm2(r);
  if (rNorm / bNorm <= relTol) {
    return {
      x,
      iterations: 0,
      residualNorm: rNorm / bNorm,
      converged: true,
      solveTimeMs: performance.now() - t0,
      method: 'SSOR-PCG',
    };
  }

  // Symmetric Gauss-Seidel preconditioner: M^-1 r
  const applySSOR = (rhs: Float64Array, out: Float64Array) => {
    const { rowPtr, colIdx, values, diagIdx } = A;
    // Forward sweep
    for (let i = 0; i < n; i++) {
      let sum = rhs[i];
      const start = rowPtr[i];
      const diagP = diagIdx[i];
      for (let k = start; k < diagP; k++) {
        sum -= values[k] * out[colIdx[k]];
      }
      out[i] = sum * invDiag[i];
    }
    // Diagonal scaling D * out
    for (let i = 0; i < n; i++) {
      out[i] *= A.values[diagIdx[i]];
    }
    // Backward sweep
    for (let i = n - 1; i >= 0; i--) {
      let sum = out[i];
      const end = rowPtr[i + 1];
      const diagP = diagIdx[i];
      for (let k = diagP + 1; k < end; k++) {
        sum -= values[k] * out[colIdx[k]];
      }
      out[i] = sum * invDiag[i];
    }
  };

  applySSOR(r, z);
  p.set(z);
  let rzOld = dotProduct(r, z);
  let iter = 0;

  for (iter = 1; iter <= maxIters; iter++) {
    if (shouldCancel && iter % 200 === 0 && shouldCancel()) {
      throw new Error('Simulation job cancelled by user.');
    }
    matVecCSR(A, p, Ap);
    const pAp = dotProduct(p, Ap);
    if (Math.abs(pAp) < 1e-30) {
      break;
    }
    const alpha = rzOld / pAp;
    for (let i = 0; i < n; i++) {
      x[i] += alpha * p[i];
      r[i] -= alpha * Ap[i];
    }
    rNorm = norm2(r);
    if (rNorm / bNorm <= relTol) {
      return {
        x,
        iterations: iter,
        residualNorm: rNorm / bNorm,
        converged: true,
        solveTimeMs: performance.now() - t0,
        method: 'SSOR-PCG',
      };
    }
    applySSOR(r, z);
    const rzNew = dotProduct(r, z);
    const beta = rzNew / Math.max(rzOld, 1e-30);
    for (let i = 0; i < n; i++) {
      p[i] = z[i] + beta * p[i];
    }
    rzOld = rzNew;
  }

  return {
    x,
    iterations: iter,
    residualNorm: rNorm / bNorm,
    converged: rNorm / bNorm <= relTol * 10,
    solveTimeMs: performance.now() - t0,
    method: 'SSOR-PCG',
  };
}

/**
 * Jacobi-Preconditioned BiCGSTAB for non-symmetric systems (e.g., off-diagonal tensor MPFA or radiation linearization).
 */
export function solveBiCGSTAB(
  A: SparseCSR,
  b: Float64Array,
  x0?: Float64Array,
  relTol = 1e-8,
  maxIters = 4000,
): LinearSolveReport {
  const t0 = performance.now();
  const n = A.n;
  const x = x0 ? new Float64Array(x0) : new Float64Array(n);
  const r = new Float64Array(n);
  const rHat = new Float64Array(n);
  const p = new Float64Array(n);
  const v = new Float64Array(n);
  const s = new Float64Array(n);
  const t = new Float64Array(n);
  const y = new Float64Array(n);
  const z = new Float64Array(n);
  const invDiag = new Float64Array(n);

  for (let i = 0; i < n; i++) {
    const d = A.values[A.diagIdx[i]];
    invDiag[i] = Math.abs(d) > 1e-30 ? 1.0 / d : 1.0;
  }

  matVecCSR(A, x, v);
  for (let i = 0; i < n; i++) {
    r[i] = b[i] - v[i];
    rHat[i] = r[i];
  }

  const bNorm = Math.max(norm2(b), 1e-15);
  let rNorm = norm2(r);
  if (rNorm / bNorm <= relTol) {
    return {
      x,
      iterations: 0,
      residualNorm: rNorm / bNorm,
      converged: true,
      solveTimeMs: performance.now() - t0,
      method: 'Jacobi-BiCGSTAB',
    };
  }

  let rhoOld = 1;
  let alpha = 1;
  let omega = 1;
  p.fill(0);
  v.fill(0);

  let iter = 0;
  for (iter = 1; iter <= maxIters; iter++) {
    const rhoNew = dotProduct(rHat, r);
    if (Math.abs(rhoNew) < 1e-30) break;
    const beta = (rhoNew / rhoOld) * (alpha / omega);
    for (let i = 0; i < n; i++) {
      p[i] = r[i] + beta * (p[i] - omega * v[i]);
      y[i] = invDiag[i] * p[i];
    }
    matVecCSR(A, y, v);
    const rHatV = dotProduct(rHat, v);
    if (Math.abs(rHatV) < 1e-30) break;
    alpha = rhoNew / rHatV;
    for (let i = 0; i < n; i++) {
      s[i] = r[i] - alpha * v[i];
    }
    if (norm2(s) / bNorm <= relTol) {
      for (let i = 0; i < n; i++) x[i] += alpha * y[i];
      rNorm = norm2(s);
      return {
        x,
        iterations: iter,
        residualNorm: rNorm / bNorm,
        converged: true,
        solveTimeMs: performance.now() - t0,
        method: 'Jacobi-BiCGSTAB',
      };
    }
    for (let i = 0; i < n; i++) {
      z[i] = invDiag[i] * s[i];
    }
    matVecCSR(A, z, t);
    const tDotT = dotProduct(t, t);
    omega = tDotT > 1e-30 ? dotProduct(t, s) / tDotT : 0;
    for (let i = 0; i < n; i++) {
      x[i] += alpha * y[i] + omega * z[i];
      r[i] = s[i] - omega * t[i];
    }
    rNorm = norm2(r);
    if (rNorm / bNorm <= relTol) {
      return {
        x,
        iterations: iter,
        residualNorm: rNorm / bNorm,
        converged: true,
        solveTimeMs: performance.now() - t0,
        method: 'Jacobi-BiCGSTAB',
      };
    }
    if (Math.abs(omega) < 1e-30) break;
    rhoOld = rhoNew;
  }

  return {
    x,
    iterations: iter,
    residualNorm: rNorm / bNorm,
    converged: rNorm / bNorm <= relTol * 10,
    solveTimeMs: performance.now() - t0,
    method: 'Jacobi-BiCGSTAB',
  };
}
