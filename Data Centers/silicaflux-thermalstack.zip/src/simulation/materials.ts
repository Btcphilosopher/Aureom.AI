import {
  ConductivityTensor,
  MaterialRecord,
  TsvConfig,
} from './types';

export const MATERIALS_DATABASE_VERSION = '1.2.0-SF';

export const MATERIALS_DATABASE: MaterialRecord[] = [
  {
    id: 'silicon_crystalline',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Crystalline Silicon (Si)',
    category: 'semiconductor',
    densityKgM3: 2329,
    specificHeatJKgK: 712,
    conductivity: { kxx: 148, kyy: 148, kzz: 148 },
    tempDependence: {
      model: 'power_law',
      tRefK: 300,
      exponent: -1.3,
    },
    validTempRangeK: [250, 500],
    uncertaintyPct: 5,
    source: 'Glassbrenner & Slack (1964) / JEDEC JESD51 baseline (~148 W/mK at 300K)',
    notes: 'Temperature-dependent phonon thermal conductivity for bulk/thinned DRAM and logic dies.',
  },
  {
    id: 'copper_electroplated',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Electroplated Copper (Cu)',
    category: 'metal',
    densityKgM3: 8960,
    specificHeatJKgK: 385,
    conductivity: { kxx: 390, kyy: 390, kzz: 390 },
    tempDependence: {
      model: 'linear',
      tRefK: 300,
      betaPerK: -0.00018,
    },
    validTempRangeK: [250, 550],
    uncertaintyPct: 6,
    source: 'NIST / packaging TSV & RDL interconnect range (360-401 W/mK)',
    notes: 'Slightly lower than annealed OFHC copper (401 W/mK) due to grain-boundary scattering in TSVs.',
  },
  {
    id: 'silicon_dioxide',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Silicon Dioxide (SiO₂ Liner / Dielectric)',
    category: 'dielectric',
    densityKgM3: 2200,
    specificHeatJKgK: 730,
    conductivity: { kxx: 1.38, kyy: 1.38, kzz: 1.38 },
    validTempRangeK: [250, 600],
    uncertaintyPct: 10,
    source: 'AMAT / CRC Handbook thin-film PECVD SiO2 range (1.1-1.4 W/mK)',
    notes: 'Used for TSV dielectric liner and BEOL/hybrid-bond oxide regions.',
  },
  {
    id: 'silicon_nitride',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Silicon Nitride (Si₃N₄ Passivation)',
    category: 'dielectric',
    densityKgM3: 3100,
    specificHeatJKgK: 700,
    conductivity: { kxx: 18, kyy: 18, kzz: 18 },
    validTempRangeK: [250, 600],
    uncertaintyPct: 20,
    source: 'Thin-film PECVD SiNx literature (3-25 W/mK depending on stoichiometry)',
    notes: 'Passivation and diffusion barrier layer.',
  },
  {
    id: 'ncf_standard',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Non-Conductive Film (Standard NCF)',
    category: 'polymer_bond',
    densityKgM3: 1550,
    specificHeatJKgK: 1050,
    conductivity: { kxx: 0.45, kyy: 0.45, kzz: 0.45 },
    validTempRangeK: [270, 450],
    uncertaintyPct: 20,
    source: 'Microelectronics Reliability 2026 / standard silica-filled TC-NCF (0.3-0.6 W/mK)',
    notes: 'Baseline polymer bonding matrix; primary through-plane thermal bottleneck without Cu bumps.',
  },
  {
    id: 'ncf_high_k',
    version: MATERIALS_DATABASE_VERSION,
    name: 'High-k Filled NCF (Selective Thermal NCF)',
    category: 'polymer_bond',
    densityKgM3: 1950,
    specificHeatJKgK: 920,
    conductivity: { kxx: 1.8, kyy: 1.8, kzz: 1.8 },
    validTempRangeK: [270, 450],
    uncertaintyPct: 25,
    source: 'Microelectronics Reliability 2026 (alumina/BN-filled NCF 1.2-2.5 W/mK)',
    notes: 'Engineered thermally conductive NCF candidate for 12H/16H stack-height mitigation.',
  },
  {
    id: 'underfill_epoxy',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Capillary Underfill Epoxy (CUF)',
    category: 'polymer_bond',
    densityKgM3: 1650,
    specificHeatJKgK: 1000,
    conductivity: { kxx: 0.65, kyy: 0.65, kzz: 0.65 },
    validTempRangeK: [270, 450],
    uncertaintyPct: 18,
    source: 'Silica-filled epoxy underfill data (0.5-0.8 W/mK)',
    notes: 'Used around microbumps and C4 package interconnects.',
  },
  {
    id: 'microbump_ncf_effective',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Effective Microbump + NCF Layer',
    category: 'composite_effective',
    densityKgM3: 2480,
    specificHeatJKgK: 860,
    conductivity: { kxx: 0.62, kyy: 0.62, kzz: 5.4 },
    validTempRangeK: [270, 450],
    uncertaintyPct: 20,
    source: 'Effective-medium rule-of-mixtures (~8% SnAg/Cu microbump area in 0.5 W/mK NCF)',
    notes: 'Anisotropic effective layer: through-plane kzz boosted by metallic bumps, in-plane kxx/kyy polymer-limited.',
  },
  {
    id: 'hybrid_bond_effective',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Cu-Cu / SiO₂ Hybrid Bonding Interface',
    category: 'composite_effective',
    densityKgM3: 3900,
    specificHeatJKgK: 580,
    conductivity: { kxx: 4.5, kyy: 4.5, kzz: 68.0 },
    validTempRangeK: [260, 480],
    uncertaintyPct: 18,
    source: 'Electronics 2025 Review (hybrid Cu pad area fraction ~18% in SiO2 dielectric)',
    notes: 'Strongly anisotropic effective bonding layer eliminating NCF bottleneck; explicit contact resistance still applies.',
  },
  {
    id: 'mold_compound_emc',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Epoxy Mold Compound (EMC)',
    category: 'polymer_bond',
    densityKgM3: 1880,
    specificHeatJKgK: 950,
    conductivity: { kxx: 0.95, kyy: 0.95, kzz: 0.95 },
    validTempRangeK: [270, 460],
    uncertaintyPct: 15,
    source: 'Standard high-filler packaging EMC (0.8-1.2 W/mK)',
    notes: 'Encapsulant surrounding HBM stack and interposer periphery.',
  },
  {
    id: 'tim_indium_solder',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Indium Metallic TIM1',
    category: 'tim',
    densityKgM3: 7310,
    specificHeatJKgK: 233,
    conductivity: { kxx: 81.8, kyy: 81.8, kzz: 81.8 },
    validTempRangeK: [260, 420],
    uncertaintyPct: 10,
    source: 'CRC Indium bulk conductivity (81.8 W/mK); contact BLT resistance modelled separately',
    notes: 'High-performance metallic TIM1 between top die / spreader.',
  },
  {
    id: 'tim_polymer_gel',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Silicone Thermal Gel / Grease TIM',
    category: 'tim',
    densityKgM3: 2600,
    specificHeatJKgK: 1020,
    conductivity: { kxx: 4.5, kyy: 4.5, kzz: 4.5 },
    validTempRangeK: [260, 430],
    uncertaintyPct: 20,
    source: 'Commercial gap-filler gel datasheet range (3.5-6.0 W/mK)',
    notes: 'Compliant polymer TIM baseline.',
  },
  {
    id: 'spreader_copper',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Nickel-Plated Copper Lid (Cu)',
    category: 'spreader',
    densityKgM3: 8940,
    specificHeatJKgK: 385,
    conductivity: { kxx: 398, kyy: 398, kzz: 398 },
    validTempRangeK: [250, 500],
    uncertaintyPct: 3,
    source: 'OFHC Copper packaging IHS baseline',
    notes: 'Standard high-conductivity integrated heat spreader.',
  },
  {
    id: 'spreader_alsic',
    version: MATERIALS_DATABASE_VERSION,
    name: 'AlSiC-9 Composite Spreader',
    category: 'spreader',
    densityKgM3: 3010,
    specificHeatJKgK: 740,
    conductivity: { kxx: 185, kyy: 185, kzz: 185 },
    validTempRangeK: [250, 500],
    uncertaintyPct: 8,
    source: 'CTE-matched AlSiC-9 lid specification (180-200 W/mK)',
    notes: 'Lower CTE mismatch to silicon interposer at reduced thermal conductivity.',
  },
  {
    id: 'spreader_diamond_cu',
    version: MATERIALS_DATABASE_VERSION,
    name: 'Diamond-Cu Composite Heat Spreader',
    category: 'spreader',
    densityKgM3: 5400,
    specificHeatJKgK: 430,
    conductivity: { kxx: 580, kyy: 580, kzz: 520 },
    validTempRangeK: [250, 500],
    uncertaintyPct: 12,
    source: 'Research sintered Diamond-Cu thermal spreader (500-650 W/mK)',
    notes: 'Advanced lateral heat-spreading candidate for co-packaged HBM + accelerator.',
  },
  {
    id: 'organic_substrate',
    version: MATERIALS_DATABASE_VERSION,
    name: 'ABF Organic Package Substrate (Effective)',
    category: 'composite_effective',
    densityKgM3: 2150,
    specificHeatJKgK: 980,
    conductivity: { kxx: 22.0, kyy: 22.0, kzz: 2.1 },
    validTempRangeK: [270, 440],
    uncertaintyPct: 22,
    source: 'Effective multi-layer Cu plane + ABF/BT dielectric substrate model',
    notes: 'Strongly anisotropic: Cu power/ground planes give ~22 W/mK in-plane, dielectric limits through-plane to ~2.1 W/mK.',
  },
];

export const MATERIALS_MAP: Record<string, MaterialRecord> = Object.fromEntries(
  MATERIALS_DATABASE.map((m) => [m.id, m]),
);

export function getMaterialOrThrow(id: string): MaterialRecord {
  const mat = MATERIALS_MAP[id];
  if (!mat) {
    throw new Error(`Unknown material ID "${id}" in materials database v${MATERIALS_DATABASE_VERSION}.`);
  }
  return mat;
}

/**
 * Validates that a conductivity tensor is physically admissible (strictly positive-definite symmetric).
 */
export function validateConductivityTensor(tensor: ConductivityTensor, label = 'material'): void {
  const { kxx, kyy, kzz, kxy = 0, kxz = 0, kyz = 0 } = tensor;
  if (![kxx, kyy, kzz, kxy, kxz, kyz].every((v) => Number.isFinite(v))) {
    throw new Error(`Non-finite conductivity value in ${label}.`);
  }
  if (kxx <= 0 || kyy <= 0 || kzz <= 0) {
    throw new Error(`Diagonal conductivities must be strictly positive in ${label}: (${kxx}, ${kyy}, ${kzz}).`);
  }
  // Sylvester's criterion for 3x3 SPD matrix
  const det2 = kxx * kyy - kxy * kxy;
  const det3 =
    kxx * (kyy * kzz - kyz * kyz) -
    kxy * (kxy * kzz - kyz * kxz) +
    kxz * (kxy * kyz - kyy * kxz);
  if (det2 <= 0 || det3 <= 0) {
    throw new Error(
      `Conductivity tensor for ${label} is not symmetric positive-definite (det2=${det2}, det3=${det3}).`,
    );
  }
}

export function evaluateMaterialKAtTemp(
  mat: MaterialRecord,
  tempK: number,
  useTempDependent: boolean,
): ConductivityTensor {
  if (!useTempDependent || !mat.tempDependence || mat.tempDependence.model === 'constant') {
    return { ...mat.conductivity };
  }
  const td = mat.tempDependence;
  const clampedT = Math.min(Math.max(tempK, mat.validTempRangeK[0] * 0.8), mat.validTempRangeK[1] * 1.2);
  let factor = 1.0;
  if (td.model === 'power_law' && td.exponent !== undefined) {
    factor = Math.pow(clampedT / td.tRefK, td.exponent);
  } else if (td.model === 'linear' && td.betaPerK !== undefined) {
    factor = Math.max(0.2, 1 + td.betaPerK * (clampedT - td.tRefK));
  }
  return {
    kxx: mat.conductivity.kxx * factor,
    kyy: mat.conductivity.kyy * factor,
    kzz: mat.conductivity.kzz * factor,
    kxy: mat.conductivity.kxy ? mat.conductivity.kxy * factor : 0,
    kxz: mat.conductivity.kxz ? mat.conductivity.kxz * factor : 0,
    kyz: mat.conductivity.kyz ? mat.conductivity.kyz * factor : 0,
  };
}

/**
 * Computes effective anisotropic properties for a homogenized TSV region:
 * - Through-plane (kzz): parallel thermal circuit of Cu core + dielectric liner + Si matrix
 * - In-plane (kxx, kyy): Maxwell-Eucken / Hashin-Shtrikman effective medium accounting for liner barrier
 * Assumptions documented explicitly in returned metadata.
 */
export interface HomogenizedTsvProperties {
  kxx: number;
  kyy: number;
  kzz: number;
  rhoCp: number;
  cuFraction: number;
  linerFraction: number;
  siliconFraction: number;
  assumptions: string;
}

export function computeHomogenizedTsvProperties(
  tsv: TsvConfig,
  siliconMat: MaterialRecord,
  cuMat: MaterialRecord,
  linerMat: MaterialRecord,
  tempK = 330,
  useTempDependent = false,
): HomogenizedTsvProperties {
  const fCu = Math.min(Math.max(tsv.cuFraction, 0), 0.45);
  const rCu = Math.max(tsv.tsvDiameterUm * 0.5, 0.5);
  const rOuter = rCu + Math.max(tsv.linerThicknessUm, 0.02);
  const linerAreaRatio = (rOuter * rOuter - rCu * rCu) / (rCu * rCu);
  const fLiner = Math.min(fCu * linerAreaRatio, 0.45 - fCu * 0.5);
  const fSi = Math.max(1 - fCu - fLiner, 0.05);

  const kSi = evaluateMaterialKAtTemp(siliconMat, tempK, useTempDependent);
  const kCu = evaluateMaterialKAtTemp(cuMat, tempK, useTempDependent);
  const kLiner = evaluateMaterialKAtTemp(linerMat, tempK, useTempDependent);

  // Parallel through-plane conduction along Z axis
  const kzz = fCu * kCu.kzz + fLiner * kLiner.kzz + fSi * kSi.kzz;

  // In-plane effective conductivity: the cylindrical dielectric liner acts as a radial thermal barrier
  // around the Cu post. Effective inclusion conductivity via concentric cylinder approximation:
  const gamma = (rCu / rOuter) ** 2;
  const kInclEff =
    kLiner.kxx *
    (((1 + gamma) * kCu.kxx + (1 - gamma) * kLiner.kxx) /
      ((1 - gamma) * kCu.kxx + (1 + gamma) * kLiner.kxx));
  const fIncl = fCu + fLiner;
  // Maxwell-Eucken 2D cylindrical transverse formula
  const kInPlane =
    kSi.kxx *
    ((kInclEff + kSi.kxx + fIncl * (kInclEff - kSi.kxx)) /
      (kInclEff + kSi.kxx - fIncl * (kInclEff - kSi.kxx)));

  const rhoCp =
    fCu * cuMat.densityKgM3 * cuMat.specificHeatJKgK +
    fLiner * linerMat.densityKgM3 * linerMat.specificHeatJKgK +
    fSi * siliconMat.densityKgM3 * siliconMat.specificHeatJKgK;

  return {
    kxx: kInPlane,
    kyy: kInPlane,
    kzz,
    rhoCp,
    cuFraction: fCu,
    linerFraction: fLiner,
    siliconFraction: fSi,
    assumptions:
      'Parallel-path through-plane homogenization (kzz) + 2D concentric-cylinder Maxwell-Eucken transverse homogenization (kxx, kyy) assuming continuous Cu core and uniform SiO2 liner thickness.',
  };
}
