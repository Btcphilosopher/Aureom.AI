import { HttpClient } from '@angular/common/http';
import { computed, inject, Injectable, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { createPresetConfig } from '../../simulation/geometry';
import { MATERIALS_DATABASE, MATERIALS_DATABASE_VERSION } from '../../simulation/materials';
import {
  BuiltPackageGeometry,
  MaterialRecord,
  SimulationConfig,
  SimulationResult,
  StackPresetId,
  ValidationTestOutcome,
} from '../../simulation/types';
import {
  ParetoCandidate,
  StackHeightComparisonOutput,
  SweepParameterKey,
  UncertaintyResult,
} from '../../simulation/analysis';

export interface ExperimentItem {
  id: string;
  code: string;
  title: string;
  question: string;
  reproductionCommand: string;
  limitations: string;
  config: SimulationConfig;
}

export interface CoolingComparisonRow {
  label: string;
  mode: string;
  spreader: string;
  hTopWm2K: number;
  hBottomWm2K: number;
  peakTempC: number;
  avgDramTempC: number;
  baseDieTempC: number;
  dieToDieDeltaK: number;
  effectiveRthKPerW: number;
  topHeatRejectionPct: number;
}

export interface SweepPoint {
  paramValue: number;
  peakTempC: number;
  avgDramTempC: number;
  baseDieTempC: number;
  dieToDieDeltaK: number;
  rthKPerW: number;
}

export interface BenchmarkRow {
  label: string;
  cellCount: number;
  matrixSize: number;
  nnz: number;
  estimatedMemoryMb: number;
  assemblyTimeMs: number;
  solveTimeMs: number;
  iterations: number;
  peakTempC: number;
  energyErrorPct: number;
  fieldPayloadKb: number;
}

export interface TsvComparisonResult {
  homogenizedProperties: {
    kxx: number;
    kyy: number;
    kzz: number;
    cuFraction: number;
    linerFraction: number;
    siliconFraction: number;
    assumptions: string;
  };
  homogenized: { peakTempC: number; avgDramTempC: number; baseDieTempC: number; effectiveRthKPerW: number };
  explicitCutaway: { peakTempC: number; avgDramTempC: number; baseDieTempC: number; effectiveRthKPerW: number };
  deltaPeakK: number;
  note: string;
}

@Injectable({ providedIn: 'root' })
export class ThermalstackApi {
  private readonly http = inject(HttpClient);

  readonly materials = signal<MaterialRecord[]>(MATERIALS_DATABASE);
  readonly materialsVersion = signal<string>(MATERIALS_DATABASE_VERSION);
  readonly experiments = signal<ExperimentItem[]>([]);

  readonly config = signal<SimulationConfig>(createPresetConfig('HBM-12H'));
  readonly result = signal<SimulationResult | null>(null);
  readonly activeJobId = signal<string | null>(null);
  readonly jobStatus = signal<'idle' | 'queued' | 'running' | 'completed' | 'failed' | 'cancelled'>('idle');
  readonly errorMessage = signal<string | null>(null);

  // Study outputs
  readonly stackComparison = signal<StackHeightComparisonOutput | null>(null);
  readonly coolingComparison = signal<CoolingComparisonRow[]>([]);
  readonly sweepResult = signal<{ parameter: string; points: SweepPoint[] } | null>(null);
  readonly optimisationResult = signal<{ candidates: ParetoCandidate[]; optimal: ParetoCandidate } | null>(null);
  readonly uncertaintyResult = signal<UncertaintyResult | null>(null);
  readonly tsvComparison = signal<TsvComparisonResult | null>(null);
  readonly validationResults = signal<{
    totalTests: number;
    passedCount: number;
    allPassed: boolean;
    outcomes: ValidationTestOutcome[];
  } | null>(null);
  readonly benchmarks = signal<BenchmarkRow[]>([]);
  readonly generatedReport = signal<{
    jobId: string;
    markdown: string;
    hdf5SchemaMetadata: Record<string, unknown>;
  } | null>(null);

  readonly busyAction = signal<string | null>(null);

  readonly isRunning = computed(
    () => this.jobStatus() === 'queued' || this.jobStatus() === 'running',
  );

  async initialize(): Promise<void> {
    try {
      const [matsRes, presetsRes] = await Promise.all([
        firstValueFrom(
          this.http.get<{ version: string; materials: MaterialRecord[] }>('/api/materials'),
        ),
        firstValueFrom(
          this.http.get<{
            presets: Record<StackPresetId, SimulationConfig>;
            experiments: ExperimentItem[];
          }>('/api/presets'),
        ),
      ]);
      this.materials.set(matsRes.materials);
      this.materialsVersion.set(matsRes.version);
      this.experiments.set(presetsRes.experiments);
    } catch {
      // Fallback already populated for materials
    }
    await this.runSimulationJob();
  }

  updateConfig(updater: (prev: SimulationConfig) => SimulationConfig): void {
    this.config.update((prev) => updater(structuredClone(prev)));
  }

  async selectPreset(preset: StackPresetId): Promise<void> {
    this.config.set(createPresetConfig(preset));
    await this.runSimulationJob();
  }

  async loadExperiment(exp: ExperimentItem): Promise<void> {
    this.config.set(structuredClone(exp.config));
    await this.runSimulationJob();
  }

  async validateGeometry(): Promise<BuiltPackageGeometry | null> {
    try {
      const res = await firstValueFrom(
        this.http.post<{ valid: boolean; geometry: BuiltPackageGeometry }>(
          '/api/geometry/build',
          this.config(),
        ),
      );
      this.errorMessage.set(null);
      return res.geometry;
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
      return null;
    }
  }

  async runSimulationJob(overrideStudyType?: 'steady_state' | 'transient'): Promise<void> {
    this.errorMessage.set(null);
    const cfg = structuredClone(this.config());
    if (overrideStudyType) {
      cfg.solver.studyType = overrideStudyType;
      this.config.set(cfg);
    }
    const endpoint =
      cfg.solver.studyType === 'transient'
        ? '/api/simulations/transient'
        : '/api/simulations/steady';

    try {
      this.jobStatus.set('queued');
      const submit = await firstValueFrom(
        this.http.post<{ jobId: string; status: string }>(endpoint, cfg),
      );
      this.activeJobId.set(submit.jobId);

      // Poll background worker job until completion/failure/cancellation
      for (let attempt = 0; attempt < 150; attempt++) {
        const poll = await firstValueFrom(
          this.http.get<{
            jobId: string;
            status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
            error?: string;
            result?: SimulationResult;
          }>(`/api/jobs/${submit.jobId}`),
        );
        this.jobStatus.set(poll.status);
        if (poll.status === 'completed' && poll.result) {
          this.result.set(poll.result);
          return;
        }
        if (poll.status === 'failed' || poll.status === 'cancelled') {
          this.errorMessage.set(poll.error ?? `Simulation ${poll.status}.`);
          return;
        }
        await new Promise((r) => setTimeout(r, 60));
      }
      this.jobStatus.set('failed');
      this.errorMessage.set('Simulation job polling timed out.');
    } catch (err: unknown) {
      this.jobStatus.set('failed');
      this.errorMessage.set(this.extractErr(err));
    }
  }

  async cancelActiveJob(): Promise<void> {
    const id = this.activeJobId();
    if (!id) return;
    try {
      await firstValueFrom(this.http.post(`/api/jobs/${id}/cancel`, {}));
      this.jobStatus.set('cancelled');
    } catch {
      // ignore
    }
  }

  async runStackHeightComparison(totalPowerW = 28, perDiePowerW = 2.2): Promise<void> {
    this.busyAction.set('stack_comparison');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<StackHeightComparisonOutput>('/api/compare/stack-heights', {
          config: this.config(),
          totalPowerW,
          perDiePowerW,
        }),
      );
      this.stackComparison.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runCoolingComparison(): Promise<void> {
    this.busyAction.set('cooling_comparison');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ strategies: CoolingComparisonRow[] }>(
          '/api/compare/cooling',
          this.config(),
        ),
      );
      this.coolingComparison.set(res.strategies);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runSweep(parameter: SweepParameterKey, values: number[]): Promise<void> {
    this.busyAction.set('sweep');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ parameter: string; points: SweepPoint[] }>('/api/sweep', {
          config: this.config(),
          parameter,
          values,
        }),
      );
      this.sweepResult.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runOptimisation(constraints: {
    maxPackageHeightMm: number;
    maxTsvFraction: number;
    maxCoolingH: number;
  }): Promise<void> {
    this.busyAction.set('optimise');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ candidates: ParetoCandidate[]; optimal: ParetoCandidate }>(
          '/api/optimize',
          { config: this.config(), constraints },
        ),
      );
      this.optimisationResult.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runUncertainty(): Promise<void> {
    this.busyAction.set('uncertainty');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<UncertaintyResult>('/api/uncertainty', this.config()),
      );
      this.uncertaintyResult.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runTsvComparison(): Promise<void> {
    this.busyAction.set('tsv_compare');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<TsvComparisonResult>('/api/tsv/compare-explicit', this.config()),
      );
      this.tsvComparison.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runValidationSuite(): Promise<void> {
    this.busyAction.set('validation');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{
          totalTests: number;
          passedCount: number;
          allPassed: boolean;
          outcomes: ValidationTestOutcome[];
        }>('/api/validation/run', {}),
      );
      this.validationResults.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async runBenchmarks(): Promise<void> {
    this.busyAction.set('benchmarks');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ benchmarks: BenchmarkRow[] }>('/api/benchmarks/run', this.config()),
      );
      this.benchmarks.set(res.benchmarks);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  async generateReport(): Promise<void> {
    this.busyAction.set('report');
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{
          jobId: string;
          markdown: string;
          hdf5SchemaMetadata: Record<string, unknown>;
        }>('/api/report', {
          jobId: this.result()?.jobId,
          config: this.config(),
        }),
      );
      this.generatedReport.set(res);
    } catch (err: unknown) {
      this.errorMessage.set(this.extractErr(err));
    } finally {
      this.busyAction.set(null);
    }
  }

  private extractErr(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as { error?: { error?: string } }).error;
      if (inner?.error) return inner.error;
    }
    return err instanceof Error ? err.message : 'Request failed.';
  }
}
