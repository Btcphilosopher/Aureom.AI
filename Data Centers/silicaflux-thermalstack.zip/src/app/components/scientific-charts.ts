import { ChangeDetectionStrategy, Component, computed, input, signal } from '@angular/core';
import { SimulationResult } from '../../simulation/types';
import {
  ParetoCandidate,
  StackHeightComparisonOutput,
  UncertaintyResult,
} from '../../simulation/analysis';
import { CoolingComparisonRow, SweepPoint } from '../services/thermalstack-api';

function thermalColorCss(norm: number): string {
  const t = Math.min(1, Math.max(0, norm));
  const stops: [number, [number, number, number]][] = [
    [0.0, [20, 56, 130]],
    [0.25, [28, 204, 229]],
    [0.5, [76, 198, 128]],
    [0.75, [215, 173, 89]],
    [1.0, [239, 68, 68]],
  ];
  for (let s = 0; s < stops.length - 1; s++) {
    const [t0, c0] = stops[s];
    const [t1, c1] = stops[s + 1];
    if (t >= t0 && t <= t1) {
      const u = (t - t0) / (t1 - t0);
      const r = Math.round(c0[0] + u * (c1[0] - c0[0]));
      const g = Math.round(c0[1] + u * (c1[1] - c0[1]));
      const b = Math.round(c0[2] + u * (c1[2] - c0[2]));
      return `rgb(${r},${g},${b})`;
    }
  }
  return 'rgb(239,68,68)';
}

@Component({
  selector: 'app-die-temperature-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col gap-2">
      <div class="flex items-center justify-between text-xs text-[#A7B5C8]">
        <span>Per-Die Min / Avg / Max Temperature (°C)</span>
        <span class="font-mono tabular-nums">Base die shown separately from DRAM 0..{{ dramCount() - 1 }}</span>
      </div>
      <div class="space-y-1.5 max-h-56 overflow-y-auto pr-1">
        @for (row of dieRows(); track row.layerId) {
          <div class="grid grid-cols-[96px_1fr_115px] items-center gap-2 text-xs">
            <span class="truncate font-mono text-[#E6EDF7]" [class.text-[#D7AD59]]="row.kind === 'base_die'">
              {{ row.shortName }}
            </span>
            <div class="relative h-4 bg-[#07101F] border border-[#A7B5C8]/15 rounded-xs overflow-hidden">
              <!-- Min-to-Max range bar -->
              <div
                class="absolute top-1 bottom-1 rounded-xs"
                [style.left.%]="pct(row.minTempK - 273.15)"
                [style.width.%]="Math.max(1.5, pct(row.maxTempK - 273.15) - pct(row.minTempK - 273.15))"
                [style.background]="barColor(row.maxTempK - 273.15)"
              ></div>
              <!-- Average tick -->
              <div
                class="absolute top-0 bottom-0 w-0.5 bg-white"
                [style.left.%]="pct(row.avgTempK - 273.15)"
              ></div>
            </div>
            <span class="font-mono tabular-nums text-[11px] text-right text-[#E6EDF7]">
              {{ (row.avgTempK - 273.15).toFixed(1) }} / <span class="text-[#D7AD59]">{{ (row.maxTempK - 273.15).toFixed(1) }}</span> °C
            </span>
          </div>
        }
      </div>
    </div>
  `,
})
export class DieTemperatureChart {
  protected readonly Math = Math;
  readonly result = input.required<SimulationResult>();

  readonly dramCount = computed(() => this.result().geometry.dramDieCount);
  readonly dieRows = computed(() =>
    this.result()
      .layers.filter((l) => l.kind === 'dram_die' || l.kind === 'base_die')
      .map((l) => ({
        ...l,
        shortName: l.kind === 'base_die' ? 'Base Logic' : `DRAM ${l.dramDieIndex}`,
      }))
      .reverse(),
  );

  private readonly bounds = computed(() => {
    const r = this.result();
    const minC = Math.floor((r.summary.minTempK - 273.15) * 0.9);
    const maxC = Math.ceil(r.summary.peakTempC + 2);
    return { minC, span: Math.max(maxC - minC, 5) };
  });

  pct(tempC: number): number {
    const { minC, span } = this.bounds();
    return Math.min(98, Math.max(0, ((tempC - minC) / span) * 100));
  }

  barColor(tempC: number): string {
    const { minC, span } = this.bounds();
    return thermalColorCss((tempC - minC) / span);
  }
}

@Component({
  selector: 'app-thermal-heatmap-2d',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col gap-2">
      <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div class="flex items-center gap-2">
          <span class="text-[#A7B5C8]">Plane</span>
          <select
            [value]="plane()"
            (change)="onPlaneChange($event)"
            class="bg-[#07101F] border border-[#A7B5C8]/20 rounded px-2 py-0.5 text-xs text-[#E6EDF7]"
          >
            <option value="xy">XY Horizontal Slice</option>
            <option value="xz">XZ Vertical Cross-Section</option>
          </select>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            [value]="sliceNorm()"
            (input)="onSliceInput($event)"
            class="w-24 accent-[#1CCCE5]"
          />
        </div>
        @if (hoveredCell(); as hc) {
          <span class="font-mono tabular-nums text-[#1CCCE5]">
            Probe ({{ hc.xMm.toFixed(2) }}, {{ hc.yOrZMm.toFixed(2) }}) mm: {{ hc.tempC.toFixed(2) }} °C
          </span>
        }
      </div>
      <div class="w-full h-44 bg-[#07101F] border border-[#A7B5C8]/15 rounded overflow-hidden">
        <svg class="w-full h-full cursor-crosshair" [attr.viewBox]="'0 0 ' + grid().cols + ' ' + grid().rows" preserveAspectRatio="none">
          @for (cell of grid().cells; track cell.key) {
            <rect
              [attr.x]="cell.c"
              [attr.y]="cell.r"
              width="1.02"
              height="1.02"
              [attr.fill]="cell.color"
              (mouseenter)="hoveredCell.set(cell)"
            />
          }
        </svg>
      </div>
    </div>
  `,
})
export class ThermalHeatmap2D {
  readonly result = input.required<SimulationResult>();
  readonly plane = signal<'xy' | 'xz'>('xz');
  readonly sliceNorm = signal(0.5);
  readonly hoveredCell = signal<{ key: string; c: number; r: number; xMm: number; yOrZMm: number; tempC: number; color: string } | null>(null);

  onPlaneChange(ev: Event): void {
    this.plane.set((ev.target as HTMLSelectElement).value as 'xy' | 'xz');
  }

  onSliceInput(ev: Event): void {
    this.sliceNorm.set(parseFloat((ev.target as HTMLInputElement).value));
  }

  readonly grid = computed(() => {
    const res = this.result();
    const { nx, ny, nz, xCentersMm, yCentersMm, zCentersMm, temperaturesK } = res.field3D;
    const tMin = res.summary.minTempK;
    const tRange = Math.max(res.summary.peakTempK - tMin, 0.5);
    const cells: { key: string; c: number; r: number; xMm: number; yOrZMm: number; tempC: number; color: string }[] = [];

    if (this.plane() === 'xy') {
      const k = Math.min(nz - 1, Math.max(0, Math.round(this.sliceNorm() * (nz - 1))));
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const T = temperaturesK[k * ny * nx + j * nx + i];
          cells.push({
            key: `${i}-${j}`,
            c: i,
            r: ny - 1 - j,
            xMm: xCentersMm[i],
            yOrZMm: yCentersMm[j],
            tempC: T - 273.15,
            color: thermalColorCss((T - tMin) / tRange),
          });
        }
      }
      return { cols: nx, rows: ny, cells };
    } else {
      const j = Math.min(ny - 1, Math.max(0, Math.round(this.sliceNorm() * (ny - 1))));
      for (let k = 0; k < nz; k++) {
        for (let i = 0; i < nx; i++) {
          const T = temperaturesK[k * ny * nx + j * nx + i];
          cells.push({
            key: `${i}-${k}`,
            c: i,
            r: nz - 1 - k,
            xMm: xCentersMm[i],
            yOrZMm: zCentersMm[k],
            tempC: T - 273.15,
            color: thermalColorCss((T - tMin) / tRange),
          });
        }
      }
      return { cols: nx, rows: nz, cells };
    }
  });
}

@Component({
  selector: 'app-depth-profile-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col gap-1.5">
      <div class="flex items-center justify-between text-xs text-[#A7B5C8]">
        <span>Through-Stack Temperature Profile T(z)</span>
        <span class="font-mono tabular-nums">Z: 0 to {{ maxZUm().toFixed(0) }} µm</span>
      </div>
      <svg viewBox="0 0 420 155" class="w-full h-40 bg-[#07101F] border border-[#A7B5C8]/15 rounded">
        <line x1="42" y1="15" x2="42" y2="130" stroke="#334155" stroke-width="1" />
        <line x1="42" y1="130" x2="405" y2="130" stroke="#334155" stroke-width="1" />
        <polyline
          fill="none"
          stroke="#1CCCE5"
          stroke-width="2"
          [attr.points]="avgPoints()"
        />
        <polyline
          fill="none"
          stroke="#D7AD59"
          stroke-width="1.5"
          stroke-dasharray="4 3"
          [attr.points]="maxPoints()"
        />
        <text x="8" y="24" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().maxC.toFixed(1) }}°</text>
        <text x="8" y="130" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().minC.toFixed(1) }}°</text>
        <text x="45" y="145" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">Substrate (0 µm)</text>
        <text x="315" y="145" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">Top Lid ({{ maxZUm().toFixed(0) }} µm)</text>
      </svg>
      <div class="flex items-center gap-4 text-[11px] font-mono text-[#A7B5C8]">
        <span class="text-[#1CCCE5]">— Layer Avg °C</span>
        <span class="text-[#D7AD59]">-- Layer Max °C</span>
      </div>
    </div>
  `,
})
export class DepthProfileChart {
  readonly result = input.required<SimulationResult>();

  readonly maxZUm = computed(() => this.result().geometry.totalHeightM * 1e6);
  readonly bounds = computed(() => {
    const r = this.result();
    return {
      minC: r.summary.minTempK - 273.15 - 1,
      maxC: r.summary.peakTempC + 1,
    };
  });

  readonly avgPoints = computed(() => this.buildPoints('avg'));
  readonly maxPoints = computed(() => this.buildPoints('max'));

  private buildPoints(kind: 'avg' | 'max'): string {
    const layers = this.result().layers;
    const maxZ = Math.max(this.maxZUm(), 1);
    const { minC, maxC } = this.bounds();
    const spanT = Math.max(maxC - minC, 1);
    return layers
      .map((l) => {
        const x = 44 + (l.zCenterUm / maxZ) * 358;
        const tC = (kind === 'avg' ? l.avgTempK : l.maxTempK) - 273.15;
        const y = 128 - ((tC - minC) / spanT) * 110;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }
}

@Component({
  selector: 'app-transient-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (result().transient; as tr) {
      <div class="flex flex-col gap-2">
        <div class="flex items-center justify-between text-xs text-[#A7B5C8]">
          <span>Transient Thermal Evolution (τ ≈ {{ tr.estimatedTimeConstantS.toFixed(3) }} s)</span>
          <span class="font-mono tabular-nums text-[#E6EDF7]">
            t = {{ (tr.steps[stepIdx()]?.timeS ?? 0).toFixed(3) }} s · Peak {{ ((tr.steps[stepIdx()]?.peakTempK ?? 298.15) - 273.15).toFixed(2) }} °C
          </span>
        </div>
        <svg viewBox="0 0 420 145" class="w-full h-36 bg-[#07101F] border border-[#A7B5C8]/15 rounded">
          <polyline fill="none" stroke="#EF4444" stroke-width="2" [attr.points]="poly('peak')" />
          <polyline fill="none" stroke="#1CCCE5" stroke-width="1.8" [attr.points]="poly('dram')" />
          <polyline fill="none" stroke="#D7AD59" stroke-width="1.5" stroke-dasharray="3 2" [attr.points]="poly('base')" />
          <line
            [attr.x1]="cursorX()"
            y1="10"
            [attr.x2]="cursorX()"
            y2="132"
            stroke="#FFFFFF"
            stroke-width="1"
            stroke-opacity="0.5"
          />
          <text x="6" y="20" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().maxC.toFixed(1) }}°C</text>
          <text x="6" y="130" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().minC.toFixed(1) }}°C</text>
        </svg>
        <div class="flex items-center gap-3 text-xs">
          <button
            type="button"
            (click)="togglePlay()"
            class="px-2.5 py-1 rounded bg-[#1CCCE5]/15 border border-[#1CCCE5]/40 text-[#1CCCE5] cursor-pointer"
          >
            {{ playing() ? 'Pause' : 'Play Trace' }}
          </button>
          <input
            type="range"
            min="0"
            [max]="Math.max(0, tr.steps.length - 1)"
            [value]="stepIdx()"
            (input)="onStepInput($event)"
            class="flex-1 accent-[#1CCCE5]"
          />
          <span class="font-mono tabular-nums text-[11px] text-[#A7B5C8]">
            Step {{ stepIdx() + 1 }}/{{ tr.steps.length }}
          </span>
        </div>
      </div>
    } @else {
      <div class="text-xs text-[#A7B5C8] py-8 text-center border border-dashed border-[#A7B5C8]/20 rounded">
        Switch study mode to Transient in the Thermal Solver panel to compute time-dependent evolution.
      </div>
    }
  `,
})
export class TransientChart {
  protected readonly Math = Math;
  readonly result = input.required<SimulationResult>();
  readonly stepIdx = signal(0);
  readonly playing = signal(false);
  private timer: number | null = null;

  readonly bounds = computed(() => {
    const steps = this.result().transient?.steps ?? [];
    if (steps.length === 0) return { minC: 20, maxC: 90 };
    const allT = steps.flatMap((s) => [s.peakTempK - 273.15, s.baseDieTempK - 273.15]);
    return {
      minC: Math.min(...allT) - 1,
      maxC: Math.max(...allT) + 1,
    };
  });

  cursorX = computed(() => {
    const steps = this.result().transient?.steps ?? [];
    if (steps.length <= 1) return 40;
    return 40 + (this.stepIdx() / (steps.length - 1)) * 370;
  });

  poly(kind: 'peak' | 'dram' | 'base'): string {
    const steps = this.result().transient?.steps ?? [];
    if (steps.length === 0) return '';
    const { minC, maxC } = this.bounds();
    const span = Math.max(maxC - minC, 1);
    const maxT = Math.max(steps[steps.length - 1].timeS, 1e-6);
    return steps
      .map((s) => {
        const x = 40 + (s.timeS / maxT) * 370;
        const valC =
          (kind === 'peak' ? s.peakTempK : kind === 'dram' ? s.avgDramTempK : s.baseDieTempK) -
          273.15;
        const y = 130 - ((valC - minC) / span) * 116;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }

  onStepInput(ev: Event): void {
    this.stepIdx.set(parseInt((ev.target as HTMLInputElement).value, 10));
  }

  togglePlay(): void {
    const steps = this.result().transient?.steps ?? [];
    if (steps.length <= 1) return;
    if (this.playing()) {
      this.playing.set(false);
      if (this.timer !== null) window.clearInterval(this.timer);
      this.timer = null;
    } else {
      this.playing.set(true);
      this.timer = window.setInterval(() => {
        const next = (this.stepIdx() + 1) % steps.length;
        this.stepIdx.set(next);
      }, 140);
    }
  }
}

@Component({
  selector: 'app-pareto-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (candidates().length > 0) {
      <div class="flex flex-col gap-2">
        <div class="flex items-center justify-between text-xs text-[#A7B5C8]">
          <span>Multi-Objective Pareto Frontier (Peak °C vs Cooling Power Proxy)</span>
          <span class="font-mono text-[#D7AD59]">Gold = Non-Dominated Optimal</span>
        </div>
        <svg viewBox="0 0 420 170" class="w-full h-44 bg-[#07101F] border border-[#A7B5C8]/15 rounded">
          <line x1="42" y1="14" x2="42" y2="142" stroke="#334155" />
          <line x1="42" y1="142" x2="405" y2="142" stroke="#334155" />
          @for (pt of plotted(); track pt.id) {
            <circle
              [attr.cx]="pt.x"
              [attr.cy]="pt.y"
              [attr.r]="pt.isParetoOptimal ? 5 : 3.5"
              [attr.fill]="pt.isParetoOptimal ? '#D7AD59' : '#1CCCE5'"
              [attr.fill-opacity]="pt.isParetoOptimal ? 1 : 0.45"
              (mouseenter)="hovered.set(pt)"
            />
          }
          <text x="6" y="22" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().maxT.toFixed(1) }}°</text>
          <text x="6" y="142" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().minT.toFixed(1) }}°</text>
          <text x="44" y="158" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().minP.toFixed(1) }} W</text>
          <text x="348" y="158" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().maxP.toFixed(1) }} W</text>
        </svg>
        @if (hovered(); as h) {
          <div class="text-[11px] font-mono text-[#E6EDF7] bg-[#101E36] border border-[#A7B5C8]/20 rounded px-2.5 py-1">
            {{ h.label }} → Peak {{ h.peakTempC.toFixed(2) }} °C · ΔT {{ h.dieToDieDeltaK.toFixed(2) }} K
          </div>
        }
      </div>
    }
  `,
})
export class ParetoChart {
  readonly candidates = input<ParetoCandidate[]>([]);
  readonly hovered = signal<ParetoCandidate | null>(null);

  readonly bounds = computed(() => {
    const list = this.candidates();
    const ts = list.map((c) => c.peakTempC);
    const ps = list.map((c) => c.coolingPowerProxyW);
    return {
      minT: Math.min(...ts) - 1,
      maxT: Math.max(...ts) + 1,
      minP: Math.min(...ps),
      maxP: Math.max(...ps) + 1,
    };
  });

  readonly plotted = computed(() => {
    const { minT, maxT, minP, maxP } = this.bounds();
    const spanT = Math.max(maxT - minT, 1);
    const spanP = Math.max(maxP - minP, 1);
    return this.candidates().map((c) => ({
      ...c,
      x: 48 + ((c.coolingPowerProxyW - minP) / spanP) * 350,
      y: 138 - ((c.peakTempC - minT) / spanT) * 120,
    }));
  });
}

@Component({
  selector: 'app-sweep-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (points().length > 0) {
      <div class="flex flex-col gap-1.5">
        <div class="flex items-center justify-between text-xs text-[#A7B5C8]">
          <span>Parameter Sweep: {{ parameter() }}</span>
          <span class="font-mono text-[#1CCCE5]">Peak °C & Base °C</span>
        </div>
        <svg viewBox="0 0 420 145" class="w-full h-36 bg-[#07101F] border border-[#A7B5C8]/15 rounded">
          <polyline fill="none" stroke="#EF4444" stroke-width="2" [attr.points]="poly('peak')" />
          <polyline fill="none" stroke="#1CCCE5" stroke-width="1.8" [attr.points]="poly('avg')" />
          <polyline fill="none" stroke="#D7AD59" stroke-width="1.5" stroke-dasharray="3 2" [attr.points]="poly('base')" />
          <text x="6" y="20" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().maxC.toFixed(1) }}°C</text>
          <text x="6" y="132" fill="#A7B5C8" font-size="9" font-family="JetBrains Mono">{{ bounds().minC.toFixed(1) }}°C</text>
        </svg>
      </div>
    }
  `,
})
export class SweepChart {
  readonly parameter = input<string>('');
  readonly points = input<SweepPoint[]>([]);

  readonly bounds = computed(() => {
    const pts = this.points();
    const vals = pts.flatMap((p) => [p.peakTempC, p.baseDieTempC, p.avgDramTempC]);
    return {
      minC: Math.min(...vals) - 1,
      maxC: Math.max(...vals) + 1,
    };
  });

  poly(kind: 'peak' | 'avg' | 'base'): string {
    const pts = this.points();
    if (pts.length === 0) return '';
    const { minC, maxC } = this.bounds();
    const span = Math.max(maxC - minC, 1);
    return pts
      .map((p, idx) => {
        const x = 44 + (idx / Math.max(pts.length - 1, 1)) * 365;
        const val = kind === 'peak' ? p.peakTempC : kind === 'avg' ? p.avgDramTempC : p.baseDieTempC;
        const y = 130 - ((val - minC) / span) * 114;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }
}

export type {
  CoolingComparisonRow,
  StackHeightComparisonOutput,
  UncertaintyResult,
};
