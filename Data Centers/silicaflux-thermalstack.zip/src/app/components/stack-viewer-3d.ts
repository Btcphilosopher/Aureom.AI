import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  ElementRef,
  inject,
  input,
  OnInit,
  output,
  PLATFORM_ID,
  signal,
  viewChild,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { SimulationResult } from '../../simulation/types';

export type SliceAxis = 'none' | 'xy' | 'xz' | 'yz';
export type ViewerColorMode = 'thermal' | 'material';

function sampleThermalColorRGB(norm: number): [number, number, number] {
  const t = Math.min(1, Math.max(0, norm));
  // Scientific calibrated midnight-cyan-gold-crimson thermal ramp
  const stops: [number, [number, number, number]][] = [
    [0.0, [20, 56, 130]],
    [0.25, [28, 204, 229]],
    [0.5, [76, 198, 128]],
    [0.75, [215, 173, 89]],
    [1.0, [239, 68, 68]],
  ];
  for (let s = 0; s < stops.length - 1; s++) {
    const [t0, c0] = stops[s];
    const [t1, c1] = stops[s + 1];
    if (t >= t0 && t <= t1) {
      const u = (t - t0) / (t1 - t0);
      return [
        Math.round(c0[0] + u * (c1[0] - c0[0])),
        Math.round(c0[1] + u * (c1[1] - c0[1])),
        Math.round(c0[2] + u * (c1[2] - c0[2])),
      ];
    }
  }
  return [239, 68, 68];
}

const MATERIAL_HEX: Record<string, number> = {
  substrate: 0x264653,
  interposer: 0x5c6b73,
  package_link: 0x4a5568,
  base_die: 0x814dd1,
  bonding: 0xd7ad59,
  dram_die: 0x1ccce5,
  tim: 0x94a3b8,
  heat_spreader: 0xb87333,
  accelerator: 0x3b82f6,
};

@Component({
  selector: 'app-stack-viewer-3d',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="relative w-full h-full min-h-[460px] bg-[#07101F] overflow-hidden select-none">
      <div #canvasHost class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Minimal Top-Left Coordinate & Mode Spec -->
      <div class="pointer-events-none absolute top-3 left-3 flex flex-col gap-1 z-10">
        <div class="text-xs font-medium text-[#E6EDF7] bg-[#0B182D]/85 border border-[#A7B5C8]/20 rounded-md px-3 py-1.5">
          @if (explodeTarget() > 0.05) {
            <span>EXPLODED HBM THERMAL STACK · Assembled Physics Mapped</span>
          } @else if (result(); as res) {
            <span>{{ res.config.geometry.stackPreset }} · {{ res.geometry.dramDieCount }} DRAM Dies + Base Die</span>
          } @else {
            <span>3D HBM Package Viewport</span>
          }
        </div>
        @if (result(); as res) {
          <div class="text-[11px] font-mono tabular-nums text-[#A7B5C8] bg-[#0B182D]/80 border border-[#A7B5C8]/15 rounded-md px-2.5 py-1">
            Peak {{ res.summary.peakTempC.toFixed(2) }} °C · Hotspot ({{ res.hotspot.positionMm[0].toFixed(1) }}, {{ res.hotspot.positionMm[1].toFixed(1) }}, {{ res.hotspot.positionMm[2].toFixed(2) }}) mm
          </div>
        }
      </div>

      <!-- Thermal Colorbar Legend (Top-Right) -->
      @if (colorMode() === 'thermal' && result(); as res) {
        <div class="pointer-events-none absolute top-3 right-3 z-10 bg-[#0B182D]/85 border border-[#A7B5C8]/20 rounded-md px-2.5 py-2 flex flex-col items-end gap-1">
          <span class="text-[10px] font-mono text-[#A7B5C8]">Temperature [°C]</span>
          <div class="flex items-center gap-2">
            <div class="flex flex-col justify-between h-24 text-[10px] font-mono tabular-nums text-[#E6EDF7] text-right">
              <span>{{ res.summary.peakTempC.toFixed(1) }}</span>
              <span>{{ ((res.summary.peakTempC + (res.summary.minTempK - 273.15)) * 0.5).toFixed(1) }}</span>
              <span>{{ (res.summary.minTempK - 273.15).toFixed(1) }}</span>
            </div>
            <div
              class="w-3 h-24 rounded-xs border border-white/15"
              style="background: linear-gradient(to bottom, #EF4444 0%, #D7AD59 25%, #4CC680 50%, #1CCCE5 75%, #143882 100%);"
            ></div>
          </div>
        </div>
      }

      <!-- WebGL Context Fallback -->
      @if (webglUnavailable()) {
        <div class="absolute inset-0 flex flex-col items-center justify-center bg-[#07101F] text-[#A7B5C8] p-6 text-center">
          <mat-icon class="text-4xl text-[#1CCCE5] mb-2">view_in_ar</mat-icon>
          <p class="text-sm font-medium text-white">WebGL context unavailable in this browser session</p>
          <p class="text-xs mt-1 max-w-md">Switch to the 2D Thermal Slice Heatmap and Die-by-Die charts below to inspect solved simulation fields.</p>
        </div>
      }

      <!-- Collapsible Bottom Viewport Control Dock -->
      <div
        class="absolute left-1/2 -translate-x-1/2 bottom-3 z-20 flex flex-col items-center transition-transform duration-200"
        [style.max-width]="'min(860px, 95%)'"
        [style.width]="'100%'"
      >
        <button
          type="button"
          (click)="dockCollapsed.set(!dockCollapsed())"
          class="flex items-center gap-1 px-3 py-1 text-[11px] font-medium text-[#A7B5C8] hover:text-white bg-[#0B182D]/90 border border-b-0 border-[#A7B5C8]/20 rounded-t-md cursor-pointer"
        >
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5">{{ dockCollapsed() ? 'keyboard_arrow_up' : 'keyboard_arrow_down' }}</mat-icon>
          <span>{{ dockCollapsed() ? 'Show 3D Controls' : 'Hide Controls' }}</span>
        </button>

        @if (!dockCollapsed()) {
          <div class="w-full bg-[#0B182D]/95 border border-[#A7B5C8]/20 rounded-lg px-3 py-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-2 text-xs">
            <!-- Camera Presets -->
            <div class="flex items-center gap-1">
              <button
                type="button"
                (click)="setCameraPreset('iso')"
                class="px-2 py-1 rounded bg-[#101E36] hover:bg-[#182C4E] text-[#E6EDF7] border border-[#A7B5C8]/15 whitespace-nowrap cursor-pointer"
              >
                Iso
              </button>
              <button
                type="button"
                (click)="setCameraPreset('front')"
                class="px-2 py-1 rounded bg-[#101E36] hover:bg-[#182C4E] text-[#E6EDF7] border border-[#A7B5C8]/15 whitespace-nowrap cursor-pointer"
              >
                Front XZ
              </button>
              <button
                type="button"
                (click)="setCameraPreset('top')"
                class="px-2 py-1 rounded bg-[#101E36] hover:bg-[#182C4E] text-[#E6EDF7] border border-[#A7B5C8]/15 whitespace-nowrap cursor-pointer"
              >
                Top XY
              </button>
            </div>

            <!-- Explode Stack Slider -->
            <label class="flex items-center gap-2 text-[#A7B5C8]">
              <span class="whitespace-nowrap">Explode</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                [value]="explodeTarget()"
                (input)="onExplodeInput($event)"
                class="w-20 accent-[#1CCCE5] cursor-pointer"
              />
              <span class="font-mono tabular-nums text-[11px] text-[#E6EDF7] w-8">{{ (explodeTarget() * 100).toFixed(0) }}%</span>
            </label>

            <!-- Color Mode & Overlays -->
            <div class="flex items-center gap-1.5">
              <button
                type="button"
                (click)="colorModeChange.emit(colorMode() === 'thermal' ? 'material' : 'thermal')"
                class="flex items-center gap-1 px-2.5 py-1 rounded border whitespace-nowrap cursor-pointer"
                [class]="colorMode() === 'thermal' ? 'bg-[#1CCCE5]/15 border-[#1CCCE5]/50 text-[#1CCCE5]' : 'bg-[#101E36] border-[#A7B5C8]/20 text-[#A7B5C8]'"
              >
                <mat-icon class="!text-[14px] !w-3.5 !h-3.5">thermostat</mat-icon>
                <span>{{ colorMode() === 'thermal' ? 'Thermal' : 'Materials' }}</span>
              </button>
              <button
                type="button"
                (click)="showTsvChange.emit(!showTsvs())"
                class="flex items-center gap-1 px-2 py-1 rounded border whitespace-nowrap cursor-pointer"
                [class]="showTsvs() ? 'bg-[#D7AD59]/15 border-[#D7AD59]/50 text-[#D7AD59]' : 'bg-[#101E36] border-[#A7B5C8]/20 text-[#A7B5C8]'"
              >
                <span>TSVs</span>
              </button>
              <button
                type="button"
                (click)="showFluxChange.emit(!showFluxVectors())"
                class="flex items-center gap-1 px-2 py-1 rounded border whitespace-nowrap cursor-pointer"
                [class]="showFluxVectors() ? 'bg-[#814DD1]/20 border-[#814DD1]/60 text-[#C4A8F5]' : 'bg-[#101E36] border-[#A7B5C8]/20 text-[#A7B5C8]'"
              >
                <span>Heat Flux</span>
              </button>
            </div>

            <!-- Slice Plane Control -->
            <div class="flex items-center gap-1.5">
              <select
                [value]="sliceAxis()"
                (change)="onSliceAxisChange($event)"
                aria-label="Slice plane axis"
                class="bg-[#101E36] text-[#E6EDF7] border border-[#A7B5C8]/20 rounded px-2 py-1 text-xs cursor-pointer"
              >
                <option value="none">No Slice</option>
                <option value="xy">XY Slice</option>
                <option value="xz">XZ Slice</option>
                <option value="yz">YZ Slice</option>
              </select>
              @if (sliceAxis() !== 'none') {
                <input
                  type="range"
                  min="0.05"
                  max="0.95"
                  step="0.02"
                  [value]="sliceNormalized()"
                  (input)="onSlicePosInput($event)"
                  class="w-16 accent-[#D7AD59] cursor-pointer"
                />
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class StackViewer3D implements OnInit {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly destroyRef = inject(DestroyRef);
  private readonly canvasHost = viewChild<ElementRef<HTMLDivElement>>('canvasHost');

  readonly result = input<SimulationResult | null>(null);
  readonly selectedLayerId = input<string | null>(null);
  readonly explodeFactor = input<number>(0);
  readonly sliceAxis = input<SliceAxis>('none');
  readonly sliceNormalized = input<number>(0.5);
  readonly showTsvs = input<boolean>(true);
  readonly showFluxVectors = input<boolean>(false);
  readonly spreaderOpacity = input<number>(0.28);
  readonly colorMode = input<ViewerColorMode>('thermal');

  readonly layerSelected = output<string>();
  readonly explodeChange = output<number>();
  readonly sliceAxisChange = output<SliceAxis>();
  readonly slicePosChange = output<number>();
  readonly showTsvChange = output<boolean>();
  readonly showFluxChange = output<boolean>();
  readonly colorModeChange = output<ViewerColorMode>();

  readonly dockCollapsed = signal(false);
  readonly webglUnavailable = signal(false);
  readonly explodeTarget = computed(() => this.explodeFactor());

  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private controls: OrbitControls | null = null;
  private rootGroup: THREE.Group | null = null;
  private sliceGroup: THREE.Group | null = null;
  private fluxGroup: THREE.Group | null = null;
  private tsvGroup: THREE.Group | null = null;

  private layerEntries: {
    layerId: string;
    mesh: THREE.Mesh;
    baseY: number;
    explodeOffset: number;
  }[] = [];

  private pickables: THREE.Object3D[] = [];
  private raycaster = new THREE.Raycaster();
  private pointerVec = new THREE.Vector2();

  private isSoftwareGl = false;
  private frameId = 0;
  private renderBusy = false;
  private renderDirty = false;
  private currentExplode = 0;
  private animActive = false;
  private lastTickTime = 0;
  private initialized = false;

  // Reusable camera transition target
  private camAnimTargetPos: THREE.Vector3 | null = null;
  private camAnimTargetLook: THREE.Vector3 | null = null;

  constructor() {
    effect(() => {
      const res = this.result();
      const mode = this.colorMode();
      const spOp = this.spreaderOpacity();
      const sel = this.selectedLayerId();
      if (this.initialized && res) {
        this.rebuildPackageScene(res, mode, spOp, sel);
        this.requestRender();
      }
    });

    effect(() => {
      const showT = this.showTsvs();
      if (this.tsvGroup) {
        this.tsvGroup.visible = showT;
        this.requestRender();
      }
    });

    effect(() => {
      const showF = this.showFluxVectors();
      if (this.fluxGroup) {
        this.fluxGroup.visible = showF;
        this.requestRender();
      }
    });

    effect(() => {
      const axis = this.sliceAxis();
      const pos = this.sliceNormalized();
      const res = this.result();
      if (this.initialized && res) {
        this.rebuildSlicePlane(res, axis, pos);
        this.requestRender();
      }
    });

    effect(() => {
      const target = this.explodeFactor();
      if (this.initialized && Math.abs(target - this.currentExplode) > 1e-3) {
        this.startAnimationLoop();
      }
    });
  }

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    setTimeout(() => this.initWebGL(), 0);
  }

  private initWebGL(): void {
    const hostEl = this.canvasHost()?.nativeElement;
    if (!hostEl) return;

    try {
      this.isSoftwareGl = (() => {
        const probe = document.createElement('canvas').getContext('webgl2');
        if (!probe) return true;
        const ext = probe.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
        const gpu = String(probe.getParameter(param));
        probe.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      })();

      const renderer = new THREE.WebGLRenderer({
        antialias: !this.isSoftwareGl,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.08;
      renderer.setPixelRatio(
        this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
      );
      renderer.shadowMap.enabled = !this.isSoftwareGl;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      const w = Math.max(hostEl.clientWidth, 400);
      const h = Math.max(hostEl.clientHeight, 360);
      renderer.setSize(w, h);
      hostEl.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x07101f);
      scene.fog = new THREE.FogExp2(0x07101f, 0.014);

      const pmrem = new THREE.PMREMGenerator(renderer);
      scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();

      const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 250);
      camera.position.set(16, 13, 18);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = !this.isSoftwareGl;
      controls.dampingFactor = 0.07;
      controls.target.set(0, 1.8, 0);
      controls.minDistance = 6;
      controls.maxDistance = 65;

      controls.addEventListener('change', () => this.requestRender());
      controls.addEventListener('start', () => {
        this.camAnimTargetPos = null;
        this.camAnimTargetLook = null;
      });

      // 3-point warm/cool studio lighting
      const hemi = new THREE.HemisphereLight(0xa5d8ff, 0x0b182d, 0.65);
      scene.add(hemi);

      const keyLight = new THREE.DirectionalLight(0xfff1d6, 1.4);
      keyLight.position.set(14, 22, 12);
      keyLight.castShadow = !this.isSoftwareGl;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
      scene.add(keyLight);

      const rimLight = new THREE.DirectionalLight(0x1ccce5, 0.55);
      rimLight.position.set(-14, 10, -14);
      scene.add(rimLight);

      // Calibration reference grid plane
      const grid = new THREE.GridHelper(32, 32, 0x1e3a5f, 0x10223b);
      grid.position.y = -0.02;
      scene.add(grid);

      this.rootGroup = new THREE.Group();
      this.tsvGroup = new THREE.Group();
      this.fluxGroup = new THREE.Group();
      this.sliceGroup = new THREE.Group();
      scene.add(this.rootGroup);
      scene.add(this.tsvGroup);
      scene.add(this.fluxGroup);
      scene.add(this.sliceGroup);

      this.renderer = renderer;
      this.scene = scene;
      this.camera = camera;
      this.controls = controls;
      this.initialized = true;

      // Resize handling
      const ro = new ResizeObserver(() => {
        if (!this.renderer || !this.camera) return;
        const cw = hostEl.clientWidth;
        const ch = hostEl.clientHeight;
        if (cw > 10 && ch > 10) {
          this.camera.aspect = cw / ch;
          this.camera.updateProjectionMatrix();
          this.renderer.setSize(cw, ch);
          this.requestRender();
        }
      });
      ro.observe(hostEl);

      // Click picking
      const onPointerDown = (ev: PointerEvent) => {
        if (!this.camera || !this.renderer) return;
        const rect = this.renderer.domElement.getBoundingClientRect();
        this.pointerVec.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
        this.pointerVec.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
        this.raycaster.setFromCamera(this.pointerVec, this.camera);
        const hits = this.raycaster.intersectObjects(this.pickables, false);
        if (hits.length > 0) {
          const lid = hits[0].object.userData['layerId'] as string | undefined;
          if (lid) this.layerSelected.emit(lid);
        }
      };
      renderer.domElement.addEventListener('pointerdown', onPointerDown);

      renderer.domElement.addEventListener('webglcontextlost', (e) => {
        e.preventDefault();
        this.webglUnavailable.set(true);
      });
      renderer.domElement.addEventListener('webglcontextrestored', () => {
        this.webglUnavailable.set(false);
        this.requestRender();
      });

      const currentRes = this.result();
      if (currentRes) {
        this.rebuildPackageScene(
          currentRes,
          this.colorMode(),
          this.spreaderOpacity(),
          this.selectedLayerId(),
        );
        this.rebuildSlicePlane(currentRes, this.sliceAxis(), this.sliceNormalized());
      }
      this.requestRender();

      this.destroyRef.onDestroy(() => {
        cancelAnimationFrame(this.frameId);
        clearTimeout(this.frameId);
        ro.disconnect();
        renderer.domElement.removeEventListener('pointerdown', onPointerDown);
        controls.dispose();
        this.clearGroup(this.rootGroup);
        this.clearGroup(this.tsvGroup);
        this.clearGroup(this.fluxGroup);
        this.clearGroup(this.sliceGroup);
        renderer.dispose();
      });
    } catch {
      this.webglUnavailable.set(true);
    }
  }

  setCameraPreset(preset: 'iso' | 'front' | 'top'): void {
    if (!this.camera || !this.controls) return;
    const look = new THREE.Vector3(0, 1.8 + this.currentExplode * 3.0, 0);
    if (preset === 'iso') {
      this.camAnimTargetPos = new THREE.Vector3(16, 13 + this.currentExplode * 3, 18);
    } else if (preset === 'front') {
      this.camAnimTargetPos = new THREE.Vector3(0, 3.0 + this.currentExplode * 3, 24);
    } else {
      this.camAnimTargetPos = new THREE.Vector3(0, 26, 0.01);
    }
    this.camAnimTargetLook = look;
    this.startAnimationLoop();
  }

  onExplodeInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    this.explodeChange.emit(val);
  }

  onSliceAxisChange(ev: Event): void {
    const val = (ev.target as HTMLSelectElement).value as SliceAxis;
    this.sliceAxisChange.emit(val);
  }

  onSlicePosInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    this.slicePosChange.emit(val);
  }

  private clearGroup(group: THREE.Group | null): void {
    if (!group) return;
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      child.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          for (const m of mats) {
            const std = m as THREE.MeshStandardMaterial;
            std.map?.dispose();
            m.dispose();
          }
        }
      });
    }
  }

  private buildLayerThermalTexture(
    res: SimulationResult,
    zCenterMm: number,
  ): THREE.DataTexture {
    const { nx, ny, nz, zCentersMm, temperaturesK } = res.field3D;
    // Find nearest Z index in solved 3D field
    let bestK = 0;
    let bestDist = Infinity;
    for (let k = 0; k < nz; k++) {
      const d = Math.abs(zCentersMm[k] - zCenterMm);
      if (d < bestDist) {
        bestDist = d;
        bestK = k;
      }
    }

    const tMin = res.summary.minTempK;
    const tRange = Math.max(res.summary.peakTempK - tMin, 0.5);
    const data = new Uint8Array(nx * ny * 4);

    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const T = temperaturesK[bestK * ny * nx + j * nx + i];
        const norm = (T - tMin) / tRange;
        const [r, g, b] = sampleThermalColorRGB(norm);
        const px = (j * nx + i) * 4;
        data[px] = r;
        data[px + 1] = g;
        data[px + 2] = b;
        data[px + 3] = 255;
      }
    }
    const tex = new THREE.DataTexture(data, nx, ny, THREE.RGBAFormat);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.magFilter = THREE.LinearFilter;
    tex.minFilter = THREE.LinearFilter;
    if (this.renderer) {
      tex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    }
    tex.needsUpdate = true;
    return tex;
  }

  private rebuildPackageScene(
    res: SimulationResult,
    colorMode: ViewerColorMode,
    spreaderOpacity: number,
    selectedLayerId: string | null,
  ): void {
    if (!this.rootGroup || !this.tsvGroup || !this.fluxGroup) return;
    this.clearGroup(this.rootGroup);
    this.clearGroup(this.tsvGroup);
    this.clearGroup(this.fluxGroup);
    this.layerEntries = [];
    this.pickables = [];

    const geom = res.geometry;
    // Scale 1 mm -> 1 Three.js world unit; exaggerate vertical Z slightly (3.5x) so micron dies & bonding layers are cleanly inspectable
    const xyScale = 1000; // m -> mm
    const zScale = 3500; // m -> visual mm (3.5x vertical clarity)
    const cxDomain = geom.domainWidthM * 0.5 * xyScale;
    const czDomain = geom.domainDepthM * 0.5 * xyScale;

    let dramOrdinal = 0;
    for (const layer of geom.layers) {
      const w = layer.widthM * xyScale;
      const d = layer.depthM * xyScale;
      const h = Math.max(layer.thicknessM * zScale, 0.04);
      const baseY = (layer.zMinM + layer.thicknessM * 0.5) * zScale;
      const xPos = layer.xCenterM * xyScale - cxDomain;
      const zPos = layer.yCenterM * xyScale - czDomain;

      const boxGeo = new THREE.BoxGeometry(w, h, d);
      const isSpreader = layer.kind === 'heat_spreader';
      const isTim = layer.kind === 'tim';
      const isSelected = selectedLayerId === layer.id;

      let mat: THREE.MeshStandardMaterial;
      if (colorMode === 'thermal' && !isSpreader) {
        const tex = this.buildLayerThermalTexture(
          res,
          0.5 * (layer.zMinM + layer.zMaxM) * 1e3,
        );
        mat = new THREE.MeshStandardMaterial({
          map: tex,
          roughness: layer.kind === 'dram_die' || layer.kind === 'base_die' ? 0.32 : 0.65,
          metalness: layer.kind === 'dram_die' ? 0.15 : 0.05,
          emissive: isSelected ? new THREE.Color(0x1ccce5) : new THREE.Color(0x000000),
          emissiveIntensity: isSelected ? 0.35 : 0,
        });
      } else {
        const hex = MATERIAL_HEX[layer.kind] ?? 0x64748b;
        mat = new THREE.MeshStandardMaterial({
          color: hex,
          roughness: isSpreader ? 0.22 : layer.kind === 'bonding' ? 0.72 : 0.38,
          metalness: isSpreader ? 0.88 : layer.kind === 'dram_die' ? 0.3 : 0.1,
          transparent: isSpreader || isTim,
          opacity: isSpreader ? spreaderOpacity : isTim ? 0.75 : 1.0,
          depthWrite: !isSpreader,
          emissive: isSelected ? new THREE.Color(0xd7ad59) : new THREE.Color(0x000000),
          emissiveIntensity: isSelected ? 0.35 : 0,
        });
      }

      const mesh = new THREE.Mesh(boxGeo, mat);
      mesh.position.set(xPos, baseY, zPos);
      mesh.userData['layerId'] = layer.id;

      // Crisp silhouette edges for die-by-die legibility
      const edges = new THREE.LineSegments(
        new THREE.EdgesGeometry(boxGeo),
        new THREE.LineBasicMaterial({
          color: isSelected ? 0x1ccce5 : 0x0b182d,
          transparent: true,
          opacity: isSelected ? 0.95 : 0.35,
        }),
      );
      mesh.add(edges);

      let explodeOffset = 0;
      if (layer.kind === 'base_die') explodeOffset = 0.6;
      else if (layer.kind === 'bonding') explodeOffset = 0.9 + dramOrdinal * 0.42;
      else if (layer.kind === 'dram_die') {
        explodeOffset = 1.05 + dramOrdinal * 0.42;
        dramOrdinal++;
      } else if (layer.kind === 'tim') {
        explodeOffset = 1.25 + geom.dramDieCount * 0.42;
      } else if (layer.kind === 'heat_spreader') {
        explodeOffset = 1.6 + geom.dramDieCount * 0.42;
      }

      mesh.position.y = baseY + explodeOffset * this.currentExplode;
      this.rootGroup.add(mesh);
      this.pickables.push(mesh);
      this.layerEntries.push({ layerId: layer.id, mesh, baseY, explodeOffset });
    }

    // Optional SilicaFlux-HPC Accelerator Die
    if (geom.acceleratorBox) {
      const acc = geom.acceleratorBox;
      const w = (acc.xMax - acc.xMin) * xyScale;
      const d = (acc.yMax - acc.yMin) * xyScale;
      const h = (acc.zMax - acc.zMin) * zScale;
      const xPos = 0.5 * (acc.xMin + acc.xMax) * xyScale - cxDomain;
      const zPos = 0.5 * (acc.yMin + acc.yMax) * xyScale - czDomain;
      const yPos = 0.5 * (acc.zMin + acc.zMax) * zScale;
      const accGeo = new THREE.BoxGeometry(w, h, d);
      const tex = this.buildLayerThermalTexture(res, 0.5 * (acc.zMin + acc.zMax) * 1e3);
      const accMat = new THREE.MeshStandardMaterial({
        map: colorMode === 'thermal' ? tex : undefined,
        color: colorMode === 'thermal' ? 0xffffff : 0x3b82f6,
        roughness: 0.28,
        metalness: 0.2,
      });
      const accMesh = new THREE.Mesh(accGeo, accMat);
      accMesh.position.set(xPos, yPos, zPos);
      accMesh.userData['layerId'] = 'accelerator_die';
      this.rootGroup.add(accMesh);
      this.pickables.push(accMesh);
    }

    // Hotspot Marker Ring at exact solved [X, Y, Z]
    const hs = res.hotspot.positionMm;
    const hsGeo = new THREE.TorusGeometry(0.45, 0.06, 12, 24);
    hsGeo.rotateX(Math.PI / 2);
    const hsMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const hsRing = new THREE.Mesh(hsGeo, hsMat);
    hsRing.position.set(
      hs[0] - cxDomain,
      hs[2] * 3.5 + 0.15,
      hs[1] - czDomain,
    );
    this.rootGroup.add(hsRing);

    // Instanced TSV Array Visualization
    if (res.config.tsv.cuFraction > 0) {
      const hbm = geom.hbmBox;
      const hbmW = (hbm.xMax - hbm.xMin) * xyScale;
      const hbmD = (hbm.yMax - hbm.yMin) * xyScale;
      const hbmCX = 0.5 * (hbm.xMin + hbm.xMax) * xyScale - cxDomain;
      const hbmCZ = 0.5 * (hbm.yMin + hbm.yMax) * xyScale - czDomain;
      const tsvBottom = hbm.zMin * zScale;
      const tsvTop = hbm.zMax * zScale;
      const tsvH = Math.max(tsvTop - tsvBottom, 0.2);

      const positions: [number, number][] = [];
      const cols = 6;
      const rows = 10;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const u = (c + 0.5) / cols - 0.5;
          const v = (r + 0.5) / rows - 0.5;
          if (
            res.config.tsv.placement === 'central_spine' &&
            Math.abs(u) > res.config.tsv.tsvRegionWidthFraction * 0.5
          ) {
            continue;
          }
          if (
            res.config.tsv.placement === 'peripheral_ring' &&
            Math.abs(u) < 0.35 &&
            Math.abs(v) < 0.35
          ) {
            continue;
          }
          positions.push([hbmCX + u * hbmW * 0.85, hbmCZ + v * hbmD * 0.85]);
        }
      }

      if (positions.length > 0) {
        const cylGeo = new THREE.CylinderGeometry(0.06, 0.06, tsvH, 8);
        const cuMat = new THREE.MeshStandardMaterial({
          color: 0xd7ad59,
          metalness: 0.92,
          roughness: 0.2,
        });
        const inst = new THREE.InstancedMesh(cylGeo, cuMat, positions.length);
        const dummy = new THREE.Object3D();
        positions.forEach(([px, pz], idx) => {
          dummy.position.set(px, tsvBottom + tsvH * 0.5, pz);
          dummy.updateMatrix();
          inst.setMatrixAt(idx, dummy.matrix);
        });
        inst.instanceMatrix.needsUpdate = true;
        inst.computeBoundingSphere();
        this.tsvGroup.add(inst);
      }
    }
    this.tsvGroup.visible = this.showTsvs();

    // 3D Heat-Flux Vectors (q = -K grad T)
    const fluxSamples = res.field3D.fluxVectorsSample;
    if (fluxSamples.length > 0) {
      let maxQ = 1e-6;
      for (const f of fluxSamples) {
        maxQ = Math.max(maxQ, Math.hypot(f.qx, f.qy, f.qz));
      }
      const dir = new THREE.Vector3();
      for (const f of fluxSamples) {
        const mag = Math.hypot(f.qx, f.qy, f.qz);
        if (mag < maxQ * 0.08) continue;
        // Map simulation (X, Y, Z) -> Three.js (X, Z_up, Y)
        dir.set(f.qx, f.qz, f.qy).normalize();
        const origin = new THREE.Vector3(
          f.xMm - cxDomain,
          f.zMm * 3.5,
          f.yMm - czDomain,
        );
        const len = 0.5 + 1.3 * (mag / maxQ);
        const arrow = new THREE.ArrowHelper(dir, origin, len, 0x1ccce5, 0.25, 0.14);
        this.fluxGroup.add(arrow);
      }
    }
    this.fluxGroup.visible = this.showFluxVectors();
  }

  private rebuildSlicePlane(
    res: SimulationResult,
    axis: SliceAxis,
    normPos: number,
  ): void {
    if (!this.sliceGroup) return;
    this.clearGroup(this.sliceGroup);
    if (axis === 'none') return;

    const { nx, ny, nz, xCentersMm, yCentersMm, zCentersMm, temperaturesK } = res.field3D;
    const geom = res.geometry;
    const wMm = geom.domainWidthM * 1e3;
    const dMm = geom.domainDepthM * 1e3;
    const hVisual = geom.totalHeightM * 3500;
    const tMin = res.summary.minTempK;
    const tRange = Math.max(res.summary.peakTempK - tMin, 0.5);

    let texW = nx;
    let texH = ny;
    let planeW = wMm;
    let planeH = dMm;
    const pos = new THREE.Vector3(0, hVisual * 0.5, 0);
    const rot = new THREE.Euler(0, 0, 0);

    let data: Uint8Array;
    if (axis === 'xy') {
      const kIdx = Math.min(nz - 1, Math.max(0, Math.round(normPos * (nz - 1))));
      texW = nx;
      texH = ny;
      planeW = wMm;
      planeH = dMm;
      data = new Uint8Array(texW * texH * 4);
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const [r, g, b] = sampleThermalColorRGB(
            (temperaturesK[kIdx * ny * nx + j * nx + i] - tMin) / tRange,
          );
          const p = (j * nx + i) * 4;
          data[p] = r;
          data[p + 1] = g;
          data[p + 2] = b;
          data[p + 3] = 230;
        }
      }
      rot.x = -Math.PI / 2;
      pos.set(0, zCentersMm[kIdx] * 3.5 + 0.03, 0);
    } else if (axis === 'xz') {
      const jIdx = Math.min(ny - 1, Math.max(0, Math.round(normPos * (ny - 1))));
      texW = nx;
      texH = nz;
      planeW = wMm;
      planeH = hVisual;
      data = new Uint8Array(texW * texH * 4);
      for (let k = 0; k < nz; k++) {
        for (let i = 0; i < nx; i++) {
          const [r, g, b] = sampleThermalColorRGB(
            (temperaturesK[k * ny * nx + jIdx * nx + i] - tMin) / tRange,
          );
          const p = (k * nx + i) * 4;
          data[p] = r;
          data[p + 1] = g;
          data[p + 2] = b;
          data[p + 3] = 230;
        }
      }
      pos.set(0, hVisual * 0.5, yCentersMm[jIdx] - dMm * 0.5);
    } else {
      const iIdx = Math.min(nx - 1, Math.max(0, Math.round(normPos * (nx - 1))));
      texW = ny;
      texH = nz;
      planeW = dMm;
      planeH = hVisual;
      data = new Uint8Array(texW * texH * 4);
      for (let k = 0; k < nz; k++) {
        for (let j = 0; j < ny; j++) {
          const [r, g, b] = sampleThermalColorRGB(
            (temperaturesK[k * ny * nx + j * nx + iIdx] - tMin) / tRange,
          );
          const p = (k * ny + j) * 4;
          data[p] = r;
          data[p + 1] = g;
          data[p + 2] = b;
          data[p + 3] = 230;
        }
      }
      rot.y = Math.PI / 2;
      pos.set(xCentersMm[iIdx] - wMm * 0.5, hVisual * 0.5, 0);
    }

    const tex = new THREE.DataTexture(data, texW, texH, THREE.RGBAFormat);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.magFilter = THREE.LinearFilter;
    tex.needsUpdate = true;

    const pGeo = new THREE.PlaneGeometry(planeW, planeH);
    const pMat = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const pMesh = new THREE.Mesh(pGeo, pMat);
    pMesh.position.copy(pos);
    pMesh.rotation.copy(rot);
    pMesh.renderOrder = 20;

    const border = new THREE.LineSegments(
      new THREE.EdgesGeometry(pGeo),
      new THREE.LineBasicMaterial({ color: 0xd7ad59 }),
    );
    pMesh.add(border);
    this.sliceGroup.add(pMesh);
  }

  private startAnimationLoop(): void {
    if (this.animActive) return;
    this.animActive = true;
    this.lastTickTime = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = Math.min((now - this.lastTickTime) / 1000, 0.05);
      this.lastTickTime = now;

      let moving = false;
      const targetEx = this.explodeFactor();
      if (Math.abs(targetEx - this.currentExplode) > 0.002) {
        this.currentExplode = THREE.MathUtils.damp(this.currentExplode, targetEx, 10, dt);
        for (const entry of this.layerEntries) {
          entry.mesh.position.y = entry.baseY + entry.explodeOffset * this.currentExplode;
        }
        moving = true;
      } else if (this.currentExplode !== targetEx) {
        this.currentExplode = targetEx;
        for (const entry of this.layerEntries) {
          entry.mesh.position.y = entry.baseY + entry.explodeOffset * this.currentExplode;
        }
      }

      if (this.camAnimTargetPos && this.camera && this.controls) {
        const alpha = 1 - Math.exp(-8 * dt);
        this.camera.position.lerp(this.camAnimTargetPos, alpha);
        if (this.camAnimTargetLook) {
          this.controls.target.lerp(this.camAnimTargetLook, alpha);
        }
        if (this.camera.position.distanceTo(this.camAnimTargetPos) < 0.05) {
          this.camera.position.copy(this.camAnimTargetPos);
          this.camAnimTargetPos = null;
          this.camAnimTargetLook = null;
        } else {
          moving = true;
        }
      }

      if (this.controls) this.controls.update();
      if (this.renderer && this.scene && this.camera) {
        this.renderer.render(this.scene, this.camera);
      }

      if (moving) {
        if (this.isSoftwareGl) {
          this.afterDraw(tick);
        } else {
          this.frameId = requestAnimationFrame(tick);
        }
      } else {
        this.animActive = false;
      }
    };
    this.frameId = requestAnimationFrame(tick);
  }

  private afterDraw(cb: () => void): void {
    if (!this.renderer) return;
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private requestRender(): void {
    if (!this.renderer || !this.scene || !this.camera || !this.controls) return;
    if (this.renderBusy) {
      this.renderDirty = true;
      return;
    }
    this.renderBusy = true;
    this.frameId = requestAnimationFrame(() => {
      this.renderDirty = false;
      this.controls?.update();
      if (this.renderer && this.scene && this.camera) {
        this.renderer.render(this.scene, this.camera);
      }
      const done = () => {
        this.renderBusy = false;
        if (this.renderDirty) this.requestRender();
      };
      if (this.isSoftwareGl) this.afterDraw(done);
      else done();
    });
  }
}
