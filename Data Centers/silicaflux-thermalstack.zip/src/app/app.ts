import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import {
  applyCoolingPreset,
  applySpreaderPreset,
} from '../simulation/geometry';
import {
  CoolingMode,
  InterfaceQualityMode,
  SpreaderPreset,
  StackPresetId,
  TsvFidelityMode,
  TsvPlacement,
  WorkloadScenario,
} from '../simulation/types';
import { SweepParameterKey } from '../simulation/analysis';
import {
  DepthProfileChart,
  DieTemperatureChart,
  ParetoChart,
  SweepChart,
  ThermalHeatmap2D,
  TransientChart,
} from './components/scientific-charts';
import {
  SliceAxis,
  StackViewer3D,
  ViewerColorMode,
} from './components/stack-viewer-3d';
import { ExperimentItem, ThermalstackApi } from './services/thermalstack-api';

export type NavSection =
  | 'overview'
  | 'stack_designer'
  | 'materials'
  | 'power_maps'
  | 'thermal_solver'
  | 'cooling'
  | 'comparisons'
  | 'optimisation'
  | 'validation'
  | 'reports';

export type BottomChartTab =
  | 'per_die'
  | 'heatmap_2d'
  | 'depth_profile'
  | 'resistance'
  | 'gradients'
  | 'transient';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    StackViewer3D,
    DieTemperatureChart,
    ThermalHeatmap2D,
    DepthProfileChart,
    TransientChart,
    ParetoChart,
    SweepChart,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly Math = Math;
  private readonly platformId = inject(PLATFORM_ID);
  readonly api = inject(ThermalstackApi);

  readonly navItems: { id: NavSection; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'stack_designer', label: 'Stack Designer' },
    { id: 'materials', label: 'Materials' },
    { id: 'power_maps', label: 'Power Maps' },
    { id: 'thermal_solver', label: 'Thermal Solver' },
    { id: 'cooling', label: 'Cooling' },
    { id: 'comparisons', label: 'Comparisons' },
    { id: 'optimisation', label: 'Optimisation' },
    { id: 'validation', label: 'Validation' },
    { id: 'reports', label: 'Reports' },
  ];

  readonly activeNav = signal<NavSection>('overview');
  readonly activeBottomTab = signal<BottomChartTab>('per_die');

  // 3D Viewer State
  readonly selectedLayerId = signal<string | null>(null);
  readonly explodeFactor = signal<number>(0);
  readonly sliceAxis = signal<SliceAxis>('none');
  readonly sliceNormalized = signal<number>(0.5);
  readonly showTsvs = signal<boolean>(true);
  readonly showFluxVectors = signal<boolean>(false);
  readonly spreaderOpacity = signal<number>(0.26);
  readonly colorMode = signal<ViewerColorMode>('thermal');

  // Sweep & Optimisation UI parameters
  readonly sweepParam = signal<SweepParameterKey>('contact_resistance_mm2kw');
  readonly optMaxHeightMm = signal<number>(3.2);
  readonly optMaxTsvPct = signal<number>(18);
  readonly optMaxH = signal<number>(10000);

  // Power trace CSV import buffer
  readonly traceStatus = signal<string | null>(null);

  readonly selectedLayerDetails = computed(() => {
    const res = this.api.result();
    const id = this.selectedLayerId();
    if (!res || !id) return null;
    return res.layers.find((l) => l.layerId === id) ?? null;
  });

  readonly uses3DWorkspace = computed(() => {
    const n = this.activeNav();
    return (
      n === 'overview' ||
      n === 'stack_designer' ||
      n === 'power_maps' ||
      n === 'thermal_solver' ||
      n === 'cooling'
    );
  });

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      void this.api.initialize();
    }
  }

  onPresetChange(ev: Event): void {
    const preset = (ev.target as HTMLSelectElement).value as StackPresetId;
    void this.api.selectPreset(preset);
  }

  onExperimentChange(ev: Event): void {
    const id = (ev.target as HTMLSelectElement).value;
    const exp = this.api.experiments().find((e) => e.id === id);
    if (exp) void this.api.loadExperiment(exp);
  }

  loadExperimentClick(exp: ExperimentItem): void {
    void this.api.loadExperiment(exp);
  }

  onBondingMatChange(ev: Event): void {
    const id = (ev.target as HTMLSelectElement).value;
    this.api.updateConfig((c) => ({
      ...c,
      geometry: { ...c.geometry, bondingMaterialId: id },
    }));
  }

  onTimMatChange(ev: Event): void {
    const id = (ev.target as HTMLSelectElement).value;
    this.api.updateConfig((c) => ({
      ...c,
      geometry: { ...c.geometry, timMaterialId: id },
    }));
  }

  onSpreaderPresetChange(ev: Event): void {
    const preset = (ev.target as HTMLSelectElement).value as SpreaderPreset;
    this.api.updateConfig((c) => ({
      ...c,
      geometry: applySpreaderPreset(c.geometry, preset),
      cooling: { ...c.cooling, spreaderPreset: preset },
    }));
  }

  onCoolingModeChange(ev: Event): void {
    const mode = (ev.target as HTMLSelectElement).value as CoolingMode;
    this.api.updateConfig((c) => ({
      ...c,
      cooling: applyCoolingPreset(c.cooling, mode),
    }));
  }

  onInterfaceModeChange(ev: Event): void {
    const mode = (ev.target as HTMLSelectElement).value as InterfaceQualityMode;
    this.api.updateConfig((c) => {
      const next = structuredClone(c);
      const primary = next.interfaces[0];
      primary.qualityMode = mode;
      primary.assumedFaultModel = mode !== 'nominal' && mode !== 'ideal_zero';
      primary.rContactAreaM2KW =
        mode === 'ideal_zero'
          ? 0
          : mode === 'nominal'
            ? 4.5e-6
            : mode === 'degraded_2x'
              ? 12e-6
              : mode === 'nonuniform_edge_void'
                ? 14e-6
                : 24e-6;
      return next;
    });
  }

  onTsvModeChange(ev: Event): void {
    const mode = (ev.target as HTMLSelectElement).value as TsvFidelityMode;
    this.api.updateConfig((c) => ({ ...c, tsv: { ...c.tsv, mode } }));
  }

  onTsvPlacementChange(ev: Event): void {
    const placement = (ev.target as HTMLSelectElement).value as TsvPlacement;
    this.api.updateConfig((c) => ({ ...c, tsv: { ...c.tsv, placement } }));
  }

  onTsvFractionInput(ev: Event): void {
    const pct = parseFloat((ev.target as HTMLInputElement).value);
    this.api.updateConfig((c) => ({
      ...c,
      tsv: { ...c.tsv, cuFraction: pct / 100 },
    }));
  }

  onDramThickInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.api.updateConfig((c) => ({
        ...c,
        geometry: { ...c.geometry, dramDieThicknessUm: val },
      }));
    }
  }

  onBondThickInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.api.updateConfig((c) => ({
        ...c,
        geometry: { ...c.geometry, bondingThicknessUm: val },
      }));
    }
  }

  onBasePowerInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val >= 0) {
      this.api.updateConfig((c) => ({
        ...c,
        heatSources: { ...c.heatSources, baseDiePowerW: val },
      }));
    }
  }

  onDramUniformPowerInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val >= 0) {
      this.api.updateConfig((c) => ({
        ...c,
        heatSources: {
          ...c.heatSources,
          dramPowersW: c.heatSources.dramPowersW.map(() => val),
        },
      }));
    }
  }

  onSingleDramPowerInput(dieIdx: number, ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val >= 0) {
      this.api.updateConfig((c) => {
        const powers = [...c.heatSources.dramPowersW];
        powers[dieIdx] = val;
        return { ...c, heatSources: { ...c.heatSources, dramPowersW: powers } };
      });
    }
  }

  onWorkloadChange(ev: Event): void {
    const scenario = (ev.target as HTMLSelectElement).value as WorkloadScenario;
    this.api.updateConfig((c) => {
      const n = c.geometry.dramDieCount;
      let perDie = 2.2;
      let base = 6.5;
      let uneven = false;
      if (scenario === 'idle') {
        perDie = 0.25;
        base = 1.1;
      } else if (scenario === 'sustained_read') {
        perDie = 1.9;
        base = 5.5;
      } else if (scenario === 'sustained_write') {
        perDie = 2.5;
        base = 6.8;
      } else if (scenario === 'tensor_hbw') {
        perDie = 2.8;
        base = 8.2;
      } else if (scenario === 'burst_activity') {
        perDie = 3.4;
        base = 9.5;
      } else if (scenario === 'refresh_dominated') {
        perDie = 1.1;
        base = 2.5;
      } else if (scenario === 'uneven_die_activity') {
        uneven = true;
      }
      const dramPowersW = Array.from({ length: n }, (_, i) =>
        uneven ? (i < n / 2 ? 3.2 : 1.4) : perDie,
      );
      return {
        ...c,
        heatSources: {
          ...c.heatSources,
          workload: scenario,
          dramPowersW,
          baseDiePowerW: base,
        },
      };
    });
  }

  toggleAccelerator(): void {
    this.api.updateConfig((c) => {
      const inc = !c.geometry.includeAccelerator;
      return {
        ...c,
        geometry: {
          ...c.geometry,
          includeAccelerator: inc,
          spreaderWidthMm: inc ? 28 : 18,
          spreaderDepthMm: inc ? 22 : 18,
        },
      };
    });
  }

  onAccelPowerInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val >= 0) {
      this.api.updateConfig((c) => ({
        ...c,
        heatSources: { ...c.heatSources, acceleratorPowerW: val },
      }));
    }
  }

  onHTopInput(ev: Event): void {
    const val = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val >= 0) {
      this.api.updateConfig((c) => ({
        ...c,
        cooling: { ...c.cooling, hTopWm2K: val },
      }));
    }
  }

  onTAmbientCInput(ev: Event): void {
    const valC = parseFloat((ev.target as HTMLInputElement).value);
    if (Number.isFinite(valC)) {
      this.api.updateConfig((c) => ({
        ...c,
        cooling: { ...c.cooling, tAmbientK: valC + 273.15 },
      }));
    }
  }

  onMeshNxInput(ev: Event): void {
    const n = parseInt((ev.target as HTMLInputElement).value, 10);
    if (Number.isFinite(n) && n >= 4 && n <= 28) {
      this.api.updateConfig((c) => ({
        ...c,
        mesh: { ...c.mesh, nx: n, ny: n },
      }));
    }
  }

  onStudyTypeChange(ev: Event): void {
    const studyType = (ev.target as HTMLSelectElement).value as 'steady_state' | 'transient';
    this.api.updateConfig((c) => ({
      ...c,
      solver: { ...c.solver, studyType },
    }));
  }

  toggleTempDependentK(): void {
    this.api.updateConfig((c) => ({
      ...c,
      solver: { ...c.solver, useTempDependentK: !c.solver.useTempDependentK },
    }));
  }

  toggleElectrothermal(): void {
    this.api.updateConfig((c) => ({
      ...c,
      heatSources: {
        ...c.heatSources,
        electrothermalEnabled: !c.heatSources.electrothermalEnabled,
      },
    }));
  }

  applyBurstTransientTrace(): void {
    this.api.updateConfig((c) => ({
      ...c,
      solver: {
        ...c.solver,
        studyType: 'transient',
        dtSeconds: 0.025,
        totalTimeSeconds: 0.6,
      },
      heatSources: {
        ...c.heatSources,
        timeTrace: {
          timesS: [0, 0.1, 0.25, 0.35, 0.5, 0.6],
          dramScale: [0.3, 1.4, 1.4, 0.4, 1.2, 0.4],
          baseScale: [0.4, 1.3, 1.3, 0.5, 1.1, 0.5],
          accelScale: [0.5, 1.5, 1.5, 0.5, 1.2, 0.5],
        },
      },
    }));
    this.traceStatus.set('Loaded burst workload trace (0.0 - 0.6 s). Click Run Simulation to solve.');
    this.activeBottomTab.set('transient');
    void this.api.runSimulationJob('transient');
  }

  toggleExplodedMode(): void {
    this.explodeFactor.set(this.explodeFactor() > 0.1 ? 0 : 0.85);
  }

  runSelectedSweep(): void {
    const p = this.sweepParam();
    let values: number[] = [2, 4.5, 8, 12, 18, 25];
    if (p === 'tsv_cu_fraction') values = [0.02, 0.06, 0.1, 0.15, 0.22];
    else if (p === 'base_die_power_w') values = [2, 5, 8, 12, 16, 20];
    else if (p === 'dram_per_die_power_w') values = [1.0, 1.8, 2.5, 3.2, 4.0];
    else if (p === 'h_top_wm2k') values = [200, 800, 2000, 3500, 6500, 12000];
    else if (p === 'bonding_thickness_um') values = [6, 10, 14, 18, 24];
    else if (p === 'spreader_thickness_um') values = [500, 1000, 1500, 2200, 3000];
    void this.api.runSweep(p, values);
  }

  onSweepParamChange(ev: Event): void {
    this.sweepParam.set((ev.target as HTMLSelectElement).value as SweepParameterKey);
  }

  runOptClick(): void {
    void this.api.runOptimisation({
      maxPackageHeightMm: this.optMaxHeightMm(),
      maxTsvFraction: this.optMaxTsvPct() / 100,
      maxCoolingH: this.optMaxH(),
    });
  }

  downloadJsonReport(): void {
    const res = this.api.result();
    if (!res) return;
    const blob = new Blob([JSON.stringify(res, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `silicaflux_${res.config.experimentId}_${res.jobId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  downloadMarkdownReport(): void {
    const rep = this.api.generatedReport();
    if (!rep) return;
    const blob = new Blob([rep.markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `silicaflux_report_${rep.jobId}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
