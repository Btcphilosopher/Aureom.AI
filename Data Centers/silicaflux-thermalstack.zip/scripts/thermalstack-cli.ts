import {
  compareCoolingStrategies,
  compareStackHeights,
  runParameterSweep,
  runParetoOptimisation,
  runSimulation,
} from '../src/simulation/analysis';
import {
  benchmarkMeshResolutions,
  EXPERIMENTS_CATALOG,
  generateMarkdownEngineeringReport,
} from '../src/simulation/experiments';
import { buildPackageGeometry, createPresetConfig } from '../src/simulation/geometry';
import { generateStructuredMesh3D } from '../src/simulation/mesh3d';
import { StackPresetId } from '../src/simulation/types';
import { runAllValidationTests } from '../src/simulation/validation';

const args = process.argv.slice(2);
const cmd = args.slice(0, 2).join(' ');

function getFlag(name: string, fallback: string): string {
  const idx = args.indexOf(`--${name}`);
  return idx >= 0 && idx + 1 < args.length ? args[idx + 1] : fallback;
}

const preset = getFlag('preset', 'HBM-12H') as StackPresetId;

if (args[0] === 'validate') {
  const outcomes = runAllValidationTests();
  for (const o of outcomes) {
    console.log(
      `[${o.passed ? 'PASS' : 'FAIL'}] ${o.testId} ${o.title} | ${o.metricName}=${o.computedValue.toExponential(3)} (tol=${o.tolerance})`,
    );
  }
  const failed = outcomes.filter((o) => !o.passed);
  process.exit(failed.length > 0 ? 1 : 0);
} else if (cmd === 'geometry build') {
  const cfg = createPresetConfig(preset);
  const geom = buildPackageGeometry(cfg);
  console.log(JSON.stringify(geom, null, 2));
} else if (cmd === 'mesh generate') {
  const cfg = createPresetConfig(preset);
  const geom = buildPackageGeometry(cfg);
  const mesh = generateStructuredMesh3D(cfg, geom);
  console.log(JSON.stringify(mesh.stats, null, 2));
} else if (cmd === 'solve steady' || cmd === 'solve transient') {
  const expId = getFlag('exp', '');
  const exp = EXPERIMENTS_CATALOG.find((e) => e.id === expId);
  const cfg = exp ? exp.buildConfig() : createPresetConfig(preset);
  if (cmd === 'solve transient') cfg.solver.studyType = 'transient';
  const res = runSimulation(`cli-${Date.now()}`, cfg);
  console.log(generateMarkdownEngineeringReport(res));
} else if (cmd === 'compare stack-heights') {
  const cmp = compareStackHeights(createPresetConfig(preset));
  console.log(JSON.stringify(cmp, null, 2));
} else if (cmd === 'compare cooling') {
  const cmp = compareCoolingStrategies(createPresetConfig(preset));
  console.log(JSON.stringify(cmp, null, 2));
} else if (cmd === 'sweep interfaces') {
  const res = runParameterSweep(
    createPresetConfig(preset),
    'contact_resistance_mm2kw',
    [2, 4.5, 10, 20],
  );
  console.log(JSON.stringify(res, null, 2));
} else if (args[0] === 'optimize') {
  const res = runParetoOptimisation(createPresetConfig(preset), {
    maxPackageHeightMm: 3.0,
    maxTsvFraction: 0.16,
    maxCoolingH: 10000,
  });
  console.log(JSON.stringify(res.optimal, null, 2));
} else if (args[0] === 'benchmark') {
  console.log(JSON.stringify(benchmarkMeshResolutions(createPresetConfig(preset)), null, 2));
} else {
  console.log(`SilicaFlux ThermalStack CLI
Commands:
  validate
  geometry build --preset HBM-8H|HBM-12H|HBM-16H
  mesh generate --preset HBM-12H
  solve steady --preset HBM-12H [--exp exp_b_12h_baseline]
  solve transient --preset HBM-12H
  compare stack-heights
  compare cooling --preset HBM-16H
  sweep interfaces --preset HBM-12H
  optimize --preset HBM-12H
  benchmark --preset HBM-12H`);
}
