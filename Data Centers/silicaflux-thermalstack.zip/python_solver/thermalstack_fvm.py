"""
SilicaFlux ThermalStack — Companion Python + SciPy 3D FVM Reference Solver
For local workstation / HPC cluster execution with NumPy, SciPy, Pydantic, and h5py.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve


@dataclass
class LayerSpec:
    name: str
    thickness_m: float
    kx: float
    ky: float
    kz: float
    rho_cp: float
    power_w: float
    r_contact_above_m2kw: float = 0.0


def solve_layered_3d_fvm(
    width_m: float,
    depth_m: float,
    layers: List[LayerSpec],
    nx: int = 12,
    ny: int = 12,
    h_top: float = 3500.0,
    h_bottom: float = 45.0,
    h_side: float = 25.0,
    t_ambient_k: float = 298.15,
) -> Dict[str, object]:
    """Conservative 3D finite-volume steady-state solver using scipy.sparse."""
    t0 = time.perf_counter()
    nz = len(layers)
    dx = width_m / nx
    dy = depth_m / ny
    dz = np.array([l.thickness_m for l in layers], dtype=np.float64)

    n = nx * ny * nz
    rows: List[int] = []
    cols: List[int] = []
    vals: List[float] = []
    rhs = np.zeros(n, dtype=np.float64)

    def idx(i: int, j: int, k: int) -> int:
        return k * ny * nx + j * nx + i

    area_z = dx * dy
    for k, layer in enumerate(layers):
        area_x = dy * dz[k]
        area_y = dx * dz[k]
        cell_power = layer.power_w / (nx * ny)

        for j in range(ny):
            for i in range(nx):
                c = idx(i, j, k)
                diag = 0.0
                b = cell_power

                # X neighbors
                if i > 0:
                    g = area_x / (dx / (2 * layer.kx) + dx / (2 * layer.kx))
                    rows.append(c); cols.append(idx(i - 1, j, k)); vals.append(-g)
                    diag += g
                elif h_side > 0:
                    g = area_x / (dx / (2 * layer.kx) + 1.0 / h_side)
                    diag += g; b += g * t_ambient_k

                if i < nx - 1:
                    g = area_x / (dx / (2 * layer.kx) + dx / (2 * layer.kx))
                    rows.append(c); cols.append(idx(i + 1, j, k)); vals.append(-g)
                    diag += g
                elif h_side > 0:
                    g = area_x / (dx / (2 * layer.kx) + 1.0 / h_side)
                    diag += g; b += g * t_ambient_k

                # Y neighbors
                if j > 0:
                    g = area_y / (dy / (2 * layer.ky) + dy / (2 * layer.ky))
                    rows.append(c); cols.append(idx(i, j - 1, k)); vals.append(-g)
                    diag += g
                elif h_side > 0:
                    g = area_y / (dy / (2 * layer.ky) + 1.0 / h_side)
                    diag += g; b += g * t_ambient_k

                if j < ny - 1:
                    g = area_y / (dy / (2 * layer.ky) + dy / (2 * layer.ky))
                    rows.append(c); cols.append(idx(i, j + 1, k)); vals.append(-g)
                    diag += g
                elif h_side > 0:
                    g = area_y / (dy / (2 * layer.ky) + 1.0 / h_side)
                    diag += g; b += g * t_ambient_k

                # Z neighbors with contact resistance
                if k > 0:
                    prev = layers[k - 1]
                    g = area_z / (
                        dz[k - 1] / (2 * prev.kz)
                        + prev.r_contact_above_m2kw
                        + dz[k] / (2 * layer.kz)
                    )
                    rows.append(c); cols.append(idx(i, j, k - 1)); vals.append(-g)
                    diag += g
                elif h_bottom > 0:
                    g = area_z / (dz[k] / (2 * layer.kz) + 1.0 / h_bottom)
                    diag += g; b += g * t_ambient_k

                if k < nz - 1:
                    nxt = layers[k + 1]
                    g = area_z / (
                        dz[k] / (2 * layer.kz)
                        + layer.r_contact_above_m2kw
                        + dz[k + 1] / (2 * nxt.kz)
                    )
                    rows.append(c); cols.append(idx(i, j, k + 1)); vals.append(-g)
                    diag += g
                elif h_top > 0:
                    g = area_z / (dz[k] / (2 * layer.kz) + 1.0 / h_top)
                    diag += g; b += g * t_ambient_k

                rows.append(c); cols.append(c); vals.append(diag)
                rhs[c] = b

    A = sparse.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsr()
    T = spsolve(A, rhs).reshape((nz, ny, nx))
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    return {
        "peak_temp_k": float(np.max(T)),
        "min_temp_k": float(np.min(T)),
        "solve_time_ms": elapsed_ms,
        "layer_avg_temp_k": [float(np.mean(T[k])) for k in range(nz)],
    }
