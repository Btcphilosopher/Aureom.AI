"""
AI Design Assistant (sections 26, 47-48): the top-level façade the UI talks
to. Inspects the live design, returns recommendations, and turns natural
language into structured proposals — never mutating the model on its own.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ai.design_reasoning import (
    DataCenterSpecification,
    IterationProposal,
    apply_specification,
    parse_design_brief,
    parse_iteration_command,
)
from ai.recommendations import Recommendation, generate_recommendations

if TYPE_CHECKING:
    from core.datacenter import DataCenter


class DesignAssistant:
    """Stateless facade: every method takes the DataCenter it should reason about."""

    def recommendations(self, dc: "DataCenter") -> list[Recommendation]:
        results = dc.compute_results()
        return generate_recommendations(dc, results)

    def generate_from_text(self, text: str) -> tuple["DataCenter", DataCenterSpecification, str]:
        """Section 47: natural-language design generation. Returns
        (new_datacenter, parsed_spec, explanation)."""
        from core.datacenter import DataCenter

        spec = parse_design_brief(text)
        dc = DataCenter(name=f"AI-Generated: {text[:40]}")
        apply_specification(dc, spec)
        results = dc.compute_results()
        explanation = self.explain_architecture(dc, results, spec)
        return dc, spec, explanation

    def explain_architecture(self, dc: "DataCenter", results=None, spec: DataCenterSpecification | None = None) -> str:
        results = results or dc.compute_results()
        lines = [
            f"Generated a {results.it_load_mw:.0f} MW IT-load facility "
            f"({results.rack_count} racks, {results.gpu_count} GPUs) at "
            f"{dc.power.redundancy} power redundancy.",
            f"Cooling: {dc.cooling.cooling_type.replace('_', ' ')} "
            f"({dc.cooling.liquid_cooling_fraction*100:.0f}% of load liquid-cooled). "
            f"Estimated PUE {results.pue:.2f}.",
            f"CAPEX ${results.capex/1e6:,.0f}M, annual OPEX ${results.annual_opex/1e6:,.1f}M, "
            f"annual revenue ${results.annual_revenue/1e6:,.1f}M.",
        ]
        if dc.energy.solar_capacity_mw > 0:
            lines.append(f"On-site solar sized at {dc.energy.solar_capacity_mw:.0f} MW "
                          f"with {dc.energy.battery_capacity_mwh:.0f} MWh of battery storage.")
        if spec and spec.notes:
            lines.extend(spec.notes)
        if results.alert_summary.get("CRITICAL", 0):
            lines.append(f"⚠ {results.alert_summary['CRITICAL']} CRITICAL validation issue(s) — "
                         f"see the Report stage before proceeding.")
        return " ".join(lines)

    def propose_iteration(self, dc: "DataCenter", command: str) -> IterationProposal:
        """Section 48: parse an iteration command into a proposal. Does not apply it."""
        return parse_iteration_command(command, dc)

    def apply_iteration(self, dc: "DataCenter", proposal: IterationProposal, run_optimisation: bool = True):
        """Explicitly apply a previously-shown proposal (user clicked APPLY)."""
        if proposal.apply is not None:
            proposal.apply(dc)
            return dc.compute_results(), None
        if proposal.objective_weights is not None and run_optimisation:
            opt_result = dc.optimise(objectives=proposal.objective_weights, method="differential_evolution")
            return opt_result.best_results, opt_result
        return dc.compute_results(), None
