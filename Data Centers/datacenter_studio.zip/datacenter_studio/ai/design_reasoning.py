"""
Natural-language design generation and iteration parsing (sections 47-48).

This is a deliberately transparent, regex/keyword-based parser — not a call
out to an external LLM — so the platform has zero external dependencies and
fully deterministic behaviour. It converts a free-text brief into a
structured :class:`DataCenterSpecification`, and free-text iteration
commands ("Reduce PUE.", "Make the facility cheaper.") into concrete
parameter changes or optimisation objective weights. Either path always
returns a *proposal* — the caller decides whether to apply it (section 48:
"Always show proposed changes before applying them").
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class DataCenterSpecification:
    it_load_mw: float = 10.0
    rack_density_kw: float = 12.0
    liquid_cooling: bool = False
    redundancy: str = "N+1"
    solar_fraction: float = 0.0
    battery_mwh: float = 0.0
    notes: list[str] = field(default_factory=list)


_NUM = r"(\d+(?:\.\d+)?)"


def parse_design_brief(text: str) -> DataCenterSpecification:
    """Parse a free-text facility brief, e.g.:
    "Design a 20 MW AI data center with 200 kW liquid-cooled racks, N+1 power
    redundancy, 30% solar generation and battery storage."
    """
    spec = DataCenterSpecification()
    t = text.lower()

    m = re.search(rf"{_NUM}\s*mw", t)
    if m:
        spec.it_load_mw = float(m.group(1))

    m = re.search(rf"{_NUM}\s*kw.{{0,20}}rack", t) or re.search(rf"rack.{{0,20}}{_NUM}\s*kw", t)
    if m:
        spec.rack_density_kw = float(m.group(1))

    if "liquid" in t or "immersion" in t or "dlc" in t:
        spec.liquid_cooling = True
        spec.notes.append("Liquid cooling requested in brief.")

    # Checked most-specific-first so an unrelated word ending in "n" (e.g.
    # "design") can never be mistaken for a bare "N" redundancy mention.
    if re.search(r"2n\+1", t):
        spec.redundancy = "2N+1"
    elif re.search(r"\b2n\b", t):
        spec.redundancy = "2N"
    elif re.search(r"n\+1", t):
        spec.redundancy = "N+1"
    elif re.search(r"\bn\b", t):
        spec.redundancy = "N"

    m = re.search(rf"{_NUM}\s*%\s*(?:solar|renewable)", t)
    if m:
        spec.solar_fraction = float(m.group(1)) / 100.0
    elif "solar" in t or "renewable" in t:
        spec.solar_fraction = 0.2
        spec.notes.append("Renewable mention without explicit % — defaulted to 20%.")

    m = re.search(rf"{_NUM}\s*mwh", t)
    if m:
        spec.battery_mwh = float(m.group(1))
    elif "battery" in t:
        spec.battery_mwh = spec.it_load_mw * 1.0
        spec.notes.append("Battery mention without explicit MWh — sized at 1h of IT load.")

    if "ai" in t or "gpu" in t or "training" in t or "inference" in t:
        spec.notes.append("AI/GPU workload detected — recommend liquid cooling above 50kW/rack.")

    return spec


def apply_specification(dc, spec: DataCenterSpecification) -> None:
    """Apply a parsed specification onto a DataCenter (explicit, caller-invoked)."""
    dc.compute.it_load_mw = spec.it_load_mw
    dc.compute.avg_rack_density_kw = spec.rack_density_kw
    if spec.liquid_cooling:
        dc.cooling.cooling_type = "direct_liquid"
        dc.cooling.liquid_cooling_fraction = 0.85
    dc.power.redundancy = spec.redundancy
    if spec.solar_fraction > 0:
        dc.energy.solar_capacity_mw = spec.it_load_mw * spec.solar_fraction * 2.5
    if spec.battery_mwh > 0:
        dc.energy.battery_capacity_mwh = spec.battery_mwh
        dc.energy.battery_power_mw = max(dc.energy.battery_power_mw, spec.battery_mwh / 3.0)


# ---------------------------------------------------------------------------
# Iteration commands (section 48)
# ---------------------------------------------------------------------------

@dataclass
class IterationProposal:
    command: str
    description: str
    changes: dict          # attribute path -> new value, human readable
    objective_weights: dict | None = None  # if the command is best expressed as an optimisation
    apply: object = None   # Callable[[DataCenter], None]


_COMMANDS = [
    (re.compile(r"reduce pue|lower pue|improve pue", re.I),
     "Reduce PUE by prioritising cooling efficiency in optimisation.",
     {"pue": 0.5, "capex": 0.15, "opex": 0.15, "carbon": 0.1, "revenue": 0.1}),
    (re.compile(r"increase gpu|more gpu|add gpu|expand gpu|increase.*capacity", re.I),
     "Increase compute/GPU capacity as the dominant objective.",
     {"capacity": 0.6, "pue": 0.1, "capex": 0.1, "revenue": 0.2}),
    (re.compile(r"cheaper|reduce cost|lower capex|minimi[sz]e cost", re.I),
     "Minimise CAPEX as the dominant objective.",
     {"capex": 0.6, "opex": 0.2, "pue": 0.1, "revenue": 0.1}),
    (re.compile(r"resilien|redundan|reliab", re.I),
     "Increase resilience (favour higher redundancy configurations).",
     {"resilience": 0.6, "capex": 0.1, "pue": 0.1, "revenue": 0.2}),
    (re.compile(r"water|wue", re.I),
     "Reduce water consumption (favour free cooling / dry coolers).",
     {"water": 0.5, "pue": 0.2, "capex": 0.15, "revenue": 0.15}),
    (re.compile(r"renewable|green|solar|carbon", re.I),
     "Optimise for renewable electricity / lower carbon intensity.",
     {"carbon": 0.5, "capex": 0.15, "pue": 0.15, "revenue": 0.2}),
    (re.compile(r"profit|revenue|margin|ebitda", re.I),
     "Maximise profitability.",
     {"revenue": 0.6, "capex": 0.15, "opex": 0.15, "pue": 0.1}),
]


def parse_iteration_command(text: str, dc=None) -> IterationProposal:
    """Translate a free-text iteration instruction into parameter changes or
    optimisation objective weights. Always returns a *proposal*; nothing is
    applied automatically (section 48)."""
    t = text.strip()

    # Direct, deterministic parameter commands take precedence over objective reweighting.
    m = re.search(r"hotter climate|climate.*hot|prepare.*heat", t, re.I)
    if m:
        return IterationProposal(
            command=t, description="Raise design ambient temperature by 8°C to model a hotter climate.",
            changes={"cooling.ambient_temperature_c": "+8.0", "cooling.ambient_wetbulb_c": "+6.0"},
            apply=lambda d: (setattr(d.cooling, "ambient_temperature_c", d.cooling.ambient_temperature_c + 8.0),
                              setattr(d.cooling, "ambient_wetbulb_c", d.cooling.ambient_wetbulb_c + 6.0)),
        )

    m = re.search(rf"add\s*{_NUM}\s*mw.*expansion|future expansion.*{_NUM}\s*mw", t, re.I)
    if m:
        mw = float(m.group(1))
        return IterationProposal(
            command=t, description=f"Increase grid capacity and IT load headroom by {mw:.0f} MW for future expansion.",
            changes={"site.grid_capacity_mw": f"+{mw}", "compute.it_load_mw": f"+{mw}"},
            apply=lambda d: (setattr(d.site, "grid_capacity_mw", d.site.grid_capacity_mw + mw),
                              setattr(d.compute, "it_load_mw", (d.compute.it_load_mw or d.results.it_load_mw) + mw)),
        )

    m = re.search(r"convert.*high.density.*liquid|liquid.cool.*high.density", t, re.I)
    if m:
        return IterationProposal(
            command=t, description="Convert all racks above the air-cooling limit to direct liquid cooling.",
            changes={"cooling.liquid_cooling_fraction": "raised", "affected racks": "cooling_type -> direct_liquid"},
            apply=lambda d: _convert_hot_racks_to_liquid(d),
        )

    for pattern, description, weights in _COMMANDS:
        if pattern.search(t):
            return IterationProposal(command=t, description=description, changes={}, objective_weights=weights)

    return IterationProposal(
        command=t,
        description="Command not recognised by the rule-based parser; no changes proposed. "
                     "Try phrasing like 'Reduce PUE', 'Increase GPU capacity', 'Make the facility cheaper'.",
        changes={},
    )


def _convert_hot_racks_to_liquid(dc) -> None:
    limit = dc.assumptions.get("air_cooling_max_kw_per_rack", 20.0)
    for floor in dc.building.floors:
        for rack in floor.racks:
            if rack.cooling_type == "air" and rack.rack_it_load_kw > limit:
                rack.cooling_type = "direct_liquid"
    dc.cooling.liquid_cooling_fraction = max(dc.cooling.liquid_cooling_fraction, 0.5)
