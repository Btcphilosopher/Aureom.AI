"""
Rule-based engineering recommendations (section 26).

Each recommendation carries RECOMMENDATION / WHY / EXPECTED IMPACT / RISK,
plus an ``apply`` callback the UI can invoke on "APPLY CHANGE" — the
assistant never silently mutates the model itself.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from core.datacenter import DataCenter, FacilityResults


@dataclass
class Recommendation:
    title: str
    why: str
    expected_impact: str
    risk: str
    apply: Callable[["DataCenter"], None] | None = None
    category: str = "general"


def generate_recommendations(dc: "DataCenter", results: "FacilityResults") -> list[Recommendation]:
    recs: list[Recommendation] = []

    # --- Cooling share of facility power ---
    cooling_share = results.cooling_electrical_kw / max(results.facility_load_mw * 1000.0, 1e-6)
    if cooling_share > 0.20:
        recs.append(Recommendation(
            title=(f"The current design has {results.it_load_mw:.1f} MW IT load and "
                   f"{results.facility_load_mw:.1f} MW facility demand. Cooling represents "
                   f"{cooling_share*100:.0f}% of facility consumption. Raising chilled-water "
                   f"supply temperature by 2°C may reduce compressor energy."),
            why="Chiller COP improves as the lift between evaporator and condenser narrows; a "
                "warmer supply setpoint reduces compressor work for the same heat rejection.",
            expected_impact=f"PUE reduction of roughly 0.02-0.05 depending on climate; cooling opex "
                             f"down a few percent.",
            risk="Reduces headroom against server inlet-temperature limits during heatwaves; "
                 "requires rebalancing airflow/containment.",
            apply=lambda d: setattr(d.cooling, "chilled_water_supply_c", d.cooling.chilled_water_supply_c + 2.0),
            category="cooling",
        ))

    # --- Rack density vs air-cooling limit ---
    air_limit = dc.assumptions.get("air_cooling_max_kw_per_rack", 20.0)
    hot_racks = [r for f in dc.building.floors for r in f.racks
                 if r.cooling_type == "air" and r.rack_it_load_kw > air_limit]
    if hot_racks:
        recs.append(Recommendation(
            title=(f"Rack density exceeds the selected air-cooling configuration on "
                   f"{len(hot_racks)} rack(s). Consider direct liquid cooling for racks above "
                   f"{air_limit:.0f} kW."),
            why="Air cooling cannot practically remove heat above roughly 20-25 kW/rack without "
                "excessive airflow and hot-spot risk.",
            expected_impact="Eliminates hot-spot risk on affected racks; enables 3-6x rack density "
                             "vs air alone.",
            risk="Requires capital investment in a liquid-cooling loop and rack-level manifolds; "
                 "increases plumbing complexity.",
            apply=lambda d: setattr(d.cooling, "liquid_cooling_fraction", max(d.cooling.liquid_cooling_fraction, 0.5)),
            category="cooling",
        ))

    # --- Redundancy ---
    if not results.redundancy_satisfied:
        recs.append(Recommendation(
            title=(f"Selected redundancy '{dc.power.redundancy}' is not satisfied by the current "
                   f"UPS/generator fleet."),
            why="The N-1 contingency check shows remaining capacity falls short of critical load "
                "after removing the largest single unit.",
            expected_impact="Restores the stated resilience level; reduces outage risk on a single "
                             "unit failure.",
            risk="Adds CAPEX (additional UPS/generator units).",
            apply=lambda d: (d.power.ups_units.append(d.power.ups_units[0].__class__(capacity_kva=d.power.ups_units[0].capacity_kva))
                              if d.power.ups_units else None),
            category="power",
        ))

    # --- Renewable fraction ---
    if dc.energy.solar_capacity_mw < results.it_load_mw * 0.15:
        recs.append(Recommendation(
            title="On-site renewable generation is small relative to IT load. Expanding solar "
                  "capacity would materially reduce grid dependence and carbon intensity.",
            why="Solar PV at this latitude/assumption set offers a ~20-25% capacity factor; even a "
                "modest array offsets a meaningful daytime load fraction.",
            expected_impact=f"Every additional 10 MW of solar reduces annual carbon by roughly "
                             f"{10 * 0.22 * 8760 * dc.assumptions.get('grid_carbon_intensity_kg_per_kwh', 0.233) / 1000:,.0f} t/yr.",
            risk="Requires available land (see site utilisation) and a grid interconnection study.",
            apply=lambda d: setattr(d.energy, "solar_capacity_mw", d.results.it_load_mw * 0.3),
            category="energy",
        ))

    # --- Water usage ---
    if results.wue > 2.0 and dc.cooling.cooling_type in ("chilled_water", "hybrid"):
        recs.append(Recommendation(
            title=f"Water Usage Effectiveness is {results.wue:.2f} L/kWh — evaporative cooling "
                  f"water draw is significant.",
            why="Cooling towers reject heat via evaporation; enabling more aggressive free cooling "
                "or a dry/adiabatic cooler reduces water consumption at a modest energy cost.",
            expected_impact="WUE reduction of 30-60% achievable with free-cooling economisers or "
                             "dry coolers in favourable climates.",
            risk="Dry coolers are less effective in hot/humid climates and may raise PUE slightly.",
            apply=lambda d: setattr(d.cooling, "free_cooling_enabled", True),
            category="cooling",
        ))

    # --- CAPEX vs redundancy over-provisioning ---
    if dc.power.redundancy == "2N+1" and results.it_load_mw < 10:
        recs.append(Recommendation(
            title="2N+1 redundancy is heavily over-specified for a facility of this size.",
            why="2N+1 roughly doubles electrical CAPEX versus N+1 for a marginal resilience gain "
                "at sub-10MW scale.",
            expected_impact=f"Potential CAPEX reduction of ${results.capex * 0.12:,.0f}-"
                             f"${results.capex * 0.18:,.0f}.",
            risk="Lower redundancy tolerates fewer simultaneous failures.",
            apply=lambda d: setattr(d.power, "redundancy", "N+1"),
            category="power",
        ))

    if not recs:
        recs.append(Recommendation(
            title="No high-priority issues detected. The design appears well-balanced across "
                  "power, cooling and cost.",
            why="All KPI thresholds are within the assistant's rule set.",
            expected_impact="N/A",
            risk="N/A",
            apply=None,
            category="general",
        ))

    return recs
