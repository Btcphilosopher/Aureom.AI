"""AI design-assistant package: rule-based reasoning over the live engineering model."""
