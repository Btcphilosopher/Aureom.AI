"""Optimisation package: multi-objective search, scenarios, sensitivity / Monte Carlo."""
