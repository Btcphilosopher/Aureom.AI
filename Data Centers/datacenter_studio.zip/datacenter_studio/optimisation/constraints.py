"""
Constraint handling for the optimisation engine (section 27, 37).

Infeasible designs (per :mod:`core.validation`) are penalised heavily rather
than silently discarded, so the optimiser is steered away from invalid
engineering states without hard-failing the search.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from config.constants import SEVERITY_CRITICAL

if TYPE_CHECKING:
    from core.datacenter import FacilityResults

CRITICAL_PENALTY = 5.0  # added to the objective per CRITICAL alert
WARNING_PENALTY = 0.5   # added per WARNING alert


def constraint_penalty(results: "FacilityResults") -> float:
    penalty = 0.0
    for alert in results.alerts:
        if alert.severity == SEVERITY_CRITICAL:
            penalty += CRITICAL_PENALTY
        elif alert.severity == "WARNING":
            penalty += WARNING_PENALTY
    return penalty


def is_feasible(results: "FacilityResults") -> bool:
    return not any(a.severity == SEVERITY_CRITICAL for a in results.alerts)
