"""
Optimisation engine (section 27).

``BaseOptimizer`` defines a common interface; concrete strategies
(``GridOptimizer``, ``RandomSearchOptimizer``, ``DifferentialEvolutionOptimizer``,
``EvolutionaryOptimizer``) are interchangeable — the method is never
hard-coded into the rest of the platform. :func:`optimise_design` is the
entry point used by ``DataCenter.optimise()``.
"""

from __future__ import annotations

import copy
import itertools
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

import numpy as np
from scipy.optimize import differential_evolution

from optimisation.constraints import constraint_penalty
from optimisation.objectives import DEFAULT_WEIGHTS, weighted_objective

if TYPE_CHECKING:
    from core.datacenter import DataCenter, FacilityResults

ParamSpace = dict[str, tuple[float, float]]
EvaluateFn = Callable[[dict[str, float]], float]

# Parameter name -> (getter(dc), setter(dc, value)) for the knobs the
# optimiser is allowed to move. Kept centralised so every optimiser
# implementation and the UI's "design space explorer" share one definition.
PARAM_ACCESSORS: dict[str, tuple[Callable, Callable]] = {
    "it_load_mw": (lambda dc: dc.compute.it_load_mw or dc.results.it_load_mw,
                   lambda dc, v: setattr(dc.compute, "it_load_mw", v)),
    "solar_capacity_mw": (lambda dc: dc.energy.solar_capacity_mw,
                           lambda dc, v: setattr(dc.energy, "solar_capacity_mw", v)),
    "battery_capacity_mwh": (lambda dc: dc.energy.battery_capacity_mwh,
                              lambda dc, v: setattr(dc.energy, "battery_capacity_mwh", v)),
    "battery_power_mw": (lambda dc: dc.energy.battery_power_mw,
                          lambda dc, v: setattr(dc.energy, "battery_power_mw", v)),
    "cooling_capacity_kw": (lambda dc: dc.cooling.cooling_capacity_kw,
                             lambda dc, v: setattr(dc.cooling, "cooling_capacity_kw", v)),
    "liquid_cooling_fraction": (lambda dc: dc.cooling.liquid_cooling_fraction,
                                 lambda dc, v: setattr(dc.cooling, "liquid_cooling_fraction", float(np.clip(v, 0, 1)))),
    "grid_price_per_kwh": (lambda dc: dc.energy.grid_price_per_kwh,
                            lambda dc, v: setattr(dc.energy, "grid_price_per_kwh", v)),
    "chilled_water_supply_c": (lambda dc: dc.cooling.chilled_water_supply_c,
                                lambda dc, v: setattr(dc.cooling, "chilled_water_supply_c", v)),
}


def default_param_space(dc: "DataCenter") -> ParamSpace:
    it_load = dc.compute.it_load_mw or dc.results.it_load_mw
    return {
        "solar_capacity_mw": (0.0, max(it_load * 0.6, 5.0)),
        "battery_capacity_mwh": (0.0, max(it_load * 2.0, 10.0)),
        "cooling_capacity_kw": (dc.results.total_heat_kw, dc.results.total_heat_kw * 1.8),
        "liquid_cooling_fraction": (0.0, 1.0),
        "chilled_water_supply_c": (5.0, 12.0),
    }


def apply_params(dc: "DataCenter", params: dict[str, float]) -> None:
    for key, value in params.items():
        if key in PARAM_ACCESSORS:
            PARAM_ACCESSORS[key][1](dc, value)


def make_evaluator(dc: "DataCenter", weights: dict[str, float]) -> tuple[EvaluateFn, list]:
    """Returns (evaluate_fn, history) where evaluate_fn(params) -> score (lower better)."""
    history: list[dict] = []

    def evaluate(params: dict[str, float]) -> float:
        trial = dc.clone()
        apply_params(trial, params)
        results = trial.compute_results()
        obj = weighted_objective(results, weights, redundancy=trial.power.redundancy)
        penalty = constraint_penalty(results)
        score = obj.total + penalty
        history.append({"params": dict(params), "score": score, "results": results})
        return score

    return evaluate, history


@dataclass
class OptimizationResult:
    method: str
    best_params: dict[str, float]
    best_score: float
    best_design: "DataCenter"
    best_results: "FacilityResults"
    history: list[dict] = field(default_factory=list)
    iterations: int = 0

    def summary(self) -> dict:
        return {
            "method": self.method,
            "best_params": self.best_params,
            "best_score": round(self.best_score, 4),
            "pue": round(self.best_results.pue, 3),
            "capex": self.best_results.capex,
            "annual_opex": self.best_results.annual_opex,
            "annual_revenue": self.best_results.annual_revenue,
            "iterations": self.iterations,
        }


class BaseOptimizer(ABC):
    """Common interface for all optimisation strategies."""

    name = "base"

    @abstractmethod
    def run(self, param_space: ParamSpace, evaluate: EvaluateFn, **kwargs) -> tuple[dict, float]:
        """Return (best_params, best_score)."""


class GridOptimizer(BaseOptimizer):
    name = "grid"

    def run(self, param_space: ParamSpace, evaluate: EvaluateFn, steps: int = 4, **kwargs) -> tuple[dict, float]:
        grids = {k: np.linspace(low, high, steps) for k, (low, high) in param_space.items()}
        keys = list(grids.keys())
        best_params, best_score = None, float("inf")
        for combo in itertools.product(*[grids[k] for k in keys]):
            params = dict(zip(keys, combo))
            score = evaluate(params)
            if score < best_score:
                best_score, best_params = score, params
        return best_params or {}, best_score


class RandomSearchOptimizer(BaseOptimizer):
    name = "random"

    def run(self, param_space: ParamSpace, evaluate: EvaluateFn, iterations: int = 60,
            seed: int = 42, **kwargs) -> tuple[dict, float]:
        rng = np.random.default_rng(seed)
        best_params, best_score = None, float("inf")
        for _ in range(iterations):
            params = {k: float(rng.uniform(low, high)) for k, (low, high) in param_space.items()}
            score = evaluate(params)
            if score < best_score:
                best_score, best_params = score, params
        return best_params or {}, best_score


class DifferentialEvolutionOptimizer(BaseOptimizer):
    name = "differential_evolution"

    def run(self, param_space: ParamSpace, evaluate: EvaluateFn, maxiter: int = 25,
            popsize: int = 12, seed: int = 42, **kwargs) -> tuple[dict, float]:
        keys = list(param_space.keys())
        bounds = [param_space[k] for k in keys]

        def objective_vec(x: np.ndarray) -> float:
            return evaluate(dict(zip(keys, x)))

        result = differential_evolution(
            objective_vec, bounds, maxiter=maxiter, popsize=popsize, seed=seed,
            polish=False, tol=1e-4, updating="deferred",
        )
        return dict(zip(keys, result.x)), float(result.fun)


class EvolutionaryOptimizer(BaseOptimizer):
    """A compact, dependency-free genetic algorithm (tournament selection,
    blend crossover, Gaussian mutation) — distinct from
    :class:`DifferentialEvolutionOptimizer`, offered for search-space
    diversity (section 27)."""

    name = "genetic"

    def run(self, param_space: ParamSpace, evaluate: EvaluateFn, generations: int = 20,
            population_size: int = 16, mutation_rate: float = 0.2, seed: int = 42,
            **kwargs) -> tuple[dict, float]:
        rng = np.random.default_rng(seed)
        keys = list(param_space.keys())
        bounds = np.array([param_space[k] for k in keys])

        def random_individual() -> np.ndarray:
            return rng.uniform(bounds[:, 0], bounds[:, 1])

        def fitness(ind: np.ndarray) -> float:
            return evaluate(dict(zip(keys, ind)))

        population = [random_individual() for _ in range(population_size)]
        scores = [fitness(ind) for ind in population]

        for _ in range(generations):
            new_population = []
            # elitism: keep the best individual
            best_idx = int(np.argmin(scores))
            new_population.append(population[best_idx])
            while len(new_population) < population_size:
                a, b = _tournament(population, scores, rng), _tournament(population, scores, rng)
                alpha = rng.uniform(0.3, 0.7)
                child = alpha * a + (1 - alpha) * b
                if rng.random() < mutation_rate:
                    child += rng.normal(0, (bounds[:, 1] - bounds[:, 0]) * 0.08)
                child = np.clip(child, bounds[:, 0], bounds[:, 1])
                new_population.append(child)
            population = new_population
            scores = [fitness(ind) for ind in population]

        best_idx = int(np.argmin(scores))
        return dict(zip(keys, population[best_idx])), float(scores[best_idx])


def _tournament(population: list[np.ndarray], scores: list[float], rng: np.random.Generator, k: int = 3) -> np.ndarray:
    idxs = rng.integers(0, len(population), size=k)
    best = min(idxs, key=lambda i: scores[i])
    return population[best]


OPTIMIZERS: dict[str, type[BaseOptimizer]] = {
    "grid": GridOptimizer,
    "random": RandomSearchOptimizer,
    "differential_evolution": DifferentialEvolutionOptimizer,
    "genetic": EvolutionaryOptimizer,
    "evolutionary": EvolutionaryOptimizer,
}


def optimise_design(
    dc: "DataCenter",
    objectives: dict[str, float] | None = None,
    method: str = "differential_evolution",
    param_space: ParamSpace | None = None,
    **kwargs,
) -> OptimizationResult:
    weights = objectives or DEFAULT_WEIGHTS
    space = param_space or default_param_space(dc)
    evaluate, history = make_evaluator(dc, weights)

    optimizer_cls = OPTIMIZERS.get(method)
    if optimizer_cls is None:
        raise ValueError(f"Unknown optimisation method '{method}'. Choose from {list(OPTIMIZERS)}.")
    optimizer = optimizer_cls()
    best_params, best_score = optimizer.run(space, evaluate, **kwargs)

    best_design = dc.clone(name=f"{dc.name} (optimised: {method})")
    apply_params(best_design, best_params)
    best_results = best_design.compute_results()

    return OptimizationResult(
        method=method,
        best_params=best_params,
        best_score=best_score,
        best_design=best_design,
        best_results=best_results,
        history=history,
        iterations=len(history),
    )
