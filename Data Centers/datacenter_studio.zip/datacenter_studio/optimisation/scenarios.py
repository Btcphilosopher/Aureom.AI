"""
Scenario engine (section 28) and design comparison engine (section 39).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

import pandas as pd

if TYPE_CHECKING:
    from core.datacenter import DataCenter, FacilityResults


@dataclass
class Scenario:
    name: str
    description: str
    apply: Callable[["DataCenter"], None]


def _high_energy_price(dc: "DataCenter") -> None:
    dc.energy.grid_price_per_kwh *= 2.2
    dc.energy.time_of_use_enabled = True


def _high_gpu_density(dc: "DataCenter") -> None:
    dc.compute.high_density_fraction = min(1.0, dc.compute.high_density_fraction + 0.5)
    dc.compute.high_density_kw = max(dc.compute.high_density_kw, 100.0)
    dc.cooling.liquid_cooling_fraction = max(dc.cooling.liquid_cooling_fraction, 0.6)


def _hot_summer(dc: "DataCenter") -> None:
    dc.cooling.ambient_temperature_c += 10.0
    dc.cooling.ambient_wetbulb_c += 8.0


def _grid_constraint(dc: "DataCenter") -> None:
    dc.site.grid_capacity_mw *= 0.6
    dc.power.generators = dc.power.generators + list(dc.power.generators[:2])


def _renewable_expansion(dc: "DataCenter") -> None:
    dc.energy.solar_capacity_mw = max(dc.energy.solar_capacity_mw, dc.results.it_load_mw * 0.8)
    dc.energy.battery_capacity_mwh = max(dc.energy.battery_capacity_mwh, dc.results.it_load_mw * 1.5)
    dc.energy.battery_power_mw = max(dc.energy.battery_power_mw, dc.results.it_load_mw * 0.5)


def _liquid_cooling(dc: "DataCenter") -> None:
    dc.cooling.cooling_type = "direct_liquid"
    dc.cooling.liquid_cooling_fraction = 0.9


def _future_expansion(dc: "DataCenter") -> None:
    if dc.compute.it_load_mw:
        dc.compute.it_load_mw *= 1.5
    dc.site.grid_capacity_mw *= 1.4


def _min_capex(dc: "DataCenter") -> None:
    dc.power.redundancy = "N"
    dc.cooling.cooling_type = "air"
    dc.energy.solar_capacity_mw = 0.0
    dc.energy.battery_capacity_mwh = 0.0


PRESET_SCENARIOS: dict[str, Scenario] = {
    "base_case": Scenario("BASE CASE", "The design as currently configured.", lambda dc: None),
    "high_energy_price": Scenario("HIGH ENERGY PRICE", "Electricity prices more than double; TOU pricing enabled.", _high_energy_price),
    "high_gpu_density": Scenario("HIGH GPU DENSITY", "Shift toward dense GPU racks with liquid cooling.", _high_gpu_density),
    "hot_summer": Scenario("HOT SUMMER", "Ambient design temperature rises by 10C.", _hot_summer),
    "grid_constraint": Scenario("GRID CONSTRAINT", "Grid capacity cut by 40%; extra generators added.", _grid_constraint),
    "renewable_expansion": Scenario("RENEWABLE EXPANSION", "Solar and battery sized to cover most of the IT load.", _renewable_expansion),
    "liquid_cooling": Scenario("LIQUID COOLING", "Facility converted to direct liquid cooling.", _liquid_cooling),
    "future_expansion": Scenario("FUTURE EXPANSION", "IT load and grid capacity grown 1.5x for future phases.", _future_expansion),
    "min_capex": Scenario("MINIMUM CAPEX", "Strip to N redundancy, air cooling, no renewables.", _min_capex),
}


def run_scenario(dc: "DataCenter", scenario: Scenario) -> tuple["DataCenter", "FacilityResults"]:
    trial = dc.clone(name=f"{dc.name} — {scenario.name}")
    scenario.apply(trial)
    return trial, trial.compute_results()


def run_scenarios(dc: "DataCenter", scenario_keys: list[str] | None = None) -> pd.DataFrame:
    keys = scenario_keys or list(PRESET_SCENARIOS.keys())
    rows = []
    for key in keys:
        scenario = PRESET_SCENARIOS[key]
        _, results = run_scenario(dc, scenario)
        rows.append({
            "scenario": scenario.name,
            "it_load_mw": round(results.it_load_mw, 2),
            "pue": round(results.pue, 3),
            "capex": round(results.capex, 0),
            "annual_opex": round(results.annual_opex, 0),
            "annual_revenue": round(results.annual_revenue, 0),
            "cooling_load_mw": round(results.cooling_load_kw / 1000, 2),
            "annual_carbon_tonnes": round(results.annual_carbon_tonnes, 0),
            "capacity_mw": round(results.it_load_mw, 2),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Comparison engine (section 39)
# ---------------------------------------------------------------------------

def compare_designs(designs: list["DataCenter"]) -> list[dict]:
    """Return a list of {metric, <design_name>: value, ...} rows plus a
    trailing recommendation row."""
    metrics = [
        ("IT Load (MW)", lambda r: round(r.it_load_mw, 2)),
        ("PUE", lambda r: round(r.pue, 3)),
        ("CAPEX ($M)", lambda r: round(r.capex / 1e6, 1)),
        ("Annual OPEX ($M)", lambda r: round(r.annual_opex / 1e6, 2)),
        ("Annual Revenue ($M)", lambda r: round(r.annual_revenue / 1e6, 2)),
        ("Cooling", lambda r: None),  # filled from dc.cooling.cooling_type below
        ("Carbon (t/yr)", lambda r: round(r.annual_carbon_tonnes, 0)),
        ("Cost per MW ($M)", lambda r: round(r.cost_per_mw / 1e6, 2)),
    ]
    all_results = [(dc, dc.compute_results()) for dc in designs]
    rows = []
    for label, fn in metrics:
        row = {"metric": label}
        for dc, results in all_results:
            row[dc.name] = dc.cooling.cooling_type if label == "Cooling" else fn(results)
        rows.append(row)

    # Recommendation: lowest PUE with CAPEX within 25% of the cheapest design.
    cheapest = min(r.capex for _, r in all_results)
    candidates = [(dc, r) for dc, r in all_results if r.capex <= cheapest * 1.25]
    best = min(candidates, key=lambda pair: pair[1].pue) if candidates else all_results[0]
    rows.append({"metric": "RECOMMENDATION", **{dc.name: ("<-- balanced choice" if dc is best[0] else "") for dc, _ in all_results}})
    return rows


# ---------------------------------------------------------------------------
# Pareto frontier (section 50)
# ---------------------------------------------------------------------------

def pareto_frontier(candidates: list["FacilityResults"], minimise: list[str], maximise: list[str]) -> list[int]:
    """Return the indices of ``candidates`` that are Pareto-optimal across
    the given minimise/maximise metric lists."""
    def dominates(a, b) -> bool:
        better_or_equal = all(getattr(a, m) <= getattr(b, m) for m in minimise) and \
                           all(getattr(a, m) >= getattr(b, m) for m in maximise)
        strictly_better = any(getattr(a, m) < getattr(b, m) for m in minimise) or \
                           any(getattr(a, m) > getattr(b, m) for m in maximise)
        return better_or_equal and strictly_better

    frontier = []
    for i, cand in enumerate(candidates):
        if not any(dominates(other, cand) for j, other in enumerate(candidates) if j != i):
            frontier.append(i)
    return frontier
