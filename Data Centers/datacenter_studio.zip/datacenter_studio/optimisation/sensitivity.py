"""
Sensitivity analysis and Monte Carlo uncertainty modelling (section 29).

Monte Carlo draws thousands of samples over key uncertain inputs
(electricity price, IT utilisation, ambient temperature, cooling
efficiency, GPU load, construction cost, renewable output) and reports
P10/P50/P90 for the major output metrics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from core.datacenter import DataCenter

DEFAULT_UNCERTAINTY = {
    # name -> (relative_std_dev, applies_to)
    "electricity_price": 0.15,
    "it_utilisation": 0.10,
    "ambient_temperature": 0.20,
    "cooling_efficiency": 0.10,
    "gpu_load": 0.08,
    "construction_cost": 0.12,
    "renewable_output": 0.20,
}

METRICS = ["pue", "capex", "annual_opex", "annual_revenue", "annual_carbon_tonnes", "ebitda"]


@dataclass
class MonteCarloResult:
    samples: pd.DataFrame
    percentiles: dict[str, dict[str, float]] = field(default_factory=dict)

    def summary_table(self) -> pd.DataFrame:
        return pd.DataFrame(self.percentiles).T


def monte_carlo_analysis(
    dc: "DataCenter",
    n_samples: int = 2000,
    uncertainty: dict[str, float] | None = None,
    seed: int = 42,
) -> MonteCarloResult:
    unc = uncertainty or DEFAULT_UNCERTAINTY
    rng = np.random.default_rng(seed)
    rows = []

    base_price = dc.energy.grid_price_per_kwh
    base_ambient = dc.cooling.ambient_temperature_c
    base_cop = dc.assumptions.get("chiller_base_cop", 5.5)
    base_solar_cf = dc.energy.solar_capacity_factor
    base_capex_multiplier = 1.0

    for _ in range(n_samples):
        trial = dc.clone()
        trial.energy.grid_price_per_kwh = max(0.01, base_price * (1 + rng.normal(0, unc["electricity_price"])))
        trial.cooling.ambient_temperature_c = base_ambient + rng.normal(0, unc["ambient_temperature"] * 5)
        trial.assumptions["chiller_base_cop"] = max(1.5, base_cop * (1 + rng.normal(0, unc["cooling_efficiency"])))
        trial.energy.solar_capacity_factor = float(np.clip(base_solar_cf * (1 + rng.normal(0, unc["renewable_output"])), 0.05, 0.4))
        capex_multiplier = max(0.6, base_capex_multiplier * (1 + rng.normal(0, unc["construction_cost"])))

        if trial.compute.it_load_mw is not None:
            trial.compute.it_load_mw *= max(0.5, 1 + rng.normal(0, unc["it_utilisation"]))

        results = trial.compute_results()
        row = {m: getattr(results, m) for m in METRICS}
        row["capex"] *= capex_multiplier
        rows.append(row)

    df = pd.DataFrame(rows)
    percentiles = {
        m: {"P10": float(np.percentile(df[m], 10)), "P50": float(np.percentile(df[m], 50)),
            "P90": float(np.percentile(df[m], 90))}
        for m in METRICS
    }
    return MonteCarloResult(samples=df, percentiles=percentiles)


def one_at_a_time_sensitivity(
    dc: "DataCenter",
    parameter: str,
    values: list[float],
    setter,
    metric: str = "pue",
) -> pd.DataFrame:
    """Sweep a single parameter (via ``setter(trial_dc, value)``) and report
    the resulting ``metric`` for each value — a classic tornado-chart input."""
    rows = []
    for v in values:
        trial = dc.clone()
        setter(trial, v)
        results = trial.compute_results()
        rows.append({"parameter": parameter, "value": v, metric: getattr(results, metric)})
    return pd.DataFrame(rows)


def tornado_chart_data(dc: "DataCenter", metric: str = "pue", swing_fraction: float = 0.20) -> pd.DataFrame:
    """Vary each key parameter +/- ``swing_fraction`` and report the metric
    swing, sorted descending — the data behind a tornado chart."""
    base_results = dc.compute_results()
    base_value = getattr(base_results, metric)

    def sweep(setter, base):
        low_dc, high_dc = dc.clone(), dc.clone()
        setter(low_dc, base * (1 - swing_fraction))
        setter(high_dc, base * (1 + swing_fraction))
        low = getattr(low_dc.compute_results(), metric)
        high = getattr(high_dc.compute_results(), metric)
        return low, high

    factors = {
        "Electricity price": (lambda d, v: setattr(d.energy, "grid_price_per_kwh", v), dc.energy.grid_price_per_kwh),
        "Ambient temperature": (lambda d, v: setattr(d.cooling, "ambient_temperature_c", v), dc.cooling.ambient_temperature_c),
        "Chiller COP": (lambda d, v: d.assumptions.__setitem__("chiller_base_cop", v), dc.assumptions.get("chiller_base_cop", 5.5)),
        "Cooling capacity": (lambda d, v: setattr(d.cooling, "cooling_capacity_kw", v), dc.cooling.cooling_capacity_kw),
    }
    rows = []
    for label, (setter, base_val) in factors.items():
        low, high = sweep(setter, base_val)
        rows.append({"factor": label, "low": low, "high": high, "base": base_value,
                      "swing": abs(high - low)})
    return pd.DataFrame(rows).sort_values("swing", ascending=False).reset_index(drop=True)
