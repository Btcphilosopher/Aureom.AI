"""
Multi-objective scoring (section 27).

Every raw engineering/financial quantity is normalised onto a 0..1 "badness"
scale (0 = best plausible outcome, 1 = worst plausible outcome) using a
transparent reference range, then combined with user-supplied weights:

    objective = (
        0.20 * capex_score +
        0.25 * energy_score +
        0.20 * pue_score +
        0.15 * carbon_score +
        0.20 * revenue_score
    )

Lower ``objective`` is always better — this is what every
:class:`~optimisation.optimiser.BaseOptimizer` implementation minimises.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from core.units import clamp

if TYPE_CHECKING:
    from core.datacenter import FacilityResults

# Reference ranges used to normalise each raw metric onto [0, 1] "badness".
# (low, high): low -> score 0 (best), high -> score 1 (worst), for MINIMISE metrics.
# For MAXIMISE metrics (capacity, profit, resilience) the sense is inverted below.
REFERENCE_RANGES = {
    "capex": (5e7, 2e9),
    "opex": (2e6, 2e8),
    "pue": (1.05, 2.2),
    "carbon": (0.0, 200_000.0),        # tonnes/yr
    "water": (0.0, 500_000.0),         # m3/yr
    "capacity": (1.0, 200.0),          # MW IT load (maximise)
    "revenue": (0.0, 5e8),             # annual revenue (maximise)
    "resilience": (0.0, 1.0),          # 0=N .. 1=2N+1 (maximise)
}

OBJECTIVE_SENSE = {
    "capex": "minimise", "opex": "minimise", "pue": "minimise", "carbon": "minimise",
    "water": "minimise", "capacity": "maximise", "revenue": "maximise", "resilience": "maximise",
}

DEFAULT_WEIGHTS = {"capex": 0.20, "opex": 0.20, "pue": 0.20, "carbon": 0.15, "revenue": 0.25}

REDUNDANCY_SCORE = {"N": 0.0, "N+1": 0.4, "2N": 0.8, "2N+1": 1.0}


def normalise(value: float, low: float, high: float, sense: str) -> float:
    if high <= low:
        return 0.0
    frac = clamp((value - low) / (high - low), 0.0, 1.0)
    return frac if sense == "minimise" else 1.0 - frac


def extract_metric(results: "FacilityResults", metric: str) -> float:
    return {
        "capex": results.capex,
        "opex": results.annual_opex,
        "pue": results.pue,
        "carbon": results.annual_carbon_tonnes,
        "water": results.water_use_m3_per_hour * 8760.0,
        "capacity": results.it_load_mw,
        "revenue": results.annual_revenue,
        "resilience": REDUNDANCY_SCORE.get("N+1", 0.4),  # overridden by caller when redundancy is known
    }[metric]


@dataclass
class ObjectiveScore:
    total: float
    components: dict[str, float]


def weighted_objective(results: "FacilityResults", weights: dict[str, float] | None = None,
                        redundancy: str = "N+1") -> ObjectiveScore:
    """Compute the weighted, minimise-oriented objective score (section 27)."""
    weights = weights or DEFAULT_WEIGHTS
    components: dict[str, float] = {}
    total = 0.0
    for metric, weight in weights.items():
        if weight == 0:
            continue
        if metric == "resilience":
            raw = REDUNDANCY_SCORE.get(redundancy, 0.4)
        else:
            raw = extract_metric(results, metric)
        low, high = REFERENCE_RANGES.get(metric, (0.0, 1.0))
        sense = OBJECTIVE_SENSE.get(metric, "minimise")
        score = normalise(raw, low, high, sense)
        components[metric] = score
        total += weight * score
    return ObjectiveScore(total=total, components=components)
