# Thermal / Cooling Model

**This is a simplified computational approximation, not a CFD solver.** It
uses lumped, per-rack energy balances and empirical correlations rather than
solving the Navier-Stokes equations over a 3D mesh. Treat every temperature
and airflow number as directional, not certified.

## Heat balance (`cooling/thermal.py::compute_heat_balance`)

```
total_heat_kw = it_heat_kw + lighting_heat_kw + people_heat_kw + electrical_heat_kw
```

- `it_heat_kw` — essentially all IT electrical power is rejected as heat.
- `lighting_heat_kw` — `gross_floor_area_m2 × lighting_w_per_m2` (assumption).
- `people_heat_kw` — `occupancy × people_heat_w_per_person` (assumption).
- `electrical_heat_kw` — the power-chain losses computed by the power model
  (transformers, UPS, etc. also dissipate heat into the building).

## Per-rack thermal profile (`cooling/thermal.py::rack_thermal_profile`)

For each rack:

- **Liquid-cooled racks** (`direct_liquid`, `immersion`) reject most heat
  directly to coolant; only a small residual fraction (10% / 3%) loads the
  room air.
- **Air-cooled racks**: inlet temperature = supply air temperature, degraded
  by a recirculation penalty proportional to `(1 − containment_efficiency)`
  and how close the rack's load is to the air-cooling ceiling
  (`air_cooling_max_kw_per_rack`, default 20 kW). This is a transparent
  proxy for hot-air recirculation / bypass air rather than a true airflow
  solve.
- Outlet temperature = inlet + a delta-T scaled by load relative to a
  reference (`rack_delta_t_c`, default 12°C).
- **Status flags**: `HOTSPOT` (air-cooled rack over the density ceiling, or
  inlet > 27°C), `INSUFFICIENT_AIRFLOW` (delta-T implausibly small for a
  loaded rack), otherwise `OK`.

## Heatmap (`cooling/thermal.py::heatmap_zone`, `visualization/thermal_map.py`)

Outlet temperatures are classified into five zones (BLUE → GREEN → YELLOW →
ORANGE → RED at 18 / 24 / 27 / 32 °C) and interpolated across the floor plate
with `scipy.interpolate.griddata` to produce a continuous 2D heatmap.

## Airflow (`cooling/hvac.py`)

`required_airflow_m3_s = heat_load_kw / (ρ_air × cp_air × ΔT)` — standard
sensible-heat airflow equation. `evaluate_airflow()` flags `COOLING
UNDERSIZED`, `COOLING OVERSIZED` (>2.2× headroom) or `INSUFFICIENT AIRFLOW`.

## Cooling plant (`cooling/chiller.py`)

Chiller COP degrades/improves linearly with ambient wet-bulb temperature
relative to a 24°C design point (±4%/°C, clamped to [0.5×, 1.8×] the
nameplate COP — a simplification of a real chiller performance curve).
When `ambient_wetbulb_c ≤ free_cooling_threshold_c` (default 12°C) and free
cooling is enabled, the plant switches to an economiser mode at a very high
effective COP (mechanical refrigeration bypassed).

Pump and fan auxiliary loads are estimated as fixed fractions of cooling
load, divided by their respective efficiencies (`pump_efficiency`,
`fan_efficiency`).

## Liquid cooling (`cooling/liquid_cooling.py`)

`coolant_flow_rate = heat / (cp_water × ΔT)`. Captured heat = rack heat ×
`liquid_cooling_capture_fraction` (default 0.85 — the rest still loads room
air, per the rack profile above). Pump energy is a simplified
flow-proportional proxy divided by pump efficiency.

## Heat recovery (`cooling/heat_recovery.py`)

`recoverable_heat_kw = total_heat_kw × heat_recovery_max_fraction`;
`recovered_heat_kw = recoverable_heat_kw × heat_recovery_efficiency`. Feeds
the ERE calculation (see `energy_model.md`) and the demo facility's
district-heating narrative.

## Water use

`cooling/cooling_tower.py::water_consumption_m3_per_hour` uses the latent
heat of vaporisation (~2260 kJ/kg) to estimate evaporative loss from heat
rejected, plus blowdown scaled by assumed cycles of concentration. Feeds the
WUE metric.
