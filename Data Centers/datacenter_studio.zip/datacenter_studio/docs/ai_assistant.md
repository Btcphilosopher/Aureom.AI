# AI Design Assistant

## Design philosophy (section 26)

The assistant is **rule-based, deterministic, and fully transparent** — it
inspects the live `FacilityResults` and `DataCenter` model and evaluates a
fixed set of engineering rules (`ai/recommendations.py::generate_recommendations`).
It does **not** call an external LLM and it **never silently mutates the
model**: every recommendation is returned as a `Recommendation` object with:

- `title` — the human-readable finding (matches the section-26 examples,
  e.g. "Rack density exceeds the selected air-cooling configuration...").
- `why` — the engineering rationale.
- `expected_impact` — a quantified or qualitative estimate.
- `risk` — the trade-off/downside.
- `apply` — an optional callback (`Callable[[DataCenter], None]`) the UI
  invokes only when the user explicitly clicks **APPLY CHANGE**.

## Natural-language design generation (section 47)

`ai/design_reasoning.py::parse_design_brief` is a regex/keyword parser
(zero external dependencies, fully deterministic) that extracts:

- IT load (MW)
- rack density (kW)
- liquid-cooling intent
- redundancy level (N / N+1 / 2N / 2N+1)
- solar fraction (%)
- battery size (MWh)

into a `DataCenterSpecification`. `DesignAssistant.generate_from_text()`
applies this specification to a fresh `DataCenter`, runs
`compute_results()` (which internally runs validation), and returns a
narrative explanation (`explain_architecture`) alongside the design and the
parsed spec — satisfying the "VALIDATION → SIMULATION → OPTIMISATION, then
explain" flow. (Optimisation is available on demand via `dc.optimise()`;
it is not run automatically so the initial generation stays fast.)

## Iteration commands (section 48)

`ai/design_reasoning.py::parse_iteration_command` recognises two families of
instruction:

1. **Direct parameter commands** (deterministic, no optimisation needed):
   "Prepare this for a hotter climate" (+8°C ambient), "Add N MW of future
   expansion" (grid capacity + IT load headroom), "Convert high-density
   racks to liquid cooling" (rack-by-rack conversion above the air-cooling
   ceiling).
2. **Objective-reweighting commands**: "Reduce PUE", "Increase GPU
   capacity", "Make the facility cheaper", "Increase resilience", "Reduce
   water consumption", "Optimise for renewable electricity", "Maximise
   profit" — each maps to a distinct objective-weight dictionary consumed
   by `dc.optimise(objectives=...)`.

Every call returns an `IterationProposal` (never applies anything);
`DesignAssistant.apply_iteration()` is the explicit, separate step that
either runs the `apply` callback or launches an optimisation run — matching
section 48's "Always show proposed changes before applying them."

## Extending the rule set

Add new rules to `ai/recommendations.py::generate_recommendations` (read
`results`/`dc`, decide whether to fire, build a `Recommendation`). Add new
natural-language patterns to `ai/design_reasoning.py::_COMMANDS` (regex →
description → objective weights) or as an explicit direct-command branch in
`parse_iteration_command` for commands that map to a concrete parameter
change rather than a re-optimisation.
