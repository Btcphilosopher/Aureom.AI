# Power Model

DATACENTER.STUDIO models the electrical delivery chain from the utility grid
to the server power supply as a sequence of loss stages, walked backwards
from the IT load (`power/power_distribution.py::compute_power_chain`):

```
GRID → MV SWITCHGEAR / SUBSTATION → TRANSFORMER → LV SWITCHGEAR → UPS →
BUSWAY → PDU → RACK → SERVER
```

## Loss model

Each stage applies either an **efficiency** (output = input × η) or a
**loss fraction** (output = input × (1 − f)). Values are pulled from
`config/constants.py::ASSUMPTIONS` and are user-editable at runtime via
`dc.assumptions["..."]`:

| Stage | Assumption key | Default |
|---|---|---|
| PDU | `pdu_efficiency` | 0.99 |
| Busway | `busway_loss_fraction` | 0.01 |
| UPS | `ups_efficiency` | 0.96 |
| LV switchgear | `lv_switchgear_loss_fraction` | 0.003 |
| Transformer | `transformer_efficiency` | 0.985 |
| MV switchgear | `mv_switchgear_loss_fraction` | 0.002 |
| Cabling | `cabling_loss_fraction` | 0.01 |

`facility_power_kw = it_load_kw + Σ(stage losses)`. This is the power drawn
from the grid to serve IT alone; cooling, lighting and other facility loads
are added on top when computing PUE (see `energy_model.md`).

## Redundancy

Four levels are supported: `N`, `N+1`, `2N`, `2N+1`. Redundancy is checked
with a simplified N-1 contingency test (`power/power_distribution.py::check_redundancy`):

- **N / N+1**: remove the single largest UPS (and generator) unit from the
  fleet; the remaining capacity must still cover the critical load.
- **2N / 2N+1**: halve total UPS and generator capacity (fully mirrored
  system); the remaining half must cover the critical load.

This is intentionally conservative and simplified — it is not a substitute
for a real single-line diagram / failure-mode analysis.

## UPS and battery

`power/ups.py` computes UPS loading (`% of rated kVA × power factor`) and
losses. `power/battery.py` implements a stateful `BatteryState` +
`dispatch_step()` used both for:

- **Backup-time sizing**: `battery_backup_minutes()` — usable energy ÷
  critical load.
- **Hourly dispatch** (`energy/storage.py`): opportunistic charging from
  renewable surplus, and peak-shaving discharge above a rolling percentile
  threshold of facility load.

## Generators

`power/generator.py` distributes a given load proportionally across the
generator fleet (respecting each unit's minimum-load fraction), and
computes fuel burn from `fuel_consumption_l_per_kwh` (declared per unit).
`backup_runtime_hours()` divides a fuel reserve by the burn rate.

## Transformer / UPS sizing helpers

`required_transformer_capacity_mva()` and `required_ups_capacity_kva()`
size components for a target load, redundancy level and safety margin —
used by the AI assistant's recommendations and by manual "what capacity do
I need" checks in the UI.
