# Financial Model

## CAPEX (`economics/capex.py`)

A category-by-category capital cost estimate driven by representative unit
costs (`UNIT_COSTS`, all USD, all user-overridable):

| Category | Basis |
|---|---|
| Land | site area (m²) |
| Building / Structure | gross floor area (m²) |
| Electrical | IT load (kW) |
| Transformers | installed capacity (MVA) |
| UPS | installed capacity (kVA) |
| Generators | installed capacity (MW) |
| Cooling | IT load (kW), blended air/liquid unit cost by liquid-cooled fraction |
| Networking / Racks | per rack |
| Servers / GPU | per unit |
| Battery | MWh installed |
| Solar | MW installed |
| Security / Fire systems | gross floor area (m²) |

Engineering (default 6%) and contingency (default 10%) are applied on top
of the subtotal, in that order (contingency is computed on subtotal +
engineering).

## OPEX (`economics/opex.py`)

Electricity (from the resolved facility load × grid price), water (from the
cooling-tower water-use model × `water_cost_per_m3`), periodic
generator-test fuel, maintenance (% of CAPEX), staffing (headcount ×
average salary, headcount scaled with rack count), network circuits (per
rack), insurance (% of CAPEX), and a small residual "other" category.

## Revenue (`economics/revenue.py`)

Deliberately independent of the engineering simulation (section 25): GPU
rental (`$/GPU-hour × utilisation`), server/rack rental (monthly), and a
minor power-passthrough revenue component. GPU-led pricing is used whenever
GPUs are present in the design; otherwise server/rack rental (whichever is
larger) is used.

## Blended metrics (`economics/financials.py`)

- **TCO** = CAPEX + (annual OPEX × horizon years, default 15).
- **Cost per MW / rack / kW / GPU** = CAPEX ÷ the relevant denominator.
- **NPV** = `Σ cash_flow_t / (1 + r)^t`, `cash_flows[0] = −CAPEX`,
  subsequent years = `annual_revenue − annual_opex`.
- **IRR**: bisection search for the discount rate that zeroes NPV over
  `[-99%, 500%]` (no external `numpy-financial` dependency).
- **Payback period**: simple (non-discounted) cumulative cash flow
  crossing zero, linearly interpolated within the crossing year.
- **ROI**: total post-CAPEX profit over the horizon ÷ CAPEX, as a
  percentage.

## Disclaimer

All unit costs are representative, order-of-magnitude figures for
comparative design exploration — not vendor quotes or a bankable cost
estimate.
