# Energy Model

## Efficiency metrics (section 19)

All four are computed in `core/datacenter.py::DataCenter.compute_results`
and documented here explicitly, per section 44's requirement that every
simplified metric expose its definition:

- **PUE** (Power Usage Effectiveness) = `facility_load_kw / it_load_kw`,
  where `facility_load_kw = it_load_kw + power_losses_kw +
  cooling_electrical_kw + lighting_kw`. A known-value helper,
  `core/units.py::calculate_pue(total, it)`, implements the raw ratio for
  direct use/testing.
- **WUE** (Water Usage Effectiveness, L/kWh) = `(water_use_m3_per_hour ×
  1000) / it_load_kw` — annualised water litres per IT kWh.
- **CUE** (Carbon Usage Effectiveness, kgCO2e/kWh) =
  `grid_carbon_intensity_kg_per_kwh × PUE` — a simplified approximation that
  assumes the facility's carbon intensity scales with its total energy
  draw at the grid's average carbon intensity (on-site generation/renewables
  are not separately netted out of this particular ratio; the full
  time-series simulation nets grid import directly instead — see below).
- **ERE** (Energy Reuse Effectiveness) = `PUE − (recovered_heat_kw /
  it_load_kw)` — PUE reduced by the fraction of IT load whose waste heat is
  usefully recovered (section 17).

## Hourly time-series simulation (section 30, `simulation/`)

`DataCenter.simulate(hours=...)` runs `simulation/facility_sim.py`, which:

1. Builds an hour-of-day / day-of-week / day-of-year index for the
   requested horizon (24h / 168h / 720h / 8760h).
2. Generates an IT load series with mild diurnal/weekly cycles
   (`simulation/timestep.py::calculate_it_load`), vectorised with NumPy.
3. Generates an ambient temperature series (diurnal + seasonal sinusoids)
   and runs the vectorised cooling-plant model
   (`simulation/timestep.py::calculate_cooling_electrical`) across every
   hour at once.
4. Generates solar (bell-curve diurnal, seasonally modulated) and wind
   (AR(1) stochastic) generation (`energy/renewables.py`).
5. Runs battery dispatch hour-by-hour (`energy/storage.py`, built on
   `power/battery.py`): opportunistic charging from renewable surplus,
   peak-shaving discharge above the horizon's 80th-percentile load.
6. Prices grid import with optional time-of-use multipliers
   (`energy/electricity.py`) and accumulates cost and carbon.

The result (`SimulationResult`) carries both the full hourly
`pandas.DataFrame` (for the UI timeline/charts) and horizon-scaled scalar
summaries (`pue`, `annual_energy_kwh`, `total_carbon_kg`,
`renewable_fraction`, plus `capex`/`annual_opex`/`annual_revenue` carried
over from the single-point design evaluation).

This vectorised approach keeps an 8760-hour run to well under a second on
commodity hardware (section 46).

## Renewables and storage (sections 21-22)

- **Solar**: `energy/renewables.py::solar_generation_mw` — a raised-cosine
  diurnal shape between a seasonally-shifted sunrise/sunset, scaled so its
  annual mean matches the configured capacity factor.
- **Wind**: an AR(1) mean-reverting stochastic series around the configured
  capacity factor — deliberately simple; swap in a real wind resource model
  for production use.
- **Battery**: `power/battery.py::dispatch_step` — charges from renewable
  surplus (up to power/energy limits), discharges to shave load above a
  threshold. `energy/storage.py::simulate_battery_series` runs this across
  a whole time series.

## Monte Carlo (section 29)

`optimisation/sensitivity.py::monte_carlo_analysis` draws N samples over
electricity price, IT utilisation, ambient temperature, cooling efficiency
(chiller COP), and renewable output capacity factor (construction cost is
applied as a CAPEX multiplier), evaluates a single-point `compute_results()`
per sample (fast — no full 8760h run per sample), and reports P10/P50/P90
for PUE, CAPEX, OPEX, revenue, carbon and EBITDA.
