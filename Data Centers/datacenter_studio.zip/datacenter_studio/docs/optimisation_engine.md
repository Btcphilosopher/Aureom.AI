# Optimisation Engine

## Abstraction (section 27)

`optimisation/optimiser.py::BaseOptimizer` defines one method:
`run(param_space, evaluate) -> (best_params, best_score)`. Four concrete
strategies are provided and are fully interchangeable — nothing else in the
platform hard-codes a particular method:

| Class | Method key | Notes |
|---|---|---|
| `GridOptimizer` | `"grid"` | Exhaustive grid over `steps` points per dimension. |
| `RandomSearchOptimizer` | `"random"` | Uniform random sampling, `iterations` draws. |
| `DifferentialEvolutionOptimizer` | `"differential_evolution"` | Wraps `scipy.optimize.differential_evolution`. |
| `EvolutionaryOptimizer` | `"genetic"` / `"evolutionary"` | Dependency-free tournament-selection GA with blend crossover and Gaussian mutation. |

`DataCenter.optimise(objectives=..., method=..., param_space=..., **kwargs)`
is the entry point; `**kwargs` are forwarded to the chosen optimizer's
`run()` (e.g. `maxiter`, `popsize`, `generations`, `steps`, `iterations`).

## Parameter space

`optimisation/optimiser.py::PARAM_ACCESSORS` centrally maps a parameter name
to a `(getter, setter)` pair on a `DataCenter` (solar capacity, battery
capacity/power, cooling capacity, liquid-cooling fraction, chilled-water
supply temperature, grid price, IT load). `default_param_space()` builds a
sensible default range from the design's current state; callers may pass
their own `param_space: dict[str, (low, high)]`.

## Objective function (section 27)

`optimisation/objectives.py::weighted_objective` normalises each raw metric
(CAPEX, OPEX, PUE, carbon, water, capacity, revenue, resilience) onto a
`[0, 1]` "badness" scale via a declared reference range
(`REFERENCE_RANGES`) and combines them with user-supplied weights:

```
objective = Σ weight_i × normalised_score_i        (lower is better)
```

`OBJECTIVE_SENSE` declares whether each metric is minimised or maximised;
maximise-sense metrics are inverted (`1 − normalised_fraction`) so every
term in the sum shares the same "lower is better" direction. Resilience is
derived from the design's redundancy level (`N`→0.0 … `2N+1`→1.0).

## Constraints (section 37)

`optimisation/constraints.py::constraint_penalty` adds a fixed penalty per
`CRITICAL` (5.0) and `WARNING` (0.5) validation alert on the resulting
design (see `core/validation.py`), steering every optimiser away from
infeasible engineering states without hard-failing candidate evaluation.

## Scenario engine (section 28)

`optimisation/scenarios.py::PRESET_SCENARIOS` defines nine named scenarios
(BASE CASE, HIGH ENERGY PRICE, HIGH GPU DENSITY, HOT SUMMER, GRID
CONSTRAINT, RENEWABLE EXPANSION, LIQUID COOLING, FUTURE EXPANSION, MINIMUM
CAPEX), each a pure function that mutates a cloned `DataCenter`.
`run_scenarios()` runs a batch and returns a comparison `DataFrame`.

## Comparison engine (section 39)

`optimisation/scenarios.py::compare_designs` builds a metric × design table
(IT load, PUE, CAPEX, OPEX, revenue, cooling type, carbon, cost/MW) plus a
"balanced choice" recommendation row: the lowest-PUE design among those
within 25% of the cheapest CAPEX.

## Pareto frontier (section 50)

`optimisation/scenarios.py::pareto_frontier` implements classic Pareto
dominance over a list of `FacilityResults` and arbitrary minimise/maximise
metric lists — used by the "Design Space Explorer" scatter chart.

## Sensitivity & Monte Carlo (section 29)

See `energy_model.md` — `optimisation/sensitivity.py` provides both
one-at-a-time sweeps (`tornado_chart_data`) and full Monte Carlo sampling
(`monte_carlo_analysis`).
