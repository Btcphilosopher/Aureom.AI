"""
Thermal subsystem time-series simulation (section 30), built on the
vectorised primitives in :mod:`simulation.timestep`.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from simulation.timestep import (
    calculate_ambient_temperature,
    calculate_cooling_electrical,
    calculate_cooling_load,
    calculate_heat_recovery,
)


@dataclass
class ThermalSimResult:
    ambient_temperature_c: np.ndarray
    cooling_load_kw: np.ndarray
    cooling_electrical_kw: np.ndarray
    cop: np.ndarray
    free_cooling_mask: np.ndarray
    recovered_heat_kw: np.ndarray


def simulate_thermal(
    n: int,
    hour_of_day: np.ndarray,
    day_of_year: np.ndarray,
    total_heat_kw_series: np.ndarray,
    mean_ambient_c: float,
    assumptions: dict,
    free_cooling_enabled: bool,
    heat_recovery_enabled: bool,
) -> ThermalSimResult:
    ambient = calculate_ambient_temperature(n, mean_ambient_c, hour_of_day, day_of_year)
    ambient_wetbulb = ambient - 5.0  # simplified wet-bulb depression assumption

    cooling_load = calculate_cooling_load(total_heat_kw_series)
    cooling_electrical, cop, free_mask = calculate_cooling_electrical(
        cooling_load, ambient_wetbulb, assumptions, free_cooling_enabled
    )
    recovered = calculate_heat_recovery(total_heat_kw_series, heat_recovery_enabled, assumptions)

    return ThermalSimResult(
        ambient_temperature_c=ambient,
        cooling_load_kw=cooling_load,
        cooling_electrical_kw=cooling_electrical,
        cop=cop,
        free_cooling_mask=free_mask,
        recovered_heat_kw=recovered,
    )
