"""
Power subsystem time-series simulation (section 30).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from simulation.timestep import calculate_it_load, calculate_power_losses


@dataclass
class PowerSimResult:
    it_load_mw: np.ndarray
    power_losses_kw: np.ndarray


def simulate_power(
    n: int,
    base_it_load_mw: float,
    loss_fraction: float,
    hour_of_day: np.ndarray,
    day_of_week: np.ndarray,
) -> PowerSimResult:
    it_load = calculate_it_load(base_it_load_mw, n, hour_of_day=hour_of_day, day_of_week=day_of_week)
    losses = calculate_power_losses(it_load * 1000.0, loss_fraction)
    return PowerSimResult(it_load_mw=it_load, power_losses_kw=losses)
