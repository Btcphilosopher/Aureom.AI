"""Simulation package: hourly time-series engine (section 30)."""
