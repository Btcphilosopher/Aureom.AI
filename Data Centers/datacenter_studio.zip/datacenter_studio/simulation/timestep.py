"""
Per-timestep calculation primitives (section 30), vectorised with NumPy so
an 8760-hour simulation runs in well under a second (section 46).

Each ``calculate_*`` function mirrors the function named in the spec and
operates on whole NumPy arrays (one element per timestep) rather than being
called in a Python loop.
"""

from __future__ import annotations

import numpy as np

from cooling.chiller import effective_cop, is_free_cooling_available


def calculate_it_load(base_it_load_mw: float, n: int, daily_variation: float = 0.06,
                       weekly_variation: float = 0.04, hour_of_day: np.ndarray | None = None,
                       day_of_week: np.ndarray | None = None, rng: np.random.Generator | None = None) -> np.ndarray:
    """IT load time series: a stable base load with a mild diurnal /
    weekly utilisation cycle plus small stochastic noise (workload jitter)."""
    hour_of_day = hour_of_day if hour_of_day is not None else np.arange(n) % 24
    day_of_week = day_of_week if day_of_week is not None else (np.arange(n) // 24) % 7
    rng = rng or np.random.default_rng(11)

    diurnal = 1.0 + daily_variation * np.sin(2 * np.pi * (hour_of_day - 14) / 24.0)
    weekly = 1.0 - weekly_variation * (day_of_week >= 5)  # slightly lower on weekends
    noise = 1.0 + rng.normal(0, 0.01, size=n)
    return base_it_load_mw * diurnal * weekly * noise


def calculate_ambient_temperature(n: int, mean_c: float, hour_of_day: np.ndarray,
                                   day_of_year: np.ndarray, diurnal_amplitude_c: float = 5.0,
                                   seasonal_amplitude_c: float = 8.0) -> np.ndarray:
    diurnal = diurnal_amplitude_c * np.sin(2 * np.pi * (hour_of_day - 15) / 24.0)
    seasonal = seasonal_amplitude_c * np.cos(2 * np.pi * (day_of_year - 200) / 365.0)
    return mean_c + diurnal + seasonal


def calculate_cooling_load(total_heat_kw_series: np.ndarray) -> np.ndarray:
    """In this simplified model the cooling load tracks total heat 1:1
    (all heat must ultimately be rejected)."""
    return total_heat_kw_series


def calculate_cooling_electrical(
    cooling_load_kw: np.ndarray,
    ambient_wetbulb_c: np.ndarray,
    assumptions: dict,
    free_cooling_enabled: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Vectorised chiller-plant electrical draw. Returns (electrical_kw, cop, free_cooling_mask)."""
    base_cop = assumptions.get("chiller_base_cop", 5.5)
    threshold = assumptions.get("free_cooling_threshold_c", 12.0)
    pump_eff = assumptions.get("pump_efficiency", 0.80)
    fan_eff = assumptions.get("fan_efficiency", 0.70)

    delta = 24.0 - ambient_wetbulb_c
    cop = np.clip(base_cop + 0.04 * base_cop * delta, base_cop * 0.5, base_cop * 1.8)

    free_mask = free_cooling_enabled & (ambient_wetbulb_c <= threshold)
    cop = np.where(free_mask, np.maximum(cop, base_cop * 3.0), cop)

    chiller_kw = cooling_load_kw / cop
    pump_kw = cooling_load_kw * 0.03 / max(pump_eff, 0.01)
    fan_kw = cooling_load_kw * 0.02 / max(fan_eff, 0.01)
    return chiller_kw + pump_kw + fan_kw, cop, free_mask


def calculate_power_losses(it_load_kw: np.ndarray, loss_fraction: float) -> np.ndarray:
    """Power-chain losses scaled proportionally to IT load using the
    loss fraction derived from a full-chain calculation at rated load
    (section 10-11); a good approximation since transformer/UPS efficiency
    curves are relatively flat near typical operating points."""
    return it_load_kw * loss_fraction


def calculate_renewable_generation(solar_mw: np.ndarray, wind_mw: np.ndarray) -> np.ndarray:
    return solar_mw + wind_mw


def calculate_heat_recovery(total_heat_kw: np.ndarray, enabled: bool, assumptions: dict) -> np.ndarray:
    if not enabled:
        return np.zeros_like(total_heat_kw)
    max_fraction = assumptions.get("heat_recovery_max_fraction", 0.50)
    efficiency = assumptions.get("heat_recovery_efficiency", 0.65)
    return total_heat_kw * max_fraction * efficiency


def calculate_cost(grid_import_mw: np.ndarray, price_per_kwh: np.ndarray, dt_hours: float = 1.0) -> np.ndarray:
    return grid_import_mw * 1000.0 * dt_hours * price_per_kwh


def calculate_carbon(grid_import_mw: np.ndarray, carbon_intensity_kg_per_kwh: float,
                      dt_hours: float = 1.0) -> np.ndarray:
    return grid_import_mw * 1000.0 * dt_hours * carbon_intensity_kg_per_kwh
