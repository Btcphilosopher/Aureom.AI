"""
Full facility hourly simulation engine (sections 30, 52).

Runs :func:`run_facility_simulation` for a chosen horizon (24h / 7-day /
30-day / 1-year, section 20) and returns a :class:`SimulationResult`
containing both the per-hour time series (as a ``pandas.DataFrame``, for the
UI timeline / charts) and the annualised scalar summary used by the
top-level API (``result.pue``, ``result.annual_energy_kwh``, ``result.capex``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from energy.electricity import hourly_price_per_kwh
from energy.emissions import cue as cue_fn
from energy.renewables import solar_generation_mw, wind_generation_mw
from energy.storage import simulate_battery_series
from simulation.power_sim import simulate_power
from simulation.thermal_sim import simulate_thermal

if TYPE_CHECKING:
    from core.datacenter import DataCenter


@dataclass
class SimulationResult:
    dataframe: pd.DataFrame
    # Annualised / horizon-scalar summary (section 41 API)
    pue: float = 1.0
    wue: float = 0.0
    cue: float = 0.0
    annual_energy_kwh: float = 0.0
    total_energy_kwh: float = 0.0
    total_cost: float = 0.0
    total_carbon_kg: float = 0.0
    renewable_fraction: float = 0.0
    capex: float = 0.0
    annual_opex: float = 0.0
    annual_revenue: float = 0.0
    hours: int = 0

    def to_csv(self, path: str) -> None:
        self.dataframe.to_csv(path, index=False)


def run_facility_simulation(dc: "DataCenter", hours: int = 8760, start: datetime | None = None) -> SimulationResult:
    n = max(1, int(hours))
    start = start or datetime(2026, 1, 1)
    timestamps = [start + timedelta(hours=i) for i in range(n)]
    hour_of_day = np.array([t.hour for t in timestamps])
    day_of_week = np.array([t.weekday() for t in timestamps])
    day_of_year = np.array([t.timetuple().tm_yday for t in timestamps])

    baseline = dc.compute_results()
    base_it_load_mw = baseline.it_load_mw
    loss_fraction = (baseline.power_losses_kw / (baseline.it_load_mw * 1000.0)
                      if baseline.it_load_mw > 0 else 0.0)

    power_sim = simulate_power(n, base_it_load_mw, loss_fraction, hour_of_day, day_of_week)
    it_load_mw = power_sim.it_load_mw
    it_load_kw = it_load_mw * 1000.0

    # Heat load tracks IT load plus a fixed lighting/people/electrical-loss offset
    # (proportionally re-derived from the baseline single-point calculation).
    heat_offset_kw = max(baseline.total_heat_kw - baseline.it_load_mw * 1000.0, 0.0)
    total_heat_kw = it_load_kw + heat_offset_kw

    thermal = simulate_thermal(
        n, hour_of_day, day_of_year, total_heat_kw,
        mean_ambient_c=dc.cooling.ambient_temperature_c,
        assumptions=dc.assumptions,
        free_cooling_enabled=dc.cooling.free_cooling_enabled,
        heat_recovery_enabled=dc.cooling.heat_recovery_enabled,
    )

    lighting_kw = dc.building.gross_floor_area_m2 * dc.assumptions.get("lighting_w_per_m2", 8.0) / 1000.0
    facility_load_kw = it_load_kw + power_sim.power_losses_kw + thermal.cooling_electrical_kw + lighting_kw
    facility_load_mw = facility_load_kw / 1000.0

    solar_mw = solar_generation_mw(dc.energy.solar_capacity_mw, hour_of_day, day_of_year,
                                    dc.energy.solar_capacity_factor)
    wind_mw = wind_generation_mw(dc.energy.wind_capacity_mw, n, dc.energy.wind_capacity_factor)
    renewable_mw = solar_mw + wind_mw

    battery = simulate_battery_series(dc.energy, facility_load_mw, renewable_mw)

    price = hourly_price_per_kwh(dc.energy, hour_of_day)
    cost = battery["grid_import_mw"] * 1000.0 * price
    carbon = battery["grid_import_mw"] * 1000.0 * dc.assumptions.get("grid_carbon_intensity_kg_per_kwh", 0.233)

    pue_series = np.divide(facility_load_kw, it_load_kw, out=np.ones_like(it_load_kw), where=it_load_kw > 0)

    df = pd.DataFrame({
        "timestamp": timestamps,
        "it_load_mw": it_load_mw,
        "facility_load_mw": facility_load_mw,
        "cooling_load_kw": thermal.cooling_load_kw,
        "cooling_electrical_kw": thermal.cooling_electrical_kw,
        "grid_import_mw": battery["grid_import_mw"],
        "solar_generation_mw": solar_mw,
        "wind_generation_mw": wind_mw,
        "renewable_generation_mw": renewable_mw,
        "battery_soc": battery["soc"],
        "battery_charge_mw": battery["charge_mw"],
        "battery_discharge_mw": battery["discharge_mw"],
        "temperature_c": thermal.ambient_temperature_c,
        "pue": pue_series,
        "cop": thermal.cop,
        "free_cooling": thermal.free_cooling_mask,
        "price_per_kwh": price,
        "cost": cost,
        "carbon_kg": carbon,
        "recovered_heat_kw": thermal.recovered_heat_kw,
    })

    total_it_energy_kwh = float(it_load_mw.sum()) * 1000.0
    total_facility_energy_kwh = float(facility_load_mw.sum()) * 1000.0
    total_carbon_kg = float(carbon.sum())
    total_cost = float(cost.sum())
    renewable_energy_kwh = float(renewable_mw.sum()) * 1000.0
    scale_to_annual = 8760.0 / n

    avg_pue = total_facility_energy_kwh / total_it_energy_kwh if total_it_energy_kwh > 0 else 1.0
    avg_wue = baseline.wue
    avg_cue = cue_fn(total_carbon_kg, total_it_energy_kwh) if total_it_energy_kwh else 0.0

    return SimulationResult(
        dataframe=df,
        pue=avg_pue,
        wue=avg_wue,
        cue=avg_cue,
        annual_energy_kwh=total_facility_energy_kwh * scale_to_annual,
        total_energy_kwh=total_facility_energy_kwh,
        total_cost=total_cost * scale_to_annual,
        total_carbon_kg=total_carbon_kg * scale_to_annual,
        renewable_fraction=(renewable_energy_kwh / total_facility_energy_kwh) if total_facility_energy_kwh else 0.0,
        capex=baseline.capex,
        annual_opex=baseline.annual_opex,
        annual_revenue=baseline.annual_revenue,
        hours=n,
    )
