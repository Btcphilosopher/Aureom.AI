"""Core package: central data model, simulation orchestration, validation, units."""
