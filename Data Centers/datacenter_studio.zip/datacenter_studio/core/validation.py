"""
Design validation / engineering rules engine (section 37).

Inspects a fully-resolved :class:`~datacenter_studio.core.datacenter.DataCenter`
(via its computed :class:`~datacenter_studio.core.datacenter.FacilityResults`)
and returns a list of :class:`Alert` objects, categorised INFO / WARNING /
CRITICAL. Never silently treats an invalid engineering state as valid.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from config.constants import SEVERITY_CRITICAL, SEVERITY_INFO, SEVERITY_WARNING

if TYPE_CHECKING:
    from core.datacenter import DataCenter, FacilityResults


@dataclass
class Alert:
    severity: str
    code: str
    message: str
    subsystem: str


def validate_design(dc: "DataCenter", results: "FacilityResults") -> list[Alert]:
    """Run all engineering rules against a design + its computed results."""
    alerts: list[Alert] = []

    # --- Power: transformer loading ---
    if results.transformer_loading_pct > 100.0:
        alerts.append(Alert(SEVERITY_CRITICAL, "PWR-001",
            f"Transformer overloaded: {results.transformer_loading_pct:.0f}% of rated capacity.",
            "power"))
    elif results.transformer_loading_pct > 85.0:
        alerts.append(Alert(SEVERITY_WARNING, "PWR-002",
            f"Transformer loading high: {results.transformer_loading_pct:.0f}%.", "power"))

    # --- Power: UPS loading ---
    if results.ups_loading_pct > 100.0:
        alerts.append(Alert(SEVERITY_CRITICAL, "PWR-003",
            f"UPS overloaded: {results.ups_loading_pct:.0f}% of rated capacity.", "power"))
    elif results.ups_loading_pct > 85.0:
        alerts.append(Alert(SEVERITY_WARNING, "PWR-004",
            f"UPS loading high: {results.ups_loading_pct:.0f}%.", "power"))

    # --- Power: generator backup sufficiency ---
    if results.generator_capacity_mw < results.critical_load_mw:
        alerts.append(Alert(SEVERITY_CRITICAL, "PWR-005",
            f"Insufficient backup generation: {results.generator_capacity_mw:.1f} MW available "
            f"vs {results.critical_load_mw:.1f} MW critical load.", "power"))

    # --- Power: redundancy sanity ---
    if not results.redundancy_satisfied:
        alerts.append(Alert(SEVERITY_WARNING, "PWR-006",
            f"Selected redundancy level '{dc.power.redundancy}' is not fully satisfied by "
            f"the current UPS/generator count.", "power"))

    # --- Grid capacity ---
    if results.facility_load_mw > dc.site.grid_capacity_mw:
        alerts.append(Alert(SEVERITY_CRITICAL, "PWR-007",
            f"Facility load ({results.facility_load_mw:.1f} MW) exceeds contracted grid "
            f"capacity ({dc.site.grid_capacity_mw:.1f} MW).", "power"))

    # --- Cooling capacity ---
    if dc.cooling.cooling_capacity_kw < results.total_heat_kw:
        alerts.append(Alert(SEVERITY_CRITICAL, "CLG-001",
            f"Insufficient cooling: {dc.cooling.cooling_capacity_kw:,.0f} kW capacity vs "
            f"{results.total_heat_kw:,.0f} kW heat load.", "cooling"))
    elif dc.cooling.cooling_capacity_kw < results.total_heat_kw * 1.10:
        alerts.append(Alert(SEVERITY_WARNING, "CLG-002",
            "Cooling capacity margin below 10% — little headroom for hot spots.", "cooling"))
    elif dc.cooling.cooling_capacity_kw > results.total_heat_kw * 2.0:
        alerts.append(Alert(SEVERITY_INFO, "CLG-003",
            "Cooling capacity appears oversized (>2x current heat load).", "cooling"))

    # --- Per-rack cooling suitability ---
    air_limit = dc.assumptions.get("air_cooling_max_kw_per_rack", 20.0)
    for floor in dc.building.floors:
        for rack in floor.racks:
            if rack.cooling_type == "air" and rack.rack_it_load_kw > air_limit:
                alerts.append(Alert(SEVERITY_WARNING, "CLG-004",
                    f"Rack {rack.rack_id} ({rack.rack_it_load_kw:.0f} kW) exceeds air-cooling "
                    f"limit ({air_limit:.0f} kW) — consider liquid cooling.", "cooling"))

    # --- PUE sanity ---
    if results.pue < 1.0:
        alerts.append(Alert(SEVERITY_CRITICAL, "PUE-001",
            f"Computed PUE ({results.pue:.3f}) is physically impossible (<1.0). Check inputs.",
            "energy"))
    elif results.pue > 2.2:
        alerts.append(Alert(SEVERITY_WARNING, "PUE-002",
            f"PUE ({results.pue:.2f}) is high for a modern facility.", "energy"))

    # --- Site utilisation ---
    if dc.site.site_utilisation_pct > 95.0:
        alerts.append(Alert(SEVERITY_WARNING, "SITE-001",
            f"Site utilisation at {dc.site.site_utilisation_pct:.0f}% — little room for expansion.",
            "site"))

    # --- Battery backup time ---
    if results.battery_backup_minutes < 5.0 and dc.power.battery_capacity_mwh > 0:
        alerts.append(Alert(SEVERITY_WARNING, "PWR-008",
            f"Battery backup time only {results.battery_backup_minutes:.1f} minutes.", "power"))

    if not alerts:
        alerts.append(Alert(SEVERITY_INFO, "OK-000", "No engineering issues detected.", "general"))

    return alerts


def summarise(alerts: list[Alert]) -> dict[str, int]:
    summary = {SEVERITY_INFO: 0, SEVERITY_WARNING: 0, SEVERITY_CRITICAL: 0}
    for a in alerts:
        summary[a.severity] = summary.get(a.severity, 0) + 1
    return summary
