"""
Core typed data model for DATACENTER.STUDIO (section 42).

Every physical / logical object in the facility digital twin is represented
as a plain, typed ``dataclass``. Objects are composable: a :class:`Rack`
contains :class:`Server` objects, a :class:`Floor` contains :class:`Rack`
objects, a :class:`Building` contains :class:`Floor` objects, and so on up to
:class:`Site`. Aggregation methods roll engineering quantities (power,
thermal load, count) up the hierarchy (section 53 — digital twin hierarchy).

These classes hold *state*; the actual engineering calculations (power
losses, thermal propagation, financials, ...) live in the dedicated engine
packages (``power``, ``cooling``, ``economics``, ...) so that the data model
stays independent of calculation logic and of the UI.
"""

from __future__ import annotations

import itertools
import uuid
from dataclasses import dataclass, field
from typing import Literal

# ---------------------------------------------------------------------------
# Identifier helper
# ---------------------------------------------------------------------------

def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# SITE / BUILDING / FLOOR / ROOM  (geometry-facing data, section 5-7)
# ---------------------------------------------------------------------------

@dataclass
class Site:
    """The physical plot on which the data center campus sits (section 5)."""

    name: str = "Site"
    width_m: float = 300.0
    length_m: float = 400.0
    shape: Literal["rectangular", "irregular"] = "rectangular"
    irregular_vertices: list[tuple[float, float]] = field(default_factory=list)

    building_footprint_m2: float = 20_000.0
    parking_area_m2: float = 4_000.0
    substation_area_m2: float = 2_500.0
    generator_area_m2: float = 2_000.0
    cooling_plant_area_m2: float = 3_500.0
    water_storage_area_m2: float = 800.0
    solar_area_m2: float = 15_000.0
    battery_area_m2: float = 1_200.0

    grid_capacity_mw: float = 120.0

    @property
    def area_m2(self) -> float:
        if self.shape == "irregular" and len(self.irregular_vertices) >= 3:
            return _polygon_area(self.irregular_vertices)
        return self.width_m * self.length_m

    @property
    def utility_area_m2(self) -> float:
        return (
            self.substation_area_m2
            + self.generator_area_m2
            + self.cooling_plant_area_m2
            + self.water_storage_area_m2
            + self.solar_area_m2
            + self.battery_area_m2
        )

    @property
    def developed_area_m2(self) -> float:
        return self.building_footprint_m2 + self.parking_area_m2 + self.utility_area_m2

    @property
    def site_utilisation_pct(self) -> float:
        if self.area_m2 <= 0:
            return 0.0
        return 100.0 * self.developed_area_m2 / self.area_m2

    @property
    def building_coverage_pct(self) -> float:
        if self.area_m2 <= 0:
            return 0.0
        return 100.0 * self.building_footprint_m2 / self.area_m2

    @property
    def expansion_area_m2(self) -> float:
        return max(0.0, self.area_m2 - self.developed_area_m2)


def _polygon_area(vertices: list[tuple[float, float]]) -> float:
    """Shoelace formula for an irregular site polygon."""
    n = len(vertices)
    area = 0.0
    for i in range(n):
        x1, y1 = vertices[i]
        x2, y2 = vertices[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) / 2.0


@dataclass
class Room:
    """A functional room within a floor (electrical, mechanical, office, ...)."""

    room_id: str = field(default_factory=lambda: _new_id("room"))
    name: str = "Room"
    room_type: Literal[
        "technical", "electrical", "mechanical", "office", "loading", "security", "compute"
    ] = "compute"
    area_m2: float = 100.0


@dataclass
class Floor:
    """A single floor of a building, containing racks and support rooms (section 7)."""

    floor_id: str = field(default_factory=lambda: _new_id("floor"))
    index: int = 1
    layout_template: str = "hot_aisle_cold_aisle"
    width_m: float = 100.0
    length_m: float = 150.0
    aisle_width_m: float = 1.2
    racks: list["Rack"] = field(default_factory=list)
    rooms: list[Room] = field(default_factory=list)

    @property
    def area_m2(self) -> float:
        return self.width_m * self.length_m

    @property
    def rack_count(self) -> int:
        return len(self.racks)

    @property
    def it_load_kw(self) -> float:
        return sum(r.rack_it_load_kw for r in self.racks)

    @property
    def thermal_load_kw(self) -> float:
        return sum(r.thermal_load_kw for r in self.racks)

    def next_rack_position(self, rack_pitch_m: float = 0.8, row_length: float = 12.0) -> tuple[float, float]:
        """Very small parametric placement helper: fills rows left-to-right."""
        n = len(self.racks)
        per_row = max(1, int(row_length / rack_pitch_m))
        row = n // per_row
        col = n % per_row
        x = 2.0 + col * rack_pitch_m
        y = 2.0 + row * (rack_pitch_m + self.aisle_width_m)
        return x, y


@dataclass
class Building:
    """A building on the site (section 6)."""

    building_id: str = field(default_factory=lambda: _new_id("bldg"))
    name: str = "Building A"
    width_m: float = 100.0
    length_m: float = 150.0
    floor_count: int = 2
    floor_to_floor_height_m: float = 5.5
    raised_floor_height_m: float = 0.6
    ceiling_height_m: float = 3.0
    structural_grid_m: float = 7.5

    technical_area_fraction: float = 0.10
    electrical_area_fraction: float = 0.08
    mechanical_area_fraction: float = 0.10
    office_area_fraction: float = 0.05
    circulation_area_fraction: float = 0.08
    loading_area_fraction: float = 0.02
    security_area_fraction: float = 0.01

    floors: list[Floor] = field(default_factory=list)

    @property
    def footprint_m2(self) -> float:
        return self.width_m * self.length_m

    @property
    def gross_floor_area_m2(self) -> float:
        return self.footprint_m2 * self.floor_count

    @property
    def support_area_fraction(self) -> float:
        return (
            self.technical_area_fraction
            + self.electrical_area_fraction
            + self.mechanical_area_fraction
            + self.office_area_fraction
            + self.circulation_area_fraction
            + self.loading_area_fraction
            + self.security_area_fraction
        )

    @property
    def net_floor_area_m2(self) -> float:
        return self.gross_floor_area_m2 * (1.0 - self.support_area_fraction)

    @property
    def compute_area_m2(self) -> float:
        """Alias for net (white space) floor area available for racks."""
        return self.net_floor_area_m2

    @property
    def technical_area_m2(self) -> float:
        return self.gross_floor_area_m2 * self.technical_area_fraction

    @property
    def plant_area_m2(self) -> float:
        return self.gross_floor_area_m2 * (
            self.mechanical_area_fraction + self.electrical_area_fraction
        )

    @property
    def circulation_area_m2(self) -> float:
        return self.gross_floor_area_m2 * self.circulation_area_fraction

    @property
    def total_height_m(self) -> float:
        return self.floor_count * self.floor_to_floor_height_m

    @property
    def total_it_load_kw(self) -> float:
        return sum(f.it_load_kw for f in self.floors)

    @property
    def total_rack_count(self) -> int:
        return sum(f.rack_count for f in self.floors)


# ---------------------------------------------------------------------------
# COMPUTE: SERVER / RACK / GPU CLUSTER (sections 8-9)
# ---------------------------------------------------------------------------

@dataclass
class Workload:
    """A workload profile driving a server's utilisation and power draw."""

    workload_type: Literal[
        "cpu", "gpu", "ai_training", "ai_inference", "storage", "network", "mixed"
    ] = "cpu"
    utilisation: float = 0.6           # 0..1
    memory_requirement_gb: float = 256.0
    network_bandwidth_gbps: float = 25.0


@dataclass
class Server:
    """A single physical server / node."""

    server_id: str = field(default_factory=lambda: _new_id("srv"))
    form_factor: Literal["1U", "2U", "4U", "blade", "storage", "network"] = "2U"
    category: Literal["general", "storage", "network", "gpu_server", "ai_training", "ai_inference"] = "general"
    idle_power_w: float = 250.0
    max_power_w: float = 750.0
    gpu_count: int = 0
    gpu_power_w: float = 700.0        # per-GPU TDP, if any
    workload: Workload = field(default_factory=Workload)

    @property
    def power_draw_w(self) -> float:
        """Simple, realistic linear-ish power curve: idle + utilisation * (max-idle)."""
        u = max(0.0, min(1.0, self.workload.utilisation))
        base = self.idle_power_w + u * (self.max_power_w - self.idle_power_w)
        gpu = self.gpu_count * self.gpu_power_w * u
        return base + gpu

    @property
    def power_draw_kw(self) -> float:
        return self.power_draw_w / 1000.0

    @property
    def thermal_output_kw(self) -> float:
        """Assume ~99% of electrical draw is rejected as heat (fans etc. included)."""
        return self.power_draw_kw * 0.99


@dataclass
class GPUCluster:
    """A tightly coupled AI training/inference cluster spanning one or more racks."""

    cluster_id: str = field(default_factory=lambda: _new_id("gpucl"))
    name: str = "AI Cluster"
    gpu_model: str = "H100-SXM"
    gpu_count: int = 512
    gpu_tdp_w: float = 700.0
    interconnect: Literal["infiniband_400g", "infiniband_800g", "ethernet_400g", "nvlink"] = "infiniband_400g"
    utilisation: float = 0.85

    @property
    def power_kw(self) -> float:
        return self.gpu_count * self.gpu_tdp_w * self.utilisation / 1000.0 * 1.25  # +25% host/network overhead


@dataclass
class Rack:
    """A single rack (section 7-9). Racks are heterogeneous in density."""

    rack_id: str = field(default_factory=lambda: _new_id("rack"))
    x: float = 0.0
    y: float = 0.0
    height_u: int = 42
    width_m: float = 0.6
    depth_m: float = 1.2
    cooling_type: Literal[
        "air", "crac", "crah", "chilled_water", "direct_liquid", "rear_door_hx", "immersion", "hybrid"
    ] = "air"
    network_ports: int = 48
    servers: list[Server] = field(default_factory=list)
    design_power_kw: float | None = None  # override: fixed nameplate density (e.g. GPU rack)

    @property
    def rack_it_load_kw(self) -> float:
        if self.design_power_kw is not None:
            return self.design_power_kw
        return sum(s.power_draw_kw for s in self.servers)

    @property
    def rack_peak_power_kw(self) -> float:
        """Peak assumes all servers at max power (nameplate), 1.15x diversity headroom."""
        if self.design_power_kw is not None:
            return self.design_power_kw * 1.10
        nameplate = sum((s.max_power_w + s.gpu_count * s.gpu_power_w) / 1000.0 for s in self.servers)
        return nameplate

    @property
    def rack_total_power_kw(self) -> float:
        """IT load plus rack-level distribution loss (PDU/busway, ~1%)."""
        return self.rack_it_load_kw * 1.01

    @property
    def thermal_load_kw(self) -> float:
        return self.rack_it_load_kw

    def rack_energy_kwh(self, hours: float) -> float:
        return self.rack_it_load_kw * hours


# ---------------------------------------------------------------------------
# POWER (sections 10-12)
# ---------------------------------------------------------------------------

@dataclass
class Transformer:
    transformer_id: str = field(default_factory=lambda: _new_id("xfmr"))
    capacity_mva: float = 20.0
    efficiency: float = 0.985


@dataclass
class UPS:
    ups_id: str = field(default_factory=lambda: _new_id("ups"))
    capacity_kva: float = 1000.0
    efficiency: float = 0.96
    power_factor: float = 0.95


@dataclass
class Generator:
    generator_id: str = field(default_factory=lambda: _new_id("gen"))
    capacity_mw: float = 2.5
    fuel_type: Literal["diesel", "natural_gas", "hydrogen"] = "diesel"
    fuel_consumption_l_per_kwh: float = 0.26
    efficiency: float = 0.40
    minimum_load_fraction: float = 0.30


@dataclass
class Battery:
    battery_id: str = field(default_factory=lambda: _new_id("batt"))
    capacity_mwh: float = 20.0
    power_mw: float = 10.0
    round_trip_efficiency: float = 0.92
    state_of_charge: float = 0.5  # 0..1


@dataclass
class PowerSystem:
    """Electrical infrastructure model (grid -> transformer -> switchgear ->
    UPS -> PDU -> rack), section 10-12."""

    grid_capacity_mw: float = 120.0
    redundancy: Literal["N", "N+1", "2N", "2N+1"] = "N+1"
    transformers: list[Transformer] = field(default_factory=list)
    ups_units: list[UPS] = field(default_factory=list)
    generators: list[Generator] = field(default_factory=list)
    batteries: list[Battery] = field(default_factory=list)
    solar_capacity_mw: float = 0.0

    @property
    def transformer_capacity_mva(self) -> float:
        return sum(t.capacity_mva for t in self.transformers)

    @property
    def ups_capacity_kva(self) -> float:
        return sum(u.capacity_kva for u in self.ups_units)

    @property
    def generator_capacity_mw(self) -> float:
        return sum(g.capacity_mw for g in self.generators)

    @property
    def battery_capacity_mwh(self) -> float:
        return sum(b.capacity_mwh for b in self.batteries)

    @property
    def battery_power_mw(self) -> float:
        return sum(b.power_mw for b in self.batteries)


# ---------------------------------------------------------------------------
# COOLING (sections 13-19)
# ---------------------------------------------------------------------------

@dataclass
class Chiller:
    chiller_id: str = field(default_factory=lambda: _new_id("chill"))
    capacity_kw: float = 3000.0
    cop: float = 5.5


@dataclass
class CoolingTower:
    tower_id: str = field(default_factory=lambda: _new_id("ctower"))
    capacity_kw: float = 3500.0
    approach_c: float = 4.0


@dataclass
class HeatPump:
    heat_pump_id: str = field(default_factory=lambda: _new_id("hp"))
    capacity_kw: float = 1000.0
    cop_heating: float = 3.5


@dataclass
class CoolingSystem:
    """Facility cooling / thermal infrastructure (sections 13-19)."""

    cooling_type: Literal[
        "air", "crac", "crah", "chilled_water", "direct_liquid", "rear_door_hx", "immersion", "hybrid"
    ] = "chilled_water"
    cooling_capacity_kw: float = 60_000.0
    chillers: list[Chiller] = field(default_factory=list)
    cooling_towers: list[CoolingTower] = field(default_factory=list)
    heat_pumps: list[HeatPump] = field(default_factory=list)

    ambient_temperature_c: float = 22.0
    ambient_wetbulb_c: float = 17.0
    water_temperature_c: float = 18.0

    chilled_water_supply_c: float = 7.0
    chilled_water_return_c: float = 14.0

    liquid_cooling_fraction: float = 0.0     # fraction of IT load served by DLC
    heat_recovery_enabled: bool = False
    free_cooling_enabled: bool = True

    @property
    def chiller_capacity_kw(self) -> float:
        return sum(c.capacity_kw for c in self.chillers)

    @property
    def type(self) -> str:
        """Alias for ``cooling_type`` (matches the ``dc.cooling.type = "liquid"``
        convenience form shown in the public API docs, section 41)."""
        return self.cooling_type

    @type.setter
    def type(self, value: str) -> None:
        self.cooling_type = value  # type: ignore[assignment]


@dataclass
class ComputeConfig:
    """Facility-level compute override (section 41 API convenience).

    When the building/floor/rack hierarchy has not been populated in detail,
    ``DataCenter`` uses these top-level figures directly (e.g.
    ``dc.compute.it_load_mw = 50``) instead of summing individual racks.
    If racks *are* present, the detailed model takes precedence and these
    fields are informational only.
    """

    it_load_mw: float | None = None
    rack_count: int | None = None
    server_count: int | None = None
    gpu_count: int = 0
    avg_rack_density_kw: float = 12.0
    high_density_fraction: float = 0.0
    high_density_kw: float = 80.0
    occupancy: int = 20


# ---------------------------------------------------------------------------
# NETWORK (section 23)
# ---------------------------------------------------------------------------

@dataclass
class Network:
    """Simplified data-center network topology model."""

    topology: Literal["3-tier", "spine-leaf", "fat-tree"] = "spine-leaf"
    internet_uplink_gbps: float = 400.0
    core_switch_count: int = 2
    core_switch_capacity_gbps: float = 12_800.0
    spine_switch_count: int = 8
    spine_switch_capacity_gbps: float = 25_600.0
    leaf_switch_count: int = 64
    leaf_switch_capacity_gbps: float = 12_800.0
    tor_uplink_gbps: float = 400.0
    server_nic_gbps: float = 200.0
    ai_fabric: bool = False  # if True, assumes high-bandwidth AI interconnect (InfiniBand/RoCE)


# ---------------------------------------------------------------------------
# ENERGY (sections 20-22)
# ---------------------------------------------------------------------------

@dataclass
class EnergySystem:
    """Energy market / renewables / storage configuration (sections 20-22)."""

    grid_price_per_kwh: float = 0.10
    time_of_use_enabled: bool = False
    peak_price_multiplier: float = 1.8
    peak_hours: tuple[int, int] = (14, 20)
    peak_demand_charge_per_kw: float = 12.0

    carbon_intensity_kg_per_kwh: float = 0.233

    solar_capacity_mw: float = 0.0
    solar_capacity_factor: float = 0.22
    wind_capacity_mw: float = 0.0
    wind_capacity_factor: float = 0.35

    battery_capacity_mwh: float = 0.0
    battery_power_mw: float = 0.0
    battery_round_trip_efficiency: float = 0.92


# ---------------------------------------------------------------------------
# ECONOMICS (sections 24-25)
# ---------------------------------------------------------------------------

@dataclass
class FinancialModel:
    """Revenue-side commercial assumptions (kept separate from engineering, section 25)."""

    gpu_rental_price_per_hour: float = 3.50
    server_rental_price_per_month: float = 800.0
    rack_rental_price_per_month: float = 4500.0
    power_price_per_kwh: float = 0.14
    utilisation: float = 0.80
    contract_duration_years: float = 5.0
