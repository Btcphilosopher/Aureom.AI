"""
The central :class:`DataCenter` object (section 41-42, 53).

This is the single composable data model that every design stage (SITE,
BUILDING, FLOOR PLAN, COMPUTE, POWER, COOLING, NETWORK, ENERGY, ECONOMICS,
OPTIMISE, SIMULATE, REPORT) reads from and writes to. Calling
:meth:`DataCenter.compute_results` walks every engineering engine and
returns a single, internally-consistent :class:`FacilityResults` snapshot —
every visual element and every optimisation result is traceable back to
this one call.
"""

from __future__ import annotations

import copy
import csv
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from compute.racks import facility_compute_totals
from config.constants import ASSUMPTIONS
from cooling.chiller import compute_cooling_plant
from cooling.cooling_tower import water_consumption_m3_per_hour
from cooling.heat_recovery import evaluate_heat_recovery
from cooling.liquid_cooling import evaluate_liquid_cooling
from cooling.thermal import compute_heat_balance, rack_thermal_profile
from core.models import (
    Battery,
    Building,
    ComputeConfig,
    CoolingSystem,
    EnergySystem,
    FinancialModel,
    Generator,
    Network,
    PowerSystem,
    Site,
    Transformer,
    UPS,
)
from core.validation import Alert, summarise, validate_design
from economics.capex import compute_capex
from economics.financials import compute_financial_summary
from economics.opex import compute_opex
from economics.revenue import compute_revenue_result
from network.bandwidth import evaluate_network
from power.electrical import evaluate_power_system


@dataclass
class FacilityResults:
    """A single, internally-consistent snapshot of every engineering and
    financial quantity computed from the current design (section 36 KPIs)."""

    # Compute
    it_load_mw: float = 0.0
    peak_it_load_mw: float = 0.0
    rack_count: int = 0
    server_count: int = 0
    gpu_count: int = 0

    # Power
    facility_load_mw: float = 0.0
    critical_load_mw: float = 0.0
    power_losses_kw: float = 0.0
    transformer_loading_pct: float = 0.0
    ups_loading_pct: float = 0.0
    generator_capacity_mw: float = 0.0
    generator_loading_pct: float = 0.0
    battery_backup_minutes: float = 0.0
    redundancy_satisfied: bool = True

    # Cooling / thermal
    total_heat_kw: float = 0.0
    cooling_electrical_kw: float = 0.0
    cooling_load_kw: float = 0.0
    free_cooling_active: bool = False
    cop: float = 0.0
    water_use_m3_per_hour: float = 0.0
    recovered_heat_kw: float = 0.0

    # Efficiency metrics
    pue: float = 1.0
    wue: float = 0.0
    cue: float = 0.0
    ere: float = 0.0

    # Network
    network_capacity_gbps: float = 0.0
    oversubscription_ratio: float = 0.0
    port_utilisation_pct: float = 0.0

    # Economics
    capex: float = 0.0
    capex_breakdown: dict[str, float] = field(default_factory=dict)
    annual_opex: float = 0.0
    opex_breakdown: dict[str, float] = field(default_factory=dict)
    annual_revenue: float = 0.0
    ebitda: float = 0.0
    npv: float = 0.0
    irr: float | None = None
    payback_years: float | None = None
    cost_per_mw: float = 0.0
    cost_per_rack: float = 0.0
    cost_per_kw: float = 0.0
    cost_per_gpu: float = 0.0

    # Carbon / environment
    annual_carbon_tonnes: float = 0.0

    # Validation
    alerts: list[Alert] = field(default_factory=list)
    alert_summary: dict[str, int] = field(default_factory=dict)

    def kpi_header(self) -> dict[str, str]:
        """Formatted KPI strings for the dashboard header (section 36)."""
        return {
            "IT LOAD": f"{self.it_load_mw:.1f} MW",
            "FACILITY LOAD": f"{self.facility_load_mw:.1f} MW",
            "PUE": f"{self.pue:.2f}",
            "WUE": f"{self.wue:.2f} L/kWh",
            "CUE": f"{self.cue:.3f} kgCO2/kWh",
            "CAPEX": f"${self.capex / 1e6:,.1f}M",
            "ANNUAL OPEX": f"${self.annual_opex / 1e6:,.1f}M",
            "REVENUE": f"${self.annual_revenue / 1e6:,.1f}M",
            "EBITDA": f"${self.ebitda / 1e6:,.1f}M",
            "COOLING LOAD": f"{self.cooling_load_kw / 1000:.1f} MW",
            "GRID LOAD": f"{self.facility_load_mw:.1f} MW",
            "CARBON": f"{self.annual_carbon_tonnes:,.0f} t/yr",
        }


class DataCenter:
    """The digital-twin root object. See module docstring."""

    def __init__(self, name: str = "Untitled Design") -> None:
        self.name = name
        self.site = Site()
        self.building = Building()
        self.compute = ComputeConfig()
        self.power = PowerSystem()
        self.cooling = CoolingSystem()
        self.network = Network()
        self.energy = EnergySystem()
        self.financial = FinancialModel()
        self.assumptions: dict[str, float] = copy.deepcopy(ASSUMPTIONS)
        self._last_results: FacilityResults | None = None

        # Sensible default power-system components so a fresh DataCenter()
        # is immediately simulate-able.
        self.power.transformers = [Transformer(capacity_mva=25.0) for _ in range(2)]
        self.power.ups_units = [UPS(capacity_kva=1500.0) for _ in range(3)]
        self.power.generators = [Generator(capacity_mw=2.5) for _ in range(4)]
        self.power.batteries = [Battery(capacity_mwh=10.0, power_mw=5.0) for _ in range(2)]
        self.cooling.chillers = []
        self.cooling.cooling_capacity_kw = 60_000.0

    # ------------------------------------------------------------------
    # Compute-load resolution
    # ------------------------------------------------------------------
    def _resolve_compute_totals(self) -> dict:
        detailed = facility_compute_totals(self.building)
        if detailed["rack_count"] > 0:
            gpu_count = sum(
                s.gpu_count for f in self.building.floors for r in f.racks for s in r.servers
            )
            detailed["gpu_count"] = gpu_count or self.compute.gpu_count
            return detailed

        # Fall back to the top-level ComputeConfig override (section 41 API).
        it_load_kw = (self.compute.it_load_mw or 0.0) * 1000.0
        rack_count = self.compute.rack_count or max(
            1, round(it_load_kw / max(self.compute.avg_rack_density_kw, 1e-6))
        )
        server_count = self.compute.server_count or rack_count * 20
        return {
            "total_it_load_kw": it_load_kw,
            "peak_it_load_kw": it_load_kw * 1.12,
            "average_it_load_kw": it_load_kw / rack_count if rack_count else 0.0,
            "rack_count": rack_count,
            "server_count": server_count,
            "gpu_count": self.compute.gpu_count,
            "daily_energy_kwh": it_load_kw * 24.0,
            "annual_energy_kwh": it_load_kw * 8760.0,
        }

    # ------------------------------------------------------------------
    # Main results pipeline
    # ------------------------------------------------------------------
    def compute_results(self) -> FacilityResults:
        """Resolve the full design into one consistent :class:`FacilityResults`.

        This is the single source of truth consumed by validation, the AI
        assistant, the visualisation layer, and the optimisation engine.
        """
        totals = self._resolve_compute_totals()
        it_load_kw = totals["total_it_load_kw"]

        # --- Power chain ---
        power_result = evaluate_power_system(self.power, it_load_kw, self.assumptions)

        # --- Thermal / heat balance ---
        heat_balance = compute_heat_balance(
            self.building, it_load_kw, power_result.power_losses_kw,
            self.compute.occupancy, self.assumptions,
        )
        total_heat_kw = heat_balance.total_heat_kw

        # --- Cooling plant ---
        liquid_fraction = self.cooling.liquid_cooling_fraction
        if self.cooling.cooling_type in ("direct_liquid", "immersion"):
            liquid_fraction = max(liquid_fraction, 0.8)
        elif self.cooling.cooling_type == "hybrid":
            liquid_fraction = max(liquid_fraction, 0.4)

        plant = compute_cooling_plant(
            cooling_load_kw=total_heat_kw,
            ambient_wetbulb_c=self.cooling.ambient_wetbulb_c,
            assumptions=self.assumptions,
            free_cooling_enabled=self.cooling.free_cooling_enabled,
        )

        liquid_result = evaluate_liquid_cooling(
            rack_heat_kw=total_heat_kw * liquid_fraction,
            coolant_supply_temp_c=self.cooling.water_temperature_c,
            coolant_return_temp_c=self.cooling.water_temperature_c + 10.0,
            heat_exchanger_efficiency=self.assumptions.get("heat_exchanger_efficiency", 0.85),
            capture_fraction=self.assumptions.get("liquid_cooling_capture_fraction", 0.85),
            pump_efficiency=self.assumptions.get("pump_efficiency", 0.80),
        )

        cooling_electrical_kw = plant.total_cooling_electrical_kw + liquid_result.pump_energy_kw

        heat_recovery = evaluate_heat_recovery(total_heat_kw, self.cooling.heat_recovery_enabled, self.assumptions)

        heat_rejected_kw = total_heat_kw + (0.0 if plant.free_cooling_active else plant.chiller_electrical_kw)
        water_m3_h = water_consumption_m3_per_hour(heat_rejected_kw)

        lighting_kw = heat_balance.lighting_heat_kw

        facility_load_kw = it_load_kw + power_result.power_losses_kw + cooling_electrical_kw + lighting_kw
        pue = facility_load_kw / it_load_kw if it_load_kw > 0 else 1.0
        wue = (water_m3_h * 1000.0) / it_load_kw if it_load_kw > 0 else 0.0
        carbon_intensity = self.assumptions.get("grid_carbon_intensity_kg_per_kwh", 0.233)
        cue = carbon_intensity * pue
        ere = pue - (heat_recovery.recovered_heat_kw / it_load_kw if it_load_kw > 0 else 0.0)

        # --- Network ---
        servers_per_rack = (totals["server_count"] / totals["rack_count"]) if totals["rack_count"] else 0.0
        net_result = evaluate_network(self.network, totals["rack_count"], servers_per_rack)

        # --- Economics ---
        annual_energy_kwh = facility_load_kw * 8760.0
        blended_price = self.energy.grid_price_per_kwh
        annual_electricity_cost = annual_energy_kwh * blended_price

        capex_breakdown = compute_capex(
            site_area_m2=self.site.area_m2,
            gross_floor_area_m2=self.building.gross_floor_area_m2,
            it_load_kw=it_load_kw,
            liquid_cooled_fraction=liquid_fraction,
            transformer_capacity_mva=self.power.transformer_capacity_mva,
            ups_capacity_kva=self.power.ups_capacity_kva,
            generator_capacity_mw=self.power.generator_capacity_mw,
            rack_count=totals["rack_count"],
            server_count=totals["server_count"],
            gpu_count=totals["gpu_count"],
            battery_capacity_mwh=self.power.battery_capacity_mwh,
            solar_capacity_mw=self.energy.solar_capacity_mw,
            assumptions=self.assumptions,
        )

        opex_breakdown = compute_opex(
            annual_electricity_cost=annual_electricity_cost,
            annual_water_m3=water_m3_h * 8760.0,
            annual_fuel_test_l=sum(g.capacity_mw for g in self.power.generators) * 200.0,
            capex_total=capex_breakdown.total,
            staff_count=max(8, totals["rack_count"] // 40),
            staff_avg_salary=95_000.0,
            rack_count=totals["rack_count"],
            assumptions=self.assumptions,
        )

        revenue_result = compute_revenue_result(
            financial=self.financial,
            gpu_count=totals["gpu_count"],
            server_count=totals["server_count"],
            rack_count=totals["rack_count"],
            it_load_kw=it_load_kw,
            annual_opex=opex_breakdown.total,
        )

        fin_summary = compute_financial_summary(
            capex=capex_breakdown.total,
            annual_opex=opex_breakdown.total,
            annual_revenue=revenue_result.annual_revenue,
            it_load_mw=it_load_kw / 1000.0,
            rack_count=totals["rack_count"],
            gpu_count=max(totals["gpu_count"], 1),
            discount_rate=self.assumptions.get("discount_rate", 0.08),
        )

        results = FacilityResults(
            it_load_mw=it_load_kw / 1000.0,
            peak_it_load_mw=totals["peak_it_load_kw"] / 1000.0,
            rack_count=totals["rack_count"],
            server_count=totals["server_count"],
            gpu_count=totals["gpu_count"],
            facility_load_mw=facility_load_kw / 1000.0,
            critical_load_mw=it_load_kw / 1000.0,
            power_losses_kw=power_result.power_losses_kw,
            transformer_loading_pct=power_result.transformer_loading_pct,
            ups_loading_pct=power_result.ups_loading_pct,
            generator_capacity_mw=power_result.generator_capacity_mw,
            generator_loading_pct=power_result.generator_loading_pct,
            battery_backup_minutes=power_result.battery_backup_minutes,
            redundancy_satisfied=power_result.redundancy_satisfied,
            total_heat_kw=total_heat_kw,
            cooling_electrical_kw=cooling_electrical_kw,
            cooling_load_kw=total_heat_kw,
            free_cooling_active=plant.free_cooling_active,
            cop=plant.cop,
            water_use_m3_per_hour=water_m3_h,
            recovered_heat_kw=heat_recovery.recovered_heat_kw,
            pue=pue,
            wue=wue,
            cue=cue,
            ere=ere,
            network_capacity_gbps=net_result.network_capacity_gbps,
            oversubscription_ratio=net_result.oversubscription_ratio,
            port_utilisation_pct=net_result.port_utilisation_pct,
            capex=capex_breakdown.total,
            capex_breakdown=capex_breakdown.as_dict(),
            annual_opex=opex_breakdown.total,
            opex_breakdown=opex_breakdown.as_dict(),
            annual_revenue=revenue_result.annual_revenue,
            ebitda=revenue_result.ebitda,
            npv=fin_summary.npv,
            irr=fin_summary.irr,
            payback_years=fin_summary.payback_years,
            cost_per_mw=fin_summary.cost_per_mw,
            cost_per_rack=fin_summary.cost_per_rack,
            cost_per_kw=fin_summary.cost_per_kw,
            cost_per_gpu=fin_summary.cost_per_gpu,
            annual_carbon_tonnes=(annual_energy_kwh * carbon_intensity) / 1000.0,
        )

        results.alerts = validate_design(self, results)
        results.alert_summary = summarise(results.alerts)
        self._last_results = results
        return results

    @property
    def results(self) -> FacilityResults:
        """Cached results (computed lazily on first access)."""
        return self._last_results or self.compute_results()

    def rack_thermal(self) -> list:
        return rack_thermal_profile(
            self.building,
            supply_air_temp_c=self.cooling.chilled_water_supply_c + 3.0,
            rack_delta_t_c=self.assumptions.get("rack_delta_t_c", 12.0),
            air_cooling_max_kw_per_rack=self.assumptions.get("air_cooling_max_kw_per_rack", 20.0),
            containment_efficiency=self.assumptions.get("containment_efficiency", 0.90),
        )

    # ------------------------------------------------------------------
    # High-level API (section 41)
    # ------------------------------------------------------------------
    def simulate(self, hours: int = 8760, mode: str | None = None):
        from simulation.facility_sim import run_facility_simulation
        return run_facility_simulation(self, hours=hours)

    def optimise(self, objectives: dict | None = None, method: str = "differential_evolution",
                 param_space: dict | None = None, **kwargs):
        from optimisation.optimiser import optimise_design
        return optimise_design(self, objectives=objectives, method=method, param_space=param_space, **kwargs)

    # British/US spelling convenience
    optimize = optimise

    def compare(self, *others: "DataCenter") -> "list[dict]":
        from optimisation.scenarios import compare_designs
        return compare_designs([self, *others])

    def clone(self, name: str | None = None) -> "DataCenter":
        clone = copy.deepcopy(self)
        clone.name = name or f"{self.name} (copy)"
        clone._last_results = None
        return clone

    def export(self, path: str | Path, fmt: str | None = None) -> Path:
        path = Path(path)
        fmt = fmt or path.suffix.lstrip(".").lower()
        results = self.compute_results()
        payload = self.to_dict(results)

        if fmt == "json":
            path.write_text(json.dumps(payload, indent=2, default=str))
        elif fmt == "csv":
            with path.open("w", newline="") as fh:
                writer = csv.writer(fh)
                writer.writerow(["metric", "value"])
                for k, v in payload["results"].items():
                    if isinstance(v, (dict, list)):
                        continue
                    writer.writerow([k, v])
        elif fmt in ("xlsx", "xls"):
            from data.report_export import export_to_excel
            export_to_excel(self, results, path)
        elif fmt == "pdf":
            from data.report_export import export_to_pdf
            export_to_pdf(self, results, path)
        else:
            raise ValueError(f"Unsupported export format: {fmt}")
        return path

    def to_dict(self, results: FacilityResults | None = None) -> dict[str, Any]:
        results = results or self.compute_results()
        return {
            "name": self.name,
            "site": asdict(self.site),
            "building": {
                "width_m": self.building.width_m, "length_m": self.building.length_m,
                "floor_count": self.building.floor_count,
                "floor_to_floor_height_m": self.building.floor_to_floor_height_m,
                "gross_floor_area_m2": self.building.gross_floor_area_m2,
                "net_floor_area_m2": self.building.net_floor_area_m2,
                "total_rack_count": self.building.total_rack_count,
            },
            "compute": asdict(self.compute),
            "power": {k: v for k, v in asdict(self.power).items()},
            "cooling": asdict(self.cooling),
            "network": asdict(self.network),
            "energy": asdict(self.energy),
            "financial": asdict(self.financial),
            "assumptions": self.assumptions,
            "results": asdict(results),
        }

    def __repr__(self) -> str:
        r = self.results
        return (f"<DataCenter '{self.name}' it_load={r.it_load_mw:.1f}MW "
                f"pue={r.pue:.2f} capex=${r.capex/1e6:.0f}M>")
