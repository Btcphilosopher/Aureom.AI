"""
Centralised unit system for DATACENTER.STUDIO (section 43).

Every conversion factor used anywhere in the platform must live here. Do not
scatter magic numbers such as ``* 1000`` or ``/ 3600`` throughout engineering
modules — import and call the named functions instead.

Supported unit families: power, energy, temperature, length, area, volume,
volumetric flow, pressure, electrical.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Power: W <-> kW <-> MW
# ---------------------------------------------------------------------------

def w_to_kw(value_w: float) -> float:
    return value_w / 1_000.0


def kw_to_w(value_kw: float) -> float:
    return value_kw * 1_000.0


def kw_to_mw(value_kw: float) -> float:
    return value_kw / 1_000.0


def mw_to_kw(value_mw: float) -> float:
    return value_mw * 1_000.0


def w_to_mw(value_w: float) -> float:
    return value_w / 1_000_000.0


def mw_to_w(value_mw: float) -> float:
    return value_mw * 1_000_000.0


# ---------------------------------------------------------------------------
# Energy: Wh <-> kWh <-> MWh, and power*time -> energy
# ---------------------------------------------------------------------------

def kwh_to_mwh(value_kwh: float) -> float:
    return value_kwh / 1_000.0


def mwh_to_kwh(value_mwh: float) -> float:
    return value_mwh * 1_000.0


def kw_to_kwh(value_kw: float, hours: float) -> float:
    """Energy (kWh) delivered by a constant power (kW) over ``hours``."""
    return value_kw * hours


def kwh_to_kw(value_kwh: float, hours: float) -> float:
    """Average power (kW) implied by an energy quantity (kWh) over ``hours``."""
    if hours <= 0:
        return 0.0
    return value_kwh / hours


# ---------------------------------------------------------------------------
# Temperature: Celsius <-> Kelvin <-> Fahrenheit
# ---------------------------------------------------------------------------

def c_to_k(value_c: float) -> float:
    return value_c + 273.15


def k_to_c(value_k: float) -> float:
    return value_k - 273.15


def c_to_f(value_c: float) -> float:
    return value_c * 9.0 / 5.0 + 32.0


def f_to_c(value_f: float) -> float:
    return (value_f - 32.0) * 5.0 / 9.0


# ---------------------------------------------------------------------------
# Length / area / volume
# ---------------------------------------------------------------------------

def m_to_ft(value_m: float) -> float:
    return value_m * 3.28084


def ft_to_m(value_ft: float) -> float:
    return value_ft / 3.28084


def m2_to_ft2(value_m2: float) -> float:
    return value_m2 * 10.7639


def ft2_to_m2(value_ft2: float) -> float:
    return value_ft2 / 10.7639


def m3_to_l(value_m3: float) -> float:
    return value_m3 * 1000.0


def l_to_m3(value_l: float) -> float:
    return value_l / 1000.0


# ---------------------------------------------------------------------------
# Volumetric flow: m3/s <-> L/s <-> CFM
# ---------------------------------------------------------------------------

def m3s_to_ls(value_m3s: float) -> float:
    return value_m3s * 1000.0


def ls_to_m3s(value_ls: float) -> float:
    return value_ls / 1000.0


def m3s_to_cfm(value_m3s: float) -> float:
    return value_m3s * 2118.88


def cfm_to_m3s(value_cfm: float) -> float:
    return value_cfm / 2118.88


# ---------------------------------------------------------------------------
# Pressure: Pa <-> bar <-> psi
# ---------------------------------------------------------------------------

def pa_to_bar(value_pa: float) -> float:
    return value_pa / 100_000.0


def bar_to_pa(value_bar: float) -> float:
    return value_bar * 100_000.0


def pa_to_psi(value_pa: float) -> float:
    return value_pa / 6894.76


# ---------------------------------------------------------------------------
# Electrical: V, A, kVA, MVA, power factor
# ---------------------------------------------------------------------------

def kva_to_kw(value_kva: float, power_factor: float = 0.95) -> float:
    return value_kva * power_factor


def kw_to_kva(value_kw: float, power_factor: float = 0.95) -> float:
    if power_factor <= 0:
        raise ValueError("power_factor must be > 0")
    return value_kw / power_factor


def mva_to_kva(value_mva: float) -> float:
    return value_mva * 1000.0


def kva_to_mva(value_kva: float) -> float:
    return value_kva / 1000.0


def three_phase_kw(voltage_v: float, current_a: float, power_factor: float = 0.95) -> float:
    """3-phase real power (kW) from line voltage (V) and current (A)."""
    import math

    return math.sqrt(3) * voltage_v * current_a * power_factor / 1000.0


# ---------------------------------------------------------------------------
# Generic dimensionless helpers
# ---------------------------------------------------------------------------

def percent(value: float, total: float) -> float:
    """Return value/total as a percentage, safe against divide-by-zero."""
    if total == 0:
        return 0.0
    return 100.0 * value / total


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def calculate_pue(total_facility_power: float, it_equipment_power: float) -> float:
    """PUE = Total Facility Energy / IT Equipment Energy (section 19).

    Works equally for power (kW) or energy (kWh) as long as both arguments
    share the same unit.
    """
    if it_equipment_power <= 0:
        raise ValueError("it_equipment_power must be > 0")
    return total_facility_power / it_equipment_power
