"""
Thin re-export shim: the full time-series simulation engine lives in the
top-level :mod:`simulation` package (``simulation/facility_sim.py`` etc.) so
it can depend on ``core``, ``power``, ``cooling`` and ``energy`` without a
circular import. This module exists so ``core.simulation`` remains a valid,
documented import path per the package architecture (section 2).
"""

from __future__ import annotations

from simulation.facility_sim import SimulationResult, run_facility_simulation

__all__ = ["SimulationResult", "run_facility_simulation"]
