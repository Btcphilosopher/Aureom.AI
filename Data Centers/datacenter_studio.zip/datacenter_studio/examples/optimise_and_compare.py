"""
Example: scenarios, optimisation, and design comparison (sections 27-28, 39).

Run with:  python examples/optimise_and_compare.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from datacenter_studio import DataCenter  # noqa: E402  (this also makes flat imports below work)
from optimisation.scenarios import run_scenarios  # noqa: E402


def main() -> None:
    dc = DataCenter(name="Baseline — 20MW Facility")
    dc.compute.it_load_mw = 20.0
    dc.cooling.cooling_capacity_kw = 26_000.0
    dc.power.redundancy = "N+1"

    print("=== Preset scenario comparison (section 28) ===")
    df = run_scenarios(dc, ["base_case", "hot_summer", "renewable_expansion", "liquid_cooling", "min_capex"])
    print(df.to_string(index=False))

    print()
    print("=== Multi-objective optimisation (section 27) ===")
    objectives = {"capex": 0.20, "opex": 0.20, "pue": 0.25, "carbon": 0.15, "revenue": 0.20}
    result = dc.optimise(objectives=objectives, method="genetic", generations=15, population_size=12)
    print("Best parameters found:")
    for k, v in result.best_params.items():
        print(f"  {k}: {v:.2f}")
    print(f"Resulting PUE:    {result.best_results.pue:.3f}")
    print(f"Resulting CAPEX:  ${result.best_results.capex/1e6:,.1f}M")

    print()
    print("=== Design comparison (section 39) ===")
    baseline_result = dc.compute_results()
    optimised = result.best_design
    rows = dc.compare(optimised)
    for row in rows:
        print(row)


if __name__ == "__main__":
    main()
