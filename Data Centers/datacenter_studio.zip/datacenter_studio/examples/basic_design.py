"""
Example: the minimal public API (section 41).

Run with:  python examples/basic_design.py
"""

import sys
from pathlib import Path

# Make the *parent* of this package importable so `import datacenter_studio`
# works when running this script directly from a source checkout.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from datacenter_studio import DataCenter  # noqa: E402  (after sys.path fix-up)
from core.models import Battery, Generator, Transformer, UPS  # noqa: E402


def main() -> None:
    dc = DataCenter(name="Example — 50MW AI Campus")
    dc.site.width_m = 300
    dc.site.length_m = 500
    dc.compute.it_load_mw = 50
    dc.cooling.type = "liquid"          # alias for dc.cooling.cooling_type
    dc.cooling.cooling_capacity_kw = 65_000.0
    dc.power.redundancy = "N+1"
    # Size the electrical chain for 50 MW IT load (N+1): the default
    # DataCenter() power system is a small starter fleet.
    dc.power.transformers = [Transformer(capacity_mva=30.0) for _ in range(3)]
    dc.power.ups_units = [UPS(capacity_kva=6000.0) for _ in range(11)]
    dc.power.generators = [Generator(capacity_mw=6.0) for _ in range(11)]
    dc.power.batteries = [Battery(capacity_mwh=15.0, power_mw=8.0) for _ in range(4)]
    dc.energy.solar_capacity_mw = 20
    dc.energy.battery_capacity_mwh = 60

    results = dc.compute_results()
    print(f"IT load:        {results.it_load_mw:.1f} MW")
    print(f"Facility load:  {results.facility_load_mw:.1f} MW")
    print(f"PUE:            {results.pue:.3f}")
    print(f"CAPEX:          ${results.capex/1e6:,.1f}M")
    print(f"Annual OPEX:    ${results.annual_opex/1e6:,.1f}M")
    print(f"Annual revenue: ${results.annual_revenue/1e6:,.1f}M")
    print()

    print("Running an 8760-hour simulation (this takes a few seconds)...")
    sim = dc.simulate(hours=8760)
    print(f"Simulated annual energy: {sim.annual_energy_kwh/1e6:,.1f} GWh")
    print(f"Simulated average PUE:   {sim.pue:.3f}")
    print(f"Renewable fraction:      {sim.renewable_fraction*100:.1f}%")
    print()

    print("Validation alerts:")
    for alert in results.alerts:
        print(f"  [{alert.severity}] {alert.code}: {alert.message}")

    print()
    print("Running a quick optimisation (differential evolution, ~25 iterations)...")
    opt = dc.optimise(method="differential_evolution", maxiter=10, popsize=8)
    print(f"Best PUE found: {opt.best_results.pue:.3f} with params {opt.best_params}")

    dc.export("/tmp/example_design.json")
    print("Exported design to /tmp/example_design.json")


if __name__ == "__main__":
    main()
