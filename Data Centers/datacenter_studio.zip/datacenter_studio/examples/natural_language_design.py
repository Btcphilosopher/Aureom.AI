"""
Example: AI design generation and iteration from natural language
(sections 47-48).

Run with:  python examples/natural_language_design.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import datacenter_studio  # noqa: E402  (triggers the flat-import path fix-up)
from ai.design_assistant import DesignAssistant  # noqa: E402


def main() -> None:
    assistant = DesignAssistant()

    brief = ("Design a 20 MW AI data center with 200 kW liquid-cooled racks, "
             "N+1 power redundancy, 30% solar generation and battery storage.")
    print(f"BRIEF: {brief}\n")

    dc, spec, explanation = assistant.generate_from_text(brief)
    print("Parsed specification:", spec)
    print()
    print("Explanation:", explanation)
    print()

    for command in ["Reduce PUE.", "Increase resilience.", "Prepare this for a hotter climate."]:
        print(f"--- Iteration command: '{command}' ---")
        proposal = assistant.propose_iteration(dc, command)
        print("Proposal:", proposal.description)
        print("Changes:", proposal.changes or proposal.objective_weights)
        if proposal.objective_weights and not proposal.changes:
            print("(This command reweights the optimiser rather than editing a parameter "
                  "directly; run_optimisation=False below skips the actual search for speed, "
                  "so PUE is unchanged here. Pass run_optimisation=True to actually re-optimise.)")
        results_before = dc.compute_results()
        new_results, opt_result = assistant.apply_iteration(dc, proposal, run_optimisation=False)
        print(f"PUE before: {results_before.pue:.3f} -> after: {new_results.pue:.3f}")
        print()


if __name__ == "__main__":
    main()
