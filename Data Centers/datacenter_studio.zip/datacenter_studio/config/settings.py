"""
Application-level settings for DATACENTER.STUDIO.

Kept deliberately small: engineering assumptions live in ``constants.py``;
this module governs runtime/application behaviour (UI, logging, performance).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field


@dataclass
class Settings:
    """Global application settings."""

    app_name: str = "DATACENTER.STUDIO"
    tagline: str = "AI Data Center Design, Simulation & Optimisation Platform"
    disclaimer: str = (
        "Conceptual engineering simulation — not a substitute for detailed "
        "engineering design."
    )

    # Simulation performance
    default_timestep_hours: float = 1.0
    max_racks: int = 5000
    max_servers: int = 50000
    random_seed: int = 42

    # UI
    theme: str = "dark"
    currency_symbol: str = "$"

    # Logging
    log_level: int = logging.INFO
    log_format: str = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"

    cache_enabled: bool = True


SETTINGS = Settings()


def configure_logging(level: int | None = None) -> None:
    """Configure root logging for the application (idempotent)."""
    logging.basicConfig(
        level=level or SETTINGS.log_level,
        format=SETTINGS.log_format,
    )


LOGGER = logging.getLogger("datacenter_studio")
