"""Configuration package: engineering assumptions and application settings."""
