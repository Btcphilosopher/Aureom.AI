"""
Engineering assumptions and physical constants used throughout DATACENTER.STUDIO.

DISCLAIMER: These are representative, order-of-magnitude engineering
assumptions for a *conceptual* design/simulation tool. They are exposed here,
centrally, so that every simplified model in the platform is transparent and
user-adjustable rather than buried in code. This is not a substitute for
detailed engineering design.

All values are editable at runtime via ``core.datacenter.DataCenter.assumptions``,
which is initialised as a deep copy of :data:`ASSUMPTIONS`.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------------------
WATER_SPECIFIC_HEAT_KJ_PER_KGK = 4.186   # kJ/(kg*K)
AIR_SPECIFIC_HEAT_KJ_PER_KGK = 1.005     # kJ/(kg*K)
AIR_DENSITY_KG_M3 = 1.2                  # kg/m3 at ~20C sea level
WATER_DENSITY_KG_M3 = 997.0              # kg/m3
STANDARD_GRAVITY = 9.80665               # m/s2

# ---------------------------------------------------------------------------
# Central, user-editable engineering assumption set (section 44)
# ---------------------------------------------------------------------------
ASSUMPTIONS: dict[str, float] = {
    # --- Electrical chain efficiencies ---
    "transformer_efficiency": 0.985,
    "mv_switchgear_loss_fraction": 0.002,
    "lv_switchgear_loss_fraction": 0.003,
    "ups_efficiency": 0.96,
    "pdu_efficiency": 0.99,
    "busway_loss_fraction": 0.01,
    "cabling_loss_fraction": 0.01,
    "generator_efficiency": 0.40,          # fuel -> electrical
    # --- Cooling ---
    "fan_efficiency": 0.70,
    "pump_efficiency": 0.80,
    "chiller_base_cop": 5.5,               # COP at AHRI nominal conditions
    "free_cooling_threshold_c": 12.0,      # ambient wet-bulb below which free cooling engages
    "crah_delta_t_c": 10.0,                # supply/return air delta-T design point
    "rack_delta_t_c": 12.0,                # typical rack inlet->outlet delta-T
    "containment_efficiency": 0.90,        # hot/cold aisle containment effectiveness
    "air_cooling_max_kw_per_rack": 20.0,   # practical air-cooling ceiling
    "liquid_cooling_capture_fraction": 0.85,  # fraction of rack heat captured by DLC loop
    "heat_exchanger_efficiency": 0.85,
    "cooling_tower_approach_c": 4.0,
    "immersion_capture_fraction": 0.97,
    # --- Heat recovery ---
    "heat_recovery_efficiency": 0.65,
    "heat_recovery_max_fraction": 0.50,    # max fraction of waste heat recoverable
    # --- Non-IT facility loads (fractions of gross floor area or IT load) ---
    "lighting_w_per_m2": 8.0,
    "people_heat_w_per_person": 120.0,
    "office_density_m2_per_person": 12.0,
    # --- Redundancy / reliability ---
    "n_plus_1_margin": 1.0,                # extra unit count for N+1
    "generator_minimum_load_fraction": 0.30,
    # --- Financial ---
    "discount_rate": 0.08,
    "corporate_tax_rate": 0.25,
    "depreciation_years": 15,
    "contingency_fraction": 0.10,
    "engineering_fraction": 0.06,
    "insurance_fraction_of_capex": 0.0035,
    "maintenance_fraction_of_capex": 0.02,
    # --- Environmental ---
    "grid_carbon_intensity_kg_per_kwh": 0.233,   # kgCO2e/kWh (representative grid mix)
    "diesel_carbon_intensity_kg_per_l": 2.68,
    "water_cost_per_m3": 2.5,
}

# ---------------------------------------------------------------------------
# Alert severities
# ---------------------------------------------------------------------------
SEVERITY_INFO = "INFO"
SEVERITY_WARNING = "WARNING"
SEVERITY_CRITICAL = "CRITICAL"

# ---------------------------------------------------------------------------
# Redundancy configurations
# ---------------------------------------------------------------------------
REDUNDANCY_LEVELS = ("N", "N+1", "2N", "2N+1")

# ---------------------------------------------------------------------------
# Cooling technology types
# ---------------------------------------------------------------------------
COOLING_TYPES = (
    "air",
    "crac",
    "crah",
    "chilled_water",
    "direct_liquid",
    "rear_door_hx",
    "immersion",
    "hybrid",
)

# ---------------------------------------------------------------------------
# Floor-plan layout templates
# ---------------------------------------------------------------------------
LAYOUT_TEMPLATES = (
    "hot_aisle_cold_aisle",
    "perimeter_cooling",
    "central_plant",
    "high_density_gpu",
    "hybrid",
    "custom",
)

# ---------------------------------------------------------------------------
# Server / rack archetypes
# ---------------------------------------------------------------------------
SERVER_FORM_FACTORS = ("1U", "2U", "4U", "blade", "storage", "network")
WORKLOAD_TYPES = ("cpu", "gpu", "ai_training", "ai_inference", "storage", "network", "mixed")
