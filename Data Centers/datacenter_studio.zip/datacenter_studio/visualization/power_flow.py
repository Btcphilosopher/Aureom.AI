"""
Animated-style power-flow diagram (section 11, 33):
GRID -> SUBSTATION -> TRANSFORMER -> UPS -> PDU -> RACK -> SERVER.

Node colour flags overloaded components; edge width encodes flow intensity.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

from visualization import THEME, apply_theme

if TYPE_CHECKING:
    from core.datacenter import DataCenter


def render_power_flow(dc: "DataCenter") -> go.Figure:
    results = dc.compute_results()
    # Stage-by-stage loss breakdown lives on ElectricalResult; recompute it directly.
    from power.electrical import evaluate_power_system
    it_load_kw = results.it_load_mw * 1000.0
    electrical = evaluate_power_system(dc.power, it_load_kw, dc.assumptions)
    stages = electrical.stage_breakdown

    order = ["Grid Cabling", "MV Switchgear / Substation", "Transformer", "LV Switchgear", "UPS", "Busway", "PDU"]
    labels = ["GRID", "SUBSTATION", "TRANSFORMER", "LV SWITCHGEAR", "UPS", "BUSWAY", "PDU", "RACK", "SERVER"]

    max_kw = max((stages.get(o, {}).get("input_kw", 1.0) for o in order), default=1.0)

    loading_flags = {
        "TRANSFORMER": results.transformer_loading_pct,
        "UPS": results.ups_loading_pct,
    }

    n = len(labels)
    xs = list(range(n))
    y = 0

    fig = go.Figure()
    for i in range(n - 1):
        stage_key = order[i] if i < len(order) else None
        flow_kw = stages.get(stage_key, {}).get("output_kw", it_load_kw) if stage_key else it_load_kw
        width = 2 + 10 * (flow_kw / max_kw)
        fig.add_trace(go.Scatter(
            x=[xs[i] + 0.4, xs[i + 1] - 0.4], y=[y, y], mode="lines",
            line=dict(color=THEME["accent"], width=width),
            hoverinfo="skip", showlegend=False,
        ))

    for i, label in enumerate(labels):
        loading = loading_flags.get(label)
        color = THEME["panel"]
        border = THEME["accent"]
        if loading is not None:
            if loading > 100:
                border, color = THEME["critical"], "#3a1414"
            elif loading > 85:
                border, color = THEME["warn"], "#3a2f14"
        fig.add_shape(type="rect", x0=xs[i] - 0.4, x1=xs[i] + 0.4, y0=y - 0.3, y1=y + 0.3,
                      line=dict(color=border, width=2), fillcolor=color)
        subtitle = f"{loading:.0f}%" if loading is not None else ""
        fig.add_annotation(x=xs[i], y=y, text=f"<b>{label}</b><br>{subtitle}", showarrow=False,
                            font=dict(color=THEME["text"], size=10))

    fig.update_layout(
        xaxis=dict(visible=False, range=[-0.7, n - 0.3]),
        yaxis=dict(visible=False, range=[-1, 1]),
        showlegend=False,
    )
    return apply_theme(fig, height=220, title="Power Flow: Grid → Substation → Transformer → UPS → PDU → Rack → Server")


def render_cooling_flow(dc: "DataCenter") -> go.Figure:
    """COOLING PLANT -> CHILLED WATER -> CRAH -> COLD AISLE -> RACK -> HOT AISLE -> RETURN -> HEAT REJECTION (section 34)."""
    results = dc.compute_results()
    labels = ["COOLING PLANT", "CHILLED WATER", "CRAH", "COLD AISLE", "RACK", "HOT AISLE", "RETURN", "HEAT REJECTION"]
    n = len(labels)
    xs = list(range(n))
    y = 0
    intensity = min(1.0, results.cooling_load_kw / max(dc.cooling.cooling_capacity_kw, 1.0))
    width = 3 + 9 * intensity

    fig = go.Figure()
    for i in range(n - 1):
        fig.add_trace(go.Scatter(
            x=[xs[i] + 0.4, xs[i + 1] - 0.4], y=[y, y], mode="lines",
            line=dict(color=THEME["accent2"], width=width), hoverinfo="skip", showlegend=False,
        ))
    for i, label in enumerate(labels):
        fig.add_shape(type="rect", x0=xs[i] - 0.4, x1=xs[i] + 0.4, y0=y - 0.3, y1=y + 0.3,
                      line=dict(color=THEME["accent2"], width=2), fillcolor=THEME["panel"])
        fig.add_annotation(x=xs[i], y=y, text=f"<b>{label}</b>", showarrow=False,
                            font=dict(color=THEME["text"], size=9))

    fig.update_layout(xaxis=dict(visible=False, range=[-0.7, n - 0.3]), yaxis=dict(visible=False, range=[-1, 1]))
    return apply_theme(fig, height=200,
                        title=f"Cooling Flow — {results.cooling_load_kw/1000:.1f} MW ({intensity*100:.0f}% of plant capacity)")
