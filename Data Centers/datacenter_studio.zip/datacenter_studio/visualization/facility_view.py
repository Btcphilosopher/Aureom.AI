"""
Facility-level visualisation (sections 31, 53): SITE -> BUILDING(S) ->
FLOOR(S), plus utility zones (substation, generators, cooling plant,
battery, solar). A clean 2D/axonometric-style engineering plan rather than a
full 3D renderer, per the section-31 guidance.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

from geometry.site import build_site_zones
from visualization import THEME, apply_theme

if TYPE_CHECKING:
    from core.datacenter import DataCenter

ZONE_COLORS = {
    "building": "#233b52",
    "substation": "#4a3b1f",
    "generator": "#3d2a2a",
    "cooling_plant": "#1f3d3d",
    "water_storage": "#1f2f4d",
    "battery": "#2f1f4d",
    "solar": "#2f4d1f",
    "parking": "#1a1e28",
}


def render_site_view(dc: "DataCenter") -> go.Figure:
    zones = build_site_zones(dc.site)
    fig = go.Figure()

    fig.add_shape(type="rect", x0=0, y0=0, x1=dc.site.width_m, y1=dc.site.length_m,
                  line=dict(color=THEME["grid"], width=1, dash="dot"), fillcolor=THEME["bg"])

    for zone in zones:
        r = zone.rect
        fig.add_shape(type="rect", x0=r.x, y0=r.y, x1=r.x2, y1=r.y2,
                      line=dict(color=THEME["accent"], width=1.4),
                      fillcolor=ZONE_COLORS.get(zone.kind, THEME["panel"]))
        cx, cy = r.center
        fig.add_annotation(x=cx, y=cy, text=f"<b>{zone.name.upper()}</b>", showarrow=False,
                            font=dict(color=THEME["text"], size=10))

    fig.update_layout(
        xaxis=dict(range=[-10, dc.site.width_m + 10], scaleanchor="y", showgrid=False),
        yaxis=dict(range=[-10, dc.site.length_m + 10], showgrid=False),
        showlegend=False,
    )
    return apply_theme(fig, height=560, title=f"{dc.name} — Site Plan ({dc.site.area_m2/10_000:.1f} ha)")


def render_facility_hierarchy(dc: "DataCenter") -> go.Figure:
    """Simple hierarchy tree: SITE -> BUILDING -> FLOOR -> ZONE/RACKS (section 53)."""
    labels = ["SITE"]
    parents = [""]
    values = [dc.site.area_m2]

    labels.append(dc.building.name if hasattr(dc.building, "name") else "BUILDING")
    parents.append("SITE")
    values.append(dc.building.gross_floor_area_m2)

    building_label = labels[-1]
    for floor in dc.building.floors:
        flabel = f"FLOOR {floor.index}"
        labels.append(flabel)
        parents.append(building_label)
        values.append(max(floor.area_m2, 1.0))

        rlabel = f"RACKS (F{floor.index})"
        labels.append(rlabel)
        parents.append(flabel)
        values.append(max(floor.it_load_kw, 1.0))

    fig = go.Figure(go.Treemap(
        labels=labels, parents=parents, values=values,
        marker=dict(colorscale="Blues", line=dict(color=THEME["bg"], width=2)),
        textfont=dict(color="white"),
    ))
    return apply_theme(fig, height=420, title="Facility Digital-Twin Hierarchy")
