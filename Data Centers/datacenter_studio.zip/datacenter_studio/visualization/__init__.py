"""
Visualisation package: Plotly-based facility view, floor plan, thermal
heatmap, power-flow diagram and analytical charts (sections 31-36, 49-50).

A shared dark "engineering workspace" theme (section 54) lives here so every
figure in the platform looks consistent.
"""

from __future__ import annotations

THEME = {
    "bg": "#0b0e14",
    "panel": "#11151f",
    "grid": "#232838",
    "text": "#c9d1d9",
    "muted": "#6b7280",
    "accent": "#3fb1ce",
    "accent2": "#f2a541",
    "ok": "#2ecc71",
    "warn": "#f2c744",
    "critical": "#e74c3c",
    "font": "IBM Plex Mono, Roboto Mono, monospace",
}

HEATMAP_COLORSCALE = [
    [0.0, "#2166ac"],   # blue - cool
    [0.35, "#4dab8f"],  # green - normal
    [0.6, "#f2c744"],   # yellow - warm
    [0.8, "#f2841f"],   # orange - hot
    [1.0, "#e74c3c"],   # red - critical
]


def apply_theme(fig, height: int | None = None, title: str | None = None):
    fig.update_layout(
        paper_bgcolor=THEME["bg"],
        plot_bgcolor=THEME["panel"],
        font=dict(color=THEME["text"], family=THEME["font"], size=11),
        margin=dict(l=30, r=20, t=40 if title else 20, b=30),
        title=title,
        legend=dict(bgcolor="rgba(0,0,0,0)"),
    )
    fig.update_xaxes(gridcolor=THEME["grid"], zerolinecolor=THEME["grid"])
    fig.update_yaxes(gridcolor=THEME["grid"], zerolinecolor=THEME["grid"])
    if height:
        fig.update_layout(height=height)
    return fig
