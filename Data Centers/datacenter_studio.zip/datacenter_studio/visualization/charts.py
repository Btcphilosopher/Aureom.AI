"""
Analytical charts (sections 35-36, 49-52): CAPEX/OPEX breakdowns, simulation
timelines, scenario comparisons, Pareto frontier, tornado / Monte Carlo.
"""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from visualization import THEME, apply_theme


def breakdown_bar(breakdown: dict[str, float], title: str) -> go.Figure:
    items = sorted(breakdown.items(), key=lambda kv: kv[1], reverse=True)
    labels = [k for k, _ in items]
    values = [v for _, v in items]
    fig = go.Figure(go.Bar(x=values, y=labels, orientation="h", marker_color=THEME["accent"]))
    return apply_theme(fig, height=380, title=title)


def timeline_chart(df: pd.DataFrame, columns: list[str], title: str, y_title: str = "") -> go.Figure:
    fig = go.Figure()
    palette = [THEME["accent"], THEME["accent2"], THEME["ok"], THEME["warn"], THEME["critical"], "#9b7fd4"]
    for i, col in enumerate(columns):
        fig.add_trace(go.Scatter(x=df["timestamp"], y=df[col], mode="lines", name=col,
                                  line=dict(color=palette[i % len(palette)], width=1.6)))
    fig.update_layout(yaxis_title=y_title)
    return apply_theme(fig, height=340, title=title)


def kpi_gauge(value: float, title: str, target: float | None = None, value_range: tuple[float, float] = (1.0, 2.5)) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value,
        number={"font": {"color": THEME["text"]}},
        gauge=dict(
            axis=dict(range=list(value_range), tickcolor=THEME["text"]),
            bar=dict(color=THEME["accent"]),
            bgcolor=THEME["panel"],
            steps=[
                dict(range=[value_range[0], (value_range[0] + value_range[1]) / 2], color="#123"),
                dict(range=[(value_range[0] + value_range[1]) / 2, value_range[1]], color="#221"),
            ],
            threshold=dict(line=dict(color=THEME["critical"], width=3), value=target) if target else None,
        ),
        title={"text": title, "font": {"color": THEME["text"], "size": 12}},
    ))
    return apply_theme(fig, height=200)


def scenario_comparison_chart(df: pd.DataFrame, metric: str) -> go.Figure:
    fig = go.Figure(go.Bar(x=df["scenario"], y=df[metric], marker_color=THEME["accent2"]))
    return apply_theme(fig, height=360, title=f"Scenario Comparison — {metric}")


def pareto_scatter(df: pd.DataFrame, x: str, y: str, frontier_idx: list[int], labels: list[str] | None = None) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df[x], y=df[y], mode="markers", name="candidates",
        marker=dict(size=8, color=THEME["muted"]),
        text=labels, hovertemplate="%{text}<extra></extra>" if labels else None,
    ))
    frontier = df.iloc[frontier_idx].sort_values(x)
    fig.add_trace(go.Scatter(
        x=frontier[x], y=frontier[y], mode="lines+markers", name="Pareto frontier",
        line=dict(color=THEME["accent"], width=2), marker=dict(size=10, color=THEME["accent"]),
    ))
    fig.update_layout(xaxis_title=x, yaxis_title=y)
    return apply_theme(fig, height=460, title=f"Design Space Explorer — {x} vs {y}")


def tornado_chart(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    base = df["base"].iloc[0] if len(df) else 0
    fig.add_trace(go.Bar(
        y=df["factor"], x=df["high"] - base, base=base, orientation="h",
        marker_color=THEME["critical"], name="high",
    ))
    fig.add_trace(go.Bar(
        y=df["factor"], x=df["low"] - base, base=base, orientation="h",
        marker_color=THEME["accent"], name="low",
    ))
    fig.update_layout(barmode="overlay")
    return apply_theme(fig, height=320, title="Sensitivity — Tornado Chart")


def monte_carlo_histogram(samples: pd.Series, title: str, percentiles: dict[str, float] | None = None) -> go.Figure:
    fig = go.Figure(go.Histogram(x=samples, marker_color=THEME["accent"], nbinsx=40))
    if percentiles:
        for label, val in percentiles.items():
            fig.add_vline(x=val, line_dash="dash", line_color=THEME["accent2"],
                          annotation_text=label, annotation_font_color=THEME["text"])
    return apply_theme(fig, height=320, title=title)


def rack_density_histogram_chart(hist: dict[str, int]) -> go.Figure:
    fig = go.Figure(go.Bar(x=list(hist.keys()), y=list(hist.values()), marker_color=THEME["accent"]))
    return apply_theme(fig, height=280, title="Rack Density Distribution")
