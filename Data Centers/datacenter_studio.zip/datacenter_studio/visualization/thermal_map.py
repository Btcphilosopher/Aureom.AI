"""
2D thermal heatmap (section 14): interpolates per-rack outlet temperature
onto a continuous grid so hot spots are visually obvious, BLUE -> RED.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import plotly.graph_objects as go
from scipy.interpolate import griddata

from visualization import HEATMAP_COLORSCALE, apply_theme

if TYPE_CHECKING:
    from core.datacenter import DataCenter
    from core.models import Floor


def render_thermal_heatmap(dc: "DataCenter", floor: "Floor", resolution: int = 80) -> go.Figure:
    thermal = {t.rack_id: t for t in dc.rack_thermal()}
    points = np.array([[r.x + r.width_m / 2, r.y + r.depth_m / 2] for r in floor.racks])
    temps = np.array([thermal[r.rack_id].outlet_temperature_c if r.rack_id in thermal else 22.0
                       for r in floor.racks])

    fig = go.Figure()
    if len(points) < 4:
        apply_theme(fig, height=520, title="Thermal Heatmap (insufficient racks)")
        return fig

    # Interpolate over the occupied rack footprint (+ a small margin) rather
    # than the full floor plate: a sparse layout on a large floor would
    # otherwise spend most of the heatmap on extrapolated colour far from
    # any rack, which reads as a misleading gradient rather than real data.
    margin = 6.0
    x_lo, x_hi = max(0.0, points[:, 0].min() - margin), min(floor.width_m, points[:, 0].max() + margin)
    y_lo, y_hi = max(0.0, points[:, 1].min() - margin), min(floor.length_m, points[:, 1].max() + margin)
    grid_x, grid_y = np.meshgrid(
        np.linspace(x_lo, x_hi, resolution),
        np.linspace(y_lo, y_hi, resolution),
    )
    try:
        grid_z = griddata(points, temps, (grid_x, grid_y), method="linear")
        # Fill NaNs (outside convex hull) with nearest-neighbour so the map has no holes.
        nan_mask = np.isnan(grid_z)
        if nan_mask.any():
            nearest = griddata(points, temps, (grid_x, grid_y), method="nearest")
            grid_z[nan_mask] = nearest[nan_mask]
    except Exception:
        # Degenerate point sets (e.g. every rack on a single row/column, so
        # the Delaunay triangulation Qhull needs is not full-dimensional)
        # fall back to nearest-neighbour interpolation, which has no such
        # dimensionality requirement.
        grid_z = griddata(points, temps, (grid_x, grid_y), method="nearest")

    fig.add_trace(go.Heatmap(
        x=grid_x[0], y=grid_y[:, 0], z=grid_z,
        colorscale=HEATMAP_COLORSCALE,
        zmin=16, zmax=34,
        colorbar=dict(title="°C"),
        hovertemplate="x=%{x:.0f}m y=%{y:.0f}m %{z:.1f}°C<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=points[:, 0], y=points[:, 1], mode="markers",
        marker=dict(size=5, color="rgba(255,255,255,0.55)", line=dict(color="black", width=0.5)),
        hoverinfo="skip", name="racks",
    ))
    fig.update_layout(
        xaxis=dict(range=[x_lo, x_hi], scaleanchor="y", showgrid=False),
        yaxis=dict(range=[y_lo, y_hi], showgrid=False),
        showlegend=False,
    )
    return apply_theme(fig, height=560, title=f"Thermal Heatmap — Floor {floor.index}")
