"""
Interactive floor-plan visualisation (sections 7, 31-32).

Renders racks as rectangles on a 2D plan, coloured by a selectable data
layer (POWER DENSITY, THERMAL LOAD, AIR TEMPERATURE, RACK UTILISATION, ...).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

from visualization import HEATMAP_COLORSCALE, THEME, apply_theme

if TYPE_CHECKING:
    from core.datacenter import DataCenter
    from core.models import Floor

LAYERS = ("POWER DENSITY", "THERMAL LOAD", "AIR TEMPERATURE", "RACK UTILISATION", "COOLING TYPE")


def render_floorplan(dc: "DataCenter", floor: "Floor", layer: str = "POWER DENSITY") -> go.Figure:
    fig = go.Figure()
    fig.add_shape(type="rect", x0=0, y0=0, x1=floor.width_m, y1=floor.length_m,
                   line=dict(color=THEME["grid"], width=1), fillcolor=THEME["panel"])

    thermal_by_id = {}
    if layer in ("THERMAL LOAD", "AIR TEMPERATURE"):
        thermal_by_id = {t.rack_id: t for t in dc.rack_thermal()}

    values, texts, colors = [], [], []
    for rack in floor.racks:
        if layer == "POWER DENSITY":
            val = rack.rack_it_load_kw
            text = f"{rack.rack_id}<br>{val:.0f} kW"
        elif layer == "THERMAL LOAD":
            val = thermal_by_id.get(rack.rack_id).thermal_load_kw if rack.rack_id in thermal_by_id else rack.rack_it_load_kw
            text = f"{rack.rack_id}<br>{val:.0f} kW heat"
        elif layer == "AIR TEMPERATURE":
            val = thermal_by_id.get(rack.rack_id).outlet_temperature_c if rack.rack_id in thermal_by_id else 22.0
            text = f"{rack.rack_id}<br>{val:.1f}C outlet"
        elif layer == "RACK UTILISATION":
            val = 100.0 * rack.rack_it_load_kw / max(rack.rack_peak_power_kw, 1e-6)
            text = f"{rack.rack_id}<br>{val:.0f}% util"
        else:  # COOLING TYPE
            val = {"air": 0, "hybrid": 0.5, "rear_door_hx": 0.6, "chilled_water": 0.4,
                   "direct_liquid": 0.85, "immersion": 1.0, "crac": 0.2, "crah": 0.3}.get(rack.cooling_type, 0.0)
            text = f"{rack.rack_id}<br>{rack.cooling_type}"
        values.append(val)
        texts.append(text)

    lo, hi = (min(values), max(values)) if values else (0, 1)
    fig.add_trace(go.Scatter(
        x=[r.x + r.width_m / 2 for r in floor.racks],
        y=[r.y + r.depth_m / 2 for r in floor.racks],
        mode="markers",
        marker=dict(
            symbol="square",
            size=14,
            color=values,
            colorscale=HEATMAP_COLORSCALE,
            cmin=lo, cmax=hi if hi > lo else lo + 1,
            colorbar=dict(title=layer, tickfont=dict(color=THEME["text"])),
            line=dict(color=THEME["grid"], width=1),
        ),
        text=texts,
        hovertemplate="%{text}<extra></extra>",
        name="racks",
    ))

    fig.update_layout(
        xaxis=dict(range=[-2, floor.width_m + 2], scaleanchor="y", constrain="domain", showgrid=False),
        yaxis=dict(range=[-2, floor.length_m + 2], showgrid=False),
        showlegend=False,
    )
    return apply_theme(fig, height=560, title=f"Floor {floor.index} — {floor.layout_template.replace('_', ' ').title()} — {layer}")
