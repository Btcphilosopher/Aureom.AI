"""UPS model (section 11): losses, loading, battery runtime."""

from __future__ import annotations

from core.models import Battery, PowerSystem


def ups_losses_kw(load_kw: float, efficiency: float) -> float:
    if efficiency <= 0:
        raise ValueError("efficiency must be > 0")
    input_kw = load_kw / efficiency
    return input_kw - load_kw


def ups_loading_pct(power_system: PowerSystem, load_kw: float, power_factor: float = 0.95) -> float:
    capacity_kw = power_system.ups_capacity_kva * power_factor
    if capacity_kw <= 0:
        return 0.0
    return 100.0 * load_kw / capacity_kw


def battery_backup_minutes(batteries: list[Battery], load_mw: float) -> float:
    """Runtime the UPS battery plant can sustain a given IT+support load."""
    if load_mw <= 0:
        return float("inf")
    usable_mwh = sum(b.capacity_mwh * b.round_trip_efficiency ** 0.5 for b in batteries)
    return 60.0 * usable_mwh / load_mw


def required_ups_capacity_kva(load_kw: float, redundancy: str, power_factor: float = 0.95,
                               margin: float = 1.10) -> float:
    load_kva = (load_kw * margin) / power_factor
    multiplier = {"N": 1.0, "N+1": 1.0, "2N": 2.0, "2N+1": 2.0}.get(redundancy, 1.0)
    return load_kva * multiplier
