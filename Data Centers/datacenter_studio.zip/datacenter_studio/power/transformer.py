"""Transformer sizing and loss calculations (section 10-11)."""

from __future__ import annotations

from core.models import PowerSystem
from core.units import kw_to_kva


def transformer_losses_kw(load_kw: float, efficiency: float) -> float:
    if efficiency <= 0:
        raise ValueError("efficiency must be > 0")
    input_kw = load_kw / efficiency
    return input_kw - load_kw


def transformer_loading_pct(power_system: PowerSystem, load_kw: float, power_factor: float = 0.95) -> float:
    capacity_kva = power_system.transformer_capacity_mva * 1000.0
    if capacity_kva <= 0:
        return 0.0
    load_kva = kw_to_kva(load_kw, power_factor)
    return 100.0 * load_kva / capacity_kva


def required_transformer_capacity_mva(load_kw: float, redundancy: str, power_factor: float = 0.95,
                                       margin: float = 1.15) -> float:
    """Recommend a total transformer capacity (MVA) for a given critical load
    and redundancy configuration."""
    load_kva = kw_to_kva(load_kw, power_factor) * margin
    multiplier = {"N": 1.0, "N+1": 1.0, "2N": 2.0, "2N+1": 2.0}.get(redundancy, 1.0)
    return (load_kva * multiplier) / 1000.0
