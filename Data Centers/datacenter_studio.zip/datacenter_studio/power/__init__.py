"""Power package: electrical distribution chain, UPS, transformer, generator, battery."""
