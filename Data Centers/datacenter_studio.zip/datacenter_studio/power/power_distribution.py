"""
Power distribution / redundancy engine (section 10).

Models the full chain GRID -> TRANSFORMER -> MV SWITCHGEAR -> LV SWITCHGEAR
-> UPS -> PDU -> BUSWAY -> RACK -> SERVER, and evaluates whether the
configured component counts satisfy the selected redundancy level.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from core.models import PowerSystem


@dataclass
class PowerFlowStage:
    name: str
    input_kw: float
    output_kw: float

    @property
    def losses_kw(self) -> float:
        return self.input_kw - self.output_kw

    @property
    def efficiency(self) -> float:
        return self.output_kw / self.input_kw if self.input_kw else 1.0


@dataclass
class PowerChainResult:
    it_load_kw: float
    stages: list[PowerFlowStage] = field(default_factory=list)

    @property
    def total_losses_kw(self) -> float:
        return sum(s.losses_kw for s in self.stages)

    @property
    def facility_input_kw(self) -> float:
        """Power drawn from the grid to deliver ``it_load_kw`` to the racks."""
        return self.it_load_kw + self.total_losses_kw


def compute_power_chain(it_load_kw: float, assumptions: dict) -> PowerChainResult:
    """Walk the electrical chain *backwards* from IT load to grid draw,
    stage by stage, recording losses at each stage (section 10-11)."""
    result = PowerChainResult(it_load_kw=it_load_kw)

    # PDU/busway (closest to rack)
    pdu_eff = assumptions.get("pdu_efficiency", 0.99)
    busway_loss = assumptions.get("busway_loss_fraction", 0.01)
    pdu_output = it_load_kw
    pdu_input = pdu_output / pdu_eff
    result.stages.append(PowerFlowStage("PDU", pdu_input, pdu_output))

    busway_output = pdu_input
    busway_input = busway_output / (1.0 - busway_loss)
    result.stages.append(PowerFlowStage("Busway", busway_input, busway_output))

    # UPS
    ups_eff = assumptions.get("ups_efficiency", 0.96)
    ups_output = busway_input
    ups_input = ups_output / ups_eff
    result.stages.append(PowerFlowStage("UPS", ups_input, ups_output))

    # LV switchgear
    lv_loss = assumptions.get("lv_switchgear_loss_fraction", 0.003)
    lv_output = ups_input
    lv_input = lv_output / (1.0 - lv_loss)
    result.stages.append(PowerFlowStage("LV Switchgear", lv_input, lv_output))

    # Transformer
    xfmr_eff = assumptions.get("transformer_efficiency", 0.985)
    xfmr_output = lv_input
    xfmr_input = xfmr_output / xfmr_eff
    result.stages.append(PowerFlowStage("Transformer", xfmr_input, xfmr_output))

    # MV switchgear / substation
    mv_loss = assumptions.get("mv_switchgear_loss_fraction", 0.002)
    mv_output = xfmr_input
    mv_input = mv_output / (1.0 - mv_loss)
    result.stages.append(PowerFlowStage("MV Switchgear / Substation", mv_input, mv_output))

    # Cabling
    cabling_loss = assumptions.get("cabling_loss_fraction", 0.01)
    grid_output = mv_input
    grid_input = grid_output / (1.0 - cabling_loss)
    result.stages.append(PowerFlowStage("Grid Cabling", grid_input, grid_output))

    # Reverse so stages read Grid -> ... -> Server
    result.stages.reverse()
    return result


def redundancy_unit_requirement(redundancy: str) -> tuple[int, str]:
    """Return (minimum_extra_units, description) for a redundancy level."""
    return {
        "N": (0, "No redundancy: a single unit failure causes an outage."),
        "N+1": (1, "One spare unit above the load-serving requirement."),
        "2N": (1, "Fully mirrored second system (effectively 2x capacity)."),
        "2N+1": (1, "Fully mirrored second system plus one spare unit."),
    }.get(redundancy, (0, "Unknown redundancy level."))


def check_redundancy(power_system: PowerSystem, critical_load_kw: float, power_factor: float = 0.95) -> bool:
    """Very simplified redundancy check: after removing the largest single
    unit (N-1 contingency, or half the fleet for 2N/2N+1), does remaining
    UPS+generator capacity still cover the critical load?"""
    ups_units = power_system.ups_units
    gens = power_system.generators
    if not ups_units or not gens:
        return False

    if power_system.redundancy in ("2N", "2N+1"):
        ups_available = sum(u.capacity_kva for u in ups_units) * power_factor / 2.0
        gen_available_mw = sum(g.capacity_mw for g in gens) / 2.0
    else:
        largest_ups = max(u.capacity_kva for u in ups_units)
        ups_available = (sum(u.capacity_kva for u in ups_units) - largest_ups) * power_factor
        largest_gen = max(g.capacity_mw for g in gens)
        gen_available_mw = sum(g.capacity_mw for g in gens) - largest_gen

    ups_ok = ups_available >= critical_load_kw
    gen_ok = gen_available_mw * 1000.0 >= critical_load_kw
    return ups_ok and gen_ok
