"""
Top-level electrical engine (sections 10-12): combines the power chain,
transformer/UPS loading, generator backup, and redundancy check into one
result object consumed by :mod:`core.datacenter`.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.models import PowerSystem
from power.generator import backup_runtime_hours, fuel_consumption_l_per_hour, generator_loading_pct
from power.power_distribution import check_redundancy, compute_power_chain
from power.transformer import transformer_loading_pct
from power.ups import battery_backup_minutes, ups_loading_pct


@dataclass
class ElectricalResult:
    it_load_kw: float
    facility_power_kw: float          # grid draw to serve IT (excludes cooling)
    power_losses_kw: float
    transformer_loading_pct: float
    ups_loading_pct: float
    generator_loading_pct: float
    generator_capacity_mw: float
    battery_backup_minutes: float
    redundancy_satisfied: bool
    stage_breakdown: dict


def evaluate_power_system(power_system: PowerSystem, it_load_kw: float, assumptions: dict) -> ElectricalResult:
    chain = compute_power_chain(it_load_kw, assumptions)
    critical_load_kw = it_load_kw  # simplification: all IT load is critical (UPS-protected)

    return ElectricalResult(
        it_load_kw=it_load_kw,
        facility_power_kw=chain.facility_input_kw,
        power_losses_kw=chain.total_losses_kw,
        transformer_loading_pct=transformer_loading_pct(power_system, it_load_kw),
        ups_loading_pct=ups_loading_pct(power_system, it_load_kw),
        generator_loading_pct=generator_loading_pct(power_system.generators, it_load_kw / 1000.0),
        generator_capacity_mw=power_system.generator_capacity_mw,
        battery_backup_minutes=battery_backup_minutes(power_system.batteries, it_load_kw / 1000.0),
        redundancy_satisfied=check_redundancy(power_system, critical_load_kw),
        stage_breakdown={s.name: {"input_kw": s.input_kw, "output_kw": s.output_kw, "losses_kw": s.losses_kw}
                          for s in chain.stages},
    )
