"""
Battery Energy Storage System (BESS) model (section 22).

Provides a simple, stateful dispatch step used both for UPS backup-time
sizing and for the hourly energy-system simulation (peak shaving / renewable
arbitrage / backup). Kept dependency-free of the wider simulation package so
it can be unit tested in isolation.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BatteryState:
    capacity_mwh: float
    power_mw: float
    round_trip_efficiency: float
    soc: float = 0.5  # 0..1

    @property
    def energy_mwh(self) -> float:
        return self.soc * self.capacity_mwh


@dataclass
class DispatchResult:
    charge_mw: float   # positive = charging (consuming power)
    discharge_mw: float  # positive = discharging (supplying power)
    soc_after: float
    grid_import_mw: float


def dispatch_step(
    state: BatteryState,
    net_load_mw: float,
    renewable_surplus_mw: float,
    dt_hours: float = 1.0,
    strategy: str = "peak_shaving",
    peak_threshold_mw: float | None = None,
) -> DispatchResult:
    """Advance the battery one timestep and update ``state.soc`` in place.

    net_load_mw: facility load not yet met by renewables/grid.
    renewable_surplus_mw: excess renewable generation available to charge with (>=0).
    strategy: "peak_shaving" discharges above ``peak_threshold_mw``; charges from
        renewable surplus whenever available and headroom exists.
    """
    one_way_eff = state.round_trip_efficiency ** 0.5
    charge_mw = 0.0
    discharge_mw = 0.0

    # 1) Opportunistic charge from renewable surplus
    if renewable_surplus_mw > 0:
        headroom_mwh = (1.0 - state.soc) * state.capacity_mwh
        max_charge_mw = min(state.power_mw, headroom_mwh / (dt_hours * one_way_eff) if dt_hours > 0 else 0.0)
        charge_mw = max(0.0, min(renewable_surplus_mw, max_charge_mw))
        state.soc += (charge_mw * dt_hours * one_way_eff) / state.capacity_mwh if state.capacity_mwh else 0.0
        net_load_mw = max(0.0, net_load_mw)  # surplus already offsets load upstream

    # 2) Discharge for peak shaving
    threshold = peak_threshold_mw if peak_threshold_mw is not None else state.power_mw * 10  # effectively disabled
    if strategy == "peak_shaving" and net_load_mw > threshold:
        available_mwh = state.soc * state.capacity_mwh
        max_discharge_mw = min(state.power_mw, (available_mwh * one_way_eff) / dt_hours if dt_hours > 0 else 0.0)
        discharge_mw = max(0.0, min(net_load_mw - threshold, max_discharge_mw))
        state.soc -= (discharge_mw * dt_hours / one_way_eff) / state.capacity_mwh if state.capacity_mwh else 0.0

    state.soc = max(0.0, min(1.0, state.soc))
    grid_import_mw = max(0.0, net_load_mw - discharge_mw)
    return DispatchResult(charge_mw=charge_mw, discharge_mw=discharge_mw, soc_after=state.soc,
                           grid_import_mw=grid_import_mw)


def backup_time_minutes(capacity_mwh: float, load_mw: float, usable_fraction: float = 0.9) -> float:
    if load_mw <= 0:
        return float("inf")
    return 60.0 * capacity_mwh * usable_fraction / load_mw
