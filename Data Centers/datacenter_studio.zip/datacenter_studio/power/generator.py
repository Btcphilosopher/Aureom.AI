"""Generator / backup power model (section 12)."""

from __future__ import annotations

from core.models import Generator


def total_generator_capacity_mw(generators: list[Generator]) -> float:
    return sum(g.capacity_mw for g in generators)


def generator_loading_pct(generators: list[Generator], load_mw: float) -> float:
    cap = total_generator_capacity_mw(generators)
    if cap <= 0:
        return 0.0
    return 100.0 * load_mw / cap


def fuel_consumption_l_per_hour(generators: list[Generator], load_mw: float) -> float:
    """Distribute load proportionally across generators and sum fuel burn."""
    cap = total_generator_capacity_mw(generators)
    if cap <= 0 or load_mw <= 0:
        return 0.0
    total = 0.0
    for g in generators:
        share_mw = load_mw * (g.capacity_mw / cap)
        share_mw = max(share_mw, g.capacity_mw * g.minimum_load_fraction) if share_mw > 0 else 0.0
        share_kw = share_mw * 1000.0
        total += share_kw * g.fuel_consumption_l_per_kwh
    return total


def backup_runtime_hours(generators: list[Generator], load_mw: float, fuel_reserve_l: float) -> float:
    burn_rate = fuel_consumption_l_per_hour(generators, load_mw)
    if burn_rate <= 0:
        return float("inf")
    return fuel_reserve_l / burn_rate


def required_generator_capacity_mw(critical_load_mw: float, redundancy: str, margin: float = 1.10) -> float:
    multiplier = {"N": 1.0, "N+1": 1.0, "2N": 2.0, "2N+1": 2.0}.get(redundancy, 1.0)
    return critical_load_mw * margin * multiplier
