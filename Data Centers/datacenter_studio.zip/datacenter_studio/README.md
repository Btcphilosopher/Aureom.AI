# DATACENTER.STUDIO

**AI Data Center Design, Simulation & Optimisation Platform**

> Conceptual engineering simulation — not a substitute for detailed
> engineering design.

DATACENTER.STUDIO is a computational design studio for data centers. It is
not a dashboard bolted onto a spreadsheet — it is a parametric digital-twin
prototype: a single, typed data model spanning SITE → BUILDING → FLOORS →
RACKS → COMPUTE → POWER → COOLING → NETWORK → ENERGY → COST →
OPTIMISATION, where changing one engineering parameter propagates through
every downstream calculation, every chart, and every optimisation result.

```
Design the data center. Simulate the data center. Optimise the data center.
```

---

## 1. What the software does

- Lets you build a facility parametrically: site geometry, building
  massing, a generated (or hand-placed) rack floor plan, compute/GPU mix,
  full electrical chain, cooling plant, network fabric, energy system and
  financial model.
- Computes a single, internally-consistent set of engineering results
  (PUE/WUE/CUE/ERE, power-chain losses, thermal load and hot spots, CAPEX/
  OPEX/revenue/NPV/IRR/payback) every time the model changes.
- Runs a vectorised hourly time-series simulation (24h / 7-day / 30-day /
  8760h) of load, weather, renewables, battery dispatch, cost and carbon.
- Searches for better designs with an interchangeable multi-objective
  optimisation engine (grid / random / differential evolution / genetic),
  Monte Carlo uncertainty analysis, scenario comparison and a Pareto
  frontier explorer.
- Ships a rule-based AI design assistant that reads the live model and
  proposes recommendations (with WHY / EXPECTED IMPACT / RISK) and can turn
  a natural-language brief or iteration command ("Reduce PUE.") into a
  structured proposal — nothing is ever applied silently.
- Visualises everything in a dark, high-tech "engineering workspace"
  aesthetic: a site/facility plan, an interactive floor plan with
  switchable data layers, a 2D thermal heatmap, and animated power-flow /
  cooling-flow diagrams.
- Validates the design continuously against an engineering rules engine
  (INFO / WARNING / CRITICAL) — an invalid design is never presented as
  valid.

## 2. Architecture

```
datacenter_studio/
├── app.py                 Streamlit entry point (UI plumbing only)
├── config/                Engineering assumptions + app settings
├── core/                  DataCenter root object, typed data model, units, validation
├── geometry/              Site / building / floor-plan / rack layout
├── compute/               Servers, CPU/GPU catalogs, workloads, rack/facility roll-ups
├── power/                 Electrical chain, UPS, transformer, generator, battery
├── cooling/                Thermal engine, HVAC/airflow, chiller, cooling tower,
│                          liquid cooling, heat recovery
├── network/               Topology (NetworkX), bandwidth/oversubscription
├── energy/                Electricity pricing, renewables, storage dispatch, emissions
├── economics/             CAPEX, OPEX, revenue, NPV/IRR/payback
├── optimisation/          BaseOptimizer + 4 strategies, objectives, constraints,
│                          scenarios, sensitivity/Monte Carlo
├── simulation/            Vectorised hourly timestep / thermal / power / facility engine
├── visualization/         Plotly: site view, floor plan, thermal heatmap, power/cooling
│                          flow diagrams, analytical charts
├── ai/                    Rule-based recommendations + NL design generation/iteration
├── ui/                    Streamlit dashboard, guided workflow, controls, panels
├── data/                  Equipment catalog, workload library, demo facility, report export
├── tests/                 pytest suite (known-value + integration tests)
├── examples/              Runnable scripts against the public API
└── docs/                  Technical documentation per subsystem
```

Engineering logic is fully independent of the UI: every calculation is
reachable through the plain Python API in `core/datacenter.py` without
importing Streamlit or Plotly.

## 3. Installation

Requires Python 3.13+ (3.10+ will generally also work).

```bash
cd datacenter_studio
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 4. Running the application

```bash
streamlit run app.py
```

The app opens on a **Dashboard** view (KPI header, facility plan,
ENERGY/THERMAL/POWER/FINANCE/OPTIMISATION tabs) pre-loaded with the demo
50 MW AI data center. Switch to **Design Studio** for the guided 12-stage
workflow (01 SITE → 12 REPORT), each with the LEFT parameters / CENTER
visualisation / RIGHT live-results layout. The sidebar also offers one-click
loading of demo Scenarios A–F, design save/duplicate/compare, and the AI
design assistant (generate-from-text and iteration commands).

Run the test suite:

```bash
pytest
```

Run the example scripts (no Streamlit required):

```bash
python examples/basic_design.py
python examples/optimise_and_compare.py
python examples/natural_language_design.py
```

## 5. Engineering models

Deep-dive documentation lives in `docs/`:

- [`docs/power_model.md`](docs/power_model.md) — electrical chain, losses, redundancy, UPS/battery/generator.
- [`docs/thermal_model.md`](docs/thermal_model.md) — heat balance, per-rack thermal profile, heatmap, cooling plant, liquid cooling, heat recovery.
- [`docs/energy_model.md`](docs/energy_model.md) — PUE/WUE/CUE/ERE definitions, hourly simulation engine, renewables/storage, Monte Carlo.
- [`docs/financial_model.md`](docs/financial_model.md) — CAPEX/OPEX/revenue, NPV/IRR/payback, TCO.
- [`docs/optimisation_engine.md`](docs/optimisation_engine.md) — optimiser abstraction, objective function, constraints, scenarios, Pareto, sensitivity.
- [`docs/ai_assistant.md`](docs/ai_assistant.md) — recommendation rules, natural-language design generation and iteration.

Every simplified engineering assumption is centralised and user-editable in
`config/constants.py::ASSUMPTIONS` (transformer/UPS/fan/pump efficiencies,
chiller COP, containment efficiency, discount rate, carbon intensity, ...).
Nothing is hidden inside a formula.

## 6. Data model

Every physical/logical object is a typed `dataclass`
(`core/models.py`): `Site → Building → Floor → Rack → Server`,
`GPUCluster`, `PowerSystem → Transformer/UPS/Generator/Battery`,
`CoolingSystem → Chiller/CoolingTower/HeatPump`, `Network`, `EnergySystem`,
`FinancialModel`. They compose into one root object, `DataCenter`
(`core/datacenter.py`), whose `compute_results()` is the single source of
truth every visual element, KPI, validation alert and optimisation score is
traceable back to.

## 7. Public API

```python
from datacenter_studio import DataCenter

dc = DataCenter()
dc.site.width_m = 300
dc.site.length_m = 500
dc.compute.it_load_mw = 50
dc.cooling.type = "liquid"          # alias for dc.cooling.cooling_type

result = dc.simulate(hours=8760)
print(result.pue)
print(result.annual_energy_kwh)
print(result.capex)

opt = dc.optimise(objectives={"capex": 0.2, "opex": 0.2, "pue": 0.25, "carbon": 0.15, "revenue": 0.2})
rows = dc.compare(opt.best_design)
dc.export("design.json")   # .json / .csv / .xlsx / .pdf
```

See `examples/` for complete, runnable walkthroughs, including natural
language design generation and scenario/optimisation comparison.

## 8. Optimisation

`BaseOptimizer` is a small abstraction with four interchangeable
implementations — `GridOptimizer`, `RandomSearchOptimizer`,
`DifferentialEvolutionOptimizer` (SciPy), `EvolutionaryOptimizer` (a
compact, dependency-free genetic algorithm). The method is never
hard-coded: `dc.optimise(method="genetic" | "differential_evolution" |
"random" | "grid", ...)`. See `docs/optimisation_engine.md`.

## 9. Simulation

`dc.simulate(hours=...)` runs a fully vectorised (NumPy) hourly engine —
IT load, ambient temperature, cooling electrical draw, renewables, and
battery dispatch — returning both a `pandas.DataFrame` of hourly results
and horizon-scaled scalar summaries. See `docs/energy_model.md`.

## 10. Demo content

- **DEMO — 50 MW AI Data Center** (`data/default_profiles.py::build_demo_datacenter`):
  230 racks (85% high-density GPU/direct-liquid), 18,000 GPUs, N+1 power,
  grid + 25 MW solar + 100 MWh battery, heat recovery, high-bandwidth AI
  network fabric. Loads automatically on first run.
- **Scenarios A–F** (`build_demo_scenarios`): conventional air-cooled,
  high-density liquid AI, renewable-heavy, minimum-CAPEX, minimum-PUE,
  maximum-profit — one click apart in the sidebar, or via
  `optimisation.scenarios.run_scenarios()` for a tabular comparison.

## 11. Limitations

This is a **conceptual** engineering simulation for design exploration,
education, and rapid what-if analysis:

- The thermal engine is a lumped, empirical approximation — not CFD.
- Unit costs, efficiencies and COP curves are representative defaults, not
  vendor quotes or certified performance data.
- The natural-language parser is a deterministic regex/keyword matcher, not
  an LLM — it recognises a fixed vocabulary of design briefs and iteration
  commands.
- Network, structural and life-safety design are out of scope.

It must not be used as the sole basis for construction, procurement or
safety decisions.

## 12. Future development

- Bayesian optimisation (surrogate-model-based) as a fifth `BaseOptimizer`.
- True 3D facility rendering (the current visualisation is a clean 2D /
  axonometric-style engineering plan by design, per the brief).
- Multi-building / multi-region campus modelling.
- Pluggable equipment catalogs sourced from real vendor datasheets.
- Persistent project storage (the current version holds designs in-memory
  per session; use `DataCenter.export()` / your own persistence layer to
  save between sessions).
