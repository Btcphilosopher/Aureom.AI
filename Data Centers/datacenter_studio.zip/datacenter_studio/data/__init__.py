"""Data package: equipment catalog, workload library, demo/default profiles, report export."""
