"""
Workload library: named, ready-to-apply workload mixes for the floor-plan
generator and demo facilities (distinct from ``compute/workloads.py``, which
holds the per-workload power/thermal *model*).
"""

from __future__ import annotations

WORKLOAD_LIBRARY = {
    "ai_training_cluster": {
        "description": "Dense GPU training pods, liquid cooled, high east-west bandwidth.",
        "avg_density_kw": 90.0,
        "high_density_fraction": 0.85,
        "high_density_kw": 120.0,
        "cooling_type": "direct_liquid",
        "ai_fabric": True,
    },
    "ai_inference_fleet": {
        "description": "Mixed GPU/CPU inference serving, moderate density.",
        "avg_density_kw": 35.0,
        "high_density_fraction": 0.4,
        "high_density_kw": 60.0,
        "cooling_type": "hybrid",
        "ai_fabric": True,
    },
    "enterprise_mixed": {
        "description": "General enterprise compute/storage/network mix.",
        "avg_density_kw": 8.0,
        "high_density_fraction": 0.05,
        "high_density_kw": 20.0,
        "cooling_type": "air",
        "ai_fabric": False,
    },
    "cloud_hosting": {
        "description": "Cloud/web-hosting workload, moderate homogeneous density.",
        "avg_density_kw": 12.0,
        "high_density_fraction": 0.1,
        "high_density_kw": 25.0,
        "cooling_type": "air",
        "ai_fabric": False,
    },
    "hpc_research": {
        "description": "HPC / scientific computing, high density, liquid assisted.",
        "avg_density_kw": 45.0,
        "high_density_fraction": 0.5,
        "high_density_kw": 70.0,
        "cooling_type": "rear_door_hx",
        "ai_fabric": False,
    },
}
