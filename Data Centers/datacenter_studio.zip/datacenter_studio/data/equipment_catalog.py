"""
Equipment catalog (section 57 support data): standard, off-the-shelf-style
component sizes used to populate designs quickly and to snap user input to
realistic increments in the UI.
"""

from __future__ import annotations

from compute.cpu import CPU_CATALOG
from compute.gpu import GPU_CATALOG

STANDARD_TRANSFORMERS_MVA = [2.5, 5.0, 7.5, 10.0, 15.0, 20.0, 25.0, 30.0, 40.0]
STANDARD_UPS_KVA = [250, 500, 750, 1000, 1500, 2000, 2500, 3000]
STANDARD_GENERATORS_MW = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
STANDARD_CHILLERS_KW = [500, 1000, 1500, 2000, 3000, 4000, 5000]
STANDARD_BATTERY_MWH = [1, 2, 5, 10, 20, 40, 60]

RACK_ARCHETYPES = {
    "standard_air_8kw": {"density_kw": 8, "cooling_type": "air"},
    "standard_air_12kw": {"density_kw": 12, "cooling_type": "air"},
    "high_density_air_20kw": {"density_kw": 20, "cooling_type": "air"},
    "gpu_liquid_80kw": {"density_kw": 80, "cooling_type": "direct_liquid"},
    "gpu_liquid_120kw": {"density_kw": 120, "cooling_type": "direct_liquid"},
    "immersion_150kw": {"density_kw": 150, "cooling_type": "immersion"},
}


def nearest_standard(value: float, options: list[float]) -> float:
    return min(options, key=lambda o: abs(o - value))


def catalog_summary() -> dict:
    return {
        "transformers_mva": STANDARD_TRANSFORMERS_MVA,
        "ups_kva": STANDARD_UPS_KVA,
        "generators_mw": STANDARD_GENERATORS_MW,
        "chillers_kw": STANDARD_CHILLERS_KW,
        "battery_mwh": STANDARD_BATTERY_MWH,
        "rack_archetypes": RACK_ARCHETYPES,
        "gpu_models": list(GPU_CATALOG.keys()),
        "cpu_models": list(CPU_CATALOG.keys()),
    }
