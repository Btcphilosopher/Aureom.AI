"""
Demo data center and demo-scenario factories (sections 57-58).

``build_demo_datacenter()`` ships a sophisticated, immediately-impressive
50 MW AI facility so the application opens with real content rather than an
empty design. ``build_demo_scenarios()`` returns Scenarios A-F, ready for
one-click comparison.
"""

from __future__ import annotations

from core.datacenter import DataCenter
from core.models import Battery, Generator, Transformer, UPS
from geometry.building import add_floor
from geometry.floor import generate_floor_plan
from network.switching import recommend_network_for_ai


def build_demo_datacenter() -> DataCenter:
    """DEMO — 50 MW AI DATA CENTER (section 57)."""
    dc = DataCenter(name="DEMO — 50MW AI Data Center")

    # --- Site ---
    dc.site.width_m = 400.0
    dc.site.length_m = 550.0
    dc.site.building_footprint_m2 = 42_000.0
    dc.site.substation_area_m2 = 4_500.0
    dc.site.generator_area_m2 = 3_500.0
    dc.site.cooling_plant_area_m2 = 6_000.0
    dc.site.water_storage_area_m2 = 1_500.0
    dc.site.solar_area_m2 = 60_000.0
    dc.site.battery_area_m2 = 2_500.0
    dc.site.grid_capacity_mw = 70.0

    # --- Building ---
    dc.building.width_m = 200.0
    dc.building.length_m = 210.0
    dc.building.floor_count = 1
    dc.building.floor_to_floor_height_m = 8.0
    dc.building.raised_floor_height_m = 0.0  # slab-on-grade, liquid cooling piped overhead
    dc.building.floors = []
    floor = add_floor(dc.building, layout_template="high_density_gpu")
    floor.width_m = 190.0
    floor.length_m = 190.0

    generate_floor_plan(
        floor,
        rack_count=300,
        avg_density_kw=10.0,           # standard air-cooled racks, under the 20kW air-cooling ceiling
        layout_template="high_density_gpu",
        aisle_width_m=1.8,
        high_density_fraction=0.85,
        high_density_kw=190.0,         # dense liquid-cooled AI racks -> ~50 MW facility total
        seed=50,
    )

    # --- Compute override (informational; the detailed rack model above is authoritative) ---
    dc.compute.gpu_count = 19_000
    dc.compute.occupancy = 35

    # --- Power: N+1, grid + generators + battery, sized for ~50 MW critical load ---
    dc.power.redundancy = "N+1"
    dc.power.transformers = [Transformer(capacity_mva=35.0) for _ in range(3)]
    dc.power.ups_units = [UPS(capacity_kva=5000.0) for _ in range(13)]      # ~61.75 MW usable @0.95pf
    dc.power.generators = [Generator(capacity_mw=6.0, fuel_type="diesel") for _ in range(12)]  # 72 MW
    dc.power.batteries = [Battery(capacity_mwh=25.0, power_mw=12.0) for _ in range(4)]
    dc.power.solar_capacity_mw = 25.0

    # --- Cooling: direct liquid cooling for AI racks + heat recovery ---
    dc.cooling.cooling_type = "direct_liquid"
    dc.cooling.liquid_cooling_fraction = 0.85
    dc.cooling.cooling_capacity_kw = 62_000.0
    dc.cooling.heat_recovery_enabled = True
    dc.cooling.free_cooling_enabled = True
    dc.cooling.ambient_temperature_c = 20.0
    dc.cooling.ambient_wetbulb_c = 15.0
    dc.cooling.chilled_water_supply_c = 18.0  # elevated supply temp typical of DLC loops

    # --- Network: high-bandwidth AI fabric ---
    dc.network = recommend_network_for_ai(dc.compute.gpu_count)

    # --- Energy ---
    dc.energy.grid_price_per_kwh = 0.09
    dc.energy.time_of_use_enabled = True
    dc.energy.solar_capacity_mw = 25.0
    dc.energy.solar_capacity_factor = 0.24
    dc.energy.battery_capacity_mwh = 100.0
    dc.energy.battery_power_mw = 48.0

    # --- Financial ---
    dc.financial.gpu_rental_price_per_hour = 2.75
    dc.financial.utilisation = 0.83

    return dc


def build_demo_scenarios(base: DataCenter | None = None) -> dict[str, DataCenter]:
    """Scenarios A-F (section 58)."""
    base = base or build_demo_datacenter()

    a = base.clone(name="Scenario A — Conventional Air-Cooled")
    a.cooling.cooling_type = "air"
    a.cooling.liquid_cooling_fraction = 0.0
    a.compute.high_density_fraction = 0.05

    b = base.clone(name="Scenario B — High-Density Liquid AI")
    b.cooling.cooling_type = "direct_liquid"
    b.cooling.liquid_cooling_fraction = 0.95

    c = base.clone(name="Scenario C — Renewable-Heavy")
    c.energy.solar_capacity_mw = base.results.it_load_mw * 0.9
    c.energy.battery_capacity_mwh = base.results.it_load_mw * 2.0
    c.energy.battery_power_mw = base.results.it_load_mw * 0.6

    d = base.clone(name="Scenario D — Minimum CAPEX")
    d.power.redundancy = "N"
    d.power.generators = d.power.generators[: max(2, len(d.power.generators) // 2)]
    d.power.batteries = d.power.batteries[:1]
    d.cooling.cooling_type = "air"
    d.cooling.liquid_cooling_fraction = 0.0
    d.energy.solar_capacity_mw = 0.0

    e = base.clone(name="Scenario E — Minimum PUE")
    e.cooling.cooling_type = "direct_liquid"
    e.cooling.liquid_cooling_fraction = 0.98
    e.cooling.free_cooling_enabled = True
    e.cooling.chilled_water_supply_c = 20.0

    f = base.clone(name="Scenario F — Maximum Profit")
    f.financial.gpu_rental_price_per_hour = 3.75
    f.financial.utilisation = 0.92

    return {"A": a, "B": b, "C": c, "D": d, "E": e, "F": f}
