"""
Export engine (section 40): professional Excel and PDF engineering reports.

JSON/CSV export is handled directly in :meth:`core.datacenter.DataCenter.export`;
this module holds the heavier openpyxl/reportlab renderers.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.datacenter import DataCenter, FacilityResults


def export_to_excel(dc: "DataCenter", results: "FacilityResults", path: Path) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()

    ws = wb.active
    ws.title = "Summary"
    ws.append(["DATACENTER.STUDIO — Engineering Report"])
    ws["A1"].font = Font(bold=True, size=14)
    ws.append([f"Design: {dc.name}"])
    ws.append([])
    ws.append(["KPI", "Value"])
    for k, v in results.kpi_header().items():
        ws.append([k, v])

    ws2 = wb.create_sheet("CAPEX")
    ws2.append(["Category", "USD"])
    for k, v in results.capex_breakdown.items():
        ws2.append([k, round(v, 0)])
    ws2.append(["TOTAL", round(results.capex, 0)])

    ws3 = wb.create_sheet("OPEX")
    ws3.append(["Category", "USD/yr"])
    for k, v in results.opex_breakdown.items():
        ws3.append([k, round(v, 0)])
    ws3.append(["TOTAL", round(results.annual_opex, 0)])

    ws4 = wb.create_sheet("Rack Schedule")
    ws4.append(["rack_id", "x", "y", "cooling_type", "it_load_kw", "peak_power_kw"])
    from geometry.rack import rack_schedule
    for floor in dc.building.floors:
        for row in rack_schedule(floor):
            ws4.append([row["rack_id"], row["x"], row["y"], row["cooling_type"],
                        row["it_load_kw"], row["peak_power_kw"]])

    ws5 = wb.create_sheet("Alerts")
    ws5.append(["Severity", "Code", "Subsystem", "Message"])
    for a in results.alerts:
        ws5.append([a.severity, a.code, a.subsystem, a.message])

    wb.save(str(path))
    return path


def export_to_pdf(dc: "DataCenter", results: "FacilityResults", path: Path) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4)
    story = [
        Paragraph("DATACENTER.STUDIO — Engineering Report", styles["Title"]),
        Paragraph(f"Design: {dc.name}", styles["Heading2"]),
        Paragraph(
            "Conceptual engineering simulation — not a substitute for detailed engineering design.",
            styles["Italic"],
        ),
        Spacer(1, 12),
    ]

    kpi_rows = [["KPI", "Value"]] + [[k, v] for k, v in results.kpi_header().items()]
    story.append(Paragraph("Key Performance Indicators", styles["Heading2"]))
    story.append(_styled_table(kpi_rows))
    story.append(Spacer(1, 12))

    capex_rows = [["CAPEX Category", "USD"]] + [[k, f"${v:,.0f}"] for k, v in results.capex_breakdown.items()]
    capex_rows.append(["TOTAL", f"${results.capex:,.0f}"])
    story.append(Paragraph("CAPEX Breakdown", styles["Heading2"]))
    story.append(_styled_table(capex_rows))
    story.append(Spacer(1, 12))

    opex_rows = [["OPEX Category", "USD/yr"]] + [[k, f"${v:,.0f}"] for k, v in results.opex_breakdown.items()]
    opex_rows.append(["TOTAL", f"${results.annual_opex:,.0f}"])
    story.append(Paragraph("Annual OPEX Breakdown", styles["Heading2"]))
    story.append(_styled_table(opex_rows))
    story.append(Spacer(1, 12))

    alert_rows = [["Severity", "Message"]] + [[a.severity, a.message] for a in results.alerts]
    story.append(Paragraph("Design Validation", styles["Heading2"]))
    story.append(_styled_table(alert_rows))

    doc.build(story)
    return path


def _styled_table(rows: list[list]):
    from reportlab.lib import colors
    from reportlab.platypus import Table, TableStyle

    t = Table(rows, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1f2b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f2f5")]),
    ]))
    return t
