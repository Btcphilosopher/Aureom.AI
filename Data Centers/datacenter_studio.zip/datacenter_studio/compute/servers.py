"""
Server catalog and factory functions (section 8).
"""

from __future__ import annotations

from core.models import Server, Workload
from compute.workloads import make_workload

SERVER_TEMPLATES: dict[str, dict] = {
    "general_1u": dict(form_factor="1U", category="general", idle_power_w=120.0, max_power_w=400.0),
    "general_2u": dict(form_factor="2U", category="general", idle_power_w=250.0, max_power_w=750.0),
    "general_4u": dict(form_factor="4U", category="general", idle_power_w=400.0, max_power_w=1200.0),
    "storage": dict(form_factor="storage", category="storage", idle_power_w=300.0, max_power_w=900.0),
    "network": dict(form_factor="network", category="network", idle_power_w=150.0, max_power_w=450.0),
    "gpu_server_8x": dict(form_factor="4U", category="gpu_server", idle_power_w=800.0,
                           max_power_w=2500.0, gpu_count=8, gpu_power_w=700.0),
    "ai_training_node": dict(form_factor="4U", category="ai_training", idle_power_w=900.0,
                              max_power_w=3200.0, gpu_count=8, gpu_power_w=1000.0),
    "ai_inference_node": dict(form_factor="2U", category="ai_inference", idle_power_w=400.0,
                               max_power_w=1600.0, gpu_count=4, gpu_power_w=300.0),
}


def create_server(template: str, workload_type: str | None = None, utilisation: float | None = None) -> Server:
    spec = SERVER_TEMPLATES.get(template)
    if spec is None:
        raise KeyError(f"Unknown server template: {template}")
    wt = workload_type or {
        "general": "cpu", "storage": "storage", "network": "network",
        "gpu_server": "gpu", "ai_training": "ai_training", "ai_inference": "ai_inference",
    }.get(spec["category"], "cpu")
    server = Server(**spec, workload=make_workload(wt, utilisation))
    return server
