"""
CPU / general-purpose server model (section 8).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CPUSpec:
    model: str
    tdp_w: float
    cores: int


CPU_CATALOG: dict[str, CPUSpec] = {
    "Xeon-8480+": CPUSpec("Xeon-8480+", 350.0, 56),
    "EPYC-9654": CPUSpec("EPYC-9654", 360.0, 96),
    "Graviton3": CPUSpec("Graviton3", 110.0, 64),
}


def cpu_server_power_w(model: str, socket_count: int, utilisation: float,
                        idle_fraction: float = 0.35) -> float:
    spec = CPU_CATALOG.get(model)
    if spec is None:
        raise KeyError(f"Unknown CPU model: {model}")
    u = max(0.0, min(1.0, utilisation))
    per_socket_max = spec.tdp_w
    per_socket = per_socket_max * idle_fraction + u * per_socket_max * (1.0 - idle_fraction)
    return per_socket * socket_count
