"""
GPU / AI accelerator model (section 8).

Representative (not vendor-official) TDP/memory figures for common AI
accelerator classes, used to size GPU servers and clusters.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GPUSpec:
    model: str
    tdp_w: float
    memory_gb: float
    fp16_tflops: float
    interconnect_gbps: float


GPU_CATALOG: dict[str, GPUSpec] = {
    "A100-80G": GPUSpec("A100-80G", 400.0, 80.0, 312.0, 600.0),
    "H100-SXM": GPUSpec("H100-SXM", 700.0, 80.0, 989.0, 900.0),
    "H200-SXM": GPUSpec("H200-SXM", 700.0, 141.0, 989.0, 900.0),
    "B200": GPUSpec("B200", 1000.0, 192.0, 2250.0, 1800.0),
    "MI300X": GPUSpec("MI300X", 750.0, 192.0, 1300.0, 896.0),
}


def gpu_cluster_power_kw(gpu_model: str, gpu_count: int, utilisation: float,
                          host_overhead_fraction: float = 0.25) -> float:
    """Total electrical power of a GPU cluster including host/network overhead."""
    spec = GPU_CATALOG.get(gpu_model)
    if spec is None:
        raise KeyError(f"Unknown GPU model: {gpu_model}")
    u = max(0.0, min(1.0, utilisation))
    gpu_power = gpu_count * spec.tdp_w * u
    return gpu_power * (1.0 + host_overhead_fraction) / 1000.0


def gpu_cluster_memory_tb(gpu_model: str, gpu_count: int) -> float:
    spec = GPU_CATALOG[gpu_model]
    return gpu_count * spec.memory_gb / 1000.0
