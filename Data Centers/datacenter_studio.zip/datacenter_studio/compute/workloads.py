"""
Workload profiles (section 8): realistic per-workload-type defaults for
utilisation, power draw multiplier, thermal output and bandwidth needs.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.models import Workload


@dataclass(frozen=True)
class WorkloadProfile:
    workload_type: str
    typical_utilisation: float
    power_draw_multiplier: float   # relative to a baseline 2U CPU server
    thermal_output_fraction: float  # fraction of electrical power emitted as heat
    memory_requirement_gb: float
    network_bandwidth_gbps: float


WORKLOAD_PROFILES: dict[str, WorkloadProfile] = {
    "cpu": WorkloadProfile("cpu", 0.55, 1.0, 0.99, 256.0, 25.0),
    "gpu": WorkloadProfile("gpu", 0.75, 4.5, 0.99, 512.0, 100.0),
    "ai_training": WorkloadProfile("ai_training", 0.90, 8.0, 0.99, 2048.0, 400.0),
    "ai_inference": WorkloadProfile("ai_inference", 0.65, 5.0, 0.99, 512.0, 200.0),
    "storage": WorkloadProfile("storage", 0.40, 0.6, 0.97, 64.0, 25.0),
    "network": WorkloadProfile("network", 0.35, 0.3, 0.95, 32.0, 400.0),
    "mixed": WorkloadProfile("mixed", 0.60, 2.0, 0.98, 512.0, 100.0),
}


def make_workload(workload_type: str, utilisation: float | None = None) -> Workload:
    profile = WORKLOAD_PROFILES.get(workload_type, WORKLOAD_PROFILES["cpu"])
    return Workload(
        workload_type=workload_type,  # type: ignore[arg-type]
        utilisation=utilisation if utilisation is not None else profile.typical_utilisation,
        memory_requirement_gb=profile.memory_requirement_gb,
        network_bandwidth_gbps=profile.network_bandwidth_gbps,
    )
