"""
Rack / facility power aggregation (section 9).

Vectorised (NumPy) roll-ups so the platform stays responsive with 1,000+
racks / 10,000+ servers (section 46).
"""

from __future__ import annotations

import numpy as np

from core.models import Building, Rack


def rack_loads_kw(racks: list[Rack]) -> np.ndarray:
    return np.array([r.rack_it_load_kw for r in racks], dtype=float)


def facility_compute_totals(building: Building) -> dict:
    all_racks: list[Rack] = [r for f in building.floors for r in f.racks]
    if not all_racks:
        return {
            "total_it_load_kw": 0.0, "peak_it_load_kw": 0.0, "average_it_load_kw": 0.0,
            "rack_count": 0, "server_count": 0, "daily_energy_kwh": 0.0, "annual_energy_kwh": 0.0,
        }
    loads = rack_loads_kw(all_racks)
    peaks = np.array([r.rack_peak_power_kw for r in all_racks], dtype=float)
    total = float(loads.sum())
    server_count = sum(len(r.servers) for r in all_racks)
    return {
        "total_it_load_kw": total,
        "peak_it_load_kw": float(peaks.sum()),
        "average_it_load_kw": float(loads.mean()),
        "rack_count": len(all_racks),
        "server_count": server_count,
        "daily_energy_kwh": total * 24.0,
        "annual_energy_kwh": total * 8760.0,
    }


def rack_density_histogram(building: Building, bin_kw: float = 10.0) -> dict[str, int]:
    all_racks = [r for f in building.floors for r in f.racks]
    hist: dict[str, int] = {}
    for r in all_racks:
        bucket = int(r.rack_it_load_kw // bin_kw) * int(bin_kw)
        key = f"{bucket}-{bucket + int(bin_kw)} kW"
        hist[key] = hist.get(key, 0) + 1
    return dict(sorted(hist.items(), key=lambda kv: int(kv[0].split("-")[0])))
