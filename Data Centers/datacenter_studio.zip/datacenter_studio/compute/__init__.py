"""Compute package: servers, GPUs, CPUs, racks and workload power models."""
