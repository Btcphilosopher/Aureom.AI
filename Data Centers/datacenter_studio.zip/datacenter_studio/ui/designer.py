"""
The guided design workflow (section 4): 01 SITE ... 12 REPORT, plus the
design-versioning sidebar (save / duplicate / compare / revert, section 38)
and the AI natural-language design generator (section 47-48).
"""

from __future__ import annotations

import streamlit as st

from ai.design_assistant import DesignAssistant
from optimisation.scenarios import compare_designs
from ui.panels import STAGES

ASSISTANT = DesignAssistant()


def _ensure_state() -> None:
    if "saved_designs" not in st.session_state:
        st.session_state["saved_designs"] = {}
    if "stage_index" not in st.session_state:
        st.session_state["stage_index"] = 0


def render_sidebar_workflow(dc) -> int:
    _ensure_state()
    st.sidebar.markdown("### DESIGN WORKFLOW")
    labels = [label for label, _ in STAGES]
    idx = st.sidebar.radio("Stage", options=list(range(len(labels))),
                            format_func=lambda i: labels[i], index=st.session_state["stage_index"],
                            label_visibility="collapsed")
    st.session_state["stage_index"] = idx

    st.sidebar.divider()
    st.sidebar.markdown("### DESIGN VERSIONING")
    st.sidebar.text_input("Design name", key="design_name_input", value=dc.name,
                           on_change=lambda: setattr(dc, "name", st.session_state["design_name_input"]))
    c1, c2 = st.sidebar.columns(2)
    if c1.button("💾 Save", use_container_width=True):
        st.session_state["saved_designs"][dc.name] = dc.clone(dc.name)
        st.sidebar.success(f"Saved '{dc.name}'")
    if c2.button("⧉ Duplicate", use_container_width=True):
        clone = dc.clone()
        st.session_state["saved_designs"][clone.name] = clone
        st.session_state["dc"] = clone
        st.rerun()

    if st.session_state["saved_designs"]:
        with st.sidebar.expander("Saved Designs / Compare"):
            names = list(st.session_state["saved_designs"].keys())
            chosen = st.multiselect("Compare with current", names, default=[])
            if chosen and st.button("Run Comparison"):
                designs = [dc] + [st.session_state["saved_designs"][n] for n in chosen]
                st.session_state["comparison_rows"] = compare_designs(designs)
            for n in names:
                cc1, cc2 = st.columns([3, 1])
                cc1.write(n)
                if cc2.button("Load", key=f"load_{n}"):
                    st.session_state["dc"] = st.session_state["saved_designs"][n].clone(n)
                    st.rerun()

    st.sidebar.divider()
    st.sidebar.markdown("### AI DESIGN ASSISTANT")
    brief = st.sidebar.text_area("Describe a facility, or an iteration command",
                                  placeholder="e.g. 'Design a 20 MW AI data center with 200 kW "
                                              "liquid-cooled racks, N+1 power redundancy, 30% solar "
                                              "and battery storage.' or 'Reduce PUE.'",
                                  key="ai_brief")
    bc1, bc2 = st.sidebar.columns(2)
    if bc1.button("Generate Design", use_container_width=True) and brief:
        new_dc, spec, explanation = ASSISTANT.generate_from_text(brief)
        st.session_state["dc"] = new_dc
        st.sidebar.success(explanation)
        st.rerun()
    if bc2.button("Propose Change", use_container_width=True) and brief:
        proposal = ASSISTANT.propose_iteration(dc, brief)
        st.session_state["pending_proposal"] = proposal

    if st.session_state.get("pending_proposal") is not None:
        proposal = st.session_state["pending_proposal"]
        with st.sidebar.container(border=True):
            st.write(f"**Proposal:** {proposal.description}")
            if proposal.changes:
                st.json(proposal.changes)
            if proposal.objective_weights:
                st.json(proposal.objective_weights)
            if st.button("✅ Apply", key="apply_proposal", use_container_width=True):
                ASSISTANT.apply_iteration(dc, proposal)
                st.session_state["pending_proposal"] = None
                st.rerun()

    return idx


def render_comparison_table() -> None:
    rows = st.session_state.get("comparison_rows")
    if rows:
        st.markdown("### Design Comparison")
        import pandas as pd
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


def render_designer(dc) -> None:
    idx = render_sidebar_workflow(dc)
    label, render_fn = STAGES[idx]
    st.markdown(f"#### {label}")
    render_fn(dc)
    render_comparison_table()
