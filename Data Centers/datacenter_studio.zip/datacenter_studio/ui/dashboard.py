"""
Landing dashboard (section 51): KPI header, facility visualisation, and a
tabbed quick-look across ENERGY / THERMAL / POWER / FINANCE / OPTIMISATION.
"""

from __future__ import annotations

import streamlit as st

from ai.design_assistant import DesignAssistant
from ui.panels import kpi_strip
from visualization import charts, facility_view, power_flow, thermal_map

ASSISTANT = DesignAssistant()


def render_dashboard(dc) -> None:
    st.markdown(
        "<h1 style='font-family:monospace;letter-spacing:2px;'>DATACENTER.STUDIO</h1>"
        "<p style='color:#6b7280;margin-top:-12px;'>AI Data Center Design, Simulation &amp; "
        "Optimisation Platform — <i>conceptual engineering simulation, not a substitute for "
        "detailed engineering design.</i></p>",
        unsafe_allow_html=True,
    )

    kpi_strip(dc)
    st.divider()

    col_viz, col_side = st.columns([2.4, 1])
    with col_viz:
        st.plotly_chart(facility_view.render_site_view(dc), use_container_width=True, key="dash_site")
    with col_side:
        st.markdown("#### Top AI Recommendations")
        recs = ASSISTANT.recommendations(dc)[:3]
        for r in recs:
            st.info(f"**{r.category.upper()}** — {r.title}")

    tabs = st.tabs(["ENERGY", "THERMAL", "POWER", "FINANCE", "OPTIMISATION"])
    results = dc.compute_results()

    with tabs[0]:
        c1, c2 = st.columns(2)
        c1.metric("PUE", f"{results.pue:.3f}")
        c1.metric("WUE", f"{results.wue:.2f} L/kWh")
        c2.metric("CUE", f"{results.cue:.3f} kgCO2/kWh")
        c2.metric("ERE", f"{results.ere:.3f}")
        st.plotly_chart(charts.breakdown_bar(
            {"IT Load": results.it_load_mw * 1000, "Cooling": results.cooling_electrical_kw,
             "Power Losses": results.power_losses_kw}, "Facility Power Split (kW)"),
            use_container_width=True, key="dash_energy")

    with tabs[1]:
        if dc.building.floors and dc.building.floors[0].racks:
            st.plotly_chart(thermal_map.render_thermal_heatmap(dc, dc.building.floors[0]),
                             use_container_width=True, key="dash_thermal")
        else:
            st.info("Generate a floor plan (stage 03) to see the thermal heatmap.")

    with tabs[2]:
        st.plotly_chart(power_flow.render_power_flow(dc), use_container_width=True, key="dash_power")

    with tabs[3]:
        st.plotly_chart(charts.breakdown_bar(results.capex_breakdown, "CAPEX Breakdown"),
                         use_container_width=True, key="dash_capex")

    with tabs[4]:
        st.write("Use the **10 OPTIMISE** stage in the workflow sidebar to run a full "
                 "multi-objective search (Grid / Random / Differential Evolution / Genetic).")
        st.metric("Current objective-relevant PUE", f"{results.pue:.3f}")
        st.metric("Current CAPEX", f"${results.capex/1e6:,.1f}M")
