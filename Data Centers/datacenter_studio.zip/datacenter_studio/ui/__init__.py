"""UI package: Streamlit-based design studio (dashboard, designer workflow, controls, panels)."""
