"""
Reusable design-control widgets (section 35): sliders/inputs bound directly
to DataCenter attributes, so moving a control immediately updates the
central model — nothing here holds its own state.
"""

from __future__ import annotations

import streamlit as st


def bound_slider(label: str, obj, attr: str, min_value: float, max_value: float,
                  step: float = 1.0, fmt: str = "%.1f", unit: str = "", key: str | None = None,
                  help: str | None = None) -> float:
    """A slider whose value is read from / written directly to ``obj.attr``."""
    current = getattr(obj, attr)
    current = min(max(current, min_value), max_value)
    key = key or f"{id(obj)}_{attr}"
    value = st.slider(f"{label} ({unit})" if unit else label, min_value=float(min_value),
                       max_value=float(max_value), value=float(current), step=float(step),
                       format=fmt, key=key, help=help)
    setattr(obj, attr, value)
    return value


def bound_number(label: str, obj, attr: str, min_value: float | None = None,
                  max_value: float | None = None, step: float = 1.0, key: str | None = None) -> float:
    current = getattr(obj, attr)
    key = key or f"{id(obj)}_{attr}_num"
    value = st.number_input(label, min_value=min_value, max_value=max_value, value=float(current),
                             step=step, key=key)
    setattr(obj, attr, value)
    return value


def bound_select(label: str, obj, attr: str, options: list[str], key: str | None = None) -> str:
    current = getattr(obj, attr)
    key = key or f"{id(obj)}_{attr}_sel"
    index = options.index(current) if current in options else 0
    value = st.selectbox(label, options, index=index, key=key)
    setattr(obj, attr, value)
    return value


def bound_toggle(label: str, obj, attr: str, key: str | None = None) -> bool:
    current = getattr(obj, attr)
    key = key or f"{id(obj)}_{attr}_tog"
    value = st.toggle(label, value=bool(current), key=key)
    setattr(obj, attr, value)
    return value


def progress_bar_metric(label: str, value: float, max_value: float, unit: str = "") -> None:
    frac = min(1.0, max(0.0, value / max_value)) if max_value else 0.0
    st.caption(f"{label}: {value:,.1f}{unit} / {max_value:,.1f}{unit}")
    st.progress(frac)
