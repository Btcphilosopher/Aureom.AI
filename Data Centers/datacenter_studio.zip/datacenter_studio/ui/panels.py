"""
The twelve design-workflow stage panels (section 4): SITE, BUILDING, FLOOR
PLAN, COMPUTE, POWER, COOLING, NETWORK, ENERGY, ECONOMICS, OPTIMISE,
SIMULATE, REPORT. Each ``render_*`` function follows the same layout
contract: LEFT parameters / CENTER visualisation / RIGHT live results
(section 3), reading and writing the same underlying :class:`DataCenter`.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from ai.design_assistant import DesignAssistant
from config.constants import COOLING_TYPES, LAYOUT_TEMPLATES, REDUNDANCY_LEVELS
from core.models import Battery, Generator, Transformer, UPS
from economics.financials import compute_financial_summary
from geometry.building import add_floor, building_summary
from geometry.floor import floor_summary, generate_floor_plan
from geometry.site import site_summary
from optimisation.scenarios import PRESET_SCENARIOS, run_scenarios
from optimisation.sensitivity import monte_carlo_analysis, tornado_chart_data
from ui.controls import bound_number, bound_select, bound_slider, bound_toggle
from visualization import charts, facility_view, floorplan, power_flow, thermal_map

ASSISTANT = DesignAssistant()


def kpi_strip(dc) -> None:
    results = dc.compute_results()
    cols = st.columns(6)
    kpis = list(results.kpi_header().items())
    for col, (label, value) in zip(cols, kpis[:6]):
        col.metric(label, value)
    cols2 = st.columns(6)
    for col, (label, value) in zip(cols2, kpis[6:]):
        col.metric(label, value)


# ---------------------------------------------------------------------------
# 01 SITE
# ---------------------------------------------------------------------------

def render_site(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    with left:
        st.subheader("Site Parameters")
        bound_slider("Site Width", dc.site, "width_m", 100.0, 1000.0, 10.0, unit="m")
        bound_slider("Site Length", dc.site, "length_m", 100.0, 1000.0, 10.0, unit="m")
        bound_slider("Building Footprint", dc.site, "building_footprint_m2", 1000.0, 100_000.0, 500.0, unit="m²")
        bound_slider("Substation Area", dc.site, "substation_area_m2", 500.0, 20_000.0, 100.0, unit="m²")
        bound_slider("Generator Yard", dc.site, "generator_area_m2", 500.0, 20_000.0, 100.0, unit="m²")
        bound_slider("Cooling Plant Area", dc.site, "cooling_plant_area_m2", 500.0, 30_000.0, 100.0, unit="m²")
        bound_slider("Solar Field Area", dc.site, "solar_area_m2", 0.0, 200_000.0, 1000.0, unit="m²")
        bound_slider("Battery Yard Area", dc.site, "battery_area_m2", 0.0, 20_000.0, 100.0, unit="m²")
        bound_slider("Grid Capacity", dc.site, "grid_capacity_mw", 5.0, 500.0, 5.0, unit="MW")
    with center:
        st.plotly_chart(facility_view.render_site_view(dc), use_container_width=True, key="site_view")
    with right:
        st.subheader("Site Metrics")
        s = site_summary(dc.site)
        st.metric("Site Area", f"{s['site_area_m2']/10_000:.2f} ha")
        st.metric("Site Utilisation", f"{s['site_utilisation_pct']:.1f}%")
        st.metric("Building Coverage", f"{s['building_coverage_pct']:.1f}%")
        st.metric("Expansion Area", f"{s['expansion_area_m2']/10_000:.2f} ha")


# ---------------------------------------------------------------------------
# 02 BUILDING
# ---------------------------------------------------------------------------

def render_building(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    with left:
        st.subheader("Building Parameters")
        bound_slider("Building Width", dc.building, "width_m", 30.0, 400.0, 5.0, unit="m")
        bound_slider("Building Length", dc.building, "length_m", 30.0, 400.0, 5.0, unit="m")
        floors = st.slider("Number of Floors", 1, 8, dc.building.floor_count)
        dc.building.floor_count = floors
        bound_slider("Floor-to-Floor Height", dc.building, "floor_to_floor_height_m", 3.5, 12.0, 0.1, unit="m")
        bound_slider("Raised Floor Height", dc.building, "raised_floor_height_m", 0.0, 1.2, 0.05, unit="m")
        bound_slider("Structural Grid", dc.building, "structural_grid_m", 5.0, 12.0, 0.5, unit="m")
        st.caption("Support-space fractions (of gross floor area)")
        bound_slider("Technical", dc.building, "technical_area_fraction", 0.0, 0.3, 0.01)
        bound_slider("Electrical", dc.building, "electrical_area_fraction", 0.0, 0.3, 0.01)
        bound_slider("Mechanical", dc.building, "mechanical_area_fraction", 0.0, 0.3, 0.01)
        bound_slider("Office", dc.building, "office_area_fraction", 0.0, 0.2, 0.01)
        if st.button("+ Add Floor", use_container_width=True):
            add_floor(dc.building)
            st.rerun()
    with center:
        st.plotly_chart(facility_view.render_facility_hierarchy(dc), use_container_width=True, key="bldg_hier")
    with right:
        st.subheader("Building Metrics")
        b = building_summary(dc.building)
        st.metric("Gross Floor Area", f"{b['gross_floor_area_m2']:,.0f} m²")
        st.metric("Net (White Space) Area", f"{b['net_floor_area_m2']:,.0f} m²")
        st.metric("Technical Area", f"{b['technical_area_m2']:,.0f} m²")
        st.metric("Plant Area", f"{b['plant_area_m2']:,.0f} m²")
        st.metric("Total Height", f"{b['total_height_m']:.1f} m")
        st.metric("Floors", b["floor_count"])


# ---------------------------------------------------------------------------
# 03 FLOOR PLAN
# ---------------------------------------------------------------------------

def render_floorplan_stage(dc) -> None:
    if not dc.building.floors:
        add_floor(dc.building)
    floor_idx = st.selectbox("Floor", options=list(range(len(dc.building.floors))),
                              format_func=lambda i: f"Floor {dc.building.floors[i].index}")
    floor = dc.building.floors[floor_idx]

    left, center, right = st.columns([1.1, 2.2, 1.1])
    with left:
        st.subheader("Floor-Plan Generator")
        layout = bound_select("Layout Template", floor, "layout_template", list(LAYOUT_TEMPLATES))
        rack_count = st.slider("Rack Count", 4, 800, max(len(floor.racks), 40))
        avg_density = st.slider("Average Rack Density (kW)", 3.0, 40.0, 12.0, 1.0)
        hd_fraction = st.slider("High-Density (GPU) Fraction", 0.0, 1.0, 0.0, 0.05)
        hd_density = st.slider("High-Density Rack Power (kW)", 40.0, 200.0, 80.0, 5.0)
        aisle = bound_slider("Aisle Width", floor, "aisle_width_m", 0.9, 3.0, 0.1, unit="m")
        if st.button("Generate Floor Plan", use_container_width=True, type="primary"):
            generate_floor_plan(floor, rack_count, avg_density, layout, aisle, hd_fraction, hd_density)
            st.rerun()
        layer = st.radio("Visualisation Layer", floorplan.LAYERS, horizontal=False)
    with center:
        if floor.racks:
            st.plotly_chart(floorplan.render_floorplan(dc, floor, layer), use_container_width=True, key="floorplan")
        else:
            st.info("Click 'Generate Floor Plan' to populate this floor with racks.")
    with right:
        st.subheader("Floor Metrics")
        fs = floor_summary(floor)
        st.metric("Racks", fs["rack_count"])
        st.metric("IT Load", f"{fs['it_load_kw']/1000:.2f} MW")
        st.metric("Power Density", f"{fs['power_density_kw_per_m2']:.2f} kW/m²")
        if floor.racks:
            from compute.racks import rack_density_histogram
            hist = rack_density_histogram(dc.building)
            st.plotly_chart(charts.rack_density_histogram_chart(hist), use_container_width=True, key="rackhist")


# ---------------------------------------------------------------------------
# 04 COMPUTE
# ---------------------------------------------------------------------------

def render_compute(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    results = dc.compute_results()
    with left:
        st.subheader("Compute Parameters")
        st.caption("Used when no detailed floor/rack plan is populated (fast override mode).")
        it_load = st.number_input("IT Load Override (MW)", 0.0, 500.0,
                                   float(dc.compute.it_load_mw or 0.0), 1.0)
        dc.compute.it_load_mw = it_load if it_load > 0 else None
        bound_slider("Avg Rack Density", dc.compute, "avg_rack_density_kw", 3.0, 40.0, 1.0, unit="kW")
        bound_slider("High-Density Fraction", dc.compute, "high_density_fraction", 0.0, 1.0, 0.05)
        bound_slider("High-Density Power", dc.compute, "high_density_kw", 40.0, 200.0, 5.0, unit="kW")
        bound_number("GPU Count", dc.compute, "gpu_count", 0, step=100)
        bound_number("Occupancy (people)", dc.compute, "occupancy", 0, step=1)
    with center:
        st.plotly_chart(charts.breakdown_bar(
            {"IT Load": results.it_load_mw * 1000, "Peak IT Load": results.peak_it_load_mw * 1000},
            "IT Load vs Peak (kW)"), use_container_width=True, key="compute_bar")
        df = pd.DataFrame({
            "Metric": ["Racks", "Servers", "GPUs"],
            "Count": [results.rack_count, results.server_count, results.gpu_count],
        })
        st.dataframe(df, use_container_width=True, hide_index=True)
    with right:
        st.subheader("Compute Totals")
        st.metric("Total IT Load", f"{results.it_load_mw:.2f} MW")
        st.metric("Peak IT Load", f"{results.peak_it_load_mw:.2f} MW")
        st.metric("Rack Count", results.rack_count)
        st.metric("Server Count", results.server_count)
        st.metric("GPU Count", results.gpu_count)


# ---------------------------------------------------------------------------
# 05 POWER
# ---------------------------------------------------------------------------

def render_power(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    results = dc.compute_results()
    with left:
        st.subheader("Power Parameters")
        bound_select("Redundancy", dc.power, "redundancy", list(REDUNDANCY_LEVELS))
        n_xfmr = st.slider("Transformers", 1, 8, len(dc.power.transformers))
        xfmr_mva = st.slider("Transformer Size (MVA)", 2.5, 50.0, dc.power.transformers[0].capacity_mva if dc.power.transformers else 20.0)
        dc.power.transformers = [Transformer(capacity_mva=xfmr_mva) for _ in range(n_xfmr)]
        n_ups = st.slider("UPS Units", 1, 12, len(dc.power.ups_units))
        ups_kva = st.slider("UPS Size (kVA)", 250.0, 4000.0, dc.power.ups_units[0].capacity_kva if dc.power.ups_units else 1000.0)
        dc.power.ups_units = [UPS(capacity_kva=ups_kva) for _ in range(n_ups)]
        n_gen = st.slider("Generators", 1, 16, len(dc.power.generators))
        gen_mw = st.slider("Generator Size (MW)", 0.5, 5.0, dc.power.generators[0].capacity_mw if dc.power.generators else 2.5)
        dc.power.generators = [Generator(capacity_mw=gen_mw) for _ in range(n_gen)]
        n_bat = st.slider("Battery Banks", 0, 12, len(dc.power.batteries))
        bat_mwh = st.slider("Battery Size (MWh each)", 1.0, 60.0, dc.power.batteries[0].capacity_mwh if dc.power.batteries else 10.0)
        dc.power.batteries = [Battery(capacity_mwh=bat_mwh, power_mw=bat_mwh / 2) for _ in range(n_bat)]
    with center:
        st.plotly_chart(power_flow.render_power_flow(dc), use_container_width=True, key="power_flow")
        st.plotly_chart(charts.breakdown_bar(
            {"Transformer Loading %": results.transformer_loading_pct,
             "UPS Loading %": results.ups_loading_pct,
             "Generator Loading %": results.generator_loading_pct},
            "Loading %"), use_container_width=True, key="power_loading")
    with right:
        st.subheader("Power Metrics")
        st.metric("Transformer Loading", f"{results.transformer_loading_pct:.0f}%")
        st.metric("UPS Loading", f"{results.ups_loading_pct:.0f}%")
        st.metric("Generator Capacity", f"{results.generator_capacity_mw:.1f} MW")
        st.metric("Battery Backup", f"{results.battery_backup_minutes:.1f} min")
        st.metric("Redundancy OK", "✅ Yes" if results.redundancy_satisfied else "❌ No")
        st.metric("Power Losses", f"{results.power_losses_kw:,.0f} kW")


# ---------------------------------------------------------------------------
# 06 COOLING
# ---------------------------------------------------------------------------

def render_cooling(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    results = dc.compute_results()
    with left:
        st.subheader("Cooling Parameters")
        bound_select("Cooling Type", dc.cooling, "cooling_type", list(COOLING_TYPES))
        bound_slider("Cooling Capacity", dc.cooling, "cooling_capacity_kw", 1000.0, 150_000.0, 500.0, unit="kW")
        bound_slider("Liquid Cooling Fraction", dc.cooling, "liquid_cooling_fraction", 0.0, 1.0, 0.05)
        bound_slider("Ambient Temperature", dc.cooling, "ambient_temperature_c", -10.0, 45.0, 0.5, unit="°C")
        bound_slider("Ambient Wet-Bulb", dc.cooling, "ambient_wetbulb_c", -10.0, 35.0, 0.5, unit="°C")
        bound_slider("Chilled Water Supply", dc.cooling, "chilled_water_supply_c", 5.0, 22.0, 0.5, unit="°C")
        bound_toggle("Free Cooling Enabled", dc.cooling, "free_cooling_enabled")
        bound_toggle("Heat Recovery Enabled", dc.cooling, "heat_recovery_enabled")
    with center:
        if dc.building.floors and dc.building.floors[0].racks:
            st.plotly_chart(thermal_map.render_thermal_heatmap(dc, dc.building.floors[0]),
                             use_container_width=True, key="thermal_map")
        st.plotly_chart(power_flow.render_cooling_flow(dc), use_container_width=True, key="cooling_flow")
    with right:
        st.subheader("Cooling Metrics")
        st.metric("Total Heat Load", f"{results.total_heat_kw/1000:.2f} MW")
        st.metric("Cooling Electrical", f"{results.cooling_electrical_kw:,.0f} kW")
        st.metric("COP", f"{results.cop:.2f}")
        st.metric("Free Cooling Active", "✅" if results.free_cooling_active else "—")
        st.metric("Water Use", f"{results.water_use_m3_per_hour:.1f} m³/h")
        st.metric("Recovered Heat", f"{results.recovered_heat_kw:,.0f} kW")


# ---------------------------------------------------------------------------
# 07 NETWORK
# ---------------------------------------------------------------------------

def render_network(dc) -> None:
    from network.bandwidth import evaluate_network
    left, center, right = st.columns([1.1, 2.2, 1.1])
    results = dc.compute_results()
    with left:
        st.subheader("Network Parameters")
        bound_select("Topology", dc.network, "topology", ["3-tier", "spine-leaf", "fat-tree"])
        bound_slider("Internet Uplink", dc.network, "internet_uplink_gbps", 10.0, 3200.0, 10.0, unit="Gbps")
        bound_number("Core Switches", dc.network, "core_switch_count", 1, step=1)
        bound_number("Spine Switches", dc.network, "spine_switch_count", 0, step=1)
        bound_number("Leaf Switches", dc.network, "leaf_switch_count", 1, step=1)
        bound_slider("ToR Uplink", dc.network, "tor_uplink_gbps", 10.0, 3200.0, 10.0, unit="Gbps")
        bound_slider("Server NIC", dc.network, "server_nic_gbps", 1.0, 800.0, 1.0, unit="Gbps")
        bound_toggle("AI Fabric (high-bandwidth interconnect)", dc.network, "ai_fabric")
    with center:
        servers_per_rack = (results.server_count / results.rack_count) if results.rack_count else 0
        net = evaluate_network(dc.network, results.rack_count, servers_per_rack)
        st.plotly_chart(charts.breakdown_bar(
            {"Server BW": net.total_server_bandwidth_gbps, "Uplink BW": net.total_uplink_bandwidth_gbps,
             "Network Capacity": net.network_capacity_gbps}, "Bandwidth (Gbps)"),
            use_container_width=True, key="net_bw")
    with right:
        st.subheader("Network Metrics")
        servers_per_rack = (results.server_count / results.rack_count) if results.rack_count else 0
        net = evaluate_network(dc.network, results.rack_count, servers_per_rack)
        st.metric("Oversubscription", f"{net.oversubscription_ratio:.2f}:1")
        st.metric("Port Utilisation", f"{net.port_utilisation_pct:.0f}%")
        st.metric("Network Capacity", f"{net.network_capacity_gbps:,.0f} Gbps")
        st.metric("AI Fabric", "✅" if net.ai_fabric else "—")


# ---------------------------------------------------------------------------
# 08 ENERGY
# ---------------------------------------------------------------------------

def render_energy(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    with left:
        st.subheader("Energy Parameters")
        bound_slider("Grid Price", dc.energy, "grid_price_per_kwh", 0.02, 0.50, 0.01, unit="$/kWh")
        bound_toggle("Time-of-Use Pricing", dc.energy, "time_of_use_enabled")
        bound_slider("Peak Price Multiplier", dc.energy, "peak_price_multiplier", 1.0, 3.0, 0.1)
        bound_slider("Solar Capacity", dc.energy, "solar_capacity_mw", 0.0, 200.0, 1.0, unit="MW")
        bound_slider("Solar Capacity Factor", dc.energy, "solar_capacity_factor", 0.10, 0.35, 0.01)
        bound_slider("Wind Capacity", dc.energy, "wind_capacity_mw", 0.0, 200.0, 1.0, unit="MW")
        bound_slider("Battery Capacity", dc.energy, "battery_capacity_mwh", 0.0, 400.0, 5.0, unit="MWh")
        bound_slider("Battery Power", dc.energy, "battery_power_mw", 0.0, 150.0, 1.0, unit="MW")
        horizon = st.selectbox("Simulation Horizon", ["24 hour", "7 day", "30 day", "1 year"], index=0)
    with center:
        hours_map = {"24 hour": 24, "7 day": 168, "30 day": 720, "1 year": 8760}
        if st.button("Run Energy Simulation", type="primary", use_container_width=True):
            with st.spinner("Simulating..."):
                st.session_state["sim_result"] = dc.simulate(hours=hours_map[horizon])
        sim = st.session_state.get("sim_result")
        if sim is not None:
            df = sim.dataframe
            st.plotly_chart(charts.timeline_chart(df, ["it_load_mw", "facility_load_mw", "grid_import_mw"],
                                                    "Load Profile", "MW"), use_container_width=True, key="energy_load")
            st.plotly_chart(charts.timeline_chart(df, ["solar_generation_mw", "wind_generation_mw"],
                                                    "Renewable Generation", "MW"), use_container_width=True, key="energy_renew")
            st.plotly_chart(charts.timeline_chart(df, ["battery_soc"], "Battery State of Charge", "SOC"),
                             use_container_width=True, key="energy_soc")
        else:
            st.info("Click 'Run Energy Simulation' to generate the hourly profile.")
    with right:
        st.subheader("Energy Metrics")
        sim = st.session_state.get("sim_result")
        if sim is not None:
            st.metric("Average PUE", f"{sim.pue:.3f}")
            st.metric("Renewable Fraction", f"{sim.renewable_fraction*100:.1f}%")
            st.metric("Total Energy", f"{sim.total_energy_kwh/1000:,.0f} MWh")
            st.metric("Total Cost", f"${sim.total_cost:,.0f}")
            st.metric("Total Carbon", f"{sim.total_carbon_kg/1000:,.1f} t")
        else:
            results = dc.compute_results()
            st.metric("PUE (instantaneous)", f"{results.pue:.3f}")
            st.metric("Carbon (annualised)", f"{results.annual_carbon_tonnes:,.0f} t/yr")


# ---------------------------------------------------------------------------
# 09 ECONOMICS
# ---------------------------------------------------------------------------

def render_economics(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    results = dc.compute_results()
    with left:
        st.subheader("Financial Parameters")
        bound_slider("GPU Rental Price", dc.financial, "gpu_rental_price_per_hour", 0.5, 8.0, 0.1, unit="$/hr")
        bound_slider("Server Rental Price", dc.financial, "server_rental_price_per_month", 200.0, 3000.0, 50.0, unit="$/mo")
        bound_slider("Rack Rental Price", dc.financial, "rack_rental_price_per_month", 1000.0, 20000.0, 250.0, unit="$/mo")
        bound_slider("Power Price", dc.financial, "power_price_per_kwh", 0.05, 0.40, 0.01, unit="$/kWh")
        bound_slider("Utilisation", dc.financial, "utilisation", 0.3, 1.0, 0.02)
        bound_slider("Contract Duration", dc.financial, "contract_duration_years", 1.0, 15.0, 0.5, unit="yrs")
    with center:
        st.plotly_chart(charts.breakdown_bar(results.capex_breakdown, "CAPEX Breakdown ($)"),
                         use_container_width=True, key="capex_bar")
        st.plotly_chart(charts.breakdown_bar(results.opex_breakdown, "Annual OPEX Breakdown ($/yr)"),
                         use_container_width=True, key="opex_bar")
    with right:
        st.subheader("Financial Metrics")
        st.metric("CAPEX", f"${results.capex/1e6:,.1f}M")
        st.metric("Annual OPEX", f"${results.annual_opex/1e6:,.2f}M")
        st.metric("Annual Revenue", f"${results.annual_revenue/1e6:,.2f}M")
        st.metric("EBITDA", f"${results.ebitda/1e6:,.2f}M")
        st.metric("NPV", f"${results.npv/1e6:,.1f}M")
        st.metric("IRR", f"{results.irr*100:.1f}%" if results.irr is not None else "n/a")
        st.metric("Payback", f"{results.payback_years:.1f} yrs" if results.payback_years is not None else "n/a")
        st.metric("Cost / MW", f"${results.cost_per_mw/1e6:,.2f}M")
        st.metric("Cost / Rack", f"${results.cost_per_rack:,.0f}")


# ---------------------------------------------------------------------------
# 10 OPTIMISE
# ---------------------------------------------------------------------------

def render_optimise(dc) -> None:
    left, center, right = st.columns([1.1, 2.2, 1.1])
    with left:
        st.subheader("Optimisation Objectives")
        weights = {}
        for obj, default in [("capex", 0.20), ("opex", 0.20), ("pue", 0.20), ("carbon", 0.15), ("revenue", 0.25)]:
            weights[obj] = st.slider(obj.upper(), 0.0, 1.0, default, 0.05, key=f"objw_{obj}")
        method = st.selectbox("Method", ["differential_evolution", "genetic", "random", "grid"])
        if st.button("Run Optimisation", type="primary", use_container_width=True):
            with st.spinner(f"Running {method}..."):
                st.session_state["opt_result"] = dc.optimise(objectives=weights, method=method)
    with center:
        opt = st.session_state.get("opt_result")
        if opt is not None:
            hist_df = pd.DataFrame([{"iteration": i, "score": h["score"]} for i, h in enumerate(opt.history)])
            st.plotly_chart(charts.timeline_chart(
                hist_df.rename(columns={"iteration": "timestamp"}), ["score"], "Convergence", "objective score"
            ), use_container_width=True, key="opt_convergence")
            st.json(opt.summary())
        else:
            st.info("Configure objective weights and click 'Run Optimisation'.")
    with right:
        st.subheader("Best Design")
        opt = st.session_state.get("opt_result")
        if opt is not None:
            r = opt.best_results
            st.metric("PUE", f"{r.pue:.3f}")
            st.metric("CAPEX", f"${r.capex/1e6:,.1f}M")
            st.metric("Annual Revenue", f"${r.annual_revenue/1e6:,.1f}M")
            if st.button("Adopt this design", use_container_width=True):
                st.session_state["dc"] = opt.best_design
                st.rerun()

    st.divider()
    st.subheader("Sensitivity & Monte Carlo (section 29)")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Run Tornado Sensitivity"):
            st.session_state["tornado"] = tornado_chart_data(dc)
        if "tornado" in st.session_state:
            st.plotly_chart(charts.tornado_chart(st.session_state["tornado"]), use_container_width=True, key="tornado")
    with c2:
        n = st.slider("Monte Carlo Samples", 200, 5000, 1000, 100)
        if st.button("Run Monte Carlo"):
            with st.spinner("Sampling..."):
                st.session_state["mc"] = monte_carlo_analysis(dc, n_samples=n)
        if "mc" in st.session_state:
            mc = st.session_state["mc"]
            st.dataframe(mc.summary_table(), use_container_width=True)
            st.plotly_chart(charts.monte_carlo_histogram(mc.samples["pue"], "PUE Distribution",
                                                            mc.percentiles["pue"]), use_container_width=True, key="mc_pue")


# ---------------------------------------------------------------------------
# 11 SIMULATE
# ---------------------------------------------------------------------------

def render_simulate(dc) -> None:
    st.subheader("Facility Simulation Timeline (section 52)")
    horizon = st.select_slider("Horizon", options=["24 hour", "7 day", "30 day", "1 year"], value="24 hour")
    hours_map = {"24 hour": 24, "7 day": 168, "30 day": 720, "1 year": 8760}
    if st.button("Run Simulation", type="primary"):
        with st.spinner("Simulating facility operation..."):
            st.session_state["sim_result"] = dc.simulate(hours=hours_map[horizon])

    sim = st.session_state.get("sim_result")
    if sim is None:
        st.info("Run a simulation to see the facility operate over time.")
        return

    df = sim.dataframe
    idx = st.slider("Playback position", 0, len(df) - 1, 0)
    row = df.iloc[idx]
    cols = st.columns(6)
    cols[0].metric("Time", str(row["timestamp"]))
    cols[1].metric("IT Load", f"{row['it_load_mw']:.2f} MW")
    cols[2].metric("Facility Load", f"{row['facility_load_mw']:.2f} MW")
    cols[3].metric("PUE", f"{row['pue']:.3f}")
    cols[4].metric("Battery SOC", f"{row['battery_soc']*100:.0f}%")
    cols[5].metric("Temperature", f"{row['temperature_c']:.1f}°C")

    st.plotly_chart(charts.timeline_chart(df, ["it_load_mw", "facility_load_mw"], "Power", "MW"),
                     use_container_width=True, key="sim_power")
    st.plotly_chart(charts.timeline_chart(df, ["pue"], "PUE Over Time"), use_container_width=True, key="sim_pue")
    st.plotly_chart(charts.timeline_chart(df, ["temperature_c"], "Ambient Temperature", "°C"),
                     use_container_width=True, key="sim_temp")
    st.plotly_chart(charts.timeline_chart(df, ["cost"], "Hourly Cost", "$"), use_container_width=True, key="sim_cost")


# ---------------------------------------------------------------------------
# 12 REPORT
# ---------------------------------------------------------------------------

def render_report(dc) -> None:
    results = dc.compute_results()
    st.subheader(f"Engineering Report — {dc.name}")
    st.caption(dc.assumptions and "Conceptual engineering simulation — not a substitute for detailed engineering design.")

    kpi_strip(dc)

    st.markdown("### Validation & Alerts")
    for a in results.alerts:
        icon = {"CRITICAL": "🔴", "WARNING": "🟠", "INFO": "🔵"}.get(a.severity, "⚪")
        st.write(f"{icon} **[{a.severity}] {a.code}** ({a.subsystem}) — {a.message}")

    st.markdown("### AI Design Assistant Recommendations")
    for rec in ASSISTANT.recommendations(dc):
        with st.expander(rec.title):
            st.write(f"**WHY:** {rec.why}")
            st.write(f"**EXPECTED IMPACT:** {rec.expected_impact}")
            st.write(f"**RISK:** {rec.risk}")
            if rec.apply is not None:
                if st.button("APPLY CHANGE", key=f"apply_{hash(rec.title)}"):
                    rec.apply(dc)
                    st.rerun()

    st.markdown("### Export")
    c1, c2, c3, c4 = st.columns(4)
    export_dir = "/tmp"
    if c1.button("Export JSON"):
        path = dc.export(f"{export_dir}/{dc.name.replace(' ', '_')}.json")
        st.success(f"Saved {path}")
    if c2.button("Export CSV"):
        path = dc.export(f"{export_dir}/{dc.name.replace(' ', '_')}.csv")
        st.success(f"Saved {path}")
    if c3.button("Export Excel"):
        path = dc.export(f"{export_dir}/{dc.name.replace(' ', '_')}.xlsx")
        st.success(f"Saved {path}")
    if c4.button("Export PDF"):
        path = dc.export(f"{export_dir}/{dc.name.replace(' ', '_')}.pdf")
        st.success(f"Saved {path}")


STAGES = [
    ("01 SITE", render_site),
    ("02 BUILDING", render_building),
    ("03 FLOOR PLAN", render_floorplan_stage),
    ("04 COMPUTE", render_compute),
    ("05 POWER", render_power),
    ("06 COOLING", render_cooling),
    ("07 NETWORK", render_network),
    ("08 ENERGY", render_energy),
    ("09 ECONOMICS", render_economics),
    ("10 OPTIMISE", render_optimise),
    ("11 SIMULATE", render_simulate),
    ("12 REPORT", render_report),
]
