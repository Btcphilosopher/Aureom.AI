"""Economics package: CAPEX, OPEX, revenue and blended financial metrics."""
