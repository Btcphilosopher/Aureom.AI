"""
OPEX model (section 24).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class OpexBreakdown:
    electricity: float = 0.0
    water: float = 0.0
    fuel: float = 0.0
    maintenance: float = 0.0
    staff: float = 0.0
    network: float = 0.0
    cooling: float = 0.0
    insurance: float = 0.0
    land: float = 0.0
    other: float = 0.0

    @property
    def total(self) -> float:
        return (
            self.electricity + self.water + self.fuel + self.maintenance + self.staff
            + self.network + self.cooling + self.insurance + self.land + self.other
        )

    def as_dict(self) -> dict[str, float]:
        return {
            "Electricity": self.electricity, "Water": self.water, "Fuel": self.fuel,
            "Maintenance": self.maintenance, "Staff": self.staff, "Network": self.network,
            "Cooling": self.cooling, "Insurance": self.insurance, "Land": self.land, "Other": self.other,
        }


def compute_opex(
    annual_electricity_cost: float,
    annual_water_m3: float,
    annual_fuel_test_l: float,
    capex_total: float,
    staff_count: int,
    staff_avg_salary: float,
    rack_count: int,
    assumptions: dict,
    water_cost_per_m3: float | None = None,
) -> OpexBreakdown:
    water_cost = (water_cost_per_m3 if water_cost_per_m3 is not None
                  else assumptions.get("water_cost_per_m3", 2.5))
    return OpexBreakdown(
        electricity=annual_electricity_cost,
        water=annual_water_m3 * water_cost,
        fuel=annual_fuel_test_l * 1.1,  # diesel price per litre for periodic testing
        maintenance=capex_total * assumptions.get("maintenance_fraction_of_capex", 0.02),
        staff=staff_count * staff_avg_salary,
        network=rack_count * 600.0,     # representative annual connectivity/circuit cost per rack
        cooling=0.0,  # cooling electricity already folded into `electricity`; kept for schedule completeness
        insurance=capex_total * assumptions.get("insurance_fraction_of_capex", 0.0035),
        land=0.0,
        other=capex_total * 0.002,
    )
