"""
CAPEX model (section 24).

Representative unit costs (USD), transparently declared as ``UNIT_COSTS`` so
they can be overridden per-design, driving a category-by-category capital
cost breakdown from the resolved facility design.
"""

from __future__ import annotations

from dataclasses import dataclass, field

UNIT_COSTS = {
    "land_per_m2": 120.0,
    "building_per_m2": 2_200.0,
    "structure_per_m2": 650.0,
    "electrical_per_kw_it": 850.0,
    "transformer_per_mva": 180_000.0,
    "ups_per_kva": 320.0,
    "generator_per_mw": 450_000.0,
    "cooling_air_per_kw_it": 350.0,
    "cooling_liquid_per_kw_it": 550.0,
    "networking_per_rack": 18_000.0,
    "server_per_unit": 9_000.0,
    "gpu_per_unit": 28_000.0,
    "rack_shell_per_rack": 6_000.0,
    "battery_per_mwh": 280_000.0,
    "solar_per_mw": 750_000.0,
    "security_per_m2": 25.0,
    "fire_systems_per_m2": 45.0,
}


@dataclass
class CapexBreakdown:
    land: float = 0.0
    building: float = 0.0
    structure: float = 0.0
    electrical: float = 0.0
    transformers: float = 0.0
    ups: float = 0.0
    generators: float = 0.0
    cooling: float = 0.0
    networking: float = 0.0
    servers: float = 0.0
    gpu: float = 0.0
    racks: float = 0.0
    battery: float = 0.0
    solar: float = 0.0
    security: float = 0.0
    fire_systems: float = 0.0
    engineering: float = 0.0
    contingency: float = 0.0

    @property
    def subtotal(self) -> float:
        return (
            self.land + self.building + self.structure + self.electrical + self.transformers
            + self.ups + self.generators + self.cooling + self.networking + self.servers
            + self.gpu + self.racks + self.battery + self.solar + self.security + self.fire_systems
        )

    @property
    def total(self) -> float:
        return self.subtotal + self.engineering + self.contingency

    def as_dict(self) -> dict[str, float]:
        return {
            "Land": self.land, "Building": self.building, "Structure": self.structure,
            "Electrical": self.electrical, "Transformers": self.transformers, "UPS": self.ups,
            "Generators": self.generators, "Cooling": self.cooling, "Networking": self.networking,
            "Servers": self.servers, "GPU": self.gpu, "Racks": self.racks, "Battery": self.battery,
            "Solar": self.solar, "Security": self.security, "Fire Systems": self.fire_systems,
            "Engineering": self.engineering, "Contingency": self.contingency,
        }


def compute_capex(
    site_area_m2: float,
    gross_floor_area_m2: float,
    it_load_kw: float,
    liquid_cooled_fraction: float,
    transformer_capacity_mva: float,
    ups_capacity_kva: float,
    generator_capacity_mw: float,
    rack_count: int,
    server_count: int,
    gpu_count: int,
    battery_capacity_mwh: float,
    solar_capacity_mw: float,
    assumptions: dict,
    unit_costs: dict | None = None,
) -> CapexBreakdown:
    uc = {**UNIT_COSTS, **(unit_costs or {})}

    cooling_cost = it_load_kw * (
        liquid_cooled_fraction * uc["cooling_liquid_per_kw_it"]
        + (1 - liquid_cooled_fraction) * uc["cooling_air_per_kw_it"]
    )

    b = CapexBreakdown(
        land=site_area_m2 * uc["land_per_m2"],
        building=gross_floor_area_m2 * uc["building_per_m2"],
        structure=gross_floor_area_m2 * uc["structure_per_m2"],
        electrical=it_load_kw * uc["electrical_per_kw_it"],
        transformers=transformer_capacity_mva * uc["transformer_per_mva"],
        ups=ups_capacity_kva * uc["ups_per_kva"],
        generators=generator_capacity_mw * uc["generator_per_mw"],
        cooling=cooling_cost,
        networking=rack_count * uc["networking_per_rack"],
        servers=server_count * uc["server_per_unit"],
        gpu=gpu_count * uc["gpu_per_unit"],
        racks=rack_count * uc["rack_shell_per_rack"],
        battery=battery_capacity_mwh * uc["battery_per_mwh"],
        solar=solar_capacity_mw * uc["solar_per_mw"],
        security=gross_floor_area_m2 * uc["security_per_m2"],
        fire_systems=gross_floor_area_m2 * uc["fire_systems_per_m2"],
    )
    b.engineering = b.subtotal * assumptions.get("engineering_fraction", 0.06)
    b.contingency = (b.subtotal + b.engineering) * assumptions.get("contingency_fraction", 0.10)
    return b
