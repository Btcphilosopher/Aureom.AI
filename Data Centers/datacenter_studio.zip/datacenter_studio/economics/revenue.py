"""
Revenue model (section 25). Deliberately independent of the engineering
simulation — a commercial overlay on top of the physical design.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.models import FinancialModel


@dataclass
class RevenueResult:
    annual_revenue: float
    annual_opex: float
    gross_margin: float
    ebitda: float


def annual_revenue(
    financial: FinancialModel,
    gpu_count: int,
    server_count: int,
    rack_count: int,
    it_load_kw: float,
) -> float:
    hours_per_year = 8760.0
    gpu_revenue = gpu_count * financial.gpu_rental_price_per_hour * hours_per_year * financial.utilisation
    server_revenue = server_count * financial.server_rental_price_per_month * 12.0 * financial.utilisation
    rack_revenue = rack_count * financial.rack_rental_price_per_month * 12.0 * financial.utilisation
    power_revenue = it_load_kw * financial.power_price_per_kwh * hours_per_year * financial.utilisation
    # Avoid double counting: use GPU-led revenue when GPUs are present, else server/rack blend.
    if gpu_count > 0:
        return gpu_revenue + power_revenue * 0.15
    return max(server_revenue, rack_revenue) + power_revenue * 0.15


def compute_revenue_result(
    financial: FinancialModel,
    gpu_count: int,
    server_count: int,
    rack_count: int,
    it_load_kw: float,
    annual_opex: float,
) -> RevenueResult:
    rev = annual_revenue(financial, gpu_count, server_count, rack_count, it_load_kw)
    gross_margin = rev - annual_opex
    ebitda = gross_margin  # simplified: no separate SG&A/D&A layer at this stage
    return RevenueResult(
        annual_revenue=rev,
        annual_opex=annual_opex,
        gross_margin=gross_margin,
        ebitda=ebitda,
    )
