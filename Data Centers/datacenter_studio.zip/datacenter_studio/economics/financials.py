"""
Blended financial metrics (sections 24-25): TCO, cost/MW, cost/rack, cost/kW,
cost/GPU, NPV, IRR, payback, cash flow, ROI.

NPV/IRR are implemented directly (bisection-based IRR) to avoid a dependency
on the (deprecated/optional) ``numpy-financial`` package.
"""

from __future__ import annotations

from dataclasses import dataclass


def npv(discount_rate: float, cash_flows: list[float]) -> float:
    """cash_flows[0] is t=0 (typically -CAPEX)."""
    return sum(cf / (1.0 + discount_rate) ** t for t, cf in enumerate(cash_flows))


def irr(cash_flows: list[float], low: float = -0.99, high: float = 5.0, tol: float = 1e-6,
        max_iter: int = 200) -> float | None:
    """Bisection search for the discount rate that zeroes NPV. Returns None
    if no sign change is found in [low, high] (no real IRR in range)."""
    f_low = npv(low, cash_flows)
    f_high = npv(high, cash_flows)
    if f_low * f_high > 0:
        return None
    for _ in range(max_iter):
        mid = (low + high) / 2.0
        f_mid = npv(mid, cash_flows)
        if abs(f_mid) < tol:
            return mid
        if f_low * f_mid < 0:
            high = mid
            f_high = f_mid
        else:
            low = mid
            f_low = f_mid
    return (low + high) / 2.0


def payback_period_years(cash_flows: list[float]) -> float | None:
    """Simple (non-discounted) payback period, cash_flows[0] = -CAPEX."""
    cumulative = 0.0
    for t, cf in enumerate(cash_flows):
        prev_cumulative = cumulative
        cumulative += cf
        if cumulative >= 0 and t > 0:
            # linear interpolation within the year the balance turns positive
            fraction = -prev_cumulative / cf if cf != 0 else 0.0
            return (t - 1) + fraction
    return None


def roi(total_net_profit: float, total_investment: float) -> float:
    if total_investment <= 0:
        return 0.0
    return total_net_profit / total_investment


@dataclass
class FinancialSummary:
    capex: float
    annual_opex: float
    annual_revenue: float
    tco_years: float
    tco: float
    cost_per_mw: float
    cost_per_rack: float
    cost_per_kw: float
    cost_per_gpu: float
    npv: float
    irr: float | None
    payback_years: float | None
    roi_pct: float
    cash_flows: list[float]


def compute_financial_summary(
    capex: float,
    annual_opex: float,
    annual_revenue: float,
    it_load_mw: float,
    rack_count: int,
    gpu_count: int,
    discount_rate: float,
    horizon_years: int = 15,
) -> FinancialSummary:
    it_load_kw = it_load_mw * 1000.0
    tco = capex + annual_opex * horizon_years
    cash_flows = [-capex] + [annual_revenue - annual_opex for _ in range(horizon_years)]
    total_profit = sum(cash_flows[1:]) - 0  # profits only, capex excluded from "profit"
    return FinancialSummary(
        capex=capex,
        annual_opex=annual_opex,
        annual_revenue=annual_revenue,
        tco_years=horizon_years,
        tco=tco,
        cost_per_mw=capex / it_load_mw if it_load_mw else 0.0,
        cost_per_rack=capex / rack_count if rack_count else 0.0,
        cost_per_kw=capex / it_load_kw if it_load_kw else 0.0,
        cost_per_gpu=capex / gpu_count if gpu_count else 0.0,
        npv=npv(discount_rate, cash_flows),
        irr=irr(cash_flows),
        payback_years=payback_period_years(cash_flows),
        roi_pct=100.0 * roi(total_profit, capex),
        cash_flows=cash_flows,
    )
