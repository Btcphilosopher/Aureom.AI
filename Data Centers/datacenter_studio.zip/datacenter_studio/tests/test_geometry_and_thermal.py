import pytest

from compute.racks import facility_compute_totals
from core.datacenter import DataCenter
from core.models import Transformer, UPS, Generator
from geometry.building import add_floor
from geometry.floor import generate_floor_plan
from geometry.site import site_summary


def test_generate_floor_plan_creates_expected_rack_count():
    dc = DataCenter(name="Geometry Test")
    dc.building.floors = []
    floor = add_floor(dc.building, layout_template="high_density_gpu")
    floor.width_m = 100.0
    floor.length_m = 100.0
    generate_floor_plan(floor, rack_count=50, avg_density_kw=10.0,
                         high_density_fraction=0.4, high_density_kw=80.0, seed=1)
    assert len(floor.racks) == 50
    liquid_racks = [r for r in floor.racks if r.cooling_type == "direct_liquid"]
    assert len(liquid_racks) > 0
    for r in liquid_racks:
        assert r.rack_it_load_kw > 40.0  # should be near the high-density band


def test_facility_compute_totals_matches_rack_sum():
    dc = DataCenter(name="Geometry Test 2")
    dc.building.floors = []
    floor = add_floor(dc.building)
    floor.width_m = 80.0
    floor.length_m = 80.0
    generate_floor_plan(floor, rack_count=20, avg_density_kw=8.0, seed=2)

    totals = facility_compute_totals(dc.building)
    manual_sum = sum(r.rack_it_load_kw for r in floor.racks)
    assert totals["total_it_load_kw"] == pytest.approx(manual_sum)
    assert totals["rack_count"] == 20


def test_rack_thermal_profile_flags_hotspots_for_dense_air_racks():
    dc = DataCenter(name="Thermal Test")
    dc.building.floors = []
    floor = add_floor(dc.building)
    floor.width_m = 80.0
    floor.length_m = 80.0
    # Force every rack to be a dense air-cooled rack well above the air limit.
    generate_floor_plan(floor, rack_count=10, avg_density_kw=35.0,
                         high_density_fraction=0.0, seed=3)
    for r in floor.racks:
        r.cooling_type = "air"

    profile = dc.rack_thermal()
    assert any(p.status == "HOTSPOT" for p in profile)


def test_site_summary_keys():
    dc = DataCenter()
    summary = site_summary(dc.site)
    for key in ["site_area_m2", "site_utilisation_pct", "expansion_area_m2"]:
        assert key in summary


def test_datacenter_with_detailed_racks_produces_consistent_results():
    dc = DataCenter(name="Detailed Rack DC")
    dc.building.floors = []
    floor = add_floor(dc.building, layout_template="hot_aisle_cold_aisle")
    floor.width_m = 90.0
    floor.length_m = 90.0
    generate_floor_plan(floor, rack_count=40, avg_density_kw=10.0,
                         high_density_fraction=0.2, high_density_kw=60.0, seed=4)
    dc.power.ups_units = [UPS(capacity_kva=1000.0) for _ in range(4)]
    dc.power.transformers = [Transformer(capacity_mva=10.0) for _ in range(2)]
    dc.power.generators = [Generator(capacity_mw=1.5) for _ in range(4)]
    dc.cooling.cooling_capacity_kw = 5000.0

    results = dc.compute_results()
    assert results.rack_count == 40
    assert results.it_load_mw > 0
    assert results.pue >= 1.0
