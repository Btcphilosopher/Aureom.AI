from core.units import (
    c_to_f,
    c_to_k,
    calculate_pue,
    cfm_to_m3s,
    kw_to_kva,
    kwh_to_kw,
    m3s_to_cfm,
    mw_to_kw,
)


def test_calculate_pue_known_value():
    assert calculate_pue(125, 100) == 1.25


def test_mw_kw_roundtrip():
    assert mw_to_kw(1.0) == 1000.0
    assert mw_to_kw(2.5) == 2500.0


def test_c_to_k():
    assert c_to_k(0) == 273.15
    assert c_to_k(100) == 373.15


def test_c_to_f():
    assert c_to_f(0) == 32.0
    assert c_to_f(100) == 212.0


def test_kw_to_kva():
    assert kw_to_kva(95, power_factor=0.95) == 100.0


def test_kwh_to_kw():
    assert kwh_to_kw(100, 4) == 25.0
    assert kwh_to_kw(100, 0) == 0.0


def test_cfm_m3s_roundtrip():
    m3s = cfm_to_m3s(1000)
    back = m3s_to_cfm(m3s)
    assert abs(back - 1000) < 1e-6
