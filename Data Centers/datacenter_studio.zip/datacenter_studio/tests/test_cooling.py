import pytest

from cooling.chiller import chiller_electrical_kw, effective_cop, is_free_cooling_available
from cooling.cooling_tower import water_consumption_m3_per_hour
from cooling.heat_recovery import evaluate_heat_recovery
from cooling.hvac import evaluate_airflow, required_airflow_m3_s
from cooling.liquid_cooling import evaluate_liquid_cooling


def test_chiller_electrical_known_value():
    # 1000 kW cooling load at COP 5.0 -> 200 kW electrical
    assert chiller_electrical_kw(1000.0, 5.0) == pytest.approx(200.0)


def test_effective_cop_improves_in_cooler_weather():
    base = 5.5
    cop_cool = effective_cop(base, ambient_wetbulb_c=10.0, design_wetbulb_c=24.0)
    cop_hot = effective_cop(base, ambient_wetbulb_c=30.0, design_wetbulb_c=24.0)
    assert cop_cool > base > cop_hot


def test_free_cooling_availability():
    assert is_free_cooling_available(8.0, threshold_c=12.0) is True
    assert is_free_cooling_available(18.0, threshold_c=12.0) is False


def test_required_airflow_known_value():
    # Q = rho * V * cp * dT  =>  V = Q / (rho * cp * dT)
    airflow = required_airflow_m3_s(heat_load_kw=100.0, delta_t_c=10.0)
    assert airflow == pytest.approx(100.0 / (1.2 * 1.005 * 10.0), rel=1e-6)


def test_evaluate_airflow_flags_undersized_cooling():
    result = evaluate_airflow(total_heat_kw=1000.0, cooling_capacity_kw=500.0,
                               supply_temp_c=18.0, crah_delta_t_c=10.0)
    assert "COOLING UNDERSIZED" in result.flags


def test_evaluate_airflow_nominal():
    result = evaluate_airflow(total_heat_kw=1000.0, cooling_capacity_kw=1200.0,
                               supply_temp_c=18.0, crah_delta_t_c=10.0)
    assert "COOLING UNDERSIZED" not in result.flags


def test_water_consumption_positive():
    water = water_consumption_m3_per_hour(heat_rejected_kw=1000.0)
    assert water > 0


def test_liquid_cooling_removes_expected_heat():
    result = evaluate_liquid_cooling(
        rack_heat_kw=100.0, coolant_supply_temp_c=20.0, coolant_return_temp_c=30.0,
        heat_exchanger_efficiency=0.85, capture_fraction=0.85, pump_efficiency=0.8,
    )
    assert result.heat_removed_kw == pytest.approx(85.0)
    assert result.coolant_flow_rate_l_s > 0


def test_heat_recovery_disabled_returns_zero():
    result = evaluate_heat_recovery(1000.0, enabled=False, assumptions={})
    assert result.recovered_heat_kw == 0.0


def test_heat_recovery_enabled_returns_positive():
    result = evaluate_heat_recovery(1000.0, enabled=True,
                                     assumptions={"heat_recovery_max_fraction": 0.5, "heat_recovery_efficiency": 0.65})
    assert result.recovered_heat_kw == pytest.approx(1000.0 * 0.5 * 0.65)
