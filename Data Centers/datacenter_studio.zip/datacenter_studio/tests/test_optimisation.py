import pytest

from core.datacenter import DataCenter
from optimisation.optimiser import GridOptimizer, RandomSearchOptimizer, optimise_design
from optimisation.scenarios import PRESET_SCENARIOS, pareto_frontier, run_scenario


def make_dc() -> DataCenter:
    dc = DataCenter(name="Opt Test DC")
    dc.compute.it_load_mw = 8.0
    dc.cooling.cooling_capacity_kw = 25_000.0
    return dc


def test_random_search_improves_or_matches_baseline():
    dc = make_dc()
    baseline_score = dc.compute_results().pue
    result = optimise_design(dc, method="random", iterations=15)
    assert result.best_results.pue <= baseline_score + 0.5  # sanity bound, not strict improvement
    assert result.best_design is not dc


def test_grid_optimizer_runs_and_returns_best():
    dc = make_dc()
    space = {"solar_capacity_mw": (0.0, 5.0), "battery_capacity_mwh": (0.0, 10.0)}
    result = optimise_design(dc, method="grid", param_space=space, steps=3)
    assert result.best_params
    assert result.iterations == 3 * 3


def test_genetic_optimizer_small_run():
    dc = make_dc()
    space = {"solar_capacity_mw": (0.0, 5.0)}
    result = optimise_design(dc, method="genetic", param_space=space, generations=3, population_size=6)
    assert "solar_capacity_mw" in result.best_params


def test_unknown_optimiser_raises():
    dc = make_dc()
    with pytest.raises(ValueError):
        optimise_design(dc, method="not_a_real_method")


def test_scenario_runs_without_error():
    dc = make_dc()
    trial, results = run_scenario(dc, PRESET_SCENARIOS["hot_summer"])
    assert results.it_load_mw == pytest.approx(dc.compute_results().it_load_mw)
    assert trial.cooling.ambient_temperature_c > dc.cooling.ambient_temperature_c


def test_pareto_frontier_selects_non_dominated():
    class R:
        def __init__(self, capex, pue):
            self.capex = capex
            self.pue = pue

    candidates = [R(100, 1.5), R(90, 1.6), R(120, 1.2), R(200, 1.9)]
    frontier = pareto_frontier(candidates, minimise=["capex", "pue"], maximise=[])
    # (200, 1.9) is dominated by (100, 1.5) on both axes -> excluded
    assert 3 not in frontier
    assert 0 in frontier or 2 in frontier
