import pytest

from config.constants import ASSUMPTIONS
from core.models import FinancialModel
from economics.capex import compute_capex
from economics.financials import irr, npv, payback_period_years
from economics.opex import compute_opex
from economics.revenue import annual_revenue, compute_revenue_result


def test_compute_capex_positive_and_includes_contingency():
    breakdown = compute_capex(
        site_area_m2=100_000, gross_floor_area_m2=20_000, it_load_kw=10_000,
        liquid_cooled_fraction=0.5, transformer_capacity_mva=40.0, ups_capacity_kva=4000.0,
        generator_capacity_mw=10.0, rack_count=500, server_count=8000, gpu_count=2000,
        battery_capacity_mwh=20.0, solar_capacity_mw=5.0, assumptions=ASSUMPTIONS,
    )
    assert breakdown.total > breakdown.subtotal
    assert breakdown.contingency > 0
    assert breakdown.servers == 8000 * 9000.0


def test_compute_opex_scales_with_capex():
    opex_small = compute_opex(100_000, 1000, 500, capex_total=10_000_000, staff_count=10,
                               staff_avg_salary=90_000, rack_count=100, assumptions=ASSUMPTIONS)
    opex_large = compute_opex(100_000, 1000, 500, capex_total=100_000_000, staff_count=10,
                               staff_avg_salary=90_000, rack_count=100, assumptions=ASSUMPTIONS)
    assert opex_large.maintenance > opex_small.maintenance


def test_annual_revenue_gpu_led():
    fm = FinancialModel(gpu_rental_price_per_hour=2.0, utilisation=1.0, power_price_per_kwh=0.0)
    rev = annual_revenue(fm, gpu_count=100, server_count=0, rack_count=0, it_load_kw=0)
    assert rev == pytest.approx(100 * 2.0 * 8760.0)


def test_npv_zero_rate_equals_sum():
    flows = [-100, 50, 50, 50]
    assert npv(0.0, flows) == pytest.approx(50.0)


def test_irr_known_value():
    # -100 now, +110 in one year -> IRR should be ~10%
    flows = [-100, 110]
    rate = irr(flows)
    assert rate == pytest.approx(0.10, abs=0.001)


def test_payback_period():
    flows = [-100, 40, 40, 40, 40]
    payback = payback_period_years(flows)
    assert payback == pytest.approx(2.5, abs=0.01)


def test_revenue_result_ebitda_matches_gross_margin():
    fm = FinancialModel(gpu_rental_price_per_hour=1.0, utilisation=1.0, power_price_per_kwh=0.0)
    result = compute_revenue_result(fm, gpu_count=10, server_count=0, rack_count=0,
                                     it_load_kw=0, annual_opex=1000.0)
    assert result.ebitda == pytest.approx(result.annual_revenue - 1000.0)
