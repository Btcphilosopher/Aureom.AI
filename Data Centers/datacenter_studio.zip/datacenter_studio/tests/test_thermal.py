from cooling.thermal import heatmap_zone


def test_heatmap_zone_boundaries():
    assert heatmap_zone(10) == "BLUE"
    assert heatmap_zone(20) == "GREEN"
    assert heatmap_zone(25) == "YELLOW"
    assert heatmap_zone(29) == "ORANGE"
    assert heatmap_zone(35) == "RED"
