import pytest

from core.models import Battery, Generator, PowerSystem, Transformer, UPS
from power.battery import BatteryState, backup_time_minutes, dispatch_step
from power.generator import fuel_consumption_l_per_hour, generator_loading_pct
from power.power_distribution import check_redundancy, compute_power_chain
from power.transformer import transformer_loading_pct, transformer_losses_kw
from power.ups import ups_loading_pct, ups_losses_kw


def test_transformer_losses_known_value():
    # 1000 kW load at 98.5% efficiency -> ~15.2 kW loss
    losses = transformer_losses_kw(1000.0, 0.985)
    assert losses == pytest.approx(15.228, abs=0.01)


def test_transformer_loading_pct():
    ps = PowerSystem(transformers=[Transformer(capacity_mva=10.0)])
    # 9500 kW load at pf=0.95 -> 10,000 kVA -> exactly 100% of a 10 MVA transformer
    pct = transformer_loading_pct(ps, 9500.0, power_factor=0.95)
    assert pct == pytest.approx(100.0, abs=0.01)


def test_ups_losses_known_value():
    losses = ups_losses_kw(960.0, 0.96)
    assert losses == pytest.approx(40.0, abs=0.01)


def test_ups_loading_pct():
    ps = PowerSystem(ups_units=[UPS(capacity_kva=1000.0)])
    pct = ups_loading_pct(ps, 475.0, power_factor=0.95)
    assert pct == pytest.approx(50.0, abs=0.1)


def test_generator_fuel_consumption_scales_with_load():
    gens = [Generator(capacity_mw=2.0, fuel_consumption_l_per_kwh=0.26, minimum_load_fraction=0.0)]
    fuel = fuel_consumption_l_per_hour(gens, load_mw=1.0)
    assert fuel == pytest.approx(1000.0 * 0.26, abs=0.1)


def test_generator_loading_pct():
    gens = [Generator(capacity_mw=2.0), Generator(capacity_mw=2.0)]
    assert generator_loading_pct(gens, load_mw=2.0) == pytest.approx(50.0)


def test_power_chain_losses_positive_and_it_load_preserved():
    assumptions = {
        "pdu_efficiency": 0.99, "busway_loss_fraction": 0.01, "ups_efficiency": 0.96,
        "lv_switchgear_loss_fraction": 0.003, "transformer_efficiency": 0.985,
        "mv_switchgear_loss_fraction": 0.002, "cabling_loss_fraction": 0.01,
    }
    result = compute_power_chain(1000.0, assumptions)
    assert result.it_load_kw == 1000.0
    assert result.total_losses_kw > 0
    assert result.facility_input_kw > result.it_load_kw
    # Chain should read Grid -> ... -> ... -> (last stage's output == IT load)
    assert result.stages[0].name == "Grid Cabling"
    assert result.stages[-1].output_kw == pytest.approx(1000.0, abs=0.01)


def test_redundancy_check_n_plus_1_fails_with_single_unit():
    ps = PowerSystem(redundancy="N+1", ups_units=[UPS(capacity_kva=1000.0)],
                      generators=[Generator(capacity_mw=1.0)])
    assert check_redundancy(ps, critical_load_kw=500.0) is False


def test_redundancy_check_n_plus_1_passes_with_spare_capacity():
    ps = PowerSystem(redundancy="N+1",
                      ups_units=[UPS(capacity_kva=1000.0), UPS(capacity_kva=1000.0), UPS(capacity_kva=1000.0)],
                      generators=[Generator(capacity_mw=1.0), Generator(capacity_mw=1.0), Generator(capacity_mw=1.0)])
    # After removing the largest single unit, 2 remain: 2000 kVA * 0.95 = 1900 kW >= 900 kW critical load
    assert check_redundancy(ps, critical_load_kw=900.0) is True


def test_battery_dispatch_charges_from_surplus():
    state = BatteryState(capacity_mwh=10.0, power_mw=5.0, round_trip_efficiency=0.9, soc=0.2)
    result = dispatch_step(state, net_load_mw=0.0, renewable_surplus_mw=3.0, dt_hours=1.0)
    assert result.charge_mw > 0
    assert state.soc > 0.2


def test_battery_backup_time_minutes():
    minutes = backup_time_minutes(capacity_mwh=2.0, load_mw=4.0, usable_fraction=1.0)
    assert minutes == pytest.approx(30.0)
