import pytest

from ai.design_reasoning import parse_design_brief, parse_iteration_command
from ai.recommendations import generate_recommendations
from core.datacenter import DataCenter


def test_parse_design_brief_extracts_mw_and_redundancy():
    spec = parse_design_brief(
        "Design a 20 MW AI data center with 200 kW liquid-cooled racks, "
        "N+1 power redundancy, 30% solar generation and battery storage."
    )
    assert spec.it_load_mw == 20.0
    assert spec.rack_density_kw == 200.0
    assert spec.liquid_cooling is True
    # Regression: a word simply *ending* in "n" (e.g. "design") must never
    # be mistaken for a bare "N" redundancy mention.
    assert spec.redundancy == "N+1"
    assert spec.solar_fraction == pytest.approx(0.30)
    assert spec.battery_mwh == 20.0


def test_parse_design_brief_bare_n_redundancy():
    spec = parse_design_brief("A small facility with N redundancy and no renewables.")
    assert spec.redundancy == "N"


def test_parse_design_brief_2n_plus_1():
    spec = parse_design_brief("A mission-critical facility at 2N+1 redundancy.")
    assert spec.redundancy == "2N+1"


def test_parse_iteration_command_reduce_pue():
    proposal = parse_iteration_command("Reduce PUE.")
    assert proposal.objective_weights is not None
    assert proposal.objective_weights.get("pue", 0) > 0


def test_parse_iteration_command_hotter_climate_has_direct_apply():
    proposal = parse_iteration_command("Prepare this for a hotter climate.")
    assert proposal.apply is not None
    dc = DataCenter()
    before = dc.cooling.ambient_temperature_c
    proposal.apply(dc)
    assert dc.cooling.ambient_temperature_c == pytest.approx(before + 8.0)


def test_parse_iteration_command_unrecognised():
    proposal = parse_iteration_command("asdkjalksjdlkasjd nonsense")
    assert not proposal.changes
    assert proposal.objective_weights is None


def test_recommendations_always_return_at_least_one():
    dc = DataCenter()
    dc.compute.it_load_mw = 5.0
    results = dc.compute_results()
    recs = generate_recommendations(dc, results)
    assert len(recs) >= 1
    for r in recs:
        assert r.title and r.why and r.expected_impact and r.risk
