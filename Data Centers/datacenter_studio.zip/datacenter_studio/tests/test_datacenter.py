import pytest

from core.datacenter import DataCenter
from core.validation import validate_design


def make_simple_dc() -> DataCenter:
    dc = DataCenter(name="Test DC")
    dc.compute.it_load_mw = 5.0
    dc.cooling.cooling_capacity_kw = 15_000.0
    dc.site.grid_capacity_mw = 50.0
    # The default DataCenter() power system is sized for a small facility;
    # bump UPS/transformer capacity so a clean 5 MW design has no CRITICAL
    # loading alerts (this helper is meant to be an otherwise-valid design).
    for u in dc.power.ups_units:
        u.capacity_kva = 3000.0
    for t in dc.power.transformers:
        t.capacity_mva = 25.0
    return dc


def test_compute_results_basic_consistency():
    dc = make_simple_dc()
    results = dc.compute_results()
    assert results.it_load_mw == pytest.approx(5.0)
    assert results.facility_load_mw > results.it_load_mw  # PUE > 1
    assert results.pue >= 1.0
    assert results.capex > 0
    assert results.rack_count > 0


def test_pue_greater_than_one_and_finite():
    dc = make_simple_dc()
    results = dc.compute_results()
    assert 1.0 <= results.pue <= 3.0


def test_validation_flags_insufficient_cooling():
    dc = make_simple_dc()
    dc.cooling.cooling_capacity_kw = 100.0  # deliberately tiny
    results = dc.compute_results()
    codes = [a.code for a in results.alerts]
    assert "CLG-001" in codes
    severities = [a.severity for a in results.alerts]
    assert "CRITICAL" in severities


def test_validation_clean_design_has_no_critical_alerts():
    dc = make_simple_dc()
    results = dc.compute_results()
    criticals = [a for a in results.alerts if a.severity == "CRITICAL"]
    assert criticals == []


def test_clone_is_independent():
    dc = make_simple_dc()
    clone = dc.clone("Clone")
    clone.compute.it_load_mw = 999.0
    assert dc.compute.it_load_mw == 5.0
    assert clone.compute.it_load_mw == 999.0


def test_simulate_returns_consistent_summary():
    dc = make_simple_dc()
    result = dc.simulate(hours=48)
    assert len(result.dataframe) == 48
    assert result.pue >= 1.0
    assert result.capex == pytest.approx(dc.compute_results().capex)


def test_kpi_header_has_expected_keys():
    dc = make_simple_dc()
    header = dc.compute_results().kpi_header()
    for key in ["IT LOAD", "PUE", "CAPEX", "ANNUAL OPEX", "CARBON"]:
        assert key in header
