"""
DATACENTER.STUDIO — application entry point.

Run with:

    streamlit run app.py

This module wires the Streamlit UI (dashboard + guided 12-stage design
workflow) to the pure-Python engineering core. All computation lives in
``core``/``geometry``/``compute``/``power``/``cooling``/``network``/
``energy``/``economics``/``optimisation``/``simulation`` — this file is UI
plumbing only.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import streamlit as st

from config.settings import SETTINGS, configure_logging
from data.default_profiles import build_demo_datacenter, build_demo_scenarios
from ui.dashboard import render_dashboard
from ui.designer import render_designer

configure_logging()

st.set_page_config(
    page_title=SETTINGS.app_name,
    page_icon="🖥️",
    layout="wide",
    initial_sidebar_state="expanded",
)

DARK_CSS = """
<style>
    .stApp { background-color: #0b0e14; }
    section[data-testid="stSidebar"] { background-color: #0e1119; }
    div[data-testid="stMetric"] {
        background-color: #11151f; border: 1px solid #232838; border-radius: 4px;
        padding: 8px 10px;
    }
    div[data-testid="stMetricValue"] { font-family: 'IBM Plex Mono', monospace; }
    .stButton>button { border-radius: 3px; font-family: monospace; }
    h1, h2, h3, h4, h5 { font-family: 'IBM Plex Mono', monospace; }
    code, .stCode { font-family: monospace; }
</style>
"""
st.markdown(DARK_CSS, unsafe_allow_html=True)


def _init_state() -> None:
    if "dc" not in st.session_state:
        st.session_state["dc"] = build_demo_datacenter()
    if "view" not in st.session_state:
        st.session_state["view"] = "dashboard"


def main() -> None:
    _init_state()
    dc = st.session_state["dc"]

    with st.sidebar:
        st.markdown("## 🖥️ DATACENTER.STUDIO")
        view = st.radio("View", ["Dashboard", "Design Studio"], horizontal=True, label_visibility="collapsed")
        st.session_state["view"] = "dashboard" if view == "Dashboard" else "designer"

        st.divider()
        st.markdown("### DEMO SCENARIOS")
        if st.button("Load Demo — 50MW AI Data Center", use_container_width=True):
            st.session_state["dc"] = build_demo_datacenter()
            st.rerun()
        scenario_key = st.selectbox(
            "Load scenario A-F",
            [None, "A", "B", "C", "D", "E", "F"],
            format_func=lambda k: "—" if k is None else f"Scenario {k}",
        )
        if scenario_key and st.button("Load Scenario", use_container_width=True):
            scenarios = build_demo_scenarios(dc)
            st.session_state["dc"] = scenarios[scenario_key]
            st.rerun()

    dc = st.session_state["dc"]

    if st.session_state["view"] == "dashboard":
        render_dashboard(dc)
    else:
        render_designer(dc)


if __name__ == "__main__":
    main()
