"""
DATACENTER.STUDIO
==================

AI Data Center Design, Simulation & Optimisation Platform.

A parametric, modular, simulation-driven and optimisation-driven digital-twin
prototype for data centers. This package exposes a small, clean Python API on
top of a much larger set of engineering engines (power, cooling, thermal,
network, energy, economics, optimisation).

    from datacenter_studio import DataCenter

    dc = DataCenter()
    dc.site.width_m = 300
    dc.site.length_m = 500
    dc.compute.it_load_mw = 50
    dc.cooling.cooling_type = "liquid"

    result = dc.simulate(hours=8760)
    print(result.pue)
    print(result.annual_energy_kwh)
    print(result.capex)

    dc.optimise()
    dc.export("design.json")

DISCLAIMER
----------
This is a conceptual engineering simulation intended for design exploration,
education and rapid what-if analysis. It is NOT a substitute for detailed,
certified engineering design, and must not be used as the sole basis for
construction, procurement or safety decisions.
"""

import sys as _sys
from pathlib import Path as _Path

# Every module in this codebase uses flat, top-level imports (e.g.
# ``from core.models import ...`` rather than
# ``from datacenter_studio.core.models import ...``) so the application can
# also be run directly from within this directory (``streamlit run app.py``,
# ``pytest``). To make ``import datacenter_studio`` work identically from
# the *outside* (as in the section-41 API example), we add this package's
# own directory to ``sys.path`` before pulling in any submodule.
_pkg_dir = str(_Path(__file__).resolve().parent)
if _pkg_dir not in _sys.path:
    _sys.path.insert(0, _pkg_dir)

from core.datacenter import DataCenter
from core.models import (
    Site,
    Building,
    Floor,
    Room,
    Rack,
    Server,
    GPUCluster,
    ComputeConfig,
    PowerSystem,
    Transformer,
    UPS,
    Generator,
    Battery,
    CoolingSystem,
    Chiller,
    CoolingTower,
    HeatPump,
    Network,
    EnergySystem,
    FinancialModel,
)

__version__ = "1.0.0"
__all__ = [
    "DataCenter",
    "Site",
    "Building",
    "Floor",
    "Room",
    "Rack",
    "Server",
    "GPUCluster",
    "ComputeConfig",
    "PowerSystem",
    "Transformer",
    "UPS",
    "Generator",
    "Battery",
    "CoolingSystem",
    "Chiller",
    "CoolingTower",
    "HeatPump",
    "Network",
    "EnergySystem",
    "FinancialModel",
]
