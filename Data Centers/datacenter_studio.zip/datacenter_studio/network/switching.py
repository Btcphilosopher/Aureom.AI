"""Switching layer helpers: port counts, AI-fabric high-bandwidth assumptions (section 23)."""

from __future__ import annotations

from core.models import Network

AI_FABRIC_PROFILES = {
    "infiniband_400g": {"port_gbps": 400.0, "latency_us": 1.0},
    "infiniband_800g": {"port_gbps": 800.0, "latency_us": 0.7},
    "ethernet_400g": {"port_gbps": 400.0, "latency_us": 2.5},
    "nvlink": {"port_gbps": 900.0, "latency_us": 0.3},
}


def recommend_network_for_ai(gpu_count: int) -> Network:
    """Return a Network config sized for a high-bandwidth AI cluster: one
    rail per GPU (simplified non-blocking fat-tree), 1:1 leaf-spine."""
    leaf_count = max(2, -(-gpu_count // 32))
    spine_count = max(2, leaf_count // 2)
    return Network(
        topology="fat-tree",
        internet_uplink_gbps=800.0,
        core_switch_count=2,
        spine_switch_count=spine_count,
        spine_switch_capacity_gbps=51_200.0,
        leaf_switch_count=leaf_count,
        leaf_switch_capacity_gbps=25_600.0,
        tor_uplink_gbps=3_200.0,
        server_nic_gbps=800.0,
        ai_fabric=True,
    )
