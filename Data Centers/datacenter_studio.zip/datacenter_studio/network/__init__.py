"""Network package: topology, bandwidth, switching / oversubscription model."""
