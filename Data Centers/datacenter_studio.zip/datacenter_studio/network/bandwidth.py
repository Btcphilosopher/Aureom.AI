"""Bandwidth / oversubscription calculations (section 23)."""

from __future__ import annotations

from dataclasses import dataclass

from core.models import Network


@dataclass
class NetworkResult:
    total_server_bandwidth_gbps: float
    total_uplink_bandwidth_gbps: float
    oversubscription_ratio: float
    port_utilisation_pct: float
    network_capacity_gbps: float
    ai_fabric: bool


def evaluate_network(network: Network, rack_count: int, servers_per_rack: float) -> NetworkResult:
    total_servers = rack_count * servers_per_rack
    total_server_bw = total_servers * network.server_nic_gbps
    total_uplink_bw = network.leaf_switch_count * network.tor_uplink_gbps

    oversubscription = total_server_bw / total_uplink_bw if total_uplink_bw else 0.0

    spine_capacity = network.spine_switch_count * network.spine_switch_capacity_gbps
    leaf_capacity = network.leaf_switch_count * network.leaf_switch_capacity_gbps
    network_capacity = min(spine_capacity, leaf_capacity) if spine_capacity else leaf_capacity

    port_utilisation = 100.0 * total_server_bw / max(network_capacity, 1e-6)

    return NetworkResult(
        total_server_bandwidth_gbps=round(total_server_bw, 1),
        total_uplink_bandwidth_gbps=round(total_uplink_bw, 1),
        oversubscription_ratio=round(oversubscription, 2),
        port_utilisation_pct=round(min(port_utilisation, 999.0), 1),
        network_capacity_gbps=round(network_capacity, 1),
        ai_fabric=network.ai_fabric,
    )


def port_count(rack_count: int, ports_per_rack: int) -> int:
    return rack_count * ports_per_rack
