"""
Network topology model (section 23), built on NetworkX so the graph is
inspectable/visualisable (shortest paths, degree, etc.) rather than an
opaque set of counters.
"""

from __future__ import annotations

import networkx as nx

from core.models import Network


def build_topology_graph(network: Network, rack_count: int) -> nx.Graph:
    """Build a simplified spine-leaf (or 3-tier) graph: Internet -> Core ->
    Spine -> Leaf/ToR -> Rack. One node per tier element; racks are
    aggregated behind their ToR switch (1 ToR per rack, simplified)."""
    g = nx.Graph()
    g.add_node("internet", tier="internet")
    for i in range(network.core_switch_count):
        g.add_node(f"core-{i}", tier="core")
        g.add_edge("internet", f"core-{i}", capacity_gbps=network.internet_uplink_gbps)

    if network.topology in ("spine-leaf", "fat-tree"):
        for i in range(network.spine_switch_count):
            g.add_node(f"spine-{i}", tier="spine")
            for c in range(network.core_switch_count):
                g.add_edge(f"core-{c}", f"spine-{i}", capacity_gbps=network.spine_switch_capacity_gbps)
        for i in range(network.leaf_switch_count):
            g.add_node(f"leaf-{i}", tier="leaf")
            for s in range(network.spine_switch_count):
                g.add_edge(f"spine-{s}", f"leaf-{i}", capacity_gbps=network.leaf_switch_capacity_gbps)
    else:  # 3-tier: core -> aggregation(leaf) directly
        for i in range(network.leaf_switch_count):
            g.add_node(f"leaf-{i}", tier="leaf")
            for c in range(network.core_switch_count):
                g.add_edge(f"core-{c}", f"leaf-{i}", capacity_gbps=network.leaf_switch_capacity_gbps)

    leaves = max(1, network.leaf_switch_count)
    racks_per_leaf = max(1, -(-rack_count // leaves))  # ceil division
    rack_i = 0
    for leaf_i in range(leaves):
        for _ in range(racks_per_leaf):
            if rack_i >= rack_count:
                break
            g.add_node(f"rack-{rack_i}", tier="rack")
            g.add_edge(f"leaf-{leaf_i % leaves}", f"rack-{rack_i}", capacity_gbps=network.tor_uplink_gbps)
            rack_i += 1

    return g
