"""
Generic 2D spatial helpers shared by the geometry package (section 31, 35).

Kept intentionally simple: this is not a CAD kernel, just enough
computational geometry to place racks/zones on a plan and detect overlaps
for the interactive floor-plan designer.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class Rect:
    x: float
    y: float
    w: float
    h: float

    @property
    def x2(self) -> float:
        return self.x + self.w

    @property
    def y2(self) -> float:
        return self.y + self.h

    @property
    def area(self) -> float:
        return self.w * self.h

    @property
    def center(self) -> tuple[float, float]:
        return (self.x + self.w / 2.0, self.y + self.h / 2.0)

    def overlaps(self, other: "Rect") -> bool:
        return not (
            self.x2 <= other.x
            or other.x2 <= self.x
            or self.y2 <= other.y
            or other.y2 <= self.y
        )

    def contains_point(self, px: float, py: float) -> bool:
        return self.x <= px <= self.x2 and self.y <= py <= self.y2


def distance(p1: tuple[float, float], p2: tuple[float, float]) -> float:
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


def grid_positions(
    count: int,
    origin: tuple[float, float],
    pitch_x: float,
    pitch_y: float,
    per_row: int,
) -> list[tuple[float, float]]:
    """Lay out ``count`` items on a regular grid starting at ``origin``."""
    positions = []
    for i in range(count):
        row, col = divmod(i, per_row)
        positions.append((origin[0] + col * pitch_x, origin[1] + row * pitch_y))
    return positions


def any_overlap(rects: list[Rect]) -> bool:
    for i in range(len(rects)):
        for j in range(i + 1, len(rects)):
            if rects[i].overlaps(rects[j]):
                return True
    return False


def bounding_box(rects: list[Rect]) -> Rect:
    if not rects:
        return Rect(0, 0, 0, 0)
    x0 = min(r.x for r in rects)
    y0 = min(r.y for r in rects)
    x1 = max(r.x2 for r in rects)
    y1 = max(r.y2 for r in rects)
    return Rect(x0, y0, x1 - x0, y1 - y0)
