"""
Parametric floor-plan generator (section 7).

Given a target rack count and average density, lays racks out into rows
following one of the supported layout templates, and returns the populated
:class:`~core.models.Floor`. Rack objects carry (x, y) positions in metres
that the visualisation layer renders directly.
"""

from __future__ import annotations

import math
import random

from core.models import Floor, Rack
from geometry.rack import make_air_rack, make_gpu_rack

RACK_WIDTH_M = 0.6
RACK_DEPTH_M = 1.2


def generate_floor_plan(
    floor: Floor,
    rack_count: int,
    avg_density_kw: float,
    layout_template: str = "hot_aisle_cold_aisle",
    aisle_width_m: float | None = None,
    high_density_fraction: float = 0.0,
    high_density_kw: float = 80.0,
    seed: int | None = 42,
) -> Floor:
    """Populate ``floor`` with ``rack_count`` racks arranged per
    ``layout_template``. A ``high_density_fraction`` of racks (0..1) is
    generated as liquid-cooled GPU racks at ``high_density_kw`` each; the
    remainder are air-cooled at ``avg_density_kw`` (with light jitter for
    realism, matching section 9's heterogeneous-density example).
    """
    rng = random.Random(seed)
    floor.racks = []
    if aisle_width_m is not None:
        floor.aisle_width_m = aisle_width_m
    floor.layout_template = layout_template

    hot_aisle_w = 1.2
    cold_aisle_w = floor.aisle_width_m
    row_capacity_m = max(1.0, floor.width_m - 4.0)
    # Cap row length to a realistic data-hall row (~24 racks) even on a very
    # wide floor plate, so large rack counts wrap into multiple rows instead
    # of a single degenerate line (which also breaks 2D thermal interpolation).
    racks_per_row = max(1, min(int(row_capacity_m / RACK_WIDTH_M), 24))

    if layout_template == "high_density_gpu":
        high_density_fraction = max(high_density_fraction, 0.7)
    elif layout_template == "perimeter_cooling":
        racks_per_row = max(1, int(racks_per_row * 0.8))

    n_high = int(round(rack_count * high_density_fraction))
    n_std = rack_count - n_high
    densities = (
        [avg_density_kw * rng.uniform(0.85, 1.15) for _ in range(n_std)]
        + [high_density_kw * rng.uniform(0.9, 1.1) for _ in range(n_high)]
    )
    rng.shuffle(densities)

    y_cursor = 2.0
    for i, density in enumerate(densities):
        row, col = divmod(i, racks_per_row)
        if col == 0 and row > 0:
            # alternate hot/cold aisle pitch between rows
            pitch = cold_aisle_w if row % 2 == 1 else hot_aisle_w
            y_cursor += RACK_DEPTH_M + pitch
        x = 2.0 + col * (RACK_WIDTH_M + 0.05)
        y = y_cursor if row > 0 or True else y_cursor

        is_gpu = density >= high_density_kw * 0.75
        if is_gpu:
            # ~1 GPU per 2.5 kW of rack power is a rough but realistic modern
            # liquid-cooled-rack density (e.g. NVL72-class racks: ~130kW/72 GPUs).
            rack = make_gpu_rack(x, y_row(row, RACK_DEPTH_M, cold_aisle_w, hot_aisle_w),
                                  gpu_count=max(8, int(density / 2.5)),
                                  cooling_type="direct_liquid")
            rack.design_power_kw = round(density, 1)
        else:
            rack = make_air_rack(x, y_row(row, RACK_DEPTH_M, cold_aisle_w, hot_aisle_w),
                                  target_kw=round(density, 1), cooling_type="air")
        floor.racks.append(rack)

    return floor


def y_row(row: int, rack_depth: float, cold_aisle: float, hot_aisle: float) -> float:
    """Cumulative y position for a given row index, alternating aisle widths."""
    y = 2.0
    for r in range(row):
        pitch = cold_aisle if r % 2 == 1 else hot_aisle
        y += rack_depth + pitch
    return y


def floor_summary(floor: Floor) -> dict:
    return {
        "floor_id": floor.floor_id,
        "index": floor.index,
        "area_m2": floor.area_m2,
        "layout_template": floor.layout_template,
        "rack_count": floor.rack_count,
        "it_load_kw": floor.it_load_kw,
        "thermal_load_kw": floor.thermal_load_kw,
        "power_density_kw_per_m2": (floor.it_load_kw / floor.area_m2) if floor.area_m2 else 0.0,
    }
