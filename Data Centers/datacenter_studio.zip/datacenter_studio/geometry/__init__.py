"""Geometry package: site, building, floor, rack layout and spatial helpers."""
