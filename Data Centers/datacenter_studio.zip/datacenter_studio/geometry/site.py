"""
Site designer engine (section 5).

Computes site-level areas, utilisation and zone layouts for visualisation.
The heavy-lifting math (utilisation %, coverage %, expansion area) lives on
:class:`core.models.Site` itself; this module adds the zone-list / layout
helpers used by the floor-plan / facility visualiser and by the site
designer UI panel.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.models import Site
from geometry.spatial import Rect


@dataclass
class SiteZone:
    name: str
    kind: str
    rect: Rect


def build_site_zones(site: Site) -> list[SiteZone]:
    """Arrange the site's functional zones into a simple non-overlapping
    layout for visualisation purposes (not a real site plan)."""
    zones: list[SiteZone] = []
    margin = site.width_m * 0.03

    # Building footprint: centred, sized to sqrt(area) rectangle with 1:1.5 aspect
    import math

    bw = math.sqrt(site.building_footprint_m2 / 1.5)
    bl = site.building_footprint_m2 / bw if bw else 0
    bx = margin
    by = margin
    zones.append(SiteZone("Building", "building", Rect(bx, by, bw, bl)))

    # Utility zones stacked to the right of the building
    right_x = bx + bw + margin
    y_cursor = margin
    for label, kind, area in [
        ("Substation", "substation", site.substation_area_m2),
        ("Generators", "generator", site.generator_area_m2),
        ("Cooling Plant", "cooling_plant", site.cooling_plant_area_m2),
        ("Water Storage", "water_storage", site.water_storage_area_m2),
        ("Battery", "battery", site.battery_area_m2),
    ]:
        zw = min(site.width_m - right_x - margin, math.sqrt(area * 1.4)) or 1.0
        zh = area / zw if zw else 0
        zones.append(SiteZone(label, kind, Rect(right_x, y_cursor, zw, zh)))
        y_cursor += zh + margin

    # Solar field along the bottom
    if site.solar_area_m2 > 0:
        sw = site.width_m - 2 * margin
        sh = site.solar_area_m2 / sw if sw else 0
        sy = max(by + bl, y_cursor) + margin
        zones.append(SiteZone("Solar Array", "solar", Rect(margin, sy, sw, sh)))

    # Parking
    if site.parking_area_m2 > 0:
        pw = site.width_m * 0.3
        ph = site.parking_area_m2 / pw if pw else 0
        zones.append(SiteZone("Parking", "parking", Rect(margin, by + bl + margin, pw, ph)))

    return zones


def site_summary(site: Site) -> dict:
    return {
        "site_area_m2": site.area_m2,
        "building_footprint_m2": site.building_footprint_m2,
        "developed_area_m2": site.developed_area_m2,
        "utility_area_m2": site.utility_area_m2,
        "site_utilisation_pct": site.site_utilisation_pct,
        "building_coverage_pct": site.building_coverage_pct,
        "expansion_area_m2": site.expansion_area_m2,
        "grid_capacity_mw": site.grid_capacity_mw,
    }
