"""
Building designer engine (section 6).

Provides the area breakdown calculations (gross/net/technical/compute/
circulation/plant) as a convenience wrapper around :class:`core.models.Building`,
plus helpers to add floors.
"""

from __future__ import annotations

from core.models import Building, Floor


def add_floor(building: Building, layout_template: str = "hot_aisle_cold_aisle") -> Floor:
    """Append a new floor sized to the building footprint, minus support space."""
    index = len(building.floors) + 1
    floor = Floor(
        index=index,
        layout_template=layout_template,
        width_m=building.width_m,
        length_m=building.length_m * (1.0 - building.support_area_fraction),
    )
    building.floors.append(floor)
    return floor


def building_summary(building: Building) -> dict:
    return {
        "footprint_m2": building.footprint_m2,
        "gross_floor_area_m2": building.gross_floor_area_m2,
        "net_floor_area_m2": building.net_floor_area_m2,
        "technical_area_m2": building.technical_area_m2,
        "compute_area_m2": building.compute_area_m2,
        "circulation_area_m2": building.circulation_area_m2,
        "plant_area_m2": building.plant_area_m2,
        "total_height_m": building.total_height_m,
        "floor_count": building.floor_count,
        "total_rack_count": building.total_rack_count,
        "total_it_load_kw": building.total_it_load_kw,
    }
