"""
Rack helpers (sections 7-9): creation, deletion, density adjustment.
"""

from __future__ import annotations

from core.models import Floor, Rack, Server, Workload


def make_air_rack(x: float, y: float, target_kw: float, cooling_type: str = "air") -> Rack:
    """Create a rack with a fixed nameplate density (fast path used by the
    floor-plan generator; avoids instantiating hundreds of Server objects)."""
    return Rack(x=x, y=y, cooling_type=cooling_type, design_power_kw=target_kw)


def make_populated_rack(
    x: float,
    y: float,
    server_count: int,
    form_factor: str = "2U",
    category: str = "general",
    utilisation: float = 0.6,
    cooling_type: str = "air",
) -> Rack:
    """Create a rack populated with individually-modelled servers (used for
    small/detailed racks where per-server power curves matter)."""
    rack = Rack(x=x, y=y, cooling_type=cooling_type)
    for _ in range(server_count):
        rack.servers.append(
            Server(
                form_factor=form_factor,  # type: ignore[arg-type]
                category=category,        # type: ignore[arg-type]
                workload=Workload(utilisation=utilisation),
            )
        )
    return rack


def make_gpu_rack(x: float, y: float, gpu_count: int = 8, gpu_power_w: float = 700.0,
                   utilisation: float = 0.85, cooling_type: str = "direct_liquid") -> Rack:
    rack = Rack(x=x, y=y, cooling_type=cooling_type)
    rack.servers.append(
        Server(
            form_factor="4U",
            category="ai_training",
            gpu_count=gpu_count,
            gpu_power_w=gpu_power_w,
            idle_power_w=800.0,
            max_power_w=2500.0,
            workload=Workload(workload_type="ai_training", utilisation=utilisation),
        )
    )
    return rack


def delete_rack(floor: Floor, rack_id: str) -> bool:
    before = len(floor.racks)
    floor.racks = [r for r in floor.racks if r.rack_id != rack_id]
    return len(floor.racks) < before


def adjust_rack_density(rack: Rack, target_kw: float) -> None:
    """Set (override) a rack's nameplate design power, bypassing per-server calc."""
    rack.design_power_kw = target_kw


def rack_schedule(floor: Floor) -> list[dict]:
    """Tabular rack schedule for export / UI grid (section 40)."""
    rows = []
    for r in floor.racks:
        rows.append({
            "rack_id": r.rack_id,
            "x": round(r.x, 2),
            "y": round(r.y, 2),
            "height_u": r.height_u,
            "cooling_type": r.cooling_type,
            "network_ports": r.network_ports,
            "it_load_kw": round(r.rack_it_load_kw, 2),
            "peak_power_kw": round(r.rack_peak_power_kw, 2),
        })
    return rows
