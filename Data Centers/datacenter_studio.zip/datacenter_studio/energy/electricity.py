"""
Electricity market model (section 20): time-of-use pricing and demand charges.
"""

from __future__ import annotations

import numpy as np

from core.models import EnergySystem


def hourly_price_per_kwh(energy: EnergySystem, hour_of_day: np.ndarray) -> np.ndarray:
    """Vectorised $/kWh for each hour-of-day value (0-23), applying a peak
    multiplier inside the configured peak window if time-of-use is enabled."""
    price = np.full(hour_of_day.shape, energy.grid_price_per_kwh, dtype=float)
    if energy.time_of_use_enabled:
        start, end = energy.peak_hours
        in_peak = (hour_of_day >= start) & (hour_of_day < end)
        price = np.where(in_peak, energy.grid_price_per_kwh * energy.peak_price_multiplier, price)
    return price


def demand_charge_cost(peak_demand_kw: float, energy: EnergySystem) -> float:
    """Monthly-style demand charge applied to the single highest kW draw."""
    return peak_demand_kw * energy.peak_demand_charge_per_kw
