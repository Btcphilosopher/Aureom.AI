"""
Renewable generation model (section 21): solar PV and wind, vectorised over
an hour-of-day / day-of-year array so 8760-hour simulations stay fast.
"""

from __future__ import annotations

import numpy as np

from core.models import EnergySystem


def solar_generation_mw(capacity_mw: float, hour_of_day: np.ndarray, day_of_year: np.ndarray,
                         capacity_factor: float) -> np.ndarray:
    """Simple bell-curve diurnal solar profile, seasonally modulated, scaled
    so the annual average matches ``capacity_factor``."""
    if capacity_mw <= 0:
        return np.zeros_like(hour_of_day, dtype=float)

    # Diurnal shape: a raised cosine between sunrise (6h) and sunset (18h),
    # widened/narrowed slightly by season (+/-1.5h at solstices).
    season = 1.5 * np.cos(2 * np.pi * (day_of_year - 172) / 365.0)  # peak width in summer
    sunrise, sunset = 6.0 - season * 0.3, 18.0 + season * 0.3
    daylight = (hour_of_day >= sunrise) & (hour_of_day <= sunset)
    frac_day = np.where(daylight, (hour_of_day - sunrise) / np.maximum(sunset - sunrise, 1e-6), 0.0)
    shape = np.where(daylight, np.sin(np.pi * frac_day), 0.0)

    # Seasonal irradiance multiplier (summer > winter), mild for generality.
    seasonal_irradiance = 1.0 + 0.15 * np.cos(2 * np.pi * (day_of_year - 172) / 365.0)

    raw = shape * seasonal_irradiance
    # Normalise so that raw's mean over a full year at these hours matches capacity_factor.
    mean_raw = raw.mean() if raw.size else 1.0
    scale = capacity_factor / mean_raw if mean_raw > 0 else 0.0
    return capacity_mw * raw * scale


def wind_generation_mw(capacity_mw: float, size: int, capacity_factor: float,
                        rng: np.random.Generator | None = None) -> np.ndarray:
    """Stochastic wind profile: capacity_factor mean, bounded [0,1], with
    autocorrelated variability (simple AR(1) noise)."""
    if capacity_mw <= 0:
        return np.zeros(size, dtype=float)
    rng = rng or np.random.default_rng(7)
    noise = rng.normal(0, 0.15, size=size)
    ar = np.zeros(size)
    for i in range(1, size):
        ar[i] = 0.8 * ar[i - 1] + noise[i]
    factor = np.clip(capacity_factor + ar * 0.3, 0.0, 1.0)
    return capacity_mw * factor


def renewable_fraction(renewable_mwh: float, total_mwh: float) -> float:
    if total_mwh <= 0:
        return 0.0
    return min(1.0, renewable_mwh / total_mwh)
