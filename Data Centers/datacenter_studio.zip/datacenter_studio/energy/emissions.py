"""
Emissions / carbon accounting (section 20, 26 assistant references).
"""

from __future__ import annotations


def grid_carbon_kg(grid_import_kwh: float, carbon_intensity_kg_per_kwh: float) -> float:
    return grid_import_kwh * carbon_intensity_kg_per_kwh


def diesel_carbon_kg(fuel_l: float, diesel_carbon_intensity_kg_per_l: float = 2.68) -> float:
    return fuel_l * diesel_carbon_intensity_kg_per_l


def cue(total_carbon_kg: float, it_energy_kwh: float) -> float:
    """Carbon Usage Effectiveness = Total CO2e (kg) / IT Energy (kWh)."""
    if it_energy_kwh <= 0:
        return 0.0
    return total_carbon_kg / it_energy_kwh
