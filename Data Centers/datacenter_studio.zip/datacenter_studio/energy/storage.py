"""
Battery dispatch over a time series (section 22), built on the single-step
model in :mod:`power.battery`.
"""

from __future__ import annotations

import numpy as np

from core.models import EnergySystem
from power.battery import BatteryState, dispatch_step


def simulate_battery_series(
    energy: EnergySystem,
    facility_load_mw: np.ndarray,
    renewable_mw: np.ndarray,
    dt_hours: float = 1.0,
    peak_threshold_fraction: float = 0.8,
) -> dict[str, np.ndarray]:
    """Run battery dispatch across a load/renewables time series. Returns
    arrays: soc, charge_mw, discharge_mw, grid_import_mw."""
    n = len(facility_load_mw)
    soc = np.zeros(n)
    charge = np.zeros(n)
    discharge = np.zeros(n)
    grid_import = np.zeros(n)

    if energy.battery_capacity_mwh <= 0:
        grid_import[:] = np.maximum(facility_load_mw - renewable_mw, 0.0)
        return {"soc": soc, "charge_mw": charge, "discharge_mw": discharge, "grid_import_mw": grid_import}

    state = BatteryState(
        capacity_mwh=energy.battery_capacity_mwh,
        power_mw=energy.battery_power_mw,
        round_trip_efficiency=energy.battery_round_trip_efficiency,
        soc=0.5,
    )
    peak_threshold = float(np.percentile(facility_load_mw, 100 * peak_threshold_fraction)) if n else 0.0

    for i in range(n):
        net_load = max(0.0, facility_load_mw[i] - renewable_mw[i])
        surplus = max(0.0, renewable_mw[i] - facility_load_mw[i])
        result = dispatch_step(state, net_load, surplus, dt_hours=dt_hours,
                                strategy="peak_shaving", peak_threshold_mw=peak_threshold)
        soc[i] = result.soc_after
        charge[i] = result.charge_mw
        discharge[i] = result.discharge_mw
        grid_import[i] = result.grid_import_mw

    return {"soc": soc, "charge_mw": charge, "discharge_mw": discharge, "grid_import_mw": grid_import}
