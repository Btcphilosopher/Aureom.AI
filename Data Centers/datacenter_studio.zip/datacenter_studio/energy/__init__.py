"""Energy package: electricity pricing, renewables, storage dispatch, emissions."""
