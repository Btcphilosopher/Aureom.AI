"""
Thermal engine (sections 13-15): facility heat balance, per-rack inlet/outlet
temperature approximation, hot-spot detection.

This is a simplified computational approximation, not a CFD solver, as
specified in section 14: it models heat propagation and airflow using
lumped, per-rack energy balances rather than solving the Navier-Stokes
equations over a 3D mesh.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from config.constants import AIR_DENSITY_KG_M3, AIR_SPECIFIC_HEAT_KJ_PER_KGK
from core.models import Building, PowerSystem


@dataclass
class FacilityHeatBalance:
    it_heat_kw: float
    lighting_heat_kw: float
    people_heat_kw: float
    electrical_heat_kw: float

    @property
    def total_heat_kw(self) -> float:
        return self.it_heat_kw + self.lighting_heat_kw + self.people_heat_kw + self.electrical_heat_kw


def compute_heat_balance(building: Building, it_load_kw: float, power_losses_kw: float,
                          occupancy: int, assumptions: dict) -> FacilityHeatBalance:
    """Total facility heat load (section 13): IT + lighting + people +
    electrical (power-chain loss) heat, all ultimately rejected by cooling."""
    lighting_w_per_m2 = assumptions.get("lighting_w_per_m2", 8.0)
    people_w = assumptions.get("people_heat_w_per_person", 120.0)

    lighting_kw = building.gross_floor_area_m2 * lighting_w_per_m2 / 1000.0
    people_kw = occupancy * people_w / 1000.0

    return FacilityHeatBalance(
        it_heat_kw=it_load_kw,
        lighting_heat_kw=lighting_kw,
        people_heat_kw=people_kw,
        electrical_heat_kw=power_losses_kw,
    )


@dataclass
class RackThermalResult:
    rack_id: str
    thermal_load_kw: float
    inlet_temperature_c: float
    outlet_temperature_c: float
    delta_temperature_c: float
    cooling_requirement_kw: float
    status: str  # "OK" | "HOTSPOT" | "INSUFFICIENT_AIRFLOW"


def rack_thermal_profile(
    building: Building,
    supply_air_temp_c: float,
    rack_delta_t_c: float,
    air_cooling_max_kw_per_rack: float,
    containment_efficiency: float,
) -> list[RackThermalResult]:
    """Approximate each rack's inlet/outlet temperature and flag hot spots.

    Model: inlet temperature = supply air temperature, degraded by
    (1 - containment_efficiency) recirculation proportional to how close the
    rack's load is to the air-cooling ceiling (a simple, transparent proxy
    for recirculation / bypass air in a real facility).
    """
    results: list[RackThermalResult] = []
    for floor in building.floors:
        for rack in floor.racks:
            load = rack.rack_it_load_kw
            if rack.cooling_type in ("direct_liquid", "immersion"):
                # Liquid-cooled racks reject most heat to coolant; residual air load is small.
                residual_fraction = 0.10 if rack.cooling_type == "direct_liquid" else 0.03
                air_load = load * residual_fraction
            else:
                air_load = load

            recirculation_penalty = (1.0 - containment_efficiency) * min(1.0, load / max(air_cooling_max_kw_per_rack, 1e-6))
            inlet_temp = supply_air_temp_c + recirculation_penalty * 8.0
            delta_t = rack_delta_t_c * min(2.0, air_load / max(air_cooling_max_kw_per_rack * 0.5, 1e-6)) if air_load > 0 else 0.0
            delta_t = max(delta_t, 0.0)
            outlet_temp = inlet_temp + delta_t

            status = "OK"
            if rack.cooling_type == "air" and load > air_cooling_max_kw_per_rack:
                status = "HOTSPOT"
            elif inlet_temp > 27.0:
                status = "HOTSPOT"
            elif air_load > 0 and delta_t < 2.0 and load > 5.0:
                status = "INSUFFICIENT_AIRFLOW"

            results.append(RackThermalResult(
                rack_id=rack.rack_id,
                thermal_load_kw=load,
                inlet_temperature_c=round(inlet_temp, 2),
                outlet_temperature_c=round(outlet_temp, 2),
                delta_temperature_c=round(delta_t, 2),
                cooling_requirement_kw=round(load * 1.0, 2),
                status=status,
            ))
    return results


def heatmap_zone(temperature_c: float) -> str:
    """Map a temperature to a heatmap zone label (section 14)."""
    if temperature_c < 18:
        return "BLUE"      # cool
    if temperature_c < 24:
        return "GREEN"     # normal
    if temperature_c < 27:
        return "YELLOW"    # warm
    if temperature_c < 32:
        return "ORANGE"    # hot
    return "RED"           # critical
