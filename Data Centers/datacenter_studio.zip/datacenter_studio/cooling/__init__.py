"""Cooling package: thermal load, HVAC, chillers, cooling towers, liquid cooling, heat recovery."""
