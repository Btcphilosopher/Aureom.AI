"""
Chiller / cooling-plant performance model (sections 18-19): COP/EER as a
function of ambient conditions, free-cooling economiser logic.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.units import clamp


def effective_cop(base_cop: float, ambient_wetbulb_c: float, design_wetbulb_c: float = 24.0) -> float:
    """Simple linear COP degradation model: chiller COP falls as ambient
    wet-bulb rises above the design condition, and improves in cooler
    weather (subject to a practical ceiling).

    ``base_cop`` is the assumed nameplate/AHRI COP (see ``ASSUMPTIONS['chiller_base_cop']``).
    """
    delta = design_wetbulb_c - ambient_wetbulb_c
    cop = base_cop + 0.04 * base_cop * delta   # +/-4% COP per degree C off design
    return clamp(cop, base_cop * 0.5, base_cop * 1.8)


def eer_from_cop(cop: float) -> float:
    """EER (Btu/Wh) from COP (dimensionless)."""
    return cop * 3.412


def is_free_cooling_available(ambient_wetbulb_c: float, threshold_c: float) -> bool:
    return ambient_wetbulb_c <= threshold_c


def chiller_electrical_kw(cooling_load_kw: float, cop: float) -> float:
    if cop <= 0:
        raise ValueError("cop must be > 0")
    return cooling_load_kw / cop


@dataclass
class CoolingPlantResult:
    cooling_load_kw: float
    free_cooling_active: bool
    chiller_electrical_kw: float
    pump_electrical_kw: float
    fan_electrical_kw: float
    cop: float
    eer: float

    @property
    def total_cooling_electrical_kw(self) -> float:
        return self.chiller_electrical_kw + self.pump_electrical_kw + self.fan_electrical_kw


def compute_cooling_plant(
    cooling_load_kw: float,
    ambient_wetbulb_c: float,
    assumptions: dict,
    free_cooling_enabled: bool,
) -> CoolingPlantResult:
    base_cop = assumptions.get("chiller_base_cop", 5.5)
    threshold = assumptions.get("free_cooling_threshold_c", 12.0)
    pump_eff = assumptions.get("pump_efficiency", 0.80)
    fan_eff = assumptions.get("fan_efficiency", 0.70)

    free_active = free_cooling_enabled and is_free_cooling_available(ambient_wetbulb_c, threshold)
    cop = effective_cop(base_cop, ambient_wetbulb_c)

    if free_active:
        # Free cooling bypasses mechanical refrigeration; only pumps/fans run,
        # at a very high effective COP (economiser mode).
        cop = max(cop, base_cop * 3.0)
        chiller_kw = cooling_load_kw / cop
    else:
        chiller_kw = chiller_electrical_kw(cooling_load_kw, cop)

    # Pump/fan auxiliary loads scaled to cooling load and component efficiency.
    pump_kw = cooling_load_kw * 0.03 / max(pump_eff, 0.01)
    fan_kw = cooling_load_kw * 0.02 / max(fan_eff, 0.01)

    return CoolingPlantResult(
        cooling_load_kw=cooling_load_kw,
        free_cooling_active=free_active,
        chiller_electrical_kw=round(chiller_kw, 2),
        pump_electrical_kw=round(pump_kw, 2),
        fan_electrical_kw=round(fan_kw, 2),
        cop=round(cop, 2),
        eer=round(eer_from_cop(cop), 2),
    )
