"""
Direct Liquid Cooling (DLC) / immersion cooling model (section 16).
"""

from __future__ import annotations

from dataclasses import dataclass

from config.constants import WATER_SPECIFIC_HEAT_KJ_PER_KGK


@dataclass
class LiquidCoolingResult:
    heat_removed_kw: float
    coolant_flow_rate_l_s: float
    coolant_temperature_rise_c: float
    pump_energy_kw: float
    heat_rejected_kw: float


def coolant_flow_rate_l_s(heat_kw: float, delta_t_c: float, density_kg_l: float = 1.0) -> float:
    """Required coolant flow (L/s) to remove ``heat_kw`` across ``delta_t_c``."""
    if delta_t_c <= 0:
        return 0.0
    mass_flow_kg_s = heat_kw / (WATER_SPECIFIC_HEAT_KJ_PER_KGK * delta_t_c)
    return mass_flow_kg_s / density_kg_l


def evaluate_liquid_cooling(
    rack_heat_kw: float,
    coolant_supply_temp_c: float,
    coolant_return_temp_c: float,
    heat_exchanger_efficiency: float,
    capture_fraction: float,
    pump_efficiency: float,
) -> LiquidCoolingResult:
    delta_t = max(coolant_return_temp_c - coolant_supply_temp_c, 0.1)
    captured_heat = rack_heat_kw * capture_fraction
    flow_l_s = coolant_flow_rate_l_s(captured_heat, delta_t)

    pump_hydraulic_kw = flow_l_s * 0.05  # simplified head-loss proxy
    pump_electrical_kw = pump_hydraulic_kw / max(pump_efficiency, 0.01)

    heat_rejected = captured_heat / max(heat_exchanger_efficiency, 0.01)

    return LiquidCoolingResult(
        heat_removed_kw=round(captured_heat, 2),
        coolant_flow_rate_l_s=round(flow_l_s, 3),
        coolant_temperature_rise_c=round(delta_t, 2),
        pump_energy_kw=round(pump_electrical_kw, 3),
        heat_rejected_kw=round(heat_rejected, 2),
    )
