"""
Airflow / HVAC model (section 15): CRAC/CRAH air handling, required airflow,
and cooling adequacy flags.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.constants import AIR_DENSITY_KG_M3, AIR_SPECIFIC_HEAT_KJ_PER_KGK


@dataclass
class AirflowResult:
    required_airflow_m3_s: float
    supply_temperature_c: float
    return_temperature_c: float
    flags: list[str]


def required_airflow_m3_s(heat_load_kw: float, delta_t_c: float) -> float:
    """Airflow needed to remove ``heat_load_kw`` of heat across ``delta_t_c``.

    Q [kW] = rho * V_dot [m3/s] * cp [kJ/kgK] * dT [K]
    => V_dot = Q / (rho * cp * dT)
    """
    if delta_t_c <= 0:
        return 0.0
    return heat_load_kw / (AIR_DENSITY_KG_M3 * AIR_SPECIFIC_HEAT_KJ_PER_KGK * delta_t_c)


def evaluate_airflow(
    total_heat_kw: float,
    cooling_capacity_kw: float,
    supply_temp_c: float,
    crah_delta_t_c: float,
) -> AirflowResult:
    flags: list[str] = []
    airflow = required_airflow_m3_s(total_heat_kw, crah_delta_t_c)
    return_temp = supply_temp_c + crah_delta_t_c

    if cooling_capacity_kw < total_heat_kw:
        flags.append("COOLING UNDERSIZED")
    elif cooling_capacity_kw > total_heat_kw * 2.2:
        flags.append("COOLING OVERSIZED")

    if total_heat_kw > 0 and cooling_capacity_kw / max(total_heat_kw, 1e-6) < 1.05:
        flags.append("INSUFFICIENT AIRFLOW")

    if not flags:
        flags.append("NOMINAL")

    return AirflowResult(
        required_airflow_m3_s=round(airflow, 2),
        supply_temperature_c=supply_temp_c,
        return_temperature_c=round(return_temp, 2),
        flags=flags,
    )
