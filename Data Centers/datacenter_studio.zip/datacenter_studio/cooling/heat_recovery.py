"""
Heat recovery subsystem (section 17).

DATA CENTER -> WASTE HEAT -> HEAT EXCHANGER -> HOT WATER -> DISTRICT HEATING
/ INDUSTRIAL HEAT / HEAT PUMP.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class HeatRecoveryResult:
    recoverable_heat_kw: float
    recovered_heat_kw: float
    heat_recovery_efficiency: float

    def recovered_energy_kwh(self, hours: float) -> float:
        return self.recovered_heat_kw * hours


def evaluate_heat_recovery(
    total_heat_kw: float,
    enabled: bool,
    assumptions: dict,
) -> HeatRecoveryResult:
    efficiency = assumptions.get("heat_recovery_efficiency", 0.65)
    max_fraction = assumptions.get("heat_recovery_max_fraction", 0.50)

    if not enabled:
        return HeatRecoveryResult(recoverable_heat_kw=0.0, recovered_heat_kw=0.0, heat_recovery_efficiency=efficiency)

    recoverable = total_heat_kw * max_fraction
    recovered = recoverable * efficiency
    return HeatRecoveryResult(
        recoverable_heat_kw=round(recoverable, 2),
        recovered_heat_kw=round(recovered, 2),
        heat_recovery_efficiency=efficiency,
    )
