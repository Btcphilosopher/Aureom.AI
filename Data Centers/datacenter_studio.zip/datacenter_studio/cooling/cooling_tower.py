"""Cooling tower / heat rejection model (section 18)."""

from __future__ import annotations

from config.constants import WATER_SPECIFIC_HEAT_KJ_PER_KGK


def approach_temperature_c(ambient_wetbulb_c: float, approach_c: float) -> float:
    """Cold-water temperature the tower can deliver: wetbulb + approach."""
    return ambient_wetbulb_c + approach_c


def water_consumption_m3_per_hour(heat_rejected_kw: float, cycles_of_concentration: float = 5.0,
                                   evaporation_fraction: float = 0.85) -> float:
    """Evaporative cooling tower water use, via latent heat of vaporisation
    (~2260 kJ/kg), plus blowdown to manage cycles of concentration (section 18, 19 WUE)."""
    latent_heat_kj_per_kg = 2260.0
    evap_kg_per_s = (heat_rejected_kw * evaporation_fraction) / latent_heat_kj_per_kg
    evap_m3_per_hour = evap_kg_per_s * 3600.0 / 1000.0
    blowdown_m3_per_hour = evap_m3_per_hour / max(cycles_of_concentration - 1.0, 1.0)
    return evap_m3_per_hour + blowdown_m3_per_hour


def fan_energy_kw(heat_rejected_kw: float, fan_efficiency: float) -> float:
    return heat_rejected_kw * 0.015 / max(fan_efficiency, 0.01)
