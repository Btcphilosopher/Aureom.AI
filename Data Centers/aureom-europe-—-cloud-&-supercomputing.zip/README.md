# AUREOM EUROPE — Cloud & Supercomputing

**Code at the speed of civilisation.**

Multilingual (**English / Français / Deutsch**) European cloud, GPU computing, batch supercomputing, storage, and private infrastructure platform with an Angular 21 SSR + Express control plane, typed infrastructure adapters, deterministic EUR metering, and a server-side Gemini 4.0 compute assistant.

> **Demonstration Notice**: All regions (`eu-sim-nord-1`, `eu-sim-central-1`, `eu-sim-west-1`), hardware telemetry, pricing books (`v2026.11-demo`), organisations, and invoices in the default local environment are synthetic demonstration models unless explicitly integrated with live infrastructure backends.

---

## Architecture

- **Frontend**: Angular 21 (zoneless, `OnPush`, signals, Reactive Forms, Tailwind CSS v4, Material Icons) with Server-Side Rendering for public pages and client-rendered interactive customer/operator console routes.
- **Backend Control Plane (`src/server.ts`, `src/server/*`)**: Express 5 REST API with `X-Request-Id` tracing, `Idempotency-Key` caching, organisation isolation, RBAC enforcement (`org_admin`, `project_admin`, `developer`, `billing_admin`, `auditor`), quota checks, CIDR overlap & default-deny SSH/RDP firewall validation, and atomic EUR usage/invoice calculation via `decimal.js`.
- **Infrastructure Adapters (`src/server/adapters.ts`)**:
  - `ComputeAdapter` (`LocalContainerSimComputeAdapter`)
  - `GpuAdapter` (`LocalGpuSimulatorAdapter`)
  - `BatchSchedulerAdapter` (`SlurmAndLocalSchedulerAdapter` — local queue simulator + Slurm `sbatch` adapter boundary)
  - `StorageAdapter` (`LocalS3StorageAdapter`)
  - `FacilityTelemetryAdapter` (`ReadOnlyFacilityTelemetryAdapter`)
- **AI Compute Assistant (`src/server/gemini-assistant.ts`)**: Server-side `@google/genai` (`gemini-4-hydrogen`) with structured read-only function tools, prompt secret redaction, and source citations. Never mutates infrastructure without explicit customer confirmation.
- **Target Database Schema**: PostgreSQL 16 reference migration at `infra/migrations/001_initial_control_plane.sql` alongside local state persistence (`/tmp/aureom-demo-state.json`).

---

## Startup & Verification Commands

```bash
# Install dependencies
npm install

# Run development server (port 3000, SSR + /api control plane)
npm run dev

# Build production SSR & browser bundles
npm run build

# Run production server after build
npm run serve:ssr:app

# Run ESLint & Angular template checks
npm run lint

# Run unit & control-plane integration tests (Vitest)
npm test -- --watch=false
```

---

## Environment Variables

Configure via Secrets / environment variables (see `.env.example`):

- `GEMINI_API_KEY`: Server-only API key for `/api/assistant/query`. Never exposed to browser code.
- `APP_URL`: Public origin URL for callbacks and metadata.
