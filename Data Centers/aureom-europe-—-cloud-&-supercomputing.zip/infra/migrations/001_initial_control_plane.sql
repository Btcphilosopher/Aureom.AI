-- AUREOM EUROPE — Cloud & Supercomputing
-- PostgreSQL 16 Reference Control-Plane Schema Migration (001)
-- Aligns domain entities, lifecycle state constraints, organisation ownership,
-- idempotent EUR usage metering, and immutable audit trails.

BEGIN;

CREATE TABLE IF NOT EXISTS organisations (
  id                TEXT PRIMARY KEY,
  name              TEXT NOT NULL,
  legal_entity_type TEXT NOT NULL,
  billing_country   CHAR(2) NOT NULL,
  vat_number        TEXT,
  default_locale    TEXT NOT NULL CHECK (default_locale IN ('en', 'fr', 'de')),
  is_demo           BOOLEAN NOT NULL DEFAULT FALSE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS org_members (
  id              TEXT PRIMARY KEY,
  org_id          TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  email           TEXT NOT NULL,
  display_name    TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('org_admin', 'project_admin', 'developer', 'billing_admin', 'auditor')),
  preferred_locale TEXT NOT NULL CHECK (preferred_locale IN ('en', 'fr', 'de')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (org_id, email)
);

CREATE TABLE IF NOT EXISTS projects (
  id                     TEXT PRIMARY KEY,
  org_id                 TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  name                   TEXT NOT NULL,
  slug                   TEXT NOT NULL,
  residency_region_id    TEXT NOT NULL,
  enforced_residency     BOOLEAN NOT NULL DEFAULT TRUE,
  quota_vcpu             INTEGER NOT NULL CHECK (quota_vcpu >= 0),
  quota_memory_gib       INTEGER NOT NULL CHECK (quota_memory_gib >= 0),
  quota_gpus             INTEGER NOT NULL CHECK (quota_gpus >= 0),
  quota_storage_gb       INTEGER NOT NULL CHECK (quota_storage_gb >= 0),
  quota_concurrent_jobs  INTEGER NOT NULL CHECK (quota_concurrent_jobs >= 0),
  budget_monthly_eur     NUMERIC(14, 4) NOT NULL CHECK (budget_monthly_eur >= 0),
  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (org_id, slug)
);

CREATE TABLE IF NOT EXISTS compute_instances (
  id                  TEXT PRIMARY KEY,
  org_id              TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id          TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  template_id         TEXT NOT NULL,
  region_id           TEXT NOT NULL,
  network_id          TEXT NOT NULL,
  subnet_id           TEXT NOT NULL,
  architecture        TEXT NOT NULL CHECK (architecture IN ('x86_64', 'arm64')),
  vcpu                INTEGER NOT NULL CHECK (vcpu > 0),
  memory_gib          INTEGER NOT NULL CHECK (memory_gib > 0),
  disk_gb             INTEGER NOT NULL CHECK (disk_gb > 0),
  image               TEXT NOT NULL,
  ssh_public_key_fp   TEXT NOT NULL,
  lifecycle_state     TEXT NOT NULL CHECK (
    lifecycle_state IN (
      'Requested', 'Validating', 'Provisioning', 'Running',
      'Stopping', 'Stopped', 'Deleting', 'Deleted', 'Failed', 'Reconciling'
    )
  ),
  execution_backend   TEXT NOT NULL,
  host_id             TEXT,
  private_ipv4        INET,
  price_book_version  TEXT NOT NULL,
  hourly_rate_eur     NUMERIC(14, 4) NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_compute_org_proj ON compute_instances (org_id, project_id);

CREATE TABLE IF NOT EXISTS gpu_allocations (
  id                  TEXT PRIMARY KEY,
  org_id              TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id          TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  profile_id          TEXT NOT NULL,
  region_id           TEXT NOT NULL,
  host_id             TEXT NOT NULL,
  device_count        INTEGER NOT NULL CHECK (device_count > 0),
  partition_profile   TEXT,
  isolation_boundary  TEXT NOT NULL,
  state               TEXT NOT NULL CHECK (state IN ('Reserved', 'Attached', 'Releasing', 'Released', 'Faulted')),
  hourly_rate_eur     NUMERIC(14, 4) NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hpc_jobs (
  id                  TEXT PRIMARY KEY,
  org_id              TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id          TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  scheduler_adapter   TEXT NOT NULL,
  scheduler_job_ref   TEXT,
  queue_class         TEXT NOT NULL CHECK (queue_class IN ('standard', 'gpu-priority', 'throughput')),
  workload_image      TEXT NOT NULL,
  cpu_cores           INTEGER NOT NULL CHECK (cpu_cores > 0),
  gpu_count           INTEGER NOT NULL CHECK (gpu_count >= 0),
  memory_gib          INTEGER NOT NULL CHECK (memory_gib > 0),
  runtime_limit_min   INTEGER NOT NULL CHECK (runtime_limit_min > 0),
  input_uri           TEXT NOT NULL,
  output_uri          TEXT NOT NULL,
  state               TEXT NOT NULL CHECK (
    state IN ('Submitted', 'Queued', 'Allocated', 'Starting', 'Running', 'Completed', 'Failed', 'Cancelled', 'TimedOut')
  ),
  output_ready        BOOLEAN NOT NULL DEFAULT FALSE,
  exit_code           INTEGER,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_jobs_org_proj_state ON hpc_jobs (org_id, project_id, state);

CREATE TABLE IF NOT EXISTS storage_buckets (
  id                 TEXT PRIMARY KEY,
  org_id             TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id         TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  region_id          TEXT NOT NULL,
  replication_mode   TEXT NOT NULL,
  encryption_mode    TEXT NOT NULL,
  versioning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  size_bytes         BIGINT NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (org_id, name)
);

CREATE TABLE IF NOT EXISTS block_volumes (
  id                 TEXT PRIMARY KEY,
  org_id             TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id         TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  region_id          TEXT NOT NULL,
  size_gb            INTEGER NOT NULL CHECK (size_gb > 0),
  attached_instance_id TEXT REFERENCES compute_instances(id) ON DELETE SET NULL,
  state              TEXT NOT NULL CHECK (state IN ('Available', 'Attached', 'Deleting', 'Deleted')),
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS storage_snapshots (
  id                 TEXT PRIMARY KEY,
  org_id             TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id         TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  volume_id          TEXT NOT NULL REFERENCES block_volumes(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,
  size_gb            INTEGER NOT NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS independent_backups (
  id                 TEXT PRIMARY KEY,
  org_id             TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id         TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  source_resource_id TEXT NOT NULL,
  vault_region_id    TEXT NOT NULL,
  retention_days     INTEGER NOT NULL CHECK (retention_days > 0),
  checksum_sha256    TEXT NOT NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS networks (
  id          TEXT PRIMARY KEY,
  org_id      TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id  TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  region_id   TEXT NOT NULL,
  cidr_block  CIDR NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS subnets (
  id          TEXT PRIMARY KEY,
  network_id  TEXT NOT NULL REFERENCES networks(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  cidr_block  CIDR NOT NULL,
  zone_label  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS security_groups (
  id          TEXT PRIMARY KEY,
  org_id      TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id  TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  network_id  TEXT NOT NULL REFERENCES networks(id) ON DELETE CASCADE,
  name        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS security_group_rules (
  id                TEXT PRIMARY KEY,
  security_group_id TEXT NOT NULL REFERENCES security_groups(id) ON DELETE CASCADE,
  protocol          TEXT NOT NULL CHECK (protocol IN ('tcp', 'udp', 'icmp')),
  from_port         INTEGER NOT NULL CHECK (from_port BETWEEN 0 AND 65535),
  to_port           INTEGER NOT NULL CHECK (to_port BETWEEN 0 AND 65535),
  cidr_source       CIDR NOT NULL,
  description       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usage_ledger (
  id                  TEXT PRIMARY KEY,
  idempotency_key     TEXT NOT NULL UNIQUE,
  org_id              TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  project_id          TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  resource_id         TEXT NOT NULL,
  resource_type       TEXT NOT NULL,
  meter_name          TEXT NOT NULL,
  quantity            NUMERIC(14, 4) NOT NULL,
  unit                TEXT NOT NULL,
  unit_price_eur      NUMERIC(14, 4) NOT NULL,
  amount_eur          NUMERIC(14, 4) NOT NULL,
  price_book_version  TEXT NOT NULL,
  period_start        TIMESTAMPTZ NOT NULL,
  period_end          TIMESTAMPTZ NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS invoices (
  id                  TEXT PRIMARY KEY,
  org_id              TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  invoice_number      TEXT NOT NULL UNIQUE,
  billing_period      TEXT NOT NULL,
  currency            CHAR(3) NOT NULL DEFAULT 'EUR',
  subtotal_eur        NUMERIC(14, 4) NOT NULL,
  vat_rate_percent    NUMERIC(5, 2) NOT NULL,
  vat_amount_eur      NUMERIC(14, 4) NOT NULL,
  total_eur           NUMERIC(14, 4) NOT NULL,
  reverse_charge_note TEXT NOT NULL,
  status              TEXT NOT NULL CHECK (status IN ('Draft', 'Issued', 'SimulatedPaid')),
  line_items_json     JSONB NOT NULL,
  issued_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS api_keys (
  id          TEXT PRIMARY KEY,
  org_id      TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  prefix      TEXT NOT NULL,
  key_hash    TEXT NOT NULL UNIQUE,
  scopes      TEXT[] NOT NULL,
  revoked     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_events (
  id            TEXT PRIMARY KEY,
  org_id        TEXT NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  actor         TEXT NOT NULL,
  role          TEXT NOT NULL,
  action        TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id   TEXT NOT NULL,
  request_id    TEXT NOT NULL,
  summary       TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_org_time ON audit_events (org_id, created_at DESC);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  composite_key TEXT PRIMARY KEY,
  status_code   INTEGER NOT NULL,
  response_body JSONB NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMIT;
