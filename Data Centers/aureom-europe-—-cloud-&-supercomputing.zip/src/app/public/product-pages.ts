import {ChangeDetectionStrategy, Component, OnInit, computed, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';

@Component({
  selector: 'app-cloud-compute-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div class="max-w-3xl">
          <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
          <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.cloudCompute') }}
          </h1>
          <p class="mt-3 text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'Instances configurables x86_64 et ARM64 avec cycle de vie explicite, vérification d’empreinte SSH et séparation honnête entre simulation locale et virtualisation KVM.'
                : i18n.locale() === 'de'
                  ? 'Konfigurierbare x86_64- und ARM64-Instanzen mit explizitem Lebenszyklus, SSH-Schlüsselprüfung und klarer Abgrenzung zwischen lokaler Container-Simulation und KVM-Hypervisor.'
                  : 'Configurable x86_64 and ARM64 instance templates with explicit lifecycle states, SSH public key enforcement, and transparent local-container-vs-VM adapter boundaries.'
            }}
          </p>
        </div>
        <a
          routerLink="/console/compute"
          class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
        >
          <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">dns</mat-icon>
          <span>{{ i18n.t('home.cta.launchInstance') }}</span>
        </a>
      </div>

      <!-- Lifecycle Strip -->
      <div class="rounded-xl border border-slate-200 bg-white p-6">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">
          {{
            i18n.locale() === 'fr'
              ? 'Machine à états explicite et réconciliation'
              : i18n.locale() === 'de'
                ? 'Expliziter Lebenszyklus und Zustandsabgleich'
                : 'Explicit Provisioning Lifecycle & Observed State'
          }}
        </h2>
        <p class="mt-1 text-sm text-slate-600">
          {{
            i18n.locale() === 'fr'
              ? 'L’acceptation d’une requête API (HTTP 202) ne prouve jamais qu’une machine est en cours d’exécution.'
              : i18n.locale() === 'de'
                ? 'Eine API-Annahme (HTTP 202) ist kein Beweis dafür, dass die Maschine bereits läuft.'
                : 'API acceptance (HTTP 202) is never treated as proof that a machine is running; observed state is reconciled from the adapter.'
          }}
        </p>
        <div class="mt-4 flex flex-wrap items-center gap-2 font-mono text-xs text-[#070D19]">
          @for (s of states; track s; let last = $last) {
            <span class="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1">{{ i18n.stateLabel(s) }}</span>
            @if (!last) {
              <span class="text-slate-400">→</span>
            }
          }
        </div>
      </div>

      <!-- Templates Table -->
      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">
            {{ i18n.locale() === 'fr' ? 'Catalogue de modèles (Démo)' : i18n.locale() === 'de' ? 'Instanzvorlagen (Demo)' : 'Instance Templates (Simulated Catalog)' }}
          </h2>
          <span class="font-mono text-xs text-slate-500">v2026.11-demo · EUR</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th class="px-6 py-3 font-semibold">Template ID</th>
                <th class="px-6 py-3 font-semibold">Arch</th>
                <th class="px-6 py-3 font-semibold text-right">vCPU</th>
                <th class="px-6 py-3 font-semibold text-right">Memory</th>
                <th class="px-6 py-3 font-semibold text-right">Disk</th>
                <th class="px-6 py-3 font-semibold">Adapter Boundary</th>
                <th class="px-6 py-3 font-semibold text-right">Demo Rate</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (t of cp.catalog()?.templates ?? []; track t.id) {
                <tr class="hover:bg-slate-50/70">
                  <td class="px-6 py-3.5 font-mono text-xs font-medium text-[#070D19]">{{ t.id }}</td>
                  <td class="px-6 py-3.5 font-mono text-xs text-slate-600">{{ t.architecture }}</td>
                  <td class="px-6 py-3.5 font-mono text-xs text-right tabular-nums">{{ t.vcpus }}</td>
                  <td class="px-6 py-3.5 font-mono text-xs text-right tabular-nums">{{ t.memoryGiB }} GiB</td>
                  <td class="px-6 py-3.5 font-mono text-xs text-right tabular-nums">{{ t.defaultDiskGB }} GB</td>
                  <td class="px-6 py-3.5 text-xs text-slate-600">{{ t.virtualizationBoundary }}</td>
                  <td class="px-6 py-3.5 font-mono text-xs text-right tabular-nums font-semibold text-[#1D4ED8]">
                    {{ i18n.formatEur(t.pricePerHourEur, 4) }}/h
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class CloudComputePage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  readonly states = ['Requested', 'Validating', 'Provisioning', 'Running', 'Stopping', 'Stopped', 'Deleting', 'Deleted'];

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) await this.cp.loadCatalog();
  }
}

@Component({
  selector: 'app-gpu-computing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center border-b border-slate-200 pb-8">
        <div class="lg:col-span-7">
          <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
          <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.gpuComputing') }}
          </h1>
          <p class="mt-3 text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'Profils d’accélérateurs synthétiques avec capacités de partitionnement exposées par adaptateur et avertissement explicite sur l’isolation multi-tenant.'
                : i18n.locale() === 'de'
                  ? 'Synthetische GPU-Beschleunigerprofile mit adaptergesteuerten Partitionierungsfähigkeiten und expliziten Hinweisen zur Mandantenisolation.'
                  : 'Synthetic accelerator profiles exposing actual adapter capabilities, driver compatibility, reservation pricing, and honest multi-tenant isolation notices.'
            }}
          </p>
          <div class="mt-5">
            <a
              routerLink="/console/gpus"
              class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
            >
              <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">developer_board</mat-icon>
              <span>{{ i18n.t('nav.customerConsole') }} · GPUs</span>
            </a>
          </div>
        </div>
        <div class="lg:col-span-5">
          <div class="overflow-hidden rounded-xl border border-slate-200 bg-[#0B1324] aspect-[4/3]">
            @if (!imgFailed()) {
              <img
                src="/assets/images/gpu_compute_cluster_1795172703951.jpg"
                alt="Liquid-cooled GPU compute cluster rack"
                referrerpolicy="no-referrer"
                (error)="imgFailed.set(true)"
                class="h-full w-full object-cover"
              />
            }
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 gap-6 md:grid-cols-3">
        @for (g of cp.catalog()?.gpuProfiles ?? []; track g.id) {
          <div class="rounded-xl border border-slate-200 bg-white p-6 flex flex-col justify-between">
            <div>
              <div class="font-mono text-xs text-slate-500">{{ g.architecture }}</div>
              <h2 class="mt-1 font-display text-lg font-semibold text-[#070D19]">{{ g.modelName }}</h2>
              <div class="mt-4 space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-4">
                <div class="flex justify-between"><span>VRAM</span><span class="font-mono font-medium text-[#070D19]">{{ g.vramGiB }} GiB</span></div>
                <div class="flex justify-between"><span>Runtime</span><span class="font-mono text-[#070D19]">{{ g.cudaOrRocmRuntime }}</span></div>
                <div class="flex justify-between">
                  <span>Partitioning</span>
                  <span class="font-mono text-[#070D19]">{{ g.supportsPartitioning ? g.partitionProfiles.join(', ') : 'Unsupported (disabled)' }}</span>
                </div>
                <div class="flex justify-between">
                  <span>On-demand (Demo)</span>
                  <span class="font-mono font-semibold text-[#1D4ED8]">{{ i18n.formatEur(g.hourlyRatePerDeviceEur, 2) }}/h</span>
                </div>
              </div>
              <p class="mt-4 text-xs leading-relaxed text-amber-800 bg-amber-50 border border-amber-200/70 rounded-lg p-3">
                {{ g.isolationNotice }}
              </p>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class GpuComputingPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  readonly imgFailed = signal(false);

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) await this.cp.loadCatalog();
  }
}

@Component({
  selector: 'app-supercomputing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div class="max-w-3xl">
          <div class="font-mono text-xs text-[#1D4ED8]">Slurm Adapter &amp; Local Queue Simulator</div>
          <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.supercomputing') }}
          </h1>
          <p class="mt-3 text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'Ordonnancement par lots avec séparation stricte entre file d’attente, allocation de nœud, exécution du conteneur et disponibilité des sorties.'
                : i18n.locale() === 'de'
                  ? 'Batch-Orchestrierung mit strikter Trennung zwischen Warteschlange, Knotenzuweisung, Ausführung und Ergebnisverfügbarkeit.'
                  : 'Batch supercomputing orchestration keeping scheduler queue acceptance, node allocation, workload execution, and output materialisation strictly distinct.'
            }}
          </p>
        </div>
        <a
          routerLink="/console/jobs"
          class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
        >
          <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">memory</mat-icon>
          <span>{{ i18n.t('home.cta.submitJob') }}</span>
        </a>
      </div>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">
            {{ i18n.locale() === 'fr' ? 'États du cycle de lot' : i18n.locale() === 'de' ? 'Batch-Job-Zustände' : 'Batch Job Lifecycle' }}
          </h2>
          <div class="flex flex-wrap gap-2 font-mono text-xs">
            @for (st of jobStates; track st) {
              <span class="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-[#070D19]">{{ i18n.stateLabel(st) }}</span>
            }
          </div>
          <p class="text-sm text-slate-600 leading-relaxed">
            Submitted workloads enter a queue class (<code class="font-mono text-xs">standard</code>, <code class="font-mono text-xs">gpu-priority</code>, <code class="font-mono text-xs">throughput</code>). Queue acceptance never promises immediate execution when capacity is allocated elsewhere.
          </p>
        </div>

        <div class="rounded-xl border border-slate-200 bg-[#070D19] p-6 text-slate-200">
          <div class="font-mono text-xs text-cyan-300 mb-3">Slurm Adapter Script Output (#SBATCH)</div>
          <pre class="font-mono text-xs leading-relaxed overflow-x-auto text-slate-100">#!/bin/bash
#SBATCH --job-name=baltic-thermocline-pass
#SBATCH --partition=gpu-priority
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --gpus=1
#SBATCH --time=00:30:00
#SBATCH --output=s3://baltic-datasets-nord/outputs/slurm-%j.out
python3 solve_mesh.py --input /data/baltic_grid_sample.csv</pre>
        </div>
      </div>
    </div>
  `,
})
export class SupercomputingPage {
  readonly i18n = inject(I18nService);
  readonly jobStates = ['Submitted', 'Queued', 'Allocated', 'Starting', 'Running', 'Completed', 'Failed', 'Cancelled', 'TimedOut'];
}

@Component({
  selector: 'app-storage-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div class="max-w-3xl">
          <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
          <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.storage') }}
          </h1>
          <p class="mt-3 text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'Ressources distinctes pour le stockage objet S3, les volumes blocs, les systèmes POSIX partagés, les instantanés et les sauvegardes indépendantes.'
                : i18n.locale() === 'de'
                  ? 'Getrennte Ressourcentypen für S3-Objektspeicher, Block-Volumes, POSIX-Dateisysteme, Snapshots und unabhängige Backups.'
                  : 'Separate resource classes for S3-compatible object buckets, persistent block volumes, POSIX shared filesystems, snapshots, and independent cross-region backups.'
            }}
          </p>
        </div>
        <a
          routerLink="/console/storage"
          class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
        >
          <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">storage</mat-icon>
          <span>{{ i18n.t('nav.customerConsole') }} · {{ i18n.t('nav.storage') }}</span>
        </a>
      </div>

      <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div class="rounded-xl border border-slate-200 bg-white p-6">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Object Storage (S3-Compatible)</h2>
          <p class="mt-2 text-sm text-slate-600">Project-scoped buckets with SHA-256 object integrity, retention days, and access policies.</p>
          <p class="mt-4 font-mono text-xs text-slate-500">Demo rate: {{ i18n.formatEur('0.021', 3) }} / GB-mo · Local single-process disk store</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-6">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Block Volumes &amp; Snapshots</h2>
          <p class="mt-2 text-sm text-slate-600">Snapshots are point-in-time references bound to the primary volume — explicitly distinct from independent backups.</p>
          <p class="mt-4 font-mono text-xs text-slate-500">Demo rate: {{ i18n.formatEur('0.095', 3) }} / GB-mo · Snapshot: {{ i18n.formatEur('0.045', 3) }}</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-6">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Independent Backups &amp; POSIX</h2>
          <p class="mt-2 text-sm text-slate-600">Dedicated backup records target a secondary demonstration region with checksum verification and retention rules.</p>
          <p class="mt-4 font-mono text-xs text-slate-500">Backup: {{ i18n.formatEur('0.032', 3) }} / GB-mo · POSIX: {{ i18n.formatEur('0.160', 3) }}</p>
        </div>
      </div>
    </div>
  `,
})
export class StoragePage {
  readonly i18n = inject(I18nService);
}

@Component({
  selector: 'app-private-infra-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="grid grid-cols-1 gap-10 lg:grid-cols-12">
        <div class="lg:col-span-6 space-y-6">
          <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
          <h1 class="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.privateInfra') }}
          </h1>
          <p class="text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'Baies dédiées, grappes GPU monoclients et connectivité privée BGP/WireGuard avec frontières de résidence explicites.'
                : i18n.locale() === 'de'
                  ? 'Dedizierte Racks, Single-Tenant-GPU-Cluster und private BGP/WireGuard-Konnektivität mit expliziten Datenresidenzgrenzen.'
                  : 'Single-tenant bare-metal racks, dedicated accelerator pods, and isolated private interconnects for workloads requiring physical separation.'
            }}
          </p>
          <div class="overflow-hidden rounded-xl border border-slate-200 bg-[#0B1324] aspect-[4/3]">
            @if (!imgFailed()) {
              <img
                src="/assets/images/network_fiber_interconnect_1795172703655.jpg"
                alt="Optical fiber patch panel interconnect"
                referrerpolicy="no-referrer"
                (error)="imgFailed.set(true)"
                class="h-full w-full object-cover"
              />
            }
          </div>
        </div>

        <div class="lg:col-span-6">
          <div class="rounded-xl border border-slate-200 bg-white p-6 sm:p-8">
            <h2 class="font-display text-xl font-semibold text-[#070D19]">
              {{ i18n.t('home.cta.requestCapacity') }}
            </h2>
            <p class="mt-1 text-sm text-slate-600">
              {{ i18n.t('common.simulatedTag') }} — Requests are logged locally in the demonstration backend.
            </p>
            <form [formGroup]="form" (ngSubmit)="submit()" class="mt-6 space-y-4">
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Full Name</span>
                <input formControlName="name" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-[#1D4ED8] focus:outline-none" />
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Work Email</span>
                <input formControlName="email" type="email" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-[#1D4ED8] focus:outline-none" />
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Organisation</span>
                <input formControlName="organisation" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-[#1D4ED8] focus:outline-none" />
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Capacity &amp; Residency Requirements</span>
                <textarea formControlName="message" rows="4" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-[#1D4ED8] focus:outline-none"></textarea>
              </label>
              @if (errorMsg()) {
                <p class="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{{ errorMsg() }}</p>
              }
              @if (submittedId()) {
                <div class="text-xs text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2.5">
                  Inquiry recorded (ID: <span class="font-mono">{{ submittedId() }}</span>). No physical reservation is created automatically.
                </div>
              }
              <button
                type="submit"
                [disabled]="submitting()"
                class="inline-flex items-center gap-2 rounded-lg bg-[#070D19] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1D4ED8] disabled:opacity-50 transition-colors cursor-pointer"
              >
                <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">send</mat-icon>
                <span>{{ i18n.t('common.submit') }}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PrivateInfrastructurePage {
  readonly i18n = inject(I18nService);
  private readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly imgFailed = signal(false);
  readonly submitting = signal(false);
  readonly submittedId = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    organisation: ['', [Validators.required]],
    message: ['', [Validators.required, Validators.minLength(10)]],
  });

  async submit(): Promise<void> {
    this.errorMsg.set(null);
    if (this.form.invalid) {
      this.errorMsg.set(this.i18n.t('common.required'));
      return;
    }
    this.submitting.set(true);
    try {
      const res = await this.cp.submitContactInquiry({
        ...this.form.getRawValue(),
        topic: 'dedicated-capacity',
      });
      this.submittedId.set(res.id);
      this.form.reset();
    } catch (e) {
      this.errorMsg.set(e instanceof Error ? e.message : 'Submission failed');
    } finally {
      this.submitting.set(false);
    }
  }
}

@Component({
  selector: 'app-data-centres-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="max-w-3xl">
        <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
        <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
          {{ i18n.t('nav.dataCentres') }}
        </h1>
        <p class="mt-3 text-base text-slate-600 leading-relaxed">
          {{
            i18n.locale() === 'fr'
              ? 'Les trois régions ci-dessous sont des sites de démonstration synthétiques utilisés pour valider le placement, la résidence et la réconciliation. Aucune installation physique active n’est revendiquée.'
              : i18n.locale() === 'de'
                ? 'Die drei aufgeführten Regionen sind synthetische Demonstrationsstandorte für Platzierungs-, Residenz- und Ausfalltests. Es werden keine realen aktiven Rechenzentren beansprucht.'
                : 'The three regions below are synthetic demonstration sites used to test placement policies, residency records, and host failure reconciliation. AUREOM EUROPE does not invent live physical facilities or third-party certifications.'
          }}
        </p>
      </div>

      <div class="overflow-hidden rounded-xl border border-slate-200 bg-[#0B1324] aspect-[16/7]">
        @if (!imgFailed()) {
          <img
            src="/assets/images/european_facility_exterior_1795172703974.jpg"
            alt="European data centre campus visual reference"
            referrerpolicy="no-referrer"
            (error)="imgFailed.set(true)"
            class="h-full w-full object-cover"
          />
        }
      </div>

      <div class="grid grid-cols-1 gap-6 md:grid-cols-3">
        @for (r of cp.catalog()?.regions ?? []; track r.id) {
          <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
            <div class="flex items-center justify-between">
              <span class="font-mono text-sm font-semibold text-[#1D4ED8]">{{ r.code }}</span>
              <span class="font-mono text-xs text-slate-500">{{ r.simulationLabel }}</span>
            </div>
            <h2 class="font-display text-xl font-semibold text-[#070D19]">{{ r.city }}, {{ r.country }}</h2>
            <p class="text-xs text-slate-600 leading-relaxed">{{ r.coolingArchitecture }}</p>
            <p class="text-xs text-slate-600 leading-relaxed">{{ r.gridCarbonNote }}</p>
            <div class="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-mono text-slate-600">
              <span>Arch: {{ r.supportedArchitectures.join(', ') }}</span>
              <span>{{ r.status }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class DataCentresPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  readonly imgFailed = signal(false);

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) await this.cp.loadCatalog();
  }
}

@Component({
  selector: 'app-pricing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="max-w-3xl">
        <div class="font-mono text-xs text-[#1D4ED8]">Price Book v2026.11-demo · EUR · {{ i18n.t('common.simulatedTag') }}</div>
        <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
          {{ i18n.t('nav.pricing') }}
        </h1>
        <p class="mt-3 text-base text-slate-600 leading-relaxed">
          {{ i18n.t('billing.explanation') }}
        </p>
      </div>

      <!-- Interactive EUR Calculator -->
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <form [formGroup]="calcForm" class="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">
            {{ i18n.locale() === 'fr' ? 'Estimateur mensuel en EUR (Démo)' : i18n.locale() === 'de' ? 'Monatlicher EUR-Kostenrechner (Demo)' : 'Monthly EUR Cost Estimator (Demo Rates)' }}
          </h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">vCPU Count</span>
              <input formControlName="vcpus" type="number" min="0" max="512" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Memory (GiB)</span>
              <input formControlName="memoryGiB" type="number" min="0" max="4096" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">GPU Devices (H100-Sim)</span>
              <input formControlName="gpus" type="number" min="0" max="64" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Hours / Month</span>
              <input formControlName="hours" type="number" min="1" max="744" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Block Storage (GB)</span>
              <input formControlName="blockGB" type="number" min="0" max="50000" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">VAT Rate (% configurable)</span>
              <input formControlName="vatPercent" type="number" min="0" max="30" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </label>
          </div>
        </form>

        <div class="lg:col-span-5 rounded-xl bg-[#070D19] text-white p-6 flex flex-col justify-between space-y-6">
          <div>
            <div class="font-mono text-xs text-cyan-300">Deterministic Estimate · EUR</div>
            <div class="mt-3 font-mono text-4xl font-bold tabular-nums">
              {{ i18n.formatEur(estimate().totalIncVat, 2) }}
            </div>
            <p class="mt-1 text-xs text-slate-400">
              Subtotal: {{ i18n.formatEur(estimate().subtotal, 2) }} · VAT ({{ calcForm.controls.vatPercent.value }}%): {{ i18n.formatEur(estimate().vat, 2) }}
            </p>
            <div class="mt-6 space-y-2 border-t border-white/10 pt-4 text-xs">
              <div class="flex justify-between">
                <span class="text-slate-300">Compute (vCPU + RAM)</span>
                <span class="font-mono tabular-nums">{{ i18n.formatEur(estimate().compute, 2) }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-300">GPU Accelerators</span>
                <span class="font-mono tabular-nums">{{ i18n.formatEur(estimate().gpu, 2) }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-300">Block Storage</span>
                <span class="font-mono tabular-nums">{{ i18n.formatEur(estimate().storage, 2) }}</span>
              </div>
            </div>
          </div>
          <div class="space-y-3 border-t border-white/10 pt-4">
            <p class="text-xs text-slate-400 leading-relaxed">
              {{ i18n.t('contract.reviewNotice') }}
            </p>
            <a
              routerLink="/console/billing"
              class="inline-flex items-center justify-center w-full rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors"
            >
              {{ i18n.t('nav.customerConsole') }} · {{ i18n.t('console.nav.billing') }}
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PricingPage implements OnInit {
  readonly i18n = inject(I18nService);
  private readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly calcForm = this.fb.nonNullable.group({
    vcpus: [8],
    memoryGiB: [32],
    gpus: [1],
    hours: [120],
    blockGB: [200],
    vatPercent: [25],
  });

  readonly formTick = signal(0);

  readonly estimate = computed(() => {
    this.formTick();
    const v = this.calcForm.getRawValue();
    const compute = (v.vcpus * 0.024 + v.memoryGiB * 0.0045) * v.hours;
    const gpu = v.gpus * 2.85 * v.hours;
    const storage = v.blockGB * 0.095;
    const subtotal = compute + gpu + storage;
    const vat = subtotal * (v.vatPercent / 100);
    return {
      compute,
      gpu,
      storage,
      subtotal,
      vat,
      totalIncVat: subtotal + vat,
    };
  });

  async ngOnInit(): Promise<void> {
    this.calcForm.valueChanges.subscribe(() => this.formTick.update((x) => x + 1));
    if (!this.cp.catalog()) await this.cp.loadCatalog();
  }
}

@Component({
  selector: 'app-security-governance-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="max-w-3xl">
        <div class="font-mono text-xs text-[#1D4ED8]">Data Governance &amp; Placement Boundaries</div>
        <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
          {{ i18n.t('nav.security') }}
        </h1>
        <p class="mt-3 text-base text-slate-600 leading-relaxed">
          {{
            i18n.locale() === 'fr'
              ? 'Un nom européen ou un serveur situé dans l’UE ne constitue pas à lui seul une preuve de souveraineté ou de conformité réglementaire. Voici les frontières réelles configurées.'
              : i18n.locale() === 'de'
                ? 'Ein europäischer Firmenname oder EU-Serverstandort begründet allein noch keine vollständige Souveränität oder Konformität. Hier dokumentieren wir alle realen Grenzen.'
                : 'A European company name or EU server location does not automatically constitute regulatory compliance or full sovereignty. We record all seven residency and operational boundaries explicitly.'
          }}
        </p>
      </div>

      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <table class="w-full text-left text-sm">
          <thead class="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
            <tr>
              <th class="px-6 py-3 font-semibold">Governance Layer</th>
              <th class="px-6 py-3 font-semibold">Configured Boundary (Demo Baseline)</th>
              <th class="px-6 py-3 font-semibold">Required Prior to Launch</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 text-xs sm:text-sm">
            <tr><td class="px-6 py-3 font-medium">Compute Location</td><td class="px-6 py-3 font-mono">eu-sim-nord-1 / central-1 / west-1</td><td class="px-6 py-3 text-slate-600">Colocation or facility lease + physical rack custody</td></tr>
            <tr><td class="px-6 py-3 font-medium">Primary Storage</td><td class="px-6 py-3 font-mono">Pinned to project primaryRegionId</td><td class="px-6 py-3 text-slate-600">Hardware encryption KMS + erasure policy</td></tr>
            <tr><td class="px-6 py-3 font-medium">Replicas &amp; Backups</td><td class="px-6 py-3 font-mono">Explicitly separate target regions</td><td class="px-6 py-3 text-slate-600">Cross-site dark fiber / independent vault keys</td></tr>
            <tr><td class="px-6 py-3 font-medium">Audit &amp; System Logs</td><td class="px-6 py-3 font-mono">Control-plane append log (secrets redacted)</td><td class="px-6 py-3 text-slate-600">WORM log shipping &amp; SIEM retention</td></tr>
            <tr><td class="px-6 py-3 font-medium">Support Access</td><td class="px-6 py-3 font-mono">Explicit approval + scoped token</td><td class="px-6 py-3 text-slate-600">Background-checked EU on-call + PAM session recording</td></tr>
            <tr><td class="px-6 py-3 font-medium">External Subprocessors</td><td class="px-6 py-3 font-mono">Optional Gemini 4.0 AI Assistant (opt-in redacted metadata only)</td><td class="px-6 py-3 text-slate-600">Signed DPA &amp; customer opt-out switch</td></tr>
          </tbody>
        </table>
      </div>

      <div class="rounded-xl border border-amber-200 bg-amber-50 p-5 text-xs text-amber-900">
        {{ i18n.t('contract.reviewNotice') }}
      </div>

      <a routerLink="/console/projects" class="inline-flex items-center rounded-lg bg-[#070D19] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1D4ED8] transition-colors">
        Configure Residency Policy in Console →
      </a>
    </div>
  `,
})
export class SecurityGovernancePage {
  readonly i18n = inject(I18nService);
}
