import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import {ArchitectureDiagram} from '../shared/architecture-diagram';

@Component({
  selector: 'app-home-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule, ArchitectureDiagram],
  template: `
    <!-- Hero Section: Midnight Navy & Glacier White with Architectural Photography -->
    <section class="relative overflow-hidden bg-[#070D19] text-white">
      <div
        class="pointer-events-none absolute inset-0 opacity-35"
        style="background: radial-gradient(circle at 75% 20%, rgba(79, 70, 229, 0.35), transparent 55%), radial-gradient(circle at 20% 80%, rgba(8, 145, 178, 0.25), transparent 50%);"
      ></div>

      <div class="relative mx-auto max-w-7xl px-4 sm:px-6 py-14 lg:py-20">
        <div class="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:items-stretch">
          <div class="lg:col-span-7 flex flex-col justify-between gap-8">
            <div>
              <p class="text-xs font-medium tracking-wide text-cyan-300">
                {{ i18n.t('home.eyebrow') }}
              </p>
              <h1
                class="mt-4 font-display font-bold tracking-tight text-white leading-[1.08]"
                style="font-size: clamp(2.25rem, 4vw, 3.65rem); text-wrap: balance;"
              >
                {{ i18n.t('home.headline') }}
              </h1>
              <p class="mt-5 max-w-2xl text-base sm:text-lg leading-relaxed text-slate-300">
                {{ i18n.t('home.subheadline') }}
              </p>
              <p class="mt-4 font-mono text-sm text-cyan-200">
                {{ i18n.t('brand.motto') }}
              </p>
            </div>

            <!-- Three clear paths -->
            <div class="flex flex-wrap items-center gap-3 pt-2">
              <a
                routerLink="/console/compute"
                class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-3 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400"
              >
                <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">dns</mat-icon>
                <span>{{ i18n.t('home.cta.launchInstance') }}</span>
              </a>
              <a
                routerLink="/console/jobs"
                class="inline-flex items-center gap-2 rounded-lg border border-white/20 bg-[#111C33] px-5 py-3 text-sm font-semibold text-white hover:border-cyan-400/60 hover:bg-[#16233F] transition-colors whitespace-nowrap shrink-0"
              >
                <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">memory</mat-icon>
                <span>{{ i18n.t('home.cta.submitJob') }}</span>
              </a>
              <a
                routerLink="/private-infrastructure"
                class="inline-flex items-center gap-2 rounded-lg border border-white/15 px-4 py-3 text-sm font-medium text-slate-200 hover:text-white hover:border-white/35 transition-colors whitespace-nowrap shrink-0"
              >
                <span>{{ i18n.t('home.cta.requestCapacity') }}</span>
                <mat-icon class="!text-[16px] !h-4 !w-4">arrow_forward</mat-icon>
              </a>
            </div>
          </div>

          <div class="lg:col-span-5 flex">
            <div class="relative w-full overflow-hidden rounded-xl border border-white/15 bg-[#0B1324] min-h-[280px]">
              @if (!heroImgFailed()) {
                <img
                  src="/assets/images/hero_datacenter_hall_1795172703546.jpg"
                  alt="European data centre server hall corridor"
                  referrerpolicy="no-referrer"
                  (error)="heroImgFailed.set(true)"
                  class="h-full w-full object-cover"
                />
              }
              <div class="absolute inset-0 bg-gradient-to-t from-[#070D19]/90 via-[#070D19]/25 to-transparent"></div>
              <div class="absolute bottom-0 left-0 right-0 p-5 text-xs text-slate-200">
                <div class="flex flex-wrap items-center gap-2 text-cyan-300 font-mono">
                  <span>eu-sim-nord-1</span>
                  <span aria-hidden="true">·</span>
                  <span>eu-sim-central-1</span>
                  <span aria-hidden="true">·</span>
                  <span>eu-sim-west-1</span>
                </div>
                <p class="mt-1.5 text-slate-300">
                  {{ i18n.t('common.simulatedTag') }} — {{ i18n.locale() === 'fr' ? 'Illustration architecturale' : i18n.locale() === 'de' ? 'Architekturvisualisierung' : 'Architectural reference photography' }}
                </p>
              </div>
            </div>
          </div>
        </div>

        <!-- Full-Width Synthetic Spec Strip below Hero Split -->
        <div class="mt-10 grid grid-cols-1 gap-4 border-t border-white/10 pt-8 sm:grid-cols-2 lg:grid-cols-4">
          <div class="rounded-xl border border-white/10 bg-[#0B1324] p-4">
            <div class="text-xs text-slate-400">
              {{ i18n.locale() === 'fr' ? 'Régions de démo simulées' : i18n.locale() === 'de' ? 'Simulierte Demo-Regionen' : 'Simulated Demo Regions' }}
            </div>
            <div class="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">3 EU</div>
            <div class="mt-1 text-xs text-cyan-300">Luleå · Frankfurt · Grenoble</div>
          </div>
          <div class="rounded-xl border border-white/10 bg-[#0B1324] p-4">
            <div class="text-xs text-slate-400">
              {{ i18n.locale() === 'fr' ? 'Calcul de base (tarif démo)' : i18n.locale() === 'de' ? 'Basis-Compute (Demo-Tarif)' : 'Baseline Compute (Demo Rate)' }}
            </div>
            <div class="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">
              {{ i18n.formatEur('0.168', 3) }}<span class="text-sm font-normal text-slate-400">/h</span>
            </div>
            <div class="mt-1 text-xs text-slate-400">eu-gp-small · 4 vCPU · 16 GiB</div>
          </div>
          <div class="rounded-xl border border-white/10 bg-[#0B1324] p-4">
            <div class="text-xs text-slate-400">
              {{ i18n.locale() === 'fr' ? 'Accélérateur GPU (simulé)' : i18n.locale() === 'de' ? 'GPU-Beschleuniger (simuliert)' : 'GPU Accelerator (Simulated)' }}
            </div>
            <div class="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">
              {{ i18n.formatEur('2.85', 2) }}<span class="text-sm font-normal text-slate-400">/h</span>
            </div>
            <div class="mt-1 text-xs text-slate-400">80 GB HBM · CUDA 12.4 runtime</div>
          </div>
          <div class="rounded-xl border border-white/10 bg-[#0B1324] p-4">
            <div class="text-xs text-slate-400">
              {{ i18n.locale() === 'fr' ? 'Langues de la plateforme' : i18n.locale() === 'de' ? 'Plattformsprachen' : 'Platform Localisation' }}
            </div>
            <div class="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">EN · FR · DE</div>
            <div class="mt-1 text-xs text-slate-400">
              {{ i18n.locale() === 'fr' ? 'Console, API & Facturation EUR' : i18n.locale() === 'de' ? 'Konsole, API & EUR-Abrechnung' : 'Console, Docs & EUR Metering' }}
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Asymmetric Capabilities Section -->
    <section class="mx-auto max-w-7xl px-4 sm:px-6 py-16">
      <div class="max-w-3xl">
        <h2 class="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#070D19]" style="text-wrap: balance;">
          {{ i18n.t('home.cap.title') }}
        </h2>
        <p class="mt-3 text-base text-slate-600 leading-relaxed">
          {{ i18n.t('home.cap.subtitle') }}
        </p>
      </div>

      <div class="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-12">
        <!-- Card 01 -->
        <div class="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between gap-4">
              <h3 class="font-display text-xl font-semibold text-[#070D19]">
                {{ i18n.t('home.cap.compute.title') }}
              </h3>
              <span class="font-mono text-xs text-slate-500">x86_64 · aarch64</span>
            </div>
            <p class="mt-3 text-sm leading-relaxed text-slate-600">
              {{ i18n.t('home.cap.compute.desc') }}
            </p>
          </div>
          <div class="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4 text-xs">
            <span class="font-mono text-slate-500">Requested → Validating → Provisioning → Running</span>
            <a routerLink="/cloud-compute" class="font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0">
              {{ i18n.t('nav.cloudCompute') }} →
            </a>
          </div>
        </div>

        <!-- Card 02 with GPU Photography -->
        <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white overflow-hidden flex flex-col">
          <div class="h-44 bg-[#0B1324] relative overflow-hidden">
            @if (!gpuImgFailed()) {
              <img
                src="/assets/images/gpu_compute_cluster_1795172703951.jpg"
                alt="Liquid-cooled GPU compute blades"
                referrerpolicy="no-referrer"
                (error)="gpuImgFailed.set(true)"
                class="h-full w-full object-cover"
              />
            }
          </div>
          <div class="p-6 flex-1 flex flex-col justify-between">
            <div>
              <h3 class="font-display text-xl font-semibold text-[#070D19]">
                {{ i18n.t('home.cap.gpu.title') }}
              </h3>
              <p class="mt-2 text-sm leading-relaxed text-slate-600">
                {{ i18n.t('home.cap.gpu.desc') }}
              </p>
            </div>
            <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
              <span class="font-mono text-slate-500">H100 / L40S / MI300X (Sim)</span>
              <a routerLink="/gpu-computing" class="font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0">
                {{ i18n.t('nav.gpuComputing') }} →
              </a>
            </div>
          </div>
        </div>

        <!-- Card 03 with Exterior Photography -->
        <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white overflow-hidden flex flex-col">
          <div class="h-44 bg-[#0B1324] relative overflow-hidden">
            @if (!extImgFailed()) {
              <img
                src="/assets/images/european_facility_exterior_1795172703974.jpg"
                alt="Minimalist European data centre campus architecture"
                referrerpolicy="no-referrer"
                (error)="extImgFailed.set(true)"
                class="h-full w-full object-cover"
              />
            }
          </div>
          <div class="p-6 flex-1 flex flex-col justify-between">
            <div>
              <h3 class="font-display text-xl font-semibold text-[#070D19]">
                {{ i18n.t('home.cap.hpc.title') }}
              </h3>
              <p class="mt-2 text-sm leading-relaxed text-slate-600">
                {{ i18n.t('home.cap.hpc.desc') }}
              </p>
            </div>
            <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
              <span class="font-mono text-slate-500">Slurm · Local Queue Sim</span>
              <a routerLink="/supercomputing" class="font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0">
                {{ i18n.t('nav.supercomputing') }} →
              </a>
            </div>
          </div>
        </div>

        <!-- Card 04 -->
        <div class="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between gap-4">
              <h3 class="font-display text-xl font-semibold text-[#070D19]">
                {{ i18n.t('home.cap.storage.title') }}
              </h3>
              <span class="font-mono text-xs text-slate-500">S3 · Block · POSIX · Backup</span>
            </div>
            <p class="mt-3 text-sm leading-relaxed text-slate-600">
              {{ i18n.t('home.cap.storage.desc') }}
            </p>
            <div class="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-100 pt-5 text-xs">
              <div>
                <div class="font-semibold text-[#070D19]">
                  {{ i18n.locale() === 'fr' ? 'Emplacement explicite' : i18n.locale() === 'de' ? 'Expliziter Standort' : 'Explicit Residency' }}
                </div>
                <p class="mt-1 text-slate-600">Compute, primary storage, replicas, backups, logs, support.</p>
              </div>
              <div>
                <div class="font-semibold text-[#070D19]">
                  {{ i18n.locale() === 'fr' ? 'Facturation décimale EUR' : i18n.locale() === 'de' ? 'EUR-Dezimalabrechnung' : 'Decimal EUR Ledger' }}
                </div>
                <p class="mt-1 text-slate-600">Idempotent metering preventing duplicate period charges.</p>
              </div>
              <div>
                <div class="font-semibold text-[#070D19]">
                  {{ i18n.locale() === 'fr' ? 'Réconciliation fiable' : i18n.locale() === 'de' ? 'Zuverlässiger Abgleich' : 'Observed State Sync' }}
                </div>
                <p class="mt-1 text-slate-600">Host failure simulation and post-restart reconciliation.</p>
              </div>
            </div>
          </div>
          <div class="mt-6 flex items-center justify-between border-t border-slate-100 pt-4 text-xs">
            <a routerLink="/security" class="font-medium text-slate-600 hover:text-[#070D19] whitespace-nowrap shrink-0">
              {{ i18n.t('nav.security') }} →
            </a>
            <a routerLink="/storage" class="font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap shrink-0">
              {{ i18n.t('nav.storage') }} →
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- Architecture Diagram Section -->
    <section class="mx-auto max-w-7xl px-4 sm:px-6 pb-16">
      <app-architecture-diagram />
    </section>

    <!-- Guided Local Demonstration Callout -->
    <section class="bg-[#0B1324] text-white border-t border-white/10">
      <div class="mx-auto max-w-7xl px-4 sm:px-6 py-14 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
        <div class="max-w-2xl">
          <div class="font-mono text-xs text-cyan-300">
            {{ i18n.t('common.simulatedTag') }} · v2026.11-demo
          </div>
          <h2 class="mt-2 font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
            {{ i18n.t('home.walkthrough.title') }}
          </h2>
          <p class="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
            {{ i18n.t('home.walkthrough.desc') }}
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-3 shrink-0">
          <a
            routerLink="/console/overview"
            class="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-3 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">play_arrow</mat-icon>
            <span>{{ i18n.t('home.walkthrough.cta') }}</span>
          </a>
          <a
            routerLink="/docs"
            class="inline-flex items-center gap-2 rounded-lg border border-white/20 px-5 py-3 text-sm font-medium text-slate-200 hover:text-white hover:border-white/40 transition-colors whitespace-nowrap shrink-0"
          >
            <span>{{ i18n.t('nav.documentation') }}</span>
          </a>
        </div>
      </div>
    </section>
  `,
})
export class HomePage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);

  readonly heroImgFailed = signal(false);
  readonly gpuImgFailed = signal(false);
  readonly extImgFailed = signal(false);

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) {
      await this.cp.loadCatalog().catch(() => undefined);
    }
  }
}
