import {HttpClient} from '@angular/common/http';
import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {firstValueFrom} from 'rxjs';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import type {DemoRegion, InfrastructureIncident, UserRole} from '../core/models';

@Component({
  selector: 'app-documentation-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-10">
      <div class="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div class="max-w-3xl">
          <div class="font-mono text-xs text-[#1D4ED8]">OpenAPI 3.1 · SDKs · CLI · Playground</div>
          <h1 class="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
            {{ i18n.t('nav.documentation') }}
          </h1>
          <p class="mt-3 text-base text-slate-600 leading-relaxed">
            {{
              i18n.locale() === 'fr'
                ? 'API REST paginée avec clés d’idempotence, identifiants X-Request-Id et erreurs structurées pour les 12 domaines de ressources.'
                : i18n.locale() === 'de'
                  ? 'Paginierte REST-API mit Idempotenz-Schlüsseln, X-Request-Id-Tracing und strukturierten Fehlern über alle 12 Ressourcengruppen.'
                  : 'Paginated REST APIs with Idempotency-Key support, X-Request-Id correlation, structured JSON errors, Python/TypeScript examples, and a live playground using synthetic credentials.'
            }}
          </p>
        </div>
        <a
          href="/api/openapi.json"
          target="_blank"
          rel="noopener"
          class="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-[#070D19] hover:bg-slate-50 whitespace-nowrap shrink-0"
        >
          <mat-icon class="!text-[16px] !h-4 !w-4">description</mat-icon>
          <span>/api/openapi.json</span>
        </a>
      </div>

      <!-- 12 Resource Groups -->
      <div class="rounded-xl border border-slate-200 bg-white p-6">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">12 Documented API Resource Groups</h2>
        <div class="mt-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 font-mono text-xs">
          @for (ep of resourceGroups; track ep.name) {
            <div class="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <div class="font-semibold text-[#070D19]">{{ ep.name }}</div>
              <div class="mt-1 text-[#1D4ED8]">{{ ep.path }}</div>
            </div>
          }
        </div>
      </div>

      <!-- SDK & CLI Examples -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div class="rounded-xl bg-[#070D19] text-slate-200 p-5">
          <div class="font-mono text-xs text-cyan-300 mb-2">TypeScript SDK Example</div>
          <pre class="font-mono text-xs overflow-x-auto leading-relaxed">const res = await fetch('/api/instances?limit=25', {{ '{' }}
  headers: {{ '{' }}
    'Authorization': 'Bearer ak_demo_7f29_...',
    'Idempotency-Key': 'inst-2026-11-20-01'
  {{ '}' }}
{{ '}' }});
const data = await res.json();</pre>
        </div>
        <div class="rounded-xl bg-[#070D19] text-slate-200 p-5">
          <div class="font-mono text-xs text-cyan-300 mb-2">Python Adapter Client</div>
          <pre class="font-mono text-xs overflow-x-auto leading-relaxed">import requests
r = requests.post(
  'http://localhost:3000/api/jobs',
  headers={{ '{' }}'Idempotency-Key': 'job-001'{{ '}' }},
  json={{ '{' }}'projectId': 'proj_baltic_hydro_sim', ...{{ '}' }}
)</pre>
        </div>
        <div class="rounded-xl bg-[#070D19] text-slate-200 p-5">
          <div class="font-mono text-xs text-cyan-300 mb-2">aureom CLI</div>
          <pre class="font-mono text-xs overflow-x-auto leading-relaxed">$ aureom auth login --org org_ncrc_eu_demo
$ aureom compute create --template eu-gp-small --region eu-sim-nord-1
$ aureom jobs submit --backend slurm-adapter-sim --gpus 1</pre>
        </div>
      </div>

      <!-- Interactive API Playground -->
      <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 class="font-display text-lg font-semibold text-[#070D19]">Live API Playground (Synthetic Credentials)</h2>
            <p class="text-xs text-slate-500">Executes real HTTP requests against the Express control-plane server with synthetic token <code class="font-mono">ak_demo_7f29_sandbox</code>.</p>
          </div>
          <div class="flex flex-wrap gap-2">
            @for (ep of playgroundEndpoints; track ep) {
              <button
                type="button"
                (click)="endpointControl.setValue(ep); runPlayground()"
                class="cursor-pointer rounded-md border px-2.5 py-1 font-mono text-xs transition-colors"
                [class]="endpointControl.value === ep ? 'border-[#1D4ED8] bg-[#1D4ED8] text-white' : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'"
              >
                GET {{ ep }}
              </button>
            }
          </div>
        </div>
        <div class="flex gap-2">
          <input
            [formControl]="endpointControl"
            type="text"
            class="flex-1 rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs"
          />
          <button
            type="button"
            (click)="runPlayground()"
            class="cursor-pointer rounded-lg bg-[#070D19] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
          >
            Execute GET
          </button>
        </div>
        <pre class="rounded-lg bg-[#070D19] text-cyan-200 p-4 font-mono text-xs overflow-x-auto max-h-80">{{ playgroundOutput() }}</pre>
      </div>
    </div>
  `,
})
export class DocumentationPage implements OnInit {
  readonly i18n = inject(I18nService);
  private readonly http = inject(HttpClient);
  private readonly fb = inject(FormBuilder);

  readonly endpointControl = this.fb.nonNullable.control('/api/projects?limit=10');
  readonly playgroundOutput = signal('Click "Execute GET" to inspect live control-plane JSON...');

  readonly playgroundEndpoints = [
    '/api/projects?limit=10',
    '/api/instances',
    '/api/gpus',
    '/api/jobs',
    '/api/usage',
    '/api/audit-events',
  ];

  readonly resourceGroups = [
    {name: 'Organisations', path: '/api/organisations'},
    {name: 'Projects', path: '/api/projects'},
    {name: 'Quotas', path: '/api/projects/:id/quotas'},
    {name: 'Instances', path: '/api/instances'},
    {name: 'GPU allocations', path: '/api/gpus'},
    {name: 'Jobs', path: '/api/jobs'},
    {name: 'Volumes', path: '/api/storage'},
    {name: 'Buckets', path: '/api/storage/buckets'},
    {name: 'Networks', path: '/api/networks'},
    {name: 'Usage', path: '/api/usage'},
    {name: 'Invoices', path: '/api/invoices'},
    {name: 'Audit events', path: '/api/audit-events'},
  ];

  async ngOnInit(): Promise<void> {
    await this.runPlayground();
  }

  async runPlayground(): Promise<void> {
    const url = this.endpointControl.value;
    try {
      const res = await firstValueFrom(
        this.http.get(url, {
          headers: {
            Authorization: 'Bearer ak_demo_7f29_sandbox',
            'x-aureom-org': 'org_ncrc_eu_demo',
          },
          observe: 'response',
        }),
      );
      this.playgroundOutput.set(
        `HTTP ${res.status} · X-Request-Id: ${res.headers.get('X-Request-Id') ?? 'auto'}\n\n` +
          JSON.stringify(res.body, null, 2),
      );
    } catch (err) {
      this.playgroundOutput.set(JSON.stringify(err, null, 2));
    }
  }
}

@Component({
  selector: 'app-service-status-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 space-y-8">
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div class="font-mono text-xs text-[#1D4ED8]">Live Control-Plane Telemetry Feed ({{ i18n.t('common.simulatedTag') }})</div>
          <h1 class="mt-2 font-display text-3xl font-bold text-[#070D19]">{{ i18n.t('nav.status') }}</h1>
        </div>
        <button
          type="button"
          (click)="refresh()"
          class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-[#070D19] hover:bg-slate-50"
        >
          <mat-icon class="!text-[16px] !h-4 !w-4">refresh</mat-icon>
          <span>{{ i18n.t('common.refresh') }}</span>
        </button>
      </div>

      @if (status(); as s) {
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div class="rounded-xl border border-slate-200 bg-white p-5">
            <div class="text-xs text-slate-500">Healthy Hosts</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ s.healthyHosts }} / {{ s.totalHosts }}</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-5">
            <div class="text-xs text-slate-500">Active Incidents</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums" [class]="s.activeIncidents.length > 0 ? 'text-red-700' : 'text-emerald-700'">
              {{ s.activeIncidents.length }}
            </div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-5">
            <div class="text-xs text-slate-500">Queued Jobs</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ s.queuedJobs }}</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-5">
            <div class="text-xs text-slate-500">Running Jobs</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ s.runningJobs }}</div>
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
          @for (r of s.regions; track r.id) {
            <div class="p-5 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div class="font-mono text-sm font-semibold text-[#070D19]">{{ r.code }} · {{ r.city }}</div>
                <div class="text-xs text-slate-500 mt-0.5">{{ r.simulationLabel }}</div>
              </div>
              <span
                class="font-mono text-xs font-semibold px-2.5 py-1 rounded-md border"
                [class]="r.status === 'operational' ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-red-200 bg-red-50 text-red-800'"
              >
                {{ r.status === 'operational' ? 'Operational (Sim)' : 'Degraded (Sim)' }}
              </span>
            </div>
          }
        </div>

        @if (s.activeIncidents.length > 0) {
          <div class="rounded-xl border border-red-200 bg-red-50 p-6 space-y-3">
            <h2 class="font-display text-lg font-semibold text-red-900">Active Infrastructure Incidents</h2>
            @for (inc of s.activeIncidents; track inc.id) {
              <div class="text-sm text-red-800">
                <div class="font-semibold">{{ inc.title }}</div>
                <div class="text-xs mt-1">{{ inc.summary }}</div>
              </div>
            }
          </div>
        }
      }
    </div>
  `,
})
export class ServiceStatusPage implements OnInit {
  readonly i18n = inject(I18nService);
  private readonly cp = inject(ControlPlaneService);
  readonly status = signal<{
    regions: DemoRegion[];
    activeIncidents: InfrastructureIncident[];
    healthyHosts: number;
    totalHosts: number;
    queuedJobs: number;
    runningJobs: number;
    isSimulated: true;
  } | null>(null);

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    this.status.set(await this.cp.getPublicStatus());
  }
}

@Component({
  selector: 'app-company-contact-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid grid-cols-1 gap-10 lg:grid-cols-12">
      <div class="lg:col-span-6 space-y-5">
        <div class="font-mono text-xs text-[#1D4ED8]">AUREOM EUROPE</div>
        <h1 class="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070D19]">
          {{ i18n.t('nav.company') }}
        </h1>
        <p class="font-mono text-sm text-[#1D4ED8]">{{ i18n.t('brand.motto') }}</p>
        <p class="text-base text-slate-600 leading-relaxed">
          {{
            i18n.locale() === 'fr'
              ? 'AUREOM EUROPE conçoit une infrastructure européenne de calcul cloud et intensif fondée sur la clarté opérationnelle, la réconciliation d’état et la transparence des limites.'
              : i18n.locale() === 'de'
                ? 'AUREOM EUROPE entwickelt europäische Cloud- und Supercomputing-Infrastruktur mit Fokus auf Betriebsklarheit, deterministischen Zustandsabgleich und ehrliche Systemgrenzen.'
                : 'AUREOM EUROPE builds European cloud and supercomputing control-plane software prioritising deterministic state reconciliation, transparent billing, and verifiable isolation boundaries.'
          }}
        </p>
      </div>

      <div class="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 sm:p-8">
        <h2 class="font-display text-xl font-semibold text-[#070D19]">Contact Engineering</h2>
        <form [formGroup]="form" (ngSubmit)="submit()" class="mt-5 space-y-4">
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Name</span>
            <input formControlName="name" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Email</span>
            <input formControlName="email" type="email" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Message</span>
            <textarea formControlName="message" rows="4" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"></textarea>
          </label>
          @if (sentId()) {
            <div class="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
              Recorded demonstration inquiry <span class="font-mono">{{ sentId() }}</span>.
            </div>
          }
          <button type="submit" class="cursor-pointer rounded-lg bg-[#070D19] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1D4ED8]">
            {{ i18n.t('common.submit') }}
          </button>
        </form>
      </div>
    </div>
  `,
})
export class CompanyContactPage {
  readonly i18n = inject(I18nService);
  private readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);
  readonly sentId = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    message: ['', Validators.required],
  });

  async submit(): Promise<void> {
    if (this.form.invalid) return;
    const val = this.form.getRawValue();
    const res = await this.cp.submitContactInquiry({
      ...val,
      organisation: 'Website Visitor',
      topic: 'general',
    });
    this.sentId.set(res.id);
    this.form.reset();
  }
}

@Component({
  selector: 'app-signin-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto max-w-md px-4 py-16">
      <div class="rounded-xl border border-slate-200 bg-white p-8 space-y-6">
        <div>
          <div class="font-mono text-xs text-[#1D4ED8]">{{ i18n.t('common.simulatedTag') }}</div>
          <h1 class="mt-2 font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('nav.signIn') }}</h1>
          <p class="mt-1 text-xs text-slate-600">Select a demonstration persona and confirm MFA verification to enter the Customer Console.</p>
        </div>

        <form [formGroup]="form" (ngSubmit)="signIn()" class="space-y-4">
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Organisation</span>
            <select formControlName="orgId" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
              <option value="org_ncrc_eu_demo">Nordic Climate Research Consortium (Demo)</option>
              <option value="org_rhein_bio_demo">Rheinland Genomics Lab (Isolated Org Demo)</option>
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Role</span>
            <select formControlName="role" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
              <option value="org_admin">Organisation Admin (Astrid Lindqvist)</option>
              <option value="project_engineer">Project Engineer (Henrik Weber)</option>
              <option value="infra_operator">Infrastructure Operator (Claire Moreau)</option>
              <option value="auditor">Read-Only Auditor</option>
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">MFA Verification Code (Demo)</span>
            <input formControlName="mfaCode" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <button
            type="submit"
            class="cursor-pointer w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#2563EB] transition-colors"
          >
            <mat-icon class="!text-[18px] !h-[18px] !w-[18px]">login</mat-icon>
            <span>{{ i18n.t('nav.customerConsole') }}</span>
          </button>
        </form>
      </div>
    </div>
  `,
})
export class SignInPage {
  readonly i18n = inject(I18nService);
  private readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);

  readonly form = this.fb.nonNullable.group({
    orgId: ['org_ncrc_eu_demo'],
    role: ['org_admin' as UserRole],
    mfaCode: ['482910', Validators.required],
  });

  async signIn(): Promise<void> {
    const {orgId, role} = this.form.getRawValue();
    const actor =
      role === 'infra_operator'
        ? 'claire.moreau@ncrc-demo.example.eu'
        : role === 'project_engineer'
          ? 'henrik.weber@ncrc-demo.example.eu'
          : role === 'auditor'
            ? 'auditor@ncrc-demo.example.eu'
            : 'astrid.lindqvist@ncrc-demo.example.eu';
    this.cp.setSession(orgId, actor, role);
    await this.cp.loadOverview();
    await this.router.navigateByUrl(role === 'infra_operator' ? '/console/operations' : '/console/overview');
  }
}
