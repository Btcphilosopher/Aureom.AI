import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {I18nService} from '../core/i18n.service';
import {LanguageSwitcher} from '../shared/language-switcher';

@Component({
  selector: 'app-public-shell',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatIconModule, LanguageSwitcher],
  template: `
    <div class="min-h-screen flex flex-col bg-[#F6F9FC] text-[#070D19]">
      <!-- Demonstration transparency notice -->
      <div class="bg-[#070D19] text-slate-300 border-b border-white/10 px-4 py-2 text-xs">
        <div class="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2">
          <span>{{ i18n.t('demo.banner') }}</span>
          <a
            routerLink="/status"
            class="font-medium text-cyan-300 hover:text-white underline-offset-4 hover:underline whitespace-nowrap shrink-0"
          >
            {{ i18n.t('nav.status') }}
          </a>
        </div>
      </div>

      <!-- 3-Zone Top Bar Contract -->
      <header class="sticky top-0 z-30 border-b border-slate-200/90 bg-white/95 backdrop-blur-sm">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
          <!-- Zone 1: Single-line Brand Wordmark -->
          <a
            routerLink="/"
            class="font-display text-lg font-bold tracking-tight text-[#070D19] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1D4ED8]"
          >
            {{ i18n.t('brand.name') }}
          </a>

          <!-- Zone 2: Clean single-line navigation links -->
          <nav class="hidden xl:flex items-center gap-5 text-sm font-medium text-slate-600" aria-label="Primary navigation">
            <a
              routerLink="/cloud-compute"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.cloudCompute') }}
            </a>
            <a
              routerLink="/gpu-computing"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.gpuComputing') }}
            </a>
            <a
              routerLink="/supercomputing"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.supercomputing') }}
            </a>
            <a
              routerLink="/storage"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.storage') }}
            </a>
            <a
              routerLink="/data-centres"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.dataCentres') }}
            </a>
            <a
              routerLink="/pricing"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.pricing') }}
            </a>
            <a
              routerLink="/docs"
              routerLinkActive="text-[#1D4ED8] underline underline-offset-8 decoration-2"
              class="hover:text-[#070D19] transition-colors whitespace-nowrap shrink-0"
            >
              {{ i18n.t('nav.documentation') }}
            </a>
          </nav>

          <!-- Zone 3: Language Switcher + Primary Console Action -->
          <div class="flex items-center gap-3 shrink-0">
            <div class="hidden sm:block">
              <app-language-switcher variant="light" />
            </div>
            <a
              routerLink="/console/overview"
              class="inline-flex items-center gap-1.5 rounded-lg bg-[#070D19] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1D4ED8] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1D4ED8]"
            >
              <mat-icon class="!text-[16px] !h-4 !w-4 leading-none">terminal</mat-icon>
              <span>{{ i18n.t('nav.customerConsole') }}</span>
            </a>
            <button
              type="button"
              (click)="mobileOpen.set(!mobileOpen())"
              class="xl:hidden inline-flex items-center justify-center rounded-lg border border-slate-200 p-2 text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              <mat-icon class="!text-[20px] !h-5 !w-5">{{ mobileOpen() ? 'close' : 'menu' }}</mat-icon>
            </button>
          </div>
        </div>

        @if (mobileOpen()) {
          <div class="xl:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3">
            <div class="sm:hidden pb-2">
              <app-language-switcher variant="light" />
            </div>
            <div class="grid grid-cols-2 gap-2 text-sm font-medium text-slate-700">
              <a routerLink="/cloud-compute" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.cloudCompute') }}</a>
              <a routerLink="/gpu-computing" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.gpuComputing') }}</a>
              <a routerLink="/supercomputing" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.supercomputing') }}</a>
              <a routerLink="/storage" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.storage') }}</a>
              <a routerLink="/data-centres" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.dataCentres') }}</a>
              <a routerLink="/pricing" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.pricing') }}</a>
              <a routerLink="/docs" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.documentation') }}</a>
              <a routerLink="/private-infrastructure" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.privateInfra') }}</a>
              <a routerLink="/security" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.security') }}</a>
              <a routerLink="/status" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.status') }}</a>
              <a routerLink="/company" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.company') }}</a>
              <a routerLink="/signin" (click)="mobileOpen.set(false)" class="py-1.5 hover:text-[#1D4ED8]">{{ i18n.t('nav.signIn') }}</a>
            </div>
          </div>
        }
      </header>

      <main class="flex-1">
        <router-outlet />
      </main>

      <!-- Quiet Architectural Footer -->
      <footer class="bg-[#070D19] text-slate-300 border-t border-white/10">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 py-12">
          <div class="grid grid-cols-1 gap-10 md:grid-cols-4">
            <div class="md:col-span-1">
              <div class="font-display text-lg font-bold tracking-tight text-white">
                {{ i18n.t('brand.name') }}
              </div>
              <p class="mt-2 text-sm text-slate-400">
                {{ i18n.t('brand.motto') }}
              </p>
              <p class="mt-4 text-xs leading-relaxed text-slate-400">
                {{ i18n.t('contract.reviewNotice') }}
              </p>
            </div>

            <div>
              <h4 class="text-xs font-semibold text-white mb-3">
                {{ i18n.locale() === 'fr' ? 'Infrastructure' : i18n.locale() === 'de' ? 'Infrastruktur' : 'Infrastructure' }}
              </h4>
              <ul class="space-y-2 text-sm text-slate-400">
                <li><a routerLink="/cloud-compute" class="hover:text-white transition-colors">{{ i18n.t('nav.cloudCompute') }}</a></li>
                <li><a routerLink="/gpu-computing" class="hover:text-white transition-colors">{{ i18n.t('nav.gpuComputing') }}</a></li>
                <li><a routerLink="/supercomputing" class="hover:text-white transition-colors">{{ i18n.t('nav.supercomputing') }}</a></li>
                <li><a routerLink="/storage" class="hover:text-white transition-colors">{{ i18n.t('nav.storage') }}</a></li>
                <li><a routerLink="/private-infrastructure" class="hover:text-white transition-colors">{{ i18n.t('nav.privateInfra') }}</a></li>
              </ul>
            </div>

            <div>
              <h4 class="text-xs font-semibold text-white mb-3">
                {{ i18n.locale() === 'fr' ? 'Plateforme & Gouvernance' : i18n.locale() === 'de' ? 'Plattform & Governance' : 'Platform & Governance' }}
              </h4>
              <ul class="space-y-2 text-sm text-slate-400">
                <li><a routerLink="/data-centres" class="hover:text-white transition-colors">{{ i18n.t('nav.dataCentres') }}</a></li>
                <li><a routerLink="/security" class="hover:text-white transition-colors">{{ i18n.t('nav.security') }}</a></li>
                <li><a routerLink="/pricing" class="hover:text-white transition-colors">{{ i18n.t('nav.pricing') }}</a></li>
                <li><a routerLink="/docs" class="hover:text-white transition-colors">{{ i18n.t('nav.documentation') }}</a></li>
                <li><a routerLink="/status" class="hover:text-white transition-colors">{{ i18n.t('nav.status') }}</a></li>
              </ul>
            </div>

            <div>
              <h4 class="text-xs font-semibold text-white mb-3">
                {{ i18n.locale() === 'fr' ? 'Accès & Entreprise' : i18n.locale() === 'de' ? 'Zugang & Unternehmen' : 'Access & Company' }}
              </h4>
              <ul class="space-y-2 text-sm text-slate-400">
                <li><a routerLink="/console/overview" class="hover:text-white transition-colors">{{ i18n.t('nav.customerConsole') }}</a></li>
                <li><a routerLink="/signin" class="hover:text-white transition-colors">{{ i18n.t('nav.signIn') }}</a></li>
                <li><a routerLink="/company" class="hover:text-white transition-colors">{{ i18n.t('nav.company') }}</a></li>
              </ul>
            </div>
          </div>

          <div class="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-slate-400">
            <span>© 2026 AUREOM EUROPE · {{ i18n.t('common.simulatedTag') }}</span>
            <app-language-switcher variant="dark" />
          </div>
        </div>
      </footer>
    </div>
  `,
})
export class PublicShell {
  readonly i18n = inject(I18nService);
  readonly mobileOpen = signal(false);
}
