import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable, computed, inject, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import {I18nService} from './i18n.service';
import type {
  BatchJob,
  BlockVolume,
  ComputeInstance,
  ConsoleOverview,
  DemoRegion,
  FacilityHost,
  GpuAllocation,
  GpuProfile,
  IndependentBackup,
  InfrastructureIncident,
  InstanceTemplate,
  Invoice,
  Organisation,
  PriceBook,
  Project,
  ProjectNetwork,
  PublicAddressAllocation,
  SecurityGroup,
  SharedFilesystem,
  StorageBucket,
  StorageSnapshot,
  UsageLedgerEntry,
  UserRole,
} from './models';

export interface CatalogResponse {
  regions: DemoRegion[];
  templates: InstanceTemplate[];
  gpuProfiles: GpuProfile[];
  priceBook: PriceBook;
}

@Injectable({providedIn: 'root'})
export class ControlPlaneService {
  private readonly http = inject(HttpClient);
  private readonly i18n = inject(I18nService);

  readonly orgId = signal<string>('org_ncrc_eu_demo');
  readonly actorEmail = signal<string>('astrid.lindqvist@ncrc-demo.example.eu');
  readonly role = signal<UserRole>('org_admin');
  readonly mfaVerified = signal<boolean>(true);
  readonly selectedProjectId = signal<string>('proj_baltic_hydro_sim');

  readonly catalog = signal<CatalogResponse | null>(null);
  readonly overview = signal<ConsoleOverview | null>(null);
  readonly projects = signal<Project[]>([]);
  readonly activeProject = computed(() =>
    this.projects().find((p) => p.id === this.selectedProjectId()) ?? this.projects()[0] ?? null,
  );

  private buildHeaders(idempotencyKey?: string): HttpHeaders {
    let headers = new HttpHeaders({
      'x-aureom-org': this.orgId(),
      'x-aureom-actor': this.actorEmail(),
      'x-aureom-role': this.role(),
      'x-aureom-locale': this.i18n.locale(),
    });
    if (idempotencyKey) {
      headers = headers.set('idempotency-key', idempotencyKey);
    }
    return headers;
  }

  setSession(orgId: string, actorEmail: string, role: UserRole): void {
    this.orgId.set(orgId);
    this.actorEmail.set(actorEmail);
    this.role.set(role);
    this.mfaVerified.set(true);
  }

  async loadCatalog(): Promise<CatalogResponse> {
    const data = await firstValueFrom(this.http.get<CatalogResponse>('/api/catalog'));
    this.catalog.set(data);
    return data;
  }

  async getPublicStatus(): Promise<{
    regions: DemoRegion[];
    activeIncidents: InfrastructureIncident[];
    healthyHosts: number;
    totalHosts: number;
    queuedJobs: number;
    runningJobs: number;
    isSimulated: true;
  }> {
    return firstValueFrom(this.http.get<{
      regions: DemoRegion[];
      activeIncidents: InfrastructureIncident[];
      healthyHosts: number;
      totalHosts: number;
      queuedJobs: number;
      runningJobs: number;
      isSimulated: true;
    }>('/api/status'));
  }

  async submitContactInquiry(payload: {
    name: string;
    email: string;
    organisation: string;
    topic: 'dedicated-capacity' | 'general' | 'governance';
    message: string;
  }): Promise<{id: string}> {
    return firstValueFrom(
      this.http.post<{id: string}>('/api/contact', {...payload, locale: this.i18n.locale()}),
    );
  }

  async loadOverview(): Promise<ConsoleOverview> {
    const pid = this.selectedProjectId();
    const data = await firstValueFrom(
      this.http.get<ConsoleOverview>(`/api/console/overview?projectId=${encodeURIComponent(pid)}`, {
        headers: this.buildHeaders(),
      }),
    );
    this.overview.set(data);
    this.projects.set(data.projects);
    if (data.projects.length > 0 && !data.projects.some((p) => p.id === pid)) {
      this.selectedProjectId.set(data.projects[0].id);
    }
    return data;
  }

  async listOrganisations(): Promise<Organisation[]> {
    const res = await firstValueFrom(this.http.get<{items: Organisation[]}>('/api/organisations'));
    return res.items;
  }

  async createProject(payload: {
    name: string;
    description: string;
    primaryRegionId: string;
    replicaLocation: string;
    backupLocation: string;
  }): Promise<Project> {
    const project = await firstValueFrom(
      this.http.post<Project>(
        '/api/projects',
        {
          name: payload.name,
          description: payload.description,
          primaryRegionId: payload.primaryRegionId,
          residency: {
            computeLocation: payload.primaryRegionId,
            primaryStorageLocation: payload.primaryRegionId,
            replicaLocation: payload.replicaLocation,
            backupLocation: payload.backupLocation,
          },
        },
        {headers: this.buildHeaders(`proj-${Date.now()}`)},
      ),
    );
    this.selectedProjectId.set(project.id);
    await this.loadOverview();
    return project;
  }

  async setBudgetAlert(projectId: string, monthlyThresholdEur: string, notifyEmail: string): Promise<void> {
    await firstValueFrom(
      this.http.put(
        `/api/projects/${encodeURIComponent(projectId)}/budget-alert`,
        {
          monthlyThresholdEur,
          notifyEmail,
          preferredLocale: this.i18n.locale(),
        },
        {headers: this.buildHeaders()},
      ),
    );
    await this.loadOverview();
  }

  async listInstances(projectId?: string): Promise<ComputeInstance[]> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    const res = await firstValueFrom(
      this.http.get<{items: ComputeInstance[]}>(`/api/instances${q}`, {headers: this.buildHeaders()}),
    );
    return res.items;
  }

  async createInstance(payload: {
    projectId: string;
    name: string;
    templateId: string;
    regionId: string;
    image: string;
    sshPublicKey: string;
  }): Promise<ComputeInstance> {
    return firstValueFrom(
      this.http.post<ComputeInstance>('/api/instances', payload, {
        headers: this.buildHeaders(`inst-${Date.now()}`),
      }),
    );
  }

  async instanceAction(instanceId: string, action: 'stop' | 'start' | 'delete'): Promise<ComputeInstance> {
    return firstValueFrom(
      this.http.post<ComputeInstance>(`/api/instances/${encodeURIComponent(instanceId)}/${action}`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async listGpus(projectId?: string): Promise<GpuAllocation[]> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    const res = await firstValueFrom(
      this.http.get<{items: GpuAllocation[]}>(`/api/gpus${q}`, {headers: this.buildHeaders()}),
    );
    return res.items;
  }

  async allocateGpu(payload: {
    projectId: string;
    regionId: string;
    gpuProfileId: string;
    deviceCount: number;
    partitionProfile?: string;
    billingBasis: 'on-demand' | 'reserved-30d-sim';
  }): Promise<GpuAllocation> {
    return firstValueFrom(
      this.http.post<GpuAllocation>('/api/gpus', payload, {headers: this.buildHeaders()}),
    );
  }

  async releaseGpu(allocationId: string): Promise<GpuAllocation> {
    return firstValueFrom(
      this.http.post<GpuAllocation>(`/api/gpus/${encodeURIComponent(allocationId)}/release`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async listJobs(projectId?: string): Promise<BatchJob[]> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    const res = await firstValueFrom(
      this.http.get<{items: BatchJob[]}>(`/api/jobs${q}`, {headers: this.buildHeaders()}),
    );
    return res.items;
  }

  async submitJob(payload: {
    projectId: string;
    name: string;
    regionId: string;
    schedulerBackend: 'slurm-adapter-sim' | 'local-queue-sim';
    workloadImage: string;
    command: string;
    cpuCores: number;
    gpuCount: number;
    memoryGiB: number;
    runtimeLimitSeconds: number;
    inputUri: string;
    outputUri: string;
    queueClass: 'standard' | 'gpu-priority' | 'throughput';
  }): Promise<BatchJob> {
    return firstValueFrom(
      this.http.post<BatchJob>('/api/jobs', payload, {
        headers: this.buildHeaders(`job-${Date.now()}`),
      }),
    );
  }

  async advanceJob(jobId: string): Promise<BatchJob> {
    return firstValueFrom(
      this.http.post<BatchJob>(`/api/jobs/${encodeURIComponent(jobId)}/advance`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async cancelJob(jobId: string): Promise<BatchJob> {
    return firstValueFrom(
      this.http.post<BatchJob>(`/api/jobs/${encodeURIComponent(jobId)}/cancel`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async getJobOutput(jobId: string): Promise<{available: boolean; artifactName?: string; content?: string; sha256?: string}> {
    return firstValueFrom(
      this.http.get<{available: boolean; artifactName?: string; content?: string; sha256?: string}>(
        `/api/jobs/${encodeURIComponent(jobId)}/output`,
        {headers: this.buildHeaders()},
      ),
    );
  }

  async getSlurmScript(jobId: string): Promise<string> {
    const res = await firstValueFrom(
      this.http.get<{script: string}>(`/api/jobs/${encodeURIComponent(jobId)}/slurm-script`, {
        headers: this.buildHeaders(),
      }),
    );
    return res.script;
  }

  async listStorage(projectId?: string): Promise<{
    buckets: StorageBucket[];
    volumes: BlockVolume[];
    filesystems: SharedFilesystem[];
    snapshots: StorageSnapshot[];
    backups: IndependentBackup[];
  }> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    return firstValueFrom(
      this.http.get<{
        buckets: StorageBucket[];
        volumes: BlockVolume[];
        filesystems: SharedFilesystem[];
        snapshots: StorageSnapshot[];
        backups: IndependentBackup[];
      }>(`/api/storage${q}`, {headers: this.buildHeaders()}),
    );
  }

  async createBucket(payload: {
    projectId: string;
    name: string;
    regionId: string;
    accessControl: 'private-project' | 'org-read-only';
    retentionDays: number;
  }): Promise<StorageBucket> {
    return firstValueFrom(
      this.http.post<StorageBucket>('/api/storage/buckets', payload, {headers: this.buildHeaders()}),
    );
  }

  async uploadBucketObject(bucketId: string, key: string, content: string, contentType = 'text/csv'): Promise<StorageBucket> {
    return firstValueFrom(
      this.http.post<StorageBucket>(
        `/api/storage/buckets/${encodeURIComponent(bucketId)}/objects`,
        {key, content, contentType},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async createVolume(payload: {projectId: string; name: string; regionId: string; sizeGB: number}): Promise<BlockVolume> {
    return firstValueFrom(
      this.http.post<BlockVolume>('/api/storage/volumes', payload, {headers: this.buildHeaders()}),
    );
  }

  async createSnapshot(volumeId: string, name: string): Promise<StorageSnapshot> {
    return firstValueFrom(
      this.http.post<StorageSnapshot>(
        `/api/storage/volumes/${encodeURIComponent(volumeId)}/snapshots`,
        {name},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async createBackup(payload: {
    sourceResourceId: string;
    sourceKind: 'volume' | 'bucket';
    targetRegionId: string;
    retentionDays: number;
  }): Promise<IndependentBackup> {
    return firstValueFrom(
      this.http.post<IndependentBackup>('/api/storage/backups', payload, {headers: this.buildHeaders()}),
    );
  }

  async listNetworking(projectId?: string): Promise<{
    networks: ProjectNetwork[];
    securityGroups: SecurityGroup[];
    publicAddresses: PublicAddressAllocation[];
  }> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    return firstValueFrom(
      this.http.get<{
        networks: ProjectNetwork[];
        securityGroups: SecurityGroup[];
        publicAddresses: PublicAddressAllocation[];
      }>(`/api/networks${q}`, {headers: this.buildHeaders()}),
    );
  }

  async addSubnet(networkId: string, name: string, cidr: string): Promise<unknown> {
    return firstValueFrom(
      this.http.post(`/api/networks/${encodeURIComponent(networkId)}/subnets`, {name, cidr}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async addFirewallRule(
    sgId: string,
    payload: {protocol: 'tcp' | 'udp' | 'icmp'; portRange: string; sourceCidr: string; description: string},
  ): Promise<SecurityGroup> {
    return firstValueFrom(
      this.http.post<SecurityGroup>(`/api/security-groups/${encodeURIComponent(sgId)}/rules`, payload, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async allocatePublicIp(projectId: string, regionId: string): Promise<PublicAddressAllocation> {
    return firstValueFrom(
      this.http.post<PublicAddressAllocation>('/api/public-addresses', {projectId, regionId}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async getUsage(projectId?: string): Promise<{
    entries: UsageLedgerEntry[];
    estimatedCurrentEur: string;
    finalisedUsageEur: string;
    invoices: Invoice[];
  }> {
    const q = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    return firstValueFrom(
      this.http.get<{
        entries: UsageLedgerEntry[];
        estimatedCurrentEur: string;
        finalisedUsageEur: string;
        invoices: Invoice[];
      }>(`/api/usage${q}`, {headers: this.buildHeaders()}),
    );
  }

  async runMeteringTick(projectId: string, periodKey: string): Promise<{createdEntries: UsageLedgerEntry[]; skippedDuplicates: number}> {
    return firstValueFrom(
      this.http.post<{createdEntries: UsageLedgerEntry[]; skippedDuplicates: number}>(
        '/api/metering/tick',
        {projectId, periodKey},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async generateInvoice(projectId: string): Promise<Invoice> {
    return firstValueFrom(
      this.http.post<Invoice>(
        '/api/invoices',
        {projectId, locale: this.i18n.locale()},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async markInvoicePaid(invoiceId: string): Promise<Invoice> {
    return firstValueFrom(
      this.http.post<Invoice>(`/api/invoices/${encodeURIComponent(invoiceId)}/pay`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async getAccessData(): Promise<{
    members: {id: string; name: string; email: string; role: string; mfaEnabled: boolean; lastActiveAt: string}[];
    apiKeys: {id: string; name: string; prefix: string; scopes: string[]; expiresAt: string; revoked: boolean}[];
  }> {
    return firstValueFrom(
      this.http.get<{
        members: {id: string; name: string; email: string; role: string; mfaEnabled: boolean; lastActiveAt: string}[];
        apiKeys: {id: string; name: string; prefix: string; scopes: string[]; expiresAt: string; revoked: boolean}[];
      }>('/api/access', {headers: this.buildHeaders()}),
    );
  }

  async createApiKey(name: string, scopes: string[], expiresInDays: number): Promise<{record: unknown; rawSecretOnce: string}> {
    return firstValueFrom(
      this.http.post<{record: unknown; rawSecretOnce: string}>(
        '/api/access/api-keys',
        {name, scopes, expiresInDays},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async revokeApiKey(keyId: string): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/access/api-keys/${encodeURIComponent(keyId)}/revoke`, {}, {headers: this.buildHeaders()}),
    );
  }

  async listAuditEvents(): Promise<{items: {id: string; actor: string; action: string; resourceType: string; resourceId: string; requestId: string; outcome: string; summary: string; timestamp: string}[]}> {
    return firstValueFrom(
      this.http.get<{items: {id: string; actor: string; action: string; resourceType: string; resourceId: string; requestId: string; outcome: string; summary: string; timestamp: string}[]}>('/api/audit-events', {
        headers: this.buildHeaders(),
      }),
    );
  }

  async getSupportData(): Promise<{
    tickets: {id: string; subject: string; severity: string; status: string; createdAt: string}[];
    emails: {id: string; to: string; locale: string; category: string; subject: string; body: string; createdAt: string}[];
  }> {
    return firstValueFrom(
      this.http.get<{
        tickets: {id: string; subject: string; severity: string; status: string; createdAt: string}[];
        emails: {id: string; to: string; locale: string; category: string; subject: string; body: string; createdAt: string}[];
      }>('/api/support', {headers: this.buildHeaders()}),
    );
  }

  async createSupportTicket(projectId: string, subject: string, severity: 'normal' | 'high'): Promise<void> {
    await firstValueFrom(
      this.http.post(
        '/api/support/tickets',
        {projectId, subject, severity, locale: this.i18n.locale()},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async getOperationsTelemetry(): Promise<{
    hosts: FacilityHost[];
    incidents: InfrastructureIncident[];
    controlSeparationNotice: string;
  }> {
    return firstValueFrom(
      this.http.get<{
        hosts: FacilityHost[];
        incidents: InfrastructureIncident[];
        controlSeparationNotice: string;
      }>('/api/operations/telemetry', {headers: this.buildHeaders()}),
    );
  }

  async simulateHostFailure(hostId: string): Promise<unknown> {
    return firstValueFrom(
      this.http.post(`/api/operations/hosts/${encodeURIComponent(hostId)}/simulate-failure`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async recoverHost(hostId: string): Promise<unknown> {
    return firstValueFrom(
      this.http.post(`/api/operations/hosts/${encodeURIComponent(hostId)}/recover`, {}, {
        headers: this.buildHeaders(),
      }),
    );
  }

  async reconcileAfterRestart(): Promise<{reconciledCount: number; failedCount: number; runningCount: number}> {
    return firstValueFrom(
      this.http.post<{reconciledCount: number; failedCount: number; runningCount: number}>(
        '/api/operations/reconcile',
        {},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async queryAssistant(prompt: string, projectId: string): Promise<{
    answer: string;
    references: {id: string; label: string}[];
    toolsInvoked: string[];
    model: string;
    privacyNotice: string;
  }> {
    return firstValueFrom(
      this.http.post<{
        answer: string;
        references: {id: string; label: string}[];
        toolsInvoked: string[];
        model: string;
        privacyNotice: string;
      }>(
        '/api/assistant/query',
        {prompt, projectId, locale: this.i18n.locale()},
        {headers: this.buildHeaders()},
      ),
    );
  }

  async resetDemo(): Promise<void> {
    await firstValueFrom(this.http.post('/api/demo/reset', {}, {headers: this.buildHeaders()}));
    this.selectedProjectId.set('proj_baltic_hydro_sim');
    await this.loadOverview();
  }
}
