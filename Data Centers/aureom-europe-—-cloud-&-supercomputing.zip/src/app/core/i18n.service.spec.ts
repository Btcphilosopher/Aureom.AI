import {TestBed} from '@angular/core/testing';
import {describe, expect, it} from 'vitest';
import {I18nService} from './i18n.service';

describe('I18nService localisation', () => {
  it('translates all mandatory navigation labels in EN, FR, and DE and formats EUR', () => {
    const i18n = TestBed.runInInjectionContext(() => new I18nService());

    i18n.setLocale('en');
    expect(i18n.t('nav.cloudCompute')).toBe('Cloud Compute');
    expect(i18n.t('nav.supercomputing')).toBe('Supercomputing');
    expect(i18n.t('nav.customerConsole')).toBe('Customer Console');

    i18n.setLocale('fr');
    expect(i18n.t('nav.cloudCompute')).toBe('Calcul cloud');
    expect(i18n.t('nav.gpuComputing')).toBe('Calcul GPU');
    expect(i18n.t('nav.supercomputing')).toBe('Calcul intensif');
    expect(i18n.t('nav.dataCentres')).toBe('Centres de données');
    expect(i18n.t('nav.customerConsole')).toBe('Console client');

    i18n.setLocale('de');
    expect(i18n.t('nav.cloudCompute')).toBe('Cloud-Computing');
    expect(i18n.t('nav.supercomputing')).toBe('Hochleistungsrechnen');
    expect(i18n.t('nav.storage')).toBe('Speicher');
    expect(i18n.t('nav.dataCentres')).toBe('Rechenzentren');
    expect(i18n.t('nav.customerConsole')).toBe('Kundenkonsole');
    expect(i18n.formatEur('2.85', 2)).toContain('€');
  });
});
