import {DOCUMENT, isPlatformBrowser} from '@angular/common';
import {Injectable, PLATFORM_ID, computed, inject, signal} from '@angular/core';
import type {LocaleCode} from './models';

type TranslationDict = Record<string, string>;

const EN: TranslationDict = {
  // Brand & Top Navigation
  'brand.name': 'AUREOM EUROPE',
  'brand.motto': 'Code at the speed of civilisation.',
  'nav.cloudCompute': 'Cloud Compute',
  'nav.gpuComputing': 'GPU Computing',
  'nav.supercomputing': 'Supercomputing',
  'nav.storage': 'Storage',
  'nav.dataCentres': 'Data Centres',
  'nav.pricing': 'Pricing',
  'nav.documentation': 'Documentation',
  'nav.customerConsole': 'Customer Console',
  'nav.privateInfra': 'Private Infrastructure',
  'nav.security': 'Security & Governance',
  'nav.status': 'Service Status',
  'nav.company': 'Company & Contact',
  'nav.signIn': 'Customer Sign-In',

  // Demonstration Notice
  'demo.banner':
    'Local Demonstration Environment — Synthetic specifications, EUR demonstration rates, and simulated EU regions. No live physical capacity or regulatory certifications are claimed.',
  'contract.reviewNotice':
    'Generated translation of contractual or billing terms — requires qualified legal review prior to commercial execution.',

  // Homepage
  'home.eyebrow': 'European Cloud & Supercomputing Architecture · Demonstration Build',
  'home.headline': 'European infrastructure. Serious computing.',
  'home.subheadline':
    'Configurable compute instances, accelerator scheduling, batch HPC queues, and explicit data residency controls built on deterministic control-plane engineering.',
  'home.cta.launchInstance': 'Launch an Instance',
  'home.cta.submitJob': 'Submit a Computing Job',
  'home.cta.requestCapacity': 'Request Dedicated Capacity',
  'home.cap.title': 'Four core primitives, unified under explicit boundaries.',
  'home.cap.subtitle':
    'Every specification and rate below operates in local demonstration mode so engineering teams can validate workflows before hardware integration.',
  'home.cap.compute.title': '01. Configurable Cloud Compute',
  'home.cap.compute.desc':
    'Explicit x86_64 and ARM64 templates with tracked lifecycle reconciliation (Requested through Running to Deleted) and honest container-vs-VM boundary labelling.',
  'home.cap.gpu.title': '02. GPU Computing & Partitioning',
  'home.cap.gpu.desc':
    'Capability-gated accelerator scheduling with driver compatibility matrices, reservation pricing, and explicit multi-tenant isolation boundaries.',
  'home.cap.hpc.title': '03. Batch Supercomputing',
  'home.cap.hpc.desc':
    'Slurm-compatible and local queue orchestration separating job submission, node allocation, execution logs, and verified output retrieval.',
  'home.cap.storage.title': '04. Storage & Residency Controls',
  'home.cap.storage.desc':
    'Distinct S3-compatible buckets, block volumes, POSIX shares, point-in-time snapshots, and independent cross-region backups with per-layer EU placement.',
  'home.diagram.title': 'Control-Plane & Adapter Isolation Architecture',
  'home.diagram.subtitle':
    'Customer workloads never execute inside the control-plane process. Observed infrastructure state is continuously reconciled against desired declarations.',
  'home.walkthrough.title': 'End-to-End Local Workflow',
  'home.walkthrough.desc':
    'Create a project, set a budget threshold, provision a local compute resource, upload synthetic data, run a batch job, retrieve outputs, and inspect a versioned EUR invoice.',
  'home.walkthrough.cta': 'Open Guided Console Workflow',

  // Console Navigation
  'console.nav.overview': 'Overview',
  'console.nav.projects': 'Projects',
  'console.nav.compute': 'Compute',
  'console.nav.gpus': 'GPUs',
  'console.nav.jobs': 'HPC Jobs',
  'console.nav.storage': 'Storage',
  'console.nav.networking': 'Networking',
  'console.nav.billing': 'Usage & Billing',
  'console.nav.access': 'Access',
  'console.nav.support': 'Support',
  'console.nav.operations': 'Operations',
  'console.nav.assistant': 'AI Assistant',
  'console.header.project': 'Active Project',
  'console.header.publicSite': 'Public Website',
  'console.header.resetDemo': 'Reset Demo Data',

  // Common UI actions & states
  'common.create': 'Create',
  'common.submit': 'Submit',
  'common.save': 'Save',
  'common.cancel': 'Cancel',
  'common.delete': 'Delete',
  'common.start': 'Start',
  'common.stop': 'Stop',
  'common.refresh': 'Refresh',
  'common.download': 'Download',
  'common.simulatedTag': 'Simulated Demonstration',
  'common.loading': 'Loading control-plane state...',
  'common.empty': 'No records match this project filter.',
  'common.required': 'This field is required.',
  'common.invalidEmail': 'Enter a valid email address.',

  // Billing & Metering
  'billing.title': 'Metering Ledger & EUR Billing',
  'billing.explanation':
    'Usage entries are metered idempotently per billing period key using exact decimal EUR arithmetic and versioned price books. Estimated current charges remain separate from finalised invoices.',
  'billing.estimated': 'Estimated Current Charges',
  'billing.finalised': 'Finalised Usage',
  'billing.runMetering': 'Run Metering Tick',
  'billing.generateInvoice': 'Finalise & Issue Invoice',
  'billing.markPaid': 'Record Payment',

  // Lifecycle States
  'state.Requested': 'Requested',
  'state.Validating': 'Validating',
  'state.Provisioning': 'Provisioning',
  'state.Running': 'Running',
  'state.Stopping': 'Stopping',
  'state.Stopped': 'Stopped',
  'state.Deleting': 'Deleting',
  'state.Deleted': 'Deleted',
  'state.Failed': 'Failed',
  'state.Reconciling': 'Reconciling',
  'state.Submitted': 'Submitted',
  'state.Queued': 'Queued',
  'state.Allocated': 'Allocated',
  'state.Starting': 'Starting',
  'state.Completed': 'Completed',
  'state.Cancelled': 'Cancelled',
  'state.TimedOut': 'Timed Out',
};

const FR: TranslationDict = {
  // Brand & Top Navigation
  'brand.name': 'AUREOM EUROPE',
  'brand.motto': 'Code at the speed of civilisation.',
  'nav.cloudCompute': 'Calcul cloud',
  'nav.gpuComputing': 'Calcul GPU',
  'nav.supercomputing': 'Calcul intensif',
  'nav.storage': 'Stockage',
  'nav.dataCentres': 'Centres de données',
  'nav.pricing': 'Tarifs',
  'nav.documentation': 'Documentation',
  'nav.customerConsole': 'Console client',
  'nav.privateInfra': 'Infrastructure dédiée',
  'nav.security': 'Sécurité et gouvernance',
  'nav.status': 'État des services',
  'nav.company': 'Entreprise et contact',
  'nav.signIn': 'Connexion client',

  // Demonstration Notice
  'demo.banner':
    'Environnement de démonstration local — Spécifications synthétiques, tarifs indicatifs en EUR et régions européennes simulées. Aucune capacité physique active ni certification commerciale revendiquée.',
  'contract.reviewNotice':
    'Traduction générée de documents contractuels ou de facturation — une relecture juridique professionnelle est requise avant utilisation commerciale.',

  // Homepage
  'home.eyebrow': 'Architecture Cloud et Calcul Intensif Européenne · Démonstration',
  'home.headline': 'Infrastructure européenne. Calcul exigeant.',
  'home.subheadline':
    'Instances configurables, ordonnancement d’accélérateurs GPU, files de calcul intensif et contrôles explicites de résidence des données sur un plan de contrôle déterministe.',
  'home.cta.launchInstance': 'Lancer une instance',
  'home.cta.submitJob': 'Soumettre un travail',
  'home.cta.requestCapacity': 'Demander une capacité dédiée',
  'home.cap.title': 'Quatre primitives fondamentales, sous limites explicites.',
  'home.cap.subtitle':
    'Chaque spécification et tarif ci-dessous fonctionne en mode démonstration local afin de valider vos flux techniques avant raccordement matériel.',
  'home.cap.compute.title': '01. Calcul cloud configurable',
  'home.cap.compute.desc':
    'Modèles x86_64 et ARM64 explicites avec réconciliation d’état (Requested jusqu’à Deleted) et distinction claire entre simulation de conteneur et machine virtuelle.',
  'home.cap.gpu.title': '02. Calcul GPU et partitionnement',
  'home.cap.gpu.desc':
    'Allocation d’accélérateurs filtrée par capacités réelles des adaptateurs, compatibilité logicielle et avis explicites d’isolation matérielle.',
  'home.cap.hpc.title': '03. Calcul intensif par lots',
  'home.cap.hpc.desc':
    'Ordonnanceur compatible Slurm et file locale séparant soumission, allocation de nœud, journaux d’exécution et récupération des résultats.',
  'home.cap.storage.title': '04. Stockage et résidence des données',
  'home.cap.storage.desc':
    'Compartiments S3, volumes blocs, systèmes POSIX, instantanés et sauvegardes indépendantes avec localisation européenne par couche.',
  'home.diagram.title': 'Architecture du plan de contrôle et d’isolation',
  'home.diagram.subtitle':
    'Les charges clientes ne s’exécutent jamais dans le processus du plan de contrôle. L’état observé est continuellement réconcilié avec l’état souhaité.',
  'home.walkthrough.title': 'Flux complet de démonstration locale',
  'home.walkthrough.desc':
    'Créez un projet, fixez une alerte budgétaire, provisionnez une ressource locale, déposez des données synthétiques, exécutez un calcul et vérifiez une facture en EUR.',
  'home.walkthrough.cta': 'Ouvrir le parcours guidé',

  // Console Navigation
  'console.nav.overview': 'Vue d’ensemble',
  'console.nav.projects': 'Projets',
  'console.nav.compute': 'Calcul',
  'console.nav.gpus': 'GPU',
  'console.nav.jobs': 'Travaux HPC',
  'console.nav.storage': 'Stockage',
  'console.nav.networking': 'Réseau',
  'console.nav.billing': 'Consommation & Facturation',
  'console.nav.access': 'Accès & Audit',
  'console.nav.support': 'Support',
  'console.nav.operations': 'Opérations',
  'console.nav.assistant': 'Assistant IA',
  'console.header.project': 'Projet actif',
  'console.header.publicSite': 'Site public',
  'console.header.resetDemo': 'Réinitialiser la démo',

  // Common UI actions & states
  'common.create': 'Créer',
  'common.submit': 'Soumettre',
  'common.save': 'Enregistrer',
  'common.cancel': 'Annuler',
  'common.delete': 'Supprimer',
  'common.start': 'Démarrer',
  'common.stop': 'Arrêter',
  'common.refresh': 'Actualiser',
  'common.download': 'Télécharger',
  'common.simulatedTag': 'Démonstration simulée',
  'common.loading': 'Chargement du plan de contrôle...',
  'common.empty': 'Aucun enregistrement pour ce projet.',
  'common.required': 'Ce champ est obligatoire.',
  'common.invalidEmail': 'Saisissez une adresse e-mail valide.',

  // Billing & Metering
  'billing.title': 'Grand livre de mesure et facturation EUR',
  'billing.explanation':
    'La consommation est enregistrée de manière idempotente par période grâce à l’arithmétique décimale exacte en EUR et des grilles tarifaires versionnées.',
  'billing.estimated': 'Charges estimées en cours',
  'billing.finalised': 'Usage finalisé',
  'billing.runMetering': 'Exécuter un cycle de mesure',
  'billing.generateInvoice': 'Finaliser et émettre la facture',
  'billing.markPaid': 'Enregistrer le paiement',

  // Lifecycle States
  'state.Requested': 'Demandé',
  'state.Validating': 'Validation',
  'state.Provisioning': 'Provisionnement',
  'state.Running': 'En cours',
  'state.Stopping': 'Arrêt en cours',
  'state.Stopped': 'Arrêté',
  'state.Deleting': 'Suppression',
  'state.Deleted': 'Supprimé',
  'state.Failed': 'Échec',
  'state.Reconciling': 'Réconciliation',
  'state.Submitted': 'Soumis',
  'state.Queued': 'En file d’attente',
  'state.Allocated': 'Alloué',
  'state.Starting': 'Démarrage',
  'state.Completed': 'Terminé',
  'state.Cancelled': 'Annulé',
  'state.TimedOut': 'Délai expiré',
};

const DE: TranslationDict = {
  // Brand & Top Navigation
  'brand.name': 'AUREOM EUROPE',
  'brand.motto': 'Code at the speed of civilisation.',
  'nav.cloudCompute': 'Cloud-Computing',
  'nav.gpuComputing': 'GPU-Computing',
  'nav.supercomputing': 'Hochleistungsrechnen',
  'nav.storage': 'Speicher',
  'nav.dataCentres': 'Rechenzentren',
  'nav.pricing': 'Preise',
  'nav.documentation': 'Dokumentation',
  'nav.customerConsole': 'Kundenkonsole',
  'nav.privateInfra': 'Private Infrastruktur',
  'nav.security': 'Sicherheit & Governance',
  'nav.status': 'Systemstatus',
  'nav.company': 'Unternehmen & Kontakt',
  'nav.signIn': 'Kundenanmeldung',

  // Demonstration Notice
  'demo.banner':
    'Lokale Demonstrationsumgebung — Synthetische Spezifikationen, EUR-Demonstrationspreise und simulierte EU-Regionen. Keine produktiven Kapazitäten oder Zertifizierungen beansprucht.',
  'contract.reviewNotice':
    'Maschinell unterstützte Übersetzung von Vertrags- oder Abrechnungstexten — vor produktiver Nutzung fachjuristisch prüfen lassen.',

  // Homepage
  'home.eyebrow': 'Europäische Cloud- & Supercomputing-Architektur · Demonstration',
  'home.headline': 'Europäische Infrastruktur. Ernsthaftes Rechnen.',
  'home.subheadline':
    'Konfigurierbare Recheninstanzen, GPU-Beschleunigerplanung, Batch-HPC-Warteschlangen und explizite Datenresidenz-Kontrollen auf einer deterministischen Steuerungsebene.',
  'home.cta.launchInstance': 'Instanz starten',
  'home.cta.submitJob': 'Rechenauftrag einreichen',
  'home.cta.requestCapacity': 'Dedizierte Kapazität anfragen',
  'home.cap.title': 'Vier Kernbausteine mit expliziten Systemgrenzen.',
  'home.cap.subtitle':
    'Alle Spezifikationen und Preise laufen im lokalen Demonstrationsmodus, damit Teams Abläufe vor der Hardware-Integration prüfen können.',
  'home.cap.compute.title': '01. Konfigurierbares Cloud-Computing',
  'home.cap.compute.desc':
    'Explizite x86_64- und ARM64-Vorlagen mit Zustandsabgleich (Requested bis Deleted) und klarer Unterscheidung zwischen Container-Simulation und VM.',
  'home.cap.gpu.title': '02. GPU-Computing & Partitionierung',
  'home.cap.gpu.desc':
    'Fähigkeitsgesteuerte Beschleunigerzuweisung mit Treiberkompatibilität, Reservierungsoptionen und transparenten Isolationshinweisen.',
  'home.cap.hpc.title': '03. Batch-Hochleistungsrechnen',
  'home.cap.hpc.desc':
    'Slurm-kompatible und lokale Warteschlangen-Orchestrierung mit sauberer Trennung von Einreichung, Knotenzuweisung, Protokollen und Ergebnisabruf.',
  'home.cap.storage.title': '04. Speicher & Datenresidenz',
  'home.cap.storage.desc':
    'Getrennte S3-kompatible Buckets, Block-Volumes, POSIX-Dateisysteme, Snapshots und unabhängige Backups mit europäischer Standortkontrolle.',
  'home.diagram.title': 'Steuerungsebene & Adapter-Isolationsarchitektur',
  'home.diagram.subtitle':
    'Kunden-Workloads laufen niemals im Prozess der Steuerungsebene. Der beobachtete Infrastrukturzustand wird laufend abgeglichen.',
  'home.walkthrough.title': 'Durchgängiger lokaler Demonstrationsablauf',
  'home.walkthrough.desc':
    'Projekt anlegen, Budgetwarnung setzen, lokale Ressource bereitstellen, Testdaten hochladen, Batch-Auftrag ausführen und EUR-Rechnung prüfen.',
  'home.walkthrough.cta': 'Geführten Konsolen-Workflow öffnen',

  // Console Navigation
  'console.nav.overview': 'Übersicht',
  'console.nav.projects': 'Projekte',
  'console.nav.compute': 'Compute',
  'console.nav.gpus': 'GPUs',
  'console.nav.jobs': 'HPC-Aufträge',
  'console.nav.storage': 'Speicher',
  'console.nav.networking': 'Netzwerk',
  'console.nav.billing': 'Nutzung & Abrechnung',
  'console.nav.access': 'Zugriff & Audit',
  'console.nav.support': 'Support',
  'console.nav.operations': 'Betrieb',
  'console.nav.assistant': 'KI-Assistent',
  'console.header.project': 'Aktives Projekt',
  'console.header.publicSite': 'Öffentliche Website',
  'console.header.resetDemo': 'Demo zurücksetzen',

  // Common UI actions & states
  'common.create': 'Erstellen',
  'common.submit': 'Einreichen',
  'common.save': 'Speichern',
  'common.cancel': 'Abbrechen',
  'common.delete': 'Löschen',
  'common.start': 'Starten',
  'common.stop': 'Stoppen',
  'common.refresh': 'Aktualisieren',
  'common.download': 'Herunterladen',
  'common.simulatedTag': 'Simulierte Demonstration',
  'common.loading': 'Lade Steuerungsebene...',
  'common.empty': 'Keine Einträge für dieses Projekt.',
  'common.required': 'Dieses Feld ist erforderlich.',
  'common.invalidEmail': 'Bitte eine gültige E-Mail-Adresse eingeben.',

  // Billing & Metering
  'billing.title': 'Nutzungsbuch & EUR-Abrechnung',
  'billing.explanation':
    'Nutzungseinträge werden je Abrechnungsperiode idempotent mittels exakter Dezimalarithmetik in EUR und versionierten Preislisten erfasst.',
  'billing.estimated': 'Geschätzte laufende Kosten',
  'billing.finalised': 'Abgeschlossene Nutzung',
  'billing.runMetering': 'Messzyklus ausführen',
  'billing.generateInvoice': 'Rechnung finalisieren',
  'billing.markPaid': 'Zahlung verbuchen',

  // Lifecycle States
  'state.Requested': 'Angefordert',
  'state.Validating': 'Validierung',
  'state.Provisioning': 'Bereitstellung',
  'state.Running': 'Aktiv',
  'state.Stopping': 'Wird gestoppt',
  'state.Stopped': 'Gestoppt',
  'state.Deleting': 'Wird gelöscht',
  'state.Deleted': 'Gelöscht',
  'state.Failed': 'Fehlgeschlagen',
  'state.Reconciling': 'Abgleich läuft',
  'state.Submitted': 'Eingereicht',
  'state.Queued': 'In Warteschlange',
  'state.Allocated': 'Zugewiesen',
  'state.Starting': 'Startet',
  'state.Completed': 'Abgeschlossen',
  'state.Cancelled': 'Abgebrochen',
  'state.TimedOut': 'Zeitüberschreitung',
};

const DICTS: Record<LocaleCode, TranslationDict> = {en: EN, fr: FR, de: DE};

@Injectable({providedIn: 'root'})
export class I18nService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly document = inject(DOCUMENT);

  readonly locale = signal<LocaleCode>('en');
  readonly intlLocale = computed(() => {
    const l = this.locale();
    return l === 'fr' ? 'fr-FR' : l === 'de' ? 'de-DE' : 'en-IE';
  });

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const saved = window.localStorage.getItem('aureom_locale');
      if (saved === 'en' || saved === 'fr' || saved === 'de') {
        this.locale.set(saved);
        this.document.documentElement.lang = saved;
      }
    }
  }

  setLocale(code: LocaleCode): void {
    this.locale.set(code);
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.setItem('aureom_locale', code);
      this.document.documentElement.lang = code;
    }
  }

  t(key: string): string {
    const dict = DICTS[this.locale()];
    return dict[key] ?? EN[key] ?? key;
  }

  formatEur(value: string | number, decimals = 2): string {
    const num = typeof value === 'string' ? Number(value) : value;
    if (Number.isNaN(num)) return `${value} EUR`;
    return new Intl.NumberFormat(this.intlLocale(), {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(num);
  }

  formatDateTime(iso: string): string {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return new Intl.DateTimeFormat(this.intlLocale(), {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(d);
  }

  stateLabel(state: string): string {
    return this.t(`state.${state}`) !== `state.${state}` ? this.t(`state.${state}`) : state;
  }
}
