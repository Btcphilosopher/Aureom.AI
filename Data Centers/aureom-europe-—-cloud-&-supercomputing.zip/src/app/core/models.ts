export type LocaleCode = 'en' | 'fr' | 'de';
export type UserRole = 'org_admin' | 'project_engineer' | 'infra_operator' | 'auditor';

export interface DemoRegion {
  id: string;
  code: string;
  city: string;
  country: string;
  isSimulated: true;
  simulationLabel: string;
  gridCarbonNote: string;
  coolingArchitecture: string;
  supportedArchitectures: ('x86_64' | 'aarch64')[];
  status: 'operational' | 'degraded';
}

export interface InstanceTemplate {
  id: string;
  name: string;
  architecture: 'x86_64' | 'aarch64';
  cpuModel: string;
  vcpus: number;
  memoryGiB: number;
  defaultDiskGB: number;
  pricePerHourEur: string;
  adapterKind: 'local-container-sim';
  virtualizationBoundary: string;
}

export interface GpuProfile {
  id: string;
  modelName: string;
  architecture: string;
  vramGiB: number;
  interconnect: string;
  driverVersion: string;
  cudaOrRocmRuntime: string;
  supportsPartitioning: boolean;
  partitionProfiles: string[];
  multiTenantHardwareIsolationSupported: boolean;
  isolationNotice: string;
  hourlyRatePerDeviceEur: string;
  isSimulated: true;
}

export interface PriceBook {
  version: string;
  effectiveFrom: string;
  currency: 'EUR';
  isSimulated: true;
  rates: Record<string, string>;
}

export interface Organisation {
  id: string;
  name: string;
  slug: string;
  billingEmail: string;
  vatId: string;
  vatRatePercent: string;
  taxJurisdictionNote: string;
  mfaEnforced: boolean;
  isSimulated: true;
  createdAt: string;
}

export interface ProjectQuotas {
  maxVcpus: number;
  maxMemoryGiB: number;
  maxGpus: number;
  maxStorageGB: number;
  maxInstances: number;
  maxConcurrentJobs: number;
}

export interface DataResidencyPolicy {
  computeLocation: string;
  primaryStorageLocation: string;
  replicaLocation: string;
  backupLocation: string;
  logLocation: string;
  supportAccessPolicy: 'eu-staff-only-explicit-approval' | 'project-admin-token-required';
  externalSubprocessors: string[];
  sovereigntyNotice: string;
}

export interface BudgetAlert {
  id: string;
  projectId: string;
  monthlyThresholdEur: string;
  notifyEmail: string;
  preferredLocale: LocaleCode;
  triggered: boolean;
  lastTriggeredAt?: string;
}

export interface Project {
  id: string;
  organisationId: string;
  name: string;
  slug: string;
  description: string;
  primaryRegionId: string;
  quotas: ProjectQuotas;
  residency: DataResidencyPolicy;
  budgetAlert?: BudgetAlert;
  createdAt: string;
}

export interface ComputeInstance {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  templateId: string;
  architecture: 'x86_64' | 'aarch64';
  vcpus: number;
  memoryGiB: number;
  diskGB: number;
  image: string;
  imageProvenanceDigest: string;
  regionId: string;
  networkId: string;
  subnetId: string;
  securityGroupId: string;
  sshPublicKeyFingerprint: string;
  privateIp: string;
  publicIp?: string;
  hostId: string;
  adapterKind: 'local-container-sim';
  isolationBoundary: string;
  desiredState: string;
  observedState: string;
  priceBasisVersion: string;
  hourlyRateEur: string;
  reconciliationNote?: string;
  lastObservedAt: string;
  createdAt: string;
}

export interface GpuAllocation {
  id: string;
  organisationId: string;
  projectId: string;
  regionId: string;
  hostId: string;
  gpuProfileId: string;
  deviceCount: number;
  partitionProfile?: string;
  billingBasis: 'on-demand' | 'reserved-30d-sim';
  hourlyRateEur: string;
  priceBasisVersion: string;
  status: string;
  runtimeCompatibility: string;
  isolationNotice: string;
  createdAt: string;
}

export interface BatchJob {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  schedulerBackend: 'slurm-adapter-sim' | 'local-queue-sim';
  workloadImage: string;
  imageDigestVerified: boolean;
  command: string;
  cpuCores: number;
  gpuCount: number;
  memoryGiB: number;
  runtimeLimitSeconds: number;
  inputUri: string;
  outputUri: string;
  environmentConfig: Record<string, string>;
  queueClass: 'standard' | 'gpu-priority' | 'throughput';
  priority: number;
  state: string;
  allocationNodeId?: string;
  outputAvailable: boolean;
  outputArtifactName?: string;
  logs: string[];
  exitCode?: number;
  hourlyRateEur: string;
  priceBasisVersion: string;
  createdAt: string;
}

export interface BucketObject {
  key: string;
  sizeBytes: number;
  contentType: string;
  sha256: string;
  contentPreview: string;
  uploadedAt: string;
}

export interface StorageBucket {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  accessControl: string;
  durabilityNotice: string;
  replicationPolicy: string;
  retentionDays: number;
  usedBytes: number;
  quotaGB: number;
  pricePerGBMonthEur: string;
  objects: BucketObject[];
  createdAt: string;
}

export interface BlockVolume {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  sizeGB: number;
  attachedInstanceId?: string;
  durabilityNotice: string;
  pricePerGBMonthEur: string;
  status: string;
  createdAt: string;
}

export interface SharedFilesystem {
  id: string;
  name: string;
  regionId: string;
  protocol: string;
  capacityGB: number;
  usedGB: number;
  mountTarget: string;
  durabilityNotice: string;
  pricePerGBMonthEur: string;
}

export interface StorageSnapshot {
  id: string;
  sourceVolumeId: string;
  name: string;
  sizeGB: number;
  isIndependentBackup: false;
  note: string;
  createdAt: string;
}

export interface IndependentBackup {
  id: string;
  sourceResourceId: string;
  sourceKind: string;
  targetRegionId: string;
  retentionDays: number;
  sizeGB: number;
  verificationStatus: string;
  createdAt: string;
}

export interface ProjectNetwork {
  id: string;
  projectId: string;
  name: string;
  regionId: string;
  cidr: string;
  privateConnectivity: string;
  publicIpPoolEnabled: boolean;
  subnets: {id: string; networkId: string; name: string; cidr: string; gatewayIp: string; availableIps: number}[];
}

export interface SecurityGroup {
  id: string;
  projectId: string;
  name: string;
  defaultInboundPolicy: 'deny-all';
  inboundRules: {id: string; protocol: string; portRange: string; sourceCidr: string; description: string}[];
}

export interface PublicAddressAllocation {
  id: string;
  ipAddress: string;
  regionId: string;
  adapterName: string;
  createdAt: string;
}

export interface UsageLedgerEntry {
  id: string;
  resourceId: string;
  resourceKind: string;
  resourceName: string;
  meteringPeriodKey: string;
  periodStart: string;
  periodEnd: string;
  quantity: string;
  unit: string;
  priceVersion: string;
  unitRateEur: string;
  amountEur: string;
  currency: 'EUR';
  finalisationState: 'EstimatedCurrent' | 'FinalisedUsage';
  invoiceId?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  projectId: string;
  currency: 'EUR';
  subtotalEur: string;
  vatRatePercent: string;
  vatAmountEur: string;
  totalEur: string;
  taxTreatmentNote: string;
  status: 'IssuedInvoice' | 'Paid';
  isSimulated: true;
  lineItems: {
    description: string;
    resourceKind: string;
    priceVersion: string;
    quantity: string;
    unit: string;
    unitRateEur: string;
    subtotalEur: string;
  }[];
  issuedAt: string;
  paidAt?: string;
}

export interface FacilityHost {
  id: string;
  regionId: string;
  siteName: string;
  roomName: string;
  rackId: string;
  hostname: string;
  architecture: string;
  totalVcpus: number;
  usedVcpus: number;
  totalMemoryGiB: number;
  usedMemoryGiB: number;
  gpuCount: number;
  gpuModel?: string;
  powerDrawWatts: number | null;
  facilityTotalPowerWatts: number | null;
  temperatureCelsius: number;
  telemetrySource: string;
  telemetryFreshnessIso: string;
  state: 'Healthy' | 'Failed' | 'Maintenance';
  pue: string | null;
  pueBoundaryNote: string;
}

export interface InfrastructureIncident {
  id: string;
  regionId: string;
  hostId?: string;
  severity: string;
  title: string;
  summary: string;
  status: 'Active' | 'Resolved';
  openedAt: string;
  resolvedAt?: string;
}

export interface ConsoleOverview {
  organisation: Organisation | undefined;
  projects: Project[];
  activeInstances: number;
  runningJobs: number;
  queuedJobs: number;
  gpuDevicesAllocated: number;
  storageUsedGB: number;
  estimatedChargesEur: string;
  finalisedChargesEur: string;
  activeIncidents: InfrastructureIncident[];
  pendingActions: {type: string; resourceId: string; summary: string}[];
  quotaSummary: {
    quotas: ProjectQuotas;
    used: {
      vcpus: number;
      memoryGiB: number;
      gpus: number;
      storageGB: number;
      instances: number;
      concurrentJobs: number;
    };
  } | null;
}
