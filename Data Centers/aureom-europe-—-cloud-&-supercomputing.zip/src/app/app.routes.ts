import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./public/public-shell').then((m) => m.PublicShell),
    children: [
      {
        path: '',
        loadComponent: () => import('./public/home-page').then((m) => m.HomePage),
      },
      {
        path: 'cloud-compute',
        loadComponent: () => import('./public/product-pages').then((m) => m.CloudComputePage),
      },
      {
        path: 'gpu-computing',
        loadComponent: () => import('./public/product-pages').then((m) => m.GpuComputingPage),
      },
      {
        path: 'supercomputing',
        loadComponent: () => import('./public/product-pages').then((m) => m.SupercomputingPage),
      },
      {
        path: 'storage',
        loadComponent: () => import('./public/product-pages').then((m) => m.StoragePage),
      },
      {
        path: 'private-infrastructure',
        loadComponent: () => import('./public/product-pages').then((m) => m.PrivateInfrastructurePage),
      },
      {
        path: 'data-centres',
        loadComponent: () => import('./public/product-pages').then((m) => m.DataCentresPage),
      },
      {
        path: 'pricing',
        loadComponent: () => import('./public/product-pages').then((m) => m.PricingPage),
      },
      {
        path: 'security',
        loadComponent: () => import('./public/product-pages').then((m) => m.SecurityGovernancePage),
      },
      {
        path: 'docs',
        loadComponent: () => import('./public/docs-status-company').then((m) => m.DocumentationPage),
      },
      {
        path: 'status',
        loadComponent: () => import('./public/docs-status-company').then((m) => m.ServiceStatusPage),
      },
      {
        path: 'company',
        loadComponent: () => import('./public/docs-status-company').then((m) => m.CompanyContactPage),
      },
      {
        path: 'signin',
        loadComponent: () => import('./public/docs-status-company').then((m) => m.SignInPage),
      },
    ],
  },
  {
    path: 'console',
    loadComponent: () => import('./console/console-shell').then((m) => m.ConsoleShell),
    children: [
      {path: '', redirectTo: 'overview', pathMatch: 'full'},
      {
        path: 'overview',
        loadComponent: () => import('./console/console-overview-projects').then((m) => m.ConsoleOverviewPage),
      },
      {
        path: 'projects',
        loadComponent: () => import('./console/console-overview-projects').then((m) => m.ConsoleProjectsPage),
      },
      {
        path: 'compute',
        loadComponent: () => import('./console/console-compute-gpus').then((m) => m.ConsoleComputePage),
      },
      {
        path: 'gpus',
        loadComponent: () => import('./console/console-compute-gpus').then((m) => m.ConsoleGpusPage),
      },
      {
        path: 'jobs',
        loadComponent: () => import('./console/console-jobs-storage').then((m) => m.ConsoleJobsPage),
      },
      {
        path: 'storage',
        loadComponent: () => import('./console/console-jobs-storage').then((m) => m.ConsoleStoragePage),
      },
      {
        path: 'networking',
        loadComponent: () => import('./console/console-network-billing').then((m) => m.ConsoleNetworkingPage),
      },
      {
        path: 'billing',
        loadComponent: () => import('./console/console-network-billing').then((m) => m.ConsoleBillingPage),
      },
      {
        path: 'access',
        loadComponent: () => import('./console/console-access-ops-ai').then((m) => m.ConsoleAccessPage),
      },
      {
        path: 'support',
        loadComponent: () => import('./console/console-access-ops-ai').then((m) => m.ConsoleSupportPage),
      },
      {
        path: 'operations',
        loadComponent: () => import('./console/console-access-ops-ai').then((m) => m.ConsoleOperationsPage),
      },
      {
        path: 'assistant',
        loadComponent: () => import('./console/console-access-ops-ai').then((m) => m.ConsoleAssistantPage),
      },
    ],
  },
  {path: '**', redirectTo: ''},
];
