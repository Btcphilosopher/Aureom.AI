import {ChangeDetectionStrategy, Component, OnInit, computed, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import type {ComputeInstance, GpuAllocation} from '../core/models';

@Component({
  selector: 'app-console-compute-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.compute') }}</h1>
          <p class="text-sm text-slate-600">
            Local container-simulated compute adapter — clearly distinguished from hardware KVM virtual machines.
          </p>
        </div>
        <button
          type="button"
          (click)="refresh()"
          class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-[#070D19] hover:bg-slate-50"
        >
          <mat-icon class="!text-[16px] !h-4 !w-4">refresh</mat-icon>
          <span>{{ i18n.t('common.refresh') }}</span>
        </button>
      </div>

      <!-- Provision Instance Form -->
      <div class="rounded-xl border border-slate-200 bg-white p-6">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">Request Compute Instance</h2>
        <form [formGroup]="form" (ngSubmit)="launch()" class="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Instance Name</span>
            <input formControlName="name" type="text" placeholder="eu-worker-01" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Template (vCPU / RAM / Arch)</span>
            <select formControlName="templateId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              @for (t of cp.catalog()?.templates ?? []; track t.id) {
                <option [value]="t.id">{{ t.name }} — {{ i18n.formatEur(t.pricePerHourEur, 3) }}/h</option>
              }
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Region</span>
            <select formControlName="regionId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              @for (r of cp.catalog()?.regions ?? []; track r.id) {
                <option [value]="r.id">{{ r.id }} ({{ r.city }})</option>
              }
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Base OS Image</span>
            <select formControlName="image" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="debian-12-bookworm-eu-minimal">debian-12-bookworm-eu-minimal</option>
              <option value="ubuntu-24.04-lts-eu-hardened">ubuntu-24.04-lts-eu-hardened</option>
              <option value="rocky-9.4-hpc-base">rocky-9.4-hpc-base</option>
            </select>
          </label>
          <label class="block sm:col-span-2 lg:col-span-3">
            <span class="block text-xs font-semibold text-slate-700 mb-1">SSH Public Key (Password root auth disabled)</span>
            <input formControlName="sshPublicKey" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
          </label>
          <div class="flex items-end">
            <button type="submit" class="cursor-pointer w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#2563EB]">
              <mat-icon class="!text-[16px] !h-4 !w-4">rocket_launch</mat-icon>
              <span>{{ i18n.t('home.cta.launchInstance') }}</span>
            </button>
          </div>
        </form>
        @if (err()) {
          <div class="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
        }
      </div>

      <!-- Instances Table -->
      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Project Compute Instances</h2>
          <span class="font-mono text-xs text-slate-500">Observed state ≠ API acceptance</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
              <tr>
                <th class="px-4 py-3 font-semibold">Instance / Adapter</th>
                <th class="px-4 py-3 font-semibold">Specs</th>
                <th class="px-4 py-3 font-semibold">Region / Host</th>
                <th class="px-4 py-3 font-semibold">Private IP</th>
                <th class="px-4 py-3 font-semibold">Observed State</th>
                <th class="px-4 py-3 font-semibold text-right">Rate</th>
                <th class="px-4 py-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (inst of instances(); track inst.id) {
                <tr class="hover:bg-slate-50/70">
                  <td class="px-4 py-3">
                    <div class="font-semibold text-[#070D19]">{{ inst.name }}</div>
                    <div class="font-mono text-[11px] text-slate-500">{{ inst.id }} · {{ inst.adapterKind }}</div>
                  </td>
                  <td class="px-4 py-3 font-mono tabular-nums">{{ inst.architecture }} · {{ inst.vcpus }}c / {{ inst.memoryGiB }}G</td>
                  <td class="px-4 py-3 font-mono">
                    <div>{{ inst.regionId }}</div>
                    <div class="text-[11px] text-slate-500">{{ inst.hostId }}</div>
                  </td>
                  <td class="px-4 py-3 font-mono tabular-nums">{{ inst.privateIp }}</td>
                  <td class="px-4 py-3">
                    <span
                      class="inline-block rounded px-2 py-0.5 font-mono text-[11px] font-semibold border"
                      [class]="
                        inst.observedState === 'Running'
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                          : inst.observedState === 'Failed' || inst.observedState === 'Reconciling'
                            ? 'border-red-200 bg-red-50 text-red-800'
                            : 'border-slate-200 bg-slate-100 text-slate-700'
                      "
                    >
                      {{ i18n.stateLabel(inst.observedState) }}
                    </span>
                    @if (inst.reconciliationNote) {
                      <div class="mt-1 text-[11px] text-slate-500 max-w-xs">{{ inst.reconciliationNote }}</div>
                    }
                  </td>
                  <td class="px-4 py-3 font-mono tabular-nums text-right">{{ i18n.formatEur(inst.hourlyRateEur, 4) }}/h</td>
                  <td class="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                    @if (inst.observedState === 'Running') {
                      <button type="button" (click)="act(inst.id, 'stop')" class="cursor-pointer rounded border border-slate-300 px-2 py-1 hover:bg-slate-100">
                        {{ i18n.t('common.stop') }}
                      </button>
                    }
                    @if (inst.observedState === 'Stopped') {
                      <button type="button" (click)="act(inst.id, 'start')" class="cursor-pointer rounded border border-slate-300 px-2 py-1 hover:bg-slate-100">
                        {{ i18n.t('common.start') }}
                      </button>
                    }
                    @if (inst.observedState !== 'Deleted') {
                      <button type="button" (click)="act(inst.id, 'delete')" class="cursor-pointer rounded border border-red-200 text-red-700 px-2 py-1 hover:bg-red-50">
                        {{ i18n.t('common.delete') }}
                      </button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="7" class="px-4 py-8 text-center text-slate-500">{{ i18n.t('common.empty') }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class ConsoleComputePage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly instances = signal<ComputeInstance[]>([]);
  readonly err = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['nord-compute-02', Validators.required],
    templateId: ['eu-gp-small'],
    regionId: ['eu-sim-nord-1'],
    image: ['debian-12-bookworm-eu-minimal'],
    sshPublicKey: ['ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDemoKeyAureomEurope2026 engineer@ncrc-demo.eu', Validators.required],
  });

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) await this.cp.loadCatalog();
    await this.refresh();
  }

  async refresh(): Promise<void> {
    this.instances.set(await this.cp.listInstances(this.cp.selectedProjectId()));
  }

  async launch(): Promise<void> {
    this.err.set(null);
    if (this.form.invalid) {
      this.err.set(this.i18n.t('common.required'));
      return;
    }
    try {
      const val = this.form.getRawValue();
      await this.cp.createInstance({
        ...val,
        projectId: this.cp.selectedProjectId(),
      });
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Provisioning rejected');
    }
  }

  async act(id: string, action: 'stop' | 'start' | 'delete'): Promise<void> {
    this.err.set(null);
    try {
      await this.cp.instanceAction(id, action);
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Action failed');
    }
  }
}

@Component({
  selector: 'app-console-gpus-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.gpus') }}</h1>
        <p class="text-sm text-slate-600">
          Synthetic GPU allocations with adapter-enforced partitioning support and explicit isolation disclosures.
        </p>
      </div>

      <div class="rounded-xl border border-slate-200 bg-white p-6">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">Allocate Simulated GPU Resources</h2>
        <form [formGroup]="form" (ngSubmit)="allocate()" class="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">GPU Profile</span>
            <select formControlName="gpuProfileId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              @for (p of cp.catalog()?.gpuProfiles ?? []; track p.id) {
                <option [value]="p.id">{{ p.modelName }}</option>
              }
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Region</span>
            <select formControlName="regionId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="eu-sim-nord-1">eu-sim-nord-1</option>
              <option value="eu-sim-central-1">eu-sim-central-1</option>
              <option value="eu-sim-west-1">eu-sim-west-1</option>
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Devices</span>
            <input formControlName="deviceCount" type="number" min="1" max="8" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Partitioning (Adapter Gated)</span>
            <select
              formControlName="partitionProfile"
              [attr.disabled]="!selectedProfile()?.supportsPartitioning ? true : null"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs disabled:bg-slate-100 disabled:text-slate-400"
            >
              <option value="">Whole Device</option>
              @for (pp of selectedProfile()?.partitionProfiles ?? []; track pp) {
                <option [value]="pp">{{ pp }}</option>
              }
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Billing Basis</span>
            <select formControlName="billingBasis" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="on-demand">On-Demand</option>
              <option value="reserved-30d-sim">Reserved 30d (Sim -18%)</option>
            </select>
          </label>
          <div class="sm:col-span-2 lg:col-span-5 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4">
            <p class="text-xs text-amber-800">{{ selectedProfile()?.isolationNotice }}</p>
            <button type="submit" class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              <mat-icon class="!text-[16px] !h-4 !w-4">developer_board</mat-icon>
              <span>Allocate GPU</span>
            </button>
          </div>
        </form>
        @if (err()) {
          <div class="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
        }
      </div>

      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
              <tr>
                <th class="px-4 py-3 font-semibold">Allocation</th>
                <th class="px-4 py-3 font-semibold">Profile</th>
                <th class="px-4 py-3 font-semibold">Runtime</th>
                <th class="px-4 py-3 font-semibold">Host / Region</th>
                <th class="px-4 py-3 font-semibold">Status</th>
                <th class="px-4 py-3 font-semibold text-right">Rate</th>
                <th class="px-4 py-3 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (g of allocations(); track g.id) {
                <tr>
                  <td class="px-4 py-3 font-mono">{{ g.id }}</td>
                  <td class="px-4 py-3 font-mono">{{ g.deviceCount }}x {{ g.gpuProfileId }} {{ g.partitionProfile || '' }}</td>
                  <td class="px-4 py-3">{{ g.runtimeCompatibility }}</td>
                  <td class="px-4 py-3 font-mono">{{ g.regionId }} · {{ g.hostId }}</td>
                  <td class="px-4 py-3 font-mono font-semibold">{{ g.status }}</td>
                  <td class="px-4 py-3 font-mono tabular-nums text-right">{{ i18n.formatEur(g.hourlyRateEur, 4) }}/h</td>
                  <td class="px-4 py-3 text-right">
                    @if (g.status === 'Allocated') {
                      <button type="button" (click)="release(g.id)" class="cursor-pointer rounded border border-slate-300 px-2.5 py-1 hover:bg-slate-100">
                        Release
                      </button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr><td colspan="7" class="px-4 py-6 text-center text-slate-500">{{ i18n.t('common.empty') }}</td></tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class ConsoleGpusPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly allocations = signal<GpuAllocation[]>([]);
  readonly err = signal<string | null>(null);
  readonly selectedProfileId = signal('gpu-h100-sxm-sim');

  readonly selectedProfile = computed(() =>
    (this.cp.catalog()?.gpuProfiles ?? []).find((p) => p.id === this.selectedProfileId()),
  );

  readonly form = this.fb.nonNullable.group({
    gpuProfileId: ['gpu-h100-sxm-sim'],
    regionId: ['eu-sim-nord-1'],
    deviceCount: [1],
    partitionProfile: [''],
    billingBasis: ['on-demand' as 'on-demand' | 'reserved-30d-sim'],
  });

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) await this.cp.loadCatalog();
    this.form.controls.gpuProfileId.valueChanges.subscribe((v) => {
      this.selectedProfileId.set(v);
      this.form.controls.partitionProfile.setValue('');
    });
    await this.refresh();
  }

  async refresh(): Promise<void> {
    this.allocations.set(await this.cp.listGpus(this.cp.selectedProjectId()));
  }

  async allocate(): Promise<void> {
    this.err.set(null);
    try {
      const val = this.form.getRawValue();
      await this.cp.allocateGpu({
        projectId: this.cp.selectedProjectId(),
        regionId: val.regionId,
        gpuProfileId: val.gpuProfileId,
        deviceCount: Number(val.deviceCount),
        partitionProfile: val.partitionProfile || undefined,
        billingBasis: val.billingBasis,
      });
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Allocation failed');
    }
  }

  async release(id: string): Promise<void> {
    await this.cp.releaseGpu(id);
    await this.refresh();
    await this.cp.loadOverview();
  }
}
