import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import type {FacilityHost, InfrastructureIncident} from '../core/models';

@Component({
  selector: 'app-console-access-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.access') }}</h1>
        <p class="text-sm text-slate-600">
          Organisation memberships, MFA status, scoped API credentials with expiry/revocation, and immutable audit events.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div class="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Create Scoped API Credential</h2>
          <form [formGroup]="keyForm" (ngSubmit)="createKey()" class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Key Name</span>
              <input formControlName="name" type="text" placeholder="slurm-ci-runner" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Expires (Days)</span>
              <input formControlName="expiresInDays" type="number" min="1" max="365" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
            </label>
            <button type="submit" class="cursor-pointer rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              Generate Key
            </button>
          </form>

          @if (newSecretOnce()) {
            <div class="rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs space-y-1">
              <div class="font-semibold text-amber-950">Copy synthetic credential now (shown once):</div>
              <div class="font-mono break-all text-amber-900">{{ newSecretOnce() }}</div>
            </div>
          }

          <div class="divide-y divide-slate-100 border-t border-slate-100 pt-2">
            @for (k of apiKeys(); track k.id) {
              <div class="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div class="font-semibold text-[#070D19]">{{ k.name }} <span class="font-mono text-slate-500">({{ k.prefix }}...)</span></div>
                  <div class="font-mono text-[11px] text-slate-500">Scopes: {{ k.scopes.join(', ') }} · {{ k.revoked ? 'REVOKED' : 'Active' }}</div>
                </div>
                @if (!k.revoked) {
                  <button type="button" (click)="revoke(k.id)" class="cursor-pointer rounded border border-red-200 px-2.5 py-1 text-red-700 hover:bg-red-50">
                    Revoke
                  </button>
                }
              </div>
            }
          </div>
        </div>

        <div class="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Organisation Members &amp; MFA</h2>
          @for (m of members(); track m.id) {
            <div class="flex items-center justify-between py-2 border-b border-slate-100 text-xs">
              <div>
                <div class="font-semibold text-[#070D19]">{{ m.name }}</div>
                <div class="font-mono text-slate-500">{{ m.email }}</div>
              </div>
              <div class="text-right font-mono">
                <div class="text-[#1D4ED8]">{{ m.role }}</div>
                <div class="text-emerald-700">{{ m.mfaEnabled ? 'MFA Active' : 'MFA Pending' }}</div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Audit Log -->
      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Audit Events (Secrets Redacted)</h2>
        </div>
        <div class="overflow-x-auto max-h-80">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
              <tr>
                <th class="px-4 py-2.5 font-semibold">Timestamp</th>
                <th class="px-4 py-2.5 font-semibold">Actor</th>
                <th class="px-4 py-2.5 font-semibold">Action</th>
                <th class="px-4 py-2.5 font-semibold">Request ID</th>
                <th class="px-4 py-2.5 font-semibold">Summary</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (ev of auditEvents(); track ev.id) {
                <tr>
                  <td class="px-4 py-2 font-mono whitespace-nowrap">{{ i18n.formatDateTime(ev.timestamp) }}</td>
                  <td class="px-4 py-2 font-mono">{{ ev.actor }}</td>
                  <td class="px-4 py-2 font-mono text-[#1D4ED8]">{{ ev.action }}</td>
                  <td class="px-4 py-2 font-mono text-slate-500">{{ ev.requestId }}</td>
                  <td class="px-4 py-2">{{ ev.summary }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class ConsoleAccessPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly members = signal<{id: string; name: string; email: string; role: string; mfaEnabled: boolean}[]>([]);
  readonly apiKeys = signal<{id: string; name: string; prefix: string; scopes: string[]; revoked: boolean}[]>([]);
  readonly auditEvents = signal<{id: string; actor: string; action: string; requestId: string; summary: string; timestamp: string}[]>([]);
  readonly newSecretOnce = signal<string | null>(null);

  readonly keyForm = this.fb.nonNullable.group({
    name: ['cli-automation', Validators.required],
    expiresInDays: [90],
  });

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const [acc, aud] = await Promise.all([this.cp.getAccessData(), this.cp.listAuditEvents()]);
    this.members.set(acc.members);
    this.apiKeys.set(acc.apiKeys);
    this.auditEvents.set(aud.items);
  }

  async createKey(): Promise<void> {
    if (this.keyForm.invalid) return;
    const {name, expiresInDays} = this.keyForm.getRawValue();
    const res = await this.cp.createApiKey(name, ['projects:read', 'jobs:write'], Number(expiresInDays));
    this.newSecretOnce.set(res.rawSecretOnce);
    await this.refresh();
  }

  async revoke(keyId: string): Promise<void> {
    await this.cp.revokeApiKey(keyId);
    await this.refresh();
  }
}

@Component({
  selector: 'app-console-support-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.support') }}</h1>
        <p class="text-sm text-slate-600">Support requests and localized automated email outbox (EN / FR / DE).</p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Open Support Ticket</h2>
          <form [formGroup]="form" (ngSubmit)="submit()" class="space-y-3">
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Subject</span>
              <input formControlName="subject" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Severity</span>
              <select formControlName="severity" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                <option value="normal">Normal</option>
                <option value="high">High</option>
              </select>
            </label>
            <button type="submit" class="cursor-pointer rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              {{ i18n.t('common.submit') }}
            </button>
          </form>

          <div class="pt-3 border-t border-slate-100 space-y-2">
            @for (t of tickets(); track t.id) {
              <div class="text-xs border border-slate-200 rounded-lg p-3">
                <div class="font-semibold text-[#070D19]">{{ t.subject }}</div>
                <div class="font-mono text-slate-500 mt-0.5">{{ t.id }} · {{ t.severity }} · {{ t.status }}</div>
              </div>
            }
          </div>
        </div>

        <div class="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Localized Email Notification Outbox (Simulated)</h2>
          @for (e of emails(); track e.id) {
            <div class="rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs space-y-1">
              <div class="flex justify-between font-mono text-slate-500">
                <span>To: {{ e.to }}</span>
                <span>Locale: {{ e.locale.toUpperCase() }}</span>
              </div>
              <div class="font-semibold text-[#070D19]">{{ e.subject }}</div>
              <p class="text-slate-700">{{ e.body }}</p>
            </div>
          } @empty {
            <p class="text-sm text-slate-500">Trigger a budget alert, issue an invoice, or simulate a host failure to see localized EN/FR/DE emails here.</p>
          }
        </div>
      </div>
    </div>
  `,
})
export class ConsoleSupportPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly tickets = signal<{id: string; subject: string; severity: string; status: string}[]>([]);
  readonly emails = signal<{id: string; to: string; locale: string; subject: string; body: string}[]>([]);

  readonly form = this.fb.nonNullable.group({
    subject: ['', Validators.required],
    severity: ['normal' as 'normal' | 'high'],
  });

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const res = await this.cp.getSupportData();
    this.tickets.set(res.tickets);
    this.emails.set(res.emails);
  }

  async submit(): Promise<void> {
    if (this.form.invalid) return;
    const {subject, severity} = this.form.getRawValue();
    await this.cp.createSupportTicket(this.cp.selectedProjectId(), subject, severity);
    this.form.controls.subject.setValue('');
    await this.refresh();
  }
}

@Component({
  selector: 'app-console-operations-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.operations') }}</h1>
          <p class="text-sm text-slate-600">{{ notice() }}</p>
        </div>
        <button
          type="button"
          (click)="reconcile()"
          class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]"
        >
          <mat-icon class="!text-[16px] !h-4 !w-4">sync</mat-icon>
          <span>Reconcile Control Plane After Restart</span>
        </button>
      </div>

      @if (reconcileMsg()) {
        <div class="rounded-lg border border-cyan-200 bg-cyan-50 px-4 py-2.5 text-xs text-cyan-950">
          {{ reconcileMsg() }}
        </div>
      }

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (h of hosts(); track h.id) {
          <div class="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
            <div class="flex items-start justify-between gap-2">
              <div>
                <div class="font-mono text-sm font-semibold text-[#070D19]">{{ h.hostname }}</div>
                <div class="text-xs text-slate-500">{{ h.siteName }} · {{ h.roomName }} · {{ h.rackId }}</div>
              </div>
              <span
                class="rounded px-2 py-0.5 font-mono text-[11px] font-semibold border"
                [class]="h.state === 'Healthy' ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-red-200 bg-red-50 text-red-800'"
              >
                {{ h.state }}
              </span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-xs border-t border-slate-100 pt-3">
              <div><span class="text-slate-500">vCPU:</span> <span class="font-mono">{{ h.usedVcpus }}/{{ h.totalVcpus }}</span></div>
              <div><span class="text-slate-500">Temp:</span> <span class="font-mono">{{ h.temperatureCelsius }}°C</span></div>
              <div><span class="text-slate-500">IT Power:</span> <span class="font-mono">{{ h.powerDrawWatts ?? 'N/A' }} W</span></div>
            </div>

            <div class="text-[11px] text-slate-600 space-y-1">
              <div class="font-mono">PUE: {{ h.pue ?? 'Unavailable' }} — {{ h.pueBoundaryNote }}</div>
              <div class="font-mono text-slate-400">Source: {{ h.telemetrySource }} · {{ i18n.formatDateTime(h.telemetryFreshnessIso) }}</div>
            </div>

            <div class="flex gap-2 pt-2 border-t border-slate-100">
              @if (h.state === 'Healthy') {
                <button
                  type="button"
                  (click)="failHost(h.id)"
                  class="cursor-pointer rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-800 hover:bg-red-100"
                >
                  Simulate Host Failure
                </button>
              } @else {
                <button
                  type="button"
                  (click)="recover(h.id)"
                  class="cursor-pointer rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800"
                >
                  Recover Host
                </button>
              }
            </div>
          </div>
        }
      </div>

      @if (incidents().length > 0) {
        <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Infrastructure Incidents</h2>
          @for (inc of incidents(); track inc.id) {
            <div class="rounded-lg border p-3 text-xs" [class]="inc.status === 'Active' ? 'border-red-200 bg-red-50 text-red-900' : 'border-slate-200 bg-slate-50 text-slate-700'">
              <div class="font-semibold">{{ inc.title }} ({{ inc.status }})</div>
              <div class="mt-0.5">{{ inc.summary }}</div>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class ConsoleOperationsPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);

  readonly hosts = signal<FacilityHost[]>([]);
  readonly incidents = signal<InfrastructureIncident[]>([]);
  readonly notice = signal('');
  readonly reconcileMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const res = await this.cp.getOperationsTelemetry();
    this.hosts.set(res.hosts);
    this.incidents.set(res.incidents);
    this.notice.set(res.controlSeparationNotice);
  }

  async failHost(hostId: string): Promise<void> {
    await this.cp.simulateHostFailure(hostId);
    await this.refresh();
    await this.cp.loadOverview();
  }

  async recover(hostId: string): Promise<void> {
    await this.cp.recoverHost(hostId);
    await this.refresh();
    await this.cp.loadOverview();
  }

  async reconcile(): Promise<void> {
    const res = await this.cp.reconcileAfterRestart();
    this.reconcileMsg.set(
      `Reconciliation complete: ${res.runningCount} running, ${res.failedCount} failed, ${res.reconciledCount} state record(s) updated.`,
    );
    await this.refresh();
    await this.cp.loadOverview();
  }
}

@Component({
  selector: 'app-console-assistant-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6 max-w-4xl">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.assistant') }} (Gemini 4.0)</h1>
        <p class="text-sm text-slate-600">
          Optional read-only compute advisor using deterministic tools. Never provisions resources, alters permissions, or receives customer datasets/secrets.
        </p>
      </div>

      <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div class="flex flex-wrap gap-2">
          @for (p of quickPrompts; track p) {
            <button
              type="button"
              (click)="promptControl.setValue(p)"
              class="cursor-pointer rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100"
            >
              {{ p }}
            </button>
          }
        </div>

        <form (ngSubmit)="ask()" class="flex gap-2">
          <input
            [formControl]="promptControl"
            type="text"
            placeholder="Ask about instance configurations, EUR cost estimates, failed job logs, or Slurm drafts..."
            class="flex-1 rounded-lg border border-slate-300 px-3 py-2.5 text-sm"
          />
          <button
            type="submit"
            [disabled]="loading()"
            class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-xs font-semibold text-white hover:bg-[#2563EB] disabled:opacity-50"
          >
            <mat-icon class="!text-[16px] !h-4 !w-4">auto_awesome</mat-icon>
            <span>{{ loading() ? 'Analyzing...' : 'Ask Gemini 4.0' }}</span>
          </button>
        </form>

        @if (err()) {
          <div class="rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-900">{{ err() }}</div>
        }

        @if (response(); as res) {
          <div class="rounded-xl border border-slate-200 bg-slate-50 p-5 space-y-4">
            <div class="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 font-mono">
              <span>Model: {{ res.model }}</span>
              <span>Tools: {{ res.toolsInvoked.join(', ') || 'none' }}</span>
            </div>
            <div class="whitespace-pre-wrap text-sm leading-relaxed text-[#070D19]">{{ res.answer }}</div>
            @if (res.references.length > 0) {
              <div class="border-t border-slate-200 pt-3 text-xs">
                <span class="font-semibold text-slate-700">Source References: </span>
                <span class="font-mono text-[#1D4ED8]">
                  @for (ref of res.references; track ref.id; let last = $last) {
                    [{{ ref.id }}: {{ ref.label }}]@if (!last) { · }
                  }
                </span>
              </div>
            }
            <div class="text-[11px] text-slate-500">{{ res.privacyNotice }}</div>
          </div>
        }
      </div>
    </div>
  `,
})
export class ConsoleAssistantPage {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly promptControl = this.fb.nonNullable.control(
    'Compare the estimated EUR cost of running eu-gp-medium with 1 H100-sim GPU for 24 hours vs 100 GB block storage, and summarize my current project usage.',
  );
  readonly loading = signal(false);
  readonly err = signal<string | null>(null);
  readonly response = signal<{
    answer: string;
    references: {id: string; label: string}[];
    toolsInvoked: string[];
    model: string;
    privacyNotice: string;
  } | null>(null);

  readonly quickPrompts = [
    'Summarize current project quotas and estimated EUR charges.',
    'Compare 48 hours of eu-gp-small vs eu-mem-large with 200 GB storage.',
    'Inspect any failed batch jobs in this project and explain the cause.',
    'Draft a Slurm batch job spec for 8 CPUs, 1 GPU, 32 GiB RAM.',
  ];

  async ask(): Promise<void> {
    const prompt = this.promptControl.value.trim();
    if (!prompt) return;
    this.loading.set(true);
    this.err.set(null);
    try {
      const res = await this.cp.queryAssistant(prompt, this.cp.selectedProjectId());
      this.response.set(res);
    } catch (e: unknown) {
      const msg = (e as {error?: {error?: {message?: string}}})?.error?.error?.message;
      this.err.set(msg ?? 'Assistant request failed. Ensure GEMINI_API_KEY is configured in Settings > Secrets.');
    } finally {
      this.loading.set(false);
    }
  }
}
