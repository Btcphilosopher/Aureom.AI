import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import type {
  BatchJob,
  BlockVolume,
  IndependentBackup,
  SharedFilesystem,
  StorageBucket,
  StorageSnapshot,
} from '../core/models';

@Component({
  selector: 'app-console-jobs-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.jobs') }}</h1>
          <p class="text-sm text-slate-600">
            Batch supercomputing workspace — separate queue allocation, workload execution, and output retrieval.
          </p>
        </div>
        <button
          type="button"
          (click)="refresh()"
          class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-[#070D19] hover:bg-slate-50"
        >
          <mat-icon class="!text-[16px] !h-4 !w-4">refresh</mat-icon>
          <span>{{ i18n.t('common.refresh') }}</span>
        </button>
      </div>

      <!-- Submit Batch Job Form -->
      <div class="rounded-xl border border-slate-200 bg-white p-6">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">Submit Batch Computing Job</h2>
        <form [formGroup]="form" (ngSubmit)="submit()" class="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Job Name</span>
            <input formControlName="name" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Scheduler Adapter</span>
            <select formControlName="schedulerBackend" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="slurm-adapter-sim">slurm-adapter-sim (Verified Slurm Sim)</option>
              <option value="local-queue-sim">local-queue-sim (Local Queue)</option>
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Region</span>
            <select formControlName="regionId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="eu-sim-nord-1">eu-sim-nord-1</option>
              <option value="eu-sim-central-1">eu-sim-central-1</option>
              <option value="eu-sim-west-1">eu-sim-west-1</option>
            </select>
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Queue &amp; Priority Class</span>
            <select formControlName="queueClass" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
              <option value="standard">standard</option>
              <option value="gpu-priority">gpu-priority</option>
              <option value="throughput">throughput</option>
            </select>
          </label>
          <label class="block sm:col-span-2">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Approved Workload Image</span>
            <input formControlName="workloadImage" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
          </label>
          <label class="block sm:col-span-2">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Command / Executable</span>
            <input formControlName="command" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">CPU Cores</span>
            <input formControlName="cpuCores" type="number" min="1" max="128" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">GPUs</span>
            <input formControlName="gpuCount" type="number" min="0" max="8" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Memory (GiB)</span>
            <input formControlName="memoryGiB" type="number" min="1" max="512" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <label class="block">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Runtime Limit (sec)</span>
            <input formControlName="runtimeLimitSeconds" type="number" min="30" max="86400" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
          </label>
          <label class="block sm:col-span-2">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Input Location (S3 URI)</span>
            <input formControlName="inputUri" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
          </label>
          <label class="block sm:col-span-2">
            <span class="block text-xs font-semibold text-slate-700 mb-1">Output Location (S3 URI)</span>
            <input formControlName="outputUri" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
          </label>
          <div class="sm:col-span-2 lg:col-span-4 flex items-center justify-between border-t border-slate-100 pt-3">
            <span class="text-xs text-slate-500">Queue acceptance returns Submitted; advance or wait for scheduler allocation separately.</span>
            <button type="submit" class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              <mat-icon class="!text-[16px] !h-4 !w-4">play_circle</mat-icon>
              <span>{{ i18n.t('home.cta.submitJob') }}</span>
            </button>
          </div>
        </form>
        @if (err()) {
          <div class="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
        }
      </div>

      <!-- Jobs Queue & State Inspection -->
      <div class="space-y-4">
        @for (job of jobs(); track job.id) {
          <div class="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <div class="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div class="flex items-center gap-2.5">
                  <span class="font-display text-base font-semibold text-[#070D19]">{{ job.name }}</span>
                  <span
                    class="rounded px-2 py-0.5 font-mono text-[11px] font-semibold border"
                    [class]="
                      job.state === 'Completed'
                        ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                        : job.state === 'Failed' || job.state === 'Cancelled'
                          ? 'border-red-200 bg-red-50 text-red-800'
                          : 'border-blue-200 bg-blue-50 text-blue-800'
                    "
                  >
                    {{ i18n.stateLabel(job.state) }}
                  </span>
                </div>
                <div class="mt-1 font-mono text-xs text-slate-500">
                  {{ job.id }} · {{ job.schedulerBackend }} · {{ job.queueClass }} · {{ job.cpuCores }} CPU / {{ job.gpuCount }} GPU / {{ job.memoryGiB }} GiB · {{ i18n.formatEur(job.hourlyRateEur, 4) }}/h
                </div>
              </div>

              <div class="flex flex-wrap gap-2 text-xs">
                @if (!isTerminal(job.state)) {
                  <button type="button" (click)="advance(job.id)" class="cursor-pointer rounded-lg bg-[#070D19] px-3 py-1.5 font-semibold text-white hover:bg-[#1D4ED8]">
                    Advance State →
                  </button>
                  <button type="button" (click)="runToCompletion(job.id)" class="cursor-pointer rounded-lg border border-[#1D4ED8] text-[#1D4ED8] px-3 py-1.5 font-semibold hover:bg-blue-50">
                    Run to Completion
                  </button>
                  <button type="button" (click)="cancel(job.id)" class="cursor-pointer rounded-lg border border-red-200 text-red-700 px-3 py-1.5 hover:bg-red-50">
                    {{ i18n.t('common.cancel') }}
                  </button>
                }
                <button type="button" (click)="viewSlurm(job.id)" class="cursor-pointer rounded-lg border border-slate-300 px-3 py-1.5 hover:bg-slate-50">
                  Slurm Script
                </button>
                @if (job.outputAvailable) {
                  <button type="button" (click)="fetchOutput(job.id)" class="cursor-pointer rounded-lg bg-emerald-700 px-3 py-1.5 font-semibold text-white hover:bg-emerald-800">
                    Retrieve Output
                  </button>
                }
              </div>
            </div>

            <div class="rounded-lg bg-[#070D19] p-3 font-mono text-[11px] text-slate-200 space-y-1 max-h-40 overflow-y-auto">
              @for (line of job.logs; track $index) {
                <div>{{ line }}</div>
              }
            </div>
          </div>
        } @empty {
          <div class="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
            {{ i18n.t('common.empty') }}
          </div>
        }
      </div>

      @if (inspectedOutput()) {
        <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-5 space-y-2">
          <div class="flex items-center justify-between">
            <h3 class="font-display text-sm font-semibold text-emerald-950">
              Retrieved Output Artifact: <span class="font-mono">{{ inspectedOutput()?.artifactName }}</span>
            </h3>
            <button type="button" (click)="inspectedOutput.set(null)" class="cursor-pointer text-xs text-emerald-800 underline">Close</button>
          </div>
          <div class="font-mono text-[11px] text-emerald-800">SHA-256: {{ inspectedOutput()?.sha256 }}</div>
          <pre class="rounded-lg bg-white border border-emerald-200 p-3 font-mono text-xs overflow-x-auto">{{ inspectedOutput()?.content }}</pre>
        </div>
      }

      @if (slurmPreview()) {
        <div class="rounded-xl border border-slate-200 bg-[#070D19] text-cyan-200 p-5 space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-mono text-xs">Generated Slurm Batch Script</span>
            <button type="button" (click)="slurmPreview.set(null)" class="cursor-pointer text-xs text-slate-300 underline">Close</button>
          </div>
          <pre class="font-mono text-xs overflow-x-auto">{{ slurmPreview() }}</pre>
        </div>
      }
    </div>
  `,
})
export class ConsoleJobsPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly jobs = signal<BatchJob[]>([]);
  readonly err = signal<string | null>(null);
  readonly inspectedOutput = signal<{artifactName?: string; content?: string; sha256?: string} | null>(null);
  readonly slurmPreview = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['nordic-mesh-run-02', Validators.required],
    schedulerBackend: ['slurm-adapter-sim' as 'slurm-adapter-sim' | 'local-queue-sim'],
    regionId: ['eu-sim-nord-1'],
    queueClass: ['gpu-priority' as 'standard' | 'gpu-priority' | 'throughput'],
    workloadImage: ['registry.sim.aureom.eu/ocean/nemo-solver:4.2.1-signed', Validators.required],
    command: ['python3 solve_mesh.py --input /data/baltic_grid_sample.csv --steps 64', Validators.required],
    cpuCores: [8],
    gpuCount: [1],
    memoryGiB: [32],
    runtimeLimitSeconds: [1200],
    inputUri: ['s3://baltic-datasets-nord/inputs/baltic_grid_sample.csv'],
    outputUri: ['s3://baltic-datasets-nord/outputs/'],
  });

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    this.jobs.set(await this.cp.listJobs(this.cp.selectedProjectId()));
  }

  isTerminal(state: string): boolean {
    return ['Completed', 'Failed', 'Cancelled', 'TimedOut'].includes(state);
  }

  async submit(): Promise<void> {
    this.err.set(null);
    if (this.form.invalid) {
      this.err.set(this.i18n.t('common.required'));
      return;
    }
    try {
      const val = this.form.getRawValue();
      await this.cp.submitJob({
        ...val,
        projectId: this.cp.selectedProjectId(),
        cpuCores: Number(val.cpuCores),
        gpuCount: Number(val.gpuCount),
        memoryGiB: Number(val.memoryGiB),
        runtimeLimitSeconds: Number(val.runtimeLimitSeconds),
      });
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Job submission failed');
    }
  }

  async advance(jobId: string): Promise<void> {
    await this.cp.advanceJob(jobId);
    await this.refresh();
    await this.cp.loadOverview();
  }

  async runToCompletion(jobId: string): Promise<void> {
    for (let i = 0; i < 6; i += 1) {
      const updated = await this.cp.advanceJob(jobId);
      if (this.isTerminal(updated.state)) break;
    }
    await this.refresh();
    await this.cp.loadOverview();
  }

  async cancel(jobId: string): Promise<void> {
    await this.cp.cancelJob(jobId);
    await this.refresh();
    await this.cp.loadOverview();
  }

  async fetchOutput(jobId: string): Promise<void> {
    const out = await this.cp.getJobOutput(jobId);
    if (out.available) {
      this.inspectedOutput.set(out);
    }
  }

  async viewSlurm(jobId: string): Promise<void> {
    this.slurmPreview.set(await this.cp.getSlurmScript(jobId));
  }
}

@Component({
  selector: 'app-console-storage-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.storage') }}</h1>
        <p class="text-sm text-slate-600">
          Object buckets, block volumes, POSIX shares, point-in-time snapshots, and independent cross-region backups.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Upload Synthetic Input Data to Object Bucket -->
        <div class="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Upload Synthetic Input Dataset (S3 Bucket)</h2>
          <form [formGroup]="uploadForm" (ngSubmit)="upload()" class="space-y-3">
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Target Bucket</span>
              <select formControlName="bucketId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
                @for (b of buckets(); track b.id) {
                  <option [value]="b.id">{{ b.name }} ({{ b.regionId }})</option>
                }
              </select>
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Object Key</span>
              <input formControlName="key" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Synthetic CSV / JSON Payload</span>
              <textarea formControlName="content" rows="4" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs"></textarea>
            </label>
            <button type="submit" class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              <mat-icon class="!text-[16px] !h-4 !w-4">upload_file</mat-icon>
              <span>Upload Object</span>
            </button>
          </form>
        </div>

        <!-- Create Bucket or Block Volume -->
        <div class="lg:col-span-6 space-y-6">
          <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
            <h2 class="font-display text-lg font-semibold text-[#070D19]">Create Object Bucket</h2>
            <form [formGroup]="bucketForm" (ngSubmit)="createBucket()" class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Bucket Name</span>
                <input formControlName="name" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Retention (Days)</span>
                <input formControlName="retentionDays" type="number" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
              </label>
              <button type="submit" class="cursor-pointer rounded-lg bg-[#070D19] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1D4ED8]">
                Create Bucket
              </button>
            </form>
          </div>

          <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
            <h2 class="font-display text-lg font-semibold text-[#070D19]">Create Persistent Block Volume</h2>
            <form [formGroup]="volumeForm" (ngSubmit)="createVolume()" class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Volume Name</span>
                <input formControlName="name" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Size (GB)</span>
                <input formControlName="sizeGB" type="number" min="10" max="2000" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs" />
              </label>
              <button type="submit" class="cursor-pointer rounded-lg bg-[#070D19] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1D4ED8]">
                Create Volume
              </button>
            </form>
          </div>
        </div>
      </div>

      @if (err()) {
        <div class="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
      }

      <!-- Buckets & Objects List -->
      <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h2 class="font-display text-lg font-semibold text-[#070D19]">Object Buckets &amp; Stored Datasets</h2>
        @for (b of buckets(); track b.id) {
          <div class="rounded-lg border border-slate-200 p-4 space-y-2">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div class="font-mono text-sm font-semibold text-[#070D19]">s3://{{ b.name }}</div>
              <div class="font-mono text-xs text-slate-500">{{ b.regionId }} · {{ b.accessControl }} · Retention {{ b.retentionDays }}d</div>
            </div>
            <p class="text-xs text-slate-600">{{ b.durabilityNotice }}</p>
            <div class="divide-y divide-slate-100 border-t border-slate-100 pt-2">
              @for (obj of b.objects; track obj.key) {
                <div class="py-1.5 flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
                  <span class="text-[#1D4ED8]">{{ obj.key }}</span>
                  <span class="text-slate-500">{{ obj.sizeBytes }} B · sha256:{{ obj.sha256.slice(0, 12) }}...</span>
                </div>
              }
            </div>
          </div>
        }
      </div>

      <!-- Block Volumes, Snapshots vs Independent Backups -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Block Volumes &amp; Snapshots</h2>
          @for (v of volumes(); track v.id) {
            <div class="rounded-lg border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div>
                <div class="font-mono font-semibold text-[#070D19]">{{ v.name }} ({{ v.sizeGB }} GB)</div>
                <div class="text-slate-500">{{ v.status }} · {{ v.regionId }}</div>
              </div>
              <div class="flex gap-2">
                <button type="button" (click)="snapshot(v.id)" class="cursor-pointer rounded border border-slate-300 px-2.5 py-1 hover:bg-slate-50">
                  Create Snapshot
                </button>
                <button type="button" (click)="backup(v.id)" class="cursor-pointer rounded bg-[#070D19] text-white px-2.5 py-1 hover:bg-[#1D4ED8]">
                  Independent Backup
                </button>
              </div>
            </div>
          }
          <div class="pt-2 border-t border-slate-100 space-y-1.5 text-xs">
            <div class="font-semibold text-slate-700">Snapshots (Dependent on Primary Volume)</div>
            @for (s of snapshots(); track s.id) {
              <div class="font-mono text-[11px] text-slate-600">{{ s.name }} ({{ s.sizeGB }} GB) — {{ s.note }}</div>
            }
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Independent Backups &amp; Shared POSIX</h2>
          @for (bak of backups(); track bak.id) {
            <div class="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3 text-xs">
              <div class="font-mono font-semibold text-[#070D19]">{{ bak.id }} · Target {{ bak.targetRegionId }}</div>
              <div class="text-slate-600 mt-0.5">Source {{ bak.sourceResourceId }} · {{ bak.verificationStatus }} · Retention {{ bak.retentionDays }}d</div>
            </div>
          }
          <div class="pt-3 border-t border-slate-100 space-y-2 text-xs">
            <div class="font-semibold text-slate-700">Shared POSIX Filesystems</div>
            @for (fs of filesystems(); track fs.id) {
              <div class="font-mono text-slate-600">{{ fs.name }} ({{ fs.protocol }}) · {{ fs.mountTarget }} · {{ fs.usedGB }}/{{ fs.capacityGB }} GB</div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ConsoleStoragePage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly buckets = signal<StorageBucket[]>([]);
  readonly volumes = signal<BlockVolume[]>([]);
  readonly filesystems = signal<SharedFilesystem[]>([]);
  readonly snapshots = signal<StorageSnapshot[]>([]);
  readonly backups = signal<IndependentBackup[]>([]);
  readonly err = signal<string | null>(null);

  readonly uploadForm = this.fb.nonNullable.group({
    bucketId: ['bkt_baltic_datasets'],
    key: ['inputs/nordic_run_input.csv', Validators.required],
    content: ['node,flux,temp_k\nN-01,1.42,276.4\nN-02,1.68,277.1\n', Validators.required],
  });

  readonly bucketForm = this.fb.nonNullable.group({
    name: ['experiment-artifacts', Validators.required],
    retentionDays: [90],
  });

  readonly volumeForm = this.fb.nonNullable.group({
    name: ['scratch-data-02', Validators.required],
    sizeGB: [100],
  });

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const data = await this.cp.listStorage(this.cp.selectedProjectId());
    this.buckets.set(data.buckets);
    this.volumes.set(data.volumes);
    this.filesystems.set(data.filesystems);
    this.snapshots.set(data.snapshots);
    this.backups.set(data.backups);
    if (data.buckets.length > 0 && !data.buckets.some((b) => b.id === this.uploadForm.controls.bucketId.value)) {
      this.uploadForm.controls.bucketId.setValue(data.buckets[0].id);
    }
  }

  async upload(): Promise<void> {
    this.err.set(null);
    const {bucketId, key, content} = this.uploadForm.getRawValue();
    try {
      await this.cp.uploadBucketObject(bucketId, key, content);
      await this.refresh();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Upload failed');
    }
  }

  async createBucket(): Promise<void> {
    this.err.set(null);
    const {name, retentionDays} = this.bucketForm.getRawValue();
    try {
      const b = await this.cp.createBucket({
        projectId: this.cp.selectedProjectId(),
        name,
        regionId: this.cp.activeProject()?.primaryRegionId ?? 'eu-sim-nord-1',
        accessControl: 'private-project',
        retentionDays: Number(retentionDays),
      });
      this.uploadForm.controls.bucketId.setValue(b.id);
      await this.refresh();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Bucket creation failed');
    }
  }

  async createVolume(): Promise<void> {
    this.err.set(null);
    const {name, sizeGB} = this.volumeForm.getRawValue();
    try {
      await this.cp.createVolume({
        projectId: this.cp.selectedProjectId(),
        name,
        regionId: this.cp.activeProject()?.primaryRegionId ?? 'eu-sim-nord-1',
        sizeGB: Number(sizeGB),
      });
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Volume creation failed');
    }
  }

  async snapshot(volId: string): Promise<void> {
    await this.cp.createSnapshot(volId, `snap-${Date.now().toString().slice(-4)}`);
    await this.refresh();
  }

  async backup(volId: string): Promise<void> {
    await this.cp.createBackup({
      sourceResourceId: volId,
      sourceKind: 'volume',
      targetRegionId: 'eu-sim-central-1',
      retentionDays: 30,
    });
    await this.refresh();
  }
}
