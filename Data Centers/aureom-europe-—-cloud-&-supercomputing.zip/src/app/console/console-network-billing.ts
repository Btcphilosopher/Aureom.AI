import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import type {
  Invoice,
  ProjectNetwork,
  PublicAddressAllocation,
  SecurityGroup,
  UsageLedgerEntry,
} from '../core/models';

@Component({
  selector: 'app-console-networking-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.networking') }}</h1>
        <p class="text-sm text-slate-600">
          Project VPC networks, CIDR overlap validation, default-deny inbound security groups, and public address allocation.
        </p>
      </div>

      @if (err()) {
        <div class="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
      }

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Subnets & Overlap Validation -->
        <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Project Networks &amp; Subnets</h2>
          @for (net of networks(); track net.id) {
            <div class="rounded-lg border border-slate-200 p-4 space-y-3">
              <div class="flex items-center justify-between">
                <span class="font-mono text-sm font-semibold text-[#070D19]">{{ net.name }} ({{ net.cidr }})</span>
                <span class="font-mono text-xs text-slate-500">{{ net.regionId }}</span>
              </div>
              <p class="text-xs text-slate-600">{{ net.privateConnectivity }}</p>
              <div class="divide-y divide-slate-100 border-t border-slate-100 pt-2 text-xs font-mono">
                @for (sub of net.subnets; track sub.id) {
                  <div class="py-1.5 flex justify-between">
                    <span>{{ sub.name }}</span>
                    <span class="text-[#1D4ED8]">{{ sub.cidr }} (gw {{ sub.gatewayIp }})</span>
                  </div>
                }
              </div>
              <form [formGroup]="subnetForm" (ngSubmit)="addSubnet(net.id)" class="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100">
                <input formControlName="name" type="text" placeholder="subnet-name" class="rounded border border-slate-300 px-2 py-1.5 text-xs" />
                <input formControlName="cidr" type="text" placeholder="10.42.30.0/24" class="rounded border border-slate-300 px-2 py-1.5 font-mono text-xs" />
                <button type="submit" class="cursor-pointer rounded bg-[#070D19] text-white px-3 py-1.5 text-xs font-semibold hover:bg-[#1D4ED8]">
                  Add Subnet
                </button>
              </form>
            </div>
          }
        </div>

        <!-- Security Groups & Public IPs -->
        <div class="space-y-6">
          <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#070D19]">Security Groups (Default-Deny Inbound)</h2>
            @for (sg of securityGroups(); track sg.id) {
              <div class="rounded-lg border border-slate-200 p-4 space-y-3">
                <div class="flex items-center justify-between text-xs">
                  <span class="font-mono font-semibold text-[#070D19]">{{ sg.name }}</span>
                  <span class="font-mono text-emerald-800">Default: {{ sg.defaultInboundPolicy }}</span>
                </div>
                <div class="divide-y divide-slate-100 text-xs font-mono">
                  @for (r of sg.inboundRules; track r.id) {
                    <div class="py-1.5 flex justify-between">
                      <span>{{ r.protocol }}:{{ r.portRange }} ← {{ r.sourceCidr }}</span>
                      <span class="text-slate-500 font-sans">{{ r.description }}</span>
                    </div>
                  }
                </div>
                <form [formGroup]="ruleForm" (ngSubmit)="addRule(sg.id)" class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100">
                  <select formControlName="protocol" class="rounded border border-slate-300 px-2 py-1.5 font-mono text-xs">
                    <option value="tcp">tcp</option>
                    <option value="udp">udp</option>
                  </select>
                  <input formControlName="portRange" type="text" placeholder="443" class="rounded border border-slate-300 px-2 py-1.5 font-mono text-xs" />
                  <input formControlName="sourceCidr" type="text" placeholder="192.0.2.0/24" class="rounded border border-slate-300 px-2 py-1.5 font-mono text-xs" />
                  <button type="submit" class="cursor-pointer rounded bg-[#1D4ED8] text-white px-3 py-1.5 text-xs font-semibold hover:bg-[#2563EB]">
                    Add Rule
                  </button>
                </form>
              </div>
            }
          </div>

          <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
            <div class="flex items-center justify-between">
              <h2 class="font-display text-lg font-semibold text-[#070D19]">Public Address Allocations (Simulated)</h2>
              <button type="button" (click)="allocateIp()" class="cursor-pointer rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-50">
                Allocate IPv4
              </button>
            </div>
            @for (ip of publicAddresses(); track ip.id) {
              <div class="font-mono text-xs flex justify-between py-1 border-b border-slate-100">
                <span class="text-[#1D4ED8]">{{ ip.ipAddress }}</span>
                <span class="text-slate-500">{{ ip.regionId }} · {{ ip.adapterName }}</span>
              </div>
            } @empty {
              <p class="text-xs text-slate-500">No public addresses allocated (control plane remains private by default).</p>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ConsoleNetworkingPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly networks = signal<ProjectNetwork[]>([]);
  readonly securityGroups = signal<SecurityGroup[]>([]);
  readonly publicAddresses = signal<PublicAddressAllocation[]>([]);
  readonly err = signal<string | null>(null);

  readonly subnetForm = this.fb.nonNullable.group({
    name: ['worker-subnet-c', Validators.required],
    cidr: ['10.42.30.0/24', Validators.required],
  });

  readonly ruleForm = this.fb.nonNullable.group({
    protocol: ['tcp' as 'tcp' | 'udp' | 'icmp'],
    portRange: ['443', Validators.required],
    sourceCidr: ['192.0.2.0/24', Validators.required],
  });

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const data = await this.cp.listNetworking(this.cp.selectedProjectId());
    this.networks.set(data.networks);
    this.securityGroups.set(data.securityGroups);
    this.publicAddresses.set(data.publicAddresses);
  }

  async addSubnet(networkId: string): Promise<void> {
    this.err.set(null);
    try {
      const {name, cidr} = this.subnetForm.getRawValue();
      await this.cp.addSubnet(networkId, name, cidr);
      await this.refresh();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Subnet error');
    }
  }

  async addRule(sgId: string): Promise<void> {
    this.err.set(null);
    try {
      const val = this.ruleForm.getRawValue();
      await this.cp.addFirewallRule(sgId, {...val, description: 'Explicit console inbound rule'});
      await this.refresh();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Firewall rule rejected');
    }
  }

  async allocateIp(): Promise<void> {
    await this.cp.allocatePublicIp(
      this.cp.selectedProjectId(),
      this.cp.activeProject()?.primaryRegionId ?? 'eu-sim-nord-1',
    );
    await this.refresh();
  }
}

@Component({
  selector: 'app-console-billing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-start justify-between gap-4">
        <div class="max-w-2xl">
          <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('billing.title') }}</h1>
          <p class="mt-1 text-sm text-slate-600">{{ i18n.t('billing.explanation') }}</p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          <input
            [formControl]="periodKeyControl"
            type="text"
            class="rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs w-44"
            aria-label="Metering period idempotency key"
          />
          <button
            type="button"
            (click)="runMetering()"
            class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#070D19] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1D4ED8]"
          >
            <mat-icon class="!text-[16px] !h-4 !w-4">speed</mat-icon>
            <span>{{ i18n.t('billing.runMetering') }}</span>
          </button>
          <button
            type="button"
            (click)="issueInvoice()"
            class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]"
          >
            <mat-icon class="!text-[16px] !h-4 !w-4">receipt_long</mat-icon>
            <span>{{ i18n.t('billing.generateInvoice') }}</span>
          </button>
        </div>
      </div>

      @if (meteringFeedback()) {
        <div class="rounded-lg border border-cyan-200 bg-cyan-50 px-4 py-2.5 text-xs text-cyan-950">
          {{ meteringFeedback() }}
        </div>
      }
      @if (err()) {
        <div class="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-900">{{ err() }}</div>
      }

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="rounded-xl border border-slate-200 bg-white p-5">
          <div class="text-xs text-slate-500">{{ i18n.t('billing.estimated') }}</div>
          <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#1D4ED8]">{{ i18n.formatEur(estimatedEur(), 2) }}</div>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-5">
          <div class="text-xs text-slate-500">{{ i18n.t('billing.finalised') }}</div>
          <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ i18n.formatEur(finalisedEur(), 2) }}</div>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-5">
          <div class="text-xs text-slate-500">Issued Demo Invoices</div>
          <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ invoices().length }}</div>
        </div>
      </div>

      <!-- Usage Ledger Table -->
      <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Auditable Decimal Usage Ledger</h2>
          <span class="font-mono text-xs text-slate-500">Currency: EUR · Price Book v2026.11-demo</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
              <tr>
                <th class="px-4 py-3 font-semibold">Resource</th>
                <th class="px-4 py-3 font-semibold">Idempotency Period Key</th>
                <th class="px-4 py-3 font-semibold text-right">Qty</th>
                <th class="px-4 py-3 font-semibold text-right">Rate</th>
                <th class="px-4 py-3 font-semibold text-right">Amount</th>
                <th class="px-4 py-3 font-semibold">State</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (u of entries(); track u.id) {
                <tr>
                  <td class="px-4 py-3 font-medium text-[#070D19]">{{ u.resourceName }}</td>
                  <td class="px-4 py-3 font-mono text-[11px] text-slate-500">{{ u.meteringPeriodKey }}</td>
                  <td class="px-4 py-3 font-mono tabular-nums text-right">{{ u.quantity }} {{ u.unit }}</td>
                  <td class="px-4 py-3 font-mono tabular-nums text-right">{{ i18n.formatEur(u.unitRateEur, 4) }}</td>
                  <td class="px-4 py-3 font-mono tabular-nums text-right font-semibold">{{ i18n.formatEur(u.amountEur, 4) }}</td>
                  <td class="px-4 py-3 font-mono">{{ u.finalisationState }}</td>
                </tr>
              } @empty {
                <tr><td colspan="6" class="px-4 py-6 text-center text-slate-500">{{ i18n.t('common.empty') }}</td></tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Issued Demonstration Invoices -->
      @if (invoices().length > 0) {
        <div class="space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Issued Demonstration Invoices</h2>
          @for (inv of invoices(); track inv.id) {
            <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <div class="font-mono text-sm font-bold text-[#070D19]">{{ inv.invoiceNumber }}</div>
                  <div class="text-xs text-slate-500">{{ i18n.formatDateTime(inv.issuedAt) }} · {{ inv.status }}</div>
                </div>
                <div class="flex items-center gap-3">
                  <div class="text-right">
                    <div class="font-mono text-xl font-bold tabular-nums text-[#070D19]">{{ i18n.formatEur(inv.totalEur, 2) }}</div>
                    <div class="text-[11px] text-slate-500">Subtotal {{ i18n.formatEur(inv.subtotalEur, 2) }} + VAT {{ inv.vatRatePercent }}% ({{ i18n.formatEur(inv.vatAmountEur, 2) }})</div>
                  </div>
                  @if (inv.status === 'IssuedInvoice') {
                    <button type="button" (click)="pay(inv.id)" class="cursor-pointer rounded-lg bg-emerald-700 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-800">
                      {{ i18n.t('billing.markPaid') }}
                    </button>
                  }
                </div>
              </div>
              <p class="text-xs text-slate-600">{{ inv.taxTreatmentNote }}</p>
              <p class="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                {{ i18n.t('contract.reviewNotice') }}
              </p>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class ConsoleBillingPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly entries = signal<UsageLedgerEntry[]>([]);
  readonly estimatedEur = signal('0.00');
  readonly finalisedEur = signal('0.00');
  readonly invoices = signal<Invoice[]>([]);
  readonly meteringFeedback = signal<string | null>(null);
  readonly err = signal<string | null>(null);

  readonly periodKeyControl = this.fb.nonNullable.control('2026-11-20T10:00Z');

  async ngOnInit(): Promise<void> {
    await this.refresh();
  }

  async refresh(): Promise<void> {
    const data = await this.cp.getUsage(this.cp.selectedProjectId());
    this.entries.set(data.entries);
    this.estimatedEur.set(data.estimatedCurrentEur);
    this.finalisedEur.set(data.finalisedUsageEur);
    this.invoices.set(data.invoices);
  }

  async runMetering(): Promise<void> {
    this.err.set(null);
    const res = await this.cp.runMeteringTick(this.cp.selectedProjectId(), this.periodKeyControl.value);
    this.meteringFeedback.set(
      `Created ${res.createdEntries.length} ledger entry/entries for period "${this.periodKeyControl.value}" (skipped ${res.skippedDuplicates} duplicate period records).`,
    );
    await this.refresh();
    await this.cp.loadOverview();
  }

  async issueInvoice(): Promise<void> {
    this.err.set(null);
    try {
      await this.cp.generateInvoice(this.cp.selectedProjectId());
      await this.refresh();
      await this.cp.loadOverview();
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Invoice generation failed');
    }
  }

  async pay(invoiceId: string): Promise<void> {
    await this.cp.markInvoicePaid(invoiceId);
    await this.refresh();
  }
}
