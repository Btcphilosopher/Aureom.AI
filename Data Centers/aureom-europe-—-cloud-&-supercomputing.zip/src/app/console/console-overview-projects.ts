import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';

@Component({
  selector: 'app-console-overview-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.overview') }}</h1>
          <p class="text-sm text-slate-600">
            {{ cp.activeProject()?.name }} · <span class="font-mono text-xs">{{ cp.activeProject()?.primaryRegionId }}</span>
          </p>
        </div>
        <div class="flex flex-wrap gap-2">
          <a routerLink="/console/compute" class="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] whitespace-nowrap">
            <mat-icon class="!text-[16px] !h-4 !w-4">add</mat-icon>
            <span>{{ i18n.t('home.cta.launchInstance') }}</span>
          </a>
          <a routerLink="/console/jobs" class="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-[#070D19] hover:bg-slate-50 whitespace-nowrap">
            <mat-icon class="!text-[16px] !h-4 !w-4">memory</mat-icon>
            <span>{{ i18n.t('home.cta.submitJob') }}</span>
          </a>
        </div>
      </div>

      @if (cp.overview(); as ov) {
        <!-- KPI Summary Row -->
        <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div class="rounded-xl border border-slate-200 bg-white p-4">
            <div class="text-xs text-slate-500">Active Instances</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ ov.activeInstances }}</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-4">
            <div class="text-xs text-slate-500">Job Queues (Q / Run)</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ ov.queuedJobs }} / {{ ov.runningJobs }}</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-4">
            <div class="text-xs text-slate-500">GPU Devices</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ ov.gpuDevicesAllocated }}</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-white p-4">
            <div class="text-xs text-slate-500">Storage Allocated</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-[#070D19]">{{ ov.storageUsedGB }} GB</div>
          </div>
          <div class="rounded-xl border border-slate-200 bg-[#070D19] text-white p-4">
            <div class="text-xs text-slate-300">{{ i18n.t('billing.estimated') }}</div>
            <div class="mt-1 font-mono text-2xl font-bold tabular-nums text-cyan-300">{{ i18n.formatEur(ov.estimatedChargesEur, 2) }}</div>
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <!-- Quotas -->
          @if (ov.quotaSummary; as q) {
            <div class="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
              <div class="flex items-center justify-between">
                <h2 class="font-display text-lg font-semibold text-[#070D19]">Available Project Quotas</h2>
                <span class="font-mono text-xs text-slate-500">{{ cp.activeProject()?.id }}</span>
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div class="space-y-1.5">
                  <div class="flex justify-between"><span>vCPUs</span><span class="font-mono tabular-nums">{{ q.used.vcpus }} / {{ q.quotas.maxVcpus }}</span></div>
                  <div class="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full bg-[#1D4ED8]" [style.width.%]="pct(q.used.vcpus, q.quotas.maxVcpus)"></div>
                  </div>
                </div>
                <div class="space-y-1.5">
                  <div class="flex justify-between"><span>Memory (GiB)</span><span class="font-mono tabular-nums">{{ q.used.memoryGiB }} / {{ q.quotas.maxMemoryGiB }}</span></div>
                  <div class="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full bg-[#1D4ED8]" [style.width.%]="pct(q.used.memoryGiB, q.quotas.maxMemoryGiB)"></div>
                  </div>
                </div>
                <div class="space-y-1.5">
                  <div class="flex justify-between"><span>GPU Accelerators</span><span class="font-mono tabular-nums">{{ q.used.gpus }} / {{ q.quotas.maxGpus }}</span></div>
                  <div class="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full bg-[#0891B2]" [style.width.%]="pct(q.used.gpus, q.quotas.maxGpus)"></div>
                  </div>
                </div>
                <div class="space-y-1.5">
                  <div class="flex justify-between"><span>Storage (GB)</span><span class="font-mono tabular-nums">{{ q.used.storageGB }} / {{ q.quotas.maxStorageGB }}</span></div>
                  <div class="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full bg-[#0891B2]" [style.width.%]="pct(q.used.storageGB, q.quotas.maxStorageGB)"></div>
                  </div>
                </div>
              </div>
            </div>
          }

          <!-- Incidents & Pending Actions -->
          <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#070D19]">Incidents &amp; Pending Actions</h2>
            @if (ov.activeIncidents.length === 0 && ov.pendingActions.length === 0) {
              <p class="text-sm text-slate-600">No active infrastructure incidents or pending reconciliation actions.</p>
            }
            @for (inc of ov.activeIncidents; track inc.id) {
              <div class="rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-900">
                <div class="font-semibold">{{ inc.title }}</div>
                <div class="mt-1">{{ inc.summary }}</div>
              </div>
            }
            @for (act of ov.pendingActions; track act.resourceId) {
              <div class="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
                <div class="font-mono font-semibold">{{ act.type }} · {{ act.resourceId }}</div>
                <div class="mt-1">{{ act.summary }}</div>
              </div>
            }
            <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <a routerLink="/console/operations" class="font-semibold text-[#1D4ED8] hover:underline">Open Operations Telemetry →</a>
              <a routerLink="/console/billing" class="font-semibold text-[#1D4ED8] hover:underline">Usage &amp; Billing →</a>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ConsoleOverviewPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);

  async ngOnInit(): Promise<void> {
    await this.cp.loadOverview();
  }

  pct(used: number, max: number): number {
    if (!max) return 0;
    return Math.min(100, Math.round((used / max) * 100));
  }
}

@Component({
  selector: 'app-console-projects-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#070D19]">{{ i18n.t('console.nav.projects') }}</h1>
        <p class="text-sm text-slate-600">Project ownership, explicit EU data residency boundaries, and monthly EUR budget alerts.</p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Create Project Form -->
        <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#070D19]">Create Project</h2>
          <form [formGroup]="createForm" (ngSubmit)="createProject()" class="space-y-3">
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Project Name</span>
              <input formControlName="name" type="text" placeholder="e.g. Alpine Glacier Ensemble" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Description</span>
              <input formControlName="description" type="text" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            </label>
            <label class="block">
              <span class="block text-xs font-semibold text-slate-700 mb-1">Primary Compute &amp; Storage Region</span>
              <select formControlName="primaryRegionId" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs">
                <option value="eu-sim-nord-1">eu-sim-nord-1 (Luleå Demo)</option>
                <option value="eu-sim-central-1">eu-sim-central-1 (Frankfurt Demo)</option>
                <option value="eu-sim-west-1">eu-sim-west-1 (Grenoble Demo)</option>
              </select>
            </label>
            <div class="grid grid-cols-2 gap-3">
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Replica Location</span>
                <select formControlName="replicaLocation" class="w-full rounded-lg border border-slate-300 px-2.5 py-2 font-mono text-xs">
                  <option value="None">None</option>
                  <option value="eu-sim-west-1 (Grenoble Demo)">eu-sim-west-1</option>
                  <option value="eu-sim-central-1 (Frankfurt Demo)">eu-sim-central-1</option>
                </select>
              </label>
              <label class="block">
                <span class="block text-xs font-semibold text-slate-700 mb-1">Backup Target</span>
                <select formControlName="backupLocation" class="w-full rounded-lg border border-slate-300 px-2.5 py-2 font-mono text-xs">
                  <option value="eu-sim-central-1 (Frankfurt Demo)">eu-sim-central-1</option>
                  <option value="eu-sim-nord-1 (Luleå Demo)">eu-sim-nord-1</option>
                </select>
              </label>
            </div>
            @if (msg()) {
              <div class="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-900">{{ msg() }}</div>
            }
            @if (err()) {
              <div class="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-900">{{ err() }}</div>
            }
            <button type="submit" class="cursor-pointer inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2563EB]">
              <mat-icon class="!text-[16px] !h-4 !w-4">create_new_folder</mat-icon>
              <span>{{ i18n.t('common.create') }}</span>
            </button>
          </form>
        </div>

        <!-- Budget Alert + Active Residency Detail -->
        <div class="lg:col-span-7 space-y-6">
          @if (cp.activeProject(); as proj) {
            <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
              <div class="flex items-center justify-between">
                <h2 class="font-display text-lg font-semibold text-[#070D19]">Budget Alert — {{ proj.name }}</h2>
                @if (proj.budgetAlert?.triggered) {
                  <span class="font-mono text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">Triggered</span>
                }
              </div>
              <form [formGroup]="budgetForm" (ngSubmit)="saveBudget(proj.id)" class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                <label class="block">
                  <span class="block text-xs font-semibold text-slate-700 mb-1">Threshold (EUR/mo)</span>
                  <input formControlName="monthlyThresholdEur" type="number" step="0.01" class="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm" />
                </label>
                <label class="block">
                  <span class="block text-xs font-semibold text-slate-700 mb-1">Alert Email</span>
                  <input formControlName="notifyEmail" type="email" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                </label>
                <button type="submit" class="cursor-pointer rounded-lg bg-[#070D19] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#1D4ED8]">
                  {{ i18n.t('common.save') }} Alert
                </button>
              </form>
            </div>

            <div class="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
              <h2 class="font-display text-lg font-semibold text-[#070D19]">Configured Residency Boundaries</h2>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div><span class="text-slate-500">Compute:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.computeLocation }}</span></div>
                <div><span class="text-slate-500">Primary Storage:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.primaryStorageLocation }}</span></div>
                <div><span class="text-slate-500">Replicas:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.replicaLocation }}</span></div>
                <div><span class="text-slate-500">Backups:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.backupLocation }}</span></div>
                <div><span class="text-slate-500">Logs:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.logLocation }}</span></div>
                <div><span class="text-slate-500">Support Access:</span> <span class="font-mono text-[#070D19]">{{ proj.residency.supportAccessPolicy }}</span></div>
              </div>
              <p class="text-xs text-slate-600 border-t border-slate-100 pt-3">{{ proj.residency.sovereigntyNotice }}</p>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class ConsoleProjectsPage implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  private readonly fb = inject(FormBuilder);

  readonly msg = signal<string | null>(null);
  readonly err = signal<string | null>(null);

  readonly createForm = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    description: ['European research workload workspace (simulated)'],
    primaryRegionId: ['eu-sim-nord-1'],
    replicaLocation: ['eu-sim-west-1 (Grenoble Demo)'],
    backupLocation: ['eu-sim-central-1 (Frankfurt Demo)'],
  });

  readonly budgetForm = this.fb.nonNullable.group({
    monthlyThresholdEur: ['10.00', Validators.required],
    notifyEmail: ['finance@ncrc-demo.example.eu', [Validators.required, Validators.email]],
  });

  async ngOnInit(): Promise<void> {
    await this.cp.loadOverview();
    const alert = this.cp.activeProject()?.budgetAlert;
    if (alert) {
      this.budgetForm.patchValue({
        monthlyThresholdEur: alert.monthlyThresholdEur,
        notifyEmail: alert.notifyEmail,
      });
    }
  }

  async createProject(): Promise<void> {
    this.msg.set(null);
    this.err.set(null);
    if (this.createForm.invalid) {
      this.err.set(this.i18n.t('common.required'));
      return;
    }
    try {
      const p = await this.cp.createProject(this.createForm.getRawValue());
      this.msg.set(`Created project "${p.name}" (${p.id}) and switched active context.`);
      this.createForm.controls.name.setValue('');
    } catch (e: unknown) {
      this.err.set((e as {error?: {error?: {message?: string}}})?.error?.error?.message ?? 'Failed to create project');
    }
  }

  async saveBudget(projectId: string): Promise<void> {
    this.msg.set(null);
    this.err.set(null);
    if (this.budgetForm.invalid) {
      this.err.set(this.i18n.t('common.invalidEmail'));
      return;
    }
    const {monthlyThresholdEur, notifyEmail} = this.budgetForm.getRawValue();
    await this.cp.setBudgetAlert(projectId, monthlyThresholdEur, notifyEmail);
    this.msg.set(`Budget alert set to ${monthlyThresholdEur} EUR for ${notifyEmail}.`);
  }
}
