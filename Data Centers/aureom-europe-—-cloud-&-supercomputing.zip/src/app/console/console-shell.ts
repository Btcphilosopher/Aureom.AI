import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {ControlPlaneService} from '../core/control-plane.service';
import {I18nService} from '../core/i18n.service';
import {LanguageSwitcher} from '../shared/language-switcher';

@Component({
  selector: 'app-console-shell',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatIconModule, LanguageSwitcher],
  template: `
    <div class="min-h-screen flex bg-[#F6F9FC] text-[#070D19]">
      <!-- Sidebar (256px) -->
      <aside class="hidden lg:flex w-64 shrink-0 flex-col bg-[#070D19] text-slate-300 border-r border-white/10">
        <div class="px-5 py-4 border-b border-white/10">
          <a routerLink="/" class="font-display text-base font-bold tracking-tight text-white whitespace-nowrap">
            {{ i18n.t('brand.name') }}
          </a>
          <div class="mt-1 font-mono text-[11px] text-cyan-300 truncate">
            {{ cp.overview()?.organisation?.name ?? 'Nordic Climate Research (Demo)' }}
          </div>
        </div>

        <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1 text-sm" aria-label="Console navigation">
          @for (item of navItems; track item.path) {
            <a
              [routerLink]="item.path"
              routerLinkActive="bg-[#1D4ED8] text-white font-semibold"
              class="flex items-center gap-2.5 rounded-lg px-3 py-2 text-slate-300 hover:bg-white/10 hover:text-white transition-colors whitespace-nowrap"
            >
              <mat-icon class="!text-[18px] !h-[18px] !w-[18px] shrink-0">{{ item.icon }}</mat-icon>
              <span class="truncate">{{ i18n.t(item.labelKey) }}</span>
            </a>
          }
        </nav>

        <div class="p-4 border-t border-white/10 text-xs space-y-2">
          <div class="font-mono text-slate-400 truncate">{{ cp.actorEmail() }}</div>
          <div class="flex items-center justify-between text-[11px] text-slate-400">
            <span>Role: <strong class="text-slate-200">{{ cp.role() }}</strong></span>
            <span>MFA: <strong class="text-cyan-300">OK</strong></span>
          </div>
          <a
            routerLink="/signin"
            class="block text-center rounded-md border border-white/15 py-1.5 text-slate-200 hover:bg-white/10 transition-colors"
          >
            {{ i18n.t('nav.signIn') }}
          </a>
        </div>
      </aside>

      <!-- Main Workspace Viewport -->
      <div class="flex-1 min-w-0 flex flex-col">
        <!-- Top Workspace Bar -->
        <header class="sticky top-0 z-20 border-b border-slate-200 bg-white px-4 sm:px-6 py-3">
          <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3 min-w-0">
              <button
                type="button"
                (click)="mobileNav.set(!mobileNav())"
                class="lg:hidden cursor-pointer rounded-lg border border-slate-200 p-1.5 text-slate-700"
                aria-label="Toggle console menu"
              >
                <mat-icon class="!text-[20px] !h-5 !w-5">menu</mat-icon>
              </button>
              <div class="flex items-center gap-2 min-w-0">
                <span class="text-xs font-medium text-slate-500 whitespace-nowrap">{{ i18n.t('console.header.project') }}:</span>
                <select
                  [value]="cp.selectedProjectId()"
                  (change)="onProjectChange($event)"
                  class="rounded-lg border border-slate-300 bg-slate-50 px-2.5 py-1.5 font-mono text-xs font-medium text-[#070D19] max-w-[240px] truncate"
                  aria-label="Active project selector"
                >
                  @for (p of cp.projects(); track p.id) {
                    <option [value]="p.id">{{ p.name }} ({{ p.primaryRegionId }})</option>
                  }
                </select>
              </div>
              <span class="hidden md:inline font-mono text-xs text-slate-500">
                · {{ i18n.t('common.simulatedTag') }}
              </span>
            </div>

            <div class="flex items-center gap-3 shrink-0">
              <app-language-switcher variant="light" />
              <button
                type="button"
                (click)="resetDemo()"
                class="cursor-pointer rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
              >
                {{ i18n.t('console.header.resetDemo') }}
              </button>
              <a
                routerLink="/"
                class="hidden sm:inline-flex items-center gap-1 rounded-lg bg-[#070D19] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#1D4ED8] transition-colors whitespace-nowrap shrink-0"
              >
                <span>{{ i18n.t('console.header.publicSite') }}</span>
              </a>
            </div>
          </div>

          @if (mobileNav()) {
            <nav class="lg:hidden mt-3 pt-3 border-t border-slate-200 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              @for (item of navItems; track item.path) {
                <a
                  [routerLink]="item.path"
                  (click)="mobileNav.set(false)"
                  routerLinkActive="bg-[#1D4ED8] text-white"
                  class="flex items-center gap-1.5 rounded-md px-2.5 py-2 text-slate-700 hover:bg-slate-100"
                >
                  <mat-icon class="!text-[16px] !h-4 !w-4">{{ item.icon }}</mat-icon>
                  <span>{{ i18n.t(item.labelKey) }}</span>
                </a>
              }
            </nav>
          }
        </header>

        <!-- Collapsible 13-Step End-to-End Demo Guide Strip -->
        <div class="border-b border-slate-200 bg-slate-50 px-4 sm:px-6 py-2.5 text-xs">
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div class="flex items-center gap-2 text-slate-700">
              <mat-icon class="!text-[16px] !h-4 !w-4 text-[#1D4ED8]">route</mat-icon>
              <span class="font-semibold">
                {{ i18n.locale() === 'fr' ? 'Parcours de démonstration en 13 étapes' : i18n.locale() === 'de' ? '13-Schritte-Demonstrationsablauf' : '13-Step Demonstration Workflow' }}
              </span>
              <span class="text-slate-500 hidden sm:inline">
                (EN/FR/DE · Project · Budget · Instance · Input · Batch Job · Output · Metering · Invoice · Host Failure · Reconcile · Safe Delete)
              </span>
            </div>
            <button
              type="button"
              (click)="showGuide.set(!showGuide())"
              class="cursor-pointer font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap"
            >
              {{ showGuide() ? 'Hide Guide' : 'Show Workflow Steps' }}
            </button>
          </div>
          @if (showGuide()) {
            <div class="mt-3 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 pb-1">
              @for (step of demoSteps; track step.n) {
                <a
                  [routerLink]="step.route"
                  class="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 hover:border-[#1D4ED8] transition-colors"
                >
                  <span class="font-mono text-[11px] text-[#1D4ED8]">{{ step.n }}.</span>
                  <span class="ml-1 text-[11px] text-slate-700">{{ step.label }}</span>
                </a>
              }
            </div>
          }
        </div>

        <main class="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
})
export class ConsoleShell implements OnInit {
  readonly i18n = inject(I18nService);
  readonly cp = inject(ControlPlaneService);
  readonly mobileNav = signal(false);
  readonly showGuide = signal(false);

  readonly navItems = [
    {path: '/console/overview', labelKey: 'console.nav.overview', icon: 'dashboard'},
    {path: '/console/projects', labelKey: 'console.nav.projects', icon: 'folder'},
    {path: '/console/compute', labelKey: 'console.nav.compute', icon: 'dns'},
    {path: '/console/gpus', labelKey: 'console.nav.gpus', icon: 'developer_board'},
    {path: '/console/jobs', labelKey: 'console.nav.jobs', icon: 'memory'},
    {path: '/console/storage', labelKey: 'console.nav.storage', icon: 'storage'},
    {path: '/console/networking', labelKey: 'console.nav.networking', icon: 'hub'},
    {path: '/console/billing', labelKey: 'console.nav.billing', icon: 'receipt_long'},
    {path: '/console/access', labelKey: 'console.nav.access', icon: 'verified_user'},
    {path: '/console/support', labelKey: 'console.nav.support', icon: 'support_agent'},
    {path: '/console/operations', labelKey: 'console.nav.operations', icon: 'precision_manufacturing'},
    {path: '/console/assistant', labelKey: 'console.nav.assistant', icon: 'auto_awesome'},
  ];

  readonly demoSteps = [
    {n: '01', label: 'Switch EN/FR/DE', route: '/console/overview'},
    {n: '02', label: 'Create Project', route: '/console/projects'},
    {n: '03', label: 'Budget Alert', route: '/console/projects'},
    {n: '04', label: 'Launch Instance', route: '/console/compute'},
    {n: '05', label: 'Upload Input', route: '/console/storage'},
    {n: '06', label: 'Submit Batch Job', route: '/console/jobs'},
    {n: '07', label: 'Observe States', route: '/console/jobs'},
    {n: '08', label: 'Retrieve Output', route: '/console/jobs'},
    {n: '09', label: 'Meter Usage', route: '/console/billing'},
    {n: '10', label: 'Issue Invoice', route: '/console/billing'},
    {n: '11', label: 'Host Failure', route: '/console/operations'},
    {n: '12', label: 'Reconcile State', route: '/console/operations'},
    {n: '13', label: 'Safe Delete', route: '/console/compute'},
  ];

  async ngOnInit(): Promise<void> {
    if (!this.cp.catalog()) {
      await this.cp.loadCatalog().catch(() => undefined);
    }
    await this.cp.loadOverview().catch(() => undefined);
  }

  async onProjectChange(event: Event): Promise<void> {
    const val = (event.target as HTMLSelectElement).value;
    this.cp.selectedProjectId.set(val);
    await this.cp.loadOverview();
  }

  async resetDemo(): Promise<void> {
    await this.cp.resetDemo();
  }
}
