import {ChangeDetectionStrategy, Component, inject, input} from '@angular/core';
import {I18nService} from '../core/i18n.service';
import type {LocaleCode} from '../core/models';

@Component({
  selector: 'app-language-switcher',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      class="inline-flex items-center rounded-lg border p-0.5 text-xs font-medium"
      [class]="
        variant() === 'dark'
          ? 'border-white/15 bg-[#0B1324] text-slate-300'
          : 'border-slate-200 bg-slate-100 text-slate-600'
      "
      role="group"
      aria-label="Language selector"
    >
      @for (opt of languages; track opt.code) {
        <button
          type="button"
          (click)="i18n.setLocale(opt.code)"
          class="cursor-pointer rounded-md px-2.5 py-1 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
          [class]="
            i18n.locale() === opt.code
              ? variant() === 'dark'
                ? 'bg-[#1D4ED8] text-white'
                : 'bg-white text-[#070D19] shadow-xs'
              : variant() === 'dark'
                ? 'text-slate-300 hover:text-white'
                : 'text-slate-600 hover:text-[#070D19]'
          "
          [attr.aria-pressed]="i18n.locale() === opt.code"
        >
          {{ opt.label }}
        </button>
      }
    </div>
  `,
})
export class LanguageSwitcher {
  readonly i18n = inject(I18nService);
  readonly variant = input<'light' | 'dark'>('light');

  readonly languages: {code: LocaleCode; label: string}[] = [
    {code: 'en', label: 'EN · English'},
    {code: 'fr', label: 'FR · Français'},
    {code: 'de', label: 'DE · Deutsch'},
  ];
}
