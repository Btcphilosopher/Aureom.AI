import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {I18nService} from '../core/i18n.service';

@Component({
  selector: 'app-architecture-diagram',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="rounded-xl border border-slate-200 bg-white p-6">
      <div class="mb-4 flex flex-wrap items-baseline justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <h3 class="font-display text-lg font-semibold text-[#070D19]">
            {{ i18n.t('home.diagram.title') }}
          </h3>
          <p class="mt-1 text-sm text-slate-600">
            {{ i18n.t('home.diagram.subtitle') }}
          </p>
        </div>
        <span class="font-mono text-xs text-slate-500">
          {{ i18n.locale() === 'fr' ? 'Schéma de référence' : i18n.locale() === 'de' ? 'Referenzarchitektur' : 'Control-plane boundary diagram' }}
        </span>
      </div>

      <svg
        viewBox="0 0 960 320"
        class="w-full h-auto"
        role="img"
        aria-label="Aureom Europe Control Plane and Adapter Isolation Diagram"
      >
        <defs>
          <linearGradient id="aureomLine" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#1D4ED8" />
            <stop offset="55%" stop-color="#4F46E5" />
            <stop offset="100%" stop-color="#0891B2" />
          </linearGradient>
        </defs>

        <!-- Layer 1: Portal & API -->
        <rect x="16" y="28" width="210" height="264" rx="10" fill="#F8FAFC" stroke="#CBD5E1" stroke-width="1.2" />
        <text x="32" y="56" font-family="Outfit, sans-serif" font-size="13" font-weight="600" fill="#070D19">
          1. Portal &amp; API Edge
        </text>
        <rect x="32" y="76" width="178" height="48" rx="6" fill="#FFFFFF" stroke="#E2E8F0" />
        <text x="44" y="98" font-family="IBM Plex Mono, monospace" font-size="11" fill="#1D4ED8">EN / FR / DE Console</text>
        <text x="44" y="114" font-family="Public Sans, sans-serif" font-size="11" fill="#475569">Scoped Bearer · MFA</text>

        <rect x="32" y="138" width="178" height="48" rx="6" fill="#FFFFFF" stroke="#E2E8F0" />
        <text x="44" y="160" font-family="IBM Plex Mono, monospace" font-size="11" fill="#0F172A">REST + OpenAPI 3.1</text>
        <text x="44" y="176" font-family="Public Sans, sans-serif" font-size="11" fill="#475569">Idempotency · X-Request-Id</text>

        <rect x="32" y="200" width="178" height="72" rx="6" fill="#EFF6FF" stroke="#BFDBFE" />
        <text x="44" y="222" font-family="IBM Plex Mono, monospace" font-size="11" fill="#1E40AF">Gemini 4.0 Assistant</text>
        <text x="44" y="239" font-family="Public Sans, sans-serif" font-size="10.5" fill="#1E3A8A">Deterministic tool calls</text>
        <text x="44" y="255" font-family="Public Sans, sans-serif" font-size="10.5" fill="#1E3A8A">No unapproved mutations</text>

        <!-- Connector 1 -> 2 -->
        <line x1="226" y1="160" x2="266" y2="160" stroke="url(#aureomLine)" stroke-width="2" />
        <polygon points="266,155 276,160 266,165" fill="#1D4ED8" />

        <!-- Layer 2: Transactional Control Plane -->
        <rect x="278" y="28" width="276" height="264" rx="10" fill="#070D19" />
        <text x="296" y="56" font-family="Outfit, sans-serif" font-size="13" font-weight="600" fill="#F8FAFC">
          2. Transactional Control Plane
        </text>
        <rect x="296" y="76" width="240" height="52" rx="6" fill="#111C33" stroke="#1E293B" />
        <text x="310" y="98" font-family="IBM Plex Mono, monospace" font-size="11" fill="#38BDF8">State &amp; Quota Engine</text>
        <text x="310" y="115" font-family="Public Sans, sans-serif" font-size="11" fill="#CBD5E1">Desired vs Observed Reconciliation</text>

        <rect x="296" y="142" width="240" height="52" rx="6" fill="#111C33" stroke="#1E293B" />
        <text x="310" y="164" font-family="IBM Plex Mono, monospace" font-size="11" fill="#38BDF8">Decimal EUR Ledger</text>
        <text x="310" y="181" font-family="Public Sans, sans-serif" font-size="11" fill="#CBD5E1">Idempotent metering · Price versions</text>

        <rect x="296" y="208" width="240" height="64" rx="6" fill="#111C33" stroke="#1E293B" />
        <text x="310" y="230" font-family="IBM Plex Mono, monospace" font-size="11" fill="#A5B4FC">EU Residency Policy Gate</text>
        <text x="310" y="247" font-family="Public Sans, sans-serif" font-size="10.5" fill="#CBD5E1">Compute · Storage · Replicas · Logs</text>
        <text x="310" y="261" font-family="Public Sans, sans-serif" font-size="10.5" fill="#94A3B8">Immutable Audit Events</text>

        <!-- Connector 2 -> 3 -->
        <line x1="554" y1="160" x2="594" y2="160" stroke="url(#aureomLine)" stroke-width="2" />
        <polygon points="594,155 604,160 594,165" fill="#0891B2" />

        <!-- Layer 3: Typed Adapters & Isolated Workloads -->
        <rect x="606" y="28" width="338" height="264" rx="10" fill="#F8FAFC" stroke="#CBD5E1" stroke-width="1.2" />
        <text x="624" y="56" font-family="Outfit, sans-serif" font-size="13" font-weight="600" fill="#070D19">
          3. Typed Infrastructure Adapters (Demo)
        </text>

        <rect x="624" y="74" width="302" height="44" rx="6" fill="#FFFFFF" stroke="#E2E8F0" />
        <text x="636" y="93" font-family="IBM Plex Mono, monospace" font-size="11" fill="#0F172A">ComputeAdapter · local-container-sim</text>
        <text x="636" y="109" font-family="Public Sans, sans-serif" font-size="10.5" fill="#475569">Explicit container vs KVM VM distinction</text>

        <rect x="624" y="128" width="302" height="44" rx="6" fill="#FFFFFF" stroke="#E2E8F0" />
        <text x="636" y="147" font-family="IBM Plex Mono, monospace" font-size="11" fill="#0F172A">SlurmSchedulerAdapter · GPU Profiles</text>
        <text x="636" y="163" font-family="Public Sans, sans-serif" font-size="10.5" fill="#475569">Queued ≠ Allocated ≠ Executed ≠ Output</text>

        <rect x="624" y="182" width="302" height="44" rx="6" fill="#FFFFFF" stroke="#E2E8F0" />
        <text x="636" y="201" font-family="IBM Plex Mono, monospace" font-size="11" fill="#0F172A">S3StorageAdapter · Block · Backups</text>
        <text x="636" y="217" font-family="Public Sans, sans-serif" font-size="10.5" fill="#475569">Snapshots separated from independent backups</text>

        <rect x="624" y="236" width="302" height="42" rx="6" fill="#ECFEFF" stroke="#A5F3FC" />
        <text x="636" y="254" font-family="IBM Plex Mono, monospace" font-size="11" fill="#0E7490">Read-Only Facility Telemetry</text>
        <text x="636" y="269" font-family="Public Sans, sans-serif" font-size="10.5" fill="#155E75">Isolated from cooling &amp; electrical breakers</text>
      </svg>
    </div>
  `,
})
export class ArchitectureDiagram {
  readonly i18n = inject(I18nService);
}
