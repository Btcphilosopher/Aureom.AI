import {createHash, randomUUID} from 'node:crypto';
import {existsSync, readFileSync, writeFileSync} from 'node:fs';
import Decimal from 'decimal.js';
import {
  LocalContainerSimComputeAdapter,
  LocalGpuSimulatorAdapter,
  LocalS3StorageAdapter,
  ReadOnlyFacilityTelemetryAdapter,
  SlurmAndLocalSchedulerAdapter,
} from './adapters';
import type {
  ApiKeyRecord,
  AuditEvent,
  BatchJob,
  BlockVolume,
  BudgetAlert,
  ComputeInstance,
  ContactInquiry,
  DataResidencyPolicy,
  DemoRegion,
  EmailOutboxMessage,
  FacilityHost,
  GpuAllocation,
  GpuProfile,
  InboundRule,
  IndependentBackup,
  InfrastructureIncident,
  InstanceTemplate,
  Invoice,
  InvoiceLineItem,
  LocaleCode,
  OrgMember,
  Organisation,
  PriceBook,
  Project,
  ProjectNetwork,
  ProjectQuotas,
  PublicAddressAllocation,
  SecurityGroup,
  SharedFilesystem,
  StorageBucket,
  StorageSnapshot,
  Subnet,
  SupportTicket,
  UsageLedgerEntry,
  UserRole,
} from './types';

export interface ControlPlaneState {
  organisations: Organisation[];
  regions: DemoRegion[];
  priceBooks: PriceBook[];
  instanceTemplates: InstanceTemplate[];
  hosts: FacilityHost[];
  incidents: InfrastructureIncident[];
  projects: Project[];
  instances: ComputeInstance[];
  gpuAllocations: GpuAllocation[];
  jobs: BatchJob[];
  buckets: StorageBucket[];
  volumes: BlockVolume[];
  filesystems: SharedFilesystem[];
  snapshots: StorageSnapshot[];
  backups: IndependentBackup[];
  networks: ProjectNetwork[];
  securityGroups: SecurityGroup[];
  publicAddresses: PublicAddressAllocation[];
  usageLedger: UsageLedgerEntry[];
  invoices: Invoice[];
  apiKeys: ApiKeyRecord[];
  members: OrgMember[];
  auditEvents: AuditEvent[];
  emailOutbox: EmailOutboxMessage[];
  supportTickets: SupportTicket[];
  contactInquiries: ContactInquiry[];
  idempotencyCache: Record<string, {status: number; body: unknown}>;
}

export class ControlPlaneError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
    public readonly details?: Record<string, unknown>,
  ) {
    super(message);
  }
}

function ipToInt(ip: string): number {
  const parts = ip.split('.').map((p) => Number(p));
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
    throw new ControlPlaneError(400, 'INVALID_IPV4', `Invalid IPv4 address: ${ip}`);
  }
  return ((parts[0] << 24) >>> 0) + ((parts[1] << 16) >>> 0) + ((parts[2] << 8) >>> 0) + (parts[3] >>> 0);
}

function intToIp(n: number): string {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
}

export function parseCidr(cidr: string, allowAnyPrefix = false): {start: number; end: number; prefix: number} {
  const match = /^(\d+\.\d+\.\d+\.\d+)\/(\d+)$/.exec(cidr.trim());
  if (!match) {
    throw new ControlPlaneError(400, 'INVALID_CIDR', `Invalid CIDR block: ${cidr}`);
  }
  const ipInt = ipToInt(match[1]);
  const prefix = Number(match[2]);
  if (allowAnyPrefix ? prefix < 0 || prefix > 32 : prefix < 8 || prefix > 30) {
    throw new ControlPlaneError(400, 'INVALID_CIDR_PREFIX', `CIDR prefix out of allowed range: ${cidr}`);
  }
  const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
  const start = (ipInt & mask) >>> 0;
  const size = Math.pow(2, 32 - prefix);
  const end = (start + size - 1) >>> 0;
  return {start, end, prefix};
}

export function cidrsOverlap(a: string, b: string): boolean {
  const pa = parseCidr(a);
  const pb = parseCidr(b);
  return pa.start <= pb.end && pb.start <= pa.end;
}

export function cidrContains(outer: string, inner: string): boolean {
  const po = parseCidr(outer);
  const pi = parseCidr(inner);
  return po.start <= pi.start && pi.end <= po.end;
}

export function buildSeedState(): ControlPlaneState {
  const now = '2026-11-20T09:00:00.000Z';

  const regions: DemoRegion[] = [
    {
      id: 'eu-sim-nord-1',
      code: 'eu-sim-nord-1',
      city: 'Luleå (Demo)',
      country: 'Sweden',
      isSimulated: true,
      simulationLabel: 'SIMULATED DEMONSTRATION REGION',
      gridCarbonNote: 'Simulated regional hydro-dominant grid profile (demonstration values only)',
      coolingArchitecture: 'Direct-to-chip liquid loop + Nordic free-air economisers (simulated)',
      supportedArchitectures: ['x86_64', 'aarch64'],
      status: 'operational',
    },
    {
      id: 'eu-sim-central-1',
      code: 'eu-sim-central-1',
      city: 'Frankfurt (Demo)',
      country: 'Germany',
      isSimulated: true,
      simulationLabel: 'SIMULATED DEMONSTRATION REGION',
      gridCarbonNote: 'Simulated central interconnection hub (demonstration values only)',
      coolingArchitecture: 'Closed-loop adiabatic chillers (simulated)',
      supportedArchitectures: ['x86_64'],
      status: 'operational',
    },
    {
      id: 'eu-sim-west-1',
      code: 'eu-sim-west-1',
      city: 'Grenoble (Demo)',
      country: 'France',
      isSimulated: true,
      simulationLabel: 'SIMULATED DEMONSTRATION REGION',
      gridCarbonNote: 'Simulated Alpine low-carbon grid profile (demonstration values only)',
      coolingArchitecture: 'Warm-water rack cooling + heat-reuse loop (simulated)',
      supportedArchitectures: ['x86_64', 'aarch64'],
      status: 'operational',
    },
  ];

  const priceBooks: PriceBook[] = [
    {
      version: 'v2026.11-demo',
      effectiveFrom: '2026-11-01T00:00:00.000Z',
      currency: 'EUR',
      isSimulated: true,
      rates: {
        vcpuHourEur: '0.0240',
        memoryGiBHourEur: '0.0045',
        blockStorageGBMonthEur: '0.0950',
        objectStorageGBMonthEur: '0.0210',
        sharedFsGBMonthEur: '0.1600',
        snapshotGBMonthEur: '0.0450',
        backupGBMonthEur: '0.0320',
        egressGBEur: '0.0180',
        publicIpHourEur: '0.0050',
        gpuH100HourEur: '2.8500',
        gpuL40SHourEur: '1.1500',
        gpuMi300XHourEur: '3.2000',
      },
    },
  ];

  const instanceTemplates: InstanceTemplate[] = [
    {
      id: 'eu-gp-small',
      name: 'eu-gp-small (4 vCPU · 16 GiB)',
      architecture: 'x86_64',
      cpuModel: 'EPYC-9354-Class (Simulated)',
      vcpus: 4,
      memoryGiB: 16,
      defaultDiskGB: 80,
      pricePerHourEur: '0.1680',
      adapterKind: 'local-container-sim',
      virtualizationBoundary: 'Local control-plane container simulation (not a hardware KVM hypervisor)',
    },
    {
      id: 'eu-gp-medium',
      name: 'eu-gp-medium (8 vCPU · 32 GiB)',
      architecture: 'x86_64',
      cpuModel: 'EPYC-9354-Class (Simulated)',
      vcpus: 8,
      memoryGiB: 32,
      defaultDiskGB: 160,
      pricePerHourEur: '0.3360',
      adapterKind: 'local-container-sim',
      virtualizationBoundary: 'Local control-plane container simulation (not a hardware KVM hypervisor)',
    },
    {
      id: 'eu-mem-large',
      name: 'eu-mem-large (16 vCPU · 128 GiB)',
      architecture: 'x86_64',
      cpuModel: 'EPYC-9654-Class (Simulated)',
      vcpus: 16,
      memoryGiB: 128,
      defaultDiskGB: 320,
      pricePerHourEur: '0.9600',
      adapterKind: 'local-container-sim',
      virtualizationBoundary: 'Local control-plane container simulation (not a hardware KVM hypervisor)',
    },
    {
      id: 'eu-arm-edge',
      name: 'eu-arm-edge (8 vCPU ARM64 · 32 GiB)',
      architecture: 'aarch64',
      cpuModel: 'AmpereOne-Class (Simulated)',
      vcpus: 8,
      memoryGiB: 32,
      defaultDiskGB: 120,
      pricePerHourEur: '0.2880',
      adapterKind: 'local-container-sim',
      virtualizationBoundary: 'Local control-plane container simulation (not a hardware KVM hypervisor)',
    },
  ];

  const hosts: FacilityHost[] = [
    {
      id: 'host-nord-01',
      regionId: 'eu-sim-nord-1',
      siteName: 'Luleå Demo Hall A',
      roomName: 'Room N1-A',
      rackId: 'Rack-A04',
      hostname: 'nord1-a04-node01.sim.aureom.eu',
      architecture: 'x86_64',
      totalVcpus: 128,
      usedVcpus: 16,
      totalMemoryGiB: 512,
      usedMemoryGiB: 64,
      gpuCount: 8,
      gpuModel: 'Aureom-H100-80GB-SXM (Simulated)',
      powerDrawWatts: 3420,
      facilityTotalPowerWatts: 3967,
      temperatureCelsius: 24.4,
      telemetrySource: 'sim-bmc-exporter://nord1-a04-node01 (read-only)',
      telemetryFreshnessIso: now,
      state: 'Healthy',
    },
    {
      id: 'host-nord-02',
      regionId: 'eu-sim-nord-1',
      siteName: 'Luleå Demo Hall A',
      roomName: 'Room N1-B',
      rackId: 'Rack-B02',
      hostname: 'nord1-b02-arm01.sim.aureom.eu',
      architecture: 'aarch64',
      totalVcpus: 128,
      usedVcpus: 8,
      totalMemoryGiB: 512,
      usedMemoryGiB: 32,
      gpuCount: 0,
      powerDrawWatts: 1180,
      facilityTotalPowerWatts: 1380,
      temperatureCelsius: 22.1,
      telemetrySource: 'sim-bmc-exporter://nord1-b02-arm01 (read-only)',
      telemetryFreshnessIso: now,
      state: 'Healthy',
    },
    {
      id: 'host-central-01',
      regionId: 'eu-sim-central-1',
      siteName: 'Frankfurt Demo Campus',
      roomName: 'Room C1-A',
      rackId: 'Rack-C11',
      hostname: 'fra1-c11-node01.sim.aureom.eu',
      architecture: 'x86_64',
      totalVcpus: 96,
      usedVcpus: 8,
      totalMemoryGiB: 384,
      usedMemoryGiB: 32,
      gpuCount: 4,
      gpuModel: 'Aureom-L40S-48GB-PCIe (Simulated)',
      powerDrawWatts: 2150,
      facilityTotalPowerWatts: null, // Intentionally missing facility boundary meter to verify PUE honesty
      temperatureCelsius: 25.8,
      telemetrySource: 'sim-bmc-exporter://fra1-c11-node01 (read-only)',
      telemetryFreshnessIso: now,
      state: 'Healthy',
    },
    {
      id: 'host-west-01',
      regionId: 'eu-sim-west-1',
      siteName: 'Grenoble Demo Site',
      roomName: 'Room W1-A',
      rackId: 'Rack-W03',
      hostname: 'gre1-w03-node01.sim.aureom.eu',
      architecture: 'x86_64',
      totalVcpus: 128,
      usedVcpus: 0,
      totalMemoryGiB: 512,
      usedMemoryGiB: 0,
      gpuCount: 8,
      gpuModel: 'Aureom-MI300X-192GB (Simulated)',
      powerDrawWatts: 2980,
      facilityTotalPowerWatts: 3486,
      temperatureCelsius: 23.6,
      telemetrySource: 'sim-bmc-exporter://gre1-w03-node01 (read-only)',
      telemetryFreshnessIso: now,
      state: 'Healthy',
    },
  ];

  const organisations: Organisation[] = [
    {
      id: 'org_ncrc_eu_demo',
      name: 'Nordic Climate Research Consortium (Demo)',
      slug: 'ncrc-eu-demo',
      billingEmail: 'finance@ncrc-demo.example.eu',
      vatId: 'SE559900112201 (Demo)',
      vatRatePercent: '25.00',
      taxJurisdictionNote:
        'Configurable demonstration VAT (25.00% SE baseline). Cross-border EU reverse-charge & local tax treatments require external ERP/tax integration prior to commercial billing.',
      mfaEnforced: true,
      isSimulated: true,
      createdAt: now,
    },
    {
      id: 'org_rhein_bio_demo',
      name: 'Rheinland Genomics Lab (Demo)',
      slug: 'rhein-bio-demo',
      billingEmail: 'billing@rheinbio-demo.example.eu',
      vatId: 'DE310099881 (Demo)',
      vatRatePercent: '19.00',
      taxJurisdictionNote: 'Isolated secondary demo organisation for multi-tenant isolation checks.',
      mfaEnforced: true,
      isSimulated: true,
      createdAt: now,
    },
  ];

  const projects: Project[] = [
    {
      id: 'proj_baltic_hydro_sim',
      organisationId: 'org_ncrc_eu_demo',
      name: 'Baltic Hydrodynamic Baseline',
      slug: 'baltic-hydro-sim',
      description: 'Simulated oceanographic fluid mesh & batch inference workspace.',
      primaryRegionId: 'eu-sim-nord-1',
      quotas: {
        maxVcpus: 64,
        maxMemoryGiB: 256,
        maxGpus: 4,
        maxStorageGB: 2000,
        maxInstances: 10,
        maxConcurrentJobs: 6,
      },
      residency: {
        computeLocation: 'eu-sim-nord-1 (Luleå Demo)',
        primaryStorageLocation: 'eu-sim-nord-1 (Luleå Demo)',
        replicaLocation: 'eu-sim-west-1 (Grenoble Demo — Simulated)',
        backupLocation: 'eu-sim-central-1 (Frankfurt Demo — Simulated)',
        logLocation: 'eu-sim-nord-1 (Control Plane Local Store)',
        supportAccessPolicy: 'eu-staff-only-explicit-approval',
        externalSubprocessors: ['None configured for workload data; optional Gemini 4.0 AI assistant receives redacted metadata only upon user action'],
        sovereigntyNotice:
          'EU region labels reflect configured placement rules in this local demonstration. Full legal sovereignty requires audited hardware custody, contractual DPAs, and independent accreditation.',
      },
      budgetAlert: {
        id: 'ba_seed_1',
        projectId: 'proj_baltic_hydro_sim',
        monthlyThresholdEur: '250.00',
        notifyEmail: 'finance@ncrc-demo.example.eu',
        preferredLocale: 'en',
        triggered: false,
      },
      createdAt: now,
    },
    {
      id: 'proj_rhein_private_sim',
      organisationId: 'org_rhein_bio_demo',
      name: 'Protein Folding Cohort (Isolated Org)',
      slug: 'protein-cohort-demo',
      description: 'Belongs to org_rhein_bio_demo; must never be accessible to org_ncrc_eu_demo.',
      primaryRegionId: 'eu-sim-central-1',
      quotas: {
        maxVcpus: 32,
        maxMemoryGiB: 128,
        maxGpus: 2,
        maxStorageGB: 500,
        maxInstances: 4,
        maxConcurrentJobs: 2,
      },
      residency: {
        computeLocation: 'eu-sim-central-1',
        primaryStorageLocation: 'eu-sim-central-1',
        replicaLocation: 'None',
        backupLocation: 'eu-sim-west-1',
        logLocation: 'eu-sim-central-1',
        supportAccessPolicy: 'project-admin-token-required',
        externalSubprocessors: ['None'],
        sovereigntyNotice: 'Simulated secondary tenant isolation fixture.',
      },
      createdAt: now,
    },
  ];

  const networks: ProjectNetwork[] = [
    {
      id: 'net_baltic_priv',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-vpc-nord',
      regionId: 'eu-sim-nord-1',
      cidr: '10.42.0.0/16',
      privateConnectivity: 'WireGuard / BGP Inter-Region Tunnel (Simulated)',
      publicIpPoolEnabled: true,
      subnets: [
        {
          id: 'sub_baltic_compute',
          networkId: 'net_baltic_priv',
          name: 'compute-subnet-a',
          cidr: '10.42.10.0/24',
          gatewayIp: '10.42.10.1',
          availableIps: 251,
        },
        {
          id: 'sub_baltic_hpc',
          networkId: 'net_baltic_priv',
          name: 'hpc-fabric-b',
          cidr: '10.42.20.0/24',
          gatewayIp: '10.42.20.1',
          availableIps: 253,
        },
      ],
      createdAt: now,
    },
  ];

  const securityGroups: SecurityGroup[] = [
    {
      id: 'sg_baltic_restricted',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'ssh-bastion-only',
      defaultInboundPolicy: 'deny-all',
      inboundRules: [
        {
          id: 'rule_ssh_corp',
          protocol: 'tcp',
          portRange: '22',
          sourceCidr: '192.0.2.0/24',
          description: 'Bastion SSH only (TEST-NET-1 demo CIDR)',
        },
      ],
      createdAt: now,
    },
  ];

  const instances: ComputeInstance[] = [
    {
      id: 'inst_baltic_prep_01',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-ingestor-01',
      templateId: 'eu-gp-medium',
      architecture: 'x86_64',
      vcpus: 8,
      memoryGiB: 32,
      diskGB: 160,
      image: 'debian-12-bookworm-eu-minimal',
      imageProvenanceDigest: 'sha256:8f4e2c1b77d9a04312be99f44d2a117c',
      regionId: 'eu-sim-nord-1',
      networkId: 'net_baltic_priv',
      subnetId: 'sub_baltic_compute',
      securityGroupId: 'sg_baltic_restricted',
      sshPublicKeyFingerprint: 'SHA256:k9Lm2pQr8XzV4nW1yC7bJ3dF6hT0aS5eU',
      privateIp: '10.42.10.14',
      hostId: 'host-nord-01',
      adapterKind: 'local-container-sim',
      isolationBoundary:
        'Simulated local control-plane container record (not a hardware-isolated KVM virtual machine)',
      desiredState: 'Running',
      observedState: 'Running',
      priceBasisVersion: 'v2026.11-demo',
      hourlyRateEur: '0.3360',
      lastObservedAt: now,
      createdAt: now,
    },
  ];

  const gpuAllocations: GpuAllocation[] = [
    {
      id: 'gpu_alloc_seed_1',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      regionId: 'eu-sim-nord-1',
      hostId: 'host-nord-01',
      gpuProfileId: 'gpu-h100-sxm-sim',
      deviceCount: 1,
      partitionProfile: 'full-80gb',
      billingBasis: 'on-demand',
      hourlyRateEur: '2.8500',
      priceBasisVersion: 'v2026.11-demo',
      status: 'Allocated',
      runtimeCompatibility: 'CUDA 12.4 / PyTorch 2.5 compatible',
      isolationNotice:
        'Assigning a synthetic device ID does not enforce hardware multi-tenant isolation; dedicated host allocation is required for strict tenant separation.',
      createdAt: now,
    },
  ];

  const buckets: StorageBucket[] = [
    {
      id: 'bkt_baltic_datasets',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-datasets-nord',
      regionId: 'eu-sim-nord-1',
      accessControl: 'private-project',
      durabilityNotice:
        'Local demonstration S3-compatible store (single-process demo disk; non-redundant outside this demo)',
      replicationPolicy: 'Single-region demo store (replica metadata: eu-sim-west-1)',
      retentionDays: 90,
      usedBytes: 4096,
      quotaGB: 500,
      pricePerGBMonthEur: '0.0210',
      objects: [
        {
          key: 'inputs/baltic_grid_sample.csv',
          sizeBytes: 248,
          contentType: 'text/csv',
          sha256: createHash('sha256')
            .update('station_id,lat,lon,temp_c,salinity_psu\nSE-01,65.58,22.15,4.2,3.1\nSE-02,63.82,20.26,5.1,4.4\n')
            .digest('hex'),
          contentPreview: 'station_id,lat,lon,temp_c,salinity_psu\nSE-01,65.58,22.15,4.2,3.1\nSE-02,63.82,20.26,5.1,4.4\n',
          uploadedAt: now,
        },
      ],
      createdAt: now,
    },
  ];

  const volumes: BlockVolume[] = [
    {
      id: 'vol_baltic_scratch',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-scratch-nvme',
      regionId: 'eu-sim-nord-1',
      sizeGB: 200,
      attachedInstanceId: 'inst_baltic_prep_01',
      durabilityNotice:
        'Simulated block volume record (attached logically to instance records; no NVMe-oF backend active)',
      pricePerGBMonthEur: '0.0950',
      status: 'Attached',
      createdAt: now,
    },
  ];

  const filesystems: SharedFilesystem[] = [
    {
      id: 'fs_baltic_posix',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-hpc-shared',
      regionId: 'eu-sim-nord-1',
      protocol: 'NFSv4.2',
      capacityGB: 500,
      usedGB: 42,
      mountTarget: '10.42.20.250:/exports/baltic-hpc-shared',
      durabilityNotice: 'Simulated POSIX shared filesystem metadata (NFSv4.2 semantics modeled)',
      pricePerGBMonthEur: '0.1600',
      createdAt: now,
    },
  ];

  const snapshots: StorageSnapshot[] = [
    {
      id: 'snap_baltic_001',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      sourceVolumeId: 'vol_baltic_scratch',
      name: 'pre-run-checkpoint',
      sizeGB: 200,
      isIndependentBackup: false,
      note: 'Point-in-time volume reference only — depends on primary volume availability; not an independent backup.',
      createdAt: now,
    },
  ];

  const backups: IndependentBackup[] = [
    {
      id: 'bak_baltic_001',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      sourceResourceId: 'vol_baltic_scratch',
      sourceKind: 'volume',
      targetRegionId: 'eu-sim-central-1',
      retentionDays: 30,
      sizeGB: 200,
      verificationStatus: 'Verified-Checksum',
      createdAt: now,
    },
  ];

  const jobs: BatchJob[] = [
    {
      id: 'job_baltic_baseline_01',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      name: 'baltic-thermocline-pass',
      regionId: 'eu-sim-nord-1',
      schedulerBackend: 'slurm-adapter-sim',
      workloadImage: 'registry.sim.aureom.eu/ocean/nemo-solver:4.2.1-signed',
      imageDigestVerified: true,
      command: 'python3 solve_mesh.py --input /data/baltic_grid_sample.csv --steps 120',
      cpuCores: 8,
      gpuCount: 1,
      memoryGiB: 32,
      runtimeLimitSeconds: 1800,
      inputUri: 's3://baltic-datasets-nord/inputs/baltic_grid_sample.csv',
      outputUri: 's3://baltic-datasets-nord/outputs/job_baltic_baseline_01',
      environmentConfig: {OMP_NUM_THREADS: '8', AUREOM_RESIDENCY_CHECK: 'eu-sim-nord-1'},
      queueClass: 'gpu-priority',
      priority: 100,
      state: 'Completed',
      allocationNodeId: 'host-nord-01',
      allocatedAt: now,
      startedAt: now,
      finishedAt: now,
      outputAvailable: true,
      outputArtifactName: 'baltic-thermocline-pass_result.json',
      logs: [
        `[${now}] Scheduler accepted job into queue "gpu-priority" (priority 100).`,
        `[${now}] Allocated node nord1-a04-node01.sim.aureom.eu (8 cores, 1 GPU).`,
        `[${now}] Staging input from s3://baltic-datasets-nord/inputs/baltic_grid_sample.csv...`,
        `[${now}] Executing "python3 solve_mesh.py --input /data/baltic_grid_sample.csv --steps 120".`,
        `[${now}] Workload finished with exit code 0.`,
        `[${now}] Materialised output artifact "baltic-thermocline-pass_result.json".`,
      ],
      exitCode: 0,
      hourlyRateEur: '3.1860',
      priceBasisVersion: 'v2026.11-demo',
      createdAt: now,
    },
  ];

  const usageLedger: UsageLedgerEntry[] = [
    {
      id: 'usg_seed_compute_1',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      resourceId: 'inst_baltic_prep_01',
      resourceKind: 'compute',
      resourceName: 'baltic-ingestor-01 (eu-gp-medium)',
      meteringPeriodKey: 'inst_baltic_prep_01:2026-11-20T08:00:00Z',
      periodStart: '2026-11-20T08:00:00.000Z',
      periodEnd: '2026-11-20T09:00:00.000Z',
      quantity: '1.0000',
      unit: 'instance-hour',
      priceVersion: 'v2026.11-demo',
      unitRateEur: '0.3360',
      amountEur: '0.3360',
      currency: 'EUR',
      finalisationState: 'EstimatedCurrent',
      createdAt: now,
    },
    {
      id: 'usg_seed_gpu_1',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      resourceId: 'gpu_alloc_seed_1',
      resourceKind: 'gpu',
      resourceName: '1x Aureom-H100-80GB-SXM (Simulated)',
      meteringPeriodKey: 'gpu_alloc_seed_1:2026-11-20T08:00:00Z',
      periodStart: '2026-11-20T08:00:00.000Z',
      periodEnd: '2026-11-20T09:00:00.000Z',
      quantity: '1.0000',
      unit: 'gpu-hour',
      priceVersion: 'v2026.11-demo',
      unitRateEur: '2.8500',
      amountEur: '2.8500',
      currency: 'EUR',
      finalisationState: 'EstimatedCurrent',
      createdAt: now,
    },
  ];

  const apiKeys: ApiKeyRecord[] = [
    {
      id: 'key_demo_readonly',
      organisationId: 'org_ncrc_eu_demo',
      name: 'ci-telemetry-reader-demo',
      prefix: 'ak_demo_7f29',
      scopes: ['projects:read', 'instances:read', 'jobs:read', 'usage:read'],
      expiresAt: '2027-05-01T00:00:00.000Z',
      revoked: false,
      createdBy: 'astrid.lindqvist@ncrc-demo.example.eu',
      createdAt: now,
    },
  ];

  const members: OrgMember[] = [
    {
      id: 'usr_astrid',
      organisationId: 'org_ncrc_eu_demo',
      name: 'Astrid Lindqvist',
      email: 'astrid.lindqvist@ncrc-demo.example.eu',
      role: 'org_admin',
      mfaEnabled: true,
      lastActiveAt: now,
    },
    {
      id: 'usr_henrik',
      organisationId: 'org_ncrc_eu_demo',
      name: 'Henrik Weber',
      email: 'henrik.weber@ncrc-demo.example.eu',
      role: 'project_engineer',
      mfaEnabled: true,
      lastActiveAt: now,
    },
    {
      id: 'usr_claire',
      organisationId: 'org_ncrc_eu_demo',
      name: 'Claire Moreau',
      email: 'claire.moreau@ncrc-demo.example.eu',
      role: 'infra_operator',
      mfaEnabled: true,
      lastActiveAt: now,
    },
  ];

  const auditEvents: AuditEvent[] = [
    {
      id: 'aud_seed_1',
      organisationId: 'org_ncrc_eu_demo',
      projectId: 'proj_baltic_hydro_sim',
      actor: 'system-bootstrap',
      action: 'project.initialized',
      resourceType: 'Project',
      resourceId: 'proj_baltic_hydro_sim',
      requestId: 'req_bootstrap_001',
      outcome: 'success',
      summary: 'Initialised simulated demonstration workspace in eu-sim-nord-1.',
      timestamp: now,
    },
  ];

  return {
    organisations,
    regions,
    priceBooks,
    instanceTemplates,
    hosts,
    incidents: [],
    projects,
    instances,
    gpuAllocations,
    jobs,
    buckets,
    volumes,
    filesystems,
    snapshots,
    backups,
    networks,
    securityGroups,
    publicAddresses: [],
    usageLedger,
    invoices: [],
    apiKeys,
    members,
    auditEvents,
    emailOutbox: [],
    supportTickets: [],
    contactInquiries: [],
    idempotencyCache: {},
  };
}

export class ControlPlaneStore {
  private state: ControlPlaneState;
  private readonly persistPath: string | null;

  readonly computeAdapter = new LocalContainerSimComputeAdapter();
  readonly gpuAdapter = new LocalGpuSimulatorAdapter();
  readonly schedulerAdapter = new SlurmAndLocalSchedulerAdapter();
  readonly storageAdapter = new LocalS3StorageAdapter();
  readonly telemetryAdapter = new ReadOnlyFacilityTelemetryAdapter();

  constructor(options?: {persistPath?: string | null}) {
    this.persistPath = options?.persistPath === undefined ? '/tmp/aureom-demo-state.json' : options.persistPath;
    if (this.persistPath && existsSync(this.persistPath)) {
      try {
        const raw = readFileSync(this.persistPath, 'utf8');
        this.state = JSON.parse(raw) as ControlPlaneState;
        this.reconcileAfterRestart('startup-auto-reconcile', 'org_ncrc_eu_demo');
      } catch {
        this.state = buildSeedState();
        this.persist();
      }
    } else {
      this.state = buildSeedState();
      this.persist();
    }
  }

  private persist(): void {
    if (!this.persistPath) return;
    try {
      writeFileSync(this.persistPath, JSON.stringify(this.state, null, 2), 'utf8');
    } catch {
      // Non-fatal in ephemeral sandboxes
    }
  }

  resetDemoState(): ControlPlaneState {
    this.state = buildSeedState();
    this.persist();
    return this.state;
  }

  getCatalog(): {
    regions: DemoRegion[];
    templates: InstanceTemplate[];
    gpuProfiles: GpuProfile[];
    priceBook: PriceBook;
  } {
    return {
      regions: this.state.regions,
      templates: this.state.instanceTemplates,
      gpuProfiles: this.gpuAdapter.listProfiles(),
      priceBook: this.state.priceBooks[0],
    };
  }

  getPublicStatus(): {
    regions: DemoRegion[];
    activeIncidents: InfrastructureIncident[];
    healthyHosts: number;
    totalHosts: number;
    queuedJobs: number;
    runningJobs: number;
    isSimulated: true;
  } {
    return {
      regions: this.state.regions,
      activeIncidents: this.state.incidents.filter((i) => i.status === 'Active'),
      healthyHosts: this.state.hosts.filter((h) => h.state === 'Healthy').length,
      totalHosts: this.state.hosts.length,
      queuedJobs: this.state.jobs.filter((j) => j.state === 'Queued' || j.state === 'Submitted').length,
      runningJobs: this.state.jobs.filter((j) => j.state === 'Running' || j.state === 'Allocated' || j.state === 'Starting').length,
      isSimulated: true,
    };
  }

  listOrganisations(): Organisation[] {
    return this.state.organisations;
  }

  listMembers(orgId: string): OrgMember[] {
    return this.state.members.filter((m) => m.organisationId === orgId);
  }

  listApiKeys(orgId: string): ApiKeyRecord[] {
    return this.state.apiKeys.filter((k) => k.organisationId === orgId);
  }

  createApiKey(
    orgId: string,
    actor: string,
    requestId: string,
    input: {name: string; scopes: string[]; expiresInDays: number},
  ): {record: ApiKeyRecord; rawSecretOnce: string} {
    if (!input.name.trim()) {
      throw new ControlPlaneError(400, 'INVALID_KEY_NAME', 'API key name is required.');
    }
    const expiresAt = new Date(Date.now() + Math.max(1, input.expiresInDays) * 86400_000).toISOString();
    const tokenSuffix = randomUUID().replace(/-/g, '').slice(0, 20);
    const prefix = `ak_demo_${tokenSuffix.slice(0, 4)}`;
    const record: ApiKeyRecord = {
      id: `key_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      name: input.name.trim(),
      prefix,
      scopes: input.scopes.length > 0 ? input.scopes : ['projects:read'],
      expiresAt,
      revoked: false,
      createdBy: actor,
      createdAt: new Date().toISOString(),
    };
    this.state.apiKeys.unshift(record);
    this.recordAudit(orgId, undefined, actor, 'api_key.created', 'ApiKey', record.id, requestId, 'success', `Created scoped API key ${record.name}`);
    this.persist();
    return {record, rawSecretOnce: `${prefix}_${tokenSuffix}`};
  }

  revokeApiKey(orgId: string, keyId: string, actor: string, requestId: string): ApiKeyRecord {
    const key = this.state.apiKeys.find((k) => k.id === keyId && k.organisationId === orgId);
    if (!key) {
      throw new ControlPlaneError(404, 'API_KEY_NOT_FOUND', 'API key not found in this organisation.');
    }
    key.revoked = true;
    this.recordAudit(orgId, undefined, actor, 'api_key.revoked', 'ApiKey', key.id, requestId, 'success', `Revoked API key ${key.name}`);
    this.persist();
    return key;
  }

  listProjects(orgId: string): Project[] {
    return this.state.projects.filter((p) => p.organisationId === orgId);
  }

  requireProject(orgId: string, projectId: string): Project {
    const project = this.state.projects.find((p) => p.id === projectId);
    if (!project) {
      throw new ControlPlaneError(404, 'PROJECT_NOT_FOUND', `Project ${projectId} does not exist.`);
    }
    if (project.organisationId !== orgId) {
      throw new ControlPlaneError(
        403,
        'ORGANISATION_ISOLATION_VIOLATION',
        `Project ${projectId} does not belong to organisation ${orgId}.`,
      );
    }
    return project;
  }

  createProject(
    orgId: string,
    actor: string,
    requestId: string,
    input: {
      name: string;
      description?: string;
      primaryRegionId: string;
      residency?: Partial<DataResidencyPolicy>;
      quotas?: Partial<ProjectQuotas>;
    },
  ): Project {
    if (!input.name || input.name.trim().length < 2) {
      throw new ControlPlaneError(400, 'INVALID_PROJECT_NAME', 'Project name must be at least 2 characters.');
    }
    const region = this.state.regions.find((r) => r.id === input.primaryRegionId);
    if (!region) {
      throw new ControlPlaneError(400, 'INVALID_REGION', `Unknown demonstration region: ${input.primaryRegionId}`);
    }
    const id = `proj_${randomUUID().slice(0, 8)}`;
    const slug = input.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 32);

    const project: Project = {
      id,
      organisationId: orgId,
      name: input.name.trim(),
      slug: slug || id,
      description: input.description?.trim() || 'European cloud & batch computing project (simulated)',
      primaryRegionId: region.id,
      quotas: {
        maxVcpus: input.quotas?.maxVcpus ?? 32,
        maxMemoryGiB: input.quotas?.maxMemoryGiB ?? 128,
        maxGpus: input.quotas?.maxGpus ?? 4,
        maxStorageGB: input.quotas?.maxStorageGB ?? 1000,
        maxInstances: input.quotas?.maxInstances ?? 8,
        maxConcurrentJobs: input.quotas?.maxConcurrentJobs ?? 4,
      },
      residency: {
        computeLocation: input.residency?.computeLocation ?? `${region.id} (${region.city})`,
        primaryStorageLocation: input.residency?.primaryStorageLocation ?? `${region.id} (${region.city})`,
        replicaLocation: input.residency?.replicaLocation ?? 'None',
        backupLocation: input.residency?.backupLocation ?? 'eu-sim-central-1 (Frankfurt Demo)',
        logLocation: input.residency?.logLocation ?? `${region.id} (Control Plane Store)`,
        supportAccessPolicy: input.residency?.supportAccessPolicy ?? 'eu-staff-only-explicit-approval',
        externalSubprocessors: input.residency?.externalSubprocessors ?? ['None configured for workload data'],
        sovereigntyNotice:
          'EU location settings define placement rules in this local demo. They do not by themselves establish certified legal sovereignty.',
      },
      createdAt: new Date().toISOString(),
    };

    // Provision default isolated VPC network & default-deny security group for the project
    const netId = `net_${randomUUID().slice(0, 8)}`;
    const subnetId = `sub_${randomUUID().slice(0, 8)}`;
    const sgId = `sg_${randomUUID().slice(0, 8)}`;

    this.state.projects.push(project);
    this.state.networks.push({
      id: netId,
      organisationId: orgId,
      projectId: project.id,
      name: `${project.slug}-vpc`,
      regionId: region.id,
      cidr: '10.50.0.0/16',
      privateConnectivity: 'Isolated project network (simulated)',
      publicIpPoolEnabled: true,
      subnets: [
        {
          id: subnetId,
          networkId: netId,
          name: 'default-compute',
          cidr: '10.50.1.0/24',
          gatewayIp: '10.50.1.1',
          availableIps: 253,
        },
      ],
      createdAt: project.createdAt,
    });
    this.state.securityGroups.push({
      id: sgId,
      organisationId: orgId,
      projectId: project.id,
      name: 'default-deny-inbound',
      defaultInboundPolicy: 'deny-all',
      inboundRules: [],
      createdAt: project.createdAt,
    });

    this.recordAudit(orgId, project.id, actor, 'project.created', 'Project', project.id, requestId, 'success', `Created project ${project.name} in ${region.id}`);
    this.persist();
    return project;
  }

  setBudgetAlert(
    orgId: string,
    projectId: string,
    actor: string,
    requestId: string,
    input: {monthlyThresholdEur: string; notifyEmail: string; preferredLocale: LocaleCode},
  ): BudgetAlert {
    const project = this.requireProject(orgId, projectId);
    const threshold = new Decimal(input.monthlyThresholdEur || '0');
    if (threshold.lte(0)) {
      throw new ControlPlaneError(400, 'INVALID_BUDGET_THRESHOLD', 'Monthly budget threshold must be greater than 0.00 EUR.');
    }
    const alert: BudgetAlert = {
      id: project.budgetAlert?.id ?? `ba_${randomUUID().slice(0, 8)}`,
      projectId: project.id,
      monthlyThresholdEur: threshold.toFixed(2),
      notifyEmail: input.notifyEmail.trim(),
      preferredLocale: input.preferredLocale,
      triggered: false,
    };
    project.budgetAlert = alert;
    this.evaluateBudgetAlert(project);
    this.recordAudit(orgId, project.id, actor, 'budget_alert.updated', 'BudgetAlert', alert.id, requestId, 'success', `Configured budget alert at ${alert.monthlyThresholdEur} EUR`);
    this.persist();
    return alert;
  }

  private evaluateBudgetAlert(project: Project): void {
    const alert = project.budgetAlert;
    if (!alert) return;
    const total = this.getProjectEstimatedCharges(project.organisationId, project.id);
    if (new Decimal(total).gte(new Decimal(alert.monthlyThresholdEur)) && !alert.triggered) {
      alert.triggered = true;
      alert.lastTriggeredAt = new Date().toISOString();
      this.enqueueLocalizedEmail(
        project.organisationId,
        alert.notifyEmail,
        alert.preferredLocale,
        'budget_alert',
        {
          projectName: project.name,
          threshold: alert.monthlyThresholdEur,
          current: total,
        },
      );
    }
  }

  private enqueueLocalizedEmail(
    orgId: string,
    to: string,
    locale: LocaleCode,
    category: EmailOutboxMessage['category'],
    vars: Record<string, string>,
  ): void {
    let subject = '';
    let body = '';

    if (category === 'budget_alert') {
      if (locale === 'fr') {
        subject = `[AUREOM EUROPE] Alerte budgétaire déclenchée — ${vars['projectName']}`;
        body = `Notification simulée : les charges estimées pour le projet « ${vars['projectName']} » ont atteint ${vars['current']} EUR (seuil configuré : ${vars['threshold']} EUR).`;
      } else if (locale === 'de') {
        subject = `[AUREOM EUROPE] Budgetwarnung ausgelöst — ${vars['projectName']}`;
        body = `Simulierte Benachrichtigung: Die geschätzten Kosten für das Projekt „${vars['projectName']}“ haben ${vars['current']} EUR erreicht (Schwellenwert: ${vars['threshold']} EUR).`;
      } else {
        subject = `[AUREOM EUROPE] Budget alert triggered — ${vars['projectName']}`;
        body = `Simulated notification: estimated charges for project "${vars['projectName']}" reached ${vars['current']} EUR (configured threshold: ${vars['threshold']} EUR).`;
      }
    } else if (category === 'invoice_issued') {
      if (locale === 'fr') {
        subject = `[AUREOM EUROPE] Facture de démonstration émise — ${vars['invoiceNumber']}`;
        body = `Une facture de démonstration (${vars['invoiceNumber']}) d'un montant total de ${vars['total']} EUR TTC a été émise. Document simulé nécessitant une validation fiscale professionnelle avant usage réel.`;
      } else if (locale === 'de') {
        subject = `[AUREOM EUROPE] Demonstrationsrechnung erstellt — ${vars['invoiceNumber']}`;
        body = `Eine Demonstrationsrechnung (${vars['invoiceNumber']}) über insgesamt ${vars['total']} EUR wurde erstellt. Simulierter Beleg; vor produktivem Einsatz steuerrechtlich zu prüfen.`;
      } else {
        subject = `[AUREOM EUROPE] Demonstration invoice issued — ${vars['invoiceNumber']}`;
        body = `A demonstration invoice (${vars['invoiceNumber']}) totaling ${vars['total']} EUR has been issued. Simulated billing document; requires professional tax review prior to commercial use.`;
      }
    } else if (category === 'incident_notice') {
      if (locale === 'fr') {
        subject = `[AUREOM EUROPE] Avis d'incident d'infrastructure — ${vars['title']}`;
        body = `Un incident simulé a été détecté sur ${vars['host']}. Une réconciliation du plan de contrôle est requise.`;
      } else if (locale === 'de') {
        subject = `[AUREOM EUROPE] Infrastruktur-Vorfallmeldung — ${vars['title']}`;
        body = `Auf ${vars['host']} wurde ein simulierter Vorfall erkannt. Ein Abgleich in der Steuerungsebene ist erforderlich.`;
      } else {
        subject = `[AUREOM EUROPE] Infrastructure incident notice — ${vars['title']}`;
        body = `A simulated host failure occurred on ${vars['host']}. Control-plane reconciliation is required.`;
      }
    } else {
      subject = `[AUREOM EUROPE] Support update — ${vars['subject'] ?? ''}`;
      body = vars['body'] ?? 'Support ticket acknowledged in demonstration environment.';
    }

    this.state.emailOutbox.unshift({
      id: `eml_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      to,
      locale,
      category,
      subject,
      body,
      createdAt: new Date().toISOString(),
    });
  }

  getQuotaUsage(orgId: string, projectId: string): {
    quotas: ProjectQuotas;
    used: {
      vcpus: number;
      memoryGiB: number;
      gpus: number;
      storageGB: number;
      instances: number;
      concurrentJobs: number;
    };
  } {
    const project = this.requireProject(orgId, projectId);
    const activeInstances = this.state.instances.filter(
      (i) => i.projectId === projectId && i.observedState !== 'Deleted' && i.observedState !== 'Failed',
    );
    const activeGpus = this.state.gpuAllocations.filter(
      (g) => g.projectId === projectId && g.status === 'Allocated',
    );
    const activeJobs = this.state.jobs.filter(
      (j) =>
        j.projectId === projectId &&
        ['Submitted', 'Queued', 'Allocated', 'Starting', 'Running'].includes(j.state),
    );
    const volumesGB = this.state.volumes
      .filter((v) => v.projectId === projectId && v.status !== 'Deleting')
      .reduce((acc, v) => acc + v.sizeGB, 0);
    const fsGB = this.state.filesystems
      .filter((f) => f.projectId === projectId)
      .reduce((acc, f) => acc + f.capacityGB, 0);
    const bucketGB = this.state.buckets
      .filter((b) => b.projectId === projectId)
      .reduce((acc, b) => acc + Math.ceil(b.usedBytes / (1024 * 1024 * 1024)), 0);

    return {
      quotas: project.quotas,
      used: {
        vcpus: activeInstances.reduce((acc, i) => acc + i.vcpus, 0),
        memoryGiB: activeInstances.reduce((acc, i) => acc + i.memoryGiB, 0),
        gpus: activeGpus.reduce((acc, g) => acc + g.deviceCount, 0),
        storageGB: volumesGB + fsGB + bucketGB,
        instances: activeInstances.length,
        concurrentJobs: activeJobs.length,
      },
    };
  }

  listInstances(orgId: string, projectId?: string): ComputeInstance[] {
    return this.state.instances.filter(
      (i) => i.organisationId === orgId && (!projectId || i.projectId === projectId),
    );
  }

  createInstance(
    orgId: string,
    actor: string,
    requestId: string,
    input: {
      projectId: string;
      name: string;
      templateId: string;
      regionId: string;
      image: string;
      sshPublicKey: string;
      networkId?: string;
      subnetId?: string;
      securityGroupId?: string;
    },
  ): ComputeInstance {
    const project = this.requireProject(orgId, input.projectId);
    const template = this.state.instanceTemplates.find((t) => t.id === input.templateId);
    if (!template) {
      throw new ControlPlaneError(400, 'INVALID_TEMPLATE', `Unknown instance template: ${input.templateId}`);
    }
    const region = this.state.regions.find((r) => r.id === input.regionId);
    if (!region) {
      throw new ControlPlaneError(400, 'INVALID_REGION', `Unknown region: ${input.regionId}`);
    }
    if (!region.supportedArchitectures.includes(template.architecture)) {
      throw new ControlPlaneError(
        400,
        'UNSUPPORTED_ARCHITECTURE',
        `Architecture ${template.architecture} is not supported in ${region.id}.`,
      );
    }
    if (!input.sshPublicKey || !input.sshPublicKey.trim().startsWith('ssh-')) {
      throw new ControlPlaneError(
        400,
        'INVALID_SSH_KEY',
        'A valid SSH public key (e.g. starting with ssh-ed25519 or ssh-rsa) is required; password root access is disabled.',
      );
    }

    const quotaUsage = this.getQuotaUsage(orgId, project.id);
    if (quotaUsage.used.instances + 1 > quotaUsage.quotas.maxInstances) {
      throw new ControlPlaneError(409, 'QUOTA_EXCEEDED', 'Instance quota exceeded for this project.');
    }
    if (quotaUsage.used.vcpus + template.vcpus > quotaUsage.quotas.maxVcpus) {
      throw new ControlPlaneError(409, 'QUOTA_EXCEEDED', 'vCPU quota exceeded for this project.');
    }
    if (quotaUsage.used.memoryGiB + template.memoryGiB > quotaUsage.quotas.maxMemoryGiB) {
      throw new ControlPlaneError(409, 'QUOTA_EXCEEDED', 'Memory quota exceeded for this project.');
    }

    const projectNetwork =
      this.state.networks.find((n) => n.projectId === project.id && n.id === input.networkId) ??
      this.state.networks.find((n) => n.projectId === project.id);
    if (!projectNetwork) {
      throw new ControlPlaneError(400, 'NETWORK_REQUIRED', 'No project network configured.');
    }
    const subnet =
      projectNetwork.subnets.find((s) => s.id === input.subnetId) ?? projectNetwork.subnets[0];
    const sg =
      this.state.securityGroups.find((s) => s.projectId === project.id && s.id === input.securityGroupId) ??
      this.state.securityGroups.find((s) => s.projectId === project.id);
    if (!subnet || !sg) {
      throw new ControlPlaneError(400, 'SUBNET_OR_SG_REQUIRED', 'Subnet and security group are required.');
    }

    const parsedSub = parseCidr(subnet.cidr);
    const hostOffset = (this.state.instances.length % 200) + 10;
    const privateIp = intToIp(parsedSub.start + hostOffset);
    const keyFingerprint = `SHA256:${createHash('sha256').update(input.sshPublicKey.trim()).digest('base64').slice(0, 32)}`;
    const imageDigest = `sha256:${createHash('sha256').update(input.image).digest('hex').slice(0, 32)}`;

    const now = new Date().toISOString();
    const draftInstance: ComputeInstance = {
      id: `inst_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      name: input.name.trim(),
      templateId: template.id,
      architecture: template.architecture,
      vcpus: template.vcpus,
      memoryGiB: template.memoryGiB,
      diskGB: template.defaultDiskGB,
      image: input.image.trim(),
      imageProvenanceDigest: imageDigest,
      regionId: region.id,
      networkId: projectNetwork.id,
      subnetId: subnet.id,
      securityGroupId: sg.id,
      sshPublicKeyFingerprint: keyFingerprint,
      privateIp,
      hostId: 'pending',
      adapterKind: 'local-container-sim',
      isolationBoundary: template.virtualizationBoundary,
      desiredState: 'Running',
      observedState: 'Provisioning',
      priceBasisVersion: this.state.priceBooks[0].version,
      hourlyRateEur: template.pricePerHourEur,
      reconciliationNote: 'API accepted request; awaiting adapter confirmation.',
      lastObservedAt: now,
      createdAt: now,
    };

    const provisionResult = this.computeAdapter.provision(
      draftInstance,
      template,
      this.state.hosts,
    );
    draftInstance.observedState = provisionResult.observedState;
    draftInstance.hostId = provisionResult.hostId;
    draftInstance.reconciliationNote = provisionResult.note;

    if (provisionResult.observedState === 'Running') {
      const host = this.state.hosts.find((h) => h.id === provisionResult.hostId);
      if (host) {
        host.usedVcpus += draftInstance.vcpus;
        host.usedMemoryGiB += draftInstance.memoryGiB;
      }
    }

    this.state.instances.unshift(draftInstance);
    this.recordAudit(
      orgId,
      project.id,
      actor,
      'instance.provisioned',
      'ComputeInstance',
      draftInstance.id,
      requestId,
      provisionResult.observedState === 'Running' ? 'success' : 'error',
      `Requested ${draftInstance.name} (${draftInstance.templateId}) -> observed ${draftInstance.observedState}`,
    );
    this.persist();
    return draftInstance;
  }

  transitionInstance(
    orgId: string,
    instanceId: string,
    action: 'stop' | 'start' | 'delete',
    actor: string,
    requestId: string,
  ): ComputeInstance {
    const inst = this.state.instances.find((i) => i.id === instanceId && i.organisationId === orgId);
    if (!inst) {
      throw new ControlPlaneError(404, 'INSTANCE_NOT_FOUND', 'Compute instance not found in this organisation.');
    }
    const now = new Date().toISOString();
    const host = this.state.hosts.find((h) => h.id === inst.hostId);

    if (action === 'stop') {
      inst.desiredState = 'Stopped';
      inst.observedState = 'Stopped';
      inst.reconciliationNote = 'Stopped cleanly on simulated adapter.';
    } else if (action === 'start') {
      if (!host || host.state !== 'Healthy') {
        inst.observedState = 'Failed';
        inst.reconciliationNote = 'Cannot start instance: assigned host is unhealthy.';
      } else {
        inst.desiredState = 'Running';
        inst.observedState = 'Running';
        inst.reconciliationNote = `Started on ${host.hostname}.`;
      }
    } else if (action === 'delete') {
      inst.desiredState = 'Deleted';
      inst.observedState = 'Deleted';
      inst.reconciliationNote = 'Deleted; attached volumes and object buckets preserved independently.';
      if (host) {
        host.usedVcpus = Math.max(0, host.usedVcpus - inst.vcpus);
        host.usedMemoryGiB = Math.max(0, host.usedMemoryGiB - inst.memoryGiB);
      }
      // Detach volumes safely without deleting data
      for (const vol of this.state.volumes) {
        if (vol.attachedInstanceId === inst.id) {
          vol.attachedInstanceId = undefined;
          vol.status = 'Available';
        }
      }
    }
    inst.lastObservedAt = now;
    this.recordAudit(orgId, inst.projectId, actor, `instance.${action}`, 'ComputeInstance', inst.id, requestId, 'success', `Instance ${inst.name} -> ${inst.observedState}`);
    this.persist();
    return inst;
  }

  listGpuAllocations(orgId: string, projectId?: string): GpuAllocation[] {
    return this.state.gpuAllocations.filter(
      (g) => g.organisationId === orgId && (!projectId || g.projectId === projectId),
    );
  }

  allocateGpu(
    orgId: string,
    actor: string,
    requestId: string,
    input: {
      projectId: string;
      regionId: string;
      gpuProfileId: string;
      deviceCount: number;
      partitionProfile?: string;
      billingBasis: 'on-demand' | 'reserved-30d-sim';
    },
  ): GpuAllocation {
    const project = this.requireProject(orgId, input.projectId);
    const profile = this.gpuAdapter.listProfiles().find((p) => p.id === input.gpuProfileId);
    if (!profile) {
      throw new ControlPlaneError(400, 'INVALID_GPU_PROFILE', `Unknown GPU profile: ${input.gpuProfileId}`);
    }
    const validation = this.gpuAdapter.validateAllocation(profile, input.deviceCount, input.partitionProfile);
    if (!validation.ok) {
      throw new ControlPlaneError(400, 'UNSUPPORTED_GPU_CAPABILITY', validation.reason || 'Invalid GPU request');
    }

    const quota = this.getQuotaUsage(orgId, project.id);
    if (quota.used.gpus + input.deviceCount > quota.quotas.maxGpus) {
      throw new ControlPlaneError(409, 'QUOTA_EXCEEDED', 'GPU quota exceeded for this project.');
    }

    const host = this.state.hosts.find((h) => h.regionId === input.regionId && h.state === 'Healthy' && h.gpuCount >= input.deviceCount);
    if (!host) {
      throw new ControlPlaneError(409, 'NO_GPU_CAPACITY', `No healthy host with ${input.deviceCount} GPUs available in ${input.regionId}.`);
    }

    const baseRate = new Decimal(profile.hourlyRatePerDeviceEur).mul(input.deviceCount);
    const rate = input.billingBasis === 'reserved-30d-sim' ? baseRate.mul('0.82') : baseRate;

    const alloc: GpuAllocation = {
      id: `gpu_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      regionId: input.regionId,
      hostId: host.id,
      gpuProfileId: profile.id,
      deviceCount: input.deviceCount,
      partitionProfile: input.partitionProfile,
      billingBasis: input.billingBasis,
      hourlyRateEur: rate.toFixed(4),
      priceBasisVersion: this.state.priceBooks[0].version,
      status: 'Allocated',
      runtimeCompatibility: profile.cudaOrRocmRuntime,
      isolationNotice: profile.isolationNotice,
      createdAt: new Date().toISOString(),
    };
    this.state.gpuAllocations.unshift(alloc);
    this.recordAudit(orgId, project.id, actor, 'gpu.allocated', 'GpuAllocation', alloc.id, requestId, 'success', `Allocated ${input.deviceCount}x ${profile.modelName}`);
    this.persist();
    return alloc;
  }

  releaseGpu(orgId: string, allocationId: string, actor: string, requestId: string): GpuAllocation {
    const alloc = this.state.gpuAllocations.find((g) => g.id === allocationId && g.organisationId === orgId);
    if (!alloc) {
      throw new ControlPlaneError(404, 'GPU_ALLOCATION_NOT_FOUND', 'GPU allocation not found.');
    }
    alloc.status = 'Released';
    this.recordAudit(orgId, alloc.projectId, actor, 'gpu.released', 'GpuAllocation', alloc.id, requestId, 'success', `Released GPU allocation ${alloc.id}`);
    this.persist();
    return alloc;
  }

  listJobs(orgId: string, projectId?: string): BatchJob[] {
    return this.state.jobs.filter(
      (j) => j.organisationId === orgId && (!projectId || j.projectId === projectId),
    );
  }

  submitJob(
    orgId: string,
    actor: string,
    requestId: string,
    input: {
      projectId: string;
      name: string;
      regionId: string;
      schedulerBackend: 'slurm-adapter-sim' | 'local-queue-sim';
      workloadImage: string;
      command: string;
      cpuCores: number;
      gpuCount: number;
      memoryGiB: number;
      runtimeLimitSeconds: number;
      inputUri: string;
      outputUri: string;
      queueClass: 'standard' | 'gpu-priority' | 'throughput';
      priority?: number;
      environmentConfig?: Record<string, string>;
    },
  ): BatchJob {
    const project = this.requireProject(orgId, input.projectId);
    const quota = this.getQuotaUsage(orgId, project.id);
    if (quota.used.concurrentJobs + 1 > quota.quotas.maxConcurrentJobs) {
      throw new ControlPlaneError(409, 'JOB_QUOTA_EXCEEDED', 'Concurrent job quota exceeded for this project.');
    }
    if (!input.workloadImage.trim() || !input.command.trim()) {
      throw new ControlPlaneError(400, 'INVALID_WORKLOAD', 'Workload image and executable command are required.');
    }
    if (input.cpuCores < 1 || input.memoryGiB < 1 || input.runtimeLimitSeconds < 10) {
      throw new ControlPlaneError(400, 'INVALID_JOB_RESOURCES', 'Invalid CPU, memory, or runtime limit.');
    }

    const hourlyRate = new Decimal(input.cpuCores)
      .mul(this.state.priceBooks[0].rates.vcpuHourEur)
      .plus(new Decimal(input.memoryGiB).mul(this.state.priceBooks[0].rates.memoryGiBHourEur))
      .plus(new Decimal(input.gpuCount).mul(this.state.priceBooks[0].rates.gpuH100HourEur));

    const now = new Date().toISOString();
    const imageVerified = input.workloadImage.includes('registry.sim.aureom.eu') || input.workloadImage.includes('@sha256:');
    const job: BatchJob = {
      id: `job_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      name: input.name.trim(),
      regionId: input.regionId,
      schedulerBackend: input.schedulerBackend,
      workloadImage: input.workloadImage.trim(),
      imageDigestVerified: imageVerified,
      command: input.command.trim(),
      cpuCores: input.cpuCores,
      gpuCount: input.gpuCount,
      memoryGiB: input.memoryGiB,
      runtimeLimitSeconds: input.runtimeLimitSeconds,
      inputUri: input.inputUri.trim(),
      outputUri: input.outputUri.trim(),
      environmentConfig: input.environmentConfig ?? {},
      queueClass: input.queueClass,
      priority: input.priority ?? 50,
      state: 'Submitted',
      outputAvailable: false,
      logs: [
        `[${now}] Job submitted to ${input.schedulerBackend}. Image provenance verified: ${imageVerified}.`,
        `[${now}] Note: scheduler queue acceptance does not guarantee immediate node allocation.`,
      ],
      hourlyRateEur: hourlyRate.toFixed(4),
      priceBasisVersion: this.state.priceBooks[0].version,
      createdAt: now,
    };

    this.state.jobs.unshift(job);
    this.recordAudit(orgId, project.id, actor, 'job.submitted', 'BatchJob', job.id, requestId, 'success', `Submitted batch job ${job.name}`);
    this.persist();
    return job;
  }

  advanceJobState(orgId: string, jobId: string, actor: string, requestId: string): BatchJob {
    const job = this.state.jobs.find((j) => j.id === jobId && j.organisationId === orgId);
    if (!job) {
      throw new ControlPlaneError(404, 'JOB_NOT_FOUND', 'Batch job not found.');
    }
    if (['Completed', 'Failed', 'Cancelled', 'TimedOut'].includes(job.state)) {
      return job;
    }
    const patch = this.schedulerAdapter.advanceJob(job, this.state.hosts);
    Object.assign(job, patch);

    // If job completed, materialise synthetic output file inside matching bucket
    if (job.state === 'Completed' && job.outputAvailable && job.outputArtifactName) {
      const targetBucket = this.state.buckets.find((b) => b.projectId === job.projectId);
      if (targetBucket) {
        const resultPayload = JSON.stringify(
          {
            jobId: job.id,
            jobName: job.name,
            regionId: job.regionId,
            schedulerBackend: job.schedulerBackend,
            nodeId: job.allocationNodeId,
            exitCode: 0,
            simulatedNote: 'Synthetic batch computation output generated by local demonstration scheduler',
            metrics: {
              meanResidual: 0.000412,
              iterations: 120,
              wallTimeSeconds: 42.7,
            },
            completedAt: job.finishedAt,
          },
          null,
          2,
        );
        const key = `outputs/${job.id}/${job.outputArtifactName}`;
        const existingIdx = targetBucket.objects.findIndex((o) => o.key === key);
        const obj = {
          key,
          sizeBytes: Buffer.byteLength(resultPayload, 'utf8'),
          contentType: 'application/json',
          sha256: this.storageAdapter.computeSha256(resultPayload),
          contentPreview: resultPayload,
          uploadedAt: new Date().toISOString(),
        };
        if (existingIdx >= 0) {
          targetBucket.objects[existingIdx] = obj;
        } else {
          targetBucket.objects.unshift(obj);
          targetBucket.usedBytes += obj.sizeBytes;
        }
      }
    }

    this.recordAudit(orgId, job.projectId, actor, 'job.advanced', 'BatchJob', job.id, requestId, 'success', `Batch job ${job.name} transitioned to ${job.state}`);
    this.persist();
    return job;
  }

  cancelJob(orgId: string, jobId: string, actor: string, requestId: string): BatchJob {
    const job = this.state.jobs.find((j) => j.id === jobId && j.organisationId === orgId);
    if (!job) {
      throw new ControlPlaneError(404, 'JOB_NOT_FOUND', 'Batch job not found.');
    }
    if (['Completed', 'Failed', 'Cancelled', 'TimedOut'].includes(job.state)) {
      throw new ControlPlaneError(409, 'JOB_TERMINAL', `Job is already in terminal state ${job.state}.`);
    }
    const now = new Date().toISOString();
    job.state = 'Cancelled';
    job.finishedAt = now;
    job.outputAvailable = false;
    job.logs.push(`[${now}] Job cancelled by ${actor}. Output artifacts were not produced.`);
    this.recordAudit(orgId, job.projectId, actor, 'job.cancelled', 'BatchJob', job.id, requestId, 'success', `Cancelled job ${job.name}`);
    this.persist();
    return job;
  }

  getJobOutput(orgId: string, jobId: string): {available: boolean; artifactName?: string; content?: string; sha256?: string} {
    const job = this.state.jobs.find((j) => j.id === jobId && j.organisationId === orgId);
    if (!job) {
      throw new ControlPlaneError(404, 'JOB_NOT_FOUND', 'Batch job not found.');
    }
    if (!job.outputAvailable || !job.outputArtifactName) {
      return {available: false};
    }
    const bucket = this.state.buckets.find((b) => b.projectId === job.projectId);
    const key = `outputs/${job.id}/${job.outputArtifactName}`;
    const obj = bucket?.objects.find((o) => o.key === key);
    if (!obj) {
      return {available: false};
    }
    return {
      available: true,
      artifactName: job.outputArtifactName,
      content: obj.contentPreview,
      sha256: obj.sha256,
    };
  }

  listStorage(orgId: string, projectId?: string): {
    buckets: StorageBucket[];
    volumes: BlockVolume[];
    filesystems: SharedFilesystem[];
    snapshots: StorageSnapshot[];
    backups: IndependentBackup[];
  } {
    return {
      buckets: this.state.buckets.filter((b) => b.organisationId === orgId && (!projectId || b.projectId === projectId)),
      volumes: this.state.volumes.filter((v) => v.organisationId === orgId && (!projectId || v.projectId === projectId)),
      filesystems: this.state.filesystems.filter((f) => f.organisationId === orgId && (!projectId || f.projectId === projectId)),
      snapshots: this.state.snapshots.filter((s) => s.organisationId === orgId && (!projectId || s.projectId === projectId)),
      backups: this.state.backups.filter((b) => b.organisationId === orgId && (!projectId || b.projectId === projectId)),
    };
  }

  createBucket(
    orgId: string,
    actor: string,
    requestId: string,
    input: {projectId: string; name: string; regionId: string; accessControl: 'private-project' | 'org-read-only'; retentionDays: number},
  ): StorageBucket {
    const project = this.requireProject(orgId, input.projectId);
    const bucket: StorageBucket = {
      id: `bkt_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      name: input.name.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-'),
      regionId: input.regionId,
      accessControl: input.accessControl,
      durabilityNotice: this.storageAdapter.describeDurability('bucket'),
      replicationPolicy: 'Single-region demo store (no automatic multi-region synchronous commit)',
      retentionDays: Math.max(1, input.retentionDays),
      usedBytes: 0,
      quotaGB: 250,
      pricePerGBMonthEur: this.state.priceBooks[0].rates.objectStorageGBMonthEur,
      objects: [],
      createdAt: new Date().toISOString(),
    };
    this.state.buckets.unshift(bucket);
    this.recordAudit(orgId, project.id, actor, 'bucket.created', 'StorageBucket', bucket.id, requestId, 'success', `Created bucket ${bucket.name}`);
    this.persist();
    return bucket;
  }

  uploadBucketObject(
    orgId: string,
    bucketId: string,
    actor: string,
    requestId: string,
    input: {key: string; content: string; contentType?: string},
  ): StorageBucket {
    const bucket = this.state.buckets.find((b) => b.id === bucketId);
    if (!bucket) {
      throw new ControlPlaneError(404, 'BUCKET_NOT_FOUND', 'Bucket not found.');
    }
    if (bucket.organisationId !== orgId) {
      throw new ControlPlaneError(403, 'STORAGE_PERMISSION_DENIED', 'Cross-organisation bucket access is forbidden.');
    }
    const cleanKey = input.key.trim().replace(/^\/+/, '');
    if (!cleanKey || cleanKey.includes('..')) {
      throw new ControlPlaneError(400, 'INVALID_OBJECT_KEY', 'Object key is invalid.');
    }
    const sizeBytes = Buffer.byteLength(input.content, 'utf8');
    const obj = {
      key: cleanKey,
      sizeBytes,
      contentType: input.contentType || 'text/plain',
      sha256: this.storageAdapter.computeSha256(input.content),
      contentPreview: input.content.slice(0, 4096),
      uploadedAt: new Date().toISOString(),
    };
    const existing = bucket.objects.findIndex((o) => o.key === cleanKey);
    if (existing >= 0) {
      bucket.usedBytes -= bucket.objects[existing].sizeBytes;
      bucket.objects[existing] = obj;
    } else {
      bucket.objects.unshift(obj);
    }
    bucket.usedBytes += sizeBytes;
    this.recordAudit(orgId, bucket.projectId, actor, 'object.uploaded', 'StorageBucket', bucket.id, requestId, 'success', `Uploaded ${cleanKey} (${sizeBytes} B)`);
    this.persist();
    return bucket;
  }

  createVolume(
    orgId: string,
    actor: string,
    requestId: string,
    input: {projectId: string; name: string; regionId: string; sizeGB: number},
  ): BlockVolume {
    const project = this.requireProject(orgId, input.projectId);
    const quota = this.getQuotaUsage(orgId, project.id);
    if (quota.used.storageGB + input.sizeGB > quota.quotas.maxStorageGB) {
      throw new ControlPlaneError(409, 'QUOTA_EXCEEDED', 'Storage quota exceeded for this project.');
    }
    const volume: BlockVolume = {
      id: `vol_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      name: input.name.trim(),
      regionId: input.regionId,
      sizeGB: input.sizeGB,
      durabilityNotice: this.storageAdapter.describeDurability('volume'),
      pricePerGBMonthEur: this.state.priceBooks[0].rates.blockStorageGBMonthEur,
      status: 'Available',
      createdAt: new Date().toISOString(),
    };
    this.state.volumes.unshift(volume);
    this.recordAudit(orgId, project.id, actor, 'volume.created', 'BlockVolume', volume.id, requestId, 'success', `Created block volume ${volume.name} (${volume.sizeGB} GB)`);
    this.persist();
    return volume;
  }

  createSnapshot(
    orgId: string,
    volumeId: string,
    name: string,
    actor: string,
    requestId: string,
  ): StorageSnapshot {
    const volume = this.state.volumes.find((v) => v.id === volumeId && v.organisationId === orgId);
    if (!volume) {
      throw new ControlPlaneError(404, 'VOLUME_NOT_FOUND', 'Volume not found in this organisation.');
    }
    const snap: StorageSnapshot = {
      id: `snap_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: volume.projectId,
      sourceVolumeId: volume.id,
      name: name.trim(),
      sizeGB: volume.sizeGB,
      isIndependentBackup: false,
      note: this.storageAdapter.describeDurability('snapshot'),
      createdAt: new Date().toISOString(),
    };
    this.state.snapshots.unshift(snap);
    this.recordAudit(orgId, volume.projectId, actor, 'snapshot.created', 'StorageSnapshot', snap.id, requestId, 'success', `Created snapshot ${snap.name} (distinct from independent backup)`);
    this.persist();
    return snap;
  }

  createIndependentBackup(
    orgId: string,
    actor: string,
    requestId: string,
    input: {sourceResourceId: string; sourceKind: 'volume' | 'bucket'; targetRegionId: string; retentionDays: number},
  ): IndependentBackup {
    const vol =
      input.sourceKind === 'volume'
        ? this.state.volumes.find((v) => v.id === input.sourceResourceId && v.organisationId === orgId)
        : undefined;
    const bucket =
      input.sourceKind === 'bucket'
        ? this.state.buckets.find((b) => b.id === input.sourceResourceId && b.organisationId === orgId)
        : undefined;
    const projectId = vol?.projectId ?? bucket?.projectId;
    if (!projectId) {
      throw new ControlPlaneError(404, 'SOURCE_NOT_FOUND', 'Backup source resource not found in this organisation.');
    }
    const backup: IndependentBackup = {
      id: `bak_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId,
      sourceResourceId: input.sourceResourceId,
      sourceKind: input.sourceKind,
      targetRegionId: input.targetRegionId,
      retentionDays: Math.max(7, input.retentionDays),
      sizeGB: vol ? vol.sizeGB : Math.max(1, Math.ceil((bucket?.usedBytes ?? 0) / 1024 / 1024 / 1024)),
      verificationStatus: 'Verified-Checksum',
      createdAt: new Date().toISOString(),
    };
    this.state.backups.unshift(backup);
    this.recordAudit(orgId, projectId, actor, 'backup.created', 'IndependentBackup', backup.id, requestId, 'success', `Created independent backup in ${input.targetRegionId}`);
    this.persist();
    return backup;
  }

  listNetworking(orgId: string, projectId?: string): {
    networks: ProjectNetwork[];
    securityGroups: SecurityGroup[];
    publicAddresses: PublicAddressAllocation[];
  } {
    return {
      networks: this.state.networks.filter((n) => n.organisationId === orgId && (!projectId || n.projectId === projectId)),
      securityGroups: this.state.securityGroups.filter((s) => s.organisationId === orgId && (!projectId || s.projectId === projectId)),
      publicAddresses: this.state.publicAddresses.filter((p) => p.organisationId === orgId && (!projectId || p.projectId === projectId)),
    };
  }

  addSubnet(
    orgId: string,
    networkId: string,
    actor: string,
    requestId: string,
    input: {name: string; cidr: string},
  ): Subnet {
    const net = this.state.networks.find((n) => n.id === networkId && n.organisationId === orgId);
    if (!net) {
      throw new ControlPlaneError(404, 'NETWORK_NOT_FOUND', 'Network not found.');
    }
    if (!cidrContains(net.cidr, input.cidr)) {
      throw new ControlPlaneError(400, 'SUBNET_OUTSIDE_VPC', `Subnet ${input.cidr} must fall within network CIDR ${net.cidr}.`);
    }
    for (const existing of net.subnets) {
      if (cidrsOverlap(existing.cidr, input.cidr)) {
        throw new ControlPlaneError(
          409,
          'SUBNET_CIDR_OVERLAP',
          `Subnet ${input.cidr} overlaps with existing subnet ${existing.name} (${existing.cidr}).`,
        );
      }
    }
    const parsed = parseCidr(input.cidr);
    const subnet: Subnet = {
      id: `sub_${randomUUID().slice(0, 8)}`,
      networkId: net.id,
      name: input.name.trim(),
      cidr: input.cidr.trim(),
      gatewayIp: intToIp(parsed.start + 1),
      availableIps: Math.max(0, parsed.end - parsed.start - 4),
    };
    net.subnets.push(subnet);
    this.recordAudit(orgId, net.projectId, actor, 'subnet.created', 'Subnet', subnet.id, requestId, 'success', `Added subnet ${subnet.cidr} to ${net.name}`);
    this.persist();
    return subnet;
  }

  addSecurityGroupRule(
    orgId: string,
    securityGroupId: string,
    actor: string,
    requestId: string,
    input: {protocol: 'tcp' | 'udp' | 'icmp'; portRange: string; sourceCidr: string; description: string},
  ): SecurityGroup {
    const sg = this.state.securityGroups.find((s) => s.id === securityGroupId && s.organisationId === orgId);
    if (!sg) {
      throw new ControlPlaneError(404, 'SECURITY_GROUP_NOT_FOUND', 'Security group not found.');
    }
    parseCidr(input.sourceCidr, true);
    if (input.sourceCidr.trim() === '0.0.0.0/0' && (input.portRange.includes('22') || input.portRange.includes('3389'))) {
      throw new ControlPlaneError(
        400,
        'INBOUND_POLICY_VIOLATION',
        'Unrestricted 0.0.0.0/0 administrative access (SSH/RDP) is denied by default policy; specify a narrow source CIDR.',
      );
    }
    const rule: InboundRule = {
      id: `rule_${randomUUID().slice(0, 8)}`,
      protocol: input.protocol,
      portRange: input.portRange.trim(),
      sourceCidr: input.sourceCidr.trim(),
      description: input.description.trim() || 'Explicit inbound allow rule',
    };
    sg.inboundRules.push(rule);
    this.recordAudit(orgId, sg.projectId, actor, 'security_group.rule_added', 'SecurityGroup', sg.id, requestId, 'success', `Allowed ${rule.protocol}:${rule.portRange} from ${rule.sourceCidr}`);
    this.persist();
    return sg;
  }

  allocatePublicAddress(
    orgId: string,
    actor: string,
    requestId: string,
    input: {projectId: string; regionId: string; attachedInstanceId?: string},
  ): PublicAddressAllocation {
    const project = this.requireProject(orgId, input.projectId);
    const octet = 10 + (this.state.publicAddresses.length % 200);
    const addr: PublicAddressAllocation = {
      id: `pip_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: project.id,
      regionId: input.regionId,
      ipAddress: `198.51.100.${octet}`, // RFC 5737 TEST-NET-2 simulated public address
      attachedInstanceId: input.attachedInstanceId,
      adapterName: 'aureom-bgp-anycast-sim',
      createdAt: new Date().toISOString(),
    };
    this.state.publicAddresses.unshift(addr);
    this.recordAudit(orgId, project.id, actor, 'public_ip.allocated', 'PublicAddress', addr.id, requestId, 'success', `Allocated simulated public IP ${addr.ipAddress}`);
    this.persist();
    return addr;
  }

  /**
   * Idempotent decimal EUR metering tick.
   * Uses a deterministic meteringPeriodKey so retries or restarts never double-bill.
   */
  runMeteringCycle(orgId: string, projectId: string, periodKey: string, actor: string, requestId: string): {
    createdEntries: UsageLedgerEntry[];
    skippedDuplicates: number;
  } {
    const project = this.requireProject(orgId, projectId);
    const priceBook = this.state.priceBooks[0];
    const now = new Date();
    const periodEnd = now.toISOString();
    const periodStart = new Date(now.getTime() - 3600_000).toISOString();

    const createdEntries: UsageLedgerEntry[] = [];
    let skippedDuplicates = 0;

    const recordIfUnique = (
      resourceId: string,
      resourceKind: UsageLedgerEntry['resourceKind'],
      resourceName: string,
      quantity: string,
      unit: string,
      unitRateEur: string,
    ) => {
      const uniqueKey = `${resourceId}:${periodKey}`;
      if (this.state.usageLedger.some((u) => u.meteringPeriodKey === uniqueKey)) {
        skippedDuplicates += 1;
        return;
      }
      const amount = new Decimal(quantity).mul(new Decimal(unitRateEur)).toFixed(4);
      const entry: UsageLedgerEntry = {
        id: `usg_${randomUUID().slice(0, 8)}`,
        organisationId: orgId,
        projectId: project.id,
        resourceId,
        resourceKind,
        resourceName,
        meteringPeriodKey: uniqueKey,
        periodStart,
        periodEnd,
        quantity,
        unit,
        priceVersion: priceBook.version,
        unitRateEur,
        amountEur: amount,
        currency: 'EUR',
        finalisationState: 'EstimatedCurrent',
        createdAt: periodEnd,
      };
      this.state.usageLedger.unshift(entry);
      createdEntries.push(entry);
    };

    for (const inst of this.state.instances.filter((i) => i.projectId === project.id && i.observedState === 'Running')) {
      recordIfUnique(inst.id, 'compute', `${inst.name} (${inst.templateId})`, '1.0000', 'instance-hour', inst.hourlyRateEur);
    }

    for (const gpu of this.state.gpuAllocations.filter((g) => g.projectId === project.id && g.status === 'Allocated')) {
      recordIfUnique(gpu.id, 'gpu', `${gpu.deviceCount}x ${gpu.gpuProfileId}`, '1.0000', 'gpu-allocation-hour', gpu.hourlyRateEur);
    }

    for (const job of this.state.jobs.filter((j) => j.projectId === project.id && j.state === 'Completed')) {
      recordIfUnique(job.id, 'hpc_job', `Batch job ${job.name}`, '0.2500', 'job-hour', job.hourlyRateEur);
    }

    const totalStorageGB = this.state.volumes
      .filter((v) => v.projectId === project.id && v.status !== 'Deleting')
      .reduce((acc, v) => acc + v.sizeGB, 0);
    if (totalStorageGB > 0) {
      recordIfUnique(
        `${project.id}-block-storage`,
        'storage',
        `Block Volumes (${totalStorageGB} GB)`,
        String(totalStorageGB),
        'GB-hour-slice',
        new Decimal(priceBook.rates.blockStorageGBMonthEur).div(730).toFixed(6),
      );
    }

    this.evaluateBudgetAlert(project);
    this.recordAudit(
      orgId,
      project.id,
      actor,
      'metering.cycle_executed',
      'UsageLedger',
      periodKey,
      requestId,
      'success',
      `Metered ${createdEntries.length} new entries (${skippedDuplicates} duplicate periods skipped)`,
    );
    this.persist();
    return {createdEntries, skippedDuplicates};
  }

  listUsage(orgId: string, projectId?: string): {
    entries: UsageLedgerEntry[];
    estimatedCurrentEur: string;
    finalisedUsageEur: string;
    invoices: Invoice[];
  } {
    const entries = this.state.usageLedger.filter(
      (u) => u.organisationId === orgId && (!projectId || u.projectId === projectId),
    );
    const estimatedCurrentEur = entries
      .filter((e) => e.finalisationState === 'EstimatedCurrent')
      .reduce((acc, e) => acc.plus(new Decimal(e.amountEur)), new Decimal(0))
      .toFixed(2);
    const finalisedUsageEur = entries
      .filter((e) => e.finalisationState === 'FinalisedUsage')
      .reduce((acc, e) => acc.plus(new Decimal(e.amountEur)), new Decimal(0))
      .toFixed(2);
    const invoices = this.state.invoices.filter(
      (inv) => inv.organisationId === orgId && (!projectId || inv.projectId === projectId),
    );
    return {entries, estimatedCurrentEur, finalisedUsageEur, invoices};
  }

  getProjectEstimatedCharges(orgId: string, projectId: string): string {
    const entries = this.state.usageLedger.filter(
      (u) => u.organisationId === orgId && u.projectId === projectId,
    );
    return entries
      .reduce((acc, e) => acc.plus(new Decimal(e.amountEur)), new Decimal(0))
      .toFixed(2);
  }

  generateInvoice(
    orgId: string,
    projectId: string,
    actor: string,
    requestId: string,
    locale: LocaleCode = 'en',
  ): Invoice {
    const project = this.requireProject(orgId, projectId);
    const org = this.state.organisations.find((o) => o.id === orgId);
    if (!org) {
      throw new ControlPlaneError(404, 'ORG_NOT_FOUND', 'Organisation not found.');
    }

    const unbilled = this.state.usageLedger.filter(
      (u) => u.organisationId === orgId && u.projectId === projectId && u.finalisationState === 'EstimatedCurrent',
    );
    if (unbilled.length === 0) {
      throw new ControlPlaneError(409, 'NO_UNBILLED_USAGE', 'No unbilled estimated usage entries to finalise.');
    }

    const invId = `inv_${randomUUID().slice(0, 8)}`;
    const invoiceNumber = `AUR-DEMO-2026-${String(this.state.invoices.length + 1).padStart(4, '0')}`;

    const lineItems: InvoiceLineItem[] = unbilled.map((u) => ({
      description: u.resourceName,
      resourceKind: u.resourceKind,
      priceVersion: u.priceVersion,
      quantity: u.quantity,
      unit: u.unit,
      unitRateEur: u.unitRateEur,
      subtotalEur: new Decimal(u.amountEur).toFixed(2),
    }));

    const subtotal = unbilled.reduce((acc, u) => acc.plus(new Decimal(u.amountEur)), new Decimal(0));
    const vatRate = new Decimal(org.vatRatePercent);
    const vatAmount = subtotal.mul(vatRate).div(100);
    const total = subtotal.plus(vatAmount);

    for (const u of unbilled) {
      u.finalisationState = 'FinalisedUsage';
      u.invoiceId = invId;
    }

    const invoice: Invoice = {
      id: invId,
      invoiceNumber,
      organisationId: orgId,
      projectId: project.id,
      currency: 'EUR',
      periodStart: unbilled[unbilled.length - 1].periodStart,
      periodEnd: unbilled[0].periodEnd,
      subtotalEur: subtotal.toFixed(2),
      vatRatePercent: vatRate.toFixed(2),
      vatAmountEur: vatAmount.toFixed(2),
      totalEur: total.toFixed(2),
      taxTreatmentNote: org.taxJurisdictionNote,
      status: 'IssuedInvoice',
      isSimulated: true,
      lineItems,
      issuedAt: new Date().toISOString(),
    };

    this.state.invoices.unshift(invoice);
    this.enqueueLocalizedEmail(orgId, org.billingEmail, locale, 'invoice_issued', {
      invoiceNumber: invoice.invoiceNumber,
      total: invoice.totalEur,
    });
    this.recordAudit(orgId, project.id, actor, 'invoice.issued', 'Invoice', invoice.id, requestId, 'success', `Issued demonstration invoice ${invoice.invoiceNumber} for ${invoice.totalEur} EUR`);
    this.persist();
    return invoice;
  }

  markInvoicePaid(orgId: string, invoiceId: string, actor: string, requestId: string): Invoice {
    const inv = this.state.invoices.find((i) => i.id === invoiceId && i.organisationId === orgId);
    if (!inv) {
      throw new ControlPlaneError(404, 'INVOICE_NOT_FOUND', 'Invoice not found.');
    }
    inv.status = 'Paid';
    inv.paidAt = new Date().toISOString();
    this.recordAudit(orgId, inv.projectId, actor, 'invoice.paid', 'Invoice', inv.id, requestId, 'success', `Recorded simulated payment for ${inv.invoiceNumber}`);
    this.persist();
    return inv;
  }

  getOperationsTelemetry(): {
    hosts: (FacilityHost & {pue: string | null; pueBoundaryNote: string})[];
    incidents: InfrastructureIncident[];
    controlSeparationNotice: string;
  } {
    return {
      hosts: this.state.hosts.map((h) => {
        const pueInfo = this.telemetryAdapter.computePue(h);
        return {
          ...h,
          pue: pueInfo.pue,
          pueBoundaryNote: pueInfo.boundaryNote,
        };
      }),
      incidents: this.state.incidents,
      controlSeparationNotice:
        'Read-only telemetry adapter: building cooling loops, electrical breakers, and fire suppression are physically and logically isolated from this software console.',
    };
  }

  simulateHostFailure(
    hostId: string,
    actor: string,
    requestId: string,
    orgId = 'org_ncrc_eu_demo',
    locale: LocaleCode = 'en',
  ): {host: FacilityHost; incident: InfrastructureIncident; affectedInstances: number} {
    const host = this.state.hosts.find((h) => h.id === hostId);
    if (!host) {
      throw new ControlPlaneError(404, 'HOST_NOT_FOUND', `Host ${hostId} not found.`);
    }
    const now = new Date().toISOString();
    host.state = 'Failed';
    host.telemetryFreshnessIso = now;

    let affectedInstances = 0;
    for (const inst of this.state.instances) {
      if (inst.hostId === host.id && inst.observedState === 'Running') {
        inst.observedState = 'Reconciling';
        inst.reconciliationNote = `Host ${host.hostname} reported failure; control plane awaiting reconciliation.`;
        inst.lastObservedAt = now;
        affectedInstances += 1;
      }
    }
    for (const job of this.state.jobs) {
      if (job.allocationNodeId === host.id && ['Allocated', 'Starting', 'Running'].includes(job.state)) {
        job.state = 'Failed';
        job.finishedAt = now;
        job.exitCode = 137;
        job.outputAvailable = false;
        job.logs.push(`[${now}] CRITICAL: Execution node ${host.hostname} failed mid-execution.`);
      }
    }

    const region = this.state.regions.find((r) => r.id === host.regionId);
    if (region) {
      region.status = 'degraded';
    }

    const incident: InfrastructureIncident = {
      id: `inc_${randomUUID().slice(0, 8)}`,
      regionId: host.regionId,
      hostId: host.id,
      severity: 'critical',
      title: `Simulated host power loss on ${host.hostname}`,
      summary: `Read-only telemetry lost heartbeat from ${host.hostname} (${host.rackId}). ${affectedInstances} instance(s) marked Reconciling.`,
      status: 'Active',
      openedAt: now,
    };
    this.state.incidents.unshift(incident);
    const org = this.state.organisations.find((o) => o.id === orgId);
    if (org) {
      this.enqueueLocalizedEmail(orgId, org.billingEmail, locale, 'incident_notice', {
        title: incident.title,
        host: host.hostname,
      });
    }
    this.recordAudit(orgId, undefined, actor, 'ops.host_failure_simulated', 'FacilityHost', host.id, requestId, 'error', incident.title);
    this.persist();
    return {host, incident, affectedInstances};
  }

  recoverHost(hostId: string, actor: string, requestId: string, orgId = 'org_ncrc_eu_demo'): FacilityHost {
    const host = this.state.hosts.find((h) => h.id === hostId);
    if (!host) {
      throw new ControlPlaneError(404, 'HOST_NOT_FOUND', `Host ${hostId} not found.`);
    }
    const now = new Date().toISOString();
    host.state = 'Healthy';
    host.telemetryFreshnessIso = now;

    for (const inc of this.state.incidents) {
      if (inc.hostId === host.id && inc.status === 'Active') {
        inc.status = 'Resolved';
        inc.resolvedAt = now;
      }
    }
    const region = this.state.regions.find((r) => r.id === host.regionId);
    if (region && this.state.hosts.filter((h) => h.regionId === region.id).every((h) => h.state === 'Healthy')) {
      region.status = 'operational';
    }
    this.recordAudit(orgId, undefined, actor, 'ops.host_recovered', 'FacilityHost', host.id, requestId, 'success', `Restored host ${host.hostname} to Healthy`);
    this.persist();
    return host;
  }

  reconcileAfterRestart(actor: string, orgId = 'org_ncrc_eu_demo'): {
    reconciledCount: number;
    failedCount: number;
    runningCount: number;
  } {
    const now = new Date().toISOString();
    let reconciledCount = 0;
    let failedCount = 0;
    let runningCount = 0;

    for (const inst of this.state.instances) {
      if (inst.observedState === 'Deleted') continue;
      const host = this.state.hosts.find((h) => h.id === inst.hostId);
      const outcome = this.computeAdapter.reconcile(inst, host);
      if (inst.observedState !== outcome.observedState || inst.reconciliationNote !== outcome.note) {
        reconciledCount += 1;
      }
      inst.observedState = outcome.observedState;
      inst.reconciliationNote = outcome.note;
      inst.lastObservedAt = now;
      if (outcome.observedState === 'Failed') failedCount += 1;
      if (outcome.observedState === 'Running') runningCount += 1;
    }

    this.recordAudit(
      orgId,
      undefined,
      actor,
      'control_plane.reconciled',
      'ControlPlane',
      'reconciler-worker',
      `req_${randomUUID().slice(0, 8)}`,
      'success',
      `Reconciled observed infrastructure state: ${runningCount} running, ${failedCount} failed, ${reconciledCount} updated.`,
    );
    this.persist();
    return {reconciledCount, failedCount, runningCount};
  }

  listAuditEvents(orgId: string): AuditEvent[] {
    return this.state.auditEvents.filter((a) => a.organisationId === orgId);
  }

  listEmailOutbox(orgId: string): EmailOutboxMessage[] {
    return this.state.emailOutbox.filter((e) => e.organisationId === orgId);
  }

  listSupportTickets(orgId: string): SupportTicket[] {
    return this.state.supportTickets.filter((t) => t.organisationId === orgId);
  }

  createSupportTicket(
    orgId: string,
    actor: string,
    requestId: string,
    input: {projectId?: string; subject: string; severity: 'normal' | 'high'; locale: LocaleCode},
  ): SupportTicket {
    const ticket: SupportTicket = {
      id: `tkt_${randomUUID().slice(0, 8)}`,
      organisationId: orgId,
      projectId: input.projectId,
      subject: input.subject.trim(),
      severity: input.severity,
      status: 'Acknowledged',
      createdAt: new Date().toISOString(),
    };
    this.state.supportTickets.unshift(ticket);
    const org = this.state.organisations.find((o) => o.id === orgId);
    if (org) {
      this.enqueueLocalizedEmail(orgId, org.billingEmail, input.locale, 'support_ack', {
        subject: ticket.subject,
        body: `Ticket ${ticket.id} acknowledged in simulated EU support queue.`,
      });
    }
    this.recordAudit(orgId, input.projectId, actor, 'support.ticket_created', 'SupportTicket', ticket.id, requestId, 'success', ticket.subject);
    this.persist();
    return ticket;
  }

  recordContactInquiry(input: {
    name: string;
    email: string;
    organisation: string;
    topic: 'dedicated-capacity' | 'general' | 'governance';
    message: string;
    locale: LocaleCode;
  }): ContactInquiry {
    if (!input.name.trim() || !input.email.includes('@') || !input.message.trim()) {
      throw new ControlPlaneError(400, 'INVALID_INQUIRY', 'Valid name, email, and message are required.');
    }
    const inquiry: ContactInquiry = {
      id: `inq_${randomUUID().slice(0, 8)}`,
      name: input.name.trim(),
      email: input.email.trim(),
      organisation: input.organisation.trim() || 'Unspecified',
      topic: input.topic,
      message: input.message.trim(),
      locale: input.locale,
      createdAt: new Date().toISOString(),
    };
    this.state.contactInquiries.unshift(inquiry);
    this.persist();
    return inquiry;
  }

  getOverview(orgId: string, projectId?: string): {
    organisation: Organisation | undefined;
    projects: Project[];
    activeInstances: number;
    runningJobs: number;
    queuedJobs: number;
    gpuDevicesAllocated: number;
    storageUsedGB: number;
    estimatedChargesEur: string;
    finalisedChargesEur: string;
    activeIncidents: InfrastructureIncident[];
    pendingActions: {type: string; resourceId: string; summary: string}[];
    quotaSummary: ReturnType<ControlPlaneStore['getQuotaUsage']> | null;
  } {
    const org = this.state.organisations.find((o) => o.id === orgId);
    const projects = this.listProjects(orgId);
    const selectedProjectId = projectId ?? projects[0]?.id;

    const instances = this.listInstances(orgId, selectedProjectId).filter((i) => i.observedState !== 'Deleted');
    const jobs = this.listJobs(orgId, selectedProjectId);
    const gpus = this.listGpuAllocations(orgId, selectedProjectId).filter((g) => g.status === 'Allocated');
    const usage = this.listUsage(orgId, selectedProjectId);
    const storage = this.listStorage(orgId, selectedProjectId);
    const storageUsedGB =
      storage.volumes.reduce((a, v) => a + v.sizeGB, 0) +
      storage.filesystems.reduce((a, f) => a + f.usedGB, 0) +
      Math.ceil(storage.buckets.reduce((a, b) => a + b.usedBytes, 0) / (1024 * 1024 * 1024));

    const pendingActions: {type: string; resourceId: string; summary: string}[] = [];
    for (const i of instances) {
      if (i.observedState === 'Reconciling' || i.observedState === 'Failed') {
        pendingActions.push({
          type: 'reconciliation',
          resourceId: i.id,
          summary: `${i.name} is ${i.observedState}: ${i.reconciliationNote ?? 'check host status'}`,
        });
      }
    }
    for (const p of projects) {
      if (p.budgetAlert?.triggered) {
        pendingActions.push({
          type: 'budget_alert',
          resourceId: p.id,
          summary: `Budget threshold (${p.budgetAlert.monthlyThresholdEur} EUR) reached on ${p.name}`,
        });
      }
    }

    return {
      organisation: org,
      projects,
      activeInstances: instances.filter((i) => i.observedState === 'Running').length,
      runningJobs: jobs.filter((j) => ['Allocated', 'Starting', 'Running'].includes(j.state)).length,
      queuedJobs: jobs.filter((j) => ['Submitted', 'Queued'].includes(j.state)).length,
      gpuDevicesAllocated: gpus.reduce((a, g) => a + g.deviceCount, 0),
      storageUsedGB,
      estimatedChargesEur: usage.estimatedCurrentEur,
      finalisedChargesEur: usage.finalisedUsageEur,
      activeIncidents: this.state.incidents.filter((i) => i.status === 'Active'),
      pendingActions,
      quotaSummary: selectedProjectId ? this.getQuotaUsage(orgId, selectedProjectId) : null,
    };
  }

  getIdempotentResponse(key: string): {status: number; body: unknown} | undefined {
    return this.state.idempotencyCache[key];
  }

  saveIdempotentResponse(key: string, status: number, body: unknown): void {
    this.state.idempotencyCache[key] = {status, body};
    this.persist();
  }

  private recordAudit(
    organisationId: string,
    projectId: string | undefined,
    actor: string,
    action: string,
    resourceType: string,
    resourceId: string,
    requestId: string,
    outcome: AuditEvent['outcome'],
    summary: string,
  ): void {
    this.state.auditEvents.unshift({
      id: `aud_${randomUUID().slice(0, 8)}`,
      organisationId,
      projectId,
      actor,
      action,
      resourceType,
      resourceId,
      requestId,
      outcome,
      summary,
      timestamp: new Date().toISOString(),
    });
    if (this.state.auditEvents.length > 200) {
      this.state.auditEvents.length = 200;
    }
  }
}

export function paginate<T>(items: T[], limitRaw?: unknown, offsetRaw?: unknown): {
  items: T[];
  total: number;
  limit: number;
  offset: number;
} {
  const limit = Math.min(100, Math.max(1, Number(limitRaw) || 25));
  const offset = Math.max(0, Number(offsetRaw) || 0);
  return {
    items: items.slice(offset, offset + limit),
    total: items.length,
    limit,
    offset,
  };
}

export function canRoleMutate(role: UserRole): boolean {
  return role !== 'auditor';
}
