import {FunctionDeclaration, GoogleGenAI, Type} from '@google/genai';
import Decimal from 'decimal.js';
import type {ControlPlaneStore} from './store';
import type {LocaleCode} from './types';

function redactSecrets(text: string): string {
  return text
    .replace(/ak_demo_[a-zA-Z0-9_]+/g, '[REDACTED_API_KEY]')
    .replace(/ssh-(ed25519|rsa)\s+[A-Za-z0-9+/=]+/g, '[REDACTED_SSH_KEY]')
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer [REDACTED_TOKEN]');
}

export async function runComputeAssistant(
  store: ControlPlaneStore,
  input: {
    orgId: string;
    projectId: string;
    locale: LocaleCode;
    prompt: string;
    approvedAction?: boolean;
  },
): Promise<{
  answer: string;
  references: {id: string; label: string}[];
  toolsInvoked: string[];
  model: string;
  privacyNotice: string;
}> {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment Secrets.');
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const cleanPrompt = redactSecrets(input.prompt);
  const toolsInvoked: string[] = [];
  const references: {id: string; label: string}[] = [];

  const getResourceCatalogTool: FunctionDeclaration = {
    name: 'get_resource_catalog',
    description:
      'Fetch official demonstration compute templates, GPU profiles, regions, and versioned EUR price book.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        regionFilter: {
          type: Type.STRING,
          description: 'Optional region ID filter such as eu-sim-nord-1.',
        },
      },
    },
  };

  const calculateCostEstimateTool: FunctionDeclaration = {
    name: 'calculate_cost_estimate',
    description:
      'Deterministically calculate estimated EUR cost for a compute, GPU, or batch configuration using exact decimal arithmetic.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        templateId: {type: Type.STRING, description: 'Instance template ID (e.g. eu-gp-medium)'},
        gpuProfileId: {type: Type.STRING, description: 'Optional GPU profile ID (e.g. gpu-h100-sxm-sim)'},
        gpuCount: {type: Type.INTEGER, description: 'Number of GPU devices (0-8)'},
        hours: {type: Type.NUMBER, description: 'Estimated duration in hours'},
        storageGB: {type: Type.NUMBER, description: 'Block storage in GB for 1 month estimate'},
      },
      required: ['hours'],
    },
  };

  const getProjectUsageSummaryTool: FunctionDeclaration = {
    name: 'get_project_usage_summary',
    description: 'Read current project quotas, estimated EUR charges, and invoice totals.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        projectId: {type: Type.STRING, description: 'Project identifier'},
      },
      required: ['projectId'],
    },
  };

  const inspectFailedJobsTool: FunctionDeclaration = {
    name: 'inspect_failed_jobs',
    description: 'Inspect authorised control-plane batch job logs for failed or cancelled jobs in the project.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        projectId: {type: Type.STRING, description: 'Project identifier'},
      },
      required: ['projectId'],
    },
  };

  const draftBatchJobTool: FunctionDeclaration = {
    name: 'draft_batch_job_spec',
    description: 'Draft a non-executing Slurm/batch job specification JSON for user review.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        name: {type: Type.STRING, description: 'Job name'},
        cpuCores: {type: Type.INTEGER, description: 'CPU cores'},
        gpuCount: {type: Type.INTEGER, description: 'GPU devices'},
        memoryGiB: {type: Type.INTEGER, description: 'Memory in GiB'},
        queueClass: {type: Type.STRING, description: 'standard | gpu-priority | throughput'},
      },
      required: ['name', 'cpuCores', 'memoryGiB', 'queueClass'],
    },
  };

  const tools = [
    {
      functionDeclarations: [
        getResourceCatalogTool,
        calculateCostEstimateTool,
        getProjectUsageSummaryTool,
        inspectFailedJobsTool,
        draftBatchJobTool,
      ],
    },
  ];

  const langLabel = input.locale === 'fr' ? 'French' : input.locale === 'de' ? 'German' : 'English';
  const systemInstruction = [
    `You are the AUREOM EUROPE Compute Assistant. Respond strictly in ${langLabel}.`,
    'Rules:',
    '1. Always call deterministic tools for resource specs, pricing math, usage summaries, or failed job diagnostics. Never invent prices or hardware specs.',
    '2. Cite exact source identifiers returned by tools (e.g. [ref: eu-gp-medium], [ref: v2026.11-demo]).',
    '3. You MUST NEVER provision paid resources, increase quotas, delete storage, or alter access permissions. If asked to mutate infrastructure, explain that explicit human operator confirmation in the console form is required.',
    '4. Clearly note when figures come from the simulated demonstration catalog.',
  ].join('\n');

  const executeTool = (name: string, args: Record<string, unknown>): Record<string, unknown> => {
    toolsInvoked.push(name);
    if (name === 'get_resource_catalog') {
      const cat = store.getCatalog();
      references.push({id: cat.priceBook.version, label: `Price Book ${cat.priceBook.version}`});
      for (const r of cat.regions) {
        references.push({id: r.id, label: `${r.id} (${r.city})`});
      }
      return {
        regions: cat.regions,
        templates: cat.templates,
        gpuProfiles: cat.gpuProfiles,
        priceBook: cat.priceBook,
      };
    }
    if (name === 'calculate_cost_estimate') {
      const cat = store.getCatalog();
      const hours = new Decimal(Number(args['hours'] ?? 1));
      const tmpl = cat.templates.find((t) => t.id === args['templateId']);
      const gpu = cat.gpuProfiles.find((g) => g.id === args['gpuProfileId']);
      const gpuCount = new Decimal(Number(args['gpuCount'] ?? 0));
      const storageGB = new Decimal(Number(args['storageGB'] ?? 0));

      const computeTotal = tmpl ? new Decimal(tmpl.pricePerHourEur).mul(hours) : new Decimal(0);
      const gpuTotal = gpu ? new Decimal(gpu.hourlyRatePerDeviceEur).mul(gpuCount).mul(hours) : new Decimal(0);
      const storageMonth = storageGB.mul(cat.priceBook.rates.blockStorageGBMonthEur);
      const grandTotal = computeTotal.plus(gpuTotal).plus(storageMonth);

      references.push({id: cat.priceBook.version, label: `Price Book ${cat.priceBook.version}`});
      if (tmpl) references.push({id: tmpl.id, label: tmpl.name});
      if (gpu) references.push({id: gpu.id, label: gpu.modelName});

      return {
        currency: 'EUR',
        priceVersion: cat.priceBook.version,
        computeEur: computeTotal.toFixed(4),
        gpuEur: gpuTotal.toFixed(4),
        storageMonthlyEur: storageMonth.toFixed(4),
        totalEstimatedEur: grandTotal.toFixed(2),
        isSimulatedEstimate: true,
      };
    }
    if (name === 'get_project_usage_summary') {
      const pid = String(args['projectId'] || input.projectId);
      const overview = store.getOverview(input.orgId, pid);
      const usage = store.listUsage(input.orgId, pid);
      references.push({id: pid, label: `Project ${pid}`});
      return {
        projectId: pid,
        activeInstances: overview.activeInstances,
        runningJobs: overview.runningJobs,
        estimatedCurrentEur: usage.estimatedCurrentEur,
        finalisedUsageEur: usage.finalisedUsageEur,
        invoiceCount: usage.invoices.length,
        quotaSummary: overview.quotaSummary,
      };
    }
    if (name === 'inspect_failed_jobs') {
      const pid = String(args['projectId'] || input.projectId);
      const jobs = store.listJobs(input.orgId, pid).filter((j) => j.state === 'Failed' || j.state === 'Cancelled');
      for (const j of jobs) {
        references.push({id: j.id, label: `Job ${j.name}`});
      }
      return {
        failedJobs: jobs.map((j) => ({
          id: j.id,
          name: j.name,
          state: j.state,
          exitCode: j.exitCode,
          logs: j.logs.slice(-6),
        })),
      };
    }
    if (name === 'draft_batch_job_spec') {
      references.push({id: 'slurm-adapter-sim', label: 'Slurm Draft Spec'});
      return {
        draftOnlyRequiresHumanSubmit: true,
        spec: {
          projectId: input.projectId,
          name: String(args['name'] || 'draft-compute-job'),
          cpuCores: Number(args['cpuCores'] || 4),
          gpuCount: Number(args['gpuCount'] || 0),
          memoryGiB: Number(args['memoryGiB'] || 16),
          queueClass: String(args['queueClass'] || 'standard'),
          workloadImage: 'registry.sim.aureom.eu/climate/mesh-solver:1.0-signed',
          runtimeLimitSeconds: 1800,
        },
      };
    }
    return {error: 'Unknown tool'};
  };

  const contents: Record<string, unknown>[] = [
    {role: 'user', parts: [{text: cleanPrompt}]},
  ];

  let finalText = '';
  for (let step = 0; step < 3; step += 1) {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: contents as never,
      config: {
        systemInstruction,
        tools,
      },
    });

    const candidateContent = response.candidates?.[0]?.content;
    const calls = response.functionCalls;
    if (calls && calls.length > 0 && candidateContent) {
      contents.push(candidateContent as Record<string, unknown>);
      const toolParts = calls.map((call) => {
        const result = executeTool(call.name ?? '', (call.args ?? {}) as Record<string, unknown>);
        return {
          functionResponse: {
            id: call.id,
            name: call.name,
            response: {result},
          },
        };
      });
      contents.push({role: 'user', parts: toolParts});
      continue;
    }

    finalText = response.text ?? '';
    break;
  }

  // Deduplicate references
  const seen = new Set<string>();
  const uniqueRefs = references.filter((r) => {
    if (seen.has(r.id)) return false;
    seen.add(r.id);
    return true;
  });

  return {
    answer: finalText || 'No response generated.',
    references: uniqueRefs,
    toolsInvoked: Array.from(new Set(toolsInvoked)),
    model: 'gemini-4-hydrogen',
    privacyNotice:
      'Redacted control-plane metadata only; API keys, SSH private/public material, and raw bucket datasets are never sent to external models.',
  };
}
