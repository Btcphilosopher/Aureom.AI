export type LocaleCode = 'en' | 'fr' | 'de';

export type InstanceLifecycleState =
  | 'Requested'
  | 'Validating'
  | 'Provisioning'
  | 'Running'
  | 'Stopping'
  | 'Stopped'
  | 'Deleting'
  | 'Deleted'
  | 'Failed'
  | 'Reconciling';

export type JobLifecycleState =
  | 'Submitted'
  | 'Queued'
  | 'Allocated'
  | 'Starting'
  | 'Running'
  | 'Completed'
  | 'Failed'
  | 'Cancelled'
  | 'TimedOut';

export type UserRole = 'org_admin' | 'project_engineer' | 'infra_operator' | 'auditor';

export interface StructuredApiError {
  error: {
    code: string;
    message: string;
    requestId: string;
    details?: Record<string, unknown>;
  };
}

export interface Organisation {
  id: string;
  name: string;
  slug: string;
  billingEmail: string;
  vatId: string;
  vatRatePercent: string;
  taxJurisdictionNote: string;
  mfaEnforced: boolean;
  isSimulated: true;
  createdAt: string;
}

export interface ProjectQuotas {
  maxVcpus: number;
  maxMemoryGiB: number;
  maxGpus: number;
  maxStorageGB: number;
  maxInstances: number;
  maxConcurrentJobs: number;
}

export interface DataResidencyPolicy {
  computeLocation: string;
  primaryStorageLocation: string;
  replicaLocation: string;
  backupLocation: string;
  logLocation: string;
  supportAccessPolicy: 'eu-staff-only-explicit-approval' | 'project-admin-token-required';
  externalSubprocessors: string[];
  sovereigntyNotice: string;
}

export interface BudgetAlert {
  id: string;
  projectId: string;
  monthlyThresholdEur: string;
  notifyEmail: string;
  preferredLocale: LocaleCode;
  triggered: boolean;
  lastTriggeredAt?: string;
}

export interface Project {
  id: string;
  organisationId: string;
  name: string;
  slug: string;
  description: string;
  primaryRegionId: string;
  quotas: ProjectQuotas;
  residency: DataResidencyPolicy;
  budgetAlert?: BudgetAlert;
  createdAt: string;
}

export interface DemoRegion {
  id: string;
  code: string;
  city: string;
  country: string;
  isSimulated: true;
  simulationLabel: string;
  gridCarbonNote: string;
  coolingArchitecture: string;
  supportedArchitectures: ('x86_64' | 'aarch64')[];
  status: 'operational' | 'degraded';
}

export interface InstanceTemplate {
  id: string;
  name: string;
  architecture: 'x86_64' | 'aarch64';
  cpuModel: string;
  vcpus: number;
  memoryGiB: number;
  defaultDiskGB: number;
  pricePerHourEur: string;
  adapterKind: 'local-container-sim';
  virtualizationBoundary: string;
}

export interface ComputeInstance {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  templateId: string;
  architecture: 'x86_64' | 'aarch64';
  vcpus: number;
  memoryGiB: number;
  diskGB: number;
  image: string;
  imageProvenanceDigest: string;
  regionId: string;
  networkId: string;
  subnetId: string;
  securityGroupId: string;
  sshPublicKeyFingerprint: string;
  privateIp: string;
  publicIp?: string;
  hostId: string;
  adapterKind: 'local-container-sim';
  isolationBoundary: string;
  desiredState: 'Running' | 'Stopped' | 'Deleted';
  observedState: InstanceLifecycleState;
  priceBasisVersion: string;
  hourlyRateEur: string;
  reconciliationNote?: string;
  lastObservedAt: string;
  createdAt: string;
}

export interface GpuProfile {
  id: string;
  modelName: string;
  architecture: string;
  vramGiB: number;
  interconnect: string;
  driverVersion: string;
  cudaOrRocmRuntime: string;
  supportsPartitioning: boolean;
  partitionProfiles: string[];
  multiTenantHardwareIsolationSupported: boolean;
  isolationNotice: string;
  hourlyRatePerDeviceEur: string;
  isSimulated: true;
}

export interface GpuAllocation {
  id: string;
  organisationId: string;
  projectId: string;
  regionId: string;
  hostId: string;
  gpuProfileId: string;
  deviceCount: number;
  partitionProfile?: string;
  billingBasis: 'on-demand' | 'reserved-30d-sim';
  hourlyRateEur: string;
  priceBasisVersion: string;
  status: 'Allocated' | 'Released' | 'Degraded';
  runtimeCompatibility: string;
  isolationNotice: string;
  createdAt: string;
}

export interface BatchJob {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  schedulerBackend: 'slurm-adapter-sim' | 'local-queue-sim';
  workloadImage: string;
  imageDigestVerified: boolean;
  command: string;
  cpuCores: number;
  gpuCount: number;
  memoryGiB: number;
  runtimeLimitSeconds: number;
  inputUri: string;
  outputUri: string;
  environmentConfig: Record<string, string>;
  queueClass: 'standard' | 'gpu-priority' | 'throughput';
  priority: number;
  state: JobLifecycleState;
  allocationNodeId?: string;
  allocatedAt?: string;
  startedAt?: string;
  finishedAt?: string;
  outputAvailable: boolean;
  outputArtifactName?: string;
  logs: string[];
  exitCode?: number;
  hourlyRateEur: string;
  priceBasisVersion: string;
  createdAt: string;
}

export interface StorageBucket {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  accessControl: 'private-project' | 'org-read-only';
  durabilityNotice: string;
  replicationPolicy: string;
  retentionDays: number;
  usedBytes: number;
  quotaGB: number;
  pricePerGBMonthEur: string;
  objects: BucketObject[];
  createdAt: string;
}

export interface BucketObject {
  key: string;
  sizeBytes: number;
  contentType: string;
  sha256: string;
  contentPreview: string;
  uploadedAt: string;
}

export interface BlockVolume {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  sizeGB: number;
  attachedInstanceId?: string;
  durabilityNotice: string;
  pricePerGBMonthEur: string;
  status: 'Available' | 'Attached' | 'Deleting';
  createdAt: string;
}

export interface SharedFilesystem {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  protocol: 'NFSv4.2' | 'Lustre-Sim';
  capacityGB: number;
  usedGB: number;
  mountTarget: string;
  durabilityNotice: string;
  pricePerGBMonthEur: string;
  createdAt: string;
}

export interface StorageSnapshot {
  id: string;
  organisationId: string;
  projectId: string;
  sourceVolumeId: string;
  name: string;
  sizeGB: number;
  isIndependentBackup: false;
  note: string;
  createdAt: string;
}

export interface IndependentBackup {
  id: string;
  organisationId: string;
  projectId: string;
  sourceResourceId: string;
  sourceKind: 'volume' | 'bucket';
  targetRegionId: string;
  retentionDays: number;
  sizeGB: number;
  verificationStatus: 'Verified-Checksum' | 'Pending';
  createdAt: string;
}

export interface InboundRule {
  id: string;
  protocol: 'tcp' | 'udp' | 'icmp';
  portRange: string;
  sourceCidr: string;
  description: string;
}

export interface SecurityGroup {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  defaultInboundPolicy: 'deny-all';
  inboundRules: InboundRule[];
  createdAt: string;
}

export interface Subnet {
  id: string;
  networkId: string;
  name: string;
  cidr: string;
  gatewayIp: string;
  availableIps: number;
}

export interface ProjectNetwork {
  id: string;
  organisationId: string;
  projectId: string;
  name: string;
  regionId: string;
  cidr: string;
  privateConnectivity: string;
  publicIpPoolEnabled: boolean;
  subnets: Subnet[];
  createdAt: string;
}

export interface PublicAddressAllocation {
  id: string;
  organisationId: string;
  projectId: string;
  regionId: string;
  ipAddress: string;
  attachedInstanceId?: string;
  adapterName: string;
  createdAt: string;
}

export interface PriceBook {
  version: string;
  effectiveFrom: string;
  currency: 'EUR';
  isSimulated: true;
  rates: {
    vcpuHourEur: string;
    memoryGiBHourEur: string;
    blockStorageGBMonthEur: string;
    objectStorageGBMonthEur: string;
    sharedFsGBMonthEur: string;
    snapshotGBMonthEur: string;
    backupGBMonthEur: string;
    egressGBEur: string;
    publicIpHourEur: string;
    gpuH100HourEur: string;
    gpuL40SHourEur: string;
    gpuMi300XHourEur: string;
  };
}

export interface UsageLedgerEntry {
  id: string;
  organisationId: string;
  projectId: string;
  resourceId: string;
  resourceKind: 'compute' | 'gpu' | 'hpc_job' | 'storage' | 'network_egress' | 'reserved_capacity';
  resourceName: string;
  meteringPeriodKey: string;
  periodStart: string;
  periodEnd: string;
  quantity: string;
  unit: string;
  priceVersion: string;
  unitRateEur: string;
  amountEur: string;
  currency: 'EUR';
  finalisationState: 'EstimatedCurrent' | 'FinalisedUsage';
  invoiceId?: string;
  createdAt: string;
}

export interface InvoiceLineItem {
  description: string;
  resourceKind: string;
  priceVersion: string;
  quantity: string;
  unit: string;
  unitRateEur: string;
  subtotalEur: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  organisationId: string;
  projectId: string;
  currency: 'EUR';
  periodStart: string;
  periodEnd: string;
  subtotalEur: string;
  vatRatePercent: string;
  vatAmountEur: string;
  totalEur: string;
  taxTreatmentNote: string;
  status: 'IssuedInvoice' | 'Paid';
  isSimulated: true;
  lineItems: InvoiceLineItem[];
  issuedAt: string;
  paidAt?: string;
}

export interface ApiKeyRecord {
  id: string;
  organisationId: string;
  name: string;
  prefix: string;
  scopes: string[];
  expiresAt: string;
  revoked: boolean;
  createdBy: string;
  createdAt: string;
}

export interface OrgMember {
  id: string;
  organisationId: string;
  name: string;
  email: string;
  role: UserRole;
  mfaEnabled: boolean;
  lastActiveAt: string;
}

export interface AuditEvent {
  id: string;
  organisationId: string;
  projectId?: string;
  actor: string;
  action: string;
  resourceType: string;
  resourceId: string;
  requestId: string;
  outcome: 'success' | 'denied' | 'error';
  summary: string;
  timestamp: string;
}

export interface FacilityHost {
  id: string;
  regionId: string;
  siteName: string;
  roomName: string;
  rackId: string;
  hostname: string;
  architecture: 'x86_64' | 'aarch64';
  totalVcpus: number;
  usedVcpus: number;
  totalMemoryGiB: number;
  usedMemoryGiB: number;
  gpuCount: number;
  gpuModel?: string;
  powerDrawWatts: number | null;
  facilityTotalPowerWatts: number | null;
  temperatureCelsius: number;
  telemetrySource: string;
  telemetryFreshnessIso: string;
  state: 'Healthy' | 'Failed' | 'Maintenance';
}

export interface InfrastructureIncident {
  id: string;
  regionId: string;
  hostId?: string;
  severity: 'info' | 'warning' | 'critical';
  title: string;
  summary: string;
  status: 'Active' | 'Resolved';
  openedAt: string;
  resolvedAt?: string;
}

export interface EmailOutboxMessage {
  id: string;
  organisationId: string;
  to: string;
  locale: LocaleCode;
  category: 'budget_alert' | 'invoice_issued' | 'incident_notice' | 'support_ack';
  subject: string;
  body: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  organisationId: string;
  projectId?: string;
  subject: string;
  severity: 'normal' | 'high';
  status: 'Open' | 'Acknowledged';
  createdAt: string;
}

export interface ContactInquiry {
  id: string;
  name: string;
  email: string;
  organisation: string;
  topic: 'dedicated-capacity' | 'general' | 'governance';
  message: string;
  locale: LocaleCode;
  createdAt: string;
}
