import {createHash} from 'node:crypto';
import type {
  BatchJob,
  ComputeInstance,
  FacilityHost,
  GpuAllocation,
  GpuProfile,
  InstanceTemplate,
  StorageBucket,
} from './types';

export interface ProvisioningResult {
  observedState: ComputeInstance['observedState'];
  hostId: string;
  privateIp: string;
  adapterKind: 'local-container-sim';
  isolationBoundary: string;
  note: string;
}

export interface ComputeProvisioningAdapter {
  readonly adapterName: string;
  readonly adapterKind: 'local-container-sim';
  provision(
    instance: ComputeInstance,
    template: InstanceTemplate,
    healthyHosts: FacilityHost[],
  ): ProvisioningResult;
  reconcile(
    instance: ComputeInstance,
    host: FacilityHost | undefined,
  ): {observedState: ComputeInstance['observedState']; note: string};
}

export interface GpuInventoryAdapter {
  readonly adapterName: string;
  readonly isSimulatedHardware: true;
  listProfiles(): GpuProfile[];
  validateAllocation(
    profile: GpuProfile,
    deviceCount: number,
    partitionProfile?: string,
  ): {ok: boolean; reason?: string};
}

export interface BatchSchedulerAdapter {
  readonly adapterName: string;
  generateSlurmScript(job: BatchJob): string;
  advanceJob(
    job: BatchJob,
    healthyHosts: FacilityHost[],
  ): Partial<BatchJob>;
}

export interface StorageBackendAdapter {
  readonly adapterName: string;
  computeSha256(content: string): string;
  describeDurability(kind: 'bucket' | 'volume' | 'filesystem' | 'snapshot' | 'backup'): string;
}

export interface FacilityTelemetryAdapter {
  readonly adapterName: string;
  readonly isReadOnly: true;
  computePue(host: FacilityHost): {
    pue: string | null;
    boundaryNote: string;
  };
}

export class LocalContainerSimComputeAdapter implements ComputeProvisioningAdapter {
  readonly adapterName = 'aureom-local-container-sim-v1';
  readonly adapterKind = 'local-container-sim' as const;

  provision(
    instance: ComputeInstance,
    template: InstanceTemplate,
    healthyHosts: FacilityHost[],
  ): ProvisioningResult {
    const matchingHost = healthyHosts.find(
      (h) => h.regionId === instance.regionId && h.architecture === template.architecture && h.state === 'Healthy',
    );
    if (!matchingHost) {
      return {
        observedState: 'Failed',
        hostId: 'unassigned',
        privateIp: instance.privateIp,
        adapterKind: this.adapterKind,
        isolationBoundary: template.virtualizationBoundary,
        note: `No healthy ${template.architecture} host available in ${instance.regionId}`,
      };
    }
    return {
      observedState: 'Running',
      hostId: matchingHost.id,
      privateIp: instance.privateIp,
      adapterKind: this.adapterKind,
      isolationBoundary:
        'Simulated local control-plane container record (not a hardware-isolated KVM virtual machine)',
      note: `Provisioned on simulated host ${matchingHost.hostname}`,
    };
  }

  reconcile(
    instance: ComputeInstance,
    host: FacilityHost | undefined,
  ): {observedState: ComputeInstance['observedState']; note: string} {
    if (instance.desiredState === 'Deleted') {
      return {observedState: 'Deleted', note: 'Deleted during reconciliation'};
    }
    if (!host || host.state === 'Failed') {
      return {
        observedState: 'Failed',
        note: `Observed host ${instance.hostId} unavailable during reconciliation`,
      };
    }
    if (instance.desiredState === 'Stopped') {
      return {observedState: 'Stopped', note: 'Confirmed stopped on host'};
    }
    return {
      observedState: 'Running',
      note: `Verified active on ${host.hostname}`,
    };
  }
}

export class LocalGpuSimulatorAdapter implements GpuInventoryAdapter {
  readonly adapterName = 'aureom-synthetic-gpu-adapter-v1';
  readonly isSimulatedHardware = true as const;

  private readonly profiles: GpuProfile[] = [
    {
      id: 'gpu-h100-sxm-sim',
      modelName: 'Aureom-H100-80GB-SXM (Simulated)',
      architecture: 'Hopper-Class (Synthetic Spec)',
      vramGiB: 80,
      interconnect: 'Simulated 900 GB/s Fabric',
      driverVersion: '550.90.07-sim',
      cudaOrRocmRuntime: 'CUDA 12.4 / PyTorch 2.5 compatible',
      supportsPartitioning: true,
      partitionProfiles: ['1g.10gb', '2g.20gb', '3g.40gb', 'full-80gb'],
      multiTenantHardwareIsolationSupported: false,
      isolationNotice:
        'Assigning a synthetic device ID does not enforce hardware multi-tenant isolation; dedicated host allocation is required for strict tenant separation.',
      hourlyRatePerDeviceEur: '2.8500',
      isSimulated: true,
    },
    {
      id: 'gpu-l40s-pcie-sim',
      modelName: 'Aureom-L40S-48GB-PCIe (Simulated)',
      architecture: 'Ada-Class (Synthetic Spec)',
      vramGiB: 48,
      interconnect: 'PCIe Gen4 x16 (Simulated)',
      driverVersion: '550.90.07-sim',
      cudaOrRocmRuntime: 'CUDA 12.4 / TensorRT 10',
      supportsPartitioning: false,
      partitionProfiles: [],
      multiTenantHardwareIsolationSupported: false,
      isolationNotice:
        'Hardware partitioning is unsupported on this profile; whole-device assignment only.',
      hourlyRatePerDeviceEur: '1.1500',
      isSimulated: true,
    },
    {
      id: 'gpu-mi300x-sim',
      modelName: 'Aureom-MI300X-192GB (Simulated)',
      architecture: 'CDNA3-Class (Synthetic Spec)',
      vramGiB: 192,
      interconnect: 'Simulated Infinity Fabric',
      driverVersion: 'ROCm 6.2.1-sim',
      cudaOrRocmRuntime: 'ROCm 6.2 / HIP',
      supportsPartitioning: true,
      partitionProfiles: ['SPX-192gb', 'CPX-24gb'],
      multiTenantHardwareIsolationSupported: false,
      isolationNotice:
        'Synthetic accelerator inventory; partition labels are modeled for scheduling validation only.',
      hourlyRatePerDeviceEur: '3.2000',
      isSimulated: true,
    },
  ];

  listProfiles(): GpuProfile[] {
    return this.profiles;
  }

  validateAllocation(
    profile: GpuProfile,
    deviceCount: number,
    partitionProfile?: string,
  ): {ok: boolean; reason?: string} {
    if (deviceCount < 1 || deviceCount > 8) {
      return {ok: false, reason: 'Device count must be between 1 and 8.'};
    }
    if (partitionProfile) {
      if (!profile.supportsPartitioning) {
        return {
          ok: false,
          reason: `Partitioning is unsupported on ${profile.modelName}.`,
        };
      }
      if (!profile.partitionProfiles.includes(partitionProfile)) {
        return {
          ok: false,
          reason: `Partition profile "${partitionProfile}" is not supported by ${profile.modelName}.`,
        };
      }
    }
    return {ok: true};
  }
}

export class SlurmAndLocalSchedulerAdapter implements BatchSchedulerAdapter {
  readonly adapterName = 'aureom-slurm-sim-scheduler-v1';

  generateSlurmScript(job: BatchJob): string {
    return [
      '#!/bin/bash',
      `#SBATCH --job-name=${job.name}`,
      `#SBATCH --partition=${job.queueClass}`,
      `#SBATCH --cpus-per-task=${job.cpuCores}`,
      `#SBATCH --mem=${job.memoryGiB}G`,
      job.gpuCount > 0 ? `#SBATCH --gpus=${job.gpuCount}` : '#SBATCH --gpus=0',
      `#SBATCH --time=00:${String(Math.max(1, Math.floor(job.runtimeLimitSeconds / 60))).padStart(2, '0')}:00`,
      `#SBATCH --output=${job.outputUri}/slurm-%j.out`,
      '',
      `# Workload image (provenance verified: ${job.imageDigestVerified})`,
      `# Container: ${job.workloadImage}`,
      `# Input: ${job.inputUri}`,
      job.command,
    ].join('\n');
  }

  advanceJob(job: BatchJob, healthyHosts: FacilityHost[]): Partial<BatchJob> {
    const now = new Date().toISOString();
    const regionalHosts = healthyHosts.filter(
      (h) => h.regionId === job.regionId && h.state === 'Healthy',
    );
    const selectedHost = regionalHosts.find((h) => h.gpuCount >= job.gpuCount) ?? regionalHosts[0];

    switch (job.state) {
      case 'Submitted':
        return {
          state: 'Queued',
          logs: [...job.logs, `[${now}] Scheduler accepted job into queue "${job.queueClass}" (priority ${job.priority}).`],
        };
      case 'Queued':
        if (!selectedHost) {
          return {
            logs: [...job.logs, `[${now}] Waiting in queue: no healthy compute node available in ${job.regionId}.`],
          };
        }
        return {
          state: 'Allocated',
          allocationNodeId: selectedHost.id,
          allocatedAt: now,
          logs: [...job.logs, `[${now}] Allocated node ${selectedHost.hostname} (${job.cpuCores} cores, ${job.gpuCount} GPU).`],
        };
      case 'Allocated':
        return {
          state: 'Starting',
          logs: [
            ...job.logs,
            `[${now}] Staging input from ${job.inputUri} into isolated sandbox workspace...`,
          ],
        };
      case 'Starting':
        return {
          state: 'Running',
          startedAt: now,
          logs: [
            ...job.logs,
            `[${now}] Executing "${job.command}" inside workload image ${job.workloadImage}.`,
          ],
        };
      case 'Running': {
        if (job.allocationNodeId) {
          const hostStillHealthy = healthyHosts.some(
            (h) => h.id === job.allocationNodeId && h.state === 'Healthy',
          );
          if (!hostStillHealthy) {
            return {
              state: 'Failed',
              finishedAt: now,
              exitCode: 137,
              outputAvailable: false,
              logs: [
                ...job.logs,
                `[${now}] ERROR: Assigned node ${job.allocationNodeId} became unreachable. Job terminated without output.`,
              ],
            };
          }
        }
        const artifactName = `${job.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_result.json`;
        return {
          state: 'Completed',
          finishedAt: now,
          exitCode: 0,
          outputAvailable: true,
          outputArtifactName: artifactName,
          logs: [
            ...job.logs,
            `[${now}] Workload finished with exit code 0.`,
            `[${now}] Materialised output artifact "${artifactName}" at ${job.outputUri}/${artifactName}.`,
          ],
        };
      }
      default:
        return {};
    }
  }
}

export class LocalS3StorageAdapter implements StorageBackendAdapter {
  readonly adapterName = 'aureom-local-s3-sim-v1';

  computeSha256(content: string): string {
    return createHash('sha256').update(content).digest('hex');
  }

  describeDurability(kind: 'bucket' | 'volume' | 'filesystem' | 'snapshot' | 'backup'): string {
    switch (kind) {
      case 'bucket':
        return 'Local demonstration S3-compatible store (single-process demo disk; non-redundant outside this demo)';
      case 'volume':
        return 'Simulated block volume record (attached logically to instance records; no NVMe-oF backend active)';
      case 'filesystem':
        return 'Simulated POSIX shared filesystem metadata (NFSv4.2 semantics modeled)';
      case 'snapshot':
        return 'Point-in-time volume reference only — depends on primary volume availability; not an independent backup';
      case 'backup':
        return 'Independent copy target metadata with SHA-256 verification state; cross-region copy simulated locally';
    }
  }
}

export class ReadOnlyFacilityTelemetryAdapter implements FacilityTelemetryAdapter {
  readonly adapterName = 'aureom-telemetry-readonly-v1';
  readonly isReadOnly = true as const;

  computePue(host: FacilityHost): {pue: string | null; boundaryNote: string} {
    if (host.powerDrawWatts === null || host.facilityTotalPowerWatts === null || host.powerDrawWatts <= 0) {
      return {
        pue: null,
        boundaryNote: 'PUE unavailable: both IT load and total facility power boundary meters are required.',
      };
    }
    const pue = (host.facilityTotalPowerWatts / host.powerDrawWatts).toFixed(2);
    return {
      pue,
      boundaryNote: `Computed strictly over measured IT (${host.powerDrawWatts}W) and facility (${host.facilityTotalPowerWatts}W) meters.`,
    };
  }
}

export function buildBucketObjectPreview(bucket: StorageBucket, key: string, content: string): {
  key: string;
  sizeBytes: number;
  sha256: string;
  bucketId: string;
} {
  const adapter = new LocalS3StorageAdapter();
  return {
    key,
    sizeBytes: Buffer.byteLength(content, 'utf8'),
    sha256: adapter.computeSha256(content),
    bucketId: bucket.id,
  };
}

export function describeGpuSummary(allocation: GpuAllocation): string {
  return `${allocation.deviceCount}x ${allocation.gpuProfileId} (${allocation.status})`;
}
