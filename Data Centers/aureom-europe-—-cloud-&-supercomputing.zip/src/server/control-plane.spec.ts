import {describe, expect, it} from 'vitest';
import {ControlPlaneError, ControlPlaneStore} from './store';

describe('AUREOM EUROPE Control Plane Store', () => {
  const orgA = 'org_ncrc_eu_demo';
  const orgB = 'org_rhein_bio_demo';
  const actor = 'test@ncrc-demo.example.eu';

  it('enforces strict organisation isolation across projects and storage', () => {
    const store = new ControlPlaneStore({persistPath: null});
    expect(() => store.requireProject(orgA, 'proj_rhein_private_sim')).toThrowError(ControlPlaneError);
    expect(() =>
      store.uploadBucketObject(orgB, 'bkt_baltic_datasets', actor, 'req_1', {
        key: 'evil.txt',
        content: 'blocked',
      }),
    ).toThrowError(ControlPlaneError);
  });

  it('enforces project quotas and validates SSH public keys on instance creation', () => {
    const store = new ControlPlaneStore({persistPath: null});
    expect(() =>
      store.createInstance(orgA, actor, 'req_bad_ssh', {
        projectId: 'proj_baltic_hydro_sim',
        name: 'bad-key',
        templateId: 'eu-gp-small',
        regionId: 'eu-sim-nord-1',
        image: 'debian-12-bookworm-eu-minimal',
        sshPublicKey: 'password123',
      }),
    ).toThrowError(/SSH public key/i);

    // Exhaust memory quota (seed uses 32 of 256 GiB; 1 eu-mem-large = 128 GiB fits, 2nd exceeds 256 GiB)
    for (let i = 0; i < 1; i += 1) {
      store.createInstance(orgA, actor, `req_ok_${i}`, {
        projectId: 'proj_baltic_hydro_sim',
        name: `large-${i}`,
        templateId: 'eu-mem-large',
        regionId: 'eu-sim-nord-1',
        image: 'debian-12-bookworm-eu-minimal',
        sshPublicKey: 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDemoKeyAureom test',
      });
    }
    expect(() =>
      store.createInstance(orgA, actor, 'req_over_quota', {
        projectId: 'proj_baltic_hydro_sim',
        name: 'overflow',
        templateId: 'eu-mem-large',
        regionId: 'eu-sim-nord-1',
        image: 'debian-12-bookworm-eu-minimal',
        sshPublicKey: 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDemoKeyAureom test',
      }),
    ).toThrowError(/quota exceeded/i);
  });

  it('gates unsupported GPU partitioning capabilities via adapter', () => {
    const store = new ControlPlaneStore({persistPath: null});
    expect(() =>
      store.allocateGpu(orgA, actor, 'req_gpu_bad', {
        projectId: 'proj_baltic_hydro_sim',
        regionId: 'eu-sim-central-1',
        gpuProfileId: 'gpu-l40s-pcie-sim',
        deviceCount: 1,
        partitionProfile: '1g.10gb',
        billingBasis: 'on-demand',
      }),
    ).toThrowError(/Partitioning is unsupported/i);
  });

  it('separates scheduler submission, allocation, execution, output retrieval, and cancellation', () => {
    const store = new ControlPlaneStore({persistPath: null});
    const job = store.submitJob(orgA, actor, 'req_job_1', {
      projectId: 'proj_baltic_hydro_sim',
      name: 'wave-sim',
      regionId: 'eu-sim-nord-1',
      schedulerBackend: 'slurm-adapter-sim',
      workloadImage: 'registry.sim.aureom.eu/ocean/nemo-solver:4.2.1-signed',
      command: 'python3 run.py',
      cpuCores: 4,
      gpuCount: 0,
      memoryGiB: 16,
      runtimeLimitSeconds: 600,
      inputUri: 's3://baltic-datasets-nord/inputs/baltic_grid_sample.csv',
      outputUri: 's3://baltic-datasets-nord/outputs/',
      queueClass: 'standard',
    });
    expect(job.state).toBe('Submitted');
    expect(store.getJobOutput(orgA, job.id).available).toBe(false);

    // Advance Submitted -> Queued -> Allocated -> Starting -> Running -> Completed
    store.advanceJobState(orgA, job.id, actor, 'req_adv_1');
    store.advanceJobState(orgA, job.id, actor, 'req_adv_2');
    store.advanceJobState(orgA, job.id, actor, 'req_adv_3');
    store.advanceJobState(orgA, job.id, actor, 'req_adv_4');
    const completed = store.advanceJobState(orgA, job.id, actor, 'req_adv_5');
    expect(completed.state).toBe('Completed');
    expect(completed.outputAvailable).toBe(true);
    expect(store.getJobOutput(orgA, job.id).available).toBe(true);

    // Test cancellation path
    const job2 = store.submitJob(orgA, actor, 'req_job_2', {
      projectId: 'proj_baltic_hydro_sim',
      name: 'cancel-sim',
      regionId: 'eu-sim-nord-1',
      schedulerBackend: 'local-queue-sim',
      workloadImage: 'registry.sim.aureom.eu/ocean/nemo-solver:4.2.1-signed',
      command: 'python3 run.py',
      cpuCores: 2,
      gpuCount: 0,
      memoryGiB: 8,
      runtimeLimitSeconds: 300,
      inputUri: 's3://baltic-datasets-nord/inputs/baltic_grid_sample.csv',
      outputUri: 's3://baltic-datasets-nord/outputs/',
      queueClass: 'throughput',
    });
    const cancelled = store.cancelJob(orgA, job2.id, actor, 'req_cancel');
    expect(cancelled.state).toBe('Cancelled');
    expect(cancelled.outputAvailable).toBe(false);
  });

  it('keeps snapshots distinct from independent backups and validates subnet CIDR overlap & firewall', () => {
    const store = new ControlPlaneStore({persistPath: null});
    const snap = store.createSnapshot(orgA, 'vol_baltic_scratch', 'snap-test', actor, 'req_snap');
    expect(snap.isIndependentBackup).toBe(false);

    expect(() =>
      store.addSubnet(orgA, 'net_baltic_priv', actor, 'req_sub_overlap', {
        name: 'overlap',
        cidr: '10.42.10.0/25',
      }),
    ).toThrowError(/overlaps/i);

    expect(() =>
      store.addSecurityGroupRule(orgA, 'sg_baltic_restricted', actor, 'req_fw_open', {
        protocol: 'tcp',
        portRange: '22',
        sourceCidr: '0.0.0.0/0',
        description: 'Open SSH',
      }),
    ).toThrowError(/denied by default policy/i);
  });

  it('prevents duplicate metering after retries and preserves decimal EUR invoice precision', () => {
    const store = new ControlPlaneStore({persistPath: null});
    const first = store.runMeteringCycle(orgA, 'proj_baltic_hydro_sim', '2026-11-20T12:00Z', actor, 'req_m1');
    expect(first.createdEntries.length).toBeGreaterThan(0);
    expect(first.skippedDuplicates).toBe(0);

    // Retry same metering period key -> 0 created, all skipped
    const retry = store.runMeteringCycle(orgA, 'proj_baltic_hydro_sim', '2026-11-20T12:00Z', actor, 'req_m2');
    expect(retry.createdEntries.length).toBe(0);
    expect(retry.skippedDuplicates).toBe(first.createdEntries.length);

    const invoice = store.generateInvoice(orgA, 'proj_baltic_hydro_sim', actor, 'req_inv', 'fr');
    expect(invoice.currency).toBe('EUR');
    expect(invoice.status).toBe('IssuedInvoice');
    expect(Number(invoice.totalEur)).toBeGreaterThan(Number(invoice.subtotalEur));
    expect(store.listEmailOutbox(orgA)[0]?.locale).toBe('fr');
  });

  it('handles host failure simulation, post-restart reconciliation, and safe deletion preserving storage', () => {
    const store = new ControlPlaneStore({persistPath: null});
    const sim = store.simulateHostFailure('host-nord-01', actor, 'req_fail', orgA, 'de');
    expect(sim.host.state).toBe('Failed');
    expect(sim.affectedInstances).toBeGreaterThan(0);
    expect(store.listEmailOutbox(orgA)[0]?.locale).toBe('de');

    const recon = store.reconcileAfterRestart('restart-worker', orgA);
    expect(recon.failedCount).toBeGreaterThan(0);

    // Delete instance without deleting independent volume or bucket data
    store.transitionInstance(orgA, 'inst_baltic_prep_01', 'delete', actor, 'req_del');
    const storage = store.listStorage(orgA, 'proj_baltic_hydro_sim');
    expect(storage.volumes.length).toBeGreaterThan(0);
    expect(storage.volumes[0].status).toBe('Available');
    expect(storage.buckets[0].objects.length).toBeGreaterThan(0);
  });
});
