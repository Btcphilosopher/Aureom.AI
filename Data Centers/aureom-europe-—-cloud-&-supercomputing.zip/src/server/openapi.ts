export const OPENAPI_SPEC = {
  openapi: '3.1.0',
  info: {
    title: 'AUREOM EUROPE Control Plane API (Demonstration)',
    version: '2026.11-demo',
    description:
      'Multilingual European cloud, GPU, batch HPC, storage, and billing control-plane demonstration API. Uses synthetic credentials and simulated regional adapters.',
  },
  servers: [{url: '/api', description: 'Local Demonstration Control Plane'}],
  components: {
    securitySchemes: {
      DemoScopedBearer: {
        type: 'http',
        scheme: 'bearer',
        description: 'Synthetic scoped API key (prefix ak_demo_*)',
      },
    },
    schemas: {
      StructuredError: {
        type: 'object',
        properties: {
          error: {
            type: 'object',
            properties: {
              code: {type: 'string'},
              message: {type: 'string'},
              requestId: {type: 'string'},
            },
          },
        },
      },
    },
  },
  paths: {
    '/organisations': {get: {summary: 'List Organisations', tags: ['Organisations']}},
    '/projects': {
      get: {summary: 'List Projects (paginated)', tags: ['Projects']},
      post: {summary: 'Create Project (idempotent)', tags: ['Projects']},
    },
    '/projects/{projectId}/quotas': {get: {summary: 'Get Project Quotas & Utilisation', tags: ['Quotas']}},
    '/instances': {
      get: {summary: 'List Compute Instances', tags: ['Instances']},
      post: {summary: 'Request Compute Instance Provisioning', tags: ['Instances']},
    },
    '/gpus': {
      get: {summary: 'List GPU Allocations', tags: ['GPU allocations']},
      post: {summary: 'Request GPU Allocation', tags: ['GPU allocations']},
    },
    '/jobs': {
      get: {summary: 'List HPC Batch Jobs', tags: ['Jobs']},
      post: {summary: 'Submit Batch Job', tags: ['Jobs']},
    },
    '/storage/volumes': {
      get: {summary: 'List Block Volumes', tags: ['Volumes']},
      post: {summary: 'Create Block Volume', tags: ['Volumes']},
    },
    '/storage/buckets': {
      get: {summary: 'List Object Buckets', tags: ['Buckets']},
      post: {summary: 'Create Object Bucket', tags: ['Buckets']},
    },
    '/networks': {get: {summary: 'List Networks, Subnets & Security Groups', tags: ['Networks']}},
    '/usage': {get: {summary: 'Get Decimal EUR Usage Ledger', tags: ['Usage']}},
    '/invoices': {
      get: {summary: 'List Issued Demonstration Invoices', tags: ['Invoices']},
      post: {summary: 'Finalise Usage & Generate Invoice', tags: ['Invoices']},
    },
    '/audit-events': {get: {summary: 'List Immutable Audit Events', tags: ['Audit events']}},
  },
};
