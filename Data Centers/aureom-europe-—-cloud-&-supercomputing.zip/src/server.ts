import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, {type NextFunction, type Request, type Response} from 'express';
import {randomUUID} from 'node:crypto';
import {join} from 'node:path';
import {runComputeAssistant} from './server/gemini-assistant';
import {OPENAPI_SPEC} from './server/openapi';
import {ControlPlaneError, ControlPlaneStore, canRoleMutate, paginate} from './server/store';
import type {LocaleCode, UserRole} from './server/types';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();
const store = new ControlPlaneStore();

app.use(express.json({limit: '2mb'}));

// Attach X-Request-Id and structured context to every /api request
app.use('/api', (req: Request, res: Response, next: NextFunction) => {
  const reqId = (req.headers['x-request-id'] as string | undefined) || `req_${randomUUID().slice(0, 12)}`;
  res.setHeader('X-Request-Id', reqId);
  res.locals['requestId'] = reqId;
  res.locals['orgId'] = (req.headers['x-aureom-org'] as string | undefined) || 'org_ncrc_eu_demo';
  res.locals['actor'] = (req.headers['x-aureom-actor'] as string | undefined) || 'astrid.lindqvist@ncrc-demo.example.eu';
  res.locals['role'] = ((req.headers['x-aureom-role'] as UserRole | undefined) || 'org_admin');
  res.locals['locale'] = ((req.headers['x-aureom-locale'] as LocaleCode | undefined) || 'en');
  next();
});

function requireWritePermission(res: Response): void {
  const role = res.locals['role'] as UserRole;
  if (!canRoleMutate(role)) {
    throw new ControlPlaneError(403, 'READ_ONLY_ROLE', 'Auditor role is read-only and cannot mutate infrastructure.');
  }
}

function withIdempotency(
  req: Request,
  res: Response,
  handler: () => {status?: number; body: unknown},
): void {
  const idemKey = req.headers['idempotency-key'] as string | undefined;
  if (idemKey) {
    const cached = store.getIdempotentResponse(`${req.method}:${req.path}:${idemKey}`);
    if (cached) {
      res.status(cached.status).json(cached.body);
      return;
    }
  }
  const result = handler();
  const status = result.status ?? 200;
  if (idemKey) {
    store.saveIdempotentResponse(`${req.method}:${req.path}:${idemKey}`, status, result.body);
  }
  res.status(status).json(result.body);
}

// Public catalog, OpenAPI & status endpoints
app.get('/api/openapi.json', (_req, res) => {
  res.json(OPENAPI_SPEC);
});

app.get('/api/catalog', (_req, res) => {
  res.json(store.getCatalog());
});

app.get('/api/status', (_req, res) => {
  res.json(store.getPublicStatus());
});

app.post('/api/contact', (req, res) => {
  const inquiry = store.recordContactInquiry(req.body);
  res.status(201).json(inquiry);
});

// Console & Resource APIs (Organisations, Projects, Quotas, Instances, GPUs, Jobs, Storage, Networking, Usage, Invoices, Audit)
app.get('/api/organisations', (_req, res) => {
  res.json({items: store.listOrganisations()});
});

app.get('/api/console/overview', (req, res) => {
  const orgId = res.locals['orgId'] as string;
  const projectId = req.query['projectId'] as string | undefined;
  res.json(store.getOverview(orgId, projectId));
});

app.get('/api/projects', (req, res) => {
  const orgId = res.locals['orgId'] as string;
  res.json(paginate(store.listProjects(orgId), req.query['limit'], req.query['offset']));
});

app.post('/api/projects', (req, res) => {
  requireWritePermission(res);
  withIdempotency(req, res, () => {
    const project = store.createProject(
      res.locals['orgId'] as string,
      res.locals['actor'] as string,
      res.locals['requestId'] as string,
      req.body,
    );
    return {status: 201, body: project};
  });
});

app.get('/api/projects/:projectId/quotas', (req, res) => {
  res.json(store.getQuotaUsage(res.locals['orgId'] as string, String(req.params['projectId'])));
});

app.put('/api/projects/:projectId/budget-alert', (req, res) => {
  requireWritePermission(res);
  const alert = store.setBudgetAlert(
    res.locals['orgId'] as string,
    String(req.params['projectId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.json(alert);
});

app.get('/api/instances', (req, res) => {
  const list = store.listInstances(
    res.locals['orgId'] as string,
    req.query['projectId'] as string | undefined,
  );
  res.json(paginate(list, req.query['limit'], req.query['offset']));
});

app.post('/api/instances', (req, res) => {
  requireWritePermission(res);
  withIdempotency(req, res, () => {
    const inst = store.createInstance(
      res.locals['orgId'] as string,
      res.locals['actor'] as string,
      res.locals['requestId'] as string,
      req.body,
    );
    return {status: 202, body: inst};
  });
});

app.post('/api/instances/:instanceId/:action', (req, res) => {
  requireWritePermission(res);
  const action = String(req.params['action']);
  if (action !== 'stop' && action !== 'start' && action !== 'delete') {
    throw new ControlPlaneError(400, 'INVALID_ACTION', `Unsupported instance action: ${action}`);
  }
  const inst = store.transitionInstance(
    res.locals['orgId'] as string,
    String(req.params['instanceId']),
    action,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(inst);
});

app.get('/api/gpus', (req, res) => {
  const list = store.listGpuAllocations(
    res.locals['orgId'] as string,
    req.query['projectId'] as string | undefined,
  );
  res.json(paginate(list, req.query['limit'], req.query['offset']));
});

app.post('/api/gpus', (req, res) => {
  requireWritePermission(res);
  const alloc = store.allocateGpu(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(alloc);
});

app.post('/api/gpus/:allocationId/release', (req, res) => {
  requireWritePermission(res);
  const alloc = store.releaseGpu(
    res.locals['orgId'] as string,
    String(req.params['allocationId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(alloc);
});

app.get('/api/jobs', (req, res) => {
  const list = store.listJobs(
    res.locals['orgId'] as string,
    req.query['projectId'] as string | undefined,
  );
  res.json(paginate(list, req.query['limit'], req.query['offset']));
});

app.post('/api/jobs', (req, res) => {
  requireWritePermission(res);
  withIdempotency(req, res, () => {
    const job = store.submitJob(
      res.locals['orgId'] as string,
      res.locals['actor'] as string,
      res.locals['requestId'] as string,
      req.body,
    );
    return {status: 202, body: job};
  });
});

app.post('/api/jobs/:jobId/advance', (req, res) => {
  requireWritePermission(res);
  const job = store.advanceJobState(
    res.locals['orgId'] as string,
    String(req.params['jobId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(job);
});

app.post('/api/jobs/:jobId/cancel', (req, res) => {
  requireWritePermission(res);
  const job = store.cancelJob(
    res.locals['orgId'] as string,
    String(req.params['jobId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(job);
});

app.get('/api/jobs/:jobId/output', (req, res) => {
  res.json(store.getJobOutput(res.locals['orgId'] as string, String(req.params['jobId'])));
});

app.get('/api/jobs/:jobId/slurm-script', (req, res) => {
  const job = store.listJobs(res.locals['orgId'] as string).find((j) => j.id === req.params['jobId']);
  if (!job) {
    throw new ControlPlaneError(404, 'JOB_NOT_FOUND', 'Batch job not found.');
  }
  res.json({script: store.schedulerAdapter.generateSlurmScript(job)});
});

app.get('/api/storage', (req, res) => {
  res.json(
    store.listStorage(
      res.locals['orgId'] as string,
      req.query['projectId'] as string | undefined,
    ),
  );
});

app.post('/api/storage/buckets', (req, res) => {
  requireWritePermission(res);
  const bucket = store.createBucket(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(bucket);
});

app.post('/api/storage/buckets/:bucketId/objects', (req, res) => {
  requireWritePermission(res);
  const bucket = store.uploadBucketObject(
    res.locals['orgId'] as string,
    String(req.params['bucketId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(bucket);
});

app.post('/api/storage/volumes', (req, res) => {
  requireWritePermission(res);
  const vol = store.createVolume(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(vol);
});

app.post('/api/storage/volumes/:volumeId/snapshots', (req, res) => {
  requireWritePermission(res);
  const snap = store.createSnapshot(
    res.locals['orgId'] as string,
    String(req.params['volumeId']),
    String(req.body?.name || 'manual-snapshot'),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.status(201).json(snap);
});

app.post('/api/storage/backups', (req, res) => {
  requireWritePermission(res);
  const bak = store.createIndependentBackup(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(bak);
});

app.get('/api/networks', (req, res) => {
  res.json(
    store.listNetworking(
      res.locals['orgId'] as string,
      req.query['projectId'] as string | undefined,
    ),
  );
});

app.post('/api/networks/:networkId/subnets', (req, res) => {
  requireWritePermission(res);
  const subnet = store.addSubnet(
    res.locals['orgId'] as string,
    String(req.params['networkId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(subnet);
});

app.post('/api/security-groups/:sgId/rules', (req, res) => {
  requireWritePermission(res);
  const sg = store.addSecurityGroupRule(
    res.locals['orgId'] as string,
    String(req.params['sgId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(sg);
});

app.post('/api/public-addresses', (req, res) => {
  requireWritePermission(res);
  const addr = store.allocatePublicAddress(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(addr);
});

app.get('/api/usage', (req, res) => {
  res.json(
    store.listUsage(
      res.locals['orgId'] as string,
      req.query['projectId'] as string | undefined,
    ),
  );
});

app.post('/api/metering/tick', (req, res) => {
  requireWritePermission(res);
  const periodKey = String(req.body?.periodKey || `hour-${new Date().toISOString().slice(0, 13)}`);
  const result = store.runMeteringCycle(
    res.locals['orgId'] as string,
    String(req.body?.projectId),
    periodKey,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(result);
});

app.get('/api/invoices', (req, res) => {
  const usage = store.listUsage(
    res.locals['orgId'] as string,
    req.query['projectId'] as string | undefined,
  );
  res.json(paginate(usage.invoices, req.query['limit'], req.query['offset']));
});

app.post('/api/invoices', (req, res) => {
  requireWritePermission(res);
  const inv = store.generateInvoice(
    res.locals['orgId'] as string,
    String(req.body?.projectId),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    (req.body?.locale as LocaleCode) || (res.locals['locale'] as LocaleCode),
  );
  res.status(201).json(inv);
});

app.post('/api/invoices/:invoiceId/pay', (req, res) => {
  requireWritePermission(res);
  const inv = store.markInvoicePaid(
    res.locals['orgId'] as string,
    String(req.params['invoiceId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(inv);
});

app.get('/api/access', (_req, res) => {
  const orgId = res.locals['orgId'] as string;
  res.json({
    members: store.listMembers(orgId),
    apiKeys: store.listApiKeys(orgId),
  });
});

app.post('/api/access/api-keys', (req, res) => {
  requireWritePermission(res);
  const created = store.createApiKey(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    req.body,
  );
  res.status(201).json(created);
});

app.post('/api/access/api-keys/:keyId/revoke', (req, res) => {
  requireWritePermission(res);
  const key = store.revokeApiKey(
    res.locals['orgId'] as string,
    String(req.params['keyId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
  );
  res.json(key);
});

app.get('/api/audit-events', (req, res) => {
  res.json(paginate(store.listAuditEvents(res.locals['orgId'] as string), req.query['limit'], req.query['offset']));
});

app.get('/api/support', (_req, res) => {
  const orgId = res.locals['orgId'] as string;
  res.json({
    tickets: store.listSupportTickets(orgId),
    emails: store.listEmailOutbox(orgId),
  });
});

app.post('/api/support/tickets', (req, res) => {
  requireWritePermission(res);
  const ticket = store.createSupportTicket(
    res.locals['orgId'] as string,
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    {
      ...req.body,
      locale: (req.body?.locale as LocaleCode) || (res.locals['locale'] as LocaleCode),
    },
  );
  res.status(201).json(ticket);
});

// Infrastructure Operations Telemetry & Fault Simulation
app.get('/api/operations/telemetry', (_req, res) => {
  res.json(store.getOperationsTelemetry());
});

app.post('/api/operations/hosts/:hostId/simulate-failure', (req, res) => {
  requireWritePermission(res);
  const result = store.simulateHostFailure(
    String(req.params['hostId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    res.locals['orgId'] as string,
    res.locals['locale'] as LocaleCode,
  );
  res.json(result);
});

app.post('/api/operations/hosts/:hostId/recover', (req, res) => {
  requireWritePermission(res);
  const host = store.recoverHost(
    String(req.params['hostId']),
    res.locals['actor'] as string,
    res.locals['requestId'] as string,
    res.locals['orgId'] as string,
  );
  res.json(host);
});

app.post('/api/operations/reconcile', (_req, res) => {
  requireWritePermission(res);
  const summary = store.reconcileAfterRestart(
    res.locals['actor'] as string,
    res.locals['orgId'] as string,
  );
  res.json(summary);
});

app.post('/api/demo/reset', (_req, res) => {
  store.resetDemoState();
  res.json({reset: true});
});

// Server-side Gemini 4.0 AI Compute Assistant
app.post('/api/assistant/query', async (req, res, next) => {
  try {
    const result = await runComputeAssistant(store, {
      orgId: res.locals['orgId'] as string,
      projectId: String(req.body?.projectId || 'proj_baltic_hydro_sim'),
      locale: (req.body?.locale as LocaleCode) || (res.locals['locale'] as LocaleCode),
      prompt: String(req.body?.prompt || ''),
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

// Structured error handler for /api/*
app.use('/api', (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  void _next;
  const requestId = (res.locals['requestId'] as string | undefined) || `req_${randomUUID().slice(0, 8)}`;
  if (err instanceof ControlPlaneError) {
    res.status(err.statusCode).json({
      error: {
        code: err.code,
        message: err.message,
        requestId,
        details: err.details,
      },
    });
    return;
  }
  const message = err instanceof Error ? err.message : 'Internal control-plane error';
  res.status(500).json({
    error: {
      code: 'INTERNAL_CONTROL_PLANE_ERROR',
      message,
      requestId,
    },
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
