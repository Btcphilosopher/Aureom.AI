'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  DataCenterState,
  DigitalTwinVisualMode,
  CameraLevel,
  RackState,
} from '@/lib/types';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Layers,
  Flame,
  Zap,
  Wind,
  Network,
  X,
  Server,
} from 'lucide-react';

interface DigitalTwinCanvasProps {
  state: DataCenterState;
  visualMode: DigitalTwinVisualMode;
  onSelectVisualMode: (mode: DigitalTwinVisualMode) => void;
  isThermalMode: boolean;
  reducedMotion: boolean;
  selectedRackId: string | null;
  onSelectRack: (rackId: string | null) => void;
}

// Grid Draw Helper
function drawGrid(ctx: CanvasRenderingContext2D, sizeX: number, sizeY: number, isThermal: boolean) {
  ctx.strokeStyle = isThermal ? 'rgba(245, 158, 11, 0.08)' : 'rgba(0, 240, 255, 0.06)';
  ctx.lineWidth = 1;

  const step = 40;
  for (let x = -sizeX / 2; x <= sizeX / 2; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, -sizeY / 2);
    ctx.lineTo(x, sizeY / 2);
    ctx.stroke();
  }
  for (let y = -sizeY / 2; y <= sizeY / 2; y += step) {
    ctx.beginPath();
    ctx.moveTo(-sizeX / 2, y);
    ctx.lineTo(sizeX / 2, y);
    ctx.stroke();
  }
}

// Substation Box Helper
function drawSubstation(ctx: CanvasRenderingContext2D, x: number, y: number, mw: number, isThermal: boolean) {
  const w = 180;
  const h = 100;
  ctx.fillStyle = isThermal ? '#2A170A' : '#101B2B';
  ctx.strokeStyle = isThermal ? '#F59E0B' : '#00F0FF';
  ctx.lineWidth = 2;

  ctx.fillRect(x - w / 2, y - h / 2, w, h);
  ctx.strokeRect(x - w / 2, y - h / 2, w, h);

  ctx.fillStyle = isThermal ? '#FBA518' : '#00F0FF';
  ctx.font = '11px monospace';
  ctx.fillText('PRIMARY SUBSTATION', x - w / 2 + 10, y - h / 2 + 25);
  ctx.font = 'bold 16px monospace';
  ctx.fillText(`${mw.toFixed(1)} MW`, x - w / 2 + 10, y - h / 2 + 55);

  // Transformers
  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(x - w / 2 + 15 + i * 50, y + 10, 40, 25);
    ctx.strokeStyle = isThermal ? '#F59E0B' : '#00F0FF';
    ctx.strokeRect(x - w / 2 + 15 + i * 50, y + 10, 40, 25);
  }
}

// Cooling Plant Box Helper
function drawCoolingPlant(ctx: CanvasRenderingContext2D, x: number, y: number, cooling: any, isThermal: boolean) {
  const w = 180;
  const h = 100;
  ctx.fillStyle = isThermal ? '#2A1208' : '#0C1A2E';
  ctx.strokeStyle = isThermal ? '#EF4444' : '#3B82F6';
  ctx.lineWidth = 2;

  ctx.fillRect(x - w / 2, y - h / 2, w, h);
  ctx.strokeRect(x - w / 2, y - h / 2, w, h);

  ctx.fillStyle = isThermal ? '#F87171' : '#60A5FA';
  ctx.font = '11px monospace';
  ctx.fillText('MECHANICAL COOLING PLANT', x - w / 2 + 10, y - h / 2 + 25);
  ctx.font = 'bold 16px monospace';
  ctx.fillText(`${cooling.coolingLoadMw.toFixed(1)} MW`, x - w / 2 + 10, y - h / 2 + 55);

  // Chillers
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = i < cooling.chillersActive ? '#1E3A5F' : '#1E293B';
    ctx.fillRect(x - w / 2 + 10 + i * 40, y + 10, 32, 25);
    ctx.strokeStyle = i < cooling.chillersActive ? '#60A5FA' : '#64748B';
    ctx.strokeRect(x - w / 2 + 10 + i * 40, y + 10, 32, 25);
  }
}

// Data Hall Box Helper
function drawDataHall(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  title: string,
  building: any,
  isThermal: boolean,
  selectedId: string | null,
  onSelect: (id: string | null) => void
) {
  const w = 340;
  const h = 260;

  ctx.fillStyle = isThermal ? '#1A0E08' : '#0E1726';
  ctx.strokeStyle = isThermal ? '#F59E0B' : '#00F0FF';
  ctx.lineWidth = 2;

  ctx.fillRect(x - w / 2, y - h / 2, w, h);
  ctx.strokeRect(x - w / 2, y - h / 2, w, h);

  ctx.fillStyle = isThermal ? '#F59E0B' : '#00F0FF';
  ctx.font = 'bold 12px monospace';
  ctx.fillText(title, x - w / 2 + 15, y - h / 2 + 25);

  // Render Rack Matrix inside Data Hall
  const racks = building?.floors[0]?.racks || [];
  const cols = 6;
  const rows = 4;
  const rw = 42;
  const rh = 38;
  const startX = x - w / 2 + 20;
  const startY = y - h / 2 + 45;

  racks.forEach((rack: RackState, idx: number) => {
    const r = Math.floor(idx / cols);
    const c = idx % cols;
    if (r >= rows) return;

    const rx = startX + c * (rw + 8);
    const ry = startY + r * (rh + 10);

    const isSelected = rack.id === selectedId;

    // Color logic based on Thermal Mode or Status
    let color = '#00FF66';
    if (isThermal) {
      if (rack.temperatureOutlet > 34) color = '#EF4444';
      else if (rack.temperatureOutlet > 30) color = '#F59E0B';
      else color = '#3B82F6';
    } else {
      if (rack.status === 'CRITICAL') color = '#EF4444';
      else if (rack.status === 'WARNING') color = '#F59E0B';
      else color = '#00F0FF';
    }

    ctx.fillStyle = isSelected ? '#1E293B' : '#111827';
    ctx.fillRect(rx, ry, rw, rh);

    ctx.strokeStyle = isSelected ? '#00FF66' : color;
    ctx.lineWidth = isSelected ? 2.5 : 1.2;
    ctx.strokeRect(rx, ry, rw, rh);

    // Rack Label
    ctx.fillStyle = '#94A3B8';
    ctx.font = '8px monospace';
    ctx.fillText(rack.id.slice(-4), rx + 4, ry + 12);

    // GPU Activity Pulse LEDs
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(rx + rw - 8, ry + 8, 3, 0, Math.PI * 2);
    ctx.fill();

    // Power Level Bar
    const pRatio = rack.powerKw / rack.maxPowerKw;
    ctx.fillStyle = color;
    ctx.fillRect(rx + 4, ry + rh - 8, (rw - 8) * pRatio, 3);
  });
}

// Power Particle Flow
function drawPowerFlows(
  ctx: CanvasRenderingContext2D,
  sub: { x: number; y: number },
  hallA: { x: number; y: number },
  hallB: { x: number; y: number },
  phase: number,
  mw: number
) {
  const lines = [
    { start: sub, end: hallA },
    { start: sub, end: hallB },
  ];

  lines.forEach(({ start, end }) => {
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.3)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();

    const particles = 8;
    for (let i = 0; i < particles; i++) {
      const p = (phase + i / particles) % 1.0;
      const px = start.x + (end.x - start.x) * p;
      const py = start.y + (end.y - start.y) * p;

      ctx.fillStyle = '#00F0FF';
      ctx.shadowColor = '#00F0FF';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  });
}

// Coolant Particle Flow
function drawCoolingFlows(
  ctx: CanvasRenderingContext2D,
  cool: { x: number; y: number },
  hallA: { x: number; y: number },
  hallB: { x: number; y: number },
  phase: number,
  mw: number
) {
  const lines = [
    { start: cool, end: hallA },
    { start: cool, end: hallB },
  ];

  lines.forEach(({ start, end }) => {
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();

    const particles = 8;
    for (let i = 0; i < particles; i++) {
      const p = (phase + i / particles) % 1.0;
      const px = start.x + (end.x - start.x) * p;
      const py = start.y + (end.y - start.y) * p;

      ctx.fillStyle = '#60A5FA';
      ctx.shadowColor = '#3B82F6';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  });
}

// Network Flow
function drawNetworkFlows(
  ctx: CanvasRenderingContext2D,
  hallA: { x: number; y: number },
  hallB: { x: number; y: number },
  phase: number,
  traffic: number
) {
  ctx.strokeStyle = 'rgba(168, 85, 247, 0.4)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(hallA.x, hallA.y);
  ctx.lineTo(hallB.x, hallB.y);
  ctx.stroke();

  const particles = 10;
  for (let i = 0; i < particles; i++) {
    const p = (phase + i / particles) % 1.0;
    const px = hallA.x + (hallB.x - hallA.x) * p;
    const py = hallA.y + (hallB.y - hallA.y) * p;

    ctx.fillStyle = '#C084FC';
    ctx.beginPath();
    ctx.arc(px, py, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function DigitalTwinCanvas({
  state,
  visualMode,
  onSelectVisualMode,
  isThermalMode,
  reducedMotion,
  selectedRackId,
  onSelectRack,
}: DigitalTwinCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Camera state
  const [camera, setCamera] = useState({
    x: 0,
    y: 0,
    zoom: 1.0,
    rotationDeg: 45,
    level: 'CAMPUS' as CameraLevel,
  });

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [particlePhase, setParticlePhase] = useState(0);

  // Main Render Logic
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.save();
    ctx.clearRect(0, 0, width, height);

    // Dark Industrial NOC Canvas background
    const bgGrad = ctx.createRadialGradient(
      width / 2,
      height / 2,
      50,
      width / 2,
      height / 2,
      width / 1.2
    );
    bgGrad.addColorStop(0, '#0F1626');
    bgGrad.addColorStop(1, '#070A12');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Apply Camera Transform
    const cx = width / 2 + camera.x;
    const cy = height / 2 + camera.y;

    ctx.translate(cx, cy);
    ctx.scale(camera.zoom, camera.zoom);

    // Draw Grid floor lines
    drawGrid(ctx, 1600, 1200, isThermalMode);

    // Draw Infrastructure Modules
    const subPos = { x: -380, y: 280 };
    drawSubstation(ctx, subPos.x, subPos.y, state.power.substationMw, isThermalMode);

    const coolPos = { x: 380, y: 280 };
    drawCoolingPlant(ctx, coolPos.x, coolPos.y, state.cooling, isThermalMode);

    const hallAPos = { x: -220, y: -120 };
    drawDataHall(
      ctx,
      hallAPos.x,
      hallAPos.y,
      'DATA HALL A (NORTH)',
      state.buildings[0],
      isThermalMode,
      selectedRackId,
      onSelectRack
    );

    const hallBPos = { x: 220, y: -120 };
    drawDataHall(
      ctx,
      hallBPos.x,
      hallBPos.y,
      'DATA HALL B (SOUTH)',
      state.buildings[1],
      isThermalMode,
      selectedRackId,
      onSelectRack
    );

    // Flow Lines
    if (visualMode === 'POWER_FLOW' || visualMode === 'STANDARD') {
      drawPowerFlows(ctx, subPos, hallAPos, hallBPos, particlePhase, state.power.itLoadMw);
    }

    if (visualMode === 'COOLING_FLOW' || visualMode === 'STANDARD') {
      drawCoolingFlows(ctx, coolPos, hallAPos, hallBPos, particlePhase, state.cooling.coolingLoadMw);
    }

    if (visualMode === 'NETWORK_FLOW') {
      drawNetworkFlows(ctx, hallAPos, hallBPos, particlePhase, state.network.totalTrafficTbps);
    }

    ctx.restore();
  }, [camera, visualMode, isThermalMode, state, particlePhase, selectedRackId, onSelectRack]);

  // Animation frame loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      if (!reducedMotion) {
        setParticlePhase((prev) => (prev + dt * 1.5) % 1.0);
      }

      drawCanvas();
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [drawCanvas, reducedMotion]);

  // Handle Canvas Resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * (window.devicePixelRatio || 1);
      canvas.height = rect.height * (window.devicePixelRatio || 1);
      drawCanvas();
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [drawCanvas]);

  // Mouse Interaction handlers for Pan & Zoom & Click
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - camera.x, y: e.clientY - camera.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setCamera((prev) => ({
      ...prev,
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    setCamera((prev) => ({
      ...prev,
      zoom: Math.min(4.0, Math.max(0.4, prev.zoom * zoomFactor)),
    }));
  };

  // Find selected rack details
  const selectedRack = state.buildings
    .flatMap((b) => b.floors)
    .flatMap((f) => f.racks)
    .find((r) => r.id === selectedRackId);

  return (
    <div className="relative w-full h-full bg-[#080B12] overflow-hidden select-none flex">
      {/* Visual Mode Selector Bar */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 bg-[#0F172A]/90 p-1.5 rounded-lg border border-[#1E293B] backdrop-blur-md shadow-xl">
        {(['STANDARD', 'POWER_FLOW', 'COOLING_FLOW', 'NETWORK_FLOW', 'THERMAL_HEATMAP'] as DigitalTwinVisualMode[]).map(
          (mode) => {
            const isActive = visualMode === mode;
            return (
              <button
                key={mode}
                onClick={() => onSelectVisualMode(mode)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono transition-all ${
                  isActive
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-500 font-bold shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {mode === 'POWER_FLOW' && <Zap className="w-3.5 h-3.5 text-yellow-400" />}
                {mode === 'COOLING_FLOW' && <Wind className="w-3.5 h-3.5 text-blue-400" />}
                {mode === 'NETWORK_FLOW' && <Network className="w-3.5 h-3.5 text-purple-400" />}
                {mode === 'THERMAL_HEATMAP' && <Flame className="w-3.5 h-3.5 text-amber-400" />}
                {mode === 'STANDARD' && <Layers className="w-3.5 h-3.5 text-cyan-400" />}
                <span>{mode.replace('_', ' ')}</span>
              </button>
            );
          }
        )}
      </div>

      {/* Floating Camera Toolbar */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2 bg-[#0F172A]/90 p-2 rounded-lg border border-[#1E293B] backdrop-blur-md shadow-xl text-slate-300">
        <button
          onClick={() => setCamera((prev) => ({ ...prev, zoom: Math.min(4.0, prev.zoom * 1.2) }))}
          className="p-1.5 hover:bg-slate-800 rounded text-cyan-400 hover:text-cyan-300"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setCamera((prev) => ({ ...prev, zoom: Math.max(0.4, prev.zoom * 0.8) }))}
          className="p-1.5 hover:bg-slate-800 rounded text-cyan-400 hover:text-cyan-300"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => setCamera((prev) => ({ ...prev, x: 0, y: 0, zoom: 1.0 }))}
          className="p-1.5 hover:bg-slate-800 rounded text-cyan-400 hover:text-cyan-300"
          title="Reset Camera"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Main Interactive Canvas */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Selected Rack Drill-down Side Panel */}
      {selectedRack && (
        <div className="absolute top-4 right-16 z-20 w-80 bg-[#0C121E]/95 border border-cyan-500/50 rounded-lg p-4 font-mono shadow-2xl backdrop-blur-md text-white animate-in slide-in-from-right duration-300">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              <span className="font-bold text-sm text-cyan-300">{selectedRack.name}</span>
            </div>
            <button
              onClick={() => onSelectRack(null)}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center bg-slate-900/80 p-2 rounded border border-slate-800">
              <span className="text-slate-400">POWER DRAW</span>
              <span className="text-cyan-300 font-bold">{selectedRack.powerKw} kW</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/80 p-2 rounded border border-slate-800">
              <span className="text-slate-400">INLET / OUTLET TEMP</span>
              <span className="text-amber-400 font-bold">
                {selectedRack.temperatureInlet}°C / {selectedRack.temperatureOutlet}°C
              </span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/80 p-2 rounded border border-slate-800">
              <span className="text-slate-400">GPU COUNT</span>
              <span className="text-purple-400 font-bold">{selectedRack.gpuCount}x NVIDIA H100</span>
            </div>
            <div className="flex justify-between items-center bg-slate-900/80 p-2 rounded border border-slate-800">
              <span className="text-slate-400">AVG GPU UTIL</span>
              <span className="text-emerald-400 font-bold">{selectedRack.gpuUtilizationAvg}%</span>
            </div>

            {/* Server Chassis Layer Breakdown */}
            <div className="pt-2">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5 font-bold">
                CHASSIS SERVER LAYERS (4U)
              </span>
              <div className="space-y-1.5">
                {selectedRack.servers.map((server) => (
                  <div
                    key={server.id}
                    className="p-2 bg-[#111827] border border-slate-800 rounded flex items-center justify-between"
                  >
                    <div>
                      <span className="text-[11px] text-slate-200 block font-semibold">{server.name}</span>
                      <span className="text-[9px] text-slate-500">U{server.positionU} • {server.powerWatts}W</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                      {server.cpuUtilization}% CPU
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
