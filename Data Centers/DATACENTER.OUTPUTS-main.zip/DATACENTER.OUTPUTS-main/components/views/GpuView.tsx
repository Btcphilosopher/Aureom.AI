'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Cpu, Zap, Activity, Flame, Sparkles } from 'lucide-react';

interface GpuViewProps {
  state: DataCenterState;
}

export function GpuView({ state }: GpuViewProps) {
  const clusters = [
    {
      id: 'CLUSTER-01',
      name: 'LLM PRE-TRAINING CLUSTER 01 (NVIDIA H100 SXM5)',
      nodeCount: 480,
      utilizationPercent: 87.4,
      powerDrawMw: 8.1,
      tempAvgC: 76.2,
      flopsPeta: 474.7,
      status: 'HIGH LOAD',
    },
    {
      id: 'CLUSTER-02',
      name: 'MULTI-MODAL REASONING CLUSTER 02 (NVIDIA H200)',
      nodeCount: 480,
      utilizationPercent: 75.8,
      powerDrawMw: 7.2,
      tempAvgC: 71.4,
      flopsPeta: 474.7,
      status: 'NORMAL',
    },
  ];

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-purple-300 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-400" />
            AI COMPUTE & GPU ACCELERATOR CLUSTERS
          </h2>
          <span className="text-xs text-slate-400">
            NVIDIA H100 SXM5 / H200 HGX nodes, Tensor FLOPS throughput & dynamic thermal load
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">TOTAL AI COMPUTE POWER</span>
          <div className="text-xl font-bold text-purple-400">15.3 MW</div>
        </div>
      </div>

      {/* Clusters List */}
      <div className="space-y-6">
        {clusters.map((cluster) => (
          <div
            key={cluster.id}
            className="bg-[#0C121E] border border-purple-500/40 rounded-lg p-5 space-y-4 shadow-lg"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs text-purple-400 font-bold block">{cluster.id}</span>
                <h3 className="font-bold text-sm text-slate-100">{cluster.name}</h3>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">POWER DRAW</span>
                  <span className="text-purple-300 font-bold text-sm">{cluster.powerDrawMw} MW</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">UTILISATION</span>
                  <span className="text-emerald-400 font-bold text-sm">{cluster.utilizationPercent}%</span>
                </div>
              </div>
            </div>

            {/* Pulsing GPU Node Matrix Representation */}
            <div>
              <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
                <span>ACTIVE GPU NODES ({cluster.nodeCount} UNITS)</span>
                <span className="text-purple-400 animate-pulse font-semibold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> PULSE RATE: {(cluster.utilizationPercent / 20).toFixed(1)} Hz
                </span>
              </div>

              <div className="grid grid-cols-12 sm:grid-cols-24 gap-1.5 p-3 bg-[#080B12] rounded border border-slate-800">
                {Array.from({ length: 96 }).map((_, idx) => {
                  const isHigh = idx % 5 === 0;
                  return (
                    <div
                      key={idx}
                      className={`h-5 rounded-xs border transition-all ${
                        isHigh
                          ? 'bg-purple-600 border-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.5)] animate-pulse'
                          : 'bg-purple-950/60 border-purple-800/80 text-purple-400'
                      }`}
                      title={`Node ${idx + 1}: ${cluster.utilizationPercent}%`}
                    />
                  );
                })}
              </div>
            </div>

            {/* Specs Footer */}
            <div className="grid grid-cols-3 gap-4 pt-2 text-xs text-slate-400">
              <div className="bg-[#111827] p-2.5 rounded border border-slate-800 flex justify-between">
                <span>TENSOR THROUGHPUT:</span>
                <span className="text-slate-200 font-bold">{cluster.flopsPeta} PFLOPS</span>
              </div>
              <div className="bg-[#111827] p-2.5 rounded border border-slate-800 flex justify-between">
                <span>AVG GPU TEMP:</span>
                <span className="text-amber-400 font-bold">{cluster.tempAvgC} °C</span>
              </div>
              <div className="bg-[#111827] p-2.5 rounded border border-slate-800 flex justify-between">
                <span>VRAM ALLOCATION:</span>
                <span className="text-purple-300 font-bold">76.8 TB / 76.8 TB</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
