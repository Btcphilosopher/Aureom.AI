'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Flame, Thermometer, Cloud, Droplets, Wind } from 'lucide-react';

interface ThermalViewProps {
  state: DataCenterState;
}

export function ThermalView({ state }: ThermalViewProps) {
  const racks = state.buildings.flatMap((b) => b.floors).flatMap((f) => f.racks);

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" />
            FACILITY THERMAL MAP & AMBIENT ENVIRONMENT
          </h2>
          <span className="text-xs text-slate-400">
            Surface rack temperature interpolation, cold/hot aisle isolation & environmental humidity
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400 font-bold block">OUTDOOR WEATHER</span>
          <div className="text-sm font-bold text-amber-300">21.4°C • 58% RH</div>
        </div>
      </div>

      {/* Legend Bar */}
      <div className="flex items-center justify-between bg-[#0C121E] border border-slate-800 p-3 rounded-lg text-xs font-mono">
        <span className="text-slate-400 font-bold">THERMAL GRADIENT LEGEND:</span>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-blue-500 inline-block"></span>
            <span className="text-slate-300">COOL (&lt; 24°C)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-emerald-500 inline-block"></span>
            <span className="text-slate-300">NORMAL (24-28°C)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-yellow-500 inline-block"></span>
            <span className="text-slate-300">WARM (28-32°C)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-amber-500 inline-block"></span>
            <span className="text-slate-300">HOT (32-36°C)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-rose-500 inline-block"></span>
            <span className="text-slate-300">CRITICAL (&gt; 36°C)</span>
          </div>
        </div>
      </div>

      {/* Facility 2D Thermal Map Grid */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-6 space-y-4 shadow-lg">
        <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
          DATA HALL RACK AMBIENT HEAT MAP
        </h3>

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-12 gap-2">
          {racks.map((rack) => {
            const temp = rack.temperatureOutlet;
            let bgColor = 'bg-blue-950/60 border-blue-500/60 text-blue-300';
            if (temp > 35) bgColor = 'bg-rose-950/80 border-rose-500 text-rose-300 shadow-[0_0_10px_rgba(244,63,94,0.4)] animate-pulse';
            else if (temp > 31) bgColor = 'bg-amber-950/70 border-amber-500 text-amber-300';
            else if (temp > 27) bgColor = 'bg-yellow-950/50 border-yellow-600 text-yellow-300';
            else if (temp > 23) bgColor = 'bg-emerald-950/50 border-emerald-600 text-emerald-300';

            return (
              <div
                key={rack.id}
                className={`p-2.5 rounded border text-center font-mono ${bgColor} transition-all hover:scale-105`}
              >
                <span className="text-[9px] block text-slate-400 font-bold">{rack.id.slice(-4)}</span>
                <span className="text-xs font-bold block mt-1">{temp}°C</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
