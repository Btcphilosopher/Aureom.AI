'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Zap, Battery, ShieldAlert, Cpu, ArrowRight } from 'lucide-react';

interface PowerViewProps {
  state: DataCenterState;
}

export function PowerView({ state }: PowerViewProps) {
  const p = state.power;

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-cyan-300 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            ELECTRICAL INFRASTRUCTURE & SINGLE-LINE DIAGRAM
          </h2>
          <span className="text-xs text-slate-400">
            Real-time power generation, high-voltage substation, UPS double-conversion & battery storage
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">TOTAL FACILITY LOAD</span>
          <div className="text-xl font-bold text-yellow-400">{p.facilityLoadMw.toFixed(1)} MW</div>
        </div>
      </div>

      {/* Power Flow Architecture Pipeline */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-6 relative overflow-x-auto">
        <div className="min-w-[760px] flex items-center justify-between gap-4 py-4">
          {/* 1. National Grid */}
          <div className="bg-[#111827] border border-yellow-500/50 p-4 rounded-lg w-44 text-center shadow-lg">
            <span className="text-[10px] text-slate-400 font-bold block mb-1">PRIMARY GRID</span>
            <div className="text-lg font-bold text-yellow-400">{p.gridInputMw.toFixed(1)} MW</div>
            <span className="text-[10px] text-emerald-400 font-semibold block mt-1">
              {p.gridFrequencyHz} Hz • STABLE
            </span>
          </div>

          <ArrowRight className="w-5 h-5 text-yellow-400 animate-pulse shrink-0" />

          {/* 2. Substation */}
          <div className="bg-[#111827] border border-cyan-500/50 p-4 rounded-lg w-44 text-center shadow-lg">
            <span className="text-[10px] text-slate-400 font-bold block mb-1">SUBSTATION</span>
            <div className="text-lg font-bold text-cyan-300">{p.substationMw.toFixed(1)} MW</div>
            <span className="text-[10px] text-slate-400 block mt-1">
              Losses: {p.transformerLossesMw} MW
            </span>
          </div>

          <ArrowRight className="w-5 h-5 text-cyan-400 animate-pulse shrink-0" />

          {/* 3. UPS Modules */}
          <div className="bg-[#111827] border border-purple-500/50 p-4 rounded-lg w-44 text-center shadow-lg">
            <span className="text-[10px] text-slate-400 font-bold block mb-1">UPS SYSTEMS</span>
            <div className="text-lg font-bold text-purple-300">{p.upsOutputMw.toFixed(1)} MW</div>
            <span className="text-[10px] text-purple-400 font-semibold block mt-1">
              97.4% EFFICIENT
            </span>
          </div>

          <ArrowRight className="w-5 h-5 text-purple-400 animate-pulse shrink-0" />

          {/* 4. IT Load Racks */}
          <div className="bg-[#111827] border border-emerald-500/50 p-4 rounded-lg w-44 text-center shadow-lg">
            <span className="text-[10px] text-slate-400 font-bold block mb-1">IT RACK LOAD</span>
            <div className="text-lg font-bold text-emerald-300">{p.itLoadMw.toFixed(1)} MW</div>
            <span className="text-[10px] text-emerald-400 font-semibold block mt-1">
              120 RACKS ACTIVE
            </span>
          </div>
        </div>
      </div>

      {/* Battery Energy Storage System (BESS) & Diesel Generators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Battery Storage */}
        <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Battery className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-sm text-slate-200">BATTERY STORAGE (BESS)</h3>
            </div>
            <span className="text-xs text-emerald-400 font-bold">50 MWh CAPACITY</span>
          </div>

          <div className="space-y-3">
            {state.batteries.map((batt) => (
              <div key={batt.id} className="bg-[#111827] p-3 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">{batt.id}</span>
                  <span
                    className={`font-bold ${
                      batt.status === 'CHARGING'
                        ? 'text-emerald-400'
                        : batt.status === 'DISCHARGING'
                        ? 'text-rose-400 animate-pulse'
                        : 'text-slate-400'
                    }`}
                  >
                    {batt.status} ({batt.currentPowerMw > 0 ? '+' : ''}
                    {batt.currentPowerMw} MW)
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                  <div
                    className="bg-emerald-400 h-full transition-all duration-500"
                    style={{ width: `${batt.socPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>STATE OF CHARGE: {batt.socPercent.toFixed(1)}%</span>
                  <span>EST BACKUP: 18.5 MIN</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diesel Backup Generators */}
        <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-sm text-slate-200">EMERGENCY GENERATORS</h3>
            </div>
            <span className="text-xs text-slate-400">4x 2.5 MW CAT D3516B</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {state.generators.map((gen) => (
              <div
                key={gen.id}
                className={`p-3 rounded border text-xs space-y-1 ${
                  gen.isRunning
                    ? 'bg-amber-950/40 border-amber-500/60 text-amber-200'
                    : 'bg-[#111827] border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex justify-between items-center font-bold">
                  <span>{gen.id}</span>
                  <span className={gen.isRunning ? 'text-amber-400 animate-pulse' : 'text-slate-500'}>
                    ● {gen.isRunning ? 'RUNNING' : 'STANDBY'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">Output: {gen.currentOutputMw} MW</div>
                <div className="text-[10px] text-slate-500">Fuel: {gen.fuelLevelPercent}%</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
