'use client';

import React, { useState } from 'react';
import { DataCenterState, AlertState } from '@/lib/types';
import { AlertTriangle, CheckCircle2, ShieldAlert, Bell, Search } from 'lucide-react';

interface AlertsViewProps {
  state: DataCenterState;
}

export function AlertsView({ state }: AlertsViewProps) {
  const [alerts, setAlerts] = useState<AlertState[]>(state.alerts);
  const [filter, setFilter] = useState<'ALL' | 'CRITICAL' | 'WARNING'>('ALL');

  const handleAcknowledge = (id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, acknowledged: true } : a))
    );
  };

  const filtered = alerts.filter((a) => {
    if (filter === 'CRITICAL') return a.severity === 'CRITICAL' || a.severity === 'EMERGENCY';
    if (filter === 'WARNING') return a.severity === 'WARNING';
    return true;
  });

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-rose-300 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            LIVE ALERTS & ANOMALY DETECTION LOG
          </h2>
          <span className="text-xs text-slate-400">
            Real-time Python AI anomaly engine stream, telemetry thresholds & equipment warnings
          </span>
        </div>
        <div className="flex items-center gap-2">
          {['ALL', 'CRITICAL', 'WARNING'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-3 py-1 rounded text-xs font-bold ${
                filter === f
                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                  : 'bg-[#111827] text-slate-400 border border-slate-800'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Alert Feed List */}
      <div className="space-y-3">
        {filtered.map((alert) => {
          const isCritical = alert.severity === 'CRITICAL' || alert.severity === 'EMERGENCY';

          return (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all ${
                isCritical
                  ? 'bg-rose-950/40 border-rose-500/80 shadow-[0_0_12px_rgba(244,63,94,0.25)]'
                  : 'bg-[#0C121E] border-slate-800'
              }`}
            >
              <div className="flex items-start gap-3">
                <AlertTriangle
                  className={`w-5 h-5 shrink-0 mt-0.5 ${
                    isCritical ? 'text-rose-400 animate-pulse' : 'text-amber-400'
                  }`}
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-100">{alert.title}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded font-bold bg-slate-900 border border-slate-700 text-slate-300">
                      {alert.assetName}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{alert.description}</p>
                  <span className="text-[10px] text-slate-500 mt-1 block font-mono">
                    EVENT ID: {alert.id} • TIME: {alert.timestamp}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                {alert.acknowledged ? (
                  <span className="text-xs text-emerald-400 flex items-center gap-1 font-bold bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5" /> ACKNOWLEDGED
                  </span>
                ) : (
                  <button
                    onClick={() => handleAcknowledge(alert.id)}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded border border-slate-700 font-bold transition-colors"
                  >
                    ACKNOWLEDGE
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
