'use client';

import React, { useState } from 'react';
import { DataCenterState, DigitalTwinVisualMode } from '@/lib/types';
import { DigitalTwinCanvas } from '../digital-twin/DigitalTwinCanvas';

interface DigitalTwinViewProps {
  state: DataCenterState;
  isThermalMode: boolean;
  onToggleThermal: () => void;
  reducedMotion: boolean;
  selectedRackId: string | null;
  onSelectRack: (rackId: string | null) => void;
}

export function DigitalTwinView({
  state,
  isThermalMode,
  onToggleThermal,
  reducedMotion,
  selectedRackId,
  onSelectRack,
}: DigitalTwinViewProps) {
  const [visualMode, setVisualMode] = useState<DigitalTwinVisualMode>('STANDARD');

  return (
    <div className="w-full h-full relative bg-[#070A12] flex flex-col">
      <DigitalTwinCanvas
        state={state}
        visualMode={visualMode}
        onSelectVisualMode={setVisualMode}
        isThermalMode={isThermalMode}
        reducedMotion={reducedMotion}
        selectedRackId={selectedRackId}
        onSelectRack={onSelectRack}
      />
    </div>
  );
}
