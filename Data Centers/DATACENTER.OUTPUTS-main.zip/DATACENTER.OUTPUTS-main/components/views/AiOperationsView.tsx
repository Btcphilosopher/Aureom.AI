'use client';

import React, { useState } from 'react';
import { DataCenterState, ViewName } from '@/lib/types';
import { Bot, Sparkles, Send, ArrowRight, Play, CheckCircle2, RefreshCw } from 'lucide-react';

interface AiOperationsViewProps {
  state: DataCenterState;
  onSelectView: (view: ViewName) => void;
  onTriggerSimulation: (scenario: string) => void;
}

export function AiOperationsView({ state, onSelectView, onTriggerSimulation }: AiOperationsViewProps) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState(state.aiRecommendation);

  const handleRunAiDiagnostics = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/diagnostics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ telemetryState: state, userQuery: query }),
      });
      const data = await res.json();
      if (data.recommendation) {
        setRecommendation(data.recommendation);
      }
    } catch (e) {
      // Fallback
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-purple-300 flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-400" />
            AI OPERATIONS & DIAGNOSTIC ASSISTANT
          </h2>
          <span className="text-xs text-slate-400">
            Real-time automated telemetry root cause analysis & predictive maintenance engine
          </span>
        </div>
        <div className="flex items-center gap-2 bg-purple-950/80 px-3 py-1 rounded border border-purple-800 text-purple-300 text-xs">
          <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
          <span>AUTONOMOUS ANALYZER ACTIVE</span>
        </div>
      </div>

      {/* Main AI Diagnostic Output Card (Spec 32 layout) */}
      <div className="bg-[#0C121E] border border-purple-500/50 rounded-lg p-6 space-y-5 shadow-2xl relative overflow-hidden">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-purple-500"></span>
            </span>
            <span className="font-bold text-sm text-purple-300">● ANALYSING FACILITY TELEMETRY</span>
          </div>
          <span className="text-xs bg-purple-950 text-purple-300 font-bold px-2.5 py-1 rounded border border-purple-800">
            CONFIDENCE {recommendation?.confidencePercent || 78}%
          </span>
        </div>

        <div className="space-y-3">
          <h3 className="text-base font-bold text-slate-100">{recommendation?.title}</h3>
          <p className="text-sm text-slate-300 leading-relaxed bg-[#111827] p-3 rounded border border-slate-800">
            {recommendation?.summary}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs">
            <div className="p-3 bg-[#111827] rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px] font-bold">PRIMARY CONTRIBUTOR</span>
              <span className="text-purple-300 font-bold text-xs">{recommendation?.primaryContributor}</span>
            </div>
            <div className="p-3 bg-[#111827] rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px] font-bold">PROBABLE CAUSE</span>
              <span className="text-amber-300 font-bold text-xs">{recommendation?.probableCause}</span>
            </div>
            <div className="p-3 bg-[#111827] rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px] font-bold">AFFECTED ASSET</span>
              <span className="text-cyan-300 font-bold text-xs">{recommendation?.affectedAsset}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-4 pt-4 border-t border-slate-800">
          <button
            onClick={() => onSelectView('Cooling')}
            className="flex items-center gap-2 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 px-4 py-2 rounded text-xs font-bold transition-all"
          >
            <span>[VIEW SYSTEM]</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              onTriggerSimulation('COOLING_FAILURE');
              onSelectView('Simulation');
            }}
            className="flex items-center gap-2 bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 px-4 py-2 rounded text-xs font-bold transition-all"
          >
            <span>[SIMULATE SCENARIO]</span>
            <Play className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Interactive Gemini AI Query Input */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-5 space-y-3">
        <label className="text-xs font-bold text-slate-300 block">
          QUERY GEMINI AI OPERATIONS ASSISTANT
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Ask AI e.g. 'What is causing the PUE spike on Data Hall A?'"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRunAiDiagnostics()}
            className="flex-1 bg-[#111827] border border-slate-800 focus:border-purple-500 text-white px-3 py-2 rounded text-xs outline-none"
          />
          <button
            onClick={handleRunAiDiagnostics}
            disabled={loading}
            className="flex items-center gap-2 bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 px-4 py-2 rounded text-xs font-bold disabled:opacity-50"
          >
            {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            <span>RUN ANALYSIS</span>
          </button>
        </div>
      </div>
    </div>
  );
}
