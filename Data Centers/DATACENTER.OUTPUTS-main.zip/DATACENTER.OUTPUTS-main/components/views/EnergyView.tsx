'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Gauge, Sun, Zap, Leaf, Shield, Globe } from 'lucide-react';
import { PueGauge } from '../ui/PueGauge';

interface EnergyViewProps {
  state: DataCenterState;
}

export function EnergyView({ state }: EnergyViewProps) {
  const e = state.energy;

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-emerald-300 flex items-center gap-2">
            <Gauge className="w-5 h-5 text-emerald-400" />
            ENERGY MANAGEMENT & SUSTAINABILITY ENGINE
          </h2>
          <span className="text-xs text-slate-400">
            Real-time Power Usage Effectiveness (PUE), Carbon Usage (CUE) & solar microgrid integration
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">PUE EFFICIENCY</span>
          <div className="text-xl font-bold text-emerald-400">{e.pue.toFixed(2)}</div>
        </div>
      </div>

      {/* Main Grid: PUE Gauge Instrument + Energy Flow Diagram */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* PUE Instrument Card */}
        <div className="bg-[#0C121E] border border-emerald-500/40 rounded-lg p-6 flex flex-col items-center justify-between shadow-lg">
          <span className="text-xs text-slate-400 font-bold tracking-wider">PUE EFFICIENCY INSTRUMENT</span>
          
          <div className="my-4">
            <PueGauge pueValue={e.pue} />
          </div>

          <div className="w-full space-y-2 text-xs">
            <div className="flex justify-between p-2 bg-[#111827] rounded border border-slate-800">
              <span className="text-slate-400">DESIGN TARGET PUE:</span>
              <span className="text-emerald-400 font-bold">1.20</span>
            </div>
            <div className="flex justify-between p-2 bg-[#111827] rounded border border-slate-800">
              <span className="text-slate-400">INDUSTRY AVERAGE:</span>
              <span className="text-amber-400 font-bold">1.55</span>
            </div>
          </div>
        </div>

        {/* Energy Flow Diagram (SOLAR + GRID -> FACILITY -> IT / COOLING / OTHER) */}
        <div className="lg:col-span-2 bg-[#0C121E] border border-slate-800 rounded-lg p-6 space-y-4 shadow-lg flex flex-col justify-between">
          <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
            ENERGY SANKEY & POWER FLOW SANKEY
          </h3>

          <div className="grid grid-cols-3 gap-4 items-center my-auto">
            {/* Sources */}
            <div className="space-y-3">
              <div className="p-3 bg-[#111827] border border-amber-500/50 rounded text-xs">
                <div className="flex items-center gap-2 text-amber-400 font-bold mb-1">
                  <Sun className="w-4 h-4" /> SOLAR MICROGRID
                </div>
                <div className="text-lg font-bold text-slate-100">{state.power.solarInputMw} MW</div>
                <span className="text-[10px] text-amber-400">100% RENEWABLE</span>
              </div>

              <div className="p-3 bg-[#111827] border border-yellow-500/50 rounded text-xs">
                <div className="flex items-center gap-2 text-yellow-400 font-bold mb-1">
                  <Zap className="w-4 h-4" /> NATIONAL GRID
                </div>
                <div className="text-lg font-bold text-slate-100">{state.power.gridInputMw} MW</div>
                <span className="text-[10px] text-slate-400">400kV TRANSMISSION</span>
              </div>
            </div>

            {/* Center Facility Node */}
            <div className="bg-[#111827] border border-emerald-500/60 p-5 rounded-lg text-center shadow-xl">
              <span className="text-[10px] text-emerald-400 font-bold block mb-1">FACILITY SUBSTATION</span>
              <div className="text-2xl font-bold text-emerald-300">{state.power.facilityLoadMw.toFixed(1)} MW</div>
              <span className="text-xs text-slate-400 block mt-1">TOTAL INGEST</span>
            </div>

            {/* Distribution Load Targets */}
            <div className="space-y-3">
              <div className="p-3 bg-[#111827] border border-cyan-500/50 rounded text-xs">
                <span className="text-[10px] text-cyan-400 font-bold block mb-1">IT COMPUTE LOAD (81%)</span>
                <div className="text-lg font-bold text-cyan-300">{state.power.itLoadMw.toFixed(1)} MW</div>
              </div>

              <div className="p-3 bg-[#111827] border border-blue-500/50 rounded text-xs">
                <span className="text-[10px] text-blue-400 font-bold block mb-1">COOLING PLANT (16%)</span>
                <div className="text-lg font-bold text-blue-300">{state.cooling.coolingLoadMw.toFixed(1)} MW</div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-700 rounded text-xs">
                <span className="text-[10px] text-slate-400 font-bold block mb-1">AUXILIARY & LOSSES (3%)</span>
                <div className="text-lg font-bold text-slate-300">2.7 MW</div>
              </div>
            </div>
          </div>

          {/* Sustainability Footer */}
          <div className="grid grid-cols-3 gap-4 border-t border-slate-800 pt-3 text-xs text-slate-400">
            <div className="flex justify-between p-2 bg-[#111827] rounded border border-slate-800">
              <span>RENEWABLE RATIO:</span>
              <span className="text-emerald-400 font-bold">{e.renewableRatioPercent}%</span>
            </div>
            <div className="flex justify-between p-2 bg-[#111827] rounded border border-slate-800">
              <span>CARBON INTENSITY:</span>
              <span className="text-emerald-400 font-bold">{e.carbonIntensityGPerKwh} g/kWh</span>
            </div>
            <div className="flex justify-between p-2 bg-[#111827] rounded border border-slate-800">
              <span>DAILY ENERGY CONSUMED:</span>
              <span className="text-slate-200 font-bold">{e.dailyEnergyMwh} MWh</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
