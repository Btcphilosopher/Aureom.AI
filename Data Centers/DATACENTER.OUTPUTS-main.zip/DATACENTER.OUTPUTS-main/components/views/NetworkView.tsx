'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Network, ArrowRight, Activity, ShieldCheck, AlertCircle } from 'lucide-react';

interface NetworkViewProps {
  state: DataCenterState;
}

export function NetworkView({ state }: NetworkViewProps) {
  const n = state.network;

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-indigo-300 flex items-center gap-2">
            <Network className="w-5 h-5 text-indigo-400" />
            HIGH-SPEED FABRIC NETWORK & TOPOLOGY
          </h2>
          <span className="text-xs text-slate-400">
            400G InfiniBand / RoCE v2 ultra-low latency Spine-Leaf fabric topology
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">TOTAL FABRIC TRAFFIC</span>
          <div className="text-xl font-bold text-indigo-400">{n.totalTrafficTbps} Tbps</div>
        </div>
      </div>

      {/* Network Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs text-slate-400 block mb-1">CORE ROUTER BANDWIDTH</span>
          <div className="text-2xl font-bold text-indigo-300">{n.coreBandwidthTbps} Tbps</div>
          <span className="text-[10px] text-emerald-400">NON-BLOCKING</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs text-slate-400 block mb-1">SPINE FABRIC</span>
          <div className="text-2xl font-bold text-indigo-300">{n.spineBandwidthTbps} Tbps</div>
          <span className="text-[10px] text-slate-400">128x 400G SWITCHES</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs text-slate-400 block mb-1">AVERAGE LATENCY</span>
          <div className="text-2xl font-bold text-emerald-300">{n.latencyMs} ms</div>
          <span className="text-[10px] text-emerald-400">ULTRA-LOW LATENCY</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <span className="text-xs text-slate-400 block mb-1">PACKET LOSS RATE</span>
          <div className="text-2xl font-bold text-cyan-300">0.0001%</div>
          <span className="text-[10px] text-cyan-400">PFC ECN ACTIVE</span>
        </div>
      </div>

      {/* Spine-Leaf Diagram */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-6 space-y-4">
        <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
          SPINE-LEAF DATA PACKET ARCHITECTURE
        </h3>

        <div className="space-y-6 py-2">
          {/* Core Level */}
          <div className="flex justify-center">
            <div className="bg-[#111827] border border-indigo-500/60 p-3 rounded-md w-72 text-center shadow-lg">
              <span className="text-[10px] text-indigo-400 font-bold block">INTERNET / CORE GATEWAY</span>
              <span className="text-sm font-bold text-slate-100">12.8 Tbps OUTBOUND</span>
            </div>
          </div>

          {/* Spine Switches */}
          <div className="flex justify-around gap-4">
            {['SPINE SWITCH 01', 'SPINE SWITCH 02', 'SPINE SWITCH 03', 'SPINE SWITCH 04'].map((s) => (
              <div key={s} className="bg-[#111827] border border-purple-500/40 p-2.5 rounded text-center text-xs flex-1">
                <span className="text-purple-300 font-bold block">{s}</span>
                <span className="text-[10px] text-slate-400">6.4 Tbps</span>
              </div>
            ))}
          </div>

          {/* Leaf Switches */}
          <div className="flex justify-around gap-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-[#111827] border border-slate-800 p-2 rounded text-center text-[11px] flex-1">
                <span className="text-cyan-300 font-bold block">LEAF-{i + 1}</span>
                <span className="text-[9px] text-slate-500">400G ToR</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
