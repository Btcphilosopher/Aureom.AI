'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Wind, Thermometer, Droplets, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface CoolingViewProps {
  state: DataCenterState;
}

export function CoolingView({ state }: CoolingViewProps) {
  const c = state.cooling;

  const chillers = [
    { id: 'CHILLER-01', name: 'York YK Centrifugal #1', status: 'RUNNING', loadKw: 3450, cop: 5.4, tempOut: 14.1 },
    { id: 'CHILLER-02', name: 'York YK Centrifugal #2', status: 'RUNNING', loadKw: 3520, cop: 5.3, tempOut: 14.2 },
    { id: 'CHILLER-03', name: 'York YK Centrifugal #3', status: 'RUNNING', loadKw: 3890, cop: 4.1, tempOut: 15.6, warning: true },
    { id: 'CHILLER-04', name: 'York YK Centrifugal #4', status: 'STANDBY', loadKw: 0, cop: 0.0, tempOut: 14.0 },
  ];

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title Header */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-blue-300 flex items-center gap-2">
            <Wind className="w-5 h-5 text-blue-400" />
            MECHANICAL COOLING & LIQUID THERMAL LOOPS
          </h2>
          <span className="text-xs text-slate-400">
            Centrifugal chillers, liquid cooling distribution units (CDU), cooling towers & Delta-T thermal loops
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">COOLING LOAD</span>
          <div className="text-xl font-bold text-blue-400">{c.coolingLoadMw.toFixed(1)} MW</div>
        </div>
      </div>

      {/* Primary Metrics Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>SUPPLY TEMP (COLD)</span>
            <Thermometer className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-300">{c.supplyTempC} °C</div>
          <span className="text-[10px] text-emerald-400">OPTIMAL INLET</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>RETURN TEMP (HOT)</span>
            <Thermometer className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-300">{c.returnTempC} °C</div>
          <span className="text-[10px] text-slate-400">DELTA-T: {(c.returnTempC - c.supplyTempC).toFixed(1)} °C</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>WATER FLOW RATE</span>
            <Droplets className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-300">{c.waterFlowLps} L/s</div>
          <span className="text-[10px] text-blue-400">PUMP SPEED: 84%</span>
        </div>

        <div className="bg-[#0D1322] border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>COP RATIO</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-300">{c.copRatio}</div>
          <span className="text-[10px] text-emerald-400">HIGH EFFICIENCY</span>
        </div>
      </div>

      {/* Chillers Matrix */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <h3 className="font-bold text-sm text-slate-200">CENTRIFUGAL CHILLER PLANT (4 UNITS)</h3>
          <span className="text-xs text-blue-400 font-semibold">{c.chillersActive} RUNNING / 1 STANDBY</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {chillers.map((chiller) => (
            <div
              key={chiller.id}
              className={`p-4 rounded-lg border text-xs space-y-2 relative ${
                chiller.warning
                  ? 'bg-amber-950/40 border-amber-500 text-amber-200'
                  : chiller.status === 'RUNNING'
                  ? 'bg-[#111827] border-blue-500/50 text-slate-200'
                  : 'bg-[#111827] border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="font-bold text-sm">{chiller.id}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                    chiller.warning
                      ? 'bg-amber-900 text-amber-300'
                      : chiller.status === 'RUNNING'
                      ? 'bg-blue-950 text-blue-300 border border-blue-800'
                      : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  ● {chiller.status}
                </span>
              </div>

              <div className="text-[11px] text-slate-400">{chiller.name}</div>

              <div className="border-t border-slate-800/80 pt-2 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>LOAD:</span>
                  <span className="font-bold text-slate-200">{chiller.loadKw} kW</span>
                </div>
                <div className="flex justify-between">
                  <span>COP:</span>
                  <span className={chiller.warning ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {chiller.cop}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>SUPPLY TEMP:</span>
                  <span className="text-cyan-300 font-semibold">{chiller.tempOut} °C</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
