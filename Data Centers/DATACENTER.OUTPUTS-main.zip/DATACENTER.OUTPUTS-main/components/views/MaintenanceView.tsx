'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { Wrench, CheckCircle2, AlertTriangle, Calendar } from 'lucide-react';

interface MaintenanceViewProps {
  state: DataCenterState;
}

export function MaintenanceView({ state }: MaintenanceViewProps) {
  const tasks = [
    { id: 'MNT-402', title: 'Chiller 03 Compressor Seal Inspection', asset: 'Chiller 03', date: '2026-09-03', priority: 'HIGH', status: 'SCHEDULED' },
    { id: 'MNT-398', title: 'UPS Module A2 Capacitor Testing', asset: 'UPS-A2', date: '2026-09-08', priority: 'MEDIUM', status: 'SCHEDULED' },
    { id: 'MNT-385', title: 'Generator 01 Diesel Fuel Filter Swap', asset: 'GEN-01', date: '2026-09-12', priority: 'LOW', status: 'PLANNED' },
  ];

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <Wrench className="w-5 h-5 text-amber-400" />
            EQUIPMENT MAINTENANCE & ASSET LIFECYCLE
          </h2>
          <span className="text-xs text-slate-400">
            Preventative maintenance scheduling, MTBF health scores & degraded component tracking
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">FACILITY HEALTH INDEX</span>
          <div className="text-xl font-bold text-emerald-400">98.4% NOMINAL</div>
        </div>
      </div>

      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
          SCHEDULED MAINTENANCE WORK ORDERS
        </h3>

        <div className="space-y-3">
          {tasks.map((t) => (
            <div key={t.id} className="p-4 bg-[#111827] border border-slate-800 rounded-lg flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-sm text-slate-100 block">{t.title}</span>
                <span className="text-slate-400 text-[11px]">Asset: {t.asset} • Date: {t.date}</span>
              </div>
              <span className={`px-2.5 py-1 rounded font-bold ${t.priority === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-slate-900 text-slate-400'}`}>
                {t.priority} PRIORITY
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
