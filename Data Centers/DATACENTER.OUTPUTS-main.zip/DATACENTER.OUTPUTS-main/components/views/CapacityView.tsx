'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';
import { BarChart3, Zap, Wind, Server, Cpu } from 'lucide-react';

interface CapacityViewProps {
  state: DataCenterState;
}

export function CapacityView({ state }: CapacityViewProps) {
  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-cyan-300 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
            INFRASTRUCTURE CAPACITY & RUNWAY PROJECTIONS
          </h2>
          <span className="text-xs text-slate-400">
            Remaining electrical power MW, CDU liquid cooling headroom & rack U space availability
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">POWER RUNWAY</span>
          <div className="text-xl font-bold text-emerald-400">18.3 MW REMAINING</div>
        </div>
      </div>

      {/* Gauges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Electrical Capacity */}
        <div className="bg-[#0C121E] border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center text-xs font-bold">
            <span className="text-slate-200">ELECTRICAL POWER CAPACITY</span>
            <span className="text-cyan-400">70.2 MW / 100.0 MW (70.2%)</span>
          </div>
          <div className="w-full bg-slate-900 h-3 rounded overflow-hidden">
            <div className="bg-cyan-400 h-full" style={{ width: '70.2%' }} />
          </div>
          <p className="text-xs text-slate-400">29.8 MW available for future GPU expansion</p>
        </div>

        {/* Cooling Headroom */}
        <div className="bg-[#0C121E] border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center text-xs font-bold">
            <span className="text-slate-200">COOLING PLANT HEADROOM</span>
            <span className="text-blue-400">13.8 MW / 20.0 MW (69.0%)</span>
          </div>
          <div className="w-full bg-slate-900 h-3 rounded overflow-hidden">
            <div className="bg-blue-400 h-full" style={{ width: '69.0%' }} />
          </div>
          <p className="text-xs text-slate-400">Chiller 04 on standby ready to stage</p>
        </div>

        {/* Rack U Space */}
        <div className="bg-[#0C121E] border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center text-xs font-bold">
            <span className="text-slate-200">RACK U SPACE OCCUPANCY</span>
            <span className="text-purple-400">3,840 U / 5,040 U (76.1%)</span>
          </div>
          <div className="w-full bg-slate-900 h-3 rounded overflow-hidden">
            <div className="bg-purple-400 h-full" style={{ width: '76.1%' }} />
          </div>
          <p className="text-xs text-slate-400">1,200 U unallocated server slot headroom</p>
        </div>

        {/* Network Port Density */}
        <div className="bg-[#0C121E] border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center text-xs font-bold">
            <span className="text-slate-200">400G INFIBAND PORT DENSITY</span>
            <span className="text-emerald-400">896 PORTS / 1,024 PORTS (87.5%)</span>
          </div>
          <div className="w-full bg-slate-900 h-3 rounded overflow-hidden">
            <div className="bg-emerald-400 h-full" style={{ width: '87.5%' }} />
          </div>
          <p className="text-xs text-slate-400">128 free ports for Leaf switch extension</p>
        </div>
      </div>
    </div>
  );
}
