'use client';

import React from 'react';
import { DataCenterState, ViewName } from '@/lib/types';
import {
  Zap,
  Wind,
  Cpu,
  Gauge,
  AlertTriangle,
  Bot,
  ArrowUpRight,
  Activity,
  Box,
  TrendingUp,
} from 'lucide-react';

interface OverviewViewProps {
  state: DataCenterState;
  onSelectView: (view: ViewName) => void;
}

export function OverviewView({ state, onSelectView }: OverviewViewProps) {
  return (
    <div className="p-6 space-y-6 bg-[#050505] min-h-full text-[#E0E0E0] font-mono overflow-y-auto custom-scrollbar">
      {/* Top Banner KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* IT Power Load */}
        <div
          onClick={() => onSelectView('Power')}
          className="bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/60 p-4 rounded cursor-pointer transition-all group"
        >
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] text-[#666] font-bold uppercase tracking-wider">IT POWER LOAD</span>
            <Zap className="w-4 h-4 text-[#00F0FF] group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {state.power.itLoadMw.toFixed(1)} <span className="text-xs text-[#666]">MW</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] text-[#888]">
            <span>Grid Substation: {state.power.substationMw.toFixed(1)} MW</span>
            <span className="text-[#00F0FF] flex items-center gap-1 font-bold">
              <TrendingUp className="w-3 h-3" /> +1.4%
            </span>
          </div>
        </div>

        {/* PUE Efficiency */}
        <div
          onClick={() => onSelectView('Energy')}
          className="bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/60 p-4 rounded cursor-pointer transition-all group"
        >
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] text-[#666] font-bold uppercase tracking-wider">FACILITY PUE</span>
            <Gauge className="w-4 h-4 text-[#00F0FF] group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {state.energy.pue.toFixed(2)}
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] text-[#888]">
            <span>Renewables: {state.energy.renewableRatioPercent}%</span>
            <span className="text-[#00F0FF] font-bold">OPTIMAL</span>
          </div>
        </div>

        {/* AI Compute GPU Util */}
        <div
          onClick={() => onSelectView('GPU')}
          className="bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/60 p-4 rounded cursor-pointer transition-all group"
        >
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] text-[#666] font-bold uppercase tracking-wider">AI COMPUTE UTIL</span>
            <Cpu className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold text-[#00F0FF] font-mono">
            81.0%
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] text-[#888]">
            <span>Nodes: 960 H100</span>
            <span className="text-purple-400 font-bold">949 PFLOPS</span>
          </div>
        </div>

        {/* Active Cooling */}
        <div
          onClick={() => onSelectView('Cooling')}
          className="bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/60 p-4 rounded cursor-pointer transition-all group"
        >
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] text-[#666] font-bold uppercase tracking-wider">COOLING DEMAND</span>
            <Wind className="w-4 h-4 text-[#00F0FF] group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {state.cooling.coolingLoadMw.toFixed(1)} <span className="text-xs text-[#666]">MW</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] text-[#888]">
            <span>Chillers: {state.cooling.chillersActive} / 4</span>
            <span className="text-[#00F0FF] font-bold">COP {state.cooling.copRatio}</span>
          </div>
        </div>
      </div>

      {/* Main Overview Grid: Digital Twin Shortcut + AI Assistant Diagnostic */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Digital Twin Launch Window */}
        <div
          onClick={() => onSelectView('Digital Twin')}
          className="lg:col-span-2 bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/80 rounded p-5 cursor-pointer relative group transition-all overflow-hidden flex flex-col justify-between h-72 shadow-2xl"
        >
          <div className="flex justify-between items-start z-10">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Box className="w-5 h-5 text-[#00F0FF]" />
                <span className="font-black text-sm text-white tracking-wider">ANIMATED DIGITAL TWIN</span>
              </div>
              <p className="text-xs text-[#666]">
                Axonometric spatial model with real-time power, cooling, network & thermal heatmaps
              </p>
            </div>
            <button className="flex items-center gap-1 text-[10px] bg-[#00F0FF] text-black font-bold uppercase tracking-widest px-3 py-1.5 rounded hover:brightness-110 transition-all">
              <span>LAUNCH FULLSCREEN</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mini Mock Rack Matrix Preview */}
          <div className="my-auto grid grid-cols-8 gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
            {Array.from({ length: 32 }).map((_, i) => (
              <div
                key={i}
                className={`h-8 rounded border flex items-center justify-center text-[9px] font-mono ${
                  i === 10
                    ? 'bg-[#FF4E00]/20 border-[#FF4E00] text-[#FF4E00] font-bold'
                    : i % 7 === 0
                    ? 'bg-amber-950/40 border-amber-500 text-amber-400'
                    : 'bg-[#111] border-[#222] text-[#00F0FF]'
                }`}
              >
                R-{(i + 1).toString().padStart(2, '0')}
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center text-[10px] text-[#666] border-t border-[#1F1F1F] pt-2 z-10 uppercase tracking-wider font-bold">
            <span>2 DATA HALLS • 120 RACKS ONLINE</span>
            <span className="text-[#00F0FF]">CLICK TO INTERACT & DRILL DOWN</span>
          </div>
        </div>

        {/* AI Operations Diagnostic Widget (Direct from Immersive UI theme) */}
        <div
          onClick={() => onSelectView('AI Operations')}
          className="bg-[#0A0A0A] border border-[#222] hover:border-[#00F0FF]/80 rounded p-5 cursor-pointer transition-all flex flex-col justify-between h-72 shadow-2xl"
        >
          <div className="flex items-center justify-between border-b border-[#222] pb-2 mb-3">
            <h3 className="text-[10px] font-bold tracking-widest text-[#888] uppercase">AI Diagnostics</h3>
            <span className="text-[8px] text-[#00F0FF] px-1 border border-[#00F0FF] rounded font-bold">MODEL v4.2</span>
          </div>

          <div className="space-y-3">
            <div className="text-xs text-[#BBB] leading-relaxed">
              <span className="text-[#00F0FF] font-bold">ANALYSIS:</span> PUE increased 4.2% over last 45m. Contributor: Cooling Plant A. Probable cause: Chiller 03 efficiency loss.
            </div>
            <div className="p-2 bg-[#111] border border-[#222] rounded flex justify-between items-center">
              <div className="text-[10px] text-[#666] uppercase font-bold">Confidence</div>
              <div className="text-xs font-mono text-[#00F0FF] font-bold">78.4%</div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectView('Simulation');
              }}
              className="w-full py-2 bg-[#00F0FF] text-black text-[10px] font-bold uppercase tracking-widest hover:brightness-110 transition-all rounded"
            >
              Run Simulation
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Event Log */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded p-5">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#00F0FF]" />
            <h3 className="font-bold text-xs text-white uppercase tracking-wider">RECENT TELEMETRY INCIDENTS & EVENTS</h3>
          </div>
          <button
            onClick={() => onSelectView('Alerts')}
            className="text-[11px] text-[#00F0FF] hover:underline uppercase font-bold"
          >
            VIEW ALL ALERTS
          </button>
        </div>

        <div className="space-y-2">
          {state.alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3 rounded border flex items-center justify-between text-xs font-mono ${
                alert.severity === 'CRITICAL' || alert.severity === 'EMERGENCY'
                  ? 'bg-[#FF4E00]/10 border-[#FF4E00] text-white'
                  : 'bg-[#111] border-[#222] text-[#CCC]'
              }`}
            >
              <div className="flex items-center gap-3">
                <AlertTriangle
                  className={`w-4 h-4 ${
                    alert.severity === 'CRITICAL' || alert.severity === 'EMERGENCY'
                      ? 'text-[#FF4E00] animate-pulse'
                      : 'text-amber-400'
                  }`}
                />
                <div>
                  <span className="font-bold block">{alert.title}</span>
                  <span className="text-[11px] text-[#888]">{alert.description}</span>
                </div>
              </div>
              <span className="text-[10px] text-[#666] font-mono">{alert.timestamp}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

