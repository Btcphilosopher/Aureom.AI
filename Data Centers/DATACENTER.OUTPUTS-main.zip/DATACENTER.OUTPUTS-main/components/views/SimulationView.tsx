'use client';

import React, { useState } from 'react';
import { DataCenterState } from '@/lib/types';
import { PlaySquare, Play, Pause, RotateCcw, Zap, AlertTriangle, ShieldCheck, Clock, FastForward } from 'lucide-react';

interface SimulationViewProps {
  state: DataCenterState;
  onTriggerSimulation: (scenario: string) => void;
}

export function SimulationView({ state, onTriggerSimulation }: SimulationViewProps) {
  const [activeScenario, setActiveScenario] = useState<string>('GRID_OUTAGE');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [timelinePos, setTimelinePos] = useState<number>(100); // 0-100%

  const handleSimulate = (scenario: string) => {
    setActiveScenario(scenario);
    onTriggerSimulation(scenario);
  };

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <PlaySquare className="w-5 h-5 text-amber-400" />
            WHAT-IF FAILURE SIMULATION & FACILITY TIME MACHINE
          </h2>
          <span className="text-xs text-slate-400">
            Interactive failure sequence scenario execution & historical telemetry incident replay
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400">SIMULATION ENGINE</span>
          <div className="text-sm font-bold text-amber-400">PYTHON MODELING BACKEND</div>
        </div>
      </div>

      {/* 1. WHAT-IF FAILURE SIMULATOR SECTION */}
      <div className="bg-[#0C121E] border border-amber-500/40 rounded-lg p-6 space-y-5 shadow-lg">
        <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-2">
          WHAT IF? FAILURE SCENARIO EXECUTION
        </h3>

        {/* Scenario Selection Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { id: 'GRID_OUTAGE', title: 'GRID POWER OUTAGE', desc: 'Substation blackout, UPS cutover & generator start' },
            { id: 'COOLING_FAILURE', title: 'CHILLER 03 TRIP', desc: 'Cooling plant degradation & thermal surge' },
            { id: 'GPU_SURGE', title: 'AI TRAINING SURGE', desc: '94.2 MW IT load thermal spike' },
            { id: 'NORMAL', title: 'RESET TO NOMINAL', desc: 'Return facility state to baseline operations' },
          ].map((sc) => (
            <button
              key={sc.id}
              onClick={() => handleSimulate(sc.id)}
              className={`p-3 rounded-lg border text-left transition-all ${
                activeScenario === sc.id
                  ? 'bg-amber-950/80 border-amber-500 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                  : 'bg-[#111827] border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <span className="font-bold text-xs block">{sc.title}</span>
              <span className="text-[10px] text-slate-400 block mt-1">{sc.desc}</span>
            </button>
          ))}
        </div>

        {/* Animated Sequence Flow Diagram */}
        <div className="bg-[#080B12] p-5 rounded-lg border border-slate-800 space-y-3">
          <span className="text-xs text-slate-400 font-bold block">SIMULATED EXECUTION SEQUENCE:</span>

          {activeScenario === 'GRID_OUTAGE' ? (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
              <div className="p-2.5 bg-rose-950/80 border border-rose-500 rounded text-rose-300 font-bold w-full text-center">
                1. GRID FAILS
              </div>
              <span className="text-amber-400">→</span>
              <div className="p-2.5 bg-purple-950/80 border border-purple-500 rounded text-purple-300 font-bold w-full text-center">
                2. UPS ACTIVATES
              </div>
              <span className="text-amber-400">→</span>
              <div className="p-2.5 bg-emerald-950/80 border border-emerald-500 rounded text-emerald-300 font-bold w-full text-center">
                3. BESS DISCHARGES
              </div>
              <span className="text-amber-400">→</span>
              <div className="p-2.5 bg-amber-950/80 border border-amber-500 rounded text-amber-300 font-bold w-full text-center animate-pulse">
                4. GENERATORS START
              </div>
            </div>
          ) : (
            <div className="p-4 text-center text-xs text-slate-400">
              Scenario active: <span className="text-amber-300 font-bold">{activeScenario}</span>. All Python telemetry visualised in digital twin.
            </div>
          )}
        </div>
      </div>

      {/* 2. FACILITY TIME MACHINE & HISTORICAL PLAYBACK */}
      <div className="bg-[#0C121E] border border-slate-800 rounded-lg p-6 space-y-4 shadow-lg">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-sm text-slate-200">FACILITY TIME MACHINE (HISTORICAL PLAYBACK)</h3>
          </div>
          <div className="flex items-center gap-1 text-xs">
            {['24 HOURS', '7 DAYS', '30 DAYS'].map((range, idx) => (
              <span
                key={range}
                className={`px-2 py-0.5 rounded font-bold ${
                  idx === 0 ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' : 'bg-slate-900 text-slate-400'
                }`}
              >
                {range}
              </span>
            ))}
          </div>
        </div>

        {/* Timeline Slider */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-400">
            <span>HISTORICAL TELEMETRY (24H AGO)</span>
            <span className="text-cyan-400 font-bold">CURRENT: LIVE TIME</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={timelinePos}
            onChange={(e) => setTimelinePos(Number(e.target.value))}
            className="w-full accent-cyan-400 bg-slate-800 h-2 rounded cursor-pointer"
          />
        </div>

        {/* Playback Controls */}
        <div className="flex items-center justify-between pt-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center gap-2 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 px-4 py-1.5 rounded font-bold"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'PAUSE PLAYBACK' : 'PLAY REPLAY'}</span>
            </button>

            <button
              onClick={() => setTimelinePos(100)}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700"
              title="Reset to Live"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-[10px] mr-2">SPEED:</span>
            {[1, 2, 10, 60].map((spd) => (
              <button
                key={spd}
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-2 py-1 rounded font-bold text-xs ${
                  playbackSpeed === spd
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'bg-slate-900 text-slate-400'
                }`}
              >
                {spd}×
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
