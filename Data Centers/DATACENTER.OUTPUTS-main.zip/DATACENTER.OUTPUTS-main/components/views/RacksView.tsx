'use client';

import React, { useState } from 'react';
import { DataCenterState, RackState } from '@/lib/types';
import { Server, Search, Filter, AlertTriangle, Cpu, Flame, CheckCircle2 } from 'lucide-react';

interface RacksViewProps {
  state: DataCenterState;
  onSelectRack: (rackId: string) => void;
}

export function RacksView({ state, onSelectRack }: RacksViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const allRacks: RackState[] = state.buildings.flatMap((b) => b.floors).flatMap((f) => f.racks);

  const filteredRacks = allRacks.filter((r) => {
    const matchesSearch = r.id.toLowerCase().includes(searchTerm.toLowerCase()) || r.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'WARNING' && (r.status === 'WARNING' || r.thermalLevel === 'HOT')) ||
      (statusFilter === 'CRITICAL' && (r.status === 'CRITICAL' || r.thermalLevel === 'CRITICAL')) ||
      (statusFilter === 'NORMAL' && r.status === 'NORMAL');
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6 bg-[#080C16] min-h-full text-white font-mono overflow-y-auto custom-scrollbar">
      {/* Title & Search Toolbar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-lg font-bold text-cyan-300 flex items-center gap-2">
            <Server className="w-5 h-5 text-cyan-400" />
            RACK INFRASTRUCTURE & FACILITY MAP ({allRacks.length} RACKS)
          </h2>
          <span className="text-xs text-slate-400">
            High-density 40kW server racks, liquid CDU manifold telemetry & GPU compute cluster nodes
          </span>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Search bar */}
          <div className="relative flex-1 md:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Filter by Rack ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#111827] border border-slate-800 focus:border-cyan-500 text-white pl-9 pr-3 py-1.5 rounded text-xs font-mono outline-none"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 bg-[#111827] p-1 rounded border border-slate-800 text-xs">
            {['ALL', 'NORMAL', 'WARNING', 'CRITICAL'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                  statusFilter === st
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Racks Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {filteredRacks.map((rack) => {
          const isCritical = rack.status === 'CRITICAL' || rack.thermalLevel === 'CRITICAL';
          const isWarning = rack.status === 'WARNING' || rack.thermalLevel === 'HOT';

          return (
            <div
              key={rack.id}
              onClick={() => onSelectRack(rack.id)}
              className={`p-3 rounded-lg border cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between h-36 ${
                isCritical
                  ? 'bg-rose-950/40 border-rose-500/80 text-rose-200 hover:border-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.2)]'
                  : isWarning
                  ? 'bg-amber-950/30 border-amber-500/80 text-amber-200 hover:border-amber-400'
                  : 'bg-[#0E1524] border-slate-800 text-slate-200 hover:border-cyan-500/60'
              }`}
            >
              <div className="flex justify-between items-start">
                <span className="font-bold text-xs text-cyan-300">{rack.id}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                    isCritical
                      ? 'bg-rose-900 text-rose-300'
                      : isWarning
                      ? 'bg-amber-900 text-amber-300'
                      : 'bg-emerald-950 text-emerald-300'
                  }`}
                >
                  {isCritical ? 'CRITICAL' : isWarning ? 'WARN' : 'NOMINAL'}
                </span>
              </div>

              <div className="space-y-1 my-2">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">POWER:</span>
                  <span className="font-bold text-slate-100">{rack.powerKw} kW</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">OUT TEMP:</span>
                  <span className={isCritical ? 'text-rose-400 font-bold' : isWarning ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                    {rack.temperatureOutlet}°C
                  </span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">GPU UTIL:</span>
                  <span className="text-purple-400 font-bold">{rack.gpuUtilizationAvg}%</span>
                </div>
              </div>

              {/* Power Ratio Bar */}
              <div className="w-full bg-slate-900 h-1.5 rounded overflow-hidden">
                <div
                  className={`h-full ${isCritical ? 'bg-rose-500' : isWarning ? 'bg-amber-400' : 'bg-cyan-400'}`}
                  style={{ width: `${(rack.powerKw / rack.maxPowerKw) * 100}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
