'use client';

import React, { useState, useEffect } from 'react';
import { Search, X, Server, Zap, Wind, Flame, AlertTriangle, Box, Cpu } from 'lucide-react';
import { ViewName } from '@/lib/types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectView: (view: ViewName) => void;
  onSelectRack: (rackId: string) => void;
  onToggleThermal: () => void;
}

export function CommandPalette({
  isOpen,
  onClose,
  onSelectView,
  onSelectRack,
  onToggleThermal,
}: CommandPaletteProps) {
  const [search, setSearch] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && !isOpen && (document.activeElement?.tagName !== 'INPUT')) {
        e.preventDefault();
        // open
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const commands = [
    { label: 'Go to Digital Twin 3D View', action: () => { onSelectView('Digital Twin'); onClose(); }, icon: Box },
    { label: 'Go to Power Dashboard', action: () => { onSelectView('Power'); onClose(); }, icon: Zap },
    { label: 'Go to Cooling Dashboard', action: () => { onSelectView('Cooling'); onClose(); }, icon: Wind },
    { label: 'Go to Racks Overview', action: () => { onSelectView('Racks'); onClose(); }, icon: Server },
    { label: 'Go to GPU Compute Clusters', action: () => { onSelectView('GPU'); onClose(); }, icon: Cpu },
    { label: 'Toggle Thermal Heatmap Mode', action: () => { onToggleThermal(); onClose(); }, icon: Flame },
    { label: 'Show Active Alerts', action: () => { onSelectView('Alerts'); onClose(); }, icon: AlertTriangle },
    { label: 'Inspect Rack RACK-A-1-018', action: () => { onSelectRack('BLDG-A-1-018'); onSelectView('Digital Twin'); onClose(); }, icon: Server },
    { label: 'Inspect Chiller 03', action: () => { onSelectView('Cooling'); onClose(); }, icon: Wind },
  ];

  const filtered = commands.filter((c) =>
    c.label.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-start justify-center pt-24 select-none">
      <div className="bg-[#0C121E] border border-cyan-500/50 rounded-xl w-full max-w-lg overflow-hidden shadow-2xl font-mono text-white animate-in zoom-in-95 duration-150">
        <div className="p-3 border-b border-slate-800 flex items-center gap-3">
          <Search className="w-4 h-4 text-cyan-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Type command or search (e.g. Search Rack, Show Thermal, Go to Power)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-transparent text-xs text-white outline-none font-mono"
          />
          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded text-slate-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-2 max-h-72 overflow-y-auto space-y-1">
          {filtered.map((cmd, idx) => {
            const Icon = cmd.icon;
            return (
              <button
                key={idx}
                onClick={cmd.action}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded hover:bg-[#162032] hover:text-cyan-300 text-xs text-slate-300 transition-colors text-left"
              >
                <Icon className="w-4 h-4 text-cyan-400" />
                <span>{cmd.label}</span>
              </button>
            );
          })}
        </div>

        <div className="p-2.5 bg-[#080B12] border-t border-slate-800 text-[10px] text-slate-500 flex justify-between font-mono">
          <span>NAVIGATION COMMAND PALETTE</span>
          <span>PRESS ESC TO CLOSE</span>
        </div>
      </div>
    </div>
  );
}
