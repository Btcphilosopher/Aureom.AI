'use client';

import React from 'react';

interface PueGaugeProps {
  pueValue: number;
}

export function PueGauge({ pueValue }: PueGaugeProps) {
  // PUE scale ranges from 1.0 (perfect) to 2.0 (inefficient)
  const minPue = 1.0;
  const maxPue = 2.0;
  const clamped = Math.min(maxPue, Math.max(minPue, pueValue));

  // Gauge angle range from -120deg to +120deg
  const pct = (clamped - minPue) / (maxPue - minPue);
  const angleDeg = -120 + pct * 240;

  return (
    <div className="flex flex-col items-center justify-center font-mono">
      <svg width="200" height="130" viewBox="0 0 200 130" className="overflow-visible">
        {/* Background Arc Track */}
        <path
          d="M 20 120 A 80 80 0 1 1 180 120"
          fill="none"
          stroke="#1E293B"
          strokeWidth="14"
          strokeLinecap="round"
        />

        {/* Active Arc Value Track */}
        <path
          d="M 20 120 A 80 80 0 1 1 180 120"
          fill="none"
          stroke={clamped > 1.35 ? '#F59E0B' : '#10B981'}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray="335"
          strokeDashoffset={335 - pct * 335}
          className="transition-all duration-700 ease-out"
        />

        {/* Needle */}
        <g transform={`rotate(${angleDeg}, 100, 120)`}>
          <line x1="100" y1="120" x2="100" y2="48" stroke="#00F0FF" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="100" cy="120" r="6" fill="#00F0FF" />
        </g>
      </svg>

      <div className="text-center -mt-6">
        <span className="text-3xl font-black text-emerald-400 block tracking-wider font-mono">
          {pueValue.toFixed(2)}
        </span>
        <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold block mt-0.5">
          PUE METRIC
        </span>
      </div>
    </div>
  );
}
