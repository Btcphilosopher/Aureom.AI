'use client';

import React from 'react';
import { ViewName } from '@/lib/types';

interface SidebarProps {
  currentView: ViewName;
  onSelectView: (view: ViewName) => void;
  alertCount: number;
}

const navItems: { name: ViewName; code: string; tag?: string }[] = [
  { name: 'Overview', code: '01' },
  { name: 'Digital Twin', code: '02', tag: '3D' },
  { name: 'Power', code: '03' },
  { name: 'Cooling', code: '04' },
  { name: 'Racks', code: '05' },
  { name: 'GPU', code: '06', tag: 'AI' },
  { name: 'Network', code: '07' },
  { name: 'Energy', code: '08' },
  { name: 'Thermal', code: '09' },
  { name: 'Alerts', code: '10' },
  { name: 'Capacity', code: '11' },
  { name: 'Maintenance', code: '12' },
  { name: 'AI Operations', code: '13', tag: 'LLM' },
  { name: 'Simulation', code: '14', tag: 'SIM' },
];

export function Sidebar({ currentView, onSelectView, alertCount }: SidebarProps) {
  return (
    <nav className="w-56 border-r border-[#222] bg-[#080808] flex flex-col p-4 gap-1 shrink-0 h-full select-none justify-between">
      <div className="flex flex-col gap-1 overflow-y-auto custom-scrollbar">
        <div className="text-[10px] text-[#444] font-bold uppercase tracking-widest mb-2 px-2">
          Navigation
        </div>

        {navItems.map((item) => {
          const isActive = currentView === item.name;

          return (
            <button
              key={item.name}
              onClick={() => onSelectView(item.name)}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium transition-colors text-left ${
                isActive
                  ? 'bg-[#1a1a1a] border-l-2 border-[#00F0FF] text-white'
                  : 'text-[#666] hover:bg-[#111] hover:text-[#CCC]'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`text-[10px] font-mono ${isActive ? 'text-[#00F0FF]' : 'opacity-40'}`}>
                  {item.code}
                </span>
                <span className="uppercase tracking-wide">{item.name}</span>
              </div>

              {/* Alert Count or Tag Badge */}
              {item.name === 'Alerts' && alertCount > 0 ? (
                <span className="bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/50 text-[9px] px-1.5 py-0.2 rounded font-mono font-bold animate-pulse">
                  {alertCount}
                </span>
              ) : (
                item.tag && (
                  <span
                    className={`text-[8px] font-mono font-bold px-1 rounded border ${
                      item.tag === '3D'
                        ? 'text-[#00F0FF] border-[#00F0FF]/40'
                        : item.tag === 'AI' || item.tag === 'LLM'
                        ? 'text-purple-400 border-purple-500/40'
                        : 'text-amber-400 border-amber-500/40'
                    }`}
                  >
                    {item.tag}
                  </span>
                )
              )}
            </button>
          );
        })}
      </div>

      {/* Immersive System Load Widget */}
      <div className="mt-auto flex flex-col gap-2 p-2 bg-[#0c0c0c] border border-[#1a1a1a] rounded">
        <div className="text-[9px] text-[#555] uppercase font-bold tracking-wider">System Load</div>
        <div className="h-1 bg-[#222] rounded-full overflow-hidden">
          <div className="h-full bg-[#00F0FF] w-[81%] shadow-[0_0_5px_#00F0FF]"></div>
        </div>
        <div className="flex justify-between text-[10px] font-mono">
          <span className="text-[#888]">RENDER: 14ms</span>
          <span className="text-[#00F0FF]">81%</span>
        </div>
      </div>
    </nav>
  );
}

