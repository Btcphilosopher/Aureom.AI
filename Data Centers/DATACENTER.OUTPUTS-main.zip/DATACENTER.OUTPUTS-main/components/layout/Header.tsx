'use client';

import React, { useState, useEffect } from 'react';
import {
  Activity,
  Flame,
  Search,
  Sliders,
} from 'lucide-react';
import { DataCenterState } from '@/lib/types';

interface HeaderProps {
  state: DataCenterState;
  isThermalMode: boolean;
  onToggleThermal: () => void;
  reducedMotion: boolean;
  onToggleMotion: () => void;
  onOpenCommandPalette: () => void;
}

export function Header({
  state,
  isThermalMode,
  onToggleThermal,
  reducedMotion,
  onToggleMotion,
  onOpenCommandPalette,
}: HeaderProps) {
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const d = new Date();
      const timeStr = d.toTimeString().split(' ')[0];
      const ms = String(d.getMilliseconds()).padStart(3, '0');
      setCurrentTime(`${timeStr}.${ms}`);
    };
    updateClock();
    const interval = setInterval(updateClock, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-16 border-b border-[#222] flex items-center justify-between px-6 bg-[#0A0A0A] select-none shrink-0">
      {/* Brand & Subtitle */}
      <div className="flex items-center gap-6">
        <div className="flex flex-col">
          <h1 className="text-xl font-black tracking-tighter text-white">
            DATACENTER<span className="text-[#00F0FF]">.OUTPUTS</span>
          </h1>
          <p className="text-[9px] tracking-[0.2em] text-[#666] font-bold uppercase">
            LIVE AI INFRASTRUCTURE OPERATIONS
          </p>
        </div>
      </div>

      {/* Center Search / Command Trigger */}
      <button
        onClick={onOpenCommandPalette}
        className="hidden md:flex items-center gap-3 bg-[#111] border border-[#222] hover:border-[#00F0FF]/50 text-[#888] hover:text-white px-3 py-1.5 rounded text-xs font-mono transition-all w-64 justify-between"
      >
        <span className="flex items-center gap-2">
          <Search className="w-3.5 h-3.5 text-[#00F0FF]" />
          <span className="text-[11px] text-[#888]">Search Racks, GPUs, Chillers...</span>
        </span>
        <kbd className="bg-[#1A1A1A] text-[#AAA] px-1.5 py-0.5 rounded text-[10px] font-mono border border-[#333]">
          /
        </kbd>
      </button>

      {/* Right Controls & Telemetry Status */}
      <div className="flex items-center gap-5">
        {/* Python Engine Status Badge */}
        <div className="flex items-center gap-2 px-3 py-1 bg-[#111] border border-[#222] rounded">
          <div className="w-2 h-2 rounded-full bg-[#00F0FF] shadow-[0_0_8px_#00F0FF] animate-pulse"></div>
          <span className="text-[10px] font-mono text-[#00F0FF] uppercase tracking-wider font-bold">
            {state.isDemoMode ? 'PYTHON ENGINE CONNECTED' : 'LIVE TELEMETRY STREAM'}
          </span>
        </div>

        {/* Thermal Mode Toggle */}
        <button
          onClick={onToggleThermal}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-[11px] font-mono transition-all border ${
            isThermalMode
              ? 'bg-[#FF4E00]/20 text-[#FF4E00] border-[#FF4E00] shadow-[0_0_10px_#FF4E0033]'
              : 'bg-[#111] text-[#888] border-[#222] hover:text-white hover:border-[#444]'
          }`}
        >
          <Flame className={`w-3.5 h-3.5 ${isThermalMode ? 'text-[#FF4E00] animate-pulse' : 'text-[#666]'}`} />
          <span>THERMAL MAP</span>
        </button>

        {/* Reduced Motion Toggle */}
        <button
          onClick={onToggleMotion}
          className={`hidden lg:flex items-center gap-1.5 px-3 py-1 rounded text-[11px] font-mono transition-all border ${
            reducedMotion
              ? 'bg-[#1A1A1A] text-white border-[#444]'
              : 'bg-[#111] text-[#888] border-[#222] hover:text-white hover:border-[#444]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{reducedMotion ? 'MOTION: OFF' : 'MOTION: ON'}</span>
        </button>

        {/* Real-time Clock & Site Tag */}
        <div className="text-right flex flex-col justify-center">
          <div className="text-xs font-mono text-[#888] font-bold tracking-wider">
            {currentTime || '09:42:31.042'}
          </div>
          <div className="text-[9px] text-[#444] text-right uppercase tracking-widest font-bold">
            NORTH SEA CAMPUS / HUB-01
          </div>
        </div>
      </div>
    </header>
  );
}

