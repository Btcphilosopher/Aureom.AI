'use client';

import React from 'react';
import { DataCenterState } from '@/lib/types';

interface BottomKpiBarProps {
  state: DataCenterState;
}

export function BottomKpiBar({ state }: BottomKpiBarProps) {
  const itLoad = state.power.itLoadMw.toFixed(1);
  const facilityLoad = state.power.facilityLoadMw.toFixed(1);
  const pue = state.energy.pue.toFixed(2);
  const gpuUtil = state.buildings
    .flatMap((b) => b.floors.flatMap((f) => f.racks))
    .map((r) => r.gpuUtilizationAvg)
    .reduce((a, b, _, arr) => a + b / arr.length, 0)
    .toFixed(1);
  const coolingLoad = state.cooling.coolingLoadMw.toFixed(1);
  const activeAlerts = state.alerts.filter((a) => !a.acknowledged);

  const isCritical = activeAlerts.some((a) => a.severity === 'CRITICAL' || a.severity === 'EMERGENCY');

  // Recent 3 telemetry events
  const telemetryLogs = state.alerts.slice(0, 3);

  return (
    <div className="flex flex-col shrink-0 select-none border-t border-[#222] bg-[#0A0A0A] font-mono text-xs">
      {/* Upper Telemetry Details Grid */}
      <div className="h-28 p-4 flex items-center justify-between gap-6 overflow-x-auto">
        {/* Telemetry Stream Log */}
        <div className="flex flex-col gap-1 w-52 shrink-0 border-r border-[#222] pr-4">
          <div className="text-[9px] text-[#555] uppercase tracking-wider font-bold">
            Telemetry Feed
          </div>
          <div className="flex flex-col gap-1 overflow-hidden h-16">
            {telemetryLogs.length > 0 ? (
              telemetryLogs.map((log) => (
                <div
                  key={log.id}
                  className={`text-[10px] truncate ${
                    log.severity === 'CRITICAL' || log.severity === 'EMERGENCY'
                      ? 'text-[#FF4E00] font-bold'
                      : log.severity === 'WARNING'
                      ? 'text-amber-400'
                      : 'text-[#888]'
                  }`}
                >
                  [{log.timestamp}] {log.title}
                </div>
              ))
            ) : (
              <>
                <div className="text-[10px] text-[#888]">[09:42:30] SYNC_RACK_A1_SUCCESS</div>
                <div className="text-[10px] text-[#888]">[09:42:31] PUE_METRIC_UPDATE_RECEIVED</div>
                <div className="text-[10px] text-[#FF4E00]">[09:42:31] RACK_A3_TEMP_THRESHOLD_EXCEEDED</div>
              </>
            )}
          </div>
        </div>

        {/* 5 Core Metrics Columns */}
        <div className="flex-1 grid grid-cols-5 gap-4 px-4">
          <div className="text-center">
            <div className="text-[10px] text-[#555] uppercase mb-1 font-bold">IT Load</div>
            <div className="text-xl font-mono text-[#00F0FF] font-bold">
              {itLoad}<span className="text-xs text-[#666]">MW</span>
            </div>
          </div>

          <div className="text-center border-l border-[#222] pl-2">
            <div className="text-[10px] text-[#555] uppercase mb-1 font-bold">Facility</div>
            <div className="text-xl font-mono text-white font-bold">
              {facilityLoad}<span className="text-xs text-[#666]">MW</span>
            </div>
          </div>

          <div className="text-center border-l border-[#222] pl-2">
            <div className="text-[10px] text-[#555] uppercase mb-1 font-bold">PUE</div>
            <div
              className={`text-xl font-mono font-bold ${
                Number(pue) > 1.3 ? 'text-[#FF4E00]' : 'text-white'
              }`}
            >
              {pue}
            </div>
          </div>

          <div className="text-center border-l border-[#222] pl-2">
            <div className="text-[10px] text-[#555] uppercase mb-1 font-bold">GPU Util</div>
            <div className="text-xl font-mono text-[#00F0FF] font-bold">
              {gpuUtil}<span className="text-xs text-[#666]">%</span>
            </div>
          </div>

          <div className="text-center border-l border-[#222] pl-2">
            <div className="text-[10px] text-[#555] uppercase mb-1 font-bold">Cooling</div>
            <div className="text-xl font-mono text-white font-bold">
              {coolingLoad}<span className="text-xs text-[#666]">MW</span>
            </div>
          </div>
        </div>

        {/* SOC Battery Circular Ring Gauge */}
        <div className="w-40 flex items-center justify-center border-l border-[#222] pl-4 shrink-0">
          <div className="relative w-16 h-16 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <circle cx="18" cy="18" r="16" fill="none" stroke="#222" strokeWidth="2.5"></circle>
              <circle
                cx="18"
                cy="18"
                r="16"
                fill="none"
                stroke="#00F0FF"
                strokeWidth="2.5"
                strokeDasharray="100"
                strokeDashoffset="28"
              ></circle>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-[11px] font-mono text-white font-bold leading-none">
                {state.batteries[0]?.socPercent ? state.batteries[0].socPercent.toFixed(0) : '72'}%
              </span>
              <span className="text-[7px] text-[#555] font-bold uppercase mt-0.5">SOC</span>
            </div>
          </div>
        </div>
      </div>

      {/* Immersive Bottom Warning Strip Footer */}
      <footer
        className={`h-8 flex items-center px-6 justify-between transition-colors ${
          isCritical
            ? 'bg-[#FF4E00] text-black'
            : activeAlerts.length > 0
            ? 'bg-amber-500 text-black'
            : 'bg-[#0F141C] border-t border-[#222] text-[#888]'
        }`}
      >
        <div className="flex items-center gap-4">
          <span
            className={`text-[10px] font-black tracking-widest uppercase ${
              isCritical || activeAlerts.length > 0 ? 'text-black' : 'text-[#00F0FF]'
            }`}
          >
            Alert State: {isCritical ? 'Critical' : activeAlerts.length > 0 ? 'Warning' : 'Nominal'}
          </span>
          <span
            className={`text-[10px] font-medium ${
              isCritical || activeAlerts.length > 0 ? 'text-black/90 underline font-semibold' : 'text-[#666]'
            }`}
          >
            {activeAlerts.length} active facility warnings identified by Python Engine
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span
            className={`text-[9px] font-mono font-bold uppercase ${
              isCritical || activeAlerts.length > 0 ? 'text-black' : 'text-[#888]'
            }`}
          >
            Node: EUR-NORTH-01 / MASTER
          </span>
        </div>
      </footer>
    </div>
  );
}

