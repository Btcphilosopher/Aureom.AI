import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'DATACENTER.OUTPUTS | LIVE AI INFRASTRUCTURE OPERATIONS',
  description: 'AI Data Center Monitoring, Telemetry & Animated Digital Twin Interface',
  openGraph: {
    title: 'DATACENTER.OUTPUTS | LIVE AI INFRASTRUCTURE OPERATIONS',
    description: 'AI Data Center Monitoring, Telemetry & Animated Digital Twin Interface',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DATACENTER.OUTPUTS | LIVE AI INFRASTRUCTURE OPERATIONS',
    description: 'AI Data Center Monitoring, Telemetry & Animated Digital Twin Interface',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
