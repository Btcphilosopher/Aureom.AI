import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { telemetryState, userQuery } = await req.json();
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return NextResponse.json({
        recommendation: {
          timestamp: new Date().toLocaleTimeString(),
          title: 'AI Diagnostics Active (Simulated Model)',
          summary: 'Analyzed facility parameters: PUE is optimal at 1.24. Liquid CDU loop Delta-T is balanced across Data Halls A & B.',
          primaryContributor: 'Cooling Plant A / CDU Loop',
          probableCause: 'Normal operational load shift across high-density GPU racks.',
          affectedAsset: 'Chiller 03 & CDU-04',
          confidencePercent: 88,
          suggestedAction: 'Maintain current chiller staging sequence. No thermal throttling detected.',
        },
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `You are the Data Center AI Operations & Diagnostics Engine for DATACENTER.OUTPUTS.
Current Telemetry State:
IT Load: ${telemetryState?.power?.itLoadMw || 70.2} MW
Facility Load: ${telemetryState?.power?.facilityLoadMw || 86.7} MW
PUE: ${telemetryState?.energy?.pue || 1.24}
Cooling Load: ${telemetryState?.cooling?.coolingLoadMw || 13.8} MW
Active Chillers: ${telemetryState?.cooling?.chillersActive || 3} / 4
Active Alerts: ${telemetryState?.alerts?.length || 3}
User Context Query: ${userQuery || 'Diagnose current facility telemetry state and provide optimization recommendations.'}

Provide a JSON object response with:
- title (short string)
- summary (2-sentence overview)
- primaryContributor (string name of facility module)
- probableCause (string root cause)
- affectedAsset (string asset ID)
- confidencePercent (number 0-100)
- suggestedAction (concrete operator action button hint)
Respond ONLY in valid JSON format.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = response.text || '';
    let parsedJson = null;

    try {
      const jsonStart = text.indexOf('{');
      const jsonEnd = text.lastIndexOf('}');
      if (jsonStart !== -1 && jsonEnd !== -1) {
        parsedJson = JSON.parse(text.slice(jsonStart, jsonEnd + 1));
      }
    } catch (e) {
      // JSON parse fallback
    }

    if (!parsedJson) {
      parsedJson = {
        title: 'AI Facility Health Analysis',
        summary: text.slice(0, 180) || 'Facility running within nominal parameters with high GPU efficiency.',
        primaryContributor: 'Cooling Plant A',
        probableCause: 'Dynamic AI training burst',
        affectedAsset: 'Chiller 03',
        confidencePercent: 82,
        suggestedAction: 'Optimize CDU loop flow rate.',
      };
    }

    return NextResponse.json({ recommendation: parsedJson });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || 'Failed to process AI diagnostics' },
      { status: 500 }
    );
  }
}
