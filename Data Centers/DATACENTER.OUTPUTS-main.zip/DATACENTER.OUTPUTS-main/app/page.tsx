'use client';

import React, { useState, useEffect } from 'react';
import { DataCenterState, ViewName, RackState } from '@/lib/types';
import { createInitialDataCenterState, updateTelemetryTick } from '@/lib/telemetry-engine';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';
import { BottomKpiBar } from '@/components/layout/BottomKpiBar';
import { OverviewView } from '@/components/views/OverviewView';
import { DigitalTwinView } from '@/components/views/DigitalTwinView';
import { PowerView } from '@/components/views/PowerView';
import { CoolingView } from '@/components/views/CoolingView';
import { RacksView } from '@/components/views/RacksView';
import { GpuView } from '@/components/views/GpuView';
import { NetworkView } from '@/components/views/NetworkView';
import { EnergyView } from '@/components/views/EnergyView';
import { ThermalView } from '@/components/views/ThermalView';
import { AlertsView } from '@/components/views/AlertsView';
import { CapacityView } from '@/components/views/CapacityView';
import { MaintenanceView } from '@/components/views/MaintenanceView';
import { AiOperationsView } from '@/components/views/AiOperationsView';
import { SimulationView } from '@/components/views/SimulationView';
import { CommandPalette } from '@/components/ui/CommandPalette';

export default function Home() {
  // State definitions
  const [mounted, setMounted] = useState<boolean>(false);
  const [dataState, setDataState] = useState<DataCenterState>(() => createInitialDataCenterState());
  const [activeView, setActiveView] = useState<ViewName>('Overview');
  const [isThermalMode, setIsThermalMode] = useState<boolean>(false);
  const [reducedMotion, setReducedMotion] = useState<boolean>(false);
  const [selectedRackId, setSelectedRackId] = useState<string | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);

  // Set mounted flag
  useEffect(() => {
    const handle = requestAnimationFrame(() => {
      setMounted(true);
    });
    return () => cancelAnimationFrame(handle);
  }, []);

  // Real-time telemetry tick loop (simulates Python backend stream)
  useEffect(() => {
    const interval = setInterval(() => {
      setDataState((prev) => updateTelemetryTick(prev));
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Keyboard shortcut listener for '/' search command palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && (document.activeElement?.tagName !== 'INPUT')) {
        e.preventDefault();
        setIsCommandPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Failure simulation trigger handler
  const handleTriggerSimulation = (scenario: string) => {
    setDataState((prev) => {
      const next = { ...prev };
      if (scenario === 'GRID_OUTAGE') {
        next.power.gridInputMw = 0;
        next.power.substationMw = 0;
        next.batteries = next.batteries.map((b) => ({ ...b, status: 'DISCHARGING', currentPowerMw: -12.5 }));
        next.generators = next.generators.map((g) => ({ ...g, isRunning: true, currentOutputMw: 2.5 }));
        next.alerts = [
          {
            id: `ALT-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            title: 'CRITICAL: NATIONAL GRID POWER FAILURE DETECTED',
            description: 'Substation supply dropped to 0 MW. BESS active. Generators starting.',
            severity: 'CRITICAL',
            acknowledged: false,
            assetId: 'SUBSTATION-01',
            assetName: 'PRIMARY SUBSTATION',
          },
          ...next.alerts,
        ];
      } else if (scenario === 'NORMAL') {
        return createInitialDataCenterState();
      }
      return next;
    });
  };

  if (!mounted) {
    return (
      <div className="flex flex-col h-screen w-screen bg-[#050505] text-[#E0E0E0] items-center justify-center font-mono select-none">
        <div className="text-xl font-black tracking-tighter text-white">
          DATACENTER<span className="text-[#00F0FF]">.OUTPUTS</span>
        </div>
        <p className="text-[10px] tracking-[0.2em] text-[#666] font-bold mt-2 uppercase animate-pulse">
          INITIALIZING SECURE PYTHON ENGINE CONNECTION...
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-[#050505] text-[#E0E0E0] overflow-hidden font-mono select-none">
      {/* Top Operations Header */}
      <Header
        state={dataState}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        isThermalMode={isThermalMode}
        onToggleThermal={() => setIsThermalMode(!isThermalMode)}
        reducedMotion={reducedMotion}
        onToggleMotion={() => setReducedMotion(!reducedMotion)}
      />

      {/* Main Center Shell (Sidebar + Workspace View) */}
      <div className="flex flex-1 overflow-hidden relative">
        <Sidebar
          currentView={activeView}
          onSelectView={setActiveView}
          alertCount={dataState.alerts.filter((a) => !a.acknowledged).length}
        />

        {/* Dynamic View Loader */}
        <main className="flex-1 h-full overflow-hidden relative bg-[#050505]">
          {activeView === 'Overview' && (
            <OverviewView state={dataState} onSelectView={setActiveView} />
          )}

          {activeView === 'Digital Twin' && (
            <DigitalTwinView
              state={dataState}
              isThermalMode={isThermalMode}
              onToggleThermal={() => setIsThermalMode(!isThermalMode)}
              reducedMotion={reducedMotion}
              selectedRackId={selectedRackId}
              onSelectRack={setSelectedRackId}
            />
          )}

          {activeView === 'Power' && <PowerView state={dataState} />}

          {activeView === 'Cooling' && <CoolingView state={dataState} />}

          {activeView === 'Racks' && (
            <RacksView
              state={dataState}
              onSelectRack={(id) => {
                setSelectedRackId(id);
                setActiveView('Digital Twin');
              }}
            />
          )}

          {activeView === 'GPU' && <GpuView state={dataState} />}

          {activeView === 'Network' && <NetworkView state={dataState} />}

          {activeView === 'Energy' && <EnergyView state={dataState} />}

          {activeView === 'Thermal' && <ThermalView state={dataState} />}

          {activeView === 'Alerts' && <AlertsView state={dataState} />}

          {activeView === 'Capacity' && <CapacityView state={dataState} />}

          {activeView === 'Maintenance' && <MaintenanceView state={dataState} />}

          {activeView === 'AI Operations' && (
            <AiOperationsView
              state={dataState}
              onSelectView={setActiveView}
              onTriggerSimulation={handleTriggerSimulation}
            />
          )}

          {activeView === 'Simulation' && (
            <SimulationView state={dataState} onTriggerSimulation={handleTriggerSimulation} />
          )}
        </main>
      </div>

      {/* Fixed Bottom KPI Bar */}
      <BottomKpiBar state={dataState} />

      {/* Command Palette Modal */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectView={setActiveView}
        onSelectRack={(id) => {
          setSelectedRackId(id);
          setActiveView('Digital Twin');
        }}
        onToggleThermal={() => setIsThermalMode(!isThermalMode)}
      />
    </div>
  );
}
