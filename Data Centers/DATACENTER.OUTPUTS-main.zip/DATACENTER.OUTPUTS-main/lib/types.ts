export type AssetStatus = 'NORMAL' | 'WARNING' | 'DEGRADED' | 'CRITICAL' | 'OFFLINE' | 'MAINTENANCE' | 'UNKNOWN';

export type ThermalLevel = 'COOL' | 'NORMAL' | 'WARM' | 'HOT' | 'CRITICAL';

export interface TelemetryPoint {
  timestamp: string;
  assetId: string;
  assetType: string;
  metric: string;
  value: number;
  unit: string;
  quality?: string;
  source?: string;
}

export interface Asset {
  id: string;
  name: string;
  type: string;
  parentId?: string;
  status: AssetStatus;
  location: string;
}

export interface GPUState {
  id: string;
  name: string;
  utilization: number; // 0 - 100%
  temperature: number; // °C
  powerDrawWatts: number;
  memoryUsedGb: number;
  memoryTotalGb: number;
  tensorFlops: number;
  status: AssetStatus;
}

export interface ServerState {
  id: string;
  rackId: string;
  positionU: number;
  name: string;
  powerWatts: number;
  cpuUtilization: number;
  memoryUtilization: number;
  gpus: GPUState[];
  status: AssetStatus;
}

export interface RackState {
  id: string;
  name: string;
  zoneId: string;
  floorId: string;
  buildingId: string;
  row: number;
  column: number;
  powerKw: number;
  maxPowerKw: number;
  temperatureInlet: number;
  temperatureOutlet: number;
  gpuCount: number;
  gpuUtilizationAvg: number;
  thermalLevel: ThermalLevel;
  servers: ServerState[];
  status: AssetStatus;
}

export interface ZoneState {
  id: string;
  name: string;
  floorId: string;
  rackCount: number;
  totalPowerKw: number;
  avgTemp: number;
  status: AssetStatus;
}

export interface FloorState {
  id: string;
  name: string;
  buildingId: string;
  zones: ZoneState[];
  racks: RackState[];
  status: AssetStatus;
}

export interface BuildingState {
  id: string;
  name: string;
  floors: FloorState[];
  totalPowerMw: number;
  pue: number;
  status: AssetStatus;
}

export interface PowerState {
  gridInputMw: number;
  solarInputMw: number;
  substationMw: number;
  transformerLossesMw: number;
  upsInputMw: number;
  upsOutputMw: number;
  pduOutputMw: number;
  itLoadMw: number;
  facilityLoadMw: number;
  totalMw: number;
  gridFrequencyHz: number;
  status: AssetStatus;
}

export interface BatteryState {
  id: string;
  socPercent: number; // 0 - 100%
  capacityMwh: number;
  currentPowerMw: number; // Positive = Charging, Negative = Discharging
  status: 'CHARGING' | 'DISCHARGING' | 'STANDBY';
}

export interface GeneratorState {
  id: string;
  name: string;
  capacityMw: number;
  currentOutputMw: number;
  fuelLevelPercent: number;
  isRunning: boolean;
  status: AssetStatus;
}

export interface UPSState {
  id: string;
  name: string;
  loadPercent: number;
  efficiencyPercent: number;
  batteryBackupMinutes: number;
  status: AssetStatus;
}

export interface CoolingState {
  chillersTotal: number;
  chillersActive: number;
  coolingLoadMw: number;
  supplyTempC: number;
  returnTempC: number;
  waterFlowLps: number;
  copRatio: number;
  coolingTowersActive: number;
  cduCount: number;
  status: AssetStatus;
}

export interface NetworkState {
  coreBandwidthTbps: number;
  spineBandwidthTbps: number;
  leafBandwidthTbps: number;
  totalTrafficTbps: number;
  packetLossRate: number;
  latencyMs: number;
  congestedLinksCount: number;
  status: AssetStatus;
}

export interface EnergyState {
  pue: number;
  cue: number;
  wue: number;
  renewableRatioPercent: number;
  carbonIntensityGPerKwh: number;
  dailyEnergyMwh: number;
}

export interface AlertState {
  id: string;
  timestamp: string;
  severity: 'WARNING' | 'CRITICAL' | 'EMERGENCY';
  title: string;
  description: string;
  assetId: string;
  assetName: string;
  acknowledged: boolean;
}

export interface AiRecommendation {
  timestamp: string;
  title: string;
  summary: string;
  primaryContributor: string;
  probableCause: string;
  affectedAsset: string;
  confidencePercent: number;
  suggestedAction: string;
}

export interface DataCenterState {
  timestamp: string;
  campusName: string;
  buildings: BuildingState[];
  power: PowerState;
  cooling: CoolingState;
  network: NetworkState;
  energy: EnergyState;
  batteries: BatteryState[];
  generators: GeneratorState[];
  upss: UPSState[];
  alerts: AlertState[];
  aiRecommendation?: AiRecommendation;
  isDemoMode: boolean;
  connectionStatus: string;
  lastUpdateAgeSeconds: number;
}

export type ViewName =
  | 'Overview'
  | 'Digital Twin'
  | 'Power'
  | 'Cooling'
  | 'Racks'
  | 'GPU'
  | 'Network'
  | 'Energy'
  | 'Thermal'
  | 'Alerts'
  | 'Capacity'
  | 'Maintenance'
  | 'AI Operations'
  | 'Simulation';

export type DigitalTwinVisualMode = 'STANDARD' | 'POWER_FLOW' | 'COOLING_FLOW' | 'NETWORK_FLOW' | 'THERMAL_HEATMAP';

export type CameraLevel = 'CAMPUS' | 'BUILDING' | 'FLOOR' | 'ZONE' | 'RACK' | 'SERVER' | 'GPU';
