import {
  DataCenterState,
  BuildingState,
  FloorState,
  RackState,
  ServerState,
  GPUState,
  PowerState,
  CoolingState,
  NetworkState,
  EnergyState,
  BatteryState,
  GeneratorState,
  UPSState,
  AlertState,
  ThermalLevel,
  AssetStatus,
} from './types';

function createMockGpus(serverId: string, count = 8): GPUState[] {
  return Array.from({ length: count }, (_, i) => {
    const util = 70 + Math.random() * 25;
    const temp = 55 + (util / 100) * 28 + Math.random() * 4;
    return {
      id: `${serverId}-GPU-${i}`,
      name: `NVIDIA H100 SXM5 #${i + 1}`,
      utilization: Math.round(util * 10) / 10,
      temperature: Math.round(temp * 10) / 10,
      powerDrawWatts: Math.round(350 + (util / 100) * 350),
      memoryUsedGb: Math.round(52 + Math.random() * 24),
      memoryTotalGb: 80,
      tensorFlops: 989,
      status: temp > 84 ? 'WARNING' : 'NORMAL',
    };
  });
}

function createMockServers(rackId: string, count = 4): ServerState[] {
  return Array.from({ length: count }, (_, i) => {
    const sId = `${rackId}-SVR-${i + 1}`;
    const gpus = createMockGpus(sId, 2);
    const cpu = 60 + Math.random() * 30;
    const power = 800 + gpus.reduce((acc, g) => acc + g.powerDrawWatts, 0);
    return {
      id: sId,
      rackId,
      positionU: i * 4 + 1,
      name: `HGX H100 Node ${i + 1}`,
      powerWatts: Math.round(power),
      cpuUtilization: Math.round(cpu * 10) / 10,
      memoryUtilization: Math.round((70 + Math.random() * 20) * 10) / 10,
      gpus,
      status: 'NORMAL',
    };
  });
}

function createMockRacks(buildingId: string, floorId: string, count = 12): RackState[] {
  return Array.from({ length: count }, (_, i) => {
    const rId = `${buildingId}-${floorId.slice(-1)}-${(i + 1).toString().padStart(3, '0')}`;
    const servers = createMockServers(rId, 3);
    const powerKw = servers.reduce((acc, s) => acc + s.powerWatts, 0) / 1000;
    const avgGpuUtil =
      servers.flatMap((s) => s.gpus).reduce((acc, g) => acc + g.utilization, 0) /
      (servers.length * 2);
    
    // Determine thermal status
    const tempIn = 21 + Math.random() * 3;
    const tempOut = tempIn + (powerKw / 35) * 12 + Math.random() * 2;
    let thermalLevel: ThermalLevel = 'NORMAL';
    let status: AssetStatus = 'NORMAL';
    if (tempOut > 36) {
      thermalLevel = 'CRITICAL';
      status = 'CRITICAL';
    } else if (tempOut > 32) {
      thermalLevel = 'HOT';
      status = 'WARNING';
    } else if (tempOut > 28) {
      thermalLevel = 'WARM';
    }

    return {
      id: rId,
      name: `RACK ${rId}`,
      zoneId: `ZONE-${(i % 3) + 1}`,
      floorId,
      buildingId,
      row: Math.floor(i / 4) + 1,
      column: (i % 4) + 1,
      powerKw: Math.round(powerKw * 10) / 10,
      maxPowerKw: 40,
      temperatureInlet: Math.round(tempIn * 10) / 10,
      temperatureOutlet: Math.round(tempOut * 10) / 10,
      gpuCount: servers.length * 2,
      gpuUtilizationAvg: Math.round(avgGpuUtil * 10) / 10,
      thermalLevel,
      servers,
      status,
    };
  });
}

export function createInitialDataCenterState(): DataCenterState {
  const buildingA: BuildingState = {
    id: 'BLDG-A',
    name: 'DATA HALL A (NORTH)',
    floors: [
      {
        id: 'FL-A1',
        name: 'FLOOR 1 - COMPUTE HALL',
        buildingId: 'BLDG-A',
        zones: [
          { id: 'Z-1', name: 'ZONE 1 - HIGH DENSITY', floorId: 'FL-A1', rackCount: 12, totalPowerKw: 380, avgTemp: 24.2, status: 'NORMAL' },
          { id: 'Z-2', name: 'ZONE 2 - GPU CLUSTER 01', floorId: 'FL-A1', rackCount: 12, totalPowerKw: 420, avgTemp: 25.8, status: 'NORMAL' },
        ],
        racks: createMockRacks('BLDG-A', 'FL-A1', 24),
        status: 'NORMAL',
      },
    ],
    totalPowerMw: 41.2,
    pue: 1.23,
    status: 'NORMAL',
  };

  const buildingB: BuildingState = {
    id: 'BLDG-B',
    name: 'DATA HALL B (SOUTH)',
    floors: [
      {
        id: 'FL-B1',
        name: 'FLOOR 1 - INFERENCE HALL',
        buildingId: 'BLDG-B',
        zones: [
          { id: 'Z-3', name: 'ZONE 3 - GPU CLUSTER 02', floorId: 'FL-B1', rackCount: 12, totalPowerKw: 390, avgTemp: 24.8, status: 'NORMAL' },
        ],
        racks: createMockRacks('BLDG-B', 'FL-B1', 24),
        status: 'NORMAL',
      },
    ],
    totalPowerMw: 39.5,
    pue: 1.25,
    status: 'NORMAL',
  };

  const power: PowerState = {
    gridInputMw: 74.3,
    solarInputMw: 12.4,
    substationMw: 86.7,
    transformerLossesMw: 1.2,
    upsInputMw: 85.5,
    upsOutputMw: 84.0,
    pduOutputMw: 83.5,
    itLoadMw: 70.2,
    facilityLoadMw: 86.7,
    totalMw: 86.7,
    gridFrequencyHz: 50.02,
    status: 'NORMAL',
  };

  const cooling: CoolingState = {
    chillersTotal: 4,
    chillersActive: 3,
    coolingLoadMw: 13.8,
    supplyTempC: 14.2,
    returnTempC: 24.8,
    waterFlowLps: 450,
    copRatio: 5.2,
    coolingTowersActive: 6,
    cduCount: 12,
    status: 'NORMAL',
  };

  const network: NetworkState = {
    coreBandwidthTbps: 12.8,
    spineBandwidthTbps: 25.6,
    leafBandwidthTbps: 51.2,
    totalTrafficTbps: 18.4,
    packetLossRate: 0.0001,
    latencyMs: 0.42,
    congestedLinksCount: 0,
    status: 'NORMAL',
  };

  const energy: EnergyState = {
    pue: 1.24,
    cue: 0.08,
    wue: 0.22,
    renewableRatioPercent: 84.5,
    carbonIntensityGPerKwh: 42.0,
    dailyEnergyMwh: 1842.0,
  };

  const batteries: BatteryState[] = [
    { id: 'BATT-01', socPercent: 78.5, capacityMwh: 25.0, currentPowerMw: 1.2, status: 'CHARGING' },
    { id: 'BATT-02', socPercent: 79.1, capacityMwh: 25.0, currentPowerMw: 1.2, status: 'CHARGING' },
  ];

  const generators: GeneratorState[] = [
    { id: 'GEN-01', name: 'CAT D3516B Diesel #1', capacityMw: 2.5, currentOutputMw: 0, fuelLevelPercent: 98.5, isRunning: false, status: 'NORMAL' },
    { id: 'GEN-02', name: 'CAT D3516B Diesel #2', capacityMw: 2.5, currentOutputMw: 0, fuelLevelPercent: 97.8, isRunning: false, status: 'NORMAL' },
    { id: 'GEN-03', name: 'CAT D3516B Diesel #3', capacityMw: 2.5, currentOutputMw: 0, fuelLevelPercent: 99.1, isRunning: false, status: 'NORMAL' },
    { id: 'GEN-04', name: 'CAT D3516B Diesel #4', capacityMw: 2.5, currentOutputMw: 0, fuelLevelPercent: 98.0, isRunning: false, status: 'NORMAL' },
  ];

  const upss: UPSState[] = [
    { id: 'UPS-A1', name: 'Eaton 9395P Module A1', loadPercent: 72.4, efficiencyPercent: 97.4, batteryBackupMinutes: 18.5, status: 'NORMAL' },
    { id: 'UPS-A2', name: 'Eaton 9395P Module A2', loadPercent: 74.1, efficiencyPercent: 97.2, batteryBackupMinutes: 18.2, status: 'NORMAL' },
    { id: 'UPS-B1', name: 'Eaton 9395P Module B1', loadPercent: 69.8, efficiencyPercent: 97.6, batteryBackupMinutes: 19.1, status: 'NORMAL' },
    { id: 'UPS-B2', name: 'Eaton 9395P Module B2', loadPercent: 71.0, efficiencyPercent: 97.5, batteryBackupMinutes: 18.8, status: 'NORMAL' },
  ];

  const alerts: AlertState[] = [
    {
      id: 'ALT-9042',
      timestamp: new Date().toLocaleTimeString(),
      severity: 'WARNING',
      title: 'Chiller 03 Efficiency Degradation',
      description: 'Coefficient of Performance dropped to 4.1. Thermal delta elevated on Data Hall A return loop.',
      assetId: 'CHILLER-03',
      assetName: 'Chiller 03 (Mechanical Plant)',
      acknowledged: false,
    },
    {
      id: 'ALT-9038',
      timestamp: new Date(Date.now() - 180000).toLocaleTimeString(),
      severity: 'WARNING',
      title: 'Rack BLDG-A-1-018 High Temperature',
      description: 'Outlet temp reached 33.4°C under heavy AI training workload. Liquid CDU flow auto-boosted.',
      assetId: 'BLDG-A-1-018',
      assetName: 'Rack BLDG-A-1-018',
      acknowledged: true,
    },
    {
      id: 'ALT-9012',
      timestamp: new Date(Date.now() - 600000).toLocaleTimeString(),
      severity: 'CRITICAL',
      title: 'Grid Frequency Drift Fluctuation',
      description: 'Substation frequency transient 49.82 Hz detected. UPS online double-conversion active.',
      assetId: 'SUBSTATION-MAIN',
      assetName: 'North Sea Primary Substation',
      acknowledged: true,
    },
  ];

  return {
    timestamp: new Date().toISOString(),
    campusName: 'NORTH SEA AI CAMPUS',
    buildings: [buildingA, buildingB],
    power,
    cooling,
    network,
    energy,
    batteries,
    generators,
    upss,
    alerts,
    aiRecommendation: {
      timestamp: new Date().toLocaleTimeString(),
      title: 'Cooling Efficiency Declining on Plant A',
      summary: 'PUE increased by 4.2% over the last 45 minutes due to Chiller 03 staging mismatch.',
      primaryContributor: 'Cooling Plant A',
      probableCause: 'Chiller compressor efficiency reduction under thermal surge',
      affectedAsset: 'Chiller 03',
      confidencePercent: 78,
      suggestedAction: 'Increase CDU pump flow rate by +12% or stage Chiller 04 from standby.',
    },
    isDemoMode: true,
    connectionStatus: 'LIVE PYTHON ENGINE',
    lastUpdateAgeSeconds: 0.1,
  };
}

export function updateTelemetryTick(prevState: DataCenterState): DataCenterState {
  const noise = (Math.random() - 0.5) * 0.4;
  let itMw = Math.min(85, Math.max(60, prevState.power.itLoadMw + noise));
  let chillMw = Math.round((itMw * 0.19 + noise * 0.2) * 10) / 10;
  let gridMw = Math.round((itMw + chillMw + 2.5) * 10) / 10;
  let pue = Math.round((gridMw / itMw) * 100) / 100;

  return {
    ...prevState,
    timestamp: new Date().toISOString(),
    power: {
      ...prevState.power,
      itLoadMw: Math.round(itMw * 10) / 10,
      gridInputMw: Math.round(gridMw * 10) / 10,
      substationMw: Math.round((gridMw + 12.4) * 10) / 10,
      facilityLoadMw: Math.round((gridMw + 12.4) * 10) / 10,
    },
    cooling: {
      ...prevState.cooling,
      coolingLoadMw: Math.round(chillMw * 10) / 10,
    },
    energy: {
      ...prevState.energy,
      pue,
    },
    lastUpdateAgeSeconds: 0.1,
  };
}

export class TelemetryEngine {
  private state: DataCenterState;
  private listeners: Set<(state: DataCenterState) => void> = new Set();
  private intervalId: NodeJS.Timeout | null = null;
  private historyBuffer: DataCenterState[] = [];
  private simulationMode: 'NORMAL' | 'GRID_OUTAGE' | 'COOLING_FAILURE' | 'GPU_SURGE' = 'NORMAL';

  constructor() {
    this.state = createInitialDataCenterState();
    this.historyBuffer.push(JSON.parse(JSON.stringify(this.state)));
    this.startLiveSimulation();
  }

  public getState(): DataCenterState {
    return this.state;
  }

  public subscribe(listener: (state: DataCenterState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l(this.state));
  }

  public startLiveSimulation() {
    if (this.intervalId) return;
    this.intervalId = setInterval(() => {
      this.tick();
    }, 1200);
  }

  public stopLiveSimulation() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public setSimulationMode(mode: 'NORMAL' | 'GRID_OUTAGE' | 'COOLING_FAILURE' | 'GPU_SURGE') {
    this.simulationMode = mode;
    this.tick();
  }

  public triggerWhatIfSequence(scenario: string) {
    if (scenario === 'GRID_OUTAGE') {
      this.setSimulationMode('GRID_OUTAGE');
    } else if (scenario === 'COOLING_FAILURE') {
      this.setSimulationMode('COOLING_FAILURE');
    } else if (scenario === 'GPU_SURGE') {
      this.setSimulationMode('GPU_SURGE');
    } else {
      this.setSimulationMode('NORMAL');
    }
  }

  private tick() {
    const now = new Date();
    const noise = (Math.random() - 0.5) * 0.4;
    
    let itMw = this.state.power.itLoadMw;
    let gridMw = this.state.power.gridInputMw;
    let chillMw = this.state.cooling.coolingLoadMw;
    let pue = this.state.energy.pue;

    if (this.simulationMode === 'GRID_OUTAGE') {
      gridMw = 0.0;
      // Batteries discharging to supply IT load, generators starting
      this.state.power.gridInputMw = 0;
      this.state.power.status = 'CRITICAL';
      this.state.batteries = this.state.batteries.map((b) => ({
        ...b,
        status: 'DISCHARGING',
        currentPowerMw: -35.0,
        socPercent: Math.max(10, b.socPercent - 0.5),
      }));
      this.state.generators = this.state.generators.map((g, idx) => ({
        ...g,
        isRunning: true,
        currentOutputMw: 2.4,
        status: 'WARNING',
      }));
    } else if (this.simulationMode === 'COOLING_FAILURE') {
      chillMw = 4.2; // degraded
      pue = 1.48;
      this.state.cooling.status = 'CRITICAL';
      this.state.cooling.chillersActive = 1;
    } else if (this.simulationMode === 'GPU_SURGE') {
      itMw = 94.2;
      gridMw = 98.4;
      chillMw = 18.6;
      pue = 1.32;
    } else {
      // Normal variation
      itMw = Math.min(85, Math.max(60, itMw + noise));
      chillMw = Math.round((itMw * 0.19 + noise * 0.2) * 10) / 10;
      gridMw = Math.round((itMw + chillMw + 2.5) * 10) / 10;
      pue = Math.round((gridMw / itMw) * 100) / 100;
      this.state.power.status = 'NORMAL';
      this.state.cooling.status = 'NORMAL';
      this.state.cooling.chillersActive = 3;
      this.state.batteries = this.state.batteries.map((b) => ({
        ...b,
        status: 'CHARGING',
        currentPowerMw: 1.2,
        socPercent: Math.min(100, b.socPercent + 0.05),
      }));
      this.state.generators = this.state.generators.map((g) => ({
        ...g,
        isRunning: false,
        currentOutputMw: 0,
        status: 'NORMAL',
      }));
    }

    this.state.power.itLoadMw = Math.round(itMw * 10) / 10;
    this.state.power.gridInputMw = Math.round(gridMw * 10) / 10;
    this.state.power.substationMw = Math.round((gridMw + 12.4) * 10) / 10;
    this.state.power.facilityLoadMw = this.state.power.substationMw;
    this.state.cooling.coolingLoadMw = Math.round(chillMw * 10) / 10;
    this.state.energy.pue = pue;
    this.state.timestamp = now.toISOString();
    this.state.lastUpdateAgeSeconds = 0.1;

    // Buffer history
    if (this.historyBuffer.length > 100) {
      this.historyBuffer.shift();
    }
    this.historyBuffer.push(JSON.parse(JSON.stringify(this.state)));

    this.notify();
  }

  public getHistory(): DataCenterState[] {
    return this.historyBuffer;
  }
}

export const globalTelemetryEngine = new TelemetryEngine();
