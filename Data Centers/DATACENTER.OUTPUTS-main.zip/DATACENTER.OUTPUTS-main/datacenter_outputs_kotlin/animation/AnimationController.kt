package com.datacenter.outputs.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import com.datacenter.outputs.core.models.DataCenterState

object AnimationDurations {
    const val FAST = 150
    const val NORMAL = 300
    const val SLOW = 600
    const val CAMERA = 800
}

data class AnimationIntensity(
    val powerParticleVelocity: Float,
    val coolantVelocity: Float,
    val packetVelocity: Float,
    val gpuPulseRateHz: Float,
    val thermalIntensity: Float,
    val alertPulseSpeed: Float
) {
    companion object {
        fun calculate(state: DataCenterState): AnimationIntensity {
            val itPower = state.power.itLoadMw
            val powerVel = (itPower / 100.0).coerceIn(0.2, 3.0).toFloat()
            
            val coolingLoad = state.cooling.coolingLoadMw
            val coolantVel = (coolingLoad / 20.0).coerceIn(0.3, 2.5).toFloat()
            
            val traffic = state.network.totalTrafficTbps
            val packetVel = (traffic / 30.0).coerceIn(0.2, 3.0).toFloat()
            
            val gpuAvg = state.buildings.flatMap { b -> b.floors.flatMap { f -> f.racks } }.map { it.gpuUtilizationAvg }.average().let { if (it.isNaN()) 75.0 else it }
            val gpuPulse = (gpuAvg / 25.0).coerceIn(0.5, 4.0).toFloat()
            
            val maxTemp = state.buildings.flatMap { b -> b.floors.flatMap { f -> f.racks } }.maxOfOrNull { it.temperatureOutlet } ?: 28.0
            val thermal = ((maxTemp - 20.0) / 25.0).coerceIn(0.0, 1.0).toFloat()
            
            val criticalAlerts = state.alerts.count { it.severity == "CRITICAL" || it.severity == "EMERGENCY" }
            val alertSpeed = if (criticalAlerts > 0) 2.5f else 1.0f

            return AnimationIntensity(
                powerParticleVelocity = powerVel,
                coolantVelocity = coolantVel,
                packetVelocity = packetVel,
                gpuPulseRateHz = gpuPulse,
                thermalIntensity = thermal,
                alertPulseSpeed = alertSpeed
            )
        }
    }
}

class PowerFlowAnimation {
    var particlePhase = 0f
    fun update(deltaSeconds: Float, speedMultiplier: Float) {
        particlePhase = (particlePhase + deltaSeconds * 2.0f * speedMultiplier) % 1.0f
    }
}

class CoolingFlowAnimation {
    var fluidPhase = 0f
    fun update(deltaSeconds: Float, speedMultiplier: Float) {
        fluidPhase = (fluidPhase + deltaSeconds * 1.5f * speedMultiplier) % 1.0f
    }
}

class NetworkFlowAnimation {
    var packetPhase = 0f
    fun update(deltaSeconds: Float, speedMultiplier: Float) {
        packetPhase = (packetPhase + deltaSeconds * 3.0f * speedMultiplier) % 1.0f
    }
}

class ThermalAnimation {
    var heatPulsePhase = 0f
    fun update(deltaSeconds: Float) {
        heatPulsePhase = (heatPulsePhase + deltaSeconds * 1.0f) % 1.0f
    }
}

class CameraState(
    var x: Float = 0f,
    var y: Float = 0f,
    var scale: Float = 1.0f,
    var rotation: Float = 0f,
    var targetRackId: String? = null
)

class CameraAnimation {
    val animX = Animatable(0f)
    val animY = Animatable(0f)
    val animScale = Animatable(1.0f)

    suspend fun animateTo(targetX: Float, targetY: Float, targetScale: Float) {
        animX.animateTo(targetX, tween(AnimationDurations.CAMERA, easing = LinearEasing))
        animY.animateTo(targetY, tween(AnimationDurations.CAMERA, easing = LinearEasing))
        animScale.animateTo(targetScale, tween(AnimationDurations.CAMERA, easing = LinearEasing))
    }
}
