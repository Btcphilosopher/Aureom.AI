package com.datacenter.outputs.data.websocket

import com.datacenter.outputs.core.models.TelemetryPoint
import io.ktor.client.*
import io.ktor.client.plugins.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json

class TelemetryWebSocketClient(
    private val wsUrl: String = "ws://localhost:8000/ws/telemetry"
) {
    private val client = HttpClient {
        install(WebSockets)
    }

    private val json = Json { ignoreUnknownKeys = true }

    fun observeTelemetry(): Flow<TelemetryPoint> = flow {
        try {
            client.webSocket(wsUrl) {
                for (frame in incoming) {
                    if (frame is Frame.Text) {
                        val text = frame.readText()
                        val point = json.decodeFromString<TelemetryPoint>(text)
                        emit(point)
                    }
                }
            }
        } catch (e: Exception) {
            // Error handling or reconnection flow
        }
    }

    fun close() {
        client.close()
    }
}
