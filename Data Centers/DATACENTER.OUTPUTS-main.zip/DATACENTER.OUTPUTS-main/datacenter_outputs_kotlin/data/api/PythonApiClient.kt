package com.datacenter.outputs.data.api

import com.datacenter.outputs.core.models.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json

class PythonApiClient(
    private val baseUrl: String = "http://localhost:8000"
) {
    private val client = HttpClient {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                prettyPrint = true
                isLenient = true
            })
        }
    }

    suspend fun checkHealth(): Boolean {
        return try {
            val response: Map<String, String> = client.get("$baseUrl/health").body()
            response["status"] == "ok" || response["status"] == "healthy"
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getOverview(): OverviewState {
        return client.get("$baseUrl/overview").body()
    }

    suspend fun getAssets(): List<Asset> {
        return client.get("$baseUrl/assets").body()
    }

    suspend fun getTelemetry(assetId: String? = null, metric: String? = null): List<TelemetryPoint> {
        return client.get("$baseUrl/telemetry") {
            assetId?.let { parameter("assetId", it) }
            metric?.let { parameter("metric", it) }
        }.body()
    }

    suspend fun getTelemetryLatest(): DataCenterState {
        return client.get("$baseUrl/telemetry/latest").body()
    }

    suspend fun getPower(): PowerState {
        return client.get("$baseUrl/power").body()
    }

    suspend fun getCooling(): CoolingState {
        return client.get("$baseUrl/cooling").body()
    }

    suspend fun getNetwork(): NetworkState {
        return client.get("$baseUrl/network").body()
    }

    suspend fun getEnergy(): EnergyState {
        return client.get("$baseUrl/energy").body()
    }

    suspend fun getAlerts(): List<AlertState> {
        return client.get("$baseUrl/alerts").body()
    }

    suspend fun triggerSimulation(scenario: String): DataCenterState {
        return client.post("$baseUrl/simulation") {
            parameter("scenario", scenario)
        }.body()
    }

    fun close() {
        client.close()
    }
}
