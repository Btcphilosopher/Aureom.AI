rootProject.name = "datacenter_outputs_kotlin"
