package com.datacenter.outputs.tests

import com.datacenter.outputs.animation.AnimationIntensity
import com.datacenter.outputs.core.models.DataCenterState
import com.datacenter.outputs.core.models.TelemetryPoint
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DataCenterStateTest {

    @Test
    fun testTelemetryParsing() {
        val jsonStr = """
            {
                "timestamp": "2026-09-01T02:10:00Z",
                "assetId": "RACK-A-042",
                "assetType": "RACK",
                "metric": "power",
                "value": 82.4,
                "unit": "kW",
                "quality": "GOOD",
                "source": "PYTHON_ENGINE"
            }
        """.trimIndent()

        val json = Json { ignoreUnknownKeys = true }
        val point = json.decodeFromString<TelemetryPoint>(jsonStr)

        assertEquals("RACK-A-042", point.assetId)
        assertEquals(82.4, point.value)
        assertEquals("kW", point.unit)
    }

    @Test
    fun testAnimationIntensityCalculation() {
        val state = DataCenterState()
        val intensity = AnimationIntensity.calculate(state)

        assertTrue(intensity.powerParticleVelocity > 0f)
        assertTrue(intensity.coolantVelocity > 0f)
        assertTrue(intensity.packetVelocity > 0f)
    }
}
