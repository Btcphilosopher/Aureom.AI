package com.datacenter.outputs.core.models

import kotlinx.serialization.Serializable

@Serializable
enum class AssetStatus {
    NORMAL,
    WARNING,
    DEGRADED,
    CRITICAL,
    OFFLINE,
    MAINTENANCE,
    UNKNOWN
}

@Serializable
enum class ThermalLevel {
    COOL,
    NORMAL,
    WARM,
    HOT,
    CRITICAL
}

@Serializable
data class TelemetryPoint(
    val timestamp: String,
    val assetId: String,
    val assetType: String,
    val metric: String,
    val value: Double,
    val unit: String,
    val quality: String = "GOOD",
    val source: String = "PYTHON_ENGINE"
)

@Serializable
data class Asset(
    val id: String,
    val name: String,
    val type: String,
    val parentId: String? = null,
    val status: AssetStatus = AssetStatus.NORMAL,
    val location: String = ""
)

@Serializable
data class GPUState(
    val id: String,
    val name: String = "NVIDIA H100 SXM5",
    val utilization: Double, // 0.0 - 100.0
    val temperature: Double, // °C
    val powerDrawWatts: Double,
    val memoryUsedGb: Double,
    val memoryTotalGb: Double = 80.0,
    val tensorFlops: Double = 989.0,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class ServerState(
    val id: String,
    val rackId: String,
    val positionU: Int,
    val name: String,
    val powerWatts: Double,
    val cpuUtilization: Double,
    val memoryUtilization: Double,
    val gpus: List<GPUState> = emptyList(),
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class RackState(
    val id: String,
    val name: String,
    val zoneId: String,
    val floorId: String,
    val buildingId: String,
    val row: Int,
    val column: Int,
    val powerKw: Double,
    val maxPowerKw: Double = 40.0,
    val temperatureInlet: Double,
    val temperatureOutlet: Double,
    val gpuCount: Int = 8,
    val gpuUtilizationAvg: Double,
    val thermalLevel: ThermalLevel = ThermalLevel.NORMAL,
    val servers: List<ServerState> = emptyList(),
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class ZoneState(
    val id: String,
    val name: String,
    val floorId: String,
    val rackCount: Int,
    val totalPowerKw: Double,
    val avgTemp: Double,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class FloorState(
    val id: String,
    val name: String,
    val buildingId: String,
    val zones: List<ZoneState> = emptyList(),
    val racks: List<RackState> = emptyList(),
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class BuildingState(
    val id: String,
    val name: String,
    val floors: List<FloorState> = emptyList(),
    val totalPowerMw: Double,
    val pue: Double,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class PowerState(
    val gridInputMw: Double,
    val solarInputMw: Double = 12.4,
    val substationMw: Double,
    val transformerLossesMw: Double,
    val upsInputMw: Double,
    val upsOutputMw: Double,
    val pduOutputMw: Double,
    val itLoadMw: Double,
    val facilityLoadMw: Double,
    val totalMw: Double,
    val gridFrequencyHz: Double = 50.0,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class BatteryState(
    val id: String,
    val socPercent: Double, // State of Charge 0-100%
    val capacityMwh: Double = 50.0,
    val currentPowerMw: Double, // Positive = Charging, Negative = Discharging
    val status: String = "STANDBY" // CHARGING, DISCHARGING, STANDBY
)

@Serializable
data class GeneratorState(
    val id: String,
    val name: String,
    val capacityMw: Double = 2.5,
    val currentOutputMw: Double = 0.0,
    val fuelLevelPercent: Double = 98.5,
    val isRunning: Boolean = false,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class UPSState(
    val id: String,
    val name: String,
    val loadPercent: Double,
    val efficiencyPercent: Double = 97.4,
    val batteryBackupMinutes: Double = 18.5,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class CoolingState(
    val chillersTotal: Int = 4,
    val chillersActive: Int = 3,
    val coolingLoadMw: Double,
    val supplyTempC: Double = 14.2,
    val returnTempC: Double = 24.8,
    val waterFlowLps: Double = 450.0,
    val copRatio: Double = 5.2, // Coefficient of Performance
    val coolingTowersActive: Int = 6,
    val cduCount: Int = 12,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class NetworkState(
    val coreBandwidthTbps: Double = 12.8,
    val spineBandwidthTbps: Double = 25.6,
    val leafBandwidthTbps: Double = 51.2,
    val totalTrafficTbps: Double = 18.4,
    val packetLossRate: Double = 0.0001,
    val latencyMs: Double = 0.42,
    val congestedLinksCount: Int = 0,
    val status: AssetStatus = AssetStatus.NORMAL
)

@Serializable
data class EnergyState(
    val pue: Double = 1.24,
    val cue: Double = 0.08, // Carbon Usage Effectiveness
    val wue: Double = 0.22, // Water Usage Effectiveness
    val renewableRatioPercent: Double = 84.5,
    val carbonIntensityGPerKwh: Double = 42.0,
    val dailyEnergyMwh: Double = 1842.0
)

@Serializable
data class AlertState(
    val id: String,
    val timestamp: String,
    val severity: String, // WARNING, CRITICAL, EMERGENCY
    val title: String,
    val description: String,
    val assetId: String,
    val assetName: String,
    val acknowledged: Boolean = false
)

@Serializable
data class DataCenterState(
    val timestamp: String = "",
    val campusName: String = "NORTH SEA AI CAMPUS",
    val buildings: List<BuildingState> = emptyList(),
    val power: PowerState = PowerState(70.2 + 16.5, 12.4, 86.7, 1.2, 85.5, 84.0, 83.5, 70.2, 86.7, 86.7),
    val cooling: CoolingState = CoolingState(4, 3, 13.8),
    val network: NetworkState = NetworkState(),
    val energy: EnergyState = EnergyState(),
    val batteries: List<BatteryState> = emptyList(),
    val generators: List<GeneratorState> = emptyList(),
    val upss: List<UPSState> = emptyList(),
    val alerts: List<AlertState> = emptyList(),
    val isDemoMode: Boolean = true,
    val connectionStatus: String = "LIVE PYTHON ENGINE",
    val lastUpdateAgeSeconds: Double = 0.0
)

@Serializable
data class OverviewState(
    val campusName: String,
    val totalPowerMw: Double,
    val itLoadMw: Double,
    val pue: Double,
    val activeAlertsCount: Int,
    val gpuAvgUtilization: Double,
    val connectionStatus: String
)
