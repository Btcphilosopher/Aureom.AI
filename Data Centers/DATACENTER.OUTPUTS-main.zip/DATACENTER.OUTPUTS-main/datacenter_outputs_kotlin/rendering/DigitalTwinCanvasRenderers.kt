package com.datacenter.outputs.rendering

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.datacenter.outputs.animation.AnimationIntensity
import com.datacenter.outputs.core.models.*

class CampusRenderer {
    fun drawCampus(
        drawScope: DrawScope,
        state: DataCenterState,
        cameraScale: Float,
        particlePhase: Float,
        intensity: AnimationIntensity,
        isThermalMode: Boolean
    ) {
        val width = drawScope.size.width
        val height = drawScope.size.height
        
        // Dark industrial canvas background
        drawScope.drawRect(Color(0xFF0A0D14), Offset.Zero, Size(width, height))

        // Level of detail check
        val lod = when {
            cameraScale < 0.6f -> "CAMPUS"
            cameraScale < 1.5f -> "BUILDING"
            cameraScale < 3.0f -> "FLOOR_RACKS"
            else -> "SERVER_GPU"
        }

        // Draw Substation & Power Grid Lines
        val substationPos = Offset(width * 0.5f, height * 0.85f)
        val hallAPos = Offset(width * 0.35f, height * 0.45f)
        val hallBPos = Offset(width * 0.65f, height * 0.45f)

        // Cables & particles
        drawPowerLine(drawScope, substationPos, hallAPos, particlePhase * intensity.powerParticleVelocity, isThermalMode)
        drawPowerLine(drawScope, substationPos, hallBPos, particlePhase * intensity.powerParticleVelocity, isThermalMode)

        // Buildings
        drawBuilding(drawScope, hallAPos, "DATA HALL A", state.buildings.getOrNull(0), lod, isThermalMode)
        drawBuilding(drawScope, hallBPos, "DATA HALL B", state.buildings.getOrNull(1), lod, isThermalMode)
        
        // Substation block
        drawScope.drawRect(Color(0xFF1E2638), substationPos - Offset(60f, 30f), Size(120f, 60f))
        drawScope.drawRect(Color(0xFF00F0FF), substationPos - Offset(60f, 30f), Size(120f, 60f), style = Stroke(1.5f))
    }

    private fun drawPowerLine(drawScope: DrawScope, start: Offset, end: Offset, phase: Float, isThermal: Boolean) {
        val lineColor = if (isThermal) Color(0xFFFF4500) else Color(0xFF00F0FF)
        drawScope.drawLine(lineColor.copy(alpha = 0.4f), start, end, strokeWidth = 2f)
        
        // Particles along line
        val count = 6
        for (i in 0 until count) {
            val progress = (phase + i.toFloat() / count) % 1.0f
            val pos = Offset(start.x + (end.x - start.x) * progress, start.y + (end.y - start.y) * progress)
            drawScope.drawCircle(lineColor, radius = 3.5f, center = pos)
        }
    }

    private fun drawBuilding(drawScope: DrawScope, center: Offset, title: String, building: BuildingState?, lod: String, isThermal: Boolean) {
        val boxWidth = 240f
        val boxHeight = 160f
        val topLeft = center - Offset(boxWidth / 2, boxHeight / 2)
        
        val strokeColor = if (isThermal) Color(0xFFFF6B00) else Color(0xFF00F0FF)
        val fillColor = if (isThermal) Color(0xFF2A150A) else Color(0xFF111726)

        drawScope.drawRect(fillColor, topLeft, Size(boxWidth, boxHeight))
        drawScope.drawRect(strokeColor, topLeft, Size(boxWidth, boxHeight), style = Stroke(1.5f))

        // Racks grid preview
        val rows = 3
        val cols = 8
        val rackW = 18f
        val rackH = 26f
        val startX = topLeft.x + 20f
        val startY = topLeft.y + 40f

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val rx = startX + c * (rackW + 8f)
                val ry = startY + r * (rackH + 12f)
                val statusColor = when ((r + c) % 7) {
                    0 -> Color(0xFF00FF66)
                    1 -> Color(0xFF00F0FF)
                    5 -> Color(0xFFFFB000)
                    6 -> Color(0xFFFF2A55)
                    else -> Color(0xFF00E5FF)
                }
                drawScope.drawRect(if (isThermal) Color(0xFFFF4500).copy(alpha = 0.6f) else statusColor, Offset(rx, ry), Size(rackW, rackH))
            }
        }
    }
}
