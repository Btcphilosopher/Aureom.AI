package com.datacenter.outputs.ui.viewmodels

import com.datacenter.outputs.core.models.DataCenterState
import com.datacenter.outputs.data.api.PythonApiClient
import com.datacenter.outputs.data.websocket.TelemetryWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DataCenterViewModel(
    private val apiClient: PythonApiClient = PythonApiClient(),
    private val wsClient: TelemetryWebSocketClient = TelemetryWebSocketClient()
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _state = MutableStateFlow(DataCenterState())
    val state: StateFlow<DataCenterState> = _state.asStateFlow()

    private val _selectedView = MutableStateFlow("Overview")
    val selectedView: StateFlow<String> = _selectedView.asStateFlow()

    private val _isThermalMode = MutableStateFlow(false)
    val isThermalMode: StateFlow<Boolean> = _isThermalMode.asStateFlow()

    private val _reducedMotion = MutableStateFlow(false)
    val reducedMotion: StateFlow<Boolean> = _reducedMotion.asStateFlow()

    private val _selectedRackId = MutableStateFlow<String?>(null)
    val selectedRackId: StateFlow<String?> = _selectedRackId.asStateFlow()

    init {
        loadInitialState()
        observeLiveTelemetry()
    }

    private fun loadInitialState() {
        scope.launch {
            try {
                val latest = apiClient.getTelemetryLatest()
                _state.value = latest
            } catch (e: Exception) {
                // Fallback demo state is already initialized in DataCenterState default constructor
            }
        }
    }

    private fun observeLiveTelemetry() {
        scope.launch {
            wsClient.observeTelemetry().collect { point ->
                val current = _state.value
                // Update state immediately without reloading UI
                val updatedPower = if (point.metric == "power") {
                    current.power.copy(itLoadMw = point.value / 1000.0)
                } else current.power
                
                _state.value = current.copy(
                    power = updatedPower,
                    lastUpdateAgeSeconds = 0.1
                )
            }
        }
    }

    fun selectView(viewName: String) {
        _selectedView.value = viewName
    }

    fun toggleThermalMode() {
        _isThermalMode.value = !_isThermalMode.value
    }

    fun toggleReducedMotion() {
        _reducedMotion.value = !_reducedMotion.value
    }

    fun selectRack(rackId: String?) {
        _selectedRackId.value = rackId
    }
}
