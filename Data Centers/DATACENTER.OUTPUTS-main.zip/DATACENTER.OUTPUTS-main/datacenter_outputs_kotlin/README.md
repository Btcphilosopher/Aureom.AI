# DATACENTER.OUTPUTS - Kotlin Multiplatform Front-End

**LIVE AI INFRASTRUCTURE OPERATIONS**
*Real-time AI Data Center Monitoring, Telemetry & Animated Digital Twin Interface*

---

## 🏛 Architecture

```
                 PYTHON ENGINE
                       │
             ┌─────────┴─────────┐
             │                   │
         REST API            WEBSOCKET
             │                   │
             └─────────┬─────────┘
                       ↓
                    KOTLIN
                       ↓
             STATE / VIEW MODEL
                       ↓
            DIGITAL TWIN ENGINE
                       ↓
           ANIMATED VISUAL INTERFACE
```

## 🚀 Key Features

- **Jetpack Compose / Compose Multiplatform**: Native high-performance Canvas rendering targeting Desktop, Web, and Mobile.
- **Isometric / Axonometric Digital Twin**: 3D spatial visualization of Campus, Data Halls, Racks, Power Substation, and Cooling Plant.
- **Hierarchical Animated Camera System**: Seamless transitions through Campus → Building → Floor → Zone → Rack → Server → GPU.
- **Telemetry-Driven Animation Intensity**:
  - Electrical Power flows animated via particle velocity based on MW load.
  - Coolant fluid loops animated proportionally to liters/sec and delta temperature.
  - Network packets animated according to link traffic (Tbps) & congestion.
  - AI Compute GPU nodes pulsing according to % utilization.
- **Thermal Heatmap Mode**: Interpolated surface heat map with smooth color transitions (Cool → Normal → Warm → Hot → Critical).
- **14 Master Operational Views**: Overview, Digital Twin, Power, Cooling, Racks, GPU, Network, Energy, Thermal, Alerts, Capacity, Maintenance, AI Operations, and What-If Simulation.
- **Command Palette & Keyboard Shortcuts**: `/` hotkey for instant search across racks, chillers, GPUs, and operational screens.

---

## 📂 Project Structure

```
datacenter_outputs_kotlin/
│
├── core/
│   ├── models/           # TelemetryPoint, DataCenterState, RackState, GPUState...
│   ├── networking/       # Ktor HTTP & WebSocket engine
│   └── state/            # StateFlow & Reactive state management
│
├── data/
│   ├── api/              # PythonApiClient REST wrapper
│   └── websocket/        # TelemetryWebSocketClient persistent connection
│
├── domain/
│   ├── telemetry/        # Telemetry aggregation & interpolation
│   ├── digitaltwin/      # Camera system, LOD virtualizer
│   └── simulation/       # Failure simulation engine
│
├── animation/
│   ├── AnimationController.kt
│   ├── PowerFlowAnimation.kt
│   ├── CoolingFlowAnimation.kt
│   ├── NetworkFlowAnimation.kt
│   └── ThermalAnimation.kt
│
├── rendering/
│   ├── CampusRenderer.kt
│   ├── BuildingRenderer.kt
│   ├── RackRenderer.kt
│   └── PowerRenderer.kt
│
├── ui/
│   ├── viewmodels/       # DataCenterViewModel
│   └── components/       # Jetpack Compose UI screens
│
└── tests/                # Unit tests for JSON parsing & animation state
```

---

## 🛠 Building & Running

To build and run the desktop application:
```bash
./gradlew run
```

To run tests:
```bash
./gradlew test
```

To package native executable:
```bash
./gradlew packageDistributionForCurrentOS
```
