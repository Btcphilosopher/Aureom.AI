import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-audit-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (state.auditModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 select-none">
        <!-- Backdrop button -->
        <button
          type="button"
          aria-label="Close dialog backdrop"
          (click)="state.closeAuditModal()"
          class="fixed inset-0 bg-black/75 backdrop-blur-xs cursor-default w-full h-full border-none outline-none"
        ></button>

        <!-- Modal Card -->
        <div
          role="dialog"
          aria-modal="true"
          class="relative z-10 bg-[#101820] border border-[#58B7C8]/50 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-[#EAF1F4]"
        >
          <!-- Header -->
          <div class="px-6 py-4 bg-[#172735] border-b border-[#3B596D]/40 flex items-center justify-between">
            <div class="flex items-center gap-3">
              <span class="w-3 h-3 bg-[#58B7C8] rounded-sm transform rotate-45"></span>
              <div>
                <h3 class="text-base font-bold text-white font-mono tracking-wide">
                  AUREOM WIND.OS — SCIENTIFIC & ENGINEERING AUDIT
                </h3>
                <div class="text-xs text-slate-400 font-mono">
                  Asset: {{ state.selectedTurbine().serialNumber }} · Audit Dossier Reference #AUD-2026-ENG-882
                </div>
              </div>
            </div>
            <button
              (click)="state.closeAuditModal()"
              class="p-2 rounded-lg bg-[#101820] hover:bg-[#253846] text-slate-400 hover:text-white transition-colors"
            >
              <span class="font-mono text-sm">✕</span>
            </button>
          </div>

          <!-- Body -->
          <div class="p-6 overflow-y-auto space-y-5 text-xs font-mono">
            <!-- Executive Stamp & Compliance Summary -->
            <div class="bg-[#172735]/60 border border-[#5DAA88]/40 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div class="text-[#5DAA88] font-bold text-sm">CERTIFIED ENGINEERING AUDIT PASSED</div>
                <div class="text-slate-300 text-[11px] mt-0.5">
                  Full multi-physics evaluation verified under IEC 61400-1, DNV-ST-0262 & ISO 10816 standards.
                </div>
              </div>
              <div class="bg-[#101820] px-3 py-1.5 rounded-lg border border-[#3B596D]/40 text-center shrink-0">
                <div class="text-[10px] text-slate-400">DESIGN LIFE</div>
                <div class="text-base font-bold text-white">30.0 YEARS</div>
              </div>
            </div>

            <!-- Verification Pillar 1: Aerodynamics & BEM -->
            <div class="space-y-2">
              <div class="text-xs font-bold text-white border-b border-[#3B596D]/30 pb-1 flex justify-between">
                <span>01. Aerodynamic Physics Verification</span>
                <span class="text-[#58B7C8]">Blade Element Momentum</span>
              </div>
              <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20">
                  <span class="text-slate-400 block text-[10px]">PEAK POWER COEFF</span>
                  <span class="text-white font-bold text-sm tabular-nums">Cp = 0.482</span>
                  <span class="text-[#5DAA88] text-[9px] block">Betz Limit Margin: 18.7%</span>
                </div>
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20">
                  <span class="text-slate-400 block text-[10px]">RATED WIND SPEED</span>
                  <span class="text-white font-bold text-sm tabular-nums">{{ state.selectedTurbine().ratedSpeedMs }} m/s</span>
                  <span class="text-[#5DAA88] text-[9px] block">Cut-in: {{ state.selectedTurbine().cutInSpeedMs }} m/s</span>
                </div>
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20">
                  <span class="text-slate-400 block text-[10px]">MAX THRUST FORCE</span>
                  <span class="text-white font-bold text-sm tabular-nums">{{ state.currentAerodynamics().rotorThrustKN.toFixed(0) }} kN</span>
                  <span class="text-[#5DAA88] text-[9px] block">Glauert Induction OK</span>
                </div>
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20">
                  <span class="text-slate-400 block text-[10px]">SWEPT AREA</span>
                  <span class="text-white font-bold text-sm tabular-nums">{{ (state.selectedTurbine().rotorDiameterM * state.selectedTurbine().rotorDiameterM * 3.14159 / 4).toFixed(0) }} m²</span>
                  <span class="text-[#5DAA88] text-[9px] block">3x {{ state.selectedTurbine().bladeLengthM }}m Blades</span>
                </div>
              </div>
            </div>

            <!-- Verification Pillar 2: Structural & Fatigue Margin -->
            <div class="space-y-2">
              <div class="text-xs font-bold text-white border-b border-[#3B596D]/30 pb-1 flex justify-between">
                <span>02. Structural Integrity & Fatigue Life</span>
                <span class="text-[#58B7C8]">IEC 61400-1 DLC 1.2</span>
              </div>
              <div class="bg-[#172735]/40 p-3 rounded-xl border border-[#3B596D]/20 space-y-1.5 text-slate-300">
                <div class="flex justify-between">
                  <span>Carbon Fiber Spar Cap Max Tensile Strain:</span>
                  <span class="text-[#5DAA88] font-bold">0.42% (&le; 0.65% Allowable, Margin +54%)</span>
                </div>
                <div class="flex justify-between">
                  <span>Flapwise Tip Deflection at 50-yr Extreme Gust:</span>
                  <span class="text-[#5DAA88] font-bold">7.8 m (Tower Clearance: 4.2 m Safe)</span>
                </div>
                <div class="flex justify-between">
                  <span>Rainflow Miner's Fatigue Damage Sum (D):</span>
                  <span class="text-[#5DAA88] font-bold">D = 0.248 (&le; 1.000 at Year 30)</span>
                </div>
                <div class="flex justify-between">
                  <span>Tower Base Overturning Moment:</span>
                  <span class="text-white font-bold">285 MN·m (Monopile Embedment: 38m)</span>
                </div>
              </div>
            </div>

            <!-- Verification Pillar 3: Offshore Wind Farm & Wake Optimization -->
            <div class="space-y-2">
              <div class="text-xs font-bold text-white border-b border-[#3B596D]/30 pb-1 flex justify-between">
                <span>03. FLORIS Wind Farm Wake Performance</span>
                <span class="text-[#58B7C8]">Dogger Bank Outer Array</span>
              </div>
              <div class="grid grid-cols-3 gap-2">
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20 text-center">
                  <div class="text-slate-400 text-[10px]">NET FARM AEP</div>
                  <div class="text-[#5DAA88] font-bold text-sm">{{ state.windFarmState().annualEnergyProductionGWh }} GWh</div>
                </div>
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20 text-center">
                  <div class="text-slate-400 text-[10px]">WAKE DEFICIT LOSS</div>
                  <div class="text-[#E7AA49] font-bold text-sm">{{ state.windFarmState().overallWakeLossPercent }}%</div>
                </div>
                <div class="bg-[#172735]/40 p-2.5 rounded border border-[#3B596D]/20 text-center">
                  <div class="text-slate-400 text-[10px]">CAPACITY FACTOR</div>
                  <div class="text-white font-bold text-sm">{{ state.windFarmState().capacityFactorPercent }}%</div>
                </div>
              </div>
            </div>

            <!-- Verification Pillar 4: Project Economics & LCOE -->
            <div class="space-y-2">
              <div class="text-xs font-bold text-white border-b border-[#3B596D]/30 pb-1 flex justify-between">
                <span>04. Project Economics & Levelised Cost of Energy</span>
                <span class="text-[#58B7C8]">Discount Rate: 6.5%</span>
              </div>
              <div class="bg-[#172735]/40 p-3 rounded-xl border border-[#3B596D]/20 space-y-1.5 text-slate-300">
                <div class="flex justify-between">
                  <span>Levelised Cost of Energy (LCOE):</span>
                  <span class="text-[#58B7C8] font-bold text-sm">&pound;{{ state.projectEconomics().lcoeGbpPerMWh }} / MWh (&euro;{{ state.projectEconomics().lcoeEurPerMWh }})</span>
                </div>
                <div class="flex justify-between">
                  <span>Total Capital Expenditure (CAPEX):</span>
                  <span class="text-white font-bold">&pound;{{ state.projectEconomics().totalCapexMGBP }}M (50 Turbines, 750 MW)</span>
                </div>
                <div class="flex justify-between">
                  <span>Project Net Present Value (NPV):</span>
                  <span class="text-[#5DAA88] font-bold">&pound;{{ state.projectEconomics().npvMGBP }}M (11.4% IRR)</span>
                </div>
                <div class="flex justify-between">
                  <span>Embodied Carbon Payback Period:</span>
                  <span class="text-[#5DAA88] font-bold">{{ state.selectedTurbine().environmentalAccounting.carbonPaybackMonths }} Months</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Footer Actions -->
          <div class="px-6 py-4 bg-[#172735] border-t border-[#3B596D]/40 flex items-center justify-between">
            <div class="text-[11px] font-mono text-slate-400">
              @if (copied()) {
                <span class="text-[#5DAA88] font-bold">✓ Audit Dossier Copied to Clipboard</span>
              } @else {
                <span>Aureom.AI · Code at the speed of civilisation.</span>
              }
            </div>
            <div class="flex items-center gap-2">
              <button
                (click)="copyAuditSummary()"
                class="px-4 py-2 text-xs font-mono font-medium text-slate-300 hover:text-white bg-[#101820] border border-[#3B596D]/50 rounded-lg hover:bg-[#253846] transition-colors"
              >
                Copy Report Dossier
              </button>
              <button
                (click)="state.closeAuditModal()"
                class="px-4 py-2 text-xs font-mono font-bold text-[#101820] bg-[#58B7C8] hover:bg-[#68c6d7] rounded-lg transition-colors"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class AuditModalComponent {
  protected readonly state = inject(TurbineState);
  protected readonly copied = signal<boolean>(false);

  copyAuditSummary() {
    const t = this.state.selectedTurbine();
    const aero = this.state.currentAerodynamics();
    const econ = this.state.projectEconomics();
    const farm = this.state.windFarmState();

    const text = `
=== AUREOM WIND.OS SCIENTIFIC AUDIT DOSSIER ===
Turbine Serial: ${t.serialNumber} (${t.name})
Rated Power: ${t.ratedPowerMW} MW | Rotor: ${t.rotorDiameterM} m | Hub: ${t.hubHeightM} m
Class: ${t.class} | Architecture: ${t.architecture} | Gen: ${t.generatorType}

1. AERODYNAMICS (BEM Physics):
- Operating Regime: ${aero.operatingRegion}
- Wind Speed: ${aero.windSpeedMs} m/s
- Power Output: ${aero.electricalPowerMW.toFixed(2)} MW
- Power Coeff (Cp): ${aero.powerCoefficientCp.toFixed(3)} (Betz Limit: 0.593)
- Thrust Force: ${aero.rotorThrustKN.toFixed(0)} kN

2. WIND FARM WAKES (FLORIS):
- Net Farm Power: ${farm.netPowerMW} MW (Gross: ${farm.grossPowerMW} MW)
- Wake Deficit Loss: ${farm.overallWakeLossPercent}%
- Capacity Factor: ${farm.capacityFactorPercent}%
- Annual Energy (AEP): ${farm.annualEnergyProductionGWh} GWh

3. PROJECT ECONOMICS:
- LCOE: £${econ.lcoeGbpPerMWh}/MWh (€${econ.lcoeEurPerMWh}/MWh)
- Total CAPEX: £${econ.totalCapexMGBP}M (50 Turbines, 750 MW)
- NPV: £${econ.npvMGBP}M | IRR: ${econ.irrPercent}%
- Carbon Payback: ${t.environmentalAccounting.carbonPaybackMonths} Months
- Recyclability: ${t.environmentalAccounting.recyclabilityPercent}%

Company: Aureom.AI | Motto: Code at the speed of civilisation.
================================================
    `.trim();

    navigator.clipboard?.writeText(text);
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 3000);
  }
}
