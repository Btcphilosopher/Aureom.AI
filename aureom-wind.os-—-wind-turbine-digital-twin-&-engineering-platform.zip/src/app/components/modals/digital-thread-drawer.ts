import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-digital-thread-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (state.digitalThreadDrawerOpen()) {
      <!-- Backdrop Button -->
      <button
        type="button"
        aria-label="Close drawer backdrop"
        (click)="state.toggleDigitalThreadDrawer()"
        class="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 transition-opacity w-full h-full border-none outline-none cursor-default"
      ></button>

      <!-- Slide-over Drawer Panel -->
      <div class="fixed top-0 right-0 bottom-0 w-full max-w-lg bg-[#101820] border-l border-[#3B596D]/50 z-50 shadow-2xl flex flex-col text-[#EAF1F4]">
        <!-- Drawer Header -->
        <div class="p-5 border-b border-[#3B596D]/30 flex items-center justify-between">
          <div>
            <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Enterprise Digital Thread</div>
            <h3 class="text-lg font-bold text-white">{{ state.selectedTurbine().serialNumber }}</h3>
          </div>
          <button
            (click)="state.toggleDigitalThreadDrawer()"
            class="p-2 rounded-lg bg-[#172735] hover:bg-[#253846] text-slate-400 hover:text-white transition-colors"
          >
            <span class="font-mono text-sm">✕</span>
          </button>
        </div>

        <!-- Drawer Content -->
        <div class="flex-1 overflow-y-auto p-5 space-y-5 text-xs font-mono">
          <!-- Turbine Identification Badge -->
          <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-4 rounded-xl space-y-2">
            <div class="text-xs font-semibold text-white">{{ state.selectedTurbine().name }}</div>
            <div class="grid grid-cols-2 gap-2 text-slate-300">
              <div>UUID: <span class="text-[#58B7C8]">e8b419-aureom-{{ state.selectedTurbine().id }}</span></div>
              <div>Class: <span class="text-white">{{ state.selectedTurbine().class }}</span></div>
              <div>Rated: <span class="text-[#5DAA88] font-bold">{{ state.selectedTurbine().ratedPowerMW }} MW</span></div>
              <div>Rotor: <span class="text-white">{{ state.selectedTurbine().rotorDiameterM }} m</span></div>
              <div>Commissioned: <span class="text-white">2026-08-14</span></div>
              <div>Location: <span class="text-[#E7AA49]">Dogger Bank B (54°58'N, 1°52'E)</span></div>
            </div>
          </div>

          <!-- Section 1: Raw Material Certificates -->
          <div class="space-y-2">
            <div class="text-xs font-semibold text-white flex items-center justify-between">
              <span>01. Certified Raw Material Batches</span>
              <span class="text-[10px] text-[#58B7C8]">EN 10204 3.1 & 3.2</span>
            </div>
            <div class="space-y-2">
              @for (batch of state.materialBatches(); track batch.id) {
                <div class="bg-[#172735]/60 border border-[#3B596D]/30 p-2.5 rounded-lg space-y-1">
                  <div class="flex justify-between text-white font-bold">
                    <span>{{ batch.materialName }}</span>
                    <span class="text-[#5DAA88]">{{ batch.status }}</span>
                  </div>
                  <div class="text-slate-400 text-[11px]">{{ batch.batchCode }} · {{ batch.grade }}</div>
                  <div class="flex justify-between text-slate-400 text-[10px]">
                    <span>Supplier: {{ batch.supplier }}</span>
                    <span>Delivered: {{ batch.deliveryDate }}</span>
                  </div>
                  <div class="text-[10px] text-[#58B7C8] border-t border-[#3B596D]/20 pt-1">
                    Cert: {{ batch.certificateRef }}
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Section 2: Component Traceability Serial Numbers -->
          <div class="space-y-2">
            <div class="text-xs font-semibold text-white">02. Component Serial Number Registry</div>
            <div class="bg-[#172735]/60 border border-[#3B596D]/30 p-3 rounded-lg space-y-1.5 text-slate-300">
              <div class="flex justify-between border-b border-[#3B596D]/20 pb-1">
                <span class="text-slate-400">Blade Set (A, B, C):</span>
                <span class="text-white">AUR-BLD-115-001A / 001B / 001C</span>
              </div>
              <div class="flex justify-between border-b border-[#3B596D]/20 pb-1">
                <span class="text-slate-400">PMSG Generator Stator:</span>
                <span class="text-white">AUR-PMSG-15M-ST-9942</span>
              </div>
              <div class="flex justify-between border-b border-[#3B596D]/20 pb-1">
                <span class="text-slate-400">Main Bearings (CARB):</span>
                <span class="text-white">SKF-CARB-C3192-GB01</span>
              </div>
              <div class="flex justify-between border-b border-[#3B596D]/20 pb-1">
                <span class="text-slate-400">66kV Converter Skid:</span>
                <span class="text-white">ABB-CONV-PCS6000-881</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Tower Sections 1-5:</span>
                <span class="text-white">TOW-S355-SEC1-THROUGH-SEC5</span>
              </div>
            </div>
          </div>

          <!-- Section 3: Decommissioning & Material Circularity -->
          <div class="space-y-2">
            <div class="text-xs font-semibold text-white">03. End-of-Life Circularity & Recycling</div>
            <div class="bg-[#172735]/60 border border-[#3B596D]/30 p-3 rounded-lg space-y-1.5 text-slate-300">
              <div class="flex justify-between">
                <span>Structural Steel (Tower & Bedplate):</span>
                <span class="text-[#5DAA88] font-bold">98.5% Recycled (EAF Route)</span>
              </div>
              <div class="flex justify-between">
                <span>Copper (Generator Windings & Cables):</span>
                <span class="text-[#5DAA88] font-bold">99.2% Smelter Reclamation</span>
              </div>
              <div class="flex justify-between">
                <span>Composite Blades (Resin & Fiber):</span>
                <span class="text-[#58B7C8] font-bold">85.0% Pyrolysis / Cement Co-proc</span>
              </div>
              <div class="flex justify-between">
                <span>Permanent Magnets (NdFeB):</span>
                <span class="text-[#E7AA49] font-bold">94.0% Chemical Hydrometallurgy</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Drawer Footer -->
        <div class="p-4 border-t border-[#3B596D]/30 flex justify-end">
          <button
            (click)="state.toggleDigitalThreadDrawer()"
            class="px-4 py-2 text-xs font-mono bg-[#172735] hover:bg-[#253846] text-white rounded-lg border border-[#3B596D]/50 transition-colors"
          >
            Close Dossier
          </button>
        </div>
      </div>
    }
  `,
})
export class DigitalThreadDrawerComponent {
  protected readonly state = inject(TurbineState);
}
