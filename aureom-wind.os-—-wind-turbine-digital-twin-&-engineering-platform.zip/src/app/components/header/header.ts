import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#101820] border-b border-[#3B596D]/30 z-30 select-none">
      <!-- Zone 1: Brand Title (Single line wordmark) -->
      <div class="flex items-center gap-3 shrink-0">
        <a href="/" class="text-lg font-bold tracking-tight text-white whitespace-nowrap hover:text-[#58B7C8] transition-colors flex items-center gap-2">
          <span class="w-2.5 h-2.5 bg-[#58B7C8] rounded-sm transform rotate-45"></span>
          <span class="font-mono tracking-widest text-[#EAF1F4]">AUREOM</span>
          <span class="text-[#58B7C8] font-mono">WIND.OS</span>
        </a>
      </div>

      <!-- Zone 2: 5 Concise Single-Line Navigation Links -->
      <nav class="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
        <button
          (click)="state.setWorkspace('ENGINEERING')"
          [class.text-[#58B7C8]]="state.activeWorkspace() === 'ENGINEERING'"
          [class.border-b-2]="state.activeWorkspace() === 'ENGINEERING'"
          [class.border-[#58B7C8]]="state.activeWorkspace() === 'ENGINEERING'"
          class="pb-1 hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          Engineering
        </button>

        <button
          (click)="state.setWorkspace('FACTORY')"
          [class.text-[#58B7C8]]="state.activeWorkspace() === 'FACTORY'"
          [class.border-b-2]="state.activeWorkspace() === 'FACTORY'"
          [class.border-[#58B7C8]]="state.activeWorkspace() === 'FACTORY'"
          class="pb-1 hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          Factory
        </button>

        <button
          (click)="state.setWorkspace('LOGISTICS')"
          [class.text-[#58B7C8]]="state.activeWorkspace() === 'LOGISTICS'"
          [class.border-b-2]="state.activeWorkspace() === 'LOGISTICS'"
          [class.border-[#58B7C8]]="state.activeWorkspace() === 'LOGISTICS'"
          class="pb-1 hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          Logistics
        </button>

        <button
          (click)="state.setWorkspace('FIELD')"
          [class.text-[#58B7C8]]="state.activeWorkspace() === 'FIELD'"
          [class.border-b-2]="state.activeWorkspace() === 'FIELD'"
          [class.border-[#58B7C8]]="state.activeWorkspace() === 'FIELD'"
          class="pb-1 hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          Field Ops
        </button>

        <button
          (click)="state.setWorkspace('LIFECYCLE')"
          [class.text-[#58B7C8]]="state.activeWorkspace() === 'LIFECYCLE'"
          [class.border-b-2]="state.activeWorkspace() === 'LIFECYCLE'"
          [class.border-[#58B7C8]]="state.activeWorkspace() === 'LIFECYCLE'"
          class="pb-1 hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          Lifecycle
        </button>
      </nav>

      <!-- Zone 3: 1 Primary Action -->
      <div class="flex items-center gap-3 shrink-0">
        <button
          (click)="state.toggleDigitalThreadDrawer()"
          class="px-3 py-1.5 text-xs font-mono font-medium text-slate-300 hover:text-white bg-[#172735] hover:bg-[#253846] border border-[#3B596D]/40 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          Asset Thread ({{ state.selectedTurbine().serialNumber }})
        </button>
        <button
          (click)="state.openAuditModal()"
          class="px-4 py-2 text-xs font-mono font-semibold text-[#101820] bg-[#58B7C8] hover:bg-[#68c6d7] rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0 active:scale-95"
        >
          Run Full Audit
        </button>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  protected readonly state = inject(TurbineState);
}
