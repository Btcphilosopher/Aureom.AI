import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  effect,
  inject,
  viewChild,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import * as THREE from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {TurbineState} from '../../services/turbine-state';
import {SceneMode} from '../../models/turbine.models';

@Component({
  selector: 'app-viewport3d',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[500px] select-none overflow-hidden bg-[#101820]">
      <!-- WebGL Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Scene Quick Badges / Telemetry Top Overlay -->
      <div class="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-auto">
        <div class="bg-[#172735]/85 border border-[#3B596D]/40 px-3 py-1.5 rounded-lg text-xs font-mono flex items-center gap-2 shadow-lg">
          <span class="text-[#58B7C8] font-bold">SCENE:</span>
          <span class="text-white uppercase tracking-wider">{{ activeSceneName() }}</span>
        </div>

        <div class="bg-[#172735]/85 border border-[#3B596D]/40 px-3 py-1.5 rounded-lg text-xs font-mono flex items-center gap-2 shadow-lg">
          <span class="text-[#E7AA49] font-bold">ROTOR:</span>
          <span class="text-white tabular-nums">{{ state.currentAerodynamics().rotorRpm.toFixed(1) }} RPM</span>
          <span class="text-slate-400">·</span>
          <span class="text-slate-300 tabular-nums">PITCH {{ state.currentAerodynamics().bladePitchDeg.toFixed(1) }}°</span>
        </div>

        <div class="bg-[#172735]/85 border border-[#3B596D]/40 px-3 py-1.5 rounded-lg text-xs font-mono flex items-center gap-2 shadow-lg">
          <span class="text-[#5DAA88] font-bold">PWR:</span>
          <span class="text-white tabular-nums font-semibold">{{ state.currentAerodynamics().electricalPowerMW.toFixed(2) }} MW</span>
          <span class="text-slate-400">·</span>
          <span class="text-[#58B7C8] tabular-nums">Cp {{ state.currentAerodynamics().powerCoefficientCp.toFixed(3) }}</span>
        </div>
      </div>

      <!-- Camera Presets Floating Pill Bar (Top Right) -->
      <div class="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-[#172735]/80 border border-[#3B596D]/40 p-1 rounded-xl shadow-lg pointer-events-auto">
        <button
          (click)="setCameraPreset('iso')"
          title="Isometric View"
          class="px-2.5 py-1 text-xs font-medium rounded-lg text-slate-300 hover:text-white hover:bg-[#3B596D]/50 transition-colors"
        >
          ISO
        </button>
        <button
          (click)="setCameraPreset('front')"
          title="Front Rotor View"
          class="px-2.5 py-1 text-xs font-medium rounded-lg text-slate-300 hover:text-white hover:bg-[#3B596D]/50 transition-colors"
        >
          FRONT
        </button>
        <button
          (click)="setCameraPreset('drivetrain')"
          title="Nacelle / Drivetrain View"
          class="px-2.5 py-1 text-xs font-medium rounded-lg text-slate-300 hover:text-white hover:bg-[#3B596D]/50 transition-colors"
        >
          NACELLE
        </button>
        <button
          (click)="setCameraPreset('top')"
          title="Top Down Plan"
          class="px-2.5 py-1 text-xs font-medium rounded-lg text-slate-300 hover:text-white hover:bg-[#3B596D]/50 transition-colors"
        >
          TOP
        </button>
        <div class="h-3 w-px bg-[#3B596D]/50 mx-0.5"></div>
        <button
          (click)="resetCamera()"
          title="Reset Camera"
          class="px-2 py-1 text-xs font-medium rounded-lg text-[#58B7C8] hover:bg-[#3B596D]/50 transition-colors flex items-center"
        >
          <span class="text-xs">RESET</span>
        </button>
      </div>

      <!-- Hover / Selected Defect or Component Overlay Tooltip -->
      @if (hoveredInfo) {
        <div class="absolute bottom-28 left-6 z-20 max-w-sm bg-[#172735]/95 border border-[#58B7C8]/60 p-3.5 rounded-xl shadow-2xl backdrop-blur-md pointer-events-none transition-all">
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider mb-1 font-semibold">
            {{ hoveredInfo.category }}
          </div>
          <div class="text-sm font-bold text-white mb-1">{{ hoveredInfo.title }}</div>
          <div class="text-xs text-slate-300 leading-relaxed">{{ hoveredInfo.details }}</div>
          @if (hoveredInfo.metric) {
            <div class="mt-2 pt-2 border-t border-[#3B596D]/40 text-xs font-mono text-[#E7AA49]">
              {{ hoveredInfo.metric }}
            </div>
          }
        </div>
      }

      <!-- Collapsible Bottom Dock (Unobstructed Viewport Standard) -->
      <div
        class="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-4xl transition-all duration-300 pointer-events-auto"
        [class.translate-y-[calc(100%+1rem)]]="state.bottomDockCollapsed()"
      >
        <!-- Collapse / Expand Toggle Button -->
        <div class="flex justify-center -mb-px">
          <button
            (click)="state.toggleBottomDock()"
            class="px-4 py-1 text-[11px] font-mono tracking-wider font-semibold bg-[#172735] border-t border-x border-[#3B596D]/60 rounded-t-lg text-slate-300 hover:text-white hover:bg-[#253846] transition-colors flex items-center gap-1.5 shadow-md"
          >
            <span>{{ state.bottomDockCollapsed() ? '▲ SHOW 3D DOCK' : '▼ HIDE CONTROLS' }}</span>
          </button>
        </div>

        <!-- Main Dock Container -->
        <div class="bg-[#172735]/95 border border-[#3B596D]/60 rounded-2xl p-3.5 shadow-2xl backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-4">
          <!-- Left: Scene Switcher Tabs -->
          <div class="flex items-center gap-1 bg-[#101820]/90 p-1 rounded-xl border border-[#3B596D]/30 shrink-0">
            <button
              (click)="changeScene('engineering')"
              [class.bg-[#3B596D]]="state.activeScene() === 'engineering'"
              [class.text-white]="state.activeScene() === 'engineering'"
              [class.text-slate-400]="state.activeScene() !== 'engineering'"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-colors hover:text-white whitespace-nowrap"
            >
              Engineering Lab
            </button>
            <button
              (click)="changeScene('factory')"
              [class.bg-[#3B596D]]="state.activeScene() === 'factory'"
              [class.text-white]="state.activeScene() === 'factory'"
              [class.text-slate-400]="state.activeScene() !== 'factory'"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-colors hover:text-white whitespace-nowrap"
            >
              Blade Factory
            </button>
            <button
              (click)="changeScene('offshore')"
              [class.bg-[#3B596D]]="state.activeScene() === 'offshore'"
              [class.text-white]="state.activeScene() === 'offshore'"
              [class.text-slate-400]="state.activeScene() !== 'offshore'"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-colors hover:text-white whitespace-nowrap"
            >
              Offshore Lift
            </button>
            <button
              (click)="changeScene('windfarm')"
              [class.bg-[#3B596D]]="state.activeScene() === 'windfarm'"
              [class.text-white]="state.activeScene() === 'windfarm'"
              [class.text-slate-400]="state.activeScene() !== 'windfarm'"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-colors hover:text-white whitespace-nowrap"
            >
              Wind Farm
            </button>
            <button
              (click)="changeScene('inspection')"
              [class.bg-[#3B596D]]="state.activeScene() === 'inspection'"
              [class.text-white]="state.activeScene() === 'inspection'"
              [class.text-slate-400]="state.activeScene() !== 'inspection'"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-colors hover:text-white whitespace-nowrap"
            >
              Drone NDT
            </button>
          </div>

          <!-- Center: Dynamic Scene Specific Controls -->
          <div class="flex-1 w-full flex items-center justify-center gap-4">
            @if (state.activeScene() === 'engineering') {
              <div class="flex items-center gap-3 w-full max-w-sm">
                <span class="text-xs font-mono text-slate-300 whitespace-nowrap shrink-0">EXPLODED VIEW:</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  [value]="state.explodedProgress()"
                  (input)="onExplodedSlider($event)"
                  class="w-full accent-[#58B7C8] cursor-pointer h-1.5 bg-[#101820] rounded-lg"
                />
                <span class="text-xs font-mono text-[#58B7C8] tabular-nums shrink-0 w-8">{{ state.explodedProgress() }}%</span>
              </div>
            } @else if (state.activeScene() === 'windfarm') {
              <div class="flex items-center gap-3 w-full max-w-sm">
                <span class="text-xs font-mono text-slate-300 whitespace-nowrap shrink-0">WIND:</span>
                <input
                  type="range"
                  min="0"
                  max="28"
                  step="0.5"
                  [value]="state.simulatedWindSpeed()"
                  (input)="onWindSpeedSlider($event)"
                  class="w-full accent-[#58B7C8] cursor-pointer h-1.5 bg-[#101820] rounded-lg"
                />
                <span class="text-xs font-mono text-[#58B7C8] tabular-nums shrink-0 w-16">{{ state.simulatedWindSpeed().toFixed(1) }} m/s</span>
              </div>
            } @else if (state.activeScene() === 'factory') {
              <div class="flex items-center gap-3 w-full max-w-sm">
                <span class="text-xs font-mono text-slate-300 whitespace-nowrap shrink-0">INFUSION TIME:</span>
                <input
                  type="range"
                  min="0"
                  max="240"
                  step="5"
                  [value]="state.cureElapsedMinutes()"
                  (input)="onCureSlider($event)"
                  class="w-full accent-[#E7AA49] cursor-pointer h-1.5 bg-[#101820] rounded-lg"
                />
                <span class="text-xs font-mono text-[#E7AA49] tabular-nums shrink-0 w-14">{{ state.cureElapsedMinutes() }} min</span>
              </div>
            } @else if (state.activeScene() === 'inspection') {
              <div class="flex items-center gap-2 overflow-x-auto py-1">
                <span class="text-xs font-mono text-slate-300 whitespace-nowrap">DEFECTS:</span>
                @for (def of state.bladeDefects; track def.id) {
                  <button
                    (click)="state.selectDefect(def)"
                    [class.border-[#58B7C8]]="state.selectedDefect()?.id === def.id"
                    [class.bg-[#58B7C8]/20]="state.selectedDefect()?.id === def.id"
                    class="px-2 py-1 text-[11px] font-mono border border-[#3B596D]/40 rounded-lg text-slate-300 hover:text-white transition-colors whitespace-nowrap"
                  >
                    B{{ def.bladeIndex }} {{ def.locationMetersFromRoot }}m ({{ def.severityScore }})
                  </button>
                }
              </div>
            } @else if (state.activeScene() === 'offshore') {
              <div class="flex items-center gap-3 text-xs font-mono text-slate-300">
                <span class="text-[#58B7C8]">DP2 JACK-UP:</span>
                <span>CRANE LOAD: 620t</span>
                <span class="text-slate-400">·</span>
                <span class="text-[#5DAA88]">SWELL: 1.3m (Hs &le; 1.8m SAFE)</span>
              </div>
            }
          </div>

          <!-- Right: Visual Layer Toggles -->
          <div class="flex items-center gap-2 shrink-0">
            @if (state.activeScene() === 'engineering') {
              <button
                (click)="state.toggleStressOverlay()"
                [class.bg-[#58B7C8]]="state.showStressOverlay()"
                [class.text-[#101820]]="state.showStressOverlay()"
                [class.bg-[#101820]]="!state.showStressOverlay()"
                [class.text-slate-300]="!state.showStressOverlay()"
                class="px-3 py-1.5 text-xs font-mono font-medium rounded-lg border border-[#3B596D]/40 transition-colors whitespace-nowrap"
              >
                STRESS MAP
              </button>
              <button
                (click)="state.toggleStreamlines()"
                [class.bg-[#58B7C8]]="state.showStreamlines()"
                [class.text-[#101820]]="state.showStreamlines()"
                [class.bg-[#101820]]="!state.showStreamlines()"
                [class.text-slate-300]="!state.showStreamlines()"
                class="px-3 py-1.5 text-xs font-mono font-medium rounded-lg border border-[#3B596D]/40 transition-colors whitespace-nowrap"
              >
                FLOW VECTORS
              </button>
            } @else if (state.activeScene() === 'windfarm') {
              <button
                (click)="state.toggleWakeCones()"
                [class.bg-[#58B7C8]]="state.showWakeCones()"
                [class.text-[#101820]]="state.showWakeCones()"
                [class.bg-[#101820]]="!state.showWakeCones()"
                [class.text-slate-300]="!state.showWakeCones()"
                class="px-3 py-1.5 text-xs font-mono font-medium rounded-lg border border-[#3B596D]/40 transition-colors whitespace-nowrap"
              >
                FLORIS WAKES
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class Viewport3d implements OnInit, OnDestroy {
  protected readonly state = inject(TurbineState);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly containerRef = viewChild<ElementRef<HTMLDivElement>>('canvasContainer');

  // Three.js Core Objects
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private controls: OrbitControls | null = null;
  private pmremGenerator: THREE.PMREMGenerator | null = null;
  private clock = new THREE.Clock();
  private animFrameId: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  // Scene Group Holders
  private sceneGroups = new Map<SceneMode, THREE.Group>();
  private rotorGroup: THREE.Group | null = null;
  private explodedParts: {mesh: THREE.Object3D; basePos: THREE.Vector3; explodeDir: THREE.Vector3}[] = [];
  private windStreamlines: THREE.LineSegments | null = null;
  private wakeConesGroup: THREE.Group | null = null;
  private defectMarkersGroup: THREE.Group | null = null;
  private oceanMesh: THREE.Mesh | null = null;
  private gantryCrane: THREE.Group | null = null;
  private inspectionDrone: THREE.Group | null = null;
  private farmRotors: THREE.Group[] = [];

  // Interaction & Raycasting
  public hoveredInfo: {
    category: string;
    title: string;
    details: string;
    metric?: string;
  } | null = null;

  private isSoftwareGl = false;

  constructor() {
    // Reactive sync between state and 3D scenes
    effect(() => {
      const activeScene = this.state.activeScene();
      this.switchActiveSceneGroup(activeScene);
    });

    effect(() => {
      const exploded = this.state.explodedProgress();
      this.updateExplodedTransforms(exploded);
    });

    effect(() => {
      const showStress = this.state.showStressOverlay();
      this.toggleBladeStressMaterials(showStress);
    });

    effect(() => {
      const showStream = this.state.showStreamlines();
      if (this.windStreamlines) {
        this.windStreamlines.visible = showStream;
      }
    });

    effect(() => {
      const showWake = this.state.showWakeCones();
      if (this.wakeConesGroup) {
        this.wakeConesGroup.visible = showWake;
      }
    });
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => {
        this.initThree();
      }, 50);
    }
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  activeSceneName(): string {
    switch (this.state.activeScene()) {
      case 'factory':
        return 'Blade & Tower Factory Twin';
      case 'engineering':
        return 'Turbine Lab & Drivetrain Physics';
      case 'offshore':
        return 'Offshore DP2 Installation';
      case 'windfarm':
        return 'FLORIS Wind Farm Operations';
      case 'inspection':
        return 'Aardvark Autonomous Drone NDT';
    }
  }

  changeScene(scene: SceneMode) {
    this.state.setScene(scene);
  }

  onExplodedSlider(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setExplodedProgress(val);
  }

  onWindSpeedSlider(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setWindSpeed(val);
  }

  onCureSlider(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setCureElapsed(val);
  }

  setCameraPreset(preset: 'iso' | 'front' | 'drivetrain' | 'top') {
    if (!this.camera || !this.controls) return;
    switch (preset) {
      case 'iso':
        this.camera.position.set(70, 50, 90);
        this.controls.target.set(0, 30, 0);
        break;
      case 'front':
        this.camera.position.set(0, 40, 110);
        this.controls.target.set(0, 40, 0);
        break;
      case 'drivetrain':
        this.camera.position.set(18, 48, 25);
        this.controls.target.set(0, 45, 0);
        break;
      case 'top':
        this.camera.position.set(0, 140, 0);
        this.controls.target.set(0, 0, 0);
        break;
    }
    this.controls.update();
  }

  resetCamera() {
    this.setCameraPreset('iso');
  }

  // -------------------------------------------------------------
  // THREE.JS INITIALIZATION
  // -------------------------------------------------------------
  private initThree() {
    const container = this.containerRef()?.nativeElement;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Detect software WebGL
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x101820); // Graphite
    this.scene.fog = new THREE.FogExp2(0x101820, 0.0035);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.5, 1200);
    this.camera.position.set(65, 45, 80);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 + 0.05; // Don't flip below ground
    this.controls.minDistance = 5;
    this.controls.maxDistance = 500;
    this.controls.target.set(0, 30, 0);

    // 5. Environment Map (PMREMGenerator with RoomEnvironment)
    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = this.pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    // 6. Balanced Lighting Rig
    this.setupLighting();

    // 7. Build All 5 Modular Procedural Scenes
    this.buildAllScenes();

    // 8. Event Listeners & Resize Observer
    this.resizeObserver = new ResizeObserver(() => {
      this.onWindowResize();
    });
    this.resizeObserver.observe(container);

    // 9. Start Animation Loop
    this.animate();
  }

  private setupLighting() {
    if (!this.scene) return;

    // Key Light (Warm directional)
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 2.2);
    keyLight.position.set(60, 90, 50);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.shadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 10;
      keyLight.shadow.camera.far = 300;
      keyLight.shadow.camera.left = -80;
      keyLight.shadow.camera.right = 80;
      keyLight.shadow.camera.top = 80;
      keyLight.shadow.camera.bottom = -80;
      keyLight.shadow.bias = -0.0005;
    }
    this.scene.add(keyLight);

    // Fill Light (Cool sky tint)
    const fillLight = new THREE.DirectionalLight(0x7fb6d6, 0.85);
    fillLight.position.set(-50, 40, -40);
    this.scene.add(fillLight);

    // Hemisphere Light (Ground graphite & sky cyan)
    const hemiLight = new THREE.HemisphereLight(0x3B596D, 0x101820, 0.9);
    hemiLight.position.set(0, 100, 0);
    this.scene.add(hemiLight);
  }

  // -------------------------------------------------------------
  // PROCEDURAL SCENE BUILDERS
  // -------------------------------------------------------------
  private buildAllScenes() {
    if (!this.scene) return;

    // Create groups for each scene mode
    const modes: SceneMode[] = ['engineering', 'factory', 'offshore', 'windfarm', 'inspection'];
    modes.forEach((mode) => {
      const group = new THREE.Group();
      group.name = `scene_${mode}`;
      group.visible = mode === this.state.activeScene();
      this.scene?.add(group);
      this.sceneGroups.set(mode, group);
    });

    this.buildEngineeringScene(this.sceneGroups.get('engineering')!);
    this.buildFactoryScene(this.sceneGroups.get('factory')!);
    this.buildOffshoreScene(this.sceneGroups.get('offshore')!);
    this.buildWindFarmScene(this.sceneGroups.get('windfarm')!);
    this.buildInspectionScene(this.sceneGroups.get('inspection')!);
  }

  private switchActiveSceneGroup(mode: SceneMode) {
    this.sceneGroups.forEach((group, sceneKey) => {
      group.visible = sceneKey === mode;
    });

    // Adjust camera target nicely when switching
    if (this.controls) {
      if (mode === 'inspection') {
        this.controls.target.set(30, 2, 0);
        this.camera?.position.set(45, 12, 35);
      } else if (mode === 'factory') {
        this.controls.target.set(0, 8, 0);
        this.camera?.position.set(40, 25, 45);
      } else if (mode === 'offshore') {
        this.controls.target.set(0, 25, 0);
        this.camera?.position.set(50, 35, 60);
      } else if (mode === 'windfarm') {
        this.controls.target.set(40, 10, 40);
        this.camera?.position.set(120, 60, 140);
      } else {
        this.controls.target.set(0, 30, 0);
        this.camera?.position.set(50, 40, 60);
      }
      this.controls.update();
    }
  }

  // -------------------------------------------------------------
  // SCENE 1: ENGINEERING LAB & DETAILED DRIVETRAIN
  // -------------------------------------------------------------
  private buildEngineeringScene(group: THREE.Group) {
    this.explodedParts = [];

    // Floor Grid with subtle blue-gray lines
    const gridHelper = new THREE.GridHelper(160, 40, 0x58B7C8, 0x1e303d);
    gridHelper.position.y = 0;
    group.add(gridHelper);

    // Materials
    const steelMat = new THREE.MeshStandardMaterial({color: 0x8ea2b0, roughness: 0.28, metalness: 0.85});
    const castIronMat = new THREE.MeshStandardMaterial({color: 0x2e3d48, roughness: 0.65, metalness: 0.6});
    const copperMat = new THREE.MeshStandardMaterial({color: 0xd97c45, roughness: 0.35, metalness: 0.9});
    const compositeMat = new THREE.MeshStandardMaterial({color: 0xe6edf0, roughness: 0.25, metalness: 0.15});
    const yellowMat = new THREE.MeshStandardMaterial({color: 0xe7aa49, roughness: 0.4, metalness: 0.5});

    // 1. Tower Base & Yaw Ring (Ground to 38m)
    const towerGeo = new THREE.CylinderGeometry(2.8, 4.5, 40, 32);
    const towerMesh = new THREE.Mesh(towerGeo, steelMat);
    towerMesh.position.y = 20;
    towerMesh.castShadow = true;
    towerMesh.receiveShadow = true;
    group.add(towerMesh);

    // Yaw Deck & Gear Ring
    const yawGeo = new THREE.CylinderGeometry(3.6, 3.6, 1.2, 32);
    const yawMesh = new THREE.Mesh(yawGeo, castIronMat);
    yawMesh.position.set(0, 40.6, 0);
    group.add(yawMesh);

    // 2. Nacelle Bedplate / Mainframe (Explodes downwards slightly or stays fixed)
    const bedplateGeo = new THREE.BoxGeometry(6.2, 1.4, 16);
    const bedplateMesh = new THREE.Mesh(bedplateGeo, castIronMat);
    bedplateMesh.position.set(0, 42.0, -2);
    group.add(bedplateMesh);

    // 3. Main Shaft Bearings (Pillow Block)
    const brgGeo = new THREE.CylinderGeometry(1.6, 1.8, 2.2, 24);
    const brgMesh = new THREE.Mesh(brgGeo, castIronMat);
    brgMesh.rotation.x = Math.PI / 2;
    brgMesh.position.set(0, 43.6, 2.5);
    group.add(brgMesh);
    this.explodedParts.push({mesh: brgMesh, basePos: brgMesh.position.clone(), explodeDir: new THREE.Vector3(0, 4, 0)});

    // 4. Low-Speed Main Shaft (Explodes forward along +Z)
    const shaftGeo = new THREE.CylinderGeometry(1.0, 1.1, 10, 32);
    const shaftMesh = new THREE.Mesh(shaftGeo, steelMat);
    shaftMesh.rotation.x = Math.PI / 2;
    shaftMesh.position.set(0, 43.6, 4.0);
    group.add(shaftMesh);
    this.explodedParts.push({mesh: shaftMesh, basePos: shaftMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0, 8)});

    // 5. Planetary Gearbox Casing (Explodes left/up)
    const gboxGeo = new THREE.CylinderGeometry(2.4, 2.4, 4.0, 24);
    const gboxMesh = new THREE.Mesh(gboxGeo, yellowMat);
    gboxMesh.rotation.x = Math.PI / 2;
    gboxMesh.position.set(0, 43.6, -1.5);
    group.add(gboxMesh);
    this.explodedParts.push({mesh: gboxMesh, basePos: gboxMesh.position.clone(), explodeDir: new THREE.Vector3(-6, 3, 0)});

    // 6. High-Speed Coupling & Brake Disc
    const brakeGeo = new THREE.CylinderGeometry(1.5, 1.5, 0.4, 32);
    const brakeMesh = new THREE.Mesh(brakeGeo, steelMat);
    brakeMesh.rotation.x = Math.PI / 2;
    brakeMesh.position.set(0, 43.6, -4.2);
    group.add(brakeMesh);
    this.explodedParts.push({mesh: brakeMesh, basePos: brakeMesh.position.clone(), explodeDir: new THREE.Vector3(0, 3, -4)});

    // 7. Permanent Magnet Synchronous Generator (PMSG)
    // Stator
    const statorGeo = new THREE.CylinderGeometry(3.0, 3.0, 4.8, 32);
    const statorMesh = new THREE.Mesh(statorGeo, castIronMat);
    statorMesh.rotation.x = Math.PI / 2;
    statorMesh.position.set(0, 43.6, -7.5);
    group.add(statorMesh);
    this.explodedParts.push({mesh: statorMesh, basePos: statorMesh.position.clone(), explodeDir: new THREE.Vector3(0, 0, -10)});

    // Rotor inside generator (copper coils ring)
    const rotorGenGeo = new THREE.CylinderGeometry(2.4, 2.4, 4.2, 32);
    const rotorGenMesh = new THREE.Mesh(rotorGenGeo, copperMat);
    rotorGenMesh.rotation.x = Math.PI / 2;
    rotorGenMesh.position.set(0, 43.6, -7.5);
    group.add(rotorGenMesh);
    this.explodedParts.push({mesh: rotorGenMesh, basePos: rotorGenMesh.position.clone(), explodeDir: new THREE.Vector3(6, 0, -10)});

    // 8. Hub and Blades Group (Rotates dynamically with wind speed!)
    this.rotorGroup = new THREE.Group();
    this.rotorGroup.position.set(0, 43.6, 9.5); // Hub center position

    // Hub Nose Cone
    const hubConeGeo = new THREE.ConeGeometry(2.4, 4.2, 32);
    hubConeGeo.rotateX(Math.PI / 2);
    const hubMesh = new THREE.Mesh(hubConeGeo, castIronMat);
    this.rotorGroup.add(hubMesh);

    // 3 Aerodynamic Blades
    const bladeLength = 36; // Scaled visual length
    for (let i = 0; i < 3; i++) {
      const bladeHolder = new THREE.Group();
      bladeHolder.rotation.z = (i * 2 * Math.PI) / 3;

      // Blade root cylinder
      const rootGeo = new THREE.CylinderGeometry(0.8, 0.9, 3.5, 16);
      rootGeo.translate(0, 2.5, 0);
      const rootMesh = new THREE.Mesh(rootGeo, steelMat);
      bladeHolder.add(rootMesh);

      // Aerodynamic tapered twisted blade body
      const bladeGeo = new THREE.BoxGeometry(1.6, bladeLength, 0.4);
      bladeGeo.translate(0, bladeLength / 2 + 4, 0);
      const bladeMesh = new THREE.Mesh(bladeGeo, compositeMat.clone());
      bladeMesh.name = `blade_${i + 1}`;
      bladeHolder.add(bladeMesh);

      this.rotorGroup.add(bladeHolder);
    }
    group.add(this.rotorGroup);

    // Explode hub forward
    this.explodedParts.push({
      mesh: this.rotorGroup,
      basePos: this.rotorGroup.position.clone(),
      explodeDir: new THREE.Vector3(0, 0, 16),
    });

    // 9. Aerodynamic Streamlines (Flow vectors)
    this.windStreamlines = this.createStreamlines();
    group.add(this.windStreamlines);
  }

  private createStreamlines(): THREE.LineSegments {
    const linesCount = 80;
    const points: THREE.Vector3[] = [];
    const colors: THREE.Color[] = [];
    const c1 = new THREE.Color(0x58b7c8); // Cyan
    const c2 = new THREE.Color(0xe7aa49); // Amber

    for (let i = 0; i < linesCount; i++) {
      const rad = 5 + Math.random() * 32;
      const angle = Math.random() * Math.PI * 2;
      const y = 43.6 + rad * Math.cos(angle);
      const x = rad * Math.sin(angle);

      // Curved streamline deflecting around rotor
      const zStart = 35 + Math.random() * 10;
      const zEnd = -30 - Math.random() * 15;

      points.push(new THREE.Vector3(x * 0.9, y, zStart));
      points.push(new THREE.Vector3(x * 1.15, y * 1.02, zEnd));

      colors.push(c1);
      colors.push(c2);
    }

    const geo = new THREE.BufferGeometry().setFromPoints(points);
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors.flatMap((c) => [c.r, c.g, c.b]), 3));
    const mat = new THREE.LineBasicMaterial({vertexColors: true, transparent: true, opacity: 0.55});
    return new THREE.LineSegments(geo, mat);
  }

  // -------------------------------------------------------------
  // SCENE 2: BLADE & TOWER MANUFACTURING HALL
  // -------------------------------------------------------------
  private buildFactoryScene(group: THREE.Group) {
    // Factory Polished Concrete Floor
    const floorGeo = new THREE.PlaneGeometry(140, 90);
    const floorMat = new THREE.MeshStandardMaterial({color: 0x1d2730, roughness: 0.4, metalness: 0.2});
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    group.add(floor);

    // Safety Yellow Walkway Lines
    const lineMat = new THREE.MeshBasicMaterial({color: 0xe7aa49});
    const lineGeo = new THREE.PlaneGeometry(130, 0.4);
    const lineMesh = new THREE.Mesh(lineGeo, lineMat);
    lineMesh.rotation.x = -Math.PI / 2;
    lineMesh.position.set(0, 0.02, 12);
    group.add(lineMesh);

    // Factory Hall Structural Columns
    const colMat = new THREE.MeshStandardMaterial({color: 0x2e3d48, roughness: 0.7, metalness: 0.5});
    for (let x = -60; x <= 60; x += 30) {
      const colGeo = new THREE.BoxGeometry(1.2, 24, 1.2);
      const col1 = new THREE.Mesh(colGeo, colMat);
      col1.position.set(x, 12, -35);
      const col2 = new THREE.Mesh(colGeo, colMat);
      col2.position.set(x, 12, 35);
      group.add(col1);
      group.add(col2);
    }

    // Overhead Gantry Crane Rail & Bridge
    this.gantryCrane = new THREE.Group();
    const gantryMat = new THREE.MeshStandardMaterial({color: 0xe7aa49, roughness: 0.35, metalness: 0.6});
    const bridgeGeo = new THREE.BoxGeometry(4, 2.5, 70);
    const bridge = new THREE.Mesh(bridgeGeo, gantryMat);
    bridge.position.set(0, 22, 0);
    this.gantryCrane.add(bridge);

    // Crane Hoist Trolley
    const trolleyGeo = new THREE.BoxGeometry(3, 1.8, 4);
    const trolley = new THREE.Mesh(trolleyGeo, new THREE.MeshStandardMaterial({color: 0x172735}));
    trolley.position.set(0, 20.8, -5);
    this.gantryCrane.add(trolley);

    // Hoist Cables and Lifting Beam
    const cableMat = new THREE.LineBasicMaterial({color: 0xcccccc});
    const cableGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 20.8, -5),
      new THREE.Vector3(0, 10, -5),
    ]);
    const cable = new THREE.Line(cableGeo, cableMat);
    this.gantryCrane.add(cable);

    group.add(this.gantryCrane);

    // 115m Blade Vacuum Infusion Mould Bed
    const mouldMat = new THREE.MeshStandardMaterial({color: 0x3b596d, roughness: 0.3, metalness: 0.7});
    const mouldGeo = new THREE.BoxGeometry(85, 2.5, 7);
    const mouldBed = new THREE.Mesh(mouldGeo, mouldMat);
    mouldBed.position.set(0, 1.25, -12);
    group.add(mouldBed);

    // Cured Blade Shell inside Mould (White Composite)
    const bladeMat = new THREE.MeshStandardMaterial({color: 0xeaf1f4, roughness: 0.2, metalness: 0.1});
    const bladeGeo = new THREE.CylinderGeometry(0.8, 2.2, 80, 16);
    bladeGeo.rotateZ(Math.PI / 2);
    const bladeInMould = new THREE.Mesh(bladeGeo, bladeMat);
    bladeInMould.position.set(0, 3.2, -12);
    group.add(bladeInMould);

    // Hydraulic Clamp Arms along mould
    for (let x = -38; x <= 38; x += 6) {
      const clampGeo = new THREE.BoxGeometry(0.5, 3.5, 8.5);
      const clamp = new THREE.Mesh(clampGeo, gantryMat);
      clamp.position.set(x, 2.8, -12);
      group.add(clamp);
    }

    // Robot Layup Head
    const robotMat = new THREE.MeshStandardMaterial({color: 0x58b7c8, roughness: 0.3, metalness: 0.6});
    const robotBase = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.8, 1.2, 16), colMat);
    robotBase.position.set(15, 0.6, -3);
    group.add(robotBase);

    const robotArm1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 6, 0.6), robotMat);
    robotArm1.position.set(15, 4.0, -3);
    robotArm1.rotation.z = -0.3;
    group.add(robotArm1);

    // Tower Fabrication Rolling Station (Steel can section)
    const towerRollMat = new THREE.MeshStandardMaterial({color: 0x556677, roughness: 0.3, metalness: 0.9});
    const towerCanGeo = new THREE.CylinderGeometry(5.2, 5.2, 14, 32, 1, true);
    towerCanGeo.rotateZ(Math.PI / 2);
    const towerCan = new THREE.Mesh(towerCanGeo, towerRollMat);
    towerCan.position.set(-30, 5.5, 15);
    group.add(towerCan);

    // Welding Arc Glow Light
    const weldLight = new THREE.PointLight(0x58b7c8, 3.0, 15);
    weldLight.position.set(-30, 5.5, 15);
    group.add(weldLight);
  }

  // -------------------------------------------------------------
  // SCENE 3: OFFSHORE DP2 JACK-UP INSTALLATION
  // -------------------------------------------------------------
  private buildOffshoreScene(group: THREE.Group) {
    // Ocean Plane with Deep Midnight Water Material
    const oceanGeo = new THREE.PlaneGeometry(240, 240, 48, 48);
    const oceanMat = new THREE.MeshStandardMaterial({
      color: 0x0f2b3c,
      roughness: 0.15,
      metalness: 0.85,
      transparent: true,
      opacity: 0.92,
    });
    this.oceanMesh = new THREE.Mesh(oceanGeo, oceanMat);
    this.oceanMesh.rotation.x = -Math.PI / 2;
    this.oceanMesh.position.y = 0;
    this.oceanMesh.receiveShadow = true;
    group.add(this.oceanMesh);

    // Offshore Monopile Foundation (Steel Blue entering water)
    const pileMat = new THREE.MeshStandardMaterial({color: 0x223344, roughness: 0.4, metalness: 0.8});
    const pileGeo = new THREE.CylinderGeometry(4.8, 4.8, 30, 32);
    const pile = new THREE.Mesh(pileGeo, pileMat);
    pile.position.set(0, 8, 0);
    group.add(pile);

    // Safety Yellow Transition Piece (TP)
    const tpMat = new THREE.MeshStandardMaterial({color: 0xe7aa49, roughness: 0.35, metalness: 0.5});
    const tpGeo = new THREE.CylinderGeometry(5.0, 5.0, 10, 32);
    const tp = new THREE.Mesh(tpGeo, tpMat);
    tp.position.set(0, 18, 0);
    group.add(tp);

    // Tower Lower Section already installed
    const towerMat = new THREE.MeshStandardMaterial({color: 0xdde5eb, roughness: 0.3, metalness: 0.4});
    const lowerTowerGeo = new THREE.CylinderGeometry(3.6, 4.6, 28, 32);
    const lowerTower = new THREE.Mesh(lowerTowerGeo, towerMat);
    lowerTower.position.set(0, 37, 0);
    group.add(lowerTower);

    // Jack-Up Installation Vessel (Seajacks Scylla)
    const vesselGroup = new THREE.Group();
    vesselGroup.position.set(38, 0, 15);

    // Hull
    const hullMat = new THREE.MeshStandardMaterial({color: 0x1d2c38, roughness: 0.4, metalness: 0.6});
    const hullGeo = new THREE.BoxGeometry(45, 8, 26);
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.set(0, 6, 0); // Elevated on jack-up legs above water
    vesselGroup.add(hull);

    // 4 Jack-Up Lattice Legs (penetrating sea)
    const legMat = new THREE.MeshStandardMaterial({color: 0x8899aa, roughness: 0.3, metalness: 0.9});
    const legGeo = new THREE.CylinderGeometry(1.6, 1.6, 65, 16);
    const legOffsets = [
      [-18, -9],
      [18, -9],
      [-18, 9],
      [18, 9],
    ];
    legOffsets.forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(lx, 15, lz);
      vesselGroup.add(leg);
    });

    // 1500t Main Offshore Crane Pedestal & Boom
    const craneGroup = new THREE.Group();
    craneGroup.position.set(-15, 10, -8);

    const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.6, 6, 24), tpMat);
    craneGroup.add(pedestal);

    // Boom lattice (inclined towards turbine)
    const boomGeo = new THREE.BoxGeometry(2.4, 55, 2.4);
    const boom = new THREE.Mesh(boomGeo, tpMat);
    boom.position.set(-14, 30, 4);
    boom.rotation.z = 0.55;
    boom.rotation.y = -0.3;
    craneGroup.add(boom);

    // Crane Hoist Cable holding Nacelle in mid-air
    const hoistWire = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(-28, 52, 6),
        new THREE.Vector3(-38, 38, -15),
      ]),
      new THREE.LineBasicMaterial({color: 0xeeeeee})
    );
    craneGroup.add(hoistWire);

    vesselGroup.add(craneGroup);
    group.add(vesselGroup);

    // Nacelle being hoisted by crane
    const nacelleMat = new THREE.MeshStandardMaterial({color: 0xeaf1f4, roughness: 0.25, metalness: 0.2});
    const hoistedNacelle = new THREE.Mesh(new THREE.BoxGeometry(6, 4, 14), nacelleMat);
    hoistedNacelle.position.set(0, 52, 0); // Directly above tower top
    group.add(hoistedNacelle);
  }

  // -------------------------------------------------------------
  // SCENE 4: FLORIS WIND FARM & WAKE INTERACTIONS
  // -------------------------------------------------------------
  private buildWindFarmScene(group: THREE.Group) {
    this.farmRotors = [];

    // Vast Offshore Water
    const waterGeo = new THREE.PlaneGeometry(350, 350, 32, 32);
    const waterMat = new THREE.MeshStandardMaterial({color: 0x142b3b, roughness: 0.18, metalness: 0.85});
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    water.receiveShadow = true;
    group.add(water);

    // Wake Cones Holder Group
    this.wakeConesGroup = new THREE.Group();
    group.add(this.wakeConesGroup);

    const towerMat = new THREE.MeshStandardMaterial({color: 0xdde5eb, roughness: 0.35, metalness: 0.4});
    const bladeMat = new THREE.MeshStandardMaterial({color: 0xf0f5f8, roughness: 0.25, metalness: 0.2});
    const hubMat = new THREE.MeshStandardMaterial({color: 0x3b596d, roughness: 0.5, metalness: 0.6});

    // Spawn 8 Wind Turbines in Array
    const turbineCoords = [
      {id: 'WT-01', x: -60, z: -50, wake: 0.0},
      {id: 'WT-02', x: -60, z: 0, wake: 0.0},
      {id: 'WT-03', x: -60, z: 50, wake: 0.0},
      {id: 'WT-04', x: 0, z: -35, wake: 0.06},
      {id: 'WT-05', x: 0, z: 0, wake: 0.15},
      {id: 'WT-06', x: 0, z: 35, wake: 0.05},
      {id: 'WT-07', x: 60, z: 0, wake: 0.25},
      {id: 'WT-08', x: 60, z: 45, wake: 0.10},
    ];

    turbineCoords.forEach((t) => {
      const tGroup = new THREE.Group();
      tGroup.position.set(t.x, 0, t.z);

      // Monopile Yellow Transition
      const pile = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 6, 16), new THREE.MeshStandardMaterial({color: 0xe7aa49}));
      pile.position.y = 3;
      tGroup.add(pile);

      // Tower
      const tower = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.5, 34, 20), towerMat);
      tower.position.y = 23;
      tGroup.add(tower);

      // Nacelle
      const nacelle = new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.8, 6.5), towerMat);
      nacelle.position.set(0, 40, -1);
      tGroup.add(nacelle);

      // Rotating Rotor
      const rotor = new THREE.Group();
      rotor.position.set(0, 40, 2.8);

      const hub = new THREE.Mesh(new THREE.SphereGeometry(1.2, 16, 16), hubMat);
      rotor.add(hub);

      for (let b = 0; b < 3; b++) {
        const bladeArm = new THREE.Group();
        bladeArm.rotation.z = (b * 2 * Math.PI) / 3;
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.7, 18, 0.18), bladeMat);
        blade.position.y = 10;
        bladeArm.add(blade);
        rotor.add(bladeArm);
      }
      tGroup.add(rotor);
      this.farmRotors.push(rotor);

      group.add(tGroup);

      // FLORIS Wake Deficit Visualization Cone
      // Spreads downstream towards +X direction
      const wakeLength = 65;
      const wakeEndRadius = 14;
      const wakeGeo = new THREE.ConeGeometry(wakeEndRadius, wakeLength, 24, 1, true);
      wakeGeo.rotateZ(-Math.PI / 2);
      wakeGeo.translate(wakeLength / 2, 0, 0);

      // Color shifts from cyan (slight deficit) to amber/red (severe deficit)
      const wakeColor = t.wake > 0.12 ? 0xe7aa49 : 0x58b7c8;
      const wakeMat = new THREE.MeshBasicMaterial({
        color: wakeColor,
        transparent: true,
        opacity: 0.18,
        wireframe: true,
        side: THREE.DoubleSide,
      });
      const wakeCone = new THREE.Mesh(wakeGeo, wakeMat);
      wakeCone.position.set(t.x + 3, 40, t.z);
      this.wakeConesGroup?.add(wakeCone);
    });
  }

  // -------------------------------------------------------------
  // SCENE 5: AARDVARK AUTONOMOUS DRONE BLADE NDT INSPECTION
  // -------------------------------------------------------------
  private buildInspectionScene(group: THREE.Group) {
    // Mounting Fixture (Heavy steel trestles)
    const fixtureMat = new THREE.MeshStandardMaterial({color: 0x3b596d, roughness: 0.5, metalness: 0.7});
    const stand1 = new THREE.Mesh(new THREE.BoxGeometry(3, 8, 4), fixtureMat);
    stand1.position.set(0, 4, 0);
    group.add(stand1);

    const stand2 = new THREE.Mesh(new THREE.BoxGeometry(2, 6, 3), fixtureMat);
    stand2.position.set(45, 3, 0);
    group.add(stand2);

    // Full 115m Scaled Blade on Display (Oriented horizontally along X)
    const bladeGroup = new THREE.Group();
    bladeGroup.position.set(0, 7.5, 0);

    // Root section (circular flange with metallic bolts)
    const rootGeo = new THREE.CylinderGeometry(2.2, 2.2, 4, 32);
    rootGeo.rotateZ(Math.PI / 2);
    const rootMesh = new THREE.Mesh(rootGeo, new THREE.MeshStandardMaterial({color: 0x223344, roughness: 0.4, metalness: 0.8}));
    bladeGroup.add(rootMesh);

    // Tapered aerodynamic body
    const bodyGeo = new THREE.CylinderGeometry(0.3, 2.2, 75, 32);
    bodyGeo.rotateZ(Math.PI / 2);
    bodyGeo.translate(37.5, 0, 0);
    const bladeMat = new THREE.MeshStandardMaterial({
      color: 0xeaf1f4,
      roughness: 0.22,
      metalness: 0.15,
    });
    const bodyMesh = new THREE.Mesh(bodyGeo, bladeMat);
    bladeGroup.add(bodyMesh);

    // Carbon spar cap strip running down the middle
    const sparGeo = new THREE.BoxGeometry(70, 0.6, 0.05);
    sparGeo.translate(38, 0.85, 0);
    const sparMesh = new THREE.Mesh(sparGeo, new THREE.MeshStandardMaterial({color: 0x172735, roughness: 0.1, metalness: 0.9}));
    bladeGroup.add(sparMesh);

    group.add(bladeGroup);

    // Defect Hotspot Markers on Blade Surface
    this.defectMarkersGroup = new THREE.Group();
    this.defectMarkersGroup.position.set(0, 7.5, 0);

    const markerMatRed = new THREE.MeshBasicMaterial({color: 0xd95a57});
    const markerMatAmber = new THREE.MeshBasicMaterial({color: 0xe7aa49});
    const markerMatCyan = new THREE.MeshBasicMaterial({color: 0x58b7c8});

    // Map defect positions
    this.state.bladeDefects.forEach((def) => {
      const xPos = (def.locationMetersFromRoot / 115.5) * 75;
      const marker = new THREE.Mesh(
        new THREE.SphereGeometry(0.55, 16, 16),
        def.severityScore === 'Critical' ? markerMatRed : def.severityScore === 'Moderate' ? markerMatAmber : markerMatCyan
      );
      marker.position.set(xPos, 1.2, 0);
      marker.userData = {defect: def};
      this.defectMarkersGroup?.add(marker);
    });

    group.add(this.defectMarkersGroup);

    // Aardvark Autonomous Inspection Drone
    this.inspectionDrone = new THREE.Group();
    this.inspectionDrone.position.set(55, 12, 4);

    // Drone Body
    const droneBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 0.4, 1.6),
      new THREE.MeshStandardMaterial({color: 0x172735, roughness: 0.2, metalness: 0.8})
    );
    this.inspectionDrone.add(droneBody);

    // 4 Quadcopter Rotor Arms & Rotors
    const armMat = new THREE.MeshStandardMaterial({color: 0x58b7c8, metalness: 0.5});
    const propMat = new THREE.MeshBasicMaterial({color: 0xcccccc});
    const armOffsets = [
      [-1.4, -1.4],
      [1.4, -1.4],
      [-1.4, 1.4],
      [1.4, 1.4],
    ];
    armOffsets.forEach(([ax, az]) => {
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.8), armMat);
      arm.position.set(ax / 2, 0, az / 2);
      this.inspectionDrone?.add(arm);

      const prop = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.02, 12), propMat);
      prop.position.set(ax, 0.25, az);
      this.inspectionDrone?.add(prop);
    });

    // Optical & LiDAR Scanner Gimbal
    const gimbal = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 16, 16),
      new THREE.MeshStandardMaterial({color: 0x58b7c8, metalness: 0.9, roughness: 0.1})
    );
    gimbal.position.set(0, -0.3, 0.4);
    this.inspectionDrone.add(gimbal);

    // LiDAR Scanning Laser Cone (pointing to defect)
    const scanGeo = new THREE.ConeGeometry(2.5, 6, 16, 1, true);
    scanGeo.rotateX(Math.PI / 2);
    const scanCone = new THREE.Mesh(
      scanGeo,
      new THREE.MeshBasicMaterial({color: 0x58b7c8, transparent: true, opacity: 0.22, wireframe: true})
    );
    scanCone.position.set(0, -3.2, 0);
    this.inspectionDrone.add(scanCone);

    group.add(this.inspectionDrone);
  }

  // -------------------------------------------------------------
  // ANIMATION & DYNAMIC UPDATES
  // -------------------------------------------------------------
  private updateExplodedTransforms(progressPercent: number) {
    const factor = progressPercent / 100;
    this.explodedParts.forEach((part) => {
      part.mesh.position.lerpVectors(part.basePos, part.basePos.clone().add(part.explodeDir.clone().multiplyScalar(factor)), 0.15);
    });
  }

  private toggleBladeStressMaterials(showStress: boolean) {
    if (!this.scene) return;
    for (let i = 1; i <= 3; i++) {
      const blade = this.scene.getObjectByName(`blade_${i}`) as THREE.Mesh | undefined;
      if (blade && blade.material instanceof THREE.MeshStandardMaterial) {
        if (showStress) {
          // Von Mises Stress Heatmap (Energy Amber/Red near root spar, Cyan at tip)
          blade.material.color.setHex(0xe7aa49);
          blade.material.emissive.setHex(0xd95a57);
          blade.material.emissiveIntensity = 0.35;
        } else {
          blade.material.color.setHex(0xe6edf0);
          blade.material.emissive.setHex(0x000000);
          blade.material.emissiveIntensity = 0;
        }
      }
    }
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // 1. Update OrbitControls damping
    this.controls?.update();

    // 2. Rotate Main Engineering Rotor based on simulated RPM
    if (this.rotorGroup) {
      const rpm = this.state.currentAerodynamics().rotorRpm;
      const radPerSec = (rpm * 2 * Math.PI) / 60;
      this.rotorGroup.rotation.z += radPerSec * delta;
    }

    // 3. Rotate Wind Farm Turbines
    this.farmRotors.forEach((rotor, idx) => {
      const baseRpm = this.state.currentAerodynamics().rotorRpm;
      // Slight stagger between turbines
      const factor = 1.0 - (idx % 3) * 0.05;
      const radPerSec = (baseRpm * factor * 2 * Math.PI) / 60;
      rotor.rotation.z += radPerSec * delta;
    });

    // 4. Subtle Ocean Undulation in Offshore Scene
    if (this.oceanMesh && this.state.activeScene() === 'offshore') {
      const posAttr = this.oceanMesh.geometry.attributes['position'];
      if (posAttr) {
        for (let i = 0; i < posAttr.count; i++) {
          const u = posAttr.getX(i);
          const v = posAttr.getY(i);
          posAttr.setZ(i, Math.sin(u * 0.08 + elapsedTime * 1.8) * 0.35 + Math.cos(v * 0.08 + elapsedTime * 1.5) * 0.25);
        }
        posAttr.needsUpdate = true;
      }
    }

    // 5. Factory Gantry Crane gentle translation
    if (this.gantryCrane && this.state.activeScene() === 'factory') {
      this.gantryCrane.position.x = Math.sin(elapsedTime * 0.3) * 15;
    }

    // 6. Drone Hover in Inspection Scene
    if (this.inspectionDrone && this.state.activeScene() === 'inspection') {
      this.inspectionDrone.position.y = 12 + Math.sin(elapsedTime * 2.2) * 0.4;
      this.inspectionDrone.position.x = 55 + Math.cos(elapsedTime * 0.8) * 1.2;
    }

    // 7. Render
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  private onWindowResize() {
    const container = this.containerRef()?.nativeElement;
    if (!container || !this.renderer || !this.camera) return;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }
}
