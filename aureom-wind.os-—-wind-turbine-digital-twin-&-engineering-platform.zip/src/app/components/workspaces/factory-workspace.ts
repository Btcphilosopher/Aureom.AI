import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-factory-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-5 text-[#EAF1F4]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3B596D]/30 pb-4">
        <div>
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Industrial Manufacturing & Composites</div>
          <h2 class="text-xl font-bold text-white tracking-tight">Factory Digital Twin & Discrete-Event Process</h2>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-xs font-mono bg-[#172735] px-3 py-1.5 rounded-lg border border-[#3B596D]/40">
            <span class="text-slate-400">ACTIVE PRODUCTION:</span>
            <span class="text-white font-bold ml-1">{{ state.selectedTurbine().serialNumber }}</span>
          </div>
        </div>
      </div>

      <!-- Factory Production OEE KPIs -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">OVERALL OEE</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">87.4%</div>
          <div class="text-[10px] text-slate-400">World-class benchmark &ge; 85%</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">ANNUAL CAPACITY</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">120 Turbines</div>
          <div class="text-[10px] text-slate-400">1.8 GW / year output</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">FIRST-PASS YIELD</div>
          <div class="text-lg font-bold font-mono text-[#58B7C8] tabular-nums">98.2%</div>
          <div class="text-[10px] text-slate-400">Scrap Rate: 1.8%</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">LEAD TIME (BLADE)</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">64.5 hrs</div>
          <div class="text-[10px] text-slate-400">Cycle: 24 hrs / mould</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">ACTIVE WIP UNITS</div>
          <div class="text-lg font-bold font-mono text-[#E7AA49] tabular-nums">14 Assemblies</div>
          <div class="text-[10px] text-slate-400">6 Blades · 4 Towers · 4 Nacelles</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">BOTTLENECK BAY</div>
          <div class="text-base font-semibold font-mono text-[#D95A57] uppercase">Bay 2 Infusion</div>
          <div class="text-[10px] text-slate-400">96% Utilization</div>
        </div>
      </div>

      <!-- Main Columns: Stations Table & Cure Kinetics Simulator -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <!-- Column 1: Station Status & Discrete-Event Workstations -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">01. Discrete-Event Manufacturing Stations</h3>
            <span class="text-xs font-mono text-[#58B7C8]">7 Operating Bays</span>
          </div>

          <div class="space-y-2.5">
            @for (station of state.factoryStations(); track station.id) {
              <div class="bg-[#101820]/70 border border-[#3B596D]/30 rounded-xl p-3 hover:border-[#58B7C8]/50 transition-colors">
                <div class="flex items-center justify-between mb-1">
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono font-bold text-[#E7AA49]">{{ station.bay }}</span>
                    <span class="text-xs font-semibold text-white">{{ station.name }}</span>
                  </div>
                  <span
                    [class.text-[#5DAA88]]="station.status === 'Operating'"
                    [class.text-[#E7AA49]]="station.status === 'Curing'"
                    [class.text-[#58B7C8]]="station.status === 'Inspection'"
                    [class.text-slate-400]="station.status === 'Setup'"
                    class="text-[11px] font-mono uppercase font-semibold"
                  >
                    {{ station.status }}
                  </span>
                </div>

                <div class="text-[11px] text-slate-400 mb-2">
                  <span>Asset: {{ station.currentAssetId }}</span>
                  <span class="mx-1">·</span>
                  <span>Lead: {{ station.leadTechnician }}</span>
                </div>

                <div class="flex items-center justify-between text-[11px] font-mono border-t border-[#3B596D]/20 pt-2 text-slate-300">
                  <span>Cycle: {{ station.cycleTimeHours }}h</span>
                  <span>Util: {{ station.utilizationPercent }}%</span>
                  <span>Temp: {{ station.sensors.temperatureC }}°C</span>
                  @if (station.sensors.vacuumMbar) {
                    <span class="text-[#58B7C8]">Vac: {{ station.sensors.vacuumMbar }} mbar</span>
                  }
                  <span>Vib: {{ station.sensors.vibrationMmS }} mm/s</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Column 2: 115m Blade Vacuum Infusion & Kamal-Sourour Cure Kinetics -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">02. Kamal-Sourour Composite Cure Kinetics</h3>
            <span class="text-xs font-mono text-[#E7AA49]">Bay 2 Infusion Bed</span>
          </div>

          <!-- Formula callout -->
          <div class="bg-[#101820] border border-[#3B596D]/40 p-2.5 rounded-xl font-mono text-xs text-slate-300">
            d&alpha;/dt = (k&#8321; + k&#8322; · &alpha;&#7504;) · (1 - &alpha;)&#8319;
            <div class="text-[10px] text-slate-400 mt-1">
              Kamal-Sourour autocatalytic cure kinetics with DiBenedetto Glass Transition Tg(&alpha;)
            </div>
          </div>

          <!-- Interactive Time Slider -->
          <div class="bg-[#101820]/60 p-3 rounded-xl border border-[#3B596D]/30 space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-slate-300">Simulate Elapsed Cure Time:</span>
              <span class="text-[#E7AA49] font-bold tabular-nums">{{ state.cureElapsedMinutes() }} min / {{ state.cureState().totalCycleMinutes }} min</span>
            </div>
            <input
              type="range"
              min="0"
              max="240"
              step="5"
              [value]="state.cureElapsedMinutes()"
              (input)="onCureSlider($event)"
              class="w-full accent-[#E7AA49] cursor-pointer h-2 bg-[#172735] rounded-lg"
            />
          </div>

          <!-- Cure Metrics Grid -->
          <div class="grid grid-cols-2 gap-3 text-xs font-mono">
            <div class="bg-[#101820]/50 p-3 rounded-xl border border-[#3B596D]/20">
              <span class="text-slate-400 text-[10px] block">DEGREE OF CURE (&alpha;)</span>
              <span class="text-2xl font-bold text-[#5DAA88] tabular-nums">{{ (state.cureState().cureCompletionAlpha * 100).toFixed(1) }}%</span>
              <div class="w-full bg-[#172735] h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  class="bg-[#5DAA88] h-full rounded-full transition-all"
                  [style.width.%]="state.cureState().cureCompletionAlpha * 100"
                ></div>
              </div>
            </div>

            <div class="bg-[#101820]/50 p-3 rounded-xl border border-[#3B596D]/20">
              <span class="text-slate-400 text-[10px] block">GLASS TRANSITION TEMP (Tg)</span>
              <span class="text-2xl font-bold text-[#58B7C8] tabular-nums">{{ state.cureState().glassTransitionTgC }}°C</span>
              <span class="text-slate-400 text-[10px] block mt-1">Target Tg,inf: 125.0°C</span>
            </div>

            <div class="bg-[#101820]/50 p-3 rounded-xl border border-[#3B596D]/20">
              <span class="text-slate-400 text-[10px] block">EXOTHERM CORE PEAK</span>
              <span class="text-lg font-bold text-[#E7AA49] tabular-nums">{{ state.cureState().coreTemperatureC }}°C</span>
              <span class="text-slate-400 text-[10px] block">Mould Target: {{ state.cureState().moldTemperatureC }}°C</span>
            </div>

            <div class="bg-[#101820]/50 p-3 rounded-xl border border-[#3B596D]/20">
              <span class="text-slate-400 text-[10px] block">VACUUM / POROSITY</span>
              <span class="text-lg font-bold text-white tabular-nums">{{ state.cureState().vacuumPressureMbar }} mbar</span>
              <span class="text-slate-400 text-[10px] block">Est. Void: {{ state.cureState().estimatedPorosityPercent }}% (&le; 1.0% pass)</span>
            </div>
          </div>

          <!-- Raw Material Traceability Snippet -->
          <div class="bg-[#101820]/40 p-3 rounded-xl border border-[#3B596D]/20 space-y-2">
            <div class="text-xs font-semibold text-white flex items-center justify-between">
              <span>Material Batch Traceability (Line Feeds)</span>
              <span class="text-[10px] font-mono text-[#58B7C8]">EN 10204 3.1</span>
            </div>
            <div class="space-y-1.5 text-[11px] font-mono text-slate-300">
              <div class="flex justify-between border-b border-[#3B596D]/15 pb-1">
                <span>Carbon Tow:</span>
                <span class="text-white">{{ state.materialBatches()[0].batchCode }} (Toray T700S)</span>
              </div>
              <div class="flex justify-between border-b border-[#3B596D]/15 pb-1">
                <span>Resin System:</span>
                <span class="text-white">{{ state.materialBatches()[1].batchCode }} (Hexion EPIKOTE)</span>
              </div>
              <div class="flex justify-between">
                <span>Steel Plate:</span>
                <span class="text-white">{{ state.materialBatches()[2].batchCode }} (Tata S355ML)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class FactoryWorkspace {
  protected readonly state = inject(TurbineState);

  onCureSlider(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.setCureElapsed(val);
  }
}
