import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-logistics-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-5 text-[#EAF1F4]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3B596D]/30 pb-4">
        <div>
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Transportation & Offshore Construction</div>
          <h2 class="text-xl font-bold text-white tracking-tight">Logistics Simulator & Metocean Weather Windows</h2>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-xs font-mono bg-[#172735] px-3 py-1.5 rounded-lg border border-[#3B596D]/40">
            <span class="text-slate-400">DESTINATION:</span>
            <span class="text-[#58B7C8] font-bold ml-1">Dogger Bank Array B (130 km Offshore)</span>
          </div>
        </div>
      </div>

      <!-- Logistics Key Metrics -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">INSTALLATION VESSEL</div>
          <div class="text-base font-bold font-mono text-[#58B7C8]">Seajacks Scylla</div>
          <div class="text-[10px] text-slate-400">DP2 Jack-Up · 1500t Crane</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">CURRENT WAVE (Hs)</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">1.3 m</div>
          <div class="text-[10px] text-slate-400">Limit: &le; 1.8 m (SAFE WINDOW)</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">WIND SPEED (U10)</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">8.5 m/s</div>
          <div class="text-[10px] text-slate-400">Limit for Lift: &le; 10.0 m/s</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">HEAVIEST LIFT</div>
          <div class="text-lg font-bold font-mono text-[#E7AA49] tabular-nums">840 t</div>
          <div class="text-[10px] text-slate-400">Tower Section 1 + TP Flange</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">CYCLE TIME / TURBINE</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">36.0 hrs</div>
          <div class="text-[10px] text-slate-400">Target: 3.5 days complete</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">CAMPAIGN PROGRESS</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">Step 4 / 8</div>
          <div class="text-[10px] text-slate-400">65% of Active Sequence</div>
        </div>
      </div>

      <!-- Installation Timeline & Vessel Specifications -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <!-- Installation Sequence (2 Columns) -->
        <div class="lg:col-span-2 bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">01. 8-Stage Offshore Construction Sequence</h3>
            <span class="text-xs font-mono text-[#58B7C8]">DNV-ST-N001 Marine Operations</span>
          </div>

          <div class="space-y-3">
            @for (step of state.logisticsSteps(); track step.id) {
              <div class="bg-[#101820]/70 border border-[#3B596D]/30 rounded-xl p-3 hover:border-[#58B7C8]/50 transition-colors">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono font-bold text-[#58B7C8] w-6">0{{ step.stepNumber }}.</span>
                    <span class="text-xs font-semibold text-white">{{ step.title }}</span>
                  </div>
                  <span
                    [class.text-[#5DAA88]]="step.status === 'Completed'"
                    [class.text-[#E7AA49]]="step.status === 'In Progress'"
                    [class.text-slate-400]="step.status === 'Scheduled'"
                    class="text-[11px] font-mono uppercase font-semibold"
                  >
                    {{ step.status }} ({{ step.progressPercent }}%)
                  </span>
                </div>

                <div class="text-[11px] text-slate-400 mb-2 font-mono">
                  <span>Tooling: {{ step.vesselOrVehicle }}</span>
                  <span class="mx-1">·</span>
                  <span>Lift Mass: {{ step.craneLiftMassTons }} t</span>
                </div>

                <!-- Weather Window Feasibility Bar -->
                <div class="flex items-center justify-between text-[11px] font-mono border-t border-[#3B596D]/20 pt-2 text-slate-300">
                  <span>Wave Limit: Hs &le; {{ step.weatherLimitWaveHsM }}m</span>
                  <span>Wind Limit: &le; {{ step.weatherLimitWindMs }} m/s</span>
                  <span class="text-[#5DAA88] font-semibold">EST. DURATION: {{ step.durationDays }} Days</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Vessel Fleet & Weather Window Simulator (1 Column) -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">02. Metocean Window Analysis</h3>
            <span class="text-xs font-mono text-[#5DAA88]">WINDOW OPEN</span>
          </div>

          <!-- Metocean Radar & Wave Forecast Box -->
          <div class="bg-[#101820]/70 p-3 rounded-xl border border-[#3B596D]/30 space-y-3">
            <div class="text-xs font-semibold text-white">48-Hour Wave & Wind Forecast (Dogger Bank)</div>

            <div class="space-y-2 text-xs font-mono">
              <div>
                <div class="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Significant Wave Height (Hs): 1.3 m</span>
                  <span class="text-[#5DAA88]">Limit: 1.8 m</span>
                </div>
                <div class="w-full bg-[#172735] h-2 rounded-full overflow-hidden">
                  <div class="bg-[#5DAA88] h-full rounded-full" style="width: 72%;"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Wind Speed at 10m: 8.5 m/s</span>
                  <span class="text-[#5DAA88]">Lift Limit: 10.0 m/s</span>
                </div>
                <div class="w-full bg-[#172735] h-2 rounded-full overflow-hidden">
                  <div class="bg-[#58B7C8] h-full rounded-full" style="width: 85%;"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Tidal Current Velocity: 1.2 knots</span>
                  <span class="text-[#58B7C8]">DP2 Station-Keeping OK</span>
                </div>
                <div class="w-full bg-[#172735] h-2 rounded-full overflow-hidden">
                  <div class="bg-[#3B596D] h-full rounded-full" style="width: 40%;"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Fleet Manifest -->
          <div class="space-y-2 text-xs font-mono">
            <div class="text-xs font-semibold text-white">Offshore Construction Fleet</div>
            <div class="bg-[#101820]/50 p-2.5 rounded-lg border border-[#3B596D]/20">
              <div class="text-white font-bold">Seajacks Scylla (OIV)</div>
              <div class="text-slate-400 text-[10px]">139m LOA · 50m Beam · 1500t Huisman Crane</div>
            </div>
            <div class="bg-[#101820]/50 p-2.5 rounded-lg border border-[#3B596D]/20">
              <div class="text-white font-bold">Living Stone (CLV)</div>
              <div class="text-slate-400 text-[10px]">Dual Cable Turntables (10,000t capacity)</div>
            </div>
            <div class="bg-[#101820]/50 p-2.5 rounded-lg border border-[#3B596D]/20">
              <div class="text-white font-bold">Boka Falcon (Anchor Handler)</div>
              <div class="text-slate-400 text-[10px]">150t Bollard Pull · ROV Workclass Support</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class LogisticsWorkspace {
  protected readonly state = inject(TurbineState);
}
