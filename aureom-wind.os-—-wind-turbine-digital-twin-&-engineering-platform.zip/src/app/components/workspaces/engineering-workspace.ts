import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';
import {TurbineConfig} from '../../models/turbine.models';

@Component({
  selector: 'app-engineering-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-5 text-[#EAF1F4]">
      <!-- Workspace Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3B596D]/30 pb-4">
        <div>
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Aero-Structural & Drivetrain Engineering</div>
          <h2 class="text-xl font-bold text-white tracking-tight">Parametric Turbine Designer & BEM Physics</h2>
        </div>
        <!-- Turbine Selector Dropdown -->
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-400">MODEL:</span>
          <select
            (change)="onTurbineChange($event)"
            class="bg-[#172735] border border-[#3B596D]/50 text-white text-xs font-mono rounded-lg px-3 py-1.5 focus:border-[#58B7C8] outline-none cursor-pointer"
          >
            @for (t of state.allTurbines; track t.id) {
              <option [value]="t.id" [selected]="t.id === state.selectedTurbine().id">
                {{ t.name }} ({{ t.ratedPowerMW }} MW)
              </option>
            }
          </select>
        </div>
      </div>

      <!-- Quick Engineering KPI Ribbon (Clean Unboxed Metadata Standard) -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">RATED POWER</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">{{ currentTurbine().ratedPowerMW }} MW</div>
          <div class="text-[10px] text-slate-400">{{ currentTurbine().class }}</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">ROTOR DIAMETER</div>
          <div class="text-lg font-bold font-mono text-[#58B7C8] tabular-nums">{{ currentTurbine().rotorDiameterM }} m</div>
          <div class="text-[10px] text-slate-400">Swept: {{ rotorSweptAreaKm2() }} km²</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">HUB HEIGHT</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">{{ currentTurbine().hubHeightM }} m</div>
          <div class="text-[10px] text-slate-400">Tip: {{ (currentTurbine().hubHeightM + currentTurbine().bladeLengthM).toFixed(0) }} m</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">ARCHITECTURE</div>
          <div class="text-base font-semibold font-mono text-[#E7AA49] uppercase">{{ currentTurbine().architecture }}</div>
          <div class="text-[10px] text-slate-400">{{ currentTurbine().generatorType }} · {{ currentTurbine().generatorVoltageKV }} kV</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">TOWER MASS</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">{{ currentTurbine().towerGeometry.totalMassTons }} t</div>
          <div class="text-[10px] text-slate-400">Base &Oslash; {{ currentTurbine().towerGeometry.baseDiameterM }} m</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">BLADE MASS</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">{{ currentTurbine().bladeMaterials.bladeTotalMassTons }} t</div>
          <div class="text-[10px] text-slate-400">3x {{ (currentTurbine().bladeMaterials.bladeTotalMassTons * 3).toFixed(1) }} t</div>
        </div>
      </div>

      <!-- Main Engineering Columns -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <!-- Card 1: Blade Element Momentum (BEM) Aerodynamic Solver -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">01. Blade Element Momentum Aerodynamics</h3>
            <span class="text-xs font-mono text-[#58B7C8]">Betz Limit: 59.3%</span>
          </div>

          <div class="space-y-3 text-xs">
            <!-- Governing Formula Banner -->
            <div class="bg-[#101820] border border-[#3B596D]/40 p-2.5 rounded-xl font-mono text-xs text-slate-300">
              <span class="text-[#E7AA49]">P</span> = ½ · &rho; · A · V³ · <span class="text-[#58B7C8]">Cp(&lambda;, &theta;)</span>
              <div class="text-[10px] text-slate-400 mt-1">
                &rho; = 1.225 kg/m³ · A = {{ (currentTurbine().rotorDiameterM * currentTurbine().rotorDiameterM * 3.14159 / 4).toFixed(0) }} m² · V = {{ state.simulatedWindSpeed() }} m/s
              </div>
            </div>

            <!-- Operating Region Status -->
            <div class="flex items-center justify-between bg-[#101820]/60 p-2.5 rounded-lg border border-[#3B596D]/20">
              <span class="text-slate-400">Operating Regime:</span>
              <span class="font-mono font-semibold text-[#58B7C8]">{{ state.currentAerodynamics().operatingRegion }}</span>
            </div>

            <!-- Parameters Table -->
            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#101820]/40 p-2 rounded border border-[#3B596D]/20">
                <span class="text-slate-400 block text-[10px]">TIP-SPEED RATIO (&lambda;)</span>
                <span class="text-white font-bold text-sm tabular-nums">{{ state.currentAerodynamics().tipSpeedRatio.toFixed(2) }}</span>
                <span class="text-slate-500 text-[10px] block">Optimal: 8.40</span>
              </div>
              <div class="bg-[#101820]/40 p-2 rounded border border-[#3B596D]/20">
                <span class="text-slate-400 block text-[10px]">POWER COEFF (Cp)</span>
                <span class="text-[#58B7C8] font-bold text-sm tabular-nums">{{ state.currentAerodynamics().powerCoefficientCp.toFixed(3) }}</span>
                <span class="text-slate-500 text-[10px] block">Max Theoretical: 0.593</span>
              </div>
              <div class="bg-[#101820]/40 p-2 rounded border border-[#3B596D]/20">
                <span class="text-slate-400 block text-[10px]">THRUST COEFF (Ct)</span>
                <span class="text-[#E7AA49] font-bold text-sm tabular-nums">{{ state.currentAerodynamics().thrustCoefficientCt.toFixed(3) }}</span>
                <span class="text-slate-500 text-[10px] block">Thrust: {{ state.currentAerodynamics().rotorThrustKN.toFixed(0) }} kN</span>
              </div>
              <div class="bg-[#101820]/40 p-2 rounded border border-[#3B596D]/20">
                <span class="text-slate-400 block text-[10px]">AERO TORQUE</span>
                <span class="text-[#5DAA88] font-bold text-sm tabular-nums">{{ state.currentAerodynamics().aerodynamicTorqueKNm.toFixed(0) }} kNm</span>
                <span class="text-slate-500 text-[10px] block">Efficiency: 96.8%</span>
              </div>
            </div>

            <!-- Real-time Power Curve SVG -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Calculated Power Curve [0 to 30 m/s]</span>
                <span class="text-white tabular-nums">{{ state.currentAerodynamics().electricalPowerMW.toFixed(2) }} MW @ {{ state.simulatedWindSpeed() }} m/s</span>
              </div>
              <div class="w-full h-32 bg-[#101820] border border-[#3B596D]/40 rounded-xl p-2 relative overflow-hidden">
                <svg class="w-full h-full" viewBox="0 0 300 100" preserveAspectRatio="none">
                  <!-- Grid horizontal lines -->
                  <line x1="0" y1="20" x2="300" y2="20" stroke="#253846" stroke-width="0.8" stroke-dasharray="2 2" />
                  <line x1="0" y1="50" x2="300" y2="50" stroke="#253846" stroke-width="0.8" stroke-dasharray="2 2" />
                  <line x1="0" y1="80" x2="300" y2="80" stroke="#253846" stroke-width="0.8" stroke-dasharray="2 2" />

                  <!-- Power Curve Polyline -->
                  <polyline
                    fill="none"
                    stroke="#58B7C8"
                    stroke-width="2"
                    [attr.points]="powerCurvePointsSvg()"
                  />

                  <!-- Cut in & Rated wind speed vertical markers -->
                  <line [attr.x1]="currentTurbine().cutInSpeedMs * 10" y1="0" [attr.x2]="currentTurbine().cutInSpeedMs * 10" y2="100" stroke="#E7AA49" stroke-width="1" stroke-dasharray="2 2" />
                  <line [attr.x1]="currentTurbine().ratedSpeedMs * 10" y1="0" [attr.x2]="currentTurbine().ratedSpeedMs * 10" y2="100" stroke="#5DAA88" stroke-width="1" stroke-dasharray="2 2" />
                  <line [attr.x1]="currentTurbine().cutOutSpeedMs * 10" y1="0" [attr.x2]="currentTurbine().cutOutSpeedMs * 10" y2="100" stroke="#D95A57" stroke-width="1" stroke-dasharray="2 2" />

                  <!-- Current Wind Speed Operating Point Dot -->
                  <circle
                    [attr.cx]="state.simulatedWindSpeed() * 10"
                    [attr.cy]="100 - (state.currentAerodynamics().electricalPowerMW / currentTurbine().ratedPowerMW) * 80 - 10"
                    r="4"
                    fill="#E7AA49"
                    stroke="#ffffff"
                    stroke-width="1.5"
                  />
                </svg>
              </div>
              <div class="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0 m/s</span>
                <span>Cut-in: {{ currentTurbine().cutInSpeedMs }} m/s</span>
                <span>Rated: {{ currentTurbine().ratedSpeedMs }} m/s</span>
                <span>Cut-out: {{ currentTurbine().cutOutSpeedMs }} m/s</span>
                <span>30 m/s</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Card 2: Composite Blade & Tower Structural Engineering -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">02. Structural Loads, Spar Caps & Fatigue</h3>
            <span class="text-xs font-mono text-[#E7AA49]">IEC 61400-1 DLC 1.2</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="grid grid-cols-2 gap-3">
              <div class="bg-[#101820]/70 p-3 rounded-xl border border-[#3B596D]/30">
                <div class="text-[11px] font-mono text-slate-400 mb-1">SPAR CAP COMPOSITE</div>
                <div class="text-sm font-semibold text-white">{{ currentTurbine().bladeMaterials.sparCapMaterial }}</div>
                <div class="text-[11px] text-slate-400 mt-1">Resin: {{ currentTurbine().bladeMaterials.resinSystem }}</div>
                <div class="text-[11px] text-slate-400">Core: {{ currentTurbine().bladeMaterials.coreMaterial }}</div>
              </div>

              <div class="bg-[#101820]/70 p-3 rounded-xl border border-[#3B596D]/30">
                <div class="text-[11px] font-mono text-slate-400 mb-1">FOUNDATION TYPE</div>
                <div class="text-sm font-semibold text-[#58B7C8] uppercase font-mono">{{ currentTurbine().foundationType }}</div>
                <div class="text-[11px] text-slate-400 mt-1">Tower Wall: {{ currentTurbine().towerGeometry.wallThicknessMm }} mm</div>
                <div class="text-[11px] text-slate-400">Sections: {{ currentTurbine().towerGeometry.sectionsCount }} Bolted Cans</div>
              </div>
            </div>

            <!-- Blade Deflection & Tip Clearance -->
            <div class="space-y-1.5 bg-[#101820]/40 p-3 rounded-xl border border-[#3B596D]/20">
              <div class="flex justify-between text-xs font-mono">
                <span class="text-slate-400">Aero Flapwise Tip Deflection:</span>
                <span class="text-[#E7AA49] font-bold tabular-nums">{{ tipDeflectionMeters() }} m</span>
              </div>
              <div class="w-full bg-[#172735] h-2 rounded-full overflow-hidden">
                <div
                  class="bg-[#E7AA49] h-full rounded-full transition-all duration-300"
                  [style.width.%]="(tipDeflectionMeters() / 12.0) * 100"
                ></div>
              </div>
              <div class="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0 m (Resting)</span>
                <span>Max Allowable Tip Clearance: 12.0 m</span>
              </div>
            </div>

            <!-- Rainflow Fatigue Damage Calculation -->
            <div class="bg-[#101820]/40 p-3 rounded-xl border border-[#3B596D]/20 space-y-2">
              <div class="text-xs font-semibold text-white">Rainflow Cycle Counting & Miner's Cumulative Rule</div>
              <div class="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                <div class="bg-[#172735] p-2 rounded">
                  <div class="text-slate-400 text-[10px]">CUMULATIVE DAMAGE (D)</div>
                  <div class="text-[#58B7C8] font-bold tabular-nums">0.248</div>
                  <div class="text-slate-500 text-[9px]">Limit: 1.000</div>
                </div>
                <div class="bg-[#172735] p-2 rounded">
                  <div class="text-slate-400 text-[10px]">BASQUIN EXPONENT</div>
                  <div class="text-white font-bold tabular-nums">m = 10.0</div>
                  <div class="text-slate-500 text-[9px]">Carbon Spar</div>
                </div>
                <div class="bg-[#172735] p-2 rounded">
                  <div class="text-slate-400 text-[10px]">EST. FATIGUE LIFE</div>
                  <div class="text-[#5DAA88] font-bold tabular-nums">34.2 yrs</div>
                  <div class="text-slate-500 text-[9px]">Design: 30 yrs</div>
                </div>
              </div>
            </div>

            <!-- Environmental Accounting -->
            <div class="flex items-center justify-between text-xs font-mono bg-[#101820]/60 p-2.5 rounded-lg border border-[#3B596D]/20">
              <span class="text-slate-400">Embodied Carbon & Circularity:</span>
              <span class="text-[#5DAA88] font-bold">{{ currentTurbine().environmentalAccounting.embodiedCarbonTonnesCO2 }} t CO2e ({{ currentTurbine().environmentalAccounting.recyclabilityPercent }}% Recyclable)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class EngineeringWorkspace {
  protected readonly state = inject(TurbineState);

  currentTurbine(): TurbineConfig {
    return this.state.selectedTurbine();
  }

  rotorSweptAreaKm2(): string {
    const r = this.currentTurbine().rotorDiameterM / 2;
    const a = (Math.PI * r * r) / 1e6;
    return a.toFixed(3);
  }

  tipDeflectionMeters(): number {
    // Scales with thrust force
    const thrust = this.state.currentAerodynamics().rotorThrustKN;
    const maxThrust = 2200;
    const def = (thrust / maxThrust) * 7.8;
    return parseFloat(Math.max(0.4, def).toFixed(2));
  }

  powerCurvePointsSvg(): string {
    const curves = this.state.powerCurves();
    const rated = this.currentTurbine().ratedPowerMW;
    // Map: windSpeed [0..30] -> X [0..300], powerMW [0..rated] -> Y [90..10]
    return curves
      .map((pt) => {
        const x = pt.windSpeed * 10;
        const y = 90 - (pt.powerMW / rated) * 80;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }

  onTurbineChange(e: Event) {
    const id = (e.target as HTMLSelectElement).value;
    const found = this.state.allTurbines.find((t) => t.id === id);
    if (found) {
      this.state.selectTurbine(found);
    }
  }
}
