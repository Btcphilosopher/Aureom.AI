import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-lifecycle-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-5 text-[#EAF1F4]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3B596D]/30 pb-4">
        <div>
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Asset Health, NDT Inspection & Economics</div>
          <h2 class="text-xl font-bold text-white tracking-tight">Predictive Maintenance, Drone NDT & LCOE Lifecycle</h2>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-xs font-mono bg-[#172735] px-3 py-1.5 rounded-lg border border-[#3B596D]/40">
            <span class="text-slate-400">OPERATING HOURS:</span>
            <span class="text-white font-bold ml-1">24,500 hrs (Year 3.2 of 30)</span>
          </div>
        </div>
      </div>

      <!-- Financial & Degradation KPI Ribbon -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">LCOE (GBP)</div>
          <div class="text-lg font-bold font-mono text-[#58B7C8] tabular-nums">&pound;{{ state.projectEconomics().lcoeGbpPerMWh }} / MWh</div>
          <div class="text-[10px] text-slate-400">&euro;{{ state.projectEconomics().lcoeEurPerMWh }} · &#36;{{ state.projectEconomics().lcoeUsdPerMWh }}</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">PROJECT CAPEX</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">&pound;{{ state.projectEconomics().totalCapexMGBP }}M</div>
          <div class="text-[10px] text-slate-400">50 Turbines (750 MW Farm)</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">NET PRESENT VALUE</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">&pound;{{ state.projectEconomics().npvMGBP }}M</div>
          <div class="text-[10px] text-slate-400">Discount Rate: 6.5%</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">INTERNAL RATE OF RETURN</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">{{ state.projectEconomics().irrPercent }}% IRR</div>
          <div class="text-[10px] text-slate-400">Payback: {{ state.projectEconomics().paybackPeriodYears }} Years</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">BLADE CIRCULARITY</div>
          <div class="text-lg font-bold font-mono text-[#58B7C8] tabular-nums">{{ state.selectedTurbine().environmentalAccounting.recyclabilityPercent }}%</div>
          <div class="text-[10px] text-slate-400">Pyrolysis & Cement Co-Proc</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">CRITICAL DEFECTS</div>
          <div class="text-base font-bold font-mono text-[#D95A57]">1 Scheduled</div>
          <div class="text-[10px] text-slate-400">Blade 2 Delamination (42m)</div>
        </div>
      </div>

      <!-- Main Columns: Reliability Weibull/FFT & Aardvark Drone Inspection -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <!-- Column 1: Predictive Maintenance & Weibull RUL -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">01. Reliability & Vibration Harmonics</h3>
            <span class="text-xs font-mono text-[#5DAA88]">ISO 10816 Zone A/B</span>
          </div>

          <div class="space-y-3">
            @for (comp of state.reliabilityComponents(); track comp.name) {
              <div class="bg-[#101820]/70 border border-[#3B596D]/30 rounded-xl p-3 hover:border-[#58B7C8]/50 transition-colors">
                <div class="flex items-center justify-between mb-1">
                  <span class="text-xs font-semibold text-white">{{ comp.name }}</span>
                  <span
                    [class.text-[#5DAA88]]="comp.healthState === 'Optimal'"
                    [class.text-[#E7AA49]]="comp.healthState === 'Advisory'"
                    [class.text-[#D95A57]]="comp.healthState === 'Urgent'"
                    class="text-[11px] font-mono font-bold uppercase"
                  >
                    {{ comp.healthState }}
                  </span>
                </div>

                <div class="text-[11px] font-mono text-slate-400 mb-2">
                  <span>Weibull &beta;={{ comp.weibullBeta }} &eta;={{ comp.weibullEtaHours / 1000 }}kh</span>
                  <span class="mx-1">·</span>
                  <span>Survival Prob: {{ (comp.survivalProbability * 100).toFixed(1) }}%</span>
                  <span class="mx-1">·</span>
                  <span class="text-slate-300">Temp: {{ comp.temperatureC }}°C</span>
                </div>

                <div class="flex items-center justify-between text-[11px] font-mono border-t border-[#3B596D]/20 pt-2 text-slate-300">
                  <span>Vibration: {{ comp.vibrationRmsMmS }} mm/s RMS</span>
                  <span>Dominant: {{ comp.dominantHarmonicHz }} Hz</span>
                  <span class="text-[#58B7C8] font-bold">EST. RUL: {{ comp.estimatedRulMonths }} Mo</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Column 2: Aardvark Autonomous Drone NDT Blade Defects -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">02. Aardvark Autonomous Drone Inspection Log</h3>
            <span class="text-xs font-mono text-[#58B7C8]">Optical + LiDAR NDT</span>
          </div>

          <!-- Active Defect Inspector Card -->
          @if (state.selectedDefect()) {
            <div class="bg-[#101820]/90 border border-[#58B7C8]/40 rounded-xl p-3.5 space-y-2">
              <div class="flex items-center justify-between">
                <span class="text-xs font-mono text-[#58B7C8] uppercase font-bold">INSPECTION DOSSIER</span>
                <span class="text-xs font-mono text-slate-400">Ref: {{ state.selectedDefect()?.id }}</span>
              </div>
              <div class="text-sm font-bold text-white">{{ state.selectedDefect()?.defectType }}</div>
              <div class="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300">
                <div>Blade: Blade {{ state.selectedDefect()?.bladeIndex }} (Span {{ state.selectedDefect()?.spanPercent }}%)</div>
                <div>Location: {{ state.selectedDefect()?.locationMetersFromRoot }}m from root</div>
                <div>Surface: {{ state.selectedDefect()?.surface }}</div>
                <div>Ultrasonic Depth: {{ state.selectedDefect()?.ultrasonicDepthMm }} mm</div>
                <div>Sensor: {{ state.selectedDefect()?.detectedBy }}</div>
                <div class="text-[#5DAA88]">Confidence: {{ state.selectedDefect()?.confidencePercent }}%</div>
              </div>
              <div class="pt-2 border-t border-[#3B596D]/30 flex items-center justify-between text-xs font-mono">
                <span class="text-slate-400">Action Plan:</span>
                <span class="text-[#E7AA49] font-semibold">{{ state.selectedDefect()?.status }}</span>
              </div>
            </div>
          }

          <!-- Defect List -->
          <div class="space-y-2">
            <div class="text-xs font-semibold text-white">All Detected Blade Anomalies</div>
            @for (def of state.bladeDefects; track def.id) {
              <button
                type="button"
                (click)="state.selectDefect(def)"
                [class.border-[#58B7C8]]="state.selectedDefect()?.id === def.id"
                [class.bg-[#101820]/90]="state.selectedDefect()?.id === def.id"
                class="w-full text-left bg-[#101820]/50 border border-[#3B596D]/30 rounded-xl p-2.5 cursor-pointer hover:border-[#58B7C8]/50 transition-colors"
              >
                <div class="flex items-center justify-between text-xs">
                  <span class="font-semibold text-white">Blade {{ def.bladeIndex }}: {{ def.defectType }}</span>
                  <span
                    [class.text-[#D95A57]]="def.severityScore === 'Critical'"
                    [class.text-[#E7AA49]]="def.severityScore === 'Moderate'"
                    [class.text-[#58B7C8]]="def.severityScore === 'Minor'"
                    class="font-mono font-bold text-[11px]"
                  >
                    {{ def.severityScore }}
                  </span>
                </div>
                <div class="flex justify-between text-[11px] font-mono text-slate-400 mt-1">
                  <span>{{ def.locationMetersFromRoot }}m · {{ def.surface }}</span>
                  <span class="text-[#5DAA88]">{{ def.status }}</span>
                </div>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class LifecycleWorkspace {
  protected readonly state = inject(TurbineState);
}
