import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {TurbineState} from '../../services/turbine-state';

@Component({
  selector: 'app-field-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-5 text-[#EAF1F4]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3B596D]/30 pb-4">
        <div>
          <div class="text-xs font-mono text-[#58B7C8] uppercase tracking-wider">Wind Farm Operations & SCADA Telemetry</div>
          <h2 class="text-xl font-bold text-white tracking-tight">FLORIS Wake Deficit & Grid Integration Twin</h2>
        </div>
        <div class="flex items-center gap-2">
          <!-- Wind Speed Quick Adjustment -->
          <span class="text-xs font-mono text-slate-400">FREE-STREAM:</span>
          <input
            type="range"
            min="3"
            max="25"
            step="0.5"
            [value]="state.simulatedWindSpeed()"
            (input)="onWindSlider($event)"
            class="w-28 accent-[#58B7C8] cursor-pointer h-1.5 bg-[#172735] rounded-lg"
          />
          <span class="text-xs font-mono text-white tabular-nums w-14 font-semibold">{{ state.simulatedWindSpeed() }} m/s</span>
        </div>
      </div>

      <!-- Wind Farm Key Operational KPIs -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">NET FARM POWER</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">{{ state.windFarmState().netPowerMW }} MW</div>
          <div class="text-[10px] text-slate-400">Gross: {{ state.windFarmState().grossPowerMW }} MW</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">WAKE LOSS DEFICIT</div>
          <div class="text-lg font-bold font-mono text-[#E7AA49] tabular-nums">{{ state.windFarmState().overallWakeLossPercent }}%</div>
          <div class="text-[10px] text-slate-400">FLORIS Jensen Model</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">CAPACITY FACTOR</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">{{ state.windFarmState().capacityFactorPercent }}%</div>
          <div class="text-[10px] text-slate-400">Dogger Bank Outer Array</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">ESTIMATED AEP</div>
          <div class="text-lg font-bold font-mono text-[#58B7C8] tabular-nums">{{ state.windFarmState().annualEnergyProductionGWh }} GWh</div>
          <div class="text-[10px] text-slate-400">Annual Energy Production</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">GRID EXPORT</div>
          <div class="text-lg font-bold font-mono text-white tabular-nums">220 kV HVAC</div>
          <div class="text-[10px] text-slate-400">Frequency: 50.02 Hz</div>
        </div>

        <div class="bg-[#172735]/80 border border-[#3B596D]/40 p-3 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400">YAW STEERING GAIN</div>
          <div class="text-lg font-bold font-mono text-[#5DAA88] tabular-nums">+2.4% AEP</div>
          <div class="text-[10px] text-slate-400">Wake Deflection Active</div>
        </div>
      </div>

      <!-- Main Columns: FLORIS Wake Deficit Table & SCADA Telemetry Stream -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <!-- Column 1 & 2: FLORIS Wake Table with Yaw Steering -->
        <div class="lg:col-span-2 bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <div>
              <h3 class="text-sm font-semibold text-white tracking-wide">01. FLORIS Wake Interactions & Yaw Steering</h3>
              <p class="text-[11px] text-slate-400">Deflect upstream wake cones using intentional yaw offsets to boost downwind turbine power.</p>
            </div>
            <span class="text-xs font-mono text-[#58B7C8]">8 Turbines Online</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-[#101820] text-slate-400 border-b border-[#3B596D]/30">
                <tr>
                  <th class="py-2.5 px-3">TURBINE</th>
                  <th class="py-2.5 px-3">EFFECTIVE V</th>
                  <th class="py-2.5 px-3">POWER (MW)</th>
                  <th class="py-2.5 px-3">WAKE LOSS</th>
                  <th class="py-2.5 px-3">YAW OFFSET (STEERING)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#3B596D]/20 text-slate-200">
                @for (turb of state.windFarmState().turbines; track turb.id) {
                  <tr class="hover:bg-[#101820]/40 transition-colors">
                    <td class="py-2.5 px-3 font-semibold text-white">{{ turb.name }}</td>
                    <td class="py-2.5 px-3 tabular-nums">{{ turb.effectiveWindSpeedMs.toFixed(1) }} m/s</td>
                    <td class="py-2.5 px-3 font-bold text-[#5DAA88] tabular-nums">{{ turb.activePowerMW.toFixed(2) }} MW</td>
                    <td class="py-2.5 px-3 tabular-nums" [class.text-[#E7AA49]]="turb.wakeLossPercent > 10">
                      {{ turb.wakeLossPercent.toFixed(1) }}%
                    </td>
                    <td class="py-2.5 px-3">
                      <div class="flex items-center gap-2">
                        <input
                          type="range"
                          min="-20"
                          max="20"
                          step="1"
                          [value]="turb.yawOffsetDeg"
                          (input)="onYawSlider(turb.id, $event)"
                          class="w-24 accent-[#58B7C8] cursor-pointer h-1.5 bg-[#101820] rounded-lg"
                        />
                        <span class="text-[11px] tabular-nums text-slate-300 w-10">{{ turb.yawOffsetDeg > 0 ? '+' : '' }}{{ turb.yawOffsetDeg }}°</span>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Column 3: SCADA Real-Time Telemetry Gauges -->
        <div class="bg-[#172735]/90 border border-[#3B596D]/50 rounded-2xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[#3B596D]/30 pb-2">
            <h3 class="text-sm font-semibold text-white tracking-wide">02. Lead Turbine SCADA Stream</h3>
            <span class="text-xs font-mono text-[#58B7C8]">{{ state.selectedTurbine().serialNumber }}</span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            <div class="bg-[#101820]/60 p-3 rounded-xl border border-[#3B596D]/20 space-y-1">
              <div class="flex justify-between text-slate-400">
                <span>Rotor Speed (RPM):</span>
                <span class="text-white font-bold tabular-nums">{{ state.currentAerodynamics().rotorRpm.toFixed(2) }} RPM</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Blade Pitch Angle:</span>
                <span class="text-[#58B7C8] font-bold tabular-nums">{{ state.currentAerodynamics().bladePitchDeg.toFixed(1) }}°</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Generator Active Power:</span>
                <span class="text-[#5DAA88] font-bold tabular-nums">{{ state.currentAerodynamics().electricalPowerMW.toFixed(2) }} MW</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Rotor Thrust Force:</span>
                <span class="text-[#E7AA49] font-bold tabular-nums">{{ state.currentAerodynamics().rotorThrustKN.toFixed(0) }} kN</span>
              </div>
            </div>

            <div class="bg-[#101820]/60 p-3 rounded-xl border border-[#3B596D]/20 space-y-1">
              <div class="text-xs font-semibold text-white mb-1.5">Critical Subsystem Thermals</div>
              <div class="flex justify-between text-slate-400">
                <span>Main Shaft Bearing:</span>
                <span class="text-white tabular-nums">48.2°C (OK)</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>PMSG Winding Phase A:</span>
                <span class="text-white tabular-nums">72.4°C (Limit: 120°C)</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>66kV Inverter Heat Sink:</span>
                <span class="text-white tabular-nums">61.5°C (Cooling ON)</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Tower Top Vibration:</span>
                <span class="text-[#5DAA88] font-semibold tabular-nums">0.82 mm/s RMS</span>
              </div>
            </div>

            <div class="bg-[#101820]/60 p-3 rounded-xl border border-[#3B596D]/20 space-y-1">
              <div class="text-xs font-semibold text-white mb-1.5">Grid Compliance (UK National Grid SQSS)</div>
              <div class="flex justify-between text-slate-400">
                <span>Voltage at Offshore TP:</span>
                <span class="text-white tabular-nums">66.1 kV (&plusmn;0.2%)</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Power Factor (cos &phi;):</span>
                <span class="text-[#5DAA88] font-bold tabular-nums">0.995 Leading</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Reactive Power Capability:</span>
                <span class="text-white tabular-nums">&plusmn;4.8 MVAR</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class FieldWorkspace {
  protected readonly state = inject(TurbineState);

  onWindSlider(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.setWindSpeed(val);
  }

  onYawSlider(turbineId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.setTurbineYawOffset(turbineId, val);
  }
}
