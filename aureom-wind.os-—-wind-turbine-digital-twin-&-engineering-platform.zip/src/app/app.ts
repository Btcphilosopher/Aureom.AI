import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {HeaderComponent} from './components/header/header';
import {Viewport3d} from './components/viewport3d/viewport3d';
import {EngineeringWorkspace} from './components/workspaces/engineering-workspace';
import {FactoryWorkspace} from './components/workspaces/factory-workspace';
import {LogisticsWorkspace} from './components/workspaces/logistics-workspace';
import {FieldWorkspace} from './components/workspaces/field-workspace';
import {LifecycleWorkspace} from './components/workspaces/lifecycle-workspace';
import {AuditModalComponent} from './components/modals/audit-modal';
import {DigitalThreadDrawerComponent} from './components/modals/digital-thread-drawer';
import {TurbineState} from './services/turbine-state';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    HeaderComponent,
    Viewport3d,
    EngineeringWorkspace,
    FactoryWorkspace,
    LogisticsWorkspace,
    FieldWorkspace,
    LifecycleWorkspace,
    AuditModalComponent,
    DigitalThreadDrawerComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly state = inject(TurbineState);

  // Layout mode: 'split' (3D + Engineering Panel side-by-side) or 'full3d' (Full 3D immersion)
  public readonly layoutMode = signal<'split' | 'full3d'>('split');

  toggleLayoutMode() {
    this.layoutMode.update((mode) => (mode === 'split' ? 'full3d' : 'split'));
  }
}
