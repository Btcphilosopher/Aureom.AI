import {Injectable, computed, inject, signal} from '@angular/core';
import {
  BladeDefect,
  CureKineticsState,
  FactoryStation,
  FlorisTurbineLocation,
  LogisticsStep,
  MaterialBatch,
  ProjectEconomics,
  ReliabilityComponent,
  SceneMode,
  TurbineConfig,
  WindFarmState,
  WorkspaceMode,
} from '../models/turbine.models';
import {AssetDatabase} from './asset-database';
import {PhysicsEngine} from './physics-engine';

@Injectable({
  providedIn: 'root',
})
export class TurbineState {
  private readonly db = inject(AssetDatabase);
  private readonly physics = inject(PhysicsEngine);

  // Active Workspace: FACTORY, ENGINEERING, LOGISTICS, FIELD, LIFECYCLE
  public readonly activeWorkspace = signal<WorkspaceMode>('ENGINEERING');

  // Active 3D Scene View
  public readonly activeScene = signal<SceneMode>('engineering');

  // Selected Turbine Asset
  public readonly selectedTurbine = signal<TurbineConfig>(this.db.turbines[0]);

  // Operational Simulation Inputs
  public readonly simulatedWindSpeed = signal<number>(11.2); // m/s
  public readonly simulatedWindDirection = signal<number>(270); // degrees (westerly)
  public readonly simulatedYawOffset = signal<number>(0); // degrees
  public readonly explodedProgress = signal<number>(0); // 0% (assembled) to 100% (fully exploded)
  public readonly showStressOverlay = signal<boolean>(false);
  public readonly showStreamlines = signal<boolean>(true);
  public readonly showWakeCones = signal<boolean>(true);

  // Cure Kinetics elapsed simulation time in minutes
  public readonly cureElapsedMinutes = signal<number>(95);
  public readonly cureMoldTargetTempC = signal<number>(75);

  // Selected defect on 3D blade
  public readonly selectedDefect = signal<BladeDefect | null>(this.db.bladeDefects[0]);

  // Modals & Drawers
  public readonly auditModalOpen = signal<boolean>(false);
  public readonly digitalThreadDrawerOpen = signal<boolean>(false);
  public readonly bottomDockCollapsed = signal<boolean>(false);

  // Farm Turbines Array
  public readonly windFarmTurbines = signal<FlorisTurbineLocation[]>(this.db.windFarmTurbines);

  // Factory Stations
  public readonly factoryStations = signal<FactoryStation[]>(this.db.factoryStations);

  // Material Batches
  public readonly materialBatches = signal<MaterialBatch[]>(this.db.materialBatches);

  // Logistics steps
  public readonly logisticsSteps = signal<LogisticsStep[]>(this.db.logisticsSteps);

  // Reliability components
  public readonly reliabilityComponents = signal<ReliabilityComponent[]>(this.db.reliabilityComponents);

  // -------------------------------------------------------------
  // COMPUTED SIGNALS
  // -------------------------------------------------------------

  // Real-time aerodynamic state calculated via BEM
  public readonly currentAerodynamics = computed(() => {
    return this.physics.simulateAerodynamics(this.selectedTurbine(), this.simulatedWindSpeed());
  });

  // Power curves across entire speed range
  public readonly powerCurves = computed(() => {
    return this.physics.generatePowerCurves(this.selectedTurbine());
  });

  // Wind Farm FLORIS state
  public readonly windFarmState = computed<WindFarmState>(() => {
    return this.physics.simulateWindFarmWakes(
      this.selectedTurbine(),
      this.windFarmTurbines(),
      this.simulatedWindSpeed(),
      this.simulatedWindDirection()
    );
  });

  // Cure kinetics state
  public readonly cureState = computed<CureKineticsState>(() => {
    return this.physics.calculateCureKinetics(this.cureElapsedMinutes(), this.cureMoldTargetTempC());
  });

  // Project economics for 50-turbine wind farm
  public readonly projectEconomics = computed<ProjectEconomics>(() => {
    return this.physics.calculateLCOE(this.selectedTurbine(), 50);
  });

  // All turbines available
  public readonly allTurbines = this.db.turbines;

  // All blade defects
  public readonly bladeDefects = this.db.bladeDefects;

  // -------------------------------------------------------------
  // ACTIONS
  // -------------------------------------------------------------

  setWorkspace(workspace: WorkspaceMode) {
    this.activeWorkspace.set(workspace);
    // Align 3D scene with chosen workspace
    switch (workspace) {
      case 'FACTORY':
        this.activeScene.set('factory');
        break;
      case 'ENGINEERING':
        this.activeScene.set('engineering');
        break;
      case 'LOGISTICS':
        this.activeScene.set('offshore');
        break;
      case 'FIELD':
        this.activeScene.set('windfarm');
        break;
      case 'LIFECYCLE':
        this.activeScene.set('inspection');
        break;
    }
  }

  setScene(scene: SceneMode) {
    this.activeScene.set(scene);
  }

  selectTurbine(turbine: TurbineConfig) {
    this.selectedTurbine.set(turbine);
  }

  setWindSpeed(speed: number) {
    this.simulatedWindSpeed.set(Math.max(0, Math.min(35, speed)));
  }

  setExplodedProgress(progress: number) {
    this.explodedProgress.set(Math.max(0, Math.min(100, progress)));
  }

  toggleStressOverlay() {
    this.showStressOverlay.update((v) => !v);
  }

  toggleStreamlines() {
    this.showStreamlines.update((v) => !v);
  }

  toggleWakeCones() {
    this.showWakeCones.update((v) => !v);
  }

  toggleBottomDock() {
    this.bottomDockCollapsed.update((v) => !v);
  }

  setTurbineYawOffset(turbineId: string, yawOffset: number) {
    this.windFarmTurbines.update((list) =>
      list.map((t) => (t.id === turbineId ? {...t, yawOffsetDeg: yawOffset} : t))
    );
  }

  setCureElapsed(minutes: number) {
    this.cureElapsedMinutes.set(Math.max(0, Math.min(240, minutes)));
  }

  selectDefect(defect: BladeDefect | null) {
    this.selectedDefect.set(defect);
  }

  openAuditModal() {
    this.auditModalOpen.set(true);
  }

  closeAuditModal() {
    this.auditModalOpen.set(false);
  }

  toggleDigitalThreadDrawer() {
    this.digitalThreadDrawerOpen.update((v) => !v);
  }
}
