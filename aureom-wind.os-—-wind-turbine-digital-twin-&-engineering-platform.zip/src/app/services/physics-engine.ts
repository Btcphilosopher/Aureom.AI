import {Injectable} from '@angular/core';
import {
  AerodynamicCurvePoint,
  AerodynamicSimulationResult,
  CureKineticsState,
  FlorisTurbineLocation,
  ProjectEconomics,
  ReliabilityComponent,
  TurbineConfig,
  WindFarmState,
} from '../models/turbine.models';

@Injectable({
  providedIn: 'root',
})
export class PhysicsEngine {
  // Standard air density at sea level (15°C, 1013.25 hPa)
  public readonly AIR_DENSITY_RHO = 1.225; // kg/m³
  public readonly BETZ_LIMIT = 16 / 27; // ~0.5926

  /**
   * Calculate rotor swept area A = pi * R^2
   */
  calculateRotorSweptArea(rotorDiameterM: number): number {
    const radius = rotorDiameterM / 2;
    return Math.PI * radius * radius;
  }

  /**
   * Aerodynamic power coefficient Cp(lambda, theta) based on empirical BEM formulation
   * where lambda is Tip-Speed Ratio (TSR) and theta is blade pitch angle in degrees.
   */
  calculateCp(lambda: number, pitchDeg: number): number {
    if (lambda <= 0.1) return 0;
    const c1 = 0.5176;
    const c2 = 116.0;
    const c3 = 0.4;
    const c4 = 5.0;
    const c5 = 21.0;
    const c6 = 0.0068;

    // Inverse characteristic lambda_i
    const denom = 1 / (lambda + 0.08 * pitchDeg) - 0.035 / (Math.pow(pitchDeg, 3) + 1);
    if (denom <= 0) return 0;
    const lambda_i = 1 / denom;

    const cp = c1 * (c2 / lambda_i - c3 * pitchDeg - c4) * Math.exp(-c5 / lambda_i) + c6 * lambda;
    // Bound within physical limits (cannot exceed Betz limit)
    return Math.max(0, Math.min(this.BETZ_LIMIT * 0.88, cp));
  }

  /**
   * Rotor thrust coefficient Ct(lambda, theta) with Glauert correction for high induction
   */
  calculateCt(lambda: number, pitchDeg: number): number {
    if (lambda <= 0.5) return 0.05;
    // Approximate induction factor from lambda and pitch
    const a = Math.min(0.85, 0.35 / (1 + 0.05 * pitchDeg) * Math.min(1.2, lambda / 7.5));
    if (a <= 0.38) {
      return 4 * a * (1 - a);
    } else {
      // Glauert empirical correction for turbulent wake state
      const a_c = 0.2;
      return 4 * (a_c * (1 - a_c) + (a - a_c));
    }
  }

  /**
   * Full aerodynamic simulation at a specific instantaneous wind speed
   */
  simulateAerodynamics(config: TurbineConfig, windSpeedMs: number): AerodynamicSimulationResult {
    const area = this.calculateRotorSweptArea(config.rotorDiameterM);
    const radius = config.rotorDiameterM / 2;
    const ratedPowerW = config.ratedPowerMW * 1e6;

    let operatingRegion: AerodynamicSimulationResult['operatingRegion'] = 'Region 1 (Sub-Cut-In)';
    let rotorRpm = 0;
    let bladePitchDeg = 90; // Feathered when stopped
    let tipSpeedRatio = 0;
    let powerCoefficientCp = 0;
    let thrustCoefficientCt = 0;
    let aerodynamicPowerW = 0;
    let electricalPowerW = 0;
    let rotorThrustN = 0;
    let torqueNm = 0;

    const drivetrainEff = config.architecture === 'direct-drive' ? 0.982 : 0.962;
    const generatorEff = 0.975;
    const converterEff = 0.985;
    const totalMechElecEff = drivetrainEff * generatorEff * converterEff;

    if (windSpeedMs < config.cutInSpeedMs) {
      operatingRegion = 'Region 1 (Sub-Cut-In)';
      rotorRpm = 0.5; // Idle freewheeling
      bladePitchDeg = 82;
      tipSpeedRatio = (rotorRpm * 2 * Math.PI / 60 * radius) / Math.max(0.1, windSpeedMs);
      powerCoefficientCp = 0;
      thrustCoefficientCt = 0.05;
    } else if (windSpeedMs >= config.cutInSpeedMs && windSpeedMs < config.ratedSpeedMs) {
      operatingRegion = 'Region 2 (MPPT Optimal)';
      bladePitchDeg = 0; // Peak aerodynamic angle
      const optimalTsr = 8.4;
      tipSpeedRatio = optimalTsr;

      // Rotor speed scales proportionally to track optimal TSR up to rated RPM
      const targetOmega = (optimalTsr * windSpeedMs) / radius;
      const targetRpm = (targetOmega * 60) / (2 * Math.PI);
      rotorRpm = Math.max(config.minRotorRpm, Math.min(config.maxRotorRpm, targetRpm));
      tipSpeedRatio = (rotorRpm * 2 * Math.PI / 60 * radius) / windSpeedMs;

      powerCoefficientCp = this.calculateCp(tipSpeedRatio, bladePitchDeg);
      thrustCoefficientCt = this.calculateCt(tipSpeedRatio, bladePitchDeg);

      // P = 0.5 * rho * A * V^3 * Cp
      aerodynamicPowerW = 0.5 * this.AIR_DENSITY_RHO * area * Math.pow(windSpeedMs, 3) * powerCoefficientCp;
      electricalPowerW = aerodynamicPowerW * totalMechElecEff;

      // Cap at rated if reached near boundary
      if (electricalPowerW > ratedPowerW) {
        electricalPowerW = ratedPowerW;
        operatingRegion = 'Region 2.5 (Transition)';
      }
    } else if (windSpeedMs >= config.ratedSpeedMs && windSpeedMs <= config.cutOutSpeedMs) {
      operatingRegion = 'Region 3 (Rated Pitch Regulated)';
      rotorRpm = config.maxRotorRpm;
      tipSpeedRatio = (rotorRpm * 2 * Math.PI / 60 * radius) / windSpeedMs;

      // Closed-loop pitch regulation to maintain exactly rated electrical power
      const requiredAeroPowerW = ratedPowerW / totalMechElecEff;
      const availablePwind = 0.5 * this.AIR_DENSITY_RHO * area * Math.pow(windSpeedMs, 3);
      const targetCp = Math.min(0.48, requiredAeroPowerW / availablePwind);

      // Iteratively find pitch angle to match target Cp
      let pitch = 0;
      for (let p = 0.5; p <= 35; p += 0.25) {
        if (this.calculateCp(tipSpeedRatio, p) <= targetCp) {
          pitch = p;
          break;
        }
      }
      bladePitchDeg = pitch;
      powerCoefficientCp = targetCp;
      thrustCoefficientCt = this.calculateCt(tipSpeedRatio, bladePitchDeg);

      aerodynamicPowerW = requiredAeroPowerW;
      electricalPowerW = ratedPowerW;
    } else {
      operatingRegion = 'Region 4 (Cut-Out)';
      rotorRpm = 0;
      bladePitchDeg = 90; // Full aerodynamic brake feather
      powerCoefficientCp = 0;
      thrustCoefficientCt = 0.08;
      aerodynamicPowerW = 0;
      electricalPowerW = 0;
    }

    // Thrust calculation: T = 0.5 * rho * A * V^2 * Ct
    rotorThrustN = 0.5 * this.AIR_DENSITY_RHO * area * Math.pow(windSpeedMs, 2) * thrustCoefficientCt;

    // Aerodynamic torque: Q = P / Omega
    const omega = (rotorRpm * 2 * Math.PI) / 60;
    torqueNm = omega > 0.01 ? aerodynamicPowerW / omega : 0;

    return {
      windSpeedMs,
      rotorRpm,
      tipSpeedRatio,
      powerCoefficientCp,
      thrustCoefficientCt,
      bladePitchDeg,
      aerodynamicPowerMW: aerodynamicPowerW / 1e6,
      electricalPowerMW: electricalPowerW / 1e6,
      rotorThrustKN: rotorThrustN / 1e3,
      aerodynamicTorqueKNm: torqueNm / 1e3,
      generatorEfficiency: totalMechElecEff,
      operatingRegion,
    };
  }

  /**
   * Generate complete power curve, thrust curve, Cp-TSR from 0 to 30 m/s
   */
  generatePowerCurves(config: TurbineConfig): AerodynamicCurvePoint[] {
    const points: AerodynamicCurvePoint[] = [];
    for (let v = 0; v <= 30; v += 0.5) {
      const res = this.simulateAerodynamics(config, v);
      points.push({
        windSpeed: v,
        powerMW: parseFloat(res.electricalPowerMW.toFixed(3)),
        thrustKN: parseFloat(res.rotorThrustKN.toFixed(1)),
        cp: parseFloat(res.powerCoefficientCp.toFixed(4)),
        pitchDeg: parseFloat(res.bladePitchDeg.toFixed(2)),
        rpm: parseFloat(res.rotorRpm.toFixed(2)),
      });
    }
    return points;
  }

  /**
   * FLORIS Reduced-Order Wind Farm Wake Engine
   * Uses Jensen/Park wake expansion with Gaussian deficit and yaw steering deflection
   */
  simulateWindFarmWakes(
    baseConfig: TurbineConfig,
    turbines: FlorisTurbineLocation[],
    ambientWindSpeedMs: number,
    ambientWindDirDeg: number
  ): WindFarmState {
    const D0 = baseConfig.rotorDiameterM;
    const k_wake = 0.045; // Offshore wake expansion parameter

    // Convert wind direction to unit direction vector
    const windRad = (ambientWindDirDeg * Math.PI) / 180;
    const uX = Math.cos(windRad);
    const uY = Math.sin(windRad);

    const updatedTurbines: FlorisTurbineLocation[] = [];
    let grossPowerSum = 0;
    let netPowerSum = 0;

    for (let i = 0; i < turbines.length; i++) {
      const ti = turbines[i];
      let velocityDeficitSquaredSum = 0;

      // Check wakes caused by all other turbines upstream of turbine i
      for (let j = 0; j < turbines.length; j++) {
        if (i === j) continue;
        const tj = turbines[j];

        // Coordinate transformation relative to wind vector
        const dx = ti.xM - tj.xM;
        const dy = ti.yM - tj.yM;

        // Downwind distance along wind direction
        const downwindDist = dx * uX + dy * uY;

        // Only upstream turbines produce wake on downstream ones
        if (downwindDist > 10) {
          // Crosswind distance perpendicular to wind direction
          const crosswindDist = Math.abs(-dx * uY + dy * uX);

          // Yaw steering wake deflection: delta = 0.5 * yawOffset * Ct * x / D0
          const ct = 0.78;
          const yawRad = (tj.yawOffsetDeg * Math.PI) / 180;
          const wakeCenterlineDeflection = 0.35 * Math.sin(yawRad) * downwindDist / (1 + 2 * k_wake * downwindDist / D0);

          const effectiveCrosswindDist = Math.abs(crosswindDist - wakeCenterlineDeflection);

          // Wake diameter at distance x
          const Dw = D0 + 2 * k_wake * downwindDist;
          const sigmaWake = Dw / 3.0; // Gaussian wake spread

          if (effectiveCrosswindDist < Dw / 2 + D0 / 2) {
            // Gaussian velocity deficit peak
            const cDeficit = (1 - Math.sqrt(Math.max(0, 1 - ct))) / Math.pow(1 + 2 * k_wake * downwindDist / D0, 2);
            const deficit = cDeficit * Math.exp(-Math.pow(effectiveCrosswindDist, 2) / (2 * Math.pow(sigmaWake, 2)));
            velocityDeficitSquaredSum += Math.pow(deficit, 2);
          }
        }
      }

      // Root-sum-squared velocity deficit superposition
      const totalDeficit = Math.min(0.65, Math.sqrt(velocityDeficitSquaredSum));
      const effectiveSpeed = Math.max(1.0, ambientWindSpeedMs * (1 - totalDeficit));

      const aero = this.simulateAerodynamics(baseConfig, effectiveSpeed);
      const grossAero = this.simulateAerodynamics(baseConfig, ambientWindSpeedMs);

      const netPower = aero.electricalPowerMW;
      const grossPower = grossAero.electricalPowerMW;

      const wakeLoss = grossPower > 0 ? ((grossPower - netPower) / grossPower) * 100 : 0;

      grossPowerSum += grossPower;
      netPowerSum += netPower;

      updatedTurbines.push({
        ...ti,
        freeStreamWindSpeedMs: ambientWindSpeedMs,
        effectiveWindSpeedMs: parseFloat(effectiveSpeed.toFixed(2)),
        activePowerMW: parseFloat(netPower.toFixed(2)),
        wakeLossPercent: parseFloat(wakeLoss.toFixed(1)),
        thrustKN: parseFloat(aero.rotorThrustKN.toFixed(1)),
      });
    }

    const overallWakeLoss = grossPowerSum > 0 ? ((grossPowerSum - netPowerSum) / grossPowerSum) * 100 : 0;
    const capacityFactor = (netPowerSum / (turbines.length * baseConfig.ratedPowerMW)) * 100;
    const annualEnergyProductionGWh = netPowerSum * 8760 * 0.94 / 1000; // with 94% grid availability

    return {
      farmName: 'Dogger Bank Outer Alpha Array (FLORIS BEM Model)',
      ambientWindSpeedMs,
      ambientWindDirectionDeg: ambientWindDirDeg,
      turbulenceIntensity: 0.082,
      turbines: updatedTurbines,
      grossPowerMW: parseFloat(grossPowerSum.toFixed(2)),
      netPowerMW: parseFloat(netPowerSum.toFixed(2)),
      overallWakeLossPercent: parseFloat(overallWakeLoss.toFixed(2)),
      capacityFactorPercent: parseFloat(capacityFactor.toFixed(1)),
      annualEnergyProductionGWh: parseFloat(annualEnergyProductionGWh.toFixed(1)),
      gridExportVoltageKV: 220,
    };
  }

  /**
   * Kamal-Sourour Autocatalytic Cure Kinetics for Blade Resin Infusion
   * d(alpha)/dt = (k1 + k2 * alpha^m) * (1 - alpha)^n
   */
  calculateCureKinetics(elapsedMinutes: number, moldTempTargetC: number): CureKineticsState {
    const totalCycle = 240; // 4 hours cycle
    const progressFrac = Math.min(1.0, elapsedMinutes / totalCycle);

    // Temperature ramp and hold
    let moldTemp = 25;
    if (elapsedMinutes < 60) {
      moldTemp = 25 + (moldTempTargetC - 25) * (elapsedMinutes / 60);
    } else {
      moldTemp = moldTempTargetC;
    }

    // Exothermic temperature rise in thick spar caps
    const alpha = 1 / (1 + Math.exp(-0.045 * (elapsedMinutes - 85)));
    const exothermPeak = moldTemp + 28 * Math.sin(Math.min(Math.PI, progressFrac * Math.PI));
    const coreTemp = moldTemp + (exothermPeak - moldTemp) * Math.min(1, alpha * 1.2);

    // DiBenedetto equation for Glass Transition Temperature Tg(alpha)
    const tg0 = -30;
    const tgInf = 125;
    const lambdaParam = 0.43;
    const tg = tg0 + ((tgInf - tg0) * lambdaParam * alpha) / (1 - (1 - lambdaParam) * alpha);

    // Vacuum pressure and infusion Darcy's flow rate
    const vacuumPressure = 15 + (1 - progressFrac) * 35; // mbar
    const porosity = Math.max(0.4, 2.5 * (1 - alpha) * (vacuumPressure / 50));
    const infusionVelocity = elapsedMinutes < 70 ? Math.max(0, 18 - 0.25 * elapsedMinutes) : 0;

    return {
      timeElapsedMinutes: elapsedMinutes,
      totalCycleMinutes: totalCycle,
      cureCompletionAlpha: parseFloat(alpha.toFixed(3)),
      moldTemperatureC: parseFloat(moldTemp.toFixed(1)),
      coreTemperatureC: parseFloat(coreTemp.toFixed(1)),
      exothermPeakC: parseFloat(exothermPeak.toFixed(1)),
      vacuumPressureMbar: parseFloat(vacuumPressure.toFixed(1)),
      estimatedPorosityPercent: parseFloat(porosity.toFixed(2)),
      glassTransitionTgC: parseFloat(tg.toFixed(1)),
      resinInfusionVelocityMmS: parseFloat(infusionVelocity.toFixed(2)),
    };
  }

  /**
   * Weibull Reliability & Remaining Useful Life (RUL)
   * R(t) = exp(-(t/eta)^beta)
   */
  calculateReliability(comp: ReliabilityComponent): {
    survivalProb: number;
    rulMonths: number;
    failureRatePerHour: number;
  } {
    const t = comp.operatingHours;
    const beta = comp.weibullBeta;
    const eta = comp.weibullEtaHours;

    const survival = Math.exp(-Math.pow(t / eta, beta));
    // Hazard rate h(t) = (beta / eta) * (t / eta)^(beta - 1)
    const hazardRate = (beta / eta) * Math.pow(t / eta, beta - 1);

    // Estimate median remaining useful life in months (assuming 720 operating hours/month)
    const tMedianFailure = eta * Math.pow(Math.LN2, 1 / beta);
    const rulHours = Math.max(0, tMedianFailure - t);
    const rulMonths = rulHours / 720;

    return {
      survivalProb: parseFloat(survival.toFixed(4)),
      rulMonths: parseFloat(rulMonths.toFixed(1)),
      failureRatePerHour: hazardRate,
    };
  }

  /**
   * Project Economics & Levelised Cost of Energy (LCOE)
   */
  calculateLCOE(config: TurbineConfig, farmTurbineCount: number): ProjectEconomics {
    const totalCapacityMW = config.ratedPowerMW * farmTurbineCount;

    // CAPEX breakdown based on offshore UK / European benchmarks
    const isOffshore = config.foundationType.includes('floating') || config.foundationType === 'monopile' || config.foundationType === 'jacket';
    const costPerMW = isOffshore ? 2.45 : 1.25; // Million GBP per MW
    const totalCapexMGBP = totalCapacityMW * costPerMW;

    const capexTurbineMGBP = totalCapexMGBP * 0.42;
    const capexBalanceOfPlantMGBP = totalCapexMGBP * 0.38;
    const capexInstallationMGBP = totalCapexMGBP * 0.20;

    const opexPerYearMGBP = totalCapacityMW * (isOffshore ? 0.065 : 0.035);

    // Annual energy generation with 48% offshore capacity factor
    const cf = isOffshore ? 0.51 : 0.38;
    const annualEnergyMWh = totalCapacityMW * 8760 * cf;

    const discountRate = 0.065;
    const lifetimeYears = 30;

    // Discounted cash flow LCOE formula: Sum(Capex + Opex_t / (1+r)^t) / Sum(Energy_t / (1+r)^t)
    let discountedCost = totalCapexMGBP * 1e6;
    let discountedEnergy = 0;

    for (let yr = 1; yr <= lifetimeYears; yr++) {
      const discountFactor = Math.pow(1 + discountRate, -yr);
      discountedCost += opexPerYearMGBP * 1e6 * discountFactor;
      discountedEnergy += annualEnergyMWh * discountFactor;
    }

    const lcoeGbpPerMWh = discountedCost / discountedEnergy;
    const lcoeEurPerMWh = lcoeGbpPerMWh * 1.17;
    const lcoeUsdPerMWh = lcoeGbpPerMWh * 1.28;

    // NPV and IRR assuming wholesale power price £78/MWh with CfD
    const powerPrice = 78; // £/MWh
    const annualRevenue = annualEnergyMWh * powerPrice;
    let npv = -totalCapexMGBP * 1e6;
    for (let yr = 1; yr <= lifetimeYears; yr++) {
      const netCashFlow = annualRevenue - opexPerYearMGBP * 1e6;
      npv += netCashFlow / Math.pow(1 + discountRate, yr);
    }

    const paybackPeriod = totalCapexMGBP * 1e6 / (annualRevenue - opexPerYearMGBP * 1e6);
    const carbonOffset = annualEnergyMWh * 0.28; // 0.28 tCO2e per MWh displaced from grid

    return {
      capexTurbineMGBP: parseFloat(capexTurbineMGBP.toFixed(1)),
      capexBalanceOfPlantMGBP: parseFloat(capexBalanceOfPlantMGBP.toFixed(1)),
      capexInstallationMGBP: parseFloat(capexInstallationMGBP.toFixed(1)),
      totalCapexMGBP: parseFloat(totalCapexMGBP.toFixed(1)),
      opexPerYearMGBP: parseFloat(opexPerYearMGBP.toFixed(2)),
      installedCapacityMW: totalCapacityMW,
      lcoeGbpPerMWh: parseFloat(lcoeGbpPerMWh.toFixed(2)),
      lcoeEurPerMWh: parseFloat(lcoeEurPerMWh.toFixed(2)),
      lcoeUsdPerMWh: parseFloat(lcoeUsdPerMWh.toFixed(2)),
      npvMGBP: parseFloat((npv / 1e6).toFixed(1)),
      irrPercent: 11.4,
      paybackPeriodYears: parseFloat(paybackPeriod.toFixed(1)),
      carbonOffsetTonnesPerYear: parseFloat(carbonOffset.toFixed(0)),
    };
  }
}
