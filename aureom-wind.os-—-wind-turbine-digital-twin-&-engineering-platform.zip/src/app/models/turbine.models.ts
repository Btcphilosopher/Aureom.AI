export type TurbineArchitecture = 'geared' | 'medium-speed' | 'direct-drive';
export type FoundationType = 'monopile' | 'jacket' | 'gravity-base' | 'floating-spar' | 'floating-semi-sub';
export type GeneratorType = 'DFIG' | 'PMSG' | 'EESG';
export type WorkspaceMode = 'FACTORY' | 'ENGINEERING' | 'LOGISTICS' | 'FIELD' | 'LIFECYCLE';
export type SceneMode = 'factory' | 'engineering' | 'offshore' | 'windfarm' | 'inspection';

export interface TurbineConfig {
  id: string;
  serialNumber: string;
  name: string;
  class: 'IEC Class I' | 'IEC Class II' | 'IEC Class S (Offshore)';
  architecture: TurbineArchitecture;
  ratedPowerMW: number; // e.g. 15 MW
  rotorDiameterM: number; // e.g. 236 m
  hubHeightM: number; // e.g. 150 m
  bladeLengthM: number; // e.g. 115.5 m
  bladeCount: number; // 3
  cutInSpeedMs: number; // 3.0 m/s
  ratedSpeedMs: number; // 10.8 m/s
  cutOutSpeedMs: number; // 25.0 m/s
  minRotorRpm: number; // 4.5 rpm
  maxRotorRpm: number; // 8.6 rpm
  gearboxRatio: number; // 1 for direct drive, or 1:115
  generatorType: GeneratorType;
  generatorVoltageKV: number; // 66 kV or 0.69 kV
  towerGeometry: {
    baseDiameterM: number;
    topDiameterM: number;
    wallThicknessMm: number;
    sectionsCount: number;
    totalMassTons: number;
  };
  foundationType: FoundationType;
  bladeMaterials: {
    sparCapMaterial: 'Carbon Fiber / Vinylester' | 'High-Modulus E-Glass' | 'Hybrid Carbon-Glass';
    resinSystem: 'Epoxy Bisphenol-A' | 'Bio-based Polyurethane' | 'Recyclable Elium® Thermoplastic';
    coreMaterial: 'PET Foam (Recycled)' | 'Balsa Wood Grade A' | 'SAN Foam';
    bladeTotalMassTons: number;
  };
  pitchSystem: 'Individual Pitch Control (Electro-Mechanical)' | 'Hydraulic Cylinder IPC';
  yawSystem: 'Multi-Drive Electric Geared (8 Drives)' | 'Active Hydraulic Brake Yaw';
  coolingSystem: 'Liquid-to-Air Forced Nacelle Heat Exchanger' | 'Direct Seawater Passive Cooling';
  environmentalAccounting: {
    embodiedCarbonTonnesCO2: number;
    carbonPaybackMonths: number;
    recyclabilityPercent: number;
  };
}

export interface MaterialBatch {
  id: string;
  batchCode: string;
  materialName: string;
  grade: string;
  supplier: string;
  quantity: string;
  densityKgM3: number;
  yieldStrengthMpa?: number;
  tensileModulusGpa?: number;
  resinViscosityCps?: number;
  embodiedCarbonKgCo2PerKg: number;
  deliveryDate: string;
  certificateRef: string;
  destinationStation: string;
  status: 'Certified' | 'Quarantine Inspection' | 'Released to Line';
}

export interface FactoryStation {
  id: string;
  name: string;
  bay: string;
  cycleTimeHours: number;
  utilizationPercent: number;
  status: 'Operating' | 'Setup' | 'Curing' | 'Maintenance' | 'Inspection';
  currentAssetId: string;
  leadTechnician: string;
  sensors: {
    temperatureC: number;
    pressureBar?: number;
    vacuumMbar?: number;
    vibrationMmS: number;
  };
}

export interface CureKineticsState {
  timeElapsedMinutes: number;
  totalCycleMinutes: number;
  cureCompletionAlpha: number; // 0.0 to 1.0
  moldTemperatureC: number;
  coreTemperatureC: number;
  exothermPeakC: number;
  vacuumPressureMbar: number;
  estimatedPorosityPercent: number;
  glassTransitionTgC: number;
  resinInfusionVelocityMmS: number;
}

export interface AerodynamicSimulationResult {
  windSpeedMs: number;
  rotorRpm: number;
  tipSpeedRatio: number;
  powerCoefficientCp: number;
  thrustCoefficientCt: number;
  bladePitchDeg: number;
  aerodynamicPowerMW: number;
  electricalPowerMW: number;
  rotorThrustKN: number;
  aerodynamicTorqueKNm: number;
  generatorEfficiency: number;
  operatingRegion: 'Region 1 (Sub-Cut-In)' | 'Region 2 (MPPT Optimal)' | 'Region 2.5 (Transition)' | 'Region 3 (Rated Pitch Regulated)' | 'Region 4 (Cut-Out)';
}

export interface AerodynamicCurvePoint {
  windSpeed: number;
  powerMW: number;
  thrustKN: number;
  cp: number;
  pitchDeg: number;
  rpm: number;
}

export interface FlorisTurbineLocation {
  id: string;
  name: string;
  xM: number;
  yM: number;
  yawOffsetDeg: number;
  freeStreamWindSpeedMs: number;
  effectiveWindSpeedMs: number;
  activePowerMW: number;
  wakeLossPercent: number;
  thrustKN: number;
}

export interface WindFarmState {
  farmName: string;
  ambientWindSpeedMs: number;
  ambientWindDirectionDeg: number;
  turbulenceIntensity: number;
  turbines: FlorisTurbineLocation[];
  grossPowerMW: number;
  netPowerMW: number;
  overallWakeLossPercent: number;
  capacityFactorPercent: number;
  annualEnergyProductionGWh: number;
  gridExportVoltageKV: number;
}

export interface LogisticsStep {
  id: string;
  stepNumber: number;
  title: string;
  vesselOrVehicle: string;
  durationDays: number;
  weatherLimitWaveHsM: number;
  weatherLimitWindMs: number;
  currentMetoceanWaveM: number;
  currentMetoceanWindMs: number;
  status: 'Completed' | 'In Progress' | 'Standby Weather' | 'Scheduled';
  progressPercent: number;
  craneLiftMassTons: number;
}

export interface BladeDefect {
  id: string;
  bladeIndex: number; // 1, 2, or 3
  locationMetersFromRoot: number; // 0 to 115m
  spanPercent: number;
  surface: 'Leading Edge' | 'Trailing Edge' | 'Suction Side' | 'Pressure Side';
  defectType: 'Leading Edge Erosion (Category 3)' | 'Lightning Strike Arc Pit' | 'Subsurface Delamination' | 'Gelcoat Microcrack';
  severityScore: 'Minor' | 'Moderate' | 'Critical';
  ultrasonicDepthMm: number;
  detectedBy: 'Aardvark Autonomous Drone Scan' | 'Technician NDT Inspection';
  status: 'Monitored' | 'Scheduled for Rope Access' | 'Repaired';
  confidencePercent: number;
}

export interface ReliabilityComponent {
  name: string;
  weibullBeta: number; // Shape parameter (e.g. 1.8 = wear out)
  weibullEtaHours: number; // Characteristic life
  operatingHours: number;
  survivalProbability: number;
  estimatedRulMonths: number;
  vibrationRmsMmS: number;
  dominantHarmonicHz: number;
  oilParticlePpm?: number;
  temperatureC: number;
  healthState: 'Optimal' | 'Advisory' | 'Urgent';
}

export interface ProjectEconomics {
  capexTurbineMGBP: number;
  capexBalanceOfPlantMGBP: number;
  capexInstallationMGBP: number;
  totalCapexMGBP: number;
  opexPerYearMGBP: number;
  installedCapacityMW: number;
  lcoeGbpPerMWh: number;
  lcoeEurPerMWh: number;
  lcoeUsdPerMWh: number;
  npvMGBP: number;
  irrPercent: number;
  paybackPeriodYears: number;
  carbonOffsetTonnesPerYear: number;
}
