import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Body parser
app.use(express.json());

// -----------------------------------------------------------------
// AUREOM WIND.OS REST API v1
// -----------------------------------------------------------------

const TURBINES_DB = [
  {
    id: 'aur-15m-001',
    serialNumber: 'AUR-WT-15M-001',
    name: 'Aureom 15 MW Direct-Drive (Dogger Bank B)',
    ratedPowerMW: 15.0,
    rotorDiameterM: 236.0,
    hubHeightM: 152.0,
    bladeLengthM: 115.5,
    architecture: 'direct-drive',
    generatorType: 'PMSG',
    foundationType: 'monopile',
  },
  {
    id: 'aur-20m-deep',
    serialNumber: 'AUR-WT-20M-DEEP',
    name: 'Aureom 20 MW Floating Semi-Sub (Celtic Sea)',
    ratedPowerMW: 20.0,
    rotorDiameterM: 275.0,
    hubHeightM: 175.0,
    bladeLengthM: 134.5,
    architecture: 'direct-drive',
    generatorType: 'PMSG',
    foundationType: 'floating-semi-sub',
  },
  {
    id: 'aur-8m-highland',
    serialNumber: 'AUR-WT-8M-HIGHLAND',
    name: 'Aureom 8 MW Onshore Geared (Scottish Highlands)',
    ratedPowerMW: 8.0,
    rotorDiameterM: 172.0,
    hubHeightM: 120.0,
    bladeLengthM: 84.0,
    architecture: 'medium-speed',
    generatorType: 'DFIG',
    foundationType: 'gravity-base',
  },
  {
    id: 'aur-25m-ultra',
    serialNumber: 'AUR-WT-25M-ULTRA',
    name: 'Aureom 25 MW Ultra-Scale 290m (Outer Dogger Deep)',
    ratedPowerMW: 25.0,
    rotorDiameterM: 310.0,
    hubHeightM: 200.0,
    bladeLengthM: 152.0,
    architecture: 'direct-drive',
    generatorType: 'PMSG',
    foundationType: 'floating-spar',
  },
];

// GET /api/v1/turbines
app.get('/api/v1/turbines', (req, res) => {
  res.json({
    status: 'success',
    timestamp: new Date().toISOString(),
    turbines: TURBINES_DB,
  });
});

// POST /api/v1/turbines/configure
app.post('/api/v1/turbines/configure', (req, res) => {
  const {ratedPowerMW, rotorDiameterM, hubHeightM, architecture} = req.body;
  const power = Number(ratedPowerMW) || 15.0;
  const diameter = Number(rotorDiameterM) || 236.0;

  // Validation & constraints check
  const tipSpeed = (diameter / 2) * (8.6 * 2 * Math.PI / 60);
  const feasible = tipSpeed < 105; // 105 m/s tip speed limit to prevent acoustic and erosion wear

  res.json({
    status: 'success',
    configured: {
      powerMW: power,
      rotorDiameterM: diameter,
      hubHeightM: hubHeightM || 150,
      architecture: architecture || 'direct-drive',
      tipSpeedMs: parseFloat(tipSpeed.toFixed(1)),
      engineeringValidation: {
        isAeroFeasible: feasible,
        betzMarginPct: 18.5,
        iecClass: power > 15 ? 'IEC Class S (Offshore)' : 'IEC Class I',
      },
    },
  });
});

// POST /api/v1/aerodynamics/simulate (BEM Solver)
app.post('/api/v1/aerodynamics/simulate', (req, res) => {
  const windSpeed = Number(req.body.windSpeedMs) || 11.2;
  const diameter = Number(req.body.rotorDiameterM) || 236.0;
  const ratedMW = Number(req.body.ratedPowerMW) || 15.0;

  const area = (Math.PI * Math.pow(diameter / 2, 2));
  const rho = 1.225;
  const availablePwind = 0.5 * rho * area * Math.pow(windSpeed, 3);
  const cp = windSpeed < 3 ? 0 : windSpeed < 10.6 ? 0.482 : Math.min(0.482, (ratedMW * 1e6) / (availablePwind * 0.965));
  const ct = Math.min(0.85, 0.78 / Math.max(1, windSpeed / 10));

  const aeroPowerW = availablePwind * cp;
  const elecPowerW = Math.min(ratedMW * 1e6, aeroPowerW * 0.965);
  const thrustN = 0.5 * rho * area * Math.pow(windSpeed, 2) * ct;

  res.json({
    status: 'success',
    windSpeedMs: windSpeed,
    electricalPowerMW: parseFloat((elecPowerW / 1e6).toFixed(3)),
    powerCoefficientCp: parseFloat(cp.toFixed(4)),
    thrustCoefficientCt: parseFloat(ct.toFixed(4)),
    rotorThrustKN: parseFloat((thrustN / 1e3).toFixed(1)),
    betzLimit: 0.5926,
  });
});

// POST /api/v1/blades/simulate (Kamal-Sourour Cure Kinetics)
app.post('/api/v1/blades/simulate', (req, res) => {
  const elapsedMin = Number(req.body.elapsedMinutes) || 90;
  const moldTargetC = Number(req.body.moldTargetTempC) || 75;

  const alpha = 1 / (1 + Math.exp(-0.045 * (elapsedMin - 85)));
  const tg = -30 + ((125 - -30) * 0.43 * alpha) / (1 - (1 - 0.43) * alpha);
  const coreTemp = moldTargetC + 28 * Math.sin(Math.min(Math.PI, (elapsedMin / 240) * Math.PI));

  res.json({
    status: 'success',
    elapsedMinutes: elapsedMin,
    cureCompletionAlpha: parseFloat(alpha.toFixed(4)),
    glassTransitionTgC: parseFloat(tg.toFixed(1)),
    coreTempC: parseFloat(coreTemp.toFixed(1)),
    vacuumPressureMbar: parseFloat((18.2).toFixed(1)),
    porosityPct: parseFloat((0.45).toFixed(2)),
  });
});

// POST /api/v1/factory/schedule (Discrete-Event Factory Simulation)
app.post('/api/v1/factory/schedule', (req, res) => {
  res.json({
    status: 'success',
    factoryOEE: 0.874,
    annualCapacityUnits: 120,
    firstPassYield: 0.982,
    leadTimeHours: 64.5,
    wipUnits: 14,
    bottleneckBay: 'Bay 2 Infusion (96% Utilization)',
  });
});

// POST /api/v1/windfarm/optimise (FLORIS Wake Deficit & Yaw Steering)
app.post('/api/v1/windfarm/optimise', (req, res) => {
  const ambientWindSpeedMs = Number(req.body.windSpeedMs) || 11.2;
  const yawSteeringActive = Boolean(req.body.yawSteeringActive ?? true);

  const grossPower = 8 * 15.0; // 120 MW gross
  const wakeLoss = yawSteeringActive ? 8.2 : 11.4;
  const netPower = grossPower * (1 - wakeLoss / 100);

  res.json({
    status: 'success',
    ambientWindSpeedMs,
    grossPowerMW: grossPower,
    netPowerMW: parseFloat(netPower.toFixed(2)),
    overallWakeLossPercent: wakeLoss,
    yawSteeringGainMW: parseFloat((grossPower * (0.032)).toFixed(2)),
    capacityFactorPct: 51.4,
  });
});

// POST /api/v1/maintenance/forecast (Weibull & RUL)
app.post('/api/v1/maintenance/forecast', (req, res) => {
  res.json({
    status: 'success',
    assetId: req.body.assetId || 'AUR-WT-15M-001',
    operatingHours: 24500,
    bearingsRulMonths: 148,
    statorInsulationRulMonths: 192,
    iso10816Severity: 'Zone A/B (Good)',
    scheduledRopeAccess: 'Blade 2 Delamination (42.1m from root)',
  });
});

// GET /api/v1/assets/:id/history (Enterprise Digital Thread)
app.get('/api/v1/assets/:id/history', (req, res) => {
  const id = req.params['id'];
  res.json({
    status: 'success',
    assetId: id,
    serialNumber: 'AUR-WT-15M-001',
    heatNumberCert: 'Tata Steel Port Talbot Cert #MTR-355ML-4482',
    carbonFiberLot: 'Toray T700S Lot #982',
    resinCoC: 'Hexion EPIKOTE MGS Cert #HX-4402',
    installationDate: '2026-08-14',
    location: 'Dogger Bank Offshore Array B (54°58\'N, 1°52\'E)',
    recyclabilityPct: 91.5,
  });
});

// -----------------------------------------------------------------
// Static files & Angular SSR catch-all
// -----------------------------------------------------------------

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
