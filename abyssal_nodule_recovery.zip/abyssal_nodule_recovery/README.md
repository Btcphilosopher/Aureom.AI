# ABYSSAL — Nodule Recovery (v2)

A browser game about piloting a deep-sea submersible. Open `index.html` in any modern browser. It needs no build step and no server, and it works from `file://`.

```
index.html      markup: HUD, touch controls, modals
css/style.css   styles (desktop, small-screen and touch layouts)
js/game.js      all game logic (documented sections 1–10)
```

## Controls

| Key | Action |
|---|---|
| `W` / `↑`, `S` / `↓` | ascend / descend |
| `A` / `←`, `D` / `→` | steer |
| `Shift` | boost (uses more power) |
| `Space` | collect the nearby nodule |
| `E` | sonar ping |
| `R` | autopilot back to the vessel |
| `P` / `Esc` | pause |

On touch devices, on-screen controls appear automatically.

## What changed from v1

### Bugs fixed
- **You couldn't see the nodules you could collect.** v1 used three different coordinate mappings: one for drawing, one for the collect range and one for the reticle. Nodules were drawn only when they were more than about 2,000 m below the sub, and the reticle never lined up with them. v2 uses one world-coordinate system, and the camera follows the sub.
- **The sub and the world disagreed about where the sub was.** The sub was drawn at `W/2 + x*0.12` while the world scrolled by `x`.
- **Physics depended on frame rate.** Steering added `+1` per frame, so the sub moved faster on 144 Hz screens and could reach about 1,150 px/s. v2 runs physics on a fixed 120 Hz step with exponential drag.
- **Notifications spammed.** At maximum depth, v1 called `notify()` every frame and queued a new `setTimeout` each time. Notifications now use a single timer and skip duplicates.
- **Space bar triggered actions twice.** After you clicked a HUD button, Space would press the focused button and also collect. Buttons now lose focus after a click, and game keys call `preventDefault` while you are playing.
- **Keys got stuck when the window lost focus.** Held input is now cleared on `blur`, and the game auto-pauses when the tab is hidden.
- **Sorting a nodule's metals changed shared data.** v1 ran `mix.sort()` inside `updateHUD()` four times a second, which mutated the nodule's data. v2 works out the dominant metal once, when the nodule is created.
- **Large deep nodules could never fit in the hold.** v1 nodules could weigh up to about 23 kg against a 12 kg hold. Masses are now rebalanced.
- **The world layout depended on window size.** Nodule positions used `W` when they were generated. The world now comes from a seeded generator.
- **Smaller fixes:** the depth-scale labels didn't match the marker, a second empty `surfaceBtn` listener was removed, `game.elapsed % 0.25 < dt` made HUD updates irregular, the rocks were drawn with a static random function, and particles ignored window resizes.

### Gameplay
- **A real basin.** The seabed is a seeded height-map that gets deeper towards the east, with two hadal trenches. Nodules rest on the seabed. Deeper nodules are larger, higher grade and richer in cobalt and rare earths.
- **Darkness and lights.** Ambient light fades with depth, and the sub's lamp and floodlight cut through it.
- **Sonar (`E`).** A sonar ping marks nodules within range, colour-coded by dominant metal, on screen and on the minimap. It costs battery and has a cooldown.
- **Recovery vessel and docking.** Cargo now sells when you dock at the vessel. Docking also recharges the battery and repairs the hull. An edge-of-screen arrow shows the way back.
- **Autopilot (`R`).** The sub returns to the vessel by itself. It disengages as soon as you steer.
- **Refit bay.** v1's text promised "upgrade your sub", but no upgrades existed. v2 adds upgrades for battery, hull rating, cargo hold, thrusters, and lamps and sonar.
- **Real risk.** Diving below your hull rating stresses the hull. Hitting the seabed hard damages it. If the battery runs flat, the sub drops ballast and floats up, and you pay a fee to be towed in. If the hull fails, you lose the sub and its cargo, and you pay a replacement fee.
- **A live market index.** v1 showed a fixed `1.00×`. The index now drifts after each sale and affects the value of your cargo.
- **Progress is saved.** Money, upgrades, the world seed and career stats are stored in `localStorage` and checked when loaded. The menu has a reset option.
- **Pause** with `P` or `Esc`, or with the HUD button.

### Code quality
- Split into HTML, CSS and JS. The code is organised into named sections with one `CFG` object for tuning values.
- A simple state machine (`menu`, `playing`, `paused`, `refit`, `lost`) drives the modals.
- The HUD writes to the DOM only when a value changes. The cargo list re-renders only when the cargo changes, and is grouped by metal.
- Cheaper rendering: off-screen objects are skipped, the lighting mask is drawn at half resolution, the terrain is precomputed as a typed array, and the minimap path is cached.
- Accessibility: `aria-live` regions for messages, `:focus-visible` outlines, `prefers-reduced-motion` support (no camera shake), and proper `type="button"` and `aria-expanded` attributes.
- Mobile: safe-area insets, a layout for small screens, and pointer-event touch controls.

*Game simulation: all resource grades, prices, depths and vehicle systems are fictional.*
