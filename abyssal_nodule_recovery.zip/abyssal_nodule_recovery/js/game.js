/*
 * ABYSSAL — Nodule Recovery
 *
 * Sections:
 *   1. Config & data        6. Simulation
 *   2. Utilities            7. Player actions
 *   3. Persistence          8. Rendering
 *   4. World generation     9. HUD & menus
 *   5. Input               10. Boot & main loop
 *
 * World units: 1 unit = 1 px at zoom 1. Depth in metres = y * M_PER_UNIT.
 * The vessel sits at the west end of the basin; the seabed deepens eastward.
 */
(() => {
  'use strict';

  /* ======================================================================
   * 1. CONFIG & DATA
   * ==================================================================== */
  const CFG = Object.freeze({
    M_PER_UNIT: 2.5,
    WORLD_W: 12000,
    FLOOR_STEP: 8,
    FLOOR_MAX_M: 10400,
    VESSEL_X: 240,
    DOCK_RANGE: 300,
    NODULE_COUNT: 230,

    SUB_HALF_W: 58,
    SUB_HALF_H: 22,
    COLLECT_RANGE: 80,
    SCAN_RANGE: 230,

    THRUST: 250,            // units/s² at thrust level 1
    DRAG: 1.8,              // exponential drag coefficient, 1/s
    BOOST: 1.7,
    EMERGENCY_LIFT: 140,    // upward accel once ballast is dropped
    TOW_SPEED: 260,

    DRAIN_IDLE: 0.12,       // kWh/s
    DRAIN_THRUST: 0.34,
    DRAIN_BOOST: 0.6,

    SONAR_COST: 2.5,
    SONAR_SPEED: 1600,
    SONAR_COOLDOWN: 2.5,
    SONAR_MARK_TIME: 7,

    HULL_STRESS_PER_M: 0.004, // % hull per second per metre below rating
    IMPACT_SPEED: 75,
    IMPACT_DAMAGE: 0.14,

    TOW_FEE: 120,
    LOSS_FEE_RATE: 0.2,
    LOSS_FEE_MIN: 150,

    STEP: 1 / 120,          // fixed physics step
    HUD_INTERVAL: 0.1,
    SAVE_KEY: 'abyssal.noduleRecovery.v2',
  });

  const METALS = Object.freeze([
    { name: 'Manganese',   sym: 'Mn',  color: '#9babb2', price: 18,  weight: 0.38, affinity: 0.0 },
    { name: 'Nickel',      sym: 'Ni',  color: '#d7bd82', price: 115, weight: 0.24, affinity: 0.6 },
    { name: 'Copper',      sym: 'Cu',  color: '#d98a5c', price: 92,  weight: 0.20, affinity: 0.4 },
    { name: 'Cobalt',      sym: 'Co',  color: '#7b9dd7', price: 205, weight: 0.12, affinity: 1.4 },
    { name: 'Rare earths', sym: 'REE', color: '#b58bd5', price: 280, weight: 0.06, affinity: 2.2 },
  ]);

  const ZONES = Object.freeze([
    [200, 'SUNLIT'], [1000, 'TWILIGHT'], [4000, 'MIDNIGHT'], [6000, 'ABYSSAL'], [Infinity, 'HADAL'],
  ]);

  /** Vehicle stats as a function of upgrade level. */
  const DERIVED = Object.freeze({
    batteryMax: l => 100 + 35 * l,
    hullRating: l => 6000 + 1200 * l,
    cargoCap:   l => 12 + 5 * l,
    thrust:     l => 1 + 0.15 * l,
    light:      l => 230 * (1 + 0.25 * l),
    sonarRange: l => 1000 + 300 * l,
  });

  const UPGRADES = Object.freeze([
    { id: 'battery',   name: 'Battery cells',       base: 350, max: 5, effect: l => `${DERIVED.batteryMax(l)} kWh capacity` },
    { id: 'hull',      name: 'Hull plating',        base: 500, max: 4, effect: l => `Rated to ${num(DERIVED.hullRating(l))} m` },
    { id: 'cargo',     name: 'Cargo hold',          base: 300, max: 5, effect: l => `${DERIVED.cargoCap(l)} kg capacity` },
    { id: 'thrusters', name: 'Thrusters',           base: 400, max: 4, effect: l => `${Math.round(DERIVED.thrust(l) * 100)}% thrust` },
    { id: 'lamps',     name: 'Floodlights & sonar', base: 250, max: 3, effect: l => `${100 + 25 * l}% lamp range · ${num(toM(DERIVED.sonarRange(l)))} m sonar` },
  ]);
  const upgradeCost = (u, lvl) => Math.round((u.base * Math.pow(1.85, lvl)) / 10) * 10;

  /** Water colour by depth (metres). */
  const WATER_STOPS = [
    [0, '#3d9db3'], [300, '#15516c'], [1200, '#082a42'], [3000, '#031a2c'], [6000, '#010b17'],
  ].map(([m, c]) => [m, hexToRgb(c)]);

  /* ======================================================================
   * 2. UTILITIES
   * ==================================================================== */
  const $ = id => document.getElementById(id);
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smoothstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
  const mod = (a, n) => ((a % n) + n) % n;
  const toM = units => units * CFG.M_PER_UNIT;
  const toUnits = m => m / CFG.M_PER_UNIT;
  const TAU = Math.PI * 2;

  const GBP = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 });
  const INT = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 0 });
  const money = n => GBP.format(Math.round(n));
  const num = n => INT.format(Math.round(n));
  const zoneFor = m => ZONES.find(([max]) => m < max)[1];

  /** Deterministic PRNG so a save always regenerates the same basin. */
  function mulberry32(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /** Stable pseudo-random value in [0,1) for decoration placement. */
  const hash = i => { const s = Math.sin(i * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

  function hexToRgb(h) { return [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); }
  function waterColor(m) {
    let i = 0;
    while (i < WATER_STOPS.length - 2 && m > WATER_STOPS[i + 1][0]) i++;
    const [m0, c0] = WATER_STOPS[i], [m1, c1] = WATER_STOPS[i + 1];
    const t = clamp((m - m0) / (m1 - m0), 0, 1);
    return `rgb(${c0.map((v, k) => Math.round(lerp(v, c1[k], t))).join(',')})`;
  }

  /* ======================================================================
   * 3. PERSISTENCE
   * ==================================================================== */
  const storage = {
    load() { try { return JSON.parse(localStorage.getItem(CFG.SAVE_KEY) || 'null'); } catch { return null; } },
    save(data) { try { localStorage.setItem(CFG.SAVE_KEY, JSON.stringify(data)); } catch { /* private mode / quota */ } },
    clear() { try { localStorage.removeItem(CFG.SAVE_KEY); } catch { /* ignore */ } },
  };

  function defaultProfile() {
    return {
      version: 2,
      seed: (Math.random() * 2 ** 31) >>> 0,
      bank: 0, earned: 0, dives: 0, bestHaul: 0, deepest: 0, market: 1,
      upgrades: Object.fromEntries(UPGRADES.map(u => [u.id, 0])),
    };
  }

  /** Load and sanitise the saved profile so corrupt data can't break the game. */
  function loadProfile() {
    const base = defaultProfile();
    const data = storage.load();
    if (!data || typeof data !== 'object') return base;
    const p = { ...base, ...data, upgrades: { ...base.upgrades, ...(data.upgrades || {}) } };
    for (const k of ['bank', 'earned', 'dives', 'bestHaul', 'deepest']) {
      p[k] = Number.isFinite(+p[k]) ? Math.max(0, +p[k]) : 0;
    }
    p.market = clamp(+p.market || 1, 0.6, 1.5);
    p.seed = (+p.seed >>> 0) || base.seed;
    for (const u of UPGRADES) p.upgrades[u.id] = clamp(Math.floor(+p.upgrades[u.id] || 0), 0, u.max);
    return p;
  }

  const persist = () => storage.save(profile);
  const hasProgress = () => profile.dives > 0 || profile.bank > 0 || profile.earned > 0;

  /* ======================================================================
   * 4. WORLD GENERATION
   * ==================================================================== */
  const world = { floor: null, nodules: [] };

  /** Seabed depth profile (units) sampled every FLOOR_STEP units. */
  function buildTerrain(seed) {
    const rng = mulberry32(seed);
    const ph = [rng(), rng(), rng(), rng()].map(v => v * TAU);
    const trenches = [
      { t: 0.58 + rng() * 0.05, depth: 1100 + rng() * 500, width: 0.022 },
      { t: 0.86 + rng() * 0.05, depth: 1500 + rng() * 500, width: 0.03 },
    ];
    const n = Math.ceil(CFG.WORLD_W / CFG.FLOOR_STEP) + 1;
    const floor = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = i * CFG.FLOOR_STEP;
      const t = x / CFG.WORLD_W;
      let m = 160 + 8600 * smoothstep(0.06, 0.82, t);
      for (const tr of trenches) m += tr.depth * Math.exp(-((t - tr.t) ** 2) / (2 * tr.width ** 2));
      const rough = 0.25 + t * 1.1;
      m += rough * (230 * Math.sin(x * 0.0017 + ph[0]) + 110 * Math.sin(x * 0.0049 + ph[1])
                  + 40 * Math.sin(x * 0.0131 + ph[2]) + 14 * Math.sin(x * 0.041 + ph[3]));
      floor[i] = toUnits(clamp(m, 90, CFG.FLOOR_MAX_M));
    }
    return floor;
  }

  /** Interpolated seabed depth (units) at world x. */
  function floorAt(x) {
    const f = x / CFG.FLOOR_STEP;
    const i = clamp(Math.floor(f), 0, world.floor.length - 2);
    const t = clamp(f - i, 0, 1);
    return lerp(world.floor[i], world.floor[i + 1], t);
  }

  /** Nodules lie on the seabed; deeper ones are larger, higher grade and rarer-metal rich. */
  function spawnNodules(seed) {
    const rng = mulberry32(seed);
    const r = (a, b) => a + rng() * (b - a);
    const list = [];
    for (let guard = 0; list.length < CFG.NODULE_COUNT && guard < 20000; guard++) {
      const x = r(600, CFG.WORLD_W - 80);
      const depthM = toM(floorAt(x));
      const d = depthM / CFG.FLOOR_MAX_M;
      if (rng() > 0.2 + 0.8 * d) continue; // density increases with depth

      const mass = r(0.5, 1.3) * (1 + d * 2.8);
      const grade = clamp(r(22, 58) + d * 36, 15, 98);
      const purity = clamp(r(38, 72) + d * 22, 30, 99);
      const mix = METALS.map(m => ({ metal: m, share: r(0.3, 1.4) * m.weight * (1 + d * m.affinity) }));
      const total = mix.reduce((s, o) => s + o.share, 0);
      mix.forEach(o => { o.share /= total; });
      mix.sort((a, b) => b.share - a.share);
      const metalFactor = mix.reduce((s, o) => s + o.share * o.metal.price, 0);
      const value = mass * (grade / 100) * (purity / 100) * metalFactor * (1 + d * 0.45) * 3;
      const radius = 5 + mass * 2;

      list.push({
        x, y: floorAt(x) - radius * 0.45, depthM, mass, grade, purity, mix, value, radius,
        dominant: mix[0].metal,
        rot: r(-0.4, 0.4),
        shape: Array.from({ length: 9 }, () => r(0.78, 1.12)),
        collected: false, pingedUntil: 0, pingId: -1,
      });
    }
    return list;
  }

  const noduleSeed = () => (profile.seed ^ Math.imul(profile.dives + 1, 0x9e3779b1)) >>> 0;

  /* ======================================================================
   * 5. INPUT
   * ==================================================================== */
  const KEYMAP = {
    KeyW: 'up', ArrowUp: 'up', KeyS: 'down', ArrowDown: 'down',
    KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right',
    ShiftLeft: 'boost', ShiftRight: 'boost',
  };
  const kbHeld = Object.create(null);
  const touchHeld = Object.create(null);
  const held = a => !!(kbHeld[a] || touchHeld[a]);
  const clearHeld = () => {
    for (const k in kbHeld) delete kbHeld[k];
    for (const k in touchHeld) delete touchHeld[k];
    document.querySelectorAll('#touch .held').forEach(b => b.classList.remove('held'));
  };

  function initInput() {
    const actions = {
      Space: collect, KeyE: pingSonar, KeyR: toggleAutopilot, KeyP: togglePause, Escape: onEscape,
    };
    addEventListener('keydown', e => {
      const playing = run.state === 'playing';
      if (KEYMAP[e.code]) {
        kbHeld[KEYMAP[e.code]] = true;
        if (playing) e.preventDefault();
      }
      const act = actions[e.code];
      if (act && (playing || e.code === 'Escape' || e.code === 'KeyP')) {
        e.preventDefault();
        if (!e.repeat) act();
      }
    });
    addEventListener('keyup', e => { if (KEYMAP[e.code]) kbHeld[KEYMAP[e.code]] = false; });
    addEventListener('blur', () => { clearHeld(); if (run.state === 'playing') setState('paused'); });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && run.state === 'playing') setState('paused');
    });

    // Touch controls: shown on coarse pointers, or as soon as someone touches the screen.
    if (matchMedia('(hover: none) and (pointer: coarse)').matches) document.body.classList.add('touch');
    addEventListener('touchstart', () => document.body.classList.add('touch'), { once: true, passive: true });

    for (const b of document.querySelectorAll('#touch [data-hold]')) {
      const a = b.dataset.hold;
      const on = e => { e.preventDefault(); touchHeld[a] = true; b.classList.add('held'); try { b.setPointerCapture(e.pointerId); } catch { /* ok */ } };
      const off = () => { touchHeld[a] = false; b.classList.remove('held'); };
      b.addEventListener('pointerdown', on);
      for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) b.addEventListener(ev, off);
    }
    const taps = { collect, sonar: pingSonar };
    for (const b of document.querySelectorAll('#touch [data-tap]')) {
      b.addEventListener('pointerdown', e => { e.preventDefault(); taps[b.dataset.tap](); });
    }
    addEventListener('contextmenu', e => { if (e.target.closest('#touch')) e.preventDefault(); });
  }

  /* ======================================================================
   * 6. SIMULATION
   * ==================================================================== */
  let profile = loadProfile();
  let S = computeStats();

  const sub = { x: CFG.VESSEL_X + 70, y: 0, vx: 0, vy: 0, facing: 1, tilt: 0, prop: 0, thrust: 0 };
  const cam = { x: sub.x, y: 0, zoom: 1 };
  const run = {
    state: 'menu', time: 0,
    battery: S.batteryMax, hull: 100, cargo: [],
    docked: true, autopilot: false, emergency: false, towing: false,
    shake: 0, bubbles: [], tether: null,
    sonar: { t: -1, x: 0, y: 0, cooldown: 0, id: 0 },
    warned: { pressure: false, battery: false },
  };

  function computeStats() {
    const u = profile.upgrades;
    return {
      batteryMax: DERIVED.batteryMax(u.battery),
      hullRating: DERIVED.hullRating(u.hull),
      cargoCap: DERIVED.cargoCap(u.cargo),
      thrust: DERIVED.thrust(u.thrusters),
      light: DERIVED.light(u.lamps),
      sonarRange: DERIVED.sonarRange(u.lamps),
    };
  }

  const cargoMass = () => run.cargo.reduce((s, n) => s + n.mass, 0);
  const cargoValue = () => run.cargo.reduce((s, n) => s + n.value, 0) * profile.market;
  const depthM = () => toM(sub.y);
  const clawPos = () => ({ x: sub.x + sub.facing * 18, y: sub.y + CFG.SUB_HALF_H });
  const altitudeM = () => toM(floorAt(sub.x) - sub.y - CFG.SUB_HALF_H);

  function nearestNodule(range) {
    const c = clawPos();
    let best = null, bestD = range;
    for (const n of world.nodules) {
      if (n.collected || Math.abs(n.x - c.x) > range) continue;
      const d = Math.hypot(n.x - c.x, n.y - c.y);
      if (d < bestD) { bestD = d; best = n; }
    }
    return best && { n: best, d: bestD };
  }

  function autopilotInput() {
    const dx = CFG.VESSEL_X - sub.x;
    return { x: Math.abs(dx) > 40 ? Math.sign(dx) * 0.8 : 0, y: sub.y > 2 ? -1 : 0 };
  }

  function damage(amount, kind) {
    if (amount <= 0) return;
    run.hull = Math.max(0, run.hull - amount);
    if (kind === 'impact') {
      run.shake = Math.min(1, run.shake + amount / 15);
      toast(`Seabed impact · hull −${amount.toFixed(1)}%`);
    }
  }

  function update(dt) {
    run.time += dt;
    const powered = run.battery > 0;

    // --- Control input ---
    let ix = 0, iy = 0, boost = false;
    if (powered && !run.towing) {
      ix = (held('right') ? 1 : 0) - (held('left') ? 1 : 0);
      iy = (held('down') ? 1 : 0) - (held('up') ? 1 : 0);
      boost = held('boost');
      if (run.autopilot) {
        if (ix || iy) { run.autopilot = false; toast('Autopilot disengaged — manual control.'); }
        else ({ x: ix, y: iy } = autopilotInput());
      }
    }
    const mag = Math.hypot(ix, iy);
    if (mag > 1) { ix /= mag; iy /= mag; }
    const load = Math.min(1, mag);
    const boosting = boost && load > 0;

    // --- Physics ---
    const accel = CFG.THRUST * S.thrust * (boosting ? CFG.BOOST : 1);
    sub.vx += ix * accel * dt;
    sub.vy += iy * accel * dt;
    if (!powered) sub.vy -= CFG.EMERGENCY_LIFT * dt;
    const drag = Math.exp(-CFG.DRAG * dt);
    sub.vx *= drag;
    sub.vy *= drag;

    if (run.towing) {
      const dx = CFG.VESSEL_X - sub.x;
      sub.vx = Math.sign(dx) * Math.min(CFG.TOW_SPEED, Math.abs(dx) * 1.5 + 30);
      sub.vy = 0;
    }

    sub.x += sub.vx * dt;
    sub.y += sub.vy * dt;

    const minX = 40, maxX = CFG.WORLD_W - 40;
    if (sub.x < minX || sub.x > maxX) { sub.x = clamp(sub.x, minX, maxX); sub.vx = 0; }
    if (sub.y < 0) { sub.y = 0; if (sub.vy < 0) sub.vy = 0; }

    // Seabed collision: test under the nose, centre and tail.
    const reach = CFG.SUB_HALF_W * 0.7;
    const floorY = Math.min(floorAt(sub.x - reach), floorAt(sub.x), floorAt(sub.x + reach)) - CFG.SUB_HALF_H;
    if (sub.y > floorY) {
      if (sub.vy > CFG.IMPACT_SPEED) damage((sub.vy - CFG.IMPACT_SPEED) * CFG.IMPACT_DAMAGE, 'impact');
      sub.y = floorY;
      if (sub.vy > 0) sub.vy *= -0.2;
      sub.vx *= Math.exp(-3 * dt); // sediment friction
    }

    // --- Attitude & effects ---
    if (ix) sub.facing = Math.sign(ix);
    sub.tilt = lerp(sub.tilt, clamp(sub.vy * 0.0018, -0.35, 0.35), 1 - Math.exp(-6 * dt));
    sub.thrust = load * (boosting ? 1.6 : 1);
    sub.prop += dt * (4 + sub.thrust * 26);
    if (sub.thrust > 0 && sub.y > 4 && Math.random() < dt * 40 * sub.thrust) spawnBubble();
    updateBubbles(dt);
    if (run.tether && (run.tether.t += dt) > 0.45) run.tether = null;
    run.shake = Math.max(0, run.shake - dt * 2.5);

    // --- Power ---
    if (!run.docked) {
      const drain = CFG.DRAIN_IDLE + load * CFG.DRAIN_THRUST + (boosting ? CFG.DRAIN_BOOST : 0);
      run.battery = Math.max(0, run.battery - drain * dt);
    }
    const battFrac = run.battery / S.batteryMax;
    if (!run.warned.battery && battFrac < 0.2 && run.battery > 0) {
      run.warned.battery = true;
      notify('Battery below 20%. Return to the recovery vessel.');
    }
    if (!run.emergency && run.battery <= 0) {
      run.emergency = true;
      run.autopilot = false;
      notify('Battery depleted. Ballast released — emergency ascent.');
    }
    if (run.emergency && !run.towing && !run.docked && sub.y <= 1) {
      run.towing = true;
      notify(`Surfaced without power. The vessel is towing you in (fee ${money(CFG.TOW_FEE)}).`);
    }

    // --- Pressure ---
    const m = depthM();
    const excess = m - S.hullRating;
    if (excess > 0) {
      damage(excess * CFG.HULL_STRESS_PER_M * dt, 'pressure');
      if (!run.warned.pressure) {
        run.warned.pressure = true;
        notify(`Below rated depth (${num(S.hullRating)} m). Hull under stress — ascend!`);
      }
    } else if (excess < -150) {
      run.warned.pressure = false;
    }
    if (m > profile.deepest) profile.deepest = m;

    // --- Sonar ---
    updateSonar(dt);

    // --- Docking ---
    const atVessel = sub.y <= 4 && Math.abs(sub.x - CFG.VESSEL_X) < CFG.DOCK_RANGE;
    if (atVessel && !run.docked) dock();
    else if (run.docked && (sub.y > 12 || Math.abs(sub.x - CFG.VESSEL_X) > CFG.DOCK_RANGE + 40)) run.docked = false;

    if (run.hull <= 0) loseSub();
  }

  function spawnBubble() {
    if (run.bubbles.length > 140) return;
    run.bubbles.push({
      x: sub.x - sub.facing * 72 + (Math.random() - 0.5) * 6,
      y: sub.y + (Math.random() - 0.5) * 10,
      vx: -sub.facing * (20 + Math.random() * 40),
      vy: -25 - Math.random() * 35,
      r: 1 + Math.random() * 2.5,
      life: 1.2 + Math.random() * 0.8,
      age: 0,
    });
  }

  function updateBubbles(dt) {
    const list = run.bubbles;
    for (let i = list.length - 1; i >= 0; i--) {
      const b = list[i];
      b.age += dt;
      b.vx *= Math.exp(-2 * dt);
      b.x += (b.vx + Math.sin((b.age + i) * 6) * 8) * dt;
      b.y += b.vy * dt;
      if (b.age > b.life || b.y < 0) list.splice(i, 1);
    }
  }

  function updateSonar(dt) {
    const s = run.sonar;
    s.cooldown = Math.max(0, s.cooldown - dt);
    if (s.t < 0) return;
    s.t += dt;
    const radius = s.t * CFG.SONAR_SPEED;
    for (const n of world.nodules) {
      if (n.collected || n.pingId === s.id) continue;
      if (Math.hypot(n.x - s.x, n.y - s.y) < Math.min(radius, S.sonarRange)) {
        n.pingId = s.id;
        n.pingedUntil = run.time + CFG.SONAR_MARK_TIME;
      }
    }
    if (radius > S.sonarRange) s.t = -1;
  }

  /* ======================================================================
   * 7. PLAYER ACTIONS
   * ==================================================================== */
  function collect() {
    if (run.state !== 'playing') return;
    const hit = nearestNodule(CFG.COLLECT_RANGE);
    if (!hit) { toast('No nodule in collection range — move closer.'); return; }
    const n = hit.n;
    if (cargoMass() + n.mass > S.cargoCap + 1e-6) {
      toast(`Hold full — ${n.mass.toFixed(1)} kg needed. Return to the vessel.`);
      return;
    }
    n.collected = true;
    run.cargo.push(n);
    run.tether = { x: n.x, y: n.y, t: 0 };
    cargoDirty = true;
    toast(`${n.dominant.name}-rich nodule recovered · ${n.grade.toFixed(0)}% grade · ${n.mass.toFixed(1)} kg`);
    updateHUD();
  }

  function pingSonar() {
    if (run.state !== 'playing') return;
    const s = run.sonar;
    if (s.cooldown > 0) { toast('Sonar recharging…'); return; }
    if (run.battery < CFG.SONAR_COST) { toast('Insufficient power for a sonar ping.'); return; }
    run.battery -= CFG.SONAR_COST;
    Object.assign(s, { t: 0, x: sub.x, y: sub.y, cooldown: CFG.SONAR_COOLDOWN, id: s.id + 1 });
  }

  function toggleAutopilot() {
    if (run.state !== 'playing') return;
    if (run.docked) { toast('Already docked at the recovery vessel.'); return; }
    if (run.emergency) { toast('No power — autopilot unavailable.'); return; }
    run.autopilot = !run.autopilot;
    toast(run.autopilot ? 'Autopilot engaged: returning to the recovery vessel.' : 'Autopilot disengaged.');
    updateHUD();
  }

  function dock() {
    run.docked = true;
    run.autopilot = false;
    sub.vx *= 0.3;
    sub.vy = 0;

    const parts = [];
    if (run.cargo.length) {
      const haul = cargoValue();
      profile.bank += haul;
      profile.earned += haul;
      profile.bestHaul = Math.max(profile.bestHaul, haul);
      profile.dives += 1;
      parts.push(`Cargo sold for ${money(haul)} at ${profile.market.toFixed(2)}× market`);
      run.cargo = [];
      cargoDirty = true;
      // New survey: fresh deposits and a new market price for next time.
      world.nodules = spawnNodules(noduleSeed());
      const drift = (Math.random() - 0.5) * 0.18;
      profile.market = clamp(profile.market * (1 + drift) + (1 - profile.market) * 0.15, 0.7, 1.4);
    }
    if (run.towing) {
      const fee = Math.min(profile.bank, CFG.TOW_FEE);
      profile.bank -= fee;
      parts.push(`tow fee ${money(fee)}`);
    }
    run.battery = S.batteryMax;
    run.hull = 100;
    run.emergency = run.towing = false;
    run.warned.pressure = run.warned.battery = false;
    persist();

    notify(parts.length ? `${parts.join(' · ')}. Recharged and repaired.` : 'Docked. Battery recharged and hull repaired.');
    updateHUD();
  }

  function loseSub() {
    const lostValue = cargoValue();
    const fee = Math.min(profile.bank, Math.max(CFG.LOSS_FEE_MIN, profile.bank * CFG.LOSS_FEE_RATE));
    profile.bank -= fee;
    run.cargo = [];
    cargoDirty = true;
    persist();
    $('lostText').textContent =
      `The hull failed at ${num(depthM())} m. ` +
      (lostValue > 0 ? `${money(lostValue)} of cargo went down with it. ` : '') +
      `A replacement submersible has been prepared at the recovery vessel` +
      (fee > 0 ? ` — salvage and replacement cost ${money(fee)}.` : '.');
    setState('lost');
  }

  function resetSub() {
    Object.assign(sub, { x: CFG.VESSEL_X + 70, y: 0, vx: 0, vy: 0, facing: 1, tilt: 0 });
    Object.assign(run, {
      battery: S.batteryMax, hull: 100, docked: true, autopilot: false,
      emergency: false, towing: false, tether: null, shake: 0,
    });
    run.bubbles.length = 0;
    run.warned.pressure = run.warned.battery = false;
    cam.x = sub.x; cam.y = 0;
  }

  function buyUpgrade(id) {
    const u = UPGRADES.find(x => x.id === id);
    const lvl = profile.upgrades[id];
    if (!u || lvl >= u.max) return;
    const cost = upgradeCost(u, lvl);
    if (profile.bank < cost) return;
    profile.bank -= cost;
    profile.upgrades[id] = lvl + 1;
    S = computeStats();
    run.battery = S.batteryMax; // only purchasable while docked
    persist();
    renderRefit();
    updateHUD();
    toast(`${u.name} upgraded to level ${lvl + 1}.`);
  }

  /* ======================================================================
   * 8. RENDERING
   * ==================================================================== */
  const canvas = $('game');
  const ctx = canvas.getContext('2d');
  const lightCanvas = document.createElement('canvas');
  const lctx = lightCanvas.getContext('2d');
  const LIGHT_RES = 0.5;
  const mini = { canvas: $('minimap'), ctx: null, w: 0, h: 0, path: null, timer: 0 };
  mini.ctx = mini.canvas.getContext('2d');
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const view = { W: 0, H: 0, dpr: 1 };
  let snow = [];
  let animTime = 0;

  const sx = x => (x - cam.x) * cam.zoom + view.W / 2;
  const sy = y => (y - cam.y) * cam.zoom + view.H * 0.5;
  const worldYAt = py => (py - view.H * 0.5) / cam.zoom + cam.y;

  function resize() {
    view.W = innerWidth;
    view.H = innerHeight;
    view.dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(view.W * view.dpr);
    canvas.height = Math.round(view.H * view.dpr);
    ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);

    lightCanvas.width = Math.ceil(view.W * LIGHT_RES);
    lightCanvas.height = Math.ceil(view.H * LIGHT_RES);
    lctx.setTransform(LIGHT_RES, 0, 0, LIGHT_RES, 0, 0);

    cam.zoom = clamp(Math.min(view.W, view.H * 1.4) / 1000, 0.55, 1.1);

    const count = Math.round(clamp((view.W * view.H) / 9000, 60, 220));
    snow = Array.from({ length: count }, () => ({
      x: Math.random(), y: Math.random(), z: 0.3 + Math.random() * 0.7,
      s: 0.5 + Math.random() * 1.6, a: 0.08 + Math.random() * 0.27,
    }));
    resizeMinimap();
  }

  function render() {
    const { W, H } = view;
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    if (run.shake > 0 && !reduceMotion) {
      const k = run.shake * 6;
      ctx.translate((Math.random() - 0.5) * k, (Math.random() - 0.5) * k);
    }
    drawWater();
    drawLightShafts();
    drawSnow();
    drawTerrain();
    drawNodules();
    drawVessel();
    drawBubbles();
    drawTether();
    drawSub();
    ctx.restore();

    drawDarkness();
    drawSonar();
    drawReticle();
    drawVesselPointer();
  }

  function drawWater() {
    const { W, H } = view;
    const surfY = sy(0);
    if (surfY > 0) {
      const sky = ctx.createLinearGradient(0, 0, 0, surfY);
      sky.addColorStop(0, '#0d2a3d');
      sky.addColorStop(1, '#5d9fb0');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, surfY);
    }
    const top = Math.max(0, surfY);
    if (top >= H) return;
    const g = ctx.createLinearGradient(0, top, 0, H);
    g.addColorStop(0, waterColor(Math.max(0, toM(worldYAt(top)))));
    g.addColorStop(1, waterColor(toM(worldYAt(H))));
    ctx.fillStyle = g;
    ctx.fillRect(0, top, W, H - top);

    if (surfY > -10 && surfY < H) {
      ctx.strokeStyle = 'rgba(200,240,245,.55)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 12) {
        const wx = (x - W / 2) / cam.zoom + cam.x;
        const y = surfY + Math.sin(wx * 0.03 + animTime * 1.8) * 2 * cam.zoom;
        x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.stroke();
    }
  }

  function drawLightShafts() {
    const alpha = 0.11 * (1 - clamp(toM(cam.y) / 1300, 0, 1));
    if (alpha <= 0.002) return;
    const { W, H } = view;
    const top = Math.max(0, sy(0));
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#b9f4f4';
    for (let i = 0; i < 9; i++) {
      const x = mod(i * (W / 7) - cam.x * cam.zoom * 0.4 + animTime * 5, W + 240) - 120;
      ctx.beginPath();
      ctx.moveTo(x, top);
      ctx.lineTo(x + 40, top);
      ctx.lineTo(x + 160, H);
      ctx.lineTo(x + 90, H);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  function drawSnow() {
    const { W, H } = view;
    const surfY = sy(0);
    ctx.fillStyle = '#9bc8d0';
    for (const p of snow) {
      const x = mod(p.x * W - cam.x * cam.zoom * p.z, W);
      const y = mod(p.y * H - cam.y * cam.zoom * p.z + animTime * 9 * p.z, H);
      if (y < surfY) continue;
      ctx.globalAlpha = p.a;
      ctx.fillRect(x, y, p.s, p.s);
    }
    ctx.globalAlpha = 1;
  }

  function drawTerrain() {
    const { W, H } = view;
    const z = cam.zoom;
    const x0 = cam.x - W / 2 / z - 24;
    const x1 = cam.x + W / 2 / z + 24;
    const step = Math.max(6, 10 / z);

    ctx.beginPath();
    ctx.moveTo(sx(x0), H + 5);
    for (let x = x0; x <= x1 + step; x += step) ctx.lineTo(sx(x), sy(floorAt(x)));
    ctx.lineTo(sx(x1 + step), H + 5);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, H * 0.3, 0, H);
    g.addColorStop(0, '#2b4142');
    g.addColorStop(1, '#0f1d23');
    ctx.fillStyle = g;
    ctx.fill();

    ctx.beginPath();
    for (let x = x0; x <= x1 + step; x += step) {
      const X = sx(x), Y = sy(floorAt(x));
      x === x0 ? ctx.moveTo(X, Y) : ctx.lineTo(X, Y);
    }
    ctx.strokeStyle = 'rgba(110,140,132,.55)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Rocks and sessile life, placed deterministically per 70-unit cell.
    const CELL = 70;
    for (let c = Math.floor(x0 / CELL); c <= Math.ceil(x1 / CELL); c++) {
      const h = hash(c);
      if (h > 0.45) continue;
      const rx = c * CELL + hash(c + 0.37) * CELL;
      const ry = floorAt(rx);
      const X = sx(rx), Y = sy(ry);
      if (h < 0.07) {
        // stalked sponge
        const len = (18 + hash(c * 3.1) * 26) * z;
        ctx.strokeStyle = '#7d9a91';
        ctx.lineWidth = 1.5 * z;
        ctx.beginPath();
        ctx.moveTo(X, Y);
        ctx.quadraticCurveTo(X + 6 * z, Y - len * 0.5, X + 2 * z, Y - len);
        ctx.stroke();
        ctx.fillStyle = '#c9d6c0';
        ctx.beginPath();
        ctx.arc(X + 2 * z, Y - len, 3 * z, 0, TAU);
        ctx.fill();
      } else {
        const rw = (8 + hash(c * 1.7) * 16) * z;
        const rh = (5 + hash(c * 2.3) * 8) * z;
        ctx.fillStyle = c % 3 ? '#304348' : '#455354';
        ctx.beginPath();
        ctx.ellipse(X, Y + rh * 0.35, rw, rh, 0, 0, TAU);
        ctx.fill();
      }
    }
  }

  function drawNodules() {
    const z = cam.zoom;
    const pad = 40;
    for (const n of world.nodules) {
      if (n.collected) continue;
      const X = sx(n.x), Y = sy(n.y);
      if (X < -pad || X > view.W + pad || Y < -pad || Y > view.H + pad) continue;
      const r = n.radius;
      ctx.save();
      ctx.translate(X, Y);
      ctx.scale(z, z);
      ctx.rotate(n.rot);
      ctx.beginPath();
      for (let k = 0; k < n.shape.length; k++) {
        const a = (k / n.shape.length) * TAU;
        const px = Math.cos(a) * r * n.shape[k] * 1.3;
        const py = Math.sin(a) * r * n.shape[k] * 0.85;
        k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, 1, 0, 0, r * 1.4);
      g.addColorStop(0, '#c1c2b0');
      g.addColorStop(0.45, '#697878');
      g.addColorStop(1, '#283b3e');
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = 'rgba(167,180,167,.7)';
      ctx.lineWidth = 1 / z;
      ctx.stroke();
      ctx.globalAlpha = 0.75;
      ctx.fillStyle = n.dominant.color;
      ctx.beginPath();
      ctx.arc(-r * 0.3, -r * 0.2, Math.max(1.2, r * 0.18), 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawVessel() {
    const z = cam.zoom;
    const X = sx(CFG.VESSEL_X);
    const Y = sy(0) + Math.sin(animTime * 1.3) * 2 * z;
    if (X < -260 * z || X > view.W + 260 * z || Y < -120 * z || Y > view.H + 60 * z) return;
    ctx.save();
    ctx.translate(X, Y);
    ctx.scale(z, z);
    ctx.rotate(Math.sin(animTime * 0.9) * 0.012);
    // hull
    ctx.fillStyle = '#1f3644';
    ctx.beginPath();
    ctx.moveTo(-135, -14); ctx.lineTo(150, -22); ctx.lineTo(126, 15); ctx.lineTo(-124, 15);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#a8432f';
    ctx.fillRect(-126, 6, 256, 9);
    // superstructure
    ctx.fillStyle = '#dfe7e9';
    ctx.fillRect(-5, -52, 78, 36);
    ctx.fillRect(15, -66, 40, 16);
    ctx.fillStyle = '#2f5566';
    for (let i = 0; i < 6; i++) ctx.fillRect(2 + i * 12, -44, 8, 7);
    ctx.fillRect(20, -61, 30, 6);
    // mast with blinking light
    ctx.strokeStyle = '#cfd8da';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(35, -66); ctx.lineTo(35, -92); ctx.stroke();
    ctx.fillStyle = Math.sin(animTime * 4) > 0 ? '#ff5d5d' : '#5a2525';
    ctx.beginPath(); ctx.arc(35, -94, 3, 0, TAU); ctx.fill();
    // A-frame launch crane and cable
    ctx.strokeStyle = '#e8bd72';
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(-118, -15); ctx.lineTo(-150, -64); ctx.lineTo(-100, -16); ctx.stroke();
    ctx.strokeStyle = '#9fb3b8';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(-150, -64); ctx.lineTo(-150, 0); ctx.stroke();
    ctx.fillStyle = '#e4f1f3';
    ctx.font = '700 9px system-ui, sans-serif';
    ctx.fillText('RV ABYSSAL', -88, -1);
    ctx.restore();
  }

  function drawBubbles() {
    ctx.strokeStyle = '#bfeef2';
    ctx.lineWidth = 1;
    for (const b of run.bubbles) {
      ctx.globalAlpha = 0.5 * (1 - b.age / b.life);
      ctx.beginPath();
      ctx.arc(sx(b.x), sy(b.y), b.r * cam.zoom, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  function drawTether() {
    const t = run.tether;
    if (!t) return;
    const c = clawPos();
    const k = t.t / 0.45;
    ctx.strokeStyle = `rgba(232,189,114,${1 - k})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(sx(c.x), sy(c.y));
    ctx.lineTo(sx(lerp(t.x, c.x, k)), sy(lerp(t.y, c.y, k)));
    ctx.stroke();
  }

  function drawSub() {
    const z = cam.zoom;
    ctx.save();
    ctx.translate(sx(sub.x), sy(sub.y));
    ctx.scale(sub.facing * z, z);
    ctx.rotate(sub.tilt);

    // faint lamp beam (the darkness pass does the real lighting)
    const beam = ctx.createRadialGradient(45, 0, 5, 120, 0, 220);
    beam.addColorStop(0, 'rgba(201,247,239,.18)');
    beam.addColorStop(1, 'rgba(183,247,233,0)');
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(48, -8); ctx.lineTo(260, -110); ctx.lineTo(260, 110); ctx.lineTo(48, 8);
    ctx.fill();

    // prop wash & propeller
    if (sub.thrust > 0) {
      ctx.fillStyle = `rgba(158,220,224,${0.15 + sub.thrust * 0.15})`;
      ctx.beginPath();
      ctx.ellipse(-86, 0, 10 + sub.thrust * 10, 6, 0, 0, TAU);
      ctx.fill();
    }
    ctx.fillStyle = '#8faab0';
    ctx.fillRect(-66, -7, 12, 14);
    ctx.fillStyle = '#c5d4d2';
    ctx.fillRect(-75, -4, 9, 8);
    const blade = Math.sin(sub.prop) * 11;
    ctx.fillStyle = '#dfe9e8';
    ctx.fillRect(-78, -Math.abs(blade), 3, Math.abs(blade) * 2);

    // hull
    const metal = ctx.createLinearGradient(0, -26, 0, 26);
    metal.addColorStop(0, '#d8e2df');
    metal.addColorStop(0.45, '#758f96');
    metal.addColorStop(1, '#263d49');
    ctx.fillStyle = metal;
    ctx.strokeStyle = '#d8e5e3';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-58, 0);
    ctx.quadraticCurveTo(-40, -24, 4, -24);
    ctx.lineTo(44, -16);
    ctx.quadraticCurveTo(62, 0, 44, 16);
    ctx.lineTo(4, 24);
    ctx.quadraticCurveTo(-40, 24, -58, 0);
    ctx.fill();
    ctx.stroke();

    // viewport
    ctx.fillStyle = '#244e60';
    ctx.beginPath();
    ctx.ellipse(10, -2, 18, 12, 0, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = '#9ce4e9';
    ctx.stroke();

    // fittings
    ctx.fillStyle = '#d6b36f';
    ctx.fillRect(-18, -28, 7, 8);
    ctx.fillRect(-18, 20, 7, 8);
    ctx.fillStyle = '#b5c6c5';
    ctx.fillRect(-5, -31, 7, 9);

    // manipulator arm
    ctx.strokeStyle = '#b5c6c5';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(14, 20); ctx.lineTo(22, 30); ctx.lineTo(30, 27);
    ctx.stroke();

    // lamp
    ctx.fillStyle = run.battery > 0 ? '#fff6d8' : '#555';
    ctx.beginPath();
    ctx.arc(50, 3, 3, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  /** Depth-based darkness with the sub's lamps cut out of it. */
  function drawDarkness() {
    const dark = clamp((toM(cam.y) - 150) / 2600, 0, 0.94);
    if (dark <= 0.01) return;
    const { W, H } = view;
    const z = cam.zoom;
    lctx.globalCompositeOperation = 'source-over';
    lctx.clearRect(0, 0, W, H);
    lctx.fillStyle = `rgba(1,6,12,${dark})`;
    lctx.fillRect(0, 0, W, H);

    if (run.battery > 0) {
      lctx.globalCompositeOperation = 'destination-out';
      const X = sx(sub.x), Y = sy(sub.y), R = S.light * z;

      let g = lctx.createRadialGradient(X, Y, 10 * z, X, Y, R * 0.6);
      g.addColorStop(0, 'rgba(0,0,0,.95)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = g;
      lctx.beginPath();
      lctx.arc(X, Y, R * 0.6, 0, TAU);
      lctx.fill();

      lctx.save();
      lctx.translate(X, Y);
      lctx.scale(sub.facing, 1);
      lctx.rotate(sub.tilt);
      g = lctx.createRadialGradient(40 * z, 0, 8 * z, 40 * z, 0, R * 1.3);
      g.addColorStop(0, 'rgba(0,0,0,1)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = g;
      lctx.beginPath();
      lctx.moveTo(40 * z, -10 * z);
      lctx.lineTo(R * 1.35, -R * 0.55);
      lctx.lineTo(R * 1.35, R * 0.55);
      lctx.lineTo(40 * z, 10 * z);
      lctx.closePath();
      lctx.fill();
      lctx.restore();
    }
    ctx.drawImage(lightCanvas, 0, 0, W, H);
  }

  function drawSonar() {
    const s = run.sonar;
    const z = cam.zoom;
    if (s.t >= 0) {
      const r = s.t * CFG.SONAR_SPEED;
      ctx.strokeStyle = `rgba(102,216,232,${0.6 * (1 - r / S.sonarRange)})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(sx(s.x), sy(s.y), r * z, 0, TAU);
      ctx.stroke();
    }
    for (const n of world.nodules) {
      if (n.collected || n.pingedUntil <= run.time) continue;
      const X = sx(n.x), Y = sy(n.y);
      if (X < -10 || X > view.W + 10 || Y < -10 || Y > view.H + 10) continue;
      const a = Math.min(1, (n.pingedUntil - run.time) / 1.5);
      const size = (3 + n.radius * 0.3) * z;
      ctx.globalAlpha = 0.9 * a;
      ctx.fillStyle = n.dominant.color;
      ctx.beginPath();
      ctx.moveTo(X, Y - size - 8 * z);
      ctx.lineTo(X + size * 0.7, Y - 8 * z);
      ctx.lineTo(X, Y + size - 8 * z);
      ctx.lineTo(X - size * 0.7, Y - 8 * z);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawReticle() {
    if (run.state === 'menu') return;
    const hit = nearestNodule(CFG.SCAN_RANGE);
    if (!hit) return;
    const { n, d } = hit;
    const X = sx(n.x), Y = sy(n.y), z = cam.zoom;
    const inRange = d <= CFG.COLLECT_RANGE;
    const fits = cargoMass() + n.mass <= S.cargoCap + 1e-6;
    const color = inRange ? (fits ? '#e8bd72' : '#ff7777') : '#66d8e8';

    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.lineDashOffset = -animTime * 12;
    ctx.beginPath();
    ctx.arc(X, Y, (n.radius * 1.4 + 10) * z, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);

    const lines = [
      `${n.dominant.name.toUpperCase()} · ${n.grade.toFixed(0)}% GRADE`,
      `${n.mass.toFixed(1)} KG · ${n.purity.toFixed(0)}% PURITY · EST. ${money(n.value * profile.market)}`,
      inRange ? (fits ? 'SPACE TO COLLECT' : 'HOLD FULL') : 'MOVE CLOSER',
    ];
    ctx.font = '600 11px system-ui, sans-serif';
    const w = Math.max(...lines.map(l => ctx.measureText(l).width)) + 16;
    let bx = X + 22, by = Y - 62;
    if (bx + w > view.W - 8) bx = X - 22 - w;
    by = clamp(by, 8, view.H - 60);
    ctx.fillStyle = 'rgba(4,17,29,.82)';
    ctx.strokeStyle = 'rgba(151,201,214,.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(bx, by, w, 52, 6) : ctx.rect(bx, by, w, 52);
    ctx.fill();
    ctx.stroke();
    lines.forEach((l, i) => {
      ctx.fillStyle = i === 2 ? color : i === 0 ? '#f3d69c' : '#c6d9df';
      ctx.fillText(l, bx + 8, by + 16 + i * 15);
    });
  }

  /** Edge-of-screen arrow towards the recovery vessel when it is off-screen. */
  function drawVesselPointer() {
    if (run.state === 'menu' || run.docked) return;
    const { W, H } = view;
    const vx = sx(CFG.VESSEL_X), vy = sy(-20);
    const margin = 46;
    if (vx > margin && vx < W - margin && vy > margin && vy < H - margin) return;
    const cx = W / 2, cy = H / 2;
    const dx = vx - cx, dy = vy - cy;
    const t = Math.min((W / 2 - margin) / Math.abs(dx || 1e-6), (H / 2 - margin) / Math.abs(dy || 1e-6));
    const px = cx + dx * t, py = cy + dy * t;
    const ang = Math.atan2(dy, dx);
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(ang);
    ctx.fillStyle = 'rgba(232,189,114,.9)';
    ctx.beginPath();
    ctx.moveTo(12, 0); ctx.lineTo(-6, -8); ctx.lineTo(-6, 8);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    const dist = toM(Math.hypot(CFG.VESSEL_X - sub.x, sub.y));
    ctx.font = '600 10px system-ui, sans-serif';
    ctx.fillStyle = '#f3d69c';
    const label = `VESSEL ${num(dist)} m`;
    const lw = ctx.measureText(label).width;
    ctx.fillText(label, clamp(px - lw / 2, 6, W - lw - 6), clamp(py + (py > cy ? -16 : 24), 14, H - 8));
  }

  /* --- Minimap --- */
  function resizeMinimap() {
    const rect = mini.canvas.getBoundingClientRect();
    mini.w = Math.max(1, rect.width);
    mini.h = Math.max(1, rect.height);
    mini.canvas.width = Math.round(mini.w * view.dpr);
    mini.canvas.height = Math.round(mini.h * view.dpr);
    mini.ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
    buildMinimapPath();
  }
  const mmx = x => (x / CFG.WORLD_W) * mini.w;
  const mmy = y => 4 + (y / toUnits(CFG.FLOOR_MAX_M + 200)) * (mini.h - 6);

  function buildMinimapPath() {
    if (!world.floor || !mini.w) return;
    const p = new Path2D();
    p.moveTo(0, mini.h);
    const step = Math.max(1, Math.floor(world.floor.length / mini.w));
    for (let i = 0; i < world.floor.length; i += step) p.lineTo(mmx(i * CFG.FLOOR_STEP), mmy(world.floor[i]));
    p.lineTo(mini.w, mini.h);
    p.closePath();
    mini.path = p;
  }

  function drawMinimap() {
    const c = mini.ctx, w = mini.w, h = mini.h;
    if (!mini.path) return;
    c.clearRect(0, 0, w, h);
    c.fillStyle = '#21393a';
    c.fill(mini.path);

    const ratingY = mmy(toUnits(S.hullRating));
    if (ratingY < h) {
      c.strokeStyle = 'rgba(255,119,119,.6)';
      c.setLineDash([3, 3]);
      c.lineWidth = 1;
      c.beginPath(); c.moveTo(0, ratingY); c.lineTo(w, ratingY); c.stroke();
      c.setLineDash([]);
    }
    for (const n of world.nodules) {
      if (n.collected || n.pingedUntil <= run.time) continue;
      c.fillStyle = n.dominant.color;
      c.fillRect(mmx(n.x) - 1, mmy(n.y) - 2, 2, 2);
    }
    c.fillStyle = '#dfe7e9';
    c.fillRect(mmx(CFG.VESSEL_X) - 4, 1, 8, 3);
    c.fillStyle = '#e8bd72';
    c.beginPath();
    c.arc(mmx(sub.x), mmy(sub.y), 3, 0, TAU);
    c.fill();
  }

  /* ======================================================================
   * 9. HUD & MENUS
   * ==================================================================== */
  const ui = {};
  for (const id of ['hullText', 'hullBar', 'hullMeter', 'batteryText', 'batteryBar', 'batteryMeter',
    'cargoText', 'cargoBar', 'valueText', 'bankText', 'depthText', 'altText', 'ratingText',
    'zoneText', 'marketText', 'objective', 'cargoList', 'autopilotBtn', 'refitBtn', 'pauseBtn']) ui[id] = $(id);

  const lastValues = new Map();
  /** Only touch the DOM when a value actually changes. */
  function set(el, prop, value) {
    const key = el.id + '.' + prop;
    if (lastValues.get(key) === value) return;
    lastValues.set(key, value);
    if (prop === 'text') el.textContent = value;
    else if (prop === 'width') el.style.width = value;
    else el[prop] = value;
  }

  let cargoDirty = true;

  function updateHUD() {
    const battPct = (run.battery / S.batteryMax) * 100;
    const m = depthM();
    set(ui.hullText, 'text', `${Math.ceil(run.hull)}%`);
    set(ui.hullBar, 'width', `${run.hull}%`);
    ui.hullMeter.classList.toggle('danger', run.hull < 35);
    set(ui.batteryText, 'text', `${Math.ceil(battPct)}%`);
    set(ui.batteryBar, 'width', `${battPct}%`);
    ui.batteryMeter.classList.toggle('danger', battPct < 20);
    const mass = cargoMass();
    set(ui.cargoText, 'text', `${mass.toFixed(1)} / ${S.cargoCap} kg`);
    set(ui.cargoBar, 'width', `${Math.min(100, (mass / S.cargoCap) * 100)}%`);
    set(ui.valueText, 'text', money(cargoValue()));
    set(ui.bankText, 'text', money(profile.bank));

    set(ui.depthText, 'text', num(m));
    const alt = altitudeM();
    set(ui.altText, 'text', alt < 5 ? 'ON SEABED' : `${num(alt)} m`);
    set(ui.ratingText, 'text', `${num(S.hullRating)} m`);
    ui.ratingText.classList.toggle('warn', m > S.hullRating);
    set(ui.zoneText, 'text', zoneFor(m));
    set(ui.marketText, 'text', `${profile.market.toFixed(2)}×`);
    set(ui.objective, 'text', objectiveText());

    set(ui.autopilotBtn, 'disabled', run.docked || run.emergency || run.state !== 'playing');
    set(ui.autopilotBtn, 'text', run.autopilot ? 'AUTOPILOT ON' : 'AUTOPILOT HOME');
    ui.autopilotBtn.classList.toggle('active', run.autopilot);
    set(ui.refitBtn, 'disabled', !run.docked || run.state !== 'playing');

    if (cargoDirty) renderCargo();
  }

  function renderCargo() {
    cargoDirty = false;
    if (!run.cargo.length) {
      ui.cargoList.innerHTML = '<div class="ore"><b>No samples aboard</b><span>—</span></div>';
      return;
    }
    const groups = new Map();
    for (const n of run.cargo) {
      const g = groups.get(n.dominant) || { metal: n.dominant, count: 0, mass: 0, value: 0 };
      g.count++; g.mass += n.mass; g.value += n.value;
      groups.set(n.dominant, g);
    }
    ui.cargoList.innerHTML = [...groups.values()]
      .sort((a, b) => b.value - a.value)
      .map(g => `<div class="ore"><b><i class="dot" style="background:${g.metal.color}"></i>${g.metal.sym} ×${g.count} · ${g.mass.toFixed(1)} kg</b><span>${money(g.value * profile.market)}</span></div>`)
      .join('');
  }

  function objectiveText() {
    const m = depthM();
    if (run.towing) return 'The recovery vessel is towing you in. A tow fee will be charged.';
    if (run.emergency) return 'Battery depleted. Ballast released — rising to the surface.';
    if (m > S.hullRating) return `Below rated depth (${num(S.hullRating)} m). Hull under stress — ascend!`;
    if (run.hull < 35) return 'Hull integrity critical. Return to the vessel for repairs.';
    if (run.docked) {
      return profile.dives === 0
        ? 'Head east (D / →) and descend. Nodules lie on the seabed — the deep trenches hold the richest deposits.'
        : 'Docked: recharged and repaired. Visit the refit bay, then head out for another dive.';
    }
    if (S.cargoCap - cargoMass() < 0.8) return 'Hold full. Return to the recovery vessel (R for autopilot).';
    if (run.battery / S.batteryMax < 0.25) return 'Battery low. Return to the recovery vessel before power runs out.';
    if (run.cargo.length) return 'Keep searching, or return to the vessel to sell your cargo.';
    return 'Ping sonar (E) to find nodules in the dark. Get close and press SPACE to collect.';
  }

  /* --- State machine for menus --- */
  const MODALS = { menu: 'menuModal', paused: 'pauseModal', refit: 'refitModal', lost: 'lostModal' };

  function setState(state) {
    run.state = state;
    for (const [s, id] of Object.entries(MODALS)) $(id).hidden = s !== state;
    $('overlay').hidden = state === 'playing';
    if (state !== 'playing') clearHeld();
    if (state === 'menu') renderMenu();
    if (state === 'refit') renderRefit();
    const focusTarget = { menu: 'startBtn', paused: 'resumeBtn', refit: 'refitClose', lost: 'lostBtn' }[state];
    if (focusTarget) $(focusTarget).focus({ preventScroll: true });
    else if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    updateHUD();
  }

  function togglePause() {
    if (run.state === 'playing') setState('paused');
    else if (run.state === 'paused') setState('playing');
  }

  function onEscape() {
    if (run.state === 'refit' || run.state === 'paused') setState('playing');
    else if (run.state === 'playing') setState('paused');
  }

  function renderMenu() {
    const progress = hasProgress();
    $('startBtn').textContent = progress ? 'CONTINUE OPERATIONS' : 'BEGIN DIVE';
    $('resetBtn').hidden = !progress;
    const career = $('careerText');
    career.hidden = !progress;
    if (progress) {
      career.textContent = `Account ${money(profile.bank)} · ${profile.dives} successful dive${profile.dives === 1 ? '' : 's'} · ` +
        `best haul ${money(profile.bestHaul)} · deepest ${num(profile.deepest)} m`;
    }
  }

  function renderRefit() {
    $('refitBank').textContent = money(profile.bank);
    $('refitList').innerHTML = UPGRADES.map(u => {
      const lvl = profile.upgrades[u.id];
      const maxed = lvl >= u.max;
      const cost = upgradeCost(u, lvl);
      return `<div class="upgrade">
          <div>
            <b>${u.name}</b><span class="lvl">${'●'.repeat(lvl)}${'○'.repeat(u.max - lvl)}</span>
            <div class="fx">${u.effect(lvl)}${maxed ? '' : ` → <em>${u.effect(lvl + 1)}</em>`}</div>
          </div>
          <button type="button" data-buy="${u.id}" ${maxed || profile.bank < cost ? 'disabled' : ''}>${maxed ? 'MAX' : money(cost)}</button>
        </div>`;
    }).join('');
  }

  function initUI() {
    const onClick = (id, fn) => $(id).addEventListener('click', e => { e.currentTarget.blur(); fn(); });

    onClick('startBtn', () => {
      setState('playing');
      notify(profile.dives ? 'Dive authorised. Good hunting.' : 'Dive authorised. Head east and descend to the seabed.');
    });
    $('howBtn').addEventListener('click', () => {
      const how = $('howText');
      how.hidden = !how.hidden;
      $('howBtn').setAttribute('aria-expanded', String(!how.hidden));
    });
    onClick('resetBtn', () => {
      if (!confirm('Reset all progress, money and upgrades? This cannot be undone.')) return;
      storage.clear();
      profile = defaultProfile();
      S = computeStats();
      newWorld();
      resetSub();
      run.cargo = [];
      cargoDirty = true;
      renderMenu();
      updateHUD();
    });
    onClick('resumeBtn', () => setState('playing'));
    onClick('pauseBtn', togglePause);
    onClick('autopilotBtn', toggleAutopilot);
    onClick('refitBtn', () => { if (run.docked && run.state === 'playing') setState('refit'); });
    onClick('refitClose', () => setState('playing'));
    onClick('lostBtn', () => { resetSub(); setState('playing'); });
    $('refitList').addEventListener('click', e => {
      const btn = e.target.closest('[data-buy]');
      if (btn) buyUpgrade(btn.dataset.buy);
    });
  }

  /* --- Notifications (single timer each, de-duplicated) --- */
  function makeFlash(el, ms) {
    let timer = 0, lastText = '', lastAt = 0;
    return text => {
      const now = performance.now();
      if (text === lastText && now - lastAt < ms) return;
      lastText = text;
      lastAt = now;
      el.textContent = text;
      el.classList.add('show');
      clearTimeout(timer);
      timer = setTimeout(() => el.classList.remove('show'), ms);
    };
  }
  const toast = makeFlash($('toast'), 2300);
  const notify = makeFlash($('message'), 3000);

  /* ======================================================================
   * 10. BOOT & MAIN LOOP
   * ==================================================================== */
  function newWorld() {
    world.floor = buildTerrain(profile.seed);
    world.nodules = spawnNodules(noduleSeed());
    buildMinimapPath();
  }

  function updateCamera(dt) {
    const k = 1 - Math.exp(-4 * dt);
    cam.x = lerp(cam.x, sub.x + sub.vx * 0.3, k);
    cam.y = lerp(cam.y, sub.y + 30, k);
  }

  let last = performance.now(), acc = 0, hudTimer = 0;
  function frame(now) {
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    animTime += dt;

    if (run.state === 'playing') {
      acc += dt;
      while (acc >= CFG.STEP) { update(CFG.STEP); acc -= CFG.STEP; }
      updateCamera(dt);
    } else {
      acc = 0;
    }

    render();
    mini.timer += dt;
    if (mini.timer > 1 / 20) { mini.timer = 0; drawMinimap(); }
    hudTimer += dt;
    if (hudTimer > CFG.HUD_INTERVAL) { hudTimer = 0; updateHUD(); }
    requestAnimationFrame(frame);
  }

  newWorld();
  resize();
  addEventListener('resize', resize);
  initInput();
  initUI();
  resetSub();
  setState('menu');
  requestAnimationFrame(t => { last = t; frame(t); });
})();
