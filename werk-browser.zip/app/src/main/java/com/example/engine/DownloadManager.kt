package com.example.engine

import com.example.data.model.DownloadItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object DownloadManager {

    private val _downloads = MutableStateFlow(
        listOf(
            DownloadItem(
                id = UUID.randomUUID().toString(),
                fileName = "BSI_Lagebericht_IT_Sicherheit_2026.pdf",
                fileSizeBytes = 4820000L,
                downloadedBytes = 4820000L,
                progressPercent = 100,
                url = "https://bsi.bund.de/publikationen/lagebericht2026.pdf",
                isCompleted = true,
                isPaused = false,
                securityScanned = true,
                destinationPath = "/storage/emulated/0/Download/WERK/"
            ),
            DownloadItem(
                id = UUID.randomUUID().toString(),
                fileName = "DIN_EN_ISO_9001_Normenauszug.pdf",
                fileSizeBytes = 1250000L,
                downloadedBytes = 1250000L,
                progressPercent = 100,
                url = "https://beuth.de/din-en-iso-9001.pdf",
                isCompleted = true,
                isPaused = false,
                securityScanned = true,
                destinationPath = "/storage/emulated/0/Download/WERK/"
            )
        )
    )
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    fun addDownload(fileName: String, url: String, sizeBytes: Long = 2500000L) {
        val newItem = DownloadItem(
            id = UUID.randomUUID().toString(),
            fileName = fileName,
            fileSizeBytes = sizeBytes,
            downloadedBytes = sizeBytes,
            progressPercent = 100,
            url = url,
            isCompleted = true,
            isPaused = false,
            securityScanned = true,
            destinationPath = "/storage/emulated/0/Download/WERK/"
        )
        _downloads.value = listOf(newItem) + _downloads.value
    }
}
