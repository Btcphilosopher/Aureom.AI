package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.model.SecurityInfo
import com.example.privacy.PrivacyEngine
import java.io.ByteArrayInputStream

interface BrowserEngineListener {
    fun onPageStarted(url: String)
    fun onPageFinished(url: String, title: String?)
    fun onProgressChanged(progress: Int)
    fun onTrackerBlocked(url: String, trackerDomain: String)
    fun onSecurityUpdated(securityInfo: SecurityInfo)
}

object BrowserEngineAdapter {

    @SuppressLint("SetJavaScriptEnabled")
    fun setupWebView(
        webView: WebView,
        listener: BrowserEngineListener
    ) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.userAgentString = "${settings.userAgentString} WERK-Browser/1.0 (European-Privacy-Edition)"

        // Cookie Manager: Third-party Cookie Schutz
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, false) // Block third-party cookies

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                listener.onProgressChanged(newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                url?.let {
                    listener.onPageStarted(it)
                    val isHttps = it.startsWith("https://", ignoreCase = true)
                    listener.onSecurityUpdated(
                        SecurityInfo(
                            isHttps = isHttps,
                            certificateValid = isHttps,
                            tlsVersion = if (isHttps) "TLS 1.3 (Modern)" else "Keine (Unverschlüsselt)",
                            cipherSuite = if (isHttps) "ChaCha20-Poly1305" else "Klartext",
                            issuer = if (isHttps) "Zertifizierte CA" else "Keine",
                            mixedContentBlocked = true
                        )
                    )
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                url?.let {
                    val title = view?.title ?: it
                    listener.onPageFinished(it, title)

                    // Datenschutz-Injektion (GPC & Cookie-Consent Automatisierung)
                    view?.evaluateJavascript(PrivacyEngine.getPrivacyInjectionScript(), null)
                    view?.evaluateJavascript(PrivacyEngine.getCookieBannerAutoDeclineScript(), null)
                }
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val reqUrl = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                val mainHost = try { view?.url?.let { java.net.URI(it).host } } catch (e: Exception) { null }

                val evaluation = PrivacyEngine.evaluateUrl(reqUrl, mainHost)
                if (evaluation.shouldBlock) {
                    listener.onTrackerBlocked(reqUrl, evaluation.details)
                    // Blockiere Anfrage durch Rückgabe einer leeren Antwort
                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream("".toByteArray()))
                }

                return super.shouldInterceptRequest(view, request)
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                // Strict Security: Niemals ungeprüft fehlerhafte Zertifikate akzeptieren
                handler?.cancel()
                listener.onSecurityUpdated(
                    SecurityInfo(
                        isHttps = false,
                        certificateValid = false,
                        tlsVersion = "SSL Fehler",
                        cipherSuite = "Ungültig",
                        issuer = "Nicht vertrauenswürdig",
                        mixedContentBlocked = true
                    )
                )
            }
        }
    }
}
