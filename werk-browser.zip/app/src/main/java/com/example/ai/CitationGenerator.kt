package com.example.ai

import com.example.data.model.ResearchDocument
import com.example.language.GermanTypography

object CitationGenerator {

    enum class CitationFormat(val label: String) {
        DIN_ISO_690("DIN ISO 690 (Deutsch)"),
        APA("APA 7th Edition"),
        MLA("MLA 9th Edition"),
        CHICAGO("Chicago Manual of Style"),
        DEUTSCHE_FUSSNOTE("Deutsche Fußnotenzitierweise")
    }

    fun format(doc: ResearchDocument, format: CitationFormat): String {
        val author = doc.author.ifBlank { "O. V." }
        val title = doc.title
        val year = doc.dateOrYear.ifBlank { "2026" }
        val url = doc.url
        val accessDate = GermanTypography.formatDate(doc.savedAt)

        return when (format) {
            CitationFormat.DIN_ISO_690 -> {
                "${author.uppercase()}. ${title}. [Online]. Berlin/Brüssel, ${year}. Verfügbar unter: <${url}> [Abgerufen am: ${accessDate}]."
            }
            CitationFormat.APA -> {
                "$author ($year). $title. Abgerufen am $accessDate von $url"
            }
            CitationFormat.MLA -> {
                "$author. \"$title.\" WERK Informationsarchiv, $year, $url. Zugegriffen $accessDate."
            }
            CitationFormat.CHICAGO -> {
                "$author. \"$title.\" Zuletzt geändert $year. Zugriff am $accessDate. $url."
            }
            CitationFormat.DEUTSCHE_FUSSNOTE -> {
                "Vgl. $author: $title, $year, online: $url (Stand: $accessDate)."
            }
        }
    }

    fun toBibTeX(doc: ResearchDocument): String {
        val cleanKey = (doc.author.split(" ").lastOrNull() ?: "werk")
            .filter { it.isLetter() }.lowercase() + doc.dateOrYear.filter { it.isDigit() }
        val accessDate = GermanTypography.formatDate(doc.savedAt)
        return """
            @online{$cleanKey,
              author = {${doc.author}},
              title = {${doc.title}},
              year = {${doc.dateOrYear}},
              url = {${doc.url}},
              urldate = {$accessDate}
            }
        """.trimIndent()
    }
}
