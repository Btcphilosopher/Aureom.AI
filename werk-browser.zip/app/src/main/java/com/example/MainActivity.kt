package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.ActiveScreen
import com.example.ui.WerkViewModel
import com.example.ui.components.QuickActionMenuDialog
import com.example.ui.components.TabsBar
import com.example.ui.components.TabsOverviewDialog
import com.example.ui.components.Universalzeile
import com.example.ui.components.WerkBottomBar
import com.example.ui.screens.WerkBrowserScreen
import com.example.ui.screens.WerkCompareScreen
import com.example.ui.screens.WerkDiagnosticsScreen
import com.example.ui.screens.WerkHistoryBookmarksScreen
import com.example.ui.screens.WerkPerformanceScreen
import com.example.ui.screens.WerkPrivacyScreen
import com.example.ui.screens.WerkReaderScreen
import com.example.ui.screens.WerkResearchScreen
import com.example.ui.screens.WerkSecurityScreen
import com.example.ui.screens.WerkSettingsScreen
import com.example.ui.screens.WerkStartScreen
import com.example.ui.screens.WerkTranslationScreen
import com.example.ui.theme.WerkTheme

class MainActivity : ComponentActivity() {

    private val viewModel: WerkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            WerkTheme {
                WerkBrowserApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun WerkBrowserApp(viewModel: WerkViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    val activeTab = viewModel.activeTab

    val universalInput by viewModel.universalInput.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val compoundAnalysis by viewModel.searchCompoundAnalysis.collectAsState()
    val spellSuggestions by viewModel.spellSuggestions.collectAsState()
    val calcPreview by viewModel.calcPreview.collectAsState()

    val readerArticle by viewModel.readerArticle.collectAsState()
    val readerSettings by viewModel.readerSettings.collectAsState()
    val savedResearchDocs by viewModel.savedResearchDocs.collectAsState(initial = emptyList())
    val historyList by viewModel.historyList.collectAsState(initial = emptyList())
    val bookmarksList by viewModel.bookmarksList.collectAsState(initial = emptyList())
    val privacyStats by viewModel.privacyStats.collectAsState()
    val privacyEvents by viewModel.privacyEvents.collectAsState(initial = emptyList())
    val bilingualTranslation by viewModel.bilingualTranslation.collectAsState()
    val compareSourceA by viewModel.compareSourceA.collectAsState()
    val compareSourceB by viewModel.compareSourceB.collectAsState()
    val aiReport by viewModel.aiReport.collectAsState()

    var showTabsOverview by remember { mutableStateOf(false) }
    var showQuickMenu by remember { mutableStateOf(false) }

    val isCurrentBookmarked = bookmarksList.any { it.url == activeTab.url }

    // System BackHandler
    BackHandler(enabled = currentScreen != ActiveScreen.START_PAGE || showTabsOverview || showQuickMenu) {
        if (showQuickMenu) {
            showQuickMenu = false
        } else if (showTabsOverview) {
            showTabsOverview = false
        } else if (currentScreen != ActiveScreen.START_PAGE) {
            viewModel.navigateToInternal("start")
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                // Obere Universalzeile
                Universalzeile(
                    input = universalInput,
                    onInputChange = { viewModel.onUniversalInputChange(it) },
                    onSubmit = { viewModel.submitUniversalInput() },
                    onRefresh = { viewModel.loadUrl(activeTab.url) },
                    onOpenReader = { viewModel.openReaderMode() },
                    onOpenSecurity = { viewModel.navigateToInternal("sicherheit") },
                    securityInfo = activeTab.securityInfo,
                    compoundAnalysis = compoundAnalysis,
                    spellSuggestions = spellSuggestions,
                    calcPreview = calcPreview,
                    isLoading = activeTab.isLoading
                )

                // Horizontale Tab-Leiste
                TabsBar(
                    tabs = tabs,
                    activeTabId = activeTabId,
                    onSelectTab = { viewModel.selectTab(it) },
                    onCloseTab = { viewModel.closeTab(it) },
                    onNewTab = { viewModel.addNewTab() },
                    onOpenTabsOverview = { showTabsOverview = true }
                )
            }
        },
        bottomBar = {
            WerkBottomBar(
                canGoBack = currentScreen != ActiveScreen.START_PAGE,
                canGoForward = false,
                tabCount = tabs.size,
                isBookmarked = isCurrentBookmarked,
                onBack = {
                    if (currentScreen != ActiveScreen.START_PAGE) {
                        viewModel.navigateToInternal("start")
                    }
                },
                onForward = {},
                onHome = { viewModel.navigateToInternal("start") },
                onTabsClick = { showTabsOverview = true },
                onBookmarkToggle = { viewModel.toggleBookmarkCurrentPage() },
                onMenuClick = { showQuickMenu = true }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ActiveScreen.START_PAGE -> {
                    WerkStartScreen(
                        onNavigateUrl = { viewModel.loadUrl(it) },
                        onNavigateScreen = { screen ->
                            when (screen) {
                                ActiveScreen.RESEARCH_WORKSPACE -> viewModel.navigateToInternal("recherche")
                                ActiveScreen.PRIVACY_CENTER -> viewModel.navigateToInternal("datenschutz")
                                ActiveScreen.HISTORY_BOOKMARKS -> viewModel.navigateToInternal("lesezeichen")
                                else -> {}
                            }
                        }
                    )
                }
                ActiveScreen.BROWSER_WEB -> {
                    WerkBrowserScreen(
                        tab = activeTab,
                        searchResults = searchResults,
                        onOpenReader = { viewModel.openReaderMode() },
                        onSummarizeAi = { viewModel.summarizeCurrentPage() },
                        onTranslate = { viewModel.translateCurrentPage() },
                        onSaveResearch = { title, snippet ->
                            viewModel.saveToResearch(title = title, snippet = snippet)
                        },
                        onExtractTables = { viewModel.extractTablesCurrentPage() },
                        onPageStarted = { url -> viewModel.loadUrl(url) },
                        onPageFinished = { url, title -> viewModel.updateTabContent(activeTab.id, url, title ?: url, null) },
                        onProgressChanged = {},
                        onTrackerBlocked = { site, tracker -> viewModel.recordBlockedTracker(site, tracker) }
                    )
                }
                ActiveScreen.READER_MODE -> {
                    WerkReaderScreen(
                        article = readerArticle,
                        settings = readerSettings,
                        ttsManager = viewModel.ttsManager,
                        onUpdateSettings = { viewModel.updateReaderSettings(it) },
                        onCloseReader = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.RESEARCH_WORKSPACE -> {
                    WerkResearchScreen(
                        savedDocs = savedResearchDocs,
                        aiReport = aiReport,
                        onDeleteDoc = { viewModel.deleteResearchDoc(it) },
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.COMPARE_VIEW -> {
                    WerkCompareScreen(
                        sourceA = compareSourceA,
                        sourceB = compareSourceB,
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.PRIVACY_CENTER -> {
                    WerkPrivacyScreen(
                        stats = privacyStats,
                        recentEvents = privacyEvents,
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.SECURITY_CENTER -> {
                    WerkSecurityScreen(
                        securityInfo = activeTab.securityInfo,
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.PERFORMANCE_CENTER -> {
                    WerkPerformanceScreen(
                        tabs = tabs,
                        onSuspendTab = { viewModel.suspendTab(it) },
                        onResumeTab = { viewModel.resumeTab(it) },
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.DIAGNOSTICS -> {
                    WerkDiagnosticsScreen(
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.SETTINGS -> {
                    WerkSettingsScreen(
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.HISTORY_BOOKMARKS -> {
                    WerkHistoryBookmarksScreen(
                        historyList = historyList,
                        bookmarksList = bookmarksList,
                        onSelectUrl = { viewModel.loadUrl(it) },
                        onDeleteHistoryItem = { viewModel.deleteHistoryEntry(it) },
                        onClearHistory = { viewModel.clearHistory() },
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
                ActiveScreen.TRANSLATOR -> {
                    WerkTranslationScreen(
                        initialResult = bilingualTranslation,
                        onClose = { viewModel.navigateToInternal("start") }
                    )
                }
            }

            // Dialoge
            if (showTabsOverview) {
                TabsOverviewDialog(
                    tabs = tabs,
                    activeTabId = activeTabId,
                    onSelectTab = { viewModel.selectTab(it) },
                    onCloseTab = { viewModel.closeTab(it) },
                    onNewTab = {
                        viewModel.addNewTab()
                        showTabsOverview = false
                    },
                    onTogglePin = { viewModel.togglePinTab(it) },
                    onDismiss = { showTabsOverview = false }
                )
            }

            if (showQuickMenu) {
                QuickActionMenuDialog(
                    onNavigate = { screen ->
                        when (screen) {
                            ActiveScreen.RESEARCH_WORKSPACE -> viewModel.navigateToInternal("recherche")
                            ActiveScreen.READER_MODE -> viewModel.openReaderMode()
                            ActiveScreen.TRANSLATOR -> viewModel.translateCurrentPage()
                            ActiveScreen.COMPARE_VIEW -> viewModel.navigateToInternal("vergleich")
                            ActiveScreen.PRIVACY_CENTER -> viewModel.navigateToInternal("datenschutz")
                            ActiveScreen.SECURITY_CENTER -> viewModel.navigateToInternal("sicherheit")
                            ActiveScreen.PERFORMANCE_CENTER -> viewModel.navigateToInternal("performance")
                            ActiveScreen.DIAGNOSTICS -> viewModel.navigateToInternal("diagnose")
                            ActiveScreen.HISTORY_BOOKMARKS -> viewModel.navigateToInternal("lesezeichen")
                            ActiveScreen.SETTINGS -> viewModel.navigateToInternal("einstellungen")
                            else -> {}
                        }
                    },
                    onOpenReader = { viewModel.openReaderMode() },
                    onDismiss = { showQuickMenu = false }
                )
            }
        }
    }
}
