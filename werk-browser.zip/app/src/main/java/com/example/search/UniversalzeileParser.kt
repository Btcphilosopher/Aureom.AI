package com.example.search

import com.example.language.GermanCompoundAnalyzer
import com.example.language.GermanTypography
import java.util.Locale

sealed class UniversalInputType {
    data class DirectUrl(val url: String) : UniversalInputType()
    data class InternalPage(val destination: String) : UniversalInputType()
    data class Command(val command: String, val argument: String) : UniversalInputType()
    data class Calculation(val expression: String, val result: Double, val formatted: String) : UniversalInputType()
    data class SearchQuery(
        val query: String,
        val expandedTokens: List<String>,
        val multilingualSuggestion: String? = null
    ) : UniversalInputType()
}

object UniversalzeileParser {

    private val INTERNAL_PAGES = setOf(
        "start", "recherche", "datenschutz", "sicherheit", "performance",
        "diagnose", "einstellungen", "lesezeichen", "verlauf", "downloads", "vergleich"
    )

    private val COMMAND_PREFIXES = listOf(
        "/suche", "/verlauf", "/lesezeichen", "/downloads", "/einstellungen",
        "/datenschutz", "/sicherheit", "/übersetzen", "/uebersetzen", "/zusammenfassen",
        "/recherche", "/vergleich", "/rechner", "/diagnose", "/performance"
    )

    fun parse(input: String): UniversalInputType {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return UniversalInputType.InternalPage("start")
        }

        // 1. Interne URLs: werk://...
        if (trimmed.startsWith("werk://", ignoreCase = true)) {
            val page = trimmed.removePrefix("werk://").removePrefix("WERK://").lowercase().trim('/')
            return UniversalInputType.InternalPage(if (page.isEmpty()) "start" else page)
        }

        // 2. Befehlssystem: /befehl [argument]
        for (cmd in COMMAND_PREFIXES) {
            if (trimmed.startsWith(cmd, ignoreCase = true)) {
                val arg = trimmed.substring(cmd.length).trim()
                val cleanCmd = cmd.removePrefix("/").lowercase()
                return UniversalInputType.Command(cleanCmd, arg)
            }
        }

        // 3. Mathematische Berechnungen: z.B. "1.250 * 48", "100 + 45", "1250 * 48"
        val mathResult = tryEvaluateMath(trimmed)
        if (mathResult != null) {
            val formatted = GermanTypography.formatCurrency(mathResult)
            return UniversalInputType.Calculation(trimmed, mathResult, formatted)
        }

        // 4. Eindeutige Web-URLs
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("file://", ignoreCase = true)
        ) {
            return UniversalInputType.DirectUrl(trimmed)
        }

        // Domain-Muster wie example.de, heise.de, spiegel.de, wikipedia.org, localhost:8080
        val isDomainLike = trimmed.matches(Regex("^[a-zA-Z0-9-]+\\.(de|com|org|net|eu|ch|at|io|info|edu)(/.*)?$", RegexOption.IGNORE_CASE))
        if (isDomainLike && !trimmed.contains(" ")) {
            return UniversalInputType.DirectUrl("https://$trimmed")
        }

        // 5. Intelligente deutsche Suche mit Komposita- und Mehrsprachen-Erkennung
        val compoundAnalysis = GermanCompoundAnalyzer.expandSearchQuery(trimmed)
        val multilingualSuggestion = generateMultilingualExpansion(trimmed)

        return UniversalInputType.SearchQuery(
            query = trimmed,
            expandedTokens = compoundAnalysis,
            multilingualSuggestion = multilingualSuggestion
        )
    }

    private fun tryEvaluateMath(text: String): Double? {
        val clean = text.replace(".", "").replace(",", ".").trim()
        // Unterstütze einfache Grundrechenarten: Zahl Operator Zahl
        val regex = Regex("^(\\d+(?:\\.\\d+)?)\\s*([+\\-*/x×])\\s*(\\d+(?:\\.\\d+)?)$")
        val match = regex.find(clean) ?: return null

        val (firstStr, op, secondStr) = match.destructured
        val a = firstStr.toDoubleOrNull() ?: return null
        val b = secondStr.toDoubleOrNull() ?: return null

        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "*", "x", "×" -> a * b
            "/" -> if (b != 0.0) a / b else null
            else -> null
        }
    }

    private fun generateMultilingualExpansion(query: String): String? {
        val lower = query.lowercase(Locale.GERMANY)
        val translations = mapOf(
            "deutsche automobilindustrie" to "German automotive industry",
            "automobilindustrie" to "automotive industry",
            "energiewende" to "energy transition",
            "energiespeichertechnologie" to "energy storage technology",
            "maschinenbau" to "mechanical engineering",
            "datenschutz" to "data privacy & GDPR",
            "hochgeschwindigkeitsbahn" to "high speed rail network",
            "klimaschutz" to "climate protection & policy"
        )

        for ((de, en) in translations) {
            if (lower.contains(de)) {
                return en
            }
        }
        return null
    }
}
