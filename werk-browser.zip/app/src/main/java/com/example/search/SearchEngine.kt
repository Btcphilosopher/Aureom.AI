package com.example.search

import com.example.data.model.DemoWebPage
import com.example.data.model.DemoWebPagesRepository
import com.example.language.GermanCompoundAnalyzer

data class SearchResultItem(
    val title: String,
    val url: String,
    val snippet: String,
    val sourceCategory: String,
    val date: String,
    val matchedTokens: List<String>,
    val isMultilingual: Boolean = false,
    val language: String = "de"
)

object SearchEngine {

    fun search(query: String, includeMultilingual: Boolean = true): List<SearchResultItem> {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return emptyList()

        val tokens = GermanCompoundAnalyzer.expandSearchQuery(cleanQuery)
        val results = mutableListOf<SearchResultItem>()

        // 1. Suche in Demo- und Fachinhalten
        for (page in DemoWebPagesRepository.pages) {
            val matched = mutableListOf<String>()
            val textToSearch = "${page.title} ${page.summary} ${page.fullText}"

            for (token in tokens) {
                if (textToSearch.contains(token, ignoreCase = true)) {
                    matched.add(token)
                }
            }

            if (matched.isNotEmpty() || page.title.contains(cleanQuery, ignoreCase = true)) {
                results.add(
                    SearchResultItem(
                        title = page.title,
                        url = page.url,
                        snippet = page.summary,
                        sourceCategory = page.category,
                        date = page.date,
                        matchedTokens = matched.distinct(),
                        isMultilingual = page.language != "de",
                        language = page.language
                    )
                )
            }
        }

        // 2. Multilinguale Erweiterung falls keine oder wenige Treffer
        if (includeMultilingual && results.none { it.isMultilingual }) {
            val englishMatch = DemoWebPagesRepository.pages.find { it.language == "en" }
            if (englishMatch != null && (cleanQuery.contains("industrie", true) || cleanQuery.contains("technik", true) || cleanQuery.contains("deutschland", true))) {
                results.add(
                    SearchResultItem(
                        title = englishMatch.title,
                        url = englishMatch.url,
                        snippet = englishMatch.summary,
                        sourceCategory = "Europäische Quelle (${englishMatch.category})",
                        date = englishMatch.date,
                        matchedTokens = listOf("Erweiterte europäische Suche"),
                        isMultilingual = true,
                        language = "en"
                    )
                )
            }
        }

        return results
    }
}
