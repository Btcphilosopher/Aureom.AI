package com.example.language

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Kernkomponente für deutsche Typografie und Normierung:
 * - „Deutsche Anführungszeichen“ & »Alternative Anführungszeichen«
 * - Gedankenstrich (–) & Geviertstrich (—)
 * - Nicht-umbrechende Leerzeichen vor Einheiten (§, €, %, kg)
 * - Deutsche Zahlenformatierung (1.234.567,89 €) & Datumsformatierung (31.12.2026)
 * - Erhaltung und Verifikation von ÄÖÜ äöü ß
 */
object GermanTypography {

    private val GERMAN_LOCALE = Locale.GERMANY

    fun formatCurrency(amount: Double): String {
        val symbols = DecimalFormatSymbols(GERMAN_LOCALE).apply {
            groupingSeparator = '.'
            decimalSeparator = ','
        }
        val formatter = DecimalFormat("#,##0.00", symbols)
        return "${formatter.format(amount)}\u00A0€"
    }

    fun formatNumber(number: Long): String {
        val symbols = DecimalFormatSymbols(GERMAN_LOCALE).apply {
            groupingSeparator = '.'
        }
        val formatter = DecimalFormat("#,###", symbols)
        return formatter.format(number)
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd.MM.yyyy", GERMAN_LOCALE)
        return sdf.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd.MM.yyyy, HH:mm\u00A0'Uhr'", GERMAN_LOCALE)
        return sdf.format(Date(timestamp))
    }

    /**
     * Konvertiert gewöhnliche Anführungszeichen in typografisch korrekte deutsche Anführungszeichen:
     * Unten 99 („) und Oben 66 (“).
     */
    fun applyGermanQuotes(input: String): String {
        var result = input
        val quoteRegex = Regex("\"([^\"]*)\"")
        result = quoteRegex.replace(result) { match ->
            "„${match.groupValues[1]}“"
        }
        return result
    }

    /**
     * Setzt geschützte Leerzeichen (NBSP) vor Einheiten, Paragraphenzeichen und Prozent.
     * Z.B. "§ 12", "100 km/h", "50 €".
     */
    fun applyNonBreakingSpaces(input: String): String {
        var text = input
        text = text.replace(Regex("§\\s+"), "§\u00A0")
        text = text.replace(Regex("(\\d+)\\s+(€|EUR|%|km/h|kW|kWh|MWh|kg|GB|MB)"), "$1\u00A0$2")
        text = text.replace(Regex("\\s+–\\s+"), "\u00A0– ")
        return text
    }

    /**
     * Unicode Normalisierung (NFC) zur Vermeidung von zerlegten Umlauten (Combining Characters).
     */
    fun normalizeNfc(text: String): String {
        return Normalizer.normalize(text, Normalizer.Form.NFC)
    }

    /**
     * Prüft, ob ein Text die charakteristischen deutschen Glyphen enthält.
     */
    fun containsGermanSpecificGlyphs(text: String): Boolean {
        return text.any { it in "äöüÄÖÜß" }
    }
}
