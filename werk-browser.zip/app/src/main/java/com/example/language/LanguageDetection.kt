package com.example.language

/**
 * LanguageDetection
 * Erkennt europäische Sprachen (Deutsch, Englisch, Französisch, Spanisch, Italienisch, Niederländisch)
 * auf Basis von Funktionswörtern, diakritischen Zeichen und typischen Sprachmustern.
 */
object LanguageDetection {

    enum class SupportedLanguage(val code: String, val displayName: String, val flagHint: String) {
        GERMAN("de", "Deutsch", "DE"),
        ENGLISH("en", "English", "EN"),
        FRENCH("fr", "Français", "FR"),
        SPANISH("es", "Español", "ES"),
        ITALIAN("it", "Italiano", "IT"),
        DUTCH("nl", "Nederlands", "NL"),
        POLISH("pl", "Polski", "PL"),
        UNKNOWN("und", "Unbekannt", "??")
    }

    private val GERMAN_INDICATORS = setOf(
        "der", "die", "das", "und", "in", "den", "von", "zu", "mit", "sich", "des",
        "auf", "für", "ist", "im", "dem", "nicht", "ein", "eine", "einer", "einem",
        "auch", "es", "an", "werden", "aus", "er", "hat", "dass", "sie", "nach",
        "wird", "bei", "einen", "haben", "wie", "wir", "aber", "kann", "nur"
    )

    private val ENGLISH_INDICATORS = setOf(
        "the", "and", "of", "to", "in", "is", "that", "it", "with", "as", "for", "was",
        "on", "are", "by", "this", "be", "from", "at", "which", "have", "or", "an"
    )

    private val FRENCH_INDICATORS = setOf(
        "le", "la", "les", "et", "de", "des", "du", "en", "un", "une", "dans", "est",
        "que", "qui", "pour", "pas", "sur", "ce", "cette", "avec", "sont"
    )

    private val SPANISH_INDICATORS = setOf(
        "el", "la", "los", "las", "y", "en", "de", "del", "que", "un", "una", "por",
        "con", "para", "es", "al", "como", "mas", "pero", "sus", "este"
    )

    private val ITALIAN_INDICATORS = setOf(
        "il", "la", "i", "gli", "le", "e", "di", "del", "della", "in", "un", "una",
        "che", "per", "non", "con", "sono", "come", "questo", "delle"
    )

    private val DUTCH_INDICATORS = setOf(
        "de", "het", "een", "en", "van", "in", "is", "op", "te", "met", "voor", "zijn",
        "dat", "niet", "aan", "om", "ook", "als", "bij", "er", "door"
    )

    fun detect(text: String): SupportedLanguage {
        val trimmed = text.trim()
        if (trimmed.length < 10) return SupportedLanguage.GERMAN // Standard

        val words = trimmed.lowercase().split(Regex("[\\s.,;:!?\"„“”»«()]+")).filter { it.length > 1 }
        if (words.isEmpty()) return SupportedLanguage.GERMAN

        // Schnelle Heuristik über Zeichen
        if (trimmed.any { it in "äöüÄÖÜß" }) {
            return SupportedLanguage.GERMAN
        }

        var deScore = 0
        var enScore = 0
        var frScore = 0
        var esScore = 0
        var itScore = 0
        var nlScore = 0

        for (word in words) {
            if (GERMAN_INDICATORS.contains(word)) deScore++
            if (ENGLISH_INDICATORS.contains(word)) enScore++
            if (FRENCH_INDICATORS.contains(word)) frScore++
            if (SPANISH_INDICATORS.contains(word)) esScore++
            if (ITALIAN_INDICATORS.contains(word)) itScore++
            if (DUTCH_INDICATORS.contains(word)) nlScore++
        }

        val scores = listOf(
            SupportedLanguage.GERMAN to deScore * 1.2, // Bevorzuge Deutsch als Default
            SupportedLanguage.ENGLISH to enScore.toDouble(),
            SupportedLanguage.FRENCH to frScore.toDouble(),
            SupportedLanguage.SPANISH to esScore.toDouble(),
            SupportedLanguage.ITALIAN to itScore.toDouble(),
            SupportedLanguage.DUTCH to nlScore.toDouble()
        )

        val best = scores.maxByOrNull { it.second }
        return if (best != null && best.second > 0) {
            best.first
        } else {
            SupportedLanguage.GERMAN
        }
    }
}
