package com.example.language

/**
 * GermanSpellchecker
 * Überprüfung deutscher Rechtschreibung, Erkennung versehentlich getrennter Komposita,
 * Umlaut-Normalisierung und Generierung von Korrekturvorschlägen.
 */
object GermanSpellchecker {

    // Fach- und Allgemeinwörterbuch
    private val DICTIONARY = setOf(
        "datenschutz", "datenschutzgrundverordnung", "bundesverfassungsgericht",
        "hochgeschwindigkeitsbahn", "energiespeichertechnologie", "maschinenbauunternehmen",
        "donaudampfschifffahrtsgesellschaft", "energieversorgungssicherheit",
        "eisenbahninfrastruktur", "informationssicherheit", "sicherheitsarchitektur",
        "forschung", "wissenschaft", "technologie", "entwicklung", "europäisch",
        "deutschland", "österreich", "schweiz", "infrastruktur", "nachhaltigkeit",
        "barrierefreiheit", "benutzeroberfläche", "recherche", "lesemodus",
        "übertragung", "verschlüsselung", "zertifikat", "einwilligung", "lesezeichen"
    )

    // Häufige Getrenntschreibungsfehler im Deutschen (Deppenleerzeichen)
    private val DEEN_SEPARATIONS = mapOf(
        "daten schutz" to "Datenschutz",
        "daten schutz verordnung" to "Datenschutzverordnung",
        "bundes verfassung" to "Bundesverfassung",
        "bundes verfassungs gericht" to "Bundesverfassungsgericht",
        "energie speicher" to "Energiespeicher",
        "maschinen bau" to "Maschinenbau",
        "hoch geschwindigkeit" to "Hochgeschwindigkeit",
        "eisen bahn" to "Eisenbahn",
        "sicherheits lücke" to "Sicherheitslücke",
        "schlüssel wort" to "Schlüsselwort"
    )

    data class SpellSuggestion(
        val original: String,
        val suggestion: String,
        val reason: String
    )

    fun checkText(input: String): List<SpellSuggestion> {
        val suggestions = mutableListOf<SpellSuggestion>()
        val lower = input.lowercase().trim()

        // 1. Prüfung auf getrennte Komposita
        for ((separated, corrected) in DEEN_SEPARATIONS) {
            if (lower.contains(separated)) {
                suggestions.add(
                    SpellSuggestion(
                        original = separated,
                        suggestion = corrected,
                        reason = "Zusammenschreibung im Deutschen (Kompositum)"
                    )
                )
            }
        }

        // 2. Prüfung auf ae/oe/ue/ss Substitutionen
        val words = input.split(Regex("[\\s.,;:!?\"„“”»«]+")).filter { it.isNotBlank() }
        for (word in words) {
            val umlautCandidate = substituteUmlauts(word)
            if (umlautCandidate != word && DICTIONARY.contains(umlautCandidate.lowercase())) {
                suggestions.add(
                    SpellSuggestion(
                        original = word,
                        suggestion = umlautCandidate,
                        reason = "Deutsche Umlautschreibung empfohlen"
                    )
                )
            }
        }

        return suggestions
    }

    private fun substituteUmlauts(word: String): String {
        var res = word
        res = res.replace("ae", "ä").replace("Ae", "Ä")
        res = res.replace("oe", "ö").replace("Oe", "Ö")
        res = res.replace("ue", "ü").replace("Ue", "Ü")
        return res
    }
}
