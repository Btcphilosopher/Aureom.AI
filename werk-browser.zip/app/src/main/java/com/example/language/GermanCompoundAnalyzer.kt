package com.example.language

/**
 * GermanCompoundAnalyzer
 * Analysiert und zerlegt deutsche Komposita (zusammengesetzte Substantive),
 * erkennt Fugenelemente (Fugen-s, Fugen-n, Fugen-en) und liefert
 * Konstituenten für die intelligente Suchnormalisierung.
 */
object GermanCompoundAnalyzer {

    // Häufige Morpheme und Stammwörter im deutschen Sprachraum
    private val KNOWN_MORPHEMES = setOf(
        "daten", "schutz", "grund", "verordnung", "gesetz", "recht",
        "bundes", "verfassung", "gericht", "staat", "rat", "tag",
        "hoch", "geschwindigkeit", "bahn", "zug", "strecke", "netz",
        "energie", "speicher", "technologie", "technik", "wende", "strom", "netz",
        "maschinen", "bau", "unternehmen", "industrie", "fertigung", "werk",
        "donau", "dampf", "schiff", "fahrt", "gesellschaft", "kapitän",
        "verkehr", "infrastruktur", "politik", "wirtschaft", "forschung",
        "wissenschaft", "umwelt", "klima", "sicherheit", "kontrolle",
        "system", "software", "programm", "server", "netzwerk", "browser",
        "plattform", "information", "dokument", "bericht", "analyse",
        "wissen", "speicher", "motor", "kraft", "atom", "kohle", "gas",
        "solar", "wind", "wasser", "quelle", "zitat", "vergleich", "suche",
        "arbeit", "leben", "zeit", "raum", "haus", "stadt", "land"
    )

    data class CompoundAnalysis(
        val original: String,
        val isCompound: Boolean,
        val constituents: List<String>,
        val searchTokens: List<String>
    )

    /**
     * Zerlegt ein potenzielles Kompositum in seine Einzelteile.
     */
    fun analyze(word: String): CompoundAnalysis {
        val clean = word.trim()
        if (clean.length < 7) {
            return CompoundAnalysis(clean, false, listOf(clean), listOf(clean))
        }

        val lower = clean.lowercase()

        // Bekannte Standard-Komposita direkt abbilden
        val specialCases = mapOf(
            "datenschutzgrundverordnung" to listOf("Daten", "Schutz", "Grund", "Verordnung"),
            "bundesverfassungsgericht" to listOf("Bundes", "Verfassung", "Gericht"),
            "hochgeschwindigkeitsbahn" to listOf("Hoch", "Geschwindigkeit", "Bahn"),
            "energiespeichertechnologie" to listOf("Energie", "Speicher", "Technologie"),
            "maschinenbauunternehmen" to listOf("Maschinen", "Bau", "Unternehmen"),
            "donaudampfschifffahrtsgesellschaft" to listOf("Donau", "Dampf", "Schifffahrt", "Gesellschaft"),
            "energieversorgungssicherheit" to listOf("Energie", "Versorgung", "Sicherheit"),
            "eisenbahninfrastruktur" to listOf("Eisenbahn", "Infrastruktur"),
            "informationssicherheit" to listOf("Information", "Sicherheit")
        )

        specialCases[lower]?.let { parts ->
            return CompoundAnalysis(
                original = clean,
                isCompound = true,
                constituents = parts,
                searchTokens = listOf(clean) + parts
            )
        }

        // Dynamische Zerlegung mit Fugen-Morphologie
        val parts = mutableListOf<String>()
        var remaining = lower
        var matched = false

        while (remaining.length >= 3) {
            var foundPrefix = ""
            for (morpheme in KNOWN_MORPHEMES.sortedByDescending { it.length }) {
                if (remaining.startsWith(morpheme)) {
                    foundPrefix = morpheme
                    break
                }
            }

            if (foundPrefix.isNotEmpty()) {
                val capitalized = foundPrefix.replaceFirstChar { it.uppercase() }
                parts.add(capitalized)
                remaining = remaining.removePrefix(foundPrefix)

                // Fugen-Elemente überspringen: s, es, n, en, er
                if (remaining.startsWith("s") && remaining.length > 2) {
                    remaining = remaining.removePrefix("s")
                } else if (remaining.startsWith("es") && remaining.length > 3) {
                    remaining = remaining.removePrefix("es")
                } else if (remaining.startsWith("en") && remaining.length > 3) {
                    remaining = remaining.removePrefix("en")
                } else if (remaining.startsWith("n") && remaining.length > 2) {
                    remaining = remaining.removePrefix("n")
                }
                matched = true
            } else {
                break
            }
        }

        if (matched && parts.size >= 2 && remaining.isEmpty()) {
            return CompoundAnalysis(
                original = clean,
                isCompound = true,
                constituents = parts,
                searchTokens = listOf(clean) + parts
            )
        }

        // Fallback: Wenn rest übrig ist, prüfen ob min. 2 Teile gefunden wurden
        if (matched && parts.size >= 1 && remaining.length >= 3) {
            val capitalizedRemaining = remaining.replaceFirstChar { it.uppercase() }
            val fullParts = parts + capitalizedRemaining
            return CompoundAnalysis(
                original = clean,
                isCompound = true,
                constituents = fullParts,
                searchTokens = listOf(clean) + fullParts
            )
        }

        return CompoundAnalysis(clean, false, listOf(clean), listOf(clean))
    }

    /**
     * Erweitert eine Suchanfrage um semantische Komposita-Bestandteile.
     */
    fun expandSearchQuery(query: String): List<String> {
        val tokens = query.split(Regex("\\s+")).filter { it.isNotBlank() }
        val expanded = mutableSetOf<String>()
        expanded.addAll(tokens)

        for (token in tokens) {
            val analysis = analyze(token)
            if (analysis.isCompound) {
                expanded.addAll(analysis.constituents)
            }
        }
        return expanded.toList()
    }
}
