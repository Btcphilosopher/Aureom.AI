package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class BrowserTab(
    val id: String,
    val url: String,
    val title: String,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val groupId: String? = null,
    val memoryMb: Double = 34.5,
    val cpuPercent: Double = 0.8,
    val isSuspended: Boolean = false,
    val securityInfo: SecurityInfo = SecurityInfo(),
    val extractedContent: String? = null
)

data class SecurityInfo(
    val isHttps: Boolean = true,
    val certificateValid: Boolean = true,
    val tlsVersion: String = "TLS 1.3",
    val cipherSuite: String = "ChaCha20-Poly1305 / AES-256-GCM",
    val issuer: String = "Let's Encrypt / European Trust Services",
    val mixedContentBlocked: Boolean = true,
    val isIsolatedProcess: Boolean = true,
    val trackersBlockedCount: Int = 0
)

data class TabGroup(
    val id: String,
    val name: String,
    val colorHex: Long
)

@Entity(tableName = "history_entries")
data class HistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val timestamp: Long,
    val domain: String,
    val visitCount: Int = 1
)

@Entity(tableName = "bookmarks")
data class BookmarkEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val folder: String = "Standard",
    val tags: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "research_documents")
data class ResearchDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String = "Unbekannt",
    val dateOrYear: String = "2026",
    val url: String,
    val language: String = "de",
    val originalSnippet: String,
    val translationSnippet: String = "",
    val notes: String = "",
    val tags: String = "Recherche",
    val citationApa: String = "",
    val citationDin: String = "",
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "privacy_events")
data class PrivacyEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val siteUrl: String,
    val blockedItem: String,
    val category: String // "TRACKER", "COOKIE", "FINGERPRINT", "GPC"
)

data class DownloadItem(
    val id: String,
    val fileName: String,
    val fileSizeBytes: Long,
    val downloadedBytes: Long,
    val progressPercent: Int,
    val url: String,
    val isCompleted: Boolean,
    val isPaused: Boolean,
    val securityScanned: Boolean = true,
    val destinationPath: String
)

data class PrivacyStatistics(
    val trackersBlockedToday: Int = 184,
    val thirdPartyCookiesBlocked: Int = 72,
    val cookieBannersHandled: Int = 14,
    val insecureConnectionsBlocked: Int = 0,
    val gpcSignalsTransmitted: Int = 31
)
