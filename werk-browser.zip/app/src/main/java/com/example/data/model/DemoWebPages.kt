package com.example.data.model

data class DemoWebPage(
    val url: String,
    val title: String,
    val category: String,
    val language: String,
    val author: String,
    val date: String,
    val summary: String,
    val fullText: String,
    val citations: Map<String, String> = emptyMap(),
    val extractedTable: List<List<String>> = emptyList()
)

object DemoWebPagesRepository {

    val pages = listOf(
        DemoWebPage(
            url = "https://forschung.bund.de/energiespeichertechnologie",
            title = "Nationale Forschungsinitiative: Energiespeichertechnologie 2030",
            category = "Forschung",
            language = "de",
            author = "Prof. Dr. Katharina Weber",
            date = "31.12.2026",
            summary = "Die Bundesregierung investiert 1.234.567,89\u00A0€ in neuartige Feststoff- und Redox-Flow-Batteriesysteme. Ziel ist die verlässliche Energieversorgungssicherheit und europäische Souveränität bei Rohstoffen.",
            fullText = """
                Die Transformation der deutschen Energieinfrastruktur erreicht mit dem Ausbau modernster Energiespeichertechnologie eine neue Phase. Durch die gezielte Kopplung von Wind- und Photovoltaikanlagen mit großtechnischen Speicherparks wird die Energieversorgungssicherheit auch bei Dunkelflauten gewährleistet.
                
                „Die verlässliche Energiespeicherung bildet das Rückgrat einer dekarbonisierten Industriegesellschaft“, betont das Bundesministerium für Wirtschaft und Klimaschutz. Die Fördermittel in Höhe von 1.234.567,89\u00A0€ fließen primär in Fraunhofer- und Max-Planck-Institute zur Erforschung nachhaltiger Natrium-Ionen-Zellen.
                
                Im Zentrum steht die Kooperation zwischen Maschinenbauunternehmen und universitären Forschungszentren. Die Kombination aus Python 3.13 + Rust + deutsche Typografie sichert dabei hochpräzise Simulationen in der Quantenchemie.
            """.trimIndent(),
            citations = mapOf(
                "DIN ISO 690" to "WEBER, Katharina. Nationale Forschungsinitiative: Energiespeichertechnologie 2030. Berlin: Bundesforschungsplattform, 2026.",
                "APA" to "Weber, K. (2026). Nationale Forschungsinitiative: Energiespeichertechnologie 2030. Bundesforschungsplattform."
            ),
            extractedTable = listOf(
                listOf("Technologie", "Wirkungsgrad", "Kosten / kWh", "Reife"),
                listOf("Natrium-Ionen", "89%", "42,00 €", "Pilotbetrieb"),
                listOf("Redox-Flow", "78%", "35,50 €", "Kommerziell"),
                listOf("Feststoffzelle", "94%", "68,00 €", "Laborphase")
            )
        ),
        DemoWebPage(
            url = "https://bahn-zukunft.de/hochgeschwindigkeitsbahn",
            title = "Hochgeschwindigkeitsbahn: Ausbaukorridore im transeuropäischen Netz",
            category = "Infrastruktur",
            language = "de",
            author = "Dr. Martin Lindner",
            date = "15.09.2026",
            summary = "Neue Hochgeschwindigkeitsstrecken verbinden Berlin, München, Paris und Warschau mit 320 km/h. Ein Paradebeispiel europäischer Eisenbahninfrastruktur.",
            fullText = """
                Die Vision einer europäischen Hochgeschwindigkeitsbahn gewinnt an Kontur. Die neue Eisenbahninfrastruktur ermöglicht Direktverbindungen zwischen den europäischen Metropolen ohne Inlandsflüge.
                
                Maschinenbauunternehmen aus Deutschland und Frankreich liefern neue Triebzüge mit rekuperativer Bremsenergierückspeisung. Die Sicherheitsleitsysteme basieren auf ETCS Level 3, wodurch Streckenkapazitäten um 30\u00A0% steigen.
                
                „Europäische Vernetzung bedeutet Freiheit und ökologische Verantwortung“, so das Konsortium. Das Gesamtinvestitionsvolumen umfasst über 12.450.000,00\u00A0€.
            """.trimIndent(),
            citations = mapOf(
                "DIN ISO 690" to "LINDNER, Martin. Hochgeschwindigkeitsbahn: Transeuropäische Korridore. Frankfurt a. M., 2026.",
                "APA" to "Lindner, M. (2026). Hochgeschwindigkeitsbahn: Ausbaukorridore im transeuropäischen Netz. Bahn Zukunft."
            )
        ),
        DemoWebPage(
            url = "https://recht-digital.de/datenschutzgrundverordnung",
            title = "Datenschutzgrundverordnung: Digitale Selbstbestimmung & Privatsphäre",
            category = "Recht",
            language = "de",
            author = "Elena Richter, LL.M.",
            date = "04.10.2026",
            summary = "Das Bundesverfassungsgericht und europäische Gerichte stärken die Datenschutzgrundverordnung gegen unzulässiges Web-Tracking und Fingerprinting.",
            fullText = """
                Die Datenschutzgrundverordnung (DSGVO) und das Grundrecht auf informationelle Selbstbestimmung bilden das Fundament europäischer Digitalpolitik. Moderne Browser wie WERK implementieren Global Privacy Control (GPC) direkt auf Protokollebene.
                
                Das Bundesverfassungsgericht urteilte wiederholt: Bürger haben das Recht, nicht ohne informierte Einwilligung durch Web-Tracker profiliert zu werden. Die strikte Trennung von Analyse- und Notwendigkeits-Cookies ist gesetzlich geboten nach §\u00A025 TDDDG.
                
                Die technische Durchsetzung erfolgt durch First-Party-Isolation, automatisierte Ablehnung manipulativer Cookie-Banner und lokale Informationsverarbeitung.
            """.trimIndent()
        ),
        DemoWebPage(
            url = "https://de.wikipedia.org/wiki/Donaudampfschifffahrtsgesellschaft",
            title = "Erste Donau-Dampfschifffahrts-Gesellschaft – Historische Enzyklopädie",
            category = "Enzyklopädie",
            language = "de",
            author = "Wikipedia Autorenkollektiv",
            date = "22.08.2026",
            summary = "Die Erste Donau-Dampfschifffahrts-Gesellschaft (DDSG) war einst die größte Binnenreederei der Welt und ein linguistisches Paradebeispiel deutscher Komposita.",
            fullText = """
                Die Erste Donau-Dampfschifffahrts-Gesellschaft (DDSG) wurde 1829 in Wien gegründet. Bekannt ist das Unternehmen nicht nur für die Erschließung der Binnenschifffahrt auf der Donau von Ulm bis zum Schwarzen Meer, sondern auch als populäres Sprachbeispiel für deutsche Bandwurmwörter: Donaudampfschifffahrtsgesellschaftskapitänskajütentürsicherheitsschloss.
                
                Die linguistische Zusammensetzung beweist die Eleganz und Präzision der deutschen Wortbildungslehre (Komposita), bei der Substantive ohne semantischen Bedeutungsverlust aggregiert werden können.
            """.trimIndent()
        ),
        DemoWebPage(
            url = "https://european-engineering.eu/quantum-materials",
            title = "Advanced Quantum Materials for European Semiconductor Sovereignty",
            category = "Wissenschaft (Englisch)",
            language = "en",
            author = "Dr. Julian Vance & Prof. Claire Dubois",
            date = "12.07.2026",
            summary = "Next-generation 2nm silicon-germanium architectures developed under the European Chips Act demonstrate unprecedented power efficiency.",
            fullText = """
                European Semiconductor manufacturers are accelerating the deployment of sub-2nm nodes utilizing tailored 2D topological insulators. Maschinenbau / Mechanical Engineering precision enables sub-angstrom optical lithography.
                
                Deutschland — Germany — Deutschland: The tripartite synergy between research hubs in Dresden, Grenoble, and Eindhoven establishes a resilient supply chain. 
                
                Financial allocations exceed €1.250 billion ($1,450 billion) with verified zero-carbon manufacturing certifications.
            """.trimIndent()
        )
    )

    fun findByUrlOrQuery(input: String): DemoWebPage? {
        val clean = input.trim()
        val exact = pages.find { it.url.equals(clean, ignoreCase = true) }
        if (exact != null) return exact

        // Domain-Matching
        val domain = clean.removePrefix("https://").removePrefix("http://").substringBefore("/")
        val byDomain = pages.find { it.url.contains(domain, ignoreCase = true) }
        if (byDomain != null) return byDomain

        // Text & Titel Matching
        return pages.find {
            it.title.contains(clean, ignoreCase = true) ||
            it.fullText.contains(clean, ignoreCase = true)
        }
    }
}
