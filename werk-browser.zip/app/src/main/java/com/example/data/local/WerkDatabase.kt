package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BookmarkEntry
import com.example.data.model.HistoryEntry
import com.example.data.model.PrivacyEvent
import com.example.data.model.ResearchDocument

@Database(
    entities = [
        HistoryEntry::class,
        BookmarkEntry::class,
        ResearchDocument::class,
        PrivacyEvent::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WerkDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun researchDao(): ResearchDao
    abstract fun privacyDao(): PrivacyDao

    companion object {
        @Volatile
        private var INSTANCE: WerkDatabase? = null

        fun getInstance(context: Context): WerkDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WerkDatabase::class.java,
                    "werk_browser_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
