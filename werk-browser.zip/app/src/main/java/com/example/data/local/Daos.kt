package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.BookmarkEntry
import com.example.data.model.HistoryEntry
import com.example.data.model.PrivacyEvent
import com.example.data.model.ResearchDocument
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history_entries ORDER BY timestamp DESC LIMIT 200")
    fun getAllHistory(): Flow<List<HistoryEntry>>

    @Query("SELECT * FROM history_entries WHERE title LIKE '%' || :query || '%' OR url LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchHistory(query: String): Flow<List<HistoryEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: HistoryEntry): Long

    @Query("DELETE FROM history_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM history_entries")
    suspend fun clearAll()
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntry>>

    @Query("SELECT * FROM bookmarks WHERE folder = :folder ORDER BY createdAt DESC")
    fun getBookmarksByFolder(folder: String): Flow<List<BookmarkEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntry): Long

    @Delete
    suspend fun delete(bookmark: BookmarkEntry)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    suspend fun isBookmarked(url: String): Boolean
}

@Dao
interface ResearchDao {
    @Query("SELECT * FROM research_documents ORDER BY savedAt DESC")
    fun getAllResearch(): Flow<List<ResearchDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(doc: ResearchDocument): Long

    @Delete
    suspend fun delete(doc: ResearchDocument)

    @Query("SELECT * FROM research_documents WHERE id = :id")
    suspend fun getById(id: Long): ResearchDocument?
}

@Dao
interface PrivacyDao {
    @Query("SELECT * FROM privacy_events ORDER BY timestamp DESC LIMIT 100")
    fun getRecentEvents(): Flow<List<PrivacyEvent>>

    @Query("SELECT COUNT(*) FROM privacy_events WHERE category = 'TRACKER'")
    suspend fun getBlockedTrackersCount(): Int

    @Query("SELECT COUNT(*) FROM privacy_events WHERE category = 'COOKIE'")
    suspend fun getBlockedCookiesCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: PrivacyEvent): Long

    @Query("DELETE FROM privacy_events")
    suspend fun clearEvents()
}
