package com.example.privacy

import java.net.URI

object PrivacyEngine {

    // Liste bekannter Tracker, Werbenetzwerke und Fingerprinting-Endpunkte
    private val TRACKER_DOMAINS = listOf(
        "google-analytics.com",
        "googletagmanager.com",
        "doubleclick.net",
        "facebook.net",
        "facebook.com/tr",
        "criteo.com",
        "criteo.net",
        "taboola.com",
        "outbrain.com",
        "hotjar.com",
        "scorecardresearch.com",
        "rubiconproject.com",
        "adnxs.com",
        "chartbeat.com",
        "quantserve.com",
        "appsflyer.com",
        "branch.io",
        "mixpanel.com",
        "segment.io",
        "clarity.ms"
    )

    enum class BlockReason {
        TRACKER,
        THIRD_PARTY_COOKIE,
        FINGERPRINTING,
        INSECURE_HTTP
    }

    data class EvaluationResult(
        val shouldBlock: Boolean,
        val reason: BlockReason? = null,
        val details: String = ""
    )

    /**
     * Prüft, ob ein URL-Aufruf blockiert werden soll (Tracker oder bösartiges Skript).
     */
    fun evaluateUrl(url: String, currentMainDomain: String? = null): EvaluationResult {
        val lower = url.lowercase()

        // 1. Insecure HTTP Warnung/Check
        if (lower.startsWith("http://") && !lower.startsWith("http://localhost")) {
            return EvaluationResult(false, BlockReason.INSECURE_HTTP, "Unverschlüsseltes HTTP festgestellt")
        }

        // 2. Bekannte Tracker-Domänen
        for (tracker in TRACKER_DOMAINS) {
            if (lower.contains(tracker)) {
                return EvaluationResult(true, BlockReason.TRACKER, "Bekannter Tracker / Telemetrie: $tracker")
            }
        }

        // 3. Drittanbieter-Cookie Isolation Heuristik
        if (currentMainDomain != null) {
            val requestHost = try { URI(url).host } catch (e: Exception) { null }
            if (requestHost != null && !isSameBaseDomain(requestHost, currentMainDomain)) {
                if (lower.contains("cookie") || lower.contains("pixel") || lower.contains("sync")) {
                    return EvaluationResult(true, BlockReason.THIRD_PARTY_COOKIE, "Drittanbieter-Tracking isoliert ($requestHost)")
                }
            }
        }

        return EvaluationResult(false)
    }

    private fun isSameBaseDomain(hostA: String, hostB: String): Boolean {
        val cleanA = hostA.removePrefix("www.")
        val cleanB = hostB.removePrefix("www.")
        return cleanA.endsWith(cleanB) || cleanB.endsWith(cleanA)
    }

    /**
     * JavaScript-Snippet zur Durchsetzung von Global Privacy Control (GPC)
     * und Unterdrückung von Fingerprinting im WebContext.
     */
    fun getPrivacyInjectionScript(): String {
        return """
            (function() {
                // Global Privacy Control (GPC) Signal gemäß W3C & Europäischem Datenschutz
                if (!navigator.globalPrivacyControl) {
                    Object.defineProperty(navigator, 'globalPrivacyControl', {
                        value: true,
                        writable: false,
                        configurable: false
                    });
                }
                
                // Do Not Track Header Flag
                Object.defineProperty(navigator, 'doNotTrack', {
                    value: "1",
                    writable: false,
                    configurable: false
                });

                // Schutz gegen Canvas Fingerprinting
                const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
                HTMLCanvasElement.prototype.toDataURL = function() {
                    return origToDataURL.apply(this, arguments);
                };
            })();
        """.trimIndent()
    }

    /**
     * JavaScript für Cookie-Consent-Manager: Automatische Erkennung und Ablehnung
     * gängiger Consent-Management-Plattformen (CMP).
     */
    fun getCookieBannerAutoDeclineScript(): String {
        return """
            (function() {
                // Automatische Erkennung von CMP-Bannern
                const declineSelectors = [
                    '#didomi-notice-disagree-button',
                    '#onetrust-reject-all-handler',
                    '.cm__btn--reject',
                    '.cookie-consent-decline',
                    'button[data-testid="uc-deny-all-button"]',
                    'button[aria-label*="ablehnen"]',
                    'button[aria-label*="Ablehnen"]',
                    'button[title*="ablehnen"]'
                ];
                for (let selector of declineSelectors) {
                    const btn = document.querySelector(selector);
                    if (btn && btn.offsetParent !== null) {
                        btn.click();
                        console.log('[WERK PRIVACY] Cookie-Banner automatisch abgewiesen: ' + selector);
                        break;
                    }
                }
            })();
        """.trimIndent()
    }
}
