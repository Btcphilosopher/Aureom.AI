package com.example.reader

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TextToSpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentSentenceIndex = MutableStateFlow(0)
    val currentSentenceIndex: StateFlow<Int> = _currentSentenceIndex.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private var currentSentences: List<String> = emptyList()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.GERMANY)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.ENGLISH
            }
            tts?.setSpeechRate(_speechRate.value)
            isInitialized = true

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                }

                override fun onDone(utteranceId: String?) {
                    val nextIndex = _currentSentenceIndex.value + 1
                    if (nextIndex < currentSentences.size) {
                        _currentSentenceIndex.value = nextIndex
                        speakSentence(nextIndex)
                    } else {
                        _isPlaying.value = false
                        _currentSentenceIndex.value = 0
                    }
                }

                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                }
            })
        }
    }

    fun playText(text: String, languageCode: String = "de") {
        if (!isInitialized || tts == null) return

        val locale = when (languageCode.lowercase()) {
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            "es" -> Locale("es", "ES")
            "it" -> Locale.ITALIAN
            else -> Locale.GERMANY
        }
        tts?.language = locale

        currentSentences = text.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }
        if (currentSentences.isNotEmpty()) {
            _currentSentenceIndex.value = 0
            speakSentence(0)
        }
    }

    private fun speakSentence(index: Int) {
        if (index in currentSentences.indices) {
            tts?.speak(
                currentSentences[index],
                TextToSpeech.QUEUE_FLUSH,
                null,
                "werk_tts_$index"
            )
        }
    }

    fun pauseOrResume() {
        if (_isPlaying.value) {
            tts?.stop()
            _isPlaying.value = false
        } else if (currentSentences.isNotEmpty()) {
            speakSentence(_currentSentenceIndex.value)
            _isPlaying.value = true
        }
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _currentSentenceIndex.value = 0
    }

    fun setSpeed(rate: Float) {
        _speechRate.value = rate
        tts?.setSpeechRate(rate)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
