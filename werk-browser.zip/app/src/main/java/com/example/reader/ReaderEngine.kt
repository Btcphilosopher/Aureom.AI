package com.example.reader

data class ReaderArticle(
    val title: String,
    val author: String,
    val date: String,
    val readingTimeMinutes: Int,
    val paragraphs: List<String>,
    val fullText: String,
    val url: String
)

data class ReaderSettings(
    val fontSizeSp: Int = 18,
    val lineHeightMultiplier: Float = 1.6f,
    val isSerif: Boolean = true,
    val themeMode: ReaderThemeMode = ReaderThemeMode.SEPIA
)

enum class ReaderThemeMode {
    LIGHT,
    DARK,
    SEPIA
}

object ReaderEngine {

    fun extractArticle(url: String, htmlOrText: String): ReaderArticle {
        // Bereinigung von HTML-Tags
        val cleaned = htmlOrText
            .replace(Regex("<script[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<style[\\s\\S]*?</style>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<header[\\s\\S]*?</header>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<footer[\\s\\S]*?</footer>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<nav[\\s\\S]*?</nav>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&lt;", "<")
            .replace("&gt;", ">")

        val rawParagraphs = cleaned
            .split(Regex("\n{2,}"))
            .map { it.trim() }
            .filter { it.length > 40 }

        val paragraphs = if (rawParagraphs.isNotEmpty()) {
            rawParagraphs
        } else {
            cleaned.split(Regex("[.!?]\\s+"))
                .chunked(3)
                .map { it.joinToString(". ") }
                .filter { it.isNotBlank() }
        }

        val fullText = paragraphs.joinToString("\n\n")
        val wordCount = fullText.split(Regex("\\s+")).size
        val readingTime = (wordCount / 200).coerceAtLeast(1)

        val title = if (paragraphs.isNotEmpty() && paragraphs[0].length < 120) {
            paragraphs[0]
        } else {
            "Fachartikel: " + url.substringAfter("://").substringBefore("/")
        }

        return ReaderArticle(
            title = title,
            author = "Redaktion / WERK Dokumentenextraktion",
            date = "Oktober 2026",
            readingTimeMinutes = readingTime,
            paragraphs = paragraphs,
            fullText = fullText,
            url = url
        )
    }
}
