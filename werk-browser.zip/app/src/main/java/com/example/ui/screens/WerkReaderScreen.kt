package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.reader.ReaderArticle
import com.example.reader.ReaderSettings
import com.example.reader.ReaderThemeMode
import com.example.reader.TextToSpeechManager
import com.example.ui.theme.WerkDarkBackground
import com.example.ui.theme.WerkDarkTextPrimary
import com.example.ui.theme.WerkPaperWhite
import com.example.ui.theme.WerkSepiaBackground
import com.example.ui.theme.WerkSepiaSurface
import com.example.ui.theme.WerkSepiaText

@Composable
fun WerkReaderScreen(
    article: ReaderArticle?,
    settings: ReaderSettings,
    ttsManager: TextToSpeechManager,
    onUpdateSettings: (ReaderSettings) -> Unit,
    onCloseReader: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showTypographyBar by remember { mutableStateOf(false) }
    val isPlaying by ttsManager.isPlaying.collectAsState()
    val speechRate by ttsManager.speechRate.collectAsState()
    val currentSentenceIndex by ttsManager.currentSentenceIndex.collectAsState()

    val scrollState = rememberScrollState()

    // Farbschemata für Lesemodus
    val (backgroundColor, textColor, surfaceColor) = when (settings.themeMode) {
        ReaderThemeMode.SEPIA -> Triple(WerkSepiaBackground, WerkSepiaText, WerkSepiaSurface)
        ReaderThemeMode.DARK -> Triple(WerkDarkBackground, WerkDarkTextPrimary, Color(0xFF1E2530))
        ReaderThemeMode.LIGHT -> Triple(WerkPaperWhite, Color(0xFF1E2530), Color(0xFFE9ECF0))
    }

    val activeFontFamily = if (settings.isSerif) FontFamily.Serif else FontFamily.SansSerif

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        // Obere Steuerleiste
        Surface(
            modifier = Modifier.fillMaxWidth().height(48.dp),
            color = surfaceColor,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, textColor.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCloseReader,
                        modifier = Modifier.size(36.dp).testTag("close_reader_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Schließen", tint = textColor)
                    }

                    Text(
                        text = "LESEMODUS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        ),
                        color = textColor
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Vorlesen Play/Pause
                    IconButton(
                        onClick = {
                            if (article != null) {
                                if (isPlaying) ttsManager.pauseOrResume() else ttsManager.playText(article.fullText)
                            }
                        },
                        modifier = Modifier.size(36.dp).testTag("tts_play_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Vorlesen anhalten" else "Vorlesen starten",
                            tint = textColor
                        )
                    }

                    // Typografie Menü Umschalter
                    IconButton(
                        onClick = { showTypographyBar = !showTypographyBar },
                        modifier = Modifier.size(36.dp).testTag("reader_typography_toggle")
                    ) {
                        Icon(Icons.Default.FormatSize, contentDescription = "Schrift & Farbe anpassen", tint = textColor)
                    }
                }
            }
        }

        // Ausklappbare Typografie-Einstellungen
        if (showTypographyBar) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = surfaceColor,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, textColor.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Farbschema Umschalter
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ThemeOptionChip(
                            label = "Sepia",
                            selected = settings.themeMode == ReaderThemeMode.SEPIA,
                            color = WerkSepiaBackground,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ReaderThemeMode.SEPIA)) }
                        )
                        ThemeOptionChip(
                            label = "Hell",
                            selected = settings.themeMode == ReaderThemeMode.LIGHT,
                            color = WerkPaperWhite,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ReaderThemeMode.LIGHT)) }
                        )
                        ThemeOptionChip(
                            label = "Dunkel",
                            selected = settings.themeMode == ReaderThemeMode.DARK,
                            color = WerkDarkBackground,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ReaderThemeMode.DARK)) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Schriftart Serif / Sans & Schriftgröße
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (settings.isSerif) textColor.copy(alpha = 0.2f) else Color.Transparent,
                                modifier = Modifier
                                    .clickable { onUpdateSettings(settings.copy(isSerif = true)) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Serif", color = textColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (!settings.isSerif) textColor.copy(alpha = 0.2f) else Color.Transparent,
                                modifier = Modifier
                                    .clickable { onUpdateSettings(settings.copy(isSerif = false)) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Sans", color = textColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // Schriftgröße Buttons
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(textColor.copy(alpha = 0.15f))
                                    .clickable {
                                        if (settings.fontSizeSp > 13) {
                                            onUpdateSettings(settings.copy(fontSizeSp = settings.fontSizeSp - 1))
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("A-", color = textColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("${settings.fontSizeSp} pt", color = textColor, fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(textColor.copy(alpha = 0.15f))
                                    .clickable {
                                        if (settings.fontSizeSp < 28) {
                                            onUpdateSettings(settings.copy(fontSizeSp = settings.fontSizeSp + 1))
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("A+", color = textColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        // TTS Geschwindigkeit
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${speechRate}x", color = textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = textColor.copy(alpha = 0.15f),
                                modifier = Modifier
                                    .clickable {
                                        val nextRate = when (speechRate) {
                                            0.75f -> 1.0f
                                            1.0f -> 1.25f
                                            1.25f -> 1.5f
                                            else -> 0.75f
                                        }
                                        ttsManager.setSpeed(nextRate)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(14.dp), tint = textColor)
                            }
                        }
                    }
                }
            }
        }

        // Hauptartikelbereich
        if (article == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Kein lesbarer Artikel geladen.", color = textColor)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 24.dp, vertical = 24.dp)
            ) {
                Text(
                    text = article.title,
                    fontFamily = activeFontFamily,
                    fontSize = (settings.fontSizeSp + 6).sp,
                    lineHeight = (settings.fontSizeSp + 12).sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${article.author} · ${article.date}",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "ca. ${article.readingTimeMinutes} Min. Lesezeit",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Absätze mit korrekter deutscher Typografie
                article.paragraphs.forEach { paragraph ->
                    Text(
                        text = paragraph,
                        fontFamily = activeFontFamily,
                        fontSize = settings.fontSizeSp.sp,
                        lineHeight = (settings.fontSizeSp * settings.lineHeightMultiplier).sp,
                        color = textColor,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionChip(
    label: String,
    selected: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 0.5.dp,
            if (selected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (color == WerkDarkBackground) Color.White else Color.Black
        )
    }
}
