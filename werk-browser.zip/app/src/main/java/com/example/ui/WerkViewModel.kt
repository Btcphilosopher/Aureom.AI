package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.CitationGenerator
import com.example.ai.WerkAiEngine
import com.example.data.local.WerkDatabase
import com.example.data.model.BookmarkEntry
import com.example.data.model.BrowserTab
import com.example.data.model.DemoWebPage
import com.example.data.model.DemoWebPagesRepository
import com.example.data.model.HistoryEntry
import com.example.data.model.PrivacyEvent
import com.example.data.model.PrivacyStatistics
import com.example.data.model.ResearchDocument
import com.example.data.model.SecurityInfo
import com.example.data.model.TabGroup
import com.example.language.GermanCompoundAnalyzer
import com.example.language.GermanSpellchecker
import com.example.language.GermanTypography
import com.example.reader.ReaderArticle
import com.example.reader.ReaderEngine
import com.example.reader.ReaderSettings
import com.example.reader.TextToSpeechManager
import com.example.search.SearchEngine
import com.example.search.SearchResultItem
import com.example.search.UniversalInputType
import com.example.search.UniversalzeileParser
import com.example.translation.WerkTranslator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class ActiveScreen {
    BROWSER_WEB,
    START_PAGE,
    READER_MODE,
    RESEARCH_WORKSPACE,
    COMPARE_VIEW,
    PRIVACY_CENTER,
    SECURITY_CENTER,
    PERFORMANCE_CENTER,
    DIAGNOSTICS,
    SETTINGS,
    HISTORY_BOOKMARKS,
    TRANSLATOR
}

class WerkViewModel(application: Application) : AndroidViewModel(application) {

    private val db = WerkDatabase.getInstance(application)
    val ttsManager = TextToSpeechManager(application)

    // Tab-Gruppen
    val tabGroups = listOf(
        TabGroup("grp_arbeit", "Arbeit & Dokumente", 0xFF1E3A5F),
        TabGroup("grp_recherche", "Recherche & Wissenschaft", 0xFFC0392B),
        TabGroup("grp_finanzen", "Wirtschaft & Finanzen", 0xFF27AE60)
    )

    // Tabs
    private val _tabs = MutableStateFlow<List<BrowserTab>>(
        listOf(
            BrowserTab(
                id = "tab_initial",
                url = "werk://start",
                title = "Neuer Tab",
                isPinned = false,
                groupId = null
            )
        )
    )
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow("tab_initial")
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    val activeTab: BrowserTab
        get() = _tabs.value.find { it.id == _activeTabId.value } ?: _tabs.value.first()

    // Aktueller Bildschirm
    private val _currentScreen = MutableStateFlow(ActiveScreen.START_PAGE)
    val currentScreen: StateFlow<ActiveScreen> = _currentScreen.asStateFlow()

    // Universalzeile State
    private val _universalInput = MutableStateFlow("")
    val universalInput: StateFlow<String> = _universalInput.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchResultItem>>(emptyList())
    val searchResults: StateFlow<List<SearchResultItem>> = _searchResults.asStateFlow()

    private val _searchCompoundAnalysis = MutableStateFlow<GermanCompoundAnalyzer.CompoundAnalysis?>(null)
    val searchCompoundAnalysis: StateFlow<GermanCompoundAnalyzer.CompoundAnalysis?> = _searchCompoundAnalysis.asStateFlow()

    private val _spellSuggestions = MutableStateFlow<List<GermanSpellchecker.SpellSuggestion>>(emptyList())
    val spellSuggestions: StateFlow<List<GermanSpellchecker.SpellSuggestion>> = _spellSuggestions.asStateFlow()

    private val _calcPreview = MutableStateFlow<String?>(null)
    val calcPreview: StateFlow<String?> = _calcPreview.asStateFlow()

    // Reader Mode State
    private val _readerArticle = MutableStateFlow<ReaderArticle?>(null)
    val readerArticle: StateFlow<ReaderArticle?> = _readerArticle.asStateFlow()

    private val _readerSettings = MutableStateFlow(ReaderSettings())
    val readerSettings: StateFlow<ReaderSettings> = _readerSettings.asStateFlow()

    // Recherche State
    val savedResearchDocs = db.researchDao().getAllResearch()

    // History & Bookmarks Flow
    val historyList = db.historyDao().getAllHistory()
    val bookmarksList = db.bookmarkDao().getAllBookmarks()
    val privacyEvents = db.privacyDao().getRecentEvents()

    // Privacy Stats
    private val _privacyStats = MutableStateFlow(PrivacyStatistics())
    val privacyStats: StateFlow<PrivacyStatistics> = _privacyStats.asStateFlow()

    // Zweisprachige Übersetzung State
    private val _bilingualTranslation = MutableStateFlow<WerkTranslator.TranslationResult?>(null)
    val bilingualTranslation: StateFlow<WerkTranslator.TranslationResult?> = _bilingualTranslation.asStateFlow()

    // Vergleichsansicht State
    private val _compareSourceA = MutableStateFlow(DemoWebPagesRepository.pages[0])
    val compareSourceA: StateFlow<DemoWebPage> = _compareSourceA.asStateFlow()

    private val _compareSourceB = MutableStateFlow(DemoWebPagesRepository.pages[1])
    val compareSourceB: StateFlow<DemoWebPage> = _compareSourceB.asStateFlow()

    // WERK AI State
    private val _aiReport = MutableStateFlow<com.example.ai.AiAnalysisReport?>(null)
    val aiReport: StateFlow<com.example.ai.AiAnalysisReport?> = _aiReport.asStateFlow()

    init {
        // Initialer Demo-Eintrag für Recherche, falls leer
        viewModelScope.launch {
            db.bookmarkDao().insert(
                BookmarkEntry(
                    url = "https://forschung.bund.de/energiespeichertechnologie",
                    title = "Nationale Forschungsinitiative: Energiespeichertechnologie 2030",
                    folder = "Wissenschaft",
                    tags = "Batterie, Energie, Förderung",
                    notes = "Wichtiges Referenzdokument für europäische Fördermittel"
                )
            )
            db.bookmarkDao().insert(
                BookmarkEntry(
                    url = "https://bahn-zukunft.de/hochgeschwindigkeitsbahn",
                    title = "Hochgeschwindigkeitsbahn: Transeuropäische Netze",
                    folder = "Infrastruktur",
                    tags = "Mobilität, ETCS 3",
                    notes = "Vergleichsdaten für Verkehrsträger"
                )
            )
        }
    }

    fun onUniversalInputChange(newText: String) {
        _universalInput.value = newText
        if (newText.isNotBlank()) {
            // Prüfung auf Komposita
            val firstWord = newText.trim().split(" ").firstOrNull() ?: ""
            if (firstWord.length > 6) {
                _searchCompoundAnalysis.value = GermanCompoundAnalyzer.analyze(firstWord)
            } else {
                _searchCompoundAnalysis.value = null
            }

            // Prüfung auf Rechtschreib- und Trennungsfehler
            _spellSuggestions.value = GermanSpellchecker.checkText(newText)

            // Schnellberechnung
            val parsed = UniversalzeileParser.parse(newText)
            if (parsed is UniversalInputType.Calculation) {
                _calcPreview.value = "= ${parsed.formatted}"
            } else {
                _calcPreview.value = null
            }
        } else {
            _searchCompoundAnalysis.value = null
            _spellSuggestions.value = emptyList()
            _calcPreview.value = null
        }
    }

    fun submitUniversalInput(input: String = _universalInput.value) {
        val parsed = UniversalzeileParser.parse(input)
        when (parsed) {
            is UniversalInputType.InternalPage -> {
                navigateToInternal(parsed.destination)
            }
            is UniversalInputType.Command -> {
                executeCommand(parsed.command, parsed.argument)
            }
            is UniversalInputType.DirectUrl -> {
                loadUrl(parsed.url)
            }
            is UniversalInputType.SearchQuery -> {
                performSearch(parsed.query)
            }
            is UniversalInputType.Calculation -> {
                // Bei Enter in Suche mit Rechenergebnis anzeigen
                _calcPreview.value = "= ${parsed.formatted}"
            }
        }
    }

    fun executeCommand(command: String, argument: String) {
        when (command) {
            "suche" -> performSearch(argument)
            "verlauf" -> _currentScreen.value = ActiveScreen.HISTORY_BOOKMARKS
            "lesezeichen" -> _currentScreen.value = ActiveScreen.HISTORY_BOOKMARKS
            "downloads" -> _currentScreen.value = ActiveScreen.SETTINGS
            "einstellungen" -> _currentScreen.value = ActiveScreen.SETTINGS
            "datenschutz" -> _currentScreen.value = ActiveScreen.PRIVACY_CENTER
            "sicherheit" -> _currentScreen.value = ActiveScreen.SECURITY_CENTER
            "recherche" -> {
                if (argument.isNotBlank()) performSearch(argument)
                _currentScreen.value = ActiveScreen.RESEARCH_WORKSPACE
            }
            "vergleich" -> _currentScreen.value = ActiveScreen.COMPARE_VIEW
            "diagnose" -> _currentScreen.value = ActiveScreen.DIAGNOSTICS
            "performance" -> _currentScreen.value = ActiveScreen.PERFORMANCE_CENTER
            "übersetzen", "uebersetzen" -> translateCurrentPage()
            "zusammenfassen" -> summarizeCurrentPage()
            else -> performSearch(argument.ifEmpty { command })
        }
    }

    fun navigateToInternal(destination: String) {
        when (destination.lowercase()) {
            "start" -> _currentScreen.value = ActiveScreen.START_PAGE
            "recherche" -> _currentScreen.value = ActiveScreen.RESEARCH_WORKSPACE
            "datenschutz" -> _currentScreen.value = ActiveScreen.PRIVACY_CENTER
            "sicherheit" -> _currentScreen.value = ActiveScreen.SECURITY_CENTER
            "performance" -> _currentScreen.value = ActiveScreen.PERFORMANCE_CENTER
            "diagnose" -> _currentScreen.value = ActiveScreen.DIAGNOSTICS
            "einstellungen" -> _currentScreen.value = ActiveScreen.SETTINGS
            "lesezeichen", "verlauf" -> _currentScreen.value = ActiveScreen.HISTORY_BOOKMARKS
            "vergleich" -> _currentScreen.value = ActiveScreen.COMPARE_VIEW
            else -> _currentScreen.value = ActiveScreen.START_PAGE
        }
    }

    fun loadUrl(url: String) {
        val currentTab = activeTab
        val updatedTabs = _tabs.value.map { tab ->
            if (tab.id == currentTab.id) {
                tab.copy(url = url, title = url.substringAfter("://").take(30), isLoading = true)
            } else tab
        }
        _tabs.value = updatedTabs
        _universalInput.value = url

        // Prüfe ob Demo-Dokument
        val demo = DemoWebPagesRepository.findByUrlOrQuery(url)
        if (demo != null) {
            updateTabContent(currentTab.id, demo.url, demo.title, demo.fullText)
        }

        // Speichere im Verlauf
        viewModelScope.launch {
            val domain = try { java.net.URI(url).host ?: url } catch (e: Exception) { url }
            db.historyDao().insert(
                HistoryEntry(
                    url = url,
                    title = if (demo != null) demo.title else url,
                    timestamp = System.currentTimeMillis(),
                    domain = domain
                )
            )
        }

        _currentScreen.value = ActiveScreen.BROWSER_WEB
    }

    fun updateTabContent(tabId: String, url: String, title: String, content: String?) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == tabId) {
                tab.copy(url = url, title = title, extractedContent = content, isLoading = false)
            } else tab
        }
    }

    fun performSearch(query: String) {
        _universalInput.value = query
        val results = SearchEngine.search(query)
        _searchResults.value = results
        _currentScreen.value = ActiveScreen.BROWSER_WEB
    }

    // Tab-Management
    fun addNewTab(url: String = "werk://start", groupId: String? = null) {
        val newId = UUID.randomUUID().toString()
        val newTab = BrowserTab(
            id = newId,
            url = url,
            title = "Neuer Tab",
            groupId = groupId
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newId
        _universalInput.value = if (url == "werk://start") "" else url
        if (url == "werk://start") {
            _currentScreen.value = ActiveScreen.START_PAGE
        } else {
            loadUrl(url)
        }
    }

    fun selectTab(id: String) {
        _activeTabId.value = id
        val tab = _tabs.value.find { it.id == id }
        if (tab != null) {
            _universalInput.value = if (tab.url == "werk://start") "" else tab.url
            if (tab.url == "werk://start") {
                _currentScreen.value = ActiveScreen.START_PAGE
            } else {
                _currentScreen.value = ActiveScreen.BROWSER_WEB
            }
        }
    }

    fun closeTab(id: String) {
        if (_tabs.value.size <= 1) {
            // Letzten Tab nicht löschen, sondern auf Startseite zurücksetzen
            _tabs.value = listOf(
                BrowserTab(
                    id = UUID.randomUUID().toString(),
                    url = "werk://start",
                    title = "Neuer Tab"
                )
            )
            _activeTabId.value = _tabs.value.first().id
            _currentScreen.value = ActiveScreen.START_PAGE
            return
        }

        val remaining = _tabs.value.filter { it.id != id }
        _tabs.value = remaining
        if (_activeTabId.value == id) {
            _activeTabId.value = remaining.last().id
        }
    }

    fun togglePinTab(id: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) it.copy(isPinned = !it.isPinned) else it
        }
    }

    fun toggleMuteTab(id: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) it.copy(isMuted = !it.isMuted) else it
        }
    }

    fun assignTabGroup(tabId: String, groupId: String?) {
        _tabs.value = _tabs.value.map {
            if (it.id == tabId) it.copy(groupId = groupId) else it
        }
    }

    fun suspendTab(id: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) it.copy(isSuspended = true, memoryMb = 4.2, cpuPercent = 0.0) else it
        }
    }

    fun resumeTab(id: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) it.copy(isSuspended = false, memoryMb = 38.6, cpuPercent = 0.9) else it
        }
    }

    // Reader Mode
    fun openReaderMode() {
        val tab = activeTab
        val demo = DemoWebPagesRepository.findByUrlOrQuery(tab.url)
        val text = demo?.fullText ?: tab.extractedContent ?: "Dokumentation für ${tab.title} im Lesemodus geladen."
        _readerArticle.value = ReaderEngine.extractArticle(tab.url, text)
        _currentScreen.value = ActiveScreen.READER_MODE
    }

    fun updateReaderSettings(settings: ReaderSettings) {
        _readerSettings.value = settings
    }

    // Vorlesen / TTS
    fun playCurrentArticleSpeech() {
        val article = _readerArticle.value ?: return
        ttsManager.playText(article.fullText)
    }

    fun pauseOrResumeSpeech() {
        ttsManager.pauseOrResume()
    }

    fun stopSpeech() {
        ttsManager.stop()
    }

    // Recherche speichern
    fun saveToResearch(
        title: String,
        author: String = "Fachquelle",
        date: String = "2026",
        url: String = activeTab.url,
        snippet: String,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val doc = ResearchDocument(
                title = title,
                author = author,
                dateOrYear = date,
                url = url,
                originalSnippet = snippet,
                notes = notes,
                savedAt = System.currentTimeMillis()
            )
            val apa = CitationGenerator.format(doc, CitationGenerator.CitationFormat.APA)
            val din = CitationGenerator.format(doc, CitationGenerator.CitationFormat.DIN_ISO_690)
            db.researchDao().insert(doc.copy(citationApa = apa, citationDin = din))
        }
    }

    // WERK AI
    fun summarizeCurrentPage() {
        val tab = activeTab
        val demo = DemoWebPagesRepository.findByUrlOrQuery(tab.url)
        val text = demo?.fullText ?: tab.extractedContent ?: "Kein ausreichender Text verfügbar."
        _aiReport.value = WerkAiEngine.summarizeContent(tab.title, tab.url, text)
        _currentScreen.value = ActiveScreen.RESEARCH_WORKSPACE
    }

    fun extractTablesCurrentPage() {
        val tab = activeTab
        val demo = DemoWebPagesRepository.findByUrlOrQuery(tab.url)
        val text = demo?.fullText ?: tab.extractedContent ?: "Kein Text verfügbar."
        _aiReport.value = WerkAiEngine.extractDataTables(tab.title, tab.url, text)
        _currentScreen.value = ActiveScreen.RESEARCH_WORKSPACE
    }

    // Übersetzung
    fun translateCurrentPage(targetLang: String = "de") {
        val tab = activeTab
        val demo = DemoWebPagesRepository.findByUrlOrQuery(tab.url)
        val text = demo?.fullText ?: tab.extractedContent ?: tab.title
        _bilingualTranslation.value = WerkTranslator.translate(text, fromLang = "auto", toLang = targetLang)
        _currentScreen.value = ActiveScreen.TRANSLATOR
    }

    // Tracking / Privacy Events
    fun recordBlockedTracker(siteUrl: String, trackerInfo: String) {
        viewModelScope.launch {
            db.privacyDao().insert(
                PrivacyEvent(
                    timestamp = System.currentTimeMillis(),
                    siteUrl = siteUrl,
                    blockedItem = trackerInfo,
                    category = "TRACKER"
                )
            )
            _privacyStats.value = _privacyStats.value.copy(
                trackersBlockedToday = _privacyStats.value.trackersBlockedToday + 1
            )
        }
    }

    fun recordSecurityUpdate(securityInfo: SecurityInfo) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == _activeTabId.value) tab.copy(securityInfo = securityInfo) else tab
        }
    }

    fun toggleBookmarkCurrentPage() {
        viewModelScope.launch {
            val url = activeTab.url
            val title = activeTab.title
            val isBookmarked = db.bookmarkDao().isBookmarked(url)
            if (isBookmarked) {
                db.bookmarkDao().deleteByUrl(url)
            } else {
                db.bookmarkDao().insert(
                    BookmarkEntry(
                        url = url,
                        title = title,
                        folder = "Standard",
                        tags = "Web",
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun deleteResearchDoc(doc: ResearchDocument) {
        viewModelScope.launch {
            db.researchDao().delete(doc)
        }
    }

    fun deleteHistoryEntry(id: Long) {
        viewModelScope.launch {
            db.historyDao().deleteById(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            db.historyDao().clearAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
    }
}
