package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WerkDarkColorScheme = darkColorScheme(
    primary = WerkDarkPrimary,
    onPrimary = WerkDarkBackground,
    primaryContainer = WerkNavyDeep,
    onPrimaryContainer = Color(0xFFD4E3F3),
    secondary = WerkSteel,
    onSecondary = Color.White,
    secondaryContainer = WerkDarkSurfaceVariant,
    onSecondaryContainer = WerkDarkTextPrimary,
    tertiary = WerkBauhausRed,
    onTertiary = Color.White,
    background = WerkDarkBackground,
    onBackground = WerkDarkTextPrimary,
    surface = WerkDarkSurface,
    onSurface = WerkDarkTextPrimary,
    surfaceVariant = WerkDarkSurfaceVariant,
    onSurfaceVariant = WerkDarkTextSecondary,
    outline = WerkDarkBorder,
    error = WerkBauhausRed,
    onError = Color.White
)

private val WerkLightColorScheme = lightColorScheme(
    primary = WerkNavyPrimary,
    onPrimary = Color.White,
    primaryContainer = WerkMutedSurface,
    onPrimaryContainer = WerkNavyDeep,
    secondary = WerkSteel,
    onSecondary = Color.White,
    secondaryContainer = WerkOffWhite,
    onSecondaryContainer = WerkGraphite,
    tertiary = WerkBauhausRed,
    onTertiary = Color.White,
    background = WerkPaperWhite,
    onBackground = WerkCharcoal,
    surface = Color.White,
    onSurface = WerkGraphite,
    surfaceVariant = WerkOffWhite,
    onSurfaceVariant = WerkSteel,
    outline = WerkBorderGray,
    error = WerkBauhausRed,
    onError = Color.White
)

@Composable
fun WerkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) WerkDarkColorScheme else WerkLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
