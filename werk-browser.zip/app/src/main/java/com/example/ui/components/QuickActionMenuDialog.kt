package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChromeReaderMode
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.GTranslate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.ActiveScreen

@Composable
fun QuickActionMenuDialog(
    onNavigate: (ActiveScreen) -> Unit,
    onOpenReader: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("quick_action_menu_dialog")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "WERK BROWSER",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Europäische Informationsplattform",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                ActionMenuItem(
                    icon = Icons.Default.MenuBook,
                    title = "Recherche & Zitate",
                    subtitle = "Quellen verwalten & exportieren (APA, DIN)",
                    onClick = {
                        onNavigate(ActiveScreen.RESEARCH_WORKSPACE)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.ChromeReaderMode,
                    title = "Lesemodus & Vorlesen",
                    subtitle = "Störungsfreies Lesen & deutsche Sprachausgabe",
                    onClick = {
                        onOpenReader()
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.GTranslate,
                    title = "Übersetzer (Zweisprachig)",
                    subtitle = "Split-Screen Übersetzung DE, EN, FR, IT",
                    onClick = {
                        onNavigate(ActiveScreen.TRANSLATOR)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Compare,
                    title = "Vergleichsansicht",
                    subtitle = "Zwei Quellen parallel analysieren",
                    onClick = {
                        onNavigate(ActiveScreen.COMPARE_VIEW)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Shield,
                    title = "Datenschutz-Center",
                    subtitle = "Tracking-Blocker & Cookie-Isolation",
                    onClick = {
                        onNavigate(ActiveScreen.PRIVACY_CENTER)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Security,
                    title = "Sicherheits-Center",
                    subtitle = "TLS 1.3, Zertifikate & Sandbox-Status",
                    onClick = {
                        onNavigate(ActiveScreen.SECURITY_CENTER)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Speed,
                    title = "Performance Center",
                    subtitle = "RAM- & CPU-Verbrauch pro Tab steuern",
                    onClick = {
                        onNavigate(ActiveScreen.PERFORMANCE_CENTER)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Build,
                    title = "Systemdiagnose",
                    subtitle = "werk://diagnose Sprachkern & Engine",
                    onClick = {
                        onNavigate(ActiveScreen.DIAGNOSTICS)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.History,
                    title = "Verlauf & Lesezeichen",
                    subtitle = "Chronik und Sammlungen",
                    onClick = {
                        onNavigate(ActiveScreen.HISTORY_BOOKMARKS)
                        onDismiss()
                    }
                )

                ActionMenuItem(
                    icon = Icons.Default.Settings,
                    title = "Einstellungen",
                    subtitle = "Sprache, Suche und Browser-Optionen",
                    onClick = {
                        onNavigate(ActiveScreen.SETTINGS)
                        onDismiss()
                    }
                )
            }
        }
    }
}

@Composable
private fun ActionMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
