package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WerkSettingsScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var compoundSearchEnabled by remember { mutableStateOf(true) }
    var multilingualSearchEnabled by remember { mutableStateOf(true) }
    var gpcEnabled by remember { mutableStateOf(true) }
    var localAiOnly by remember { mutableStateOf(true) }
    var autoTabSuspension by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "EINSTELLUNGEN",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Schließen")
                }
            }
        }

        // Kategorie: Sprache & Typografie
        item {
            SettingsCategoryCard(title = "Sprache & Typografie", icon = Icons.Default.Language) {
                Text(
                    text = "Primärsprache: Deutsch (Deutschland)",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Unterstützt Unicode 16.0, korrekte Worttrennung, Komposita-Stammbäume und typografische Anführungszeichen („…“ & »…«).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Kategorie: Suche
        item {
            SettingsCategoryCard(title = "Intelligente Suche", icon = Icons.Default.Search) {
                SettingsSwitchRow(
                    title = "Komposita-Zerlegung (Morphologie)",
                    desc = "Findet Wortstämme (z.B. Eisenbahn -> Eisenbahnverkehr) automatisch.",
                    checked = compoundSearchEnabled,
                    onCheckedChange = { compoundSearchEnabled = it }
                )
                SettingsSwitchRow(
                    title = "Mehrsprachige europäische Suche",
                    desc = "Erweitert deutsche Anfragen transparent um europäische Fachquellen.",
                    checked = multilingualSearchEnabled,
                    onCheckedChange = { multilingualSearchEnabled = it }
                )
            }
        }

        // Kategorie: Datenschutz
        item {
            SettingsCategoryCard(title = "Datenschutz & Sicherheit", icon = Icons.Default.Shield) {
                SettingsSwitchRow(
                    title = "Global Privacy Control (GPC)",
                    desc = "Signalisiert Webseiten das Verbot von Datenverkauf und Tracking.",
                    checked = gpcEnabled,
                    onCheckedChange = { gpcEnabled = it }
                )
                SettingsSwitchRow(
                    title = "Lokale KI-Verarbeitung (On-Device)",
                    desc = "Keine Datenübertragung von Webseitentexten an externe Cloud-Server.",
                    checked = localAiOnly,
                    onCheckedChange = { localAiOnly = it }
                )
                SettingsSwitchRow(
                    title = "Automatische Tab-Pausierung",
                    desc = "Senkt RAM-Verbrauch im Hintergrund um bis zu 85 %.",
                    checked = autoTabSuspension,
                    onCheckedChange = { autoTabSuspension = it }
                )
            }
        }

        // Kategorie: Über WERK
        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Über WERK BROWSER",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Version 1.0 (Europa-Release)\n" +
                                "Gebaut auf den Prinzipien deutscher Ingenieurskunst, offener europäischer Standards, digitaler Souveränität und kompromisslosem Datenschutz.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsCategoryCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
