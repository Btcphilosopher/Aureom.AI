package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WERK BROWSER Bauhaus & German Precision Palette
// Primär: Tiefes Preußischblau & Graphit
val WerkGraphite = Color(0xFF1E2530)
val WerkCharcoal = Color(0xFF12161E)
val WerkSteel = Color(0xFF536271)
val WerkSlate = Color(0xFF7E8B9B)
val WerkNavyDeep = Color(0xFF132238)
val WerkNavyPrimary = Color(0xFF1E3A5F)
val WerkBlueAccent = Color(0xFF2B5B88)

// Helle Töne: Warmes Weiß, Papier & Helles Grau
val WerkPaperWhite = Color(0xFFF9F9FA)
val WerkOffWhite = Color(0xFFF2F4F7)
val WerkLightGray = Color(0xFFE5E7EB)
val WerkBorderGray = Color(0xFFD1D5DB)
val WerkMutedSurface = Color(0xFFE9ECF0)

// Bauhaus Akzentfarben: Gedämpftes Rubinrot & Ockergelb
val WerkBauhausRed = Color(0xFFC0392B)
val WerkBauhausRedSubtle = Color(0xFFFADBD8)
val WerkBauhausAmber = Color(0xFFD4AC0D)
val WerkBauhausGreen = Color(0xFF27AE60)

// Sepia Reader Mode
val WerkSepiaBackground = Color(0xFFFBF0D9)
val WerkSepiaText = Color(0xFF5F4B32)
val WerkSepiaSurface = Color(0xFFF4E4C1)

// Dark Mode Palette (Deep Graphite & Dark Navy, no neon glows)
val WerkDarkBackground = Color(0xFF11141A)
val WerkDarkSurface = Color(0xFF181D26)
val WerkDarkSurfaceVariant = Color(0xFF222834)
val WerkDarkBorder = Color(0xFF2F3746)
val WerkDarkTextPrimary = Color(0xFFE5E7EB)
val WerkDarkTextSecondary = Color(0xFF9CA3AF)
val WerkDarkPrimary = Color(0xFF6B9AC4)
