package com.example

import com.example.language.GermanCompoundAnalyzer
import com.example.language.GermanSpellchecker
import com.example.language.GermanTypography
import com.example.privacy.PrivacyEngine
import com.example.search.UniversalInputType
import com.example.search.UniversalzeileParser
import com.example.translation.WerkTranslator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testGermanTypographyFormatting() {
        val currencyFormatted = GermanTypography.formatCurrency(1234567.89)
        assertTrue(currencyFormatted.contains("1.234.567,89"))
        assertTrue(currencyFormatted.contains("€"))

        val quoteInput = "Hier ist ein \"Test\" fuer Typografie."
        val quoted = GermanTypography.applyGermanQuotes(quoteInput)
        assertEquals("Hier ist ein „Test“ fuer Typografie.", quoted)

        val glyphsValid = GermanTypography.containsGermanSpecificGlyphs("ÄÖÜ äöü ß")
        assertTrue(glyphsValid)
    }

    @Test
    fun testGermanCompoundAnalyzer() {
        val analysis = GermanCompoundAnalyzer.analyze("Datenschutzgrundverordnung")
        assertTrue(analysis.isCompound)
        assertEquals(listOf("Daten", "Schutz", "Grund", "Verordnung"), analysis.constituents)

        val bvg = GermanCompoundAnalyzer.analyze("Bundesverfassungsgericht")
        assertTrue(bvg.isCompound)
        assertEquals(listOf("Bundes", "Verfassung", "Gericht"), bvg.constituents)

        val ddsg = GermanCompoundAnalyzer.analyze("Donaudampfschifffahrtsgesellschaft")
        assertTrue(ddsg.isCompound)
    }

    @Test
    fun testGermanSpellchecker() {
        val suggestions = GermanSpellchecker.checkText("Hier geht es um daten schutz im Internet.")
        assertTrue(suggestions.any { it.suggestion == "Datenschutz" })
    }

    @Test
    fun testUniversalzeileParser() {
        // Berechnungen
        val math = UniversalzeileParser.parse("1.250 * 48")
        assertTrue(math is UniversalInputType.Calculation)
        val calc = math as UniversalInputType.Calculation
        assertEquals(60000.0, calc.result, 0.01)

        // Interne Schemata
        val internal = UniversalzeileParser.parse("werk://datenschutz")
        assertTrue(internal is UniversalInputType.InternalPage)
        assertEquals("datenschutz", (internal as UniversalInputType.InternalPage).destination)

        // Befehle
        val cmd = UniversalzeileParser.parse("/recherche deutsche Energiewirtschaft")
        assertTrue(cmd is UniversalInputType.Command)
        assertEquals("recherche", (cmd as UniversalInputType.Command).command)
        assertEquals("deutsche Energiewirtschaft", cmd.argument)

        // Web-URLs
        val web = UniversalzeileParser.parse("https://heise.de")
        assertTrue(web is UniversalInputType.DirectUrl)
    }

    @Test
    fun testPrivacyEngineTrackerBlocking() {
        val trackerEval = PrivacyEngine.evaluateUrl("https://www.google-analytics.com/analytics.js")
        assertTrue(trackerEval.shouldBlock)
        assertEquals(PrivacyEngine.BlockReason.TRACKER, trackerEval.reason)

        val safeEval = PrivacyEngine.evaluateUrl("https://forschung.bund.de/energiespeicher")
        assertFalse(safeEval.shouldBlock)
    }

    @Test
    fun testWerkTranslator() {
        val result = WerkTranslator.translate("Datenschutzgrundverordnung", "de", "en")
        assertTrue(result.translatedText.contains("General Data Protection Regulation"))
    }
}
