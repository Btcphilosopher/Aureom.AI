package com.example.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

data class GlSliceFrame(
    val key: String,
    val width: Int,
    val height: Int,
    val pixels: FloatArray,
    val missingMask: BooleanArray?,
    val photometricInterpretation: String,
)

@Composable
fun MriSliceGlView(
    frame: GlSliceFrame?,
    windowCenter: Double,
    windowWidth: Double,
    invert: Boolean,
    zoom: Float,
    panXNorm: Float,
    panYNorm: Float,
    modifier: Modifier = Modifier,
) {
    val renderer = remember { MriSliceRenderer() }

    AndroidView(
        modifier = modifier,
        factory = { ctx: Context ->
            GLSurfaceView(ctx).apply {
                setEGLContextClientVersion(3)
                preserveEGLContextOnPause = true
                setRenderer(renderer)
                renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            }
        },
        update = { view ->
            renderer.updateParams(
                frame = frame,
                windowCenter = windowCenter.toFloat(),
                windowWidth = windowWidth.toFloat().coerceAtLeast(1f),
                invert = invert,
                zoom = zoom.coerceIn(0.25f, 12f),
                panX = panXNorm,
                panY = panYNorm,
            )
            view.requestRender()
        },
    )

    DisposableEffect(Unit) {
        onDispose { renderer.releasePending() }
    }
}

private class MriSliceRenderer : GLSurfaceView.Renderer {
    private var program = 0
    private var textureId = 0
    private var quadBuffer: FloatBuffer = ByteBuffer.allocateDirect(16 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(
                floatArrayOf(
                    // x, y, u, v
                    -1f, -1f, 0f, 1f,
                    1f, -1f, 1f, 1f,
                    -1f, 1f, 0f, 0f,
                    1f, 1f, 1f, 0f,
                )
            )
            position(0)
        }

    @Volatile private var pendingFrame: GlSliceFrame? = null
    @Volatile private var lastUploadedKey: String? = null
    @Volatile private var baseMin: Float = 0f
    @Volatile private var baseRange: Float = 1f
    @Volatile private var imageWidth: Int = 1
    @Volatile private var imageHeight: Int = 1
    @Volatile private var viewWidth: Int = 1
    @Volatile private var viewHeight: Int = 1

    @Volatile private var wc: Float = 500f
    @Volatile private var ww: Float = 1000f
    @Volatile private var invertFlag: Boolean = false
    @Volatile private var isMono1: Boolean = false
    @Volatile private var zoomVal: Float = 1f
    @Volatile private var panXVal: Float = 0f
    @Volatile private var panYVal: Float = 0f

    fun updateParams(
        frame: GlSliceFrame?,
        windowCenter: Float,
        windowWidth: Float,
        invert: Boolean,
        zoom: Float,
        panX: Float,
        panY: Float,
    ) {
        if (frame != null && frame.key != lastUploadedKey) {
            pendingFrame = frame
        }
        wc = windowCenter
        ww = windowWidth
        invertFlag = invert
        isMono1 = frame?.photometricInterpretation == "MONOCHROME1"
        zoomVal = zoom
        panXVal = panX
        panYVal = panY
    }

    fun releasePending() {
        pendingFrame = null
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.055f, 0.067f, 0.086f, 1f) // #0E1116 Graphite
        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        textureId = tex[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        lastUploadedKey = null
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewWidth = max(1, width)
        viewHeight = max(1, height)
        GLES30.glViewport(0, 0, viewWidth, viewHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        val frame = pendingFrame
        if (frame != null && frame.key != lastUploadedKey) {
            uploadFrameTexture(frame)
            lastUploadedKey = frame.key
        }
        if (lastUploadedKey == null || program == 0) return

        GLES30.glUseProgram(program)
        val imgAspect = imageWidth.toFloat() / imageHeight.toFloat()
        val viewAspect = viewWidth.toFloat() / viewHeight.toFloat()
        val scaleX = if (imgAspect > viewAspect) 1f else imgAspect / viewAspect
        val scaleY = if (imgAspect > viewAspect) viewAspect / imgAspect else 1f

        GLES30.glUniform2f(GLES30.glGetUniformLocation(program, "uAspectScale"), scaleX, scaleY)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uZoom"), zoomVal)
        GLES30.glUniform2f(GLES30.glGetUniformLocation(program, "uPan"), panXVal, panYVal)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uBaseMin"), baseMin)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uBaseRange"), baseRange)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uWC"), wc)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uWW"), ww)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uInvert"), if (invertFlag xor isMono1) 1 else 0)
        GLES30.glUniform2f(GLES30.glGetUniformLocation(program, "uImageSize"), imageWidth.toFloat(), imageHeight.toFloat())

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uTex"), 0)

        val posAttr = GLES30.glGetAttribLocation(program, "aPos")
        val uvAttr = GLES30.glGetAttribLocation(program, "aUv")
        quadBuffer.position(0)
        GLES30.glEnableVertexAttribArray(posAttr)
        GLES30.glVertexAttribPointer(posAttr, 2, GLES30.GL_FLOAT, false, 16, quadBuffer)
        quadBuffer.position(2)
        GLES30.glEnableVertexAttribArray(uvAttr)
        GLES30.glVertexAttribPointer(uvAttr, 2, GLES30.GL_FLOAT, false, 16, quadBuffer)

        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

        GLES30.glDisableVertexAttribArray(posAttr)
        GLES30.glDisableVertexAttribArray(uvAttr)
    }

    private fun uploadFrameTexture(frame: GlSliceFrame) {
        val count = frame.width * frame.height
        var minV = Float.MAX_VALUE
        var maxV = -Float.MAX_VALUE
        for (i in 0 until min(count, frame.pixels.size)) {
            if (frame.missingMask?.getOrNull(i) == true) continue
            val v = frame.pixels[i]
            if (v < minV) minV = v
            if (v > maxV) maxV = v
        }
        if (minV == Float.MAX_VALUE) {
            minV = 0f
            maxV = 1f
        }
        val range = (maxV - minV).coerceAtLeast(1f)
        baseMin = minV
        baseRange = range
        imageWidth = frame.width
        imageHeight = frame.height

        // Pack 16-bit normalized intensity across R (high byte) & G (low byte), missing mask in B
        val rgba = ByteBuffer.allocateDirect(count * 4)
        for (i in 0 until count) {
            val missing = frame.missingMask?.getOrNull(i) == true
            if (missing) {
                rgba.put(0.toByte()).put(0.toByte()).put(255.toByte()).put(255.toByte())
            } else {
                val p = frame.pixels.getOrElse(i) { minV }
                val q = (((p - minV) / range).coerceIn(0f, 1f) * 65535f).toInt()
                rgba.put(((q shr 8) and 0xFF).toByte())
                    .put((q and 0xFF).toByte())
                    .put(0.toByte())
                    .put(255.toByte())
            }
        }
        rgba.position(0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D,
            0,
            GLES30.GL_RGBA,
            frame.width,
            frame.height,
            0,
            GLES30.GL_RGBA,
            GLES30.GL_UNSIGNED_BYTE,
            rgba,
        )
    }

    private fun buildProgram(vsSrc: String, fsSrc: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSrc)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSrc)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)
        return shader
    }

    companion object {
        private const val VERTEX_SHADER = """
            #version 300 es
            layout(location = 0) in vec2 aPos;
            layout(location = 1) in vec2 aUv;
            uniform vec2 uAspectScale;
            uniform float uZoom;
            uniform vec2 uPan;
            out vec2 vUv;
            void main() {
                vec2 scaled = aPos * uAspectScale * uZoom + uPan;
                gl_Position = vec4(scaled, 0.0, 1.0);
                vUv = aUv;
            }
        """

        private const val FRAGMENT_SHADER = """
            #version 300 es
            precision highp float;
            in vec2 vUv;
            uniform sampler2D uTex;
            uniform float uBaseMin;
            uniform float uBaseRange;
            uniform float uWC;
            uniform float uWW;
            uniform int uInvert;
            uniform vec2 uImageSize;
            out vec4 fragColor;
            void main() {
                vec4 texel = texture(uTex, vUv);
                if (texel.b > 0.5) {
                    // Explicit hatched pattern for missing-data / out-of-bounds MPR voxels
                    float hatch = mod(floor(vUv.x * uImageSize.x) + floor(vUv.y * uImageSize.y), 6.0);
                    float c = hatch < 1.5 ? 0.14 : 0.07;
                    fragColor = vec4(c, c * 1.15, c * 1.35, 1.0);
                    return;
                }
                float norm16 = (texel.r * 255.0 * 256.0 + texel.g * 255.0) / 65535.0;
                float intensity = uBaseMin + norm16 * uBaseRange;
                float low = uWC - 0.5 * uWW;
                float g = clamp((intensity - low) / max(uWW, 1.0), 0.0, 1.0);
                if (uInvert == 1) {
                    g = 1.0 - g;
                }
                fragColor = vec4(g, g, g, 1.0);
            }
        """
    }
}
