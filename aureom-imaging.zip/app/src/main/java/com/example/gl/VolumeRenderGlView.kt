package com.example.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.dicom.DicomSlice
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

enum class VolumeTransferPreset(val id: Int, val label: String) {
    STANDARD_TISSUE(0, "MRI Tissue"),
    MIP(1, "MIP"),
    HIGH_CONTRAST(2, "High-Contrast"),
}

enum class VolumeQuality(val steps: Int, val label: String) {
    FAST(48, "Draft (48)"),
    BALANCED(96, "Balanced (96)"),
    HIGH(160, "High (160)"),
}

data class VolumeRenderConfig(
    val yawDeg: Float = 28f,
    val pitchDeg: Float = 18f,
    val zoom: Float = 1.15f,
    val opacityScale: Float = 1.0f,
    val thresholdNorm: Float = 0.18f,
    val preset: VolumeTransferPreset = VolumeTransferPreset.STANDARD_TISSUE,
    val quality: VolumeQuality = VolumeQuality.BALANCED,
    val cropXMin: Float = 0f,
    val cropXMax: Float = 1f,
    val cropYMin: Float = 0f,
    val cropYMax: Float = 1f,
    val cropZMin: Float = 0f,
    val cropZMax: Float = 1f,
)

@Composable
fun VolumeRenderGlView(
    seriesUid: String?,
    slices: List<DicomSlice>,
    config: VolumeRenderConfig,
    modifier: Modifier = Modifier,
) {
    val renderer = remember { VolumeRaymarchRenderer() }

    AndroidView(
        modifier = modifier,
        factory = { ctx: Context ->
            GLSurfaceView(ctx).apply {
                setEGLContextClientVersion(3)
                preserveEGLContextOnPause = true
                setRenderer(renderer)
                renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            }
        },
        update = { view ->
            renderer.updateVolume(seriesUid, slices, config)
            view.requestRender()
        },
    )
}

private class VolumeRaymarchRenderer : GLSurfaceView.Renderer {
    private var program = 0
    private var tex3d = 0
    private var viewW = 1
    private var viewH = 1

    private val quadBuffer: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    @Volatile private var pendingSeriesUid: String? = null
    @Volatile private var uploadedSeriesUid: String? = null
    @Volatile private var pendingSlices: List<DicomSlice> = emptyList()
    @Volatile private var cfg: VolumeRenderConfig = VolumeRenderConfig()
    @Volatile private var aspectVec = floatArrayOf(1f, 1f, 0.7f)

    fun updateVolume(seriesUid: String?, slices: List<DicomSlice>, config: VolumeRenderConfig) {
        if (seriesUid != uploadedSeriesUid) {
            pendingSeriesUid = seriesUid
            pendingSlices = slices
        }
        cfg = config
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.055f, 0.067f, 0.086f, 1f)
        program = buildProgram(VS, FS)
        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        tex3d = tex[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, tex3d)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE)
        uploadedSeriesUid = null
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = max(1, width)
        viewH = max(1, height)
        GLES30.glViewport(0, 0, viewW, viewH)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        val targetUid = pendingSeriesUid
        val slices = pendingSlices
        if (targetUid != null && targetUid != uploadedSeriesUid && slices.size >= 3) {
            uploadVolume3D(slices)
            uploadedSeriesUid = targetUid
        }
        if (uploadedSeriesUid == null || program == 0) return

        val c = cfg
        GLES30.glUseProgram(program)

        val yaw = Math.toRadians(c.yawDeg.toDouble()).toFloat()
        val pitch = Math.toRadians(c.pitchDeg.toDouble()).toFloat()
        val camDist = 2.4f / c.zoom.coerceIn(0.4f, 4f)
        val camX = camDist * cos(pitch) * sin(yaw)
        val camY = camDist * sin(pitch)
        val camZ = camDist * cos(pitch) * cos(yaw)

        GLES30.glUniform3f(GLES30.glGetUniformLocation(program, "uCamPos"), camX, camY, camZ)
        GLES30.glUniform2f(GLES30.glGetUniformLocation(program, "uResolution"), viewW.toFloat(), viewH.toFloat())
        GLES30.glUniform3f(GLES30.glGetUniformLocation(program, "uBoxScale"), aspectVec[0], aspectVec[1], aspectVec[2])
        GLES30.glUniform3f(GLES30.glGetUniformLocation(program, "uCropMin"), c.cropXMin - 0.5f, c.cropYMin - 0.5f, c.cropZMin - 0.5f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(program, "uCropMax"), c.cropXMax - 0.5f, c.cropYMax - 0.5f, c.cropZMax - 0.5f)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uOpacityScale"), c.opacityScale)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program, "uThreshold"), c.thresholdNorm)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uPreset"), c.preset.id)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uSteps"), c.quality.steps)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, tex3d)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uVol"), 0)

        quadBuffer.position(0)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quadBuffer)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glDisableVertexAttribArray(0)
    }

    private fun uploadVolume3D(slices: List<DicomSlice>) {
        val w = slices.first().columns
        val h = slices.first().rows
        val d = slices.size
        var minV = Float.MAX_VALUE
        var maxV = -Float.MAX_VALUE
        for (s in slices) {
            for (v in s.rawPixels) {
                if (v < minV) minV = v
                if (v > maxV) maxV = v
            }
        }
        val range = (maxV - minV).coerceAtLeast(1f)
        val buf = ByteBuffer.allocateDirect(w * h * d)
        for (s in slices) {
            for (v in s.rawPixels) {
                val n = (((v - minV) / range).coerceIn(0f, 1f) * 255f).toInt().toByte()
                buf.put(n)
            }
        }
        buf.position(0)

        val spCol = (slices.first().pixelSpacingCol ?: 1.0).toFloat()
        val spRow = (slices.first().pixelSpacingRow ?: 1.0).toFloat()
        val dz = (slices.first().sliceThickness ?: 2.0).toFloat()
        val sx = w * spCol
        val sy = h * spRow
        val sz = d * dz
        val maxDim = max(sx, max(sy, sz)).coerceAtLeast(1f)
        aspectVec = floatArrayOf(sx / maxDim, sy / maxDim, sz / maxDim)

        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, tex3d)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage3D(
            GLES30.GL_TEXTURE_3D,
            0,
            GLES30.GL_R8,
            w,
            h,
            d,
            0,
            GLES30.GL_RED,
            GLES30.GL_UNSIGNED_BYTE,
            buf,
        )
    }

    private fun buildProgram(vsSrc: String, fsSrc: String): Int {
        val vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER).also {
            GLES30.glShaderSource(it, vsSrc)
            GLES30.glCompileShader(it)
        }
        val fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER).also {
            GLES30.glShaderSource(it, fsSrc)
            GLES30.glCompileShader(it)
        }
        return GLES30.glCreateProgram().also {
            GLES30.glAttachShader(it, vs)
            GLES30.glAttachShader(it, fs)
            GLES30.glLinkProgram(it)
        }
    }

    companion object {
        private const val VS = """
            #version 300 es
            layout(location = 0) in vec2 aPos;
            out vec2 vNdc;
            void main() {
                vNdc = aPos;
                gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """

        private const val FS = """
            #version 300 es
            precision highp float;
            precision highp sampler3D;
            in vec2 vNdc;
            uniform sampler3D uVol;
            uniform vec3 uCamPos;
            uniform vec2 uResolution;
            uniform vec3 uBoxScale;
            uniform vec3 uCropMin;
            uniform vec3 uCropMax;
            uniform float uOpacityScale;
            uniform float uThreshold;
            uniform int uPreset;
            uniform int uSteps;
            out vec4 fragColor;

            vec2 intersectBox(vec3 orig, vec3 dir, vec3 bmin, vec3 bmax) {
                vec3 inv = 1.0 / dir;
                vec3 t0 = (bmin - orig) * inv;
                vec3 t1 = (bmax - orig) * inv;
                vec3 tmin = min(t0, t1);
                vec3 tmax = max(t0, t1);
                float enter = max(max(tmin.x, tmin.y), tmin.z);
                float exit = min(min(tmax.x, tmax.y), tmax.z);
                return vec2(enter, exit);
            }

            void main() {
                vec3 forward = normalize(-uCamPos);
                vec3 worldUp = abs(forward.y) > 0.98 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
                vec3 right = normalize(cross(forward, worldUp));
                vec3 up = cross(right, forward);

                float aspect = uResolution.x / max(uResolution.y, 1.0);
                vec2 uv = vec2(vNdc.x * aspect, vNdc.y);
                vec3 rayDir = normalize(forward * 1.7 + right * uv.x + up * uv.y);

                vec3 bmin = uCropMin * uBoxScale;
                vec3 bmax = uCropMax * uBoxScale;
                vec2 hit = intersectBox(uCamPos, rayDir, bmin, bmax);
                if (hit.x > hit.y || hit.y < 0.0) {
                    fragColor = vec4(0.055, 0.067, 0.086, 1.0);
                    return;
                }

                float tStart = max(hit.x, 0.0);
                float tEnd = hit.y;
                float dt = (tEnd - tStart) / float(uSteps);

                vec3 accumColor = vec3(0.0);
                float accumAlpha = 0.0;
                float maxMip = 0.0;

                for (int i = 0; i < 160; i++) {
                    if (i >= uSteps) break;
                    float t = tStart + (float(i) + 0.5) * dt;
                    vec3 pos = uCamPos + rayDir * t;
                    vec3 texCoord = (pos / uBoxScale) + 0.5;
                    float val = texture(uVol, texCoord).r;

                    if (uPreset == 1) {
                        maxMip = max(maxMip, val);
                    } else {
                        float density = max(0.0, val - uThreshold) / max(1.0 - uThreshold, 0.05);
                        float sampleAlpha = clamp(density * dt * 3.8 * uOpacityScale, 0.0, 0.95);
                        vec3 sampleCol;
                        if (uPreset == 2) {
                            sampleCol = mix(vec3(0.18, 0.58, 0.85), vec3(0.95, 0.98, 1.0), smoothstep(0.25, 0.85, val));
                        } else {
                            sampleCol = mix(vec3(0.35, 0.45, 0.56), vec3(0.92, 0.96, 1.0), val);
                        }
                        accumColor += (1.0 - accumAlpha) * sampleCol * sampleAlpha;
                        accumAlpha += (1.0 - accumAlpha) * sampleAlpha;
                        if (accumAlpha > 0.97) break;
                    }
                }

                vec3 bg = vec3(0.055, 0.067, 0.086);
                if (uPreset == 1) {
                    float m = smoothstep(uThreshold * 0.5, 1.0, maxMip);
                    fragColor = vec4(mix(bg, vec3(0.85, 0.95, 1.0), m), 1.0);
                } else {
                    fragColor = vec4(mix(bg, accumColor, accumAlpha), 1.0);
                }
            }
        """
    }
}
