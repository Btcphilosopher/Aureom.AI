package com.example.dicom

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

object DicomGeometry {

    /**
     * Explicitly separates source-provided series descriptions from inferred sequence labels.
     */
    fun classifySeries(sample: DicomSlice): SeriesClassification {
        val desc = sample.seriesDescription.uppercase()
        val imgType = sample.imageType.uppercase()
        val seq = sample.scanningSequence.uppercase()
        val tr = sample.repetitionTime
        val te = sample.echoTime
        val ti = sample.inversionTime

        return when {
            "LOCALIZER" in imgType || "LOCALIZER" in desc || "SCOUT" in desc ->
                SeriesClassification(sample.seriesDescription, "Localiser / Scout", "DICOM_IMAGE_TYPE_TAG", 0.99)
            "ADC" in desc ->
                SeriesClassification(sample.seriesDescription, "ADC Map", "SOURCE_DESCRIPTION_AND_PARAMS", 0.95)
            "DWI" in desc || "DIFF" in desc || "EP" in seq ->
                SeriesClassification(sample.seriesDescription, "Diffusion-Weighted", "SOURCE_DESCRIPTION_AND_PARAMS", 0.90)
            "FLAIR" in desc || (ti != null && ti >= 1800.0 && (te ?: 0.0) >= 80.0) ->
                SeriesClassification(sample.seriesDescription, "FLAIR", "TI_TE_TR_METADATA", 0.94)
            "T2" in desc || ((tr ?: 0.0) >= 2500.0 && (te ?: 0.0) >= 70.0) ->
                SeriesClassification(sample.seriesDescription, "T2-Weighted", "TE_TR_METADATA", 0.92)
            "T1" in desc || "MPRAGE" in desc || ((tr ?: 9999.0) <= 2500.0 && (te ?: 999.0) <= 20.0) ->
                SeriesClassification(sample.seriesDescription, "T1-Weighted", "TE_TR_METADATA", 0.91)
            "PD" in desc ->
                SeriesClassification(sample.seriesDescription, "Proton Density", "SOURCE_DESCRIPTION", 0.86)
            else ->
                SeriesClassification(sample.seriesDescription, null, "UNCLASSIFIED", 0.0)
        }
    }

    /**
     * Sorts slices strictly by geometric projection along slice normal (row x col),
     * never solely by filename or InstanceNumber.
     */
    fun sortSlicesByGeometry(slices: List<DicomSlice>): List<DicomSlice> {
        if (slices.isEmpty()) return emptyList()
        val ref = slices.firstOrNull { it.rowDirection != null && it.colDirection != null }
        val refNormal = ref?.let { it.rowDirection!!.cross(it.colDirection!!).normalized() }
        return slices.sortedWith(
            compareBy<DicomSlice>(
                { slice ->
                    if (refNormal != null && slice.imagePositionPatient != null) {
                        slice.imagePositionPatient.dot(refNormal)
                    } else {
                        slice.sliceLocation ?: Double.MAX_VALUE
                    }
                },
                { it.instanceNumber },
                { it.sopInstanceUid },
            )
        )
    }

    /**
     * Validates parallel orientations, matrix consistency, localisers, duplicates, and slice spacing.
     */
    fun validateSeriesGeometry(slices: List<DicomSlice>): GeometryValidationReport {
        if (slices.isEmpty()) {
            return GeometryValidationReport(
                isLocaliser = false,
                isVolumetricCompatible = false,
                status = GeometryStatus.INSUFFICIENT_SLICES,
                warnings = listOf("Series contains zero instances."),
                medianSliceSpacingMm = null,
                isOblique = false,
            )
        }

        val warnings = mutableListOf<String>()
        val isLocaliser = slices.any {
            "LOCALIZER" in it.imageType.uppercase() || "LOCALIZER" in it.seriesDescription.uppercase()
        }
        if (isLocaliser) {
            warnings.add("Localiser / Scout acquisition: excluded from volumetric MPR and 3D rendering.")
            return GeometryValidationReport(
                isLocaliser = true,
                isVolumetricCompatible = false,
                status = GeometryStatus.LOCALISER,
                warnings = warnings,
                medianSliceSpacingMm = null,
                isOblique = false,
            )
        }

        val dims = slices.map { it.rows to it.columns }.toSet()
        if (dims.size > 1) {
            warnings.add("Mixed image matrix sizes detected: $dims.")
        }

        val validGeom = slices.filter {
            it.imagePositionPatient != null && it.rowDirection != null && it.colDirection != null
        }
        if (validGeom.size < slices.size) {
            warnings.add("${slices.size - validGeom.size} slice(s) lack ImagePositionPatient / ImageOrientationPatient.")
        }
        if (validGeom.size < 3) {
            warnings.add("Fewer than 3 slices with valid patient-space geometry; 3D volume construction disabled.")
            return GeometryValidationReport(
                isLocaliser = false,
                isVolumetricCompatible = false,
                status = GeometryStatus.INSUFFICIENT_SLICES,
                warnings = warnings,
                medianSliceSpacingMm = null,
                isOblique = false,
            )
        }

        val refNormal = validGeom.first().rowDirection!!.cross(validGeom.first().colDirection!!).normalized()
        var nonParallel = false
        for (s in validGeom) {
            val n = s.rowDirection!!.cross(s.colDirection!!).normalized()
            if (abs(refNormal.dot(n)) < 0.995) {
                nonParallel = true
            }
        }
        if (nonParallel) {
            warnings.add("Non-parallel slice orientations detected within series.")
        }

        val sorted = sortSlicesByGeometry(validGeom)
        val projections = sorted.map { it.imagePositionPatient!!.dot(refNormal) }
        val diffs = (0 until projections.size - 1).map { projections[it + 1] - projections[it] }

        if (diffs.any { abs(it) < 0.05 }) {
            warnings.add("Duplicate slice positions detected along stack normal.")
        }

        val posDiffs = diffs.filter { it >= 0.05 }.sorted()
        val medianSpacing = if (posDiffs.isNotEmpty()) posDiffs[posDiffs.size / 2] else null
        if (medianSpacing != null && posDiffs.any { abs(it - medianSpacing) > max(0.5, medianSpacing * 0.35) }) {
            warnings.add(
                "Irregular slice spacing detected (median ${"%.2f".format(medianSpacing)} mm; min ${"%.2f".format(posDiffs.first())} mm, max ${"%.2f".format(posDiffs.last())} mm)."
            )
        }

        // Check obliquity (whether normal differs noticeably from pure X, Y, or Z cardinal axes)
        val maxAxisAlign = max(abs(refNormal.x), max(abs(refNormal.y), abs(refNormal.z)))
        val isOblique = maxAxisAlign < 0.995

        val compatible = warnings.isEmpty()
        return GeometryValidationReport(
            isLocaliser = false,
            isVolumetricCompatible = compatible,
            status = if (compatible) GeometryStatus.VOLUMETRIC_VALID else GeometryStatus.GEOMETRY_WARNING,
            warnings = warnings,
            medianSliceSpacingMm = medianSpacing,
            isOblique = isOblique,
        )
    }

    /**
     * Computes DICOM anatomical orientation labels (L/R, A/P, H/F) for screen edges
     * directly from direction cosines in LPS patient space (+X=L, +Y=P, +Z=H).
     */
    fun computeOrientationMarkers(rowDir: Vec3?, colDir: Vec3?): OrientationMarkers {
        if (rowDir == null || colDir == null) {
            return OrientationMarkers(top = "?", bottom = "?", left = "?", right = "?")
        }
        fun dirLabel(v: Vec3): String {
            val sb = StringBuilder()
            val ax = abs(v.x)
            val ay = abs(v.y)
            val az = abs(v.z)
            val threshold = 0.20
            val components = listOf(
                Triple(ax, if (v.x >= 0) "L" else "R", 0),
                Triple(ay, if (v.y >= 0) "P" else "A", 1),
                Triple(az, if (v.z >= 0) "H" else "F", 2),
            ).sortedByDescending { it.first }
            for ((mag, lbl, _) in components) {
                if (mag > threshold && sb.length < 2) sb.append(lbl)
            }
            return sb.toString().ifEmpty { "?" }
        }
        return OrientationMarkers(
            right = dirLabel(rowDir),
            left = dirLabel(rowDir * -1.0),
            bottom = dirLabel(colDir),
            top = dirLabel(colDir * -1.0),
        )
    }

    /**
     * Builds a 3D volumetric representation and resamples orthogonal Axial, Sagittal, or Coronal planes
     * using patient-space LPS geometry. Out-of-bounds regions are explicitly flagged in missingDataMask.
     */
    fun resampleMprPlane(
        sortedSlices: List<DicomSlice>,
        plane: MprPlane,
        normalizedSlicePos: Float,
        interpolation: InterpolationMode,
    ): MprSliceResult? {
        if (sortedSlices.size < 3) return null
        val first = sortedSlices.first()
        val rows = first.rows
        val cols = first.columns
        val spRow = first.pixelSpacingRow ?: return null
        val spCol = first.pixelSpacingCol ?: return null
        val rDir = first.rowDirection ?: return null
        val cDir = first.colDirection ?: return null
        val nDir = rDir.cross(cDir).normalized()
        val origin0 = first.imagePositionPatient ?: return null

        val proj0 = origin0.dot(nDir)
        val projLast = (sortedSlices.last().imagePositionPatient ?: return null).dot(nDir)
        val totalNormalSpan = (projLast - proj0).coerceAtLeast(1e-3)
        val dz = totalNormalSpan / (sortedSlices.size - 1)

        if (plane == MprPlane.ACQUISITION) {
            val idx = (normalizedSlicePos * (sortedSlices.size - 1)).roundToInt().coerceIn(0, sortedSlices.size - 1)
            val s = sortedSlices[idx]
            return MprSliceResult(
                plane = plane,
                interpolation = interpolation,
                width = cols,
                height = rows,
                pixels = s.rawPixels,
                missingDataMask = BooleanArray(rows * cols) { false },
                rowSpacingMm = spRow,
                colSpacingMm = spCol,
                originLps = s.imagePositionPatient ?: origin0,
                rowDir = rDir,
                colDir = cDir,
                sliceIndex = idx,
                sliceCount = sortedSlices.size,
                isReconstructed = false,
            )
        }

        // Compute world bounding box of the acquired volume in LPS space
        val corners = listOf(
            origin0,
            origin0 + rDir * ((cols - 1) * spCol),
            origin0 + cDir * ((rows - 1) * spRow),
            origin0 + rDir * ((cols - 1) * spCol) + cDir * ((rows - 1) * spRow),
            origin0 + nDir * totalNormalSpan,
            origin0 + rDir * ((cols - 1) * spCol) + nDir * totalNormalSpan,
            origin0 + cDir * ((rows - 1) * spRow) + nDir * totalNormalSpan,
            origin0 + rDir * ((cols - 1) * spCol) + cDir * ((rows - 1) * spRow) + nDir * totalNormalSpan,
        )
        val minX = corners.minOf { it.x }
        val maxX = corners.maxOf { it.x }
        val minY = corners.minOf { it.y }
        val maxY = corners.maxOf { it.y }
        val minZ = corners.minOf { it.z }
        val maxZ = corners.maxOf { it.z }

        val isoStep = min(spRow, min(spCol, dz)).coerceAtLeast(0.8)
        val outRowDir: Vec3
        val outColDir: Vec3
        val outNormal: Vec3
        val outW: Int
        val outH: Int
        val outDepthCount: Int
        val outOrigin: Vec3

        when (plane) {
            MprPlane.AXIAL -> {
                outRowDir = Vec3(1.0, 0.0, 0.0)
                outColDir = Vec3(0.0, 1.0, 0.0)
                outNormal = Vec3(0.0, 0.0, 1.0)
                outW = ((maxX - minX) / isoStep).roundToInt().coerceIn(32, 256)
                outH = ((maxY - minY) / isoStep).roundToInt().coerceIn(32, 256)
                outDepthCount = ((maxZ - minZ) / isoStep).roundToInt().coerceIn(8, 256)
                val zVal = minZ + normalizedSlicePos.coerceIn(0f, 1f) * (maxZ - minZ)
                outOrigin = Vec3(minX, minY, zVal)
            }
            MprPlane.CORONAL -> {
                outRowDir = Vec3(1.0, 0.0, 0.0)
                outColDir = Vec3(0.0, 0.0, -1.0)
                outNormal = Vec3(0.0, 1.0, 0.0)
                outW = ((maxX - minX) / isoStep).roundToInt().coerceIn(32, 256)
                outH = ((maxZ - minZ) / isoStep).roundToInt().coerceIn(32, 256)
                outDepthCount = ((maxY - minY) / isoStep).roundToInt().coerceIn(8, 256)
                val yVal = minY + normalizedSlicePos.coerceIn(0f, 1f) * (maxY - minY)
                outOrigin = Vec3(minX, yVal, maxZ)
            }
            MprPlane.SAGITTAL -> {
                outRowDir = Vec3(0.0, 1.0, 0.0)
                outColDir = Vec3(0.0, 0.0, -1.0)
                outNormal = Vec3(1.0, 0.0, 0.0)
                outW = ((maxY - minY) / isoStep).roundToInt().coerceIn(32, 256)
                outH = ((maxZ - minZ) / isoStep).roundToInt().coerceIn(32, 256)
                outDepthCount = ((maxX - minX) / isoStep).roundToInt().coerceIn(8, 256)
                val xVal = minX + normalizedSlicePos.coerceIn(0f, 1f) * (maxX - minX)
                outOrigin = Vec3(xVal, minY, maxZ)
            }
            MprPlane.ACQUISITION -> throw IllegalStateException("Handled above")
        }

        val outPixels = FloatArray(outW * outH)
        val missingMask = BooleanArray(outW * outH)

        for (r in 0 until outH) {
            for (c in 0 until outW) {
                val world = outOrigin + outRowDir * (c * isoStep) + outColDir * (r * isoStep)
                val rel = world - origin0
                val u = rel.dot(rDir) / spCol // col index
                val v = rel.dot(cDir) / spRow // row index
                val w = rel.dot(nDir) / dz    // slice index

                val idxOut = r * outW + c
                if (u < 0.0 || u > cols - 1.0 || v < 0.0 || v > rows - 1.0 || w < 0.0 || w > sortedSlices.size - 1.0) {
                    outPixels[idxOut] = 0f
                    missingMask[idxOut] = true
                } else if (interpolation == InterpolationMode.NEAREST) {
                    val iu = u.roundToInt().coerceIn(0, cols - 1)
                    val iv = v.roundToInt().coerceIn(0, rows - 1)
                    val iw = w.roundToInt().coerceIn(0, sortedSlices.size - 1)
                    outPixels[idxOut] = sortedSlices[iw].rawPixels[iv * cols + iu]
                    missingMask[idxOut] = false
                } else {
                    val u0 = floor(u).toInt().coerceIn(0, cols - 1)
                    val v0 = floor(v).toInt().coerceIn(0, rows - 1)
                    val w0 = floor(w).toInt().coerceIn(0, sortedSlices.size - 1)
                    val u1 = (u0 + 1).coerceAtMost(cols - 1)
                    val v1 = (v0 + 1).coerceAtMost(rows - 1)
                    val w1 = (w0 + 1).coerceAtMost(sortedSlices.size - 1)
                    val fu = (u - u0).toFloat()
                    val fv = (v - v0).toFloat()
                    val fw = (w - w0).toFloat()

                    val s0 = sortedSlices[w0].rawPixels
                    val s1 = sortedSlices[w1].rawPixels

                    val c000 = s0[v0 * cols + u0]
                    val c100 = s0[v0 * cols + u1]
                    val c010 = s0[v1 * cols + u0]
                    val c110 = s0[v1 * cols + u1]
                    val c001 = s1[v0 * cols + u0]
                    val c101 = s1[v0 * cols + u1]
                    val c011 = s1[v1 * cols + u0]
                    val c111 = s1[v1 * cols + u1]

                    val c00 = c000 * (1 - fu) + c100 * fu
                    val c10 = c010 * (1 - fu) + c110 * fu
                    val c01 = c001 * (1 - fu) + c101 * fu
                    val c11 = c011 * (1 - fu) + c111 * fu
                    val c0 = c00 * (1 - fv) + c10 * fv
                    val c1 = c01 * (1 - fv) + c11 * fv
                    outPixels[idxOut] = c0 * (1 - fw) + c1 * fw
                    missingMask[idxOut] = false
                }
            }
        }

        val sliceIdx = (normalizedSlicePos * (outDepthCount - 1)).roundToInt().coerceIn(0, outDepthCount - 1)
        return MprSliceResult(
            plane = plane,
            interpolation = interpolation,
            width = outW,
            height = outH,
            pixels = outPixels,
            missingDataMask = missingMask,
            rowSpacingMm = isoStep,
            colSpacingMm = isoStep,
            originLps = outOrigin,
            rowDir = outRowDir,
            colDir = outColDir,
            sliceIndex = sliceIdx,
            sliceCount = outDepthCount,
            isReconstructed = true,
        )
    }

    /**
     * Maps normalized image coordinate [0..1] to 3D Patient LPS coordinates.
     */
    fun pixelToPatientLps(
        origin: Vec3?,
        rowDir: Vec3?,
        colDir: Vec3?,
        colSpacingMm: Double?,
        rowSpacingMm: Double?,
        width: Int,
        height: Int,
        normX: Float,
        normY: Float,
    ): Vec3? {
        if (origin == null || rowDir == null || colDir == null || colSpacingMm == null || rowSpacingMm == null) return null
        val px = normX.coerceIn(0f, 1f) * (width - 1)
        val py = normY.coerceIn(0f, 1f) * (height - 1)
        return origin + rowDir * (px * colSpacingMm) + colDir * (py * rowSpacingMm)
    }

    /**
     * Computes physical distance (mm) when valid spacing exists, otherwise pixel distance.
     */
    fun measureLength(
        normX1: Float, normY1: Float,
        normX2: Float, normY2: Float,
        width: Int, height: Int,
        colSpacingMm: Double?, rowSpacingMm: Double?,
        isReconstructedPlane: Boolean,
    ): Pair<String, Boolean> {
        val dxPx = (normX2 - normX1) * width
        val dyPx = (normY2 - normY1) * height
        if (colSpacingMm != null && rowSpacingMm != null && colSpacingMm > 0 && rowSpacingMm > 0) {
            val dxMm = dxPx * colSpacingMm
            val dyMm = dyPx * rowSpacingMm
            val mm = sqrt(dxMm * dxMm + dyMm * dyMm)
            val suffix = if (isReconstructedPlane) " mm (MPR)" else " mm"
            return "${"%.1f".format(mm)}$suffix" to true
        }
        val px = sqrt(dxPx * dxPx + dyPx * dyPx)
        return "${"%.1f".format(px)} px (no spacing)" to false
    }

    /**
     * Computes angle in degrees at vertex (x2, y2) between segments (x1,y1)-(x2,y2) and (x3,y3)-(x2,y2).
     */
    fun measureAngleDeg(
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        width: Int, height: Int,
        colSpacingMm: Double?, rowSpacingMm: Double?,
    ): Double {
        val sx = colSpacingMm ?: 1.0
        val sy = rowSpacingMm ?: 1.0
        val v1x = (x1 - x2) * width * sx
        val v1y = (y1 - y2) * height * sy
        val v2x = (x3 - x2) * width * sx
        val v2y = (y3 - y2) * height * sy
        val m1 = sqrt(v1x * v1x + v1y * v1y)
        val m2 = sqrt(v2x * v2x + v2y * v2y)
        if (m1 < 1e-6 || m2 < 1e-6) return 0.0
        val cos = ((v1x * v2x + v1y * v2y) / (m1 * m2)).coerceIn(-1.0, 1.0)
        return acos(cos) * 180.0 / PI
    }

    /**
     * Computes elliptical ROI intensity statistics on original rescaled pixel intensities.
     * Labels values explicitly according to underlying data (never claims universal diagnostic units).
     */
    fun computeEllipticalRoiStats(
        pixels: FloatArray,
        missingMask: BooleanArray?,
        width: Int,
        height: Int,
        centerXNorm: Float,
        centerYNorm: Float,
        rxNorm: Float,
        ryNorm: Float,
        colSpacingMm: Double?,
        rowSpacingMm: Double?,
        quantityLabel: String,
    ): RoiStats {
        val cx = centerXNorm * width
        val cy = centerYNorm * height
        val rx = (rxNorm * width).coerceAtLeast(1f)
        val ry = (ryNorm * height).coerceAtLeast(1f)
        val samples = mutableListOf<Double>()

        val minR = floor((cy - ry).toDouble()).toInt().coerceIn(0, height - 1)
        val maxR = floor((cy + ry).toDouble()).toInt().coerceIn(0, height - 1)
        val minC = floor((cx - rx).toDouble()).toInt().coerceIn(0, width - 1)
        val maxC = floor((cx + rx).toDouble()).toInt().coerceIn(0, width - 1)

        for (r in minR..maxR) {
            for (c in minC..maxC) {
                val dx = (c - cx) / rx
                val dy = (r - cy) / ry
                if (dx * dx + dy * dy <= 1.0) {
                    val idx = r * width + c
                    if (missingMask == null || !missingMask[idx]) {
                        samples.add(pixels[idx].toDouble())
                    }
                }
            }
        }
        if (samples.isEmpty()) {
            return RoiStats(0, "0 px²", 0.0, 0.0, 0.0, 0.0, quantityLabel)
        }
        val mean = samples.average()
        val variance = samples.sumOf { (it - mean) * (it - mean) } / samples.size
        val areaLabel = if (colSpacingMm != null && rowSpacingMm != null) {
            val areaMm2 = samples.size * colSpacingMm * rowSpacingMm
            "${"%.1f".format(areaMm2)} mm²"
        } else {
            "${samples.size} px²"
        }
        return RoiStats(
            pixelCount = samples.size,
            areaLabel = areaLabel,
            minValue = samples.min(),
            maxValue = samples.max(),
            meanValue = mean,
            stdDev = sqrt(variance),
            quantityLabel = quantityLabel,
        )
    }
}

/**
 * Pure-Kotlin display LUT verification helper (mirrors GPU GLSL fragment shader math).
 */
object PixelDisplayTransform {
    fun mapIntensityToGray8(
        intensity: Float,
        windowCenter: Double,
        windowWidth: Double,
        photometricInterpretation: String,
        userInvert: Boolean,
    ): Int {
        val ww = windowWidth.coerceAtLeast(1.0)
        val low = windowCenter - 0.5 * ww
        var norm = ((intensity - low) / ww).coerceIn(0.0, 1.0)
        if (photometricInterpretation == "MONOCHROME1") {
            norm = 1.0 - norm
        }
        if (userInvert) {
            norm = 1.0 - norm
        }
        return (norm * 255.0).roundToInt().coerceIn(0, 255)
    }
}
