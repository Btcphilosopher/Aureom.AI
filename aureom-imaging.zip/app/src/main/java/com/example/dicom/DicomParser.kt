package com.example.dicom

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

object DicomParser {
    val SUPPORTED_TRANSFER_SYNTAXES = mapOf(
        "1.2.840.10008.1.2" to "Implicit VR Little Endian",
        "1.2.840.10008.1.2.1" to "Explicit VR Little Endian",
    )

    private const val ENHANCED_MR_SOP_CLASS = "1.2.840.10008.5.1.4.1.1.4.1"
    private val LONG_VRS = setOf("OB", "OD", "OF", "OL", "OW", "SQ", "UC", "UR", "UT", "UN")

    fun parse(bytes: ByteArray): DicomSlice {
        if (bytes.size < 136 ||
            bytes[128] != 'D'.code.toByte() ||
            bytes[129] != 'I'.code.toByte() ||
            bytes[130] != 'C'.code.toByte() ||
            bytes[131] != 'M'.code.toByte()
        ) {
            throw DicomParseException(
                code = "MALFORMED_PREAMBLE",
                message = "File lacks the 128-byte DICOM preamble and DICM magic marker.",
                remediation = "Select a valid DICOM Part 10 (.dcm) file.",
            )
        }

        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var offset = 132
        var inMeta = true
        var transferSyntaxUid = "1.2.840.10008.1.2.1"
        val tags = HashMap<Long, ByteArray>()

        while (offset + 4 <= bytes.size) {
            val group = bb.getShort(offset).toInt() and 0xFFFF
            val elem = bb.getShort(offset + 2).toInt() and 0xFFFF

            if (group == 0xFFFE) {
                if (offset + 8 > bytes.size) break
                val len = bb.getInt(offset + 4).toLong() and 0xFFFFFFFFL
                offset += 8 + (if (len == 0xFFFFFFFFL) 0 else len.toInt())
                continue
            }

            if (group != 0x0002 && inMeta) {
                inMeta = false
                val ts = tags[tagKey(0x0002, 0x0010)]?.toString(Charsets.US_ASCII)?.trim('\u0000', ' ')
                if (!ts.isNullOrEmpty()) {
                    transferSyntaxUid = ts
                }
                if (transferSyntaxUid !in SUPPORTED_TRANSFER_SYNTAXES) {
                    throw DicomParseException(
                        code = "UNSUPPORTED_TRANSFER_SYNTAX",
                        message = "Unsupported Transfer Syntax UID: $transferSyntaxUid",
                        remediation = "Supported syntaxes: Implicit VR LE (1.2.840.10008.1.2) and Explicit VR LE (1.2.840.10008.1.2.1). Transcode compressed DICOMs prior to import.",
                    )
                }
            }

            val isExplicit = inMeta || transferSyntaxUid == "1.2.840.10008.1.2.1"
            val length: Long
            val valStart: Int
            if (isExplicit) {
                if (offset + 8 > bytes.size) {
                    throw DicomParseException(
                        code = "TRUNCATED_OBJECT",
                        message = "Unexpected EOF reading tag (${"%04X".format(group)},${"%04X".format(elem)}).",
                        remediation = "Cancel and retry retrieval; the file is truncated.",
                    )
                }
                val vr = String(bytes, offset + 4, 2, Charsets.US_ASCII)
                if (vr in LONG_VRS) {
                    if (offset + 12 > bytes.size) {
                        throw DicomParseException(
                            code = "TRUNCATED_OBJECT",
                            message = "Truncated extended VR header at (${"%04X".format(group)},${"%04X".format(elem)}).",
                            remediation = "Re-export or re-retrieve the DICOM file.",
                        )
                    }
                    length = bb.getInt(offset + 8).toLong() and 0xFFFFFFFFL
                    valStart = offset + 12
                } else {
                    length = (bb.getShort(offset + 6).toInt() and 0xFFFF).toLong()
                    valStart = offset + 8
                }
            } else {
                if (offset + 8 > bytes.size) {
                    throw DicomParseException(
                        code = "TRUNCATED_OBJECT",
                        message = "Truncated implicit VR tag (${"%04X".format(group)},${"%04X".format(elem)}).",
                        remediation = "Re-retrieve the DICOM object.",
                    )
                }
                length = bb.getInt(offset + 4).toLong() and 0xFFFFFFFFL
                valStart = offset + 8
            }

            if (length == 0xFFFFFFFFL) {
                throw DicomParseException(
                    code = "UNSUPPORTED_UNDEFINED_LENGTH",
                    message = "Undefined-length encapsulated item at (${"%04X".format(group)},${"%04X".format(elem)}) is not supported.",
                    remediation = "Use uncompressed single-frame MR DICOM objects.",
                )
            }

            val valEnd = valStart + length.toInt()
            if (valEnd > bytes.size || valEnd < valStart) {
                throw DicomParseException(
                    code = "TRUNCATED_PAYLOAD",
                    message = "Tag (${"%04X".format(group)},${"%04X".format(elem)}) declares $length bytes but stream ended early.",
                    remediation = "Transfer interrupted or malformed file. Retry transfer.",
                )
            }

            tags[tagKey(group, elem)] = bytes.copyOfRange(valStart, valEnd)
            offset = valEnd
            if (group == 0x7FE0 && elem == 0x0010) break
        }

        fun getStr(g: Int, e: Int, default: String = ""): String {
            val raw = tags[tagKey(g, e)] ?: return default
            return String(raw, Charsets.ISO_8859_1).trim('\u0000', ' ')
        }

        fun getUs(g: Int, e: Int, default: Int = 0): Int {
            val raw = tags[tagKey(g, e)] ?: return default
            if (raw.size < 2) return default
            return ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).getShort(0).toInt() and 0xFFFF
        }

        fun getDouble(g: Int, e: Int): Double? {
            val s = getStr(g, e)
            if (s.isEmpty()) return null
            return s.split("\\").firstOrNull()?.trim()?.toDoubleOrNull()
        }

        fun getDoubleList(g: Int, e: Int, expected: Int): List<Double>? {
            val s = getStr(g, e)
            if (s.isEmpty()) return null
            val parts = s.split("\\").mapNotNull { it.trim().toDoubleOrNull() }
            return if (parts.size == expected) parts else null
        }

        val modality = getStr(0x0008, 0x0060)
        if (modality != "MR") {
            throw DicomParseException(
                code = "UNSUPPORTED_MODALITY",
                message = "Modality '${modality.ifEmpty { "UNKNOWN" }}' is outside the MR workspace scope.",
                remediation = "Import MR DICOM objects only.",
            )
        }

        val sopClassUid = getStr(0x0008, 0x0016).ifEmpty { getStr(0x0002, 0x0002) }
        if (sopClassUid == ENHANCED_MR_SOP_CLASS) {
            throw DicomParseException(
                code = "ENHANCED_MR_MILESTONE_PENDING",
                message = "Enhanced MR Image Storage (multiframe) is scheduled for Milestone 2.",
                remediation = "Export single-frame MR objects (1.2.840.10008.5.1.4.1.1.4).",
            )
        }

        val sopUid = getStr(0x0008, 0x0018)
        val seriesUid = getStr(0x0020, 0x000E)
        val studyUid = getStr(0x0020, 0x000D)
        if (sopUid.isEmpty() || seriesUid.isEmpty() || studyUid.isEmpty()) {
            throw DicomParseException(
                code = "MISSING_UIDS",
                message = "Missing StudyInstanceUID, SeriesInstanceUID, or SOPInstanceUID.",
                remediation = "Ensure DICOM UIDs (0020,000D), (0020,000E), and (0008,0018) exist.",
            )
        }

        val rows = getUs(0x0028, 0x0010)
        val cols = getUs(0x0028, 0x0011)
        val bitsAllocated = getUs(0x0028, 0x0100, 16)
        val bitsStored = getUs(0x0028, 0x0101, bitsAllocated)
        val pixelRep = getUs(0x0028, 0x0103, 0)
        val photometric = getStr(0x0028, 0x0004, "MONOCHROME2")
        if (photometric != "MONOCHROME1" && photometric != "MONOCHROME2") {
            throw DicomParseException(
                code = "UNSUPPORTED_PHOTOMETRIC",
                message = "Unsupported PhotometricInterpretation '$photometric'.",
                remediation = "Only MONOCHROME1 and MONOCHROME2 single-frame MR objects are supported.",
            )
        }

        val pixelRaw = tags[tagKey(0x7FE0, 0x0010)] ?: ByteArray(0)
        val bytesPerSample = (bitsAllocated / 8).coerceAtLeast(1)
        val expectedBytes = rows * cols * bytesPerSample
        if (rows <= 0 || cols <= 0 || pixelRaw.size < expectedBytes) {
            throw DicomParseException(
                code = "INVALID_PIXEL_DATA",
                message = "Pixel data mismatch: expected $expectedBytes bytes for ${rows}x$cols, found ${pixelRaw.size}.",
                remediation = "Re-import a complete uncompressed MR DICOM file.",
            )
        }

        val slope = getDouble(0x0028, 0x1053) ?: 1.0
        val intercept = getDouble(0x0028, 0x1052) ?: 0.0
        val rawPixels = decodePixels(pixelRaw, rows * cols, bitsAllocated, bitsStored, pixelRep, slope, intercept)

        var minVal = Float.MAX_VALUE
        var maxVal = -Float.MAX_VALUE
        for (v in rawPixels) {
            if (v < minVal) minVal = v
            if (v > maxVal) maxVal = v
        }
        val autoWc = (minVal + maxVal) / 2.0
        val autoWw = (maxVal - minVal).toDouble().coerceAtLeast(1.0)
        val wc = getDouble(0x0028, 0x1050) ?: autoWc
        val ww = (getDouble(0x0028, 0x1051) ?: autoWw).coerceAtLeast(1.0)

        val ippList = getDoubleList(0x0020, 0x0032, 3)
        val iopList = getDoubleList(0x0020, 0x0037, 6)
        val psList = getDoubleList(0x0028, 0x0030, 2)

        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }

        return DicomSlice(
            sopInstanceUid = sopUid,
            sopClassUid = sopClassUid,
            transferSyntaxUid = transferSyntaxUid,
            studyInstanceUid = studyUid,
            seriesInstanceUid = seriesUid,
            patientId = getStr(0x0010, 0x0020, "UNKNOWN"),
            issuerOfPatientId = getStr(0x0010, 0x0021, "UNSPECIFIED_ISSUER"),
            patientName = getStr(0x0010, 0x0010, "UNIDENTIFIED"),
            patientBirthDate = getStr(0x0010, 0x0030),
            patientSex = getStr(0x0010, 0x0040),
            studyId = getStr(0x0020, 0x0010),
            accessionNumber = getStr(0x0008, 0x0050),
            studyDescription = getStr(0x0008, 0x1030, "MR Examination"),
            studyDate = getStr(0x0008, 0x0020, "19700101"),
            studyTime = getStr(0x0008, 0x0030, "000000"),
            seriesNumber = getStr(0x0020, 0x0011).toIntOrNull() ?: 0,
            seriesDescription = getStr(0x0008, 0x103E, "Unnamed Series"),
            modality = modality,
            imageType = getStr(0x0008, 0x0008),
            scanningSequence = getStr(0x0018, 0x0020),
            mrAcquisitionType = getStr(0x0018, 0x0023),
            repetitionTime = getDouble(0x0018, 0x0080),
            echoTime = getDouble(0x0018, 0x0081),
            inversionTime = getDouble(0x0018, 0x0082),
            flipAngle = getDouble(0x0018, 0x1314),
            magneticFieldStrength = getDouble(0x0018, 0x0087),
            sliceThickness = getDouble(0x0018, 0x0050),
            sliceSpacing = getDouble(0x0018, 0x0088),
            instanceNumber = getStr(0x0020, 0x0013).toIntOrNull() ?: 0,
            imagePositionPatient = ippList?.let { Vec3(it[0], it[1], it[2]) },
            rowDirection = iopList?.let { Vec3(it[0], it[1], it[2]).normalized() },
            colDirection = iopList?.let { Vec3(it[3], it[4], it[5]).normalized() },
            frameOfReferenceUid = getStr(0x0020, 0x0052),
            sliceLocation = getDouble(0x0020, 0x1041),
            rows = rows,
            columns = cols,
            pixelSpacingRow = psList?.getOrNull(0),
            pixelSpacingCol = psList?.getOrNull(1),
            bitsAllocated = bitsAllocated,
            bitsStored = bitsStored,
            pixelRepresentation = pixelRep,
            photometricInterpretation = photometric,
            defaultWindowCenter = wc,
            defaultWindowWidth = ww,
            rescaleSlope = slope,
            rescaleIntercept = intercept,
            sha256Checksum = digest,
            rawPixels = rawPixels,
        )
    }

    private fun decodePixels(
        raw: ByteArray,
        count: Int,
        bitsAllocated: Int,
        bitsStored: Int,
        pixelRep: Int,
        slope: Double,
        intercept: Double,
    ): FloatArray {
        val out = FloatArray(count)
        if (bitsAllocated == 8) {
            for (i in 0 until count) {
                val sample = if (pixelRep == 1) raw[i].toInt() else (raw[i].toInt() and 0xFF)
                out[i] = (sample * slope + intercept).toFloat()
            }
            return out
        }
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val mask = if (bitsStored in 1..15) ((1 shl bitsStored) - 1) else 0xFFFF
        val signBit = 1 shl (bitsStored - 1)
        for (i in 0 until count) {
            val rawShort = bb.getShort(i * 2).toInt()
            val sample = if (pixelRep == 1) {
                val masked = rawShort and mask
                if ((masked and signBit) != 0) masked - (1 shl bitsStored) else masked
            } else {
                rawShort and mask
            }
            out[i] = (sample * slope + intercept).toFloat()
        }
        return out
    }

    private fun tagKey(group: Int, elem: Int): Long = ((group.toLong() and 0xFFFF) shl 16) or (elem.toLong() and 0xFFFF)
}
