package com.example.dicom

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Double) = Vec3(x * s, y * s, z * s)
    fun dot(o: Vec3): Double = x * o.x + y * o.y + z * o.z
    fun cross(o: Vec3): Vec3 = Vec3(
        y * o.z - z * o.y,
        z * o.x - x * o.z,
        x * o.y - y * o.x,
    )
    fun length(): Double = kotlin.math.sqrt(x * x + y * y + z * z)
    fun normalized(): Vec3 {
        val len = length()
        return if (len > 1e-9) Vec3(x / len, y / len, z / len) else Vec3(0.0, 0.0, 0.0)
    }
}

data class PatientIdentity(
    val patientRecordId: String,
    val patientId: String,
    val issuingAuthority: String,
    val patientName: String,
    val birthDate: String,
    val sex: String,
    val isSyntheticDemo: Boolean = true,
)

enum class TransferStatus { COMPLETE, PARTIAL, FAILED, RETRIEVING, LOCAL_IMPORT }
enum class TechnicalReviewStatus { PENDING, PASSED, GEOMETRY_WARNING, REJECTED }
enum class ClinicalReviewStatus { UNREAD, DRAFT_REPORT, IN_REVIEW, FINAL_SIGNED, AMENDED }

data class StudyRecord(
    val studyInstanceUid: String,
    val patient: PatientIdentity,
    val studyId: String,
    val accessionNumber: String,
    val accessionIssuer: String,
    val studyDescription: String,
    val studyDate: String,
    val studyTime: String,
    val frameOfReferenceUid: String,
    val sourceSystem: String,
    val transferStatus: TransferStatus,
    val technicalReviewStatus: TechnicalReviewStatus,
    val clinicalReviewStatus: ClinicalReviewStatus,
    val seriesCount: Int,
    val cachedAtEpochMs: Long,
)

enum class GeometryStatus { VOLUMETRIC_VALID, LOCALISER, GEOMETRY_WARNING, INSUFFICIENT_SLICES }

data class GeometryValidationReport(
    val isLocaliser: Boolean,
    val isVolumetricCompatible: Boolean,
    val status: GeometryStatus,
    val warnings: List<String>,
    val medianSliceSpacingMm: Double?,
    val isOblique: Boolean,
)

data class SeriesClassification(
    val sourceDescription: String,
    val inferredSequenceLabel: String?,
    val classificationSource: String,
    val confidence: Double,
)

data class SeriesRecord(
    val seriesInstanceUid: String,
    val studyInstanceUid: String,
    val seriesNumber: Int,
    val modality: String,
    val classification: SeriesClassification,
    val geometryReport: GeometryValidationReport,
    val sliceCount: Int,
    val rows: Int,
    val columns: Int,
    val pixelSpacingRowMm: Double?,
    val pixelSpacingColMm: Double?,
    val sliceThicknessMm: Double?,
    val repetitionTimeMs: Double?,
    val echoTimeMs: Double?,
    val inversionTimeMs: Double?,
    val flipAngleDeg: Double?,
    val fieldStrengthTesla: Double?,
    val rescaleSlope: Double,
    val rescaleIntercept: Double,
    val quantityLabel: String = "Arbitrary MR Signal Intensity",
)

data class DicomSlice(
    val sopInstanceUid: String,
    val sopClassUid: String,
    val transferSyntaxUid: String,
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val patientId: String,
    val issuerOfPatientId: String,
    val patientName: String,
    val patientBirthDate: String,
    val patientSex: String,
    val studyId: String,
    val accessionNumber: String,
    val studyDescription: String,
    val studyDate: String,
    val studyTime: String,
    val seriesNumber: Int,
    val seriesDescription: String,
    val modality: String,
    val imageType: String,
    val scanningSequence: String,
    val mrAcquisitionType: String,
    val repetitionTime: Double?,
    val echoTime: Double?,
    val inversionTime: Double?,
    val flipAngle: Double?,
    val magneticFieldStrength: Double?,
    val sliceThickness: Double?,
    val sliceSpacing: Double?,
    val instanceNumber: Int,
    val imagePositionPatient: Vec3?,
    val rowDirection: Vec3?,
    val colDirection: Vec3?,
    val frameOfReferenceUid: String,
    val sliceLocation: Double?,
    val rows: Int,
    val columns: Int,
    val pixelSpacingRow: Double?,
    val pixelSpacingCol: Double?,
    val bitsAllocated: Int,
    val bitsStored: Int,
    val pixelRepresentation: Int,
    val photometricInterpretation: String,
    val defaultWindowCenter: Double,
    val defaultWindowWidth: Double,
    val rescaleSlope: Double,
    val rescaleIntercept: Double,
    val sha256Checksum: String,
    // Immutable source intensities (rescaled floating values in original acquisition units)
    val rawPixels: FloatArray,
) {
    val sliceNormalProjection: Double?
        get() {
            val ipp = imagePositionPatient ?: return null
            val r = rowDirection ?: return null
            val c = colDirection ?: return null
            val normal = r.cross(c).normalized()
            return ipp.dot(normal)
        }
}

data class OrientationMarkers(
    val top: String,
    val bottom: String,
    val left: String,
    val right: String,
)

enum class MprPlane(val label: String) {
    ACQUISITION("Native Acquisition"),
    AXIAL("MPR Axial"),
    SAGITTAL("MPR Sagittal"),
    CORONAL("MPR Coronal"),
}

enum class InterpolationMode(val label: String) {
    TRILINEAR("Trilinear"),
    NEAREST("Nearest-Neighbor"),
}

data class MprSliceResult(
    val plane: MprPlane,
    val interpolation: InterpolationMode,
    val width: Int,
    val height: Int,
    val pixels: FloatArray,
    val missingDataMask: BooleanArray,
    val rowSpacingMm: Double,
    val colSpacingMm: Double,
    val originLps: Vec3,
    val rowDir: Vec3,
    val colDir: Vec3,
    val sliceIndex: Int,
    val sliceCount: Int,
    val isReconstructed: Boolean,
)

data class RoiStats(
    val pixelCount: Int,
    val areaLabel: String,
    val minValue: Double,
    val maxValue: Double,
    val meanValue: Double,
    val stdDev: Double,
    val quantityLabel: String,
)

class DicomParseException(
    val code: String,
    override val message: String,
    val remediation: String,
) : Exception(message)
