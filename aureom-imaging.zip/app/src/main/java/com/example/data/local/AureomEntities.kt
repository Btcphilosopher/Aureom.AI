package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "cached_studies")
data class CachedStudyEntity(
    @PrimaryKey val studyInstanceUid: String,
    val patientRecordId: String,
    val patientId: String,
    val issuingAuthority: String,
    val patientName: String,
    val patientBirthDate: String,
    val patientSex: String,
    val studyId: String,
    val accessionNumber: String,
    val accessionIssuer: String,
    val studyDescription: String,
    val studyDate: String,
    val studyTime: String,
    val frameOfReferenceUid: String,
    val sourceSystem: String,
    val transferStatus: String,
    val technicalReviewStatus: String,
    val clinicalReviewStatus: String,
    val seriesCount: Int,
    val isSyntheticDemo: Boolean,
    val cachedAtEpochMs: Long,
)

@Entity(
    tableName = "cached_series",
    indices = [Index("studyInstanceUid")],
)
data class CachedSeriesEntity(
    @PrimaryKey val seriesInstanceUid: String,
    val studyInstanceUid: String,
    val seriesNumber: Int,
    val modality: String,
    val sourceDescription: String,
    val inferredSequenceLabel: String?,
    val classificationSource: String,
    val classificationConfidence: Double,
    val isLocaliser: Boolean,
    val isVolumetricCompatible: Boolean,
    val geometryStatus: String,
    val geometryWarningsJoined: String,
    val medianSliceSpacingMm: Double?,
    val isOblique: Boolean,
    val sliceCount: Int,
    val rows: Int,
    val columns: Int,
    val pixelSpacingRowMm: Double?,
    val pixelSpacingColMm: Double?,
    val sliceThicknessMm: Double?,
    val repetitionTimeMs: Double?,
    val echoTimeMs: Double?,
    val inversionTimeMs: Double?,
    val flipAngleDeg: Double?,
    val fieldStrengthTesla: Double?,
    val rescaleSlope: Double,
    val rescaleIntercept: Double,
    val quantityLabel: String,
)

@Entity(
    tableName = "cached_instances",
    indices = [Index("studyInstanceUid"), Index("seriesInstanceUid")],
)
data class CachedInstanceEntity(
    @PrimaryKey val sopInstanceUid: String,
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val instanceNumber: Int,
    val sliceNormalProj: Double?,
    val sha256Checksum: String,
    val privateFilePath: String,
    val byteSize: Long,
)

@Entity(
    tableName = "annotations",
    indices = [Index("studyInstanceUid"), Index("seriesInstanceUid")],
)
data class AnnotationEntity(
    @PrimaryKey val id: String,
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val sopInstanceUid: String?,
    val authorId: String,
    val authorName: String,
    val measurementType: String, // LENGTH, ANGLE, ROI_ELLIPSE, TEXT_NOTE, ARROW, CONTOUR
    val coordinateSystem: String, // IMAGE_PIXEL_2D, PATIENT_LPS_3D, MPR_OBLIQUE_PLANE
    val isReconstructedPlane: Boolean,
    val planeLabel: String,
    val physicalUnitsValid: Boolean,
    val physicalUnitLabel: String,
    val geometryJson: String,
    val measuredValueText: String,
    val intensityStatsJson: String?,
    val noteText: String?,
    val createdAtEpochMs: Long,
)

@Entity(
    tableName = "reports",
    indices = [Index("studyInstanceUid")],
)
data class ReportEntity(
    @PrimaryKey val id: String,
    val studyInstanceUid: String,
    val authorName: String,
    val reviewerName: String,
    val status: String, // DRAFT, IN_REVIEW, SIGNED, AMENDED
    val version: Int,
    val clinicalHistory: String,
    val techniqueText: String,
    val findingsText: String,
    val impressionText: String,
    val examinationNotes: String,
    val signedBy: String?,
    val signedAtEpochMs: Long?,
    val contentSha256: String?,
    val updatedAtEpochMs: Long,
)

@Entity(
    tableName = "report_amendments",
    indices = [Index("reportId"), Index("studyInstanceUid")],
)
data class ReportAmendmentEntity(
    @PrimaryKey val id: String,
    val reportId: String,
    val studyInstanceUid: String,
    val authorName: String,
    val reason: String,
    val amendmentText: String,
    val createdAtEpochMs: Long,
)

@Entity(
    tableName = "review_tasks",
    indices = [Index("studyInstanceUid")],
)
data class ReviewTaskEntity(
    @PrimaryKey val id: String,
    val studyInstanceUid: String,
    val taskType: String,
    val assignedTo: String,
    val status: String,
    val dueDate: String,
    val notes: String,
    val createdAtEpochMs: Long,
)

@Entity(tableName = "transfer_jobs")
data class TransferJobEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sourceType: String,
    val status: String, // QUEUED, IN_PROGRESS, CANCELLED, FAILED, COMPLETED
    val totalObjects: Int,
    val completedObjects: Int,
    val bytesTransferred: Long,
    val errorMessage: String?,
    val remediationHint: String?,
    val updatedAtEpochMs: Long,
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey val id: String,
    val actorName: String,
    val action: String,
    val resourceType: String,
    val resourceId: String,
    val studyInstanceUid: String?,
    val outcome: String,
    val details: String,
    val createdAtEpochMs: Long,
)
