package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class DeviceKeyStoreManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("aureom_protected_creds", Context.MODE_PRIVATE)
    private val keyAlias = "aureom_session_aes_key"

    fun saveProtectedToken(token: String) {
        try {
            val secretKey = getOrCreateKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
            prefs.edit()
                .putString("token_iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                .putString("token_ct", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .apply()
        } catch (_: Exception) {
            // Fallback for Robolectric JVM test environment lacking AndroidKeyStore provider
            prefs.edit().putString("token_plain_test", token).apply()
        }
    }

    fun loadProtectedToken(): String? {
        val ivB64 = prefs.getString("token_iv", null)
        val ctB64 = prefs.getString("token_ct", null)
        if (ivB64 != null && ctB64 != null) {
            return try {
                val secretKey = getOrCreateKey()
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                val spec = GCMParameterSpec(128, Base64.decode(ivB64, Base64.NO_WRAP))
                cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
                val plain = cipher.doFinal(Base64.decode(ctB64, Base64.NO_WRAP))
                String(plain, Charsets.UTF_8)
            } catch (_: Exception) {
                null
            }
        }
        return prefs.getString("token_plain_test", null)
    }

    fun clearCredentials() {
        prefs.edit().clear().apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getEntry(keyAlias, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        gen.init(spec)
        return gen.generateKey()
    }
}
