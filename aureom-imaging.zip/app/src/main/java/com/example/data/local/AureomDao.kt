package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AureomDao {
    @Query("SELECT * FROM cached_studies ORDER BY studyDate DESC, studyTime DESC")
    fun observeStudies(): Flow<List<CachedStudyEntity>>

    @Query("SELECT * FROM cached_studies WHERE studyInstanceUid = :studyUid")
    suspend fun getStudy(studyUid: String): CachedStudyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStudy(study: CachedStudyEntity)

    @Query("UPDATE cached_studies SET clinicalReviewStatus = :status WHERE studyInstanceUid = :studyUid")
    suspend fun updateStudyClinicalStatus(studyUid: String, status: String)

    @Query("SELECT * FROM cached_series WHERE studyInstanceUid = :studyUid ORDER BY seriesNumber ASC")
    fun observeSeriesForStudy(studyUid: String): Flow<List<CachedSeriesEntity>>

    @Query("SELECT * FROM cached_series WHERE studyInstanceUid = :studyUid ORDER BY seriesNumber ASC")
    suspend fun getSeriesForStudy(studyUid: String): List<CachedSeriesEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSeries(series: CachedSeriesEntity)

    @Query("SELECT * FROM cached_instances WHERE seriesInstanceUid = :seriesUid ORDER BY sliceNormalProj ASC, instanceNumber ASC")
    suspend fun getInstancesForSeries(seriesUid: String): List<CachedInstanceEntity>

    @Query("SELECT * FROM cached_instances WHERE sopInstanceUid = :sopUid")
    suspend fun getInstanceBySop(sopUid: String): CachedInstanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInstance(instance: CachedInstanceEntity)

    // Strict study isolation on annotations!
    @Query("SELECT * FROM annotations WHERE studyInstanceUid = :studyUid ORDER BY createdAtEpochMs DESC")
    fun observeAnnotationsForStudy(studyUid: String): Flow<List<AnnotationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnotation(annotation: AnnotationEntity)

    @Query("DELETE FROM annotations WHERE id = :id AND studyInstanceUid = :studyUid")
    suspend fun deleteAnnotation(id: String, studyUid: String)

    @Query("SELECT * FROM reports WHERE studyInstanceUid = :studyUid ORDER BY updatedAtEpochMs DESC")
    fun observeReportsForStudy(studyUid: String): Flow<List<ReportEntity>>

    @Query("SELECT * FROM reports WHERE id = :reportId")
    suspend fun getReport(reportId: String): ReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReport(report: ReportEntity)

    @Query("SELECT * FROM report_amendments WHERE studyInstanceUid = :studyUid ORDER BY createdAtEpochMs ASC")
    fun observeAmendmentsForStudy(studyUid: String): Flow<List<ReportAmendmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAmendment(amendment: ReportAmendmentEntity)

    @Query("SELECT * FROM review_tasks WHERE studyInstanceUid = :studyUid ORDER BY createdAtEpochMs DESC")
    fun observeTasksForStudy(studyUid: String): Flow<List<ReviewTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: ReviewTaskEntity)

    @Query("SELECT * FROM transfer_jobs ORDER BY updatedAtEpochMs DESC")
    fun observeTransfers(): Flow<List<TransferJobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTransfer(job: TransferJobEntity)

    @Query("SELECT * FROM audit_events ORDER BY createdAtEpochMs DESC LIMIT 200")
    fun observeAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEventEntity)

    @Query("DELETE FROM cached_studies")
    suspend fun clearAllStudies()

    @Query("DELETE FROM cached_series")
    suspend fun clearAllSeries()

    @Query("DELETE FROM cached_instances")
    suspend fun clearAllInstances()
}
