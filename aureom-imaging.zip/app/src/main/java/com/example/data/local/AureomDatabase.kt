package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CachedStudyEntity::class,
        CachedSeriesEntity::class,
        CachedInstanceEntity::class,
        AnnotationEntity::class,
        ReportEntity::class,
        ReportAmendmentEntity::class,
        ReviewTaskEntity::class,
        TransferJobEntity::class,
        AuditEventEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun aureomDao(): AureomDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_workspace_cache.db",
                ).build().also { INSTANCE = it }
            }
        }
    }
}
