package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.AnnotationEntity
import com.example.data.local.AuditEventEntity
import com.example.data.local.AureomDao
import com.example.data.local.CachedInstanceEntity
import com.example.data.local.CachedSeriesEntity
import com.example.data.local.CachedStudyEntity
import com.example.data.local.ReportAmendmentEntity
import com.example.data.local.ReportEntity
import com.example.data.local.ReviewTaskEntity
import com.example.data.local.TransferJobEntity
import com.example.data.remote.AureomApiService
import com.example.data.remote.BootstrapRequestDto
import com.example.data.remote.LoginRequestDto
import com.example.data.research.KSpaceReconstructionResult
import com.example.data.research.KSpaceReconstructor
import com.example.data.security.DeviceKeyStoreManager
import com.example.dicom.DicomGeometry
import com.example.dicom.DicomParseException
import com.example.dicom.DicomParser
import com.example.dicom.DicomSlice
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.UUID

sealed interface IngestionOutcome {
    data class Success(val studyUid: String, val seriesUid: String, val sopUid: String, val duplicateSkipped: Boolean) : IngestionOutcome
    data class Failure(val code: String, val message: String, val remediation: String) : IngestionOutcome
}

class WorkspaceRepository(
    private val context: Context,
    private val dao: AureomDao,
    private val keyStore: DeviceKeyStoreManager,
) {
    // Restricted app-private directory — strictly outside personal photo gallery / MediaStore
    private val privateDicomRoot = File(context.filesDir, "protected_dicom_cache").apply { mkdirs() }

    val studiesFlow: Flow<List<CachedStudyEntity>> = dao.observeStudies()
    val transfersFlow: Flow<List<TransferJobEntity>> = dao.observeTransfers()
    val auditEventsFlow: Flow<List<AuditEventEntity>> = dao.observeAuditEvents()

    fun observeSeries(studyUid: String): Flow<List<CachedSeriesEntity>> = dao.observeSeriesForStudy(studyUid)
    fun observeAnnotations(studyUid: String): Flow<List<AnnotationEntity>> = dao.observeAnnotationsForStudy(studyUid)
    fun observeReports(studyUid: String): Flow<List<ReportEntity>> = dao.observeReportsForStudy(studyUid)
    fun observeAmendments(studyUid: String): Flow<List<ReportAmendmentEntity>> = dao.observeAmendmentsForStudy(studyUid)
    fun observeTasks(studyUid: String): Flow<List<ReviewTaskEntity>> = dao.observeTasksForStudy(studyUid)

    fun hasSavedToken(): Boolean = !keyStore.loadProtectedToken().isNullOrBlank()
    fun clearToken() = keyStore.clearCredentials()

    suspend fun checkServerConnection(baseUrl: String): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val api = AureomApiService.create(baseUrl) { keyStore.loadProtectedToken() }
            api.health().status == "ok"
        }
    }

    suspend fun loginRemote(baseUrl: String, username: String, password: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val api = AureomApiService.create(baseUrl) { null }
            val status = api.authStatus()
            val resp = if (!status.bootstrapped) {
                api.bootstrap(BootstrapRequestDto(username, password, "$username (Clinical Workstation)"))
            } else {
                api.login(LoginRequestDto(username, password))
            }
            keyStore.saveProtectedToken(resp.access_token)
            logAudit(resp.user.display_name, "LOGIN_REMOTE", "session", resp.user.id, null, "SUCCESS", "Connected to $baseUrl")
            resp.user.display_name
        }
    }

    suspend fun seedBundledDemoFixturesIfEmpty(actorName: String) = withContext(Dispatchers.IO) {
        val assetFixtures = listOf(
            "fixtures/study_1_brain_current/series_1_t1_3d",
            "fixtures/study_1_brain_current/series_2_t2_tse",
            "fixtures/study_1_brain_current/series_3_flair",
            "fixtures/study_1_brain_current/series_4_localizer",
            "fixtures/study_1_brain_current/series_5_oblique",
            "fixtures/study_2_brain_prior/series_1_t1_prior",
            "fixtures/study_3_knee_anomaly/series_1_pd_gapped",
        )
        val jobId = "job-demo-seed"
        val filesToLoad = mutableListOf<String>()
        for (dir in assetFixtures) {
            val entries = context.assets.list(dir) ?: emptyArray()
            entries.filter { it.endsWith(".dcm") }.sorted().forEach { filesToLoad.add("$dir/$it") }
        }
        if (filesToLoad.isEmpty()) return@withContext

        // Skip if already seeded
        val existing = dao.getStudy("1.2.826.0.1.3680043.10.900.1001")
        if (existing != null) return@withContext

        dao.upsertTransfer(
            TransferJobEntity(
                id = jobId,
                title = "Local Synthetic Demonstration Archive",
                sourceType = "LOCAL_ARCHIVE",
                status = "IN_PROGRESS",
                totalObjects = filesToLoad.size,
                completedObjects = 0,
                bytesTransferred = 0,
                errorMessage = null,
                remediationHint = null,
                updatedAtEpochMs = System.currentTimeMillis(),
            )
        )
        var done = 0
        var totalBytes = 0L
        for (assetPath in filesToLoad) {
            val bytes = context.assets.open(assetPath).use { it.readBytes() }
            ingestDicomBytes(bytes, "LOCAL_DEMO_ARCHIVE", actorName)
            done++
            totalBytes += bytes.size
            if (done % 10 == 0 || done == filesToLoad.size) {
                dao.upsertTransfer(
                    TransferJobEntity(
                        id = jobId,
                        title = "Local Synthetic Demonstration Archive",
                        sourceType = "LOCAL_ARCHIVE",
                        status = if (done == filesToLoad.size) "COMPLETED" else "IN_PROGRESS",
                        totalObjects = filesToLoad.size,
                        completedObjects = done,
                        bytesTransferred = totalBytes,
                        errorMessage = null,
                        remediationHint = null,
                        updatedAtEpochMs = System.currentTimeMillis(),
                    )
                )
            }
        }
        logAudit(actorName, "SEED_DEMO_ARCHIVE", "archive", "synthetic_mri_fixtures", null, "SUCCESS", "Loaded $done synthetic MR DICOM objects.")
    }

    suspend fun importFromDocumentUris(uris: List<Uri>, actorName: String): List<IngestionOutcome> = withContext(Dispatchers.IO) {
        val jobId = "job-import-${UUID.randomUUID().toString().take(8)}"
        val outcomes = mutableListOf<IngestionOutcome>()
        var bytesTotal = 0L
        dao.upsertTransfer(
            TransferJobEntity(
                id = jobId,
                title = "Local Document Import (${uris.size} file(s))",
                sourceType = "LOCAL_DOCUMENT",
                status = "IN_PROGRESS",
                totalObjects = uris.size,
                completedObjects = 0,
                bytesTransferred = 0,
                errorMessage = null,
                remediationHint = null,
                updatedAtEpochMs = System.currentTimeMillis(),
            )
        )
        var okCount = 0
        var lastError: IngestionOutcome.Failure? = null
        try {
            for ((idx, uri) in uris.withIndex()) {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    val fail = IngestionOutcome.Failure("READ_ERROR", "Unable to open selected document.", "Verify file permissions and retry.")
                    outcomes.add(fail)
                    lastError = fail
                    continue
                }
                bytesTotal += bytes.size
                val res = ingestDicomBytes(bytes, "LOCAL_DOCUMENT", actorName)
                outcomes.add(res)
                if (res is IngestionOutcome.Success) okCount++ else if (res is IngestionOutcome.Failure) lastError = res
                dao.upsertTransfer(
                    TransferJobEntity(
                        id = jobId,
                        title = "Local Document Import (${uris.size} file(s))",
                        sourceType = "LOCAL_DOCUMENT",
                        status = "IN_PROGRESS",
                        totalObjects = uris.size,
                        completedObjects = idx + 1,
                        bytesTransferred = bytesTotal,
                        errorMessage = lastError?.message,
                        remediationHint = lastError?.remediation,
                        updatedAtEpochMs = System.currentTimeMillis(),
                    )
                )
            }
            dao.upsertTransfer(
                TransferJobEntity(
                    id = jobId,
                    title = "Local Document Import (${uris.size} file(s))",
                    sourceType = "LOCAL_DOCUMENT",
                    status = if (okCount > 0 && lastError == null) "COMPLETED" else if (okCount == 0) "FAILED" else "COMPLETED",
                    totalObjects = uris.size,
                    completedObjects = uris.size,
                    bytesTransferred = bytesTotal,
                    errorMessage = lastError?.message,
                    remediationHint = lastError?.remediation,
                    updatedAtEpochMs = System.currentTimeMillis(),
                )
            )
        } catch (ce: CancellationException) {
            dao.upsertTransfer(
                TransferJobEntity(
                    id = jobId,
                    title = "Local Document Import (${uris.size} file(s))",
                    sourceType = "LOCAL_DOCUMENT",
                    status = "CANCELLED",
                    totalObjects = uris.size,
                    completedObjects = okCount,
                    bytesTransferred = bytesTotal,
                    errorMessage = "Cancelled by user.",
                    remediationHint = "Tap Retry to resume import.",
                    updatedAtEpochMs = System.currentTimeMillis(),
                )
            )
            throw ce
        }
        outcomes
    }

    suspend fun testEdgeFixtureIngestion(fixtureAssetPath: String, actorName: String): IngestionOutcome = withContext(Dispatchers.IO) {
        val bytes = context.assets.open(fixtureAssetPath).use { it.readBytes() }
        val outcome = ingestDicomBytes(bytes, "EDGE_CASE_FIXTURE", actorName)
        val jobId = "job-edge-${UUID.randomUUID().toString().take(6)}"
        if (outcome is IngestionOutcome.Failure) {
            dao.upsertTransfer(
                TransferJobEntity(
                    id = jobId,
                    title = "Fixture Test: ${fixtureAssetPath.substringAfterLast('/')}",
                    sourceType = "LOCAL_ARCHIVE",
                    status = "FAILED",
                    totalObjects = 1,
                    completedObjects = 0,
                    bytesTransferred = bytes.size.toLong(),
                    errorMessage = "${outcome.code}: ${outcome.message}",
                    remediationHint = outcome.remediation,
                    updatedAtEpochMs = System.currentTimeMillis(),
                )
            )
        }
        outcome
    }

    suspend fun simulateInterruptedTransfer(jobId: String, shouldFailMidway: Boolean, actorName: String) = withContext(Dispatchers.IO) {
        val title = "Archive Retrieval: Study 1.2.826...1001"
        dao.upsertTransfer(
            TransferJobEntity(
                id = jobId,
                title = title,
                sourceType = "DICOMWEB",
                status = "IN_PROGRESS",
                totalObjects = 16,
                completedObjects = 0,
                bytesTransferred = 0,
                errorMessage = null,
                remediationHint = null,
                updatedAtEpochMs = System.currentTimeMillis(),
            )
        )
        for (step in 1..16) {
            delay(120)
            if (shouldFailMidway && step == 7) {
                dao.upsertTransfer(
                    TransferJobEntity(
                        id = jobId,
                        title = title,
                        sourceType = "DICOMWEB",
                        status = "FAILED",
                        totalObjects = 16,
                        completedObjects = 6,
                        bytesTransferred = 6L * 19500L,
                        errorMessage = "INTERRUPTED_STREAM: Socket closed at byte 117,000 before SHA-256 verification.",
                        remediationHint = "Original archive records untouched. Tap Retry to resume remaining 10 objects.",
                        updatedAtEpochMs = System.currentTimeMillis(),
                    )
                )
                logAudit(actorName, "TRANSFER_INTERRUPTED", "transfer", jobId, null, "FAILED", "Interrupted at object 7/16 without partial record corruption.")
                return@withContext
            }
            dao.upsertTransfer(
                TransferJobEntity(
                    id = jobId,
                    title = title,
                    sourceType = "DICOMWEB",
                    status = if (step == 16) "COMPLETED" else "IN_PROGRESS",
                    totalObjects = 16,
                    completedObjects = step,
                    bytesTransferred = step * 19500L,
                    errorMessage = null,
                    remediationHint = null,
                    updatedAtEpochMs = System.currentTimeMillis(),
                )
            )
        }
        logAudit(actorName, "TRANSFER_RETRY_COMPLETE", "transfer", jobId, null, "SUCCESS", "Checksum verified across all 16 objects.")
    }

    suspend fun markTransferCancelled(job: TransferJobEntity) = withContext(Dispatchers.IO) {
        dao.upsertTransfer(
            job.copy(
                status = "CANCELLED",
                errorMessage = "Transfer cancelled by operator.",
                remediationHint = "Tap Retry to re-initiate transfer.",
                updatedAtEpochMs = System.currentTimeMillis(),
            )
        )
    }

    suspend fun ingestDicomBytes(bytes: ByteArray, sourceSystem: String, actorName: String): IngestionOutcome = withContext(Dispatchers.IO) {
        val parsed = try {
            DicomParser.parse(bytes)
        } catch (e: DicomParseException) {
            logAudit(actorName, "INGEST_REJECTED", "dicom", "upload", null, e.code, e.message)
            return@withContext IngestionOutcome.Failure(e.code, e.message, e.remediation)
        }

        // Duplicate-safe check by SOPInstanceUID
        val existingInst = dao.getInstanceBySop(parsed.sopInstanceUid)
        if (existingInst != null) {
            if (existingInst.sha256Checksum == parsed.sha256Checksum) {
                return@withContext IngestionOutcome.Success(
                    studyUid = parsed.studyInstanceUid,
                    seriesUid = parsed.seriesInstanceUid,
                    sopUid = parsed.sopInstanceUid,
                    duplicateSkipped = true,
                )
            }
            return@withContext IngestionOutcome.Failure(
                code = "UID_CHECKSUM_CONFLICT",
                message = "Duplicate SOPInstanceUID ${parsed.sopInstanceUid} has differing checksum.",
                remediation = "Investigate archive collision before overwriting.",
            )
        }

        // Persist immutable original DICOM file inside app-private directory
        val studyDir = File(privateDicomRoot, sanitizeUidForPath(parsed.studyInstanceUid))
        val seriesDir = File(studyDir, sanitizeUidForPath(parsed.seriesInstanceUid))
        seriesDir.mkdirs()
        val destFile = File(seriesDir, "${sanitizeUidForPath(parsed.sopInstanceUid)}.dcm")
        destFile.writeBytes(bytes)

        dao.upsertInstance(
            CachedInstanceEntity(
                sopInstanceUid = parsed.sopInstanceUid,
                studyInstanceUid = parsed.studyInstanceUid,
                seriesInstanceUid = parsed.seriesInstanceUid,
                instanceNumber = parsed.instanceNumber,
                sliceNormalProj = parsed.sliceNormalProjection,
                sha256Checksum = parsed.sha256Checksum,
                privateFilePath = destFile.absolutePath,
                byteSize = bytes.size.toLong(),
            )
        )

        // Recompute geometry validation across all cached slices of this series
        val seriesSlices = loadSeriesSlices(parsed.seriesInstanceUid)
        val geom = DicomGeometry.validateSeriesGeometry(seriesSlices)
        val cls = DicomGeometry.classifySeries(parsed)

        dao.upsertSeries(
            CachedSeriesEntity(
                seriesInstanceUid = parsed.seriesInstanceUid,
                studyInstanceUid = parsed.studyInstanceUid,
                seriesNumber = parsed.seriesNumber,
                modality = parsed.modality,
                sourceDescription = cls.sourceDescription,
                inferredSequenceLabel = cls.inferredSequenceLabel,
                classificationSource = cls.classificationSource,
                classificationConfidence = cls.confidence,
                isLocaliser = geom.isLocaliser,
                isVolumetricCompatible = geom.isVolumetricCompatible,
                geometryStatus = geom.status.name,
                geometryWarningsJoined = geom.warnings.joinToString("\n"),
                medianSliceSpacingMm = geom.medianSliceSpacingMm,
                isOblique = geom.isOblique,
                sliceCount = seriesSlices.size,
                rows = parsed.rows,
                columns = parsed.columns,
                pixelSpacingRowMm = parsed.pixelSpacingRow,
                pixelSpacingColMm = parsed.pixelSpacingCol,
                sliceThicknessMm = parsed.sliceThickness,
                repetitionTimeMs = parsed.repetitionTime,
                echoTimeMs = parsed.echoTime,
                inversionTimeMs = parsed.inversionTime,
                flipAngleDeg = parsed.flipAngle,
                fieldStrengthTesla = parsed.magneticFieldStrength,
                rescaleSlope = parsed.rescaleSlope,
                rescaleIntercept = parsed.rescaleIntercept,
                quantityLabel = "Arbitrary MR Signal Intensity",
            )
        )

        val studySeries = dao.getSeriesForStudy(parsed.studyInstanceUid)
        val hasWarning = studySeries.any { it.geometryStatus == "GEOMETRY_WARNING" }
        val existingStudy = dao.getStudy(parsed.studyInstanceUid)
        dao.upsertStudy(
            CachedStudyEntity(
                studyInstanceUid = parsed.studyInstanceUid,
                patientRecordId = "pt-${parsed.patientId}-${parsed.issuerOfPatientId}",
                patientId = parsed.patientId,
                issuingAuthority = parsed.issuerOfPatientId,
                patientName = parsed.patientName.replace("^", " ").trim(),
                patientBirthDate = parsed.patientBirthDate,
                patientSex = parsed.patientSex,
                studyId = parsed.studyId,
                accessionNumber = parsed.accessionNumber,
                accessionIssuer = parsed.issuerOfPatientId,
                studyDescription = parsed.studyDescription,
                studyDate = parsed.studyDate,
                studyTime = parsed.studyTime,
                frameOfReferenceUid = parsed.frameOfReferenceUid,
                sourceSystem = existingStudy?.sourceSystem ?: sourceSystem,
                transferStatus = if (sourceSystem == "LOCAL_DOCUMENT") "LOCAL_IMPORT" else "COMPLETE",
                technicalReviewStatus = if (hasWarning) "GEOMETRY_WARNING" else "PASSED",
                clinicalReviewStatus = existingStudy?.clinicalReviewStatus ?: "UNREAD",
                seriesCount = studySeries.size,
                isSyntheticDemo = true,
                cachedAtEpochMs = System.currentTimeMillis(),
            )
        )

        IngestionOutcome.Success(parsed.studyInstanceUid, parsed.seriesInstanceUid, parsed.sopInstanceUid, duplicateSkipped = false)
    }

    suspend fun loadSeriesSlices(seriesUid: String): List<DicomSlice> = withContext(Dispatchers.IO) {
        val entities = dao.getInstancesForSeries(seriesUid)
        val slices = mutableListOf<DicomSlice>()
        for (ent in entities) {
            val file = File(ent.privateFilePath)
            if (file.exists()) {
                val bytes = file.readBytes()
                val actualSha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
                if (actualSha == ent.sha256Checksum) {
                    runCatching { DicomParser.parse(bytes) }.getOrNull()?.let { slices.add(it) }
                }
            }
        }
        DicomGeometry.sortSlicesByGeometry(slices)
    }

    suspend fun saveAnnotation(annotation: AnnotationEntity) = withContext(Dispatchers.IO) {
        dao.insertAnnotation(annotation)
        logAudit(
            annotation.authorName,
            "CREATE_ANNOTATION",
            "annotation",
            annotation.id,
            annotation.studyInstanceUid,
            "SUCCESS",
            "${annotation.measurementType} in ${annotation.coordinateSystem}",
        )
    }

    suspend fun deleteAnnotation(id: String, studyUid: String, actorName: String) = withContext(Dispatchers.IO) {
        dao.deleteAnnotation(id, studyUid)
        logAudit(actorName, "DELETE_ANNOTATION", "annotation", id, studyUid, "SUCCESS", "")
    }

    suspend fun saveReportDraft(
        studyUid: String,
        existing: ReportEntity?,
        authorName: String,
        reviewerName: String,
        clinicalHistory: String,
        techniqueText: String,
        findingsText: String,
        impressionText: String,
        examinationNotes: String,
        submitForReview: Boolean,
    ): Result<ReportEntity> = withContext(Dispatchers.IO) {
        if (existing != null && (existing.status == "SIGNED" || existing.status == "AMENDED")) {
            return@withContext Result.failure(IllegalStateException("Signed reports are immutable. Add a linked amendment instead."))
        }
        val nextStatus = if (submitForReview) "IN_REVIEW" else "DRAFT"
        val now = System.currentTimeMillis()
        val updated = if (existing == null) {
            ReportEntity(
                id = "rep-${UUID.randomUUID().toString().take(10)}",
                studyInstanceUid = studyUid,
                authorName = authorName,
                reviewerName = reviewerName,
                status = nextStatus,
                version = 1,
                clinicalHistory = clinicalHistory,
                techniqueText = techniqueText,
                findingsText = findingsText,
                impressionText = impressionText,
                examinationNotes = examinationNotes,
                signedBy = null,
                signedAtEpochMs = null,
                contentSha256 = null,
                updatedAtEpochMs = now,
            )
        } else {
            // Atomic version check against current DB record
            val currentDb = dao.getReport(existing.id)
            if (currentDb != null && currentDb.version != existing.version) {
                return@withContext Result.failure(IllegalStateException("Version conflict: expected v${existing.version}, found v${currentDb.version}."))
            }
            existing.copy(
                reviewerName = reviewerName,
                status = nextStatus,
                version = existing.version + 1,
                clinicalHistory = clinicalHistory,
                techniqueText = techniqueText,
                findingsText = findingsText,
                impressionText = impressionText,
                examinationNotes = examinationNotes,
                updatedAtEpochMs = now,
            )
        }
        dao.upsertReport(updated)
        dao.updateStudyClinicalStatus(studyUid, if (submitForReview) "IN_REVIEW" else "DRAFT_REPORT")
        logAudit(authorName, "SAVE_REPORT", "report", updated.id, studyUid, "SUCCESS", "Version ${updated.version} ($nextStatus)")
        Result.success(updated)
    }

    suspend fun signReport(report: ReportEntity, signerName: String): Result<ReportEntity> = withContext(Dispatchers.IO) {
        val current = dao.getReport(report.id) ?: return@withContext Result.failure(IllegalStateException("Report not found."))
        if (current.status == "SIGNED" || current.status == "AMENDED") {
            return@withContext Result.failure(IllegalStateException("Report is already signed."))
        }
        if (current.version != report.version) {
            return@withContext Result.failure(IllegalStateException("Atomic version check failed before sign."))
        }
        val canonical = "${current.studyInstanceUid}|v${current.version}|${current.findingsText}|${current.impressionText}"
        val sha = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray()).joinToString("") { "%02x".format(it) }
        val signed = current.copy(
            status = "SIGNED",
            signedBy = signerName,
            signedAtEpochMs = System.currentTimeMillis(),
            contentSha256 = sha,
            updatedAtEpochMs = System.currentTimeMillis(),
        )
        dao.upsertReport(signed)
        dao.updateStudyClinicalStatus(current.studyInstanceUid, "FINAL_SIGNED")
        logAudit(signerName, "SIGN_REPORT", "report", signed.id, current.studyInstanceUid, "SUCCESS", "SHA256=${sha.take(12)}")
        Result.success(signed)
    }

    suspend fun addAmendment(report: ReportEntity, authorName: String, reason: String, text: String): Result<ReportAmendmentEntity> = withContext(Dispatchers.IO) {
        if (report.status != "SIGNED" && report.status != "AMENDED") {
            return@withContext Result.failure(IllegalStateException("Amendments apply only to signed reports."))
        }
        val amd = ReportAmendmentEntity(
            id = "amd-${UUID.randomUUID().toString().take(8)}",
            reportId = report.id,
            studyInstanceUid = report.studyInstanceUid,
            authorName = authorName,
            reason = reason,
            amendmentText = text,
            createdAtEpochMs = System.currentTimeMillis(),
        )
        dao.insertAmendment(amd)
        dao.upsertReport(report.copy(status = "AMENDED", updatedAtEpochMs = System.currentTimeMillis()))
        dao.updateStudyClinicalStatus(report.studyInstanceUid, "AMENDED")
        logAudit(authorName, "AMEND_REPORT", "report", report.id, report.studyInstanceUid, "SUCCESS", reason)
        Result.success(amd)
    }

    suspend fun addReviewTask(studyUid: String, taskType: String, assignee: String, dueDate: String, notes: String, actorName: String) = withContext(Dispatchers.IO) {
        val task = ReviewTaskEntity(
            id = "tsk-${UUID.randomUUID().toString().take(8)}",
            studyInstanceUid = studyUid,
            taskType = taskType,
            assignedTo = assignee,
            status = "OPEN",
            dueDate = dueDate,
            notes = notes,
            createdAtEpochMs = System.currentTimeMillis(),
        )
        dao.upsertTask(task)
        logAudit(actorName, "CREATE_REVIEW_TASK", "review_task", task.id, studyUid, "SUCCESS", "$taskType -> $assignee")
    }

    suspend fun reconstructBundledResearchKSpace(): KSpaceReconstructionResult = withContext(Dispatchers.IO) {
        val jsonText = context.assets.open("fixtures/kspace_cartesian_2d.json").bufferedReader().use { it.readText() }
        KSpaceReconstructor.reconstructFromJson(jsonText)
    }

    suspend fun purgeRestrictedCache(actorName: String) = withContext(Dispatchers.IO) {
        privateDicomRoot.deleteRecursively()
        privateDicomRoot.mkdirs()
        dao.clearAllInstances()
        dao.clearAllSeries()
        dao.clearAllStudies()
        logAudit(actorName, "PURGE_DEVICE_CACHE", "cache", "protected_dicom_cache", null, "SUCCESS", "Cleared restricted local DICOM cache.")
    }

    suspend fun logAudit(
        actor: String,
        action: String,
        resourceType: String,
        resourceId: String,
        studyUid: String?,
        outcome: String,
        details: String,
    ) {
        dao.insertAuditEvent(
            AuditEventEntity(
                id = "aud-${UUID.randomUUID().toString().take(10)}",
                actorName = actor,
                action = action,
                resourceType = resourceType,
                resourceId = resourceId,
                studyInstanceUid = studyUid,
                outcome = outcome,
                details = details,
                createdAtEpochMs = System.currentTimeMillis(),
            )
        )
    }

    private fun sanitizeUidForPath(uid: String): String = uid.replace(Regex("[^a-zA-Z0-9._-]"), "_")
}
