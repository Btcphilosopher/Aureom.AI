package com.example.data.research

import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class KSpaceReconstructionResult(
    val datasetId: String,
    val title: String,
    val disclaimer: String,
    val width: Int,
    val height: Int,
    val coilCount: Int,
    val fftConvention: String,
    val scalingNote: String,
    val kSpaceLogMagnitude: FloatArray,
    val reconstructedMagnitudeRss: FloatArray,
)

/**
 * Isolated Research Module: Performs documented 2D Cartesian IFFT reconstruction
 * (ifftshift -> 2D radix-2 IFFT -> fftshift -> Root-Sum-of-Squares coil combination).
 * Strictly separated from the clinical DICOM archive; never fabricates k-space from magnitude images.
 */
object KSpaceReconstructor {

    fun reconstructFromJson(jsonText: String): KSpaceReconstructionResult {
        val root = JSONObject(jsonText)
        val matrix = root.getJSONArray("matrix_size")
        val h = matrix.getInt(0)
        val w = matrix.getInt(1)
        val coilsJson = root.getJSONArray("coils")
        val coilCount = coilsJson.length()

        val rss = FloatArray(h * w)
        val kLog = FloatArray(h * w)

        for (cIdx in 0 until coilCount) {
            val coilObj = coilsJson.getJSONObject(cIdx)
            val reArr = coilObj.getJSONArray("real")
            val imArr = coilObj.getJSONArray("imag")

            val re = Array(h) { DoubleArray(w) }
            val im = Array(h) { DoubleArray(w) }
            for (y in 0 until h) {
                val rRow = reArr.getJSONArray(y)
                val iRow = imArr.getJSONArray(y)
                for (x in 0 until w) {
                    val rv = rRow.getDouble(x)
                    val iv = iRow.getDouble(x)
                    re[y][x] = rv
                    im[y][x] = iv
                    if (cIdx == 0) {
                        kLog[y * w + x] = kotlin.math.ln(1.0 + sqrt(rv * rv + iv * iv) * 100.0).toFloat()
                    }
                }
            }

            // 1. ifftshift (swap quadrants before IFFT)
            fftShift2D(re, im, h, w)
            // 2. 2D IFFT (row-wise then column-wise)
            for (y in 0 until h) {
                fft1D(re[y], im[y], invert = true)
            }
            val colRe = DoubleArray(h)
            val colIm = DoubleArray(h)
            for (x in 0 until w) {
                for (y in 0 until h) {
                    colRe[y] = re[y][x]
                    colIm[y] = im[y][x]
                }
                fft1D(colRe, colIm, invert = true)
                for (y in 0 until h) {
                    re[y][x] = colRe[y]
                    im[y][x] = colIm[y]
                }
            }
            // 3. fftshift (center image)
            fftShift2D(re, im, h, w)

            // 4. Accumulate squared magnitude for RSS coil combination (scale by H*W to invert 1/N^2 forward DFT)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val mag = sqrt(re[y][x] * re[y][x] + im[y][x] * im[y][x]) * (h * w)
                    rss[y * w + x] += (mag * mag).toFloat()
                }
            }
        }

        for (i in rss.indices) {
            rss[i] = sqrt(rss[i].toDouble()).toFloat()
        }

        return KSpaceReconstructionResult(
            datasetId = root.getString("dataset_id"),
            title = root.getString("title"),
            disclaimer = root.getString("disclaimer"),
            width = w,
            height = h,
            coilCount = coilCount,
            fftConvention = root.getString("fft_convention"),
            scalingNote = root.getString("scaling_note"),
            kSpaceLogMagnitude = kLog,
            reconstructedMagnitudeRss = rss,
        )
    }

    private fun fftShift2D(re: Array<DoubleArray>, im: Array<DoubleArray>, h: Int, w: Int) {
        val hy = h / 2
        val hx = w / 2
        for (y in 0 until hy) {
            for (x in 0 until hx) {
                swap(re, y, x, y + hy, x + hx)
                swap(im, y, x, y + hy, x + hx)
                swap(re, y, x + hx, y + hy, x)
                swap(im, y, x + hx, y + hy, x)
            }
        }
    }

    private fun swap(arr: Array<DoubleArray>, y1: Int, x1: Int, y2: Int, x2: Int) {
        val t = arr[y1][x1]
        arr[y1][x1] = arr[y2][x2]
        arr[y2][x2] = t
    }

    private fun fft1D(re: DoubleArray, im: DoubleArray, invert: Boolean) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }

        var len = 2
        while (len <= n) {
            val ang = 2.0 * PI / len * (if (invert) 1.0 else -1.0)
            val wlenRe = cos(ang)
            val wlenIm = sin(ang)
            var i = 0
            while (i < n) {
                var wRe = 1.0
                var wIm = 0.0
                for (k in 0 until len / 2) {
                    val uRe = re[i + k]
                    val uIm = im[i + k]
                    val vRe = re[i + k + len / 2] * wRe - im[i + k + len / 2] * wIm
                    val vIm = re[i + k + len / 2] * wIm + im[i + k + len / 2] * wRe
                    re[i + k] = uRe + vRe
                    im[i + k] = uIm + vIm
                    re[i + k + len / 2] = uRe - vRe
                    im[i + k + len / 2] = uIm - vIm
                    val nextRe = wRe * wlenRe - wIm * wlenIm
                    wIm = wRe * wlenIm + wIm * wlenRe
                    wRe = nextRe
                }
                i += len
            }
            len = len shl 1
        }
        if (invert) {
            for (i in 0 until n) {
                re[i] /= n.toDouble()
                im[i] /= n.toDouble()
            }
        }
    }
}
