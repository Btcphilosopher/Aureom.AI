package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.aureomDataStore by preferencesDataStore(name = "aureom_settings")

data class WorkspaceSettingsState(
    val serverBaseUrl: String = "http://10.0.2.2:8000",
    val dicomWebEndpoint: String = "http://10.0.2.2:8042/dicom-web",
    val textScale: Float = 1.0f,
    val reducedMotion: Boolean = false,
    val sessionLockMinutes: Int = 15,
    val aiAssistOptIn: Boolean = false, // Disabled by default!
    val cacheRetentionHours: Int = 24,
)

class WorkspacePreferences(private val context: Context) {
    private object Keys {
        val SERVER_URL = stringPreferencesKey("server_url")
        val DICOMWEB_URL = stringPreferencesKey("dicomweb_url")
        val TEXT_SCALE = floatPreferencesKey("text_scale")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val LOCK_MINUTES = intPreferencesKey("lock_minutes")
        val AI_OPT_IN = booleanPreferencesKey("ai_opt_in")
        val CACHE_RETENTION_HOURS = intPreferencesKey("cache_retention_hours")
    }

    val settingsFlow: Flow<WorkspaceSettingsState> = context.aureomDataStore.data.map { prefs ->
        WorkspaceSettingsState(
            serverBaseUrl = prefs[Keys.SERVER_URL] ?: "http://10.0.2.2:8000",
            dicomWebEndpoint = prefs[Keys.DICOMWEB_URL] ?: "http://10.0.2.2:8042/dicom-web",
            textScale = prefs[Keys.TEXT_SCALE] ?: 1.0f,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            sessionLockMinutes = prefs[Keys.LOCK_MINUTES] ?: 15,
            aiAssistOptIn = prefs[Keys.AI_OPT_IN] ?: false,
            cacheRetentionHours = prefs[Keys.CACHE_RETENTION_HOURS] ?: 24,
        )
    }

    suspend fun updateSettings(transform: (WorkspaceSettingsState) -> WorkspaceSettingsState) {
        context.aureomDataStore.edit { prefs ->
            val current = WorkspaceSettingsState(
                serverBaseUrl = prefs[Keys.SERVER_URL] ?: "http://10.0.2.2:8000",
                dicomWebEndpoint = prefs[Keys.DICOMWEB_URL] ?: "http://10.0.2.2:8042/dicom-web",
                textScale = prefs[Keys.TEXT_SCALE] ?: 1.0f,
                reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
                sessionLockMinutes = prefs[Keys.LOCK_MINUTES] ?: 15,
                aiAssistOptIn = prefs[Keys.AI_OPT_IN] ?: false,
                cacheRetentionHours = prefs[Keys.CACHE_RETENTION_HOURS] ?: 24,
            )
            val next = transform(current)
            prefs[Keys.SERVER_URL] = next.serverBaseUrl
            prefs[Keys.DICOMWEB_URL] = next.dicomWebEndpoint
            prefs[Keys.TEXT_SCALE] = next.textScale
            prefs[Keys.REDUCED_MOTION] = next.reducedMotion
            prefs[Keys.LOCK_MINUTES] = next.sessionLockMinutes
            prefs[Keys.AI_OPT_IN] = next.aiAssistOptIn
            prefs[Keys.CACHE_RETENTION_HOURS] = next.cacheRetentionHours
        }
    }
}
