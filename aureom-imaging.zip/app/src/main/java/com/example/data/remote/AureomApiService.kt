package com.example.data.remote

import com.squareup.moshi.JsonClass
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class AuthStatusResponse(val bootstrapped: Boolean)

@JsonClass(generateAdapter = true)
data class LoginRequestDto(val username: String, val password: String)

@JsonClass(generateAdapter = true)
data class BootstrapRequestDto(
    val admin_username: String,
    val admin_password: String,
    val display_name: String,
)

@JsonClass(generateAdapter = true)
data class UserPublicDto(
    val id: String,
    val username: String,
    val display_name: String,
    val role: String,
    val organisation_id: String,
)

@JsonClass(generateAdapter = true)
data class AuthTokenResponse(
    val access_token: String,
    val token_type: String,
    val user: UserPublicDto,
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    val status: String,
    val service: String,
    val ai_assist_enabled: Boolean,
)

@JsonClass(generateAdapter = true)
data class WorklistStudyDto(
    val study_instance_uid: String,
    val patient_record_id: String,
    val patient_id: String,
    val issuing_authority: String,
    val patient_name: String,
    val birth_date: String?,
    val sex: String?,
    val study_id: String?,
    val accession_number: String?,
    val accession_issuer: String?,
    val study_description: String,
    val study_date: String,
    val study_time: String,
    val frame_of_reference_uid: String?,
    val source_system: String,
    val transfer_status: String,
    val technical_review_status: String,
    val clinical_review_status: String,
    val series_count: Int,
    val is_synthetic_demo: Boolean,
)

@JsonClass(generateAdapter = true)
data class WorklistResponse(val studies: List<WorklistStudyDto>)

@JsonClass(generateAdapter = true)
data class AnnotationCreateDto(
    val series_instance_uid: String,
    val sop_instance_uid: String?,
    val measurement_type: String,
    val coordinate_system: String,
    val is_reconstructed_plane: Boolean,
    val plane_label: String?,
    val physical_units_valid: Boolean,
    val physical_unit_label: String,
    val geometry_json: String,
    val measured_value_text: String,
    val intensity_stats_json: String?,
    val note_text: String?,
)

@JsonClass(generateAdapter = true)
data class ReportSaveDto(
    val expected_version: Int?,
    val clinical_history: String,
    val technique_text: String,
    val findings_text: String,
    val impression_text: String,
    val examination_notes: String,
    val reviewer_id: String?,
    val status: String,
)

@JsonClass(generateAdapter = true)
data class AiAssistRequestDto(
    val study_instance_uid: String,
    val action: String,
)

interface AureomApiService {
    @GET("/health")
    suspend fun health(): HealthResponse

    @GET("/api/v1/auth/status")
    suspend fun authStatus(): AuthStatusResponse

    @POST("/api/v1/auth/bootstrap")
    suspend fun bootstrap(@Body req: BootstrapRequestDto): AuthTokenResponse

    @POST("/api/v1/auth/login")
    suspend fun login(@Body req: LoginRequestDto): AuthTokenResponse

    @GET("/api/v1/worklist")
    suspend fun getWorklist(@Query("q") q: String = ""): WorklistResponse

    @Multipart
    @POST("/api/v1/imports/dicom")
    suspend fun uploadDicom(@Part file: MultipartBody.Part): Map<String, Any>

    @GET("/api/v1/instances/{sopUid}/dicom")
    suspend fun downloadDicom(
        @Path("sopUid") sopUid: String,
        @Query("simulate_interrupt_byte") simulateInterruptByte: Int? = null,
    ): Response<ResponseBody>

    @POST("/api/v1/studies/{studyUid}/annotations")
    suspend fun createAnnotation(
        @Path("studyUid") studyUid: String,
        @Body req: AnnotationCreateDto,
    ): Map<String, Any>

    @DELETE("/api/v1/studies/{studyUid}/annotations/{id}")
    suspend fun deleteAnnotation(
        @Path("studyUid") studyUid: String,
        @Path("id") id: String,
    ): Map<String, Any>

    @PUT("/api/v1/studies/{studyUid}/reports")
    suspend fun saveReport(
        @Path("studyUid") studyUid: String,
        @Body req: ReportSaveDto,
    ): Map<String, Any>

    @POST("/api/v1/ai/assist")
    suspend fun aiAssist(
        @Header("X-AI-Assist-OptIn") optIn: String,
        @Body req: AiAssistRequestDto,
    ): Map<String, Any>

    companion object {
        fun create(baseUrl: String, tokenProvider: () -> String?): AureomApiService {
            val cleanBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
            val client = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .addInterceptor { chain ->
                    val token = tokenProvider()
                    val req = if (!token.isNullOrBlank()) {
                        chain.request().newBuilder()
                            .addHeader("Authorization", "Bearer $token")
                            .build()
                    } else {
                        chain.request()
                    }
                    chain.proceed(req)
                }
                .build()

            val moshi = com.squareup.moshi.Moshi.Builder()
                .add(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(cleanBase)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(AureomApiService::class.java)
        }
    }
}
