package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AnnotationEntity
import com.example.data.local.AuditEventEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.CachedSeriesEntity
import com.example.data.local.CachedStudyEntity
import com.example.data.local.ReportAmendmentEntity
import com.example.data.local.ReportEntity
import com.example.data.local.ReviewTaskEntity
import com.example.data.local.TransferJobEntity
import com.example.data.preferences.WorkspacePreferences
import com.example.data.preferences.WorkspaceSettingsState
import com.example.data.repository.IngestionOutcome
import com.example.data.repository.WorkspaceRepository
import com.example.data.research.KSpaceReconstructionResult
import com.example.data.security.DeviceKeyStoreManager
import com.example.dicom.DicomGeometry
import com.example.dicom.DicomSlice
import com.example.dicom.InterpolationMode
import com.example.dicom.MprPlane
import com.example.dicom.MprSliceResult
import com.example.dicom.RoiStats
import com.example.gl.GlSliceFrame
import com.example.gl.VolumeRenderConfig
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

enum class NavSection(val route: String, val label: String) {
    WORKLIST("worklist", "Worklist"),
    STUDIES("studies", "Studies"),
    VIEWER("viewer", "Viewer"),
    COMPARISONS("comparisons", "Comparisons"),
    ANNOTATIONS("annotations", "Annotations"),
    REPORTS("reports", "Reports"),
    TRANSFERS("transfers", "Transfers"),
    SETTINGS("settings", "Settings"),
}

enum class ViewerTool(val label: String) {
    SCROLL("Scroll / WL"),
    PAN_ZOOM("Pan / Zoom"),
    CROSSHAIR("Crosshair"),
    LENGTH("Length"),
    ANGLE("Angle"),
    ROI("ROI Stats"),
    ARROW("Arrow"),
    TEXT_NOTE("Text Note"),
    CONTOUR("Contour"),
}

enum class ViewportLayoutMode(val label: String) {
    SINGLE("1-Panel"),
    FOUR_UP("4-Panel MPR+3D"),
}

data class ViewerState(
    val layoutMode: ViewportLayoutMode = ViewportLayoutMode.SINGLE,
    val activePlane: MprPlane = MprPlane.ACQUISITION,
    val interpolation: InterpolationMode = InterpolationMode.TRILINEAR,
    val activeTool: ViewerTool = ViewerTool.SCROLL,
    val sliceIndex: Int = 0,
    val normalizedMprPos: Float = 0.5f,
    val axialPos: Float = 0.5f,
    val sagittalPos: Float = 0.5f,
    val coronalPos: Float = 0.5f,
    val windowCenter: Double = 700.0,
    val windowWidth: Double = 1400.0,
    val invertGrayscale: Boolean = false,
    val zoom: Float = 1.0f,
    val panXNorm: Float = 0f,
    val panYNorm: Float = 0f,
    val showCrosshair: Boolean = true,
    val crosshairNormX: Float = 0.5f,
    val crosshairNormY: Float = 0.5f,
    val linkMprCrosshair: Boolean = true,
    val showToolsDrawer: Boolean = true,
    val showMetadataSheet: Boolean = false,
    val volumeConfig: VolumeRenderConfig = VolumeRenderConfig(),
    val latestRoiStats: RoiStats? = null,
)

data class ComparisonState(
    val priorStudyUid: String? = null,
    val priorSeriesUid: String? = null,
    val priorSlices: List<DicomSlice> = emptyList(),
    val currentSliceIdx: Int = 0,
    val priorSliceIdx: Int = 0,
    val manualSliceOffset: Int = 0,
    val manualPanXMm: Float = 0f,
    val manualPanYMm: Float = 0f,
    val linkBySpatialPosition: Boolean = false,
    val spatialLinkStatus: String = "Select a prior study & series to establish spatial relationship.",
)

data class WorkspaceSessionState(
    val operatorName: String = "Dr. Claire Aureom (Demo Radiologist)",
    val isLocked: Boolean = false,
    val serverConnected: Boolean = false,
    val statusBanner: String? = null,
    val errorBanner: String? = null,
    val remediationBanner: String? = null,
    val worklistQuery: String = "",
)

@OptIn(ExperimentalCoroutinesApi::class)
class AureomViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AureomDatabase.getInstance(application)
    private val dao = db.aureomDao()
    private val keyStore = DeviceKeyStoreManager(application)
    private val prefs = WorkspacePreferences(application)
    private val repo = WorkspaceRepository(application, dao, keyStore)

    private val _session = MutableStateFlow(WorkspaceSessionState())
    val session: StateFlow<WorkspaceSessionState> = _session.asStateFlow()

    val settings: StateFlow<WorkspaceSettingsState> = prefs.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        WorkspaceSettingsState(),
    )

    val studies: StateFlow<List<CachedStudyEntity>> = repo.studiesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList(),
    )

    val transfers: StateFlow<List<TransferJobEntity>> = repo.transfersFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList(),
    )

    val auditEvents: StateFlow<List<AuditEventEntity>> = repo.auditEventsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList(),
    )

    private val _selectedStudyUid = MutableStateFlow<String?>(null)
    val selectedStudyUid: StateFlow<String?> = _selectedStudyUid.asStateFlow()

    val selectedStudy: StateFlow<CachedStudyEntity?> = combine(studies, _selectedStudyUid) { list, uid ->
        list.firstOrNull { it.studyInstanceUid == uid } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeSeriesList: StateFlow<List<CachedSeriesEntity>> = selectedStudy.flatMapLatest { study ->
        if (study == null) flowOf(emptyList()) else repo.observeSeries(study.studyInstanceUid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Study-isolated annotations, reports, amendments, and tasks
    val activeAnnotations: StateFlow<List<AnnotationEntity>> = selectedStudy.flatMapLatest { study ->
        if (study == null) flowOf(emptyList()) else repo.observeAnnotations(study.studyInstanceUid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeReports: StateFlow<List<ReportEntity>> = selectedStudy.flatMapLatest { study ->
        if (study == null) flowOf(emptyList()) else repo.observeReports(study.studyInstanceUid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAmendments: StateFlow<List<ReportAmendmentEntity>> = selectedStudy.flatMapLatest { study ->
        if (study == null) flowOf(emptyList()) else repo.observeAmendments(study.studyInstanceUid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeReviewTasks: StateFlow<List<ReviewTaskEntity>> = selectedStudy.flatMapLatest { study ->
        if (study == null) flowOf(emptyList()) else repo.observeTasks(study.studyInstanceUid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedSeriesUid = MutableStateFlow<String?>(null)
    val selectedSeries: StateFlow<CachedSeriesEntity?> = combine(activeSeriesList, _selectedSeriesUid) { list, uid ->
        list.firstOrNull { it.seriesInstanceUid == uid } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _activeSlices = MutableStateFlow<List<DicomSlice>>(emptyList())
    val activeSlices: StateFlow<List<DicomSlice>> = _activeSlices.asStateFlow()

    private val _viewerState = MutableStateFlow(ViewerState())
    val viewerState: StateFlow<ViewerState> = _viewerState.asStateFlow()

    private val _comparisonState = MutableStateFlow(ComparisonState())
    val comparisonState: StateFlow<ComparisonState> = _comparisonState.asStateFlow()

    private val _kspaceResult = MutableStateFlow<KSpaceReconstructionResult?>(null)
    val kspaceResult: StateFlow<KSpaceReconstructionResult?> = _kspaceResult.asStateFlow()

    private val _aiSummaryOutput = MutableStateFlow<String?>(null)
    val aiSummaryOutput: StateFlow<String?> = _aiSummaryOutput.asStateFlow()

    private var importJob: Job? = null

    init {
        viewModelScope.launch {
            repo.seedBundledDemoFixturesIfEmpty(_session.value.operatorName)
            refreshServerHealth()
        }
        viewModelScope.launch {
            selectedSeries.collect { series ->
                if (series != null) {
                    loadSeriesForViewing(series)
                } else {
                    _activeSlices.value = emptyList()
                }
            }
        }
    }

    fun selectStudy(studyUid: String) {
        if (_selectedStudyUid.value != studyUid) {
            _selectedStudyUid.value = studyUid
            _selectedSeriesUid.value = null
            _viewerState.update { it.copy(latestRoiStats = null, activePlane = MprPlane.ACQUISITION) }
            viewModelScope.launch {
                repo.logAudit(_session.value.operatorName, "SELECT_STUDY", "study", studyUid, studyUid, "SUCCESS", "Isolated context switched.")
            }
        }
    }

    fun selectSeries(seriesUid: String) {
        _selectedSeriesUid.value = seriesUid
    }

    private suspend fun loadSeriesForViewing(series: CachedSeriesEntity) {
        val loaded = repo.loadSeriesSlices(series.seriesInstanceUid)
        _activeSlices.value = loaded
        val mid = (loaded.size / 2).coerceIn(0, (loaded.size - 1).coerceAtLeast(0))
        val midSlice = loaded.getOrNull(mid)
        _viewerState.update {
            it.copy(
                sliceIndex = mid,
                normalizedMprPos = 0.5f,
                axialPos = 0.5f,
                sagittalPos = 0.5f,
                coronalPos = 0.5f,
                activePlane = if (series.isVolumetricCompatible) it.activePlane else MprPlane.ACQUISITION,
                layoutMode = if (series.isVolumetricCompatible) it.layoutMode else ViewportLayoutMode.SINGLE,
                windowCenter = midSlice?.defaultWindowCenter ?: 700.0,
                windowWidth = midSlice?.defaultWindowWidth ?: 1400.0,
                invertGrayscale = false,
                zoom = 1.0f,
                panXNorm = 0f,
                panYNorm = 0f,
                latestRoiStats = null,
            )
        }
    }

    fun updateWorklistQuery(q: String) {
        _session.update { it.copy(worklistQuery = q) }
    }

    fun clearBanners() {
        _session.update { it.copy(statusBanner = null, errorBanner = null, remediationBanner = null) }
    }

    fun setSessionLocked(locked: Boolean) {
        _session.update { it.copy(isLocked = locked) }
        viewModelScope.launch {
            repo.logAudit(_session.value.operatorName, if (locked) "SESSION_LOCKED" else "SESSION_UNLOCKED", "session", "workstation", null, "SUCCESS", "")
        }
    }

    fun refreshServerHealth() {
        viewModelScope.launch {
            val ok = repo.checkServerConnection(settings.value.serverBaseUrl).getOrDefault(false)
            _session.update { it.copy(serverConnected = ok) }
        }
    }

    fun connectRemoteServer(username: String, password: String) {
        viewModelScope.launch {
            val res = repo.loginRemote(settings.value.serverBaseUrl, username, password)
            res.onSuccess { displayName ->
                _session.update {
                    it.copy(
                        operatorName = displayName,
                        serverConnected = true,
                        statusBanner = "Authenticated to FastAPI backend as $displayName.",
                        errorBanner = null,
                    )
                }
            }.onFailure { err ->
                _session.update {
                    it.copy(
                        serverConnected = false,
                        errorBanner = "Backend connection failed: ${err.message}",
                        remediationBanner = "Start Docker Compose or verify Server URL in Settings. Local synthetic archive remains available.",
                    )
                }
            }
        }
    }

    fun importLocalDicomUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        importJob?.cancel()
        importJob = viewModelScope.launch {
            val outcomes = repo.importFromDocumentUris(uris, _session.value.operatorName)
            val successes = outcomes.filterIsInstance<IngestionOutcome.Success>()
            val failures = outcomes.filterIsInstance<IngestionOutcome.Failure>()
            if (successes.isNotEmpty()) {
                _selectedStudyUid.value = successes.first().studyUid
                _selectedSeriesUid.value = successes.first().seriesUid
            }
            if (failures.isNotEmpty()) {
                val f = failures.first()
                _session.update {
                    it.copy(
                        errorBanner = "${f.code}: ${f.message}",
                        remediationBanner = f.remediation,
                        statusBanner = if (successes.isNotEmpty()) "Imported ${successes.size} valid object(s); ${failures.size} rejected." else null,
                    )
                }
            } else if (successes.isNotEmpty()) {
                val dupCount = successes.count { it.duplicateSkipped }
                _session.update {
                    it.copy(
                        statusBanner = "Imported ${successes.size} DICOM object(s) ($dupCount duplicate(s) skipped safely).",
                        errorBanner = null,
                        remediationBanner = null,
                    )
                }
            }
        }
    }

    fun runEdgeCaseFixtureTest(assetPath: String) {
        viewModelScope.launch {
            when (val res = repo.testEdgeFixtureIngestion(assetPath, _session.value.operatorName)) {
                is IngestionOutcome.Failure -> {
                    _session.update {
                        it.copy(
                            errorBanner = "${res.code}: ${res.message}",
                            remediationBanner = res.remediation,
                            statusBanner = null,
                        )
                    }
                }
                is IngestionOutcome.Success -> {
                    _session.update {
                        it.copy(statusBanner = "Object ingested: ${res.sopUid}", errorBanner = null)
                    }
                }
            }
        }
    }

    fun triggerSimulatedInterruptedTransfer() {
        viewModelScope.launch {
            val jobId = "job-sim-interrupt-${System.currentTimeMillis() % 10000}"
            repo.simulateInterruptedTransfer(jobId, shouldFailMidway = true, actorName = _session.value.operatorName)
        }
    }

    fun retryTransfer(job: TransferJobEntity) {
        viewModelScope.launch {
            repo.simulateInterruptedTransfer(job.id, shouldFailMidway = false, actorName = _session.value.operatorName)
        }
    }

    fun cancelTransfer(job: TransferJobEntity) {
        importJob?.cancel()
        viewModelScope.launch {
            repo.markTransferCancelled(job)
        }
    }

    // ---- Viewer Controls ----

    fun stepSlice(delta: Int) {
        val slices = _activeSlices.value
        if (slices.isEmpty()) return
        val state = _viewerState.value
        if (state.activePlane == MprPlane.ACQUISITION) {
            val next = (state.sliceIndex + delta).coerceIn(0, slices.size - 1)
            _viewerState.update { it.copy(sliceIndex = next) }
        } else {
            val nextPos = (state.normalizedMprPos + delta * 0.04f).coerceIn(0f, 1f)
            _viewerState.update { it.copy(normalizedMprPos = nextPos) }
        }
    }

    fun setSliceIndex(index: Int) {
        val maxIdx = (_activeSlices.value.size - 1).coerceAtLeast(0)
        _viewerState.update { it.copy(sliceIndex = index.coerceIn(0, maxIdx)) }
    }

    fun setMprPosition(pos: Float) {
        _viewerState.update { it.copy(normalizedMprPos = pos.coerceIn(0f, 1f)) }
    }

    fun setQuadPositions(axial: Float? = null, sagittal: Float? = null, coronal: Float? = null) {
        _viewerState.update {
            it.copy(
                axialPos = axial?.coerceIn(0f, 1f) ?: it.axialPos,
                sagittalPos = sagittal?.coerceIn(0f, 1f) ?: it.sagittalPos,
                coronalPos = coronal?.coerceIn(0f, 1f) ?: it.coronalPos,
            )
        }
    }

    fun adjustWindowLevel(deltaWc: Double, deltaWw: Double) {
        _viewerState.update {
            it.copy(
                windowCenter = it.windowCenter + deltaWc,
                windowWidth = (it.windowWidth + deltaWw).coerceAtLeast(10.0),
            )
        }
    }

    fun setWindowLevel(wc: Double, ww: Double) {
        _viewerState.update { it.copy(windowCenter = wc, windowWidth = ww.coerceAtLeast(10.0)) }
    }

    fun adjustZoomPan(zoomFactor: Float, panDx: Float, panDy: Float) {
        _viewerState.update {
            it.copy(
                zoom = (it.zoom * zoomFactor).coerceIn(0.4f, 8.0f),
                panXNorm = (it.panXNorm + panDx).coerceIn(-1.5f, 1.5f),
                panYNorm = (it.panYNorm + panDy).coerceIn(-1.5f, 1.5f),
            )
        }
    }

    fun fitToScreen() {
        _viewerState.update { it.copy(zoom = 1.0f, panXNorm = 0f, panYNorm = 0f) }
    }

    fun toggleInvert() {
        _viewerState.update { it.copy(invertGrayscale = !it.invertGrayscale) }
    }

    fun toggleCrosshair() {
        _viewerState.update { it.copy(showCrosshair = !it.showCrosshair) }
    }

    fun moveCrosshair(normX: Float, normY: Float) {
        _viewerState.update {
            val nx = normX.coerceIn(0f, 1f)
            val ny = normY.coerceIn(0f, 1f)
            if (it.linkMprCrosshair) {
                it.copy(crosshairNormX = nx, crosshairNormY = ny, sagittalPos = nx, coronalPos = ny)
            } else {
                it.copy(crosshairNormX = nx, crosshairNormY = ny)
            }
        }
    }

    fun toggleLinkedMprCrosshair() {
        _viewerState.update { it.copy(linkMprCrosshair = !it.linkMprCrosshair) }
    }

    fun resetDisplaySettings() {
        val slice = _activeSlices.value.getOrNull(_viewerState.value.sliceIndex)
        _viewerState.update {
            it.copy(
                windowCenter = slice?.defaultWindowCenter ?: 700.0,
                windowWidth = slice?.defaultWindowWidth ?: 1400.0,
                invertGrayscale = false,
                zoom = 1.0f,
                panXNorm = 0f,
                panYNorm = 0f,
                volumeConfig = VolumeRenderConfig(),
            )
        }
    }

    fun setActiveTool(tool: ViewerTool) {
        _viewerState.update { it.copy(activeTool = tool) }
    }

    fun toggleToolsDrawer() {
        _viewerState.update { it.copy(showToolsDrawer = !it.showToolsDrawer) }
    }

    fun setLayoutMode(mode: ViewportLayoutMode) {
        val series = selectedSeries.value
        if (mode == ViewportLayoutMode.FOUR_UP && series?.isVolumetricCompatible != true) {
            _session.update {
                it.copy(
                    errorBanner = "4-Panel MPR/3D requires a validated volumetric series.",
                    remediationBanner = series?.geometryWarningsJoined?.ifBlank { null }
                        ?: "Select a volumetric series (e.g., 3D T1 MPRAGE or Oblique 30° T1) to unlock MPR and 3D views.",
                )
            }
            return
        }
        _viewerState.update { it.copy(layoutMode = mode) }
    }

    fun setMprPlane(plane: MprPlane) {
        val series = selectedSeries.value
        if (plane != MprPlane.ACQUISITION && series?.isVolumetricCompatible != true) {
            _session.update {
                it.copy(
                    errorBanner = "MPR disabled for non-volumetric or flagged series.",
                    remediationBanner = series?.geometryWarningsJoined?.ifBlank { "Geometry check failed." },
                )
            }
            return
        }
        _viewerState.update { it.copy(activePlane = plane) }
    }

    fun setInterpolation(mode: InterpolationMode) {
        _viewerState.update { it.copy(interpolation = mode) }
    }

    fun updateVolumeConfig(transform: (VolumeRenderConfig) -> VolumeRenderConfig) {
        _viewerState.update { it.copy(volumeConfig = transform(it.volumeConfig)) }
    }

    fun computeCurrentFrame(): Pair<GlSliceFrame?, MprSliceResult?> {
        val slices = _activeSlices.value
        if (slices.isEmpty()) return null to null
        val v = _viewerState.value
        if (v.activePlane == MprPlane.ACQUISITION) {
            val s = slices[v.sliceIndex.coerceIn(0, slices.size - 1)]
            val frame = GlSliceFrame(
                key = "${s.sopInstanceUid}|${v.activePlane.name}",
                width = s.columns,
                height = s.rows,
                pixels = s.rawPixels,
                missingMask = null,
                photometricInterpretation = s.photometricInterpretation,
            )
            return frame to null
        }
        val mpr = DicomGeometry.resampleMprPlane(slices, v.activePlane, v.normalizedMprPos, v.interpolation)
            ?: return null to null
        val frame = GlSliceFrame(
            key = "${slices.first().seriesInstanceUid}|${v.activePlane.name}|${v.interpolation.name}|${"%.3f".format(v.normalizedMprPos)}",
            width = mpr.width,
            height = mpr.height,
            pixels = mpr.pixels,
            missingMask = mpr.missingDataMask,
            photometricInterpretation = slices.first().photometricInterpretation,
        )
        return frame to mpr
    }

    // ---- Measurements & Study-Isolated Annotations ----

    fun recordTwoPointAnnotation(
        type: String, // LENGTH, ARROW
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        mpr: MprSliceResult?,
    ) {
        val study = selectedStudy.value ?: return
        val series = selectedSeries.value ?: return
        val slice = _activeSlices.value.getOrNull(_viewerState.value.sliceIndex) ?: return

        val width = mpr?.width ?: slice.columns
        val height = mpr?.height ?: slice.rows
        val colSp = mpr?.colSpacingMm ?: slice.pixelSpacingCol
        val rowSp = mpr?.rowSpacingMm ?: slice.pixelSpacingRow
        val isMpr = mpr?.isReconstructed == true

        val (measuredText, physicalValid) = if (type == "LENGTH") {
            DicomGeometry.measureLength(x1, y1, x2, y2, width, height, colSp, rowSp, isMpr)
        } else {
            "Pointer Arrow" to (colSp != null && rowSp != null)
        }

        val geomJson = JSONObject().apply {
            put("points", JSONArray().apply {
                put(JSONArray(listOf(x1, y1)))
                put(JSONArray(listOf(x2, y2)))
            })
        }.toString()

        saveNewAnnotation(
            studyUid = study.studyInstanceUid,
            seriesUid = series.seriesInstanceUid,
            sopUid = if (isMpr) null else slice.sopInstanceUid,
            type = type,
            isMpr = isMpr,
            planeLabel = mpr?.plane?.label ?: MprPlane.ACQUISITION.label,
            physicalValid = physicalValid,
            unitLabel = if (physicalValid) "mm" else "px",
            geomJson = geomJson,
            measuredValueText = measuredText,
            statsJson = null,
            noteText = null,
        )
    }

    fun recordAngleAnnotation(
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        mpr: MprSliceResult?,
    ) {
        val study = selectedStudy.value ?: return
        val series = selectedSeries.value ?: return
        val slice = _activeSlices.value.getOrNull(_viewerState.value.sliceIndex) ?: return
        val deg = DicomGeometry.measureAngleDeg(
            x1, y1, x2, y2, x3, y3,
            mpr?.width ?: slice.columns,
            mpr?.height ?: slice.rows,
            mpr?.colSpacingMm ?: slice.pixelSpacingCol,
            mpr?.rowSpacingMm ?: slice.pixelSpacingRow,
        )
        val isMpr = mpr?.isReconstructed == true
        val geomJson = JSONObject().apply {
            put("points", JSONArray().apply {
                put(JSONArray(listOf(x1, y1)))
                put(JSONArray(listOf(x2, y2)))
                put(JSONArray(listOf(x3, y3)))
            })
        }.toString()
        saveNewAnnotation(
            studyUid = study.studyInstanceUid,
            seriesUid = series.seriesInstanceUid,
            sopUid = if (isMpr) null else slice.sopInstanceUid,
            type = "ANGLE",
            isMpr = isMpr,
            planeLabel = mpr?.plane?.label ?: MprPlane.ACQUISITION.label,
            physicalValid = true,
            unitLabel = "deg",
            geomJson = geomJson,
            measuredValueText = "${"%.1f".format(deg)}°${if (isMpr) " (MPR)" else ""}",
            statsJson = null,
            noteText = null,
        )
    }

    fun recordRoiAnnotation(
        cx: Float, cy: Float,
        rx: Float, ry: Float,
        mpr: MprSliceResult?,
    ) {
        val study = selectedStudy.value ?: return
        val series = selectedSeries.value ?: return
        val slice = _activeSlices.value.getOrNull(_viewerState.value.sliceIndex) ?: return
        val pixels = mpr?.pixels ?: slice.rawPixels
        val width = mpr?.width ?: slice.columns
        val height = mpr?.height ?: slice.rows
        val colSp = mpr?.colSpacingMm ?: slice.pixelSpacingCol
        val rowSp = mpr?.rowSpacingMm ?: slice.pixelSpacingRow

        val stats = DicomGeometry.computeEllipticalRoiStats(
            pixels = pixels,
            missingMask = mpr?.missingDataMask,
            width = width,
            height = height,
            centerXNorm = cx,
            centerYNorm = cy,
            rxNorm = rx,
            ryNorm = ry,
            colSpacingMm = colSp,
            rowSpacingMm = rowSp,
            quantityLabel = series.quantityLabel,
        )
        _viewerState.update { it.copy(latestRoiStats = stats) }

        val statsJson = JSONObject().apply {
            put("mean", stats.meanValue)
            put("stdDev", stats.stdDev)
            put("min", stats.minValue)
            put("max", stats.maxValue)
            put("area", stats.areaLabel)
            put("quantityLabel", stats.quantityLabel)
        }.toString()

        val geomJson = JSONObject().apply {
            put("center", JSONArray(listOf(cx, cy)))
            put("radii", JSONArray(listOf(rx, ry)))
        }.toString()

        val isMpr = mpr?.isReconstructed == true
        saveNewAnnotation(
            studyUid = study.studyInstanceUid,
            seriesUid = series.seriesInstanceUid,
            sopUid = if (isMpr) null else slice.sopInstanceUid,
            type = "ROI_ELLIPSE",
            isMpr = isMpr,
            planeLabel = mpr?.plane?.label ?: MprPlane.ACQUISITION.label,
            physicalValid = colSp != null && rowSp != null,
            unitLabel = if (colSp != null) "mm²" else "px²",
            geomJson = geomJson,
            measuredValueText = "Mean ${"%.1f".format(stats.meanValue)} ± ${"%.1f".format(stats.stdDev)} (${stats.areaLabel})",
            statsJson = statsJson,
            noteText = stats.quantityLabel,
        )
    }

    fun recordContourOrTextAnnotation(
        type: String, // TEXT_NOTE or CONTOUR
        points: List<Pair<Float, Float>>,
        noteText: String?,
        mpr: MprSliceResult?,
    ) {
        val study = selectedStudy.value ?: return
        val series = selectedSeries.value ?: return
        val slice = _activeSlices.value.getOrNull(_viewerState.value.sliceIndex) ?: return
        val isMpr = mpr?.isReconstructed == true
        val geomJson = JSONObject().apply {
            put("points", JSONArray(points.map { JSONArray(listOf(it.first, it.second)) }))
        }.toString()
        saveNewAnnotation(
            studyUid = study.studyInstanceUid,
            seriesUid = series.seriesInstanceUid,
            sopUid = if (isMpr) null else slice.sopInstanceUid,
            type = type,
            isMpr = isMpr,
            planeLabel = mpr?.plane?.label ?: MprPlane.ACQUISITION.label,
            physicalValid = false,
            unitLabel = "norm",
            geomJson = geomJson,
            measuredValueText = if (type == "CONTOUR") "Manual Contour (${points.size} pts)" else (noteText ?: "Note"),
            statsJson = null,
            noteText = noteText,
        )
    }

    private fun saveNewAnnotation(
        studyUid: String,
        seriesUid: String,
        sopUid: String?,
        type: String,
        isMpr: Boolean,
        planeLabel: String,
        physicalValid: Boolean,
        unitLabel: String,
        geomJson: String,
        measuredValueText: String,
        statsJson: String?,
        noteText: String?,
    ) {
        viewModelScope.launch {
            repo.saveAnnotation(
                AnnotationEntity(
                    id = "ann-${UUID.randomUUID().toString().take(8)}",
                    studyInstanceUid = studyUid,
                    seriesInstanceUid = seriesUid,
                    sopInstanceUid = sopUid,
                    authorId = "usr-local",
                    authorName = _session.value.operatorName,
                    measurementType = type,
                    coordinateSystem = if (isMpr) "MPR_OBLIQUE_PLANE" else "IMAGE_PIXEL_2D",
                    isReconstructedPlane = isMpr,
                    planeLabel = planeLabel,
                    physicalUnitsValid = physicalValid,
                    physicalUnitLabel = unitLabel,
                    geometryJson = geomJson,
                    measuredValueText = measuredValueText,
                    intensityStatsJson = statsJson,
                    noteText = noteText,
                    createdAtEpochMs = System.currentTimeMillis(),
                )
            )
        }
    }

    fun deleteAnnotation(annotation: AnnotationEntity) {
        viewModelScope.launch {
            repo.deleteAnnotation(annotation.id, annotation.studyInstanceUid, _session.value.operatorName)
        }
    }

    // ---- Comparison Controls ----

    fun loadComparisonPriorStudy(priorStudyUid: String) {
        viewModelScope.launch {
            val seriesList = repo.observeSeries(priorStudyUid)
            val currentStudy = selectedStudy.value
            val priorStudy = studies.value.firstOrNull { it.studyInstanceUid == priorStudyUid }
            val priorSeriesAll = db.aureomDao().getSeriesForStudy(priorStudyUid)
            val targetSeries = priorSeriesAll.firstOrNull { !it.isLocaliser } ?: priorSeriesAll.firstOrNull()
            val slices = if (targetSeries != null) repo.loadSeriesSlices(targetSeries.seriesInstanceUid) else emptyList()

            val sameFoR = !currentStudy?.frameOfReferenceUid.isNullOrBlank() &&
                currentStudy?.frameOfReferenceUid == priorStudy?.frameOfReferenceUid
            val statusMsg = when {
                slices.isEmpty() -> "Prior series contains no displayable slices."
                sameFoR -> "Shared FrameOfReferenceUID verified. Spatial linking permitted."
                else -> "Different FrameOfReferenceUID (different scan session). Manual alignment active; spatial link gated until manual offset verified."
            }
            _comparisonState.update {
                it.copy(
                    priorStudyUid = priorStudyUid,
                    priorSeriesUid = targetSeries?.seriesInstanceUid,
                    priorSlices = slices,
                    priorSliceIdx = (slices.size / 2).coerceIn(0, (slices.size - 1).coerceAtLeast(0)),
                    currentSliceIdx = _viewerState.value.sliceIndex,
                    linkBySpatialPosition = sameFoR,
                    spatialLinkStatus = statusMsg,
                )
            }
        }
    }

    fun stepComparisonSlices(deltaCurrent: Int, deltaPrior: Int) {
        val curSlices = _activeSlices.value
        val comp = _comparisonState.value
        val curNext = (comp.currentSliceIdx + deltaCurrent).coerceIn(0, (curSlices.size - 1).coerceAtLeast(0))

        val priorNext = if (comp.linkBySpatialPosition && curSlices.isNotEmpty() && comp.priorSlices.isNotEmpty()) {
            // Find closest prior slice by patient LPS projection (never assuming same slice index!)
            val curProj = curSlices[curNext].sliceNormalProjection
            if (curProj != null) {
                comp.priorSlices.indices.minByOrNull { idx ->
                    val pProj = comp.priorSlices[idx].sliceNormalProjection ?: Double.MAX_VALUE
                    abs(pProj - curProj)
                } ?: comp.priorSliceIdx
            } else {
                (comp.priorSliceIdx + deltaPrior).coerceIn(0, (comp.priorSlices.size - 1).coerceAtLeast(0))
            }
        } else {
            (comp.priorSliceIdx + deltaPrior).coerceIn(0, (comp.priorSlices.size - 1).coerceAtLeast(0))
        }
        _comparisonState.update { it.copy(currentSliceIdx = curNext, priorSliceIdx = priorNext) }
    }

    fun adjustComparisonManualAlignment(sliceOffsetDelta: Int, panDxMm: Float, panDyMm: Float) {
        _comparisonState.update {
            it.copy(
                manualSliceOffset = it.manualSliceOffset + sliceOffsetDelta,
                manualPanXMm = (it.manualPanXMm + panDxMm).coerceIn(-60f, 60f),
                manualPanYMm = (it.manualPanYMm + panDyMm).coerceIn(-60f, 60f),
            )
        }
    }

    fun toggleSpatialComparisonLink(enable: Boolean) {
        _comparisonState.update {
            it.copy(
                linkBySpatialPosition = enable,
                spatialLinkStatus = if (enable) {
                    "Linked via patient-space LPS normal projection (+ manual offset ${it.manualSliceOffset})."
                } else {
                    "Unlinked independent manual scrolling."
                },
            )
        }
    }

    // ---- Reporting & Review ----

    fun saveReport(
        existing: ReportEntity?,
        reviewerName: String,
        clinicalHistory: String,
        techniqueText: String,
        findingsText: String,
        impressionText: String,
        examinationNotes: String,
        submitForReview: Boolean,
    ) {
        val study = selectedStudy.value ?: return
        viewModelScope.launch {
            val res = repo.saveReportDraft(
                studyUid = study.studyInstanceUid,
                existing = existing,
                authorName = _session.value.operatorName,
                reviewerName = reviewerName,
                clinicalHistory = clinicalHistory,
                techniqueText = techniqueText,
                findingsText = findingsText,
                impressionText = impressionText,
                examinationNotes = examinationNotes,
                submitForReview = submitForReview,
            )
            res.onSuccess { rep ->
                _session.update { it.copy(statusBanner = "Saved report v${rep.version} (${rep.status}).", errorBanner = null) }
            }.onFailure { err ->
                _session.update { it.copy(errorBanner = err.message, remediationBanner = null) }
            }
        }
    }

    fun signReport(report: ReportEntity) {
        viewModelScope.launch {
            val res = repo.signReport(report, _session.value.operatorName)
            res.onSuccess {
                _session.update { it.copy(statusBanner = "Report signed & SHA-256 sealed.", errorBanner = null) }
            }.onFailure { err ->
                _session.update { it.copy(errorBanner = err.message) }
            }
        }
    }

    fun addAmendment(report: ReportEntity, reason: String, text: String) {
        viewModelScope.launch {
            val res = repo.addAmendment(report, _session.value.operatorName, reason, text)
            res.onSuccess {
                _session.update { it.copy(statusBanner = "Linked amendment recorded.", errorBanner = null) }
            }.onFailure { err ->
                _session.update { it.copy(errorBanner = err.message) }
            }
        }
    }

    fun addReviewTask(taskType: String, assignee: String, dueDate: String, notes: String) {
        val study = selectedStudy.value ?: return
        viewModelScope.launch {
            repo.addReviewTask(study.studyInstanceUid, taskType, assignee, dueDate, notes, _session.value.operatorName)
            _session.update { it.copy(statusBanner = "Review task created ($taskType).") }
        }
    }

    // ---- Research k-Space & AI Assist ----

    fun runResearchKSpaceDemo() {
        viewModelScope.launch {
            val res = repo.reconstructBundledResearchKSpace()
            _kspaceResult.value = res
        }
    }

    fun generateNonDiagnosticReportSummary() {
        if (!settings.value.aiAssistOptIn) {
            _session.update {
                it.copy(
                    errorBanner = "AI Assist is disabled by default.",
                    remediationBanner = "Enable the non-diagnostic AI Assist adapter in Settings if authorised.",
                )
            }
            return
        }
        val study = selectedStudy.value ?: return
        val series = activeSeriesList.value
        val reports = activeReports.value
        val sb = StringBuilder()
        sb.appendLine("NON-DIAGNOSTIC METADATA & REPORT SUMMARY (Source-Referenced)")
        sb.appendLine("Study: ${study.studyDescription} [${study.studyInstanceUid.takeLast(12)}]")
        sb.appendLine("Series Organised (${series.size}):")
        series.forEach { s ->
            sb.appendLine("  • #${s.seriesNumber} ${s.sourceDescription} -> ${s.inferredSequenceLabel ?: "Unclassified"} (${s.geometryStatus})")
        }
        if (reports.isEmpty()) {
            sb.appendLine("Authorised Reports: None recorded yet.")
        } else {
            reports.forEach { r ->
                sb.appendLine("Source Report [${r.id} v${r.version} ${r.status}]: ${r.impressionText.ifBlank { r.findingsText.take(120) }}")
            }
        }
        _aiSummaryOutput.value = sb.toString()
    }

    // ---- Settings & Cache ----

    fun updateSettings(transform: (WorkspaceSettingsState) -> WorkspaceSettingsState) {
        viewModelScope.launch {
            prefs.updateSettings(transform)
        }
    }

    fun purgeLocalCacheAndReseed() {
        viewModelScope.launch {
            repo.purgeRestrictedCache(_session.value.operatorName)
            repo.seedBundledDemoFixturesIfEmpty(_session.value.operatorName)
            _session.update { it.copy(statusBanner = "Restricted private cache purged and demonstration archive reloaded.") }
        }
    }
}
