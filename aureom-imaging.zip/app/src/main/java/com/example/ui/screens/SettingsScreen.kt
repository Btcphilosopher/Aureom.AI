package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.AuditEventEntity
import com.example.data.preferences.WorkspaceSettingsState
import com.example.ui.components.formatEpoch
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning

@Composable
fun SettingsScreen(
    settings: WorkspaceSettingsState,
    serverConnected: Boolean,
    auditEvents: List<AuditEventEntity>,
    onUpdateSettings: ((WorkspaceSettingsState) -> WorkspaceSettingsState) -> Unit,
    onConnectRemote: (String, String) -> Unit,
    onPurgeCache: () -> Unit,
) {
    var serverUrl by remember(settings.serverBaseUrl) { mutableStateOf(settings.serverBaseUrl) }
    var dicomWebUrl by remember(settings.dicomWebEndpoint) { mutableStateOf(settings.dicomWebEndpoint) }
    var username by remember { mutableStateOf("dr.aureom") }
    var password by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
    ) {
        item {
            Text("Workspace Settings, Security & Audit Log", style = MaterialTheme.typography.headlineMedium)
        }

        // Backend & DICOMweb Configuration
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "FastAPI Backend & DICOMweb Endpoint (${if (serverConnected) "CONNECTED" else "LOCAL ARCHIVE MODE"})",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (serverConnected) StatusValid else StatusWarning,
                    )
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("FastAPI Server URL") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = dicomWebUrl,
                        onValueChange = { dicomWebUrl = it },
                        label = { Text("DICOMweb QIDO/WADO Endpoint") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Org Username") },
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password (>=8 chars)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onUpdateSettings { it.copy(serverBaseUrl = serverUrl.trim(), dicomWebEndpoint = dicomWebUrl.trim()) } },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Save Endpoints") }
                        Button(
                            onClick = {
                                onUpdateSettings { it.copy(serverBaseUrl = serverUrl.trim(), dicomWebEndpoint = dicomWebUrl.trim()) }
                                onConnectRemote(username.trim(), password)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Authenticate / Claim Server") }
                    }
                }
            }
        }

        // Accessibility & Display Preferences
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Accessibility & Ergonomics", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    Text("Interface Text Scale", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1.0f to "1.0x", 1.15f to "1.15x", 1.3f to "1.3x").forEach { (scale, lbl) ->
                            FilterChip(
                                selected = settings.textScale == scale,
                                onClick = { onUpdateSettings { it.copy(textScale = scale) } },
                                label = { Text(lbl) },
                                modifier = Modifier.testTag("text_scale_$lbl"),
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Reduced Motion", style = MaterialTheme.typography.bodyLarge)
                            Text("Disables animated transitions in UI.", style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = settings.reducedMotion,
                            onCheckedChange = { v -> onUpdateSettings { it.copy(reducedMotion = v) } },
                            modifier = Modifier.testTag("reduced_motion_switch"),
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Non-Diagnostic AI Assist Adapter", style = MaterialTheme.typography.bodyLarge)
                            Text("Disabled by default. Organises series metadata & summarises authorised text only.", style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = settings.aiAssistOptIn,
                            onCheckedChange = { v -> onUpdateSettings { it.copy(aiAssistOptIn = v) } },
                            modifier = Modifier.testTag("ai_assist_switch"),
                        )
                    }
                }
            }
        }

        // Restricted Cache & Keyboard Shortcuts
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Restricted Device Cache & Keyboard Shortcuts", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    Text(
                        "Original DICOM files are stored inside app-private storage (outside MediaStore/photo gallery) with KeyStore-protected credentials. Retention: ${settings.cacheRetentionHours}h.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedButton(
                        onClick = onPurgeCache,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) { Text("Purge Restricted Cache & Reload Demo Archive", color = StatusError) }
                    Text(
                        "Keyboard Shortcuts (Hardware Keyboard): Up/Down/Left/Right = Scroll Slices • I = Invert • F = Fit • R = Reset • C = Crosshair • 1/4 = 1-Panel / 4-Panel",
                        style = MaterialTheme.typography.labelSmall,
                        color = ClinicalSlate,
                    )
                }
            }
        }

        // Supported Format Matrix & Regulatory Reminder
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Supported Format Matrix & Safety Notice", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    Text("• Supported: Single-frame MR Image Storage (1.2.840.10008.5.1.4.1.1.4), Implicit & Explicit VR Little Endian, 8/12/16-bit MONOCHROME1/2.", style = MaterialTheme.typography.labelSmall)
                    Text("• Rejected cleanly: JPEG 2000 / compressed syntaxes, Enhanced Multiframe MR (Milestone 2), non-MR modalities.", style = MaterialTheme.typography.labelSmall)
                    Text("• Clinical Safety: Demonstration build only. Verify jurisdiction, SaMD classification, GSDF display calibration, and PACS integration prior to clinical use.", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                }
            }
        }

        item {
            Text("Security & Access Audit Log (${auditEvents.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(auditEvents.take(30), key = { it.id }) { ev ->
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp)),
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("${ev.action} • ${ev.outcome} (${ev.actorName})", style = MaterialTheme.typography.labelMedium, color = ClinicalWhite)
                    Text("${ev.resourceType}: ${ev.resourceId} • ${formatEpoch(ev.createdAtEpochMs)} ${if (ev.details.isNotBlank()) "• ${ev.details}" else ""}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
