package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedStudyEntity
import com.example.data.local.ReportAmendmentEntity
import com.example.data.local.ReportEntity
import com.example.data.local.ReviewTaskEntity
import com.example.ui.components.formatEpoch
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning

@Composable
fun ReportsScreen(
    study: CachedStudyEntity?,
    reports: List<ReportEntity>,
    amendments: List<ReportAmendmentEntity>,
    tasks: List<ReviewTaskEntity>,
    aiAssistEnabled: Boolean,
    aiSummaryOutput: String?,
    onSaveReport: (ReportEntity?, String, String, String, String, String, String, Boolean) -> Unit,
    onSignReport: (ReportEntity) -> Unit,
    onAddAmendment: (ReportEntity, String, String) -> Unit,
    onAddTask: (String, String, String, String) -> Unit,
    onGenerateAiSummary: () -> Unit,
) {
    val activeReport = reports.firstOrNull()
    val isSignedOrAmended = activeReport?.status == "SIGNED" || activeReport?.status == "AMENDED"

    var reviewer by remember(activeReport?.id, study?.studyInstanceUid) { mutableStateOf(activeReport?.reviewerName ?: "Dr. M. Patel (Peer Reviewer)") }
    var history by remember(activeReport?.id, activeReport?.version, study?.studyInstanceUid) { mutableStateOf(activeReport?.clinicalHistory ?: "") }
    var technique by remember(activeReport?.id, activeReport?.version, study?.studyInstanceUid) { mutableStateOf(activeReport?.techniqueText ?: "Multiplanar non-contrast MRI brain protocol (3D T1 MPRAGE, T2 TSE, FLAIR).") }
    var findings by remember(activeReport?.id, activeReport?.version, study?.studyInstanceUid) { mutableStateOf(activeReport?.findingsText ?: "") }
    var impression by remember(activeReport?.id, activeReport?.version, study?.studyInstanceUid) { mutableStateOf(activeReport?.impressionText ?: "") }
    var notes by remember(activeReport?.id, activeReport?.version, study?.studyInstanceUid) { mutableStateOf(activeReport?.examinationNotes ?: "") }

    var amdReason by remember { mutableStateOf("") }
    var amdText by remember { mutableStateOf("") }
    var newTaskNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
    ) {
        item {
            Text("Clinical Reporting, Review & Amendments", style = MaterialTheme.typography.headlineMedium)
            if (study != null) {
                // Separate Image Availability, Technical Review, and Clinical Reporting Status
                Surface(
                    color = GraphiteSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp).border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text("IMAGE AVAILABILITY", style = MaterialTheme.typography.labelSmall)
                            Text(study.transferStatus, style = MaterialTheme.typography.labelMedium, color = StatusValid)
                        }
                        Column {
                            Text("TECHNICAL QA", style = MaterialTheme.typography.labelSmall)
                            Text(study.technicalReviewStatus, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                        }
                        Column {
                            Text("CLINICAL REPORT", style = MaterialTheme.typography.labelSmall)
                            Text(study.clinicalReviewStatus, style = MaterialTheme.typography.labelMedium, color = if (isSignedOrAmended) StatusValid else StatusWarning)
                        }
                    }
                }
            }
        }

        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = if (activeReport == null) "New Draft Report" else "Report ${activeReport.id} • v${activeReport.version} • ${activeReport.status}",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanAccent,
                        )
                        if (activeReport?.contentSha256 != null) {
                            Text("Seal: ${activeReport.contentSha256.take(12)}", style = MaterialTheme.typography.labelSmall, color = StatusValid)
                        }
                    }

                    OutlinedTextField(
                        value = reviewer,
                        onValueChange = { reviewer = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Assigned Peer Reviewer") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = history,
                        onValueChange = { history = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Clinical History / Indication") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = technique,
                        onValueChange = { technique = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Technique") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = findings,
                        onValueChange = { findings = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Findings") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("report_findings_input"),
                    )
                    OutlinedTextField(
                        value = impression,
                        onValueChange = { impression = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Impression") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("report_impression_input"),
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        enabled = !isSignedOrAmended,
                        label = { Text("Examination Notes (Technical / Internal)") },
                        modifier = Modifier.fillMaxWidth(),
                    )

                    if (!isSignedOrAmended) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onSaveReport(activeReport, reviewer, history, technique, findings, impression, notes, false) },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("save_draft_button"),
                            ) { Text("Save Draft") }
                            OutlinedButton(
                                onClick = { onSaveReport(activeReport, reviewer, history, technique, findings, impression, notes, true) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) { Text("Submit Review") }
                            if (activeReport != null) {
                                Button(
                                    onClick = { onSignReport(activeReport) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusValid, contentColor = GraphiteVoid),
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("sign_report_button"),
                                ) { Text("Sign & Seal", fontWeight = FontWeight.SemiBold) }
                            }
                        }
                    } else {
                        Text(
                            "Signed by ${activeReport?.signedBy} at ${activeReport?.signedAtEpochMs?.let { formatEpoch(it) } ?: "-"}. Signed content is immutable.",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusValid,
                        )
                    }
                }
            }
        }

        // Linked Amendments Section (active after signature)
        if (activeReport != null && isSignedOrAmended) {
            item {
                Surface(
                    color = GraphiteSurfaceElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, StatusWarning.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Linked Amendments (${amendments.size})", style = MaterialTheme.typography.titleMedium, color = StatusWarning)
                        amendments.forEach { amd ->
                            Text("• ${amd.reason} (${amd.authorName}, ${formatEpoch(amd.createdAtEpochMs)}): ${amd.amendmentText}", style = MaterialTheme.typography.bodyMedium)
                        }
                        OutlinedTextField(value = amdReason, onValueChange = { amdReason = it }, label = { Text("Amendment Reason") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = amdText, onValueChange = { amdText = it }, label = { Text("Amendment Text") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                if (amdReason.isNotBlank() && amdText.isNotBlank()) {
                                    onAddAmendment(activeReport, amdReason.trim(), amdText.trim())
                                    amdReason = ""
                                    amdText = ""
                                }
                            },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Record Linked Amendment") }
                    }
                }
            }
        }

        // Review & Follow-up Tasks
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Review & Follow-up Tasks (${tasks.size})", style = MaterialTheme.typography.titleMedium)
                    tasks.forEach { t ->
                        Text("• [${t.status}] ${t.taskType} (${t.assignedTo}): ${t.notes}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newTaskNotes,
                            onValueChange = { newTaskNotes = it },
                            label = { Text("Follow-up / QA task note") },
                            modifier = Modifier.weight(1f),
                        )
                        Button(
                            onClick = {
                                if (newTaskNotes.isNotBlank()) {
                                    onAddTask("FOLLOW_UP", reviewer, "2026-12-01", newTaskNotes.trim())
                                    newTaskNotes = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Add Task") }
                    }
                }
            }
        }

        // Optional Non-Diagnostic AI Assist (Disabled by Default)
        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Optional Text & Metadata Assist (${if (aiAssistEnabled) "ENABLED" else "DISABLED BY DEFAULT"})",
                        style = MaterialTheme.typography.titleSmall,
                        color = ClinicalSlate,
                    )
                    Text(
                        "Strictly non-diagnostic: organises series metadata and summarises existing authorised report text with source citations. Enable in Settings if needed.",
                        style = MaterialTheme.typography.labelSmall,
                    )
                    OutlinedButton(
                        onClick = onGenerateAiSummary,
                        enabled = aiAssistEnabled,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) { Text("Draft Source-Referenced Metadata & Report Summary") }
                    if (!aiSummaryOutput.isNullOrBlank()) {
                        Text(aiSummaryOutput, style = MaterialTheme.typography.labelMedium, color = ClinicalWhite)
                    }
                }
            }
        }
    }
}
