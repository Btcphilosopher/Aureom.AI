package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedStudyEntity
import com.example.dicom.DicomSlice
import com.example.gl.GlSliceFrame
import com.example.gl.MriSliceGlView
import com.example.ui.ComparisonState
import com.example.ui.ViewerState
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusWarning

@Composable
fun ComparisonsScreen(
    isWideScreen: Boolean,
    currentStudy: CachedStudyEntity?,
    allStudies: List<CachedStudyEntity>,
    currentSlices: List<DicomSlice>,
    viewerState: ViewerState,
    comparisonState: ComparisonState,
    onSelectPriorStudy: (String) -> Unit,
    onStepCurrent: (Int) -> Unit,
    onStepPrior: (Int) -> Unit,
    onManualAlign: (Int, Float, Float) -> Unit,
    onToggleSpatialLink: (Boolean) -> Unit,
) {
    val candidatePriors = remember(allStudies, currentStudy) {
        allStudies.filter { it.studyInstanceUid != currentStudy?.studyInstanceUid }
    }

    val curIdx = comparisonState.currentSliceIdx.coerceIn(0, (currentSlices.size - 1).coerceAtLeast(0))
    val curSlice = currentSlices.getOrNull(curIdx)

    val priorIdx = (comparisonState.priorSliceIdx + comparisonState.manualSliceOffset)
        .coerceIn(0, (comparisonState.priorSlices.size - 1).coerceAtLeast(0))
    val priorSlice = comparisonState.priorSlices.getOrNull(priorIdx)

    val curFrame = remember(curSlice?.sopInstanceUid) {
        curSlice?.let {
            GlSliceFrame("cmp-cur-${it.sopInstanceUid}", it.columns, it.rows, it.rawPixels, null, it.photometricInterpretation)
        }
    }
    val priorFrame = remember(priorSlice?.sopInstanceUid) {
        priorSlice?.let {
            GlSliceFrame("cmp-pri-${it.sopInstanceUid}", it.columns, it.rows, it.rawPixels, null, it.photometricInterpretation)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Side-by-Side Examination Comparison", style = MaterialTheme.typography.headlineMedium)
                Text(
                    comparisonState.spatialLinkStatus,
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusWarning,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Link by LPS Position", style = MaterialTheme.typography.labelSmall)
                Switch(
                    checked = comparisonState.linkBySpatialPosition,
                    onCheckedChange = onToggleSpatialLink,
                    enabled = comparisonState.priorSlices.isNotEmpty(),
                )
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(candidatePriors, key = { it.studyInstanceUid }) { prior ->
                FilterChip(
                    selected = prior.studyInstanceUid == comparisonState.priorStudyUid,
                    onClick = { onSelectPriorStudy(prior.studyInstanceUid) },
                    label = { Text("${prior.patientId} • ${prior.studyDescription} (${prior.studyDate})") },
                )
            }
        }

        // Manual Alignment Controls
        Surface(
            color = GraphiteSurface,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)),
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Manual Alignment:", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                OutlinedButton(onClick = { onManualAlign(-1, 0f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Slice -1") }
                OutlinedButton(onClick = { onManualAlign(1, 0f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Slice +1") }
                OutlinedButton(onClick = { onManualAlign(0, -4f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Pan L") }
                OutlinedButton(onClick = { onManualAlign(0, 4f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Pan R") }
                Text(
                    "Offset: ${comparisonState.manualSliceOffset} sl, dX=${comparisonState.manualPanXMm.toInt()} mm",
                    style = MaterialTheme.typography.labelSmall,
                    color = ClinicalSlate,
                )
            }
        }

        val panesModifier = Modifier.weight(1f).fillMaxWidth()
        if (isWideScreen) {
            Row(modifier = panesModifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ComparisonPane(
                    title = "CURRENT: ${currentStudy?.studyDate ?: "-"}",
                    slice = curSlice,
                    frame = curFrame,
                    sliceIndex = curIdx,
                    sliceTotal = currentSlices.size,
                    viewerState = viewerState,
                    panOffsetX = 0f,
                    onPrev = { onStepCurrent(-1) },
                    onNext = { onStepCurrent(1) },
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
                ComparisonPane(
                    title = "PRIOR: ${priorSlice?.studyDate ?: "None Selected"}",
                    slice = priorSlice,
                    frame = priorFrame,
                    sliceIndex = priorIdx,
                    sliceTotal = comparisonState.priorSlices.size,
                    viewerState = viewerState,
                    panOffsetX = comparisonState.manualPanXMm / 100f,
                    onPrev = { onStepPrior(-1) },
                    onNext = { onStepPrior(1) },
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
            }
        } else {
            Column(modifier = panesModifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ComparisonPane(
                    title = "CURRENT: ${currentStudy?.studyDate ?: "-"}",
                    slice = curSlice,
                    frame = curFrame,
                    sliceIndex = curIdx,
                    sliceTotal = currentSlices.size,
                    viewerState = viewerState,
                    panOffsetX = 0f,
                    onPrev = { onStepCurrent(-1) },
                    onNext = { onStepCurrent(1) },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )
                ComparisonPane(
                    title = "PRIOR: ${priorSlice?.studyDate ?: "None Selected"}",
                    slice = priorSlice,
                    frame = priorFrame,
                    sliceIndex = priorIdx,
                    sliceTotal = comparisonState.priorSlices.size,
                    viewerState = viewerState,
                    panOffsetX = comparisonState.manualPanXMm / 100f,
                    onPrev = { onStepPrior(-1) },
                    onNext = { onStepPrior(1) },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun ComparisonPane(
    title: String,
    slice: DicomSlice?,
    frame: GlSliceFrame?,
    sliceIndex: Int,
    sliceTotal: Int,
    viewerState: ViewerState,
    panOffsetX: Float,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier,
) {
    Surface(
        color = GraphiteVoid,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (frame != null) {
                    MriSliceGlView(
                        frame = frame,
                        windowCenter = viewerState.windowCenter,
                        windowWidth = viewerState.windowWidth,
                        invert = viewerState.invertGrayscale,
                        zoom = viewerState.zoom,
                        panXNorm = panOffsetX,
                        panYNorm = 0f,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Select a prior examination above to compare.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Column(modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                    Text(title, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                    if (slice != null) {
                        Text(
                            "Slice ${sliceIndex + 1}/$sliceTotal • Z/Proj=${slice.sliceNormalProjection?.let { "%.1f".format(it) } ?: "-"} mm",
                            style = MaterialTheme.typography.labelSmall,
                            color = ClinicalWhite,
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    onClick = onPrev,
                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurface, contentColor = ClinicalWhite),
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) { Text("Prev") }
                Text(slice?.seriesDescription ?: "-", style = MaterialTheme.typography.labelSmall)
                Button(
                    onClick = onNext,
                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurface, contentColor = ClinicalWhite),
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) { Text("Next") }
            }
        }
    }
}
