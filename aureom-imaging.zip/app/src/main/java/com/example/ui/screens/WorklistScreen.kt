package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedStudyEntity
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning

@Composable
fun WorklistScreen(
    studies: List<CachedStudyEntity>,
    selectedStudyUid: String?,
    query: String,
    onQueryChange: (String) -> Unit,
    onSelectStudy: (String) -> Unit,
    onOpenStudies: (String) -> Unit,
    onOpenViewer: (String) -> Unit,
    onImportLocalDicom: () -> Unit,
) {
    var statusFilter by remember { mutableStateOf<String?>(null) }

    val filtered = remember(studies, query, statusFilter) {
        val q = query.trim().lowercase()
        studies.filter { st ->
            val matchesQ = q.isEmpty() ||
                st.patientName.lowercase().contains(q) ||
                st.patientId.lowercase().contains(q) ||
                st.studyDescription.lowercase().contains(q) ||
                st.accessionNumber.lowercase().contains(q)
            val matchesStatus = statusFilter == null || st.clinicalReviewStatus == statusFilter
            matchesQ && matchesStatus
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Imaging Worklist", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Searchable examinations with separated patient, issuing authority, accession, and review statuses.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Button(
                onClick = onImportLocalDicom,
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("import_dicom_button"),
            ) {
                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Import DICOM", fontWeight = FontWeight.SemiBold)
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search worklist") },
            placeholder = { Text("Search patient name, ID, accession, or study description...") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("worklist_search_input"),
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            val filters = listOf(null to "All (${studies.size})", "UNREAD" to "Unread", "DRAFT_REPORT" to "Draft", "FINAL_SIGNED" to "Signed")
            filters.forEach { (key, label) ->
                FilterChip(
                    selected = statusFilter == key,
                    onClick = { statusFilter = key },
                    label = { Text(label) },
                )
            }
        }

        if (filtered.isEmpty()) {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("No matching MRI studies", style = MaterialTheme.typography.titleMedium)
                    Text("Adjust your search filter or import single-frame MR DICOM objects via the Document Picker.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(filtered, key = { it.studyInstanceUid }) { study ->
                    val isSelected = study.studyInstanceUid == selectedStudyUid
                    Surface(
                        color = if (isSelected) GraphiteSurfaceElevated else GraphiteSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) CyanAccent else GraphiteBorder,
                                shape = RoundedCornerShape(10.dp),
                            )
                            .clickable { onSelectStudy(study.studyInstanceUid) }
                            .testTag("worklist_study_card_${study.studyId}"),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(study.patientName, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "ID: ${study.patientId} • Issuer: ${study.issuingAuthority} • DOB: ${study.patientBirthDate} • Sex: ${study.patientSex}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyanAccent,
                                    )
                                }
                                StatusBadge(
                                    text = study.clinicalReviewStatus,
                                    highlight = study.clinicalReviewStatus == "FINAL_SIGNED",
                                )
                            }

                            Text(study.studyDescription, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                            ) {
                                Text("Date/Time: ${study.studyDate} ${study.studyTime}", style = MaterialTheme.typography.labelSmall)
                                Text("Acc: ${study.accessionNumber.ifBlank { "None" }}", style = MaterialTheme.typography.labelSmall)
                                Text("Series: ${study.seriesCount}", style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                                Text("Transfer: ${study.transferStatus}", style = MaterialTheme.typography.labelSmall)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val geomWarn = study.technicalReviewStatus == "GEOMETRY_WARNING"
                                    Icon(
                                        imageVector = if (geomWarn) Icons.Default.WarningAmber else Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = if (geomWarn) StatusWarning else StatusValid,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text = "QA: ${study.technicalReviewStatus} • Source: ${study.sourceSystem}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (geomWarn) StatusWarning else ClinicalSlate,
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onOpenStudies(study.studyInstanceUid) },
                                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceElevated, contentColor = ClinicalWhite),
                                        modifier = Modifier.minimumInteractiveComponentSize(),
                                    ) {
                                        Text("Inspect Series")
                                    }
                                    Button(
                                        onClick = { onOpenViewer(study.studyInstanceUid) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                                        modifier = Modifier.minimumInteractiveComponentSize(),
                                    ) {
                                        Text("Open Viewer", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(text: String, highlight: Boolean) {
    val color = if (highlight) StatusValid else CyanAccent
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}
