package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.AnnotationEntity
import com.example.data.local.CachedSeriesEntity
import com.example.dicom.DicomGeometry
import com.example.dicom.DicomSlice
import com.example.dicom.InterpolationMode
import com.example.dicom.MprPlane
import com.example.dicom.MprSliceResult
import com.example.dicom.PixelDisplayTransform
import com.example.gl.GlSliceFrame
import com.example.gl.MriSliceGlView
import com.example.gl.VolumeQuality
import com.example.gl.VolumeRenderGlView
import com.example.gl.VolumeTransferPreset
import com.example.ui.AureomViewModel
import com.example.ui.ViewerState
import com.example.ui.ViewerTool
import com.example.ui.ViewportLayoutMode
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning
import org.json.JSONObject
import kotlin.math.abs

@Composable
fun ViewerScreen(
    isWideScreen: Boolean,
    seriesList: List<CachedSeriesEntity>,
    selectedSeries: CachedSeriesEntity?,
    slices: List<DicomSlice>,
    viewerState: ViewerState,
    annotations: List<AnnotationEntity>,
    viewModel: AureomViewModel,
) {
    val (glFrame, mprResult) = remember(
        slices,
        viewerState.activePlane,
        viewerState.sliceIndex,
        viewerState.normalizedMprPos,
        viewerState.interpolation,
    ) {
        viewModel.computeCurrentFrame()
    }

    var pendingNoteCoord by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var noteDraft by remember { mutableStateOf("") }

    if (pendingNoteCoord != null) {
        AlertDialog(
            onDismissRequest = { pendingNoteCoord = null },
            title = { Text("Add Examination Annotation Note") },
            text = {
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = { noteDraft = it },
                    label = { Text("Annotation text") },
                    singleLine = false,
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val coord = pendingNoteCoord ?: return@Button
                        if (noteDraft.isNotBlank()) {
                            viewModel.recordContourOrTextAnnotation("TEXT_NOTE", listOf(coord), noteDraft.trim(), mprResult)
                        }
                        noteDraft = ""
                        pendingNoteCoord = null
                    },
                ) { Text("Save Note") }
            },
            dismissButton = {
                TextButton(onClick = { pendingNoteCoord = null }) { Text("Cancel") }
            },
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(GraphiteBase)) {
        // Top Viewer Control Bar
        ViewerToolbar(
            selectedSeries = selectedSeries,
            viewerState = viewerState,
            onToggleLayout = {
                val next = if (viewerState.layoutMode == ViewportLayoutMode.SINGLE) ViewportLayoutMode.FOUR_UP else ViewportLayoutMode.SINGLE
                viewModel.setLayoutMode(next)
            },
            onSelectPlane = { viewModel.setMprPlane(it) },
            onToggleInterp = {
                val next = if (viewerState.interpolation == InterpolationMode.TRILINEAR) InterpolationMode.NEAREST else InterpolationMode.TRILINEAR
                viewModel.setInterpolation(next)
            },
            onToggleInvert = { viewModel.toggleInvert() },
            onToggleCrosshair = { viewModel.toggleCrosshair() },
            onFit = { viewModel.fitToScreen() },
            onReset = { viewModel.resetDisplaySettings() },
            onToggleTools = { viewModel.toggleToolsDrawer() },
        )

        if (isWideScreen) {
            // Tablet Landscape 3-Pane Workspace
            Row(modifier = Modifier.fillMaxSize()) {
                SeriesThumbnailRail(
                    seriesList = seriesList,
                    selectedSeriesUid = selectedSeries?.seriesInstanceUid,
                    slicesForSelected = slices,
                    onSelectSeries = { viewModel.selectSeries(it) },
                    modifier = Modifier
                        .width(172.dp)
                        .fillMaxHeight(),
                )

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    ViewportBody(
                        selectedSeries = selectedSeries,
                        slices = slices,
                        viewerState = viewerState,
                        glFrame = glFrame,
                        mprResult = mprResult,
                        annotations = annotations,
                        viewModel = viewModel,
                        onRequestTextNote = { x, y -> pendingNoteCoord = x to y },
                    )
                }

                if (viewerState.showToolsDrawer) {
                    ToolsAnd3DPanel(
                        viewerState = viewerState,
                        slices = slices,
                        viewModel = viewModel,
                        modifier = Modifier
                            .width(290.dp)
                            .fillMaxHeight(),
                    )
                }
            }
        } else {
            // Adapted Phone Vertical Layout
            Column(modifier = Modifier.fillMaxSize()) {
                SeriesHorizontalStrip(
                    seriesList = seriesList,
                    selectedSeriesUid = selectedSeries?.seriesInstanceUid,
                    onSelectSeries = { viewModel.selectSeries(it) },
                )
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    ViewportBody(
                        selectedSeries = selectedSeries,
                        slices = slices,
                        viewerState = viewerState,
                        glFrame = glFrame,
                        mprResult = mprResult,
                        annotations = annotations,
                        viewModel = viewModel,
                        onRequestTextNote = { x, y -> pendingNoteCoord = x to y },
                    )
                }
                if (viewerState.showToolsDrawer) {
                    ToolsAnd3DPanel(
                        viewerState = viewerState,
                        slices = slices,
                        viewModel = viewModel,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ViewerToolbar(
    selectedSeries: CachedSeriesEntity?,
    viewerState: ViewerState,
    onToggleLayout: () -> Unit,
    onSelectPlane: (MprPlane) -> Unit,
    onToggleInterp: () -> Unit,
    onToggleInvert: () -> Unit,
    onToggleCrosshair: () -> Unit,
    onFit: () -> Unit,
    onReset: () -> Unit,
    onToggleTools: () -> Unit,
) {
    Surface(
        color = GraphiteSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GraphiteBorder),
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            item {
                FilterChip(
                    selected = viewerState.layoutMode == ViewportLayoutMode.FOUR_UP,
                    onClick = onToggleLayout,
                    leadingIcon = { Icon(Icons.Default.GridView, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(if (viewerState.layoutMode == ViewportLayoutMode.FOUR_UP) "4-Panel Active" else "4-Panel MPR+3D") },
                    modifier = Modifier.testTag("toggle_4panel_button"),
                )
            }
            if (viewerState.layoutMode == ViewportLayoutMode.SINGLE) {
                items(MprPlane.entries) { plane ->
                    val enabled = plane == MprPlane.ACQUISITION || selectedSeries?.isVolumetricCompatible == true
                    FilterChip(
                        selected = viewerState.activePlane == plane,
                        onClick = { onSelectPlane(plane) },
                        enabled = enabled,
                        label = { Text(plane.label) },
                    )
                }
            }
            item {
                FilterChip(
                    selected = viewerState.interpolation == InterpolationMode.TRILINEAR,
                    onClick = onToggleInterp,
                    label = { Text("Interp: ${viewerState.interpolation.label}") },
                )
            }
            item {
                FilterChip(
                    selected = viewerState.invertGrayscale,
                    onClick = onToggleInvert,
                    leadingIcon = { Icon(Icons.Default.Contrast, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Invert") },
                    modifier = Modifier.testTag("invert_grayscale_button"),
                )
            }
            item {
                FilterChip(
                    selected = viewerState.showCrosshair,
                    onClick = onToggleCrosshair,
                    leadingIcon = { Icon(Icons.Default.CenterFocusStrong, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Crosshair") },
                )
            }
            item {
                OutlinedButton(onClick = onFit, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Text("Fit")
                }
            }
            item {
                OutlinedButton(onClick = onReset, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reset")
                }
            }
            item {
                FilterChip(
                    selected = viewerState.showToolsDrawer,
                    onClick = onToggleTools,
                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Tools") },
                    modifier = Modifier.testTag("toggle_tools_drawer"),
                )
            }
        }
    }
}

@Composable
private fun SeriesThumbnailRail(
    seriesList: List<CachedSeriesEntity>,
    selectedSeriesUid: String?,
    slicesForSelected: List<DicomSlice>,
    onSelectSeries: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = GraphiteSurface,
        modifier = modifier.border(1.dp, GraphiteBorder),
    ) {
        LazyColumn(
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text("SERIES (${seriesList.size})", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
            }
            items(seriesList, key = { it.seriesInstanceUid }) { s ->
                val isSel = s.seriesInstanceUid == selectedSeriesUid
                val previewSlice = if (isSel && slicesForSelected.isNotEmpty()) slicesForSelected[slicesForSelected.size / 2] else null
                Surface(
                    color = if (isSel) GraphiteSurfaceElevated else GraphiteBase,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(if (isSel) 1.5.dp else 1.dp, if (isSel) CyanAccent else GraphiteBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectSeries(s.seriesInstanceUid) },
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (previewSlice != null) {
                            SliceBitmapPreview(
                                slice = previewSlice,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(76.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .background(GraphiteVoid, RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("#${s.seriesNumber} • ${s.sliceCount} sl", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                            }
                        }
                        Text(
                            text = s.sourceDescription,
                            style = MaterialTheme.typography.labelSmall,
                            color = ClinicalWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "${s.inferredSequenceLabel ?: "Unclassified"} • ${s.sliceCount} sl",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (s.isVolumetricCompatible) StatusValid else StatusWarning,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SeriesHorizontalStrip(
    seriesList: List<CachedSeriesEntity>,
    selectedSeriesUid: String?,
    onSelectSeries: (String) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(GraphiteSurface),
    ) {
        items(seriesList, key = { it.seriesInstanceUid }) { s ->
            FilterChip(
                selected = s.seriesInstanceUid == selectedSeriesUid,
                onClick = { onSelectSeries(s.seriesInstanceUid) },
                label = { Text("#${s.seriesNumber} ${s.inferredSequenceLabel ?: s.sourceDescription} (${s.sliceCount})") },
            )
        }
    }
}

@Composable
private fun SliceBitmapPreview(slice: DicomSlice, modifier: Modifier = Modifier) {
    val bmp = remember(slice.sopInstanceUid) {
        val w = slice.columns
        val h = slice.rows
        val pixels = IntArray(w * h)
        for (i in pixels.indices) {
            val g = PixelDisplayTransform.mapIntensityToGray8(
                slice.rawPixels[i],
                slice.defaultWindowCenter,
                slice.defaultWindowWidth,
                slice.photometricInterpretation,
                false,
            )
            pixels[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }
    Image(
        bitmap = bmp.asImageBitmap(),
        contentDescription = "Series thumbnail ${slice.seriesDescription}",
        contentScale = ContentScale.Fit,
        modifier = modifier.background(GraphiteVoid),
    )
}

@Composable
private fun ViewportBody(
    selectedSeries: CachedSeriesEntity?,
    slices: List<DicomSlice>,
    viewerState: ViewerState,
    glFrame: GlSliceFrame?,
    mprResult: MprSliceResult?,
    annotations: List<AnnotationEntity>,
    viewModel: AureomViewModel,
    onRequestTextNote: (Float, Float) -> Unit,
) {
    if (slices.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No MR slices loaded for selected series.", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    if (viewerState.layoutMode == ViewportLayoutMode.FOUR_UP && selectedSeries?.isVolumetricCompatible == true) {
        FourPanelViewport(
            slices = slices,
            viewerState = viewerState,
            viewModel = viewModel,
        )
        return
    }

    val currentSlice = slices[viewerState.sliceIndex.coerceIn(0, slices.size - 1)]
    val orientation = remember(currentSlice.sopInstanceUid, mprResult) {
        DicomGeometry.computeOrientationMarkers(
            mprResult?.rowDir ?: currentSlice.rowDirection,
            mprResult?.colDir ?: currentSlice.colDirection,
        )
    }

    // Pending interactive measurement state
    var dragStart by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var dragEnd by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    val anglePoints = remember { mutableStateListOf<Pair<Float, Float>>() }
    val contourPoints = remember { mutableStateListOf<Pair<Float, Float>>() }

    Column(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(GraphiteVoid)
                .pointerInput(viewerState.activeTool, mprResult) {
                    detectTapGestures { offset ->
                        val nx = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        val ny = (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                        when (viewerState.activeTool) {
                            ViewerTool.CROSSHAIR -> viewModel.moveCrosshair(nx, ny)
                            ViewerTool.TEXT_NOTE -> onRequestTextNote(nx, ny)
                            ViewerTool.ANGLE -> {
                                anglePoints.add(nx to ny)
                                if (anglePoints.size == 3) {
                                    viewModel.recordAngleAnnotation(
                                        anglePoints[0].first, anglePoints[0].second,
                                        anglePoints[1].first, anglePoints[1].second,
                                        anglePoints[2].first, anglePoints[2].second,
                                        mprResult,
                                    )
                                    anglePoints.clear()
                                }
                            }
                            else -> {}
                        }
                    }
                }
                .pointerInput(viewerState.activeTool, mprResult, viewerState.sliceIndex) {
                    detectDragGestures(
                        onDragStart = { start ->
                            val nx = (start.x / size.width.toFloat()).coerceIn(0f, 1f)
                            val ny = (start.y / size.height.toFloat()).coerceIn(0f, 1f)
                            dragStart = nx to ny
                            dragEnd = nx to ny
                            if (viewerState.activeTool == ViewerTool.CONTOUR) {
                                contourPoints.clear()
                                contourPoints.add(nx to ny)
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val nx = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                            val ny = (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                            dragEnd = nx to ny
                            when (viewerState.activeTool) {
                                ViewerTool.SCROLL -> {
                                    if (abs(dragAmount.y) > abs(dragAmount.x) * 1.4f) {
                                        if (dragAmount.y > 6f) viewModel.stepSlice(1) else if (dragAmount.y < -6f) viewModel.stepSlice(-1)
                                    } else {
                                        viewModel.adjustWindowLevel(dragAmount.y * 2.0, dragAmount.x * 4.0)
                                    }
                                }
                                ViewerTool.PAN_ZOOM -> {
                                    viewModel.adjustZoomPan(1f, dragAmount.x / size.width * 2f, -dragAmount.y / size.height * 2f)
                                }
                                ViewerTool.CROSSHAIR -> viewModel.moveCrosshair(nx, ny)
                                ViewerTool.CONTOUR -> contourPoints.add(nx to ny)
                                else -> {}
                            }
                        },
                        onDragEnd = {
                            val s = dragStart
                            val e = dragEnd
                            if (s != null && e != null) {
                                when (viewerState.activeTool) {
                                    ViewerTool.LENGTH -> viewModel.recordTwoPointAnnotation("LENGTH", s.first, s.second, e.first, e.second, mprResult)
                                    ViewerTool.ARROW -> viewModel.recordTwoPointAnnotation("ARROW", s.first, s.second, e.first, e.second, mprResult)
                                    ViewerTool.ROI -> {
                                        val cx = (s.first + e.first) / 2f
                                        val cy = (s.second + e.second) / 2f
                                        val rx = (abs(e.first - s.first) / 2f).coerceAtLeast(0.03f)
                                        val ry = (abs(e.second - s.second) / 2f).coerceAtLeast(0.03f)
                                        viewModel.recordRoiAnnotation(cx, cy, rx, ry, mprResult)
                                    }
                                    ViewerTool.CONTOUR -> {
                                        if (contourPoints.size >= 4) {
                                            viewModel.recordContourOrTextAnnotation("CONTOUR", contourPoints.toList(), null, mprResult)
                                        }
                                        contourPoints.clear()
                                    }
                                    else -> {}
                                }
                            }
                            dragStart = null
                            dragEnd = null
                        },
                    )
                },
        ) {
            // OpenGL ES 3.0 GPU Slice Surface
            MriSliceGlView(
                frame = glFrame,
                windowCenter = viewerState.windowCenter,
                windowWidth = viewerState.windowWidth,
                invert = viewerState.invertGrayscale,
                zoom = viewerState.zoom,
                panXNorm = viewerState.panXNorm,
                panYNorm = viewerState.panYNorm,
                modifier = Modifier.fillMaxSize(),
            )

            // Crosshair & Saved Annotations Canvas Overlay
            val seriesAnnotations = annotations.filter {
                it.seriesInstanceUid == selectedSeries?.seriesInstanceUid &&
                    (it.sopInstanceUid == null || it.sopInstanceUid == currentSlice.sopInstanceUid || mprResult != null)
            }
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (viewerState.showCrosshair) {
                    val cx = viewerState.crosshairNormX * size.width
                    val cy = viewerState.crosshairNormY * size.height
                    drawLine(CyanAccent.copy(alpha = 0.55f), Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 1.5f)
                    drawLine(CyanAccent.copy(alpha = 0.55f), Offset(0f, cy), Offset(size.width, cy), strokeWidth = 1.5f)
                }

                // Render active drag preview
                val ds = dragStart
                val de = dragEnd
                if (ds != null && de != null) {
                    val p1 = Offset(ds.first * size.width, ds.second * size.height)
                    val p2 = Offset(de.first * size.width, de.second * size.height)
                    when (viewerState.activeTool) {
                        ViewerTool.LENGTH, ViewerTool.ARROW -> drawLine(CyanAccent, p1, p2, strokeWidth = 3f)
                        ViewerTool.ROI -> {
                            val left = kotlin.math.min(p1.x, p2.x)
                            val top = kotlin.math.min(p1.y, p2.y)
                            drawOval(
                                color = StatusValid,
                                topLeft = Offset(left, top),
                                size = Size(abs(p2.x - p1.x).coerceAtLeast(16f), abs(p2.y - p1.y).coerceAtLeast(16f)),
                                style = Stroke(width = 2.5f),
                            )
                        }
                        ViewerTool.CONTOUR -> {
                            if (contourPoints.size > 1) {
                                val path = Path().apply {
                                    moveTo(contourPoints.first().first * size.width, contourPoints.first().second * size.height)
                                    contourPoints.drop(1).forEach { lineTo(it.first * size.width, it.second * size.height) }
                                }
                                drawPath(path, StatusWarning, style = Stroke(width = 3f))
                            }
                        }
                        else -> {}
                    }
                }

                // Render saved study-isolated annotations
                seriesAnnotations.forEach { ann ->
                    runCatching {
                        val obj = JSONObject(ann.geometryJson)
                        when (ann.measurementType) {
                            "LENGTH", "ARROW", "ANGLE", "CONTOUR" -> {
                                val pts = obj.getJSONArray("points")
                                if (pts.length() >= 2) {
                                    val path = Path()
                                    val p0 = pts.getJSONArray(0)
                                    path.moveTo(p0.getDouble(0).toFloat() * size.width, p0.getDouble(1).toFloat() * size.height)
                                    for (i in 1 until pts.length()) {
                                        val pi = pts.getJSONArray(i)
                                        path.lineTo(pi.getDouble(0).toFloat() * size.width, pi.getDouble(1).toFloat() * size.height)
                                    }
                                    drawPath(path, CyanAccent, style = Stroke(width = 2.5f))
                                }
                            }
                            "ROI_ELLIPSE" -> {
                                val c = obj.getJSONArray("center")
                                val r = obj.getJSONArray("radii")
                                val cx = c.getDouble(0).toFloat() * size.width
                                val cy = c.getDouble(1).toFloat() * size.height
                                val rx = r.getDouble(0).toFloat() * size.width
                                val ry = r.getDouble(1).toFloat() * size.height
                                drawOval(
                                    color = StatusValid,
                                    topLeft = Offset(cx - rx, cy - ry),
                                    size = Size(rx * 2f, ry * 2f),
                                    style = Stroke(width = 2.5f),
                                )
                            }
                            "TEXT_NOTE" -> {
                                val pts = obj.getJSONArray("points")
                                val p0 = pts.getJSONArray(0)
                                drawCircle(
                                    color = StatusWarning,
                                    radius = 7f,
                                    center = Offset(p0.getDouble(0).toFloat() * size.width, p0.getDouble(1).toFloat() * size.height),
                                )
                            }
                        }
                    }
                }
            }

            // Anatomical Orientation Markers (A/P/L/R/H/F) at viewport edges
            Text(orientation.top, style = MaterialTheme.typography.labelMedium, color = CyanAccent, modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp))
            Text(orientation.bottom, style = MaterialTheme.typography.labelMedium, color = CyanAccent, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
            Text(orientation.left, style = MaterialTheme.typography.labelMedium, color = CyanAccent, modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp))
            Text(orientation.right, style = MaterialTheme.typography.labelMedium, color = CyanAccent, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp))

            // Non-obscuring Corner Telemetry Overlays
            Column(modifier = Modifier.align(Alignment.TopStart).padding(10.dp)) {
                Text("${currentSlice.seriesDescription}", style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                Text("${selectedSeries?.inferredSequenceLabel ?: "MR"} • ${mprResult?.plane?.label ?: "Native"}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                if (mprResult?.isReconstructed == true) {
                    Text("RECONSTRUCTED (${mprResult.interpolation.label})", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                }
            }

            val dispIdx = (mprResult?.sliceIndex ?: viewerState.sliceIndex) + 1
            val dispTot = mprResult?.sliceCount ?: slices.size
            val lps = DicomGeometry.pixelToPatientLps(
                mprResult?.originLps ?: currentSlice.imagePositionPatient,
                mprResult?.rowDir ?: currentSlice.rowDirection,
                mprResult?.colDir ?: currentSlice.colDirection,
                mprResult?.colSpacingMm ?: currentSlice.pixelSpacingCol,
                mprResult?.rowSpacingMm ?: currentSlice.pixelSpacingRow,
                mprResult?.width ?: currentSlice.columns,
                mprResult?.height ?: currentSlice.rows,
                viewerState.crosshairNormX,
                viewerState.crosshairNormY,
            )
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                Text("Slice $dispIdx / $dispTot", style = MaterialTheme.typography.labelMedium, color = ClinicalWhite)
                if (lps != null) {
                    Text("LPS: ${"%.1f".format(lps.x)}, ${"%.1f".format(lps.y)}, ${"%.1f".format(lps.z)} mm", style = MaterialTheme.typography.labelSmall, color = ClinicalSlate)
                }
            }

            Column(modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                Text("W/L: ${viewerState.windowWidth.toInt()} / ${viewerState.windowCenter.toInt()} • Zoom: ${"%.2f".format(viewerState.zoom)}x", style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                Text(selectedSeries?.quantityLabel ?: "Arbitrary MR Signal Intensity", style = MaterialTheme.typography.labelSmall, color = ClinicalSlate)
            }

            Column(horizontalAlignment = Alignment.End, modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)) {
                Text("TR ${currentSlice.repetitionTime ?: "-"} / TE ${currentSlice.echoTime ?: "-"} ms", style = MaterialTheme.typography.labelSmall, color = ClinicalSlate)
                Text("Thick ${currentSlice.sliceThickness ?: "-"} mm • ${currentSlice.photometricInterpretation}", style = MaterialTheme.typography.labelSmall, color = ClinicalSlate)
            }
        }

        // Bottom Slice Scrubber Bar
        Surface(
            color = GraphiteSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GraphiteBorder),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = { viewModel.stepSlice(-1) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("prev_slice_button"),
                ) { Text("-") }
                if (viewerState.activePlane == MprPlane.ACQUISITION) {
                    Slider(
                        value = viewerState.sliceIndex.toFloat(),
                        onValueChange = { viewModel.setSliceIndex(it.toInt()) },
                        valueRange = 0f..(slices.size - 1).coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent),
                        modifier = Modifier.weight(1f).testTag("slice_scrubber"),
                    )
                } else {
                    Slider(
                        value = viewerState.normalizedMprPos,
                        onValueChange = { viewModel.setMprPosition(it) },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent),
                        modifier = Modifier.weight(1f),
                    )
                }
                OutlinedButton(
                    onClick = { viewModel.stepSlice(1) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("next_slice_button"),
                ) { Text("+") }
            }
        }
    }
}

@Composable
private fun FourPanelViewport(
    slices: List<DicomSlice>,
    viewerState: ViewerState,
    viewModel: AureomViewModel,
) {
    val ax = remember(slices, viewerState.axialPos, viewerState.interpolation) {
        DicomGeometry.resampleMprPlane(slices, MprPlane.AXIAL, viewerState.axialPos, viewerState.interpolation)
    }
    val sag = remember(slices, viewerState.sagittalPos, viewerState.interpolation) {
        DicomGeometry.resampleMprPlane(slices, MprPlane.SAGITTAL, viewerState.sagittalPos, viewerState.interpolation)
    }
    val cor = remember(slices, viewerState.coronalPos, viewerState.interpolation) {
        DicomGeometry.resampleMprPlane(slices, MprPlane.CORONAL, viewerState.coronalPos, viewerState.interpolation)
    }

    Column(modifier = Modifier.fillMaxSize().background(GraphiteVoid)) {
        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            QuadMprCell("AXIAL (MPR)", ax, viewerState, { viewModel.setQuadPositions(axial = it) }, Modifier.weight(1f).fillMaxHeight())
            QuadMprCell("SAGITTAL (MPR)", sag, viewerState, { viewModel.setQuadPositions(sagittal = it) }, Modifier.weight(1f).fillMaxHeight())
        }
        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            QuadMprCell("CORONAL (MPR)", cor, viewerState, { viewModel.setQuadPositions(coronal = it) }, Modifier.weight(1f).fillMaxHeight())
            // Panel 4: 3D Volume Raycasting View
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .border(1.dp, GraphiteBorder)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            viewModel.updateVolumeConfig { cfg ->
                                cfg.copy(
                                    yawDeg = cfg.yawDeg + dragAmount.x * 0.6f,
                                    pitchDeg = (cfg.pitchDeg + dragAmount.y * 0.5f).coerceIn(-85f, 85f),
                                )
                            }
                        }
                    },
            ) {
                VolumeRenderGlView(
                    seriesUid = slices.firstOrNull()?.seriesInstanceUid,
                    slices = slices,
                    config = viewerState.volumeConfig,
                    modifier = Modifier.fillMaxSize(),
                )
                Column(modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                    Text("3D VOLUME RAYCAST (${viewerState.volumeConfig.preset.label})", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    Text("Visualisation only — not anatomical segmentation", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                }
                // Orientation Indicator Tripod
                Text(
                    "Yaw ${viewerState.volumeConfig.yawDeg.toInt()}° Pitch ${viewerState.volumeConfig.pitchDeg.toInt()}°",
                    style = MaterialTheme.typography.labelSmall,
                    color = ClinicalSlate,
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
                )
            }
        }
    }
}

@Composable
private fun QuadMprCell(
    title: String,
    mpr: MprSliceResult?,
    viewerState: ViewerState,
    onSlicePos: (Float) -> Unit,
    modifier: Modifier,
) {
    val frame = remember(mpr) {
        mpr?.let {
            GlSliceFrame(
                key = "${it.plane.name}|${it.sliceIndex}|${it.interpolation.name}",
                width = it.width,
                height = it.height,
                pixels = it.pixels,
                missingMask = it.missingDataMask,
                photometricInterpretation = "MONOCHROME2",
            )
        }
    }
    Box(modifier = modifier.border(1.dp, GraphiteBorder)) {
        MriSliceGlView(
            frame = frame,
            windowCenter = viewerState.windowCenter,
            windowWidth = viewerState.windowWidth,
            invert = viewerState.invertGrayscale,
            zoom = viewerState.zoom,
            panXNorm = viewerState.panXNorm,
            panYNorm = viewerState.panYNorm,
            modifier = Modifier.fillMaxSize(),
        )
        Text(
            text = "$title • ${(mpr?.sliceIndex ?: 0) + 1}/${mpr?.sliceCount ?: 0}",
            style = MaterialTheme.typography.labelSmall,
            color = CyanAccent,
            modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
        )
        Slider(
            value = (mpr?.sliceIndex?.toFloat() ?: 0f) / ((mpr?.sliceCount ?: 2) - 1).coerceAtLeast(1),
            onValueChange = onSlicePos,
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
        )
    }
}

@Composable
private fun ToolsAnd3DPanel(
    viewerState: ViewerState,
    slices: List<DicomSlice>,
    viewModel: AureomViewModel,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = GraphiteSurface,
        modifier = modifier.border(1.dp, GraphiteBorder),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("MEASUREMENT & DISPLAY TOOLS", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ViewerTool.entries.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        pair.forEach { tool ->
                            val sel = viewerState.activeTool == tool
                            Surface(
                                color = if (sel) CyanAccent else GraphiteSurfaceElevated,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .clickable { viewModel.setActiveTool(tool) }
                                    .testTag("tool_${tool.name.lowercase()}"),
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)) {
                                    Text(
                                        text = tool.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (sel) GraphiteVoid else ClinicalWhite,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (viewerState.latestRoiStats != null) {
                val stats = viewerState.latestRoiStats
                Surface(
                    color = GraphiteSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, StatusValid.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Latest ROI (${stats.areaLabel}, ${stats.pixelCount} px)", style = MaterialTheme.typography.labelSmall, color = StatusValid)
                        Text("Mean: ${"%.1f".format(stats.meanValue)} ± ${"%.1f".format(stats.stdDev)}", style = MaterialTheme.typography.labelMedium)
                        Text("Min/Max: ${"%.1f".format(stats.minValue)} .. ${"%.1f".format(stats.maxValue)}", style = MaterialTheme.typography.labelSmall)
                        Text(stats.quantityLabel, style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                    }
                }
            }

            Text("WINDOW / LEVEL & ZOOM", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
            Text("Center: ${viewerState.windowCenter.toInt()}", style = MaterialTheme.typography.labelSmall)
            Slider(
                value = viewerState.windowCenter.toFloat(),
                onValueChange = { viewModel.setWindowLevel(it.toDouble(), viewerState.windowWidth) },
                valueRange = 50f..2200f,
                colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent),
            )
            Text("Width: ${viewerState.windowWidth.toInt()}", style = MaterialTheme.typography.labelSmall)
            Slider(
                value = viewerState.windowWidth.toFloat(),
                onValueChange = { viewModel.setWindowLevel(viewerState.windowCenter, it.toDouble()) },
                valueRange = 50f..3500f,
                colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.adjustZoomPan(0.85f, 0f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Zoom out", tint = CyanAccent)
                }
                Text("Zoom ${"%.2f".format(viewerState.zoom)}x", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { viewModel.adjustZoomPan(1.2f, 0f, 0f) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Zoom in", tint = CyanAccent)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Link MPR Crosshairs", style = MaterialTheme.typography.labelSmall)
                Switch(checked = viewerState.linkMprCrosshair, onCheckedChange = { viewModel.toggleLinkedMprCrosshair() })
            }

            if (viewerState.layoutMode == ViewportLayoutMode.FOUR_UP) {
                Text("3D VOLUME RENDERING", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    VolumeTransferPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = viewerState.volumeConfig.preset == preset,
                            onClick = { viewModel.updateVolumeConfig { it.copy(preset = preset) } },
                            label = { Text(preset.label) },
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    VolumeQuality.entries.forEach { q ->
                        FilterChip(
                            selected = viewerState.volumeConfig.quality == q,
                            onClick = { viewModel.updateVolumeConfig { it.copy(quality = q) } },
                            label = { Text(q.label) },
                        )
                    }
                }
                Text("Opacity: ${"%.2f".format(viewerState.volumeConfig.opacityScale)}", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = viewerState.volumeConfig.opacityScale,
                    onValueChange = { v -> viewModel.updateVolumeConfig { it.copy(opacityScale = v) } },
                    valueRange = 0.2f..2.5f,
                )
                Text("Threshold: ${"%.2f".format(viewerState.volumeConfig.thresholdNorm)}", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = viewerState.volumeConfig.thresholdNorm,
                    onValueChange = { v -> viewModel.updateVolumeConfig { it.copy(thresholdNorm = v) } },
                    valueRange = 0.02f..0.75f,
                )
                Text("Crop Z-Min / Z-Max", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = viewerState.volumeConfig.cropZMin,
                    onValueChange = { v -> viewModel.updateVolumeConfig { it.copy(cropZMin = v.coerceAtMost(it.cropZMax - 0.1f)) } },
                    valueRange = 0f..0.9f,
                )
                Slider(
                    value = viewerState.volumeConfig.cropZMax,
                    onValueChange = { v -> viewModel.updateVolumeConfig { it.copy(cropZMax = v.coerceAtLeast(it.cropZMin + 0.1f)) } },
                    valueRange = 0.1f..1f,
                )
                OutlinedButton(
                    onClick = { viewModel.resetDisplaySettings() },
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
                ) {
                    Text("Reset 3D View")
                }
            }
        }
    }
}
