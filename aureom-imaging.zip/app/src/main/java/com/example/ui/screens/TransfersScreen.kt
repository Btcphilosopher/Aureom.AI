package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.TransferJobEntity
import com.example.ui.components.formatEpoch
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning

@Composable
fun TransfersScreen(
    transfers: List<TransferJobEntity>,
    onImportLocalDicom: () -> Unit,
    onTestUnsupportedTransferSyntax: () -> Unit,
    onTestMalformedTruncated: () -> Unit,
    onSimulateInterruptedRetrieval: () -> Unit,
    onCancelTransfer: (TransferJobEntity) -> Unit,
    onRetryTransfer: (TransferJobEntity) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
    ) {
        item {
            Text("Ingestion, DICOMweb Transfers & Validation Queue", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Duplicate-safe ingestion with SHA-256 verification, transfer progress, cancellation, retry, and edge-case fixture validation.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        item {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Import & Fixture Verification Actions", style = MaterialTheme.typography.titleSmall, color = CyanAccent)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onImportLocalDicom,
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Pick Local .dcm") }
                        OutlinedButton(
                            onClick = onTestUnsupportedTransferSyntax,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("test_unsupported_ts_button"),
                        ) { Text("Test Unsupported J2K") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onTestMalformedTruncated,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("test_malformed_button"),
                        ) { Text("Test Truncated DICOM") }
                        OutlinedButton(
                            onClick = onSimulateInterruptedRetrieval,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("test_interrupted_button"),
                        ) { Text("Simulate Interrupted Retrieval") }
                    }
                }
            }
        }

        items(transfers, key = { it.id }) { job ->
            val progress = if (job.totalObjects > 0) job.completedObjects.toFloat() / job.totalObjects else 0f
            val statusColor = when (job.status) {
                "COMPLETED" -> StatusValid
                "FAILED" -> StatusError
                "CANCELLED" -> StatusWarning
                else -> CyanAccent
            }
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(job.title, style = MaterialTheme.typography.titleSmall, color = ClinicalWhite)
                        Text(job.status, style = MaterialTheme.typography.labelMedium, color = statusColor)
                    }
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        color = statusColor,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "${job.completedObjects} / ${job.totalObjects} objects • ${job.bytesTransferred / 1024} KB • ${formatEpoch(job.updatedAtEpochMs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ClinicalSlate,
                    )
                    if (!job.errorMessage.isNullOrBlank()) {
                        Text("Error: ${job.errorMessage}", style = MaterialTheme.typography.labelSmall, color = StatusError)
                    }
                    if (!job.remediationHint.isNullOrBlank()) {
                        Text("Remediation: ${job.remediationHint}", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                    }
                    if (job.status in listOf("IN_PROGRESS", "FAILED", "CANCELLED")) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (job.status == "IN_PROGRESS") {
                                OutlinedButton(onClick = { onCancelTransfer(job) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Text("Cancel")
                                }
                            }
                            if (job.status == "FAILED" || job.status == "CANCELLED") {
                                Button(
                                    onClick = { onRetryTransfer(job) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                ) { Text("Retry") }
                            }
                        }
                    }
                }
            }
        }
    }
}
