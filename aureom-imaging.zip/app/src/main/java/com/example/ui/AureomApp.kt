package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.ListAlt
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.PatientExamHeaderBar
import com.example.ui.components.SessionLockOverlay
import com.example.ui.components.StatusAndErrorBanner
import com.example.ui.screens.AnnotationsScreen
import com.example.ui.screens.ComparisonsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudiesScreen
import com.example.ui.screens.TransfersScreen
import com.example.ui.screens.ViewerScreen
import com.example.ui.screens.WorklistScreen
import com.example.ui.theme.AureomTheme
import com.example.ui.theme.AureomUiSettings
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AureomApp(
    viewModel: AureomViewModel = viewModel(),
) {
    val session by viewModel.session.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val studies by viewModel.studies.collectAsStateWithLifecycle()
    val selectedStudy by viewModel.selectedStudy.collectAsStateWithLifecycle()
    val activeSeriesList by viewModel.activeSeriesList.collectAsStateWithLifecycle()
    val selectedSeries by viewModel.selectedSeries.collectAsStateWithLifecycle()
    val activeSlices by viewModel.activeSlices.collectAsStateWithLifecycle()
    val viewerState by viewModel.viewerState.collectAsStateWithLifecycle()
    val comparisonState by viewModel.comparisonState.collectAsStateWithLifecycle()
    val annotations by viewModel.activeAnnotations.collectAsStateWithLifecycle()
    val reports by viewModel.activeReports.collectAsStateWithLifecycle()
    val amendments by viewModel.activeAmendments.collectAsStateWithLifecycle()
    val tasks by viewModel.activeReviewTasks.collectAsStateWithLifecycle()
    val transfers by viewModel.transfers.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()
    val kspaceResult by viewModel.kspaceResult.collectAsStateWithLifecycle()
    val aiSummaryOutput by viewModel.aiSummaryOutput.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: NavSection.WORKLIST.route

    val docPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importLocalDicomUris(uris)
            navController.navigate(NavSection.TRANSFERS.route) { launchSingleTop = true }
        }
    }

    var showMoreNavSheet by remember { mutableStateOf(false) }

    AureomTheme(
        uiSettings = AureomUiSettings(
            textScale = settings.textScale,
            reducedMotion = settings.reducedMotion,
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(GraphiteBase)
                .onPreviewKeyEvent { ev ->
                    if (ev.type != KeyEventType.KeyDown || session.isLocked) return@onPreviewKeyEvent false
                    when (ev.key) {
                        Key.DirectionUp, Key.DirectionLeft -> { viewModel.stepSlice(-1); true }
                        Key.DirectionDown, Key.DirectionRight -> { viewModel.stepSlice(1); true }
                        Key.I -> { viewModel.toggleInvert(); true }
                        Key.F -> { viewModel.fitToScreen(); true }
                        Key.R -> { viewModel.resetDisplaySettings(); true }
                        Key.C -> { viewModel.toggleCrosshair(); true }
                        Key.One -> { viewModel.setLayoutMode(ViewportLayoutMode.SINGLE); true }
                        Key.Four -> { viewModel.setLayoutMode(ViewportLayoutMode.FOUR_UP); true }
                        else -> false
                    }
                },
        ) {
            val isWideScreen = maxWidth >= 680.dp

            val navigateTo: (NavSection) -> Unit = { sec ->
                navController.navigate(sec.route) {
                    popUpTo(NavSection.WORKLIST.route) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            Scaffold(
                containerColor = GraphiteBase,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!isWideScreen) {
                        val primaryTabs = listOf(
                            NavSection.WORKLIST,
                            NavSection.STUDIES,
                            NavSection.VIEWER,
                            NavSection.REPORTS,
                        )
                        NavigationBar(containerColor = GraphiteSurface) {
                            primaryTabs.forEach { sec ->
                                NavigationBarItem(
                                    selected = currentRoute == sec.route,
                                    onClick = { navigateTo(sec) },
                                    icon = { Icon(iconForSection(sec), contentDescription = sec.label) },
                                    label = { Text(sec.label, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_${sec.route}"),
                                )
                            }
                            NavigationBarItem(
                                selected = currentRoute in listOf(
                                    NavSection.COMPARISONS.route,
                                    NavSection.ANNOTATIONS.route,
                                    NavSection.TRANSFERS.route,
                                    NavSection.SETTINGS.route,
                                ),
                                onClick = { showMoreNavSheet = true },
                                icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More workspace sections") },
                                label = { Text("More", maxLines = 1) },
                                modifier = Modifier.testTag("nav_more"),
                            )
                        }
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    if (isWideScreen) {
                        NavigationRail(
                            containerColor = GraphiteSurface,
                            modifier = Modifier
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState()),
                        ) {
                            NavSection.entries.forEach { sec ->
                                NavigationRailItem(
                                    selected = currentRoute == sec.route,
                                    onClick = { navigateTo(sec) },
                                    icon = { Icon(iconForSection(sec), contentDescription = sec.label) },
                                    label = { Text(sec.label) },
                                    modifier = Modifier.testTag("nav_${sec.route}"),
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        PatientExamHeaderBar(
                            study = selectedStudy,
                            serverConnected = session.serverConnected,
                            operatorName = session.operatorName,
                            isCompact = !isWideScreen,
                            onLockSession = { viewModel.setSessionLocked(true) },
                        )

                        StatusAndErrorBanner(
                            statusMessage = session.statusBanner,
                            errorMessage = session.errorBanner,
                            remediationMessage = session.remediationBanner,
                            onDismiss = { viewModel.clearBanners() },
                        )

                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            NavHost(
                                navController = navController,
                                startDestination = NavSection.WORKLIST.route,
                            ) {
                                composable(NavSection.WORKLIST.route) {
                                    WorklistScreen(
                                        studies = studies,
                                        selectedStudyUid = selectedStudy?.studyInstanceUid,
                                        query = session.worklistQuery,
                                        onQueryChange = { viewModel.updateWorklistQuery(it) },
                                        onSelectStudy = { viewModel.selectStudy(it) },
                                        onOpenStudies = { uid ->
                                            viewModel.selectStudy(uid)
                                            navigateTo(NavSection.STUDIES)
                                        },
                                        onOpenViewer = { uid ->
                                            viewModel.selectStudy(uid)
                                            navigateTo(NavSection.VIEWER)
                                        },
                                        onImportLocalDicom = { docPickerLauncher.launch(arrayOf("*/*")) },
                                    )
                                }
                                composable(NavSection.STUDIES.route) {
                                    StudiesScreen(
                                        study = selectedStudy,
                                        seriesList = activeSeriesList,
                                        selectedSeriesUid = selectedSeries?.seriesInstanceUid,
                                        kspaceResult = kspaceResult,
                                        onSelectSeriesAndView = { seriesUid ->
                                            viewModel.selectSeries(seriesUid)
                                            navigateTo(NavSection.VIEWER)
                                        },
                                        onRunResearchKSpace = { viewModel.runResearchKSpaceDemo() },
                                    )
                                }
                                composable(NavSection.VIEWER.route) {
                                    ViewerScreen(
                                        isWideScreen = isWideScreen,
                                        seriesList = activeSeriesList,
                                        selectedSeries = selectedSeries,
                                        slices = activeSlices,
                                        viewerState = viewerState,
                                        annotations = annotations,
                                        viewModel = viewModel,
                                    )
                                }
                                composable(NavSection.COMPARISONS.route) {
                                    ComparisonsScreen(
                                        isWideScreen = isWideScreen,
                                        currentStudy = selectedStudy,
                                        allStudies = studies,
                                        currentSlices = activeSlices,
                                        viewerState = viewerState,
                                        comparisonState = comparisonState,
                                        onSelectPriorStudy = { viewModel.loadComparisonPriorStudy(it) },
                                        onStepCurrent = { viewModel.stepComparisonSlices(it, 0) },
                                        onStepPrior = { viewModel.stepComparisonSlices(0, it) },
                                        onManualAlign = { ds, dx, dy -> viewModel.adjustComparisonManualAlignment(ds, dx, dy) },
                                        onToggleSpatialLink = { viewModel.toggleSpatialComparisonLink(it) },
                                    )
                                }
                                composable(NavSection.ANNOTATIONS.route) {
                                    AnnotationsScreen(
                                        study = selectedStudy,
                                        annotations = annotations,
                                        onDeleteAnnotation = { viewModel.deleteAnnotation(it) },
                                    )
                                }
                                composable(NavSection.REPORTS.route) {
                                    ReportsScreen(
                                        study = selectedStudy,
                                        reports = reports,
                                        amendments = amendments,
                                        tasks = tasks,
                                        aiAssistEnabled = settings.aiAssistOptIn,
                                        aiSummaryOutput = aiSummaryOutput,
                                        onSaveReport = { rep, rev, hist, tech, find, imp, notes, sub ->
                                            viewModel.saveReport(rep, rev, hist, tech, find, imp, notes, sub)
                                        },
                                        onSignReport = { viewModel.signReport(it) },
                                        onAddAmendment = { rep, rsn, txt -> viewModel.addAmendment(rep, rsn, txt) },
                                        onAddTask = { type, ass, due, notes -> viewModel.addReviewTask(type, ass, due, notes) },
                                        onGenerateAiSummary = { viewModel.generateNonDiagnosticReportSummary() },
                                    )
                                }
                                composable(NavSection.TRANSFERS.route) {
                                    TransfersScreen(
                                        transfers = transfers,
                                        onImportLocalDicom = { docPickerLauncher.launch(arrayOf("*/*")) },
                                        onTestUnsupportedTransferSyntax = {
                                            viewModel.runEdgeCaseFixtureTest("fixtures/edge_cases/unsupported_j2k.dcm")
                                        },
                                        onTestMalformedTruncated = {
                                            viewModel.runEdgeCaseFixtureTest("fixtures/edge_cases/malformed_truncated.dcm")
                                        },
                                        onSimulateInterruptedRetrieval = { viewModel.triggerSimulatedInterruptedTransfer() },
                                        onCancelTransfer = { viewModel.cancelTransfer(it) },
                                        onRetryTransfer = { viewModel.retryTransfer(it) },
                                    )
                                }
                                composable(NavSection.SETTINGS.route) {
                                    SettingsScreen(
                                        settings = settings,
                                        serverConnected = session.serverConnected,
                                        auditEvents = auditEvents,
                                        onUpdateSettings = { viewModel.updateSettings(it) },
                                        onConnectRemote = { u, p -> viewModel.connectRemoteServer(u, p) },
                                        onPurgeCache = { viewModel.purgeLocalCacheAndReseed() },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showMoreNavSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showMoreNavSheet = false },
                    containerColor = GraphiteSurface,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("Workspace Sections", style = MaterialTheme.typography.titleMedium, color = CyanAccent)
                        listOf(
                            NavSection.COMPARISONS,
                            NavSection.ANNOTATIONS,
                            NavSection.TRANSFERS,
                            NavSection.SETTINGS,
                        ).forEach { sec ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .clickable {
                                        showMoreNavSheet = false
                                        navigateTo(sec)
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(iconForSection(sec), contentDescription = null, tint = CyanAccent)
                                Spacer(Modifier.width(12.dp))
                                Text(sec.label, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            }

            if (session.isLocked) {
                SessionLockOverlay(
                    operatorName = session.operatorName,
                    onUnlock = { viewModel.setSessionLocked(false) },
                )
            }
        }
    }
}

private fun iconForSection(sec: NavSection): ImageVector = when (sec) {
    NavSection.WORKLIST -> Icons.AutoMirrored.Filled.ListAlt
    NavSection.STUDIES -> Icons.Default.FolderOpen
    NavSection.VIEWER -> Icons.Default.Visibility
    NavSection.COMPARISONS -> Icons.AutoMirrored.Filled.CompareArrows
    NavSection.ANNOTATIONS -> Icons.Default.Bookmarks
    NavSection.REPORTS -> Icons.Default.Assignment
    NavSection.TRANSFERS -> Icons.Default.CloudDownload
    NavSection.SETTINGS -> Icons.Default.Settings
}
