package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

data class AureomUiSettings(
    val textScale: Float = 1.0f,
    val reducedMotion: Boolean = false,
)

val LocalAureomUiSettings = staticCompositionLocalOf { AureomUiSettings() }

private val AureomColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = GraphiteVoid,
    primaryContainer = CyanSubtleBg,
    onPrimaryContainer = CyanAccent,
    secondary = ClinicalSlate,
    onSecondary = GraphiteVoid,
    secondaryContainer = GraphiteSurfaceElevated,
    onSecondaryContainer = ClinicalWhite,
    tertiary = StatusValid,
    background = GraphiteBase,
    onBackground = ClinicalWhite,
    surface = GraphiteSurface,
    onSurface = ClinicalWhite,
    surfaceVariant = GraphiteSurfaceElevated,
    onSurfaceVariant = ClinicalSlate,
    outline = GraphiteBorder,
    error = StatusError,
    onError = ClinicalWhite,
)

private val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(12.dp),
)

@Composable
fun AureomTheme(
    uiSettings: AureomUiSettings = AureomUiSettings(),
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalAureomUiSettings provides uiSettings) {
        MaterialTheme(
            colorScheme = AureomColorScheme,
            typography = buildAureomTypography(uiSettings.textScale),
            shapes = AureomShapes,
            content = content,
        )
    }
}
