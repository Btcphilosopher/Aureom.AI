package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedSeriesEntity
import com.example.data.local.CachedStudyEntity
import com.example.data.research.KSpaceReconstructionResult
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning

@Composable
fun StudiesScreen(
    study: CachedStudyEntity?,
    seriesList: List<CachedSeriesEntity>,
    selectedSeriesUid: String?,
    kspaceResult: KSpaceReconstructionResult?,
    onSelectSeriesAndView: (String) -> Unit,
    onRunResearchKSpace: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Series Organisation & Acquisition Metadata", style = MaterialTheme.typography.headlineMedium)
                Text(
                    if (study != null) {
                        "Study UID: ${study.studyInstanceUid} • FrameOfReference: ${study.frameOfReferenceUid.ifBlank { "Unspecified" }}"
                    } else {
                        "Select a study from the Worklist."
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanAccent,
                )
            }
        }

        items(seriesList, key = { it.seriesInstanceUid }) { s ->
            val isSelected = s.seriesInstanceUid == selectedSeriesUid
            val statusColor = when (s.geometryStatus) {
                "VOLUMETRIC_VALID" -> StatusValid
                "LOCALISER" -> CyanAccent
                else -> StatusWarning
            }
            Surface(
                color = if (isSelected) GraphiteSurfaceElevated else GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(if (isSelected) 1.5.dp else 1.dp, if (isSelected) CyanAccent else GraphiteBorder, RoundedCornerShape(10.dp))
                    .clickable { onSelectSeriesAndView(s.seriesInstanceUid) },
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Series #${s.seriesNumber} — Source: ${s.sourceDescription}",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Text(
                                text = "Inferred Sequence: ${s.inferredSequenceLabel ?: "Unclassified"} (Basis: ${s.classificationSource})",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanAccent,
                            )
                        }
                        Button(
                            onClick = { onSelectSeriesAndView(s.seriesInstanceUid) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("View", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Slices: ${s.sliceCount}", style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                        Text("Matrix: ${s.columns}x${s.rows}", style = MaterialTheme.typography.labelSmall)
                        Text("TR/TE: ${s.repetitionTimeMs ?: "-"} / ${s.echoTimeMs ?: "-"} ms", style = MaterialTheme.typography.labelSmall)
                        if (s.inversionTimeMs != null) {
                            Text("TI: ${s.inversionTimeMs} ms", style = MaterialTheme.typography.labelSmall)
                        }
                        Text("Field: ${s.fieldStrengthTesla ?: "-"} T", style = MaterialTheme.typography.labelSmall)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            "Geometry: ${s.geometryStatus}${if (s.isOblique) " (OBLIQUE)" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                        )
                        Text(
                            "Spacing: ${s.pixelSpacingColMm ?: "-"}x${s.pixelSpacingRowMm ?: "-"}x${s.medianSliceSpacingMm?.let { "%.2f".format(it) } ?: "-"} mm",
                            style = MaterialTheme.typography.labelSmall,
                        )
                        Text(
                            "Units: ${s.quantityLabel} (slope=${s.rescaleSlope}, int=${s.rescaleIntercept})",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }

                    if (s.geometryWarningsJoined.isNotBlank()) {
                        Surface(
                            color = statusColor.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(Icons.Default.WarningAmber, contentDescription = null, tint = statusColor, modifier = Modifier.size(16.dp))
                                Text(s.geometryWarningsJoined, style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                            }
                        }
                    }
                }
            }
        }

        // Separately Labelled Research Workspace (k-Space Cartesian Reconstruction Demo)
        item {
            Spacer(Modifier.height(8.dp))
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StatusWarning.copy(alpha = 0.6f), RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Science, contentDescription = null, tint = StatusWarning)
                        Text("RESEARCH MODULE — Isolated 2D Cartesian k-Space Reconstruction", style = MaterialTheme.typography.titleMedium, color = StatusWarning)
                    }
                    Text(
                        "Strictly separated from the clinical DICOM archive. Demonstrates documented 2D Cartesian IFFT (ifftshift -> 2D ifft2 -> fftshift -> Root-Sum-of-Squares 4-coil combine) on synthetic mathematical phantom k-space.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedButton(
                        onClick = onRunResearchKSpace,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("run_research_kspace_button"),
                    ) {
                        Text("Run 2D Cartesian k-Space IFFT Demo")
                    }

                    if (kspaceResult != null) {
                        Text(kspaceResult.disclaimer, style = MaterialTheme.typography.labelSmall, color = StatusError)
                        Text("Convention: ${kspaceResult.fftConvention}", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                        Text("Scaling: ${kspaceResult.scalingNote}", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Coil 0 k-Space (log |k|)", style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(4.dp))
                                GrayGridPreview(kspaceResult.kSpaceLogMagnitude, kspaceResult.width, kspaceResult.height, Modifier.size(140.dp))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("RSS Magnitude Image (${kspaceResult.coilCount} coils)", style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(4.dp))
                                GrayGridPreview(kspaceResult.reconstructedMagnitudeRss, kspaceResult.width, kspaceResult.height, Modifier.size(140.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GrayGridPreview(values: FloatArray, width: Int, height: Int, modifier: Modifier) {
    val maxVal = values.maxOrNull()?.coerceAtLeast(1e-5f) ?: 1f
    val minVal = values.minOrNull() ?: 0f
    val range = (maxVal - minVal).coerceAtLeast(1e-5f)
    Canvas(modifier = modifier.border(1.dp, GraphiteBorder)) {
        val cw = size.width / width
        val ch = size.height / height
        for (y in 0 until height) {
            for (x in 0 until width) {
                val n = ((values[y * width + x] - minVal) / range).coerceIn(0f, 1f)
                drawRect(
                    color = Color(n, n, n, 1f),
                    topLeft = Offset(x * cw, y * ch),
                    size = Size(cw + 0.5f, ch + 0.5f),
                )
            }
        }
    }
}
