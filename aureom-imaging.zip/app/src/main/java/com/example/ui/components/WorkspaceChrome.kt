package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedStudyEntity
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanSubtleBg
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteVoid
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusWarning
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PatientExamHeaderBar(
    study: CachedStudyEntity?,
    serverConnected: Boolean,
    operatorName: String,
    isCompact: Boolean,
    onLockSession: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = GraphiteSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, GraphiteBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(CyanAccent)
                )
                Spacer(Modifier.width(10.dp))
                if (study == null) {
                    Column {
                        Text(
                            text = "AUREOM IMAGING — MRI Workspace",
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "No active examination selected • $operatorName",
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                } else {
                    val ageMin = ((System.currentTimeMillis() - study.cachedAtEpochMs).coerceAtLeast(0L) / 60000L)
                    val ageLabel = if (ageMin < 1L) "Cached <1m" else if (ageMin < 60L) "Cached ${ageMin}m" else "Cached ${ageMin / 60L}h"
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = study.patientName,
                                style = MaterialTheme.typography.titleSmall,
                                color = ClinicalWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "${study.patientId} (${study.issuingAuthority})",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanAccent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (study.isSyntheticDemo && !isCompact) {
                                Surface(
                                    color = CyanSubtleBg,
                                    shape = RoundedCornerShape(4.dp),
                                ) {
                                    Text(
                                        text = "SYNTHETIC DEMO",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanAccent,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    )
                                }
                            }
                        }
                        val subLine = if (isCompact) {
                            "${study.studyDescription} • ${study.studyDate} • ${study.seriesCount} ser"
                        } else {
                            "${study.studyDescription} • ${study.studyDate} ${study.studyTime} • Acc: ${study.accessionNumber.ifBlank { "N/A" }} • ${study.seriesCount} series • $ageLabel"
                        }
                        Text(
                            text = subLine,
                            style = MaterialTheme.typography.labelSmall,
                            color = ClinicalSlate,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Surface(
                    color = GraphiteSurfaceElevated,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = if (serverConnected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = if (serverConnected) "Backend connected" else "Local archive mode",
                            tint = if (serverConnected) StatusValid else StatusWarning,
                            modifier = Modifier.size(16.dp),
                        )
                        if (!isCompact) {
                            Text(
                                text = if (serverConnected) "Server Online" else "Local Archive",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (serverConnected) StatusValid else StatusWarning,
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onLockSession,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("lock_session_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock workstation session",
                        tint = CyanAccent,
                    )
                }
            }
        }
    }
}

@Composable
fun StatusAndErrorBanner(
    statusMessage: String?,
    errorMessage: String?,
    remediationMessage: String?,
    onDismiss: () -> Unit,
) {
    if (statusMessage == null && errorMessage == null) return
    val isError = errorMessage != null
    val borderCol = if (isError) StatusError else CyanAccent
    val bgCol = if (isError) StatusError.copy(alpha = 0.14f) else CyanSubtleBg
    Surface(
        color = bgCol,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .border(1.dp, borderCol, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = if (isError) Icons.Default.ErrorOutline else Icons.Default.Info,
                contentDescription = if (isError) "Error" else "Status",
                tint = borderCol,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = errorMessage ?: statusMessage.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ClinicalWhite,
                    fontWeight = FontWeight.Medium,
                )
                if (!remediationMessage.isNullOrBlank()) {
                    Text(
                        text = "Action: $remediationMessage",
                        style = MaterialTheme.typography.labelSmall,
                        color = ClinicalSlate,
                    )
                }
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Icon(Icons.Default.Close, contentDescription = "Dismiss notification", tint = ClinicalWhite)
            }
        }
    }
}

@Composable
fun SessionLockOverlay(
    operatorName: String,
    onUnlock: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteVoid.copy(alpha = 0.97f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            color = GraphiteSurface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .padding(24.dp)
                .border(1.dp, GraphiteBorder, RoundedCornerShape(12.dp)),
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Session locked",
                    tint = CyanAccent,
                    modifier = Modifier.size(44.dp),
                )
                Text("Workstation Session Locked", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "Patient imagery and clinical reports are protected. Active operator: $operatorName",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onUnlock,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = GraphiteVoid),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("unlock_session_button"),
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Resume Authorised Session", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

fun formatEpoch(epochMs: Long): String {
    return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(epochMs))
}
