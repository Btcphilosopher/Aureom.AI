package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AUREOM IMAGING — Clinical Graphite & Restrained Cyan Palette
val GraphiteVoid = Color(0xFF090C10)
val GraphiteBase = Color(0xFF0E1116)
val GraphiteSurface = Color(0xFF141922)
val GraphiteSurfaceElevated = Color(0xFF1B222E)
val GraphiteBorder = Color(0xFF283243)

val ClinicalWhite = Color(0xFFF4F7FB)
val ClinicalSlate = Color(0xFF9FB0C7)
val ClinicalMuted = Color(0xFF6B7B93)

val CyanAccent = Color(0xFF38BDF8)
val CyanMuted = Color(0xFF0EA5E9)
val CyanSubtleBg = Color(0xFF0F293A)

val StatusValid = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFF43F5E)
val StatusInfo = Color(0xFF38BDF8)
