package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.AnnotationEntity
import com.example.data.local.CachedStudyEntity
import com.example.ui.components.formatEpoch
import com.example.ui.theme.ClinicalSlate
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning

@Composable
fun AnnotationsScreen(
    study: CachedStudyEntity?,
    annotations: List<AnnotationEntity>,
    onDeleteAnnotation: (AnnotationEntity) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Study-Isolated Annotations & Measurements", style = MaterialTheme.typography.headlineMedium)
        Text(
            if (study != null) {
                "Scoped strictly to Study ${study.studyId} (${study.patientId}). Switching studies never carries annotations across examinations."
            } else {
                "No study selected."
            },
            style = MaterialTheme.typography.bodyMedium,
        )

        if (annotations.isEmpty()) {
            Surface(
                color = GraphiteSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
            ) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("No annotations recorded for this study", style = MaterialTheme.typography.titleMedium)
                    Text("Use Length, Angle, ROI Stats, Arrow, Text Note, or Contour tools in the Viewer to record measurements.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(annotations, key = { it.id }) { ann ->
                    Surface(
                        color = GraphiteSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(10.dp)),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(ann.measurementType, style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                                    if (ann.isReconstructedPlane) {
                                        Text("RECONSTRUCTED PLANE (${ann.planeLabel})", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                                    }
                                }
                                Text(ann.measuredValueText, style = MaterialTheme.typography.titleMedium, color = ClinicalWhite)
                                Text(
                                    "Author: ${ann.authorName} • ${formatEpoch(ann.createdAtEpochMs)} • Coord: ${ann.coordinateSystem}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ClinicalSlate,
                                )
                                Text(
                                    "Series: ${ann.seriesInstanceUid.takeLast(14)} • Physical Units: ${if (ann.physicalUnitsValid) ann.physicalUnitLabel else "Pixel only"}",
                                    style = MaterialTheme.typography.labelSmall,
                                )
                                if (!ann.noteText.isNullOrBlank()) {
                                    Text("Note/Basis: ${ann.noteText}", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            IconButton(
                                onClick = { onDeleteAnnotation(ann) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete annotation", tint = StatusError)
                            }
                        }
                    }
                }
            }
        }
    }
}
