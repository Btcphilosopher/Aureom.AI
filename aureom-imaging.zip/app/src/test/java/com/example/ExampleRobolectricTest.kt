package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AnnotationEntity
import com.example.data.local.AureomDatabase
import com.example.data.repository.IngestionOutcome
import com.example.data.repository.WorkspaceRepository
import com.example.data.research.KSpaceReconstructor
import com.example.data.security.DeviceKeyStoreManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.security.MessageDigest

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches AUREOM Imaging`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("AUREOM Imaging", context.getString(R.string.app_name))
    }

    @Test
    fun `import validate annotate study isolation and preservation of originals`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.aureomDao()
        val repo = WorkspaceRepository(context, dao, DeviceKeyStoreManager(context))

        // 1. Seed bundled synthetic archive
        repo.seedBundledDemoFixturesIfEmpty("Test Operator")
        val studies = dao.observeStudies().first()
        assertTrue(studies.size >= 3)

        // 2. Verify original DICOM file preservation (SHA-256 unchanged)
        val t1Instances = dao.getInstancesForSeries("1.2.826.0.1.3680043.10.900.1001.1")
        assertEquals(16, t1Instances.size)
        val firstFile = File(t1Instances.first().privateFilePath)
        assertTrue(firstFile.exists())
        val actualSha = MessageDigest.getInstance("SHA-256").digest(firstFile.readBytes())
            .joinToString("") { "%02x".format(it) }
        assertEquals(t1Instances.first().sha256Checksum, actualSha)

        // 3. Verify duplicate-safe ingestion skips identical SOPInstanceUID without error
        val dupOutcome = repo.ingestDicomBytes(firstFile.readBytes(), "LOCAL_DOCUMENT", "Test Operator")
        assertTrue(dupOutcome is IngestionOutcome.Success && dupOutcome.duplicateSkipped)

        // 4. Verify unsupported transfer syntax & malformed truncated rejection
        val j2kRes = repo.testEdgeFixtureIngestion("fixtures/edge_cases/unsupported_j2k.dcm", "Test Operator")
        assertTrue(j2kRes is IngestionOutcome.Failure && j2kRes.code == "UNSUPPORTED_TRANSFER_SYNTAX")

        val truncRes = repo.testEdgeFixtureIngestion("fixtures/edge_cases/malformed_truncated.dcm", "Test Operator")
        assertTrue(truncRes is IngestionOutcome.Failure)

        // 5. Verify annotation patient/study isolation
        val studyA = "1.2.826.0.1.3680043.10.900.1001"
        val studyB = "1.2.826.0.1.3680043.10.900.1003"
        repo.saveAnnotation(
            AnnotationEntity(
                id = "ann-test-a",
                studyInstanceUid = studyA,
                seriesInstanceUid = "$studyA.1",
                sopInstanceUid = "$studyA.1.1",
                authorId = "usr-1",
                authorName = "Dr. Aureom",
                measurementType = "LENGTH",
                coordinateSystem = "IMAGE_PIXEL_2D",
                isReconstructedPlane = false,
                planeLabel = "Native Acquisition",
                physicalUnitsValid = true,
                physicalUnitLabel = "mm",
                geometryJson = "{\"points\":[[0.2,0.2],[0.6,0.2]]}",
                measuredValueText = "57.6 mm",
                intensityStatsJson = null,
                noteText = null,
                createdAtEpochMs = 1000L,
            )
        )
        val annsA = dao.observeAnnotationsForStudy(studyA).first()
        val annsB = dao.observeAnnotationsForStudy(studyB).first()
        assertEquals(1, annsA.size)
        assertEquals(0, annsB.size)

        // 6. Verify isolated research 2D Cartesian k-space IFFT reconstruction
        val kspaceJson = context.assets.open("fixtures/kspace_cartesian_2d.json").bufferedReader().use { it.readText() }
        val recon = KSpaceReconstructor.reconstructFromJson(kspaceJson)
        assertEquals(64, recon.width)
        assertEquals(64, recon.height)
        assertEquals(4, recon.coilCount)
        assertTrue(recon.reconstructedMagnitudeRss.maxOrNull()!! > 0.5f)

        db.close()
    }
}
