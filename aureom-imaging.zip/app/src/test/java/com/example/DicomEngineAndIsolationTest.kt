package com.example

import com.example.dicom.DicomGeometry
import com.example.dicom.DicomSlice
import com.example.dicom.GeometryStatus
import com.example.dicom.InterpolationMode
import com.example.dicom.MprPlane
import com.example.dicom.PixelDisplayTransform
import com.example.dicom.Vec3
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

class DicomEngineAndIsolationTest {

    private fun makeSlice(
        sop: String,
        instNum: Int,
        ipp: Vec3,
        rowDir: Vec3 = Vec3(1.0, 0.0, 0.0),
        colDir: Vec3 = Vec3(0.0, 1.0, 0.0),
        rows: Int = 16,
        cols: Int = 16,
        fillVal: Float = 500f,
    ): DicomSlice {
        val pixels = FloatArray(rows * cols) { idx -> fillVal + (idx % cols) * 10f }
        return DicomSlice(
            sopInstanceUid = sop,
            sopClassUid = "1.2.840.10008.5.1.4.1.1.4",
            transferSyntaxUid = "1.2.840.10008.1.2.1",
            studyInstanceUid = "1.2.3.study",
            seriesInstanceUid = "1.2.3.series",
            patientId = "PT-1",
            issuerOfPatientId = "ORG",
            patientName = "SYNTH^TEST",
            patientBirthDate = "19900101",
            patientSex = "F",
            studyId = "S1",
            accessionNumber = "ACC1",
            studyDescription = "Test",
            studyDate = "20261101",
            studyTime = "100000",
            seriesNumber = 1,
            seriesDescription = "AX_T1_MPRAGE",
            modality = "MR",
            imageType = "ORIGINAL\\PRIMARY\\M\\ND",
            scanningSequence = "GR",
            mrAcquisitionType = "3D",
            repetitionTime = 2000.0,
            echoTime = 3.0,
            inversionTime = 900.0,
            flipAngle = 9.0,
            magneticFieldStrength = 3.0,
            sliceThickness = 2.0,
            sliceSpacing = 2.0,
            instanceNumber = instNum,
            imagePositionPatient = ipp,
            rowDirection = rowDir,
            colDirection = colDir,
            frameOfReferenceUid = "1.2.3.for",
            sliceLocation = ipp.z,
            rows = rows,
            columns = cols,
            pixelSpacingRow = 1.5,
            pixelSpacingCol = 1.5,
            bitsAllocated = 16,
            bitsStored = 12,
            pixelRepresentation = 0,
            photometricInterpretation = "MONOCHROME2",
            defaultWindowCenter = 500.0,
            defaultWindowWidth = 1000.0,
            rescaleSlope = 1.0,
            rescaleIntercept = 0.0,
            sha256Checksum = "abc",
            rawPixels = pixels,
        )
    }

    @Test
    fun `orientation markers reflect axial sagittal and oblique LPS vectors`() {
        val axial = DicomGeometry.computeOrientationMarkers(Vec3(1.0, 0.0, 0.0), Vec3(0.0, 1.0, 0.0))
        assertEquals("L", axial.right)
        assertEquals("R", axial.left)
        assertEquals("P", axial.bottom)
        assertEquals("A", axial.top)

        val sagittal = DicomGeometry.computeOrientationMarkers(Vec3(0.0, 1.0, 0.0), Vec3(0.0, 0.0, -1.0))
        assertEquals("P", sagittal.right)
        assertEquals("A", sagittal.left)
        assertEquals("F", sagittal.bottom)
        assertEquals("H", sagittal.top)

        val ang = Math.toRadians(30.0)
        val oblique = DicomGeometry.computeOrientationMarkers(Vec3(1.0, 0.0, 0.0), Vec3(0.0, cos(ang), sin(ang)))
        assertEquals("PH", oblique.bottom)
        assertEquals("AF", oblique.top)
    }

    @Test
    fun `slice ordering uses patient-space normal projection rather than instance number`() {
        // Instance numbers deliberately inverted relative to spatial Z
        val s1 = makeSlice("sop-1", instNum = 99, ipp = Vec3(0.0, 0.0, -10.0))
        val s2 = makeSlice("sop-2", instNum = 1, ipp = Vec3(0.0, 0.0, 0.0))
        val s3 = makeSlice("sop-3", instNum = 50, ipp = Vec3(0.0, 0.0, 10.0))

        val sorted = DicomGeometry.sortSlicesByGeometry(listOf(s3, s1, s2))
        assertEquals(listOf("sop-1", "sop-2", "sop-3"), sorted.map { it.sopInstanceUid })
    }

    @Test
    fun `display transformation handles window level MONOCHROME1 and inversion without mutating source`() {
        val slice = makeSlice("sop-disp", 1, Vec3(0.0, 0.0, 0.0), fillVal = 500f)
        val snapshotBefore = slice.rawPixels.copyOf()

        val gMid = PixelDisplayTransform.mapIntensityToGray8(500f, 500.0, 1000.0, "MONOCHROME2", userInvert = false)
        assertEquals(128, gMid)

        val gMono1 = PixelDisplayTransform.mapIntensityToGray8(1000f, 500.0, 1000.0, "MONOCHROME1", userInvert = false)
        assertEquals(0, gMono1)

        val gMono1Inverted = PixelDisplayTransform.mapIntensityToGray8(1000f, 500.0, 1000.0, "MONOCHROME1", userInvert = true)
        assertEquals(255, gMono1Inverted)

        assertTrue(snapshotBefore.contentEquals(slice.rawPixels))
    }

    @Test
    fun `oblique MPR resampling produces reconstructed sagittal plane and flags out-of-bounds regions`() {
        val ang = Math.toRadians(30.0)
        val rDir = Vec3(1.0, 0.0, 0.0)
        val cDir = Vec3(0.0, cos(ang), sin(ang))
        val nDir = rDir.cross(cDir).normalized()
        val slices = (0 until 8).map { i ->
            val d = i * 3.0
            makeSlice("sop-$i", i + 1, nDir * d, rowDir = rDir, colDir = cDir, fillVal = 600f + i * 20f)
        }
        val geom = DicomGeometry.validateSeriesGeometry(slices)
        assertTrue(geom.isVolumetricCompatible)
        assertTrue(geom.isOblique)
        assertEquals(GeometryStatus.VOLUMETRIC_VALID, geom.status)

        val sag = DicomGeometry.resampleMprPlane(slices, MprPlane.SAGITTAL, 0.5f, InterpolationMode.TRILINEAR)
        assertNotNull(sag)
        assertTrue(sag!!.isReconstructed)
        // Oblique bounding box corners include out-of-bounds regions outside the tilted slab
        assertTrue(sag.missingDataMask.any { it })
        assertTrue(sag.missingDataMask.any { !it })
    }

    @Test
    fun `physical length angle and ROI stats label arbitrary MR signal intensity`() {
        val (lenText, valid) = DicomGeometry.measureLength(0.0f, 0.0f, 0.5f, 0.0f, 100, 100, 1.5, 1.5, isReconstructedPlane = true)
        assertTrue(valid)
        assertTrue(lenText.contains("75.0 mm (MPR)"))

        val deg = DicomGeometry.measureAngleDeg(0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 100, 100, 1.5, 1.5)
        assertEquals(90.0, deg, 0.1)

        val pixels = FloatArray(100 * 100) { 800f }
        val roi = DicomGeometry.computeEllipticalRoiStats(
            pixels, null, 100, 100, 0.5f, 0.5f, 0.1f, 0.1f, 1.5, 1.5, "Arbitrary MR Signal Intensity"
        )
        assertEquals(800.0, roi.meanValue, 0.1)
        assertFalse(roi.quantityLabel.contains("SUV"))
        assertEquals("Arbitrary MR Signal Intensity", roi.quantityLabel)
    }
}
