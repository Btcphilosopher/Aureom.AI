# AUREOM IMAGING — Data Provenance, Safety Verification & Build Guide

## 1. Demonstration Data Provenance
All imaging fixtures included in `backend/fixtures/generated/` and `app/src/main/assets/fixtures/` are **100% synthetic mathematical phantoms** generated deterministically by `backend/fixtures/generate_fixtures.py`:
- Zero real patient images, zero clinical PHI, and zero scraped external datasets.
- Fictional patient records (`AUR-PT-0419` *Elena Vance-Sterling (Synthetic)* and `AUR-PT-0882` *Marcus Chen-Demo (Synthetic)*) are explicitly marked `PatientIdentityRemoved = YES` and `is_synthetic_demo = true`.
- Synthetic k-space dataset (`SYNTH_CARTESIAN_BRAIN_64X64_4COIL`) is generated via analytical 2D DFT of a synthetic brain phantom across 4 simulated quadrature coils; never derived from magnitude DICOM images.

## 2. Clinical Deployment Pre-Check (Regulatory & Safety Gate)
Before proposing any clinical deployment outside demonstration/research:
1. **Intended Jurisdiction & Medical-Device Classification**: Determine SaMD classification under FDA 21 CFR 892.2050 (PACS/medical image management & display), EU MDR (2017/745) Rule 11, or UK MHRA UKCA guidance.
2. **Display Suitability & Calibration**: Verify diagnostic display luminance, DICOM GSDF (Part 14) calibration, and mobile/tablet ambient-light viewing restrictions (mobile screens are typically restricted from primary diagnostic mammography/subtle micro-finding reads without calibrated monitors).
3. **Clinical Safety & Risk Management**: Complete ISO 14971 hazard analysis, IEC 62304 software lifecycle documentation, and independent clinical validation of MPR resampling & ROI coordinate accuracy.
4. **Archive & Identity Integration**: Replace demo auth with enterprise OIDC/SAML2 + MFA, enforce TLS 1.3 with mutual or pinned certificates, and validate DICOMweb PACS conformance statements.

## 3. APK Build & Verification Instructions

```bash
# Compile Android debug APK
gradle :app:assembleDebug

# Run Android JVM & Robolectric unit tests (orientation, slice ordering, WL/LUT, MPR coordinates, patient isolation, transfer recovery)
gradle :app:testDebugUnitTest

# Run Backend unit tests
python3 -m unittest discover -s backend/tests -v
```
