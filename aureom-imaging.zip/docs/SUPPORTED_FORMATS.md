# AUREOM IMAGING — Supported Format & Compatibility Matrix

Verified against DICOM PS3.5 (Data Structures & Encoding), PS3.6 (Data Dictionary), and PS3.18 (Web Services / DICOMweb).

## 1. Supported SOP Classes (Initial Release)

| SOP Class Name | SOP Class UID | Support Status | Notes |
|---|---|---|---|
| MR Image Storage (Single-Frame) | `1.2.840.10008.5.1.4.1.1.4` | **Supported** | Full metadata, pixel decode, patient-space geometry, MPR & 3D volume |
| Enhanced MR Image Storage (Multiframe) | `1.2.840.10008.5.1.4.1.1.4.1` | **Milestone 2 (Explicitly Gated)** | Rejected at ingestion with actionable message directing single-frame split or server converter |
| Secondary Capture / Non-MR Modalities | `1.2.840.10008.5.1.4.1.1.7` etc. | **Rejected** | Workspace restricted to MR objects (`Modality = MR`) |

## 2. Supported Transfer Syntaxes

| Transfer Syntax Name | Transfer Syntax UID | Support Status |
|---|---|---|
| Implicit VR Little Endian | `1.2.840.10008.1.2` | **Supported** |
| Explicit VR Little Endian | `1.2.840.10008.1.2.1` | **Supported** |
| JPEG 2000 Lossless / Lossy | `1.2.840.10008.1.2.4.90` / `.91` | **Rejected (Milestone 2 Transcoding)** |
| JPEG Baseline / Lossless / RLE / Deflated | `1.2.840.10008.1.2.4.*`, `.5`, `.1.99` | **Rejected with Remediation** |

## 3. Pixel Encoding & Display Transformations

- **BitsAllocated / BitsStored**: `8`-bit unsigned, `16`-bit allocated (`12`-bit / `16`-bit stored).
- **PixelRepresentation**: `0` (unsigned integer) and `1` (two's-complement signed integer).
- **PhotometricInterpretation**: `MONOCHROME2` (standard bright high-signal) and `MONOCHROME1` (inverted polarity handled before user inversion toggle).
- **Rescale & Quantitative Mapping**: Preserves `RescaleSlope (0028,1053)` and `RescaleIntercept (0028,1052)`. Ordinary MR arbitrary signal intensity is explicitly labelled *"Arbitrary MR Signal Intensity"* rather than universal physical units.
- **GPU Rendering Layer**: OpenGL ES 3.0 (`GLSurfaceView` + GLSL fragment shaders) uploads normalized 16-bit/float luminance textures (`R32F` / `RGBA8` high-precision packed 16-bit) and executes real-time GPU Window/Level, grayscale inversion, zoom/pan, and oblique MPR/3D raymarching without mutating original source pixels.

## 4. Geometry & Volumetric Rules

- Slices are sorted strictly by scalar projection along the unit slice normal `n = row_dir x col_dir` derived from `ImageOrientationPatient (0020,0037)` and `ImagePositionPatient (0020,0032)`.
- Never sorted solely by filename or `InstanceNumber (0020,0013)`.
- Localisers (`ImageType` containing `LOCALIZER`), non-parallel planes (`|dot(n_0, n_i)| < 0.995`), duplicate slice positions (`|Δproj| < 0.05 mm`), and irregular slice spacing (>35% deviation from median) are flagged and blocked from silent 3D/MPR synthesis.
