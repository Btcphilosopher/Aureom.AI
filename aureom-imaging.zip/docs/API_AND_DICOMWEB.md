# AUREOM IMAGING — Backend API, DICOMweb Adapter & Docker Environment

## 1. Local Demonstration Environment (Docker Compose)

Start PostgreSQL 16, Orthanc DICOMweb Archive, and the FastAPI application service:

```bash
docker compose up --build
```

Services:
- **FastAPI Backend**: `http://localhost:8000` (Android emulator accesses via `http://10.0.2.2:8000`)
- **OpenAPI Docs**: `http://localhost:8000/docs`
- **Orthanc DICOMweb Archive**: `http://localhost:8042/dicom-web` (QIDO-RS, WADO-RS, STOW-RS)
- **PostgreSQL 16**: `localhost:5432` (schema auto-initialized from `backend/migrations/001_initial_schema.sql`)

## 2. Core REST Endpoints

| Method | Path | Purpose | Auth / RBAC |
|---|---|---|---|
| `GET` | `/api/v1/auth/status` | Checks if initial workspace admin is claimed | Public |
| `POST` | `/api/v1/auth/bootstrap` | First-run organisational admin claim | Public (one-time) |
| `POST` | `/api/v1/auth/login` | Organisational login returning HS256 JWT | Public |
| `GET` | `/api/v1/worklist` | Searchable patient/study worklist | Authenticated + Patient ACL |
| `GET` | `/api/v1/studies/{study_uid}/series` | Series list with source vs inferred labels | Authenticated + Study ACL |
| `GET` | `/api/v1/instances/{sop_uid}/dicom` | Immutable original DICOM Part 10 stream | Authenticated + Study ACL |
| `POST` | `/api/v1/imports/dicom` | Duplicate-safe validated DICOM ingestion | `admin`, `radiologist`, `technologist` |
| `GET` | `/api/v1/dicomweb/studies` | QIDO-RS query via replaceable adapter | Authenticated |
| `POST` | `/api/v1/dicomweb/retrieve/{study_uid}` | WADO-RS retrieval & ingestion job | `admin`, `radiologist`, `technologist` |
| `GET/POST/DELETE` | `/api/v1/studies/{study_uid}/annotations` | Study-isolated measurements & notes | Authenticated / Clinician |
| `GET/PUT` | `/api/v1/studies/{study_uid}/reports` | Versioned draft reports with optimistic lock | `admin`, `radiologist` |
| `POST` | `/api/v1/reports/{report_id}/sign` | Immutable signature + SHA-256 seal | `admin`, `radiologist` |
| `POST` | `/api/v1/reports/{report_id}/amendments` | Linked post-signature amendments | `admin`, `radiologist` |
| `GET` | `/api/v1/audit` | Immutable security & access audit log | `admin`, `radiologist` |
| `POST` | `/api/v1/admin/backup` | Protected originals ZIP backup + SHA-256 | `admin` |
| `POST` | `/api/v1/ai/assist` | Non-diagnostic metadata/summary helper | Disabled by default (`403`) |
| `GET` | `/api/v1/research/kspace-datasets` | Isolated synthetic 2D Cartesian k-space | Authenticated |
