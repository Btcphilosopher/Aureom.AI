import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.ai_adapter import DeterministicMetadataAssistAdapter
from app.dicom_service import (
    DicomValidationError,
    analyze_series_geometry,
    classify_mr_series,
    parse_dicom_part10,
)

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures" / "generated"


class TestDicomFixturesAndGeometry(unittest.TestCase):
    def test_valid_volumetric_t1_series_parses_and_validates(self):
        t1_dir = FIXTURES_DIR / "study_1_brain_current" / "series_1_t1_3d"
        files = sorted(t1_dir.glob("*.dcm"))
        self.assertEqual(len(files), 16)
        instances = []
        for f in files:
            p = parse_dicom_part10(f.read_bytes())
            self.assertEqual(p.modality, "MR")
            self.assertEqual(p.rows, 96)
            self.assertEqual(p.columns, 96)
            label, src, _ = classify_mr_series(p)
            self.assertEqual(label, "T1-Weighted")
            instances.append(
                {
                    "instance_number": p.instance_number,
                    "image_type": p.image_type,
                    "rows": p.rows,
                    "columns": p.columns,
                    "image_position_patient": "\\".join(str(v) for v in p.image_position_patient),
                    "image_orientation_patient": "\\".join(str(v) for v in p.image_orientation_patient),
                }
            )
        geom = analyze_series_geometry(instances)
        self.assertTrue(geom["is_volumetric_compatible"])
        self.assertFalse(geom["is_localiser"])
        self.assertEqual(geom["geometry_status"], "VOLUMETRIC_VALID")

    def test_localiser_detected_and_excluded_from_volume(self):
        loc_dir = FIXTURES_DIR / "study_1_brain_current" / "series_4_localizer"
        instances = []
        for f in sorted(loc_dir.glob("*.dcm")):
            p = parse_dicom_part10(f.read_bytes())
            instances.append(
                {
                    "instance_number": p.instance_number,
                    "image_type": p.image_type,
                    "rows": p.rows,
                    "columns": p.columns,
                    "image_position_patient": "\\".join(str(v) for v in p.image_position_patient),
                    "image_orientation_patient": "\\".join(str(v) for v in p.image_orientation_patient),
                }
            )
        geom = analyze_series_geometry(instances)
        self.assertTrue(geom["is_localiser"])
        self.assertFalse(geom["is_volumetric_compatible"])

    def test_knee_geometry_anomaly_detects_duplicates_and_gap(self):
        knee_dir = FIXTURES_DIR / "study_3_knee_anomaly" / "series_1_pd_gapped"
        instances = []
        for f in sorted(knee_dir.glob("*.dcm")):
            p = parse_dicom_part10(f.read_bytes())
            instances.append(
                {
                    "instance_number": p.instance_number,
                    "image_type": p.image_type,
                    "rows": p.rows,
                    "columns": p.columns,
                    "image_position_patient": "\\".join(str(v) for v in p.image_position_patient),
                    "image_orientation_patient": "\\".join(str(v) for v in p.image_orientation_patient),
                }
            )
        geom = analyze_series_geometry(instances)
        self.assertFalse(geom["is_volumetric_compatible"])
        self.assertEqual(geom["geometry_status"], "GEOMETRY_WARNING")
        joined = " ".join(geom["warnings"])
        self.assertIn("Duplicate slice positions", joined)
        self.assertIn("Irregular slice spacing", joined)

    def test_unsupported_transfer_syntax_rejected_cleanly(self):
        j2k_file = FIXTURES_DIR / "edge_cases" / "unsupported_j2k.dcm"
        with self.assertRaises(DicomValidationError) as ctx:
            parse_dicom_part10(j2k_file.read_bytes())
        self.assertEqual(ctx.exception.code, "UNSUPPORTED_TRANSFER_SYNTAX")

    def test_malformed_truncated_dicom_rejected_cleanly(self):
        trunc_file = FIXTURES_DIR / "edge_cases" / "malformed_truncated.dcm"
        with self.assertRaises(DicomValidationError) as ctx:
            parse_dicom_part10(trunc_file.read_bytes())
        self.assertIn(ctx.exception.code, {"TRUNCATED_OBJECT", "TRUNCATED_PAYLOAD"})

    def test_ai_adapter_strictly_non_diagnostic_with_citations(self):
        adapter = DeterministicMetadataAssistAdapter()
        res = adapter.summarise_authorised_reports(
            "1.2.3",
            [{"id": "rep-1", "status": "SIGNED", "version": 2, "study_instance_uid": "1.2.3", "impression_text": "Stable focus."}],
        )
        self.assertEqual(res["source_references"][0]["report_id"], "rep-1")
        self.assertIn("Stable focus.", res["summary_bullets"][0])


if __name__ == "__main__":
    unittest.main()
