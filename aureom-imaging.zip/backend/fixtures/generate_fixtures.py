#!/usr/bin/env python3
"""
Synthetic, de-identified DICOM Part 10 MR fixture & k-space dataset generator for AUREOM IMAGING.
Produces strictly synthetic mathematical phantom anatomy (zero real patient data):
1. Study 1 (Current): Volumetric T1 MPRAGE (16 slices), T2 TSE (12 slices), FLAIR (12 slices),
   3-Plane Localizer (3 scout slices), Oblique 30-deg Coronal-Axial (12 slices).
2. Study 2 (Prior -6 Mo): Comparison volumetric T1 MPRAGE (16 slices, shifted origin & smaller lesion).
3. Study 3 (Anomaly): Knee PD FS Sagittal with missing slice gap + duplicate slice position.
4. Edge fixtures: Unsupported Transfer Syntax (JPEG 2000 1.2.840.10008.1.2.4.90) & Malformed Truncated DICOM.
5. Research fixture: 2D Cartesian multi-coil k-space JSON/binary dataset (separate from clinical archive).
"""

import hashlib
import json
import math
import os
import shutil
import struct
from pathlib import Path
from typing import Dict, List, Tuple

LONG_VRS = {"OB", "OD", "OF", "OL", "OW", "SQ", "UC", "UR", "UT", "UN"}

ROOT_DIR = Path(__file__).resolve().parent
GENERATED_DIR = ROOT_DIR / "generated"
RESEARCH_DIR = ROOT_DIR / "research"
ANDROID_ASSETS_DIR = ROOT_DIR.parent.parent / "app" / "src" / "main" / "assets" / "fixtures"


def pad_value(vr: str, raw: bytes) -> bytes:
    if len(raw) % 2 == 1:
        pad_byte = b"\x00" if vr in {"UI", "OB", "OW", "UN"} else b" "
        return raw + pad_byte
    return raw


def encode_elem(group: int, elem: int, vr: str, value: bytes) -> bytes:
    val = pad_value(vr, value)
    if vr in LONG_VRS:
        return struct.pack("<HH2sHI", group, elem, vr.encode("ascii"), 0, len(val)) + val
    return struct.pack("<HH2sH", group, elem, vr.encode("ascii"), len(val)) + val


def encode_str(group: int, elem: int, vr: str, text: str) -> bytes:
    return encode_elem(group, elem, vr, text.encode("ascii"))


def encode_us(group: int, elem: int, val: int) -> bytes:
    return encode_elem(group, elem, "US", struct.pack("<H", val))


def encode_ul(group: int, elem: int, val: int) -> bytes:
    return encode_elem(group, elem, "UL", struct.pack("<I", val))


def build_dicom_part10(
    tags: List[Tuple[int, int, str, bytes]],
    transfer_syntax_uid: str = "1.2.840.10008.1.2.1",
    sop_class_uid: str = "1.2.840.10008.5.1.4.1.1.4",
    sop_instance_uid: str = "",
) -> bytes:
    # Build Group 0002 File Meta Information
    meta_elems = b"".join([
        encode_elem(0x0002, 0x0001, "OB", b"\x00\x01"),
        encode_str(0x0002, 0x0002, "UI", sop_class_uid),
        encode_str(0x0002, 0x0003, "UI", sop_instance_uid),
        encode_str(0x0002, 0x0010, "UI", transfer_syntax_uid),
        encode_str(0x0002, 0x0012, "UI", "1.2.826.0.1.3680043.10.900.1"),
        encode_str(0x0002, 0x0013, "SH", "AUREOM_SYNTH_1"),
    ])
    meta_group = encode_ul(0x0002, 0x0000, len(meta_elems)) + meta_elems

    # Sort dataset tags strictly by (group, elem)
    sorted_tags = sorted(tags, key=lambda t: (t[0], t[1]))
    dataset = b"".join(encode_elem(g, e, vr, val) for g, e, vr, val in sorted_tags)

    preamble = b"\x00" * 128 + b"DICM"
    return preamble + meta_group + dataset


def generate_brain_slice(
    rows: int,
    cols: int,
    z_mm: float,
    contrast: str,
    lesion_radius_mm: float = 7.5,
    angle_rad: float = 0.0,
) -> bytes:
    """
    Generate realistic 16-bit synthetic brain MR slice in patient LPS space.
    Uses anatomical ellipsoids: scalp/skull rim, cortex, white matter,
    lateral ventricles (CSF), corpus callosum, and right-frontal focal hyper/hypointense focus.
    """
    buf = bytearray(rows * cols * 2)
    idx = 0
    # Contrast baselines (arbitrary MR units 0..2200)
    if contrast == "T1":
        bg, skull, csf, gm, wm, lesion = 18, 220, 260, 820, 1180, 560
    elif contrast == "T2":
        bg, skull, csf, gm, wm, lesion = 14, 150, 1850, 960, 640, 1520
    elif contrast == "FLAIR":
        bg, skull, csf, gm, wm, lesion = 14, 140, 190, 920, 680, 1740
    else:  # LOCALIZER / PD
        bg, skull, csf, gm, wm, lesion = 16, 180, 1100, 950, 880, 1280

    cos_a = math.cos(angle_rad)
    sin_a = math.sin(angle_rad)

    for r in range(rows):
        y_img = (r - rows / 2.0) * 1.6  # mm
        for c in range(cols):
            x = (c - cols / 2.0) * 1.6  # mm
            # Apply oblique rotation in y-z plane if oblique acquisition
            y = y_img * cos_a - z_mm * sin_a
            z = y_img * sin_a + z_mm * cos_a

            # Outer head ellipsoid
            head_r = (x / 72.0) ** 2 + (y / 88.0) ** 2 + (z / 66.0) ** 2
            if head_r > 1.0:
                val = bg + int(4 * math.sin(x * 0.4) * math.cos(y * 0.4))
            elif head_r > 0.86:
                # Scalp + cortical bone low signal
                val = skull + (120 if head_r > 0.94 else 0)
            else:
                # Brain parenchyma
                brain_r = (x / 63.0) ** 2 + (y / 79.0) ** 2 + (z / 56.0) ** 2
                if brain_r > 1.0:
                    val = csf
                else:
                    # Gray matter cortical ribbon + gyral modulation
                    gyri = 0.06 * math.sin(x * 0.25) * math.cos(y * 0.25)
                    if brain_r > 0.72 + gyri:
                        val = gm
                    else:
                        val = wm
                    # Midline falx / interhemispheric fissure
                    if abs(x) < 1.8 and (y > 18 or y < -18 or z > 12):
                        val = csf
                    # Lateral ventricles (butterfly shape)
                    vx = (abs(x) - 12.0) / 8.5
                    vy = (y + 2.0) / 24.0
                    vz = (z + 2.0) / 14.0
                    if vx * vx + vy * vy + vz * vz < 1.0 and abs(x) > 2.2:
                        val = csf
                    # Focal right-frontal lesion (patient right = x < 0 in LPS)
                    lx = (x + 24.0) / lesion_radius_mm
                    ly = (y + 22.0) / lesion_radius_mm
                    lz = (z - 2.0) / (lesion_radius_mm * 1.1)
                    d_lesion = lx * lx + ly * ly + lz * lz
                    if d_lesion < 1.0:
                        blend = 1.0 - d_lesion
                        val = int(val * (1.0 - blend) + lesion * blend)

            # Subtle deterministic Rician-like texture
            noise = int(16 * math.sin(x * 1.7 + y * 2.3 + z * 0.9))
            clamped = max(0, min(4095, val + noise))
            struct.pack_into("<H", buf, idx, clamped)
            idx += 2
    return bytes(buf)


def generate_knee_slice(rows: int, cols: int, slice_idx: int) -> bytes:
    buf = bytearray(rows * cols * 2)
    idx = 0
    for r in range(rows):
        y = (r - rows / 2.0) * 1.4
        for c in range(cols):
            x = (c - cols / 2.0) * 1.4
            leg = (x / 52.0) ** 2 + (y / 78.0) ** 2
            if leg > 1.0:
                val = 15
            else:
                val = 580
                # Femur & Tibia bone marrow
                femur = ((x + 4) / 24.0) ** 2 + ((y + 34) / 26.0) ** 2
                tibia = ((x + 2) / 26.0) ** 2 + ((y - 36) / 24.0) ** 2
                patella = ((x - 32) / 10.0) ** 2 + ((y + 6) / 16.0) ** 2
                if femur < 1.0 or tibia < 1.0 or patella < 1.0:
                    val = 1120 if (femur < 0.82 or tibia < 0.82 or patella < 0.8) else 220
                # Joint space fluid
                if abs(y) < 5.5 and abs(x) < 28.0:
                    val = 1480 + slice_idx * 25
            struct.pack_into("<H", buf, idx, max(0, min(4095, val)))
            idx += 2
    return bytes(buf)


def make_mr_tags(
    patient_name: str,
    patient_id: str,
    issuer: str,
    birth_date: str,
    sex: str,
    study_uid: str,
    study_id: str,
    study_desc: str,
    study_date: str,
    study_time: str,
    accession: str,
    series_uid: str,
    series_num: int,
    series_desc: str,
    sop_uid: str,
    instance_num: int,
    image_type: str,
    seq: str,
    acq_type: str,
    tr: float,
    te: float,
    ti: float | None,
    flip: float,
    slice_thickness: float,
    slice_spacing: float,
    ipp: Tuple[float, float, float],
    iop: Tuple[float, float, float, float, float, float],
    for_uid: str,
    slice_loc: float,
    rows: int,
    cols: int,
    pixel_spacing: Tuple[float, float],
    wc: float,
    ww: float,
    pixel_data: bytes,
) -> List[Tuple[int, int, str, bytes]]:
    tags: List[Tuple[int, int, str, bytes]] = [
        (0x0008, 0x0005, "CS", b"ISO_IR 100"),
        (0x0008, 0x0008, "CS", image_type.encode("ascii")),
        (0x0008, 0x0016, "UI", b"1.2.840.10008.5.1.4.1.1.4"),
        (0x0008, 0x0018, "UI", sop_uid.encode("ascii")),
        (0x0008, 0x0020, "DA", study_date.encode("ascii")),
        (0x0008, 0x0030, "TM", study_time.encode("ascii")),
        (0x0008, 0x0050, "SH", accession.encode("ascii")),
        (0x0008, 0x0060, "CS", b"MR"),
        (0x0008, 0x0070, "LO", b"AUREOM SYNTHETIC PHANTOM"),
        (0x0008, 0x1030, "LO", study_desc.encode("ascii")),
        (0x0008, 0x103E, "LO", series_desc.encode("ascii")),
        (0x0010, 0x0010, "PN", patient_name.encode("ascii")),
        (0x0010, 0x0020, "LO", patient_id.encode("ascii")),
        (0x0010, 0x0021, "LO", issuer.encode("ascii")),
        (0x0010, 0x0030, "DA", birth_date.encode("ascii")),
        (0x0010, 0x0040, "CS", sex.encode("ascii")),
        (0x0012, 0x0062, "CS", b"YES"),
        (0x0012, 0x0063, "LO", b"SYNTHETIC_MATHEMATICAL_PHANTOM"),
        (0x0018, 0x0020, "CS", seq.encode("ascii")),
        (0x0018, 0x0023, "CS", acq_type.encode("ascii")),
        (0x0018, 0x0050, "DS", f"{slice_thickness:.2f}".encode("ascii")),
        (0x0018, 0x0080, "DS", f"{tr:.1f}".encode("ascii")),
        (0x0018, 0x0081, "DS", f"{te:.1f}".encode("ascii")),
        (0x0018, 0x0087, "DS", b"3.0"),
        (0x0018, 0x0088, "DS", f"{slice_spacing:.2f}".encode("ascii")),
        (0x0018, 0x1314, "DS", f"{flip:.1f}".encode("ascii")),
        (0x0020, 0x000D, "UI", study_uid.encode("ascii")),
        (0x0020, 0x000E, "UI", series_uid.encode("ascii")),
        (0x0020, 0x0010, "SH", study_id.encode("ascii")),
        (0x0020, 0x0011, "IS", str(series_num).encode("ascii")),
        (0x0020, 0x0013, "IS", str(instance_num).encode("ascii")),
        (0x0020, 0x0032, "DS", f"{ipp[0]:.4f}\\{ipp[1]:.4f}\\{ipp[2]:.4f}".encode("ascii")),
        (0x0020, 0x0037, "DS", "\\".join(f"{v:.6f}" for v in iop).encode("ascii")),
        (0x0020, 0x0052, "UI", for_uid.encode("ascii")),
        (0x0020, 0x1041, "DS", f"{slice_loc:.2f}".encode("ascii")),
        (0x0028, 0x0002, "US", struct.pack("<H", 1)),
        (0x0028, 0x0004, "CS", b"MONOCHROME2"),
        (0x0028, 0x0010, "US", struct.pack("<H", rows)),
        (0x0028, 0x0011, "US", struct.pack("<H", cols)),
        (0x0028, 0x0030, "DS", f"{pixel_spacing[0]:.4f}\\{pixel_spacing[1]:.4f}".encode("ascii")),
        (0x0028, 0x0100, "US", struct.pack("<H", 16)),
        (0x0028, 0x0101, "US", struct.pack("<H", 12)),
        (0x0028, 0x0102, "US", struct.pack("<H", 11)),
        (0x0028, 0x0103, "US", struct.pack("<H", 0)),
        (0x0028, 0x1050, "DS", f"{wc:.1f}".encode("ascii")),
        (0x0028, 0x1051, "DS", f"{ww:.1f}".encode("ascii")),
        (0x0028, 0x1052, "DS", b"0.0"),
        (0x0028, 0x1053, "DS", b"1.0"),
        (0x7FE0, 0x0010, "OW", pixel_data),
    ]
    if ti is not None:
        tags.append((0x0018, 0x0082, "DS", f"{ti:.1f}".encode("ascii")))
    return tags


def write_dcm(path: Path, data: bytes) -> Dict[str, object]:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return {
        "file": str(path.relative_to(GENERATED_DIR)),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def generate_kspace_research_fixture() -> None:
    """
    Generate a documented 2D Cartesian multi-coil k-space dataset (64x64, 4 receiver coils)
    strictly separated from the clinical DICOM archive.
    Convention: centered 2D DFT, k[ky, kx] -> ifftshift -> ifft2 -> fftshift -> RSS coil combine.
    """
    RESEARCH_DIR.mkdir(parents=True, exist_ok=True)
    n = 64
    # Create synthetic ground-truth object (shepp-like brain cross-section)
    img = [[0.0 for _ in range(n)] for _ in range(n)]
    for y in range(n):
        yn = (y - n / 2.0) / (n / 2.0)
        for x in range(n):
            xn = (x - n / 2.0) / (n / 2.0)
            if (xn / 0.72) ** 2 + (yn / 0.85) ** 2 < 1.0:
                val = 0.75
                if (xn / 0.58) ** 2 + (yn / 0.70) ** 2 < 1.0:
                    val = 1.0
                if ((abs(xn) - 0.16) / 0.10) ** 2 + (yn / 0.25) ** 2 < 1.0:
                    val = 0.35
                if ((xn + 0.25) / 0.12) ** 2 + ((yn + 0.22) / 0.12) ** 2 < 1.0:
                    val = 1.45
                img[y][x] = val

    # 4 coil sensitivity profiles (quadrature surface coils)
    coil_centers = [(-0.8, 0.0), (0.8, 0.0), (0.0, -0.8), (0.0, 0.8)]
    coils_kspace = []
    for cx, cy in coil_centers:
        # Compute 2D centered DFT directly (N=64 is fast!)
        coil_img_re = [[0.0] * n for _ in range(n)]
        coil_img_im = [[0.0] * n for _ in range(n)]
        for y in range(n):
            yn = (y - n / 2.0) / (n / 2.0)
            for x in range(n):
                xn = (x - n / 2.0) / (n / 2.0)
                dist2 = (xn - cx) ** 2 + (yn - cy) ** 2
                sens = math.exp(-dist2 * 1.1)
                phase = 0.6 * (xn * cy - yn * cx)
                coil_img_re[y][x] = img[y][x] * sens * math.cos(phase)
                coil_img_im[y][x] = img[y][x] * sens * math.sin(phase)

        # Row 1D DFT then Col 1D DFT (shifted so k=0 is at index N/2)
        half = n // 2
        row_re = [[0.0] * n for _ in range(n)]
        row_im = [[0.0] * n for _ in range(n)]
        for y in range(n):
            for kx in range(n):
                k_freq = kx - half
                s_re = 0.0
                s_im = 0.0
                for x in range(n):
                    ang = -2.0 * math.pi * k_freq * (x - half) / n
                    ca, sa = math.cos(ang), math.sin(ang)
                    s_re += coil_img_re[y][x] * ca - coil_img_im[y][x] * sa
                    s_im += coil_img_re[y][x] * sa + coil_img_im[y][x] * ca
                row_re[y][kx] = s_re / n
                row_im[y][kx] = s_im / n

        k_re = [[0.0] * n for _ in range(n)]
        k_im = [[0.0] * n for _ in range(n)]
        for ky in range(n):
            k_freq = ky - half
            for kx in range(n):
                s_re = 0.0
                s_im = 0.0
                for y in range(n):
                    ang = -2.0 * math.pi * k_freq * (y - half) / n
                    ca, sa = math.cos(ang), math.sin(ang)
                    s_re += row_re[y][kx] * ca - row_im[y][kx] * sa
                    s_im += row_re[y][kx] * sa + row_im[y][kx] * ca
                k_re[ky][kx] = round(s_re / n, 6)
                k_im[ky][kx] = round(s_im / n, 6)

        coils_kspace.append({"coil_index": len(coils_kspace), "real": k_re, "imag": k_im})

    dataset = {
        "dataset_id": "SYNTH_CARTESIAN_BRAIN_64X64_4COIL",
        "title": "Synthetic 2D Cartesian Multi-Coil k-Space Phantom",
        "disclaimer": "RESEARCH ONLY — Not for clinical diagnostic use. Synthetic mathematical phantom; never derived from clinical magnitude DICOMs.",
        "matrix_size": [n, n],
        "coil_count": 4,
        "sampling": "Full 2D Cartesian (phase-encode ky x frequency-encode kx)",
        "fft_convention": "Centered k-space (DC at [N/2, N/2]); reconstruct via ifftshift -> 2D ifft2 -> fftshift",
        "scaling_note": "Unitary 1/N forward normalization; inverse scales by N and combines coils via Root-Sum-of-Squares (RSS)",
        "coils": coils_kspace,
    }
    (RESEARCH_DIR / "kspace_cartesian_2d.json").write_text(json.dumps(dataset))


def main() -> None:
    if GENERATED_DIR.exists():
        shutil.rmtree(GENERATED_DIR)
    GENERATED_DIR.mkdir(parents=True, exist_ok=True)

    manifest = []
    base_uid = "1.2.826.0.1.3680043.10.900"

    # 1. STUDY 1: Elena Vance-Sterling (Synthetic) — Volumetric Brain MRI
    study1 = f"{base_uid}.1001"
    for1 = f"{base_uid}.99.1001"
    rows, cols = 96, 96  # Compact & crisp 96x96 slices for instant APK asset + fast Docker load

    # Series 1: 3D T1 MPRAGE Axial (16 slices, Z from -22.5 to +22.5 step 3.0mm)
    s1_uid = f"{study1}.1"
    for i in range(16):
        z = -22.5 + i * 3.0
        sop = f"{s1_uid}.{i+1}"
        px = generate_brain_slice(rows, cols, z, "T1", lesion_radius_mm=9.5)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study1,
            study_id="ST1001",
            study_desc="MRI BRAIN W/O CONTRAST VOLUMETRIC",
            study_date="20261115",
            study_time="091530",
            accession="ACC-2026-0419",
            series_uid=s1_uid,
            series_num=1,
            series_desc="SAG_AX_T1_MPRAGE_3D",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="GR",
            acq_type="3D",
            tr=2100.0,
            te=3.2,
            ti=900.0,
            flip=9.0,
            slice_thickness=3.0,
            slice_spacing=3.0,
            ipp=(-72.0, -72.0, z),
            iop=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            for_uid=for1,
            slice_loc=z,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=700.0,
            ww=1400.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_1_brain_current" / "series_1_t1_3d" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # Series 2: T2 TSE Axial (12 slices)
    s2_uid = f"{study1}.2"
    for i in range(12):
        z = -22.0 + i * 4.0
        sop = f"{s2_uid}.{i+1}"
        px = generate_brain_slice(rows, cols, z, "T2", lesion_radius_mm=9.5)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study1,
            study_id="ST1001",
            study_desc="MRI BRAIN W/O CONTRAST VOLUMETRIC",
            study_date="20261115",
            study_time="091530",
            accession="ACC-2026-0419",
            series_uid=s2_uid,
            series_num=2,
            series_desc="AX_T2_TSE",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="SE",
            acq_type="2D",
            tr=4200.0,
            te=102.0,
            ti=None,
            flip=150.0,
            slice_thickness=4.0,
            slice_spacing=4.0,
            ipp=(-72.0, -72.0, z),
            iop=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            for_uid=for1,
            slice_loc=z,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=950.0,
            ww=1900.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_1_brain_current" / "series_2_t2_tse" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # Series 3: FLAIR Axial (12 slices)
    s3_uid = f"{study1}.3"
    for i in range(12):
        z = -22.0 + i * 4.0
        sop = f"{s3_uid}.{i+1}"
        px = generate_brain_slice(rows, cols, z, "FLAIR", lesion_radius_mm=9.5)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study1,
            study_id="ST1001",
            study_desc="MRI BRAIN W/O CONTRAST VOLUMETRIC",
            study_date="20261115",
            study_time="091530",
            accession="ACC-2026-0419",
            series_uid=s3_uid,
            series_num=3,
            series_desc="AX_T2_FLAIR_FS",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="IR",
            acq_type="2D",
            tr=9000.0,
            te=120.0,
            ti=2500.0,
            flip=150.0,
            slice_thickness=4.0,
            slice_spacing=4.0,
            ipp=(-72.0, -72.0, z),
            iop=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            for_uid=for1,
            slice_loc=z,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=850.0,
            ww=1750.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_1_brain_current" / "series_3_flair" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # Series 4: 3-Plane Localizer (3 orthogonal scouts — LOCALIZER)
    s4_uid = f"{study1}.4"
    scout_orientations = [
        (1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
        (1.0, 0.0, 0.0, 0.0, 0.0, -1.0),
        (0.0, 1.0, 0.0, 0.0, 0.0, -1.0),
    ]
    for i, iop in enumerate(scout_orientations):
        sop = f"{s4_uid}.{i+1}"
        px = generate_brain_slice(rows, cols, 0.0, "LOCALIZER", lesion_radius_mm=9.5)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study1,
            study_id="ST1001",
            study_desc="MRI BRAIN W/O CONTRAST VOLUMETRIC",
            study_date="20261115",
            study_time="091530",
            accession="ACC-2026-0419",
            series_uid=s4_uid,
            series_num=4,
            series_desc="3_PLANE_LOCALIZER",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\LOCALIZER",
            seq="GR",
            acq_type="2D",
            tr=8.6,
            te=3.1,
            ti=None,
            flip=20.0,
            slice_thickness=8.0,
            slice_spacing=10.0,
            ipp=(-72.0, -72.0, 0.0),
            iop=iop,
            for_uid=for1,
            slice_loc=0.0,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=700.0,
            ww=1400.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_1_brain_current" / "series_4_localizer" / f"scout_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # Series 5: Oblique Acquisition (30 degrees rotated around X)
    s5_uid = f"{study1}.5"
    ang = math.radians(30.0)
    iop_obl = (1.0, 0.0, 0.0, 0.0, math.cos(ang), math.sin(ang))
    normal_obl = (0.0, -math.sin(ang), math.cos(ang))
    for i in range(12):
        d = -16.5 + i * 3.0
        sop = f"{s5_uid}.{i+1}"
        ipp_obl = (-72.0, -72.0 * math.cos(ang) + d * normal_obl[1], -72.0 * math.sin(ang) + d * normal_obl[2])
        px = generate_brain_slice(rows, cols, d, "T1", lesion_radius_mm=9.5, angle_rad=ang)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study1,
            study_id="ST1001",
            study_desc="MRI BRAIN W/O CONTRAST VOLUMETRIC",
            study_date="20261115",
            study_time="091530",
            accession="ACC-2026-0419",
            series_uid=s5_uid,
            series_num=5,
            series_desc="OBLIQUE_30DEG_AX_COR_T1",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="GR",
            acq_type="3D",
            tr=2050.0,
            te=3.4,
            ti=900.0,
            flip=9.0,
            slice_thickness=3.0,
            slice_spacing=3.0,
            ipp=ipp_obl,
            iop=iop_obl,
            for_uid=for1,
            slice_loc=d,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=700.0,
            ww=1400.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_1_brain_current" / "series_5_oblique" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # 2. STUDY 2: Comparison Study (-6 Mo) for Elena Vance-Sterling
    study2 = f"{base_uid}.1002"
    for2 = f"{base_uid}.99.1002"
    s2_1_uid = f"{study2}.1"
    for i in range(16):
        z = -20.5 + i * 3.0  # Shifted +2mm Z, +3mm X, -2mm Y relative to current study
        sop = f"{s2_1_uid}.{i+1}"
        px = generate_brain_slice(rows, cols, z - 2.0, "T1", lesion_radius_mm=6.2)
        tags = make_mr_tags(
            patient_name="VANCE-STERLING^ELENA^SYNTHETIC",
            patient_id="AUR-PT-0419",
            issuer="AUREOM_DEMO_HOSPITAL",
            birth_date="19840512",
            sex="F",
            study_uid=study2,
            study_id="ST1002",
            study_desc="MRI BRAIN W/O CONTRAST PRIOR",
            study_date="20260518",
            study_time="142010",
            accession="ACC-2026-0112",
            series_uid=s2_1_uid,
            series_num=1,
            series_desc="AX_T1_MPRAGE_PRIOR",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="GR",
            acq_type="3D",
            tr=2100.0,
            te=3.2,
            ti=900.0,
            flip=9.0,
            slice_thickness=3.0,
            slice_spacing=3.0,
            ipp=(-69.0, -74.0, z),
            iop=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            for_uid=for2,
            slice_loc=z,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.5, 1.5),
            wc=700.0,
            ww=1400.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_2_brain_prior" / "series_1_t1_prior" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # 3. STUDY 3: Marcus Chen-Demo (Synthetic) — Knee with missing slice gap & duplicate position
    study3 = f"{base_uid}.1003"
    for3 = f"{base_uid}.99.1003"
    s3_1_uid = f"{study3}.1"
    # Deliberate geometry anomaly: positions [-12, -8, -8 (duplicate!), 4 (12mm gap!), 8, 12]
    anomaly_positions = [-12.0, -8.0, -8.0, 4.0, 8.0, 12.0]
    for i, x_pos in enumerate(anomaly_positions):
        sop = f"{s3_1_uid}.{i+1}"
        px = generate_knee_slice(rows, cols, i)
        tags = make_mr_tags(
            patient_name="CHEN-DEMO^MARCUS^SYNTHETIC",
            patient_id="AUR-PT-0882",
            issuer="AUREOM_ORTHO_CLINIC",
            birth_date="19911003",
            sex="M",
            study_uid=study3,
            study_id="ST1003",
            study_desc="MRI RIGHT KNEE GEOMETRY ANOMALY",
            study_date="20261119",
            study_time="114500",
            accession="ACC-2026-0882",
            series_uid=s3_1_uid,
            series_num=1,
            series_desc="SAG_PD_FS_KNEE_GAPPED",
            sop_uid=sop,
            instance_num=i + 1,
            image_type="ORIGINAL\\PRIMARY\\M\\ND",
            seq="SE",
            acq_type="2D",
            tr=3100.0,
            te=32.0,
            ti=None,
            flip=140.0,
            slice_thickness=4.0,
            slice_spacing=4.0,
            ipp=(x_pos, -60.0, 60.0),
            iop=(0.0, 1.0, 0.0, 0.0, 0.0, -1.0),
            for_uid=for3,
            slice_loc=x_pos,
            rows=rows,
            cols=cols,
            pixel_spacing=(1.4, 1.4),
            wc=750.0,
            ww=1500.0,
            pixel_data=px,
        )
        manifest.append(write_dcm(GENERATED_DIR / "study_3_knee_anomaly" / "series_1_pd_gapped" / f"slice_{i+1:03d}.dcm", build_dicom_part10(tags, sop_instance_uid=sop)))

    # 4. Unsupported Transfer Syntax fixture (JPEG 2000 1.2.840.10008.1.2.4.90)
    unsup_sop = f"{base_uid}.9999.1"
    unsup_tags = make_mr_tags(
        patient_name="TEST^UNSUPPORTED_TS^SYNTHETIC",
        patient_id="AUR-PT-9901",
        issuer="AUREOM_QA_LAB",
        birth_date="19750101",
        sex="O",
        study_uid=f"{base_uid}.9999",
        study_id="ST9999",
        study_desc="UNSUPPORTED TRANSFER SYNTAX FIXTURE",
        study_date="20261120",
        study_time="080000",
        accession="ACC-QA-9901",
        series_uid=f"{base_uid}.9999.1",
        series_num=1,
        series_desc="J2K_COMPRESSED_MR",
        sop_uid=unsup_sop,
        instance_num=1,
        image_type="ORIGINAL\\PRIMARY\\M\\ND",
        seq="SE",
        acq_type="2D",
        tr=500.0,
        te=15.0,
        ti=None,
        flip=90.0,
        slice_thickness=5.0,
        slice_spacing=5.0,
        ipp=(0.0, 0.0, 0.0),
        iop=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
        for_uid=f"{base_uid}.99.9999",
        slice_loc=0.0,
        rows=rows,
        cols=cols,
        pixel_spacing=(1.5, 1.5),
        wc=500.0,
        ww=1000.0,
        pixel_data=b"\xff\x4f\xff\x51\x00\x2f\x00\x00",  # J2K SOC/SIZ stub marker
    )
    manifest.append(
        write_dcm(
            GENERATED_DIR / "edge_cases" / "unsupported_j2k.dcm",
            build_dicom_part10(unsup_tags, transfer_syntax_uid="1.2.840.10008.1.2.4.90", sop_instance_uid=unsup_sop),
        )
    )

    # 5. Malformed Truncated DICOM fixture
    valid_bytes = (GENERATED_DIR / "study_1_brain_current" / "series_1_t1_3d" / "slice_001.dcm").read_bytes()
    manifest.append(write_dcm(GENERATED_DIR / "edge_cases" / "malformed_truncated.dcm", valid_bytes[:420]))

    # Write manifest & provenance
    provenance = {
        "provenance": "100% synthetic mathematical phantom objects generated deterministically by backend/fixtures/generate_fixtures.py. Contains zero real patient data or clinical PHI.",
        "files_count": len(manifest),
        "files": manifest,
    }
    (GENERATED_DIR / "manifest.json").write_text(json.dumps(provenance, indent=2))

    # Research k-space dataset
    generate_kspace_research_fixture()

    # Copy fixtures to Android app/src/main/assets/fixtures for bundled standalone demonstration
    if ANDROID_ASSETS_DIR.exists():
        shutil.rmtree(ANDROID_ASSETS_DIR)
    shutil.copytree(GENERATED_DIR, ANDROID_ASSETS_DIR)
    shutil.copy2(RESEARCH_DIR / "kspace_cartesian_2d.json", ANDROID_ASSETS_DIR / "kspace_cartesian_2d.json")
    print(f"Generated {len(manifest)} DICOM fixtures + research k-space dataset.")


if __name__ == "__main__":
    main()
