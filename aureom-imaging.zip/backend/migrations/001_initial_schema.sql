-- AUREOM IMAGING — PostgreSQL Initial Schema (001)
-- Separates Patient, Study, Series, Instance, Annotation, Report, Review, Transfer, and Audit records.

CREATE TABLE IF NOT EXISTS organisations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    issuing_authority TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('radiologist', 'technologist', 'researcher', 'admin')),
    organisation_id TEXT NOT NULL REFERENCES organisations(id),
    password_hash TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patients (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    issuing_authority TEXT NOT NULL,
    patient_name TEXT NOT NULL,
    birth_date TEXT,
    sex TEXT,
    organisation_id TEXT NOT NULL REFERENCES organisations(id),
    is_synthetic_demo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (patient_id, issuing_authority)
);

CREATE TABLE IF NOT EXISTS user_patient_access (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    patient_record_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    access_level TEXT NOT NULL CHECK (access_level IN ('read', 'annotate', 'report', 'admin')),
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, patient_record_id)
);

CREATE TABLE IF NOT EXISTS studies (
    study_instance_uid TEXT PRIMARY KEY,
    patient_record_id TEXT NOT NULL REFERENCES patients(id),
    study_id TEXT,
    accession_number TEXT,
    accession_issuer TEXT,
    study_description TEXT NOT NULL,
    study_date TEXT NOT NULL,
    study_time TEXT NOT NULL,
    frame_of_reference_uid TEXT,
    source_system TEXT NOT NULL,
    transfer_status TEXT NOT NULL CHECK (transfer_status IN ('COMPLETE', 'PARTIAL', 'FAILED', 'RETRIEVING', 'LOCAL_IMPORT')),
    image_availability TEXT NOT NULL CHECK (image_availability IN ('AVAILABLE', 'PARTIAL', 'UNAVAILABLE')),
    technical_review_status TEXT NOT NULL CHECK (technical_review_status IN ('PENDING', 'PASSED', 'GEOMETRY_WARNING', 'REJECTED')),
    clinical_review_status TEXT NOT NULL CHECK (clinical_review_status IN ('UNREAD', 'DRAFT_REPORT', 'IN_REVIEW', 'FINAL_SIGNED', 'AMENDED')),
    series_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS series (
    series_instance_uid TEXT PRIMARY KEY,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    series_number INTEGER,
    modality TEXT NOT NULL,
    source_description TEXT NOT NULL,
    inferred_sequence_label TEXT,
    classification_source TEXT NOT NULL DEFAULT 'UNCLASSIFIED',
    classification_confidence DOUBLE PRECISION,
    is_localiser BOOLEAN NOT NULL DEFAULT FALSE,
    is_volumetric_compatible BOOLEAN NOT NULL DEFAULT FALSE,
    geometry_status TEXT NOT NULL,
    geometry_warnings_json TEXT NOT NULL DEFAULT '[]',
    slice_count INTEGER NOT NULL DEFAULT 0,
    rows INTEGER,
    columns INTEGER,
    pixel_spacing TEXT,
    slice_thickness DOUBLE PRECISION,
    slice_spacing DOUBLE PRECISION,
    repetition_time DOUBLE PRECISION,
    echo_time DOUBLE PRECISION,
    inversion_time DOUBLE PRECISION,
    flip_angle DOUBLE PRECISION,
    magnetic_field_strength DOUBLE PRECISION,
    rescale_slope DOUBLE PRECISION DEFAULT 1.0,
    rescale_intercept DOUBLE PRECISION DEFAULT 0.0,
    quantity_label TEXT DEFAULT 'Arbitrary MR Signal Intensity',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS instances (
    sop_instance_uid TEXT PRIMARY KEY,
    series_instance_uid TEXT NOT NULL REFERENCES series(series_instance_uid) ON DELETE CASCADE,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    sop_class_uid TEXT NOT NULL,
    transfer_syntax_uid TEXT NOT NULL,
    instance_number INTEGER,
    image_position_patient TEXT,
    image_orientation_patient TEXT,
    slice_location DOUBLE PRECISION,
    rows INTEGER NOT NULL,
    columns INTEGER NOT NULL,
    bits_allocated INTEGER NOT NULL,
    bits_stored INTEGER NOT NULL,
    pixel_representation INTEGER NOT NULL,
    photometric_interpretation TEXT NOT NULL,
    window_center DOUBLE PRECISION,
    window_width DOUBLE PRECISION,
    rescale_slope DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    rescale_intercept DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    sha256_checksum TEXT NOT NULL,
    storage_rel_path TEXT NOT NULL,
    byte_size BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (sop_instance_uid, sha256_checksum)
);

CREATE TABLE IF NOT EXISTS annotations (
    id TEXT PRIMARY KEY,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    series_instance_uid TEXT NOT NULL REFERENCES series(series_instance_uid) ON DELETE CASCADE,
    sop_instance_uid TEXT,
    author_id TEXT NOT NULL REFERENCES users(id),
    author_name TEXT NOT NULL,
    measurement_type TEXT NOT NULL CHECK (measurement_type IN ('LENGTH', 'ANGLE', 'ROI_ELLIPSE', 'ROI_FREEHAND', 'TEXT_NOTE', 'ARROW', 'CONTOUR')),
    coordinate_system TEXT NOT NULL CHECK (coordinate_system IN ('IMAGE_PIXEL_2D', 'PATIENT_LPS_3D', 'MPR_OBLIQUE_PLANE')),
    is_reconstructed_plane BOOLEAN NOT NULL DEFAULT FALSE,
    plane_label TEXT,
    physical_units_valid BOOLEAN NOT NULL DEFAULT FALSE,
    physical_unit_label TEXT NOT NULL DEFAULT 'px',
    geometry_json TEXT NOT NULL,
    measured_value_text TEXT NOT NULL,
    intensity_stats_json TEXT,
    note_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_annotations_study ON annotations(study_instance_uid, series_instance_uid);

CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    author_id TEXT NOT NULL REFERENCES users(id),
    reviewer_id TEXT REFERENCES users(id),
    status TEXT NOT NULL CHECK (status IN ('DRAFT', 'IN_REVIEW', 'SIGNED', 'AMENDED')),
    version INTEGER NOT NULL DEFAULT 1,
    clinical_history TEXT NOT NULL DEFAULT '',
    technique_text TEXT NOT NULL DEFAULT '',
    findings_text TEXT NOT NULL DEFAULT '',
    impression_text TEXT NOT NULL DEFAULT '',
    examination_notes TEXT NOT NULL DEFAULT '',
    signed_by TEXT,
    signed_at TIMESTAMPTZ,
    content_sha256 TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS report_versions (
    id TEXT PRIMARY KEY,
    report_id TEXT NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    status TEXT NOT NULL,
    editor_id TEXT NOT NULL REFERENCES users(id),
    snapshot_json TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS report_amendments (
    id TEXT PRIMARY KEY,
    report_id TEXT NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    author_id TEXT NOT NULL REFERENCES users(id),
    reason TEXT NOT NULL,
    amendment_text TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS review_tasks (
    id TEXT PRIMARY KEY,
    study_instance_uid TEXT NOT NULL REFERENCES studies(study_instance_uid) ON DELETE CASCADE,
    assigned_to TEXT REFERENCES users(id),
    task_type TEXT NOT NULL CHECK (task_type IN ('TECHNICAL_QA', 'PRIMARY_READ', 'PEER_REVIEW', 'FOLLOW_UP')),
    status TEXT NOT NULL CHECK (status IN ('OPEN', 'IN_PROGRESS', 'COMPLETED', 'DISMISSED')),
    due_date TEXT,
    notes TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transfer_jobs (
    id TEXT PRIMARY KEY,
    study_instance_uid TEXT,
    source_type TEXT NOT NULL CHECK (source_type IN ('LOCAL_DOCUMENT', 'LOCAL_ARCHIVE', 'DICOMWEB')),
    source_uri TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('QUEUED', 'IN_PROGRESS', 'PAUSED', 'CANCELLED', 'FAILED', 'COMPLETED')),
    total_objects INTEGER NOT NULL DEFAULT 0,
    completed_objects INTEGER NOT NULL DEFAULT 0,
    bytes_transferred BIGINT NOT NULL DEFAULT 0,
    error_message TEXT,
    created_by TEXT REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY,
    actor_id TEXT,
    actor_username TEXT,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    study_instance_uid TEXT,
    outcome TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS retention_policies (
    id TEXT PRIMARY KEY,
    organisation_id TEXT NOT NULL REFERENCES organisations(id),
    original_retention_days INTEGER NOT NULL DEFAULT 2555,
    derived_cache_days INTEGER NOT NULL DEFAULT 30,
    device_cache_max_age_hours INTEGER NOT NULL DEFAULT 24,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
