"""
Pure-Python DICOM Part 10 parser, validator, sequence classifier, and geometry analyzer
for AUREOM IMAGING.
Supports documented single-frame MR objects in Explicit/Implicit VR Little Endian.
"""

import hashlib
import math
import statistics
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

SUPPORTED_TRANSFER_SYNTAXES = {
    "1.2.840.10008.1.2": "Implicit VR Little Endian",
    "1.2.840.10008.1.2.1": "Explicit VR Little Endian",
}

MR_IMAGE_STORAGE_SOP_CLASS = "1.2.840.10008.5.1.4.1.1.4"
ENHANCED_MR_SOP_CLASS = "1.2.840.10008.5.1.4.1.1.4.1"
LONG_VRS = {b"OB", b"OD", b"OF", b"OL", b"OW", b"SQ", b"UC", b"UR", b"UT", b"UN"}


class DicomValidationError(Exception):
    def __init__(self, code: str, message: str, remediation: str):
        super().__init__(message)
        self.code = code
        self.message = message
        self.remediation = remediation


@dataclass
class ParsedDicomInstance:
    sop_instance_uid: str
    sop_class_uid: str
    transfer_syntax_uid: str
    study_instance_uid: str
    series_instance_uid: str
    patient_id: str
    issuer_of_patient_id: str
    patient_name: str
    patient_birth_date: str
    patient_sex: str
    study_id: str
    accession_number: str
    study_description: str
    study_date: str
    study_time: str
    series_number: int
    series_description: str
    modality: str
    image_type: str
    scanning_sequence: str
    mr_acquisition_type: str
    repetition_time: Optional[float]
    echo_time: Optional[float]
    inversion_time: Optional[float]
    flip_angle: Optional[float]
    magnetic_field_strength: Optional[float]
    slice_thickness: Optional[float]
    slice_spacing: Optional[float]
    instance_number: int
    image_position_patient: Optional[Tuple[float, float, float]]
    image_orientation_patient: Optional[Tuple[float, float, float, float, float, float]]
    frame_of_reference_uid: str
    slice_location: Optional[float]
    rows: int
    columns: int
    pixel_spacing: Optional[Tuple[float, float]]
    bits_allocated: int
    bits_stored: int
    pixel_representation: int
    photometric_interpretation: str
    window_center: Optional[float]
    window_width: Optional[float]
    rescale_slope: float
    rescale_intercept: float
    sha256_checksum: str
    pixel_data_bytes: int


def _parse_floats(raw: str, expected: Optional[int] = None) -> Optional[Tuple[float, ...]]:
    if not raw:
        return None
    try:
        vals = tuple(float(p.strip()) for p in raw.split("\\") if p.strip() != "")
        if expected is not None and len(vals) != expected:
            return None
        return vals
    except ValueError:
        return None


def _parse_float(raw: str) -> Optional[float]:
    if not raw:
        return None
    try:
        return float(raw.split("\\")[0].strip())
    except ValueError:
        return None


def _parse_int(raw: str, default: int = 0) -> int:
    if not raw:
        return default
    try:
        return int(float(raw.split("\\")[0].strip()))
    except ValueError:
        return default


def parse_dicom_part10(data: bytes) -> ParsedDicomInstance:
    if len(data) < 136 or data[128:132] != b"DICM":
        raise DicomValidationError(
            "MALFORMED_PREAMBLE",
            "File is missing the 128-byte DICOM preamble and 'DICM' magic header.",
            "Export a valid DICOM Part 10 (.dcm) file from the scanner or archive.",
        )

    offset = 132
    tags: Dict[Tuple[int, int], bytes] = {}
    in_meta = True
    transfer_syntax_uid = "1.2.840.10008.1.2.1"

    while offset + 4 <= len(data):
        group, elem = struct.unpack_from("<HH", data, offset)
        if group == 0xFFFE:
            # Skip sequence delimiters if any
            if offset + 8 > len(data):
                break
            length = struct.unpack_from("<I", data, offset + 4)[0]
            offset += 8 + (0 if length == 0xFFFFFFFF else length)
            continue

        if group != 0x0002 and in_meta:
            in_meta = False
            ts_raw = tags.get((0x0002, 0x0010), b"").decode("ascii", errors="ignore").strip("\x00 ")
            if ts_raw:
                transfer_syntax_uid = ts_raw
            if transfer_syntax_uid not in SUPPORTED_TRANSFER_SYNTAXES:
                raise DicomValidationError(
                    "UNSUPPORTED_TRANSFER_SYNTAX",
                    f"Unsupported Transfer Syntax UID '{transfer_syntax_uid}'.",
                    "Supported syntaxes: Implicit VR Little Endian (1.2.840.10008.1.2) and Explicit VR Little Endian (1.2.840.10008.1.2.1). Transcode compressed objects before import.",
                )

        is_explicit = in_meta or transfer_syntax_uid == "1.2.840.10008.1.2.1"
        if is_explicit:
            if offset + 8 > len(data):
                raise DicomValidationError(
                    "TRUNCATED_OBJECT",
                    f"Unexpected end of file reading tag ({group:04X},{elem:04X}).",
                    "Re-retrieve the complete DICOM object; the file appears truncated.",
                )
            vr = data[offset + 4 : offset + 6]
            if vr in LONG_VRS:
                if offset + 12 > len(data):
                    raise DicomValidationError(
                        "TRUNCATED_OBJECT",
                        f"Truncated extended VR header at ({group:04X},{elem:04X}).",
                        "Re-export or re-retrieve the DICOM file.",
                    )
                length = struct.unpack_from("<I", data, offset + 8)[0]
                val_start = offset + 12
            else:
                length = struct.unpack_from("<H", data, offset + 6)[0]
                val_start = offset + 8
        else:
            if offset + 8 > len(data):
                raise DicomValidationError(
                    "TRUNCATED_OBJECT",
                    f"Truncated implicit VR header at ({group:04X},{elem:04X}).",
                    "Re-retrieve the DICOM object.",
                )
            length = struct.unpack_from("<I", data, offset + 4)[0]
            val_start = offset + 8

        if length == 0xFFFFFFFF:
            raise DicomValidationError(
                "UNSUPPORTED_UNDEFINED_LENGTH",
                f"Encapsulated or undefined-length element ({group:04X},{elem:04X}) is not supported in the initial single-frame MR subset.",
                "Use uncompressed single-frame MR DICOM objects.",
            )

        val_end = val_start + length
        if val_end > len(data):
            raise DicomValidationError(
                "TRUNCATED_PAYLOAD",
                f"Tag ({group:04X},{elem:04X}) declares {length} bytes, but only {len(data) - val_start} bytes remain.",
                "File transfer was interrupted or truncated. Cancel and retry transfer.",
            )

        tags[(group, elem)] = data[val_start:val_end]
        offset = val_end
        if (group, elem) == (0x7FE0, 0x0010):
            break

    def get_str(g: int, e: int, default: str = "") -> str:
        raw = tags.get((g, e))
        if raw is None:
            return default
        return raw.decode("latin-1", errors="replace").strip("\x00 ").strip()

    def get_us(g: int, e: int, default: int = 0) -> int:
        raw = tags.get((g, e))
        if raw is None or len(raw) < 2:
            return default
        return struct.unpack_from("<H", raw, 0)[0]

    modality = get_str(0x0008, 0x0060)
    if modality != "MR":
        raise DicomValidationError(
            "UNSUPPORTED_MODALITY",
            f"Modality '{modality or 'UNKNOWN'}' is outside the MR workspace scope.",
            "Import MR modality DICOM objects only.",
        )

    sop_class_uid = get_str(0x0008, 0x0016) or get_str(0x0002, 0x0002)
    if sop_class_uid == ENHANCED_MR_SOP_CLASS:
        raise DicomValidationError(
            "ENHANCED_MR_MILESTONE_PENDING",
            "Enhanced MR Image Storage (1.2.840.10008.5.1.4.1.1.4.1) requires the multiframe milestone adapter.",
            "Split into single-frame MR Image Storage objects (1.2.840.10008.5.1.4.1.1.4) or enable multiframe converter.",
        )

    sop_uid = get_str(0x0008, 0x0018)
    series_uid = get_str(0x0020, 0x000E)
    study_uid = get_str(0x0020, 0x000D)
    if not sop_uid or not series_uid or not study_uid:
        raise DicomValidationError(
            "MISSING_UIDS",
            "Missing required StudyInstanceUID, SeriesInstanceUID, or SOPInstanceUID.",
            "Ensure DICOM tags (0020,000D), (0020,000E), and (0008,0018) are populated.",
        )

    rows = get_us(0x0028, 0x0010)
    cols = get_us(0x0028, 0x0011)
    bits_allocated = get_us(0x0028, 0x0100, 16)
    bits_stored = get_us(0x0028, 0x0101, bits_allocated)
    pixel_rep = get_us(0x0028, 0x0103, 0)
    photometric = get_str(0x0028, 0x0004, "MONOCHROME2")
    if photometric not in {"MONOCHROME1", "MONOCHROME2"}:
        raise DicomValidationError(
            "UNSUPPORTED_PHOTOMETRIC",
            f"Unsupported Photometric Interpretation '{photometric}'.",
            "Only MONOCHROME1 and MONOCHROME2 single-frame MR objects are supported.",
        )

    pixel_bytes = tags.get((0x7FE0, 0x0010), b"")
    expected_bytes = rows * cols * (bits_allocated // 8)
    if rows <= 0 or cols <= 0 or len(pixel_bytes) < expected_bytes:
        raise DicomValidationError(
            "INVALID_PIXEL_DATA",
            f"Pixel data size mismatch: expected at least {expected_bytes} bytes for {rows}x{cols} ({bits_allocated}-bit), got {len(pixel_bytes)}.",
            "Re-import an intact uncompressed MR DICOM file.",
        )

    ipp = _parse_floats(get_str(0x0020, 0x0032), 3)
    iop = _parse_floats(get_str(0x0020, 0x0037), 6)
    ps = _parse_floats(get_str(0x0028, 0x0030), 2)

    return ParsedDicomInstance(
        sop_instance_uid=sop_uid,
        sop_class_uid=sop_class_uid,
        transfer_syntax_uid=transfer_syntax_uid,
        study_instance_uid=study_uid,
        series_instance_uid=series_uid,
        patient_id=get_str(0x0010, 0x0020, "UNKNOWN"),
        issuer_of_patient_id=get_str(0x0010, 0x0021, "UNSPECIFIED_ISSUER"),
        patient_name=get_str(0x0010, 0x0010, "UNIDENTIFIED"),
        patient_birth_date=get_str(0x0010, 0x0030),
        patient_sex=get_str(0x0010, 0x0040),
        study_id=get_str(0x0020, 0x0010),
        accession_number=get_str(0x0008, 0x0050),
        study_description=get_str(0x0008, 0x1030, "MR Examination"),
        study_date=get_str(0x0008, 0x0020, "19700101"),
        study_time=get_str(0x0008, 0x0030, "000000"),
        series_number=_parse_int(get_str(0x0020, 0x0011), 0),
        series_description=get_str(0x0008, 0x103E, "Unnamed Series"),
        modality=modality,
        image_type=get_str(0x0008, 0x0008),
        scanning_sequence=get_str(0x0018, 0x0020),
        mr_acquisition_type=get_str(0x0018, 0x0023),
        repetition_time=_parse_float(get_str(0x0018, 0x0080)),
        echo_time=_parse_float(get_str(0x0018, 0x0081)),
        inversion_time=_parse_float(get_str(0x0018, 0x0082)),
        flip_angle=_parse_float(get_str(0x0018, 0x1314)),
        magnetic_field_strength=_parse_float(get_str(0x0018, 0x0087)),
        slice_thickness=_parse_float(get_str(0x0018, 0x0050)),
        slice_spacing=_parse_float(get_str(0x0018, 0x0088)),
        instance_number=_parse_int(get_str(0x0020, 0x0013), 0),
        image_position_patient=ipp,  # type: ignore[arg-type]
        image_orientation_patient=iop,  # type: ignore[arg-type]
        frame_of_reference_uid=get_str(0x0020, 0x0052),
        slice_location=_parse_float(get_str(0x0020, 0x1041)),
        rows=rows,
        columns=cols,
        pixel_spacing=ps,  # type: ignore[arg-type]
        bits_allocated=bits_allocated,
        bits_stored=bits_stored,
        pixel_representation=pixel_rep,
        photometric_interpretation=photometric,
        window_center=_parse_float(get_str(0x0028, 0x1050)),
        window_width=_parse_float(get_str(0x0028, 0x1051)),
        rescale_slope=_parse_float(get_str(0x0028, 0x1053)) or 1.0,
        rescale_intercept=_parse_float(get_str(0x0028, 0x1052)) or 0.0,
        sha256_checksum=hashlib.sha256(data).hexdigest(),
        pixel_data_bytes=len(pixel_bytes),
    )


def classify_mr_series(inst: ParsedDicomInstance) -> Tuple[Optional[str], str, float]:
    """
    Distinguishes source-provided series descriptions from explicitly supported sequence labels.
    Returns (inferred_label, classification_source, confidence).
    """
    desc = inst.series_description.upper()
    img_type = inst.image_type.upper()
    if "LOCALIZER" in img_type or "LOCALIZER" in desc or "SCOUT" in desc:
        return ("Localiser / Scout", "DICOM_IMAGE_TYPE_TAG", 0.99)
    if "ADC" in desc:
        return ("ADC Map", "SOURCE_DESCRIPTION_AND_PARAMS", 0.95)
    if "DWI" in desc or "DIFF" in desc or "EP" in inst.scanning_sequence.upper():
        return ("Diffusion-Weighted", "SOURCE_DESCRIPTION_AND_PARAMS", 0.90)
    if "FLAIR" in desc or (inst.inversion_time and inst.inversion_time >= 1800.0 and (inst.echo_time or 0) >= 80.0):
        return ("FLAIR", "TI_TE_TR_METADATA", 0.94)
    if "T2" in desc or ((inst.repetition_time or 0) >= 2500.0 and (inst.echo_time or 0) >= 70.0):
        return ("T2-Weighted", "TE_TR_METADATA", 0.92)
    if "T1" in desc or "MPRAGE" in desc or ((inst.repetition_time or 9999) <= 2500.0 and (inst.echo_time or 999) <= 20.0):
        return ("T1-Weighted", "TE_TR_METADATA", 0.91)
    if "PD" in desc:
        return ("Proton Density", "SOURCE_DESCRIPTION", 0.86)
    return (None, "UNCLASSIFIED", 0.0)


def _cross(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> Tuple[float, float, float]:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _dot(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def analyze_series_geometry(instances: List[Dict]) -> Dict:
    """
    Validate geometry across slices in a series using ImagePositionPatient & ImageOrientationPatient.
    Detects localisers, missing geometry, non-parallel orientations, duplicate positions, and spacing gaps.
    """
    warnings: List[str] = []
    if not instances:
        return {
            "is_localiser": False,
            "is_volumetric_compatible": False,
            "geometry_status": "EMPTY",
            "warnings": ["Series contains no instances."],
        }

    is_localiser = any("LOCALIZER" in (i.get("image_type") or "").upper() for i in instances)
    if is_localiser:
        warnings.append("Identified as Localiser / Scout series; excluded from 3D volumetric reconstruction.")
        return {
            "is_localiser": True,
            "is_volumetric_compatible": False,
            "geometry_status": "LOCALISER",
            "warnings": warnings,
        }

    # Verify dimensions & orientation consistency
    dims = {(i["rows"], i["columns"]) for i in instances}
    if len(dims) > 1:
        warnings.append(f"Mixed image matrix dimensions detected: {sorted(dims)}.")

    positions: List[Tuple[float, Tuple[float, float, float]]] = []
    ref_normal: Optional[Tuple[float, float, float]] = None

    for inst in instances:
        ipp_raw = inst.get("image_position_patient")
        iop_raw = inst.get("image_orientation_patient")
        if not ipp_raw or not iop_raw:
            warnings.append(f"Instance {inst.get('instance_number')} lacks patient-space IPP/IOP tags.")
            continue
        ipp = tuple(float(x) for x in ipp_raw.split("\\"))
        iop = tuple(float(x) for x in iop_raw.split("\\"))
        row_vec = (iop[0], iop[1], iop[2])
        col_vec = (iop[3], iop[4], iop[5])
        normal = _cross(row_vec, col_vec)
        norm_len = math.sqrt(_dot(normal, normal))
        if norm_len < 1e-4:
            warnings.append("Degenerate ImageOrientationPatient vectors.")
            continue
        normal = (normal[0] / norm_len, normal[1] / norm_len, normal[2] / norm_len)
        if ref_normal is None:
            ref_normal = normal
        else:
            if abs(_dot(ref_normal, normal)) < 0.995:
                warnings.append("Non-parallel slice orientations detected within series.")
        proj = _dot(ipp, ref_normal)
        positions.append((proj, ipp))  # type: ignore[arg-type]

    if len(positions) < 3:
        warnings.append("Fewer than 3 geometrically valid slices; cannot construct 3D volume.")
        return {
            "is_localiser": False,
            "is_volumetric_compatible": False,
            "geometry_status": "INSUFFICIENT_SLICES",
            "warnings": warnings,
        }

    positions.sort(key=lambda item: item[0])
    diffs = [positions[k + 1][0] - positions[k][0] for k in range(len(positions) - 1)]

    # Check duplicates
    if any(abs(d) < 0.05 for d in diffs):
        warnings.append("Duplicate slice positions detected along stack normal.")

    positive_diffs = [d for d in diffs if d >= 0.05]
    if positive_diffs:
        med = statistics.median(positive_diffs)
        if any(abs(d - med) > max(0.5, med * 0.35) for d in positive_diffs):
            warnings.append(
                f"Irregular slice spacing detected (median {med:.2f} mm; range {min(positive_diffs):.2f}..{max(positive_diffs):.2f} mm)."
            )

    compatible = len(warnings) == 0
    return {
        "is_localiser": False,
        "is_volumetric_compatible": compatible,
        "geometry_status": "VOLUMETRIC_VALID" if compatible else "GEOMETRY_WARNING",
        "warnings": warnings,
    }
