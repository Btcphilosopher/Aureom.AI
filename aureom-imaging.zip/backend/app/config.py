import os
import secrets
from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "AUREOM IMAGING API"
    database_url: str = os.getenv(
        "DATABASE_URL",
        "postgresql://aureom:aureom_demo_local_only@localhost:5432/aureom_imaging",
    )
    jwt_secret: str = os.getenv("JWT_SECRET") or secrets.token_urlsafe(32)
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = int(os.getenv("JWT_EXPIRE_MINUTES", "480"))
    protected_storage_dir: Path = Path(
        os.getenv("PROTECTED_STORAGE_DIR", "./data/protected_storage")
    )
    backup_dir: Path = Path(os.getenv("BACKUP_DIR", "./data/backups"))
    dicomweb_base_url: str = os.getenv(
        "DICOMWEB_BASE_URL", "http://localhost:8042/dicom-web"
    )
    dicomweb_username: str = os.getenv("DICOMWEB_USERNAME", "dicomweb_client")
    dicomweb_password: str = os.getenv("DICOMWEB_PASSWORD", "")
    ai_assist_enabled: bool = os.getenv("AI_ASSIST_ENABLED", "false").lower() == "true"
    demo_seed_on_startup: bool = os.getenv("DEMO_SEED_ON_STARTUP", "true").lower() == "true"
    allowed_origins: str = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://10.0.2.2")


settings = Settings()
