import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, Request, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field

from .ai_adapter import DeterministicMetadataAssistAdapter
from .config import settings
from .db import get_conn
from .dicom_service import (
    SUPPORTED_TRANSFER_SYNTAXES,
    DicomValidationError,
    analyze_series_geometry,
    classify_mr_series,
    parse_dicom_part10,
)
from .dicomweb_adapter import DicomWebAdapter
from .security import create_access_token, get_current_user, hash_password, require_roles, verify_password

app = FastAPI(
    title="AUREOM IMAGING — MRI Workspace API",
    version="1.0.0",
    description="Clinical-grade MRI workspace application services, DICOM ingestion, DICOMweb adapter, annotations, versioned reporting, and audit log.",
)

origins = [o.strip() for o in settings.allowed_origins.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Range", "X-AI-Assist-OptIn"],
)

ai_adapter = DeterministicMetadataAssistAdapter()


# ---- Pydantic Schemas ----

class BootstrapRequest(BaseModel):
    admin_username: str = Field(default="dr.aureom", min_length=3, max_length=64)
    admin_password: str = Field(min_length=8, max_length=128)
    display_name: str = Field(default="Dr. Claire Aureom (Radiologist)", max_length=120)


class LoginRequest(BaseModel):
    username: str
    password: str


class AnnotationCreate(BaseModel):
    series_instance_uid: str
    sop_instance_uid: Optional[str] = None
    measurement_type: str
    coordinate_system: str
    is_reconstructed_plane: bool = False
    plane_label: Optional[str] = None
    physical_units_valid: bool = False
    physical_unit_label: str = "px"
    geometry_json: str
    measured_value_text: str
    intensity_stats_json: Optional[str] = None
    note_text: Optional[str] = None


class ReportSaveRequest(BaseModel):
    expected_version: Optional[int] = None
    clinical_history: str = ""
    technique_text: str = ""
    findings_text: str = ""
    impression_text: str = ""
    examination_notes: str = ""
    reviewer_id: Optional[str] = None
    status: str = "DRAFT"


class AmendmentCreate(BaseModel):
    reason: str = Field(min_length=3, max_length=300)
    amendment_text: str = Field(min_length=3, max_length=5000)


class ReviewTaskCreate(BaseModel):
    task_type: str
    assigned_to: Optional[str] = None
    due_date: Optional[str] = None
    notes: str = ""


class AiAssistRequest(BaseModel):
    study_instance_uid: str
    action: str  # "organise_series" | "summarise_reports"


# ---- Storage & Audit Helpers ----

def _ensure_storage_dirs() -> None:
    (settings.protected_storage_dir / "originals").mkdir(parents=True, exist_ok=True)
    (settings.protected_storage_dir / "derived").mkdir(parents=True, exist_ok=True)
    settings.backup_dir.mkdir(parents=True, exist_ok=True)


def _safe_original_path(rel_path: str) -> Path:
    base = (settings.protected_storage_dir / "originals").resolve()
    target = (base / rel_path).resolve()
    if not target.is_relative_to(base):
        raise HTTPException(status_code=400, detail="Invalid storage path boundary.")
    return target


def _log_audit(
    conn,
    actor: Optional[Dict[str, Any]],
    action: str,
    resource_type: str,
    resource_id: str,
    study_uid: Optional[str] = None,
    outcome: str = "SUCCESS",
    details: Optional[Dict[str, Any]] = None,
) -> None:
    conn.execute(
        """
        INSERT INTO audit_events (id, actor_id, actor_username, action, resource_type, resource_id, study_instance_uid, outcome, details_json)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            str(uuid.uuid4()),
            actor.get("sub") if actor else None,
            actor.get("username") if actor else "system",
            action,
            resource_type,
            resource_id,
            study_uid,
            outcome,
            json.dumps(details or {}),
        ),
    )


def _assert_study_access(conn, user: Dict[str, Any], study_uid: str) -> Dict[str, Any]:
    row = conn.execute(
        """
        SELECT s.*, p.patient_id, p.issuing_authority, p.patient_name, p.organisation_id
        FROM studies s
        JOIN patients p ON p.id = s.patient_record_id
        WHERE s.study_instance_uid = %s
        """,
        (study_uid,),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Study not found.")
    if row["organisation_id"] != user["organisation_id"]:
        raise HTTPException(status_code=403, detail="Cross-organisation study access denied.")
    if user["role"] != "admin":
        access = conn.execute(
            "SELECT access_level FROM user_patient_access WHERE user_id = %s AND patient_record_id = %s",
            (user["sub"], row["patient_record_id"]),
        ).fetchone()
        if not access:
            raise HTTPException(status_code=403, detail="Patient-level access control denied.")
    return dict(row)


def ingest_dicom_bytes(conn, raw: bytes, source_system: str, actor: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    parsed = parse_dicom_part10(raw)

    # Duplicate-safe check by SOPInstanceUID + checksum
    existing = conn.execute(
        "SELECT sop_instance_uid, sha256_checksum, study_instance_uid, series_instance_uid FROM instances WHERE sop_instance_uid = %s",
        (parsed.sop_instance_uid,),
    ).fetchone()
    if existing:
        if existing["sha256_checksum"] == parsed.sha256_checksum:
            return {
                "status": "DUPLICATE_SKIPPED",
                "sop_instance_uid": parsed.sop_instance_uid,
                "study_instance_uid": existing["study_instance_uid"],
                "series_instance_uid": existing["series_instance_uid"],
            }
        raise HTTPException(
            status_code=409,
            detail=f"SOPInstanceUID collision with differing checksum for {parsed.sop_instance_uid}.",
        )

    org_id = actor["organisation_id"] if actor else "org-aureom-demo"
    # Upsert patient strictly by (patient_id, issuing_authority)
    patient_row = conn.execute(
        "SELECT id FROM patients WHERE patient_id = %s AND issuing_authority = %s",
        (parsed.patient_id, parsed.issuer_of_patient_id),
    ).fetchone()
    if not patient_row:
        patient_record_id = f"pt-{hashlib.sha1(f'{parsed.patient_id}:{parsed.issuer_of_patient_id}'.encode()).hexdigest()[:12]}"
        conn.execute(
            """
            INSERT INTO patients (id, patient_id, issuing_authority, patient_name, birth_date, sex, organisation_id, is_synthetic_demo)
            VALUES (%s, %s, %s, %s, %s, %s, %s, TRUE)
            ON CONFLICT (patient_id, issuing_authority) DO NOTHING
            """,
            (
                patient_record_id,
                parsed.patient_id,
                parsed.issuer_of_patient_id,
                parsed.patient_name,
                parsed.patient_birth_date,
                parsed.patient_sex,
                org_id,
            ),
        )
    else:
        patient_record_id = patient_row["id"]

    # Ensure uploader / org users with admin or clinician role get access in demo org
    if actor:
        conn.execute(
            """
            INSERT INTO user_patient_access (user_id, patient_record_id, access_level)
            VALUES (%s, %s, 'report') ON CONFLICT DO NOTHING
            """,
            (actor["sub"], patient_record_id),
        )

    # Upsert Study
    conn.execute(
        """
        INSERT INTO studies (
            study_instance_uid, patient_record_id, study_id, accession_number, accession_issuer,
            study_description, study_date, study_time, frame_of_reference_uid, source_system,
            transfer_status, image_availability, technical_review_status, clinical_review_status, series_count
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'AVAILABLE', 'PENDING', 'UNREAD', 0)
        ON CONFLICT (study_instance_uid) DO NOTHING
        """,
        (
            parsed.study_instance_uid,
            patient_record_id,
            parsed.study_id,
            parsed.accession_number,
            parsed.issuer_of_patient_id,
            parsed.study_description,
            parsed.study_date,
            parsed.study_time,
            parsed.frame_of_reference_uid,
            source_system,
            "LOCAL_IMPORT" if source_system == "LOCAL_DOCUMENT" else "COMPLETE",
        ),
    )

    inferred_label, cls_source, cls_conf = classify_mr_series(parsed)
    ps_str = "\\".join(f"{x:.4f}" for x in parsed.pixel_spacing) if parsed.pixel_spacing else None
    conn.execute(
        """
        INSERT INTO series (
            series_instance_uid, study_instance_uid, series_number, modality, source_description,
            inferred_sequence_label, classification_source, classification_confidence,
            is_localiser, is_volumetric_compatible, geometry_status, geometry_warnings_json,
            slice_count, rows, columns, pixel_spacing, slice_thickness, slice_spacing,
            repetition_time, echo_time, inversion_time, flip_angle, magnetic_field_strength,
            rescale_slope, rescale_intercept
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, FALSE, FALSE, 'PENDING', '[]', 0, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (series_instance_uid) DO NOTHING
        """,
        (
            parsed.series_instance_uid,
            parsed.study_instance_uid,
            parsed.series_number,
            parsed.modality,
            parsed.series_description,
            inferred_label,
            cls_source,
            cls_conf,
            parsed.rows,
            parsed.columns,
            ps_str,
            parsed.slice_thickness,
            parsed.slice_spacing,
            parsed.repetition_time,
            parsed.echo_time,
            parsed.inversion_time,
            parsed.flip_angle,
            parsed.magnetic_field_strength,
            parsed.rescale_slope,
            parsed.rescale_intercept,
        ),
    )

    # Write immutable original object into protected storage
    rel_path = f"{parsed.study_instance_uid}/{parsed.series_instance_uid}/{parsed.sop_instance_uid}.dcm"
    target_path = _safe_original_path(rel_path)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_bytes(raw)

    ipp_str = "\\".join(f"{x:.4f}" for x in parsed.image_position_patient) if parsed.image_position_patient else None
    iop_str = "\\".join(f"{x:.6f}" for x in parsed.image_orientation_patient) if parsed.image_orientation_patient else None
    conn.execute(
        """
        INSERT INTO instances (
            sop_instance_uid, series_instance_uid, study_instance_uid, sop_class_uid,
            transfer_syntax_uid, instance_number, image_position_patient, image_orientation_patient,
            slice_location, rows, columns, bits_allocated, bits_stored, pixel_representation,
            photometric_interpretation, window_center, window_width, rescale_slope, rescale_intercept,
            sha256_checksum, storage_rel_path, byte_size
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            parsed.sop_instance_uid,
            parsed.series_instance_uid,
            parsed.study_instance_uid,
            parsed.sop_class_uid,
            parsed.transfer_syntax_uid,
            parsed.instance_number,
            ipp_str,
            iop_str,
            parsed.slice_location,
            parsed.rows,
            parsed.columns,
            parsed.bits_allocated,
            parsed.bits_stored,
            parsed.pixel_representation,
            parsed.photometric_interpretation,
            parsed.window_center,
            parsed.window_width,
            parsed.rescale_slope,
            parsed.rescale_intercept,
            parsed.sha256_checksum,
            rel_path,
            len(raw),
        ),
    )

    # Recompute series geometry analysis
    series_insts = conn.execute(
        "SELECT *, %s AS image_type FROM instances WHERE series_instance_uid = %s",
        (parsed.image_type, parsed.series_instance_uid),
    ).fetchall()
    geom = analyze_series_geometry([dict(r) for r in series_insts])
    conn.execute(
        """
        UPDATE series
        SET slice_count = %s,
            is_localiser = %s,
            is_volumetric_compatible = %s,
            geometry_status = %s,
            geometry_warnings_json = %s
        WHERE series_instance_uid = %s
        """,
        (
            len(series_insts),
            geom["is_localiser"],
            geom["is_volumetric_compatible"],
            geom["geometry_status"],
            json.dumps(geom["warnings"]),
            parsed.series_instance_uid,
        ),
    )

    # Update study series_count & technical review status
    study_series = conn.execute(
        "SELECT geometry_status FROM series WHERE study_instance_uid = %s",
        (parsed.study_instance_uid,),
    ).fetchall()
    has_warn = any(s["geometry_status"] == "GEOMETRY_WARNING" for s in study_series)
    conn.execute(
        """
        UPDATE studies
        SET series_count = %s,
            technical_review_status = %s,
            updated_at = NOW()
        WHERE study_instance_uid = %s
        """,
        (
            len(study_series),
            "GEOMETRY_WARNING" if has_warn else "PASSED",
            parsed.study_instance_uid,
        ),
    )

    return {
        "status": "INGESTED",
        "sop_instance_uid": parsed.sop_instance_uid,
        "study_instance_uid": parsed.study_instance_uid,
        "series_instance_uid": parsed.series_instance_uid,
        "geometry": geom,
    }


@app.on_event("startup")
def on_startup() -> None:
    _ensure_storage_dirs()
    try:
        with get_conn() as conn:
            conn.execute(
                """
                INSERT INTO organisations (id, name, issuing_authority)
                VALUES ('org-aureom-demo', 'AUREOM Clinical MRI Demonstration Network', 'AUREOM_DEMO_HOSPITAL')
                ON CONFLICT (id) DO NOTHING
                """
            )
            conn.execute(
                """
                INSERT INTO retention_policies (id, organisation_id, original_retention_days, derived_cache_days, device_cache_max_age_hours)
                VALUES ('ret-default', 'org-aureom-demo', 2555, 30, 24)
                ON CONFLICT (id) DO NOTHING
                """
            )
            # Seed demo synthetic fixtures into database & protected storage
            if settings.demo_seed_on_startup:
                fixtures_dir = Path(__file__).resolve().parent.parent / "fixtures" / "generated"
                if fixtures_dir.exists():
                    for dcm_path in sorted(fixtures_dir.rglob("*.dcm")):
                        if "edge_cases" in dcm_path.parts:
                            continue
                        try:
                            ingest_dicom_bytes(conn, dcm_path.read_bytes(), "LOCAL_DEMO_ARCHIVE")
                        except Exception:
                            pass
            conn.commit()
    except Exception:
        # Allow app startup even if DB is temporarily unreachable during unit tests
        pass


# ---- Health & Format Matrix ----

@app.get("/health")
def health() -> Dict[str, Any]:
    return {"status": "ok", "service": settings.app_name, "ai_assist_enabled": settings.ai_assist_enabled}


@app.get("/api/v1/supported-formats")
def supported_formats() -> Dict[str, Any]:
    return {
        "supported_sop_classes": [
            {"uid": "1.2.840.10008.5.1.4.1.1.4", "name": "MR Image Storage (Single-Frame)", "status": "SUPPORTED"},
            {"uid": "1.2.840.10008.5.1.4.1.1.4.1", "name": "Enhanced MR Image Storage (Multiframe)", "status": "PLANNED_MILESTONE_2"},
        ],
        "supported_transfer_syntaxes": [
            {"uid": uid, "name": name, "status": "SUPPORTED"}
            for uid, name in SUPPORTED_TRANSFER_SYNTAXES.items()
        ],
        "unsupported_transfer_syntaxes_action": "Rejected at ingestion with actionable remediation guidance; original database records remain untouched.",
        "photometric_interpretations": ["MONOCHROME1", "MONOCHROME2"],
        "bit_depths": ["8-bit unsigned", "12/16-bit unsigned", "16-bit signed (PixelRepresentation=1)"],
    }


# ---- Organisational Auth & First-Run Claim ----

@app.get("/api/v1/auth/status")
def auth_status() -> Dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) AS cnt FROM users").fetchone()
        return {"bootstrapped": (row["cnt"] > 0) if row else False}


@app.post("/api/v1/auth/bootstrap")
def bootstrap_admin(req: BootstrapRequest) -> Dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) AS cnt FROM users").fetchone()
        if row and row["cnt"] > 0:
            raise HTTPException(status_code=409, detail="Organisational workspace is already claimed.")
        user_id = f"usr-{uuid.uuid4().hex[:10]}"
        conn.execute(
            """
            INSERT INTO users (id, username, display_name, role, organisation_id, password_hash)
            VALUES (%s, %s, %s, 'admin', 'org-aureom-demo', %s)
            """,
            (user_id, req.admin_username, req.display_name, hash_password(req.admin_password)),
        )
        # Grant initial admin access to seeded demo patients
        patients = conn.execute("SELECT id FROM patients WHERE organisation_id = 'org-aureom-demo'").fetchall()
        for pt in patients:
            conn.execute(
                "INSERT INTO user_patient_access (user_id, patient_record_id, access_level) VALUES (%s, %s, 'admin') ON CONFLICT DO NOTHING",
                (user_id, pt["id"]),
            )
        _log_audit(conn, {"sub": user_id, "username": req.admin_username}, "BOOTSTRAP_ADMIN", "user", user_id)
        conn.commit()
        user_obj = {
            "id": user_id,
            "username": req.admin_username,
            "display_name": req.display_name,
            "role": "admin",
            "organisation_id": "org-aureom-demo",
        }
        return {"access_token": create_access_token(user_obj), "token_type": "bearer", "user": user_obj}


@app.post("/api/v1/auth/login")
def login(req: LoginRequest) -> Dict[str, Any]:
    with get_conn() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username = %s AND is_active = TRUE",
            (req.username,),
        ).fetchone()
        if not user or not verify_password(req.password, user["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid organisational credentials.")
        _log_audit(conn, {"sub": user["id"], "username": user["username"]}, "LOGIN", "session", user["id"])
        conn.commit()
        user_public = {
            "id": user["id"],
            "username": user["username"],
            "display_name": user["display_name"],
            "role": user["role"],
            "organisation_id": user["organisation_id"],
        }
        return {"access_token": create_access_token(user_public), "token_type": "bearer", "user": user_public}


# ---- Worklist & Studies ----

@app.get("/api/v1/worklist")
def get_worklist(
    q: str = Query(default="", max_length=120),
    review_status: Optional[str] = None,
    user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    with get_conn() as conn:
        params: List[Any] = [user["organisation_id"]]
        sql = """
            SELECT s.study_instance_uid, s.study_id, s.accession_number, s.accession_issuer,
                   s.study_description, s.study_date, s.study_time, s.frame_of_reference_uid,
                   s.source_system, s.transfer_status, s.image_availability,
                   s.technical_review_status, s.clinical_review_status, s.series_count,
                   p.id AS patient_record_id, p.patient_id, p.issuing_authority, p.patient_name,
                   p.birth_date, p.sex, p.is_synthetic_demo
            FROM studies s
            JOIN patients p ON p.id = s.patient_record_id
            WHERE p.organisation_id = %s
        """
        if user["role"] != "admin":
            sql += " AND EXISTS (SELECT 1 FROM user_patient_access upa WHERE upa.user_id = %s AND upa.patient_record_id = p.id)"
            params.append(user["sub"])
        if q.strip():
            like = f"%{q.strip()}%"
            sql += " AND (p.patient_name ILIKE %s OR p.patient_id ILIKE %s OR s.study_description ILIKE %s OR COALESCE(s.accession_number, '') ILIKE %s)"
            params.extend([like, like, like, like])
        if review_status:
            sql += " AND s.clinical_review_status = %s"
            params.append(review_status)
        sql += " ORDER BY s.study_date DESC, s.study_time DESC"
        rows = conn.execute(sql, params).fetchall()
        return {"studies": [dict(r) for r in rows]}


@app.get("/api/v1/studies/{study_uid}/series")
def get_study_series(study_uid: str, user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    with get_conn() as conn:
        study = _assert_study_access(conn, user, study_uid)
        series_rows = conn.execute(
            "SELECT * FROM series WHERE study_instance_uid = %s ORDER BY series_number ASC, source_description ASC",
            (study_uid,),
        ).fetchall()
        _log_audit(conn, user, "VIEW_STUDY", "study", study_uid, study_uid=study_uid)
        conn.commit()
        return {"study": study, "series": [dict(r) for r in series_rows]}


@app.get("/api/v1/studies/{study_uid}/series/{series_uid}/instances")
def get_series_instances(
    study_uid: str,
    series_uid: str,
    user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        rows = conn.execute(
            """
            SELECT sop_instance_uid, series_instance_uid, study_instance_uid, sop_class_uid,
                   transfer_syntax_uid, instance_number, image_position_patient, image_orientation_patient,
                   slice_location, rows, columns, bits_allocated, bits_stored, pixel_representation,
                   photometric_interpretation, window_center, window_width, rescale_slope, rescale_intercept,
                   sha256_checksum, byte_size
            FROM instances
            WHERE study_instance_uid = %s AND series_instance_uid = %s
            ORDER BY slice_location ASC NULLS LAST, instance_number ASC
            """,
            (study_uid, series_uid),
        ).fetchall()
        return {"instances": [dict(r) for r in rows]}


@app.get("/api/v1/instances/{sop_uid}/dicom")
def download_instance_dicom(
    sop_uid: str,
    simulate_interrupt_byte: Optional[int] = Query(default=None, ge=64),
    range_header: Optional[str] = Header(default=None, alias="Range"),
    user: Dict[str, Any] = Depends(get_current_user),
):
    with get_conn() as conn:
        inst = conn.execute(
            "SELECT study_instance_uid, storage_rel_path, sha256_checksum FROM instances WHERE sop_instance_uid = %s",
            (sop_uid,),
        ).fetchone()
        if not inst:
            raise HTTPException(status_code=404, detail="DICOM instance not found.")
        _assert_study_access(conn, user, inst["study_instance_uid"])
        path = _safe_original_path(inst["storage_rel_path"])
        if not path.exists():
            raise HTTPException(status_code=404, detail="Protected DICOM object missing from storage.")
        raw = path.read_bytes()
        _log_audit(conn, user, "DOWNLOAD_DICOM", "instance", sop_uid, study_uid=inst["study_instance_uid"])
        conn.commit()

    if simulate_interrupt_byte is not None and simulate_interrupt_byte < len(raw):
        return Response(
            content=raw[:simulate_interrupt_byte],
            status_code=206,
            media_type="application/dicom",
            headers={"X-Aureom-Simulated-Interrupt": "true", "X-Expected-SHA256": inst["sha256_checksum"]},
        )
    return FileResponse(
        path=path,
        media_type="application/dicom",
        headers={"X-Expected-SHA256": inst["sha256_checksum"], "Accept-Ranges": "bytes"},
    )


# ---- Import & DICOMweb ----

@app.post("/api/v1/imports/dicom")
async def import_dicom_file(
    file: UploadFile = File(...),
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist", "technologist")),
) -> Dict[str, Any]:
    raw = await file.read()
    if len(raw) > 128 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Object exceeds 128 MB per-instance safeguard.")
    with get_conn() as conn:
        try:
            result = ingest_dicom_bytes(conn, raw, "LOCAL_DOCUMENT", actor=user)
            _log_audit(conn, user, "IMPORT_DICOM", "instance", result["sop_instance_uid"], study_uid=result["study_instance_uid"])
            conn.commit()
            return result
        except DicomValidationError as exc:
            _log_audit(conn, user, "IMPORT_DICOM_REJECTED", "upload", file.filename or "unknown", outcome=exc.code)
            conn.commit()
            raise HTTPException(
                status_code=422,
                detail={"code": exc.code, "message": exc.message, "remediation": exc.remediation},
            ) from exc


@app.get("/api/v1/dicomweb/studies")
async def dicomweb_query_studies(
    patient_id: str = "",
    user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    adapter = DicomWebAdapter()
    try:
        results = await adapter.query_studies_qido(patient_id=patient_id)
        return {"source": settings.dicomweb_base_url, "studies": results}
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"DICOMweb QIDO-RS archive unreachable at {settings.dicomweb_base_url}: {exc}",
        ) from exc


@app.post("/api/v1/dicomweb/retrieve/{study_uid}")
async def dicomweb_retrieve_study(
    study_uid: str,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist", "technologist")),
) -> Dict[str, Any]:
    adapter = DicomWebAdapter()
    job_id = str(uuid.uuid4())
    with get_conn() as conn:
        conn.execute(
            """
            INSERT INTO transfer_jobs (id, study_instance_uid, source_type, source_uri, status, created_by)
            VALUES (%s, %s, 'DICOMWEB', %s, 'IN_PROGRESS', %s)
            """,
            (job_id, study_uid, f"{settings.dicomweb_base_url}/studies/{study_uid}", user["sub"]),
        )
        conn.commit()

    try:
        blobs = await adapter.retrieve_study_wado(study_uid)
        ingested = 0
        with get_conn() as conn:
            for blob in blobs:
                ingest_dicom_bytes(conn, blob, "DICOMWEB_ARCHIVE", actor=user)
                ingested += 1
            conn.execute(
                "UPDATE transfer_jobs SET status = 'COMPLETED', total_objects = %s, completed_objects = %s, updated_at = NOW() WHERE id = %s",
                (len(blobs), ingested, job_id),
            )
            _log_audit(conn, user, "DICOMWEB_RETRIEVE", "study", study_uid, study_uid=study_uid)
            conn.commit()
        return {"job_id": job_id, "status": "COMPLETED", "ingested_objects": ingested}
    except Exception as exc:
        with get_conn() as conn:
            conn.execute(
                "UPDATE transfer_jobs SET status = 'FAILED', error_message = %s, updated_at = NOW() WHERE id = %s",
                (str(exc), job_id),
            )
            conn.commit()
        raise HTTPException(status_code=502, detail=f"DICOMweb retrieval failed: {exc}") from exc


# ---- Study-Isolated Annotations ----

@app.get("/api/v1/studies/{study_uid}/annotations")
def list_annotations(study_uid: str, user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        rows = conn.execute(
            "SELECT * FROM annotations WHERE study_instance_uid = %s ORDER BY created_at DESC",
            (study_uid,),
        ).fetchall()
        return {"study_instance_uid": study_uid, "annotations": [dict(r) for r in rows]}


@app.post("/api/v1/studies/{study_uid}/annotations")
def create_annotation(
    study_uid: str,
    req: AnnotationCreate,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist", "technologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        # Verify series belongs strictly to study_uid (prevents cross-study bleeding)
        series_row = conn.execute(
            "SELECT study_instance_uid FROM series WHERE series_instance_uid = %s",
            (req.series_instance_uid,),
        ).fetchone()
        if not series_row or series_row["study_instance_uid"] != study_uid:
            raise HTTPException(
                status_code=400,
                detail="Series does not belong to target study; annotation rejected to prevent cross-study leakage.",
            )
        ann_id = f"ann-{uuid.uuid4().hex[:12]}"
        conn.execute(
            """
            INSERT INTO annotations (
                id, study_instance_uid, series_instance_uid, sop_instance_uid, author_id, author_name,
                measurement_type, coordinate_system, is_reconstructed_plane, plane_label,
                physical_units_valid, physical_unit_label, geometry_json, measured_value_text,
                intensity_stats_json, note_text
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                ann_id,
                study_uid,
                req.series_instance_uid,
                req.sop_instance_uid,
                user["sub"],
                user["display_name"],
                req.measurement_type,
                req.coordinate_system,
                req.is_reconstructed_plane,
                req.plane_label,
                req.physical_units_valid,
                req.physical_unit_label,
                req.geometry_json,
                req.measured_value_text,
                req.intensity_stats_json,
                req.note_text,
            ),
        )
        _log_audit(conn, user, "CREATE_ANNOTATION", "annotation", ann_id, study_uid=study_uid)
        conn.commit()
        created = conn.execute("SELECT * FROM annotations WHERE id = %s", (ann_id,)).fetchone()
        return {"annotation": dict(created)}


@app.delete("/api/v1/studies/{study_uid}/annotations/{annotation_id}")
def delete_annotation(
    study_uid: str,
    annotation_id: str,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist", "technologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        res = conn.execute(
            "DELETE FROM annotations WHERE id = %s AND study_instance_uid = %s",
            (annotation_id, study_uid),
        )
        if res.rowcount == 0:
            raise HTTPException(status_code=404, detail="Annotation not found in target study.")
        _log_audit(conn, user, "DELETE_ANNOTATION", "annotation", annotation_id, study_uid=study_uid)
        conn.commit()
        return {"deleted": annotation_id}


# ---- Versioned Reports, Signing, Amendments & Review Tasks ----

@app.get("/api/v1/studies/{study_uid}/reports")
def get_study_reports(study_uid: str, user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        reports = conn.execute(
            "SELECT * FROM reports WHERE study_instance_uid = %s ORDER BY updated_at DESC",
            (study_uid,),
        ).fetchall()
        tasks = conn.execute(
            "SELECT * FROM review_tasks WHERE study_instance_uid = %s ORDER BY created_at DESC",
            (study_uid,),
        ).fetchall()
        amendments = conn.execute(
            "SELECT * FROM report_amendments WHERE study_instance_uid = %s ORDER BY created_at ASC",
            (study_uid,),
        ).fetchall()
        return {
            "reports": [dict(r) for r in reports],
            "review_tasks": [dict(t) for t in tasks],
            "amendments": [dict(a) for a in amendments],
        }


@app.put("/api/v1/studies/{study_uid}/reports")
def save_report_draft(
    study_uid: str,
    req: ReportSaveRequest,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        existing = conn.execute(
            "SELECT * FROM reports WHERE study_instance_uid = %s ORDER BY created_at DESC LIMIT 1",
            (study_uid,),
        ).fetchone()

        if existing:
            if existing["status"] in {"SIGNED", "AMENDED"}:
                raise HTTPException(
                    status_code=409,
                    detail="Signed reports are immutable. Submit a linked amendment instead.",
                )
            if req.expected_version is not None and existing["version"] != req.expected_version:
                raise HTTPException(
                    status_code=409,
                    detail=f"Version conflict: expected v{req.expected_version}, current is v{existing['version']}.",
                )
            new_version = existing["version"] + 1
            report_id = existing["id"]
            conn.execute(
                """
                UPDATE reports
                SET version = %s, status = %s, reviewer_id = %s, clinical_history = %s,
                    technique_text = %s, findings_text = %s, impression_text = %s,
                    examination_notes = %s, updated_at = NOW()
                WHERE id = %s AND study_instance_uid = %s AND version = %s
                """,
                (
                    new_version,
                    req.status if req.status in {"DRAFT", "IN_REVIEW"} else "DRAFT",
                    req.reviewer_id,
                    req.clinical_history,
                    req.technique_text,
                    req.findings_text,
                    req.impression_text,
                    req.examination_notes,
                    report_id,
                    study_uid,
                    existing["version"],
                ),
            )
        else:
            report_id = f"rep-{uuid.uuid4().hex[:12]}"
            new_version = 1
            conn.execute(
                """
                INSERT INTO reports (
                    id, study_instance_uid, author_id, reviewer_id, status, version,
                    clinical_history, technique_text, findings_text, impression_text, examination_notes
                )
                VALUES (%s, %s, %s, %s, %s, 1, %s, %s, %s, %s, %s)
                """,
                (
                    report_id,
                    study_uid,
                    user["sub"],
                    req.reviewer_id,
                    req.status if req.status in {"DRAFT", "IN_REVIEW"} else "DRAFT",
                    req.clinical_history,
                    req.technique_text,
                    req.findings_text,
                    req.impression_text,
                    req.examination_notes,
                ),
            )

        snapshot = req.model_dump()
        conn.execute(
            """
            INSERT INTO report_versions (id, report_id, study_instance_uid, version, status, editor_id, snapshot_json)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (str(uuid.uuid4()), report_id, study_uid, new_version, req.status, user["sub"], json.dumps(snapshot)),
        )
        conn.execute(
            "UPDATE studies SET clinical_review_status = %s, updated_at = NOW() WHERE study_instance_uid = %s",
            ("IN_REVIEW" if req.status == "IN_REVIEW" else "DRAFT_REPORT", study_uid),
        )
        _log_audit(conn, user, "SAVE_REPORT", "report", report_id, study_uid=study_uid, details={"version": new_version})
        conn.commit()
        updated = conn.execute("SELECT * FROM reports WHERE id = %s", (report_id,)).fetchone()
        return {"report": dict(updated)}


@app.post("/api/v1/reports/{report_id}/sign")
def sign_report(
    report_id: str,
    expected_version: int = Query(...),
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        rep = conn.execute("SELECT * FROM reports WHERE id = %s", (report_id,)).fetchone()
        if not rep:
            raise HTTPException(status_code=404, detail="Report not found.")
        _assert_study_access(conn, user, rep["study_instance_uid"])
        if rep["status"] in {"SIGNED", "AMENDED"}:
            raise HTTPException(status_code=409, detail="Report is already signed.")
        if rep["version"] != expected_version:
            raise HTTPException(status_code=409, detail="Version mismatch during atomic sign.")

        canonical = json.dumps(
            {
                "study_instance_uid": rep["study_instance_uid"],
                "version": rep["version"],
                "findings": rep["findings_text"],
                "impression": rep["impression_text"],
            },
            sort_keys=True,
        )
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        conn.execute(
            """
            UPDATE reports
            SET status = 'SIGNED', signed_by = %s, signed_at = NOW(), content_sha256 = %s, updated_at = NOW()
            WHERE id = %s
            """,
            (user["display_name"], digest, report_id),
        )
        conn.execute(
            "UPDATE studies SET clinical_review_status = 'FINAL_SIGNED', updated_at = NOW() WHERE study_instance_uid = %s",
            (rep["study_instance_uid"],),
        )
        _log_audit(conn, user, "SIGN_REPORT", "report", report_id, study_uid=rep["study_instance_uid"], details={"sha256": digest})
        conn.commit()
        signed = conn.execute("SELECT * FROM reports WHERE id = %s", (report_id,)).fetchone()
        return {"report": dict(signed)}


@app.post("/api/v1/reports/{report_id}/amendments")
def add_amendment(
    report_id: str,
    req: AmendmentCreate,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        rep = conn.execute("SELECT * FROM reports WHERE id = %s", (report_id,)).fetchone()
        if not rep:
            raise HTTPException(status_code=404, detail="Report not found.")
        _assert_study_access(conn, user, rep["study_instance_uid"])
        if rep["status"] not in {"SIGNED", "AMENDED"}:
            raise HTTPException(status_code=400, detail="Amendments can only be linked to signed reports.")
        am_id = f"amd-{uuid.uuid4().hex[:12]}"
        conn.execute(
            """
            INSERT INTO report_amendments (id, report_id, study_instance_uid, author_id, reason, amendment_text)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (am_id, report_id, rep["study_instance_uid"], user["sub"], req.reason, req.amendment_text),
        )
        conn.execute("UPDATE reports SET status = 'AMENDED', updated_at = NOW() WHERE id = %s", (report_id,))
        conn.execute(
            "UPDATE studies SET clinical_review_status = 'AMENDED', updated_at = NOW() WHERE study_instance_uid = %s",
            (rep["study_instance_uid"],),
        )
        _log_audit(conn, user, "AMEND_REPORT", "report", report_id, study_uid=rep["study_instance_uid"])
        conn.commit()
        created = conn.execute("SELECT * FROM report_amendments WHERE id = %s", (am_id,)).fetchone()
        return {"amendment": dict(created)}


@app.post("/api/v1/studies/{study_uid}/tasks")
def create_review_task(
    study_uid: str,
    req: ReviewTaskCreate,
    user: Dict[str, Any] = Depends(require_roles("admin", "radiologist", "technologist")),
) -> Dict[str, Any]:
    with get_conn() as conn:
        _assert_study_access(conn, user, study_uid)
        task_id = f"tsk-{uuid.uuid4().hex[:10]}"
        conn.execute(
            """
            INSERT INTO review_tasks (id, study_instance_uid, assigned_to, task_type, status, due_date, notes)
            VALUES (%s, %s, %s, %s, 'OPEN', %s, %s)
            """,
            (task_id, study_uid, req.assigned_to or user["sub"], req.task_type, req.due_date, req.notes),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM review_tasks WHERE id = %s", (task_id,)).fetchone()
        return {"task": dict(row)}


# ---- Transfers, Audit, Backup & Retention ----

@app.get("/api/v1/transfers")
def list_transfers(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM transfer_jobs ORDER BY created_at DESC LIMIT 100").fetchall()
        return {"transfers": [dict(r) for r in rows]}


@app.get("/api/v1/audit")
def list_audit_events(user: Dict[str, Any] = Depends(require_roles("admin", "radiologist"))) -> Dict[str, Any]:
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 200").fetchall()
        return {"events": [dict(r) for r in rows]}


@app.post("/api/v1/admin/backup")
def create_backup_snapshot(user: Dict[str, Any] = Depends(require_roles("admin"))) -> Dict[str, Any]:
    _ensure_storage_dirs()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    archive_path = settings.backup_dir / f"aureom_originals_backup_{stamp}"
    shutil.make_archive(str(archive_path), "zip", str(settings.protected_storage_dir / "originals"))
    zip_file = Path(f"{archive_path}.zip")
    digest = hashlib.sha256(zip_file.read_bytes()).hexdigest()
    with get_conn() as conn:
        _log_audit(conn, user, "BACKUP_SNAPSHOT", "storage", zip_file.name, details={"sha256": digest})
        conn.commit()
    return {"backup_file": zip_file.name, "bytes": zip_file.stat().st_size, "sha256": digest}


# ---- AI Assist (Disabled by Default) ----

@app.post("/api/v1/ai/assist")
def run_ai_assist(
    req: AiAssistRequest,
    opt_in: Optional[str] = Header(default="false", alias="X-AI-Assist-OptIn"),
    user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    if not settings.ai_assist_enabled or opt_in.lower() != "true":
        raise HTTPException(
            status_code=403,
            detail="AI assistance is disabled by default. Enable AI_ASSIST_ENABLED=true and explicit user opt-in in Settings.",
        )
    with get_conn() as conn:
        _assert_study_access(conn, user, req.study_instance_uid)
        _log_audit(conn, user, "AI_ASSIST_INVOKED", "study", req.study_instance_uid, study_uid=req.study_instance_uid)
        if req.action == "organise_series":
            series_rows = conn.execute(
                "SELECT * FROM series WHERE study_instance_uid = %s",
                (req.study_instance_uid,),
            ).fetchall()
            conn.commit()
            return ai_adapter.organise_series_metadata([dict(r) for r in series_rows])
        if req.action == "summarise_reports":
            rep_rows = conn.execute(
                "SELECT * FROM reports WHERE study_instance_uid = %s",
                (req.study_instance_uid,),
            ).fetchall()
            conn.commit()
            return ai_adapter.summarise_authorised_reports(req.study_instance_uid, [dict(r) for r in rep_rows])
        raise HTTPException(status_code=400, detail="Unsupported AI assist action.")


# ---- Research k-space Module (Isolated from Clinical Archive) ----

@app.get("/api/v1/research/kspace-datasets")
def get_research_kspace(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    kspace_file = Path(__file__).resolve().parent.parent / "fixtures" / "research" / "kspace_cartesian_2d.json"
    if not kspace_file.exists():
        raise HTTPException(status_code=404, detail="Research k-space fixture not generated.")
    return json.loads(kspace_file.read_text())
