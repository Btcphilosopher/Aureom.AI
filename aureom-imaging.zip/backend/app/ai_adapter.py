"""
Replaceable AI Assistance Adapter for AUREOM IMAGING.
Disabled by default (AI_ASSIST_ENABLED=false).
Permitted initial functions are strictly non-diagnostic:
1. Organising series metadata into structured protocol tables.
2. Locating existing authorised reports for comparison context.
3. Drafting concise summaries of already-authorised report text with explicit source citations.
AI must NEVER independently diagnose, fabricate measurements, sign reports, or conceal conflicting findings.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class AIAssistAdapter(ABC):
    adapter_name: str = "DisabledAdapter"
    adapter_version: str = "0.0.0"

    @abstractmethod
    def organise_series_metadata(self, series_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        ...

    @abstractmethod
    def summarise_authorised_reports(
        self, study_uid: str, reports: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        ...


class DeterministicMetadataAssistAdapter(AIAssistAdapter):
    """
    Safe baseline adapter used only when AI_ASSIST_ENABLED=true and user explicitly enables it.
    Performs transparent, deterministic grouping & extractive summarisation with explicit source UIDs.
    """

    adapter_name = "AureomDeterministicTextAssist"
    adapter_version = "1.0.0"

    def organise_series_metadata(self, series_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        grouped: Dict[str, List[Dict[str, Any]]] = {
            "volumetric_3d": [],
            "diagnostic_2d": [],
            "localiser_scout": [],
            "geometry_flagged": [],
        }
        for s in series_list:
            entry = {
                "series_instance_uid": s["series_instance_uid"],
                "source_description": s["source_description"],
                "inferred_sequence_label": s.get("inferred_sequence_label"),
                "slice_count": s["slice_count"],
                "tr_te": f"TR={s.get('repetition_time') or '-'} / TE={s.get('echo_time') or '-'}",
            }
            if s.get("is_localiser"):
                grouped["localiser_scout"].append(entry)
            elif not s.get("is_volumetric_compatible"):
                grouped["geometry_flagged"].append(entry)
            elif s.get("mr_acquisition_type") == "3D" or (s.get("slice_count", 0) >= 12):
                grouped["volumetric_3d"].append(entry)
            else:
                grouped["diagnostic_2d"].append(entry)

        return {
            "adapter": self.adapter_name,
            "version": self.adapter_version,
            "intended_use": "Non-diagnostic series metadata organisation only.",
            "grouped_series": grouped,
        }

    def summarise_authorised_reports(
        self, study_uid: str, reports: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        citations = []
        bullets = []
        for rep in reports:
            if rep.get("status") not in {"SIGNED", "AMENDED", "IN_REVIEW", "DRAFT"}:
                continue
            citations.append(
                {
                    "report_id": rep["id"],
                    "status": rep["status"],
                    "version": rep["version"],
                    "study_instance_uid": rep["study_instance_uid"],
                }
            )
            imp = (rep.get("impression_text") or "").strip()
            if imp:
                bullets.append(f"[{rep['id']} v{rep['version']} ({rep['status']})]: {imp}")
        return {
            "adapter": self.adapter_name,
            "version": self.adapter_version,
            "intended_use": "Extractive summary of authorised report text with source references; non-diagnostic.",
            "study_instance_uid": study_uid,
            "summary_bullets": bullets or ["No authorised report impression text available to summarise."],
            "source_references": citations,
        }
