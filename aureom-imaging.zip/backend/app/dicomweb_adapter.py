"""
Documented, replaceable DICOMweb Adapter (QIDO-RS, WADO-RS, STOW-RS) for AUREOM IMAGING.
Supports Orthanc DICOMweb or any DICOM PS3.18 compliant PACS endpoint with Basic or Bearer authentication.
"""

import os
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import httpx

from .config import settings


@dataclass
class DicomWebConfig:
    base_url: str
    auth_mode: str = "basic"  # "basic" | "bearer" | "none"
    username: str = ""
    password: str = ""
    bearer_token: str = ""


class DicomWebAdapter:
    """
    Replaceable DICOMweb interface implementing PS3.18 QIDO-RS, WADO-RS, and STOW-RS.
    Validates outbound archive URLs to prevent SSRF against unexpected metadata endpoints.
    """

    def __init__(self, config: Optional[DicomWebConfig] = None):
        self.config = config or DicomWebConfig(
            base_url=settings.dicomweb_base_url,
            auth_mode="basic" if settings.dicomweb_username else "none",
            username=settings.dicomweb_username,
            password=settings.dicomweb_password,
        )

    def _validate_base_url(self, url: str) -> str:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("DICOMweb URL must use http or https scheme.")
        if parsed.hostname in {"169.254.169.254"}:
            raise ValueError("Link-local metadata addresses are blocked.")
        return url.rstrip("/")

    def _headers(self, accept: str) -> Dict[str, str]:
        headers = {"Accept": accept}
        if self.config.auth_mode == "bearer" and self.config.bearer_token:
            headers["Authorization"] = f"Bearer {self.config.bearer_token}"
        return headers

    def _auth(self) -> Optional[httpx.BasicAuth]:
        if self.config.auth_mode == "basic" and self.config.username:
            return httpx.BasicAuth(self.config.username, self.config.password)
        return None

    async def query_studies_qido(self, patient_id: str = "", limit: int = 25) -> List[Dict[str, Any]]:
        """PS3.18 QIDO-RS: GET /studies?ModalitiesInStudy=MR"""
        base = self._validate_base_url(self.config.base_url)
        params: Dict[str, Any] = {"ModalitiesInStudy": "MR", "limit": limit}
        if patient_id:
            params["PatientID"] = patient_id
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{base}/studies",
                params=params,
                headers=self._headers("application/dicom+json"),
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.json()

    async def query_series_qido(self, study_uid: str) -> List[Dict[str, Any]]:
        """PS3.18 QIDO-RS: GET /studies/{study}/series"""
        base = self._validate_base_url(self.config.base_url)
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{base}/studies/{study_uid}/series",
                headers=self._headers("application/dicom+json"),
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.json()

    async def retrieve_study_wado(self, study_uid: str) -> List[bytes]:
        """
        PS3.18 WADO-RS: GET /studies/{study}
        Parses multipart/related; type="application/dicom" response into individual DICOM Part 10 byte payloads.
        """
        base = self._validate_base_url(self.config.base_url)
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.get(
                f"{base}/studies/{study_uid}",
                headers=self._headers('multipart/related; type="application/dicom"'),
                auth=self._auth(),
            )
            resp.raise_for_status()
            return self._parse_multipart_dicom(resp.headers.get("content-type", ""), resp.content)

    async def store_instances_stow(self, dicom_blobs: List[bytes]) -> Dict[str, Any]:
        """PS3.18 STOW-RS: POST /studies with multipart/related; type="application/dicom" """
        base = self._validate_base_url(self.config.base_url)
        boundary = "AUREOM_DICOMWEB_BOUNDARY_7F92"
        parts: List[bytes] = []
        for blob in dicom_blobs:
            parts.append(
                f"--{boundary}\r\nContent-Type: application/dicom\r\n\r\n".encode("ascii")
                + blob
                + b"\r\n"
            )
        body = b"".join(parts) + f"--{boundary}--\r\n".encode("ascii")
        headers = self._headers("application/dicom+json")
        headers["Content-Type"] = f'multipart/related; type="application/dicom"; boundary={boundary}'

        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"{base}/studies",
                content=body,
                headers=headers,
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.json() if resp.content else {"status": "stored"}

    @staticmethod
    def _parse_multipart_dicom(content_type: str, body: bytes) -> List[bytes]:
        match = re.search(r'boundary="?([^";\s]+)"?', content_type, re.IGNORECASE)
        if not match:
            return [body] if body.startswith(b"\x00" * 128 + b"DICM") else []
        boundary = b"--" + match.group(1).encode("ascii")
        chunks = body.split(boundary)
        objects: List[bytes] = []
        for chunk in chunks:
            if not chunk or chunk.strip() in {b"", b"--"}:
                continue
            sep_idx = chunk.find(b"\r\n\r\n")
            if sep_idx == -1:
                continue
            payload = chunk[sep_idx + 4 :]
            if payload.endswith(b"\r\n"):
                payload = payload[:-2]
            if len(payload) > 132 and payload[128:132] == b"DICM":
                objects.append(payload)
        return objects
