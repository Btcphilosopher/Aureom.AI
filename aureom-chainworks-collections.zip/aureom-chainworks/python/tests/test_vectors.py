"""Cross-implementation checks: the Python reference (python/chainworks/protocol.py)
independently recomputes the Rust-generated test vectors."""
import json
import pathlib

from chainworks import bech32m, protocol as P

V = pathlib.Path(__file__).resolve().parents[2] / "test-vectors"


def load(n):
    return json.loads((V / n).read_text())


def test_addresses():
    v = load("addresses.json")
    for c in v["cases"]:
        pk = bytes.fromhex(c["pubkey"])
        assert P.address_bytes(pk).hex() == c["address_bytes"]
        assert P.address(pk, v["hrp"]) == c["address"]
        assert bech32m.decode(v["hrp"], c["address"]).hex() == c["address_bytes"]
        assert not bech32m.is_valid("aur", c["address"])  # wrong prefix rejected


def test_hashing_and_merkle():
    v = load("hashing.json")
    for d in v["domain_hash"]:
        assert P.H(d["domain"], bytes.fromhex(d["data"])).hex() == d["hash"]
    for r in v["merkle_roots"]:
        assert P.merkle_root([bytes.fromhex(x) for x in r["items"]]).hex() == r["root"]
    mp = v["merkle_proof"]
    items = [bytes.fromhex(x) for x in mp["items"]]
    proof = P.merkle_proof(items, mp["index"])
    assert [(s, b.hex()) for s, b in proof] == [(p["side"], p["sibling"]) for p in mp["proof"]]
    assert P.verify_proof(items[mp["index"]], proof, P.merkle_root(items))
    cl = v["claim_leaf"]
    leaf = P.H("AUREOM/CLAIM/v1", cl["index"].to_bytes(4, "big") + bytes.fromhex(cl["address"]) + int(cl["amount"]).to_bytes(16, "big"))
    assert leaf.hex() == cl["leaf"]
    sl = v["state_leaf"]
    assert P.state_leaf(bytes.fromhex(sl["key"]), bytes.fromhex(sl["value"])).hex() == sl["leaf"]


def test_transactions_encoding_signatures_ids():
    v = load("transactions.json")
    hrp = "aurd"
    for c in v["cases"]:
        tx = c["tx_json"]
        unsigned = P.encode_unsigned(tx, hrp)
        assert unsigned.hex() == c["unsigned_hex"], tx["action"]["type"]
        msg = P.signing_message(tx["chain_id"], P.ACTION_TAGS[tx["action"]["type"]], unsigned)
        assert msg.hex() == c["signing_message_hex"]
        assert P.txid(unsigned).hex() == c["txid"] == tx["id"]
        assert P.verify_sig(bytes.fromhex(tx["sender_pubkey"]), msg, bytes.fromhex(c["signature"]))
        assert c["signed_hex"] == c["unsigned_hex"] + c["signature"]
        assert c["min_fee"] == 1000 + 1 * c["signed_size"]
    # negative: signature for another chain must not verify under this chain id
    neg = bytes.fromhex(v["negative"][0]["signed_hex"])
    t = P.decode_signed_transfer(neg)
    assert t.chain_id == "another-chain"
    assert P.verify_sig(t.pubkey, P.signing_message(t.chain_id, 1, t.unsigned), t.signature)
    forged = P.encode_unsigned({"version": 1, "chain_id": v["chain_id"], "nonce": t.nonce, "fee": str(t.fee), "expiry_height": t.expiry,
                                "sender_pubkey": t.pubkey.hex(), "action": {"type": "transfer", "to": bech32m.encode(hrp, t.to), "amount": str(t.amount)}, "memo": ""}, hrp)
    assert not P.verify_sig(t.pubkey, P.signing_message(v["chain_id"], 1, forged), t.signature)


def test_genesis_hash_state_root_and_transition():
    v = load("state_transition.json")
    g = v["genesis"]
    assert P.jcs(g) == v["genesis_jcs"]
    assert P.genesis_hash(g).hex() == v["genesis_hash"]
    st = P.genesis_state(g)
    assert P.state_root(st).hex() == v["genesis_state_root"]
    txs = [bytes.fromhex(x) for x in v["txs"]]
    ids = [P.txid(P.decode_signed_transfer(t).unsigned) for t in txs]
    assert P.merkle_root(ids).hex() == v["tx_root"]
    statuses, rroot = P.execute_transfer_block(g, st, v["height"], bytes.fromhex(v["miner"]), txs)
    assert statuses == v["expected_status"]
    assert rroot.hex() == v["receipt_root"]
    assert P.state_root(st).hex() == v["post_state_root"]
    assert {k.hex(): x.hex() for k, x in st.items()} == {k: x for k, x in v["post_state"]}
