"""AUREOM COLLECTIONS application tests: media validation, metadata commitments, storage
adapters, SigV4, token gating, indexer reorganisation handling and rebuild, request
idempotency and reconciliation of unknown outcomes."""
from __future__ import annotations

import hashlib
import json
import pathlib
import struct
import time

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from chainworks.nft import art, media, metadata as md
from chainworks.nft.authenticity import Claims
from chainworks.nft.db import connect, migrate, open_db
from chainworks.nft.gating import Gate, address_from_pubkey, message_bytes
from chainworks.nft.indexer import Indexer
from chainworks.nft.requests import Requests
from chainworks.nft.storage import LocalObjectStore, sigv4_headers
from chainworks.util import ChainworksError
from fakenode import GEN, FakeNode, ev, tx

C = "aurdcol1qqqq"  # collection id label used by the fake chain
A, B, X = "aurd1alice", "aurd1bob", "aurd1mallory"


@pytest.fixture
def node():
    n = FakeNode()
    yield n
    n.close()


@pytest.fixture
def db(tmp_path):
    return open_db(tmp_path / "c.db")


# ---------------------------------------------------------------- media

def test_png_validated_from_content_with_dimensions_and_cid():
    b, tr = art.illustration(1)
    v = media.validate(b, "lantern.png", art.alt_text(1, tr))
    assert (v["mime"], v["width"], v["height"]) == ("image/png", 192, 192)
    assert v["sha256"] == hashlib.sha256(b).hexdigest()
    assert v["cid_raw_v1"].startswith("bafkrei")
    assert media.cid_v1_raw(b"") == "bafkreihdwdcefgh4dqkjv67uzcmw7ojee6xedzdetojuzjevtenxquvyku"  # known IPFS value


def test_media_rejections():
    b, tr = art.illustration(2)
    alt = art.alt_text(2, tr)
    with pytest.raises(media.MediaError, match="alt text"):
        media.validate(b, "x.png", None)
    with pytest.raises(media.MediaError, match="does not match"):
        media.validate(b, "x.jpg", alt)
    bad = bytearray(b)
    bad[40] ^= 0xFF
    with pytest.raises(media.MediaError, match="CRC|chunk"):
        media.validate(bytes(bad), "x.png", alt)
    with pytest.raises(media.MediaError, match="IEND|truncated|past end"):
        media.validate(b[:-20], "x.png", alt)
    svg = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><script>alert(1)</script></svg>'
    with pytest.raises(media.MediaError, match="script"):
        media.validate(svg, "x.svg", "an image description")
    svg2 = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><image href="https://tracker.example/p.png"/></svg>'
    with pytest.raises(media.MediaError, match="external"):
        media.validate(svg2, "x.svg", "an image description")
    with pytest.raises(media.MediaError, match="active content"):
        media.validate(art.statement_pdf(["x"]).replace(b"/Type /Catalog", b"/Type /Catalog /OpenAction 3 0 R"), "x.pdf")
    wav = art.chime_wav()
    with pytest.raises(media.MediaError, match="RIFF size"):
        media.validate(wav[:-100], "c.wav")
    with pytest.raises(media.MediaError, match="unsupported"):
        media.validate(b"\x00\x01\x02\x03binary", "x.bin")
    assert media.validate(art.collection_svg(), "c.svg", "collection artwork of lanterns")["mime"] == "image/svg+xml"
    assert media.validate(art.chime_wav(), "c.wav")["warnings"]  # transcript recommended


# ---------------------------------------------------------------- metadata

def _doc(**over):
    img = {"role": "image", "uri": "https://example.invalid/x", "sha256": "11" * 32, "mime": "image/png", "alt_text": "A lantern on water"}
    d = md.token_document(name="Lantern", description="d", collection_slug="tidewater", chain_id="c", genesis_hash=GEN, token_id=1, image=img,
                          creator="Lumen Atelier (fictional)", rights=md.rights_block("Lumen Atelier (fictional)", "CC-BY-4.0", "Illustration licensed CC BY 4.0."))
    d.update(over)
    return d


def test_metadata_canonical_hash_and_roundtrip():
    d = _doc()
    v = md.validate(d)
    b = md.canonical_bytes(d)
    assert v["sha256"] == hashlib.sha256(b).hexdigest()
    assert md.parse_canonical(b) == d
    reordered = json.dumps(d, indent=2).encode()
    with pytest.raises(md.MetadataError, match="canonical"):
        md.parse_canonical(reordered)
    assert md.digest(json.loads(reordered)) == v["sha256"]  # same content -> same commitment


def test_metadata_rules():
    with pytest.raises(md.MetadataError, match="floats"):
        md.validate(_doc(attributes=[{"trait_type": "w", "value": 1.5}]))
    with pytest.raises(md.MetadataError, match="personal information"):
        md.validate(_doc(description="contact artist at jane.doe@example.com"))
    bad = _doc()
    bad["rights"]["token_owner_receives_copyright"] = True
    with pytest.raises(md.MetadataError, match="copyright"):
        md.validate(bad)
    noalt = _doc()
    del noalt["image"]["alt_text"]
    with pytest.raises(md.MetadataError, match="alt_text"):
        md.validate(noalt)


# ---------------------------------------------------------------- storage

def test_local_store_verifies_and_detects_tampering(tmp_path):
    s = LocalObjectStore(tmp_path)
    data = b"hello lanterns"
    h = hashlib.sha256(data).hexdigest()
    st = s.put(data, h, "x.txt")
    assert s.check(st.locator, h).hash_matches
    pathlib.Path(st.locator).write_bytes(b"changed")
    c = s.check(st.locator, h)
    assert c.available and c.hash_matches is False and "CHANGED" in c.detail
    pathlib.Path(st.locator).unlink()
    assert s.check(st.locator, h).available is False
    with pytest.raises(Exception, match="SHA-256"):
        s.put(data, "00" * 32, "x")


def test_sigv4_matches_aws_documented_example():
    # AWS General Reference, "Signature Version 4 signing process" example (IAM ListUsers)
    h = sigv4_headers("GET", "https://iam.amazonaws.com/?Action=ListUsers&Version=2010-05-08", "us-east-1", "iam",
                      "AKIDEXAMPLE", "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY",
                      extra={"content-type": "application/x-www-form-urlencoded; charset=utf-8"}, amz_date="20150830T123600Z")
    assert h["Authorization"].endswith("Signature=5d672d79c15b13162d9279b0855cfba6789a8edb4c82c400e06b5924a6f2b5d7")


# ---------------------------------------------------------------- gating

def _key():
    k = Ed25519PrivateKey.generate()
    pk = k.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return k, pk, address_from_pubkey(pk, "aurd")


def test_token_gate_requires_signature_and_current_ownership(node, db):
    k, pk, addr = _key()
    node.set_chain([("b1", [tx("t1", A, "nft_mint", [ev("nft_mint", collection=C, token_id=1, to=addr, metadata_uri="u", metadata_hash="aa" * 32, frozen="false")])])])
    g = Gate(db, node.url, {"chain_id": "fake-1", "genesis_hash": GEN}, "aurd")
    ch = g.issue(addr, C, "gallery-backstage", "1")
    sig = k.sign(message_bytes(ch["message"])).hex()
    assert g.verify(ch["nonce"], pk.hex(), sig)["granted"] is True
    assert "replay" in g.verify(ch["nonce"], pk.hex(), sig)["reason"]
    # someone who only knows the address cannot pass
    k2, pk2, _ = _key()
    ch = g.issue(addr, C, "gallery-backstage", "1")
    r = g.verify(ch["nonce"], pk2.hex(), k2.sign(message_bytes(ch["message"])).hex())
    assert not r["granted"] and "does not belong" in r["reason"]
    # right key, wrong message
    ch = g.issue(addr, C, "gallery-backstage", "1")
    assert "signature invalid" in g.verify(ch["nonce"], pk.hex(), k.sign(b"something else").hex())["reason"]
    # valid signature but the token has moved on chain
    node.set_chain([("b1", [tx("t1", A, "nft_mint", [ev("nft_mint", collection=C, token_id=1, to=addr, metadata_uri="u", metadata_hash="aa" * 32, frozen="false")])]),
                    ("b2", [tx("t2", addr, "nft_transfer", [ev("nft_transfer", collection=C, token_id=1, **{"from": addr}, to=B, by=addr, authority="owner")])])])
    ch = g.issue(addr, C, "gallery-backstage", "1")
    r = g.verify(ch["nonce"], pk.hex(), k.sign(message_bytes(ch["message"])).hex())
    assert not r["granted"] and "does not currently own" in r["reason"]
    # expiry
    g.ttl = 0
    ch = g.issue(addr, C, "gallery-backstage")
    time.sleep(0.01)
    assert "expired" in g.verify(ch["nonce"], pk.hex(), k.sign(message_bytes(ch["message"])).hex())["reason"]


# ---------------------------------------------------------------- indexer

def mint(i, to):
    return tx(f"m{i}", A, "nft_mint", [ev("nft_mint", collection=C, token_id=i, to=to, by=A, metadata_uri=f"u{i}", metadata_hash=f"{i:02x}" * 32, frozen="false")])


def xfer(t, i, frm, to):
    return tx(t, frm, "nft_transfer", [ev("nft_transfer", collection=C, token_id=i, to=to, by=frm, authority="owner", **{"from": frm})])


CREATE = tx("c0", A, "nft_collection_create", [ev("nft_collection_create", collection=C, slug="tidewater", creator=A, max_supply=10, mint_authority=A,
                                                    metadata_policy=2, metadata_admin=A, admin="none", flags=4, transfer_policy=0, royalty_bps=500,
                                                    metadata_hash="cc" * 32, rights_hash="dd" * 32)],
            action={"royalty": {"recipient": A, "bps": 500}})


def owner(db, i):
    r = db.execute("SELECT owner FROM ownership_cache WHERE token_id = ?", (str(i),)).fetchone()
    return r["owner"] if r else None


def test_indexer_derives_ownership_and_records_failed_txs(node, db):
    node.set_chain([("b1", [CREATE]), ("b2", [mint(1, A), mint(2, A)]), ("b3", [xfer("x1", 1, A, B)]),
                    ("b4", [tx("bad", X, "nft_transfer", [], status="failed", error="UNAUTHORIZED")])])
    ix = Indexer(db, node.url, "fake")
    r = ix.sync()
    assert r["blocks_added"] == 4 and r["reorgs"] == []
    assert (owner(db, 1), owner(db, 2)) == (B, A)
    f = db.execute("SELECT status, error, sender FROM chain_tx_outcomes WHERE txid = 'bad'").fetchone()
    assert dict(f) == {"status": "failed", "error": "UNAUTHORIZED", "sender": X}
    assert ix.verify_against_chain()["consistent"]
    col = db.execute("SELECT minted, royalty_recipient, metadata_policy FROM collections_cache").fetchone()
    assert dict(col) == {"minted": 2, "royalty_recipient": A, "metadata_policy": "freezable"}


def test_indexer_reorg_reconciles_to_winning_branch(node, db):
    node.set_chain([("b1", [CREATE]), ("b2", [mint(1, A)]), ("b3", [xfer("x1", 1, A, B)]), ("b4", [])])
    ix = Indexer(db, node.url, "fake")
    ix.sync()
    assert owner(db, 1) == B
    # competing branch with more work replaces heights 3..5: token goes to mallory instead
    node.set_chain([("b1", [CREATE]), ("b2", [mint(1, A)]), ("b3'", [xfer("x2", 1, A, X)]), ("b4'", []), ("b5'", [])])
    r = ix.sync()
    assert r["reorgs"] and r["reorgs"][0]["fork_height"] == 2 and r["reorgs"][0]["blocks_removed"] == 2
    assert owner(db, 1) == X
    assert db.execute("SELECT count(*) FROM provenance_events WHERE txid = 'x1'").fetchone()[0] == 0
    assert db.execute("SELECT count(*) FROM reorg_log").fetchone()[0] == 1
    assert ix.verify_against_chain()["consistent"]


def test_rebuild_from_chain_events_reproduces_index(node, db):
    node.set_chain([("b1", [CREATE]), ("b2", [mint(1, A), mint(2, B)]), ("b3", [xfer("x1", 1, A, X)])])
    ix = Indexer(db, node.url, "fake")
    ix.sync()
    before = [dict(r) for r in db.execute("SELECT collection_id, token_id, owner, metadata_hash FROM ownership_cache ORDER BY token_id")]
    db.execute("UPDATE ownership_cache SET owner = 'aurd1tampered'")  # corrupt the cache
    assert not ix.verify_against_chain()["consistent"]
    r = ix.rebuild()
    after = [dict(r) for r in db.execute("SELECT collection_id, token_id, owner, metadata_hash FROM ownership_cache ORDER BY token_id")]
    assert after == before and r["blocks_added"] == 3
    assert ix.verify_against_chain()["consistent"]


def test_bft_finality_violation_is_not_silently_reindexed(db):
    n = FakeNode("poa")
    try:
        n.set_chain([("b1", [CREATE]), ("b2", [mint(1, A)])])
        ix = Indexer(db, n.url, "fake")
        ix.sync()
        n.set_chain([("b1", [CREATE]), ("b2x", [mint(1, X)])])
        with pytest.raises(ChainworksError, match="FINALITY VIOLATION"):
            ix.sync()
        assert owner(db, 1) == A  # untouched for investigation
    finally:
        n.close()


# ---------------------------------------------------------------- requests

class FakeNet:
    def __init__(self, node, d):
        self.node, self.dir = node, pathlib.Path(d)

    def nodes(self):
        return [{"name": "n0"}]

    def api(self, name):
        return self.node.url


class FakeWallet:
    def __init__(self, node, d):
        self.api, self.d, self.n = node.url, pathlib.Path(d), 0

    def prepare(self, sender, action, nonce="auto"):
        self.n += 1
        body = json.dumps({"s": sender, "a": action, "i": self.n}).encode().hex()
        p = self.d / f"u{self.n}.json"
        p.write_text(json.dumps({"unsigned_hex": body, "review": {"nonce": 0, "txid": "pending"}}))
        return p

    def review(self, p):
        return {"summary": "fake", "warnings": []}

    def sign(self, sender, p):
        u = json.loads(pathlib.Path(p).read_text())
        signed = u["unsigned_hex"] + "00" * 64
        out = pathlib.Path(str(p) + ".signed")
        out.write_text(json.dumps({"signed_hex": signed, "txid": hashlib.sha256(bytes.fromhex(signed)).hexdigest()}))
        return out

    def account(self, s):
        return {"nonce": 0}


def test_requests_idempotent_and_unknown_outcome_reconciled(node, db, tmp_path):
    rq = Requests(db, FakeNet(node, tmp_path), FakeWallet(node, tmp_path), "fake-1:" + GEN)
    r1 = rq.create("mint", "artist", {"type": "nft_mint"}, "mint:tidewater:1")
    r2 = rq.create("mint", "artist", {"type": "nft_mint"}, "mint:tidewater:1")
    assert r2["deduplicated"] and r2["request_id"] == r1["request_id"]
    assert db.execute("SELECT count(*) FROM module_requests").fetchone()[0] == 1
    rid = r1["request_id"]
    assert rq.validate(rid)["status"] == "validated"
    s = rq.sign(rid)
    # the connection drops during submission: the outcome is unknown
    node.fail_submit = True
    assert rq.submit(rid)["status"] == "unknown"
    # meanwhile the transaction actually landed in a block
    node.fail_submit = False
    node.set_chain([("b1", [({"id": s["txid"], "sender": "artist", "action": {"type": "nft_mint"}}, {"txid": s["txid"], "status": "success", "fee_paid": "1", "events": []})]), ("b2", [])])
    r = rq.submit(rid)  # submit() reconciles first instead of re-sending
    assert r["status"] == "confirmed"
    assert len(node.submits) == 1, "nothing re-sent once the chain showed the transaction"
    statuses = [h["to_status"] for h in rq.history(rid)]
    assert statuses[:5] == ["prepared", "validated", "signed", "unknown", "confirmed"]


def test_requests_resubmit_identical_bytes_only(node, db, tmp_path):
    rq = Requests(db, FakeNet(node, tmp_path), FakeWallet(node, tmp_path), "fake-1:" + GEN)
    rid = rq.create("transfer", "collector", {"type": "nft_transfer"}, "t:1")["request_id"]
    rq.validate(rid)
    rq.sign(rid)
    node.fail_submit = True
    rq.submit(rid)
    node.fail_submit = False
    r = rq.submit(rid)  # not found anywhere yet -> resubmits the SAME signed bytes
    assert r["status"] == "submitted"
    assert len(set(node.submits)) == 1 and len(node.submits) == 2


def test_claims_are_reviewed_off_chain(db):
    c = Claims(db, "k")
    with pytest.raises(ChainworksError, match="evidence"):
        c.submit("col", "physical_asset_backed", "backed by a painting", "aurd1artist", [{"description": "scan"}])
    cl = c.submit("col", "verified_artist", "Lumen Atelier made this", "aurd1artist", [{"description": "studio attestation", "sha256": "ab" * 32, "held_by": "registrar"}])
    assert cl["status"] == "submitted" and cl["on_chain"] is False and "not reviewed" in cl["display"]
    with pytest.raises(ChainworksError, match="own claim"):
        c.review(cl["claim_id"], "aurd1artist", "accepted", "self")
    r = c.review(cl["claim_id"], "reviewer@registrar (fictional)", "accepted", "attestation checked")
    assert r["status"] == "accepted" and "not a chain fact" in r["display"]


def test_migrations_are_checksummed(tmp_path):
    c = connect(tmp_path / "m.db")
    assert migrate(c)["applied"] == ["0001_chain_index", "0002_application"]
    assert migrate(c)["applied"] == []
    c.execute("UPDATE schema_migrations SET sha256 = 'x' WHERE version = 1")
    assert migrate(c)["problems"]
