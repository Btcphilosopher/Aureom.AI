"""Configuration validation, genesis cross-checks (Python vs Rust), supply preview,
export secret scanning and console-server request filtering."""
import copy
import json
import pathlib

import pytest

from chainworks import bech32m, protocol as P, spec
from chainworks.network import Network, patch_toml
from chainworks.util import ChainworksError, base_units, cli, fmt_units

ROOT = pathlib.Path(__file__).resolve().parents[2]


@pytest.fixture(scope="module")
def net(tmp_path_factory):
    d = tmp_path_factory.mktemp("net") / "pow"
    n = Network.init(d, "pow")
    n.build_genesis()
    return n


def test_genesis_python_rust_hash_agree(net):
    g = json.loads(net.genesis_path.read_text())
    assert P.genesis_hash(g).hex() == cli("genesis", "hash", net.genesis_path)["genesis_hash"] == net.genesis_hash


def test_validate_network_ok(net):
    r = net.validate()
    assert r["ok"], [c for c in r["checks"] if not c["ok"]]


def test_genesis_rebuild_refused(net):
    with pytest.raises(ChainworksError):
        net.build_genesis()


@pytest.mark.parametrize("mutate,needle", [
    (lambda g: g["allocations"].append(copy.deepcopy(g["allocations"][0])), "duplicate"),
    (lambda g: g["monetary_policy"].__setitem__("max_supply", "1"), "exceeds max_supply"),
    (lambda g: g["allocations"][0].__setitem__("amount", "1.5"), "schema"),
    (lambda g: g["allocations"][0].__setitem__("address", g["allocations"][0]["address"][:-1] + ("p" if g["allocations"][0]["address"][-1] == "q" else "q")), "checksum"),
    (lambda g: g.__setitem__("extra", 1), "schema"),
])
def test_invalid_genesis_rejected_by_both(net, tmp_path, mutate, needle):
    g = json.loads(net.genesis_path.read_text())
    mutate(g)
    py = spec.validate_genesis_py(g)
    p = tmp_path / "g.json"
    p.write_text(json.dumps(g))
    rs = cli("genesis", "validate", p, check=False)
    assert not py["ok"] or not rs.get("ok", False)
    assert not rs.get("ok", False), rs
    assert any(needle in e for e in py["errors"]) or needle in json.dumps(rs)


def test_genesis_contains_no_secrets(net):
    t = net.genesis_path.read_text()
    for marker in ("seed", "priv_key", "ciphertext", "passphrase"):
        assert marker not in t


def test_keystores_encrypted_and_private(net):
    ks = json.loads(net.keystore("alice").read_text())
    assert ks["kdf"]["name"] == "argon2id" and ks["cipher"]["name"] == "xchacha20poly1305"
    assert "seed" not in ks
    assert net.keystore("alice").stat().st_mode & 0o077 == 0
    assert (net.secrets.stat().st_mode & 0o077) == 0


def test_supply_preview_scheduled(net):
    g = json.loads(net.genesis_path.read_text())
    pv = spec.supply_preview(g, heights=(0, 10))
    genesis = int(pv["genesis_supply"])
    assert int(pv["rows"][1]["total_supply"]) == genesis + 10 * 50 * 10**6


def test_amount_parsing_exact():
    assert base_units("1.5", 6) == 1_500_000
    assert base_units("0.000001", 6) == 1
    with pytest.raises(ChainworksError):
        base_units("0.0000001", 6)
    assert fmt_units(1_500_000, 6, "ADC") == "1.500000 ADC"


def test_bech32m_rejects_wrong_prefix_and_case():
    a = bech32m.encode("aurd", bytes(20))
    assert bech32m.decode("aurd", a) == bytes(20)
    for bad in (a.upper(), a.replace("aurd", "aur", 1), a[:-1] + ("q" if a[-1] != "q" else "p")):
        with pytest.raises(ValueError):
            bech32m.decode("aurd", bad)


def test_patch_toml_requires_known_keys(tmp_path):
    p = tmp_path / "c.toml"
    p.write_text('moniker = "x"\n[p2p]\nladdr = "a"\n')
    patch_toml(p, {"": {"moniker": '"y"'}, "p2p": {"laddr": '"b"'}})
    assert 'laddr = "b"' in p.read_text()
    with pytest.raises(ChainworksError):
        patch_toml(p, {"p2p": {"nonexistent": "1"}})


def test_export_scan_detects_secrets(tmp_path):
    from chainworks.export import _scan
    (tmp_path / "ok.json").write_text('{"address": "x"}')
    assert _scan(tmp_path) == []
    (tmp_path / "leak.json").write_text('{"seed": "00"}')
    assert _scan(tmp_path)


def test_console_proxy_allowlist():
    from chainworks.console_server import ALLOWED_GET
    assert ALLOWED_GET.match("/v1/blocks?limit=5")
    assert ALLOWED_GET.match("/v1/accounts/aurd1abc/transactions")
    assert not ALLOWED_GET.match("/admin/v1/status")
    assert not ALLOWED_GET.match("/v1/../admin/v1/status")
    assert not ALLOWED_GET.match("/v1/blocks/..%2fadmin")
