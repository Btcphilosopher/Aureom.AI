"""A scripted stand-in for a node's public API (for indexer / gating / request tests).

Blocks are lists of (tx, receipt) built by helpers below; the chain can be swapped to
simulate a reorganisation. Token state for /v1/nft/tokens is derived from the current
chain so "authoritative" answers follow the chain like a real node.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

GEN = "ab" * 32


def bid(tag: str) -> str:
    return hashlib.sha256(tag.encode()).hexdigest()


def ev(kind, **attrs):
    return {"kind": kind, "attrs": {k: str(v) for k, v in attrs.items()}}


def tx(txid, sender, atype, events, status="success", error=None, action=None):
    a = {"type": atype, **(action or {})}
    return ({"id": txid, "sender": sender, "action": a}, {"txid": txid, "status": status, "error": error, "fee_paid": "20000", "events": [{"kind": "fee", "attrs": {}}] + events})


class FakeNode:
    def __init__(self, profile="pow"):
        self.profile = profile
        self.blocks = []          # list of dicts
        self.mempool = {}         # txid -> status
        self.submits = []
        self.fail_submit = False
        self.lock = threading.Lock()
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.url = f"http://127.0.0.1:{self.srv.server_address[1]}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()

    def set_chain(self, spec: list[tuple[str, list]]):
        """spec: [(block_tag, [tx,...]), ...] for heights 1..n (genesis id = bid('g'))."""
        with self.lock:
            prev = bid("g")
            self.blocks = []
            for h, (tag, txs) in enumerate(spec, 1):
                i = bid(tag)
                self.blocks.append({"height": h, "id": i, "prev_id": prev, "timestamp_ms": 1000 * h, "tx_count": len(txs),
                                    "txs": [t for t, _ in txs], "receipts": [r for _, r in txs]})
                prev = i

    def state(self):
        toks = {}
        for b in self.blocks:
            for r in b["receipts"]:
                if r["status"] != "success":
                    continue
                for e in r["events"]:
                    a = e["attrs"]
                    if e["kind"] == "nft_mint":
                        toks[(a["collection"], a["token_id"])] = {"owner": a["to"], "burned": False, "metadata": {"sha256": a["metadata_hash"], "uri": a["metadata_uri"]}, "revision": 0, "metadata_frozen": a.get("frozen") == "true"}
                    elif e["kind"] == "nft_transfer":
                        toks[(a["collection"], a["token_id"])]["owner"] = a["to"]
                    elif e["kind"] == "nft_burn":
                        toks[(a["collection"], a["token_id"])].update(owner=None, burned=True)
        return toks

    def _handler(node):
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def send(self, code, body):
                d = json.dumps(body).encode()
                self.send_response(code)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(d)))
                self.end_headers()
                self.wfile.write(d)

            def do_GET(self):
                p, _, q = self.path.partition("?")
                with node.lock:
                    if p == "/v1/network":
                        return self.send(200, {"chain_id": "fake-1", "genesis_hash": GEN, "profile": node.profile, "network_name": "Fake",
                                               "finality": "probabilistic" if node.profile == "pow" else "deterministic-bft", "confirmations_recommended": 2,
                                               "modules": {"collections": {"enabled": True, "marketplace": True}}})
                    if p == "/v1/health":
                        return self.send(200, {"height": len(node.blocks)})
                    m = re.match(r"^/v1/blocks/(\d+)$", p)
                    if m:
                        h = int(m.group(1))
                        if 1 <= h <= len(node.blocks):
                            return self.send(200, node.blocks[h - 1])
                        return self.send(404, {"error": {"code": "not_found"}})
                    m = re.match(r"^/v1/nft/tokens/([a-z0-9]+)/(\d+)$", p)
                    if m:
                        t = node.state().get((m.group(1), m.group(2)))
                        if not t:
                            return self.send(404, {"error": {"code": "not_found"}})
                        return self.send(200, {**t, "state_height": len(node.blocks)})
                    m = re.match(r"^/v1/nft/collections/([a-z0-9]+)/tokens$", p)
                    if m:
                        owner = dict(x.split("=") for x in q.split("&") if "=" in x).get("owner")
                        ts = [{"token_id": k[1], **v} for k, v in node.state().items() if k[0] == m.group(1) and (owner is None or v["owner"] == owner)]
                        return self.send(200, {"tokens": ts, "state_height": len(node.blocks)})
                    m = re.match(r"^/v1/nft/collections/([a-z0-9]+)$", p)
                    if m:
                        ts = [k for k in node.state() if k[0] == m.group(1)]
                        burned = sum(1 for k, v in node.state().items() if k[0] == m.group(1) and v["burned"])
                        return self.send(200, {"minted": len(ts), "burned": burned})
                    m = re.match(r"^/v1/transactions/([0-9a-f]+)$", p)
                    if m:
                        t = m.group(1)
                        for b in node.blocks:
                            for x, r in zip(b["txs"], b["receipts"]):
                                if x["id"] == t:
                                    conf = len(node.blocks) - b["height"] + 1
                                    return self.send(200, {"status": "confirmed" if conf >= 2 else "included", "block_height": b["height"], "confirmations": conf, "receipt": r})
                        if t in node.mempool:
                            return self.send(200, {"status": node.mempool[t]})
                        return self.send(200, {"status": "unknown"})
                    m = re.match(r"^/v1/accounts/(.+)$", p)
                    if m:
                        return self.send(200, {"nonce": 0})
                return self.send(404, {"error": {"code": "not_found", "message": p}})

            def do_POST(self):
                n = int(self.headers.get("content-length", "0"))
                body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/v1/transactions":
                    node.submits.append(body["tx"])
                    if node.fail_submit:
                        self.connection.close()  # outcome unknown to the client
                        return None
                    txid = hashlib.sha256(bytes.fromhex(body["tx"])).hexdigest()
                    if txid in node.mempool or any(x["id"] == txid for b in node.blocks for x in b["txs"]):
                        return self.send(400, {"error": {"code": "bad_nonce", "message": "already used"}})
                    node.mempool[txid] = "pending"
                    return self.send(202, {"id": txid, "status": "pending"})
                if self.path == "/v1/simulate":
                    return self.send(200, {"admissible": True, "receipt": {"status": "success", "events": []}, "simulated_height": len(node.blocks) + 1, "note": "fake"})
                return self.send(404, {})
        return H
