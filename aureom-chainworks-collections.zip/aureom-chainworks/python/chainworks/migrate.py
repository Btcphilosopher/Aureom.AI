"""Consensus migration *proposals* (PROTOCOL.md 14). A different profile always means a
new network. This module exports a checkpoint, an account-state mapping, a target genesis
draft and a validation report. It does not and cannot carry over security or history."""
from __future__ import annotations

import json
import pathlib

from . import bech32m, protocol as P
from .network import Network
from .spec import default_spec
from .util import ChainworksError, read_json, write_json


def _decode_snapshot(path: pathlib.Path):
    data = path.read_bytes()
    if data[:8] != b"AURSNAP1":
        raise ChainworksError("not a snapshot")
    body, digest = data[:-32], data[-32:]
    if P.H("AUREOM/SNAPSHOT/v1", body) != digest:
        raise ChainworksError("snapshot digest mismatch")
    r = P.R(body[8:])
    chain = r.bytes_(64).decode()
    gh, height, bid, root = r.take(32), r.u64(), r.take(32), r.take(32)
    n = r.u64()
    st = {}
    for _ in range(n):
        k = r.bytes_(1 << 16)
        v = r.bytes_(1 << 24)
        st[k] = v
    if P.state_root(st) != root:
        raise ChainworksError("snapshot state root mismatch")
    return {"chain_id": chain, "genesis_hash": gh.hex(), "height": height, "block_id": bid.hex(), "state_root": root.hex()}, st


def propose(net: Network, target_profile: str, out, node=None) -> dict:
    out = pathlib.Path(out)
    out.mkdir(parents=True, exist_ok=True)
    node = node or net.nodes()[0]["name"]
    snap = net.snapshot(node)
    hdr, st = _decode_snapshot(pathlib.Path(snap["path"]))
    src = read_json(net.genesis_path)
    hrp = src["native_asset"]["address_hrp"]
    accounts, tokens, staked, escrow = [], {}, 0, 0
    for k, v in st.items():
        if k[0] == 0x01:
            a = P.decode_account(v)
            accounts.append({"address": bech32m.encode(hrp, k[1:21]), "balance": str(a.balance), "nonce": a.nonce,
                             "vesting": [{"total": str(t), "start_height": s, "cliff_height": c, "end_height": e} for t, s, c, e in a.vesting],
                             "immature": [{"mature_height": h, "amount": str(x)} for h, x in a.immature]})
        elif k[0] == 0x03:
            r = P.R(v)
            amt = r.u128()
            tokens.setdefault(bech32m.encode(hrp + "tok", k[1:21]), []).append({"holder": bech32m.encode(hrp, k[21:41]), "amount": str(amt)})
        elif k[0] == 0x10:
            r = P.R(v)
            op, _ck = r.take(20), r.take(32)
            r.bytes_(64)
            staked_v = r.u128()
            staked += staked_v
            if staked_v:
                accounts.append({"address": bech32m.encode(hrp, op), "balance": str(staked_v), "nonce": 0, "vesting": [], "immature": [],
                                 "note": "bonded stake converted to a liquid balance"})
        elif k[0] == 0x06:
            escrow += 1
    # merge duplicate addresses (stake + balance)
    merged: dict = {}
    for a in accounts:
        m = merged.setdefault(a["address"], {"address": a["address"], "balance": 0, "vesting": [], "notes": []})
        m["balance"] += int(a["balance"])
        m["vesting"] += a["vesting"]
        if a.get("note"):
            m["notes"].append(a["note"])
        if a["immature"]:
            m["notes"].append("immature PoW rewards included as liquid balance")
    draft = default_spec(target_profile, name=src["network_name"] + f" (migrated to {target_profile})", chain_id=src["chain_id"] + f"-{target_profile}")
    allocs = []
    for m in merged.values():
        if m["balance"] == 0:
            continue
        e = {"address": m["address"], "amount": str(m["balance"]), "label": "migrated"}
        if len(m["vesting"]) == 1:
            v = m["vesting"][0]
            if int(v["total"]) == m["balance"]:
                e["vesting"] = {"start_height": 0, "cliff_height": max(0, v["cliff_height"] - hdr["height"]), "end_height": max(1, v["end_height"] - hdr["height"])}
        allocs.append(e)
    total = sum(int(a["amount"]) for a in allocs)
    target = {"genesis_format": 1, "protocol_version": 1, "network_name": draft["network_name"], "chain_id": draft["chain_id"],
              "genesis_time_ms": 0, "consensus": draft["consensus"], "native_asset": src["native_asset"], "monetary_policy": src["monetary_policy"],
              "fee_policy": src["fee_policy"], "limits": src["limits"], "allocations": allocs, "treasuries": [], "validators": [],
              "governance": src["governance"], "upgrades": []}
    report = {
        "source": {"chain_id": src["chain_id"], "profile": src["consensus"]["profile"], "genesis_hash": hdr["genesis_hash"]},
        "checkpoint": hdr, "target_profile": target_profile,
        "accounts_mapped": len(allocs), "native_total_mapped": str(total), "staked_converted": str(staked),
        "tokens_requiring_reissuance": {t: len(h) for t, h in tokens.items()},
        "open_distributions_not_migrated": escrow,
        "warnings": [
            "This is a NEW network. It does not inherit the source chain's security, history, finality or validator set.",
            "Validators/authorities for the target must be added before the draft genesis is valid (validators: []).",
            "Treasury multisigs are mapped as plain balances of their multisig address, which has no key on the new chain unless re-created; review manually.",
            "Tokens are not representable in genesis v1 and must be re-issued (holder table provided).",
            "Vesting heights were rebased to the new chain's height 0; review against calendar expectations.",
            "Nonces are not carried over; signed but unsubmitted source-chain transactions are invalid on the target (different chain id).",
        ],
    }
    write_json(out / "checkpoint.json", hdr)
    write_json(out / "account-mapping.json", {"accounts": list(merged.values()), "tokens": tokens})
    write_json(out / "target-genesis.draft.json", target)
    write_json(out / "validation-report.json", report)
    return {"out": str(out), **{k: report[k] for k in ("checkpoint", "accounts_mapped", "native_total_mapped")}}
