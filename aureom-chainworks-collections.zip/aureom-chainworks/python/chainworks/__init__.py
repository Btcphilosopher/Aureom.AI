"""AUREOM CHAINWORKS orchestration, configuration validation, testing and analysis."""
__version__ = "0.1.0"
