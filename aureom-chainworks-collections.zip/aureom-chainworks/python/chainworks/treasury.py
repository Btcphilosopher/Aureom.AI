"""Treasury management: budgets (off-chain policy), payment proposals and approvals
(on-chain multisig transactions), history and public allocation reports.

Separation of duties:
  proposal   — a signer submits MultisigPropose (one signed transaction)
  approval   — other signers each submit MultisigApprove (separately signed)
  signing    — each signer's key stays in its own keystore; aureom-cli signs locally
  settlement — the state machine executes the inner payment when approvals >= threshold
A budget check here is an operational guard rail, not a protocol rule.
"""
from __future__ import annotations

import time

from .network import Network
from .util import ChainworksError, read_json, try_get, write_json
from .wallet import Wallet


def _bpath(net):
    return net.dir / "treasury" / "budgets.json"


def treasury_address(net: Network, index=0) -> str:
    return net._treasury_address(index)


def set_budget(net: Network, category: str, limit: int, period_label: str = "") -> dict:
    p = _bpath(net)
    b = read_json(p) if p.exists() else {"categories": {}, "payments": []}
    b["categories"][category] = {"limit": str(limit), "period": period_label}
    write_json(p, b)
    return b


def propose_payment(net: Network, proposer: str, to: str, amount: int, category: str, memo: str = "", ttl=500, node=None) -> dict:
    b = read_json(_bpath(net)) if _bpath(net).exists() else {"categories": {}, "payments": []}
    if category not in b["categories"]:
        raise ChainworksError(f"no budget category {category!r}")
    spent = sum(int(x["amount"]) for x in b["payments"] if x["category"] == category and x.get("state") != "failed")
    if spent + amount > int(b["categories"][category]["limit"]):
        raise ChainworksError(f"budget exceeded for {category}: spent/proposed {spent} + {amount} > {b['categories'][category]['limit']}")
    w = Wallet(net, node)
    tre = treasury_address(net)
    ms = try_get(f"{w.api}/v1/multisigs/{tre}")
    pid = len(ms["proposals"]) if ms else 0
    to_addr = to if to.startswith(net.spec["native_asset"]["address_hrp"] + "1") else net.address(to)
    h = try_get(f"{w.api}/v1/health")["height"]
    r = w.send(proposer, {"type": "multisig_propose", "multisig": tre, "inner": {"type": "transfer", "to": to_addr, "amount": str(amount)},
                          "expiry_height": h + ttl}, memo=memo[:200])
    b["payments"].append({"proposal_id": pid, "to": to_addr, "amount": str(amount), "category": category, "proposer": proposer,
                          "propose_txid": r["txid"], "state": "proposed", "memo": memo, "at": int(time.time())})
    write_json(_bpath(net), b)
    return {"proposal_id": pid, **{k: r.get(k) for k in ("txid", "status", "block_height")}, "receipt": r.get("receipt")}


def approve(net: Network, signer: str, proposal_id: int, node=None) -> dict:
    w = Wallet(net, node)
    r = w.send(signer, {"type": "multisig_approve", "multisig": treasury_address(net), "proposal_id": proposal_id})
    ms = try_get(f"{w.api}/v1/multisigs/{treasury_address(net)}")
    prop = next((p for p in ms["proposals"] if p["id"] == proposal_id), None)
    b = read_json(_bpath(net))
    for x in b["payments"]:
        if x["proposal_id"] == proposal_id and prop:
            x["state"] = prop["status"]
    write_json(_bpath(net), b)
    return {"txid": r["txid"], "status": r.get("status"), "receipt": r.get("receipt"), "proposal": prop}


def report(net: Network, node=None) -> dict:
    w = Wallet(net, node)
    tre = treasury_address(net)
    ms = try_get(f"{w.api}/v1/multisigs/{tre}") or {}
    b = read_json(_bpath(net)) if _bpath(net).exists() else {"categories": {}, "payments": []}
    usage = {}
    for c, v in b["categories"].items():
        executed = sum(int(p["amount"]) for p in b["payments"] if p["category"] == c and p["state"] == "executed")
        usage[c] = {"limit": v["limit"], "executed": str(executed)}
    return {"treasury": tre, "on_chain": {"balance": ms.get("balance"), "signers": ms.get("signers"), "threshold": ms.get("threshold"),
            "proposals": ms.get("proposals")}, "budgets": usage, "payments": b["payments"],
            "note": "on_chain values are read from the node API; budgets are off-chain operational policy"}
