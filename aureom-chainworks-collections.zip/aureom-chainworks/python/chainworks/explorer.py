"""Optional PostgreSQL explorer index. Derived data only: it is rebuilt from node APIs,
never consulted by consensus, and can be dropped at any time (`--rebuild`)."""
from __future__ import annotations

import json

from .network import Network
from .util import ChainworksError, get

SCHEMA = """
CREATE TABLE IF NOT EXISTS cw_meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS cw_blocks (height BIGINT PRIMARY KEY, id TEXT NOT NULL, ts_ms BIGINT, proposer TEXT, tx_count INT, raw JSONB NOT NULL);
CREATE TABLE IF NOT EXISTS cw_txs (txid TEXT PRIMARY KEY, height BIGINT NOT NULL REFERENCES cw_blocks(height) ON DELETE CASCADE, idx INT,
  sender TEXT, type TEXT, status TEXT, fee NUMERIC, raw JSONB NOT NULL);
CREATE TABLE IF NOT EXISTS cw_events (height BIGINT NOT NULL REFERENCES cw_blocks(height) ON DELETE CASCADE, txid TEXT, kind TEXT, attrs JSONB);
CREATE INDEX IF NOT EXISTS cw_txs_sender ON cw_txs(sender);
CREATE INDEX IF NOT EXISTS cw_events_kind ON cw_events(kind);
"""


def _conn(dsn):
    try:
        import psycopg
    except ImportError as e:
        raise ChainworksError("psycopg is required for the PostgreSQL explorer index (pip install 'psycopg[binary]')") from e
    return psycopg.connect(dsn, autocommit=False)


def index(net: Network, dsn: str, node=None, rebuild=False, limit=None) -> dict:
    node = node or net.nodes()[0]["name"]
    api = net.api(node)
    info = get(api + "/v1/network")
    with _conn(dsn) as c:
        cur = c.cursor()
        if rebuild:
            cur.execute("DROP TABLE IF EXISTS cw_events, cw_txs, cw_blocks, cw_meta")
        cur.execute(SCHEMA)
        cur.execute("SELECT v FROM cw_meta WHERE k='genesis_hash'")
        r = cur.fetchone()
        if r and r[0] != info["genesis_hash"]:
            raise ChainworksError("index belongs to another chain; use --rebuild")
        cur.execute("INSERT INTO cw_meta VALUES ('genesis_hash', %s) ON CONFLICT (k) DO UPDATE SET v=excluded.v", (info["genesis_hash"],))
        cur.execute("SELECT coalesce(max(height), 0) FROM cw_blocks")
        last = cur.fetchone()[0]
        tip = get(api + "/v1/health")["height"]
        start = 1 if last == 0 else last + 1
        # PoW: re-check the last indexed block is still on the main chain; roll back if reorganised
        removed = 0
        while last > 0:
            cur.execute("SELECT id FROM cw_blocks WHERE height=%s", (last,))
            (bid,) = cur.fetchone()
            b = get(f"{api}/v1/blocks/{last}")
            if b["id"] == bid:
                break
            cur.execute("DELETE FROM cw_blocks WHERE height=%s", (last,))
            removed += 1
            last -= 1
            start = last + 1
        n = 0
        for h in range(start, tip + 1):
            if limit and n >= limit:
                break
            b = get(f"{api}/v1/blocks/{h}")
            cur.execute("INSERT INTO cw_blocks VALUES (%s,%s,%s,%s,%s,%s)", (h, b["id"], b["timestamp_ms"], b.get("proposer"), b["tx_count"], json.dumps(b)))
            rc = {r["txid"]: r for r in b.get("receipts", [])}
            for i, t in enumerate(b["txs"]):
                r = rc.get(t.get("id"), {})
                cur.execute("INSERT INTO cw_txs VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (txid) DO NOTHING",
                            (t.get("id"), h, i, t.get("sender"), t.get("action", {}).get("type"), r.get("status"), int(t.get("fee", 0)), json.dumps(t)))
                for e in r.get("events", []):
                    cur.execute("INSERT INTO cw_events VALUES (%s,%s,%s,%s)", (h, t.get("id"), e["kind"], json.dumps(e["attrs"])))
            n += 1
        c.commit()
    return {"indexed_blocks": n, "from": start, "tip": tip, "rolled_back": removed}


def query(dsn: str, sql_name: str, arg: str | None = None) -> list:
    q = {
        "supply_events": "SELECT height, kind, attrs FROM cw_events WHERE kind IN ('mint','burn','token_create','token_admin','msig_execute','vesting') ORDER BY height",
        "by_sender": "SELECT txid, height, type, status FROM cw_txs WHERE sender=%s ORDER BY height",
        "counts": "SELECT (SELECT count(*) FROM cw_blocks), (SELECT count(*) FROM cw_txs), (SELECT count(*) FROM cw_events)",
    }[sql_name]
    with _conn(dsn) as c:
        cur = c.cursor()
        cur.execute(q, (arg,) if "%s" in q else None)
        return [list(r) for r in cur.fetchall()]
