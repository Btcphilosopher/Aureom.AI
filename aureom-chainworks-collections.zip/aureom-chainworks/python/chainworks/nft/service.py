"""AUREOM COLLECTIONS service layer over a Chainworks network directory.

Keys never enter this process: every transaction is prepared here, reviewed and
simulated, then signed by `aureom-cli` from its encrypted keystore (see wallet.py).
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import pathlib
import re

from .. import bech32m
from ..network import Network
from ..util import ChainworksError, cli, get, read_json, write_json
from ..wallet import Wallet
from . import media as mediamod
from . import metadata as md
from .authenticity import Claims
from .db import now_ms, open_db, tx
from .gating import Gate
from .indexer import Indexer
from .requests import Requests
from .storage import IpfsAdapter, LocalObjectStore

LOCAL_URL_NOTE = "local development URL served by `chainworks console`; not publicly resolvable"
MAX_BATCH = 32


def hrp(net: Network) -> str:
    return net.spec["native_asset"]["address_hrp"]


def powers_preview(a: dict) -> list[dict]:
    """Plain-language administrative powers of a collection-create action (before signing)."""
    out = []
    ms = a.get("max_supply")
    out.append({"power": "mint new tokens", "holder": a.get("mint_authority") or "nobody", "limit": f"at most {ms} tokens ever" if ms else "UNCAPPED",
                "risk": "high" if a.get("mint_authority") and not ms else "normal"})
    pol = a["metadata_policy"]
    out.append({"power": "change token metadata", "holder": a.get("metadata_admin") or "nobody",
                "limit": {"immutable": "never: content hash fixed at mint", "freezable": "recorded revisions until a permanent freeze", "mutable": "recorded revisions, no freeze"}[pol],
                "risk": "none" if pol == "immutable" else "medium"})
    if a.get("pausable"):
        out.append({"power": "pause transfers, minting and sales", "holder": a.get("admin"), "limit": "reversible", "risk": "high"})
    if a.get("forced_transfer"):
        out.append({"power": "FORCE-TRANSFER any token without the owner's signature", "holder": a.get("admin"), "limit": "publicly recorded with a reason hash", "risk": "critical"})
    if a.get("owner_burn"):
        out.append({"power": "burn own token", "holder": "each owner", "limit": "holder right; ids never reused", "risk": "none"})
    if a.get("transfer_policy") == "non_transferable":
        out.append({"power": "transfer tokens", "holder": "nobody", "limit": "non-transferable (only mint/burn)", "risk": "none"})
    if a.get("royalty"):
        out.append({"power": "receive royalties on native-marketplace sales", "holder": a["royalty"]["recipient"], "limit": f"{a['royalty']['bps']} bps; other marketplaces and direct transfers may ignore it", "risk": "none"})
    return out


class Collections:
    def __init__(self, net: Network | str, node: str | None = None, db_path=None):
        self.net = net if isinstance(net, Network) else Network(net)
        self.node = node or self.net.nodes()[0]["name"]
        self.w = Wallet(self.net, self.node)
        self.home = self.net.dir / "collections"
        self.db = open_db(db_path or self.home / "collections.db")
        self.local = LocalObjectStore(self.home / "objects", public_base=self.public_base())
        self.ipfs = IpfsAdapter()
        self._ix = None

    def public_base(self) -> str:
        cfg = self.home / "storage.json"
        if cfg.exists():
            return read_json(cfg).get("public_base", "http://127.0.0.1:8787/media")
        return "http://127.0.0.1:8787/media"

    @property
    def api(self):
        return self.net.api(self.node)

    @property
    def ix(self) -> Indexer:
        if self._ix is None:
            self._ix = Indexer(self.db, self.api, self.node)
        return self._ix

    @property
    def key(self) -> str:
        return self.ix.key

    @property
    def requests(self) -> Requests:
        return Requests(self.db, self.net, self.w, self.key)

    def network(self) -> dict:
        return self.ix.net

    # ------------------------------------------------------------------ media
    def add_media(self, data: bytes, name: str, alt_text: str | None = None, transcript: str | None = None, licence: str | None = None, ipfs: bool = False) -> dict:
        info = mediamod.validate(data, name, alt_text, transcript)
        with tx(self.db):
            self.db.execute("INSERT OR IGNORE INTO media_assets VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (info["media_id"], info["sha256"], info["kind"], info["mime"], info["bytes"], info.get("width"), info.get("height"), name, alt_text, transcript,
                             info["cid_raw_v1"], licence, json.dumps({"warnings": info["warnings"]}), now_ms()))
        locs = [self._store(data, info["sha256"], "media", name, self.local)]
        if ipfs:
            if self.ipfs.available():
                locs.append(self._store(data, info["sha256"], "media", name, self.ipfs))
            else:
                info["warnings"].append("IPFS requested but no IPFS node is reachable at " + self.ipfs.api + "; stored locally only")
        info["locations"] = locs
        info["uri"] = next((x["public_uri"] for x in locs if x["adapter"] == "ipfs"), None) or locs[0]["public_uri"]
        return info

    def _store(self, data, sha, kind, name, adapter) -> dict:
        s = adapter.put(data, sha, name)
        with tx(self.db):
            self.db.execute("INSERT OR IGNORE INTO storage_locations (content_sha256, content_kind, adapter, locator, public_uri, maintainer, monitoring, added_at_ms) VALUES (?,?,?,?,?,?,?,?)",
                            (sha, kind, s.adapter, s.locator, s.public_uri, s.maintainer, s.monitoring, now_ms()))
        return {"adapter": s.adapter, "locator": s.locator, "public_uri": s.public_uri, "maintainer": s.maintainer, "monitoring": s.monitoring,
                "note": LOCAL_URL_NOTE if s.adapter == "local" and "127.0.0.1" in (s.public_uri or "") else
                ("pinned on our IPFS node only; a CID does not guarantee anyone keeps hosting the file" if s.adapter == "ipfs" else None)}

    def media_ref(self, sha256: str, role: str = "image") -> dict:
        r = self.db.execute("SELECT * FROM media_assets WHERE sha256 = ?", (sha256,)).fetchone()
        if not r:
            raise ChainworksError(f"unknown media {sha256}")
        uri = self.db.execute("SELECT public_uri FROM storage_locations WHERE content_sha256 = ? ORDER BY adapter = 'ipfs' DESC, location_id LIMIT 1", (sha256,)).fetchone()["public_uri"]
        ref = md.media_ref(dict(r), uri, role)
        if r["bytes"] <= 256 * 1024:
            ref["cid_raw_v1"] = r["cid_raw_v1"]
        return ref

    # ------------------------------------------------------------------ metadata
    def put_metadata(self, doc: dict, slug: str | None = None, token_id=None) -> dict:
        v = md.validate(doc)
        b = md.canonical_bytes(doc)
        media = [x["sha256"] for x in [doc.get("image") or doc.get("artwork") or {}] + doc.get("media", []) if x.get("sha256")]
        with tx(self.db):
            self.db.execute("INSERT OR IGNORE INTO metadata_documents VALUES (?,?,?,?,?,?,?,?,?)",
                            (v["sha256"], doc["schema"], b, doc.get("name") or doc.get("rights_holder", ""), slug, None if token_id is None else str(token_id), json.dumps(media), json.dumps(v["warnings"]), now_ms()))
        loc = self._store(b, v["sha256"], "metadata", f"{v['sha256']}.json", self.local)
        return {"uri": loc["public_uri"], "sha256": v["sha256"], "bytes": len(b), "warnings": v["warnings"] + ([LOCAL_URL_NOTE] if loc.get("note") else []), "preview": md.preview(doc) if doc["schema"] != md.RIGHTS_SCHEMA else None}

    def get_content(self, sha256: str) -> tuple[bytes, str] | None:
        if not re.fullmatch(r"[0-9a-f]{64}", sha256):
            return None
        p = self.local.path(sha256)
        if not p.exists():
            return None
        m = self.db.execute("SELECT mime FROM media_assets WHERE sha256 = ?", (sha256,)).fetchone()
        return p.read_bytes(), (m["mime"] if m else "application/json")

    # ------------------------------------------------------------------ storage monitoring
    def storage_check(self) -> dict:
        res = []
        adapters = {"local": self.local, "ipfs": self.ipfs}
        for loc in self.db.execute("SELECT * FROM storage_locations").fetchall():
            a = adapters.get(loc["adapter"])
            if a is None:
                continue
            c = a.check(loc["locator"], loc["content_sha256"])
            with tx(self.db):
                self.db.execute("INSERT INTO storage_checks (location_id, checked_at_ms, available, hash_matches, http_status, latency_ms, detail) VALUES (?,?,?,?,?,?,?)",
                                (loc["location_id"], now_ms(), int(c.available), None if c.hash_matches is None else int(c.hash_matches), c.http_status, c.latency_ms, c.detail))
            res.append({"content": loc["content_sha256"], "kind": loc["content_kind"], "adapter": loc["adapter"], "available": c.available, "hash_matches": c.hash_matches, "detail": c.detail})
        return {"checked": len(res), "healthy": sum(1 for r in res if r["available"] and r["hash_matches"]), "problems": [r for r in res if not (r["available"] and r["hash_matches"])], "results": res}

    def storage_health(self) -> list[dict]:
        rows = self.db.execute("""SELECT l.*, (SELECT available FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_available,
                                  (SELECT hash_matches FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_hash_ok,
                                  (SELECT checked_at_ms FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_checked,
                                  (SELECT detail FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_detail
                                  FROM storage_locations l ORDER BY l.location_id""").fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ collection wizard
    def collection_action(self, answers: dict) -> dict:
        """Wizard answers -> exact on-chain action (minimal privileges by default)."""
        A = lambda x: x if (x is None or x.startswith(hrp(self.net) + "1")) else self.net.address(x)  # noqa: E731
        pol = answers.get("metadata_policy", "freezable")
        a = {"type": "nft_collection_create", "slug": answers["slug"], "name": answers["name"],
             "collection_metadata": answers["collection_metadata"], "max_supply": answers.get("max_supply"),
             "mint_authority": A(answers.get("mint_authority")), "metadata_policy": pol,
             "metadata_admin": None if pol == "immutable" else A(answers.get("metadata_admin") or answers.get("mint_authority")),
             "admin": A(answers.get("admin")) if (answers.get("pausable") or answers.get("forced_transfer")) else None,
             "pausable": bool(answers.get("pausable")), "forced_transfer": bool(answers.get("forced_transfer")), "owner_burn": bool(answers.get("owner_burn", True)),
             "transfer_policy": answers.get("transfer_policy", "transferable"),
             "royalty": {"recipient": A(answers["royalty"]["recipient"]), "bps": int(answers["royalty"]["bps"])} if answers.get("royalty") else None,
             "rights_holder": answers["rights_holder"], "rights": answers["rights"]}
        return a

    def create_collection(self, creator: str, answers: dict, idempotency_key: str | None = None) -> dict:
        a = self.collection_action(answers)
        nonce = self.w.account(creator)["nonce"]
        derived = cli("derive", "--genesis", self.net.genesis_path, "--kind", "collection", "--creator", self.net.address(creator), "--nonce", nonce)["collection_id"]
        powers = powers_preview(a)
        req = self.requests.create("other", creator, a, idempotency_key or f"collection:{a['slug']}", collection_id=derived, nonce=nonce)
        req = self.requests.validate(req["request_id"])
        with tx(self.db):
            self.db.execute("INSERT OR REPLACE INTO collection_drafts VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (req["request_id"], self.key, a["slug"], self.net.address(creator), json.dumps(a), json.dumps(powers), "prepared", req["txid"], derived, now_ms(), now_ms()))
        return {"request": req, "derived_collection_id": derived, "administrative_powers": powers, "action": a,
                "note": "the collection id becomes real only when this transaction succeeds on chain"}

    # ------------------------------------------------------------------ minting
    def mint(self, collection_id: str, token_id: int, to: str, metadata: dict, idempotency_key: str | None = None) -> dict:
        authority = self.collection(collection_id)["roles"]["mint_authority"]
        sender = self._label(authority)
        to_a = to if to.startswith(hrp(self.net) + "1") else self.net.address(to)
        act = {"type": "nft_mint", "collection": collection_id, "item": {"token_id": str(token_id), "to": to_a, "metadata": {"uri": metadata["uri"], "sha256": metadata["sha256"]}}}
        return self.requests.create("mint", sender, act, idempotency_key or f"mint:{collection_id}:{token_id}", collection_id, [token_id])

    def _label(self, address: str) -> str:
        for a in self.net.spec["accounts"]:
            if self.net.address(a["label"]) == address:
                return a["label"]
        raise ChainworksError(f"no local keystore for {address}; that role must sign elsewhere (external signer)")

    def batch_plan(self, collection_id: str, rows: list[dict], name: str) -> dict:
        """Reviewed batch minting: validate a whole allocation before anything is signed."""
        col = self.collection(collection_id)
        problems, items, seen = [], [], set()
        onchain = {t["token_id"] for t in get(f"{self.api}/v1/nft/collections/{collection_id}/tokens?limit=5000")["tokens"]}
        for i, r in enumerate(rows):
            try:
                tid = int(r["token_id"])
            except (KeyError, ValueError):
                problems.append(f"row {i}: token_id must be an integer")
                continue
            if tid in seen:
                problems.append(f"row {i}: duplicate token_id {tid} in plan")
                continue
            seen.add(tid)
            to = r.get("to", "")
            try:
                to_a = to if to.startswith(hrp(self.net) + "1") else self.net.address(to)
                if len(bech32m.decode(hrp(self.net), to_a)) != 20:
                    raise ValueError("length")
            except Exception:  # noqa: BLE001
                problems.append(f"row {i}: invalid recipient {to!r}")
                continue
            m = self.db.execute("SELECT metadata_sha256 FROM metadata_documents WHERE metadata_sha256 = ?", (r.get("metadata_sha256", ""),)).fetchone()
            if not m:
                problems.append(f"row {i}: metadata document {r.get('metadata_sha256')!r} not registered (upload is not minting: register the document first)")
                continue
            if str(tid) in onchain:
                problems.append(f"row {i}: token {tid} already exists on chain")
                continue
            items.append({"token_id": str(tid), "to": to_a, "metadata": {"uri": f"{self.public_base()}/{m['metadata_sha256']}", "sha256": m["metadata_sha256"]}})
        ms = col["max_supply"]
        if ms is not None and col["minted"] + len(items) > int(ms):
            problems.append(f"supply limit: {col['minted']} minted + {len(items)} planned > max_supply {ms}")
        chunks = [items[i:i + MAX_BATCH] for i in range(0, len(items), MAX_BATCH)]
        plan = {"name": name, "collection_id": collection_id, "network_key": self.key, "items": items, "chunks": len(chunks),
                "mint_authority": col["roles"]["mint_authority"], "problems": problems, "ok": not problems,
                "recipients": sorted({i["to"] for i in items}), "per_recipient": {a: sum(1 for i in items if i["to"] == a) for a in sorted({i["to"] for i in items})}}
        plan["plan_id"] = hashlib.sha256(json.dumps({k: plan[k] for k in ("collection_id", "network_key", "items")}, sort_keys=True).encode()).hexdigest()[:16]
        write_json(self.home / "plans" / f"{plan['plan_id']}.json", plan)
        return plan

    def batch_run(self, plan_id: str, approve: str, stop_after: int | None = None) -> dict:
        if approve != plan_id:
            raise ChainworksError("batch minting requires --approve <plan_id> of the reviewed plan")
        plan = read_json(self.home / "plans" / f"{plan_id}.json")
        if not plan["ok"]:
            raise ChainworksError("plan has problems; fix them and re-plan: " + "; ".join(plan["problems"]))
        sender = self._label(plan["mint_authority"])
        out = []
        chunks = [plan["items"][i:i + MAX_BATCH] for i in range(0, len(plan["items"]), MAX_BATCH)]
        for n, ch in enumerate(chunks):
            idem = f"batch:{plan_id}:{n}"
            req = self.requests.create("mint_batch", sender, {"type": "nft_mint_batch", "collection": plan["collection_id"], "items": ch}, idem, plan["collection_id"], [i["token_id"] for i in ch])
            if req["status"] in ("indexed", "confirmed", "finalised"):
                out.append({"chunk": n, "request_id": req["request_id"], "status": req["status"], "skipped": "already done"})
                continue
            req = self.requests.run(req["request_id"], self.ix)
            out.append({"chunk": n, "request_id": req["request_id"], "status": req["status"], "txid": req["txid"], "tokens": len(ch)})
            if stop_after is not None and n + 1 >= stop_after:
                return {"plan_id": plan_id, "chunks": out, "interrupted": True}
        return {"plan_id": plan_id, "chunks": out, "interrupted": False}

    # ------------------------------------------------------------------ chain reads
    def collection(self, cid_or_slug: str) -> dict:
        return get(f"{self.api}/v1/nft/collections/{cid_or_slug}")

    def token(self, cid: str, tid) -> dict:
        return get(f"{self.api}/v1/nft/tokens/{cid}/{tid}")

    def owner_of(self, cid: str, tid) -> dict:
        """Authoritative owner query (chain), with the index view alongside for comparison."""
        t = self.token(cid, tid)
        row = self.db.execute("SELECT owner, as_of_height FROM ownership_cache WHERE network_key = ? AND collection_id = ? AND token_id = ?", (self.key, cid, str(tid))).fetchone()
        return {"ref": t["ref"], "owner": t["owner"], "burned": t["burned"], "chain_height": t["state_height"], "source": "chain (authoritative)",
                "index": dict(row) if row else None, "index_agrees": bool(row) and row["owner"] == t["owner"]}

    # ------------------------------------------------------------------ freeze preview
    def freeze_preview(self, cid: str, token_id=None) -> dict:
        """Exactly what a freeze will make permanent, and the expected value to sign."""
        col = self.collection(cid)
        if token_id is not None:
            t = self.token(cid, token_id)
            return {"scope": {"token_id": str(token_id)}, "expected": t["metadata"]["sha256"], "affected": [{"ref": t["ref"], "metadata": t["metadata"], "revision": t["revision"],
                    "document": self._doc_summary(t["metadata"]["sha256"])}], "permanent": True}
        toks = get(f"{self.api}/v1/nft/collections/{cid}/tokens?limit=5000")["tokens"]
        live = [t for t in toks if not t["burned"]]
        return {"scope": "collection", "expected": col["metadata_root"], "affected": [{"ref": t["ref"], "metadata": t["metadata"], "revision": t["revision"]} for t in live],
                "also": "every token minted later is frozen from birth; the metadata administrator role is removed", "permanent": True}

    def _doc_summary(self, sha):
        r = self.db.execute("SELECT media_sha256_json, name FROM metadata_documents WHERE metadata_sha256 = ?", (sha,)).fetchone()
        return {"name": r["name"], "media_sha256": json.loads(r["media_sha256_json"])} if r else {"note": "document not in this application's store"}

    # ------------------------------------------------------------------ provenance
    def provenance(self, cid: str, tid) -> dict:
        self.ix.sync()
        tip = self.ix.tip()
        t = self.token(cid, tid)
        rows = self.db.execute("SELECT * FROM provenance_events WHERE network_key = ? AND collection_id = ? AND (token_id = ? OR token_id IS NULL) ORDER BY height, tx_index, event_index",
                               (self.key, cid, str(tid))).fetchall()
        events = []
        for r in rows:
            a = json.loads(r["attrs_json"])
            if r["token_id"] is None and r["kind"] not in ("nft_collection_create", "nft_authority", "nft_admin") and not (r["kind"] == "nft_metadata" and a.get("op") == "freeze_collection"):
                continue
            events.append({"height": r["height"], "block_id": r["block_id"], "txid": r["txid"], "kind": r["kind"], "op": r["op"], "from": r["from_addr"], "to": r["to_addr"],
                           "actor": r["actor"], "attrs": a, "settlement": self.ix.settlement(r["height"], tip)})
        col = self.collection(cid)
        docs = []
        for rv in t["revisions"]:
            docs.append({"revision": rv["revision"], "metadata": rv["metadata"], "height": rv["height"], "by": rv["by"], "storage": self._locations(rv["metadata"]["sha256"]),
                         "document": self._doc_summary(rv["metadata"]["sha256"])})
        export = {
            "format": "aureom-provenance/v1",
            "ref": t["ref"],
            "network": {"chain_id": self.network()["chain_id"], "genesis_hash": self.network()["genesis_hash"], "profile": self.network()["profile"], "settlement": self.network().get("finality")},
            "current": {"owner": t["owner"], "burned": t["burned"], "metadata": t["metadata"], "revision": t["revision"], "metadata_frozen": t["metadata_frozen"],
                        "approved": t["approved"], "chain_height": t["state_height"], "source": "chain (authoritative)"},
            "collection": {"collection_id": cid, "slug": col["spec"]["slug"], "name": col["spec"]["name"], "roles": col["roles"], "metadata_policy": col["metadata_policy"],
                           "administrative_powers": col["administrative_powers"]},
            "events": events,
            "metadata_revisions": docs,
            "authority_log": get(f"{self.api}/v1/nft/collections/{cid}/authority-log")["authority_changes"],
            "off_chain_reviews": [x for x in Claims(self.db, self.key).list(cid) if x["token_id"] in (None, str(tid))],
            "statements": ["A ledger entry proves that a transaction was recorded; it does not prove issuer claims.",
                           "Owning the token does not transfer copyright or any physical object.",
                           "Storage availability is monitored, not guaranteed."],
            "generated_at_ms": now_ms(),
        }
        body = json.dumps(export, sort_keys=True, separators=(",", ":")).encode()
        export["export_sha256"] = hashlib.sha256(body).hexdigest()
        return export

    def provenance_csv(self, prov: dict) -> str:
        f = io.StringIO()
        w = csv.writer(f)
        w.writerow(["height", "block_id", "txid", "kind", "op", "from", "to", "actor", "settlement"])
        for e in prov["events"]:
            w.writerow([e["height"], e["block_id"], e["txid"], e["kind"], e["op"], e["from"], e["to"], e["actor"], e["settlement"]["state"]])
        return f.getvalue()

    def _locations(self, sha):
        return [dict(r) for r in self.db.execute("""SELECT l.adapter, l.locator, l.public_uri, l.maintainer, l.monitoring,
            (SELECT available FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_available,
            (SELECT checked_at_ms FROM storage_checks c WHERE c.location_id = l.location_id ORDER BY check_id DESC LIMIT 1) AS last_checked_ms
            FROM storage_locations l WHERE content_sha256 = ?""", (sha,))]

    # ------------------------------------------------------------------ gating / claims
    def gate(self) -> Gate:
        return Gate(self.db, self.api, self.network(), hrp(self.net))

    def claims(self) -> Claims:
        return Claims(self.db, self.key)

    def sign_message(self, label: str, message: str) -> dict:
        """Development wallet: sign an off-chain message with aureom-cli (key stays in the keystore)."""
        f = self.net.dir / "secrets" / f"msg-{now_ms()}.txt"
        f.write_text(message)
        try:
            return cli("message", "sign", "--keystore", self.net.keystore(label), "--passphrase-file", self.net.passfile(label), "--message", f"@{f}")
        finally:
            f.unlink()


def collection_dir(net_dir) -> pathlib.Path:
    return pathlib.Path(net_dir) / "collections"
