"""Object-storage adapters for media files and metadata documents.

Persistence is never implied by an identifier:
* a local or S3 object exists only while its operator keeps the disk/bucket;
* an IPFS CID names content, it does not host it — the file stays retrievable only while
  at least one reachable node pins it. Pinning on *our* node says nothing about others;
* an HTTP URL is available only while its server serves it.
Each stored copy is recorded with who maintains it and how availability is monitored,
and `check()` re-fetches the bytes and compares their SHA-256 with the recorded hash.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import hmac
import json
import os
import pathlib
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass


@dataclass
class Stored:
    adapter: str
    locator: str
    public_uri: str | None
    maintainer: str
    monitoring: str


@dataclass
class Check:
    available: bool
    hash_matches: bool | None
    http_status: int | None
    latency_ms: int
    detail: str


class StorageError(RuntimeError):
    pass


class Adapter:
    name = "base"
    maintainer = "unspecified"
    monitoring = "unspecified"

    def put(self, data: bytes, sha256: str, filename: str) -> Stored:
        raise NotImplementedError

    def get(self, locator: str) -> bytes:
        raise NotImplementedError

    def check(self, locator: str, sha256: str) -> Check:
        t = time.time()
        try:
            data = self.get(locator)
        except Exception as e:  # noqa: BLE001
            return Check(False, None, getattr(e, "code", None), int((time.time() - t) * 1000), f"fetch failed: {e}")
        ok = hashlib.sha256(data).hexdigest() == sha256
        return Check(True, ok, 200, int((time.time() - t) * 1000), "content hash matches" if ok else "CONTENT CHANGED: hash mismatch")


class LocalObjectStore(Adapter):
    """Content-addressed directory: <root>/<sha[0:2]>/<sha>. Written atomically and verified."""

    name = "local"

    def __init__(self, root, maintainer="network operator (local disk)", public_base: str | None = None):
        self.root = pathlib.Path(root)
        self.maintainer = maintainer
        self.monitoring = "chainworks nft storage check (re-reads the file and compares SHA-256)"
        self.public_base = public_base

    def path(self, sha256: str) -> pathlib.Path:
        return self.root / sha256[:2] / sha256

    def put(self, data: bytes, sha256: str, filename: str) -> Stored:
        if hashlib.sha256(data).hexdigest() != sha256:
            raise StorageError("refusing to store: bytes do not match the declared SHA-256")
        p = self.path(sha256)
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            tmp = p.with_suffix(f".tmp-{uuid.uuid4().hex}")
            tmp.write_bytes(data)
            os.replace(tmp, p)
        if hashlib.sha256(p.read_bytes()).hexdigest() != sha256:
            raise StorageError("stored file failed verification")
        uri = f"{self.public_base.rstrip('/')}/{sha256}" if self.public_base else None
        return Stored(self.name, str(p), uri, self.maintainer, self.monitoring)

    def get(self, locator: str) -> bytes:
        return pathlib.Path(locator).read_bytes()


# ---------------------------------------------------------------- S3-compatible

def sigv4_headers(method: str, url: str, region: str, service: str, access_key: str, secret_key: str,
                  payload: bytes = b"", extra: dict | None = None, amz_date: str | None = None) -> dict:
    """AWS Signature Version 4 (header form). Works with S3-compatible stores (MinIO, Ceph RGW, R2…)."""
    u = urllib.parse.urlsplit(url)
    amz_date = amz_date or _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    date = amz_date[:8]
    payload_hash = hashlib.sha256(payload).hexdigest()
    headers = {"host": u.netloc, "x-amz-date": amz_date}
    if service == "s3":
        headers["x-amz-content-sha256"] = payload_hash
    for k, v in (extra or {}).items():
        headers[k.lower()] = v.strip()
    names = sorted(headers)
    canon_headers = "".join(f"{k}:{headers[k]}\n" for k in names)
    signed = ";".join(names)
    q = urllib.parse.parse_qsl(u.query, keep_blank_values=True)
    canon_q = "&".join(f"{urllib.parse.quote(k, safe='-_.~')}={urllib.parse.quote(v, safe='-_.~')}" for k, v in sorted(q))
    path = urllib.parse.quote(u.path or "/", safe="/-_.~")
    creq = "\n".join([method, path, canon_q, canon_headers, signed, payload_hash])
    scope = f"{date}/{region}/{service}/aws4_request"
    sts = "\n".join(["AWS4-HMAC-SHA256", amz_date, scope, hashlib.sha256(creq.encode()).hexdigest()])

    def h(k, m):
        return hmac.new(k, m.encode(), hashlib.sha256).digest()
    k = h(h(h(h(("AWS4" + secret_key).encode(), date), region), service), "aws4_request")
    sig = hmac.new(k, sts.encode(), hashlib.sha256).hexdigest()
    out = {k2: v for k2, v in headers.items() if k2 != "host"}
    out["Authorization"] = f"AWS4-HMAC-SHA256 Credential={access_key}/{scope}, SignedHeaders={signed}, Signature={sig}"
    return out


class S3ObjectStore(Adapter):
    """S3-compatible bucket, path-style URLs, key = <prefix><sha256>. Credentials come from
    the environment (AUREOM_S3_ACCESS_KEY / AUREOM_S3_SECRET_KEY) and are never stored."""

    name = "s3"

    def __init__(self, endpoint: str, bucket: str, region: str = "us-east-1", prefix: str = "aureom/", maintainer: str = "bucket owner",
                 public_base: str | None = None, access_key: str | None = None, secret_key: str | None = None):
        self.endpoint, self.bucket, self.region, self.prefix = endpoint.rstrip("/"), bucket, region, prefix
        self.maintainer = maintainer
        self.monitoring = "chainworks nft storage check (signed GET, SHA-256 compare)"
        self.public_base = public_base
        self.ak = access_key or os.environ.get("AUREOM_S3_ACCESS_KEY", "")
        self.sk = secret_key or os.environ.get("AUREOM_S3_SECRET_KEY", "")

    def url(self, sha256: str) -> str:
        return f"{self.endpoint}/{self.bucket}/{self.prefix}{sha256}"

    def _req(self, method, url, data=b"", extra=None):
        if not self.ak or not self.sk:
            raise StorageError("S3 credentials not configured (AUREOM_S3_ACCESS_KEY / AUREOM_S3_SECRET_KEY)")
        hdrs = sigv4_headers(method, url, self.region, "s3", self.ak, self.sk, data, extra)
        req = urllib.request.Request(url, data=data if method == "PUT" else None, method=method, headers=hdrs)
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read()

    def put(self, data: bytes, sha256: str, filename: str) -> Stored:
        if hashlib.sha256(data).hexdigest() != sha256:
            raise StorageError("bytes do not match the declared SHA-256")
        url = self.url(sha256)
        self._req("PUT", url, data, {"x-amz-meta-sha256": sha256})
        uri = f"{self.public_base.rstrip('/')}/{self.prefix}{sha256}" if self.public_base else None
        return Stored(self.name, f"s3://{self.bucket}/{self.prefix}{sha256}", uri, self.maintainer, self.monitoring)

    def get(self, locator: str) -> bytes:
        key = locator.split("/", 3)[3]
        return self._req("GET", f"{self.endpoint}/{self.bucket}/{key}")


# ---------------------------------------------------------------- IPFS (optional)

class IpfsAdapter(Adapter):
    """Kubo HTTP RPC (`/api/v0`). `put` adds and pins on the configured node only."""

    name = "ipfs"

    def __init__(self, api: str = "http://127.0.0.1:5001", gateway: str | None = None, maintainer: str = "operator of the configured IPFS node"):
        self.api = api.rstrip("/")
        self.gateway = gateway
        self.maintainer = maintainer
        self.monitoring = "pin/ls on the configured node + content fetch and SHA-256 compare; says nothing about other IPFS nodes"

    def _post(self, path, body=None, ctype=None, timeout=30):
        req = urllib.request.Request(self.api + path, data=body or b"", method="POST", headers={"Content-Type": ctype} if ctype else {})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()

    def available(self) -> bool:
        try:
            self._post("/api/v0/version", timeout=2)
            return True
        except Exception:  # noqa: BLE001
            return False

    def put(self, data: bytes, sha256: str, filename: str) -> Stored:
        if hashlib.sha256(data).hexdigest() != sha256:
            raise StorageError("bytes do not match the declared SHA-256")
        boundary = uuid.uuid4().hex
        body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{sha256}\"\r\n"
                "Content-Type: application/octet-stream\r\n\r\n").encode() + data + f"\r\n--{boundary}--\r\n".encode()
        try:
            out = json.loads(self._post("/api/v0/add?cid-version=1&raw-leaves=true&pin=true", body, f"multipart/form-data; boundary={boundary}"))
        except urllib.error.URLError as e:
            raise StorageError(f"IPFS node not reachable at {self.api}: {e}")
        cid = out["Hash"]
        uri = f"ipfs://{cid}"
        return Stored(self.name, uri, uri, self.maintainer, self.monitoring)

    def get(self, locator: str) -> bytes:
        cid = locator.removeprefix("ipfs://")
        return self._post(f"/api/v0/cat?arg={urllib.parse.quote(cid)}")

    def check(self, locator: str, sha256: str) -> Check:
        cid = locator.removeprefix("ipfs://")
        try:
            pins = json.loads(self._post(f"/api/v0/pin/ls?arg={urllib.parse.quote(cid)}&type=recursive", timeout=5))
            pinned = cid in pins.get("Keys", {})
        except Exception as e:  # noqa: BLE001
            return Check(False, None, None, 0, f"IPFS node unreachable or CID not pinned: {e}")
        c = super().check(locator, sha256)
        c.detail = ("pinned on the configured node; " if pinned else "NOT pinned on the configured node; ") + c.detail
        return c


class HttpAdapter(Adapter):
    """Read-only availability checks for content served elsewhere (https gateways, CDNs)."""

    name = "http"

    def __init__(self, maintainer: str = "operator of the URL's server"):
        self.maintainer = maintainer
        self.monitoring = "HTTP GET and SHA-256 compare"

    def put(self, data, sha256, filename):
        raise StorageError("the http adapter is read-only; upload with another adapter and register the URL")

    def get(self, locator: str) -> bytes:
        with urllib.request.urlopen(locator, timeout=15) as r:
            return r.read()


def adapter_for(name: str, **kw) -> Adapter:
    return {"local": LocalObjectStore, "s3": S3ObjectStore, "ipfs": IpfsAdapter, "http": HttpAdapter}[name](**kw)
