"""Chain indexer for the collections module.

Reads blocks + receipts from a node's public API and records every collections-module
transaction outcome and event. Ownership, listings, approvals and collection counters
are then *derived* by replaying those events (`derive_caches`); nothing else writes them.

Reorganisations (PoW): the index stores each consumed block id. Before every sync the
stored tip is compared with the node's block at that height; on mismatch the indexer
walks back to the highest height where both agree (the fork point), deletes everything
above it (blocks cascade to events and outcomes), records the reorganisation, re-fetches
the winning branch and re-derives the caches. On BFT profiles committed blocks are final,
so a mismatch is reported as a finality violation instead of being re-indexed.
"""
from __future__ import annotations

import json

from ..util import ChainworksError, get, try_get
from .db import now_ms, tx

NFT_KINDS = ("nft_collection_create", "nft_mint", "nft_mint_batch", "nft_transfer", "nft_approval", "nft_burn", "nft_metadata",
             "nft_admin", "nft_authority", "nft_listing", "nft_sale", "nft_drop")
POLICY = {"1": "mutable", "2": "freezable", "3": "immutable"}


def none(v):
    return None if v in (None, "none", "") else v


class Indexer:
    def __init__(self, conn, api: str, node_name: str = "node"):
        self.c = conn
        self.api = api.rstrip("/")
        self.node = node_name
        self.net = get(self.api + "/v1/network")
        self.key = f"{self.net['chain_id']}:{self.net['genesis_hash']}"
        self.profile = self.net["profile"]
        self._register()

    # ------------------------------------------------------------------ identity
    def _register(self):
        row = self.c.execute("SELECT * FROM networks WHERE network_key = ?", (self.key,)).fetchone()
        if row is None:
            clash = self.c.execute("SELECT network_key FROM networks WHERE chain_id = ?", (self.net["chain_id"],)).fetchone()
            if clash:
                # same chain id, different genesis: a different network — keep them apart
                pass
            self.c.execute("INSERT INTO networks VALUES (?, ?, ?, ?, ?, ?, ?)", (self.key, self.net["chain_id"], self.net["genesis_hash"], self.profile,
                           self.net["network_name"], self.net.get("finality", "unknown"), self.net.get("confirmations_recommended")))
        if not (self.net.get("modules", {}).get("collections", {}) or {}).get("enabled"):
            raise ChainworksError("the node's network does not enable the collections module")

    def cursor(self):
        return self.c.execute("SELECT * FROM index_cursor WHERE network_key = ?", (self.key,)).fetchone()

    def tip(self) -> int:
        return get(self.api + "/v1/health")["height"]

    def _stored_id(self, h):
        r = self.c.execute("SELECT block_id FROM chain_blocks WHERE network_key = ? AND height = ?", (self.key, h)).fetchone()
        return r["block_id"] if r else None

    def _node_id(self, h):
        b = try_get(f"{self.api}/v1/blocks/{h}", timeout=5)
        return b["id"] if b else None

    # ------------------------------------------------------------------ reorg
    def check_reorg(self) -> dict | None:
        cur = self.cursor()
        if not cur:
            return None
        h = cur["height"]
        if self._node_id(h) == cur["block_id"]:
            return None
        if self.profile != "pow":
            raise ChainworksError(f"FINALITY VIOLATION: committed block at height {h} changed on a {self.profile} network "
                                  f"(indexed {cur['block_id'][:16]}, node reports {str(self._node_id(h))[:16]}); index left untouched for investigation")
        fork = h
        while fork > 0:
            fork -= 1
            sid = self._stored_id(fork)
            if sid is None or sid == self._node_id(fork):
                break
        with tx(self.c):
            ev = self.c.execute("SELECT count(*) FROM provenance_events WHERE network_key = ? AND height > ?", (self.key, fork)).fetchone()[0]
            nb = self.c.execute("DELETE FROM chain_blocks WHERE network_key = ? AND height > ?", (self.key, fork)).rowcount
            fid = self._stored_id(fork) or ""
            self.c.execute("UPDATE index_cursor SET height = ?, block_id = ?, updated_at_ms = ? WHERE network_key = ?", (fork, fid, now_ms(), self.key))
            new_tip = self._node_id(h)
            self.c.execute("INSERT INTO reorg_log (network_key, detected_at_ms, fork_height, old_tip_height, old_tip, new_tip, blocks_removed, events_removed, source_node) VALUES (?,?,?,?,?,?,?,?,?)",
                           (self.key, now_ms(), fork, h, cur["block_id"], new_tip, nb, ev, self.node))
            self.derive_caches()
        return {"fork_height": fork, "old_tip_height": h, "blocks_removed": nb, "events_removed": ev}

    # ------------------------------------------------------------------ sync
    def sync(self, max_blocks: int = 100_000) -> dict:
        reorgs = []
        r = self.check_reorg()
        if r:
            reorgs.append(r)
        tip = self.tip()
        cur = self.cursor()
        start = (cur["height"] + 1) if cur else 1
        added, events = 0, 0
        h = start
        while h <= tip and added < max_blocks:
            b = get(f"{self.api}/v1/blocks/{h}")
            prev = self._stored_id(h - 1)
            if prev is not None and b["prev_id"] != prev:
                # the chain changed under us mid-sync: resolve and continue from the fork
                self._set_cursor(h - 1, prev)
                r = self.check_reorg()
                if r:
                    reorgs.append(r)
                cur = self.cursor()
                h = cur["height"] + 1
                tip = self.tip()
                continue
            with tx(self.c):
                events += self._ingest(b)
                self._set_cursor(h, b["id"])
            added += 1
            h += 1
        with tx(self.c):
            self.derive_caches()
        cur = self.cursor()
        return {"network_key": self.key, "source_node": self.node, "indexed_height": cur["height"] if cur else 0, "node_tip": tip,
                "blocks_added": added, "events_added": events, "reorgs": reorgs}

    def _set_cursor(self, h, bid):
        self.c.execute("INSERT INTO index_cursor VALUES (?, ?, ?, ?, ?) ON CONFLICT(network_key) DO UPDATE SET height = excluded.height, block_id = excluded.block_id, source_node = excluded.source_node, updated_at_ms = excluded.updated_at_ms",
                       (self.key, h, bid, self.node, now_ms()))

    def _ingest(self, b) -> int:
        h = b["height"]
        self.c.execute("INSERT OR REPLACE INTO chain_blocks VALUES (?, ?, ?, ?, ?, ?, ?)", (self.key, h, b["id"], b["prev_id"], b.get("timestamp_ms") or 0, b.get("tx_count", 0), now_ms()))
        n = 0
        for i, (t, rc) in enumerate(zip(b.get("txs", []), b.get("receipts", []))):
            act = t["action"]
            inner = act.get("inner", {}).get("type", "") if act["type"] == "multisig_propose" else ""
            kinds = [e["kind"] for e in rc.get("events", [])]
            relevant = act["type"].startswith("nft_") or inner.startswith("nft_") or any(k in NFT_KINDS for k in kinds)
            if not relevant:
                continue
            self.c.execute("INSERT OR REPLACE INTO chain_tx_outcomes VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                           (self.key, t["id"], h, b["id"], i, act["type"] if not inner else f"multisig:{inner}", t["sender"], rc["status"], rc.get("error"), rc["fee_paid"], json.dumps(act)))
            if rc["status"] != "success":
                continue
            for j, e in enumerate(rc.get("events", [])):
                if e["kind"] not in NFT_KINDS:
                    continue
                a = e.get("attrs", {})
                frm = a.get("from") or a.get("owner") or a.get("seller") or (a.get("old") if e["kind"] == "nft_authority" else None)
                to = a.get("to") or a.get("approved") or a.get("buyer") or a.get("claimant") or (a.get("new") if e["kind"] == "nft_authority" else None)
                actor = a.get("by") or a.get("creator") or a.get("admin") or t["sender"]
                self.c.execute("INSERT INTO provenance_events (network_key, height, block_id, txid, tx_index, event_index, kind, op, collection_id, token_id, from_addr, to_addr, actor, attrs_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               (self.key, h, b["id"], t["id"], i, j, e["kind"], a.get("op") or a.get("authority") or a.get("role"), a.get("collection"), a.get("token_id"),
                                none(frm), none(to), actor, json.dumps(a, sort_keys=True)))
                n += 1
        return n

    # ------------------------------------------------------------------ derived caches
    def derive_caches(self):
        """Recompute every cache from provenance_events (called inside a transaction)."""
        k = self.key
        cur = self.cursor()
        at = cur["height"] if cur else 0
        for t in ("collections_cache", "ownership_cache", "operator_cache", "listings_cache", "sales_cache"):
            self.c.execute(f"DELETE FROM {t} WHERE network_key = ?", (k,))
        cols, toks, ops, lst, sales = {}, {}, {}, {}, {}
        outcomes = {r["txid"]: r for r in self.c.execute("SELECT txid, action_json, fee_paid FROM chain_tx_outcomes WHERE network_key = ?", (k,))}
        rows = self.c.execute("SELECT * FROM provenance_events WHERE network_key = ? ORDER BY height, tx_index, event_index", (k,)).fetchall()
        for r in rows:
            a = json.loads(r["attrs_json"])
            kind, h, cid, tid = r["kind"], r["height"], r["collection_id"], r["token_id"]
            if kind == "nft_collection_create":
                act = json.loads(outcomes[r["txid"]]["action_json"]) if r["txid"] in outcomes else {}
                roy = act.get("royalty") or {}
                cols[cid] = {"slug": a["slug"], "creator": a["creator"], "created_height": h, "created_txid": r["txid"], "max_supply": none(a.get("max_supply")),
                             "metadata_policy": POLICY.get(a.get("metadata_policy"), a.get("metadata_policy")), "mint_authority": none(a.get("mint_authority")),
                             "metadata_admin": none(a.get("metadata_admin")), "admin": none(a.get("admin")), "flags": int(a.get("flags", 0)),
                             "transfer_policy": int(a.get("transfer_policy", 0)), "royalty_bps": int(a.get("royalty_bps", 0)), "royalty_recipient": roy.get("recipient"),
                             "minted": 0, "burned": 0, "paused": 0, "frozen_all": 0}
            elif kind == "nft_mint":
                toks[(cid, tid)] = {"owner": a["to"], "burned": 0, "metadata_uri": a["metadata_uri"], "metadata_hash": a["metadata_hash"], "revision": 0,
                                    "frozen": 1 if a.get("frozen") == "true" else 0, "minted_height": h, "last_event_height": h, "transfers": 0, "approved": None, "approval_expiry": 0}
                if cid in cols:
                    cols[cid]["minted"] += 1
            elif kind == "nft_transfer" and (cid, tid) in toks:
                t = toks[(cid, tid)]
                t.update(owner=a["to"], approved=None, approval_expiry=0, last_event_height=h, transfers=t["transfers"] + 1)
            elif kind == "nft_burn" and (cid, tid) in toks:
                toks[(cid, tid)].update(owner=None, burned=1, approved=None, approval_expiry=0, last_event_height=h)
                if cid in cols:
                    cols[cid]["burned"] += 1
            elif kind == "nft_metadata":
                op = a.get("op")
                if op == "update" and (cid, tid) in toks:
                    toks[(cid, tid)].update(metadata_uri=a["metadata_uri"], metadata_hash=a["metadata_hash"], revision=int(a["revision"]), last_event_height=h)
                elif op == "freeze_token" and (cid, tid) in toks:
                    toks[(cid, tid)].update(frozen=1, last_event_height=h)
                elif op == "freeze_collection":
                    for (c2, _), t in toks.items():
                        if c2 == cid and not t["burned"]:
                            t["frozen"] = 1
                    if cid in cols:
                        cols[cid]["frozen_all"] = 1
            elif kind == "nft_approval":
                if a.get("scope") == "token" and (cid, tid) in toks:
                    toks[(cid, tid)].update(approved=none(a.get("approved")) if a.get("op") == "approve" else None, approval_expiry=int(a.get("expiry_height", 0)))
                else:
                    key = (cid, a["owner"], a["approved"])
                    if a.get("op") == "approve":
                        ops[key] = {"expiry_height": int(a.get("expiry_height", 0)), "granted_height": h}
                    else:
                        ops.pop(key, None)
            elif kind == "nft_admin" and cid in cols:
                cols[cid]["paused"] = 1 if a.get("op") == "pause" else 0
            elif kind == "nft_authority" and cid in cols:
                role, new = a.get("role"), none(a.get("new"))
                if role == "royalty_recipient":
                    cols[cid]["royalty_recipient"] = new
                    if new is None:
                        cols[cid]["royalty_bps"] = 0
                elif role in ("admin", "mint_authority", "metadata_admin"):
                    cols[cid][role] = new
            elif kind == "nft_listing":
                op, lid = a.get("op"), a.get("listing")
                if op == "create":
                    lst[lid] = {"collection_id": cid, "token_id": tid, "seller": a["seller"], "price": a["price"], "currency": a["currency"],
                                "expiry_height": int(a["expiry_height"]), "status": "active", "buyer": None, "created_height": h, "closed_height": None}
                elif lid in lst:
                    lst[lid].update(status={"cancel": "cancelled", "invalidated": "invalidated", "expired_superseded": "expired"}.get(op, op), closed_height=h)
            elif kind == "nft_sale":
                lid = a["listing"]
                if lid in lst:
                    lst[lid].update(status="sold", buyer=a["buyer"], closed_height=h)
                sales[lid] = {"txid": r["txid"], "height": h, "collection_id": cid, "token_id": tid, "seller": a["seller"], "buyer": a["buyer"], "price": a["price"],
                              "currency": a["currency"], "royalty": a["royalty"], "royalty_to": none(a.get("royalty_to")), "platform_fee": a["platform_fee"],
                              "platform_to": none(a.get("platform_to")), "seller_proceeds": a["seller_proceeds"], "network_fee": outcomes.get(r["txid"], {"fee_paid": "0"})["fee_paid"]}
        for cid, v in cols.items():
            self.c.execute("INSERT INTO collections_cache VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (k, cid, v["slug"], v["creator"], v["created_height"], v["created_txid"], v["max_supply"], v["metadata_policy"], v["mint_authority"], v["metadata_admin"],
                            v["admin"], v["flags"], v["transfer_policy"], v["royalty_bps"], v["royalty_recipient"], v["minted"], v["burned"], v["paused"], v["frozen_all"], at))
        for (cid, tid), v in toks.items():
            self.c.execute("INSERT INTO ownership_cache VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (k, cid, tid, v["owner"], v["burned"], v["metadata_uri"], v["metadata_hash"], v["revision"], v["frozen"], v["minted_height"], v["last_event_height"],
                            v["transfers"], v["approved"], v["approval_expiry"], at))
        for (cid, owner, op), v in ops.items():
            self.c.execute("INSERT INTO operator_cache VALUES (?,?,?,?,?,?,?)", (k, cid, owner, op, v["expiry_height"], v["granted_height"], at))
        for lid, v in lst.items():
            self.c.execute("INSERT INTO listings_cache VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (k, lid, v["collection_id"], v["token_id"], v["seller"], v["price"], v["currency"], v["expiry_height"], v["status"], v["buyer"], v["created_height"], v["closed_height"], at))
        for lid, v in sales.items():
            self.c.execute("INSERT INTO sales_cache VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (k, lid, v["txid"], v["height"], v["collection_id"], v["token_id"], v["seller"], v["buyer"], v["price"], v["currency"], v["royalty"], v["royalty_to"],
                            v["platform_fee"], v["platform_to"], v["seller_proceeds"], v["network_fee"]))

    # ------------------------------------------------------------------ rebuild / verify
    def rebuild(self) -> dict:
        """Drop every chain-derived row for this network and re-index from chain events."""
        with tx(self.c):
            before = self.c.execute("SELECT count(*) FROM provenance_events WHERE network_key = ?", (self.key,)).fetchone()[0]
            for t in ("collections_cache", "ownership_cache", "operator_cache", "listings_cache", "sales_cache", "index_cursor"):
                self.c.execute(f"DELETE FROM {t} WHERE network_key = ?", (self.key,))
            self.c.execute("DELETE FROM chain_blocks WHERE network_key = ?", (self.key,))
        r = self.sync()
        r["events_before_rebuild"] = before
        return r

    def verify_against_chain(self) -> dict:
        """Compare every cached token with the node's authoritative state."""
        mismatches, checked = [], 0
        for row in self.c.execute("SELECT * FROM ownership_cache WHERE network_key = ?", (self.key,)).fetchall():
            v = get(f"{self.api}/v1/nft/tokens/{row['collection_id']}/{row['token_id']}")
            checked += 1
            want = {"owner": v["owner"], "burned": int(v["burned"]), "metadata_hash": v["metadata"]["sha256"], "revision": v["revision"], "frozen": int(v["metadata_frozen"])}
            have = {"owner": row["owner"], "burned": row["burned"], "metadata_hash": row["metadata_hash"], "revision": row["revision"], "frozen": row["frozen"]}
            if want != have:
                mismatches.append({"token": f"{row['collection_id']}/{row['token_id']}", "index": have, "chain": want, "chain_height": v["state_height"]})
        for row in self.c.execute("SELECT * FROM collections_cache WHERE network_key = ?", (self.key,)).fetchall():
            v = get(f"{self.api}/v1/nft/collections/{row['collection_id']}")
            checked += 1
            if (v["minted"], v["burned"]) != (row["minted"], row["burned"]):
                mismatches.append({"collection": row["collection_id"], "index": [row["minted"], row["burned"]], "chain": [v["minted"], v["burned"]]})
        cur = self.cursor()
        return {"checked": checked, "mismatches": mismatches, "consistent": not mismatches, "index_height": cur["height"] if cur else 0,
                "note": "chain state is authoritative; on mismatch run sync (or rebuild) — never edit the index by hand"}

    # ------------------------------------------------------------------ settlement labels
    def settlement(self, height: int | None, tip: int | None = None) -> dict:
        if height is None:
            return {"state": "not_indexed"}
        if self.profile != "pow":
            return {"state": "finalised", "semantics": "BFT commit (> 2/3 voting power); irreversible under the fault assumption"}
        tip = self.tip() if tip is None else tip
        conf = max(0, tip - height + 1)
        need = self.net.get("confirmations_recommended") or 6
        return {"state": "confirmed" if conf >= need else "included", "confirmations": conf, "recommended": need,
                "semantics": "probabilistic: a branch with more cumulative work can still replace this block"}
