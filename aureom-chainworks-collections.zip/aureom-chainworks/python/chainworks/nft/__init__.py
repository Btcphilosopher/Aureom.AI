"""AUREOM COLLECTIONS — NFT issuance and management on Chainworks development networks.

The on-chain part is a native module of the Chainworks state machine (Rust,
`aureom_core::nft`); this package is the off-chain application: media and metadata,
storage adapters, request lifecycle, chain indexer, provenance, gating and reviews.
"""
