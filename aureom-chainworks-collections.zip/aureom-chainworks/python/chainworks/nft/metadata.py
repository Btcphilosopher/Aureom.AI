"""Metadata documents (off-chain) and their on-chain commitment.

On chain a token stores only `{uri, sha256}` where sha256 is the SHA-256 of the exact
canonical bytes of its metadata document. The document names each media file by its own
SHA-256, so the chain commits transitively to the media without holding it. Whether the
bytes can still be *retrieved* depends on storage (see storage.py), not on the chain.

Canonical bytes: UTF-8 JSON, object keys sorted by code point, no insignificant
whitespace, integers only (no floats), no duplicate keys.
"""
from __future__ import annotations

import hashlib
import json
import re

TOKEN_SCHEMA = "aureom-nft-metadata/v1"
COLLECTION_SCHEMA = "aureom-collection-metadata/v1"
RIGHTS_SCHEMA = "aureom-rights-statement/v1"

LICENCES = {
    "CC-BY-4.0": "https://creativecommons.org/licenses/by/4.0/",
    "CC-BY-NC-4.0": "https://creativecommons.org/licenses/by-nc/4.0/",
    "CC0-1.0": "https://creativecommons.org/publicdomain/zero/1.0/",
    "ALL-RIGHTS-RESERVED": None,
    "PERSONAL-DISPLAY-ONLY": None,
}

PII = [
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "e-mail address"),
    (re.compile(r"(?<!\w)\+?\d[\d ()-]{8,}\d(?!\w)"), "phone-number-like digits"),
    (re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b"), "IBAN-like account number"),
    (re.compile(r"\b(passport|national insurance|social security|date of birth|home address)\b", re.I), "personal identity reference"),
]


class MetadataError(ValueError):
    pass


def canonical_bytes(doc) -> bytes:
    def chk(v, path="$"):
        if isinstance(v, float):
            raise MetadataError(f"{path}: floats are not allowed (use integers or strings)")
        if isinstance(v, dict):
            for k, x in v.items():
                if not isinstance(k, str):
                    raise MetadataError(f"{path}: non-string key")
                chk(x, f"{path}.{k}")
        elif isinstance(v, list):
            for i, x in enumerate(v):
                chk(x, f"{path}[{i}]")
    chk(doc)
    return json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(doc) -> str:
    return hashlib.sha256(canonical_bytes(doc)).hexdigest()


def parse_canonical(b: bytes) -> dict:
    """Parse stored bytes and confirm they are canonical (so the hash is reproducible)."""
    def no_dupes(pairs):
        keys = [k for k, _ in pairs]
        if len(keys) != len(set(keys)):
            raise MetadataError("duplicate keys")
        return dict(pairs)
    d = json.loads(b.decode("utf-8"), object_pairs_hook=no_dupes)
    if canonical_bytes(d) != b:
        raise MetadataError("document bytes are not in canonical form")
    return d


def pii_findings(doc) -> list[str]:
    text = json.dumps(doc, ensure_ascii=False)
    # hashes and bech32 addresses are long digit/letter runs; ignore 64-hex and bech32 tokens
    text = re.sub(r"\b[0-9a-f]{64}\b", "", text)
    text = re.sub(r"\baurd[a-z]*1[02-9ac-hj-np-z]{20,}\b", "", text)
    return [what for rx, what in PII if rx.search(text)]


def media_ref(m: dict, uri: str, role: str = "image") -> dict:
    """Reference a validated media file (output of media.validate) at a storage URI."""
    r = {"role": role, "uri": uri, "sha256": m["sha256"], "mime": m["mime"], "bytes": m["bytes"]}
    for k in ("width", "height"):
        if m.get(k):
            r[k] = m[k]
    if m.get("alt_text"):
        r["alt_text"] = m["alt_text"]
    if m.get("transcript"):
        r["transcript"] = m["transcript"]
    return r


def rights_block(holder: str, licence: str, statement: str, physical_object: str | None = None) -> dict:
    if licence not in LICENCES:
        raise MetadataError(f"licence must be one of {sorted(LICENCES)}")
    b = {
        "holder": holder,
        "licence": licence,
        "licence_uri": LICENCES[licence],
        "statement": statement,
        "token_owner_receives_copyright": False,
        "note": "Owning this token is a ledger record of control over the token. It does not transfer copyright, other intellectual-property rights or any physical object unless a separate agreement says so.",
    }
    if physical_object:
        b["physical_object"] = {"description": physical_object, "claim_status": "unverified issuer claim — see authenticity reviews"}
    return b


def token_document(*, name: str, description: str, collection_slug: str, chain_id: str, genesis_hash: str, token_id: int,
                   image: dict, media: list[dict] | None = None, attributes: list[dict] | None = None, creator: str,
                   rights: dict, language: str = "en") -> dict:
    doc = {
        "schema": TOKEN_SCHEMA,
        "name": name,
        "description": description,
        "collection": {"slug": collection_slug, "network": {"chain_id": chain_id, "genesis_hash": genesis_hash}},
        "token_id": str(token_id),
        "image": image,
        "media": media or [],
        "attributes": attributes or [],
        "creator": {"display_name": creator},
        "rights": rights,
        "accessibility": {"language": language, "image_alt_text": image.get("alt_text", "")},
    }
    return doc


def collection_document(*, name: str, description: str, slug: str, chain_id: str, genesis_hash: str, artwork: dict, creator: str,
                        rights: dict, external_url: str | None = None) -> dict:
    d = {"schema": COLLECTION_SCHEMA, "name": name, "description": description, "slug": slug,
         "network": {"chain_id": chain_id, "genesis_hash": genesis_hash}, "artwork": artwork,
         "creator": {"display_name": creator}, "rights": rights}
    if external_url:
        d["external_url"] = external_url
    return d


def rights_document(*, holder: str, licence: str, statement: str, collection_slug: str, contact_policy: str) -> dict:
    if licence not in LICENCES:
        raise MetadataError(f"licence must be one of {sorted(LICENCES)}")
    return {"schema": RIGHTS_SCHEMA, "collection_slug": collection_slug, "rights_holder": holder, "licence": licence,
            "licence_uri": LICENCES[licence], "statement": statement, "token_owner_receives_copyright": False,
            "contact_policy": contact_policy}


def validate(doc: dict) -> dict:
    """Structural checks + warnings. Raises MetadataError on errors."""
    errors, warnings = [], []
    sch = doc.get("schema")
    if sch not in (TOKEN_SCHEMA, COLLECTION_SCHEMA, RIGHTS_SCHEMA):
        errors.append(f"unknown schema {sch!r}")
    if sch in (TOKEN_SCHEMA, COLLECTION_SCHEMA):
        if not doc.get("name") or len(doc["name"]) > 200:
            errors.append("name required (<= 200 characters)")
        img = doc.get("image") if sch == TOKEN_SCHEMA else doc.get("artwork")
        if not img or not re.fullmatch(r"[0-9a-f]{64}", img.get("sha256", "")):
            errors.append("an image/artwork reference with sha256 is required")
        elif img.get("mime", "").startswith(("image/", "video/")) and not img.get("alt_text"):
            errors.append("image/artwork reference requires alt_text")
        for i, m in enumerate(doc.get("media", [])):
            if not re.fullmatch(r"[0-9a-f]{64}", m.get("sha256", "")):
                errors.append(f"media[{i}] requires sha256")
            if m.get("mime", "").startswith(("image/", "video/")) and not m.get("alt_text"):
                errors.append(f"media[{i}] requires alt_text")
        r = doc.get("rights") or {}
        if not r.get("holder") or r.get("licence") not in LICENCES:
            errors.append("rights.holder and a known rights.licence are required")
        if r.get("token_owner_receives_copyright") is not False:
            errors.append("rights.token_owner_receives_copyright must be explicitly false (owning a token does not transfer copyright)")
        for a in doc.get("attributes", []):
            if set(a) - {"trait_type", "value", "display_type"} or "trait_type" not in a:
                errors.append(f"attribute {a} must have trait_type/value only")
    for uri in [doc.get("image", {}).get("uri", "")] + [m.get("uri", "") for m in doc.get("media", [])]:
        if uri.startswith("http://"):
            warnings.append(f"{uri}: plain http URI; prefer https or a content-addressed URI")
    found = pii_findings(doc)
    if found:
        errors.append("possible personal information in a public metadata document: " + ", ".join(found)
                      + " — do not publish personal data; keep it in private storage")
    try:
        b = canonical_bytes(doc)
    except MetadataError as e:
        errors.append(str(e))
        b = b""
    if errors:
        raise MetadataError("; ".join(errors))
    return {"sha256": hashlib.sha256(b).hexdigest(), "bytes": len(b), "warnings": warnings}


def preview(doc: dict) -> dict:
    """Plain summary for review screens (what holders and buyers will see)."""
    img = doc.get("image") or doc.get("artwork") or {}
    return {"schema": doc.get("schema"), "name": doc.get("name"), "description": (doc.get("description") or "")[:280],
            "image": {k: img.get(k) for k in ("uri", "sha256", "mime", "width", "height", "alt_text")},
            "media": [{k: m.get(k) for k in ("role", "uri", "mime", "sha256")} for m in doc.get("media", [])],
            "attributes": doc.get("attributes", []), "rights": doc.get("rights"), "sha256": digest(doc)}
