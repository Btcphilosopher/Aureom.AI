"""Media validation, checksums and content identifiers.

The file type is decided from the bytes (magic numbers and structure), never from the
file name alone; a name whose extension disagrees with the content is rejected. Active
content (scripts in SVG, JavaScript/launch actions in PDF) is rejected. Images and video
require an accessibility description.
"""
from __future__ import annotations

import base64
import hashlib
import re
import struct
import zlib

LIMITS = {"image": 25 << 20, "audio": 50 << 20, "video": 200 << 20, "document": 25 << 20, "structured": 2 << 20}

EXT = {
    "image/png": {".png"}, "image/jpeg": {".jpg", ".jpeg"}, "image/gif": {".gif"}, "image/webp": {".webp"}, "image/svg+xml": {".svg"},
    "audio/wav": {".wav"}, "audio/ogg": {".ogg", ".oga"}, "audio/flac": {".flac"}, "audio/mpeg": {".mp3"},
    "video/mp4": {".mp4", ".m4v"}, "video/webm": {".webm"},
    "application/pdf": {".pdf"}, "text/plain": {".txt", ".md"}, "application/json": {".json"},
}


class MediaError(ValueError):
    pass


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def cid_v1_raw(b: bytes) -> str:
    """CIDv1, codec raw (0x55), multihash sha2-256, multibase base32 ('b').

    This equals the CID an IPFS node reports for `ipfs add --cid-version=1 --raw-leaves`
    only when the file fits in a single chunk (<= 256 KiB with the default chunker).
    Larger files are stored as a UnixFS DAG whose root CID differs; the IPFS adapter
    records the CID the node actually returns. Either way the SHA-256 recorded on chain
    (via the metadata document) is what proves integrity.
    """
    mh = bytes([0x12, 0x20]) + hashlib.sha256(b).digest()
    raw = bytes([0x01, 0x55]) + mh
    return "b" + base64.b32encode(raw).decode().lower().rstrip("=")


# ---------------------------------------------------------------- sniffers

def _png(b: bytes) -> dict:
    if len(b) < 33:
        raise MediaError("PNG truncated")
    pos, chunks, seen_end = 8, 0, False
    w = h = None
    while pos + 8 <= len(b):
        (n,) = struct.unpack(">I", b[pos:pos + 4])
        typ = b[pos + 4:pos + 8]
        if pos + 12 + n > len(b):
            raise MediaError(f"PNG chunk {typ!r} runs past end of file")
        data = b[pos + 8:pos + 8 + n]
        (crc,) = struct.unpack(">I", b[pos + 8 + n:pos + 12 + n])
        if zlib.crc32(typ + data) & 0xFFFFFFFF != crc:
            raise MediaError(f"PNG chunk {typ!r} CRC mismatch (corrupted file)")
        if chunks == 0:
            if typ != b"IHDR":
                raise MediaError("PNG must start with IHDR")
            w, h = struct.unpack(">II", data[:8])
        chunks += 1
        pos += 12 + n
        if typ == b"IEND":
            seen_end = True
            break
    if not seen_end:
        raise MediaError("PNG has no IEND chunk (truncated)")
    if not w or not h or w > 20000 or h > 20000:
        raise MediaError(f"PNG dimensions {w}x{h} out of range")
    return {"mime": "image/png", "kind": "image", "width": w, "height": h}


def _jpeg(b: bytes) -> dict:
    if not b.endswith(b"\xff\xd9"):
        raise MediaError("JPEG has no end-of-image marker (truncated)")
    i, w, h = 2, None, None
    while i + 4 <= len(b):
        if b[i] != 0xFF:
            raise MediaError("JPEG marker structure invalid")
        m = b[i + 1]
        if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        (ln,) = struct.unpack(">H", b[i + 2:i + 4])
        if m in (0xC0, 0xC1, 0xC2):
            h, w = struct.unpack(">HH", b[i + 5:i + 9])
            break
        if m == 0xDA:
            break
        i += 2 + ln
    if not w or not h:
        raise MediaError("JPEG frame header not found")
    return {"mime": "image/jpeg", "kind": "image", "width": w, "height": h}


SVG_BAD = [
    (re.compile(rb"<\s*script", re.I), "script element"),
    (re.compile(rb"\son[a-z]+\s*=", re.I), "event-handler attribute"),
    (re.compile(rb"javascript:", re.I), "javascript: URL"),
    (re.compile(rb"<\s*foreignObject", re.I), "foreignObject element"),
    (re.compile(rb"<!\s*(DOCTYPE|ENTITY)", re.I), "DOCTYPE/ENTITY declaration"),
    (re.compile(rb"(xlink:)?href\s*=\s*[\"'](?!#)", re.I), "external reference (href to anything but a local #fragment)"),
]


def _svg(b: bytes) -> dict:
    try:
        b.decode("utf-8")
    except UnicodeDecodeError:
        raise MediaError("SVG must be UTF-8 text")
    for rx, what in SVG_BAD:
        if rx.search(b):
            raise MediaError(f"SVG contains active or external content: {what}")
    m = re.search(rb"<svg\b[^>]*>", b)
    if not m:
        raise MediaError("no <svg> root element")
    tag = m.group(0)
    vb = re.search(rb'viewBox\s*=\s*"([\d.\s\-]+)"', tag)
    w = h = None
    if vb:
        parts = vb.group(1).split()
        if len(parts) == 4:
            w, h = int(float(parts[2])), int(float(parts[3]))
    import xml.etree.ElementTree as ET  # entity declarations were rejected above
    try:
        ET.fromstring(b)
    except ET.ParseError as e:
        raise MediaError(f"SVG is not well-formed XML: {e}")
    return {"mime": "image/svg+xml", "kind": "image", "width": w, "height": h}


def _pdf(b: bytes) -> dict:
    if b"%%EOF" not in b[-1024:]:
        raise MediaError("PDF has no %%EOF trailer (truncated)")
    for tok in (b"/JavaScript", b"/JS ", b"/JS(", b"/Launch", b"/EmbeddedFile", b"/OpenAction"):
        if tok in b:
            raise MediaError(f"PDF contains active content ({tok.decode().strip()}); export a static PDF")
    return {"mime": "application/pdf", "kind": "document"}


def sniff(b: bytes) -> dict:
    if not b:
        raise MediaError("empty file")
    if b.startswith(b"\x89PNG\r\n\x1a\n"):
        return _png(b)
    if b.startswith(b"\xff\xd8\xff"):
        return _jpeg(b)
    if b[:6] in (b"GIF87a", b"GIF89a"):
        w, h = struct.unpack("<HH", b[6:10])
        return {"mime": "image/gif", "kind": "image", "width": w, "height": h}
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return {"mime": "image/webp", "kind": "image"}
    if b[:4] == b"RIFF" and b[8:12] == b"WAVE":
        if struct.unpack("<I", b[4:8])[0] + 8 != len(b):
            raise MediaError("WAV RIFF size does not match file size (truncated or padded)")
        return {"mime": "audio/wav", "kind": "audio"}
    if b.startswith(b"OggS"):
        return {"mime": "audio/ogg", "kind": "audio"}
    if b.startswith(b"fLaC"):
        return {"mime": "audio/flac", "kind": "audio"}
    if b.startswith(b"ID3") or (len(b) > 1 and b[0] == 0xFF and b[1] & 0xE0 == 0xE0):
        return {"mime": "audio/mpeg", "kind": "audio"}
    if b[4:8] == b"ftyp":
        return {"mime": "video/mp4", "kind": "video"}
    if b.startswith(b"\x1a\x45\xdf\xa3"):
        return {"mime": "video/webm", "kind": "video"}
    if b.startswith(b"%PDF-"):
        return _pdf(b)
    head = b.lstrip()[:512]
    if head.startswith(b"<?xml") or head.startswith(b"<svg"):
        return _svg(b)
    if head.startswith(b"{") or head.startswith(b"["):
        import json
        try:
            json.loads(b)
        except Exception as e:  # noqa: BLE001
            raise MediaError(f"invalid JSON: {e}")
        return {"mime": "application/json", "kind": "structured"}
    try:
        t = b.decode("utf-8")
        if all(c.isprintable() or c in "\r\n\t" for c in t[:4096]):
            return {"mime": "text/plain", "kind": "document"}
    except UnicodeDecodeError:
        pass
    raise MediaError("unsupported or unrecognised file type")


def validate(b: bytes, name: str | None = None, alt_text: str | None = None, transcript: str | None = None) -> dict:
    """Validate bytes; returns a description with checksums or raises MediaError."""
    info = sniff(b)
    errors, warnings = [], []
    lim = LIMITS[info["kind"]]
    if len(b) > lim:
        errors.append(f"{info['kind']} larger than {lim >> 20} MiB")
    if name:
        ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
        if ext and ext not in EXT.get(info["mime"], set()):
            errors.append(f"file name extension {ext} does not match detected type {info['mime']}")
    if info["kind"] in ("image", "video"):
        if not alt_text or len(alt_text.strip()) < 10:
            errors.append("an accessibility description (alt text, >= 10 characters) is required for images and video")
        elif len(alt_text) > 1000:
            errors.append("alt text longer than 1000 characters; put long descriptions in the metadata description")
    if info["kind"] in ("audio", "video") and not transcript:
        warnings.append("no transcript or text alternative provided for time-based media")
    if errors:
        raise MediaError("; ".join(errors))
    return {**info, "bytes": len(b), "sha256": sha256_hex(b), "media_id": "sha256:" + sha256_hex(b), "cid_raw_v1": cid_v1_raw(b),
            "alt_text": alt_text, "transcript": transcript, "warnings": warnings}
