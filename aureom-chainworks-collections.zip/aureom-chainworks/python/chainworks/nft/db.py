"""SQLite database with ordered, checksummed migrations.

`migrations/NNNN_name.sql` files are applied in order inside a transaction each. An
applied migration whose file content changed afterwards is reported as an error rather
than silently re-run. The chain-derived tables (0001) can be rebuilt from chain events;
the application tables (0002) cannot and must be backed up.
"""
from __future__ import annotations

import hashlib
import pathlib
import sqlite3
import time

MIGRATIONS = pathlib.Path(__file__).with_name("migrations")


def now_ms() -> int:
    return int(time.time() * 1000)


def connect(path) -> sqlite3.Connection:
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # check_same_thread=False: the console server shares one connection across request
    # threads and serialises every use behind a lock (console_api.ConsoleNft)
    c = sqlite3.connect(str(path), timeout=30, isolation_level=None, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.execute("PRAGMA journal_mode = WAL")
    return c


def migration_files() -> list[tuple[int, str, pathlib.Path]]:
    out = []
    for f in sorted(MIGRATIONS.glob("*.sql")):
        n, _, name = f.stem.partition("_")
        out.append((int(n), name, f))
    return out


def migrate(c: sqlite3.Connection) -> dict:
    c.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, sha256 TEXT NOT NULL, applied_at_ms INTEGER NOT NULL)")
    applied = {r["version"]: r for r in c.execute("SELECT * FROM schema_migrations")}
    done, problems = [], []
    for v, name, f in migration_files():
        sql = f.read_text()
        digest = hashlib.sha256(sql.encode()).hexdigest()
        if v in applied:
            if applied[v]["sha256"] != digest:
                problems.append(f"migration {v:04d}_{name} changed after it was applied")
            continue
        c.execute("BEGIN")
        try:
            for stmt in _split(sql):
                c.execute(stmt)
            c.execute("INSERT INTO schema_migrations VALUES (?, ?, ?, ?)", (v, name, digest, now_ms()))
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
        done.append(f"{v:04d}_{name}")
    return {"applied": done, "problems": problems, "version": max([v for v, _, _ in migration_files()] or [0])}


def _split(sql: str) -> list[str]:
    """Split a migration into complete statements (SQLite's own tokenizer decides where a
    statement ends, so semicolons inside comments or literals are handled correctly)."""
    out, buf = [], ""
    for ln in sql.splitlines(keepends=True):
        buf += ln
        if sqlite3.complete_statement(buf):
            if buf.strip():
                out.append(buf.strip())
            buf = ""
    if buf.strip() and not all(x.strip().startswith("--") or not x.strip() for x in buf.splitlines()):
        raise RuntimeError(f"incomplete SQL statement at end of migration: {buf[:80]!r}")
    return out


def open_db(path) -> sqlite3.Connection:
    c = connect(path)
    r = migrate(c)
    if r["problems"]:
        raise RuntimeError("; ".join(r["problems"]))
    return c


class tx:
    """`with tx(conn): ...` — one atomic transaction."""

    def __init__(self, c: sqlite3.Connection):
        self.c = c

    def __enter__(self):
        self.c.execute("BEGIN IMMEDIATE")
        return self.c

    def __exit__(self, et, ev, tb):
        self.c.execute("COMMIT" if et is None else "ROLLBACK")
        return False
