"""Original demonstration artwork for the fictional collection "Tidewater Lanterns" by the
fictional studio "Lumen Atelier".

Every image, sound and document here is generated procedurally by this file (no external
assets, no reproduction of existing works). Licence: CC BY 4.0, attributed to the
fictional Lumen Atelier — chosen so the demonstration can be redistributed.
"""
from __future__ import annotations

import math
import random
import struct
import zlib

TITLES = ["Harbour at First Light", "Seven Lanterns Drifting", "The Ferryman's Signal", "Low Tide Vigil", "Mooring of Small Fires", "Copper Moon Crossing",
          "Night Market on the Water", "Gull Wind, Lantern Calm", "The Last Boat Home", "Salt and Ember", "Tidewater Procession", "Quiet Lights of the Estuary"]

PALETTES = [
    ((24, 32, 72), (180, 96, 120), (12, 40, 70)),
    ((14, 22, 48), (90, 70, 140), (8, 30, 58)),
    ((40, 30, 60), (220, 140, 90), (20, 46, 72)),
    ((10, 18, 36), (60, 110, 150), (6, 26, 44)),
]


def _png(w: int, h: int, rows: list[bytes]) -> bytes:
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def illustration(seed: int, size: int = 192) -> tuple[bytes, dict]:
    """Return (PNG bytes, traits). Deterministic for a seed."""
    rnd = random.Random(seed * 7919 + 17)
    top, glow, sea = PALETTES[seed % len(PALETTES)]
    horizon = int(size * (0.52 + rnd.random() * 0.1))
    moon = (rnd.randint(size // 5, size * 4 // 5), rnd.randint(size // 8, horizon // 2), rnd.randint(size // 16, size // 9))
    n = 3 + seed % 6
    lanterns = [(rnd.randint(10, size - 10), rnd.randint(horizon + 8, size - 14), rnd.randint(3, 6), rnd.random()) for _ in range(n)]
    px = [[(0, 0, 0)] * size for _ in range(size)]
    for y in range(size):
        for x in range(size):
            if y < horizon:
                c = _mix(top, glow, (y / horizon) ** 1.6)
                d = math.hypot(x - moon[0], y - moon[1])
                if d < moon[2]:
                    c = _mix(c, (250, 226, 190), 0.92)
                elif d < moon[2] * 2.6:
                    c = _mix(c, (250, 220, 180), 0.25 * (1 - (d - moon[2]) / (moon[2] * 1.6)))
            else:
                t = (y - horizon) / (size - horizon)
                c = _mix(_mix(glow, sea, 0.55), sea, t ** 0.6)
                wave = math.sin(x * 0.18 + y * 0.9 + seed) * math.sin(y * 0.35)
                if wave > 0.82:
                    c = _mix(c, (230, 200, 170), 0.18)
                if abs(x - moon[0]) < moon[2] * (1.2 - t) and math.sin(y * 1.7 + x * 0.3) > 0.2:
                    c = _mix(c, (250, 220, 170), 0.35 * (1 - t))
            px[y][x] = c
    for (lx, ly, r, hue) in lanterns:
        warm = _mix((255, 170, 70), (255, 110, 60), hue)
        for y in range(max(0, ly - r * 4), min(size, ly + r * 6)):
            for x in range(max(0, lx - r * 4), min(size, lx + r * 4)):
                d = math.hypot((x - lx) / 1.0, (y - ly) / 1.25)
                if d < r:
                    px[y][x] = _mix(warm, (255, 240, 200), 0.4 * (1 - d / r))
                elif d < r * 3.2:
                    px[y][x] = _mix(px[y][x], warm, 0.45 * (1 - (d - r) / (r * 2.2)) ** 2)
        for k in range(1, r * 5):  # reflection
            y = ly + r + k * 2
            if y < size and math.sin(k * 1.3 + lx) > -0.3:
                for x in range(max(0, lx - 1), min(size, lx + 2)):
                    px[y][x] = _mix(px[y][x], warm, 0.5 * (1 - k / (r * 5)))
    rows = [bytes(v for p in row for v in p) for row in px]
    traits = [{"trait_type": "Lanterns", "value": n}, {"trait_type": "Palette", "value": ["Dusk Rose", "Violet Hour", "Copper Evening", "Deep Blue"][seed % 4]},
              {"trait_type": "Moon", "value": "high" if moon[1] < horizon // 3 else "low"}]
    return _png(size, size, rows), {"attributes": traits, "lanterns": n}


def alt_text(seed: int, traits: dict) -> str:
    pal = traits["attributes"][1]["value"].lower()
    return (f"Digital illustration: {traits['lanterns']} small glowing paper lanterns float on dark tidal water beneath a pale moon, "
            f"their warm reflections streaking toward the viewer; {pal} sky fading to deep sea colours.")


def collection_svg() -> bytes:
    """Collection artwork as a static, script-free SVG."""
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 240" width="400" height="240" role="img">',
             '<title>Tidewater Lanterns</title>',
             '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#181f48"/><stop offset="0.6" stop-color="#b46078"/>'
             '<stop offset="1" stop-color="#0c2846"/></linearGradient>'
             '<radialGradient id="g"><stop offset="0" stop-color="#fff0c8"/><stop offset="0.4" stop-color="#ffaa46"/><stop offset="1" stop-color="#ffaa46" stop-opacity="0"/></radialGradient></defs>',
             '<rect width="400" height="240" fill="url(#s)"/>', '<circle cx="300" cy="60" r="22" fill="#fae2be"/>', '<rect y="140" width="400" height="100" fill="#0c2846" opacity="0.85"/>']
    rnd = random.Random(42)
    for i in range(9):
        x, y = 30 + i * 42 + rnd.randint(-8, 8), 160 + rnd.randint(0, 50)
        parts.append(f'<circle cx="{x}" cy="{y}" r="16" fill="url(#g)"/><rect x="{x - 4}" y="{y - 5}" width="8" height="10" rx="2" fill="#ffd28c"/>')
    parts.append('<text x="20" y="40" font-family="Georgia, serif" font-size="24" fill="#f8f4ea">Tidewater Lanterns</text></svg>')
    return "".join(parts).encode()


def chime_wav(seed: int = 3, seconds: float = 1.2, rate: int = 8000) -> bytes:
    """A short synthesized harbour-bell chime (mono 8-bit PCM)."""
    n = int(seconds * rate)
    f = [523.25, 659.25, 783.99][seed % 3]
    data = bytes(int(128 + 90 * math.exp(-3 * i / n) * (math.sin(2 * math.pi * f * i / rate) * 0.7 + math.sin(2 * math.pi * f * 2.01 * i / rate) * 0.3)) for i in range(n))
    fmt = struct.pack("<HHIIHH", 1, 1, rate, rate, 1, 8)
    body = b"WAVE" + b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(data)) + data
    return b"RIFF" + struct.pack("<I", len(body)) + body


def statement_pdf(lines: list[str]) -> bytes:
    """Minimal static PDF (one page, Helvetica text, no scripts or actions)."""
    def esc(s):
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    content = "BT /F1 11 Tf 50 780 Td 14 TL " + " ".join(f"({esc(l)}) '" for l in lines) + " ET"
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>", f"<< /Length {len(content)} >>\nstream\n{content}\nendstream"]
    out = b"%PDF-1.4\n"
    offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode("latin-1")
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode() + b"".join(f"{o:010d} 00000 n \n".encode() for o in offs)
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return out
