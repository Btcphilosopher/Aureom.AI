"""Issuer claims and their review.

A blockchain entry proves that a transaction was recorded — not that every statement an
issuer attaches is true. Claims such as "verified artist", "authentic work" or "physical
asset backed" are therefore tracked here, off chain, with evidence references (hashes and
who holds the documents) and an explicit human review outcome. Nothing in this module
writes to the ledger, and the console labels these as *reviews*, never as chain facts.

Do not put personal information or confidential documents on the public ledger or in
public metadata: store the documents privately and record only their SHA-256 here.
"""
from __future__ import annotations

import json
import re
import uuid

from ..util import ChainworksError
from .db import now_ms, tx

TYPES = ("verified_artist", "authentic_work", "physical_asset_backed", "licence_grant", "other")
LABEL = {"submitted": "claim submitted — not reviewed", "under_review": "under review — not verified", "accepted": "accepted by reviewer (off-chain review, not a chain fact)",
         "rejected": "rejected by reviewer", "withdrawn": "withdrawn by claimant"}


class Claims:
    def __init__(self, conn, network_key: str):
        self.c, self.key = conn, network_key

    def submit(self, collection_id: str, claim_type: str, statement: str, claimant: str, evidence: list[dict], token_id: str | None = None) -> dict:
        if claim_type not in TYPES:
            raise ChainworksError(f"claim_type must be one of {TYPES}")
        for e in evidence:
            if not re.fullmatch(r"[0-9a-f]{64}", e.get("sha256", "")) or not e.get("description") or not e.get("held_by"):
                raise ChainworksError("each evidence item needs description, sha256 (of the private document) and held_by")
        cid = "clm_" + uuid.uuid4().hex[:12]
        with tx(self.c):
            self.c.execute("INSERT INTO authenticity_claims (claim_id, network_key, collection_id, token_id, claim_type, statement, claimant, evidence_json, status, created_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?)",
                           (cid, self.key, collection_id, token_id, claim_type, statement, claimant, json.dumps(evidence), "submitted", now_ms()))
        return self.get(cid)

    def review(self, claim_id: str, reviewer: str, decision: str, notes: str) -> dict:
        if decision not in ("under_review", "accepted", "rejected"):
            raise ChainworksError("decision must be under_review|accepted|rejected")
        c = self.get(claim_id)
        if c["status"] in ("accepted", "rejected", "withdrawn") and decision != "under_review":
            raise ChainworksError(f"claim already {c['status']}; reopen with under_review first")
        if decision == "accepted" and not c["evidence"]:
            raise ChainworksError("cannot accept a claim without evidence")
        if reviewer == c["claimant"]:
            raise ChainworksError("a claimant cannot review their own claim")
        with tx(self.c):
            self.c.execute("UPDATE authenticity_claims SET status = ?, reviewer = ?, review_notes = ?, reviewed_at_ms = ? WHERE claim_id = ?",
                           (decision, reviewer, notes, now_ms(), claim_id))
        return self.get(claim_id)

    def get(self, claim_id: str) -> dict:
        r = self.c.execute("SELECT * FROM authenticity_claims WHERE claim_id = ?", (claim_id,)).fetchone()
        if not r:
            raise ChainworksError(f"unknown claim {claim_id}")
        d = dict(r)
        d["evidence"] = json.loads(d.pop("evidence_json"))
        d["display"] = LABEL[d["status"]]
        d["on_chain"] = False
        return d

    def list(self, collection_id: str | None = None) -> list[dict]:
        q = "SELECT claim_id FROM authenticity_claims WHERE network_key = ?" + (" AND collection_id = ?" if collection_id else "") + " ORDER BY created_at_ms"
        args = (self.key, collection_id) if collection_id else (self.key,)
        return [self.get(r["claim_id"]) for r in self.c.execute(q, args)]
