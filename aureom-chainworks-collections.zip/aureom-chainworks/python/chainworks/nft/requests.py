"""Collections-module requests: prepare -> validate (simulate) -> review -> sign -> submit
-> confirm/finalise -> index, with idempotency and reconciliation of unknown outcomes.

Rules this module enforces:
* One request per (network, idempotency key). Creating it again returns the existing
  request instead of a second transaction.
* A request is signed once. Its exact signed bytes are stored; any resubmission sends the
  same bytes (same txid, same nonce), which the ledger can include at most once.
* If a submission's outcome is not known (timeout, node unreachable), the request becomes
  `unknown`. It is reconciled by querying the txid on every node before anything else;
  it is never re-signed with a fresh nonce while the old transaction might still land.
* "Uploaded" is not "minted", and "submitted" is not "confirmed": the status only advances
  on evidence from the chain (receipt in a block, confirmations or BFT commit, index).
"""
from __future__ import annotations

import json
import pathlib
import uuid

from ..util import ChainworksError, http, read_json, try_get
from .db import now_ms, tx

TERMINAL = {"indexed", "rejected", "failed", "dropped"}


class Requests:
    def __init__(self, conn, net, wallet, network_key: str):
        self.c = conn
        self.net = net
        self.w = wallet
        self.key = network_key

    # ------------------------------------------------------------------ state
    def get(self, rid: str) -> dict:
        r = self.c.execute("SELECT * FROM module_requests WHERE request_id = ?", (rid,)).fetchone()
        if not r:
            raise ChainworksError(f"unknown request {rid}")
        return dict(r)

    def _move(self, rid, to, detail=None, **fields):
        r = self.get(rid)
        sets = ", ".join(f"{k} = ?" for k in fields)
        with tx(self.c):
            self.c.execute(f"UPDATE module_requests SET status = ?, updated_at_ms = ?{', ' + sets if sets else ''} WHERE request_id = ?",
                           (to, now_ms(), *fields.values(), rid))
            self.c.execute("INSERT INTO request_transitions (request_id, at_ms, from_status, to_status, detail) VALUES (?,?,?,?,?)",
                           (rid, now_ms(), r["status"], to, detail))
        return self.get(rid)

    def history(self, rid):
        return [dict(x) for x in self.c.execute("SELECT at_ms, from_status, to_status, detail FROM request_transitions WHERE request_id = ? ORDER BY id", (rid,))]

    # ------------------------------------------------------------------ prepare
    def create(self, kind: str, sender: str, action: dict, idempotency_key: str, collection_id=None, token_ids=(), nonce="auto") -> dict:
        ex = self.c.execute("SELECT request_id FROM module_requests WHERE network_key = ? AND idempotency_key = ?", (self.key, idempotency_key)).fetchone()
        if ex:
            r = self.get(ex["request_id"])
            r["deduplicated"] = True
            return r
        unsigned = self.w.prepare(sender, action, nonce=nonce)
        doc = read_json(unsigned)
        rid = "req_" + uuid.uuid4().hex[:16]
        with tx(self.c):
            self.c.execute("INSERT INTO module_requests (request_id, idempotency_key, network_key, kind, sender, collection_id, token_ids_json, action_json, status, txid, created_at_ms, updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                           (rid, idempotency_key, self.key, kind, sender, collection_id, json.dumps([str(t) for t in token_ids]), json.dumps(action), "prepared", doc["review"]["txid"], now_ms(), now_ms()))
            self.c.execute("INSERT INTO request_transitions (request_id, at_ms, from_status, to_status, detail) VALUES (?,?,?,?,?)", (rid, now_ms(), None, "prepared", str(unsigned)))
        (self._dir() / f"{rid}.unsigned.json").write_text(pathlib.Path(unsigned).read_text())
        r = self.get(rid)
        r["deduplicated"] = False
        return r

    def _dir(self):
        d = self.net.dir / "secrets" / "nft-requests"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def unsigned_path(self, rid) -> pathlib.Path:
        return self._dir() / f"{rid}.unsigned.json"

    # ------------------------------------------------------------------ validate + review
    def validate(self, rid: str) -> dict:
        """Simulate the unsigned transaction on the node and record the human review."""
        r = self.get(rid)
        u = read_json(self.unsigned_path(rid))
        review = self.w.review(self.unsigned_path(rid))
        code, sim = http("POST", f"{self.w.api}/v1/simulate", {"unsigned_tx": u["unsigned_hex"]})
        if code != 200:
            raise ChainworksError(f"simulation request failed: {code} {sim}")
        result = {"review": {k: review.get(k) for k in ("summary", "warnings", "fee", "nonce", "chain_id", "expiry_height", "txid")},
                  "simulation": {"admissible": sim["admissible"], "status": (sim.get("receipt") or {}).get("status"), "error": (sim.get("receipt") or {}).get("error") or sim.get("error"),
                                 "events": [e["kind"] for e in (sim.get("receipt") or {}).get("events", [])], "height": sim["simulated_height"], "note": sim["note"]}}
        ok = sim["admissible"] and sim["receipt"]["status"] == "success"
        if not ok:
            return self._move(rid, "rejected", "simulation: " + json.dumps(result["simulation"]["error"]), review_json=json.dumps(result), last_error=json.dumps(result["simulation"]["error"])) | {"validation": result}
        return self._move(rid, "validated", "simulation succeeded", review_json=json.dumps(result)) | {"validation": result}

    # ------------------------------------------------------------------ sign + submit
    def sign(self, rid: str) -> dict:
        r = self.get(rid)
        if r["status"] != "validated":
            raise ChainworksError(f"request {rid} is {r['status']}; only validated (reviewed) requests are signed")
        signed = self.w.sign(r["sender"], self.unsigned_path(rid))
        d = read_json(signed)
        return self._move(rid, "signed", "signed by aureom-cli (key never left the keystore)", signed_hex=d["signed_hex"], txid=d["txid"])

    def submit(self, rid: str) -> dict:
        r = self.get(rid)
        if r["status"] in ("submitted", "unknown"):
            rr = self.reconcile(rid)
            if rr["status"] not in ("unknown", "submitted", "signed"):
                return rr
            if rr["status"] == "submitted":
                return rr
        elif r["status"] != "signed":
            raise ChainworksError(f"request {rid} is {r['status']}; nothing to submit")
        try:
            code, resp = http("POST", f"{self.w.api}/v1/transactions", {"tx": r["signed_hex"]}, timeout=5)
        except Exception as e:  # noqa: BLE001 — connection failure: outcome unknown
            return self._move(rid, "unknown", f"submission outcome unknown: {e}", attempts=r["attempts"] + 1, last_error=str(e))
        if code == 202:
            return self._move(rid, "submitted", "accepted by the node's mempool (not yet included)", attempts=r["attempts"] + 1)
        err = (resp or {}).get("error", {}) if isinstance(resp, dict) else {}
        if err.get("code") in ("bad_nonce", "duplicate", "conflicting_nonce"):
            # possibly our own earlier submission already landed: reconcile, do not re-sign
            self._move(rid, "unknown", f"node replied {err.get('code')}: reconciling by txid", attempts=r["attempts"] + 1)
            return self.reconcile(rid)
        return self._move(rid, "rejected", f"node rejected: {err.get('code')} {err.get('message')}", attempts=r["attempts"] + 1, last_error=json.dumps(err))

    def reconcile(self, rid: str) -> dict:
        """Determine what happened to a submitted transaction from the chain itself."""
        r = self.get(rid)
        seen = []
        for n in self.net.nodes():
            v = try_get(f"{self.net.api(n['name'])}/v1/transactions/{r['txid']}")
            if v:
                seen.append(v)
        for v in seen:
            if v["status"] in ("included", "confirmed", "finalised"):
                rc = v.get("receipt") or {}
                if rc.get("status") == "failed":
                    return self._move(rid, "failed", f"included at height {v['block_height']} but the action failed: {rc.get('error')}",
                                      receipt_json=json.dumps(rc), block_height=v["block_height"], last_error=rc.get("error"))
                # reflect the chain's current view; under PoW a reorganisation can move a
                # transaction back from confirmed to included or pending
                return self._move(rid, v["status"], f"{v['status']} at height {v['block_height']}" + (f" ({v.get('confirmations')} confirmations)" if v.get("confirmations") else ""),
                                  receipt_json=json.dumps(rc), block_height=v["block_height"])
        if any(v["status"] == "pending" for v in seen):
            return self._move(rid, "submitted", "pending in a mempool") if r["status"] != "submitted" else r
        # not known anywhere: has the nonce been consumed by something else?
        tx_nonce = read_json(self.unsigned_path(rid))["review"]["nonce"]
        acct = self.w.account(r["sender"]) or {}
        if acct.get("nonce", 0) > tx_nonce:
            return self._move(rid, "dropped", "nonce consumed by a different transaction; this one can never be included")
        if any(v["status"] == "dropped" for v in seen):
            return self._move(rid, "signed", "dropped from mempools without inclusion; the identical bytes may be resubmitted")
        return self._move(rid, "unknown", "not found on any node yet") if r["status"] != "unknown" else r

    def mark_indexed(self, rid: str, indexer) -> dict:
        r = self.get(rid)
        row = self.c.execute("SELECT height, status FROM chain_tx_outcomes WHERE network_key = ? AND txid = ?", (self.key, r["txid"])).fetchone()
        if not row:
            return r
        s = indexer.settlement(row["height"])
        if s["state"] in ("confirmed", "finalised") and row["status"] == "success":
            return self._move(rid, "indexed", f"in the index at height {row['height']} ({s['state']})")
        return r

    # ------------------------------------------------------------------ convenience
    def run(self, rid: str, indexer=None, wait_s: float = 90.0, settle=True) -> dict:
        """Full pipeline for one request (used by the CLI and demos)."""
        import time
        r = self.get(rid)
        if r["status"] == "prepared":
            r = self.validate(rid)
            if r["status"] == "rejected":
                return r
        if r["status"] == "validated":
            r = self.sign(rid)
        if r["status"] in ("signed", "unknown", "submitted"):
            r = self.submit(rid)
        end = time.time() + wait_s
        want = {"confirmed", "finalised"} if settle else {"included", "confirmed", "finalised"}
        while time.time() < end and r["status"] not in want | TERMINAL:
            time.sleep(0.5)
            r = self.reconcile(rid)
        if indexer and r["status"] in ("confirmed", "finalised", "failed"):
            indexer.sync()  # failed receipts are indexed too (they are part of the record)
            if r["status"] != "failed":
                r = self.mark_indexed(rid, indexer)
        return r
