"""Token-gated access by signed challenge.

A wallet address alone proves nothing: anyone can type someone else's address. Access is
granted only when the requester signs a fresh, single-use challenge with the key whose
address currently owns a qualifying token *according to the chain*:

1. `issue()` creates a challenge naming the network (chain id + genesis hash), the
   audience (which service), the collection (and optional token), the address, a random
   nonce and an expiry. It is stored server-side.
2. The holder signs the exact challenge text with `aureom-cli message sign`
   (domain `AUREOM/MSG/v1`, which can never be a transaction signature).
3. `verify()` checks: challenge known, unused, unexpired; public key hashes to the claimed
   address; Ed25519 signature valid over the domain-separated bytes; and — via the node's
   authoritative state — that the address owns the token (or any live token in the
   collection) right now. The challenge is consumed whatever the result.

Ownership can change immediately after verification; services that grant long sessions
should re-check ownership periodically.
"""
from __future__ import annotations

import hashlib
import secrets
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .. import bech32m
from ..util import try_get
from .db import tx

DOMAIN = b"AUREOM/MSG/v1"


def message_bytes(msg: str) -> bytes:
    m = msg.encode("utf-8")
    return bytes([len(DOMAIN)]) + DOMAIN + len(m).to_bytes(4, "big") + m


def address_from_pubkey(pk: bytes, hrp: str) -> str:
    d = b"AUREOM/ADDR/v1"
    a = hashlib.sha256(bytes([len(d)]) + d + b"\x01" + pk).digest()[:20]
    return bech32m.encode(hrp, a)


class Gate:
    def __init__(self, conn, api: str, network: dict, hrp: str, ttl_s: int = 300):
        self.c, self.api, self.net, self.hrp, self.ttl = conn, api.rstrip("/"), network, hrp, ttl_s
        self.key = f"{network['chain_id']}:{network['genesis_hash']}"

    def issue(self, address: str, collection_id: str, audience: str, token_id: str | None = None) -> dict:
        nonce = secrets.token_hex(16)
        now = int(time.time() * 1000)
        exp = now + self.ttl * 1000
        msg = "\n".join([
            "AUREOM COLLECTIONS access challenge",
            f"audience: {audience}",
            f"chain_id: {self.net['chain_id']}",
            f"genesis_hash: {self.net['genesis_hash']}",
            f"address: {address}",
            f"collection: {collection_id}",
            f"token_id: {token_id or 'any'}",
            f"nonce: {nonce}",
            f"expires_at_ms: {exp}",
            "Signing this proves control of the address. It is not a transaction and moves nothing.",
        ])
        with tx(self.c):
            self.c.execute("INSERT INTO gate_challenges (nonce, network_key, address, collection_id, token_id, audience, message, issued_at_ms, expires_at_ms) VALUES (?,?,?,?,?,?,?,?,?)",
                           (nonce, self.key, address, collection_id, token_id, audience, msg, now, exp))
        return {"nonce": nonce, "message": msg, "expires_at_ms": exp}

    def verify(self, nonce: str, pubkey_hex: str, signature_hex: str) -> dict:
        row = self.c.execute("SELECT * FROM gate_challenges WHERE nonce = ?", (nonce,)).fetchone()
        now = int(time.time() * 1000)

        def done(ok: bool, reason: str, **extra):
            if row is not None and row["used_at_ms"] is None:
                with tx(self.c):
                    self.c.execute("UPDATE gate_challenges SET used_at_ms = ?, result = ? WHERE nonce = ?", (now, reason, nonce))
            return {"granted": ok, "reason": reason, **extra}

        if row is None:
            return {"granted": False, "reason": "unknown challenge"}
        if row["used_at_ms"] is not None:
            return {"granted": False, "reason": "challenge already used (replay)"}
        if row["network_key"] != self.key:
            return done(False, "challenge was issued for another network")
        if now > row["expires_at_ms"]:
            return done(False, "challenge expired")
        try:
            pk = bytes.fromhex(pubkey_hex)
            sig = bytes.fromhex(signature_hex)
        except ValueError:
            return done(False, "malformed key or signature")
        if len(pk) != 32 or address_from_pubkey(pk, self.hrp) != row["address"]:
            return done(False, "public key does not belong to the challenged address")
        try:
            Ed25519PublicKey.from_public_bytes(pk).verify(sig, message_bytes(row["message"]))
        except (InvalidSignature, ValueError):
            return done(False, "signature invalid for this challenge")
        # ownership from the chain (authoritative), not from the application index
        if row["token_id"]:
            t = try_get(f"{self.api}/v1/nft/tokens/{row['collection_id']}/{row['token_id']}")
            owns = bool(t) and t.get("owner") == row["address"]
            h = t.get("state_height") if t else None
        else:
            v = try_get(f"{self.api}/v1/nft/collections/{row['collection_id']}/tokens?owner={row['address']}&limit=1")
            owns = bool(v) and len(v.get("tokens", [])) > 0
            h = v.get("state_height") if v else None
        if not owns:
            return done(False, "signature valid, but the address does not currently own a qualifying token", chain_height=h)
        return done(True, "signature valid and ownership confirmed on chain", chain_height=h, address=row["address"],
                    note="ownership can change at any time; re-check for long-lived sessions")
