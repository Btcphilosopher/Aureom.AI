-- AUREOM COLLECTIONS — off-chain application data.
-- Media, metadata documents, drafts, requests, storage monitoring, access challenges and
-- authenticity reviews. None of these tables record or decide token ownership.

CREATE TABLE media_assets (
  media_id      TEXT PRIMARY KEY,           -- "sha256:<hex>" of the exact bytes
  sha256        TEXT NOT NULL UNIQUE CHECK (length(sha256) = 64),
  kind          TEXT NOT NULL CHECK (kind IN ('image', 'audio', 'video', 'document', 'structured')),
  mime          TEXT NOT NULL,
  bytes         INTEGER NOT NULL CHECK (bytes > 0),
  width         INTEGER,
  height        INTEGER,
  original_name TEXT,
  alt_text      TEXT,                       -- accessibility description (required for images/video)
  transcript    TEXT,                       -- audio/video text alternative, optional
  cid_raw_v1    TEXT,                       -- CIDv1 (raw codec, sha2-256) over the full bytes
  licence       TEXT,
  validation_json TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);

-- Where copies of a media file or metadata document are stored, and who maintains them.
CREATE TABLE storage_locations (
  location_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  content_sha256 TEXT NOT NULL,
  content_kind  TEXT NOT NULL CHECK (content_kind IN ('media', 'metadata')),
  adapter       TEXT NOT NULL CHECK (adapter IN ('local', 's3', 'ipfs', 'http')),
  locator       TEXT NOT NULL,              -- path, s3://bucket/key, ipfs://cid, https://...
  public_uri    TEXT,                       -- URI written into metadata, if any
  maintainer    TEXT NOT NULL,              -- who keeps this copy available
  monitoring    TEXT NOT NULL,              -- how availability is monitored
  added_at_ms   INTEGER NOT NULL,
  UNIQUE (content_sha256, adapter, locator)
);

CREATE TABLE storage_checks (
  check_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  location_id   INTEGER NOT NULL REFERENCES storage_locations(location_id) ON DELETE CASCADE,
  checked_at_ms INTEGER NOT NULL,
  available     INTEGER NOT NULL,
  hash_matches  INTEGER,                    -- NULL when content could not be fetched
  http_status   INTEGER,
  latency_ms    INTEGER,
  detail        TEXT NOT NULL
);

CREATE TABLE metadata_documents (
  metadata_sha256 TEXT PRIMARY KEY CHECK (length(metadata_sha256) = 64),
  schema        TEXT NOT NULL,
  canonical_bytes BLOB NOT NULL,            -- the exact bytes hashed on chain
  name          TEXT NOT NULL,
  collection_slug TEXT,
  token_id      TEXT,
  media_sha256_json TEXT NOT NULL,          -- media referenced by the document
  warnings_json TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);

CREATE TABLE collection_drafts (
  draft_id      TEXT PRIMARY KEY,
  network_key   TEXT NOT NULL,
  slug          TEXT NOT NULL,
  creator       TEXT NOT NULL,
  action_json   TEXT NOT NULL,
  powers_json   TEXT NOT NULL,              -- shown before signing
  status        TEXT NOT NULL CHECK (status IN ('draft', 'prepared', 'submitted', 'confirmed', 'failed', 'abandoned')),
  txid          TEXT,
  collection_id TEXT,                       -- derived id; becomes real only when the tx succeeds on chain
  created_at_ms INTEGER NOT NULL,
  updated_at_ms INTEGER NOT NULL
);

-- Mint / transfer / other module requests. A request moves through
-- prepared -> validated -> signed -> submitted -> included -> (confirmed|finalised) -> indexed
-- or ends rejected | failed | dropped. `unknown` means a submission's outcome is not yet
-- known; it must be reconciled (query the txid) before anything is retried.
CREATE TABLE module_requests (
  request_id    TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL,
  network_key   TEXT NOT NULL,
  kind          TEXT NOT NULL CHECK (kind IN ('mint', 'mint_batch', 'drop', 'transfer', 'approve', 'operator', 'burn', 'metadata_update', 'metadata_freeze', 'listing_create', 'listing_cancel', 'listing_buy', 'role', 'other')),
  sender        TEXT NOT NULL,
  collection_id TEXT,
  token_ids_json TEXT NOT NULL DEFAULT '[]',
  action_json   TEXT NOT NULL,
  review_json   TEXT,
  status        TEXT NOT NULL CHECK (status IN ('prepared', 'validated', 'signed', 'submitted', 'unknown', 'included', 'confirmed', 'finalised', 'indexed', 'rejected', 'failed', 'dropped')),
  txid          TEXT,
  signed_hex    TEXT,                       -- exact bytes; resubmission reuses them (same txid, same nonce)
  attempts      INTEGER NOT NULL DEFAULT 0,
  last_error    TEXT,
  receipt_json  TEXT,
  block_height  INTEGER,
  created_at_ms INTEGER NOT NULL,
  updated_at_ms INTEGER NOT NULL,
  UNIQUE (network_key, idempotency_key)
);

CREATE TABLE request_transitions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id    TEXT NOT NULL REFERENCES module_requests(request_id) ON DELETE CASCADE,
  at_ms         INTEGER NOT NULL,
  from_status   TEXT,
  to_status     TEXT NOT NULL,
  detail        TEXT
);

-- Token-gated access: single-use signed challenges.
CREATE TABLE gate_challenges (
  nonce         TEXT PRIMARY KEY,
  network_key   TEXT NOT NULL,
  address       TEXT NOT NULL,
  collection_id TEXT NOT NULL,
  token_id      TEXT,
  audience      TEXT NOT NULL,
  message       TEXT NOT NULL,
  issued_at_ms  INTEGER NOT NULL,
  expires_at_ms INTEGER NOT NULL,
  used_at_ms    INTEGER,
  result        TEXT
);

-- Issuer claims ("verified artist", "authentic work", "physical asset backed") need
-- separate evidence and human review. Only evidence hashes are stored here; documents
-- themselves stay in private storage and never go on the public ledger.
CREATE TABLE authenticity_claims (
  claim_id      TEXT PRIMARY KEY,
  network_key   TEXT NOT NULL,
  collection_id TEXT NOT NULL,
  token_id      TEXT,
  claim_type    TEXT NOT NULL CHECK (claim_type IN ('verified_artist', 'authentic_work', 'physical_asset_backed', 'licence_grant', 'other')),
  statement     TEXT NOT NULL,
  claimant      TEXT NOT NULL,
  evidence_json TEXT NOT NULL,              -- [{"description", "sha256", "held_by"}]
  status        TEXT NOT NULL CHECK (status IN ('submitted', 'under_review', 'accepted', 'rejected', 'withdrawn')),
  reviewer      TEXT,
  review_notes  TEXT,
  reviewed_at_ms INTEGER,
  created_at_ms INTEGER NOT NULL
);
