-- AUREOM COLLECTIONS — chain-derived index (rebuildable).
-- Everything in this file is derived from on-chain blocks and receipts. The ledger is
-- authoritative; these tables are a cache that `chainworks nft index rebuild` can drop and
-- recreate from chain events at any time. No application code writes ownership here
-- except the indexer replaying chain events.

CREATE TABLE networks (
  network_key   TEXT PRIMARY KEY,           -- "<chain_id>:<genesis_hash>"
  chain_id      TEXT NOT NULL,
  genesis_hash  TEXT NOT NULL CHECK (length(genesis_hash) = 64),
  profile       TEXT NOT NULL CHECK (profile IN ('pow', 'pos', 'poa')),
  name          TEXT NOT NULL,
  settlement    TEXT NOT NULL,              -- probabilistic | deterministic-bft
  confirmations_recommended INTEGER,
  UNIQUE (chain_id, genesis_hash)
);

-- Blocks the index has consumed, used to detect reorganisations (prev_id linkage).
CREATE TABLE chain_blocks (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  height        INTEGER NOT NULL CHECK (height >= 0),
  block_id      TEXT NOT NULL,
  prev_id       TEXT NOT NULL,
  timestamp_ms  INTEGER NOT NULL,
  tx_count      INTEGER NOT NULL,
  indexed_at_ms INTEGER NOT NULL,
  PRIMARY KEY (network_key, height)
);

CREATE TABLE index_cursor (
  network_key   TEXT PRIMARY KEY REFERENCES networks(network_key),
  height        INTEGER NOT NULL,
  block_id      TEXT NOT NULL,
  source_node   TEXT NOT NULL,
  updated_at_ms INTEGER NOT NULL
);

-- Outcome of every collections-module transaction seen on the indexed chain,
-- including failed ones (e.g. a rejected unauthorised transfer).
CREATE TABLE chain_tx_outcomes (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  txid          TEXT NOT NULL,
  height        INTEGER NOT NULL,
  block_id      TEXT NOT NULL,
  tx_index      INTEGER NOT NULL,
  action_type   TEXT NOT NULL,
  sender        TEXT NOT NULL,
  status        TEXT NOT NULL CHECK (status IN ('success', 'failed')),
  error         TEXT,
  fee_paid      TEXT NOT NULL,
  action_json   TEXT NOT NULL,
  PRIMARY KEY (network_key, txid),
  FOREIGN KEY (network_key, height) REFERENCES chain_blocks(network_key, height) ON DELETE CASCADE
);

-- Every collections-module event, in chain order. The provenance record.
CREATE TABLE provenance_events (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  height        INTEGER NOT NULL,
  block_id      TEXT NOT NULL,
  txid          TEXT NOT NULL,
  tx_index      INTEGER NOT NULL,
  event_index   INTEGER NOT NULL,
  kind          TEXT NOT NULL,
  op            TEXT,
  collection_id TEXT,
  token_id      TEXT,
  from_addr     TEXT,
  to_addr       TEXT,
  actor         TEXT,
  attrs_json    TEXT NOT NULL,
  UNIQUE (network_key, block_id, tx_index, event_index),
  FOREIGN KEY (network_key, height) REFERENCES chain_blocks(network_key, height) ON DELETE CASCADE
);
CREATE INDEX provenance_token ON provenance_events (network_key, collection_id, token_id, height);
CREATE INDEX provenance_kind ON provenance_events (network_key, kind, height);

-- ---------------------------------------------------------------- derived caches
-- Recomputed from provenance_events by the indexer (`derive_caches`) after every sync,
-- reorganisation or rebuild. `as_of_height` is the index height they reflect.

CREATE TABLE collections_cache (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  collection_id TEXT NOT NULL,
  slug          TEXT NOT NULL,
  creator       TEXT NOT NULL,
  created_height INTEGER NOT NULL,
  created_txid  TEXT NOT NULL,
  max_supply    TEXT,
  metadata_policy TEXT NOT NULL,
  mint_authority TEXT,
  metadata_admin TEXT,
  admin         TEXT,
  flags         INTEGER NOT NULL,
  transfer_policy INTEGER NOT NULL,
  royalty_bps   INTEGER NOT NULL,
  royalty_recipient TEXT,
  minted        INTEGER NOT NULL DEFAULT 0,
  burned        INTEGER NOT NULL DEFAULT 0,
  paused        INTEGER NOT NULL DEFAULT 0,
  frozen_all    INTEGER NOT NULL DEFAULT 0,
  as_of_height  INTEGER NOT NULL,
  PRIMARY KEY (network_key, collection_id)
);

CREATE TABLE ownership_cache (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  collection_id TEXT NOT NULL,
  token_id      TEXT NOT NULL,
  owner         TEXT,                       -- NULL when burned
  burned        INTEGER NOT NULL DEFAULT 0,
  metadata_uri  TEXT NOT NULL,
  metadata_hash TEXT NOT NULL,
  revision      INTEGER NOT NULL,
  frozen        INTEGER NOT NULL,
  minted_height INTEGER NOT NULL,
  last_event_height INTEGER NOT NULL,
  transfers     INTEGER NOT NULL DEFAULT 0,
  approved      TEXT,
  approval_expiry INTEGER NOT NULL DEFAULT 0,
  as_of_height  INTEGER NOT NULL,
  PRIMARY KEY (network_key, collection_id, token_id)
);
CREATE INDEX ownership_owner ON ownership_cache (network_key, owner);

CREATE TABLE operator_cache (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  collection_id TEXT NOT NULL,
  owner         TEXT NOT NULL,
  operator      TEXT NOT NULL,
  expiry_height INTEGER NOT NULL,
  granted_height INTEGER NOT NULL,
  as_of_height  INTEGER NOT NULL,
  PRIMARY KEY (network_key, collection_id, owner, operator)
);

CREATE TABLE listings_cache (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  listing_id    TEXT NOT NULL,
  collection_id TEXT NOT NULL,
  token_id      TEXT NOT NULL,
  seller        TEXT NOT NULL,
  price         TEXT NOT NULL,
  currency      TEXT NOT NULL,
  expiry_height INTEGER NOT NULL,
  status        TEXT NOT NULL,              -- active | sold | cancelled | invalidated | expired (expiry evaluated at read time)
  buyer         TEXT,
  created_height INTEGER NOT NULL,
  closed_height INTEGER,
  as_of_height  INTEGER NOT NULL,
  PRIMARY KEY (network_key, listing_id)
);

CREATE TABLE sales_cache (
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  listing_id    TEXT NOT NULL,
  txid          TEXT NOT NULL,
  height        INTEGER NOT NULL,
  collection_id TEXT NOT NULL,
  token_id      TEXT NOT NULL,
  seller        TEXT NOT NULL,
  buyer         TEXT NOT NULL,
  price         TEXT NOT NULL,
  currency      TEXT NOT NULL,
  royalty       TEXT NOT NULL,
  royalty_to    TEXT,
  platform_fee  TEXT NOT NULL,
  platform_to   TEXT,
  seller_proceeds TEXT NOT NULL,
  network_fee   TEXT NOT NULL,              -- paid by the buyer, separate from the price
  PRIMARY KEY (network_key, listing_id)
);

CREATE TABLE reorg_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  network_key   TEXT NOT NULL REFERENCES networks(network_key),
  detected_at_ms INTEGER NOT NULL,
  fork_height   INTEGER NOT NULL,
  old_tip_height INTEGER NOT NULL,
  old_tip       TEXT NOT NULL,
  new_tip       TEXT,
  blocks_removed INTEGER NOT NULL,
  events_removed INTEGER NOT NULL,
  source_node   TEXT NOT NULL
);
