"""Read-only JSON for the console's Collections section.

Index rows are labelled as a cache with their `as_of_height`; where ownership matters the
authoritative chain value is fetched and shown next to the index value. Nothing here
signs, submits or changes ledger state.
"""
from __future__ import annotations

import json
import threading
import time

from ..util import get, try_get
from .service import Collections, powers_preview

_lock = threading.RLock()


def serialised(f):
    """One request at a time touches the shared SQLite connection and indexer."""
    def w(*a, **k):
        with _lock:
            return f(*a, **k)
    w.__name__ = f.__name__
    return w


class ConsoleNft:
    def __init__(self, net):
        self.net = net
        self._s = None
        self._last_sync = 0.0
        self.error = None

    def s(self) -> Collections:
        if self._s is None:
            self._s = Collections(self.net)
        return self._s

    def synced(self):
        with _lock:
            s = self.s()
            if time.time() - self._last_sync > 2:
                try:
                    s.ix.sync()
                    self.error = None
                except Exception as e:  # noqa: BLE001
                    self.error = str(e)
                self._last_sync = time.time()
            return s

    @serialised
    def content(self, sha):
        return self.s().get_content(sha)

    def _rows(self, q, *a):
        return [dict(r) for r in self.s().db.execute(q, a)]

    @serialised
    def summary(self):
        s = self.synced()
        cur = s.ix.cursor()
        tip = try_get(s.api + "/v1/health")
        n = s.network()
        counts = {t: s.db.execute(f"SELECT count(*) FROM {t} WHERE network_key = ?", (s.key,)).fetchone()[0]
                  for t in ("collections_cache", "ownership_cache", "provenance_events", "listings_cache", "sales_cache", "reorg_log")}
        return {"module": n.get("modules", {}).get("collections"), "network": {"chain_id": n["chain_id"], "genesis_hash": n["genesis_hash"], "profile": n["profile"],
                "settlement": n.get("finality"), "confirmations_recommended": n.get("confirmations_recommended")},
                "index": {"height": cur["height"] if cur else 0, "block_id": cur["block_id"] if cur else None, "source_node": s.node, "node_tip": tip["height"] if tip else None,
                          "error": self.error, "note": "the index is a cache of chain events; ownership is authoritative only on chain"},
                "counts": counts, "requests": self._rows("SELECT status, count(*) AS n FROM module_requests WHERE network_key = ? GROUP BY status", s.key)}

    @serialised
    def collections(self):
        s = self.synced()
        out = []
        for r in self._rows("SELECT * FROM collections_cache WHERE network_key = ? ORDER BY created_height", s.key):
            chain = try_get(f"{s.api}/v1/nft/collections/{r['collection_id']}") or {}
            out.append({"index": r, "chain": chain, "agrees": bool(chain) and (chain.get("minted"), chain.get("burned")) == (r["minted"], r["burned"])})
        return {"collections": out}

    @serialised
    def assets(self, collection=None):
        s = self.synced()
        q = "SELECT o.*, c.slug FROM ownership_cache o LEFT JOIN collections_cache c ON c.network_key = o.network_key AND c.collection_id = o.collection_id WHERE o.network_key = ?"
        args = [s.key]
        if collection:
            q += " AND o.collection_id = ?"
            args.append(collection)
        rows = self._rows(q + " ORDER BY o.collection_id, CAST(o.token_id AS INTEGER)", *args)
        for r in rows:
            d = s.db.execute("SELECT canonical_bytes FROM metadata_documents WHERE metadata_sha256 = ?", (r["metadata_hash"],)).fetchone()
            if d:
                doc = json.loads(bytes(d["canonical_bytes"]))
                img = doc.get("image", {})
                r["document"] = {"name": doc.get("name"), "description": doc.get("description"), "image_sha256": img.get("sha256"), "image_mime": img.get("mime"),
                                 "alt_text": img.get("alt_text"), "attributes": doc.get("attributes", []), "rights": doc.get("rights")}
            else:
                r["document"] = None
            r["settlement"] = s.ix.settlement(r["last_event_height"])
        return {"assets": rows, "as_of_height": rows[0]["as_of_height"] if rows else None}

    @serialised
    def asset(self, cid, tid):
        s = self.synced()
        chain = get(f"{s.api}/v1/nft/tokens/{cid}/{tid}")
        idx = s.db.execute("SELECT * FROM ownership_cache WHERE network_key = ? AND collection_id = ? AND token_id = ?", (s.key, cid, str(tid))).fetchone()
        ev = self._rows("SELECT height, block_id, txid, kind, op, from_addr, to_addr, actor, attrs_json FROM provenance_events WHERE network_key = ? AND collection_id = ? AND token_id = ? ORDER BY height, tx_index, event_index", s.key, cid, str(tid))
        tip = s.ix.tip()
        for e in ev:
            e["attrs"] = json.loads(e.pop("attrs_json"))
            e["settlement"] = s.ix.settlement(e["height"], tip)
        docs = []
        for rv in chain.get("revisions", []):
            d = s.db.execute("SELECT canonical_bytes FROM metadata_documents WHERE metadata_sha256 = ?", (rv["metadata"]["sha256"],)).fetchone()
            docs.append({**rv, "document": json.loads(bytes(d["canonical_bytes"])) if d else None, "storage": s._locations(rv["metadata"]["sha256"])})
        return {"chain": chain, "index": dict(idx) if idx else None, "index_agrees": bool(idx) and idx["owner"] == chain["owner"], "events": ev, "revisions": docs,
                "claims": [c for c in s.claims().list(cid) if c["token_id"] in (None, str(tid))]}

    @serialised
    def activity(self, limit=200):
        s = self.synced()
        tip = s.ix.tip()
        outs = self._rows("SELECT * FROM chain_tx_outcomes WHERE network_key = ? ORDER BY height DESC, tx_index DESC LIMIT ?", s.key, limit)
        for o in outs:
            o["action"] = json.loads(o.pop("action_json"))
            o["settlement"] = s.ix.settlement(o["height"], tip)
        evs = self._rows("SELECT height, txid, kind, op, collection_id, token_id, from_addr, to_addr, actor FROM provenance_events WHERE network_key = ? ORDER BY height DESC, tx_index DESC, event_index DESC LIMIT ?", s.key, limit)
        return {"transactions": outs, "events": evs, "reorgs": self._rows("SELECT * FROM reorg_log WHERE network_key = ? ORDER BY id DESC", s.key), "tip": tip, "profile": s.network()["profile"]}

    @serialised
    def requests(self):
        s = self.s()
        rows = self._rows("SELECT request_id, idempotency_key, kind, sender, collection_id, token_ids_json, status, txid, attempts, last_error, block_height, created_at_ms, updated_at_ms FROM module_requests WHERE network_key = ? ORDER BY created_at_ms DESC", s.key)
        for r in rows:
            r["token_ids"] = json.loads(r.pop("token_ids_json"))
            r["history"] = s.requests.history(r["request_id"])
        return {"requests": rows, "lifecycle": ["prepared", "validated", "signed", "submitted", "included", "confirmed|finalised", "indexed"],
                "note": "a completed upload is not a mint and a submitted transaction is not a confirmed NFT"}

    @serialised
    def media(self):
        s = self.s()
        rows = self._rows("SELECT media_id, sha256, kind, mime, bytes, width, height, original_name, alt_text, transcript, cid_raw_v1, licence, created_at_ms FROM media_assets ORDER BY created_at_ms")
        health = s.storage_health()
        for r in rows:
            r["locations"] = [h for h in health if h["content_sha256"] == r["sha256"]]
        docs = self._rows("SELECT metadata_sha256, schema, name, collection_slug, token_id, media_sha256_json, warnings_json, created_at_ms FROM metadata_documents ORDER BY created_at_ms")
        for d in docs:
            d["media_sha256"] = json.loads(d.pop("media_sha256_json"))
            d["warnings"] = json.loads(d.pop("warnings_json"))
            d["locations"] = [h for h in health if h["content_sha256"] == d["metadata_sha256"]]
        return {"media": rows, "metadata_documents": docs,
                "persistence": "Copies exist only while their maintainer keeps them. An IPFS CID names content; it does not guarantee anyone hosts it. Availability is checked, not promised."}

    @serialised
    def permissions(self):
        s = self.synced()
        cols = []
        for r in self._rows("SELECT collection_id FROM collections_cache WHERE network_key = ?", s.key):
            c = try_get(f"{s.api}/v1/nft/collections/{r['collection_id']}")
            if c:
                c["authority_log"] = (try_get(f"{s.api}/v1/nft/collections/{r['collection_id']}/authority-log") or {}).get("authority_changes", [])
                cols.append(c)
        h = s.ix.tip() + 1
        ops = self._rows("SELECT * FROM operator_cache WHERE network_key = ?", s.key)
        for o in ops:
            o["active"] = o["expiry_height"] == 0 or h <= o["expiry_height"]
            o["risk"] = "high — no expiry, collection-wide" if o["expiry_height"] == 0 else "elevated — collection-wide until expiry"
        toks = self._rows("SELECT collection_id, token_id, owner, approved, approval_expiry FROM ownership_cache WHERE network_key = ? AND approved IS NOT NULL", s.key)
        return {"collections": cols, "operator_approvals": ops, "token_approvals": toks,
                "roles_note": "creator, owner, approved operator, metadata administrator and rights holder are distinct roles"}

    @serialised
    def listings(self):
        s = self.synced()
        h = s.ix.tip() + 1
        ls = self._rows("SELECT * FROM listings_cache WHERE network_key = ? ORDER BY created_height DESC", s.key)
        for l in ls:
            if l["status"] == "active" and h > l["expiry_height"]:
                l["status"] = "expired"
        return {"module": s.network().get("modules", {}).get("collections"), "listings": ls,
                "sales": self._rows("SELECT * FROM sales_cache WHERE network_key = ? ORDER BY height DESC", s.key),
                "settlement": "ListingBuy settles payment, royalty, platform fee and the NFT in one state transition; any failed check reverts all of it",
                "royalties": "enforced only by this native marketplace; direct transfers or other marketplaces can ignore creator royalty preferences"}

    @serialised
    def provenance(self, cid, tid):
        return self.synced().provenance(cid, tid)

    @serialised
    def wizard_preview(self, answers: dict) -> dict:
        """Pure computation: the action and powers a wizard submission would create."""
        s = self.s()
        try:
            a = s.collection_action(answers)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        warnings = []
        if a.get("forced_transfer"):
            warnings.append("forced transfer lets the admin move any holder's token")
        if a.get("mint_authority") and not a.get("max_supply"):
            warnings.append("uncapped supply with a mint authority")
        if a["metadata_policy"] == "mutable":
            warnings.append("metadata can change forever (revisions are recorded); consider 'freezable'")
        return {"ok": True, "action": a, "administrative_powers": powers_preview(a), "warnings": warnings,
                "next": "sign with: chainworks nft collection-create --from <label> --answers answers.json (keys never enter the console)"}
