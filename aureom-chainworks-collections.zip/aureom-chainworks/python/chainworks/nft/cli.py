"""`chainworks nft …` — AUREOM COLLECTIONS command group."""
from __future__ import annotations

import json
import pathlib

import click

from ..util import ChainworksError, read_json


def out(v):
    click.echo(json.dumps(v, indent=2, default=str))


def svc(d, node=None):
    from .service import Collections
    return Collections(d, node)


@click.group(help="AUREOM COLLECTIONS: NFT collections, minting, media, transfers, approvals, listings, index, provenance.")
def nft():
    pass


D = click.option("--dir", "d", default="./network", show_default=True)
NODE = click.option("--node", default=None, help="node whose public API to use")


@nft.command("db-migrate", help="Create or migrate the collections database.")
@D
def db_migrate(d):
    from .db import connect, migrate
    from .service import collection_dir
    out(migrate(connect(collection_dir(d) / "collections.db")))


@nft.command("media-add", help="Validate a media file (type from content, checksums, alt text) and store it.")
@D
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--alt", "alt_text", help="accessibility description (required for images/video)")
@click.option("--transcript")
@click.option("--licence")
@click.option("--ipfs", is_flag=True, help="also add + pin on the configured IPFS node (http://127.0.0.1:5001)")
def media_add(d, file, alt_text, transcript, licence, ipfs):
    p = pathlib.Path(file)
    out(svc(d).add_media(p.read_bytes(), p.name, alt_text, transcript, licence, ipfs))


@nft.command("metadata-put", help="Validate a metadata document JSON, store its canonical bytes and print {uri, sha256}.")
@D
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
def metadata_put(d, file):
    out(svc(d).put_metadata(read_json(file)))


@nft.command("collection-create", help="Wizard answers JSON -> review administrative powers -> simulate -> sign -> submit.")
@D
@NODE
@click.option("--from", "creator", required=True)
@click.option("--answers", required=True, type=click.Path(exists=True))
@click.option("--yes", is_flag=True, help="skip the confirmation prompt after the review")
def collection_create(d, node, creator, answers, yes):
    s = svc(d, node)
    r = s.create_collection(creator, read_json(answers))
    click.echo("ADMINISTRATIVE POWERS (review before signing):", err=True)
    for p in r["administrative_powers"]:
        click.echo(f"  - {p['power']}: {p['holder']}  [{p['limit']}]  risk={p['risk']}", err=True)
    for w in json.loads(r["request"]["review_json"])["review"]["warnings"]:
        click.echo(f"  ! {w}", err=True)
    if r["request"]["status"] == "rejected":
        out(r)
        raise ChainworksError("simulation failed; nothing was signed")
    if not yes and not click.confirm("Sign and submit?", err=True):
        out(r)
        return
    r["request"] = s.requests.run(r["request"]["request_id"], s.ix)
    out(r)


@nft.command("mint", help="Mint one token (idempotent by --key, default mint:<collection>:<token_id>).")
@D
@NODE
@click.option("--collection", required=True)
@click.option("--token-id", required=True, type=int)
@click.option("--to", required=True)
@click.option("--metadata-sha256", required=True)
@click.option("--key")
def mint(d, node, collection, token_id, to, metadata_sha256, key):
    s = svc(d, node)
    r = s.mint(collection, token_id, to, {"uri": f"{s.public_base()}/{metadata_sha256}", "sha256": metadata_sha256}, key)
    out(s.requests.run(r["request_id"], s.ix))


@nft.command("batch-plan", help="Reviewed batch minting: rows JSON [{token_id,to,metadata_sha256}] -> plan with problems.")
@D
@NODE
@click.option("--collection", required=True)
@click.option("--rows", required=True, type=click.Path(exists=True))
@click.option("--name", default="batch")
def batch_plan(d, node, collection, rows, name):
    out(svc(d, node).batch_plan(collection, read_json(rows), name))


@nft.command("batch-run", help="Sign and submit an approved plan; safe to re-run (resumes, never double-mints).")
@D
@NODE
@click.argument("plan_id")
@click.option("--approve", required=True, help="repeat the plan id to confirm you reviewed it")
def batch_run(d, node, plan_id, approve):
    out(svc(d, node).batch_run(plan_id, approve))


def _send(d, node, sender, kind, action, key, collection=None, tokens=()):
    s = svc(d, node)
    r = s.requests.create(kind, sender, action, key, collection, tokens)
    out(s.requests.run(r["request_id"], s.ix))


@nft.command("transfer")
@D
@NODE
@click.option("--from", "sender", required=True)
@click.option("--collection", required=True)
@click.option("--token-id", required=True)
@click.option("--to", required=True)
@click.option("--key", required=True, help="idempotency key, e.g. a support-ticket or order id")
def transfer(d, node, sender, collection, token_id, to, key):
    _send(d, node, sender, "transfer", {"type": "nft_transfer", "collection": collection, "token_id": token_id, "to": to}, key, collection, [token_id])


@nft.command("approve", help="Single-token approval (narrowest scope). --revoke removes it.")
@D
@NODE
@click.option("--from", "sender", required=True)
@click.option("--collection", required=True)
@click.option("--token-id", required=True)
@click.option("--operator")
@click.option("--expiry-height", type=int, default=0)
@click.option("--revoke", is_flag=True)
@click.option("--key", required=True)
def approve(d, node, sender, collection, token_id, operator, expiry_height, revoke, key):
    a = {"type": "nft_approve", "collection": collection, "token_id": token_id, "approved": None if revoke else operator, "expiry_height": 0 if revoke else expiry_height}
    _send(d, node, sender, "approve", a, key, collection, [token_id])


@nft.command("operator", help="Collection-wide operator approval (HIGH RISK: all your tokens in the collection).")
@D
@NODE
@click.option("--from", "sender", required=True)
@click.option("--collection", required=True)
@click.option("--operator", required=True)
@click.option("--expiry-height", type=int, default=0)
@click.option("--revoke", is_flag=True)
@click.option("--key", required=True)
@click.option("--i-understand-collection-wide-risk", "ack", is_flag=True)
def operator(d, node, sender, collection, operator, expiry_height, revoke, key, ack):
    if not revoke and not ack:
        raise ChainworksError("an operator can move ALL of your tokens in this collection; prefer `nft approve` (one token) or a listing. Re-run with --i-understand-collection-wide-risk")
    _send(d, node, sender, "operator", {"type": "nft_set_operator", "collection": collection, "operator": operator, "approved": not revoke, "expiry_height": 0 if revoke else expiry_height}, key, collection)


@nft.command("freeze-preview", help="Show exactly which metadata and content references a freeze makes permanent.")
@D
@NODE
@click.option("--collection", required=True)
@click.option("--token-id")
def freeze_preview(d, node, collection, token_id):
    out(svc(d, node).freeze_preview(collection, token_id))


@nft.command("owner", help="Authoritative owner (chain) with the index view for comparison.")
@D
@NODE
@click.option("--collection", required=True)
@click.option("--token-id", required=True)
def owner(d, node, collection, token_id):
    out(svc(d, node).owner_of(collection, token_id))


@nft.group("index", help="Chain index (a rebuildable cache).")
def index():
    pass


@index.command("sync")
@D
@NODE
def index_sync(d, node):
    out(svc(d, node).ix.sync())


@index.command("rebuild", help="Drop all chain-derived rows and re-index from chain events.")
@D
@NODE
def index_rebuild(d, node):
    out(svc(d, node).ix.rebuild())


@index.command("verify", help="Compare the index with authoritative chain state.")
@D
@NODE
def index_verify(d, node):
    s = svc(d, node)
    s.ix.sync()
    out(s.ix.verify_against_chain())


@nft.command("storage-check", help="Re-fetch every stored copy and compare SHA-256; record results.")
@D
def storage_check(d):
    out(svc(d).storage_check())


@nft.command("provenance", help="Export provenance for one token (JSON, or CSV of events).")
@D
@NODE
@click.option("--collection", required=True)
@click.option("--token-id", required=True)
@click.option("--csv", "as_csv", is_flag=True)
@click.option("--out", "o", type=click.Path())
def provenance(d, node, collection, token_id, as_csv, o):
    s = svc(d, node)
    p = s.provenance(collection, token_id)
    body = s.provenance_csv(p) if as_csv else json.dumps(p, indent=2)
    if o:
        pathlib.Path(o).write_text(body)
        out({"written": o, "export_sha256": p["export_sha256"]})
    else:
        click.echo(body)


@nft.command("gate-challenge", help="Issue a single-use token-gated access challenge.")
@D
@NODE
@click.option("--address", required=True)
@click.option("--collection", required=True)
@click.option("--token-id")
@click.option("--audience", required=True)
def gate_challenge(d, node, address, collection, token_id, audience):
    out(svc(d, node).gate().issue(address, collection, audience, token_id))


@nft.command("gate-verify")
@D
@NODE
@click.option("--nonce", required=True)
@click.option("--pubkey", required=True)
@click.option("--signature", required=True)
def gate_verify(d, node, nonce, pubkey, signature):
    out(svc(d, node).gate().verify(nonce, pubkey, signature))


@nft.command("claim-submit", help="Record an issuer claim with evidence hashes (off-chain; needs review).")
@D
@click.option("--collection", required=True)
@click.option("--type", "claim_type", required=True)
@click.option("--statement", required=True)
@click.option("--claimant", required=True)
@click.option("--evidence", required=True, type=click.Path(exists=True), help='JSON [{"description","sha256","held_by"}]')
@click.option("--token-id")
def claim_submit(d, collection, claim_type, statement, claimant, evidence, token_id):
    out(svc(d).claims().submit(collection, claim_type, statement, claimant, read_json(evidence), token_id))


@nft.command("claim-review")
@D
@click.argument("claim_id")
@click.option("--reviewer", required=True)
@click.option("--decision", type=click.Choice(["under_review", "accepted", "rejected"]), required=True)
@click.option("--notes", required=True)
def claim_review(d, claim_id, reviewer, decision, notes):
    out(svc(d).claims().review(claim_id, reviewer, decision, notes))


@nft.command("request", help="Show a module request with its full status history; --reconcile queries the chain.")
@D
@NODE
@click.argument("request_id")
@click.option("--reconcile", is_flag=True)
def request(d, node, request_id, reconcile):
    s = svc(d, node)
    r = s.requests.reconcile(request_id) if reconcile else s.requests.get(request_id)
    r["history"] = s.requests.history(request_id)
    out(r)
