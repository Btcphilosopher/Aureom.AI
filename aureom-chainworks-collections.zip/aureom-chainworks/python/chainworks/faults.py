"""Fault injection helpers: an untrusted PoW peer that completes the authenticated
handshake and then sends malformed / invalid blocks, and process-level faults."""
from __future__ import annotations

import os
import signal
import socket
import struct
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from . import protocol as P


def _frame(b: bytes) -> bytes:
    return struct.pack(">I", len(b)) + b


def _read_frame(s: socket.socket, max_len=1 << 22) -> bytes:
    hdr = _recv(s, 4)
    n = struct.unpack(">I", hdr)[0]
    if n > max_len:
        raise ValueError("frame too large")
    return _recv(s, n)


def _recv(s, n):
    b = b""
    while len(b) < n:
        c = s.recv(n - len(b))
        if not c:
            raise ConnectionError("closed")
        b += c
    return b


class RawPeer:
    """Minimal implementation of the PoW p2p handshake (docs/PROTOCOL.md, p2p.rs)."""

    def __init__(self, host, port, chain_id: str, genesis_hash: bytes):
        self.sk = Ed25519PrivateKey.generate()
        self.pk = self.sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.chain_id, self.genesis = chain_id, genesis_hash
        self.s = socket.create_connection((host, port), timeout=5)

    def handshake(self):
        ch = os.urandom(32)
        hello = P.W().u8(0).u16(1).u16(1).string(self.chain_id).fixed(self.genesis).fixed(self.pk).fixed(ch).u64(0).fixed(b"\0" * 32).u16(0).string("fault-injector")
        self.s.sendall(_frame(bytes(hello.b)))
        theirs = _read_frame(self.s)
        r = P.R(theirs)
        assert r.u8() == 0
        r.u16(), r.u16()
        r.bytes_(64)
        r.take(32)
        their_pk = r.take(32)
        their_ch = r.take(32)
        d = b"AUREOM/P2P-HANDSHAKE/v1"
        msg = bytes([len(d)]) + d + bytes(P.W().string(self.chain_id).b) + self.genesis + their_ch + self.pk + their_pk
        self.s.sendall(_frame(bytes(P.W().u8(1).fixed(self.sk.sign(msg)).b)))
        ack = _read_frame(self.s)
        assert ack[0] == 1, "expected hello_ack"
        return their_pk.hex()

    def send_block_bytes(self, block: bytes):
        self.s.sendall(_frame(bytes(P.W().u8(5).bytes_(block).b)))

    def send_raw_frame(self, payload: bytes):
        self.s.sendall(_frame(payload))

    def closed_by_peer(self, timeout=5.0) -> str:
        """Read until the peer disconnects; returns the disconnect reason if sent."""
        self.s.settimeout(timeout)
        try:
            while True:
                f = _read_frame(self.s)
                if f and f[0] == 11:
                    return P.R(f[1:]).bytes_(256).decode()
        except (ConnectionError, socket.timeout, OSError) as e:
            return f"connection closed ({type(e).__name__})"


def pow_header(chain_id, height, prev_id: bytes, ts, miner: bytes, target: bytes, nonce: int, state_root=b"\x00" * 32) -> bytes:
    empty = P.H("AUREOM/EMPTY/v1", b"")
    return bytes(P.W().u16(1).string(chain_id).u64(height).fixed(prev_id).u64(ts).fixed(empty).fixed(empty).fixed(state_root)
                 .fixed(miner).fixed(target).u64(nonce).b)


def pow_hash(header: bytes) -> bytes:
    import hashlib
    return hashlib.sha256(P.H("AUREOM/POW/v1", header)).digest()


def mine_header(chain_id, height, prev_id, ts, miner, target: bytes, max_iter=5_000_000):
    t = int.from_bytes(target, "big")
    for n in range(max_iter):
        h = pow_header(chain_id, height, prev_id, ts, miner, target, n)
        if int.from_bytes(pow_hash(h), "big") <= t:
            return h
    raise RuntimeError("not found")


def block_bytes(header: bytes) -> bytes:
    return header + struct.pack(">I", 0)


def pause(pid: int, seconds: float):
    """SIGSTOP a process group (its messages are delayed until SIGCONT)."""
    os.killpg(pid, signal.SIGSTOP)
    time.sleep(seconds)
    os.killpg(pid, signal.SIGCONT)
