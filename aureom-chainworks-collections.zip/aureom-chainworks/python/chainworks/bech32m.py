"""Bech32m (BIP-350) reference codec for 20-byte payloads. This is an encoding (a
checksummed base-32 alphabet), not a cryptographic primitive; it follows the BIP-350
reference implementation."""

CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
BECH32M_CONST = 0x2BC830A3


def _polymod(values):
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ v
        for i in range(5):
            chk ^= gen[i] if ((b >> i) & 1) else 0
    return chk


def _hrp_expand(hrp):
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]


def _convertbits(data, frombits, tobits, pad=True):
    acc, bits, ret, maxv = 0, 0, [], (1 << tobits) - 1
    for v in data:
        acc = (acc << frombits) | v
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        raise ValueError("invalid padding")
    return ret


def encode(hrp: str, data: bytes) -> str:
    d = _convertbits(data, 8, 5)
    poly = _polymod(_hrp_expand(hrp) + d + [0] * 6) ^ BECH32M_CONST
    chk = [(poly >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(CHARSET[x] for x in d + chk)


def decode(expected_hrp: str, s: str) -> bytes:
    if s.lower() != s:
        raise ValueError("address must be lowercase")
    pos = s.rfind("1")
    if pos < 1 or pos + 7 > len(s):
        raise ValueError("invalid bech32m string")
    hrp, data = s[:pos], s[pos + 1:]
    if hrp != expected_hrp:
        raise ValueError(f"wrong prefix: expected {expected_hrp}, got {hrp}")
    try:
        vals = [CHARSET.index(c) for c in data]
    except ValueError:
        raise ValueError("invalid character")
    if _polymod(_hrp_expand(hrp) + vals) != BECH32M_CONST:
        raise ValueError("bad checksum (or not bech32m)")
    out = bytes(_convertbits(vals[:-6], 5, 8, False))
    if len(out) != 20:
        raise ValueError("expected 20-byte payload")
    return out


def is_valid(hrp: str, s: str) -> bool:
    try:
        decode(hrp, s)
        return True
    except ValueError:
        return False
