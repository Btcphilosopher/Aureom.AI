"""Network specification (launch-wizard answers), defaults per profile, independent
Python validation and supply preview.

The spec (network.json) is human-edited input. The genesis document is *derived* from
it by `chainworks genesis build`, hashed, and from then on consensus-critical: changing
network.json afterwards does not change a running network (nodes pin the genesis hash).
"""
from __future__ import annotations

import json
import pathlib

import jsonschema

from .util import ROOT, ChainworksError

PROFILES = ("pow", "pos", "poa")
DEC = 6
U = 10**DEC  # one coin in base units for the defaults


def default_spec(profile: str, name: str | None = None, chain_id: str | None = None, nodes: int | None = None,
                 base_port: int | None = None, target: str = "local") -> dict:
    if profile not in PROFILES:
        raise ChainworksError(f"profile must be one of {PROFILES}")
    n = nodes or (3 if profile == "pow" else 4)
    base = base_port or {"pow": 18100, "pos": 18200, "poa": 18300}[profile]
    accounts = [
        {"label": "alice", "role": "account", "allocation": str(1_000_000 * U)},
        {"label": "bob", "role": "account", "allocation": str(500_000 * U)},
        {"label": "carol", "role": "account", "allocation": str(1_000 * U)},
        {"label": "dave", "role": "account", "allocation": str(1_000 * U)},
        {"label": "team", "role": "account", "allocation": str(100_000 * U),
         "vesting": {"start_height": 0, "cliff_height": 20, "end_height": 120}},
        {"label": "issuer", "role": "account", "allocation": str(10_000 * U)},
        {"label": "t1", "role": "treasury-signer", "allocation": str(100 * U)},
        {"label": "t2", "role": "treasury-signer", "allocation": str(100 * U)},
        {"label": "t3", "role": "treasury-signer", "allocation": str(100 * U)},
    ]
    if profile != "pow":
        accounts += [{"label": f"op{i}", "role": "operator", "allocation": str(1_000 * U)} for i in range(n)]
    else:
        accounts += [{"label": f"miner{i}", "role": "account", "allocation": None} for i in range(n)]
    consensus: dict = {"profile": profile}
    if profile == "pow":
        consensus["pow"] = {
            "initial_target": "000fffff" + "f" * 56,
            "pow_limit": "00ffffff" + "f" * 56,
            "target_block_time_ms": 2000, "retarget_interval": 20, "max_future_drift_ms": 15000,
            "coinbase_maturity": 10, "confirmations_recommended": 6,
        }
        monetary = {"kind": "scheduled", "max_supply": str(21_000_000 * U),
                    "scheduled": {"initial_block_reward": str(50 * U), "halving_interval_blocks": 100_000}}
    elif profile == "pos":
        consensus["pos"] = {
            "epoch_length": 20, "unbonding_period_blocks": 200, "min_self_bond": str(1_000 * U), "max_validators": 10,
            "power_unit": str(U), "slash_double_sign_bps": 500, "slash_downtime_bps": 100, "downtime_window": 50,
            "downtime_max_missed": 25, "jail_duration_blocks": 50, "evidence_max_age_blocks": 100,
        }
        monetary = {"kind": "scheduled", "max_supply": str(100_000_000 * U),
                    "scheduled": {"initial_block_reward": str(5 * U), "halving_interval_blocks": 1_000_000}}
    else:
        consensus["poa"] = {"evidence_max_age_blocks": 1000}
        monetary = {"kind": "fixed"}
    nodes_l = []
    for i in range(n):
        d = {"name": f"node{i}", "api_port": base + i * 10, "admin_port": base + i * 10 + 1, "p2p_port": base + i * 10 + 2}
        if profile == "pow":
            d.update({"miner": True, "miner_account": f"miner{i}", "max_hashes_per_sec": 300_000})
        else:
            d.update({"validator": True, "operator": f"op{i}", "abci_port": base + i * 10 + 3, "rpc_port": base + i * 10 + 4,
                      "self_bond": str(10_000 * U) if profile == "pos" else None, "power": 10 if profile == "poa" else None})
        nodes_l.append(d)
    return {
        "spec_format": 1,
        "network_name": name or f"Aureom Development Network ({profile.upper()})",
        "chain_id": chain_id or f"aureom-dev-{profile}-1",
        "profile": profile,
        "target": target,
        "genesis_time_ms": None,
        "native_asset": {"name": "Aureom Development Coin", "ticker": "ADC", "decimals": DEC, "address_hrp": "aurd"},
        "monetary_policy": monetary,
        "fee_policy": {"base_fee": "1000", "per_byte_fee": "10", "burn_bps": 2000, "recipient": "proposer"},
        "limits": {"max_block_bytes": 1_000_000, "max_block_txs": 2000, "max_tx_bytes": 16384, "max_memo_bytes": 256},
        "consensus": consensus,
        "accounts": accounts,
        "treasuries": [{"label": "treasury", "signers": ["t1", "t2", "t3"], "threshold": 2, "amount": str(200_000 * U)}],
        "governance": {"approval_threshold_num": 2, "approval_threshold_den": 3, "proposal_max_ttl_blocks": 1000},
        "upgrades": [],
        "nodes": nodes_l,
        "admin": {"admin_listen_host": "127.0.0.1"},
        "dev": {"store_dev_passphrases": True, "fast_kdf": True,
                "note": "development convenience only: passphrases are stored beside keystores; never use for real value"},
    }


def schema() -> dict:
    return json.loads((ROOT / "schemas" / "genesis.schema.json").read_text())


def validate_genesis_py(g: dict) -> dict:
    """Independent Python validation (schema + economics). Rust validates again."""
    errors, warnings = [], []
    try:
        jsonschema.validate(g, schema())
    except jsonschema.ValidationError as e:
        errors.append(f"schema: {e.message} at {'/'.join(map(str, e.absolute_path))}")
        return {"ok": False, "errors": errors, "warnings": warnings}
    from . import bech32m
    hrp = g["native_asset"]["address_hrp"]
    seen, total = set(), 0
    for i, a in enumerate(g["allocations"]):
        try:
            ab = bech32m.decode(hrp, a["address"])
            if ab in seen:
                errors.append(f"allocations[{i}]: duplicate recipient")
            seen.add(ab)
        except ValueError as e:
            errors.append(f"allocations[{i}]: {e}")
        total += int(a["amount"])
        v = a.get("vesting")
        if v and not (v["start_height"] <= v["cliff_height"] <= v["end_height"] and v["start_height"] < v["end_height"]):
            errors.append(f"allocations[{i}]: bad vesting heights")
    for t in g.get("treasuries", []):
        total += int(t["amount"])
        if not 1 <= t["threshold"] <= len(t["signers"]):
            errors.append(f"treasury {t['label']}: threshold out of range")
    for v in g.get("validators", []):
        total += int(v.get("self_bond", "0"))
    if total >= 2**128:
        errors.append("allocation total overflows u128")
    ms = g["monetary_policy"].get("max_supply")
    if ms is not None and total > int(ms):
        errors.append(f"genesis supply {total} exceeds max_supply {ms}")
    n = len(g.get("validators", []))
    if g["consensus"]["profile"] != "pow":
        f = (n - 1) // 3
        warnings.append(f"{n} validators: tolerates up to {f} Byzantine (n >= 3f+1); liveness lost if more than {n - (2 * n // 3 + 1)} of equal power are offline")
    return {"ok": not errors, "errors": errors, "warnings": warnings, "genesis_supply": str(total)}


def supply_preview(g: dict, heights=(0, 100, 1000, 10_000, 100_000, 1_000_000)) -> dict:
    """Projected supply under stated assumptions: every block pays the full scheduled
    reward; no burns, slashing or authority mints (those only reduce/raise it)."""
    genesis = sum(int(a["amount"]) for a in g["allocations"]) + sum(int(t["amount"]) for t in g.get("treasuries", [])) \
        + sum(int(v.get("self_bond", "0")) for v in g.get("validators", []))
    mp = g["monetary_policy"]
    cap = int(mp["max_supply"]) if mp.get("max_supply") else None
    rows = []
    for h in heights:
        minted = 0
        if mp["kind"] == "scheduled":
            r0, hi = int(mp["scheduled"]["initial_block_reward"]), mp["scheduled"]["halving_interval_blocks"]
            # sum over blocks 1..h of r0 >> (b // hi)
            b = 1
            while b <= h:
                k = b // hi
                if k >= 128:
                    break
                end = min(h, (k + 1) * hi - 1)
                minted += (end - b + 1) * (r0 >> k)
                b = end + 1
        tot = genesis + minted
        if cap is not None:
            tot = min(tot, cap)
        vest_locked = 0
        for a in g["allocations"]:
            v = a.get("vesting")
            if v:
                amt = int(a["amount"])
                if h < v["cliff_height"]:
                    vested = 0
                elif h >= v["end_height"]:
                    vested = amt
                else:
                    vested = amt * (h - v["start_height"]) // (v["end_height"] - v["start_height"])
                vest_locked += amt - vested
        rows.append({"height": h, "total_supply": str(tot), "vesting_locked": str(vest_locked)})
    return {"genesis_supply": str(genesis), "max_supply": mp.get("max_supply"), "policy": mp["kind"], "rows": rows,
            "assumptions": "every block pays the scheduled reward; burns, slashing and authority mints are excluded; heights are not dates"}
