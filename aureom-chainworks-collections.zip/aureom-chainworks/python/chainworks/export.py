"""Deployment package and asset information package exports. Private keys, keystores,
passphrases, admin tokens, CometBFT node/validator keys and databases are excluded by
construction, and the result is scanned for secret markers before it is accepted."""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import shutil
import time

from .network import Network
from .util import ROOT, ChainworksError, read_json, try_get, write_json

SECRET_MARKERS = [re.compile(p) for p in (r'"seed"\s*:', r'"priv_key"\s*:', r'"ciphertext"\s*:', r"PRIVATE KEY", r'"passphrase"\s*:')]
DOCS = ["PROTOCOL.md", "API.md", "THREAT-MODEL.md", "SECURITY-LIMITATIONS.md", "OPERATIONS.md", "GOVERNANCE.md", "ASSETS.md", "CONSENSUS.md", "MIGRATION.md"]


def source_version() -> dict:
    h = hashlib.sha256()
    n = 0
    for base in ("rust/crates", "python/chainworks"):
        for f in sorted((ROOT / base).rglob("*")):
            if f.is_file() and f.suffix in (".rs", ".py", ".toml") and "target" not in f.parts and "__pycache__" not in f.parts:
                h.update(str(f.relative_to(ROOT)).encode() + b"\0" + f.read_bytes())
                n += 1
    return {"source_tree_sha256": h.hexdigest(), "files": n, "software_version": "0.1.0"}


def _scan(out: pathlib.Path):
    bad = []
    for f in out.rglob("*"):
        if f.is_file() and f.stat().st_size < 5_000_000:
            t = f.read_text(errors="ignore")
            for m in SECRET_MARKERS:
                if m.search(t):
                    bad.append(f"{f.relative_to(out)}: {m.pattern}")
    return bad


def _checksums(out: pathlib.Path):
    lines = []
    for f in sorted(out.rglob("*")):
        if f.is_file() and f.name != "CHECKSUMS.sha256":
            lines.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(out)}")
    (out / "CHECKSUMS.sha256").write_text("\n".join(lines) + "\n")
    return len(lines)


def deployment_package(net: Network, out) -> dict:
    out = pathlib.Path(out)
    if out.exists():
        shutil.rmtree(out)
    (out / "nodes").mkdir(parents=True)
    shutil.copy2(net.genesis_path, out / "genesis.json")
    shutil.copy2(net.dir / "genesis.hash", out / "genesis.hash")
    s = net.spec
    public_spec = {k: v for k, v in s.items() if k not in ("dev",)}
    write_json(out / "network.json", public_spec)
    for n in net.nodes():
        nd = out / "nodes" / n["name"]
        nd.mkdir(parents=True)
        cfg = read_json(net.node_dir(n["name"]) / "node.json")
        cfg["admin_token_path"] = "<provision locally: secrets/nodes/%s/admin.token (0600)>" % n["name"]
        if "pow" in cfg:
            cfg["pow"]["node_key_path"] = "<provision locally: secrets/nodes/%s/node_key.json (0600)>" % n["name"]
        write_json(nd / "node.json", cfg)
        pub = net.dir / "public" / "nodes" / f"{n['name']}.json"
        if pub.exists():
            shutil.copy2(pub, nd / "public-identity.json")
        if net.profile != "pow":
            (nd / "cometbft" / "config").mkdir(parents=True)
            for fname in ("config.toml", "genesis.json"):
                shutil.copy2(net.node_dir(n["name"]) / "cometbft" / "config" / fname, nd / "cometbft" / "config" / fname)
    from . import compose
    compose.write(net, out)
    _monitoring(net, out / "monitoring")
    (out / "docs").mkdir()
    for d in DOCS:
        p = ROOT / "docs" / d
        if p.exists():
            shutil.copy2(p, out / "docs" / d)
    shutil.copy2(ROOT / "schemas" / "genesis.schema.json", out / "genesis.schema.json")
    (out / "DEPLOY.md").write_text(_deploy_md(net))
    write_json(out / "source-version.json", source_version())
    bad = _scan(out)
    if bad:
        shutil.rmtree(out)
        raise ChainworksError(f"export aborted: secret markers found {bad}")
    n = _checksums(out)
    return {"package": str(out), "files": n, "secret_scan": "clean",
            "excluded": ["secrets/ (keystores, passphrases, admin tokens, node keys)", "nodes/*/cometbft/config/priv_validator_key.json",
                         "nodes/*/cometbft/config/node_key.json", "nodes/*/data", "nodes/*/cometbft/data"]}


def _monitoring(net: Network, d: pathlib.Path):
    d.mkdir(parents=True)
    targets = [f"{net.host(n['name']) if net.spec.get('target') == 'docker' else '127.0.0.1'}:{n['api_port']}" for n in net.nodes()]
    (d / "prometheus.yml").write_text("global:\n  scrape_interval: 10s\nrule_files: [alerts.yml]\nscrape_configs:\n  - job_name: aureom\n    metrics_path: /metrics\n    static_configs:\n      - targets: [" + ", ".join(f"'{t}'" for t in targets) + "]\n")
    (d / "alerts.yml").write_text("""groups:
  - name: aureom
    rules:
      - alert: AureomNoPeers
        expr: aureom_peers == 0
        for: 2m
      - alert: AureomHeightStalled
        expr: increase(aureom_height[5m]) == 0
        for: 5m
      - alert: AureomHeightDivergence
        expr: max(aureom_height) - min(aureom_height) > 10
        for: 5m
      - alert: AureomBftParticipationLow
        expr: aureom_bft_last_commit_signed_power / aureom_bft_last_commit_total_power < 0.8
        for: 2m
""")


def _deploy_md(net: Network) -> str:
    s = net.spec
    return f"""# Deployment instructions — {s['network_name']}

* chain id: `{s['chain_id']}`  · profile: `{s['profile']}`  · genesis hash: `{net.genesis_hash}`
* This is a **development network package**. It is not production-secure; see docs/SECURITY-LIMITATIONS.md.

1. Verify the package: `sha256sum -c CHECKSUMS.sha256`. Verify `genesis.hash` equals the hash
   published by the network coordinator through a separate channel.
2. Provision secrets **locally** on each host (never from this package): admin token (0600),
   PoW node key, or CometBFT `priv_validator_key.json` / `node_key.json` for BFT validators.
   Each validator key must be active on exactly one machine.
3. Install `aureom-node` (and `cometbft` 0.38.x for PoS/PoA) built from the source version in
   `source-version.json`.
4. Start nodes: `docker compose up -d` (see docker-compose.yml) or
   `aureom-node run --config nodes/<name>/node.json` (+ `cometbft start --home nodes/<name>/cometbft`).
5. Check: `curl http://127.0.0.1:<api_port>/v1/network` — compare `genesis_hash` and `chain_id`.
6. Monitoring: `monitoring/prometheus.yml`, `monitoring/alerts.yml`.
7. Backups and recovery: docs/OPERATIONS.md.
"""


def asset_package(net: Network, out, node=None) -> dict:
    out = pathlib.Path(out)
    out.mkdir(parents=True, exist_ok=True)
    node = node or net.nodes()[0]["name"]
    api = net.api(node)
    g = read_json(net.genesis_path)
    netinfo = try_get(api + "/v1/network") or {}
    tokens = (try_get(api + "/v1/tokens") or {}).get("tokens", [])
    supply = try_get(api + "/v1/supply") or {}
    mp = g["monetary_policy"]
    admin_powers = {
        "native_coin": {"policy": mp["kind"], "mint_authority": (mp.get("authority") or {}).get("mint_authority"),
                        "statement": {"fixed": "no account can mint the native coin", "scheduled": "new coins are issued only by protocol rules per block",
                                      "authority": "the named mint authority can mint up to the per-window limit and max_supply"}[mp["kind"]]},
        "tokens": [{"token_id": t["token_id"], "mint_authority": t["mint_authority"], "admin": t["admin"], "pausable": t["pausable"],
                    "freezable": t["freezable"], "max_supply": t["max_supply"]} for t in tokens],
    }
    pkg = {
        "generated_at": int(time.time()),
        "chain_id": g["chain_id"], "genesis_hash": net.genesis_hash, "profile": g["consensus"]["profile"],
        "native_coin": {**g["native_asset"], "identifier": "native (the chain's built-in asset; ticker is a display label)"},
        "tokens": tokens,
        "supply_policy": mp, "supply_now": supply,
        "administrative_powers": admin_powers,
        "allocation_table": g["allocations"], "treasuries": [{**t, "address": net._treasury_address(i)} for i, t in enumerate(g.get("treasuries", []))],
        "vesting_rules": [{"address": a["address"], "label": a.get("label"), **a["vesting"], "amount": a["amount"]} for a in g["allocations"] if a.get("vesting")]
                         + [{"note": "vesting is measured in block heights; calendar dates are estimates"}],
        "wallet_connection": {"nodes": [{"name": n["name"], "rpc": net.api(n["name"])} for n in net.nodes()], "address_hrp": g["native_asset"]["address_hrp"],
                              "token_hrp": g["native_asset"]["address_hrp"] + "tok", "chain_id": g["chain_id"], "decimals": g["native_asset"]["decimals"],
                              "signature_scheme": "ed25519, domain-separated (PROTOCOL.md 5.2)"},
        "explorer": {"api": [net.api(n["name"]) + "/v1" for n in net.nodes()], "console": "chainworks console <network-dir>"},
        "source_version": source_version(),
        "known_limitations": [
            "development software; not audited; not production-secure",
            "creating an asset does not give it monetary value, reserve backing, exchange listing or legal status",
            "ticker symbols and token symbols are display labels only; identify assets by chain id + token id",
            "PoW settlement is probabilistic; BFT finality holds only while < 1/3 of voting power is Byzantine",
            "issuer-supplied token names, symbols and metadata URIs are not verified by the protocol",
        ],
        "node_reported": {"network": netinfo},
    }
    write_json(out / "asset-information.json", pkg)
    md = [f"# Asset information — {g['network_name']}", "", f"* chain id `{g['chain_id']}`, genesis `{net.genesis_hash}`", "",
          "## Native coin", f"{g['native_asset']['name']} ({g['native_asset']['ticker']}, {g['native_asset']['decimals']} decimals) — policy `{mp['kind']}`",
          "", "## Tokens"]
    for t in tokens:
        md.append(f"* `{t['token_id']}` — issuer-supplied: {t['symbol']} / {t['name']}; supply {t['supply']} (max {t['max_supply']}); "
                  f"mint authority {t['mint_authority']}; admin {t['admin']}; pausable {t['pausable']}; freezable {t['freezable']}")
    md += ["", "## Known limitations"] + [f"* {x}" for x in pkg["known_limitations"]]
    (out / "ASSET-INFORMATION.md").write_text("\n".join(md) + "\n")
    bad = _scan(out)
    if bad:
        raise ChainworksError(f"secret markers in asset package: {bad}")
    _checksums(out)
    return {"package": str(out), "tokens": len(tokens)}
