"""Reviewed batch distributions that resume without paying anyone twice.

Design: every payment is one transaction with a fixed nonce, signed once and written to
a journal *before* anything is submitted. Resuming re-submits the identical signed
bytes (same txid), which is idempotent: if the original was already included, the
duplicate is rejected by nonce/replay rules and cannot pay again. A journal entry is
never re-signed with a different nonce automatically; if its nonce was consumed by an
unrelated transaction, the entry is flagged for manual review instead.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import time

from . import bech32m
from .network import Network
from .util import ChainworksError, cli, read_json, try_get, write_json
from .wallet import Wallet

FINAL = ("included", "confirmed", "finalised")


def _plan_dir(net: Network, name: str) -> pathlib.Path:
    return net.dir / "distributions" / name


def plan(net: Network, name: str, sender: str, asset: str, recipients: list[dict], merge_duplicates=False, node=None) -> dict:
    """recipients: [{"address": "aurd1..." | label, "amount": "<base units>"}]"""
    s = net.spec
    hrp = s["native_asset"]["address_hrp"]
    w = Wallet(net, node)
    problems, rows, seen = [], [], {}
    for i, r in enumerate(recipients):
        a = r["address"]
        if not a.startswith(hrp + "1"):
            try:
                a = net.address(a)
            except FileNotFoundError:
                problems.append(f"row {i}: unknown label or invalid address {r['address']!r}")
                continue
        if not bech32m.is_valid(hrp, a):
            problems.append(f"row {i}: invalid address {a!r}")
            continue
        try:
            amt = int(str(r["amount"]))
            if amt <= 0:
                raise ValueError
        except ValueError:
            problems.append(f"row {i}: amount must be a positive integer of base units, got {r['amount']!r}")
            continue
        if a in seen:
            if merge_duplicates:
                rows[seen[a]]["amount"] += amt
                rows[seen[a]]["merged_rows"].append(i)
                continue
            problems.append(f"row {i}: duplicate recipient {a} (first at row {rows[seen[a]]['rows'][0]}); pass merge_duplicates to combine")
            continue
        seen[a] = len(rows)
        rows.append({"address": a, "amount": amt, "rows": [i], "merged_rows": []})
    sender_addr = net.address(sender)
    acct = w.account(sender)
    if not acct:
        raise ChainworksError("query node unreachable")
    # fees: protocol minimum for each payment (computed by preparing one sample tx)
    sample = rows[0]["address"] if rows else sender_addr
    act = {"type": "transfer", "to": sample, "amount": "1"} if asset == "native" else {"type": "token_transfer", "token": asset, "to": sample, "amount": "1"}
    u = w.prepare(sender, act, nonce=acct["nonce"], memo=f"dist:{name}:{len(recipients)}")
    fee = int(read_json(u)["review"]["fee_base_units"])
    total = sum(r["amount"] for r in rows)
    fees = fee * len(rows)
    native_avail = int(acct["native"]["available"])
    if asset == "native":
        need = total + fees
        bal_before = native_avail
    else:
        tok = next((t for t in acct["tokens"] if t["token_id"] == asset), None)
        bal_before = int(tok["balance"]) if tok else 0
        need = total
        if fees > native_avail:
            problems.append(f"insufficient native balance for fees: need {fees}, available {native_avail}")
    if need > bal_before:
        problems.append(f"insufficient funds: need {need}, available {bal_before}")
    preview = []
    for r in rows:
        ra = w.account(r["address"])
        before = int(ra.get("native", {}).get("total", "0")) if asset == "native" else int(next((t["balance"] for t in ra.get("tokens", []) if t["token_id"] == asset), "0"))
        preview.append({"address": r["address"], "amount": str(r["amount"]), "fee": str(fee), "balance_before": str(before), "balance_after": str(before + r["amount"]),
                        "source_rows": r["rows"] + r["merged_rows"]})
    doc = {"name": name, "sender": sender, "sender_address": sender_addr, "asset": asset, "recipients": preview,
           "totals": {"amount": str(total), "fees": str(fees), "sender_balance_before": str(bal_before),
                      "sender_balance_after": str(bal_before - (total + fees if asset == "native" else total))},
           "problems": problems, "ok": not problems, "created": int(time.time())}
    doc["plan_id"] = hashlib.sha256(json.dumps({k: doc[k] for k in ("sender_address", "asset", "recipients")}, sort_keys=True).encode()).hexdigest()
    d = _plan_dir(net, name)
    d.mkdir(parents=True, exist_ok=True)
    write_json(d / "plan.json", doc)
    return doc


def run(net: Network, name: str, approve_plan_id: str, stop_after: int | None = None, node=None) -> dict:
    """Execute a reviewed plan. `approve_plan_id` must equal the plan id shown in the
    preview (explicit review step). `stop_after` simulates an interruption."""
    d = _plan_dir(net, name)
    p = read_json(d / "plan.json")
    if not p["ok"]:
        raise ChainworksError(f"plan has problems: {p['problems']}")
    if approve_plan_id != p["plan_id"]:
        raise ChainworksError("plan id mismatch: review the current plan and approve its id")
    jpath = d / "journal.json"
    w = Wallet(net, node)
    if jpath.exists():
        j = read_json(jpath)
        if j["plan_id"] != p["plan_id"]:
            raise ChainworksError("journal belongs to a different plan")
    else:
        # sign everything up front with consecutive nonces, then persist before submitting
        start = w.account(p["sender"])["nonce"]
        entries = []
        for i, r in enumerate(p["recipients"]):
            act = {"type": "transfer", "to": r["address"], "amount": r["amount"]} if p["asset"] == "native" else \
                  {"type": "token_transfer", "token": p["asset"], "to": r["address"], "amount": r["amount"]}
            u = w.prepare(p["sender"], act, nonce=start + i, fee="auto", memo=f"dist:{name}:{i}")
            sgn = read_json(w.sign(p["sender"], u))
            entries.append({"i": i, "address": r["address"], "amount": r["amount"], "nonce": start + i, "txid": sgn["txid"], "signed_hex": sgn["signed_hex"], "status": "signed"})
        j = {"plan_id": p["plan_id"], "start_nonce": start, "entries": entries}
        write_json(jpath, j)
    return _submit(net, w, jpath, j, stop_after)


def _submit(net, w: Wallet, jpath, j, stop_after):
    from .util import http
    submitted = 0
    for e in j["entries"]:
        st = try_get(f"{w.api}/v1/transactions/{e['txid']}") or {}
        if st.get("status") in FINAL:
            e["status"] = st["status"]
            continue
        if stop_after is not None and submitted >= stop_after:
            write_json(jpath, j)
            return {"interrupted": True, "submitted_this_run": submitted, "journal": str(jpath)}
        s, resp = http("POST", f"{w.api}/v1/transactions", {"tx": e["signed_hex"]})
        if s == 202:
            e["status"] = "pending"
        elif isinstance(resp, dict) and resp.get("error", {}).get("code") in ("duplicate",):
            e["status"] = "pending"
        elif isinstance(resp, dict) and resp.get("error", {}).get("code") == "bad_nonce":
            # nonce already used: either by this very tx (included) or by something else
            st = try_get(f"{w.api}/v1/transactions/{e['txid']}") or {}
            e["status"] = st.get("status") if st.get("status") in FINAL else "needs_review: nonce consumed by another transaction"
        else:
            e["status"] = f"error: {resp}"
        submitted += 1
        write_json(jpath, j)
    return status_report(jpath, j, w)


def status_report(jpath, j, w: Wallet, wait=60) -> dict:
    end = time.time() + wait
    while time.time() < end:
        pending = False
        for e in j["entries"]:
            if e["status"] in FINAL or e["status"].startswith(("needs_review", "error")):
                continue
            st = try_get(f"{w.api}/v1/transactions/{e['txid']}") or {}
            if st.get("status") in FINAL:
                e["status"] = st["status"]
                e["block_height"] = st.get("block_height")
            else:
                pending = True
        write_json(jpath, j)
        if not pending:
            break
        time.sleep(1)
    counts: dict = {}
    for e in j["entries"]:
        k = e["status"].split(":")[0]
        counts[k] = counts.get(k, 0) + 1
    return {"journal": str(jpath), "counts": counts, "complete": all(e["status"] in FINAL for e in j["entries"])}


def resume(net: Network, name: str, node=None) -> dict:
    d = _plan_dir(net, name)
    j = read_json(d / "journal.json")
    return _submit(net, Wallet(net, node), d / "journal.json", j, None)


def claims_tree(net: Network, name: str, claims: list[dict]) -> dict:
    """Claim-based distribution: Merkle tree of (index, address, amount)."""
    d = _plan_dir(net, name)
    d.mkdir(parents=True, exist_ok=True)
    write_json(d / "claims.json", claims)
    return cli("merkle", "--genesis", net.genesis_path, "--claims", d / "claims.json", "--out", d / "claims-tree.json")
