"""Development-wallet workflows over aureom-cli: prepare -> review -> sign -> submit -> wait.
Keys never pass through Python memory; aureom-cli decrypts keystores itself."""
from __future__ import annotations

import json
import pathlib
import tempfile
import time

from .network import Network
from .util import ChainworksError, cli, http, try_get, wait_for


class Wallet:
    def __init__(self, net: Network, node: str | None = None):
        self.net = net
        self.node = node or net.nodes()[0]["name"]
        self.tmp = pathlib.Path(tempfile.mkdtemp(prefix="cw-tx-", dir=net.dir / "secrets"))

    @property
    def api(self):
        return self.net.api(self.node)

    def account(self, label_or_addr: str) -> dict:
        addr = label_or_addr if label_or_addr.startswith(self.net.spec["native_asset"]["address_hrp"] + "1") else self.net.address(label_or_addr)
        return try_get(f"{self.api}/v1/accounts/{addr}") or {}

    def prepare(self, sender: str, action: dict, nonce: int | str = "auto", fee="auto", expiry: int = 0, memo: str = "") -> pathlib.Path:
        out = self.tmp / f"{sender}-{time.time_ns()}.unsigned.json"
        cli("tx", "prepare", "--genesis", self.net.genesis_path, "--from", self.net.keystore(sender), "--nonce", nonce, "--fee", fee,
            "--expiry-height", expiry, "--memo", memo, "--action", json.dumps(action), "--node", self.api, "--out", out)
        return out

    def review(self, f) -> dict:
        return cli("tx", "review", f, "--genesis", self.net.genesis_path)

    def sign(self, sender: str, unsigned: pathlib.Path) -> pathlib.Path:
        out = unsigned.with_suffix("").with_suffix(".signed.json")
        cli("tx", "sign", "--in", unsigned, "--genesis", self.net.genesis_path, "--keystore", self.net.keystore(sender),
            "--passphrase-file", self.net.passfile(sender), "--out", out)
        return out

    def submit_file(self, signed: pathlib.Path, node: str | None = None) -> tuple[int, dict]:
        doc = json.loads(pathlib.Path(signed).read_text())
        api = self.net.api(node) if node else self.api
        return http("POST", f"{api}/v1/transactions", {"tx": doc["signed_hex"]})

    def send(self, sender: str, action: dict, wait=True, **kw) -> dict:
        u = self.prepare(sender, action, **kw)
        s = self.sign(sender, u)
        doc = json.loads(s.read_text())
        st, resp = self.submit_file(s)
        res = {"txid": doc["txid"], "http_status": st, "response": resp, "signed_hex": doc["signed_hex"]}
        if st != 202:
            res["status"] = "rejected"
            return res
        if wait:
            res.update(self.wait(doc["txid"]))
        return res

    def wait(self, txid: str, timeout=60.0, final=True) -> dict:
        def done():
            v = try_get(f"{self.api}/v1/transactions/{txid}")
            if v and v["status"] in ("included", "confirmed", "finalised", "dropped", "rejected"):
                return v
            return None
        v = wait_for(done, timeout, 0.5, f"tx {txid[:12]}")
        return {"status": v["status"], "block_height": v.get("block_height"), "receipt": v.get("receipt"), "tx_status": v}

    def transfer(self, sender, to, amount: int, **kw):
        to_addr = to if to.startswith(self.net.spec["native_asset"]["address_hrp"] + "1") else self.net.address(to)
        return self.send(sender, {"type": "transfer", "to": to_addr, "amount": str(amount)}, **kw)
