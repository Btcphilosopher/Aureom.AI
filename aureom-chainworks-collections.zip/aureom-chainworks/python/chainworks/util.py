"""Shared helpers: binaries, JSON files, HTTP, secret files, waiting."""
from __future__ import annotations

import json
import os
import pathlib
import secrets as _secrets
import shutil
import subprocess
import time
import urllib.error
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[2]


class ChainworksError(Exception):
    pass


def find_bin(name: str) -> str:
    env = os.environ.get("AUREOM_BIN_DIR")
    cands = []
    if env:
        cands.append(pathlib.Path(env) / name)
    cands += [ROOT / "rust" / "target" / "release" / name, ROOT / "tools" / "bin" / name, ROOT / "bin" / name]
    for c in cands:
        if c.exists():
            return str(c)
    w = shutil.which(name)
    if w:
        return w
    raise ChainworksError(f"binary {name!r} not found (build with `cargo build --release` in rust/, or set AUREOM_BIN_DIR)")


def run_json(args: list[str], env: dict | None = None, check=True) -> dict:
    """Run a tool that prints JSON on stdout."""
    e = dict(os.environ)
    if env:
        e.update(env)
    p = subprocess.run(args, capture_output=True, text=True, env=e)
    if check and p.returncode != 0:
        raise ChainworksError(f"{pathlib.Path(args[0]).name} {' '.join(args[1:3])} failed: {p.stderr.strip()[-2000:]}")
    try:
        return json.loads(p.stdout)
    except json.JSONDecodeError:
        raise ChainworksError(f"unexpected output from {args[0]}: {p.stdout[:500]} {p.stderr[-500:]}")


def cli(*args, env=None, check=True) -> dict:
    return run_json([find_bin("aureom-cli"), *map(str, args)], env=env, check=check)


def read_json(p) -> dict:
    return json.loads(pathlib.Path(p).read_text())


def write_json(p, v) -> None:
    p = pathlib.Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(v, indent=2) + "\n")


def write_secret(p, content: str) -> None:
    p = pathlib.Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(p.parent, 0o700)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(content)


def random_token(n=32) -> str:
    return _secrets.token_hex(n)


def http(method: str, url: str, body=None, headers=None, timeout=5.0):
    """Returns (status, json-or-text). Never raises for HTTP errors; raises on connection failure."""
    data = json.dumps(body).encode() if body is not None else None
    h = {"content-type": "application/json"} if data is not None else {}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            status = r.status
    except urllib.error.HTTPError as e:
        raw, status = e.read(), e.code
    try:
        return status, json.loads(raw)
    except json.JSONDecodeError:
        return status, raw.decode(errors="replace")


def get(url, timeout=5.0):
    s, v = http("GET", url, timeout=timeout)
    if s != 200:
        raise ChainworksError(f"GET {url} -> {s}: {v}")
    return v


def try_get(url, timeout=2.0):
    try:
        s, v = http("GET", url, timeout=timeout)
        return v if s == 200 else None
    except Exception:
        return None


def wait_for(pred, timeout=60.0, interval=0.5, what="condition"):
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            last = pred()
            if last:
                return last
        except Exception as e:  # noqa: BLE001
            last = e
        time.sleep(interval)
    raise ChainworksError(f"timed out after {timeout:.0f}s waiting for {what} (last: {last!r})")


def base_units(amount: str, decimals: int) -> int:
    """'1.5' -> 1500000 for 6 decimals, exact (no floats)."""
    amount = amount.strip()
    if "." in amount:
        w, f = amount.split(".", 1)
        if len(f) > decimals:
            raise ChainworksError(f"{amount} has more than {decimals} decimals")
        return int(w or "0") * 10**decimals + int(f.ljust(decimals, "0") or "0")
    return int(amount) * 10**decimals


def fmt_units(v: int | str, decimals: int, ticker: str = "") -> str:
    v = int(v)
    s = f"{v // 10**decimals}.{v % 10**decimals:0{decimals}d}" if decimals else str(v)
    return f"{s} {ticker}".strip()
