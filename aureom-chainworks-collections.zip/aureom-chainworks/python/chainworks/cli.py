"""chainworks — AUREOM CHAINWORKS command line (automation, deployment, inspection, recovery)."""
from __future__ import annotations

import json
import pathlib
import sys

import click

from . import distribute as dist
from . import export as exp
from . import spec as specmod
from . import treasury as tre
from .network import Network
from .util import ChainworksError, base_units, cli as rcli, get, read_json
from .wallet import Wallet


def out(v):
    click.echo(json.dumps(v, indent=2, default=str))


def main():
    try:
        root(standalone_mode=True)
    except ChainworksError as e:
        click.secho(f"error: {e}", fg="red", err=True)
        sys.exit(2)


@click.group(help="AUREOM CHAINWORKS — blockchain launch & management (development networks; not production-secure).")
def root():
    pass


# ------------------------------------------------------------------ setup
@root.command(help="Create a network directory with a launch-wizard spec for a consensus profile.")
@click.option("--profile", type=click.Choice(specmod.PROFILES), required=True)
@click.option("--dir", "d", default="./network", show_default=True)
@click.option("--name")
@click.option("--chain-id")
@click.option("--nodes", type=int)
@click.option("--base-port", type=int)
@click.option("--target", type=click.Choice(["local", "docker"]), default="local", show_default=True)
@click.option("--interactive", is_flag=True, help="Ask for the main launch-wizard answers.")
@click.option("--collections", is_flag=True, help="Enable the AUREOM COLLECTIONS native NFT module in genesis.")
@click.option("--marketplace-fee-bps", type=int, default=None, help="With --collections: enable the demo marketplace with this platform fee (fee recipient: a new 'platform' account).")
@click.option("--force", is_flag=True)
def init(profile, d, name, chain_id, nodes, base_port, target, interactive, collections, marketplace_fee_bps, force):
    if interactive:
        name = click.prompt("Network name", default=name or f"Aureom Development Network ({profile.upper()})")
        chain_id = click.prompt("Chain identifier", default=chain_id or f"aureom-dev-{profile}-1")
        nodes = click.prompt("Number of nodes", default=nodes or (3 if profile == "pow" else 4), type=int)
    net = Network.init(d, profile, force=force, name=name, chain_id=chain_id, nodes=nodes, base_port=base_port, target=target)
    if interactive:
        s = net.spec
        na = s["native_asset"]
        na["name"] = click.prompt("Native coin name", default=na["name"])
        na["ticker"] = click.prompt("Ticker (display label only)", default=na["ticker"])
        na["decimals"] = click.prompt("Decimal precision", default=na["decimals"], type=int)
        kind = click.prompt("Issuance policy", type=click.Choice(["fixed", "scheduled", "authority"]), default=s["monetary_policy"]["kind"])
        if kind != s["monetary_policy"]["kind"]:
            if kind == "fixed":
                s["monetary_policy"] = {"kind": "fixed"}
            elif kind == "scheduled":
                r = click.prompt("Block reward (whole coins)", default="5")
                s["monetary_policy"] = {"kind": "scheduled", "max_supply": str(base_units(click.prompt("Max supply (whole coins)", default="100000000"), na["decimals"])),
                                        "scheduled": {"initial_block_reward": str(base_units(r, na["decimals"])), "halving_interval_blocks": 1_000_000}}
            else:
                s["monetary_policy"] = {"kind": "authority", "max_supply": str(base_units(click.prompt("Max supply (whole coins)", default="100000000"), na["decimals"])),
                                        "authority": {"mint_authority": "treasury", "max_mint_per_window": str(base_units(click.prompt("Max mint per window (coins)", default="10000"), na["decimals"])),
                                                      "window_blocks": click.prompt("Window (blocks)", default=1000, type=int)}}
        s["fee_policy"]["burn_bps"] = click.prompt("Fee burn (basis points)", default=s["fee_policy"]["burn_bps"], type=int)
        net.save_spec(s)
    if collections:
        s = net.spec
        col = {"activation_height": 0, "marketplace": marketplace_fee_bps is not None}
        if marketplace_fee_bps:
            col.update(marketplace_fee_bps=marketplace_fee_bps, marketplace_fee_recipient="platform")
            s["accounts"].append({"label": "platform", "role": "account", "allocation": None})
        s["modules"] = {"collections": col}
        net.save_spec(s)
    out({"network_dir": str(net.dir), "spec": str(net.spec_path), "next": "edit network.json if needed, then `chainworks genesis build`"})


@root.group(help="Key management (keys are written under <dir>/secrets with mode 0600).")
def keys():
    pass


@keys.command("create")
@click.option("--dir", "d", default="./network")
@click.option("--role", type=click.Choice(["account", "node", "validator", "treasury-signer", "operator"]), required=True)
@click.option("--label", required=True)
def keys_create(d, role, label):
    net = Network(d)
    if role in ("node", "validator"):
        out(net.ensure_node_keys(label))
    else:
        out(net.ensure_account_key(label, role))


@keys.command("list")
@click.option("--dir", "d", default="./network")
def keys_list(d):
    from .console_server import keys_inventory
    out(keys_inventory(Network(d)))


@root.group(help="Genesis construction and inspection.")
def genesis():
    pass


@genesis.command("build")
@click.argument("d", default="./network")
@click.option("--force", is_flag=True)
def genesis_build(d, force):
    out(Network(d).build_genesis(force=force))


@genesis.command("preview")
@click.argument("d", default="./network")
def genesis_preview(d):
    net = Network(d)
    g = read_json(net.genesis_path)
    out({"supply_preview": specmod.supply_preview(g), "inspect": rcli("genesis", "inspect", net.genesis_path)})


@root.command(help="Validate configuration and genesis consistency across all nodes.")
@click.argument("d", default="./network")
def validate(d):
    r = Network(d).validate()
    out(r)
    if not r["ok"]:
        sys.exit(1)


# ------------------------------------------------------------------ network
@root.group(help="Start, stop and inspect a network.")
def network():
    pass


@network.command("up")
@click.argument("d", default="./network")
@click.option("--nodes", help="comma separated subset")
def network_up(d, nodes):
    out(Network(d).up(nodes.split(",") if nodes else None))


@network.command("down")
@click.argument("d", default="./network")
@click.option("--nodes")
def network_down(d, nodes):
    out(Network(d).down(nodes.split(",") if nodes else None))


@network.command("status")
@click.argument("d", default="./network")
def network_status(d):
    out(Network(d).status())


@network.command("add-node", help="Add a non-validating node that joins and synchronises.")
@click.argument("d", default="./network")
@click.option("--name", required=True)
@click.option("--trust-from", help="BFT: take a trusted checkpoint (height/hash) from this existing node")
@click.option("--start", is_flag=True)
def network_add(d, name, trust_from, start):
    net = Network(d)
    n = net.add_node(name, trust_from)
    if start:
        net.start_node(name)
    out(n)


@network.command("compose", help="Write docker-compose.yml into the network directory.")
@click.argument("d", default="./network")
def network_compose(d):
    from . import compose
    out({"compose": str(compose.write(Network(d), Network(d).dir))})


# ------------------------------------------------------------------ wallet & tx
@root.group(help="Development wallet.")
def wallet():
    pass


@wallet.command("create")
@click.option("--dir", "d", default="./network")
@click.option("--label", required=True)
def wallet_create(d, label):
    out(Network(d).ensure_account_key(label))


@wallet.command("balance")
@click.option("--dir", "d", default="./network")
@click.option("--account", required=True, help="label or address")
@click.option("--node")
def wallet_balance(d, account, node):
    out(Wallet(Network(d), node).account(account))


@root.group(help="Transactions: prepare -> review -> sign -> submit.")
def tx():
    pass


@tx.command("prepare")
@click.option("--dir", "d", default="./network")
@click.option("--from", "sender", required=True)
@click.option("--action", required=True, help="JSON action or @file")
@click.option("--nonce", default="auto")
@click.option("--fee", default="auto")
@click.option("--expiry", type=int, default=0)
@click.option("--out", "o", required=True)
@click.option("--node")
def tx_prepare(d, sender, action, nonce, fee, expiry, o, node):
    net = Network(d)
    a = json.loads(pathlib.Path(action[1:]).read_text()) if action.startswith("@") else json.loads(action)
    p = Wallet(net, node).prepare(sender, a, nonce=nonce, fee=fee, expiry=expiry)
    pathlib.Path(o).write_text(p.read_text())
    out(read_json(o)["review"])


@tx.command("review")
@click.option("--dir", "d", default="./network")
@click.argument("file")
def tx_review(d, file):
    out(Wallet(Network(d)).review(file))


@tx.command("sign")
@click.option("--dir", "d", default="./network")
@click.option("--from", "sender", required=True)
@click.option("--in", "i", required=True)
@click.option("--out", "o", required=True)
def tx_sign(d, sender, i, o):
    s = Wallet(Network(d)).sign(sender, pathlib.Path(i).resolve())
    pathlib.Path(o).write_text(s.read_text())
    out({"signed": o, "txid": read_json(o)["txid"]})


@tx.command("submit")
@click.option("--dir", "d", default="./network")
@click.option("--in", "i", required=True)
@click.option("--node")
@click.option("--wait", is_flag=True)
def tx_submit(d, i, node, wait):
    w = Wallet(Network(d), node)
    st, resp = w.submit_file(pathlib.Path(i), node)
    r = {"http_status": st, "response": resp}
    if wait and st == 202:
        r.update(w.wait(resp["id"]))
    out(r)


@tx.command("status")
@click.option("--dir", "d", default="./network")
@click.option("--id", "txid", required=True)
@click.option("--node")
def tx_status(d, txid, node):
    w = Wallet(Network(d), node)
    out(get(f"{w.api}/v1/transactions/{txid}"))


@root.command(help="Convenience: prepare, sign, submit and wait for a native transfer.")
@click.option("--dir", "d", default="./network")
@click.option("--from", "sender", required=True)
@click.option("--to", required=True)
@click.option("--amount", required=True, help="whole/decimal coins, e.g. 1.5")
@click.option("--node")
def transfer(d, sender, to, amount, node):
    net = Network(d)
    out(Wallet(net, node).transfer(sender, to, base_units(amount, net.spec["native_asset"]["decimals"])))


# ------------------------------------------------------------------ assets
@root.group(help="Tokens and asset information.")
def asset():
    pass


@asset.command("create-token")
@click.option("--dir", "d", default="./network")
@click.option("--from", "sender", required=True)
@click.option("--symbol", required=True)
@click.option("--name", required=True)
@click.option("--decimals", type=int, default=0)
@click.option("--initial-supply", required=True, help="base units")
@click.option("--max-supply", help="base units; omit for uncapped")
@click.option("--mintable", is_flag=True, help="keep the creator as mint authority")
@click.option("--pausable", is_flag=True)
@click.option("--freezable", is_flag=True)
@click.option("--yes", is_flag=True, help="skip the permissions confirmation")
def create_token(d, sender, symbol, name, decimals, initial_supply, max_supply, mintable, pausable, freezable, yes):
    net = Network(d)
    w = Wallet(net)
    me = net.address(sender)
    act = {"type": "token_create", "symbol": symbol, "name": name, "decimals": decimals, "initial_supply": initial_supply, "initial_recipient": me,
           "max_supply": max_supply, "mint_authority": me if mintable else None, "admin": me if (pausable or freezable) else None,
           "pausable": pausable, "freezable": freezable, "metadata_uri": ""}
    click.echo(f"Permissions: mint_authority={act['mint_authority']} cap={max_supply or 'NONE'} pausable={pausable} freezable={freezable}", err=True)
    if not yes and not click.confirm("Create this token with these administrative powers?"):
        sys.exit(1)
    nonce = w.account(sender)["nonce"]
    r = w.send(sender, act)
    tid = rcli("derive", "--genesis", net.genesis_path, "--kind", "token", "--creator", me, "--nonce", nonce)["token_id"]
    out({"token_id": tid, **{k: r.get(k) for k in ("txid", "status", "block_height", "receipt")}})


@asset.command("info-package")
@click.option("--dir", "d", default="./network")
@click.option("--out", "o", required=True)
def asset_pkg(d, o):
    out(exp.asset_package(Network(d), o))


@root.group(help="Reviewed batch distributions (resumable, no double payment).")
def distribute():
    pass


@distribute.command("plan")
@click.option("--dir", "d", default="./network")
@click.option("--name", required=True)
@click.option("--from", "sender", required=True)
@click.option("--asset", "asset_", default="native", help="native or token id")
@click.option("--recipients", required=True, help='JSON file: [{"address": ..., "amount": "<base units>"}]')
@click.option("--merge-duplicates", is_flag=True)
def dist_plan(d, name, sender, asset_, recipients, merge_duplicates):
    out(dist.plan(Network(d), name, sender, asset_, read_json(recipients), merge_duplicates))


@distribute.command("run")
@click.option("--dir", "d", default="./network")
@click.option("--name", required=True)
@click.option("--approve", "plan_id", required=True, help="plan id from the reviewed preview")
@click.option("--stop-after", type=int)
def dist_run(d, name, plan_id, stop_after):
    out(dist.run(Network(d), name, plan_id, stop_after))


@distribute.command("resume")
@click.option("--dir", "d", default="./network")
@click.option("--name", required=True)
def dist_resume(d, name):
    out(dist.resume(Network(d), name))


@root.group(help="Treasury budgets, payment proposals, approvals and reports.")
def treasury():
    pass


@treasury.command("budget")
@click.option("--dir", "d", default="./network")
@click.option("--category", required=True)
@click.option("--limit", required=True, help="base units")
def tr_budget(d, category, limit):
    out(tre.set_budget(Network(d), category, int(limit)))


@treasury.command("propose")
@click.option("--dir", "d", default="./network")
@click.option("--signer", required=True)
@click.option("--to", required=True)
@click.option("--amount", required=True, help="base units")
@click.option("--category", required=True)
@click.option("--memo", default="")
def tr_propose(d, signer, to, amount, category, memo):
    out(tre.propose_payment(Network(d), signer, to, int(amount), category, memo))


@treasury.command("approve")
@click.option("--dir", "d", default="./network")
@click.option("--signer", required=True)
@click.option("--proposal", type=int, required=True)
def tr_approve(d, signer, proposal):
    out(tre.approve(Network(d), signer, proposal))


@treasury.command("report")
@click.option("--dir", "d", default="./network")
def tr_report(d):
    out(tre.report(Network(d)))


# ------------------------------------------------------------------ recovery
@root.group(help="State snapshots.")
def snapshot():
    pass


@snapshot.command("create")
@click.argument("d", default="./network")
@click.option("--node", required=True)
def snap_create(d, node):
    out(Network(d).snapshot(node))


@snapshot.command("verify")
@click.argument("d", default="./network")
@click.option("--file", "f", required=True)
@click.option("--against-node", help="fetch the trusted state root for the snapshot height from this node's validated chain")
def snap_verify(d, f, against_node):
    net = Network(d)
    r = rcli("snapshot", "verify", f, "--genesis", net.genesis_path)
    if r.get("ok") and against_node:
        b = get(f"{net.api(against_node)}/v1/blocks/{r['height']}")
        trusted = b["state_root"]
        r = rcli("snapshot", "verify", f, "--genesis", net.genesis_path, "--trusted-root", trusted)
        r["trusted_root_source"] = f"block {r['height']} as validated by {against_node}"
    out(r)
    if not r.get("ok"):
        sys.exit(1)


@root.command(help="Back up a node database (node is briefly stopped for a consistent copy).")
@click.argument("d", default="./network")
@click.option("--node", required=True)
def backup(d, node):
    out(Network(d).backup(node))


@root.command(help="Restore a node from a verified backup.")
@click.argument("d", default="./network")
@click.option("--node", required=True)
@click.option("--from", "src", required=True)
def restore(d, node, src):
    out(Network(d).restore(node, src))


@root.command(help="Replay stored blocks from a validated snapshot (node must be stopped).")
@click.argument("d", default="./network")
@click.option("--node", required=True)
@click.option("--snapshot", "snap", required=True)
@click.option("--repair", is_flag=True)
def replay(d, node, snap, repair):
    out(Network(d).replay(node, snap, repair))


# ------------------------------------------------------------------ export, migration, explorer, console
@root.command("export", help="Export the deployment package (no private keys or credentials).")
@click.argument("d", default="./network")
@click.option("--out", "o")
def export_cmd(d, o):
    net = Network(d)
    out(exp.deployment_package(net, o or net.dir / "export"))


@root.group(help="Consensus migration proposals (always a new network).")
def migrate():
    pass


@migrate.command("propose")
@click.argument("d", default="./network")
@click.option("--target-profile", type=click.Choice(specmod.PROFILES), required=True)
@click.option("--out", "o", required=True)
def migrate_propose(d, target_profile, o):
    from . import migrate as mg
    out(mg.propose(Network(d), target_profile, o))


@root.group(help="Optional PostgreSQL explorer index.")
def explorer():
    pass


@explorer.command("index")
@click.argument("d", default="./network")
@click.option("--dsn", required=True)
@click.option("--rebuild", is_flag=True)
def ex_index(d, dsn, rebuild):
    from . import explorer as ex
    out(ex.index(Network(d), dsn, rebuild=rebuild))


@explorer.command("query")
@click.option("--dsn", required=True)
@click.argument("name", type=click.Choice(["supply_events", "by_sender", "counts"]))
@click.argument("arg", required=False)
def ex_query(dsn, name, arg):
    from . import explorer as ex
    out(ex.query(dsn, name, arg))


@root.command(help="Serve the management console for a network.")
@click.argument("d", default="./network")
@click.option("--port", type=int, default=8787)
def console(d, port):
    from .console_server import serve
    srv = serve(Network(d), port)
    click.echo(f"console on http://127.0.0.1:{port} (read-only; signed-tx passthrough only)")
    srv.serve_forever()


from .nft.cli import nft as _nft  # noqa: E402

root.add_command(_nft)


@root.command(help="Run a reproducible demonstration: pow | pos | poa | assets | collections.")
@click.argument("which", type=click.Choice(["pow", "pos", "poa", "assets", "collections"]))
@click.option("--dir", "d", required=True)
def demo(which, d):
    from .demos import run_demo
    out(run_demo(which, d))


if __name__ == "__main__":
    main()
