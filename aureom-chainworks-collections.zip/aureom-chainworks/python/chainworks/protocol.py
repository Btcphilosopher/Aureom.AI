"""Independent Python reference implementation of the Aureom ledger encoding rules
(docs/PROTOCOL.md). Used to cross-check the Rust implementation through the test
vectors. Ed25519 comes from `cryptography` (no primitives implemented here).

Scope: canonical encoding of transactions/blocks, domain hashing, Merkle, addresses,
signatures, genesis hash (JCS), genesis state construction and a transfer-only
executor for the PoW state-transition vector.
"""
from __future__ import annotations

import hashlib
import json
import struct
from dataclasses import dataclass, field

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from . import bech32m


def H(domain: str, data: bytes) -> bytes:
    d = domain.encode()
    return hashlib.sha256(bytes([len(d)]) + d + data).digest()


# ---------------------------------------------------------------- merkle
def leaf(x: bytes) -> bytes:
    return H("AUREOM/LEAF/v1", x)


def node(a: bytes, b: bytes) -> bytes:
    return H("AUREOM/NODE/v1", a + b)


def merkle_root_from_leaves(level: list[bytes]) -> bytes:
    if not level:
        return H("AUREOM/EMPTY/v1", b"")
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            nxt.append(node(level[i], level[i + 1]) if i + 1 < len(level) else level[i])
        level = nxt
    return level[0]


def merkle_root(items: list[bytes]) -> bytes:
    return merkle_root_from_leaves([leaf(x) for x in items])


def merkle_proof(items: list[bytes], index: int) -> list[tuple[int, bytes]]:
    level = [leaf(x) for x in items]
    idx, out = index, []
    while len(level) > 1:
        sib = idx ^ 1
        if sib < len(level):
            out.append((0 if sib < idx else 1, level[sib]))
        level = [node(level[i], level[i + 1]) if i + 1 < len(level) else level[i] for i in range(0, len(level), 2)]
        idx //= 2
    return out


def verify_proof(item: bytes, proof: list[tuple[int, bytes]], root: bytes) -> bool:
    h = leaf(item)
    for side, sib in proof:
        h = node(sib, h) if side == 0 else node(h, sib)
    return h == root


# ---------------------------------------------------------------- encoding
class W:
    def __init__(self):
        self.b = bytearray()

    def u8(self, v): self.b += struct.pack(">B", v); return self
    def u16(self, v): self.b += struct.pack(">H", v); return self
    def u32(self, v): self.b += struct.pack(">I", v); return self
    def u64(self, v): self.b += struct.pack(">Q", v); return self
    def u128(self, v): self.b += int(v).to_bytes(16, "big"); return self
    def boolean(self, v): return self.u8(1 if v else 0)
    def fixed(self, v: bytes): self.b += v; return self
    def bytes_(self, v: bytes): self.u32(len(v)); self.b += v; return self
    def string(self, s: str): return self.bytes_(s.encode())

    def opt(self, v, f):
        if v is None:
            return self.u8(0)
        self.u8(1)
        f(v)
        return self


def address_bytes(pubkey: bytes) -> bytes:
    return H("AUREOM/ADDR/v1", b"\x01" + pubkey)[:20]


def address(pubkey: bytes, hrp: str) -> str:
    return bech32m.encode(hrp, address_bytes(pubkey))


ACTION_TAGS = {
    "transfer": 1, "vested_transfer": 2, "native_mint": 3, "native_burn": 4, "token_create": 10,
    "token_transfer": 11, "token_mint": 12, "token_burn": 13, "multisig_approve": 22,
}


def encode_action(a: dict, hrp: str) -> bytes:
    """Encode a JSON action (subset sufficient for the vectors and tooling)."""
    t = a["type"]
    w = W().u8(ACTION_TAGS[t])
    dec = lambda s: bech32m.decode(hrp, s)
    tok = lambda s: bech32m.decode(hrp + "tok", s)
    if t in ("transfer", "native_mint"):
        w.fixed(dec(a["to"])).u128(int(a["amount"]))
    elif t == "vested_transfer":
        w.fixed(dec(a["to"])).u128(int(a["amount"])).u64(a["start_height"]).u64(a["cliff_height"]).u64(a["end_height"])
    elif t == "native_burn":
        w.u128(int(a["amount"]))
    elif t == "token_create":
        flags = (1 if a.get("pausable") else 0) | (2 if a.get("freezable") else 0)
        w.string(a["symbol"]).string(a["name"]).u8(a["decimals"]).u128(int(a["initial_supply"])).fixed(dec(a["initial_recipient"]))
        w.opt(a.get("max_supply"), lambda v: w.u128(int(v)))
        w.opt(a.get("mint_authority"), lambda v: w.fixed(dec(v)))
        w.opt(a.get("admin"), lambda v: w.fixed(dec(v)))
        w.u8(flags).string(a.get("metadata_uri", ""))
    elif t in ("token_transfer", "token_mint"):
        w.fixed(tok(a["token"])).fixed(dec(a["to"])).u128(int(a["amount"]))
    elif t == "token_burn":
        w.fixed(tok(a["token"])).u128(int(a["amount"]))
    elif t == "multisig_approve":
        w.fixed(dec(a["multisig"])).u64(a["proposal_id"])
    else:
        raise ValueError(f"reference encoder does not implement {t}")
    return bytes(w.b)


def encode_unsigned(tx: dict, hrp: str) -> bytes:
    w = W().u16(tx["version"]).string(tx["chain_id"]).u64(tx["nonce"]).u64(int(tx["fee"])).u64(tx["expiry_height"])
    w.fixed(bytes.fromhex(tx["sender_pubkey"]))
    w.fixed(encode_action(tx["action"], hrp))
    w.bytes_(tx["memo"].encode())
    return bytes(w.b)


def signing_message(chain_id: str, action_tag: int, unsigned: bytes) -> bytes:
    d = b"AUREOM/TXSIG/v1"
    return bytes([len(d)]) + d + W().string(chain_id).u16(1).u8(action_tag).b + unsigned


def txid(unsigned: bytes) -> bytes:
    return H("AUREOM/TXID/v1", unsigned)


def verify_sig(pubkey: bytes, msg: bytes, sig: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(pubkey).verify(sig, msg)
        return True
    except InvalidSignature:
        return False


# ---------------------------------------------------------------- decoding (signed tx, transfer subset)
class R:
    def __init__(self, b: bytes):
        self.b, self.p = b, 0

    def take(self, n):
        if self.p + n > len(self.b):
            raise ValueError("eof")
        v = self.b[self.p:self.p + n]
        self.p += n
        return v

    def u8(self): return self.take(1)[0]
    def u16(self): return struct.unpack(">H", self.take(2))[0]
    def u32(self): return struct.unpack(">I", self.take(4))[0]
    def u64(self): return struct.unpack(">Q", self.take(8))[0]
    def u128(self): return int.from_bytes(self.take(16), "big")

    def bytes_(self, mx):
        n = self.u32()
        if n > mx:
            raise ValueError("too long")
        return self.take(n)

    def end(self):
        if self.p != len(self.b):
            raise ValueError("trailing bytes")


@dataclass
class Transfer:
    chain_id: str
    nonce: int
    fee: int
    expiry: int
    pubkey: bytes
    to: bytes
    amount: int
    memo: bytes
    unsigned: bytes
    signature: bytes


def decode_signed_transfer(b: bytes) -> Transfer:
    r = R(b)
    assert r.u16() == 1
    chain = r.bytes_(64).decode()
    nonce, fee, exp = r.u64(), r.u64(), r.u64()
    pk = r.take(32)
    if r.u8() != 1:
        raise ValueError("not a transfer")
    to, amt = r.take(20), r.u128()
    memo = r.bytes_(256)
    unsigned = b[: r.p]
    sig = r.take(64)
    r.end()
    return Transfer(chain, nonce, fee, exp, pk, to, amt, memo, unsigned, sig)


# ---------------------------------------------------------------- genesis
def jcs(v) -> str:
    """RFC 8785 canonical JSON for the ASCII/integer genesis domain."""
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        raise ValueError("floats not allowed in genesis")
    if isinstance(v, str):
        if not all(0x20 <= ord(c) < 0x7F for c in v):
            raise ValueError(f"non-printable-ASCII string {v!r}")
        return json.dumps(v)
    if isinstance(v, list):
        return "[" + ",".join(jcs(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ",".join(json.dumps(k) + ":" + jcs(v[k]) for k in sorted(v)) + "}"
    raise TypeError(type(v))


def genesis_hash(g: dict) -> bytes:
    return H("AUREOM/GENESIS/v1", jcs(g).encode())


def treasury_address(index: int) -> bytes:
    return H("AUREOM/MSIG/v1", b"\x00" * 20 + index.to_bytes(8, "big"))[:20]


def state_leaf(k: bytes, v: bytes) -> bytes:
    return H("AUREOM/STATE/v1", len(k).to_bytes(4, "big") + k + len(v).to_bytes(4, "big") + v)


def state_root(entries: dict[bytes, bytes]) -> bytes:
    return merkle_root_from_leaves([leaf(state_leaf(k, entries[k])) for k in sorted(entries)])


@dataclass
class Account:
    balance: int = 0
    nonce: int = 0
    vesting: list = field(default_factory=list)  # (total,start,cliff,end)
    immature: list = field(default_factory=list)  # (mature_height, amount)

    def encode(self) -> bytes:
        w = W().u128(self.balance).u64(self.nonce).u32(len(self.vesting))
        for t, s, c, e in self.vesting:
            w.u128(t).u64(s).u64(c).u64(e)
        w.u32(len(self.immature))
        for h, a in self.immature:
            w.u64(h).u128(a)
        return bytes(w.b)

    def vested(self, v, h):
        t, s, c, e = v
        if h < c:
            return 0
        if h >= e:
            return t
        return t * (h - s) // (e - s)

    def available(self, h):
        locked = sum(v[0] - self.vested(v, h) for v in self.vesting)
        imm = sum(a for mh, a in self.immature if h < mh)
        return max(0, self.balance - locked - imm)

    def prune(self, h):
        self.vesting = [v for v in self.vesting if v[0] - self.vested(v, h) > 0]
        self.immature = [x for x in self.immature if h < x[0]]

    def empty(self):
        return self.balance == 0 and self.nonce == 0 and not self.vesting and not self.immature


def genesis_state(g: dict) -> dict[bytes, bytes]:
    """Genesis state for the PoW/no-validator case (validators omitted)."""
    hrp = g["native_asset"]["address_hrp"]
    st: dict[bytes, bytes] = {b"\x00": genesis_hash(g)}
    total = 0
    for a in g["allocations"]:
        acct = Account(balance=int(a["amount"]))
        if a.get("vesting"):
            v = a["vesting"]
            acct.vesting.append((int(a["amount"]), v["start_height"], v["cliff_height"], v["end_height"]))
        st[b"\x01" + bech32m.decode(hrp, a["address"])] = acct.encode()
        total += int(a["amount"])
    for i, t in enumerate(g.get("treasuries", [])):
        addr = treasury_address(i)
        signers = [bech32m.decode(hrp, s) for s in t["signers"]]
        w = W().u32(len(signers))
        for s in signers:
            w.fixed(s)
        w.u8(t["threshold"]).u64(0)
        st[b"\x04" + addr] = bytes(w.b)
        if int(t["amount"]) > 0:
            st[b"\x01" + addr] = Account(balance=int(t["amount"])).encode()
        total += int(t["amount"])
    if g.get("validators"):
        raise NotImplementedError("reference genesis_state covers networks without validators")
    st[b"\x21"] = bytes(W().u64(0).u32(0).b)  # GovState{next_id:0, upgrades:[]}
    st[b"\x30"] = bytes(W().u128(total).u128(0).u128(0).u128(total).b)
    return st


def decode_account(b: bytes) -> Account:
    r = R(b)
    a = Account(r.u128(), r.u64())
    for _ in range(r.u32()):
        a.vesting.append((r.u128(), r.u64(), r.u64(), r.u64()))
    for _ in range(r.u32()):
        a.immature.append((r.u64(), r.u128()))
    r.end()
    return a


def execute_transfer_block(g: dict, st: dict[bytes, bytes], height: int, miner: bytes, txs: list[bytes]):
    """Independent executor for PoW blocks containing only transfers (vector check).
    Returns (statuses, receipts_root)."""
    fp = g["fee_policy"]
    base, per, burn_bps = int(fp["base_fee"]), int(fp["per_byte_fee"]), fp["burn_bps"]
    sup = R(st[b"\x30"])
    genesis_s, minted, burned, total = sup.u128(), sup.u128(), sup.u128(), sup.u128()
    proposer_fees = 0
    receipts = []
    statuses = []

    def get(addr):
        k = b"\x01" + addr
        return decode_account(st[k]) if k in st else Account()

    def put(addr, a: Account):
        k = b"\x01" + addr
        if a.empty():
            st.pop(k, None)
        else:
            st[k] = a.encode()

    for raw in txs:
        t = decode_signed_transfer(raw)
        assert t.chain_id == g["chain_id"]
        assert verify_sig(t.pubkey, signing_message(t.chain_id, 1, t.unsigned), t.signature), "bad signature"
        assert t.fee >= base + per * len(raw), "fee too low"
        sender = address_bytes(t.pubkey)
        a = get(sender)
        assert t.nonce == a.nonce, "bad nonce"
        assert t.fee <= a.available(height), "insufficient fee balance"
        a.balance -= t.fee
        a.nonce += 1
        a.prune(height)
        put(sender, a)
        b = t.fee * burn_bps // 10000
        burned += b
        total -= b
        proposer_fees += t.fee - b
        events = [("fee", [("paid", str(t.fee)), ("burned", str(b)), ("to_recipient", str(t.fee - b))])]
        a = get(sender)
        if a.available(height) >= t.amount:
            a.balance -= t.amount
            a.prune(height)
            put(sender, a)
            r = get(t.to)
            r.balance += t.amount
            r.prune(height)
            put(t.to, r)
            hrp = g["native_asset"]["address_hrp"]
            events.append(("transfer", [("from", bech32m.encode(hrp, sender)), ("to", bech32m.encode(hrp, t.to)), ("amount", str(t.amount))]))
            status, code = 1, 0
        else:
            status, code = 2, 1
        statuses.append(status)
        w = W().fixed(txid(t.unsigned)).u8(status).u16(code).u64(t.fee).u32(len(events))
        for kind, attrs in events:
            w.string(kind).u32(len(attrs))
            for k, v in attrs:
                w.string(k).string(v)
        receipts.append(H("AUREOM/RECEIPT/v1", bytes(w.b)))
    # coinbase (scheduled policy)
    mp = g["monetary_policy"]
    reward = 0
    if mp["kind"] == "scheduled":
        s = mp["scheduled"]
        halvings = height // s["halving_interval_blocks"]
        reward = int(s["initial_block_reward"]) >> halvings if halvings < 128 else 0
        cap = int(mp.get("max_supply", str(2**128 - 1)))
        reward = min(reward, cap - total)
    minted += reward
    total += reward
    payout = reward + proposer_fees
    if payout:
        m = get(miner)
        m.prune(height)
        m.balance += payout
        m.immature.append((height + g["consensus"]["pow"]["coinbase_maturity"], payout))
        put(miner, m)
    st[b"\x30"] = bytes(W().u128(genesis_s).u128(minted).u128(burned).u128(total).b)
    return statuses, merkle_root(receipts)
