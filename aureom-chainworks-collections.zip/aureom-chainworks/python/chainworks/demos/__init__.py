import pathlib


def run_demo(which: str, d: str, out: str | None = None):
    out = out or str(pathlib.Path(d).parent / "results")
    if which == "pow":
        from .pow import run
    elif which in ("pos", "poa"):
        from .bft import run_pos as run_pos, run_poa
        run = run_pos if which == "pos" else run_poa
    elif which == "collections":
        from .collections_demo import run
    else:
        from .assets import run
    return run(d, out)
