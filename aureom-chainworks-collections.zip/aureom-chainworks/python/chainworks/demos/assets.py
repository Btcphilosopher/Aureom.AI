"""Aureom Development Network (fictional): native coin with a fixed genesis allocation,
treasury, vesting, an additional token, distributions, supply reconciliation, exports,
explorer index, console server and a migration proposal."""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import socket
import subprocess
import threading
import time

from .. import distribute as dist
from .. import export as exp
from .. import treasury as tre
from ..util import cli, get, http, read_json, try_get, wait_for
from ..wallet import Wallet
from .common import Recorder, fresh, heights, tips_agree, wait_height

U = 10**6


def run(d, out):
    rec = Recorder("assets", out)
    net = fresh(d, "poa", name="Aureom Development Network", chain_id="aureom-devnet-1", base_port=18400)
    s = net.spec
    s["native_asset"].update({"name": "Aureom Demonstration Coin", "ticker": "ADC"})
    s["monetary_policy"] = {"kind": "fixed"}
    net.save_spec(s)
    w = Wallet(net, "node0")
    ctx = {}

    def launch():
        g = net.build_genesis()
        v = net.validate()
        net.up()
        wait_for(lambda: min(heights(net).values()) >= 3 and tips_agree(net, [n["name"] for n in net.nodes()], 1), 90, 1, "launch")
        return {"genesis_hash": g["genesis_hash"], "validation_ok": v["ok"], "heights": heights(net), "policy": "fixed (no minting authority)"}
    rec.step("Launch the Aureom Development Network (PoA, fixed-supply native coin, treasury, vesting)", launch, lambda e: e["validation_ok"])

    def genesis_supply():
        g = read_json(net.genesis_path)
        expected = sum(int(a["amount"]) for a in g["allocations"]) + sum(int(t["amount"]) for t in g["treasuries"])
        sup = get(w.api + "/v1/supply")
        ctx["genesis_total"] = expected
        return {"genesis_document_sum": str(expected), "node_reported_total": sup["total"], "genesis": sup["genesis"], "minted": sup["minted"],
                "locked_vesting": sup["locked_vesting"], "treasury": sup["treasury"], "circulating": sup["circulating"], "reconciled": sup["reconciled"]}
    rec.step("Verify genesis supply against the genesis document", genesis_supply,
             lambda e: e["genesis_document_sum"] == e["node_reported_total"] == e["genesis"] and e["minted"] == "0" and e["reconciled"])

    def native():
        b0 = int(w.account("dave")["native"]["total"])
        r = w.transfer("alice", "dave", 1_000 * U)
        ctx["fee_tx"] = r
        return {"status": r["status"], "dave_delta": int(w.account("dave")["native"]["total"]) - b0, "receipt": r["receipt"]["status"]}
    rec.step("Transfer the native coin", native, lambda e: e["dave_delta"] == 1_000 * U and e["receipt"] == "success")

    def fees():
        r = ctx["fee_tx"]["receipt"]
        fee = next(e for e in r["events"] if e["kind"] == "fee")["attrs"]
        sup = get(w.api + "/v1/supply")
        payouts = get(w.api + "/v1/events?kind=fee_payout&limit=5")["events"]
        return {"fee_paid": r["fee_paid"], "burned": fee["burned"], "to_proposer": fee["to_recipient"], "burn_bps": 2000,
                "supply_burned_total": sup["burned"], "total_now": sup["total"], "recent_proposer_payouts": [p["attrs"] for p in payouts][:2]}
    rec.step("Pay transaction fees: 20% burned (supply decreases), 80% to the block proposer", fees,
             lambda e: int(e["burned"]) == int(e["fee_paid"]) * 2000 // 10000 and int(e["burned"]) + int(e["to_proposer"]) == int(e["fee_paid"]) and e["recent_proposer_payouts"])

    def token():
        issuer = net.address("issuer")
        act = {"type": "token_create", "symbol": "GLDX", "name": "Demo Gold Units", "decimals": 2, "initial_supply": str(10_000_000), "initial_recipient": issuer,
               "max_supply": str(100_000_000), "mint_authority": issuer, "admin": None, "pausable": False, "freezable": False,
               "metadata_uri": "https://example.invalid/demo-gold (issuer-supplied, unverified)"}
        u = w.prepare("issuer", act)
        review = w.review(u)
        nonce = w.account("issuer")["nonce"]
        sg = read_json(w.sign("issuer", u))
        http("POST", w.api + "/v1/transactions", {"tx": sg["signed_hex"]})
        res = w.wait(sg["txid"])
        tid = cli("derive", "--genesis", net.genesis_path, "--kind", "token", "--creator", issuer, "--nonce", nonce)["token_id"]
        ctx["token"] = tid
        t = get(f"{w.api}/v1/tokens/{tid}")
        return {"review_before_signing": {"summary": review["summary"], "warnings": review["warnings"]}, "status": res["status"], "token_id": tid,
                "on_chain": {k: t[k] for k in ("symbol", "supply", "max_supply", "mint_authority", "admin", "pausable", "freezable")}}
    rec.step("Define token -> review permissions -> sign -> submit -> verify (capped, mintable by issuer, no pause/freeze)", token,
             lambda e: e["on_chain"]["supply"] == "10000000" and e["on_chain"]["pausable"] is False)

    def cap():
        tid = ctx["token"]
        ok = w.send("issuer", {"type": "token_mint", "token": tid, "to": net.address("issuer"), "amount": str(90_000_000)})
        over = w.send("issuer", {"type": "token_mint", "token": tid, "to": net.address("issuer"), "amount": "1"})
        return {"mint_to_cap": ok["receipt"]["status"], "mint_beyond_cap": over["receipt"]["error"], "supply": get(f"{w.api}/v1/tokens/{tid}")["supply"]}
    rec.step("Enforce the token supply cap", cap, lambda e: e["mint_to_cap"] == "success" and e["mint_beyond_cap"] == "SUPPLY_CAP" and e["supply"] == "100000000")

    def unauthorised():
        tid = ctx["token"]
        r = w.send("bob", {"type": "token_mint", "token": tid, "to": net.address("bob"), "amount": "5"})
        u = w.prepare("alice", {"type": "native_mint", "to": net.address("alice"), "amount": "5"})
        code, resp = http("POST", w.api + "/v1/transactions", {"tx": read_json(w.sign("alice", u))["signed_hex"]})
        return {"token_mint_by_non_authority": r["receipt"]["error"], "native_mint_on_fixed_supply": {"http": code, "code": resp["error"]["code"]}}
    rec.step("Reject unauthorised minting (token and native coin)", unauthorised,
             lambda e: e["token_mint_by_non_authority"] == "UNAUTHORIZED" and e["native_mint_on_fixed_supply"]["code"] == "unsupported_action")

    def spoof():
        nonce = w.account("bob")["nonce"]
        w.send("bob", {"type": "token_create", "symbol": "GLDX", "name": "Demo Gold Units", "decimals": 2, "initial_supply": "500", "initial_recipient": net.address("dave"),
                       "max_supply": None, "mint_authority": None, "admin": None})
        fake = cli("derive", "--genesis", net.genesis_path, "--kind", "token", "--creator", net.address("bob"), "--nonce", nonce)["token_id"]
        toks = get(w.api + "/v1/tokens")["tokens"]
        same = [t for t in toks if t["symbol"] == "GLDX"]
        return {"tokens_with_symbol_GLDX": [{"token_id": t["token_id"], "creator": t["creator"], "supply": t["supply"]} for t in same], "ids_distinct": len({t["token_id"] for t in same}) == 2,
                "identify_by": "token_id (symbols and names are issuer-supplied labels)"}
    rec.step("Spoofing resistance: a second token with an identical symbol/name gets a distinct token id", spoof, lambda e: e["ids_distinct"])

    def distribution():
        tid = ctx["token"]
        rows = [{"address": "carol", "amount": "1000"}, {"address": "dave", "amount": "2000"}, {"address": "t1", "amount": "3000"},
                {"address": "carol", "amount": "50"}, {"address": "aurd1invalid", "amount": "1"}]
        bad = dist.plan(net, "gold-airdrop", "issuer", tid, rows)
        good_rows = rows[:3] + [{"address": "t2", "amount": "4000"}]
        p = dist.plan(net, "gold-airdrop", "issuer", tid, good_rows)
        before = {r["address"]: int(r["balance_before"]) for r in p["recipients"]}
        first = dist.run(net, "gold-airdrop", p["plan_id"], stop_after=2)
        second = dist.resume(net, "gold-airdrop")
        third = dist.resume(net, "gold-airdrop")
        after = {}
        for a in before:
            acct = w.account(a)
            after[a] = int(next((t["balance"] for t in acct["tokens"] if t["token_id"] == tid), "0"))
        deltas = {a: after[a] - before[a] for a in before}
        expected = {r["address"]: int(r["amount"]) for r in p["recipients"]}
        return {"rejected_plan_problems": bad["problems"], "preview": p["totals"], "interrupted_run": first, "resume": second["counts"],
                "second_resume": third["counts"], "balance_deltas_equal_plan": deltas == expected}
    rec.step("Distribute the token: reviewed preview (duplicates/invalid rejected), interrupted run, resume, no duplicate payments", distribution,
             lambda e: len(e["rejected_plan_problems"]) >= 2 and e["interrupted_run"].get("interrupted") and e["balance_deltas_equal_plan"])

    def claims():
        claims = [{"index": 0, "address": net.address("carol"), "amount": str(300 * U)}, {"index": 1, "address": net.address("dave"), "amount": str(700 * U)}]
        tree = dist.claims_tree(net, "claims-1", claims)
        proofs = read_json(net.dir / "distributions" / "claims-1" / "claims-tree.json")["claims"]
        h = heights(net, ["node0"])["node0"]
        nonce = w.account("alice")["nonce"]
        cr = w.send("alice", {"type": "distribution_create", "asset": "native", "total": str(1000 * U), "merkle_root": tree["merkle_root"], "claim_deadline_height": h + 500})
        did = cli("derive", "--genesis", net.genesis_path, "--kind", "distribution", "--creator", net.address("alice"), "--nonce", nonce)["dist_id"]
        c1 = w.send("carol", {"type": "distribution_claim", "dist_id": did, "index": 0, "amount": str(300 * U), "proof": proofs[0]["proof"]})
        c2 = w.send("carol", {"type": "distribution_claim", "dist_id": did, "index": 0, "amount": str(300 * U), "proof": proofs[0]["proof"]})
        c3 = w.send("dave", {"type": "distribution_claim", "dist_id": did, "index": 1, "amount": str(900 * U), "proof": proofs[1]["proof"]})
        dd = get(f"{w.api}/v1/distributions/{did}")
        return {"create": cr["receipt"]["status"], "claim": c1["receipt"]["status"], "double_claim": c2["receipt"]["error"], "inflated_claim": c3["receipt"]["error"],
                "remaining_in_escrow": dd["remaining"]}
    rec.step("Claim-based distribution (Merkle commitment): claim once; double claim and inflated claim rejected", claims,
             lambda e: e["claim"] == "success" and e["double_claim"] == "ALREADY_CLAIMED" and e["inflated_claim"] == "BAD_PROOF")

    def vesting():
        g = read_json(net.genesis_path)
        v = next(a for a in g["allocations"] if a["label"] == "team")["vesting"]
        w.transfer("alice", "team", 10 * U)  # fee money outside the vesting lock
        early = w.send("team", {"type": "transfer", "to": net.address("bob"), "amount": str(20 * U)})
        wait_height(net, "node0", v["cliff_height"] + 2, 120)
        acct = w.account("team")
        avail = int(acct["native"]["available"])
        ok = w.send("team", {"type": "transfer", "to": net.address("bob"), "amount": str(5_000 * U)})
        too_much = w.send("team", {"type": "transfer", "to": net.address("bob"), "amount": str(90_000 * U)})
        return {"schedule": v, "before_cliff": early["receipt"]["error"], "at_height": acct["height"], "available_after_cliff": avail,
                "vesting": acct["vesting"], "partial_unlock_spend": ok["receipt"]["status"], "spend_beyond_vested": too_much["receipt"]["error"]}
    rec.step("Vesting: locked before the cliff; linear unlock by block height after it", vesting,
             lambda e: e["before_cliff"] == "INSUFFICIENT_FUNDS" and e["partial_unlock_spend"] == "success" and e["spend_beyond_vested"] == "INSUFFICIENT_FUNDS")

    def treasury():
        tre.set_budget(net, "grants", 50_000 * U, "demo quarter")
        p = tre.propose_payment(net, "t1", "carol", 1_000 * U, "grants", "grant #1")
        intruder = w.send("bob", {"type": "multisig_approve", "multisig": tre.treasury_address(net), "proposal_id": p["proposal_id"]})
        c0 = int(w.account("carol")["native"]["total"])
        a = tre.approve(net, "t2", p["proposal_id"])
        c1 = int(w.account("carol")["native"]["total"])
        over = None
        try:
            tre.propose_payment(net, "t1", "carol", 60_000 * U, "grants")
        except Exception as e:  # noqa: BLE001
            over = str(e)
        rep = tre.report(net)
        return {"proposal": p["proposal_id"], "after_proposal": "pending (1 of 2)", "non_signer_approval": intruder["receipt"]["error"],
                "after_second_signer": a["proposal"]["status"], "carol_received": c1 - c0, "over_budget_proposal": over,
                "report_budgets": rep["budgets"], "treasury_balance": rep["on_chain"]["balance"]}
    rec.step("Treasury: budget, proposal by one signer, approval by another (separately signed), settlement on-chain, report", treasury,
             lambda e: e["non_signer_approval"] == "UNAUTHORIZED" and e["after_second_signer"] == "executed" and e["carol_received"] == 1_000 * U and e["over_budget_proposal"])

    def reconcile():
        sup = get(w.api + "/v1/supply")
        fee_events = get(w.api + "/v1/events?kind=fee&limit=500")["events"]
        burned_from_receipts = sum(int(e["attrs"]["burned"]) for e in fee_events)
        tid = ctx["token"]
        t = get(f"{w.api}/v1/tokens/{tid}")
        holders = 0
        for lbl in ("issuer", "carol", "dave", "t1", "t2", "bob", "alice"):
            holders += int(next((x["balance"] for x in w.account(lbl)["tokens"] if x["token_id"] == tid), "0"))
        return {"genesis": sup["genesis"], "burned": sup["burned"], "burned_sum_of_fee_receipts": str(burned_from_receipts), "total": sup["total"],
                "genesis_minus_burned": str(ctx["genesis_total"] - int(sup["burned"])), "node_reconciled": sup["reconciled"], "tokens_reconciled": sup["tokens_reconciled"],
                "token_supply": t["supply"], "sum_of_holder_balances": str(holders), "fee_events_counted": len(fee_events)}
    rec.step("Reconcile supply against state transitions (genesis - burns = total; token supply = holder balances)", reconcile,
             lambda e: e["burned"] == e["burned_sum_of_fee_receipts"] and e["total"] == e["genesis_minus_burned"] and e["node_reconciled"] and e["token_supply"] == e["sum_of_holder_balances"])

    def restart():
        before = get(w.api + "/v1/supply")
        net.stop_node("node0")
        net.start_node("node0")
        wait_for(lambda: tips_agree(net, ["node0", "node1"], 1), 60, 1, "node0")
        after = get(w.api + "/v1/supply")
        return {"total_before": before["total"], "total_after": after["total"], "reconciled": after["reconciled"]}
    rec.step("Restart recovery preserves balances and supply invariants", restart, lambda e: e["total_before"] == e["total_after"] and e["reconciled"])

    def postgres():
        name = "cw-explorer-pg"
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
        r = subprocess.run(["docker", "run", "-d", "--rm", "--name", name, "-p", "127.0.0.1:55432:5432", "-e", "POSTGRES_HOST_AUTH_METHOD=trust",
                            "-e", "POSTGRES_USER=aureom", "-e", "POSTGRES_DB=explorer", "mirror.gcr.io/library/postgres:16"], capture_output=True, text=True)
        if r.returncode != 0:
            return {"skipped": "docker/postgres unavailable: " + r.stderr[-200:]}
        try:
            import psycopg
            dsn = "postgresql://aureom@127.0.0.1:55432/explorer"
            wait_for(lambda: psycopg.connect(dsn).close() or True, 60, 1, "postgres")
            from .. import explorer as ex
            r1 = ex.index(net, dsn)
            r2 = ex.index(net, dsn)
            counts = ex.query(dsn, "counts")
            evs = ex.query(dsn, "supply_events")
            r3 = ex.index(net, dsn, rebuild=True)
            return {"postgres": "16 (docker)", "first_index": r1, "incremental": r2, "rebuild": r3, "counts_blocks_txs_events": counts[0],
                    "supply_event_kinds": sorted({e[1] for e in evs})}
        finally:
            subprocess.run(["docker", "rm", "-f", name], capture_output=True)
    rec.step("Optional PostgreSQL explorer index (derived, rebuildable) of issuance/burn/admin events", postgres,
             lambda e: e.get("skipped") or (e["first_index"]["indexed_blocks"] > 0 and "mint" in e["supply_event_kinds"]))

    def exports():
        a = exp.asset_package(net, net.dir / "asset-package")
        d_ = exp.deployment_package(net, net.dir / "export")
        info = read_json(net.dir / "asset-package" / "asset-information.json")
        check = subprocess.run(["sha256sum", "-c", "--quiet", "CHECKSUMS.sha256"], cwd=net.dir / "export", capture_output=True, text=True)
        return {"asset_package": a, "deployment": {k: d_[k] for k in ("files", "secret_scan")}, "checksums_verify": check.returncode == 0,
                "wallet_connection": info["wallet_connection"], "admin_powers": info["administrative_powers"]["native_coin"]}
    rec.step("Export wallet connection details, asset documentation and the deployment package (secret scan, checksums)", exports,
             lambda e: e["deployment"]["secret_scan"] == "clean" and e["checksums_verify"])

    def console():
        from ..console_server import serve
        srv = serve(net, 18799)
        th = threading.Thread(target=srv.serve_forever, daemon=True)
        th.start()
        base = "http://127.0.0.1:18799"
        try:
            r = {"manifest_nodes": len(get(base + "/api/manifest")["nodes"]), "proxied_health": get(base + "/proxy/node0/v1/health")["status"],
                 "admin_via_console": http("GET", base + "/proxy/node0/admin/v1/status")[0], "post_non_tx": http("POST", base + "/proxy/node0/v1/blocks", {"x": 1})[0],
                 "post_bad_body": http("POST", base + "/proxy/node0/v1/transactions", {"tx": "zz"})[0], "keys_have_no_secrets": "ciphertext" not in json.dumps(get(base + "/api/keys"))}
            shots = net.dir.parent / "results" / "console"
            shots.mkdir(parents=True, exist_ok=True)
            js = f"""
const {{ chromium }} = require('playwright');
(async () => {{
  const b = await chromium.launch(); const p = await b.newPage({{viewport: {{width: 1440, height: 1000}}, deviceScaleFactor: 1}});
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  for (const r of ['nodes','assets','validators','treasury','accounts']) {{
    await p.goto('{base}/#/' + r); await p.waitForTimeout(4500);
    await p.screenshot({{path: '{shots}/' + r + '.png', fullPage: false}});
  }}
  console.log(JSON.stringify({{errors: errs}})); await b.close();
}})();"""
            pr = subprocess.run(["node", "-e", js], capture_output=True, text=True, timeout=120)
            r["screenshots"] = sorted(x.name for x in shots.glob("*.png"))
            r["browser"] = pr.stdout.strip()[-300:] or pr.stderr.strip()[-300:]
            return r
        finally:
            srv.shutdown()
    rec.step("Management console against the live network: manifest, proxied reads; admin proxy and non-tx POST refused", console,
             lambda e: e["admin_via_console"] == 403 and e["post_non_tx"] == 403 and e["post_bad_body"] == 400 and e["keys_have_no_secrets"])

    def migration():
        from .. import migrate
        r = migrate.propose(net, "pos", net.dir / "migration-to-pos")
        rep = read_json(net.dir / "migration-to-pos" / "validation-report.json")
        return {"checkpoint": r["checkpoint"], "accounts_mapped": r["accounts_mapped"], "warnings": rep["warnings"][:2], "tokens": rep["tokens_requiring_reissuance"]}
    rec.step("Export a consensus migration proposal (new network; no implied continuity)", migration, lambda e: e["accounts_mapped"] > 0)

    net.down()
    return rec.save()
