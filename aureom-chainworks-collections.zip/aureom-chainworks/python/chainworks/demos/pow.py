"""Proof-of-work demonstration: 3 miners + joining node, reorganisation by cumulative
work, malformed / invalid-target block injection, delayed messages, crash recovery."""
from __future__ import annotations

import json
import pathlib
import time

from .. import faults
from ..util import get, http, try_get, wait_for
from ..wallet import Wallet
from .common import Recorder, api_permission_steps, common_tx_steps, explorer_steps, fresh, heights, snapshot_steps, tips_agree, wait_height


def admin(net, node, path, body):
    url, tok = net.admin(node)
    return http("POST", url + path, body, {"authorization": f"Bearer {tok}"})


def run(d, out):
    rec = Recorder("pow", out)
    net = fresh(d, "pow")
    w = Wallet(net, "node0")
    rec.step("Generate configuration and keys", lambda: {"accounts": len(net.create_all_keys()), "spec": str(net.spec_path)})
    rec.step("Build and validate genesis", lambda: {**net.build_genesis(), "validation_ok": net.validate()["ok"]}, lambda e: e["validation_ok"])
    rec.step("Launch three mining nodes", lambda: [x["status"] for x in net.up()])
    rec.step("Nodes produce and agree on blocks", lambda: wait_for(lambda: (min(heights(net).values() or [0]) >= 12) and tips_agree(net, ["node0", "node1", "node2"]), 120, 1, "agreement"),
             lambda e: bool(e))
    st = common_tx_steps(rec, net, w)

    def confirmations():
        h0 = get(f"{w.api}/v1/transactions/{st['txid']}")
        wait_for(lambda: get(f"{w.api}/v1/transactions/{st['txid']}")["status"] == "confirmed", 120, 1, "6 confirmations")
        h1 = get(f"{w.api}/v1/transactions/{st['txid']}")
        return {"first": {k: h0.get(k) for k in ("status", "confirmations")}, "later": {k: h1.get(k) for k in ("status", "confirmations", "finality")}}
    rec.step("Confirmation depth is reported as probabilistic settlement", confirmations, lambda e: e["later"]["status"] == "confirmed" and e["later"]["finality"] == "probabilistic")

    api_permission_steps(rec, net)

    # ---------------------------------------------------------------- fork / reorg
    ids = {n: get(net.api(n) + "/v1/peers")["self_id"] for n in ("node0", "node1", "node2")}
    p2p = {n["name"]: f"127.0.0.1:{n['p2p_port']}" for n in net.nodes()}
    rs = {}

    def partition():
        for a, b in (("node0", "node2"), ("node1", "node2"), ("node2", "node0"), ("node2", "node1")):
            admin(net, a, "/admin/v1/peer-actions", {"action": "ban", "peer": ids[b]})
            admin(net, a, "/admin/v1/peer-actions", {"action": "ban", "peer": p2p[b]})
        time.sleep(3)
        return {n: [p["id"][:12] for p in get(net.api(n) + "/v1/peers")["peers"]] for n in ("node0", "node1", "node2")}
    rec.step("Partition node2 from the majority (operator bans via admin API)", partition, lambda e: e["node2"] == [] and len(e["node0"]) == 1)

    def minority_tx():
        w2 = Wallet(net, "node2")
        r = w2.transfer("carol", "dave", 1234, wait=False)
        rs["minority_txid"] = r["txid"]
        wait_for(lambda: get(f"{net.api('node2')}/v1/transactions/{r['txid']}")["status"] in ("included", "confirmed"), 120, 0.5, "minority inclusion")
        t = get(f"{net.api('node2')}/v1/transactions/{r['txid']}")
        maj = get(f"{net.api('node0')}/v1/transactions/{r['txid']}")
        return {"minority_status": t["status"], "minority_block": t["block_height"], "majority_view": maj["status"]}
    rec.step("Transaction included only on the minority branch", minority_tx, lambda e: e["minority_status"] in ("included", "confirmed") and e["majority_view"] == "unknown")

    def compete():
        h2 = heights(net, ["node2"])["node2"]
        wait_for(lambda: heights(net, ["node2"])["node2"] >= h2 + 2, 120, 0.5, "minority blocks")
        admin(net, "node2", "/admin/v1/mining", {"enabled": False})
        h0 = heights(net, ["node0"])["node0"]
        wait_for(lambda: heights(net, ["node0"])["node0"] >= max(h0, heights(net, ["node2"])["node2"]) + 4, 180, 0.5, "majority lead")
        c0 = get(net.api("node0") + "/v1/consensus/status")
        c2 = get(net.api("node2") + "/v1/consensus/status")
        return {"majority": {"height": c0["height"], "work": c0["cumulative_work"], "tip": c0["tip"][:16]},
                "minority": {"height": c2["height"], "work": c2["cumulative_work"], "tip": c2["tip"][:16]}}
    rec.step("Competing branches: both sides mine; majority accumulates more work", compete,
             lambda e: int(e["majority"]["work"]) > int(e["minority"]["work"]) and e["majority"]["tip"] != e["minority"]["tip"])

    def heal():
        for n in ("node0", "node1", "node2"):
            admin(net, n, "/admin/v1/peer-actions", {"action": "unban", "peer": "*"})
        admin(net, "node2", "/admin/v1/mining", {"enabled": True})
        wait_for(lambda: tips_agree(net, ["node0", "node1", "node2"], 1), 120, 1, "reconvergence")
        c2 = get(net.api("node2") + "/v1/consensus/status")
        t = get(f"{net.api('node2')}/v1/transactions/{rs['minority_txid']}")
        return {"node2_reorgs": c2["reorgs"][-1:], "minority_tx_after_reorg": {k: t.get(k) for k in ("status", "block_height", "reason")}}
    rec.step("Reconnect: node2 reorganises to the chain with most cumulative work; its tx returns to the mempool and is re-validated", heal,
             lambda e: e["node2_reorgs"] and e["node2_reorgs"][0]["depth"] >= 1 and e["minority_tx_after_reorg"]["status"] in ("pending", "included", "confirmed"))

    def reincluded():
        t = wait_for(lambda: (x := get(f"{net.api('node0')}/v1/transactions/{rs['minority_txid']}"))["status"] in ("included", "confirmed") and x, 120, 1, "re-inclusion")
        return {"status": t["status"], "block_height": t["block_height"]}
    rec.step("Disconnected-branch transaction re-included on the winning chain exactly once", reincluded)

    # ---------------------------------------------------------------- malicious peer
    g = json.loads(net.genesis_path.read_text())
    gh = bytes.fromhex(net.genesis_hash)
    n0 = net.node("node0")

    def malformed():
        p = faults.RawPeer("127.0.0.1", n0["p2p_port"], g["chain_id"], gh)
        p.handshake()
        p.send_block_bytes(b"\x00\x01garbage" * 10)
        why = p.closed_by_peer()
        bans = get(net.api("node0") + "/v1/peers")["bans"]
        return {"disconnect_reason": why, "banned_ids": [b["key"][:16] for b in bans]}
    rec.step("Malformed block from an authenticated peer: rejected, peer banned", malformed, lambda e: "banned" in e["disconnect_reason"])

    def bad_target():
        tip = get(net.api("node0") + "/v1/blocks/latest")
        limit = bytes.fromhex(g["consensus"]["pow"]["pow_limit"])
        hdr = faults.mine_header(g["chain_id"], tip["height"] + 1, bytes.fromhex(tip["id"]), tip["timestamp_ms"] + 1000, b"\x11" * 20, limit)
        p = faults.RawPeer("127.0.0.1", n0["p2p_port"], g["chain_id"], gh)
        p.handshake()
        p.send_block_bytes(faults.block_bytes(hdr))
        why = p.closed_by_peer()
        still = get(net.api("node0") + "/v1/blocks/latest")
        return {"disconnect_reason": why, "tip_unchanged_by_injection": still["proposer"] != "aurd1zyg3zyg3zyg3zyg3zyg3zyg3zyg3zyg3pnquzu"}
    rec.step("Block with an easier-than-required target (valid PoW for the wrong target): rejected, peer banned", bad_target,
             lambda e: "target" in e["disconnect_reason"] or "banned" in e["disconnect_reason"])

    def no_work():
        tip = get(net.api("node0") + "/v1/blocks/latest")
        target = bytes.fromhex(get(net.api("node0") + "/v1/consensus/status")["target"])
        nonce = 0
        while True:
            hdr = faults.pow_header(g["chain_id"], tip["height"] + 1, bytes.fromhex(tip["id"]), tip["timestamp_ms"] + 1000, b"\x22" * 20, target, nonce)
            if int.from_bytes(faults.pow_hash(hdr), "big") > int.from_bytes(target, "big"):
                break
            nonce += 1
        p = faults.RawPeer("127.0.0.1", n0["p2p_port"], g["chain_id"], gh)
        p.handshake()
        p.send_block_bytes(faults.block_bytes(hdr))
        return {"disconnect_reason": p.closed_by_peer()}
    rec.step("Block whose hash does not meet its target: rejected, peer banned", no_work, lambda e: "banned" in e["disconnect_reason"])

    def oversized():
        p = faults.RawPeer("127.0.0.1", n0["p2p_port"], g["chain_id"], gh)
        p.handshake()
        import struct
        p.s.sendall(struct.pack(">I", 0x7FFFFFFF))  # claims a 2 GiB frame
        why = p.closed_by_peer()
        alive = try_get(net.api("node0") + "/v1/health") is not None
        return {"result": why, "node_still_healthy": alive}
    rec.step("Oversized length prefix (2 GiB frame claim): connection dropped without allocation, node unaffected", oversized, lambda e: e["node_still_healthy"])

    # ---------------------------------------------------------------- restart, delay, crash
    def restart():
        h = heights(net, ["node1"])["node1"]
        net.stop_node("node1")
        time.sleep(4)
        net.start_node("node1")
        log = (net.node_dir("node1") / "logs" / "node.log").read_text()
        wait_for(lambda: tips_agree(net, ["node0", "node1"]), 120, 1, "node1 catch-up")
        return {"height_before": h, "after": heights(net, ["node1"]), "state_root_verified_on_start": "state root verified" in log}
    rec.step("Restart a node: state root verified on start, catches up", restart, lambda e: e["state_root_verified_on_start"])

    def delay():
        net.stop_node("node2")
        net.start_node("node2", env={"AUREOM_FAULT_P2P_DELAY_MS": "400"})
        time.sleep(20)
        hs = heights(net)
        h = get(net.api("node2") + "/v1/health")
        ok = wait_for(lambda: tips_agree(net, ["node0", "node1", "node2"], 3), 90, 1, "agreement under delay")
        net.stop_node("node2")
        net.start_node("node2")
        return {"heights_under_delay": hs, "fault_alert": [a for a in h["alerts"] if a["code"] == "fault_injection_active"], "agreement": ok}
    rec.step("Delayed messages (400 ms on every node2 send): network keeps agreeing", delay, lambda e: bool(e["agreement"]))

    def crash():
        h = heights(net, ["node1"])["node1"]
        net.stop_node("node1")
        target = h + 3
        net.start_node("node1", env={"AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT": str(target)}, wait=False)
        wait_for(lambda: not net.is_running("node1"), 120, 0.5, "injected abort")
        log = (net.node_dir("node1") / "logs" / "node.log").read_text()
        net.pidfile("node1").unlink(missing_ok=True)
        net.start_node("node1")
        import re
        tail = (net.node_dir("node1") / "logs" / "node.log").read_text().split("FAULT INJECTION: aborting")[-1]
        m = re.search(r"chain loaded at height (\d+)", tail)
        h_after_restart = int(m.group(1)) if m else None
        wait_for(lambda: tips_agree(net, ["node0", "node1"]), 120, 1, "recovery")
        return {"abort_height": target, "aborted": "FAULT INJECTION: aborting" in log, "height_on_restart": h_after_restart,
                "recovered": heights(net, ["node0", "node1"])}
    rec.step("Database interruption: process aborted inside the commit of a block; restart recovers last committed state", crash,
             lambda e: e["aborted"] and e["height_on_restart"] == e["abort_height"] - 1)

    # ---------------------------------------------------------------- join, backup, snapshot, replay
    def join():
        net.add_node("node3")
        net.start_node("node3")
        ok = wait_for(lambda: tips_agree(net, ["node0", "node3"]), 180, 1, "node3 sync")
        s = get(net.api("node3") + "/v1/sync")
        return {"agreement": ok, "sync": {k: s[k] for k in ("local_height", "best_known_height", "trust_anchor", "validation")}}
    rec.step("Synchronise a new node from genesis (full validation)", join, lambda e: bool(e["agreement"]))

    snapshot_steps(rec, net, "node0")

    def backup_restore():
        b = net.backup("node2")
        time.sleep(3)
        net.stop_node("node2")
        db = net.node_dir("node2") / "data" / "chain.redb"
        db.write_bytes(b"corrupted")
        bad_start = None
        try:
            net.start_node("node2")
        except Exception as e:  # noqa: BLE001
            bad_start = str(e)[:200]
        net.stop_node("node2", kill=True)
        r = net.restore("node2", b["backup"])
        net.start_node("node2")
        wait_for(lambda: tips_agree(net, ["node0", "node2"]), 120, 1, "restored node sync")
        return {"backup": {k: b[k] for k in ("tip_height",)}, "corrupt_db_refused": bad_start is not None, "restore": r, "heights": heights(net)}
    rec.step("Back up, corrupt the database (refused on start), restore with checksum verification, resync", backup_restore,
             lambda e: e["corrupt_db_refused"] and e["restore"]["verified_checksums"] >= 1)

    def replay():
        snap = net.snapshot("node1")
        time.sleep(6)
        net.stop_node("node1")
        r = net.replay("node1", snap["path"])
        v = net.verify_chain("node1")
        net.start_node("node1")
        return {"replay": r, "verify_chain": v}
    rec.step("Replay from a validated snapshot and full-chain re-execution audit", replay,
             lambda e: e["replay"]["stored_state_matched"] and e["verify_chain"]["ok"])

    explorer_steps(rec, net, w, st["txid"])

    def difficulty():
        c = get(w.api + "/v1/consensus/status")
        return {k: c[k] for k in ("height", "target", "difficulty", "target_block_time_ms", "retarget_interval", "recent_block_times_ms")}
    rec.step("Difficulty adjustment observed (target retargeted from genesis value)", difficulty,
             lambda e: e["target"] != json.loads(net.genesis_path.read_text())["consensus"]["pow"]["initial_target"])
    net.down()
    return rec.save()
