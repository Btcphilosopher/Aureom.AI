"""PoS and PoA demonstrations on CometBFT: quorum behaviour, validator-set changes,
downtime jailing, governance, key rotation, crash recovery, sync, backup and replay."""
from __future__ import annotations

import json
import shutil
import time

from .. import faults
from ..util import cli, get, read_json, try_get, wait_for, write_json
from ..wallet import Wallet
from .common import Recorder, api_permission_steps, common_tx_steps, explorer_steps, fresh, heights, snapshot_steps, tips_agree, wait_height

U = 10**6


def advancing(net, node, blocks=3, timeout=30):
    h0 = heights(net, [node])[node]
    wait_for(lambda: heights(net, [node])[node] >= h0 + blocks, timeout, 0.5, f"{node} +{blocks} blocks")
    return {"from": h0, "to": heights(net, [node])[node]}


def stalled(net, node, seconds=12):
    h0 = heights(net, [node])[node]
    time.sleep(seconds)
    h1 = heights(net, [node])[node]
    return {"height_before": h0, "height_after": h1, "seconds": seconds, "advanced": h1 - h0}


def participation(net, node):
    c = get(net.api(node) + "/v1/consensus/status")
    return c["last_commit"] | {"total_power_now": c["total_power"]}


def setup(rec, profile, d):
    net = fresh(d, profile)
    rec.step("Generate configuration and keys (accounts, CometBFT node + validator keys)", lambda: {"keys": len(net.create_all_keys())})
    rec.step("Build genesis; validate genesis and CometBFT genesis consistency across all nodes",
             lambda: {**net.build_genesis(), "validation": [c for c in net.validate()["checks"] if "CometBFT" in c["check"] or "shared" in c["check"]], "ok": net.validate()["ok"]},
             lambda e: e["ok"])
    rec.step("Launch four validators", lambda: [x["status"] for x in net.up()])
    rec.step("Validators commit blocks and agree", lambda: wait_for(lambda: min(heights(net).values()) >= 5 and tips_agree(net, [n["name"] for n in net.nodes()]), 90, 1, "agreement"))
    return net


def quorum_steps(rec, net, unit_power):
    rec.step("Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing",
             lambda: {"stopped": net.stop_node("node3"), "progress": advancing(net, "node0", 3), "last_commit": participation(net, "node0")},
             lambda e: e["last_commit"]["signed_power"] * 3 > e["last_commit"]["total_power"] * 2)
    rec.step("Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept)",
             lambda: {"stopped": net.stop_node("node2"), "observation": stalled(net, "node0", 12),
                      "round_state": get(net.api("node0") + "/v1/consensus/status")["round_state"]},
             lambda e: e["observation"]["advanced"] <= 1)
    rec.step("Restart the 2nd validator: quorum restored, commits resume",
             lambda: {"started": net.start_node("node2")["status"], "progress": advancing(net, "node0", 3, 60)})


def common_bft_tail(rec, net, w):
    def pause():
        pid = read_json(net.pidfile("node1"))["cometbft"]
        h0 = heights(net, ["node0"])["node0"]
        faults.pause(pid, 6)
        h1 = heights(net, ["node0"])["node0"]
        wait_for(lambda: tips_agree(net, ["node0", "node1"]), 60, 1, "node1 catch-up")
        return {"node0_height_during_pause": [h0, h1], "node1_caught_up": heights(net, ["node0", "node1"])}
    rec.step("Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up", pause)

    def crash():
        h = heights(net, ["node1"])["node1"]
        net.stop_node("node1")
        target = h + 3
        net.start_node("node1", env={"AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT": str(target)}, wait=False)
        pids = read_json(net.pidfile("node1"))
        from ..network import _alive
        wait_for(lambda: not _alive(pids["app"]), 90, 0.5, "injected abort")
        net.stop_node("node1", kill=True)
        log = (net.node_dir("node1") / "logs" / "node.log").read_text()
        net.start_node("node1")
        import re
        tail = (net.node_dir("node1") / "logs" / "node.log").read_text().split("FAULT INJECTION: aborting")[-1]
        m = re.search(r"application state at height (\d+)", tail)
        wait_for(lambda: tips_agree(net, ["node0", "node1"]), 90, 1, "recovery")
        return {"abort_height": target, "aborted": "FAULT INJECTION: aborting" in log, "app_height_on_restart": int(m.group(1)) if m else None,
                "after": heights(net, ["node0", "node1"]), "note": "CometBFT handshake replayed the uncommitted block to the application"}
    rec.step("Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers", crash,
             lambda e: e["aborted"] and e["app_height_on_restart"] == e["abort_height"] - 1)

    def restart():
        net.stop_node("node2")
        time.sleep(3)
        net.start_node("node2")
        log = (net.node_dir("node2") / "logs" / "node.log").read_text()
        wait_for(lambda: tips_agree(net, ["node0", "node2"]), 60, 1, "node2")
        return {"state_root_verified_on_start": "state root verified" in log, "heights": heights(net, ["node0", "node2"])}
    rec.step("Restart a validator: state root verified against committed app hash; rejoins", restart, lambda e: e["state_root_verified_on_start"])

    snapshot_steps(rec, net, "node0")

    def backup_restore():
        b = net.backup("node2")
        time.sleep(3)
        net.stop_node("node2")
        (net.node_dir("node2") / "data" / "chain.redb").write_bytes(b"corrupted")
        refused = None
        try:
            net.start_node("node2")
        except Exception as e:  # noqa: BLE001
            refused = str(e)[:160]
        net.stop_node("node2", kill=True)
        r = net.restore("node2", b["backup"])
        net.start_node("node2")
        wait_for(lambda: tips_agree(net, ["node0", "node2"]), 120, 1, "restored node")
        return {"backup_height": b["tip_height"], "corrupt_db_refused": refused is not None, "restore": r, "heights": heights(net)}
    rec.step("Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up", backup_restore,
             lambda e: e["corrupt_db_refused"] and e["restore"]["verified_checksums"] >= 1)

    def replay():
        snap = net.snapshot("node1")
        time.sleep(5)
        net.stop_node("node1")
        r = net.replay("node1", snap["path"])
        v = net.verify_chain("node1")
        net.start_node("node1")
        return {"replay": r, "verify_chain": v}
    rec.step("Replay stored blocks from a validated snapshot; full re-execution audit from genesis", replay,
             lambda e: e["replay"]["stored_state_matched"] and e["verify_chain"]["ok"])


def run_pos(d, out):
    rec = Recorder("pos", out)
    net = setup(rec, "pos", d)
    w = Wallet(net, "node0")
    st = common_tx_steps(rec, net, w)
    api_permission_steps(rec, net)
    rec.step("Finality: committed transaction reported as finalised (BFT), not probabilistic",
             lambda: {k: get(f"{w.api}/v1/transactions/{st['txid']}")[k] for k in ("status", "finality")}, lambda e: e["status"] == "finalised")

    def rewards():
        a0 = int(w.account("op1")["native"]["total"])
        advancing(net, "node0", 3)
        a1 = int(w.account("op1")["native"]["total"])
        sup = get(w.api + "/v1/supply")
        return {"op1_balance_delta": a1 - a0, "minted_so_far": sup["minted"], "reconciled": sup["reconciled"]}
    rec.step("Scheduled block rewards paid to signing validators; supply reconciles", rewards, lambda e: e["op1_balance_delta"] > 0 and e["reconciled"])

    common_bft_tail(rec, net, w)
    quorum_steps(rec, net, 10_000)

    def jailed():
        v = wait_for(lambda: (x := next(v for v in get(w.api + "/v1/validators")["validators"] if v["moniker"] == "node3"))["status"] == "jailed" and x, 240, 2,
                     "downtime jail of node3")
        return {"node3": {k: v[k] for k in ("status", "power", "bonded", "jailed_until")}, "total_power": get(w.api + "/v1/validators")["total_power"],
                "slash_events": [e for e in get(w.api + "/v1/events?kind=slash")["events"]][:2]}
    rec.step("Downtime: node3 (offline) exceeds missed-block limit -> jailed, 1% downtime penalty, removed from set (not tombstoned)", jailed,
             lambda e: e["node3"]["status"] == "jailed" and e["slash_events"] and e["slash_events"][0]["attrs"]["reason"] == "downtime")

    def unjail():
        net.start_node("node3")
        wait_for(lambda: tips_agree(net, ["node0", "node3"]), 120, 1, "node3 sync")
        early = w.send("op3", {"type": "validator_unjail"})
        v = next(v for v in get(w.api + "/v1/validators")["validators"] if v["moniker"] == "node3")
        wait_height(net, "node0", v["jailed_until"] + 1, 240)
        late = w.send("op3", {"type": "validator_unjail"})
        wait_for(lambda: next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node3")["status"] == "active", 60, 1, "re-entry")
        v2 = next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node3")
        return {"unjail_before_expiry": early["receipt"]["error"], "unjail_after_expiry": late["receipt"]["status"], "node3_now": {k: v2[k] for k in ("status", "power")}}
    rec.step("Unjail: refused before jail period ends; accepted after; validator re-enters the set", unjail,
             lambda e: e["unjail_before_expiry"] == "JAILED" and e["unjail_after_expiry"] == "success" and e["node3_now"]["status"] == "active")

    def join_and_stake():
        n4 = net.add_node("node4")
        net.start_node("node4")
        wait_for(lambda: tips_agree(net, ["node0", "node4"]), 180, 1, "node4 sync")
        net.ensure_account_key("op4", "operator")
        w.transfer("alice", "op4", 25_000 * U)
        pub = read_json(net.dir / "public" / "nodes" / "node4.json")
        r = w.send("op4", {"type": "validator_create", "consensus_pubkey": pub["consensus_pubkey"], "self_bond": str(20_000 * U), "moniker": "node4"})
        v = wait_for(lambda: (x := next((v for v in get(w.api + "/v1/validators")["validators"] if v["moniker"] == "node4"), None)) and x["status"] == "active" and x, 120, 1, "epoch")
        wait_for(lambda: next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node4")["signed_last_block"], 60, 1, "node4 signing")
        return {"create_receipt": r["receipt"]["status"], "included_at": r["block_height"], "node4": {k: v[k] for k in ("status", "power", "bonded")},
                "epoch_length": 20, "participation": participation(net, "node0"), "sync": get(net.api("node4") + "/v1/sync")["trust_anchor"]}
    rec.step("New node synchronises, its operator bonds stake; it joins the validator set at the next epoch and signs", join_and_stake,
             lambda e: e["create_receipt"] == "success" and e["node4"]["status"] == "active" and e["node4"]["power"] == 20_000)

    def unbond():
        r = w.send("op4", {"type": "validator_unbond", "amount": str(5_000 * U)})
        v = next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node4")
        acct = w.account("op4")["native"]
        return {"receipt": r["receipt"]["status"], "unbonding": acct["unbonding"], "bonded": acct["bonded"], "power_now": v["power"],
                "completes_at": next(e for e in r["receipt"]["events"] if e["kind"] == "stake")["attrs"]["completes_at"]}
    rec.step("Unbonding: stake moves to an unbonding entry (still slashable) that pays out after unbonding_period_blocks", unbond,
             lambda e: e["receipt"] == "success" and int(e["unbonding"]) == 5_000 * U)

    explorer_steps(rec, net, w, st["txid"])
    net.down()
    return rec.save()


def run_poa(d, out):
    rec = Recorder("poa", out)
    net = setup(rec, "poa", d)
    w = Wallet(net, "node0")
    st = common_tx_steps(rec, net, w)
    api_permission_steps(rec, net)
    rec.step("No staking on PoA: validator_create rejected at submission",
             lambda: (lambda u: __import__("chainworks.util", fromlist=["http"]).http("POST", w.api + "/v1/transactions", {"tx": json.loads(w.sign("bob", u).read_text())["signed_hex"]}))(
                 w.prepare("bob", {"type": "validator_create", "consensus_pubkey": read_json(net.dir / "public" / "nodes" / "node0.json")["consensus_pubkey"], "self_bond": "1", "moniker": "x"})),
             lambda e: e[0] == 400 and e[1]["error"]["code"] == "unsupported_action")
    common_bft_tail(rec, net, w)
    quorum_steps(rec, net, 10)
    rec.step("Restart the 4th authority", lambda: {"started": net.start_node("node3")["status"], "sync": wait_for(lambda: tips_agree(net, ["node0", "node3"]), 90, 1, "node3")})

    n4 = net.add_node("node4")
    net.start_node("node4")
    net.ensure_account_key("op4", "operator")
    pub4 = read_json(net.dir / "public" / "nodes" / "node4.json")
    add = {"kind": "add_authority", "operator": net.address("op4"), "consensus_pubkey": pub4["consensus_pubkey"], "power": 10, "moniker": "node4"}

    def unauthorised():
        h = heights(net, ["node0"])["node0"]
        r = w.send("bob", {"type": "gov_propose", "proposal": add, "expiry_height": h + 200})
        vs = get(w.api + "/v1/validators")
        return {"receipt": r["receipt"]["status"], "error": r["receipt"]["error"], "validators": len([v for v in vs["validators"] if v["status"] == "active"])}
    rec.step("Unauthorised validator-set change (non-authority proposes adding an authority): rejected by the state machine", unauthorised,
             lambda e: e["error"] == "UNAUTHORIZED" and e["validators"] == 4)

    def authorised():
        wait_for(lambda: tips_agree(net, ["node0", "node4"]), 120, 1, "node4 sync")
        h = heights(net, ["node0"])["node0"]
        r0 = w.send("op0", {"type": "gov_propose", "proposal": add, "expiry_height": h + 300})
        pid = int(next(e for e in r0["receipt"]["events"] if e["kind"] == "gov")["attrs"]["proposal"])
        r1 = w.send("op1", {"type": "gov_approve", "proposal_id": pid})
        mid = next(p for p in get(w.api + "/v1/proposals")["proposals"] if p["id"] == pid)
        r_dup = w.send("op1", {"type": "gov_approve", "proposal_id": pid})
        r2 = w.send("op2", {"type": "gov_approve", "proposal_id": pid})
        done = next(p for p in get(w.api + "/v1/proposals")["proposals"] if p["id"] == pid)
        wait_for(lambda: next((x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node4"), {}).get("signed_last_block"), 60, 1, "node4 signing")
        return {"after_2_of_4": {"status": mid["status"], "approving_power": mid["approving_power"], "total_power": mid["total_power"]},
                "duplicate_approval": r_dup["receipt"]["error"], "after_3_of_4": done["status"], "executed_height": done["executed_height"],
                "validators_active": len([v for v in get(w.api + "/v1/validators")["validators"] if v["status"] == "active"]),
                "participation": participation(net, "node0")}
    rec.step("Authorised validator-set change: authority proposes, others approve with separately signed txs; executes at > 2/3; node4 signs", authorised,
             lambda e: e["after_2_of_4"]["status"] == "pending" and e["after_3_of_4"] == "executed" and e["validators_active"] == 5 and e["duplicate_approval"] == "ALREADY_EXISTS")

    def rotate():
        newkey = net.dir / "secrets" / "nodes" / "node1" / "rotated_priv_validator_key.json"
        k = cli("keys", "create", "--role", "validator", "--out", newkey)
        r = w.send("op1", {"type": "validator_rotate_key", "new_consensus_pubkey": k["consensus_pubkey"]})
        h = r["block_height"]
        wait_height(net, "node0", h + 3, 60)
        v = next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node1")
        signing_before_swap = v["signed_last_block"]
        net.stop_node("node1")
        cfg = net.node_dir("node1") / "cometbft"
        shutil.copy2(newkey, cfg / "config" / "priv_validator_key.json")
        write_json(cfg / "data" / "priv_validator_state.json", {"height": "0", "round": 0, "step": 0})
        pubf = net.dir / "public" / "nodes" / "node1.json"
        p = read_json(pubf)
        p.update({"consensus_pubkey": k["consensus_pubkey"], "consensus_address": k["consensus_address"]})
        write_json(pubf, p)
        net.start_node("node1")
        v2 = wait_for(lambda: (x := next(x for x in get(w.api + "/v1/validators")["validators"] if x["moniker"] == "node1"))["signed_last_block"] and x, 90, 1, "node1 signing with new key")
        return {"rotate_receipt": r["receipt"]["status"], "signing_with_old_key_after_activation": signing_before_swap,
                "new_key_active": v2["consensus_pubkey"] == k["consensus_pubkey"], "signing_with_new_key": v2["signed_last_block"],
                "participation": participation(net, "node0")}
    rec.step("Key rotation: authority rotates its consensus key (signed by operator key); old key stops counting; node restarts with new key and signs", rotate,
             lambda e: e["rotate_receipt"] == "success" and e["new_key_active"] and e["signing_with_new_key"] and not e["signing_with_old_key_after_activation"])

    explorer_steps(rec, net, w, st["txid"])
    net.down()
    return rec.save()
