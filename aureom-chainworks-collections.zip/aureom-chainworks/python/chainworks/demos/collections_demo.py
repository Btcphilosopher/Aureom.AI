"""AUREOM COLLECTIONS demonstration on a live 3-node proof-of-work development network.

Fictional collection "Tidewater Lanterns" by the fictional studio "Lumen Atelier":
original procedurally generated illustrations (chainworks/nft/art.py, CC BY 4.0).

Every step records the evidence it observed; nothing is reported that was not observed.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time

from ..nft import art
from ..nft import metadata as md
from ..nft.service import Collections
from ..util import cli, get, http, read_json, try_get, wait_for
from .common import Recorder, fresh, heights, tips_agree
from .pow import admin

U = 10**6


def run(d, out):
    rec = Recorder("collections", out)
    net = fresh(d, "pow", name="Aureom Development Network (Collections)", chain_id="aureom-collections-1", base_port=18700)
    s = net.spec
    s["accounts"] += [
        {"label": "artist", "role": "account", "allocation": str(50_000 * U)},      # Lumen Atelier: creator, mint authority, metadata admin
        {"label": "collector", "role": "account", "allocation": str(50_000 * U)},
        {"label": "buyer", "role": "account", "allocation": str(50_000 * U)},
        {"label": "buyer2", "role": "account", "allocation": str(50_000 * U)},
        {"label": "courier", "role": "account", "allocation": str(1_000 * U)},      # a narrowly approved operator
        {"label": "mallory", "role": "account", "allocation": str(1_000 * U)},      # unauthorised actor
        {"label": "platform", "role": "account", "allocation": None},               # marketplace fee recipient
    ]
    s["consensus"]["pow"]["confirmations_recommended"] = 3  # demo pacing; settlement stays probabilistic
    s["modules"] = {"collections": {"activation_height": 0, "marketplace": True, "marketplace_fee_bps": 250, "marketplace_fee_recipient": "platform"}}
    net.save_spec(s)
    ctx: dict = {}

    def launch():
        g = net.build_genesis()
        v = net.validate()
        net.up()
        wait_for(lambda: min(heights(net).values()) >= 3 and tips_agree(net, ["node0", "node1", "node2"], 1), 120, 1, "launch")
        n = get(net.api("node0") + "/v1/network")
        return {"genesis_hash": g["genesis_hash"], "validation_ok": v["ok"], "modules": n["modules"], "heights": heights(net)}
    rec.step("Launch a 3-node PoW development network with the collections module and demo marketplace enabled", launch,
             lambda e: e["validation_ok"] and e["modules"]["collections"]["enabled"] and e["modules"]["collections"]["marketplace"])

    c = Collections(net, "node0")
    ctx["c"] = c
    gh = net.genesis_hash
    cid_net = net.spec["chain_id"]
    rights = md.rights_block("Lumen Atelier (fictional studio)", "CC-BY-4.0",
                             "Original digital illustration by Lumen Atelier (fictional), licensed under CC BY 4.0. Token ownership conveys no copyright.")

    # ---------------------------------------------------------------- 2. media + metadata
    def upload():
        art_svg = c.add_media(art.collection_svg(), "tidewater.svg", "Collection artwork: nine glowing lanterns drifting on a dark harbour under a pale moon.", licence="CC-BY-4.0")
        pdf = art.statement_pdf(["Tidewater Lanterns - rights statement (fictional demonstration)", "Rights holder: Lumen Atelier (fictional studio)",
                                 "Licence: CC BY 4.0 for the illustrations.", "Owning a token does not transfer copyright or any physical object."])
        pdf_m = c.add_media(pdf, "rights-statement.pdf", licence="CC-BY-4.0")
        chime = c.add_media(art.chime_wav(), "harbour-bell.wav", transcript="A single soft harbour bell chime fading over about one second.", licence="CC-BY-4.0")
        coll_doc = md.collection_document(name="Tidewater Lanterns", description="Original procedural illustrations of lanterns on tidal water by the fictional Lumen Atelier.",
                                          slug="tidewater-lanterns", chain_id=cid_net, genesis_hash=gh, artwork=c.media_ref(art_svg["sha256"]), creator="Lumen Atelier (fictional)", rights=rights)
        rights_doc = md.rights_document(holder="Lumen Atelier (fictional studio)", licence="CC-BY-4.0", collection_slug="tidewater-lanterns",
                                        statement="Illustrations licensed CC BY 4.0; token ownership conveys no copyright and no physical object.",
                                        contact_policy="requests via the studio's published channel (fictional); no personal data on chain")
        ctx["coll_meta"] = c.put_metadata(coll_doc, "tidewater-lanterns")
        ctx["rights_meta"] = c.put_metadata(rights_doc, "tidewater-lanterns")
        ctx["tokens"] = {}
        for i in range(1, 13):
            png, tr = art.illustration(i)
            m = c.add_media(png, f"lantern-{i:02d}.png", art.alt_text(i, tr), licence="CC-BY-4.0")
            extra = [c.media_ref(chime["sha256"], "audio")] if i == 1 else []
            if i == 1:
                extra.append(c.media_ref(pdf_m["sha256"], "document"))
            doc = md.token_document(name=art.TITLES[i - 1], description=f"Tidewater Lanterns no. {i}: {art.alt_text(i, tr)}", collection_slug="tidewater-lanterns",
                                    chain_id=cid_net, genesis_hash=gh, token_id=i, image=c.media_ref(m["sha256"]), media=extra, attributes=tr["attributes"],
                                    creator="Lumen Atelier (fictional)", rights=rights)
            ctx["tokens"][i] = c.put_metadata(doc, "tidewater-lanterns", i)
        bad = {}
        for name, data, alt in (("evil.svg", b'<svg xmlns="http://www.w3.org/2000/svg"><script>steal()</script></svg>', "x" * 20), ("photo.png", b"GIF89a" + b"\x01\x00\x01\x00" + b"\x00" * 20, "a photo of something"),
                                ("noalt.png", art.illustration(99)[0], None)):
            try:
                c.add_media(data, name, alt)
                bad[name] = "ACCEPTED (unexpected)"
            except Exception as e:  # noqa: BLE001
                bad[name] = str(e)[:140]
        try:
            md.validate(md.token_document(name="x", description="ping me at someone@example.com", collection_slug="t", chain_id=cid_net, genesis_hash=gh, token_id=99,
                                          image=c.media_ref(art_svg["sha256"]), creator="x", rights=rights))
            bad["metadata with e-mail"] = "ACCEPTED (unexpected)"
        except md.MetadataError as e:
            bad["metadata with e-mail"] = str(e)[:140]
        onchain_before = get(net.api("node0") + "/v1/nft/collections")["collections"]
        t1 = ctx["tokens"][1]
        return {"collection_metadata": ctx["coll_meta"]["sha256"], "token_metadata_docs": len(ctx["tokens"]), "token1": {"uri": t1["uri"], "sha256": t1["sha256"], "preview": t1["preview"]},
                "media_types": sorted({x["mime"] for x in (art_svg, pdf_m, chime)} | {"image/png"}), "rejected_uploads": bad,
                "collections_on_chain_after_upload": len(onchain_before), "note": "an upload is not a mint: nothing exists on chain yet"}
    rec.step("Upload media and metadata: content-type sniffing, checksums, alt text, rights; unsafe/invalid uploads rejected; nothing on chain yet", upload,
             lambda e: e["token_metadata_docs"] == 12 and all("ACCEPTED" not in v for v in e["rejected_uploads"].values()) and e["collections_on_chain_after_upload"] == 0)

    def storage():
        r = c.storage_check()
        # tamper with one stored copy, detect it, restore it
        sha = ctx["tokens"][3]["preview"]["image"]["sha256"]
        p = c.local.path(sha)
        orig = p.read_bytes()
        p.write_bytes(orig[:-10] + b"tampered!!")
        tampered = c.storage_check()
        p.write_bytes(orig)
        after = c.storage_check()
        ipfs = c.ipfs.available()
        return {"locations_checked": r["checked"], "healthy": r["healthy"], "tamper_detected": [x["detail"] for x in tampered["problems"]],
                "after_restore_problems": len(after["problems"]), "ipfs_node_available": ipfs,
                "maintainers": sorted({h["maintainer"] for h in c.storage_health()}),
                "note": "IPFS integration is optional; with no IPFS node reachable nothing was pinned, and the demo does not claim IPFS persistence"}
    rec.step("Storage monitoring: re-fetch every stored copy, compare SHA-256, detect a tampered copy, record maintainer", storage,
             lambda e: e["healthy"] == e["locations_checked"] and len(e["tamper_detected"]) == 1 and e["after_restore_problems"] == 0)

    # ---------------------------------------------------------------- 1. collection
    def create():
        answers = {"slug": "tidewater-lanterns", "name": "Tidewater Lanterns", "collection_metadata": {"uri": ctx["coll_meta"]["uri"], "sha256": ctx["coll_meta"]["sha256"]},
                   "max_supply": 16, "mint_authority": "artist", "metadata_policy": "freezable", "metadata_admin": "artist", "owner_burn": True,
                   "royalty": {"recipient": "artist", "bps": 500}, "rights_holder": "Lumen Atelier (fictional studio)",
                   "rights": {"uri": ctx["rights_meta"]["uri"], "sha256": ctx["rights_meta"]["sha256"]}}
        r = c.create_collection("artist", answers)
        review = json.loads(r["request"]["review_json"])
        done = c.requests.run(r["request"]["request_id"], c.ix)
        col = c.collection("tidewater-lanterns")
        ctx["cid"] = col["collection_id"]
        return {"derived_before_signing": r["derived_collection_id"], "on_chain_id": col["collection_id"], "powers_shown_before_signing": r["administrative_powers"],
                "review_warnings": review["review"]["warnings"], "simulation": review["simulation"], "request_status": done["status"],
                "roles": col["roles"], "admin_powers": [p["power"] for p in col["administrative_powers"]], "pausable": col["spec"]["pausable"], "forced_transfer": col["spec"]["forced_transfer"]}
    rec.step("Create the collection: wizard -> administrative powers shown -> simulate -> sign (aureom-cli) -> submit -> confirm -> index", create,
             lambda e: e["derived_before_signing"] == e["on_chain_id"] and e["request_status"] == "indexed" and e["roles"]["admin"] is None
             and not e["pausable"] and not e["forced_transfer"] and e["simulation"]["status"] == "success")
    cid = ctx.get("cid")

    # ---------------------------------------------------------------- 3. mint
    def mint_one():
        t = ctx["tokens"][1]
        r = c.mint(cid, 1, "collector", t)
        r = c.requests.run(r["request_id"], c.ix)
        own = c.owner_of(cid, 1)
        again = c.mint(cid, 1, "collector", t)  # same idempotency key -> same request, no second tx
        return {"status": r["status"], "txid": r["txid"], "owner": own, "duplicate_request_deduplicated": again["deduplicated"] and again["request_id"] == r["request_id"],
                "history": [h["to_status"] for h in c.requests.history(r["request_id"])]}
    rec.step("Mint one token -> verify ownership on chain (authoritative) and in the index; duplicate mint request deduplicated", mint_one,
             lambda e: e["status"] == "indexed" and e["owner"]["owner"] == net.address("collector") and e["owner"]["index_agrees"] and e["duplicate_request_deduplicated"])

    def dup_onchain():
        # a *different* request for an already-minted id: the ledger itself refuses
        t = ctx["tokens"][1]
        r = c.requests.create("mint", "artist", {"type": "nft_mint", "collection": cid, "item": {"token_id": "1", "to": net.address("buyer"), "metadata": {"uri": t["uri"], "sha256": t["sha256"]}}}, "mint-again-different-key")
        v = c.requests.validate(r["request_id"])
        # bypass the simulation guard deliberately: sign and submit anyway, to show the chain's answer
        c.requests._move(r["request_id"], "validated", "demo: submitting despite failed simulation")
        rr = c.requests.run(r["request_id"], c.ix)
        return {"simulation": json.loads(v["review_json"])["simulation"], "on_chain_status": rr["status"], "error": rr.get("last_error"), "owner_unchanged": c.owner_of(cid, 1)["owner"]}
    rec.step("Unique identifiers: minting an existing token id fails in simulation and on chain (fee charged, owner unchanged)", dup_onchain,
             lambda e: e["simulation"]["error"] == "ALREADY_EXISTS" and e["on_chain_status"] == "failed" and e["owner_unchanged"] == net.address("collector"))

    def batch():
        rows = [{"token_id": i, "to": "collector" if i % 2 else "buyer2", "metadata_sha256": ctx["tokens"][i]["sha256"]} for i in range(2, 11)]
        bad_rows = rows + [{"token_id": 3, "to": "buyer", "metadata_sha256": ctx["tokens"][3]["sha256"]}, {"token_id": 40, "to": "nobody-here", "metadata_sha256": ctx["tokens"][4]["sha256"]},
                           {"token_id": 41, "to": "buyer", "metadata_sha256": "00" * 32}, {"token_id": 1, "to": "buyer", "metadata_sha256": ctx["tokens"][1]["sha256"]}]
        bad = c.batch_plan(cid, bad_rows, "lanterns-wave-1")
        big = c.batch_plan(cid, [{"token_id": 100 + i, "to": "buyer", "metadata_sha256": ctx["tokens"][2]["sha256"]} for i in range(20)], "too-many")
        plan = c.batch_plan(cid, rows, "lanterns-wave-1")
        try:
            c.batch_run(plan["plan_id"], approve="not-the-plan")
            unapproved = "ran (unexpected)"
        except Exception as e:  # noqa: BLE001
            unapproved = str(e)
        # split into chunks of 4 to show interruption and resume
        import chainworks.nft.service as svc
        old = svc.MAX_BATCH
        svc.MAX_BATCH = 4
        try:
            first = c.batch_run(plan["plan_id"], plan["plan_id"], stop_after=1)
            second = c.batch_run(plan["plan_id"], plan["plan_id"])
            third = c.batch_run(plan["plan_id"], plan["plan_id"])
        finally:
            svc.MAX_BATCH = old
        col = c.collection(cid)
        owners = {i: c.owner_of(cid, i)["owner"] for i in range(2, 11)}
        expected = {i: net.address("collector" if i % 2 else "buyer2") for i in range(2, 11)}
        return {"rejected_plan_problems": bad["problems"], "over_supply_plan": big["problems"], "unapproved_run": unapproved, "plan": {k: plan[k] for k in ("plan_id", "chunks", "per_recipient")},
                "interrupted": first, "resume": [x["status"] if "skipped" not in x else "skipped:" + x["skipped"] for x in second["chunks"]],
                "rerun": [x.get("skipped", x["status"]) for x in third["chunks"]], "minted_total": col["minted"], "owners_match_plan": owners == expected}
    rec.step("Reviewed batch minting: invalid plans rejected, approval required, interrupted run resumed, re-run mints nothing twice", batch,
             lambda e: len(e["rejected_plan_problems"]) == 4 and e["over_supply_plan"] and "approve" in e["unapproved_run"] and e["interrupted"]["interrupted"]
             and e["minted_total"] == 10 and e["owners_match_plan"] and all(x == "already done" for x in e["rerun"]))

    def drop():
        claims = [{"index": 0, "address": net.address("buyer"), "token_id": "11", "uri": ctx["tokens"][11]["uri"], "sha256": ctx["tokens"][11]["sha256"]},
                  {"index": 1, "address": net.address("buyer2"), "token_id": "12", "uri": ctx["tokens"][12]["uri"], "sha256": ctx["tokens"][12]["sha256"]}]
        f = c.home / "drop-claims.json"
        f.write_text(json.dumps(claims))
        tree = cli("drop-tree", "--genesis", net.genesis_path, "--claims", f, "--out", c.home / "drop-tree.json")
        proofs = read_json(c.home / "drop-tree.json")["claims"]
        nonce = c.w.account("artist")["nonce"]
        h = heights(net, ["node0"])["node0"]
        r = c.requests.create("drop", "artist", {"type": "nft_drop_create", "collection": cid, "merkle_root": tree["merkle_root"], "claim_deadline_height": h + 400, "max_claims": 2}, "drop:wave-2")
        r = c.requests.run(r["request_id"], c.ix)
        did = cli("derive", "--genesis", net.genesis_path, "--kind", "drop", "--creator", net.address("artist"), "--nonce", nonce)["drop_id"]
        claim = lambda who, p: {"type": "nft_drop_claim", "drop_id": did, "index": p["index"], "token_id": p["token_id"], "metadata": {"uri": p["uri"], "sha256": p["sha256"]}, "proof": p["proof"]}  # noqa: E731
        ok = c.requests.run(c.requests.create("drop", "buyer", claim("buyer", proofs[0]), "claim:0:buyer")["request_id"], c.ix)
        stolen = c.requests.create("drop", "mallory", claim("mallory", proofs[1]), "claim:1:mallory")
        stolen_v = c.requests.validate(stolen["request_id"])
        return {"drop": r["status"], "claim_by_eligible": ok["status"], "owner_11": c.owner_of(cid, 11)["owner"], "mallory_with_stolen_proof": stolen_v["status"],
                "mallory_error": json.loads(stolen_v["review_json"])["simulation"]["error"], "drop_state": get(f"{net.api('node0')}/v1/nft/drops/{did}")}
    rec.step("Optional claim-based distribution: Merkle drop, eligible claim mints, someone else's proof is refused", drop,
             lambda e: e["claim_by_eligible"] == "indexed" and e["owner_11"] == net.address("buyer") and e["mallory_error"] == "BAD_PROOF")

    # ---------------------------------------------------------------- 4/5. transfers
    def transfer():
        r = c.requests.create("transfer", "collector", {"type": "nft_transfer", "collection": cid, "token_id": "3", "to": net.address("buyer")}, "gift:3")
        r = c.requests.run(r["request_id"], c.ix)
        return {"status": r["status"], "owner_chain": c.owner_of(cid, 3)}
    rec.step("Transfer an asset (collector -> buyer), confirmed and indexed", transfer, lambda e: e["status"] == "indexed" and e["owner_chain"]["owner"] == net.address("buyer") and e["owner_chain"]["index_agrees"])

    def unauthorised():
        act = {"type": "nft_transfer", "collection": cid, "token_id": "5", "to": net.address("mallory")}
        r = c.requests.create("transfer", "mallory", act, "steal:5")
        v = c.requests.validate(r["request_id"])
        c.requests._move(r["request_id"], "validated", "demo: submit despite failed simulation to show the ledger's answer")
        rr = c.requests.run(r["request_id"], c.ix)
        out = c.db.execute("SELECT status, error FROM chain_tx_outcomes WHERE txid = ?", (rr["txid"],)).fetchone()
        return {"simulation_error": json.loads(v["review_json"])["simulation"]["error"], "on_chain": rr["status"], "receipt_error": rr["last_error"],
                "owner_still": c.owner_of(cid, 5)["owner"], "index_records_failure": dict(out) if out else None}
    rec.step("Reject an unauthorised transfer (mallory): refused in simulation and on chain; owner unchanged; failure indexed", unauthorised,
             lambda e: e["simulation_error"] == "UNAUTHORIZED" and e["on_chain"] == "failed" and e["owner_still"] == net.address("collector") and e["index_records_failure"]["error"] == "UNAUTHORIZED")

    # ---------------------------------------------------------------- 6. approvals
    def approvals():
        courier = net.address("courier")
        g = c.requests.run(c.requests.create("approve", "collector", {"type": "nft_approve", "collection": cid, "token_id": "7", "approved": courier, "expiry_height": 0}, "approve:7")["request_id"], c.ix)
        inspect = get(f"{net.api('node0')}/v1/nft/owners/{net.address('collector')}")
        tok_appr = inspect["token_approvals"]
        op_review = c.requests.create("operator", "collector", {"type": "nft_set_operator", "collection": cid, "operator": courier, "approved": True, "expiry_height": 0}, "op-review-only")
        op_warn = [w for w in c.w.review(c.requests.unsigned_path(op_review["request_id"]))["warnings"] if "COLLECTION-WIDE" in w]
        c.requests._move(op_review["request_id"], "rejected", "review only: the narrower single-token approval was used instead")
        rv = c.requests.run(c.requests.create("approve", "collector", {"type": "nft_approve", "collection": cid, "token_id": "7", "approved": None, "expiry_height": 0}, "revoke:7")["request_id"], c.ix)
        after = get(f"{net.api('node0')}/v1/nft/owners/{net.address('collector')}")["token_approvals"]
        use = c.requests.create("transfer", "courier", {"type": "nft_transfer", "collection": cid, "token_id": "7", "to": courier}, "courier-after-revoke")
        uv = c.requests.validate(use["request_id"])
        return {"grant": g["status"], "inspected_token_approvals": tok_appr, "operator_warning_in_review": op_warn, "revoke": rv["status"], "approvals_after_revoke": after,
                "courier_after_revoke": json.loads(uv["review_json"])["simulation"]["error"]}
    rec.step("Inspect and revoke an approval: single-token approval shown with its scope; collection-wide operator flagged as high risk; revoked approval no longer works", approvals,
             lambda e: e["grant"] == "indexed" and len(e["inspected_token_approvals"]) == 1 and e["operator_warning_in_review"] and e["revoke"] == "indexed"
             and e["approvals_after_revoke"] == [] and e["courier_after_revoke"] == "UNAUTHORIZED")

    # ---------------------------------------------------------------- 7/8. metadata
    def update_meta():
        png, tr = art.illustration(102)
        m = c.add_media(png, "lantern-02-restored.png", art.alt_text(102, tr), licence="CC-BY-4.0")
        doc = md.token_document(name=art.TITLES[1] + " (restored colours)", description="Revised colour grading by the studio.", collection_slug="tidewater-lanterns", chain_id=cid_net,
                                genesis_hash=gh, token_id=2, image=c.media_ref(m["sha256"]), attributes=tr["attributes"], creator="Lumen Atelier (fictional)", rights=rights)
        new = c.put_metadata(doc, "tidewater-lanterns", 2)
        act = {"type": "nft_update_metadata", "collection": cid, "token_id": "2", "metadata": {"uri": new["uri"], "sha256": new["sha256"]}, "expected_revision": 0}
        r = c.requests.run(c.requests.create("metadata_update", "artist", act, "meta:2:r1")["request_id"], c.ix)
        stale = c.requests.validate(c.requests.create("metadata_update", "artist", act | {"expected_revision": 0, "metadata": {"uri": new["uri"] + "?x", "sha256": "ab" * 32}}, "meta:2:stale")["request_id"])
        holder = c.requests.validate(c.requests.create("metadata_update", "buyer2", act | {"expected_revision": 1}, "meta:2:by-holder")["request_id"])
        t = c.token(cid, 2)
        return {"status": r["status"], "revision": t["revision"], "revisions": [(x["revision"], x["metadata"]["sha256"][:16]) for x in t["revisions"]],
                "stale_revision": json.loads(stale["review_json"])["simulation"]["error"], "update_by_token_holder": json.loads(holder["review_json"])["simulation"]["error"]}
    rec.step("Update permitted metadata: metadata admin creates revision 1 (history kept); stale revision and token holder are refused", update_meta,
             lambda e: e["status"] == "indexed" and e["revision"] == 1 and len(e["revisions"]) == 2 and e["stale_revision"] == "STALE" and e["update_by_token_holder"] == "UNAUTHORIZED")

    def freeze():
        pv = c.freeze_preview(cid, 2)
        act = {"type": "nft_freeze_metadata", "collection": cid, "scope": {"token_id": "2"}, "expected": pv["expected"]}
        rr = c.requests.create("metadata_freeze", "artist", act, "freeze:2")
        warn = c.w.review(c.requests.unsigned_path(rr["request_id"]))["warnings"]
        r = c.requests.run(rr["request_id"], c.ix)
        png, tr = art.illustration(202)
        m = c.add_media(png, "lantern-02-v3.png", art.alt_text(202, tr))
        doc = md.token_document(name="attempt after freeze", description="x", collection_slug="tidewater-lanterns", chain_id=cid_net, genesis_hash=gh, token_id=2,
                                image=c.media_ref(m["sha256"]), creator="Lumen Atelier (fictional)", rights=rights)
        new = c.put_metadata(doc, "tidewater-lanterns", 2)
        upd = {"type": "nft_update_metadata", "collection": cid, "token_id": "2", "metadata": {"uri": new["uri"], "sha256": new["sha256"]}, "expected_revision": 1}
        after = c.requests.create("metadata_update", "artist", upd, "meta:2:after-freeze")
        v = c.requests.validate(after["request_id"])
        c.requests._move(after["request_id"], "validated", "demo: submit despite failed simulation")
        onchain = c.requests.run(after["request_id"], c.ix)
        cpv = c.freeze_preview(cid)
        return {"preview_affects": [(a["ref"], a["metadata"]["sha256"][:16], a["document"]) for a in pv["affected"]], "expected_signed": pv["expected"], "review_warnings": warn,
                "freeze": r["status"], "token_frozen": c.token(cid, 2)["metadata_frozen"], "update_after_freeze_sim": json.loads(v["review_json"])["simulation"]["error"],
                "update_after_freeze_chain": onchain["last_error"], "collection_freeze_preview": {"expected_root": cpv["expected"], "tokens_affected": len(cpv["affected"]), "also": cpv["also"]}}
    rec.step("Freeze metadata: preview shows exact reference, freeze signs that hash; further changes rejected (simulation and chain)", freeze,
             lambda e: e["freeze"] == "indexed" and e["token_frozen"] and e["update_after_freeze_sim"] == "METADATA_FROZEN" and e["update_after_freeze_chain"] == "METADATA_FROZEN"
             and any("permanent" in w for w in e["review_warnings"]))

    # ---------------------------------------------------------------- 9. marketplace
    def sale():
        price = 1_234_567  # 1.234567 ADC, odd on purpose (rounding)
        nonce = c.w.account("collector")["nonce"]
        h = heights(net, ["node0"])["node0"]
        lr = c.requests.run(c.requests.create("listing_create", "collector", {"type": "nft_listing_create", "collection": cid, "token_id": "9", "price": str(price), "currency": "native", "expiry_height": h + 300}, "list:9")["request_id"], c.ix)
        lid = cli("derive", "--genesis", net.genesis_path, "--kind", "listing", "--creator", net.address("collector"), "--nonce", nonce)["listing_id"]
        listing = get(f"{net.api('node0')}/v1/nft/listings/{lid}")
        bal = lambda who: int(get(f"{net.api('node0')}/v1/accounts/{net.address(who)}")["native"]["total"])  # noqa: E731
        before = {w: bal(w) for w in ("collector", "artist", "platform", "buyer")}
        wrong_price = c.requests.validate(c.requests.create("listing_buy", "buyer", {"type": "nft_listing_buy", "listing_id": lid, "price": str(price - 1), "currency": "native"}, "buy:9:wrong")["request_id"])
        br = c.requests.create("listing_buy", "buyer", {"type": "nft_listing_buy", "listing_id": lid, "price": str(price), "currency": "native"}, "buy:9")
        buyer_review = c.w.review(c.requests.unsigned_path(br["request_id"]))["summary"]
        b = c.requests.run(br["request_id"], c.ix)
        after = {w: bal(w) for w in ("collector", "artist", "platform", "buyer")}
        sold = get(f"{net.api('node0')}/v1/nft/listings/{lid}")
        fee = int(json.loads(b["receipt_json"])["fee_paid"])
        royalty, platform = price * 500 // 10000, price * 250 // 10000
        expect = {"collector": price - royalty - platform, "artist": royalty, "platform": platform, "buyer": -(price + fee)}
        deltas = {w: after[w] - before[w] for w in after}
        # duplicate purchase by a second buyer and a replay of the exact signed bytes
        dup = c.requests.validate(c.requests.create("listing_buy", "buyer2", {"type": "nft_listing_buy", "listing_id": lid, "price": str(price), "currency": "native"}, "buy:9:second")["request_id"])
        code, resp = http("POST", net.api("node1") + "/v1/transactions", {"tx": c.requests.get(br["request_id"])["signed_hex"]})
        # replay on another network: change the chain id in the signed bytes -> wrong chain / bad signature
        sb = bytes.fromhex(c.requests.get(br["request_id"])["signed_hex"])
        forged = sb.replace(cid_net.encode(), b"aureom-collections-2")
        code2, resp2 = http("POST", net.api("node0") + "/v1/transactions", {"tx": forged.hex()})
        ctx["sale"] = {"listing": lid}
        return {"listing": {k: listing[k] for k in ("status", "price", "currency", "expiry_height", "seller")}, "buyer_review": buyer_review,
                "wrong_price_commitment": json.loads(wrong_price["review_json"])["simulation"]["error"], "buy": b["status"], "new_owner": c.owner_of(cid, 9)["owner"],
                "settlement": sold["settlement"], "balance_deltas": deltas, "expected_deltas": expect, "accounting_exact": deltas == expect,
                "duplicate_purchase": json.loads(dup["review_json"])["simulation"]["error"], "replay_same_bytes": {"http": code, "code": resp["error"]["code"]},
                "replay_other_chain": {"http": code2, "code": resp2["error"]["code"]}}
    rec.step("Fixed-price sale: seller listing, buyer review, atomic settlement (price, royalty, platform fee, network fee kept separate), duplicate and replay rejected", sale,
             lambda e: e["buy"] == "indexed" and e["new_owner"] == net.address("buyer") and e["accounting_exact"] and e["duplicate_purchase"] == "LISTING_INACTIVE"
             and e["wrong_price_commitment"] == "STALE" and e["replay_same_bytes"]["code"] == "bad_nonce" and e["replay_other_chain"]["code"] in ("wrong_chain", "bad_signature"))

    def listing_invalidation():
        nonce = c.w.account("buyer2")["nonce"]
        h = heights(net, ["node0"])["node0"]
        c.requests.run(c.requests.create("listing_create", "buyer2", {"type": "nft_listing_create", "collection": cid, "token_id": "4", "price": "500000", "currency": "native", "expiry_height": h + 300}, "list:4")["request_id"], c.ix)
        lid = cli("derive", "--genesis", net.genesis_path, "--kind", "listing", "--creator", net.address("buyer2"), "--nonce", nonce)["listing_id"]
        c.requests.run(c.requests.create("transfer", "buyer2", {"type": "nft_transfer", "collection": cid, "token_id": "4", "to": net.address("collector")}, "move:4")["request_id"], c.ix)
        st = get(f"{net.api('node0')}/v1/nft/listings/{lid}")["status"]
        v = c.requests.validate(c.requests.create("listing_buy", "buyer", {"type": "nft_listing_buy", "listing_id": lid, "price": "500000", "currency": "native"}, "buy:4")["request_id"])
        return {"listing_status_after_seller_moved_token": st, "buy_attempt": json.loads(v["review_json"])["simulation"]["error"]}
    rec.step("Settlement revalidates ownership: a listing is invalidated when the seller transfers the token away", listing_invalidation,
             lambda e: e["listing_status_after_seller_moved_token"] == "invalidated" and e["buy_attempt"] == "LISTING_INACTIVE")

    # ---------------------------------------------------------------- 11. gating, claims
    def gating():
        g = c.gate()
        buyer = net.address("buyer")
        ch = g.issue(buyer, cid, "lumen-atelier-members-room", "9")
        sig = c.sign_message("buyer", ch["message"])
        ok = g.verify(ch["nonce"], sig["pubkey"], sig["signature"])
        replay = g.verify(ch["nonce"], sig["pubkey"], sig["signature"])
        ch2 = g.issue(buyer, cid, "lumen-atelier-members-room", "9")
        msig = c.sign_message("mallory", ch2["message"])
        imp = g.verify(ch2["nonce"], msig["pubkey"], msig["signature"])
        ch3 = g.issue(net.address("mallory"), cid, "lumen-atelier-members-room")
        m3 = c.sign_message("mallory", ch3["message"])
        nonholder = g.verify(ch3["nonce"], m3["pubkey"], m3["signature"])
        return {"holder": ok, "replay": replay["reason"], "address_only_impersonation": imp["reason"], "valid_signer_without_token": nonholder["reason"]}
    rec.step("Token-gated access: signed single-use challenge + on-chain ownership; impersonation, replay and non-holders refused", gating,
             lambda e: e["holder"]["granted"] and "replay" in e["replay"] and "does not belong" in e["address_only_impersonation"] and "does not currently own" in e["valid_signer_without_token"])

    def claims():
        cl = c.claims()
        pdf_sha = hashlib.sha256(art.statement_pdf(["Studio attestation (fictional)", "Lumen Atelier created Tidewater Lanterns."])).hexdigest()
        a = cl.submit(cid, "verified_artist", "Lumen Atelier (fictional) created these illustrations", net.address("artist"),
                      [{"description": "studio attestation PDF (private storage)", "sha256": pdf_sha, "held_by": "Lumen Atelier registrar (fictional)"}])
        a = cl.review(a["claim_id"], "collections-reviewer (fictional)", "accepted", "attestation hash matches the document provided privately")
        b = cl.submit(cid, "physical_asset_backed", "Token 1 is backed by a framed print", net.address("artist"),
                      [{"description": "photo of a print (private)", "sha256": "ab" * 32, "held_by": "artist"}], "1")
        b = cl.review(b["claim_id"], "collections-reviewer (fictional)", "rejected", "no custody, insurance or redemption terms were evidenced")
        return {"verified_artist": a["display"], "physical_backing": b["display"], "on_chain": [a["on_chain"], b["on_chain"]]}
    rec.step("Authenticity claims need evidence and review (off-chain); a ledger entry is not proof of issuer claims", claims,
             lambda e: "not a chain fact" in e["verified_artist"] and "rejected" in e["physical_backing"] and e["on_chain"] == [False, False])

    # ---------------------------------------------------------------- reorg handling (PoW)
    def reorg():
        ids = {n: get(net.api(n) + "/v1/peers")["self_id"] for n in ("node0", "node1", "node2")}
        p2p = {n["name"]: f"127.0.0.1:{n['p2p_port']}" for n in net.nodes()}
        c2 = Collections(net, "node2", db_path=c.home / "collections-node2.db")
        c2.ix.sync()
        for a, b in (("node0", "node2"), ("node1", "node2"), ("node2", "node0"), ("node2", "node1")):
            admin(net, a, "/admin/v1/peer-actions", {"action": "ban", "peer": ids[b]})
            admin(net, a, "/admin/v1/peer-actions", {"action": "ban", "peer": p2p[b]})
        time.sleep(3)
        # collector signs two conflicting transfers of token 5 with the SAME nonce
        nonce = c.w.account("collector")["nonce"]
        to_minority = net.address("buyer2")
        to_majority = net.address("buyer")
        ua = c.w.prepare("collector", {"type": "nft_transfer", "collection": cid, "token_id": "5", "to": to_minority}, nonce=nonce)
        ub = c.w.prepare("collector", {"type": "nft_transfer", "collection": cid, "token_id": "5", "to": to_majority}, nonce=nonce)
        sa, sb = read_json(c.w.sign("collector", ua)), read_json(c.w.sign("collector", ub))
        http("POST", net.api("node2") + "/v1/transactions", {"tx": sa["signed_hex"]})
        http("POST", net.api("node0") + "/v1/transactions", {"tx": sb["signed_hex"]})
        wait_for(lambda: get(f"{net.api('node2')}/v1/transactions/{sa['txid']}")["status"] in ("included", "confirmed"), 120, 0.5, "minority inclusion")
        r_min = c2.ix.sync()
        minority_owner = c2.db.execute("SELECT owner FROM ownership_cache WHERE token_id = '5'").fetchone()["owner"]
        h2 = heights(net, ["node2"])["node2"]
        wait_for(lambda: heights(net, ["node2"])["node2"] >= h2 + 1, 120, 0.5, "minority blocks")
        admin(net, "node2", "/admin/v1/mining", {"enabled": False})
        wait_for(lambda: get(f"{net.api('node0')}/v1/transactions/{sb['txid']}")["status"] in ("included", "confirmed"), 120, 0.5, "majority inclusion")
        wait_for(lambda: heights(net, ["node0"])["node0"] >= heights(net, ["node2"])["node2"] + 3, 180, 0.5, "majority lead")
        for n in ("node0", "node1", "node2"):
            admin(net, n, "/admin/v1/peer-actions", {"action": "unban", "peer": "*"})
        admin(net, "node2", "/admin/v1/mining", {"enabled": True})
        wait_for(lambda: tips_agree(net, ["node0", "node1", "node2"], 1), 180, 1, "reconvergence")
        r_after = c2.ix.sync()
        after_owner = c2.db.execute("SELECT owner FROM ownership_cache WHERE token_id = '5'").fetchone()["owner"]
        chain_owner = get(f"{net.api('node2')}/v1/nft/tokens/{cid}/5")["owner"]
        mtx = get(f"{net.api('node2')}/v1/transactions/{sa['txid']}")
        reorgs = [dict(x) for x in c2.db.execute("SELECT fork_height, old_tip_height, blocks_removed, events_removed FROM reorg_log")]
        return {"minority_index_owner": minority_owner == to_minority, "minority_sync": {k: r_min[k] for k in ("indexed_height", "blocks_added")},
                "node_reorgs": get(net.api("node2") + "/v1/consensus/status")["reorgs"][-1:], "index_reorgs": reorgs, "after_sync_reorgs": r_after["reorgs"],
                "index_owner_after": after_owner == to_majority, "chain_owner_after": chain_owner == to_majority, "minority_tx_now": mtx["status"],
                "verify": c2.ix.verify_against_chain()}
    rec.step("PoW reorganisation: an index following the minority branch reconciles to the winning chain (conflicting transfer dropped)", reorg,
             lambda e: e["minority_index_owner"] and e["index_reorgs"] and e["index_owner_after"] and e["chain_owner_after"] and e["verify"]["consistent"])

    # ---------------------------------------------------------------- 10. rebuild + provenance + invariants
    def rebuild():
        c.ix.sync()
        snap = lambda: [tuple(r) for r in c.db.execute("SELECT collection_id, token_id, owner, burned, metadata_hash, revision, frozen FROM ownership_cache ORDER BY CAST(token_id AS INTEGER)")]  # noqa: E731
        before = snap()
        sales = [tuple(r) for r in c.db.execute("SELECT listing_id, buyer, price, royalty, platform_fee, seller_proceeds FROM sales_cache")]
        r = c.ix.rebuild()
        after = snap()
        sales2 = [tuple(r) for r in c.db.execute("SELECT listing_id, buyer, price, royalty, platform_fee, seller_proceeds FROM sales_cache")]
        v = c.ix.verify_against_chain()
        return {"rebuild": {k: r[k] for k in ("blocks_added", "events_added", "indexed_height", "events_before_rebuild")}, "ownership_identical": before == after and len(after) == 11,
                "sales_identical": sales == sales2 and len(sales2) == 1, "verify_against_chain": {k: v[k] for k in ("checked", "consistent", "mismatches")}}
    rec.step("Rebuild the index from chain events: identical ownership and sales; verified against chain state", rebuild,
             lambda e: e["ownership_identical"] and e["sales_identical"] and e["verify_against_chain"]["consistent"])

    def provenance():
        p = c.provenance(cid, 9)
        f = pathlib.Path(out) / "provenance-token-9.json"
        f.write_text(json.dumps(p, indent=2))
        (pathlib.Path(out) / "provenance-token-9.csv").write_text(c.provenance_csv(p))
        kinds = [e["kind"] + (":" + e["op"] if e["op"] else "") for e in p["events"]]
        sup = get(net.api("node0") + "/v1/supply")
        return {"ref": p["ref"], "event_kinds": kinds, "current_owner": p["current"]["owner"], "revisions": len(p["metadata_revisions"]),
                "storage_of_metadata": p["metadata_revisions"][0]["storage"][:1], "export_sha256": p["export_sha256"], "written": [f.name, "provenance-token-9.csv"],
                "supply_invariants": {k: sup[k] for k in ("reconciled", "tokens_reconciled", "nfts_reconciled")}}
    rec.step("Export provenance (JSON + CSV) and check ledger invariants (native, token and NFT reconciliation)", provenance,
             lambda e: "nft_mint" in e["event_kinds"] and "nft_sale" in e["event_kinds"] and e["current_owner"] == net.address("buyer") and all(e["supply_invariants"].values()))

    if os.environ.get("AUREOM_DEMO_KEEP") != "1":
        net.down()
    return rec.save()
