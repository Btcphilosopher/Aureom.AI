"""Shared demonstration steps. Every step records what was done, the observed evidence
and whether the expectation held. Results are written as JSON and Markdown; nothing is
reported that was not observed."""
from __future__ import annotations

import json
import pathlib
import shutil
import time
import traceback

from ..network import Network
from ..util import ChainworksError, get, http, try_get, wait_for, write_json
from ..wallet import Wallet


class Recorder:
    def __init__(self, name, out_dir):
        self.name = name
        self.out = pathlib.Path(out_dir)
        self.out.mkdir(parents=True, exist_ok=True)
        self.steps = []
        self.t0 = time.time()

    def step(self, title, fn, expect=None):
        t = time.time()
        rec = {"step": len(self.steps) + 1, "title": title}
        try:
            ev = fn()
            ok = True if expect is None else bool(expect(ev))
            rec.update({"ok": ok, "evidence": ev})
        except Exception as e:  # noqa: BLE001
            rec.update({"ok": False, "error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc()[-1500:]})
        rec["seconds"] = round(time.time() - t, 2)
        self.steps.append(rec)
        mark = "PASS" if rec["ok"] else "FAIL"
        print(f"[{self.name}] {mark} {rec['step']:>2}. {title} ({rec['seconds']}s)", flush=True)
        if not rec["ok"]:
            print("      ", rec.get("error") or json.dumps(rec.get("evidence"), default=str)[:600], flush=True)
        self.save()
        return rec.get("evidence")

    def save(self):
        res = {"demo": self.name, "passed": sum(s["ok"] for s in self.steps), "total": len(self.steps),
               "seconds": round(time.time() - self.t0, 1), "steps": self.steps,
               "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        write_json(self.out / f"{self.name}-results.json", res)
        md = [f"# Demo results: {self.name}", "", f"{res['passed']}/{res['total']} steps passed in {res['seconds']} s ({res['recorded_at']}).", "",
              "| # | step | result | seconds |", "|---|---|---|---|"]
        for s in self.steps:
            md.append(f"| {s['step']} | {s['title']} | {'PASS' if s['ok'] else 'FAIL'} | {s['seconds']} |")
        md.append("")
        for s in self.steps:
            md.append(f"## {s['step']}. {s['title']} — {'PASS' if s['ok'] else 'FAIL'}")
            md.append("```json")
            md.append(json.dumps(s.get("evidence", s.get("error")), indent=1, default=str)[:4000])
            md.append("```")
        (self.out / f"{self.name}-results.md").write_text("\n".join(md) + "\n")
        return res


def fresh(d, profile, **kw) -> Network:
    d = pathlib.Path(d)
    if d.exists():
        try:
            Network(d).down()
        except Exception:  # noqa: BLE001
            pass
        shutil.rmtree(d)
    return Network.init(d, profile, **kw)


def heights(net: Network, names=None):
    out = {}
    for n in names or [x["name"] for x in net.nodes()]:
        h = try_get(net.api(n) + "/v1/health")
        out[n] = h["height"] if h else None
    return out


def wait_height(net, name, h, timeout=90):
    return wait_for(lambda: (try_get(net.api(name) + "/v1/health") or {}).get("height", -1) >= h and heights(net, [name]), timeout, 0.5, f"{name} height >= {h}")


def tips_agree(net, names, depth_back=2):
    """Same block id at (min height - depth_back) on all nodes."""
    hs = heights(net, names)
    if None in hs.values():
        return False
    h = max(1, min(hs.values()) - depth_back)
    ids = {n: get(f"{net.api(n)}/v1/blocks/{h}")["id"] for n in names}
    return {"height": h, "ids": ids} if len(set(ids.values())) == 1 else False


def tamper_signature(signed_hex: str) -> str:
    b = bytearray(bytes.fromhex(signed_hex))
    b[-1] ^= 0x01
    return b.hex()


def common_tx_steps(rec: Recorder, net: Network, w: Wallet, final_words=("included", "confirmed", "finalised")):
    st = {}

    def transfer():
        before = w.account("bob")["native"]["total"]
        r = w.transfer("alice", "bob", 2_500_000)
        st["signed"] = r["signed_hex"]
        st["txid"] = r["txid"]
        after = w.account("bob")["native"]["total"]
        return {"txid": r["txid"], "status": r["status"], "block_height": r.get("block_height"), "receipt_status": (r.get("receipt") or {}).get("status"),
                "fee_paid": (r.get("receipt") or {}).get("fee_paid"), "bob_before": before, "bob_after": after}
    rec.step("Submit a signed transfer (alice -> bob, 2.5 ADC)", transfer,
             lambda e: e["status"] in final_words and e["receipt_status"] == "success" and int(e["bob_after"]) - int(e["bob_before"]) == 2_500_000)

    def bad_sig():
        # fresh transaction (next nonce) with a corrupted signature
        u = w.prepare("alice", {"type": "transfer", "to": net.address("carol"), "amount": "1"})
        s = json.loads(w.sign("alice", u).read_text())
        code, resp = http("POST", f"{w.api}/v1/transactions", {"tx": tamper_signature(s["signed_hex"])})
        return {"http_status": code, "response": resp}
    rec.step("Reject an invalid signature", bad_sig, lambda e: e["http_status"] == 400 and e["response"]["error"]["code"] == "bad_signature")

    def replay():
        code, resp = http("POST", f"{w.api}/v1/transactions", {"tx": st["signed"]})
        other = net.nodes()[1]["name"]
        code2, resp2 = http("POST", f"{net.api(other)}/v1/transactions", {"tx": st["signed"]})
        return {"same_node": {"http_status": code, "response": resp}, "other_node": {"http_status": code2, "response": resp2}}
    rec.step("Reject a replayed transaction (same signed bytes, two nodes)", replay,
             lambda e: e["same_node"]["http_status"] == 400 and e["other_node"]["http_status"] == 400 and "nonce" in json.dumps(e))
    return st


def explorer_steps(rec, net, w, txid):
    def ex():
        blocks = get(w.api + "/v1/blocks?limit=5")["blocks"]
        tx = get(f"{w.api}/v1/transactions/{txid}")
        acct_txs = get(f"{w.api}/v1/accounts/{net.address('alice')}/transactions")["transactions"]
        ev = get(w.api + "/v1/events?limit=10")["events"]
        sup = get(w.api + "/v1/supply")
        return {"latest_blocks": [(b["height"], b["id"][:16], b["tx_count"]) for b in blocks], "tx_status": tx["status"], "tx_block": tx.get("block_height"),
                "alice_tx_count_indexed": len(acct_txs), "recent_event_kinds": sorted({e["kind"] for e in ev}),
                "supply": {k: sup[k] for k in ("total", "genesis", "minted", "burned", "circulating", "reconciled", "tokens_reconciled")}}
    rec.step("Inspect explorer results (blocks, tx, address index, events, supply)", ex,
             lambda e: e["tx_status"] in ("included", "confirmed", "finalised") and e["alice_tx_count_indexed"] >= 1 and e["supply"]["reconciled"])


def api_permission_steps(rec, net):
    n = net.nodes()[0]["name"]
    url, tok = net.admin(n)

    def perms():
        r = {}
        r["admin_no_token"] = http("POST", url + "/admin/v1/snapshots", {})[0]
        r["admin_wrong_token"] = http("POST", url + "/admin/v1/snapshots", {}, {"authorization": "Bearer " + "0" * 64})[0]
        r["admin_status_with_token"] = http("GET", url + "/admin/v1/status", None, {"authorization": f"Bearer {tok}"})[0]
        r["public_port_has_no_admin_routes"] = http("POST", net.api(n) + "/admin/v1/shutdown", {})[0]
        r["admin_listen"] = json.loads((net.node_dir(n) / "node.json").read_text())["admin_listen"]
        return r
    rec.step("API permissions: admin API requires token, is loopback-bound, absent from public port", perms,
             lambda e: e["admin_no_token"] == 401 and e["admin_wrong_token"] == 401 and e["admin_status_with_token"] == 200
             and e["public_port_has_no_admin_routes"] == 404 and e["admin_listen"].startswith("127.0.0.1"))


def snapshot_steps(rec, net, node):
    st = {}

    def snap():
        s = net.snapshot(node)
        st["snap"] = s
        from ..util import cli
        b = get(f"{net.api(node)}/v1/blocks/{s['height']}")
        ok = cli("snapshot", "verify", s["path"], "--genesis", net.genesis_path, "--trusted-root", b["state_root"])
        data = bytearray(pathlib.Path(s["path"]).read_bytes())
        data[len(data) // 2] ^= 0xFF
        bad = pathlib.Path(s["path"] + ".tampered")
        bad.write_bytes(bytes(data))
        tampered = cli("snapshot", "verify", bad, "--genesis", net.genesis_path, check=False)
        wrong = cli("snapshot", "verify", s["path"], "--trusted-root", "00" * 32, check=False)
        return {"snapshot": {k: s[k] for k in ("height", "state_root", "bytes")}, "verify_against_validated_block": ok["ok"],
                "tampered_file": tampered, "untrusted_root": {"ok": wrong["ok"], "problems": wrong["problems"]}}
    rec.step("Snapshot: create, verify against a validated block root, reject tampered/untrusted", snap,
             lambda e: e["verify_against_validated_block"] and not e["tampered_file"]["ok"] and not e["untrusted_root"]["ok"])
    return st
