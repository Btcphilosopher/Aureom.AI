"""Network-level throughput/latency measurement on a local development network.
Pre-signs transfers (signing is excluded from the timed window), submits them round-robin
to all nodes and measures time until every transaction is included/finalised."""
from __future__ import annotations

import concurrent.futures as cf
import json
import time

from .network import Network
from .util import http, read_json, try_get, wait_for
from .wallet import Wallet


def measure(d, senders=("alice", "bob", "issuer", "carol", "dave", "t1"), per_sender=50, out=None) -> dict:
    net = Network(d)
    w = Wallet(net)
    nodes = [n["name"] for n in net.nodes() if not n.get("joiner")]
    signed = []
    t = time.time()
    for s in senders:
        start = w.account(s)["nonce"]
        for i in range(per_sender):
            u = w.prepare(s, {"type": "transfer", "to": net.address("t3"), "amount": "1"}, nonce=start + i)
            signed.append(read_json(w.sign(s, u)))
    sign_s = time.time() - t
    h0 = try_get(net.api(nodes[0]) + "/v1/health")["height"]
    # submit in nonce order per sender (round robin across senders and nodes)
    order = []
    for i in range(per_sender):
        for j in range(len(senders)):
            order.append(signed[j * per_sender + i])
    t0 = time.time()
    codes = []

    def submit(k):
        doc = order[k]
        # one node per sender: CheckTx requires each sender's nonces to arrive in order
        return http("POST", net.api(nodes[(k % len(senders)) % len(nodes)]) + "/v1/transactions", {"tx": doc["signed_hex"]}, timeout=10)[0]
    # per-sender ordering matters for nonce gaps on BFT CheckTx: submit sequentially per sender, senders in parallel
    by_sender = [[k for k in range(len(order)) if k % len(senders) == j] for j in range(len(senders))]
    with cf.ThreadPoolExecutor(len(senders)) as ex:
        codes_by_k = {}
        for ks, r in zip(by_sender, ex.map(lambda ks: [submit(k) for k in ks], by_sender)):
            codes += r
            codes_by_k.update(dict(zip(ks, r)))
    submit_s = time.time() - t0
    ids = [d_["txid"] for d_ in order]
    done = set()

    def all_done():
        for i in ids:
            if i in done:
                continue
            v = try_get(f"{net.api(nodes[0])}/v1/transactions/{i}")
            if v and v["status"] in ("included", "confirmed", "finalised"):
                done.add(i)
        return len(done) == len(ids)
    ids = [order[k]["txid"] for k in range(len(order)) if codes_by_k.get(k) == 202]
    wait_for(all_done, 300, 0.5, "all accepted transactions included")
    total_s = time.time() - t0
    h1 = try_get(net.api(nodes[0]) + "/v1/health")["height"]
    res = {"profile": net.profile, "transactions_submitted": len(order), "transactions_included": len(ids), "accepted_http_202": codes.count(202), "presign_seconds": round(sign_s, 2),
           "submit_seconds": round(submit_s, 2), "seconds_until_all_included": round(total_s, 2), "throughput_tx_per_s": round(len(ids) / total_s, 1),
           "blocks_used": h1 - h0, "nodes": len(nodes),
           "note": "local processes on one 4-vCPU machine; dominated by block interval (BFT ~1 s commit timeout; PoW 2 s target) and HTTP submission, not execution"}
    if out:
        from .util import write_json
        write_json(out, res)
    return res
