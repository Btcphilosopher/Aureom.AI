# chainworks (Python)

Orchestration, configuration validation, testing and analysis for AUREOM CHAINWORKS.

```bash
pip install -e .            # or PYTHONPATH=python
chainworks --help
python -m pytest tests      # needs rust/target/release binaries (or AUREOM_BIN_DIR)
```

Modules: `spec` (launch wizard defaults, Python genesis validation, supply preview),
`network` (init/keys/genesis/configs/CometBFT/processes/backup/restore/replay),
`wallet`, `distribute`, `treasury`, `export`, `compose`, `migrate`, `explorer`,
`console_server`, `faults`, `perf`, `protocol` + `bech32m` (independent reference
implementation used to verify the Rust test vectors), `demos/`.
