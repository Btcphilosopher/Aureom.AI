// Dev-only check: start the mock, visit every page with Playwright Chromium, report
// console/page errors and write a few screenshots to ../screenshots/.
//   node mock/screenshots.cjs            # PoW mock, writes screenshots
//   node mock/screenshots.cjs pos        # BFT (PoS) mock, render check only, no screenshots
// Requires a globally resolvable `playwright` package (not a project dependency).
const { spawn } = require('node:child_process');
const path = require('node:path');
const { chromium } = require('playwright');

const PROFILE = process.argv[2] || 'pow';
const PORT = PROFILE === 'pow' ? 8790 : 8791;
const BASE = `http://127.0.0.1:${PORT}/`;
const OUT = path.join(__dirname, '..', 'screenshots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const srv = spawn(process.execPath, [path.join(__dirname, 'server.mjs')], {
    env: { ...process.env, PORT: String(PORT), NODE2_UP_MS: '3000', MOCK_PROFILE: PROFILE },
    stdio: 'inherit',
  });
  const t0 = Date.now();
  await sleep(700);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
  const problems = [];
  let expected502 = 0;
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() !== 'error' && m.type() !== 'warning') return;
    // node2 is deliberately down after 3 s: the browser logs each failed proxy fetch.
    if (/status of 502/.test(m.text())) return void expected502++;
    problems.push(`console.${m.type()}: ${m.text()} @ ${page.url()}`);
  });
  const visit = async (hash, wait = 1200) => {
    await page.goto(BASE + hash);
    await sleep(wait);
  };
  const shoot = PROFILE === 'pow';
  const shot = async (name) => shoot && page.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: true });
  const checks = [];
  const expectText = async (label, re) => {
    const body = await page.textContent('body');
    checks.push(`${re.test(body) ? 'PASS' : 'FAIL'}  ${label}`);
  };

  await visit('#/networks', 1500);
  await expectText('networks: fixed-at-genesis text', /fixed at genesis and cannot be switched/);
  await visit('#/blocks', 1500);
  await shot('blocks');
  // open a block that has transactions
  const blockHref = await page.evaluate(() => {
    const rows = [...document.querySelectorAll('table.table tbody tr')];
    const r = rows.find((tr) => tr.children[3] && tr.children[3].textContent.trim() !== '0');
    const a = r && r.querySelector('a');
    return a ? a.getAttribute('href') : null;
  });
  await visit(blockHref || '#/blocks/latest', 1200);
  await expectText('block detail: finality label', PROFILE === 'pow' ? /probabilistic — \d+ confirmation/ : /final \(BFT commit\)/);
  const txHref = await page.evaluate(() => {
    const a = document.querySelector('a[href^="#/transactions/"]');
    return a ? a.getAttribute('href') : null;
  });
  await visit(txHref || '#/transactions', 1500);
  await expectText('tx detail: lifecycle state shown', /State on node0/);
  // submit box: non-hex must be refused client-side; short hex reaches the node and is rejected
  await page.fill('textarea', 'not hex at all');
  await expectText('submit: non-hex refused', /NOT HEX/);
  await page.fill('textarea', 'deadbeef');
  await page.click('button[type=submit]:has-text("Broadcast")');
  await sleep(800);
  await expectText('submit: node error rendered', /Rejected \(HTTP 400\)[\s\S]*malformed/);
  await visit('#/consensus', 1500);
  await expectText('consensus: profile text', PROFILE === 'pow' ? /no resistance to a majority-hashpower attacker/ : /less than 1\/3 of the total voting power/);
  await shot('consensus');
  await visit('#/assets', 1500);
  await expectText('assets: disclaimer', /does not give it monetary value, reserve backing, exchange listing or legal status/);
  await expectText('assets: duplicate symbol warning', /Symbols are not unique — compare token ids/);
  await shot('assets');
  await visit('#/validators', 1200);
  await expectText('validators', PROFILE === 'pow' ? /Proof-of-work networks have no validator set/ : /TOMBSTONED/);
  await visit('#/governance', 1200);
  await expectText('governance', PROFILE === 'pow' ? /no on-chain governance/ : /protocol upgrade/);
  await visit('#/treasury', 1500);
  await expectText('treasury: approvals text', /dashboard clicks are not approvals/);
  await expectText('treasury: proposal rendered', /PENDING/);
  await visit('#/keys', 1000);
  await expectText('keys: notice', /never asks for private keys, keystore passphrases or seed phrases/);
  const alice = await page.evaluate(() => {
    const r = [...document.querySelectorAll('tbody tr')].find((tr) => tr.textContent.includes('alice'));
    const c = r && r.querySelector('code[title^="aurd1"]');
    return c ? c.getAttribute('title') : null;
  });
  await visit(`#/accounts/${alice}`, 1500);
  await expectText('accounts: token ids + issuer-supplied', /token_id[\s\S]*issuer-supplied/i);
  for (const h of ['#/deployments', '#/recovery', '#/nonexistent']) await visit(h, 900);
  await expectText('unknown route handled', /Unknown page/);
  // wait until node2's last good observation is > 10 s old
  const wait = 16000 - (Date.now() - t0);
  if (wait > 0) await sleep(wait);
  await visit('#/nodes', 4500);
  await expectText('nodes: WRONG CHAIN', /WRONG CHAIN/);
  await expectText('nodes: STALE', /STALE/);
  await expectText('nodes: UNREACHABLE', /UNREACHABLE/);
  await shot('nodes');
  await visit('#/monitoring', 3500);
  await shot('monitoring');
  await browser.close();
  srv.kill();
  console.log(`\nprofile ${PROFILE}`);
  for (const c of checks) console.log('  ' + c);
  console.log(`expected 502 messages from the deliberately-down node2: ${expected502}`);
  console.log(`${problems.length} other console/page errors or warnings:`);
  for (const p of problems) console.log('  ' + p);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
