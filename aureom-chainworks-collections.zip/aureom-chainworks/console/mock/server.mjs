#!/usr/bin/env node
// Development mock of the `chainworks console` server. No dependencies.
//
//   node mock/server.mjs            # serves ./dist on http://127.0.0.1:8787
//   PORT=9000 node mock/server.mjs
//
// It fakes one PoW network with three nodes, shaped after docs/API.md:
//   node0  healthy miner on the manifest chain
//   node1  answers, but on a DIFFERENT genesis hash (wrong chain) and has no peers
//   node2  answers for the first NODE2_UP_MS (default 6000 ms) after start, then the
//          proxy returns 502 — the console must show it as STALE, then UNREACHABLE.
// All data is synthetic. Nothing here is a real key, address or checksum.

import http from 'node:http';
import { createHash } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const NODE2_UP_MS = Number(process.env.NODE2_UP_MS || 6000);
// MOCK_PROFILE=pos|poa switches to a BFT-shaped network (for checking those code paths); default pow.
const PROFILE = ['pos', 'poa'].includes(process.env.MOCK_PROFILE) ? process.env.MOCK_PROFILE : 'pow';
const BFT = PROFILE !== 'pow';
const DIST = resolve(fileURLToPath(new URL('../dist/', import.meta.url)));
const START = Date.now();
const BLOCK_MS = 2000;
const BASE_HEIGHT = 1200;

const sha = (s) => createHash('sha256').update(String(s)).digest('hex');
const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const b32 = (seed, n = 38) => {
  const h = sha(seed) + sha(seed + '/2');
  let out = '';
  for (let i = 0; i < n; i++) out += CHARSET[parseInt(h.slice(i * 2, i * 2 + 2), 16) % 32];
  return out;
};
const addr = (seed) => `aurd1${b32('addr/' + seed)}`;
const tokenId = (seed) => `aurdtok1${b32('tok/' + seed)}`;

const GENESIS = sha('mock-genesis-aureom-dev-pow-1');
const WRONG_GENESIS = sha('some-other-genesis');
const CHAIN_ID = `aureom-dev-${PROFILE}-1`;
const DECIMALS = 6;
const U = 10n ** BigInt(DECIMALS);

const A = {
  miner0: addr('miner0'),
  miner2: addr('miner2'),
  alice: addr('alice'),
  bob: addr('bob'),
  carol: addr('carol'),
  issuer: addr('issuer'),
  copycat: addr('copycat'),
  treasury: addr('treasury-msig-0'),
  signer1: addr('signer1'),
  signer2: addr('signer2'),
  signer3: addr('signer3'),
};

const NATIVE_ASSET = { name: 'Aureom Development Coin', ticker: 'ADC', decimals: DECIMALS, address_hrp: 'aurd' };
const MONETARY = { kind: 'scheduled', max_supply: (21_000_000n * U).toString(), scheduled: { initial_block_reward: (50n * U).toString(), halving_interval_blocks: 100000 } };
const FEES = { base_fee: '1000', per_byte_fee: '10', burn_bps: 2000, recipient: 'proposer' };
const LIMITS = { max_block_bytes: 1048576, max_block_txs: 2000, max_tx_bytes: 65536, max_memo_bytes: 256 };
const POW_PARAMS = {
  initial_target: '00000fffff' + 'f'.repeat(54),
  pow_limit: '0000ffff' + 'f'.repeat(56),
  target_block_time_ms: BLOCK_MS,
  retarget_interval: 60,
  max_future_drift_ms: 15000,
  coinbase_maturity: 20,
  confirmations_recommended: 6,
};

const NODES = {
  node0: { role: 'miner', p2p: '127.0.0.1:27001', api: 'http://127.0.0.1:28001', lag: 0, genesis: GENESIS, version: '0.1.0' },
  node1: { role: 'full', p2p: '127.0.0.1:27002', api: 'http://127.0.0.1:28002', lag: 0, genesis: WRONG_GENESIS, version: '0.1.0', heightOffset: -1150 },
  node2: { role: 'miner', p2p: '127.0.0.1:27003', api: 'http://127.0.0.1:28003', lag: 1, genesis: GENESIS, version: '0.1.0' },
};

// ------------------------------------------------------------------ chain model

const tipHeight = () => BASE_HEIGHT + Math.floor((Date.now() - START) / BLOCK_MS);
const T0 = START - BASE_HEIGHT * BLOCK_MS;
const jitter = (h) => parseInt(sha('j' + h).slice(0, 4), 16) % 1500;
const tsOf = (h) => T0 + h * BLOCK_MS + jitter(h);
const blockId = (h, g = GENESIS) => sha(`block/${g}/${h}`);
const TARGET = '00000fffff' + 'f'.repeat(54);

function txsAt(h) {
  if (h % 3 !== 0 || h <= 0) return [];
  const n = h % 9 === 0 ? 2 : 1;
  const out = [];
  for (let i = 0; i < n; i++) {
    const from = i === 0 ? A.alice : A.bob;
    const to = i === 0 ? A.bob : A.carol;
    const amount = (BigInt((h * 7919 + i * 31) % 5000) * U) / 100n + 1n;
    const tx = {
      id: sha(`tx/${h}/${i}`),
      version: 1,
      chain_id: CHAIN_ID,
      sender: from,
      sender_pubkey: sha('pk/' + from),
      nonce: Math.floor(h / 3) + i,
      fee: '2400',
      expiry_height: 0,
      action: h % 27 === 0 && i === 1 ? { type: 'token_transfer', token: tokenId('gld-real'), to, amount: '1500' } : { type: 'transfer', to, amount: amount.toString() },
      memo: i === 0 ? 'payroll' : '',
    };
    const failed = h % 45 === 0 && i === 0;
    const receipt = {
      txid: tx.id,
      status: failed ? 'failed' : 'success',
      error: failed ? 'INSUFFICIENT_FUNDS' : null,
      error_code: failed ? 1 : 0,
      fee_paid: '2400',
      events: failed
        ? [{ kind: 'fee', attrs: { payer: from, amount: '2400', burned: '480' } }]
        : [
            { kind: 'fee', attrs: { payer: from, amount: '2400', burned: '480' } },
            { kind: 'transfer', attrs: { from, to, amount: tx.action.amount } },
          ],
    };
    out.push({ tx, receipt });
  }
  return out;
}

function blockJson(h, tip, g = GENESIS) {
  const items = txsAt(h);
  const cw = (BigInt(h) * 1048576n + 1n).toString();
  return {
    height: h,
    id: blockId(h, g),
    prev_id: h > 0 ? blockId(h - 1, g) : '0'.repeat(64),
    timestamp_ms: tsOf(h),
    proposer: h % 4 === 1 ? A.miner2 : A.miner0,
    tx_count: items.length,
    size_bytes: 180 + items.length * 214,
    state_root: sha('state/' + h),
    tx_root: sha('txroot/' + h),
    receipt_root: sha('rroot/' + h),
    txs: items.map((x) => x.tx),
    receipts: items.map((x) => x.receipt),
    consensus: BFT ? { bft: { cometbft_block_hash: sha('cmt/' + h).toUpperCase(), app_hash: sha('state/' + (h - 1)).toUpperCase() } } : { pow: { target: TARGET, nonce: String(parseInt(sha('n' + h).slice(0, 8), 16)), pow_hash: '00000' + sha('pow' + h).slice(5), work: '1048576', cumulative_work: cw } },
    confirmations: tip - h,
    finality: BFT ? 'final' : 'probabilistic',
    on_main_chain: true,
  };
}

function summary(b) {
  const { txs, receipts, consensus, ...rest } = b;
  void txs; void receipts; void consensus;
  return rest;
}

// ------------------------------------------------------------------ fixtures

const TOKENS = [
  {
    token_id: tokenId('gld-real'), symbol: 'GLD', name: 'Gold Ledger Units', decimals: 2,
    supply: '100000000', max_supply: '100000000', creator: A.issuer, mint_authority: null, admin: null,
    pausable: false, freezable: false, paused: false, metadata_uri: 'https://example.invalid/gld.json', created_height: 14,
  },
  {
    token_id: tokenId('gld-copy'), symbol: 'GLD', name: 'Gold Ledger Units', decimals: 2,
    supply: '5000000', max_supply: null, creator: A.copycat, mint_authority: A.copycat, admin: A.copycat,
    pausable: true, freezable: true, paused: false, metadata_uri: 'https://example.invalid/totally-the-real-gld.json', created_height: 803,
  },
  {
    token_id: tokenId('pts'), symbol: 'PTS', name: 'Workshop Points', decimals: 0,
    supply: '25000', max_supply: '1000000', creator: A.issuer, mint_authority: A.issuer, admin: A.issuer,
    pausable: true, freezable: false, paused: true, metadata_uri: '', created_height: 512,
  },
];
const VERIFIED = 'on-chain facts: supply, permissions; issuer-supplied: name, symbol, metadata_uri';

function supply(tip) {
  const genesis = 10_000_000n * U;
  const minted = BigInt(tip) * 50n * U;
  const burned = BigInt(Math.floor(tip / 3)) * 480n + 1_250n * U;
  const total = genesis + minted - burned;
  const locked_vesting = 1_800_000n * U;
  const immature = 20n * 50n * U;
  const staked = 0n;
  const unbonding = 0n;
  const escrow = 250_000n * U;
  const treasury = 2_000_000n * U;
  const circulating = total - locked_vesting - immature - staked - escrow - treasury;
  const s = (x) => x.toString();
  return {
    total: s(total), genesis: s(genesis), minted: s(minted), burned: s(burned), staked: s(staked), unbonding: s(unbonding),
    escrow: s(escrow), locked_vesting: s(locked_vesting), immature: s(immature), treasury: s(treasury), circulating: s(circulating),
    max_supply: MONETARY.max_supply, reconciled: true, tokens_reconciled: true, problems: [], height: tip,
    asset: { ticker: 'ADC', decimals: DECIMALS },
  };
}

function account(address, tip) {
  const known = Object.values(A).includes(address) || address.startsWith('aurd1');
  if (!known) return null;
  const isAlice = address === A.alice;
  const isMiner = address === A.miner0;
  const total = (isAlice ? 1_250_000n : isMiner ? 61_000n : 1_000n) * U + BigInt(address.length);
  const locked = isAlice ? 400_000n * U : 0n;
  const imm = isMiner ? 1_000n * U : 0n;
  return {
    address, nonce: isAlice ? Math.floor(tip / 3) : 0, height: tip,
    native: {
      total: total.toString(), available: (total - locked - imm).toString(), locked_vesting: locked.toString(),
      immature: imm.toString(), bonded: '0', unbonding: '0',
    },
    vesting: isAlice ? [{ total: (600_000n * U).toString(), start_height: 0, cliff_height: 500, end_height: 3000, vested: (200_000n * U).toString(), locked: locked.toString() }] : [],
    immature: isMiner ? [{ amount: (500n * U).toString(), mature_height: tip + 5 }, { amount: (500n * U).toString(), mature_height: tip + 12 }] : [],
    tokens: isAlice
      ? TOKENS.map((t, i) => ({
          token_id: t.token_id, symbol: t.symbol, name: t.name, decimals: t.decimals, balance: ['1250075', '990000', '320'][i], frozen: i === 1,
          issuer_permissions: { mint_authority: t.mint_authority, admin: t.admin, pausable: t.pausable, freezable: t.freezable },
        }))
      : [],
    multisig: address === A.treasury ? { signers: [A.signer1, A.signer2, A.signer3], threshold: 2 } : null,
  };
}

function multisig(address) {
  if (address !== A.treasury) return null;
  return {
    address, signers: [A.signer1, A.signer2, A.signer3], threshold: 2, balance: (2_000_000n * U).toString(),
    proposals: [
      { id: 0, proposer: A.signer1, inner: { type: 'transfer', to: A.carol, amount: (5_000n * U).toString() }, approvals: [A.signer1, A.signer2], expiry_height: 900, status: 'executed', error: null },
      { id: 1, proposer: A.signer2, inner: { type: 'transfer', to: A.bob, amount: (12_500n * U).toString() }, approvals: [A.signer2], expiry_height: 99999, status: 'pending', error: null },
      { id: 2, proposer: A.signer3, inner: { type: 'token_mint', token: TOKENS[2].token_id, to: A.alice, amount: '100' }, approvals: [A.signer3, A.signer1], expiry_height: 700, status: 'failed', error: 'UNAUTHORIZED' },
    ],
  };
}

const MEMPOOL = [
  { id: sha('mp/1'), sender: A.bob, nonce: 41, fee: '2600', size_bytes: 212, received_ms: START - 4000, action: { type: 'transfer', to: A.alice, amount: (3n * U).toString() } },
  { id: sha('mp/2'), sender: A.carol, nonce: 7, fee: '2400', size_bytes: 208, received_ms: START - 1500, action: { type: 'native_burn', amount: (1n * U).toString() } },
];
const submitted = new Map();

// ------------------------------------------------------------------ node API

const node2Up = () => Date.now() - START < NODE2_UP_MS;

function nodeHeight(name) {
  const n = NODES[name];
  let h = tipHeight() - n.lag + (n.heightOffset || 0);
  if (name === 'node2' && !node2Up()) h = BASE_HEIGHT + Math.floor(NODE2_UP_MS / BLOCK_MS) - n.lag;
  return h;
}

function nodeApi(name, method, path, query, body) {
  const n = NODES[name];
  const now = Date.now();
  const tip = nodeHeight(name);
  const g = n.genesis;
  const ok = (obj, status = 200) => ({ status, body: { ...obj, observed_at_ms: now } });
  const err = (status, code, message) => ({ status, body: { error: { code, message } } });
  const parts = path.split('/').filter(Boolean); // ["v1", ...]
  if (parts[0] !== 'v1') return err(404, 'not_found', 'unknown path');
  const p = parts.slice(1);

  if (method === 'POST') {
    if (p.length === 1 && p[0] === 'transactions') {
      const hex = body && typeof body.tx === 'string' ? body.tx : '';
      if (!/^[0-9a-f]+$/.test(hex) || hex.length % 2) return err(400, 'malformed', 'tx must be lowercase hex');
      if (hex.length < 200) return err(400, 'malformed', `decoding failed: ${hex.length / 2} bytes is shorter than a SignedTx`);
      const id = sha('submitted/' + hex);
      submitted.set(id, { at: now, hex });
      return ok({ id, status: 'pending', note: "accepted by this node's mempool; inclusion is not guaranteed" }, 202);
    }
    return err(405, 'method_not_allowed', 'only POST /v1/transactions is accepted');
  }

  switch (p[0]) {
    case 'network':
      return ok({
        network_name: 'Aureom Development Network', chain_id: CHAIN_ID, profile: PROFILE, backend: BFT ? 'cometbft' : 'aureom-nakamoto', backend_version: BFT ? '0.38.26' : '0.1.0',
        protocol_version: 1, node_version: n.version, genesis_hash: g, node_name: name, native_asset: NATIVE_ASSET,
        monetary_policy: MONETARY, fee_policy: FEES, limits: LIMITS, finality: BFT ? 'deterministic-bft' : 'probabilistic', confirmations_recommended: BFT ? undefined : 6,
        fault_assumption: BFT ? 'safety: < 1/3 Byzantine voting power; liveness: > 2/3 online' : 'probabilistic: safety requires honest miners to control the majority of hash power',
      });
    case 'health': {
      const peers = name === 'node0' ? (node2Up() ? 2 : 1) : name === 'node1' ? 0 : 1;
      const alerts = [];
      if (peers === 0) alerts.push({ level: 'warning', code: 'no_peers', message: 'node has no connected peers' });
      return ok({
        status: 'ok', height: tip, tip_id: blockId(tip, g), tip_time_ms: tsOf(tip), tip_age_ms: Math.max(0, now - tsOf(tip)),
        peers, syncing: false, mempool_txs: name === 'node0' ? MEMPOOL.length + submitted.size : name === 'node2' ? 1 : 0,
        storage: { db_path: `/var/lib/aureom/${name}/db`, db_bytes: 48_000_000 + tip * 1700, db_version: 1, pruning: { keep_blocks: 0, keep_undo: 1000 } },
        alerts,
      });
    }
    case 'blocks': {
      if (p.length === 1) {
        const limit = Math.min(100, Math.max(1, Number(query.get('limit') || 20)));
        const before = query.has('before') ? Number(query.get('before')) : tip + 1;
        const blocks = [];
        for (let h = Math.min(before - 1, tip); h >= 0 && blocks.length < limit; h--) blocks.push(summary(blockJson(h, tip, g)));
        return ok({ blocks });
      }
      const id = p[1];
      let h = null;
      if (id === 'latest') h = tip;
      else if (/^\d+$/.test(id)) h = Number(id);
      else if (/^[0-9a-f]{64}$/.test(id)) {
        for (let x = tip; x >= Math.max(0, tip - 2000); x--) if (blockId(x, g) === id) { h = x; break; }
      }
      if (h === null || h > tip || h < 0) return err(404, 'not_found', 'block not found');
      return ok(blockJson(h, tip, g));
    }
    case 'transactions': {
      const id = p[1] || '';
      if (submitted.has(id)) return ok({ id, status: 'pending', block_height: null, block_id: null, index: null, confirmations: null, finality: null, receipt: null, tx: null, reason: null });
      const mp = MEMPOOL.find((m) => m.id === id);
      if (mp) return ok({ id, status: 'pending', block_height: null, block_id: null, index: null, confirmations: null, finality: null, receipt: null, tx: { ...mp, chain_id: CHAIN_ID, version: 1, expiry_height: 0, memo: '' }, reason: null });
      for (let h = tip; h >= Math.max(0, tip - 600); h--) {
        const items = txsAt(h);
        const i = items.findIndex((x) => x.tx.id === id);
        if (i >= 0) {
          const conf = tip - h;
          return ok({ id, status: BFT ? 'finalised' : conf >= 6 ? 'confirmed' : 'included', block_height: h, block_id: blockId(h, g), index: i, confirmations: conf, finality: BFT ? 'final' : 'probabilistic', receipt: items[i].receipt, tx: items[i].tx, reason: null });
        }
      }
      if (id === sha('dropped')) return ok({ id, status: 'dropped', reason: 'evicted: replaced by a conflicting transaction with the same nonce' });
      return ok({ id, status: 'unknown', reason: 'this node has no record of the transaction' });
    }
    case 'accounts': {
      const a = account(p[1] || '', tip);
      if (!a) return err(404, 'not_found', 'bad address');
      if (p[2] === 'transactions') {
        const ids = [];
        for (let h = tip; h >= 0 && ids.length < 10; h--) for (const x of txsAt(h)) if (x.tx.sender === a.address || x.tx.action.to === a.address) ids.push(x.tx.id);
        return ok({ address: a.address, transactions: ids });
      }
      return ok(a);
    }
    case 'mempool': {
      const txs = name === 'node0' ? [...MEMPOOL, ...[...submitted.entries()].map(([id, s]) => ({ id, received_ms: s.at, size_bytes: s.hex.length / 2 }))] : name === 'node2' ? [MEMPOOL[0]] : [];
      return ok({ count: txs.length, bytes: txs.reduce((s, t) => s + (t.size_bytes || 0), 0), max_txs: 5000, txs });
    }
    case 'consensus': {
      if (BFT)
        return ok({
          profile: PROFILE, engine: 'cometbft', cometbft_version: '0.38.26', height: tip, app_height: tip, round: 0,
          latest_block_hash: sha('cmt/' + tip).toUpperCase(), latest_app_hash: sha('state/' + tip).toUpperCase(), catching_up: false,
          total_power: 40, last_commit: { signed_power: 30, total_power: 40, signers: 3, validators: 4 },
          quorum: '> 2/3 of voting power', fault_assumption: 'safety: < 1/3 Byzantine voting power; liveness: > 2/3 online',
          finality: 'deterministic-bft', epoch: PROFILE === 'pos' ? { length: 10, next: Math.ceil((tip + 1) / 10) * 10 } : null,
        });
      const times = [];
      for (let h = tip - 30; h < tip; h++) times.push(tsOf(h + 1) - tsOf(h));
      return ok({
        profile: 'pow', engine: 'aureom-nakamoto', height: tip, tip: blockId(tip, g), cumulative_work: (BigInt(tip) * 1048576n + 1n).toString(),
        target: TARGET, difficulty: '1048576', target_block_time_ms: BLOCK_MS, recent_block_times_ms: times,
        reorgs: [
          { at_ms: START - 3600_000, depth: 1, old_tip: sha('old1'), new_tip: sha('new1'), fork_height: BASE_HEIGHT - 900 },
          { at_ms: START - 600_000, depth: 2, old_tip: sha('old2'), new_tip: sha('new2'), fork_height: BASE_HEIGHT - 300 },
        ],
        mining: { enabled: n.role === 'miner', address: name === 'node2' ? A.miner2 : A.miner0, hashes: 1234567 + tip * 1000 },
        finality: 'probabilistic', confirmations_recommended: 6,
        fault_assumption: 'probabilistic: safety requires honest miners to control the majority of hash power',
      });
    }
    case 'validators':
      if (BFT)
        return ok({
          profile: PROFILE, total_power: 40,
          validators: [
            { operator: addr('v0'), moniker: 'aureom-v0', consensus_pubkey: 'b64key0=', consensus_address: sha('ca0').slice(0, 40).toUpperCase(), power: 10, bonded: (10_000n * U).toString(), status: 'active', jailed_until: 0, missed_in_window: 0, signed_last_block: true },
            { operator: addr('v1'), moniker: 'aureom-v1', consensus_pubkey: 'b64key1=', consensus_address: sha('ca1').slice(0, 40).toUpperCase(), power: 10, bonded: (10_000n * U).toString(), status: 'active', jailed_until: 0, missed_in_window: 1, signed_last_block: true },
            { operator: addr('v2'), moniker: 'aureom-v2', consensus_pubkey: 'b64key2=', consensus_address: sha('ca2').slice(0, 40).toUpperCase(), power: 10, bonded: (10_000n * U).toString(), status: 'active', jailed_until: 0, missed_in_window: 0, signed_last_block: true },
            { operator: addr('v3'), moniker: 'aureom-v3', consensus_pubkey: 'b64key3=', consensus_address: sha('ca3').slice(0, 40).toUpperCase(), power: 10, bonded: (10_000n * U).toString(), status: 'jailed', jailed_until: tip + 50, missed_in_window: 37, signed_last_block: false },
            { operator: addr('v4'), moniker: 'old-v4', consensus_pubkey: 'b64key4=', consensus_address: sha('ca4').slice(0, 40).toUpperCase(), power: 0, bonded: '0', status: 'tombstoned', jailed_until: 0, missed_in_window: 0, signed_last_block: null },
          ],
        });
      return ok({ profile: 'pow', total_power: 0, validators: [], note: 'proof-of-work networks have no validator set' });
    case 'peers': {
      const mk = (id, address, direction) => ({ id, address, direction, height: tip, score: 0, connected_since_ms: START - 50_000, protocol_version: 1 });
      if (name === 'node0') return ok({ peers: [mk(sha('ext').slice(0, 16), '10.0.0.9:27001', 'inbound'), ...(node2Up() ? [mk(sha('node2').slice(0, 16), NODES.node2.p2p, 'outbound')] : [])], max_peers: 16 });
      if (name === 'node2') return ok({ peers: [mk(sha('node0').slice(0, 16), NODES.node0.p2p, 'inbound')], max_peers: 16 });
      return ok({ peers: [], max_peers: 16 });
    }
    case 'sync':
      return ok({ syncing: false, local_height: tip, best_known_height: tip, progress: 1.0, trust_anchor: { kind: 'genesis', height: 0, hash: g, note: 'PoW nodes validate from genesis' }, validation: 'full', errors: [] });
    case 'supply':
      return ok(supply(tip));
    case 'tokens': {
      if (p[1]) {
        const t = TOKENS.find((x) => x.token_id === p[1]);
        return t ? ok({ ...t, verified: VERIFIED }) : err(404, 'not_found', 'token not found');
      }
      return ok({ tokens: TOKENS.map((t) => ({ ...t, verified: VERIFIED })) });
    }
    case 'multisigs': {
      const m = multisig(p[1] || '');
      return m ? ok(m) : err(404, 'not_found', 'no multisig at this address');
    }
    case 'proposals':
      if (BFT)
        return ok({
          proposals: [
            { id: 0, proposer: addr('v0'), kind: { kind: 'protocol_upgrade', name: 'v2-fees', protocol_version: 2, activation_height: tip + 500 }, created_height: tip - 40, expiry_height: tip + 200, approvals: [addr('v0'), addr('v1')], approving_power: 20, total_power: 40, status: 'pending', executed_height: 0 },
            { id: 1, proposer: addr('v1'), kind: { kind: 'text', title: 'Rotate operator keys quarterly', uri: '' }, created_height: tip - 400, expiry_height: tip - 100, approvals: [addr('v1'), addr('v2'), addr('v0')], approving_power: 30, total_power: 40, status: 'executed', executed_height: tip - 390 },
          ],
        });
      return err(404, 'unsupported_profile', 'proof-of-work networks have no on-chain governance');
    case 'events':
      return ok({ events: [] });
    default:
      return err(404, 'not_found', 'unknown endpoint');
  }
}

// ------------------------------------------------------------------ console server API

function manifest() {
  return {
    network: {
      name: 'Aureom Development Network', chain_id: CHAIN_ID, profile: PROFILE, genesis_hash: GENESIS,
      native_asset: NATIVE_ASSET, monetary_policy: MONETARY, fee_policy: FEES, limits: LIMITS,
      consensus: BFT ? { profile: PROFILE, [PROFILE]: { epoch_length: 10, evidence_max_age_blocks: 100 } } : { profile: 'pow', pow: POW_PARAMS },
      treasuries: [{ label: 'Development treasury', address: A.treasury }],
    },
    nodes: Object.entries(NODES).map(([name, n]) => ({ name, role: n.role, proxy: `/proxy/${name}`, api_url: n.api, p2p_listen: n.p2p })),
    generated_at_ms: START,
  };
}

const API = {
  '/api/manifest': manifest,
  '/api/keys': () => ({
    keys: [
      { role: 'miner', label: 'node0 coinbase', node: 'node0', address: A.miner0, pubkey: sha('pk/' + A.miner0) },
      { role: 'miner', label: 'node2 coinbase', node: 'node2', address: A.miner2, pubkey: sha('pk/' + A.miner2) },
      { role: 'treasury-signer', label: 'treasury signer 1', address: A.signer1, pubkey: sha('pk/' + A.signer1) },
      { role: 'treasury-signer', label: 'treasury signer 2', address: A.signer2, pubkey: sha('pk/' + A.signer2) },
      { role: 'treasury-signer', label: 'treasury signer 3', address: A.signer3, pubkey: sha('pk/' + A.signer3) },
      { role: 'allocation', label: 'alice (demo)', address: A.alice, pubkey: sha('pk/' + A.alice) },
      { role: 'p2p', label: 'node0 p2p identity', node: 'node0', pubkey: sha('p2p/node0') },
    ],
  }),
  '/api/deployment': () => ({
    package: 'aureom-dev-pow-1-export',
    generated_at_ms: START,
    files: [
      ['genesis.json', 8211], ['manifest.json', 1630], ['nodes/node0/node.toml', 912], ['nodes/node1/node.toml', 905], ['nodes/node2/node.toml', 909],
      ['docker-compose.yml', 2210], ['systemd/aureom-node@.service', 640], ['README-deploy.md', 3120],
    ].map(([path, bytes]) => ({ path, bytes, sha256: sha('file/' + path) })),
    excluded: ['keystores/*', 'nodes/*/admin.token', 'nodes/*/p2p_key'],
  }),
  '/api/recovery': () => ({
    snapshots: [
      { path: 'snapshots/node0-h001000.snap', node: 'node0', height: 1000, state_root: sha('state/1000'), bytes: 3_400_000, created_ms: START - 400_000, verified: true },
      { path: 'snapshots/node0-h000500.snap', node: 'node0', height: 500, state_root: sha('state/500'), bytes: 2_100_000, created_ms: START - 1_400_000, verified: null },
    ],
    backups: [{ path: 'backups/node0-2026-11-26.tar', node: 'node0', height: 980, sha256: sha('backup'), bytes: 51_000_000, created_ms: START - 86_400_000, verified: true }],
  }),
};

// ------------------------------------------------------------------ http

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

function send(res, status, body, type = 'application/json') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(data);
}

async function serveStatic(res, pathname) {
  const rel = normalize(decodeURIComponent(pathname)).replace(/^([/\\])+/, '');
  let file = resolve(join(DIST, rel || 'index.html'));
  if (file !== DIST && !file.startsWith(DIST + sep)) return send(res, 403, { error: { code: 'forbidden', message: 'path' } });
  try {
    const st = await stat(file);
    if (st.isDirectory()) file = join(file, 'index.html');
    const data = await readFile(file);
    send(res, 200, data, MIME[extname(file)] || 'application/octet-stream');
  } catch {
    if (pathname === '/' || pathname === '/index.html') return send(res, 500, 'dist/ not built — run `npm run build` first', 'text/plain');
    send(res, 404, 'not found', 'text/plain');
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', 'http://local');
  const { pathname } = url;
  if (API[pathname]) {
    if (req.method !== 'GET') return send(res, 405, { error: { code: 'method_not_allowed', message: 'GET only' } });
    return send(res, 200, API[pathname]());
  }
  const m = pathname.match(/^\/proxy\/([a-z0-9_-]+)(\/v1\/.*)$/);
  if (m) {
    const [, name, path] = m;
    if (!NODES[name]) return send(res, 404, { error: { code: 'unknown_node', message: `no node ${name} in manifest` } });
    const isPostTx = req.method === 'POST' && path === '/v1/transactions';
    if (req.method !== 'GET' && !isPostTx) return send(res, 405, { error: { code: 'method_not_allowed', message: 'proxy is GET-only except POST /v1/transactions' } });
    if (name === 'node2' && !node2Up()) return send(res, 502, { error: { code: 'upstream_unreachable', message: `connect ECONNREFUSED ${NODES.node2.api.replace('http://', '')}` } });
    const finish = (body) => {
      const r = nodeApi(name, req.method, path, url.searchParams, body);
      send(res, r.status, r.body);
    };
    if (isPostTx) {
      let raw = '';
      req.on('data', (c) => {
        raw += c;
        if (raw.length > 300_000) req.destroy();
      });
      req.on('end', () => {
        let body = null;
        try { body = JSON.parse(raw); } catch { return send(res, 400, { error: { code: 'malformed', message: 'body must be JSON {"tx":"<hex>"}' } }); }
        finish(body);
      });
      return;
    }
    return finish(null);
  }
  if (pathname.startsWith('/admin')) return send(res, 404, { error: { code: 'not_found', message: 'the console never proxies the admin API' } });
  if (req.method !== 'GET') return send(res, 405, { error: { code: 'method_not_allowed', message: 'GET only' } });
  void serveStatic(res, pathname);
});

server.listen(PORT, HOST, () => {
  console.log(`mock console server on http://${HOST}:${PORT}  (dist: ${DIST}; node2 goes down after ${NODE2_UP_MS} ms)`);
});
