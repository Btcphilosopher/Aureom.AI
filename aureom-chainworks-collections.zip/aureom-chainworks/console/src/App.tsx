import type { ReactNode } from 'react';
import { Badge, Notice } from './components/ui';
import { profileLabel, shortHash } from './lib/format';
import { href, useNow, useRoute } from './lib/hooks';
import { chainCheck, isStale, nodeState, useApp } from './lib/state';
import { NetworksPage } from './pages/Networks';
import { NodesPage } from './pages/Nodes';
import { BlocksPage } from './pages/Blocks';
import { TransactionsPage } from './pages/Transactions';
import { AccountsPage } from './pages/Accounts';
import { ConsensusPage } from './pages/Consensus';
import { ValidatorsPage } from './pages/Validators';
import { KeysPage } from './pages/Keys';
import { DeploymentsPage } from './pages/Deployments';
import { MonitoringPage } from './pages/Monitoring';
import { RecoveryPage } from './pages/Recovery';
import { AssetsPage } from './pages/Assets';
import { TreasuryPage } from './pages/Treasury';
import { GovernancePage } from './pages/Governance';
import { CollectionsPage } from './pages/nft/Collections';
import { NftAssetsPage } from './pages/nft/Assets';
import { ActivityPage, ListingsPage, MediaPage, MintingPage, PermissionsPage, TransfersPage } from './pages/nft/Operations';

interface NavItem {
  id: string;
  label: string;
  render: (params: string[]) => ReactNode;
}

const PRIMARY: NavItem[] = [
  { id: 'networks', label: 'Networks', render: () => <NetworksPage /> },
  { id: 'nodes', label: 'Nodes', render: () => <NodesPage /> },
  { id: 'blocks', label: 'Blocks', render: (p) => <BlocksPage blockId={p[0]} /> },
  { id: 'transactions', label: 'Transactions', render: (p) => <TransactionsPage txid={p[0]} /> },
  { id: 'accounts', label: 'Accounts', render: (p) => <AccountsPage address={p[0]} /> },
  { id: 'consensus', label: 'Consensus', render: () => <ConsensusPage /> },
  { id: 'validators', label: 'Validators', render: () => <ValidatorsPage /> },
  { id: 'keys', label: 'Keys', render: () => <KeysPage /> },
  { id: 'deployments', label: 'Deployments', render: () => <DeploymentsPage /> },
  { id: 'monitoring', label: 'Monitoring', render: () => <MonitoringPage /> },
  { id: 'recovery', label: 'Recovery', render: () => <RecoveryPage /> },
];

const SECONDARY: NavItem[] = [
  { id: 'assets', label: 'Assets', render: () => <AssetsPage /> },
  { id: 'treasury', label: 'Treasury', render: (p) => <TreasuryPage address={p[0]} /> },
  { id: 'governance', label: 'Governance', render: () => <GovernancePage /> },
];

// AUREOM COLLECTIONS
const COLLECTIONS: NavItem[] = [
  { id: 'nft-collections', label: 'Collections', render: () => <CollectionsPage /> },
  { id: 'nft-assets', label: 'Assets', render: (p) => <NftAssetsPage cid={p[0]} tid={p[1]} /> },
  { id: 'nft-minting', label: 'Minting', render: () => <MintingPage /> },
  { id: 'nft-transfers', label: 'Transfers', render: () => <TransfersPage /> },
  { id: 'nft-media', label: 'Media', render: () => <MediaPage /> },
  { id: 'nft-permissions', label: 'Permissions', render: () => <PermissionsPage /> },
  { id: 'nft-listings', label: 'Listings', render: () => <ListingsPage /> },
  { id: 'nft-activity', label: 'Activity', render: () => <ActivityPage /> },
];

function Sidebar({ current }: { current: string }) {
  const link = (n: NavItem) => (
    <li key={n.id}>
      <a href={href(n.id)} className={current === n.id ? 'active' : undefined} aria-current={current === n.id ? 'page' : undefined}>
        {n.label}
      </a>
    </li>
  );
  return (
    <nav className="sidebar" aria-label="Console sections">
      <div className="brand">
        <span className="brand-mark" aria-hidden="true">
          ◆
        </span>
        <div>
          <div className="brand-name">AUREOM</div>
          <div className="brand-sub">CHAINWORKS console</div>
        </div>
      </div>
      <ul>{PRIMARY.map(link)}</ul>
      <div className="nav-sep">Ledger</div>
      <ul>{SECONDARY.map(link)}</ul>
      <div className="nav-sep">Collections</div>
      <ul>{COLLECTIONS.map(link)}</ul>
      <div className="sidebar-foot">Read-only console · signed-tx passthrough only</div>
    </nav>
  );
}

function Header() {
  const { manifest, manifestError, nodes, observations, queryNode, setQueryNode, profile } = useApp();
  const now = useNow(1000);
  const net = manifest?.network;
  const name = net?.name ?? net?.network_name ?? '—';
  return (
    <header className="topbar">
      <div className="dev-banner" role="status">
        <Badge tone="caution">DEV</Badge> Development network — not production-secure
      </div>
      <div className="topbar-main">
        <div className="ident">
          <span className="net-name">{name}</span>
          <span className={`profile-badge profile-${profile ?? 'unknown'}`} title="Consensus profile (fixed at genesis)">
            {profileLabel(profile)}
          </span>
          <span className="ident-item">
            <span className="ident-k">chain id</span> <code className="mono">{net?.chain_id ?? '—'}</code>
          </span>
          <span className="ident-item">
            <span className="ident-k">genesis</span>{' '}
            <code className="mono" title={net?.genesis_hash}>
              {shortHash(net?.genesis_hash, 8)}
            </code>
          </span>
        </div>
        <label className="node-select">
          <span className="ident-k">query node</span>
          <select value={queryNode?.name ?? ''} onChange={(e) => setQueryNode(e.target.value)} disabled={!nodes.length}>
            {nodes.map((n) => {
              const o = observations.find((x) => x.node.name === n.name);
              let s = 'pending';
              if (o) {
                const st = nodeState(o, manifest);
                s = st === 'wrong-chain' ? 'WRONG CHAIN' : st;
                if (st !== 'unreachable' && st !== 'pending' && isStale(o, now)) s += ', STALE';
                if (chainCheck(o, manifest).result === 'unknown' && st === 'healthy') s += ', chain unverified';
              }
              return (
                <option key={n.name} value={n.name}>
                  {n.name} ({s})
                </option>
              );
            })}
          </select>
        </label>
      </div>
      {manifestError ? (
        <div className="topbar-error">
          <Badge tone="fail">MANIFEST UNAVAILABLE</Badge> {manifestError}
        </div>
      ) : null}
    </header>
  );
}

export function App() {
  const route = useRoute();
  const { manifest, manifestError } = useApp();
  const item = [...PRIMARY, ...SECONDARY, ...COLLECTIONS].find((n) => n.id === route.page);
  return (
    <div className="shell">
      <Sidebar current={item?.id ?? ''} />
      <div className="main">
        <Header />
        <main className="workspace">
          {!manifest && !manifestError ? <div className="loading">Loading network manifest…</div> : null}
          {!manifest && manifestError ? (
            <Notice tone="fail" title="The console server did not return /api/manifest">
              Without the manifest the console does not know which network or nodes to observe. Check that <code>chainworks console</code> is running for this network
              directory.
            </Notice>
          ) : null}
          {manifest ? item ? item.render(route.params) : <Notice tone="caution">Unknown page “{route.page}”.</Notice> : null}
        </main>
      </div>
    </div>
  );
}
