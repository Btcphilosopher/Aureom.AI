import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { apiGet, nodeGet, proxyFor, type ApiResult, type Health, type Manifest, type ManifestNode, type NativeAsset, type NetworkInfo } from './api';

export const POLL_MS = 3000;
export const STALE_MS = 10000;

export type NodeState = 'pending' | 'unreachable' | 'unhealthy' | 'wrong-chain' | 'healthy';

export interface NodeObservation {
  node: ManifestNode;
  proxy: string;
  health: ApiResult<Health> | null;
  network: ApiResult<NetworkInfo> | null;
  lastHealth: Health | null;
  lastNetwork: NetworkInfo | null;
  /** client clock of last successful /v1/health */
  lastOkAt: number | null;
  lastAttemptAt: number | null;
}

export interface ChainCheck {
  result: 'match' | 'mismatch' | 'unknown';
  problems: string[];
}

export function chainCheck(obs: NodeObservation, manifest: Manifest | null): ChainCheck {
  const net = obs.lastNetwork;
  const want = manifest?.network;
  if (!net || !want) return { result: 'unknown', problems: [] };
  const problems: string[] = [];
  if (want.chain_id && net.chain_id !== want.chain_id) problems.push(`chain_id ${net.chain_id ?? '—'} ≠ manifest ${want.chain_id}`);
  if (want.genesis_hash && net.genesis_hash !== want.genesis_hash) problems.push(`genesis_hash ${net.genesis_hash ?? '—'} ≠ manifest ${want.genesis_hash}`);
  if (want.profile && net.profile && net.profile !== want.profile) problems.push(`profile ${net.profile} ≠ manifest ${want.profile}`);
  if (!want.chain_id && !want.genesis_hash) return { result: 'unknown', problems: ['manifest has no chain_id / genesis_hash'] };
  return { result: problems.length ? 'mismatch' : 'match', problems };
}

export function nodeState(obs: NodeObservation, manifest: Manifest | null): NodeState {
  if (!obs.health) return 'pending';
  if (!obs.health.ok && obs.health.unreachable) return 'unreachable';
  if (chainCheck(obs, manifest).result === 'mismatch') return 'wrong-chain';
  if (!obs.health.ok) return 'unhealthy';
  const h = obs.health.data;
  if (h.status !== 'ok') return 'unhealthy';
  if ((h.alerts ?? []).some((a) => a.level === 'critical')) return 'unhealthy';
  return 'healthy';
}

export function isStale(obs: NodeObservation, now: number): boolean {
  if (obs.lastOkAt === null) return obs.lastAttemptAt !== null;
  return now - obs.lastOkAt > STALE_MS;
}

interface AppState {
  manifest: Manifest | null;
  manifestError: string | null;
  nodes: ManifestNode[];
  observations: NodeObservation[];
  queryNode: ManifestNode | null;
  queryProxy: string | null;
  setQueryNode: (name: string) => void;
  queryNetwork: NetworkInfo | null;
  profile: string | undefined;
  nativeAsset: NativeAsset | undefined;
  decimals: number | undefined;
  ticker: string;
}

const Ctx = createContext<AppState | null>(null);

const LS_KEY = 'aureom.console.queryNode';

function readLs(): string | null {
  try {
    return window.localStorage.getItem(LS_KEY);
  } catch {
    return null;
  }
}
function writeLs(v: string): void {
  try {
    window.localStorage.setItem(LS_KEY, v);
  } catch {
    /* ignore */
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [manifestError, setManifestError] = useState<string | null>(null);
  const [obs, setObs] = useState<Record<string, NodeObservation>>({});
  const [chosen, setChosen] = useState<string | null>(() => readLs());

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const r = await apiGet<Manifest>('/api/manifest');
      if (!alive) return;
      if (r.ok) {
        setManifest(r.data);
        setManifestError(null);
      } else {
        setManifestError(`${r.error.code}: ${r.error.message}`);
      }
    };
    void load();
    const t = setInterval(() => {
      // Retry until a manifest is loaded; afterwards refresh rarely.
      void load();
    }, 30000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  const nodes = useMemo(() => (Array.isArray(manifest?.nodes) ? manifest!.nodes!.filter((n) => n && typeof n.name === 'string') : []), [manifest]);
  const nodesRef = useRef(nodes);
  nodesRef.current = nodes;

  const pollAll = useCallback(async () => {
    const list = nodesRef.current;
    await Promise.all(
      list.map(async (node) => {
        const proxy = proxyFor(node);
        const [health, network] = await Promise.all([nodeGet<Health>(proxy, '/v1/health'), nodeGet<NetworkInfo>(proxy, '/v1/network')]);
        setObs((prev) => {
          const p = prev[node.name];
          const next: NodeObservation = {
            node,
            proxy,
            health,
            network,
            lastHealth: health.ok ? health.data : p?.lastHealth ?? null,
            lastNetwork: network.ok ? network.data : p?.lastNetwork ?? null,
            lastOkAt: health.ok ? health.receivedAt : p?.lastOkAt ?? null,
            lastAttemptAt: health.receivedAt,
          };
          return { ...prev, [node.name]: next };
        });
      }),
    );
  }, []);

  useEffect(() => {
    if (!nodes.length) return;
    void pollAll();
    const t = setInterval(() => void pollAll(), POLL_MS);
    return () => clearInterval(t);
  }, [nodes, pollAll]);

  const observations: NodeObservation[] = useMemo(
    () =>
      nodes.map(
        (n) =>
          obs[n.name] ?? {
            node: n,
            proxy: proxyFor(n),
            health: null,
            network: null,
            lastHealth: null,
            lastNetwork: null,
            lastOkAt: null,
            lastAttemptAt: null,
          },
      ),
    [nodes, obs],
  );

  // Query node: the operator's explicit choice, else the first reachable node on the
  // manifest chain, else the first reachable node, else the first node.
  const queryNode = useMemo(() => {
    if (!nodes.length) return null;
    const explicit = chosen ? nodes.find((n) => n.name === chosen) : undefined;
    if (explicit) return explicit;
    const reachable = observations.filter((o) => o.health && !(!o.health.ok && o.health.unreachable));
    const rightChain = reachable.find((o) => chainCheck(o, manifest).result !== 'mismatch');
    return (rightChain ?? reachable[0])?.node ?? nodes[0];
  }, [nodes, chosen, observations, manifest]);

  const setQueryNode = useCallback((name: string) => {
    setChosen(name);
    writeLs(name);
  }, []);

  const queryObs = queryNode ? observations.find((o) => o.node.name === queryNode.name) : undefined;
  const queryNetwork = queryObs?.lastNetwork ?? null;
  const profile = manifest?.network?.profile ?? queryNetwork?.profile;
  const nativeAsset = manifest?.network?.native_asset ?? queryNetwork?.native_asset;
  const decimals = typeof nativeAsset?.decimals === 'number' ? nativeAsset.decimals : undefined;
  const ticker = nativeAsset?.ticker ?? '';

  const value: AppState = {
    manifest,
    manifestError,
    nodes,
    observations,
    queryNode,
    queryProxy: queryNode ? proxyFor(queryNode) : null,
    setQueryNode,
    queryNetwork,
    profile,
    nativeAsset,
    decimals,
    ticker,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp outside AppProvider');
  return v;
}
