import { apiGet, nodeGet } from './api';
import { usePoll, type Polled } from './hooks';
import { useApp } from './state';

/** GET `path` (/v1/...) on the selected query node, optionally polling. Pass null to skip. */
export function useNodeQuery<T>(path: string | null, intervalMs?: number): Polled<T> & { nodeName: string | null } {
  const { queryProxy, queryNode } = useApp();
  const key = `${queryProxy ?? ''}|${path ?? ''}`;
  const p = usePoll<T>(queryProxy && path ? () => nodeGet<T>(queryProxy, path) : null, key, intervalMs);
  return { ...p, nodeName: queryNode?.name ?? null };
}

/** GET a console-server endpoint (/api/...). */
export function useApi<T>(path: string, intervalMs?: number): Polled<T> {
  return usePoll<T>(() => apiGet<T>(path), path, intervalMs);
}
