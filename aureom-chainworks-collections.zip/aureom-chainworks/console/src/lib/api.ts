// Read-only client for the console server. All URLs are relative (same origin).
// The only non-GET call is the signed-transaction passthrough.

export type Json = Record<string, unknown>;

export interface ApiError {
  code: string;
  message: string;
}

export type ApiResult<T> =
  | { ok: true; status: number; data: T; receivedAt: number }
  | { ok: false; status: number; error: ApiError; unreachable: boolean; receivedAt: number };

function asApiError(body: unknown, status: number): ApiError {
  if (body && typeof body === 'object' && 'error' in body) {
    const e = (body as { error?: unknown }).error;
    if (e && typeof e === 'object') {
      const code = (e as Json).code;
      const message = (e as Json).message;
      return {
        code: typeof code === 'string' ? code : `http_${status}`,
        message: typeof message === 'string' ? message : '',
      };
    }
  }
  return { code: `http_${status}`, message: `HTTP ${status}` };
}

const TIMEOUT_MS = 4000;

async function request<T>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      ...init,
      signal: ctrl.signal,
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { Accept: 'application/json', ...(init?.headers ?? {}) },
    });
    const text = await res.text();
    let body: unknown = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = null;
    }
    const receivedAt = Date.now();
    if (!res.ok) {
      // 502/504 from the console server's proxy mean the node itself could not be reached.
      const unreachable = res.status === 502 || res.status === 504;
      return { ok: false, status: res.status, error: asApiError(body, res.status), unreachable, receivedAt };
    }
    if (body === null || typeof body !== 'object') {
      return { ok: false, status: res.status, error: { code: 'bad_json', message: 'Response was not a JSON object' }, unreachable: false, receivedAt };
    }
    return { ok: true, status: res.status, data: body as T, receivedAt };
  } catch (e) {
    const aborted = e instanceof DOMException && e.name === 'AbortError';
    return {
      ok: false,
      status: 0,
      error: { code: aborted ? 'timeout' : 'network_error', message: aborted ? `No response within ${TIMEOUT_MS} ms` : String(e) },
      unreachable: true,
      receivedAt: Date.now(),
    };
  } finally {
    clearTimeout(timer);
  }
}

export function apiGet<T>(path: string): Promise<ApiResult<T>> {
  return request<T>(path);
}

/** GET through the console server's read-only node proxy. `path` starts with /v1/. */
export function nodeGet<T>(proxy: string, path: string): Promise<ApiResult<T>> {
  return request<T>(`${proxy.replace(/\/$/, '')}${path}`);
}

/** POST an already-signed, hex-encoded transaction. The console never signs. */
export function submitSignedTx(proxy: string, hex: string): Promise<ApiResult<SubmitResult>> {
  return request<SubmitResult>(`${proxy.replace(/\/$/, '')}/v1/transactions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tx: hex }),
  });
}

export function proxyFor(node: ManifestNode): string {
  if (typeof node.proxy === 'string' && node.proxy.startsWith('/')) return node.proxy;
  return `/proxy/${encodeURIComponent(node.name)}`;
}

// ---------------------------------------------------------------- shapes (docs/API.md)
// Every field is optional: profiles differ and the console renders "—" for gaps.

export interface Treasury {
  label?: string;
  address?: string;
}

export interface ManifestNetwork {
  name?: string;
  network_name?: string;
  chain_id?: string;
  profile?: string;
  genesis_hash?: string;
  native_asset?: NativeAsset;
  monetary_policy?: Json;
  fee_policy?: Json;
  limits?: Json;
  consensus?: Json;
  treasuries?: Treasury[];
  [k: string]: unknown;
}

export interface ManifestNode {
  name: string;
  role?: string;
  proxy?: string;
  api_url?: string;
  [k: string]: unknown;
}

export interface Manifest {
  network?: ManifestNetwork;
  nodes?: ManifestNode[];
  generated_at_ms?: number;
}

export interface NativeAsset {
  name?: string;
  ticker?: string;
  decimals?: number;
  address_hrp?: string;
}

export interface NetworkInfo {
  network_name?: string;
  chain_id?: string;
  profile?: string;
  backend?: string;
  backend_version?: string;
  protocol_version?: number;
  node_version?: string;
  genesis_hash?: string;
  node_name?: string;
  native_asset?: NativeAsset;
  monetary_policy?: Json;
  fee_policy?: Json;
  limits?: Json;
  finality?: string;
  confirmations_recommended?: number;
  fault_assumption?: string;
  observed_at_ms?: number;
}

export interface Alert {
  level?: string;
  code?: string;
  message?: string;
}

export interface Health {
  status?: string;
  height?: number;
  tip_id?: string;
  tip_time_ms?: number;
  tip_age_ms?: number;
  peers?: number;
  syncing?: boolean;
  mempool_txs?: number;
  storage?: { db_path?: string; db_bytes?: number | string; db_version?: number; pruning?: Json };
  alerts?: Alert[];
  observed_at_ms?: number;
}

export interface TxJson {
  id?: string;
  version?: number;
  chain_id?: string;
  sender?: string;
  sender_pubkey?: string;
  nonce?: number;
  fee?: string;
  expiry_height?: number;
  action?: Json & { type?: string };
  memo?: string;
}

export interface Receipt {
  txid?: string;
  status?: string;
  error?: string | null;
  error_code?: number;
  fee_paid?: string;
  events?: { kind?: string; attrs?: Record<string, string> }[];
}

export interface Block {
  height?: number;
  id?: string;
  prev_id?: string;
  timestamp_ms?: number;
  proposer?: string;
  tx_count?: number;
  size_bytes?: number;
  state_root?: string;
  tx_root?: string;
  receipt_root?: string;
  txs?: TxJson[];
  receipts?: Receipt[];
  consensus?: {
    pow?: { target?: string; nonce?: string; pow_hash?: string; work?: string; cumulative_work?: string };
    bft?: { cometbft_block_hash?: string; app_hash?: string };
  };
  confirmations?: number;
  finality?: string;
  on_main_chain?: boolean;
  observed_at_ms?: number;
}

export interface BlockList {
  blocks?: Block[];
  observed_at_ms?: number;
}

export interface TxStatus {
  id?: string;
  status?: string;
  block_height?: number | null;
  block_id?: string | null;
  index?: number | null;
  confirmations?: number | null;
  finality?: string | null;
  receipt?: Receipt | null;
  tx?: TxJson | null;
  reason?: string | null;
  observed_at_ms?: number;
}

export interface SubmitResult {
  id?: string;
  status?: string;
  note?: string;
}

export interface TokenBalance {
  token_id?: string;
  symbol?: string;
  name?: string;
  decimals?: number;
  balance?: string;
  frozen?: boolean;
  issuer_permissions?: { mint_authority?: string | null; admin?: string | null; pausable?: boolean; freezable?: boolean };
}

export interface Account {
  address?: string;
  nonce?: number;
  height?: number;
  native?: Record<string, string | undefined>;
  vesting?: { total?: string; start_height?: number; cliff_height?: number; end_height?: number; vested?: string; locked?: string }[];
  immature?: { amount?: string; mature_height?: number }[];
  tokens?: TokenBalance[];
  multisig?: { signers?: string[]; threshold?: number } | null;
  observed_at_ms?: number;
}

export interface Token {
  token_id?: string;
  symbol?: string;
  name?: string;
  decimals?: number;
  supply?: string;
  max_supply?: string | null;
  creator?: string;
  mint_authority?: string | null;
  admin?: string | null;
  pausable?: boolean;
  freezable?: boolean;
  paused?: boolean;
  metadata_uri?: string;
  created_height?: number;
  verified?: string;
}

export interface ConsensusStatus {
  profile?: string;
  engine?: string;
  height?: number;
  tip?: string;
  cumulative_work?: string;
  target?: string;
  difficulty?: string;
  target_block_time_ms?: number;
  recent_block_times_ms?: number[];
  reorgs?: { at_ms?: number; depth?: number; old_tip?: string; new_tip?: string; fork_height?: number }[];
  mining?: { enabled?: boolean; address?: string; hashes?: number };
  finality?: string;
  confirmations_recommended?: number;
  fault_assumption?: string;
  cometbft_version?: string;
  app_height?: number;
  latest_block_hash?: string;
  latest_app_hash?: string;
  catching_up?: boolean;
  total_power?: number;
  round?: number;
  last_commit?: { signed_power?: number; total_power?: number; signers?: number; validators?: number };
  quorum?: string;
  epoch?: { length?: number; next?: number } | null;
  observed_at_ms?: number;
}

export interface Validator {
  operator?: string;
  moniker?: string;
  consensus_pubkey?: string;
  consensus_address?: string;
  power?: number;
  bonded?: string;
  status?: string;
  jailed_until?: number;
  missed_in_window?: number;
  signed_last_block?: boolean | null;
}

export interface ValidatorSet {
  profile?: string;
  total_power?: number;
  validators?: Validator[];
  note?: string;
  observed_at_ms?: number;
}

export interface Peer {
  id?: string;
  address?: string;
  direction?: string;
  height?: number;
  score?: number;
  connected_since_ms?: number;
  protocol_version?: number;
  node_name?: string;
}

export interface Peers {
  peers?: Peer[];
  max_peers?: number;
  observed_at_ms?: number;
}

export interface Supply {
  total?: string;
  genesis?: string;
  minted?: string;
  burned?: string;
  staked?: string;
  unbonding?: string;
  escrow?: string;
  locked_vesting?: string;
  immature?: string;
  treasury?: string;
  circulating?: string;
  max_supply?: string | null;
  reconciled?: boolean;
  tokens_reconciled?: boolean;
  problems?: unknown[];
  height?: number;
  asset?: unknown;
  observed_at_ms?: number;
}

export interface MsigProposal {
  id?: number;
  proposer?: string;
  inner?: Json & { type?: string };
  approvals?: string[] | number;
  approval_count?: number;
  expiry_height?: number;
  status?: string;
  error?: string | null;
}

export interface Multisig {
  address?: string;
  signers?: string[];
  threshold?: number;
  balance?: string;
  proposals?: MsigProposal[];
  observed_at_ms?: number;
}

export interface GovProposal {
  id?: number;
  proposer?: string;
  kind?: (Json & { kind?: string }) | string;
  created_height?: number;
  expiry_height?: number;
  approvals?: string[] | number;
  approving_power?: number;
  total_power?: number;
  threshold?: string;
  status?: string;
  executed_height?: number;
}

export interface KeyEntry {
  role?: string;
  label?: string;
  address?: string;
  pubkey?: string;
  node?: string;
}

export interface DeploymentFile {
  path?: string;
  sha256?: string;
  bytes?: number;
  size?: number;
}

export interface RecoveryItem {
  path?: string;
  kind?: string;
  node?: string;
  height?: number;
  state_root?: string;
  sha256?: string;
  bytes?: number;
  created_ms?: number;
  verified?: boolean | null;
}

/** Pick the first array-valued field among `keys` (or the value itself if it is an array). */
export function pickArray<T>(v: unknown, ...keys: string[]): T[] {
  if (Array.isArray(v)) return v as T[];
  if (v && typeof v === 'object') {
    for (const k of keys) {
      const x = (v as Json)[k];
      if (Array.isArray(x)) return x as T[];
    }
  }
  return [];
}
