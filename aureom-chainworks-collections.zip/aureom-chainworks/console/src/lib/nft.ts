// Types and helpers for the Collections section (console server /api/nft/*).
// Index rows are a cache of chain events; authoritative values come from the node.

export interface Settlement {
  state?: string;
  confirmations?: number;
  recommended?: number;
  semantics?: string;
}

export interface Power {
  power?: string;
  holder?: string | null;
  limit?: string;
  risk?: string;
}

export interface MetadataRef {
  uri?: string;
  sha256?: string;
}

export interface ChainCollection {
  collection_id?: string;
  spec?: {
    slug?: string;
    name?: string;
    collection_metadata?: MetadataRef;
    pausable?: boolean;
    forced_transfer?: boolean;
    owner_burn?: boolean;
    transfer_policy?: string;
    rights?: MetadataRef;
  };
  roles?: { creator?: string; admin?: string | null; mint_authority?: string | null; metadata_admin?: string | null; royalty_recipient?: string | null; rights_holder?: string; note?: string };
  administrative_powers?: Power[];
  minted?: number;
  burned?: number;
  live?: number;
  max_supply?: string | null;
  paused?: boolean;
  metadata_policy?: string;
  metadata_frozen_all?: boolean;
  metadata_root?: string;
  royalty?: { recipient?: string; bps?: number; enforced_by?: string } | null;
  created_height?: number;
  state_height?: number;
  authority_log?: { seq?: number; role?: string; old?: string | null; new?: string | null; height?: number; by?: string }[];
}

export interface IndexCollection {
  collection_id: string;
  slug?: string;
  minted?: number;
  burned?: number;
  as_of_height?: number;
}

export interface Summary {
  module?: { enabled?: boolean; marketplace?: boolean; marketplace_fee_bps?: number; marketplace_fee_recipient?: string | null; implementation?: string; activation_height?: number };
  network?: { chain_id?: string; genesis_hash?: string; profile?: string; settlement?: string; confirmations_recommended?: number };
  index?: { height?: number; block_id?: string; source_node?: string; node_tip?: number | null; error?: string | null; note?: string };
  counts?: Record<string, number>;
  requests?: { status: string; n: number }[];
}

export interface AssetDoc {
  name?: string;
  description?: string;
  image_sha256?: string;
  image_mime?: string;
  alt_text?: string;
  attributes?: { trait_type?: string; value?: unknown }[];
  rights?: { holder?: string; licence?: string; statement?: string; token_owner_receives_copyright?: boolean; note?: string };
}

export interface Asset {
  collection_id: string;
  token_id: string;
  slug?: string;
  owner?: string | null;
  burned?: number;
  metadata_uri?: string;
  metadata_hash?: string;
  revision?: number;
  frozen?: number;
  minted_height?: number;
  last_event_height?: number;
  transfers?: number;
  approved?: string | null;
  as_of_height?: number;
  document?: AssetDoc | null;
  settlement?: Settlement;
}

export interface ProvEvent {
  height?: number;
  block_id?: string;
  txid?: string;
  kind?: string;
  op?: string | null;
  from_addr?: string | null;
  to_addr?: string | null;
  actor?: string | null;
  attrs?: Record<string, string>;
  settlement?: Settlement;
}

export interface StorageLoc {
  adapter?: string;
  locator?: string;
  public_uri?: string | null;
  maintainer?: string;
  monitoring?: string;
  last_available?: number | null;
  last_hash_ok?: number | null;
  last_checked?: number | null;
  last_available_ms?: number | null;
  last_checked_ms?: number | null;
  last_detail?: string | null;
  content_sha256?: string;
}

export interface TxOutcome {
  txid: string;
  height?: number;
  action_type?: string;
  sender?: string;
  status?: string;
  error?: string | null;
  fee_paid?: string;
  action?: Record<string, unknown>;
  settlement?: Settlement;
}

export interface ModuleRequest {
  request_id: string;
  idempotency_key?: string;
  kind?: string;
  sender?: string;
  collection_id?: string | null;
  token_ids?: string[];
  status?: string;
  txid?: string | null;
  attempts?: number;
  last_error?: string | null;
  block_height?: number | null;
  created_at_ms?: number;
  updated_at_ms?: number;
  history?: { at_ms?: number; from_status?: string | null; to_status?: string; detail?: string | null }[];
}

export const LIFECYCLE = ['prepared', 'validated', 'signed', 'submitted', 'included', 'confirmed', 'indexed'];

export function lifecycleIndex(status: string | undefined): number {
  if (!status) return -1;
  if (status === 'finalised') return LIFECYCLE.indexOf('confirmed');
  if (status === 'unknown') return LIFECYCLE.indexOf('submitted');
  return LIFECYCLE.indexOf(status);
}

export function requestTone(s: string | undefined): 'ok' | 'info' | 'caution' | 'fail' | 'neutral' {
  if (s === 'indexed' || s === 'confirmed' || s === 'finalised') return 'ok';
  if (s === 'failed' || s === 'rejected' || s === 'dropped') return 'fail';
  if (s === 'unknown') return 'caution';
  if (s === 'included' || s === 'submitted' || s === 'signed') return 'info';
  return 'neutral';
}

export function riskTone(r: string | undefined): 'ok' | 'info' | 'caution' | 'fail' | 'neutral' {
  if (r === 'critical') return 'fail';
  if (r === 'high') return 'caution';
  if (r === 'medium') return 'info';
  if (r === 'none') return 'ok';
  return 'neutral';
}

export function mediaUrl(sha: string | undefined | null): string | null {
  return sha && /^[0-9a-f]{64}$/.test(sha) ? `/media/${sha}` : null;
}

export function short(a: string | null | undefined, n = 10): string {
  if (!a) return '—';
  return a.length > n * 2 + 1 ? `${a.slice(0, n)}…${a.slice(-6)}` : a;
}
