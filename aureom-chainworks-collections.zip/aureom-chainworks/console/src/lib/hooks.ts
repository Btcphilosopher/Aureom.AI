import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { ApiResult } from './api';

export interface Polled<T> {
  /** Most recent response (success or failure). */
  last: ApiResult<T> | null;
  /** Most recent successful payload, kept while later polls fail. */
  data: T | null;
  /** Client wall clock (ms) of the most recent success. */
  lastOkAt: number | null;
  loading: boolean;
  refresh: () => void;
}

/**
 * Fetch on mount / when `key` changes, and every `intervalMs` if given.
 * Failures keep the last good payload so callers can label it stale.
 */
export function usePoll<T>(fetcher: (() => Promise<ApiResult<T>>) | null, key: string, intervalMs?: number): Polled<T> {
  const [last, setLast] = useState<ApiResult<T> | null>(null);
  const [data, setData] = useState<T | null>(null);
  const [lastOkAt, setLastOkAt] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(fetcher !== null);
  const fetchRef = useRef(fetcher);
  fetchRef.current = fetcher;
  const gen = useRef(0);
  const inflight = useRef(false);

  const run = useCallback(async (g: number) => {
    const f = fetchRef.current;
    if (!f || inflight.current) return;
    inflight.current = true;
    try {
      const r = await f();
      if (g !== gen.current) return;
      setLast(r);
      if (r.ok) {
        setData(r.data);
        setLastOkAt(r.receivedAt);
      }
      setLoading(false);
    } finally {
      inflight.current = false;
    }
  }, []);

  useEffect(() => {
    gen.current++;
    const g = gen.current;
    inflight.current = false;
    setLast(null);
    setData(null);
    setLastOkAt(null);
    setLoading(fetchRef.current !== null);
    void run(g);
    if (!intervalMs) return;
    const t = setInterval(() => void run(g), intervalMs);
    return () => clearInterval(t);
  }, [key, intervalMs, run]);

  const refresh = useCallback(() => void run(gen.current), [run]);
  return { last, data, lastOkAt, loading, refresh };
}

/** A clock that ticks every `ms` so ages re-render. */
export function useNow(ms = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

// ---------------------------------------------------------------- tiny hash router

function subscribe(cb: () => void): () => void {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

function snapshot(): string {
  return window.location.hash || '#/networks';
}

export interface Route {
  page: string;
  params: string[];
}

export function parseHash(h: string): Route {
  const raw = h.replace(/^#\/?/, '').split('?')[0] ?? '';
  const parts = raw.split('/').filter(Boolean).map((p) => {
    try {
      return decodeURIComponent(p);
    } catch {
      return p;
    }
  });
  return { page: parts[0] ?? 'networks', params: parts.slice(1) };
}

export function useRoute(): Route {
  const h = useSyncExternalStore(subscribe, snapshot, snapshot);
  return parseHash(h);
}

export function href(page: string, ...params: (string | number)[]): string {
  return `#/${[page, ...params.map((p) => encodeURIComponent(String(p)))].join('/')}`;
}

export function navigate(page: string, ...params: (string | number)[]): void {
  window.location.hash = href(page, ...params);
}
