// Formatting helpers. Amounts are base-unit decimal strings and are only ever
// handled as BigInt — never as JS numbers / floats.

export const DASH = '—';

const DIGITS = /^\d+$/;

export function isAmount(v: unknown): v is string {
  return typeof v === 'string' && DIGITS.test(v);
}

export function toBig(v: unknown): bigint | null {
  if (typeof v === 'string' && DIGITS.test(v)) return BigInt(v);
  if (typeof v === 'number' && Number.isSafeInteger(v) && v >= 0) return BigInt(v);
  if (typeof v === 'bigint') return v;
  return null;
}

function group(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/** Format a base-unit amount with `decimals` places. Returns "—" for missing/invalid input. */
export function formatAmount(v: unknown, decimals: unknown, opts: { trim?: boolean } = {}): string {
  const b = toBig(v);
  if (b === null) return DASH;
  const d = typeof decimals === 'number' && Number.isInteger(decimals) && decimals >= 0 && decimals <= 36 ? decimals : null;
  if (d === null) return `${group(b.toString())} (base units)`;
  if (d === 0) return group(b.toString());
  const base = 10n ** BigInt(d);
  const whole = b / base;
  let frac = (b % base).toString().padStart(d, '0');
  if (opts.trim !== false) frac = frac.replace(/0+$/, '');
  return frac.length ? `${group(whole.toString())}.${frac}` : group(whole.toString());
}

export function formatBaseUnits(v: unknown): string {
  const b = toBig(v);
  return b === null ? DASH : group(b.toString());
}

export function num(v: unknown): string {
  if (typeof v === 'number' && Number.isFinite(v)) return Number.isInteger(v) ? group(String(v)) : String(v);
  if (typeof v === 'string' && v.length) return DIGITS.test(v) ? group(v) : v;
  return DASH;
}

export function str(v: unknown): string {
  if (v === null || v === undefined || v === '') return DASH;
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return DASH;
}

export function yesNo(v: unknown): string {
  if (v === true) return 'yes';
  if (v === false) return 'no';
  return DASH;
}

export function shortHash(v: unknown, n = 8): string {
  if (typeof v !== 'string' || !v) return DASH;
  if (v.length <= n * 2 + 1) return v;
  return `${v.slice(0, n)}…${v.slice(-4)}`;
}

export function formatBytes(v: unknown): string {
  const b = toBig(v);
  if (b === null) return DASH;
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let i = 0;
  let whole = b;
  let rem = 0n;
  while (whole >= 1024n && i < units.length - 1) {
    rem = whole % 1024n;
    whole = whole / 1024n;
    i++;
  }
  if (i === 0) return `${whole} B`;
  const tenth = (rem * 10n) / 1024n;
  return `${whole}.${tenth} ${units[i]}`;
}

export function formatDuration(ms: unknown): string {
  if (typeof ms !== 'number' || !Number.isFinite(ms)) return DASH;
  const neg = ms < 0;
  let s = Math.abs(ms) / 1000;
  let out: string;
  if (s < 1) out = `${Math.round(Math.abs(ms))} ms`;
  else if (s < 60) out = `${s.toFixed(1)} s`;
  else if (s < 3600) out = `${Math.floor(s / 60)} min ${Math.floor(s % 60)} s`;
  else if (s < 86400) out = `${Math.floor(s / 3600)} h ${Math.floor((s % 3600) / 60)} min`;
  else {
    s = s / 86400;
    out = `${s.toFixed(1)} d`;
  }
  return neg ? `-${out}` : out;
}

/** Age since `t` on the client clock, never negative (polls can land after the clock tick). */
export function ago(now: number, t: number): number {
  return Math.max(0, now - t);
}

export function formatTime(ms: unknown): string {
  if (typeof ms !== 'number' || !Number.isFinite(ms) || ms <= 0) return DASH;
  const d = new Date(ms);
  return d.toISOString().replace('T', ' ').replace(/\.\d+Z$/, ' UTC');
}

export function formatBps(v: unknown): string {
  if (typeof v !== 'number' || !Number.isFinite(v)) return DASH;
  return `${v} bps (${(v / 100).toFixed(2)} %)`;
}

/** Ratio of two BigInt-able values as a percentage string with one decimal, computed without floats on big values. */
export function pct(part: unknown, whole: unknown): string {
  const p = toBig(part);
  const w = toBig(whole);
  if (p === null || w === null || w === 0n) return DASH;
  const tenths = (p * 1000n) / w;
  return `${tenths / 10n}.${tenths % 10n} %`;
}

export function ratio(part: unknown, whole: unknown): number | null {
  const p = toBig(part);
  const w = toBig(whole);
  if (p === null || w === null || w === 0n) return null;
  return Number((p * 10000n) / w) / 10000;
}

export const PROFILE_LABEL: Record<string, string> = { pow: 'PoW', pos: 'PoS', poa: 'PoA' };

export function profileLabel(p: unknown): string {
  return typeof p === 'string' && PROFILE_LABEL[p] ? PROFILE_LABEL[p] : DASH;
}

export function isBft(p: unknown): boolean {
  return p === 'pos' || p === 'poa';
}
