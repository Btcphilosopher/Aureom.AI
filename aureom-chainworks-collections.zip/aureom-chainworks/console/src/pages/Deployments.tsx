import { Card, ErrorBox, KV, Loading, Mono, Notice, Page, Table } from '../components/ui';
import { pickArray, type DeploymentFile, type Json } from '../lib/api';
import { formatBytes, formatTime, str } from '../lib/format';
import { useApi } from '../lib/query';

export function DeploymentsPage() {
  const q = useApi<Json>('/api/deployment');
  const files = pickArray<DeploymentFile>(q.data, 'files');
  const d = q.data ?? {};
  return (
    <Page title="Deployments" subtitle="Export package for this network: file list with SHA-256 checksums.">
      <Notice tone="security" title="Secrets are excluded">
        Private keys, keystores, admin API tokens and other credentials are excluded from exports. The package contains public configuration (genesis, node configs
        without secrets, manifests) only. Verify checksums out-of-band before using a package on another host.
      </Notice>
      <ErrorBox result={q.last} what="deployment package" />
      {q.loading ? <Loading what="deployment" /> : null}
      {q.data ? (
        <Card title="Package">
          <KV
            rows={[
              ['package', <Mono>{str(d.package ?? d.name ?? d.path)}</Mono>],
              ['generated', formatTime(d.generated_at_ms)],
              ['files', String(files.length)],
            ]}
          />
        </Card>
      ) : null}
      <Card title="Files">
        <Table
          head={['path', 'size', 'SHA-256']}
          rows={files.map((f) => [<Mono>{str(f.path)}</Mono>, formatBytes(f.bytes ?? f.size), <code className="mono small">{str(f.sha256)}</code>])}
          empty="No files listed."
        />
      </Card>
    </Page>
  );
}
