import { Amount, Badge, Bar, Card, ErrorBox, Freshness, Hash, Loading, Notice, Page, Table, type Tone } from '../components/ui';
import { pickArray, type Validator, type ValidatorSet } from '../lib/api';
import { DASH, num, str } from '../lib/format';
import { useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';

const STATUS_TONE: Record<string, Tone> = { active: 'ok', inactive: 'neutral', jailed: 'caution', tombstoned: 'fail', removed: 'fail' };

function statusBadge(s: unknown) {
  const k = typeof s === 'string' ? s : '';
  return <Badge tone={STATUS_TONE[k] ?? 'neutral'}>{k ? k.toUpperCase() : DASH}</Badge>;
}

export function ValidatorsPage() {
  const { profile, decimals, ticker } = useApp();
  const now = useNow(1000);
  const q = useNodeQuery<ValidatorSet>(profile === 'pow' ? null : '/v1/validators', 5000);
  if (profile === 'pow') {
    return (
      <Page title="Validators">
        <Notice tone="info" title="Proof-of-work networks have no validator set">
          Blocks are produced by whoever finds a valid proof-of-work. There is no staking, jailing or voting power; see Consensus for mining and difficulty.
        </Notice>
      </Page>
    );
  }
  const vs = pickArray<Validator>(q.data?.validators);
  const total = q.data?.total_power ?? vs.reduce((s, v) => s + (typeof v.power === 'number' && v.status === 'active' ? v.power : 0), 0);
  const counts = vs.reduce<Record<string, number>>((m, v) => ({ ...m, [v.status ?? 'unknown']: (m[v.status ?? 'unknown'] ?? 0) + 1 }), {});
  return (
    <Page
      title="Validators"
      subtitle={profile === 'poa' ? 'Proof-of-authority: fixed authority set changed only by governance.' : 'Proof-of-stake validator set (voting power = floor(bonded / power_unit)).'}
      actions={<Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />}
    >
      {profile === 'poa' ? (
        <Notice tone="caution" title="Permissioned network">
          Permissioned network — several nodes run by one organisation are not decentralised. Security rests entirely on the honesty and independence of the authority
          operators.
        </Notice>
      ) : null}
      <ErrorBox result={q.last} what="validators" />
      {q.loading ? <Loading what="validators" /> : null}
      <Card
        title={`Validator set (${vs.length})`}
        right={
          <span className="small">
            total power {num(total)} ·{' '}
            {Object.entries(counts)
              .map(([k, n]) => `${n} ${k}`)
              .join(' · ')}
          </span>
        }
      >
        <Table
          head={['moniker', 'operator', 'status', 'power', 'share', profile === 'pos' ? 'bonded' : 'consensus address', 'signed last block', 'missed (window)', 'jailed until']}
          rows={vs.map((v) => {
            const share = typeof v.power === 'number' && total > 0 ? v.power / total : null;
            return [
              <strong>{str(v.moniker)}</strong>,
              <Hash value={v.operator} />,
              statusBadge(v.status),
              num(v.power),
              <span className="row-gap">
                <Bar value={share} width={110} label={share === null ? DASH : `${(share * 100).toFixed(1)} % of voting power`} />
                <span className="small">{share === null ? DASH : `${(share * 100).toFixed(1)} %`}</span>
              </span>,
              profile === 'pos' ? <Amount value={v.bonded} decimals={decimals} unit={ticker} /> : <Hash value={v.consensus_address} />,
              v.signed_last_block === true ? <Badge tone="ok">signed</Badge> : v.signed_last_block === false ? <Badge tone="caution">missed</Badge> : DASH,
              num(v.missed_in_window),
              v.jailed_until ? num(v.jailed_until) : DASH,
            ];
          })}
          empty="No validators returned."
        />
        <p className="small dim">
          Status: ACTIVE in the consensus set · INACTIVE (power 0 / not in top set) · JAILED (downtime, can unjail after the jail period) · TOMBSTONED (proven
          equivocation, permanent) · REMOVED (PoA authority removed by governance or evidence).
        </p>
      </Card>
    </Page>
  );
}
