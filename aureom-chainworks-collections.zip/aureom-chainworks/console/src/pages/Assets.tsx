import type { ReactNode } from 'react';
import { Amount, Badge, Card, ErrorBox, Freshness, IssuerTag, KV, Loading, Mono, Notice, OnChainTag, Page, Table } from '../components/ui';
import { pickArray, type Supply, type Token } from '../lib/api';
import { DASH, num, pct, str } from '../lib/format';
import { useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';
import { duplicateSymbols, Perm, SymbolWarning } from './Accounts';

function recon(v: unknown, label: string) {
  if (v === true) return <Badge tone="ok">{label} reconciled ✓</Badge>;
  if (v === false) return <Badge tone="fail">{label} NOT reconciled ✗</Badge>;
  return <span className="dim">{label}: {DASH}</span>;
}

export function AssetsPage() {
  const { decimals, ticker, nativeAsset } = useApp();
  const now = useNow(1000);
  const sq = useNodeQuery<Supply>('/v1/supply', 6000);
  const tq = useNodeQuery<{ tokens?: Token[] }>('/v1/tokens', 10000);
  const s = sq.data;
  const tokens = pickArray<Token>(tq.data, 'tokens');
  const dups = duplicateSymbols(tokens);
  const amt = (v: unknown) => <Amount value={v} decimals={decimals} unit={ticker} />;
  const row = (k: string, v: unknown, note?: string): [string, ReactNode] => [
    k,
    <span>
      {amt(v)} {s?.total && typeof v === 'string' && k !== 'total' ? <span className="dim small">({pct(v, s.total)} of total)</span> : null}
      {note ? <span className="dim small"> — {note}</span> : null}
    </span>,
  ];
  const problems = pickArray<unknown>(s?.problems);
  return (
    <Page title="Assets" subtitle="Native coin supply report and the token registry, from the selected query node.">
      <Notice tone="caution" title="No implied value">
        Creating an asset does not give it monetary value, reserve backing, exchange listing or legal status.
      </Notice>
      <ErrorBox result={sq.last} what="supply" />
      {sq.loading ? <Loading what="supply" /> : null}
      <div className="grid-2">
        <Card title={`Native supply — ${str(nativeAsset?.name)} (${str(ticker)})`} right={<Freshness lastOkAt={sq.lastOkAt} now={now} />}>
          <div className="badge-row">
            {recon(s?.reconciled, 'native supply')}
            {recon(s?.tokens_reconciled, 'token supplies')}
            <span className="small dim">at height {num(s?.height)}</span>
          </div>
          {s?.reconciled === false || s?.tokens_reconciled === false || problems.length ? (
            <Notice tone="fail" title="Supply reconciliation problems">
              <ul className="tight">
                {problems.map((p, i) => (
                  <li key={i}>
                    <Mono>{typeof p === 'string' ? p : JSON.stringify(p)}</Mono>
                  </li>
                ))}
                {problems.length === 0 ? <li>The node reported a failed reconciliation without details.</li> : null}
              </ul>
            </Notice>
          ) : null}
          <KV
            rows={[
              row('total', s?.total, 'genesis + minted − burned'),
              row('genesis', s?.genesis),
              row('minted', s?.minted),
              row('burned', s?.burned, 'provable removals only'),
              row('circulating', s?.circulating, 'total − locked − immature − staked − escrow − treasury'),
              row('locked (vesting)', s?.locked_vesting),
              row('immature', s?.immature),
              row('staked', s?.staked),
              row('unbonding', s?.unbonding),
              row('escrow (distributions)', s?.escrow),
              row('treasury', s?.treasury),
              ['max supply', s?.max_supply ? amt(s.max_supply) : s ? 'uncapped / not reported' : DASH],
            ]}
          />
          <p className="small dim">Coins held by lost or inaccessible keys cannot be distinguished from circulating coins.</p>
        </Card>
        <Card title="On-chain facts vs issuer-supplied descriptions">
          <p className="small">
            <OnChainTag /> Enforced by the ledger: <Mono>token_id</Mono>, supply, max supply, decimals, creator, mint authority, admin, pausable/freezable flags, paused
            state, creation height.
          </p>
          <p className="small">
            <IssuerTag /> Chosen freely by whoever created the token and never verified: symbol, name, metadata URI. Two unrelated tokens can share a symbol and name.
          </p>
          <p className="small dim">
            The native coin ({str(ticker)}) is not a token; it is identified by the network itself.
          </p>
        </Card>
      </div>
      <Card title={`Tokens (${tokens.length})`} right={<Freshness lastOkAt={tq.lastOkAt} now={now} />}>
        <ErrorBox result={tq.last} what="tokens" />
        <SymbolWarning dups={dups} />
        <Table
          head={[
            <span>
              token_id <OnChainTag />
            </span>,
            <span>
              symbol / name <IssuerTag />
            </span>,
            <span>
              supply / max <OnChainTag />
            </span>,
            <span>
              issuer permissions <OnChainTag />
            </span>,
            'state',
            <span>
              metadata URI <IssuerTag />
            </span>,
          ]}
          rows={tokens.map((t) => {
            const dup = !!t.symbol && dups.has(t.symbol.toUpperCase());
            return [
              <div>
                <code className="mono strong token-id-cell">{str(t.token_id)}</code>
                <div className="small dim">
                  created at {num(t.created_height)} by <Mono>{str(t.creator).slice(0, 14)}…</Mono>
                </div>
              </div>,
              <div>
                <strong>{str(t.symbol)}</strong> {dup ? <Badge tone="caution">SYMBOL NOT UNIQUE</Badge> : null}
                <div className="small">{str(t.name)}</div>
              </div>,
              <div>
                <Amount value={t.supply} decimals={t.decimals} />
                <div className="small dim">max {t.max_supply ? <Amount value={t.max_supply} decimals={t.decimals} /> : 'uncapped'} · decimals {num(t.decimals)}</div>
              </div>,
              <div className="small perms-col">
                <Perm label="mint authority" value={t.mint_authority} />
                <Perm label="admin" value={t.admin} />
                <Perm label="pausable" value={t.pausable} />
                <Perm label="freezable" value={t.freezable} />
              </div>,
              t.paused ? <Badge tone="fail">PAUSED</Badge> : t.paused === false ? <span className="small">active</span> : DASH,
              t.metadata_uri ? <span className="mono small unverified" title="Issuer-supplied, unverified. Not fetched by the console.">{t.metadata_uri}</span> : DASH,
            ];
          })}
          empty="No tokens registered."
        />
        <p className="small dim">The console never fetches metadata URIs. A token with no mint authority and no admin is fixed-supply and cannot be paused or frozen.</p>
      </Card>
    </Page>
  );
}
