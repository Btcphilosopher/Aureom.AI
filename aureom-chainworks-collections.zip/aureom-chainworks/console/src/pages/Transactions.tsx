import { useEffect, useState, type FormEvent } from 'react';
import { Amount, Badge, Card, ErrorBox, Freshness, Hash, Json, KV, Loading, Mono, Notice, Page, Table, type Tone } from '../components/ui';
import { pickArray, submitSignedTx, type ApiResult, type Json as JsonT, type SubmitResult, type TxJson, type TxStatus } from '../lib/api';
import { DASH, formatBytes, formatTime, isBft, num, str } from '../lib/format';
import { href, navigate, useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';
import { actionSummary, finalityLabel } from './Blocks';

export const LIFECYCLE: { state: string; tone: Tone; meaning: string }[] = [
  { state: 'received', tone: 'neutral', meaning: 'Bytes arrived at a node API or peer. Nothing has been checked yet.' },
  { state: 'validated', tone: 'neutral', meaning: 'Passed stateless and mempool-level stateful checks on that one node.' },
  { state: 'pending', tone: 'caution', meaning: "Held in that node's mempool. Pending is NOT included: inclusion is not guaranteed and the tx may still be dropped." },
  { state: 'included', tone: 'info', meaning: "In a block on the node's current best chain. On PoW this can still be reversed by a reorganisation." },
  { state: 'confirmed', tone: 'info', meaning: 'PoW only: included with at least the recommended number of blocks on top. Probabilistic — a heavier branch can still reverse it.' },
  { state: 'finalised', tone: 'ok', meaning: 'BFT (PoS/PoA) only: block committed by > 2/3 of voting power. Irreversible while < 1/3 of voting power is Byzantine.' },
  { state: 'rejected', tone: 'fail', meaning: 'Failed validation; never entered the mempool.' },
  { state: 'dropped', tone: 'fail', meaning: 'Left the mempool without inclusion (evicted, expired, invalidated by a reorg or a conflicting tx).' },
  { state: 'unknown', tone: 'neutral', meaning: 'This node has no record of the id. Another node may; ids are not proof that a tx exists.' },
];

function stateTone(s: unknown): Tone {
  return LIFECYCLE.find((l) => l.state === s)?.tone ?? 'neutral';
}

function TxDetail({ txid }: { txid: string }) {
  const { decimals, ticker, profile, queryNetwork } = useApp();
  const q = useNodeQuery<TxStatus>(`/v1/transactions/${encodeURIComponent(txid)}`, 4000);
  const now = useNow(1000);
  const t = q.data;
  const r = t?.receipt ?? null;
  const tx = t?.tx ?? null;
  return (
    <>
      <ErrorBox result={q.last} what={`transaction ${txid}`} />
      {q.loading ? <Loading what="transaction" /> : null}
      {t ? (
        <div className="grid-2">
          <Card title="Lifecycle" right={<Freshness lastOkAt={q.lastOkAt} now={now} />}>
            <p className="tx-state">
              State on <strong>{q.nodeName}</strong>: <Badge tone={stateTone(t.status)}>{str(t.status).toUpperCase()}</Badge>
            </p>
            <ol className="lifecycle">
              {LIFECYCLE.filter((l) => l.state !== 'unknown')
                .filter((l) => (profile === 'pow' ? l.state !== 'finalised' : isBft(profile) ? l.state !== 'confirmed' : true))
                .map((l) => (
                  <li key={l.state} className={l.state === t.status ? 'current' : undefined}>
                    <Mono>{l.state}</Mono>
                    {l.state === t.status ? ' ◀ current' : ''} — <span className="small">{l.meaning}</span>
                  </li>
                ))}
            </ol>
            {t.reason ? (
              <Notice tone="caution" title="Reason">
                {t.reason}
              </Notice>
            ) : null}
            <KV
              rows={[
                ['tx id', <Hash value={t.id ?? txid} full />],
                ['block', t.block_height !== null && t.block_height !== undefined ? <a href={href('blocks', String(t.block_id ?? t.block_height))}>{num(t.block_height)}</a> : DASH],
                ['index in block', num(t.index)],
                ['confirmations', num(t.confirmations)],
                ['finality', t.finality ? finalityLabel(t.finality, t.confirmations, queryNetwork?.confirmations_recommended) : DASH],
              ]}
            />
          </Card>
          <Card title="Transaction & receipt">
            <KV
              rows={[
                ['sender', tx?.sender ? <a href={href('accounts', tx.sender)}><Hash value={tx.sender} full /></a> : DASH],
                ['nonce', num(tx?.nonce)],
                ['chain id', <Mono>{str(tx?.chain_id)}</Mono>],
                ['action', actionSummary(tx, decimals, ticker)],
                ['fee (declared)', <Amount value={tx?.fee} decimals={decimals} unit={ticker} />],
                ['expiry height', tx?.expiry_height === 0 ? 'no expiry' : num(tx?.expiry_height)],
                ['memo', str(tx?.memo)],
                ['receipt status', r ? r.status === 'success' ? <Badge tone="ok">success</Badge> : <Badge tone="fail">failed</Badge> : DASH],
                ['error', r?.error ? <Mono>{r.error}</Mono> : DASH],
                ['fee paid', <Amount value={r?.fee_paid} decimals={decimals} unit={ticker} />],
              ]}
            />
            {r?.status === 'failed' ? <p className="small">A failed receipt still consumed the nonce and charged the fee; the action's effects were reverted.</p> : null}
            <Json value={t} />
          </Card>
        </div>
      ) : null}
    </>
  );
}

interface MempoolEntry extends TxJson {
  txid?: string;
  size_bytes?: number;
  received_ms?: number;
  received_at_ms?: number;
}

function Mempool() {
  const { decimals, ticker } = useApp();
  const q = useNodeQuery<JsonT>('/v1/mempool', 4000);
  const now = useNow(1000);
  const entries = pickArray<MempoolEntry>(q.data, 'txs', 'transactions', 'entries');
  const d = q.data ?? {};
  return (
    <Card title={`Mempool of ${q.nodeName ?? DASH}`} right={<Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />}>
      <ErrorBox result={q.last} what="mempool" />
      <p className="small dim">
        Local view of one node: {num(d.count ?? d.size ?? entries.length)} tx(s){d.bytes !== undefined ? `, ${formatBytes(d.bytes)}` : ''}
        {d.max_txs !== undefined ? ` (max ${num(d.max_txs)})` : ''}. Other nodes may hold different transactions; being here guarantees nothing about inclusion.
      </p>
      <Table
        head={['tx id', 'sender', 'nonce', 'fee', 'action', 'received']}
        rows={entries.map((e) => {
          const id = e.id ?? e.txid;
          return [
            id ? <a href={href('transactions', id)}><Hash value={id} /></a> : DASH,
            <Hash value={e.sender} />,
            num(e.nonce),
            <Amount value={e.fee} decimals={decimals} unit={ticker} />,
            e.action ? actionSummary(e, decimals, ticker) : DASH,
            formatTime(e.received_ms ?? e.received_at_ms),
          ];
        })}
        empty="Mempool is empty."
      />
    </Card>
  );
}

const HEX = /^(0x)?[0-9a-fA-F]+$/;

function Submit() {
  const { queryProxy, queryNode } = useApp();
  const [hex, setHex] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ApiResult<SubmitResult> | null>(null);
  const clean = hex.replace(/\s+/g, '');
  const valid = clean.length > 0 && HEX.test(clean) && clean.replace(/^0x/, '').length % 2 === 0;
  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid || !queryProxy) return;
    setBusy(true);
    setResult(await submitSignedTx(queryProxy, clean.replace(/^0x/, '').toLowerCase()));
    setBusy(false);
  };
  return (
    <Card title="Submit signed transaction">
      <Notice tone="security" title="Signing happens in the CLI wallet, never in the console">
        Paste only a hex-encoded, <strong>already signed</strong> transaction (for example the output of the <Mono>chainworks</Mono> CLI wallet). The console has no key material and
        cannot sign, modify or approve anything. Never paste private keys, keystore files, passphrases or seed phrases here.
      </Notice>
      <form onSubmit={onSubmit} autoComplete="off">
        <label className="field">
          <span>Signed transaction (hex)</span>
          <textarea
            value={hex}
            onChange={(e) => {
              setHex(e.target.value);
              setResult(null);
            }}
            rows={4}
            spellCheck={false}
            placeholder="0001… (hex SignedTx bytes)"
            className="mono"
          />
        </label>
        {clean && !valid ? (
          <p className="small">
            <Badge tone="caution">NOT HEX</Badge> Input must be an even-length hexadecimal string. Nothing will be sent.
          </p>
        ) : null}
        <div className="row-gap">
          <button type="submit" className="btn-primary" disabled={!valid || busy || !queryProxy}>
            {busy ? 'Submitting…' : `Broadcast via ${queryNode?.name ?? DASH}`}
          </button>
          <span className="small dim">POST /proxy/{queryNode?.name ?? '…'}/v1/transactions</span>
        </div>
      </form>
      {result ? (
        result.ok ? (
          <Notice tone="info" title={`Accepted by ${queryNode?.name}'s mempool (HTTP ${result.status})`}>
            id <Mono>{str(result.data.id)}</Mono> · status <Mono>{str(result.data.status)}</Mono>. {result.data.note ?? 'Inclusion is not guaranteed.'}{' '}
            {result.data.id ? (
              <button type="button" className="btn-link" onClick={() => navigate('transactions', result.data.id as string)}>
                Track this transaction
              </button>
            ) : null}
          </Notice>
        ) : (
          <Notice tone="fail" title={`Rejected (HTTP ${result.status || 'no response'})`}>
            <Mono>{result.error.code}</Mono> {result.error.message}
          </Notice>
        )
      ) : null}
    </Card>
  );
}

export function TransactionsPage({ txid }: { txid?: string }) {
  const [input, setInput] = useState(txid ?? '');
  useEffect(() => setInput(txid ?? ''), [txid]);
  return (
    <Page title="Transactions" subtitle="Lifecycle lookup, local mempool view and signed-transaction passthrough.">
      <Card>
        <form
          className="lookup"
          onSubmit={(e) => {
            e.preventDefault();
            const v = input.trim().toLowerCase();
            if (v) navigate('transactions', v);
          }}
        >
          <label className="field grow">
            <span>Transaction id (64 hex)</span>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="txid" className="mono" spellCheck={false} />
          </label>
          <button type="submit" className="btn-primary">
            Look up
          </button>
        </form>
        {input.trim() && !/^[0-9a-fA-F]{64}$/.test(input.trim()) ? <p className="small dim">Transaction ids are 32-byte lowercase hex (64 characters).</p> : null}
      </Card>
      {txid ? <TxDetail txid={txid} /> : null}
      <div className="grid-2">
        <Mempool />
        <Submit />
      </div>
      <Card title="Lifecycle states">
        <Table head={['state', 'meaning']} rows={LIFECYCLE.map((l) => [<Badge tone={l.tone}>{l.state}</Badge>, l.meaning])} />
      </Card>
    </Page>
  );
}
