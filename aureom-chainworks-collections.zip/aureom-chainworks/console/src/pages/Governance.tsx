import { Badge, Card, ErrorBox, Freshness, Hash, Loading, Mono, Notice, Page, Table, type Tone } from '../components/ui';
import { pickArray, type GovProposal } from '../lib/api';
import { DASH, num, str } from '../lib/format';
import { useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';
import { approvalCount } from './Treasury';

const TONE: Record<string, Tone> = { pending: 'caution', approved: 'ok', executed: 'ok', expired: 'neutral', rejected: 'fail', failed: 'fail' };

function describe(k: GovProposal['kind']): string {
  if (typeof k === 'string') return k;
  if (!k) return DASH;
  switch (k.kind) {
    case 'add_authority':
      return `add authority ${str(k.moniker)} (${str(k.operator)}), power ${str(k.power)}`;
    case 'remove_authority':
      return `remove authority ${str(k.operator)}`;
    case 'protocol_upgrade':
      return `protocol upgrade “${str(k.name)}” → v${str(k.protocol_version)} at height ${str(k.activation_height)}`;
    case 'text':
      return `text: ${str(k.title)}${k.uri ? ` (${str(k.uri)})` : ''}`;
    default:
      return str(k.kind);
  }
}

export function GovernancePage() {
  const { profile } = useApp();
  const now = useNow(1000);
  const q = useNodeQuery<{ proposals?: GovProposal[] }>(profile === 'pow' ? null : '/v1/proposals', 8000);
  if (profile === 'pow') {
    return (
      <Page title="Governance">
        <Notice tone="info" title="Proof-of-work networks have no on-chain governance">
          Nobody can propose or approve changes on-chain. Protocol changes are coordinated releases with an activation height that node operators choose to run;
          consensus-critical parameters otherwise require launching a new network.
        </Notice>
      </Page>
    );
  }
  const props = pickArray<GovProposal>(q.data, 'proposals');
  return (
    <Page
      title="Governance"
      subtitle={profile === 'poa' ? 'Proposals by authority operators; approved by > threshold of authority voting power.' : 'Proposals by active validator operators; approved by > threshold of voting power.'}
      actions={<Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />}
    >
      <Notice tone="info">
        Consensus-critical configuration changes are governance proposals. Proposing and approving are signed on-chain transactions (<Mono>gov_propose</Mono>,{' '}
        <Mono>gov_approve</Mono>) made in the CLI wallet; the console only displays them.
      </Notice>
      <ErrorBox result={q.last} what="proposals" />
      {q.loading ? <Loading what="proposals" /> : null}
      <Card title={`Proposals (${props.length})`}>
        <Table
          head={['id', 'proposal', 'proposer', 'approvals', 'created', 'expires', 'status']}
          rows={props.map((p) => {
            const n = approvalCount(p.approvals);
            return [
              num(p.id),
              <span className="small">{describe(p.kind)}</span>,
              <Hash value={p.proposer} />,
              <span>
                {n === null ? DASH : n} signer{n === 1 ? '' : 's'}
                {typeof p.approving_power === 'number' ? (
                  <span className="small dim">
                    {' '}
                    · power {p.approving_power}
                    {typeof p.total_power === 'number' ? ` / ${p.total_power}` : ''}
                  </span>
                ) : null}
              </span>,
              num(p.created_height),
              num(p.expiry_height),
              <span>
                <Badge tone={TONE[p.status ?? ''] ?? 'neutral'}>{str(p.status).toUpperCase()}</Badge>
                {p.executed_height ? <span className="small dim"> at {p.executed_height}</span> : null}
              </span>,
            ];
          })}
          empty="No proposals."
        />
      </Card>
    </Page>
  );
}
