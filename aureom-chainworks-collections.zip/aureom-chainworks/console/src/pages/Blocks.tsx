import { useState } from 'react';
import { Amount, Badge, Card, ErrorBox, Freshness, Hash, Json, KV, Link, Loading, Mono, Notice, Page, Table } from '../components/ui';
import { pickArray, type Block, type Receipt, type TxJson } from '../lib/api';
import { DASH, formatAmount, formatBaseUnits, formatTime, num, str } from '../lib/format';
import { href, useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';

export function finalityLabel(finality: unknown, confirmations: unknown, recommended?: number) {
  if (finality === 'final' || finality === 'deterministic-bft') return <Badge tone="ok">final (BFT commit)</Badge>;
  if (finality === 'probabilistic') {
    const c = typeof confirmations === 'number' ? confirmations : null;
    const enough = c !== null && recommended !== undefined && c >= recommended;
    return (
      <Badge tone={enough ? 'info' : 'caution'} title="Proof-of-work settlement is probabilistic: a branch with more cumulative work can still replace this block.">
        probabilistic — {c === null ? DASH : c} confirmation{c === 1 ? '' : 's'}
        {recommended !== undefined ? ` (recommended ≥ ${recommended})` : ''}
      </Badge>
    );
  }
  return <span className="dim">{DASH}</span>;
}

export function actionSummary(tx: TxJson | null | undefined, decimals: number | undefined, ticker: string): string {
  const a = tx?.action;
  if (!a) return DASH;
  const t = str(a.type);
  const amount = typeof a.amount === 'string' ? a.amount : undefined;
  const to = typeof a.to === 'string' ? a.to : undefined;
  const isNative = t === 'transfer' || t === 'vested_transfer' || t === 'native_mint' || t === 'native_burn';
  let s = t;
  if (amount) s += ` ${isNative ? `${fmt(amount, decimals)} ${ticker}` : `${formatBaseUnits(amount)} base units`}`;
  if (to) s += ` → ${to.length > 20 ? `${to.slice(0, 12)}…${to.slice(-4)}` : to}`;
  return s;
}

function fmt(v: string, d: number | undefined): string {
  return d === undefined ? formatBaseUnits(v) : formatAmount(v, d);
}

function BlockList() {
  const [before, setBefore] = useState<number | null>(null);
  const path = `/v1/blocks?limit=20${before !== null ? `&before=${before}` : ''}`;
  const q = useNodeQuery<{ blocks?: Block[] }>(path, before === null ? 5000 : undefined);
  const now = useNow(1000);
  const blocks = pickArray<Block>(q.data, 'blocks');
  const lowest = blocks.reduce<number | null>((m, b) => (typeof b.height === 'number' && (m === null || b.height < m) ? b.height : m), null);
  return (
    <Card
      title={before === null ? 'Latest blocks' : `Blocks before height ${before}`}
      right={
        <span className="row-gap">
          <Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />
          <span className="dim small">from {q.nodeName ?? DASH}</span>
        </span>
      }
    >
      <ErrorBox result={q.last} what="blocks" />
      {q.loading ? <Loading what="blocks" /> : null}
      <Table
        head={['height', 'block id', 'time', 'txs', 'size', 'proposer / miner']}
        rows={blocks.map((b) => [
          <a href={href('blocks', String(b.id ?? b.height ?? ''))}>{num(b.height)}</a>,
          <a href={href('blocks', String(b.id ?? b.height ?? ''))}>
            <Hash value={b.id} />
          </a>,
          formatTime(b.timestamp_ms),
          num(b.tx_count),
          typeof b.size_bytes === 'number' ? `${num(b.size_bytes)} B` : DASH,
          b.proposer ? (
            <a href={href('accounts', b.proposer)}>
              <Hash value={b.proposer} />
            </a>
          ) : (
            DASH
          ),
        ])}
        empty="No blocks returned."
      />
      <div className="row-gap pager">
        {before !== null ? (
          <button type="button" className="btn-secondary" onClick={() => setBefore(null)}>
            ← Latest
          </button>
        ) : null}
        {lowest !== null && lowest > 0 ? (
          <button type="button" className="btn-secondary" onClick={() => setBefore(lowest)}>
            Older →
          </button>
        ) : null}
      </div>
    </Card>
  );
}

function receiptFor(receipts: Receipt[], tx: TxJson, i: number): Receipt | undefined {
  return receipts.find((r) => r.txid && r.txid === tx.id) ?? receipts[i];
}

function BlockDetail({ id }: { id: string }) {
  const { decimals, ticker, queryNetwork } = useApp();
  const q = useNodeQuery<Block>(`/v1/blocks/${encodeURIComponent(id)}`, 5000);
  const b = q.data;
  const now = useNow(1000);
  const txs = pickArray<TxJson>(b?.txs);
  const receipts = pickArray<Receipt>(b?.receipts);
  const pow = b?.consensus?.pow;
  const bft = b?.consensus?.bft;
  return (
    <>
      <p>
        <a href={href('blocks')}>← all blocks</a>
      </p>
      <ErrorBox result={q.last} what={`block ${id}`} />
      {q.loading ? <Loading what="block" /> : null}
      {b ? (
        <>
          {b.on_main_chain === false ? (
            <Notice tone="caution" title="Not on the node's main chain">
              This block is known to the node but is not part of its current best chain (it was reorganised away or is on a side branch).
            </Notice>
          ) : null}
          <div className="grid-2">
            <Card title={`Block ${num(b.height)}`} right={<Freshness lastOkAt={q.lastOkAt} now={now} />}>
              <KV
                rows={[
                  ['height', num(b.height)],
                  ['block id', <Hash value={b.id} full />],
                  ['previous', b.prev_id ? <a href={href('blocks', b.prev_id)}><Hash value={b.prev_id} /></a> : DASH],
                  ['time', formatTime(b.timestamp_ms)],
                  ['proposer / miner', b.proposer ? <a href={href('accounts', b.proposer)}><Hash value={b.proposer} full /></a> : DASH],
                  ['transactions', num(b.tx_count ?? txs.length)],
                  ['size', typeof b.size_bytes === 'number' ? `${num(b.size_bytes)} B` : DASH],
                  ['state root', <Hash value={b.state_root} />],
                  ['tx root', <Hash value={b.tx_root} />],
                  ['receipt root', <Hash value={b.receipt_root} />],
                  ['confirmations', num(b.confirmations)],
                  ['finality', finalityLabel(b.finality, b.confirmations, queryNetwork?.confirmations_recommended)],
                ]}
              />
            </Card>
            <Card title="Consensus fields">
              {pow ? (
                <>
                  <KV
                    rows={[
                      ['engine', 'proof-of-work (Aureom Nakamoto)'],
                      ['target', <Hash value={pow.target} full />],
                      ['nonce', <Mono>{str(pow.nonce)}</Mono>],
                      ['pow hash', <Hash value={pow.pow_hash} full />],
                      ['work', <Mono>{str(pow.work)}</Mono>],
                      ['cumulative work', <Mono>{str(pow.cumulative_work)}</Mono>],
                    ]}
                  />
                  <p className="small dim">Confirmations count blocks on top of this one. They make reversal more expensive, not impossible.</p>
                </>
              ) : null}
              {bft ? (
                <>
                  <KV
                    rows={[
                      ['engine', 'CometBFT'],
                      ['CometBFT block hash', <Hash value={bft.cometbft_block_hash} full />],
                      ['app hash', <Hash value={bft.app_hash} full />],
                    ]}
                  />
                  <p className="small dim">Committed with precommits from &gt; 2/3 of voting power. Final under the BFT fault assumption.</p>
                </>
              ) : null}
              {!pow && !bft ? <p className="dim">{DASH} No consensus fields in the response.</p> : null}
            </Card>
          </div>
          <Card title={`Transactions (${txs.length})`}>
            <Table
              head={['#', 'tx id', 'sender', 'action', 'fee', 'receipt']}
              rows={txs.map((tx, i) => {
                const r = receiptFor(receipts, tx, i);
                return [
                  String(i),
                  tx.id ? <a href={href('transactions', tx.id)}><Hash value={tx.id} /></a> : DASH,
                  tx.sender ? <a href={href('accounts', tx.sender)}><Hash value={tx.sender} /></a> : DASH,
                  actionSummary(tx, decimals, ticker),
                  <Amount value={tx.fee} decimals={decimals} unit={ticker} />,
                  r ? (
                    r.status === 'success' ? (
                      <Badge tone="ok">success</Badge>
                    ) : r.status === 'failed' ? (
                      <Badge tone="fail">failed: {str(r.error)}</Badge>
                    ) : (
                      str(r.status)
                    )
                  ) : (
                    DASH
                  ),
                ];
              })}
              empty="This block has no transactions."
            />
            {receipts.length ? (
              <details className="small">
                <summary>Receipt events ({receipts.reduce((s, r) => s + (r.events?.length ?? 0), 0)})</summary>
                <Table
                  head={['tx', 'event', 'attributes']}
                  rows={receipts.flatMap((r) =>
                    (r.events ?? []).map((e) => [
                      <Hash value={r.txid} n={6} />,
                      <Mono>{str(e.kind)}</Mono>,
                      <span className="mono small">
                        {Object.entries(e.attrs ?? {})
                          .map(([k, v]) => `${k}=${v}`)
                          .join('  ')}
                      </span>,
                    ]),
                  )}
                />
              </details>
            ) : null}
            <Json value={b} />
          </Card>
        </>
      ) : null}
    </>
  );
}

export function BlocksPage({ blockId }: { blockId?: string }) {
  return (
    <Page title="Blocks" subtitle="Block explorer for the selected query node. Click a block for its transactions, receipts and consensus fields.">
      {blockId ? <BlockDetail id={blockId} /> : <BlockList />}
      <p className="small dim">
        <Link to={['transactions']}>Look up a transaction →</Link>
      </p>
    </Page>
  );
}
