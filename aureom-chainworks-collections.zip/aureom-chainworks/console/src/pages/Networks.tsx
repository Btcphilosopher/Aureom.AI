import type { ReactNode } from 'react';
import { Amount, Card, Hash, KV, Mono, Notice, Page } from '../components/ui';
import type { Json } from '../lib/api';
import { DASH, formatBps, formatDuration, formatTime, num, profileLabel, str } from '../lib/format';
import { useApp } from '../lib/state';

function obj(v: unknown): Json | undefined {
  return v && typeof v === 'object' && !Array.isArray(v) ? (v as Json) : undefined;
}

const ENGINE: Record<string, string> = {
  pow: 'Aureom Nakamoto engine — probabilistic settlement by confirmations',
  pos: 'CometBFT (Tendermint BFT) + Aureom ABCI app — deterministic finality on commit',
  poa: 'CometBFT (Tendermint BFT) + Aureom ABCI app — deterministic finality on commit, permissioned authorities',
};

export function NetworksPage() {
  const { manifest, queryNetwork, profile, decimals, ticker, queryNode } = useApp();
  const m = manifest?.network ?? {};
  const n = queryNetwork ?? {};
  const asset = m.native_asset ?? n.native_asset;
  const mp = obj(m.monetary_policy) ?? obj(n.monetary_policy);
  const fp = obj(m.fee_policy) ?? obj(n.fee_policy);
  const lim = obj(m.limits) ?? obj(n.limits);
  const sched = obj(mp?.scheduled);
  const auth = obj(mp?.authority);
  const cons = obj(m.consensus);
  const profParams = cons && typeof profile === 'string' ? obj(cons[profile]) : undefined;
  const amt = (v: unknown) => <Amount value={v} decimals={decimals} unit={ticker} />;
  const src = (field: string) => (obj((m as Json)[field]) ? 'manifest' : obj((n as Json)[field]) ? `node ${queryNode?.name ?? ''}` : DASH);

  let policyRows: [ReactNode, ReactNode][] = [
    ['kind', <Mono>{str(mp?.kind)}</Mono>],
    ['max supply', mp?.max_supply === undefined || mp?.max_supply === null ? (mp ? 'uncapped (no max_supply set)' : DASH) : amt(mp.max_supply)],
  ];
  if (mp?.kind === 'scheduled' || sched) {
    policyRows = policyRows.concat([
      ['initial block reward', amt(sched?.initial_block_reward)],
      ['halving interval', sched?.halving_interval_blocks !== undefined ? `${num(sched.halving_interval_blocks)} blocks` : DASH],
    ]);
  }
  if (mp?.kind === 'authority' || auth) {
    policyRows = policyRows.concat([
      ['mint authority', <Hash value={auth?.mint_authority} full />],
      ['max mint per window', amt(auth?.max_mint_per_window)],
      ['window', auth?.window_blocks !== undefined ? `${num(auth.window_blocks)} blocks` : DASH],
    ]);
  }
  if (mp?.kind === 'fixed') policyRows.push(['issuance', 'none after genesis (fixed supply)']);

  return (
    <Page title="Networks" subtitle="Identity and genesis parameters of the managed network. Read-only.">
      <Notice tone="info" title="Consensus-critical settings cannot be edited here">
        The consensus profile (<strong>{profileLabel(profile)}</strong>) is fixed at genesis and cannot be switched on a running network; moving to another profile means
        launching a new network. Monetary policy, fee policy, limits and consensus parameters are part of the genesis document and its hash. They change only through
        on-chain governance proposals (PoS/PoA: <Mono>ProtocolUpgrade</Mono> approved by validators/authorities) or by launching a new network (PoW: coordinated release with
        an activation height). This page has no edit controls.
      </Notice>
      <div className="grid-2">
        <Card title="Network identity">
          <KV
            rows={[
              ['network name', str(m.name ?? m.network_name ?? n.network_name)],
              ['chain id', <Mono>{str(m.chain_id ?? n.chain_id)}</Mono>],
              ['profile', profileLabel(profile)],
              ['engine', typeof profile === 'string' ? ENGINE[profile] ?? DASH : DASH],
              ['backend', n.backend ? `${n.backend} ${n.backend_version ?? ''}` : DASH],
              ['protocol version', num(n.protocol_version)],
              ['finality', str(n.finality)],
              ['confirmations recommended', profile === 'pow' ? num(n.confirmations_recommended ?? profParams?.confirmations_recommended) : 'n/a (BFT commit is final)'],
              ['genesis hash', <Hash value={m.genesis_hash ?? n.genesis_hash} full />],
              ['manifest generated', formatTime(manifest?.generated_at_ms)],
            ]}
          />
          {n.fault_assumption ? <p className="small fault">Fault assumption (as reported by the node): {n.fault_assumption}</p> : null}
        </Card>
        <Card title="Native asset">
          <KV
            rows={[
              ['name', str(asset?.name)],
              ['ticker', <Mono>{str(asset?.ticker)}</Mono>],
              ['decimals', num(asset?.decimals)],
              ['address prefix (HRP)', <Mono>{str(asset?.address_hrp)}</Mono>],
              ['token id prefix', asset?.address_hrp ? <Mono>{asset.address_hrp}tok1…</Mono> : DASH],
            ]}
          />
          <p className="small dim">Tickers and symbols are display labels only; they never identify an asset.</p>
        </Card>
        <Card title="Monetary policy" right={<span className="dim small">source: {src('monetary_policy')}</span>}>
          <KV rows={policyRows} />
        </Card>
        <Card title="Fee policy" right={<span className="dim small">source: {src('fee_policy')}</span>}>
          <KV
            rows={[
              ['base fee', amt(fp?.base_fee)],
              ['per-byte fee', amt(fp?.per_byte_fee)],
              ['burned share', formatBps(fp?.burn_bps)],
              ['remainder goes to', str(fp?.recipient)],
            ]}
          />
          <p className="small dim">min_fee = base_fee + per_byte_fee × signed size. The whole declared fee is charged.</p>
        </Card>
        <Card title="Limits" right={<span className="dim small">source: {src('limits')}</span>}>
          <KV
            rows={[
              ['max block bytes', num(lim?.max_block_bytes)],
              ['max block txs', num(lim?.max_block_txs)],
              ['max tx bytes', num(lim?.max_tx_bytes)],
              ['max memo bytes', num(lim?.max_memo_bytes)],
            ]}
          />
        </Card>
        <Card title={`Consensus parameters (${profileLabel(profile)})`}>
          {profParams ? (
            <KV
              rows={Object.entries(profParams).map(([k, v]) => [
                k,
                typeof v === 'number' && k.endsWith('_ms') ? `${num(v)} ms (${formatDuration(v)})` : typeof v === 'string' || typeof v === 'number' ? <Mono>{String(v)}</Mono> : DASH,
              ])}
            />
          ) : (
            <p className="dim">{DASH} The manifest does not include consensus parameters.</p>
          )}
        </Card>
      </div>
    </Page>
  );
}
