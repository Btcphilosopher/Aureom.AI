// Minting · Transfers · Media · Permissions · Listings · Activity
import { Amount, Badge, Card, KV, Loading, Mono, Notice, Page, Table } from '../../components/ui';
import { href } from '../../lib/hooks';
import { mediaUrl, requestTone, riskTone, type ChainCollection, type ModuleRequest, type ProvEvent, type StorageLoc, type TxOutcome } from '../../lib/nft';
import { useApi } from '../../lib/query';
import { useApp } from '../../lib/state';
import { PowersTable } from './Collections';
import { StorageBadge } from './Assets';
import { Addr, IndexLine, Lifecycle, SettlementBadge, Unavailable } from './common';

function when(ms: number | undefined) {
  return ms ? new Date(ms).toISOString().replace('T', ' ').slice(0, 19) + 'Z' : '—';
}

function RequestsTable({ rows }: { rows: ModuleRequest[] }) {
  return (
    <Table
      head={['request', 'kind', 'tokens', 'progress', 'tx', 'detail']}
      rows={rows.map((r) => [
        <div>
          <Mono>{r.request_id}</Mono>
          <div className="small dim">key: {r.idempotency_key}</div>
        </div>,
        r.kind,
        <span className="small">{(r.token_ids ?? []).join(', ') || '—'}</span>,
        <Lifecycle status={r.status} />,
        r.txid ? (
          <a href={href('transactions', r.txid)}>
            <Mono>{r.txid.slice(0, 10)}…</Mono>
          </a>
        ) : (
          '—'
        ),
        <details>
          <summary>
            <Badge tone={requestTone(r.status)}>{(r.status ?? '').toUpperCase()}</Badge> {r.last_error ? <span className="small">{r.last_error}</span> : null}
          </summary>
          <ol className="tight small">
            {(r.history ?? []).map((h, i) => (
              <li key={i}>
                {when(h.at_ms)} {h.from_status ?? '∅'} → <strong>{h.to_status}</strong> {h.detail ? <span className="dim">— {h.detail}</span> : null}
              </li>
            ))}
          </ol>
        </details>,
      ])}
      empty="No requests."
    />
  );
}

export function MintingPage() {
  const q = useApi<{ requests?: ModuleRequest[]; note?: string }>('/api/nft/requests', 4000);
  const all = q.data?.requests ?? [];
  const mint = all.filter((r) => r.kind === 'mint' || r.kind === 'mint_batch' || r.kind === 'drop');
  const other = all.filter((r) => !mint.includes(r));
  const count = (s: string) => mint.filter((r) => r.status === s).length;
  return (
    <Page title="Minting" subtitle="Prepare → validate (simulate) → review → sign → submit → confirm/finalise → index. Idempotent requests; unknown outcomes are reconciled before any retry.">
      <Unavailable r={q.last} />
      <Notice tone="caution" title="Upload ≠ mint · submitted ≠ confirmed">
        {q.data?.note ?? 'A completed upload is not a mint, and a submitted transaction is not a confirmed NFT.'}
      </Notice>
      <IndexLine />
      <div className="stat-row">
        {[
          ['indexed', 'ok'],
          ['confirmed', 'ok'],
          ['submitted', ''],
          ['unknown', 'caution'],
          ['failed', 'fail'],
          ['rejected', 'fail'],
        ].map(([s, t]) => (
          <div key={s} className={`stat ${t ? `stat-${t}` : ''}`}>
            <div className="stat-v">{count(s)}</div>
            <div className="stat-k">{s}</div>
          </div>
        ))}
      </div>
      {q.loading ? <Loading what="requests" /> : null}
      <Card title={`Mint, batch and drop requests (${mint.length})`}>
        <RequestsTable rows={mint} />
      </Card>
      <Card title={`Other module requests (${other.length})`}>
        <RequestsTable rows={other} />
      </Card>
    </Page>
  );
}

interface Activity {
  transactions?: TxOutcome[];
  events?: ProvEvent[];
  reorgs?: { fork_height?: number; old_tip_height?: number; old_tip?: string; new_tip?: string; blocks_removed?: number; events_removed?: number; detected_at_ms?: number; source_node?: string }[];
  tip?: number;
  profile?: string;
}

export function TransfersPage() {
  const q = useApi<Activity>('/api/nft/activity', 5000);
  const ev = (q.data?.events ?? []).filter((e) => e.kind === 'nft_transfer');
  const failed = (q.data?.transactions ?? []).filter((t) => t.status === 'failed' && /transfer|listing_buy/.test(t.action_type ?? ''));
  return (
    <Page title="Transfers" subtitle="Ownership changes recorded on chain, with the authority each one used: owner, single-token approval, operator, sale or forced transfer.">
      <Unavailable r={q.last} />
      <IndexLine />
      <Card title={`Transfers (${ev.length})`}>
        <Table
          head={['height', 'token', 'from', 'to', 'authority', 'tx']}
          rows={ev.map((e) => [
            e.height,
            <a href={href('nft-assets', e.attrs?.collection ?? (e as { collection_id?: string }).collection_id ?? '', (e as { token_id?: string }).token_id ?? '')}>#{(e as { token_id?: string }).token_id}</a>,
            <Addr a={e.from_addr} />,
            <Addr a={e.to_addr} />,
            <Badge tone={e.op === 'forced_by_admin' ? 'fail' : e.op === 'operator' ? 'caution' : 'neutral'}>{e.op}</Badge>,
            <a href={href('transactions', e.txid ?? '')}>
              <Mono>{e.txid?.slice(0, 10)}…</Mono>
            </a>,
          ])}
          empty="No transfers."
        />
      </Card>
      <Card title={`Rejected transfer attempts on chain (${failed.length})`}>
        <p className="small">These transactions were included (the sender paid the fee) but the state machine refused the action. Ownership did not change.</p>
        <Table
          head={['height', 'sender', 'action', 'error', 'fee paid']}
          rows={failed.map((t) => [t.height, <Addr a={t.sender} />, t.action_type, <Badge tone="fail">{t.error}</Badge>, t.fee_paid])}
          empty="None."
        />
      </Card>
    </Page>
  );
}

interface MediaResp {
  media?: { sha256: string; kind?: string; mime?: string; bytes?: number; width?: number; height?: number; original_name?: string; alt_text?: string; transcript?: string; cid_raw_v1?: string; licence?: string; locations?: (StorageLoc & { last_hash_ok?: number | null })[] }[];
  metadata_documents?: { metadata_sha256: string; schema?: string; name?: string; token_id?: string | null; warnings?: string[]; locations?: (StorageLoc & { last_hash_ok?: number | null })[] }[];
  persistence?: string;
}

export function MediaPage() {
  const q = useApi<MediaResp>('/api/nft/media', 10000);
  const m = q.data?.media ?? [];
  const docs = q.data?.metadata_documents ?? [];
  const locs = [...m.flatMap((x) => x.locations ?? []), ...docs.flatMap((x) => x.locations ?? [])];
  const unhealthy = locs.filter((l) => l.last_available !== 1 || l.last_hash_ok === 0).length;
  return (
    <Page title="Media" subtitle="Validated media and metadata documents, their checksums, where each copy is stored, who maintains it and the last availability check.">
      <Unavailable r={q.last} />
      <Notice tone="caution" title="Persistence is monitored, not guaranteed">
        {q.data?.persistence}
      </Notice>
      <div className="stat-row">
        <div className="stat">
          <div className="stat-v">{m.length}</div>
          <div className="stat-k">media files</div>
        </div>
        <div className="stat">
          <div className="stat-v">{docs.length}</div>
          <div className="stat-k">metadata documents</div>
        </div>
        <div className={`stat ${unhealthy ? 'stat-fail' : 'stat-ok'}`}>
          <div className="stat-v">
            {locs.length - unhealthy}/{locs.length}
          </div>
          <div className="stat-k">copies verified (available + hash match) at last check; unchecked copies not counted</div>
        </div>
      </div>
      {q.loading ? <Loading what="media" /> : null}
      <Card title="Media files">
        <Table
          head={['preview', 'file', 'type', 'checksums', 'accessibility', 'storage']}
          rows={m.map((x) => [
            x.kind === 'image' ? <img className="thumb" src={mediaUrl(x.sha256) ?? ''} alt={x.alt_text ?? ''} /> : <Badge tone="neutral">{x.kind?.toUpperCase()}</Badge>,
            <div>
              <strong>{x.original_name}</strong>
              <div className="small dim">
                {x.bytes?.toLocaleString()} bytes {x.width ? `· ${x.width}×${x.height}` : ''} · {x.licence ?? 'no licence recorded'}
              </div>
            </div>,
            x.mime,
            <div className="small">
              sha256 <Mono>{x.sha256.slice(0, 16)}…</Mono>
              <div>
                CIDv1 raw <Mono>{x.cid_raw_v1?.slice(0, 18)}…</Mono>
              </div>
            </div>,
            <span className="small">{x.alt_text ?? x.transcript ?? <Badge tone="caution">none</Badge>}</span>,
            <div>
              {(x.locations ?? []).map((l, i) => (
                <div key={i} className="small">
                  {l.adapter} · {l.maintainer} <StorageBadge v={l.last_available} hashOk={l.last_hash_ok} />
                </div>
              ))}
            </div>,
          ])}
        />
      </Card>
      <Card title="Metadata documents (their SHA-256 is what the chain records)">
        <Table
          head={['document', 'schema', 'sha256', 'warnings', 'storage']}
          rows={docs.map((d) => [
            <span>
              {d.name} {d.token_id ? <span className="dim">· token {d.token_id}</span> : null}
            </span>,
            <Mono>{d.schema}</Mono>,
            <Mono>{d.metadata_sha256.slice(0, 20)}…</Mono>,
            <span className="small">{(d.warnings ?? []).join('; ') || '—'}</span>,
            <div>
              {(d.locations ?? []).map((l, i) => (
                <div key={i} className="small">
                  {l.adapter} <StorageBadge v={l.last_available} hashOk={l.last_hash_ok} />
                </div>
              ))}
            </div>,
          ])}
        />
      </Card>
    </Page>
  );
}

interface Perms {
  collections?: ChainCollection[];
  operator_approvals?: { collection_id?: string; owner?: string; operator?: string; expiry_height?: number; active?: boolean; risk?: string }[];
  token_approvals?: { collection_id?: string; token_id?: string; owner?: string; approved?: string; approval_expiry?: number }[];
  roles_note?: string;
}

export function PermissionsPage() {
  const q = useApi<Perms>('/api/nft/permissions', 8000);
  const ops = q.data?.operator_approvals ?? [];
  return (
    <Page title="Permissions" subtitle="Who can do what, per collection, as enforced by the ledger — and every approval holders have granted.">
      <Unavailable r={q.last} />
      <Notice tone="info">{q.data?.roles_note}</Notice>
      {(q.data?.collections ?? []).map((c) => (
        <Card key={c.collection_id} title={`${c.spec?.name} — roles and powers`}>
          <PowersTable powers={c.administrative_powers} />
          <h3>Authority changes (on chain)</h3>
          <Table
            head={['#', 'role', 'old', 'new', 'height', 'by']}
            rows={(c.authority_log ?? []).map((a) => [a.seq, a.role, <Addr a={a.old} />, <Addr a={a.new} />, a.height, <Addr a={a.by} />])}
            empty="No role changes since creation."
          />
        </Card>
      ))}
      <Card title={`Collection-wide operator approvals (${ops.length})`}>
        {ops.some((o) => o.active) ? <Notice tone="caution">An operator can move every token the owner holds in the collection, including tokens acquired later.</Notice> : null}
        <Table
          head={['owner', 'operator', 'expiry', 'state', 'risk']}
          rows={ops.map((o) => [<Addr a={o.owner} />, <Addr a={o.operator} />, o.expiry_height || 'none', o.active ? <Badge tone="caution">ACTIVE</Badge> : 'expired', <Badge tone={riskTone(o.risk?.startsWith('high') ? 'high' : 'medium')}>{o.risk}</Badge>])}
          empty="No operator approvals."
        />
      </Card>
      <Card title="Single-token approvals">
        <Table
          head={['token', 'owner', 'approved address', 'expiry']}
          rows={(q.data?.token_approvals ?? []).map((t) => [`#${t.token_id}`, <Addr a={t.owner} />, <Addr a={t.approved} />, t.approval_expiry || 'none'])}
          empty="No active single-token approvals."
        />
      </Card>
    </Page>
  );
}

interface Listings {
  module?: { marketplace?: boolean; marketplace_fee_bps?: number; marketplace_fee_recipient?: string | null };
  listings?: { listing_id: string; collection_id?: string; token_id?: string; seller?: string; price?: string; currency?: string; expiry_height?: number; status?: string; buyer?: string | null; created_height?: number; closed_height?: number | null }[];
  sales?: { listing_id: string; height?: number; token_id?: string; seller?: string; buyer?: string; price?: string; currency?: string; royalty?: string; royalty_to?: string | null; platform_fee?: string; platform_to?: string | null; seller_proceeds?: string; network_fee?: string; txid?: string }[];
  settlement?: string;
  royalties?: string;
}

export function ListingsPage() {
  const { decimals, ticker } = useApp();
  const q = useApi<Listings>('/api/nft/listings', 5000);
  const amt = (v: string | undefined, cur: string | undefined) => (cur === 'native' ? <Amount value={v} decimals={decimals} unit={ticker} /> : <span>{v} <span className="dim small">base units of {cur?.slice(0, 14)}…</span></span>);
  const tone = (s: string | undefined) => (s === 'active' ? 'info' : s === 'sold' ? 'ok' : s === 'invalidated' ? 'caution' : 'neutral');
  return (
    <Page title="Listings" subtitle="Fixed-price demonstration marketplace. Seller-authorised listings; settlement is one atomic ledger state transition.">
      <Unavailable r={q.last} />
      <Notice tone="info" title="Atomic settlement">
        {q.data?.settlement}
      </Notice>
      <Notice tone="caution" title="Royalties">
        {q.data?.royalties}
      </Notice>
      <KV rows={[['marketplace', q.data?.module?.marketplace ? 'enabled in genesis' : 'disabled'], ['platform fee', `${(q.data?.module?.marketplace_fee_bps ?? 0) / 100}% → ${q.data?.module?.marketplace_fee_recipient ?? 'none'}`]]} />
      <Card title="Sales and settlement receipts">
        <Table
          head={['height', 'token', 'buyer ← seller', 'price', 'royalty', 'platform fee', 'seller proceeds', 'network fee (buyer)']}
          rows={(q.data?.sales ?? []).map((s) => [
            s.height,
            `#${s.token_id}`,
            <span>
              <Addr a={s.buyer} n={8} /> ← <Addr a={s.seller} n={8} />
            </span>,
            amt(s.price, s.currency),
            amt(s.royalty, s.currency),
            amt(s.platform_fee, s.currency),
            amt(s.seller_proceeds, s.currency),
            amt(s.network_fee, 'native'),
          ])}
          empty="No sales."
        />
        <p className="small dim">Rounding: royalty and platform fee are floor(price × bps / 10000); the seller receives the remainder. Network fees are separate and paid by the buyer.</p>
      </Card>
      <Card title="Listings">
        <Table
          head={['listing', 'token', 'seller', 'price', 'expiry', 'status']}
          rows={(q.data?.listings ?? []).map((l) => [
            <Mono>{l.listing_id.slice(0, 12)}…</Mono>,
            `#${l.token_id}`,
            <Addr a={l.seller} />,
            amt(l.price, l.currency),
            `h${l.expiry_height}`,
            <Badge tone={tone(l.status)}>{(l.status ?? '').toUpperCase()}</Badge>,
          ])}
          empty="No listings."
        />
      </Card>
    </Page>
  );
}

export function ActivityPage() {
  const q = useApi<Activity>('/api/nft/activity', 4000);
  const d = q.data;
  return (
    <Page title="Activity" subtitle="Every collections-module transaction on the indexed chain, successful or failed, with settlement state per the chain's actual semantics.">
      <Unavailable r={q.last} />
      <IndexLine />
      {(d?.reorgs ?? []).length ? (
        <Card title={`Reorganisations reconciled by the index (${d?.reorgs?.length})`}>
          <Table
            head={['detected', 'fork height', 'old tip', 'blocks removed', 'events removed', 'source node']}
            rows={(d?.reorgs ?? []).map((r) => [when(r.detected_at_ms), r.fork_height, <span>h{r.old_tip_height} <Mono>{r.old_tip?.slice(0, 10)}…</Mono></span>, r.blocks_removed, r.events_removed, r.source_node])}
          />
        </Card>
      ) : null}
      <Card title="Transactions">
        <Table
          head={['height', 'action', 'sender', 'result', 'settlement', 'tx']}
          rows={(d?.transactions ?? []).map((t) => [
            t.height,
            <Mono>{t.action_type}</Mono>,
            <Addr a={t.sender} />,
            t.status === 'success' ? <Badge tone="ok">SUCCESS</Badge> : <Badge tone="fail">FAILED · {t.error}</Badge>,
            <SettlementBadge s={t.settlement} />,
            <a href={href('transactions', t.txid)}>
              <Mono>{t.txid.slice(0, 10)}…</Mono>
            </a>,
          ])}
          empty="No collections activity."
        />
      </Card>
    </Page>
  );
}
