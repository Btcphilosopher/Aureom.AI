import type { ReactNode } from 'react';
import { Badge, Notice } from '../../components/ui';
import type { ApiResult } from '../../lib/api';
import { lifecycleIndex, LIFECYCLE, requestTone, short, type Settlement, type Summary } from '../../lib/nft';
import { useApi } from '../../lib/query';

/** PoW: included / confirmed (k confirmations, probabilistic). BFT: finalised. */
export function SettlementBadge({ s }: { s: Settlement | undefined }) {
  if (!s || !s.state) return <span className="dim">—</span>;
  if (s.state === 'finalised')
    return (
      <Badge tone="ok" title={s.semantics}>
        FINALISED
      </Badge>
    );
  if (s.state === 'confirmed')
    return (
      <Badge tone="ok" title={s.semantics}>
        CONFIRMED · {s.confirmations} conf
      </Badge>
    );
  if (s.state === 'included')
    return (
      <Badge tone="info" title={s.semantics}>
        INCLUDED · {s.confirmations}/{s.recommended} conf
      </Badge>
    );
  return <Badge tone="neutral">{s.state.toUpperCase()}</Badge>;
}

export function Addr({ a, n = 10 }: { a: string | null | undefined; n?: number }) {
  if (!a) return <span className="dim">none</span>;
  return (
    <code className="mono" title={a}>
      {short(a, n)}
    </code>
  );
}

export function Unavailable<T>({ r }: { r: ApiResult<T> | null }) {
  if (!r || r.ok) return null;
  return (
    <Notice tone="fail" title="Collections data unavailable">
      <code className="mono">{r.error.code}</code> {r.error.message} — the collections module may not be enabled on this network, or the collections database has not been created
      (<code>chainworks nft db-migrate</code>).
    </Notice>
  );
}

export function useSummary() {
  return useApi<Summary>('/api/nft/summary', 5000);
}

export function IndexLine() {
  const q = useSummary();
  const s = q.data;
  if (!s) return null;
  const lag = typeof s.index?.node_tip === 'number' && typeof s.index?.height === 'number' ? s.index.node_tip - s.index.height : null;
  return (
    <div className="badge-row small">
      <Badge tone="info">INDEX = CACHE</Badge>
      <span>
        indexed to height <strong>{s.index?.height ?? '—'}</strong> from <code className="mono">{s.index?.source_node}</code>
        {lag !== null ? <span className="dim"> (node tip {s.index?.node_tip}{lag > 0 ? `, ${lag} behind` : ''})</span> : null}
      </span>
      <span className="dim">
        settlement: {s.network?.profile === 'pow' ? `probabilistic — confirmed at ${s.network?.confirmations_recommended} confirmations, reorganisable` : 'BFT finality on commit'}
      </span>
      {s.index?.error ? <Badge tone="fail">INDEX ERROR: {s.index.error}</Badge> : null}
    </div>
  );
}

export function Lifecycle({ status }: { status: string | undefined }) {
  const i = lifecycleIndex(status);
  const terminalFail = status === 'failed' || status === 'rejected' || status === 'dropped';
  return (
    <div className="lc" aria-label={`lifecycle: ${status}`}>
      {LIFECYCLE.map((s, k) => (
        <span key={s} className={`lc-step ${k < i ? 'done' : k === i ? (terminalFail ? 'fail' : 'cur') : ''}`} title={s}>
          {s}
        </span>
      ))}
      {terminalFail || status === 'unknown' ? <Badge tone={requestTone(status)}>{status?.toUpperCase()}</Badge> : null}
    </div>
  );
}

export function Section({ children }: { children: ReactNode }) {
  return <div className="nft-section">{children}</div>;
}
