import { useState } from 'react';
import { Badge, Card, KV, Loading, Mono, Notice, Page, Table } from '../../components/ui';
import { riskTone, type ChainCollection, type IndexCollection, type Power } from '../../lib/nft';
import { useApi } from '../../lib/query';
import { Addr, IndexLine, Unavailable, useSummary } from './common';

interface Row {
  index: IndexCollection;
  chain: ChainCollection;
  agrees: boolean;
}

export function PowersTable({ powers }: { powers: Power[] | undefined }) {
  return (
    <Table
      head={['power', 'held by', 'limit', 'risk']}
      rows={(powers ?? []).map((p) => [
        <strong>{p.power}</strong>,
        p.holder && p.holder.startsWith('aurd') ? <Addr a={p.holder} /> : <span>{p.holder ?? 'nobody'}</span>,
        <span className="small">{p.limit}</span>,
        <Badge tone={riskTone(p.risk)}>{(p.risk ?? '').toUpperCase()}</Badge>,
      ])}
    />
  );
}

export function CollectionsPage() {
  const q = useApi<{ collections?: Row[] }>('/api/nft/collections', 6000);
  const sum = useSummary();
  const m = sum.data?.module;
  const rows = q.data?.collections ?? [];
  return (
    <Page title="Collections" subtitle="NFT collections on this network — a native module of the Chainworks state machine (not a smart contract; not ERC-721/ERC-1155 compatible).">
      <Unavailable r={q.last} />
      <IndexLine />
      <div className="stat-row">
        <div className="stat">
          <div className="stat-v">{rows.length}</div>
          <div className="stat-k">collections</div>
        </div>
        <div className="stat">
          <div className="stat-v">{rows.reduce((a, r) => a + (r.chain.live ?? 0), 0)}</div>
          <div className="stat-k">live tokens (chain)</div>
        </div>
        <div className={`stat ${m?.marketplace ? 'stat-ok' : ''}`}>
          <div className="stat-v">{m?.marketplace ? `${(m.marketplace_fee_bps ?? 0) / 100}%` : 'off'}</div>
          <div className="stat-k">demo marketplace fee</div>
        </div>
      </div>
      {q.loading ? <Loading what="collections" /> : null}
      {rows.map((r) => (
        <CollectionCard key={r.index.collection_id} r={r} />
      ))}
      {!q.loading && rows.length === 0 && q.last?.ok ? <Notice tone="info">No collections yet. Use the wizard below to prepare one.</Notice> : null}
      <Wizard />
    </Page>
  );
}

function CollectionCard({ r }: { r: Row }) {
  const c = r.chain;
  const s = c.spec ?? {};
  const roles = c.roles ?? {};
  return (
    <Card
      title={
        <span>
          {s.name} <span className="dim">· {s.slug}</span>
        </span>
      }
      right={
        <span className="badge-row">
          <Badge tone="info">{(c.metadata_policy ?? '').toUpperCase()} METADATA</Badge>
          {c.metadata_frozen_all ? <Badge tone="ok">FROZEN</Badge> : null}
          {c.paused ? <Badge tone="fail">PAUSED</Badge> : null}
          {r.agrees ? <Badge tone="ok">index = chain</Badge> : <Badge tone="caution">index differs from chain</Badge>}
        </span>
      }
    >
      <div className="grid-2">
        <div>
          <KV
            rows={[
              ['collection id', <Mono>{c.collection_id}</Mono>],
              ['supply', `${c.live ?? 0} live · ${c.minted ?? 0} minted · ${c.burned ?? 0} burned · max ${c.max_supply ?? 'uncapped'}`],
              ['transfers', s.transfer_policy],
              ['royalty preference', c.royalty ? `${(c.royalty.bps ?? 0) / 100}% → ${c.royalty.recipient?.slice(0, 16)}…` : 'none'],
              ['royalty enforcement', c.royalty?.enforced_by ?? '—'],
              ['collection metadata', <Mono>{c.spec?.collection_metadata?.sha256?.slice(0, 20)}…</Mono>],
              ['metadata root', <Mono>{c.metadata_root?.slice(0, 20)}…</Mono>],
              ['created at height', c.created_height],
            ]}
          />
        </div>
        <div>
          <h3>Distinct roles</h3>
          <KV
            rows={[
              ['creator', <Addr a={roles.creator} />],
              ['mint authority', <Addr a={roles.mint_authority} />],
              ['metadata administrator', <Addr a={roles.metadata_admin} />],
              ['admin (pause / force)', <Addr a={roles.admin} />],
              ['royalty recipient', <Addr a={roles.royalty_recipient} />],
              ['IP rights holder', roles.rights_holder],
            ]}
          />
          <p className="small dim">{roles.note}</p>
        </div>
      </div>
      <h3>Administrative powers (enforced on chain)</h3>
      <PowersTable powers={c.administrative_powers} />
    </Card>
  );
}

interface Preview {
  ok?: boolean;
  error?: string;
  administrative_powers?: Power[];
  warnings?: string[];
  action?: Record<string, unknown>;
  next?: string;
}

function Wizard() {
  const [f, setF] = useState({
    name: 'Tidewater Lanterns II',
    slug: 'tidewater-lanterns-ii',
    max_supply: '50',
    mint_authority: 'artist',
    metadata_policy: 'freezable',
    transfer_policy: 'transferable',
    royalty_bps: '500',
    rights_holder: 'Lumen Atelier (fictional studio)',
    pausable: false,
    forced_transfer: false,
    owner_burn: true,
    admin: '',
    collection_sha: '',
    rights_sha: '',
  });
  const [p, setP] = useState<Preview | null>(null);
  const set = (k: string, v: unknown) => setF({ ...f, [k]: v });
  const answers = () => ({
    slug: f.slug,
    name: f.name,
    collection_metadata: { uri: `http://127.0.0.1:8787/media/${f.collection_sha || '0'.repeat(64)}`, sha256: f.collection_sha || '0'.repeat(64) },
    max_supply: f.max_supply ? Number(f.max_supply) : null,
    mint_authority: f.mint_authority || null,
    metadata_policy: f.metadata_policy,
    metadata_admin: f.metadata_policy === 'immutable' ? null : f.mint_authority,
    admin: f.admin || null,
    pausable: f.pausable,
    forced_transfer: f.forced_transfer,
    owner_burn: f.owner_burn,
    transfer_policy: f.transfer_policy,
    royalty: f.royalty_bps && Number(f.royalty_bps) > 0 ? { recipient: f.mint_authority, bps: Number(f.royalty_bps) } : null,
    rights_holder: f.rights_holder,
    rights: { uri: `http://127.0.0.1:8787/media/${f.rights_sha || '0'.repeat(64)}`, sha256: f.rights_sha || '0'.repeat(64) },
  });
  const preview = async () => {
    const r = await fetch('/api/nft/wizard-preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(answers()) });
    setP((await r.json()) as Preview);
  };
  const text = (k: keyof typeof f, label: string) => (
    <label className="field">
      {label}
      <input value={String(f[k])} onChange={(e) => set(k, e.target.value)} />
    </label>
  );
  const check = (k: keyof typeof f, label: string) => (
    <label className="check">
      <input type="checkbox" checked={Boolean(f[k])} onChange={(e) => set(k, e.target.checked)} /> {label}
    </label>
  );
  return (
    <Card title="New collection wizard" right={<Badge tone="neutral">PREVIEW ONLY · signing happens in the CLI</Badge>}>
      <p className="small">
        Defaults are minimal privileges: no admin, no pause, no forced transfer. Every power must be chosen explicitly and is shown below before anything is signed.
      </p>
      <div className="wizard-grid">
        {text('name', 'name')}
        {text('slug', 'collection identifier (slug)')}
        {text('max_supply', 'supply limit (blank = uncapped)')}
        {text('mint_authority', 'minting permission (account label / address)')}
        <label className="field">
          metadata policy
          <select value={f.metadata_policy} onChange={(e) => set('metadata_policy', e.target.value)}>
            <option value="mutable">mutable with recorded revisions</option>
            <option value="freezable">mutable until permanently frozen</option>
            <option value="immutable">content-addressed, immutable from creation</option>
          </select>
        </label>
        <label className="field">
          transfer restrictions
          <select value={f.transfer_policy} onChange={(e) => set('transfer_policy', e.target.value)}>
            <option value="transferable">freely transferable</option>
            <option value="non_transferable">non-transferable</option>
          </select>
        </label>
        {text('royalty_bps', 'royalty preference (bps, optional)')}
        {text('rights_holder', 'rights statement holder')}
        {text('collection_sha', 'collection metadata sha256 (artwork, description)')}
        {text('rights_sha', 'rights statement sha256')}
        {text('admin', 'admin (only if pause/force chosen)')}
      </div>
      <div className="badge-row">
        {check('owner_burn', 'owners may burn their own tokens')}
        {check('pausable', 'admin may PAUSE the collection')}
        {check('forced_transfer', 'admin may FORCE-TRANSFER tokens')}
      </div>
      <button type="button" className="btn-primary" onClick={() => void preview()}>
        Show administrative powers
      </button>
      {p && !p.ok ? <Notice tone="fail">{p.error}</Notice> : null}
      {p && p.ok ? (
        <div>
          {(p.warnings ?? []).map((w, i) => (
            <Notice key={i} tone="caution">
              {w}
            </Notice>
          ))}
          <PowersTable powers={p.administrative_powers} />
          <div className="cmd">{p.next}</div>
        </div>
      ) : null}
    </Card>
  );
}
