import { useState } from 'react';
import { Badge, Card, Json, KV, Loading, Mono, Notice, Page, Table } from '../../components/ui';
import { href } from '../../lib/hooks';
import { mediaUrl, type Asset, type ProvEvent, type StorageLoc } from '../../lib/nft';
import { useApi } from '../../lib/query';
import { Addr, IndexLine, SettlementBadge, Unavailable } from './common';

export function StorageBadge({ v, hashOk }: { v: number | null | undefined; hashOk?: number | null }) {
  if (v === null || v === undefined) return <Badge tone="caution">UNCHECKED</Badge>;
  if (v === 0) return <Badge tone="fail">UNAVAILABLE</Badge>;
  if (hashOk === 0) return <Badge tone="fail">CONTENT CHANGED</Badge>;
  return <Badge tone="ok">AVAILABLE</Badge>;
}

export function NftAssetsPage({ cid, tid }: { cid?: string; tid?: string }) {
  if (cid && tid) return <AssetDetail cid={cid} tid={tid} />;
  return <AssetList />;
}

function AssetList() {
  const q = useApi<{ assets?: Asset[]; as_of_height?: number }>('/api/nft/assets', 6000);
  const [view, setView] = useState<'gallery' | 'table'>('gallery');
  const rows = q.data?.assets ?? [];
  return (
    <Page
      title="Assets"
      subtitle="Every token in the index. Owners shown here are a cache of chain events; open a token for the authoritative on-chain owner."
      actions={
        <div className="badge-row">
          <button type="button" className={view === 'gallery' ? 'btn-primary' : 'btn-secondary'} onClick={() => setView('gallery')}>
            Gallery
          </button>
          <button type="button" className={view === 'table' ? 'btn-primary' : 'btn-secondary'} onClick={() => setView('table')}>
            Table
          </button>
        </div>
      }
    >
      <Unavailable r={q.last} />
      <IndexLine />
      {q.loading ? <Loading what="assets" /> : null}
      {view === 'gallery' ? (
        <div className="gallery">
          {rows.map((a) => {
            const img = mediaUrl(a.document?.image_sha256);
            return (
              <a key={`${a.collection_id}/${a.token_id}`} className="tile" href={href('nft-assets', a.collection_id, a.token_id)}>
                {img ? <img src={img} alt={a.document?.alt_text ?? ''} loading="lazy" /> : <div className="tile-missing">metadata document not in this application's store</div>}
                <div className="tile-body">
                  <div className="tile-title">
                    #{a.token_id} {a.document?.name ?? ''}
                  </div>
                  <div className="small dim">{a.slug}</div>
                  <div className="badge-row small">
                    {a.burned ? <Badge tone="fail">BURNED</Badge> : <Addr a={a.owner} n={8} />}
                    {a.frozen ? <Badge tone="ok">FROZEN</Badge> : <Badge tone="neutral">rev {a.revision}</Badge>}
                  </div>
                </div>
              </a>
            );
          })}
        </div>
      ) : (
        <Card>
          <Table
            head={['token', 'name', 'owner (index)', 'metadata', 'transfers', 'last change']}
            rows={rows.map((a) => [
              <a href={href('nft-assets', a.collection_id, a.token_id)}>
                {a.slug} #{a.token_id}
              </a>,
              a.document?.name ?? '—',
              a.burned ? <Badge tone="fail">BURNED</Badge> : <Addr a={a.owner} />,
              <span>
                <Mono>{a.metadata_hash?.slice(0, 12)}…</Mono> rev {a.revision} {a.frozen ? <Badge tone="ok">FROZEN</Badge> : null}
              </span>,
              a.transfers,
              <span>
                h{a.last_event_height} <SettlementBadge s={a.settlement} />
              </span>,
            ])}
            empty="No tokens indexed."
          />
        </Card>
      )}
      <p className="small dim">Index as of height {q.data?.as_of_height ?? '—'}. Images are served from this application's content-addressed store by SHA-256.</p>
    </Page>
  );
}

interface Detail {
  chain?: {
    ref?: string;
    owner?: string | null;
    burned?: boolean;
    approved?: string | null;
    metadata?: { uri?: string; sha256?: string };
    revision?: number;
    metadata_frozen?: boolean;
    minted_height?: number;
    minted_by?: string;
    transfers?: number;
    active_listing?: string | null;
    state_height?: number;
    owner_operators?: { operator?: string; expiry_height?: number; active?: boolean }[];
  };
  index?: { owner?: string | null; as_of_height?: number } | null;
  index_agrees?: boolean;
  events?: ProvEvent[];
  revisions?: { revision?: number; height?: number; by?: string; metadata?: { uri?: string; sha256?: string }; document?: Record<string, unknown> | null; storage?: StorageLoc[] }[];
  claims?: { claim_id?: string; claim_type?: string; statement?: string; display?: string; status?: string }[];
}

function AssetDetail({ cid, tid }: { cid: string; tid: string }) {
  const q = useApi<Detail>(`/api/nft/assets/${cid}/${tid}`, 6000);
  const d = q.data;
  const c = d?.chain;
  const latest = d?.revisions?.[d.revisions.length - 1];
  const doc = (latest?.document ?? {}) as { name?: string; description?: string; image?: { sha256?: string; alt_text?: string; mime?: string; width?: number; height?: number; uri?: string }; attributes?: { trait_type?: string; value?: unknown }[]; rights?: { holder?: string; licence?: string; statement?: string; note?: string }; media?: { role?: string; mime?: string; sha256?: string; transcript?: string }[] };
  const img = mediaUrl(doc.image?.sha256);
  return (
    <Page title={doc.name ?? `Token ${tid}`} subtitle={<Mono>{c?.ref}</Mono>} actions={<a className="btn-secondary" href={`/api/nft/provenance/${cid}/${tid}`} download={`provenance-${tid}.json`}>Export provenance (JSON)</a>}>
      <Unavailable r={q.last} />
      {!d ? <Loading what="token" /> : null}
      {d ? (
        <>
          <div className="grid-2">
            <Card title="Ownership">
              <KV
                rows={[
                  ['owner — chain (authoritative)', c?.burned ? <Badge tone="fail">BURNED</Badge> : <Mono>{c?.owner}</Mono>],
                  ['at chain height', c?.state_height],
                  ['owner — index (cache)', <span><Mono>{d.index?.owner ?? '—'}</Mono> <span className="dim small">as of {d.index?.as_of_height}</span></span>],
                  ['index agrees', d.index_agrees ? <Badge tone="ok">YES</Badge> : <Badge tone="caution">NO — run index sync</Badge>],
                  ['single-token approval', c?.approved ? <Mono>{c.approved}</Mono> : 'none'],
                  ['owner operators (collection-wide)', (c?.owner_operators ?? []).length ? (c?.owner_operators ?? []).map((o, i) => <div key={i}><Mono>{o.operator}</Mono> {o.active ? <Badge tone="caution">ACTIVE</Badge> : 'expired'}</div>) : 'none'],
                  ['active listing', c?.active_listing ? <Mono>{c.active_listing.slice(0, 16)}…</Mono> : 'none'],
                  ['minted', `height ${c?.minted_height} by ${c?.minted_by?.slice(0, 16)}…`],
                  ['transfers', c?.transfers],
                ]}
              />
              <Notice tone="info">Owning this token is a ledger record. It does not transfer copyright or any physical object.</Notice>
            </Card>
            <Card title="Metadata" right={c?.metadata_frozen ? <Badge tone="ok">FROZEN</Badge> : <Badge tone="info">revision {c?.revision}</Badge>}>
              {img ? <img className="detail-img" src={img} alt={doc.image?.alt_text ?? ''} /> : <Notice tone="caution">Image not available from this application's store.</Notice>}
              <p className="small">
                <strong>Alt text:</strong> {doc.image?.alt_text ?? '—'}
              </p>
              <p>{doc.description}</p>
              <KV
                rows={[
                  ['on chain: metadata sha256', <Mono>{c?.metadata?.sha256}</Mono>],
                  ['on chain: metadata uri', <Mono>{c?.metadata?.uri}</Mono>],
                  ['off chain: image sha256', <Mono>{doc.image?.sha256}</Mono>],
                  ['image', `${doc.image?.mime ?? ''} ${doc.image?.width ?? ''}×${doc.image?.height ?? ''}`],
                  ['rights holder', doc.rights?.holder],
                  ['licence', doc.rights?.licence],
                  ['statement', <span className="small">{doc.rights?.statement}</span>],
                  ['other media', (doc.media ?? []).map((m, i) => <div key={i} className="small">{m.role}: {m.mime} <Mono>{m.sha256?.slice(0, 12)}…</Mono>{m.transcript ? ` — transcript: ${m.transcript}` : ''}</div>)],
                ]}
              />
              <div className="badge-row">
                {(doc.attributes ?? []).map((a, i) => (
                  <Badge key={i} tone="neutral">
                    {a.trait_type}: {String(a.value)}
                  </Badge>
                ))}
              </div>
            </Card>
          </div>
          <Card title="Metadata revisions (recorded on chain)">
            <Table
              head={['rev', 'height', 'by', 'metadata sha256', 'stored copies (maintainer · last check)']}
              rows={(d.revisions ?? []).map((r) => [
                r.revision,
                r.height,
                <Addr a={r.by} />,
                <Mono>{r.metadata?.sha256?.slice(0, 24)}…</Mono>,
                <div>
                  {(r.storage ?? []).map((s, i) => (
                    <div key={i} className="small">
                      {s.adapter} · {s.maintainer} · <StorageBadge v={s.last_available} />
                    </div>
                  ))}
                  {(r.storage ?? []).length === 0 ? <span className="dim small">no copy registered here</span> : null}
                </div>,
              ])}
            />
          </Card>
          <Card title="Provenance (chain events)">
            <Table
              head={['height', 'event', 'from', 'to', 'by', 'tx', 'settlement']}
              rows={(d.events ?? []).map((e) => [
                e.height,
                <span>
                  <strong>{e.kind?.replace('nft_', '')}</strong> {e.op ? <span className="dim">· {e.op}</span> : null}
                </span>,
                <Addr a={e.from_addr} n={8} />,
                <Addr a={e.to_addr} n={8} />,
                <Addr a={e.actor} n={8} />,
                <a href={href('transactions', e.txid ?? '')}>
                  <Mono>{e.txid?.slice(0, 10)}…</Mono>
                </a>,
                <SettlementBadge s={e.settlement} />,
              ])}
            />
          </Card>
          {(d.claims ?? []).length ? (
            <Card title="Issuer claims (off-chain reviews — not chain facts)">
              <Table head={['claim', 'statement', 'review']} rows={(d.claims ?? []).map((cl) => [cl.claim_type, cl.statement, <Badge tone={cl.status === 'accepted' ? 'ok' : cl.status === 'rejected' ? 'fail' : 'caution'}>{cl.display}</Badge>])} />
            </Card>
          ) : null}
          <Json value={d} />
        </>
      ) : null}
    </Page>
  );
}
