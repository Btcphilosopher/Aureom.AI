import { useEffect, useState } from 'react';
import { Amount, Badge, Card, ErrorBox, Freshness, Hash, IssuerTag, Json, KV, Loading, Mono, Notice, OnChainTag, Page, Table } from '../components/ui';
import { pickArray, type Account, type TokenBalance } from '../lib/api';
import { DASH, num, str } from '../lib/format';
import { href, navigate, useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';

/** Symbols that occur on more than one distinct token id. */
export function duplicateSymbols(tokens: { token_id?: string; symbol?: string }[]): Set<string> {
  const ids = new Map<string, Set<string>>();
  for (const t of tokens) {
    if (!t.symbol) continue;
    const k = t.symbol.toUpperCase();
    if (!ids.has(k)) ids.set(k, new Set());
    ids.get(k)!.add(t.token_id ?? '?');
  }
  return new Set([...ids.entries()].filter(([, s]) => s.size > 1).map(([k]) => k));
}

export function SymbolWarning({ dups }: { dups: Set<string> }) {
  if (!dups.size) return null;
  return (
    <Notice tone="caution" title={`Duplicate symbol${dups.size > 1 ? 's' : ''}: ${[...dups].join(', ')}`}>
      Symbols are not unique — compare token ids. Anyone can create a token with any symbol or name; only the <Mono>token_id</Mono> identifies an asset.
    </Notice>
  );
}

export function Perm({ label, value }: { label: string; value: unknown }) {
  if (value === null || value === undefined || value === false || value === '')
    return (
      <span className="perm perm-none">
        {label}: <strong>{value === false ? 'no' : 'none'}</strong>
      </span>
    );
  if (value === true)
    return (
      <span className="perm perm-on">
        <Badge tone="caution">{label}: yes</Badge>
      </span>
    );
  return (
    <span className="perm perm-on">
      <Badge tone="caution">{label}</Badge> <Hash value={value} n={8} />
    </span>
  );
}

function TokenRow({ t, dup }: { t: TokenBalance; dup: boolean }) {
  const p = t.issuer_permissions ?? {};
  return (
    <div className={`token-row ${dup ? 'token-dup' : ''}`}>
      <div className="token-id">
        <span className="small dim">token_id</span> <OnChainTag />
        <div>
          <code className="mono strong">{str(t.token_id)}</code>
        </div>
      </div>
      <div className="token-label">
        <div>
          <strong>{str(t.symbol)}</strong> {dup ? <Badge tone="caution">SYMBOL NOT UNIQUE</Badge> : null}
        </div>
        <div className="small">{str(t.name)}</div>
        <IssuerTag />
      </div>
      <div className="token-bal">
        <Amount value={t.balance} decimals={t.decimals} />
        <div className="small dim">decimals {num(t.decimals)}</div>
        {t.frozen ? <Badge tone="fail">FROZEN for this account</Badge> : null}
      </div>
      <div className="token-perms small">
        <div className="dim">issuer permissions</div>
        <Perm label="mint authority" value={p.mint_authority} />
        <Perm label="admin" value={p.admin} />
        <Perm label="pausable" value={p.pausable} />
        <Perm label="freezable" value={p.freezable} />
      </div>
    </div>
  );
}

function AccountDetail({ address }: { address: string }) {
  const { decimals, ticker } = useApp();
  const q = useNodeQuery<Account>(`/v1/accounts/${encodeURIComponent(address)}`, 6000);
  const txq = useNodeQuery<unknown>(`/v1/accounts/${encodeURIComponent(address)}/transactions?limit=20`);
  const now = useNow(1000);
  const a = q.data;
  const tokens = pickArray<TokenBalance>(a?.tokens);
  const dups = duplicateSymbols(tokens);
  const nat = a?.native ?? {};
  const amt = (v: unknown) => <Amount value={v} decimals={decimals} unit={ticker} />;
  const txs = pickArray<unknown>(txq.data, 'transactions', 'txids', 'txs');
  return (
    <>
      <ErrorBox result={q.last} what={`account ${address}`} />
      {q.loading ? <Loading what="account" /> : null}
      {a ? (
        <>
          <div className="grid-2">
            <Card title="Native balances" right={<Freshness lastOkAt={q.lastOkAt} now={now} />}>
              <KV
                rows={[
                  ['address', <Hash value={a.address ?? address} full />],
                  ['nonce', num(a.nonce)],
                  ['as of height', num(a.height)],
                  ['total', amt(nat.total)],
                  ['available', amt(nat.available)],
                  ['locked (vesting)', amt(nat.locked_vesting)],
                  ['immature (mining rewards)', amt(nat.immature)],
                  ['bonded (stake)', amt(nat.bonded)],
                  ['unbonding', amt(nat.unbonding)],
                ]}
              />
              {a.multisig ? (
                <p className="small">
                  <Badge tone="info">MULTISIG</Badge> {num(a.multisig.threshold)} of {num(a.multisig.signers?.length)} signers.{' '}
                  <a href={href('treasury', a.address ?? address)}>View proposals →</a>
                </p>
              ) : null}
            </Card>
            <Card title="Vesting & maturity">
              <Table
                head={['total', 'start', 'cliff', 'end', 'vested', 'locked']}
                rows={pickArray<NonNullable<Account['vesting']>[number]>(a.vesting).map((v) => [
                  amt(v.total),
                  num(v.start_height),
                  num(v.cliff_height),
                  num(v.end_height),
                  amt(v.vested),
                  amt(v.locked),
                ])}
                empty="No vesting schedules."
              />
              <p className="small dim">Vesting is by block height. Calendar dates are only estimates.</p>
              {pickArray<NonNullable<Account['immature']>[number]>(a.immature).length ? (
                <Table head={['immature amount', 'matures at height']} rows={pickArray<NonNullable<Account['immature']>[number]>(a.immature).map((i) => [amt(i.amount), num(i.mature_height)])} />
              ) : null}
            </Card>
          </div>
          <Card title={`Token balances (${tokens.length})`}>
            <SymbolWarning dups={dups} />
            {tokens.length === 0 ? <p className="dim">No token balances.</p> : tokens.map((t, i) => <TokenRow key={`${t.token_id}-${i}`} t={t} dup={!!t.symbol && dups.has(t.symbol.toUpperCase())} />)}
          </Card>
          <Card title="Recent transactions (explorer index)">
            <ErrorBox result={txq.last} what="account transactions" />
            {txs.length === 0 ? (
              <p className="dim">{txq.loading ? 'Loading…' : 'None indexed.'}</p>
            ) : (
              <ul className="tight">
                {txs.map((t, i) => {
                  const id = typeof t === 'string' ? t : t && typeof t === 'object' ? String((t as { id?: string; txid?: string }).id ?? (t as { txid?: string }).txid ?? '') : '';
                  return id ? (
                    <li key={i}>
                      <a href={href('transactions', id)}>
                        <Mono>{id}</Mono>
                      </a>
                    </li>
                  ) : null;
                })}
              </ul>
            )}
          </Card>
          <Json value={a} />
        </>
      ) : null}
    </>
  );
}

export function AccountsPage({ address }: { address?: string }) {
  const { nativeAsset } = useApp();
  const [input, setInput] = useState(address ?? '');
  useEffect(() => setInput(address ?? ''), [address]);
  const hrp = nativeAsset?.address_hrp;
  return (
    <Page title="Accounts" subtitle="Address lookup: native balances, vesting, and token holdings.">
      <Card>
        <form
          className="lookup"
          onSubmit={(e) => {
            e.preventDefault();
            const v = input.trim();
            if (v) navigate('accounts', v);
          }}
        >
          <label className="field grow">
            <span>Address{hrp ? ` (${hrp}1…)` : ''}</span>
            <input value={input} onChange={(e) => setInput(e.target.value)} className="mono" spellCheck={false} placeholder={hrp ? `${hrp}1…` : 'address'} />
          </label>
          <button type="submit" className="btn-primary">
            Look up
          </button>
        </form>
        {hrp && input.trim() && !input.trim().startsWith(`${hrp}1`) ? (
          <p className="small">
            <Badge tone="caution">PREFIX</Badge> Addresses on this network start with <Mono>{hrp}1</Mono>. A different prefix belongs to another network.
          </p>
        ) : null}
      </Card>
      {address ? <AccountDetail address={address} /> : <p className="dim">{DASH} Enter an address to inspect.</p>}
    </Page>
  );
}
