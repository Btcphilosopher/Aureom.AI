import { Badge, Card, ErrorBox, Freshness, Hash, Json, KV, Loading, Mono, Notice, Page, Sparkline, Table } from '../components/ui';
import { pickArray, type ConsensusStatus } from '../lib/api';
import { DASH, formatTime, isBft, num, profileLabel, str, yesNo } from '../lib/format';
import { useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';

function PowView({ c }: { c: ConsensusStatus }) {
  const times = pickArray<number>(c.recent_block_times_ms).filter((v) => typeof v === 'number');
  const secs = times.map((t) => Math.round(t / 100) / 10);
  const reorgs = pickArray<NonNullable<ConsensusStatus['reorgs']>[number]>(c.reorgs);
  const target = typeof c.target_block_time_ms === 'number' ? c.target_block_time_ms / 1000 : undefined;
  return (
    <>
      <Notice tone="caution" title="Probabilistic settlement">
        Proof-of-work settlement is probabilistic. A transaction with k confirmations can still be reversed by a branch with more cumulative work. A small development
        network offers no resistance to a majority-hashpower attacker: anyone with more hash power than the honest miners combined can rewrite recent history. The
        confirmation count is a convenience, not a finality guarantee
        {typeof c.confirmations_recommended === 'number' ? ` (recommended: ${c.confirmations_recommended})` : ''}.
      </Notice>
      <div className="grid-2">
        <Card title="Proof-of-work state">
          <KV
            rows={[
              ['engine', str(c.engine)],
              ['height', num(c.height)],
              ['tip', <Hash value={c.tip} />],
              ['difficulty', <Mono>{str(c.difficulty)}</Mono>],
              ['target', <Hash value={c.target} full />],
              ['cumulative work', <Mono>{str(c.cumulative_work)}</Mono>],
              ['target block time', typeof c.target_block_time_ms === 'number' ? `${c.target_block_time_ms} ms` : DASH],
              ['finality', str(c.finality)],
              ['mining on this node', c.mining ? `${yesNo(c.mining.enabled)}${c.mining.hashes !== undefined ? ` · ${num(c.mining.hashes)} hashes` : ''}` : DASH],
              ['mining address', <Hash value={c.mining?.address} />],
            ]}
          />
        </Card>
        <Card title="Recent block intervals (s)">
          <Sparkline values={secs} reference={target} unit=" s" width={420} height={90} />
          <p className="small dim">Interval between consecutive blocks, oldest → newest, as reported by the node. Large variance is normal for PoW.</p>
        </Card>
      </div>
      <Card title={`Reorganisation log (${reorgs.length})`}>
        <Table
          head={['when', 'depth', 'fork height', 'old tip', 'new tip']}
          rows={reorgs.map((r) => [
            formatTime(r.at_ms),
            typeof r.depth === 'number' ? <Badge tone={r.depth >= 2 ? 'caution' : 'neutral'}>{r.depth} block{r.depth === 1 ? '' : 's'}</Badge> : DASH,
            num(r.fork_height),
            <Hash value={r.old_tip} />,
            <Hash value={r.new_tip} />,
          ])}
          empty="No reorganisations observed by this node."
        />
        <p className="small dim">Transactions from disconnected blocks return to the mempool; those no longer valid are dropped.</p>
      </Card>
    </>
  );
}

function BftView({ c, profile }: { c: ConsensusStatus; profile: string | undefined }) {
  const lc = c.last_commit ?? {};
  const total = lc.total_power ?? c.total_power;
  const signed = lc.signed_power;
  const frac = typeof signed === 'number' && typeof total === 'number' && total > 0 ? signed / total : null;
  const quorumMet = typeof signed === 'number' && typeof total === 'number' ? signed * 3 > total * 2 : null;
  const W = 520;
  return (
    <>
      <Notice tone="info" title="BFT fault assumption">
        Safety requires that validators controlling less than 1/3 of the total voting power are Byzantine. Liveness additionally needs more than 2/3 of the voting power
        online and honest. A committed block is final; this software never rolls back finalised history.
        {profile === 'poa' ? ' On PoA the authorities are a fixed permissioned set: security rests on the honesty of those operators.' : ''}
        {c.fault_assumption ? <span className="small dim"> Node reports: “{c.fault_assumption}”</span> : null}
      </Notice>
      <div className="grid-2">
        <Card title="CometBFT state">
          <KV
            rows={[
              ['engine', `${str(c.engine)} ${c.cometbft_version ?? ''}`],
              ['height', num(c.height)],
              ['round', num(c.round)],
              ['app height', num(c.app_height)],
              ['latest block hash', <Hash value={c.latest_block_hash} />],
              ['latest app hash', <Hash value={c.latest_app_hash} />],
              ['catching up', c.catching_up === true ? <Badge tone="caution">yes</Badge> : yesNo(c.catching_up)],
              ['quorum', str(c.quorum)],
              ['finality', str(c.finality)],
              ['epoch', c.epoch ? `length ${num(c.epoch.length)} · next at ${num(c.epoch.next)}` : profile === 'pos' ? DASH : 'n/a'],
            ]}
          />
        </Card>
        <Card title="Last commit participation">
          <svg width={W} height={54} viewBox={`0 0 ${W} 54`} className="quorum" role="img" aria-label="signed voting power versus 2/3 quorum">
            <title>{`signed ${signed ?? '—'} of ${total ?? '—'} voting power`}</title>
            <rect x={0} y={14} width={W} height={18} rx={4} className="bar-track" />
            {frac !== null ? <rect x={0} y={14} width={Math.max(4, frac * W)} height={18} rx={4} className="bar-fill" /> : null}
            <line x1={(W * 2) / 3} x2={(W * 2) / 3} y1={6} y2={40} className="bar-marker" />
            <text x={(W * 2) / 3 + 4} y={50} className="svg-label">
              quorum 2/3
            </text>
          </svg>
          <KV
            rows={[
              ['signed power', `${num(signed)} / ${num(total)}${frac !== null ? ` (${(frac * 100).toFixed(1)} %)` : ''}`],
              ['signers', `${num(lc.signers)} of ${num(lc.validators)} validators`],
              [
                'quorum (> 2/3)',
                quorumMet === null ? DASH : quorumMet ? <Badge tone="ok">met</Badge> : <Badge tone="fail">NOT MET — chain cannot commit</Badge>,
              ],
            ]}
          />
          {frac !== null && quorumMet && frac < 0.8 ? (
            <Notice tone="caution">Participation is close to the 2/3 quorum. Losing a little more voting power will halt block production (liveness), not safety.</Notice>
          ) : null}
        </Card>
      </div>
    </>
  );
}

export function ConsensusPage() {
  const { profile } = useApp();
  const q = useNodeQuery<ConsensusStatus>('/v1/consensus/status', 4000);
  const now = useNow(1000);
  const c = q.data;
  const p = c?.profile ?? profile;
  return (
    <Page
      title="Consensus"
      subtitle={`Consensus status from ${q.nodeName ?? DASH} — profile ${profileLabel(p)}.`}
      actions={<Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />}
    >
      <ErrorBox result={q.last} what="consensus status" />
      {q.loading ? <Loading what="consensus status" /> : null}
      {c && profile && c.profile && c.profile !== profile ? (
        <Notice tone="fail" title="Profile mismatch">
          The node reports profile <Mono>{c.profile}</Mono> but the manifest says <Mono>{profile}</Mono>.
        </Notice>
      ) : null}
      {c ? p === 'pow' ? <PowView c={c} /> : isBft(p) ? <BftView c={c} profile={p} /> : <Notice tone="caution">Unknown profile {str(p)}.</Notice> : null}
      {c ? <Json value={c} /> : null}
    </Page>
  );
}
