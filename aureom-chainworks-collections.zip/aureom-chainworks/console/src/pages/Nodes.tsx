import { Badge, Card, Hash, KV, Mono, Notice, Page, type Tone } from '../components/ui';
import { ago, DASH, formatBytes, formatDuration, num, str, yesNo } from '../lib/format';
import { useNow } from '../lib/hooks';
import { chainCheck, isStale, nodeState, POLL_MS, STALE_MS, useApp, type NodeObservation, type NodeState } from '../lib/state';

export const STATE_INFO: Record<NodeState, { label: string; tone: Tone; text: string }> = {
  pending: { label: 'WAITING', tone: 'neutral', text: 'No observation yet.' },
  unreachable: { label: 'UNREACHABLE', tone: 'fail', text: 'The node API did not answer through the console server.' },
  unhealthy: { label: 'REACHABLE — UNHEALTHY', tone: 'caution', text: 'The node answers but reports a degraded/halted status, a critical alert or an API error.' },
  'wrong-chain': { label: 'WRONG CHAIN', tone: 'fail', text: 'The node answers but its chain_id / genesis hash does not match this network manifest.' },
  healthy: { label: 'HEALTHY', tone: 'ok', text: 'Reachable, status ok, and on the manifest chain.' },
};

export function NodeCard({ o, now }: { o: NodeObservation; now: number }) {
  const { manifest, queryNode } = useApp();
  const st = nodeState(o, manifest);
  const info = STATE_INFO[st];
  const cc = chainCheck(o, manifest);
  const stale = isStale(o, now);
  const h = o.lastHealth;
  const n = o.lastNetwork;
  const tipAge = typeof h?.tip_age_ms === 'number' ? h.tip_age_ms : typeof h?.tip_time_ms === 'number' && typeof h?.observed_at_ms === 'number' ? h.observed_at_ms - h.tip_time_ms : undefined;
  const err = o.health && !o.health.ok ? o.health.error : null;
  return (
    <Card
      className={`node-card node-${st}`}
      title={
        <span>
          {o.node.name} {o.node.role ? <span className="dim small">· {o.node.role}</span> : null}
          {queryNode?.name === o.node.name ? <span className="dim small"> · query node</span> : null}
        </span>
      }
      right={<Badge tone={info.tone}>{info.label}</Badge>}
    >
      <p className="small state-text">
        {st === 'wrong-chain'
          ? `${o.health?.ok && o.health.data.status === 'ok' ? 'Healthy (status ok)' : `Reachable (status ${str(h?.status)})`} — but on the WRONG CHAIN: its chain_id / genesis hash does not match this network manifest.`
          : info.text}
      </p>
      <div className="badge-row">
        {cc.result === 'match' ? <Badge tone="ok">CHAIN MATCHES MANIFEST</Badge> : null}
        {cc.result === 'mismatch' ? <Badge tone="fail">WRONG CHAIN</Badge> : null}
        {cc.result === 'unknown' ? <Badge tone="caution">CHAIN UNVERIFIED</Badge> : null}
        {stale ? (
          <Badge tone="caution">STALE · {o.lastOkAt ? `last good ${formatDuration(ago(now, o.lastOkAt))} ago` : 'never observed'}</Badge>
        ) : o.lastOkAt ? (
          <span className="dim small">observed {formatDuration(ago(now, o.lastOkAt))} ago</span>
        ) : null}
        {h?.syncing ? <Badge tone="caution">SYNCING</Badge> : null}
      </div>
      {cc.result === 'mismatch' ? (
        <Notice tone="fail" title="Chain check failed">
          <ul className="tight">
            {cc.problems.map((p) => (
              <li key={p}>
                <Mono>{p}</Mono>
              </li>
            ))}
          </ul>
          Data from this node must not be used for this network.
        </Notice>
      ) : null}
      {err ? (
        <p className="small">
          <Badge tone={o.health && !o.health.ok && o.health.unreachable ? 'fail' : 'caution'}>LAST POLL FAILED</Badge> <Mono>{err.code}</Mono> {err.message}
        </p>
      ) : null}
      {o.health && !o.health.ok && h ? <p className="small dim">Values below are from the last successful observation, not the current state.</p> : null}
      <KV
        rows={[
          ['status', h ? <Mono>{str(h.status)}</Mono> : DASH],
          ['height', num(h?.height)],
          ['tip', <Hash value={h?.tip_id} />],
          ['tip age', typeof tipAge === 'number' ? formatDuration(tipAge) : DASH],
          ['peers', num(h?.peers)],
          ['syncing', yesNo(h?.syncing)],
          ['mempool txs', num(h?.mempool_txs)],
          ['node version', str(n?.node_version)],
          ['backend', n?.backend ? `${n.backend} ${n.backend_version ?? ''}` : DASH],
          ['chain id', <Mono>{str(n?.chain_id)}</Mono>],
          ['genesis hash', <Hash value={n?.genesis_hash} />],
          ['storage', h?.storage ? `${formatBytes(h.storage.db_bytes)} · db v${num(h.storage.db_version)}` : DASH],
          ['api url', <Mono>{str(o.node.api_url)}</Mono>],
        ]}
      />
      {h?.alerts && h.alerts.length ? (
        <ul className="alerts">
          {h.alerts.map((a, i) => (
            <li key={i}>
              <Badge tone={a.level === 'critical' ? 'fail' : 'caution'}>{(a.level ?? 'alert').toUpperCase()}</Badge> <Mono>{str(a.code)}</Mono> {str(a.message)}
            </li>
          ))}
        </ul>
      ) : null}
    </Card>
  );
}

export function NodesPage() {
  const { observations } = useApp();
  const now = useNow(1000);
  return (
    <Page
      title="Nodes"
      subtitle={`Each manifest node is polled every ${POLL_MS / 1000} s (/v1/health and /v1/network) through the console server. An observation is STALE when the last successful one is older than ${STALE_MS / 1000} s.`}
    >
      <div className="legend-row small">
        {(['unreachable', 'unhealthy', 'wrong-chain', 'healthy'] as NodeState[]).map((s) => (
          <span key={s}>
            <Badge tone={STATE_INFO[s].tone}>{STATE_INFO[s].label}</Badge> {STATE_INFO[s].text}
          </span>
        ))}
      </div>
      {observations.length === 0 ? <Notice tone="caution">The manifest lists no nodes.</Notice> : null}
      <div className="grid-3">
        {observations.map((o) => (
          <NodeCard key={o.node.name} o={o} now={now} />
        ))}
      </div>
    </Page>
  );
}
