import { useEffect, useState } from 'react';
import { Amount, Badge, Card, ErrorBox, Freshness, Hash, KV, Loading, Mono, Notice, Page, Table, type Tone } from '../components/ui';
import { pickArray, type MsigProposal, type Multisig, type Treasury } from '../lib/api';
import { DASH, num, str } from '../lib/format';
import { href, navigate, useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { useApp } from '../lib/state';
import { actionSummary } from './Blocks';

const PROP_TONE: Record<string, Tone> = { pending: 'caution', executed: 'ok', failed: 'fail', expired: 'neutral' };

export function approvalCount(a: unknown, fallback?: unknown): number | null {
  if (Array.isArray(a)) return a.length;
  if (typeof a === 'number') return a;
  if (typeof fallback === 'number') return fallback;
  return null;
}

function MultisigCard({ label, address }: { label?: string; address: string }) {
  const { decimals, ticker } = useApp();
  const now = useNow(1000);
  const q = useNodeQuery<Multisig>(`/v1/multisigs/${encodeURIComponent(address)}`, 8000);
  const m = q.data;
  const signers = pickArray<string>(m?.signers);
  const props = pickArray<MsigProposal>(m?.proposals);
  return (
    <Card title={label ? `${label}` : 'Multisig'} right={<Freshness lastOkAt={q.lastOkAt} now={now} failing={q.last !== null && !q.last.ok} />}>
      <ErrorBox result={q.last} what={`multisig ${address}`} />
      {q.loading ? <Loading what="multisig" /> : null}
      <KV
        rows={[
          ['address', <a href={href('accounts', address)}><Hash value={address} full /></a>],
          ['threshold', m ? `${num(m.threshold)} of ${signers.length} signers` : DASH],
          ['balance', m?.balance !== undefined ? <Amount value={m.balance} decimals={decimals} unit={ticker} /> : DASH],
        ]}
      />
      {signers.length ? (
        <>
          <h3>Signers</h3>
          <ol className="tight mono small">
            {signers.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ol>
        </>
      ) : null}
      <h3>Proposals ({props.length})</h3>
      <Table
        head={['id', 'proposed action', 'proposer', 'approvals', 'expiry', 'status']}
        rows={props.map((p) => {
          const n = approvalCount(p.approvals, p.approval_count);
          const th = typeof m?.threshold === 'number' ? m.threshold : null;
          return [
            num(p.id),
            <span className="small">{actionSummary({ action: p.inner }, decimals, ticker)}</span>,
            <Hash value={p.proposer} />,
            <span>
              <strong>{n === null ? DASH : n}</strong> / {th ?? DASH}
              {Array.isArray(p.approvals) ? <span className="dim small" title={p.approvals.join('\n')}> (signed by {p.approvals.length})</span> : null}
            </span>,
            num(p.expiry_height),
            <span>
              <Badge tone={PROP_TONE[p.status ?? ''] ?? 'neutral'}>{str(p.status).toUpperCase()}</Badge>
              {p.error ? <Mono> {p.error}</Mono> : null}
            </span>,
          ];
        })}
        empty="No proposals."
      />
    </Card>
  );
}

export function TreasuryPage({ address }: { address?: string }) {
  const { manifest } = useApp();
  const list = pickArray<Treasury>(manifest?.network?.treasuries).filter((t) => typeof t.address === 'string' && t.address);
  const [input, setInput] = useState(address ?? '');
  useEffect(() => setInput(address ?? ''), [address]);
  const extra = address && !list.some((t) => t.address === address) ? address : null;
  return (
    <Page title="Treasury" subtitle="Threshold-approval multisignature accounts declared in the manifest, read from the selected query node.">
      <Notice tone="security" title="Dashboard clicks are not approvals">
        Approvals are separately signed on-chain transactions; dashboard clicks are not approvals. Each signer approves with their own key in the CLI wallet
        (<Mono>multisig_approve</Mono>). When approvals reach the threshold the proposed action executes on-chain as the multisig account.
      </Notice>
      <Card>
        <form
          className="lookup"
          onSubmit={(e) => {
            e.preventDefault();
            if (input.trim()) navigate('treasury', input.trim());
          }}
        >
          <label className="field grow">
            <span>Inspect another multisig address</span>
            <input value={input} onChange={(e) => setInput(e.target.value)} className="mono" spellCheck={false} />
          </label>
          <button type="submit" className="btn-secondary">
            Look up
          </button>
        </form>
      </Card>
      {list.length === 0 && !extra ? <Notice tone="info">The manifest declares no treasuries (network.treasuries is absent or empty).</Notice> : null}
      <div className="grid-2">
        {extra ? <MultisigCard address={extra} label="Looked-up multisig" /> : null}
        {list.map((t) => (
          <MultisigCard key={t.address} address={t.address as string} label={t.label} />
        ))}
      </div>
    </Page>
  );
}
