import { Badge, Card, ErrorBox, Hash, Loading, Mono, Notice, Page, Table } from '../components/ui';
import { pickArray, type RecoveryItem } from '../lib/api';
import { formatBytes, formatTime, num, str } from '../lib/format';
import { useApi } from '../lib/query';

const PROCEDURES: { title: string; cmd: string; text: string }[] = [
  { title: 'Create a state snapshot', cmd: 'chainworks snapshot create <network-dir> --node <name>', text: 'Writes a verified state snapshot (via the node’s local, token-authenticated admin API — never through this console). Records height and state root.' },
  { title: 'Verify a snapshot', cmd: 'chainworks snapshot verify <network-dir> --file <snapshot> --against-node <name>', text: 'Recomputes the snapshot digest and state root, then compares the root with a block that node validated itself. A peer-supplied hash alone is never enough.' },
  { title: 'Back up a node', cmd: 'chainworks backup <network-dir> --node <name>', text: 'Briefly stops the node, makes a consistent copy of its database (and CometBFT data for BFT nodes) with a SHA-256 manifest, then restarts it.' },
  { title: 'Restore a node', cmd: 'chainworks restore <network-dir> --node <name> --from <backup-dir>', text: 'Verifies every checksum, keeps the replaced data aside, never moves validator signing state backwards; the node re-checks its state root and genesis hash on start.' },
  { title: 'Replay / re-validate', cmd: 'chainworks replay <network-dir> --node <name> --snapshot <file> [--repair]', text: 'Node stopped: verifies the snapshot against the locally validated block, re-executes stored blocks above it checking every state root; `aureom-node verify-chain` re-executes from genesis.' },
];

export function RecoveryPage() {
  const q = useApi<unknown>('/api/recovery');
  const snaps = pickArray<RecoveryItem>(q.data, 'snapshots');
  const backups = pickArray<RecoveryItem>(q.data, 'backups');
  const row = (s: RecoveryItem) => [
    <Mono>{str(s.path)}</Mono>,
    str(s.node),
    num(s.height),
    <Hash value={s.state_root ?? s.sha256} />,
    formatBytes(s.bytes),
    formatTime(s.created_ms),
    s.verified === true ? <Badge tone="ok">verified</Badge> : s.verified === false ? <Badge tone="fail">FAILED VERIFY</Badge> : <Badge tone="caution">not verified</Badge>,
  ];
  return (
    <Page title="Recovery" subtitle="Snapshots and backups found in the network directory, and the documented CLI procedures.">
      <Notice tone="caution" title="The console performs no recovery actions">
        Snapshot, backup, restore and replay are run by an operator with the <Mono>chainworks</Mono> CLI on the host. There is no rollback of finalised history: recovery
        restores a node to the canonical chain, it never rewrites what the network has agreed on.
      </Notice>
      <ErrorBox result={q.last} what="recovery inventory" />
      {q.loading ? <Loading what="recovery inventory" /> : null}
      <Card title={`Snapshots (${snaps.length})`}>
        <Table head={['path', 'node', 'height', 'state root / digest', 'size', 'created', 'verification']} rows={snaps.map(row)} empty="No snapshots found." />
      </Card>
      <Card title={`Backups (${backups.length})`}>
        <Table head={['path', 'node', 'height', 'state root / digest', 'size', 'created', 'verification']} rows={backups.map(row)} empty="No backups found." />
      </Card>
      <Card title="CLI procedures">
        <p className="small dim">
          Commands as implemented in this release — run <Mono>chainworks &lt;command&gt; --help</Mono> for all flags of your
          installed version.
        </p>
        <ol className="procedures">
          {PROCEDURES.map((p) => (
            <li key={p.title}>
              <strong>{p.title}</strong>
              <pre className="cmd">{p.cmd}</pre>
              <p className="small">{p.text}</p>
            </li>
          ))}
        </ol>
        <Notice tone="info">
          PoW reorganisations deeper than a node's undo retention halt the node with a critical alert; recover it from a verified snapshot or backup, then let it sync. BFT
          (PoS/PoA) nodes never roll back committed blocks.
        </Notice>
      </Card>
    </Page>
  );
}
