import { Card, ErrorBox, Hash, Loading, Mono, Notice, Page, Table } from '../components/ui';
import { pickArray, type KeyEntry } from '../lib/api';
import { str } from '../lib/format';
import { useApi } from '../lib/query';

export function KeysPage() {
  const q = useApi<unknown>('/api/keys');
  const keys = pickArray<KeyEntry>(q.data, 'keys');
  return (
    <Page title="Keys" subtitle="Public key inventory of this network directory (role, label, address, public key).">
      <div className="big-notice" role="note">
        <div className="big-notice-label">SECURITY</div>
        <p>
          The console never asks for private keys, keystore passphrases or seed phrases. Never enter production recovery material into any web page.
        </p>
        <p className="small">
          Keystores stay encrypted on disk (Argon2id + XChaCha20-Poly1305) and are used only by the <Mono>chainworks</Mono> CLI. This page shows public information only, as
          returned by <Mono>GET /api/keys</Mono>; it has no input for keys.
        </p>
      </div>
      <ErrorBox result={q.last} what="key inventory" />
      {q.loading ? <Loading what="keys" /> : null}
      <Card title={`Public keys (${keys.length})`}>
        <Table
          head={['role', 'label', 'node', 'address', 'public key']}
          rows={keys.map((k) => [<Mono>{str(k.role)}</Mono>, str(k.label), str(k.node), <Hash value={k.address} full />, <Hash value={k.pubkey} n={12} />])}
          empty="No public keys listed."
        />
      </Card>
      <Notice tone="info">An address or public key being listed here says nothing about who controls the private key today.</Notice>
    </Page>
  );
}
