import { useEffect, useMemo, useRef, useState } from 'react';
import { Badge, Bar, Card, Mono, Notice, Page, Sparkline, Table, type Tone } from '../components/ui';
import { nodeGet, pickArray, type Block, type ManifestNode, type Peer, type Peers } from '../lib/api';
import { ago, DASH, formatDuration, num } from '../lib/format';
import { useNow } from '../lib/hooks';
import { useNodeQuery } from '../lib/query';
import { chainCheck, isStale, nodeState, useApp, type NodeObservation, type NodeState } from '../lib/state';
import { STATE_INFO } from './Nodes';

interface AggAlert {
  node: string;
  level: 'critical' | 'warning';
  code: string;
  message: string;
}

const DIVERGENCE_WARN = 3;

function collectAlerts(obs: NodeObservation[], manifest: ReturnType<typeof useApp>['manifest'], now: number, maxHeight: number | null): AggAlert[] {
  const out: AggAlert[] = [];
  for (const o of obs) {
    const st = nodeState(o, manifest);
    const name = o.node.name;
    if (st === 'unreachable') out.push({ node: name, level: 'critical', code: 'unreachable', message: o.health && !o.health.ok ? `${o.health.error.code}: ${o.health.error.message}` : 'no response' });
    if (st === 'wrong-chain') out.push({ node: name, level: 'critical', code: 'wrong_chain', message: chainCheck(o, manifest).problems.join('; ') });
    if (o.health && !o.health.ok && !o.health.unreachable) out.push({ node: name, level: 'warning', code: o.health.error.code, message: o.health.error.message });
    if (isStale(o, now)) out.push({ node: name, level: 'warning', code: 'stale_observation', message: o.lastOkAt ? `last good observation ${formatDuration(ago(now, o.lastOkAt))} ago` : 'never observed' });
    const h = o.lastHealth;
    if (h && o.health?.ok) {
      if (h.status && h.status !== 'ok') out.push({ node: name, level: h.status === 'halted' ? 'critical' : 'warning', code: `status_${h.status}`, message: `node reports status ${h.status}` });
      for (const a of h.alerts ?? []) out.push({ node: name, level: a.level === 'critical' ? 'critical' : 'warning', code: a.code ?? 'alert', message: a.message ?? '' });
      if (st !== 'wrong-chain' && !isStale(o, now) && maxHeight !== null && typeof h.height === 'number' && maxHeight - h.height >= DIVERGENCE_WARN)
        out.push({ node: name, level: 'warning', code: 'height_divergence', message: `${maxHeight - h.height} blocks behind the highest node` });
    }
  }
  return out.sort((a, b) => (a.level === b.level ? a.node.localeCompare(b.node) : a.level === 'critical' ? -1 : 1));
}

/** Poll /v1/peers for every node (for the map edges). */
function usePeers(nodes: { node: ManifestNode; proxy: string }[]): Record<string, Peer[]> {
  const [peers, setPeers] = useState<Record<string, Peer[]>>({});
  const ref = useRef(nodes);
  ref.current = nodes;
  const key = nodes.map((n) => n.proxy).join(',');
  useEffect(() => {
    let alive = true;
    const run = async () => {
      const res = await Promise.all(ref.current.map(async (n) => [n.node.name, await nodeGet<Peers>(n.proxy, '/v1/peers')] as const));
      if (!alive) return;
      setPeers((prev) => {
        const next = { ...prev };
        for (const [name, r] of res) next[name] = r.ok ? pickArray<Peer>(r.data.peers) : [];
        return next;
      });
    };
    void run();
    const t = setInterval(() => void run(), 6000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [key]);
  return peers;
}

function matchPeer(p: Peer, nodes: ManifestNode[]): string | null {
  for (const n of nodes) {
    if (p.node_name === n.name || p.id === n.name) return n.name;
    const addrs = [n.p2p_listen, n.p2p_address, n.p2p].filter((x): x is string => typeof x === 'string');
    if (p.address && addrs.some((a) => a === p.address)) return n.name;
  }
  return null;
}

const MAP_TONE: Record<NodeState, string> = { pending: 'map-pending', unreachable: 'map-fail', 'wrong-chain': 'map-fail', unhealthy: 'map-caution', healthy: 'map-ok' };

function NetworkMap({ obs, peers }: { obs: NodeObservation[]; peers: Record<string, Peer[]> }) {
  const { manifest } = useApp();
  const now = useNow(1000);
  const W = 520;
  const H = 300;
  const R = 105;
  const nodes = obs.map((o) => o.node);
  const pos = new Map<string, { x: number; y: number }>();
  obs.forEach((o, i) => {
    const a = -Math.PI / 2 + (2 * Math.PI * i) / Math.max(1, obs.length);
    pos.set(o.node.name, { x: W / 2 + (obs.length === 1 ? 0 : R * 1.5 * Math.cos(a)), y: H / 2 + (obs.length === 1 ? 0 : R * Math.sin(a)) });
  });
  const edges = new Set<string>();
  for (const [name, list] of Object.entries(peers)) {
    for (const p of list) {
      const other = matchPeer(p, nodes);
      if (other && other !== name) edges.add([name, other].sort().join('|'));
    }
  }
  return (
    <div className="map-wrap">
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} className="netmap" role="img" aria-label="network map of manifest nodes and their peer links">
        {[...edges].map((e) => {
          const [a, b] = e.split('|');
          const pa = pos.get(a);
          const pb = pos.get(b);
          if (!pa || !pb) return null;
          return <line key={e} x1={pa.x} y1={pa.y} x2={pb.x} y2={pb.y} className="map-edge" />;
        })}
        {obs.map((o) => {
          const p = pos.get(o.node.name)!;
          const st = nodeState(o, manifest);
          const stale = isStale(o, now);
          const peersN = o.lastHealth?.peers;
          return (
            <g key={o.node.name} className={MAP_TONE[st]}>
              <title>{`${o.node.name}: ${STATE_INFO[st].label}${stale ? ', STALE' : ''} · peers ${peersN ?? '—'} · height ${o.lastHealth?.height ?? '—'}`}</title>
              <circle cx={p.x} cy={p.y} r={30} className="map-halo" />
              <circle cx={p.x} cy={p.y} r={22} className="map-node" strokeDasharray={stale ? '4 3' : undefined} />
              <text x={p.x} y={p.y + 4} textAnchor="middle" className="map-count">
                {peersN ?? '—'}
              </text>
              <text x={p.x} y={p.y + 46} textAnchor="middle" className="map-label">
                {o.node.name}
              </text>
              <text x={p.x} y={p.y + 60} textAnchor="middle" className="map-sub">
                {st === 'wrong-chain' ? 'WRONG CHAIN' : STATE_INFO[st].label}
                {stale ? ' · STALE' : ''}
              </text>
            </g>
          );
        })}
      </svg>
      <p className="small dim">
        Circles are manifest nodes; the number inside is the node’s reported peer count. Lines are peer links matched to manifest nodes from <Mono>/v1/peers</Mono>{' '}
        (peers outside the manifest are counted but not drawn). Dashed outline = stale observation.
      </p>
    </div>
  );
}

function ProductionRate() {
  const q = useNodeQuery<{ blocks?: Block[] }>('/v1/blocks?limit=20', 6000);
  const blocks = pickArray<Block>(q.data, 'blocks')
    .filter((b) => typeof b.timestamp_ms === 'number' && typeof b.height === 'number')
    .sort((a, b) => (a.height as number) - (b.height as number));
  const intervals = blocks.slice(1).map((b, i) => Math.round(((b.timestamp_ms as number) - (blocks[i].timestamp_ms as number)) / 100) / 10);
  const span = blocks.length > 1 ? (blocks[blocks.length - 1].timestamp_ms as number) - (blocks[0].timestamp_ms as number) : 0;
  const perMin = span > 0 ? ((blocks.length - 1) * 60000) / span : null;
  return (
    <Card title="Block production rate" right={<span className="dim small">from {q.nodeName ?? DASH}, last {blocks.length} blocks</span>}>
      <div className="stat-row">
        <div className="stat">
          <div className="stat-v">{perMin === null ? DASH : perMin.toFixed(1)}</div>
          <div className="stat-k">blocks / minute</div>
        </div>
        <div className="stat">
          <div className="stat-v">{perMin === null ? DASH : `${(60 / perMin).toFixed(1)} s`}</div>
          <div className="stat-k">mean interval</div>
        </div>
      </div>
      <Sparkline values={intervals} unit=" s" width={420} height={70} />
    </Card>
  );
}

export function MonitoringPage() {
  const { observations, manifest } = useApp();
  const now = useNow(1000);
  const peers = usePeers(useMemo(() => observations.map((o) => ({ node: o.node, proxy: o.proxy })), [observations]));
  // Divergence only over fresh observations of nodes on the manifest chain.
  const onChain = observations.filter((o) => nodeState(o, manifest) !== 'wrong-chain' && !isStale(o, now) && o.lastHealth && typeof o.lastHealth.height === 'number');
  const heights = onChain.map((o) => o.lastHealth!.height as number);
  const maxH = heights.length ? Math.max(...heights) : null;
  const minH = heights.length ? Math.min(...heights) : null;
  const alerts = collectAlerts(observations, manifest, now, maxH);
  const states = observations.map((o) => nodeState(o, manifest));
  const staleN = observations.filter((o) => isStale(o, now)).length;
  const mempools = observations.map((o) => ({ name: o.node.name, n: o.lastHealth?.mempool_txs, stale: isStale(o, now) }));
  const maxMp = Math.max(1, ...mempools.map((m) => (typeof m.n === 'number' ? m.n : 0)));
  const divergence = maxH !== null && minH !== null ? maxH - minH : null;
  const tile = (v: string, k: string, tone?: Tone) => (
    <div className={`stat ${tone ? `stat-${tone}` : ''}`}>
      <div className="stat-v">{v}</div>
      <div className="stat-k">{k}</div>
    </div>
  );
  return (
    <Page title="Monitoring" subtitle="Aggregated from every manifest node's /v1/health, /v1/network and /v1/peers via the console server.">
      <div className="stat-row">
        {tile(`${states.filter((s) => s === 'healthy').length} / ${observations.length}`, 'nodes healthy', states.every((s) => s === 'healthy') ? 'ok' : 'caution')}
        {tile(String(alerts.filter((a) => a.level === 'critical').length), 'critical alerts', alerts.some((a) => a.level === 'critical') ? 'fail' : undefined)}
        {tile(String(alerts.filter((a) => a.level === 'warning').length), 'warnings', alerts.some((a) => a.level === 'warning') ? 'caution' : undefined)}
        {tile(divergence === null ? DASH : `${divergence} blk`, 'height divergence (fresh, on-chain)', divergence !== null && divergence >= DIVERGENCE_WARN ? 'caution' : undefined)}
        {tile(String(staleN), 'stale observations', staleN ? 'caution' : undefined)}
      </div>
      <div className="grid-2">
        <Card title={`Alerts (${alerts.length})`}>
          {alerts.length === 0 ? (
            <p>
              <Badge tone="ok">NO ALERTS</Badge>
            </p>
          ) : (
            <Table
              head={['level', 'node', 'code', 'detail']}
              rows={alerts.map((a) => [
                <Badge tone={a.level === 'critical' ? 'fail' : 'caution'}>{a.level.toUpperCase()}</Badge>,
                a.node,
                <Mono>{a.code}</Mono>,
                <span className="small">{a.message}</span>,
              ])}
            />
          )}
        </Card>
        <Card title="Network map">
          <NetworkMap obs={observations} peers={peers} />
        </Card>
        <Card title="Heights">
          <Table
            head={['node', 'state', 'height', 'behind highest', 'tip age', 'observed']}
            rows={observations.map((o) => {
              const st = nodeState(o, manifest);
              const h = o.lastHealth?.height;
              return [
                o.node.name,
                <Badge tone={STATE_INFO[st].tone}>{STATE_INFO[st].label}</Badge>,
                num(h),
                st === 'wrong-chain' ? 'n/a (other chain)' : isStale(o, now) ? 'n/a (stale)' : typeof h === 'number' && maxH !== null ? String(maxH - h) : DASH,
                typeof o.lastHealth?.tip_age_ms === 'number' ? formatDuration(o.lastHealth.tip_age_ms) : DASH,
                o.lastOkAt ? isStale(o, now) ? <Badge tone="caution">STALE · {formatDuration(ago(now, o.lastOkAt))}</Badge> : `${formatDuration(ago(now, o.lastOkAt))} ago` : <Badge tone="fail">never</Badge>,
              ];
            })}
          />
          <p className="small dim">Nodes on a different chain and stale observations are excluded from divergence. A gap of {DIVERGENCE_WARN}+ blocks raises a warning.</p>
        </Card>
        <Card title="Mempool sizes">
          <Table
            head={['node', 'pending txs', '']}
            rows={mempools.map((m) => [
              m.name,
              typeof m.n === 'number' ? `${m.n}${m.stale ? ' (stale)' : ''}` : DASH,
              <Bar value={typeof m.n === 'number' ? m.n / maxMp : null} width={180} label={`${m.n ?? '—'} txs`} />,
            ])}
          />
          <p className="small dim">Each node has its own mempool; sizes differ normally.</p>
        </Card>
        <ProductionRate />
      </div>
      {observations.some((o) => nodeState(o, manifest) === 'wrong-chain') ? (
        <Notice tone="fail" title="A manifest node is on the wrong chain">
          Its heights, mempool and peers are not part of this network. Check its genesis file and node configuration.
        </Notice>
      ) : null}
    </Page>
  );
}
