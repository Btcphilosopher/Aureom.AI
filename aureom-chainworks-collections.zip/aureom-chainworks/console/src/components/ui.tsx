import { useState, type ReactNode } from 'react';
import type { ApiResult } from '../lib/api';
import { ago, DASH, formatAmount, formatDuration, shortHash } from '../lib/format';
import { href } from '../lib/hooks';

export function Page({ title, subtitle, actions, children }: { title: string; subtitle?: ReactNode; actions?: ReactNode; children: ReactNode }) {
  return (
    <section className="page">
      <header className="page-head">
        <div>
          <h1>{title}</h1>
          {subtitle ? <p className="page-sub">{subtitle}</p> : null}
        </div>
        {actions ? <div className="page-actions">{actions}</div> : null}
      </header>
      {children}
    </section>
  );
}

export function Card({ title, right, children, className }: { title?: ReactNode; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <div className={`card ${className ?? ''}`}>
      {title || right ? (
        <div className="card-head">
          <h2>{title}</h2>
          {right ? <div className="card-right">{right}</div> : null}
        </div>
      ) : null}
      <div className="card-body">{children}</div>
    </div>
  );
}

export type Tone = 'ok' | 'info' | 'caution' | 'fail' | 'neutral' | 'copper';

/** Badges always carry text; colour is secondary. Caution/failure get a glyph too. */
export function Badge({ tone = 'neutral', children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  const glyph = tone === 'fail' ? '✕ ' : tone === 'caution' ? '▲ ' : tone === 'ok' ? '✓ ' : '';
  return (
    <span className={`badge badge-${tone}`} title={title}>
      {glyph}
      {children}
    </span>
  );
}

export function Notice({ tone = 'info', title, children }: { tone?: 'info' | 'caution' | 'fail' | 'security'; title?: ReactNode; children: ReactNode }) {
  const label = tone === 'caution' ? 'CAUTION' : tone === 'fail' ? 'FAILURE' : tone === 'security' ? 'SECURITY' : 'NOTE';
  return (
    <div className={`notice notice-${tone}`} role={tone === 'fail' ? 'alert' : 'note'}>
      <span className="notice-label">{label}</span>
      <div>
        {title ? <strong className="notice-title">{title}</strong> : null}
        <div>{children}</div>
      </div>
    </div>
  );
}

export function KV({ rows }: { rows: [ReactNode, ReactNode][] }) {
  return (
    <dl className="kv">
      {rows.map(([k, v], i) => (
        <div key={i} className="kv-row">
          <dt>{k}</dt>
          <dd>{v === null || v === undefined || v === '' ? DASH : v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Mono({ children, title }: { children: ReactNode; title?: string }) {
  return (
    <code className="mono" title={title}>
      {children}
    </code>
  );
}

/** Full value available on hover and via copy; shown shortened. */
export function Hash({ value, n = 10, full }: { value: unknown; n?: number; full?: boolean }) {
  if (typeof value !== 'string' || !value) return <span className="dim">{DASH}</span>;
  return (
    <code className="mono hash" title={value}>
      {full ? value : shortHash(value, n)}
    </code>
  );
}

export function Amount({ value, decimals, unit }: { value: unknown; decimals: number | undefined; unit?: string }) {
  const s = formatAmount(value, decimals);
  if (s === DASH) return <span className="dim">{DASH}</span>;
  return (
    <span className="amount" title={typeof value === 'string' ? `${value} base units` : undefined}>
      {s}
      {unit ? <span className="unit"> {unit}</span> : null}
    </span>
  );
}

export function Link({ to, children }: { to: [string, ...(string | number)[]]; children: ReactNode }) {
  return <a href={href(...to)}>{children}</a>;
}

export function Loading({ what }: { what?: string }) {
  return <div className="loading">Loading{what ? ` ${what}` : ''}…</div>;
}

export function ErrorBox<T>({ result, what }: { result: ApiResult<T> | null; what: string }) {
  if (!result || result.ok) return null;
  return (
    <Notice tone="fail" title={`Could not load ${what}`}>
      <Mono>{result.error.code}</Mono> {result.error.message}
      {result.unreachable ? ' — the node (or console server) did not respond.' : ''}
    </Notice>
  );
}

export function Age({ ms, now }: { ms: number | null | undefined; now: number }) {
  if (typeof ms !== 'number') return <span className="dim">{DASH}</span>;
  return <span>{formatDuration(ago(now, ms))} ago</span>;
}

/** Fetch status line + stale label for a polled view. */
export function Freshness({ lastOkAt, now, staleAfter = 10000, failing }: { lastOkAt: number | null; now: number; staleAfter?: number; failing?: boolean }) {
  if (lastOkAt === null) return failing ? <Badge tone="fail">NO DATA</Badge> : <span className="dim">waiting…</span>;
  const age = ago(now, lastOkAt);
  if (age > staleAfter) return <Badge tone="caution">STALE · {formatDuration(age)} old</Badge>;
  return <span className="dim small">updated {formatDuration(age)} ago</span>;
}

export function Table({ head, rows, empty }: { head: ReactNode[]; rows: ReactNode[][]; empty?: string }) {
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            {head.map((h, i) => (
              <th key={i}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={head.length} className="dim center">
                {empty ?? 'Nothing to show.'}
              </td>
            </tr>
          ) : (
            rows.map((r, i) => (
              <tr key={i}>
                {r.map((c, j) => (
                  <td key={j}>{c}</td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export function Json({ value }: { value: unknown }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="json">
      <button type="button" className="btn-link" onClick={() => setOpen(!open)}>
        {open ? 'Hide raw JSON' : 'Show raw JSON'}
      </button>
      {open ? <pre>{JSON.stringify(value, null, 2)}</pre> : null}
    </div>
  );
}

/** Horizontal bar 0..1 in cyan; optional marker line (e.g. quorum). */
export function Bar({ value, marker, label, width = 160 }: { value: number | null; marker?: number; label?: string; width?: number }) {
  const v = value === null ? 0 : Math.max(0, Math.min(1, value));
  const h = 10;
  return (
    <svg className="bar" width={width} height={h + 4} viewBox={`0 0 ${width} ${h + 4}`} role="img" aria-label={label ?? `${Math.round(v * 100)}%`}>
      <title>{label ?? `${(v * 100).toFixed(1)}%`}</title>
      <rect x={0} y={2} width={width} height={h} rx={4} className="bar-track" />
      {value !== null && v > 0 ? <rect x={0} y={2} width={Math.max(4, v * width)} height={h} rx={4} className="bar-fill" /> : null}
      {marker !== undefined ? <line x1={marker * width} x2={marker * width} y1={0} y2={h + 4} className="bar-marker" /> : null}
    </svg>
  );
}

/** Single-series sparkline with optional reference line (e.g. target block time). */
export function Sparkline({ values, reference, width = 360, height = 64, unit = '' }: { values: number[]; reference?: number; width?: number; height?: number; unit?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const vals = values.filter((v) => typeof v === 'number' && Number.isFinite(v));
  if (vals.length < 2) return <span className="dim">{DASH} (not enough samples)</span>;
  const max = Math.max(...vals, reference ?? 0) * 1.1 || 1;
  const pad = 4;
  const xs = (i: number) => pad + (i * (width - 2 * pad)) / (vals.length - 1);
  const ys = (v: number) => height - pad - (v / max) * (height - 2 * pad);
  const d = vals.map((v, i) => `${i ? 'L' : 'M'}${xs(i).toFixed(1)},${ys(v).toFixed(1)}`).join(' ');
  return (
    <div className="spark-wrap">
      <svg
        className="spark"
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={`sparkline of ${vals.length} samples`}
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect();
          const i = Math.round(((e.clientX - r.left - pad) / (r.width - 2 * pad)) * (vals.length - 1));
          setHover(Math.max(0, Math.min(vals.length - 1, i)));
        }}
      >
        <line x1={0} x2={width} y1={height - pad} y2={height - pad} className="axis" />
        {reference !== undefined ? <line x1={0} x2={width} y1={ys(reference)} y2={ys(reference)} className="ref" /> : null}
        <path d={d} className="spark-line" />
        {hover !== null ? (
          <>
            <line x1={xs(hover)} x2={xs(hover)} y1={0} y2={height} className="crosshair" />
            <circle cx={xs(hover)} cy={ys(vals[hover])} r={4} className="spark-dot" />
          </>
        ) : null}
      </svg>
      <div className="spark-legend small">
        {hover !== null ? (
          <span>
            sample {hover + 1}/{vals.length}: <strong>{vals[hover]}{unit}</strong>
          </span>
        ) : (
          <span>
            min {Math.min(...vals)}
            {unit} · max {Math.max(...vals)}
            {unit} · last {vals[vals.length - 1]}
            {unit}
          </span>
        )}
        {reference !== undefined ? <span className="ref-key"> — dashed line: target {reference}{unit}</span> : null}
      </div>
    </div>
  );
}

export function IssuerTag() {
  return (
    <span className="tag-issuer" title="Supplied by the token issuer at creation. Not verified by the protocol.">
      issuer-supplied
    </span>
  );
}

export function OnChainTag() {
  return (
    <span className="tag-onchain" title="Enforced by the ledger state machine.">
      on-chain
    </span>
  );
}
