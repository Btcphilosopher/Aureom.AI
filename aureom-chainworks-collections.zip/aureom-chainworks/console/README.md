# AUREOM CHAINWORKS — management console

A read-only operator console for an Aureom development network (PoW, PoS or PoA).
Vite + React 18 + TypeScript. No router library, no UI kit, no chart library.

## Build

```sh
npm install
npm run build        # = tsc --noEmit (strict) && vite build  → dist/
npm run typecheck    # tsc --noEmit only
```

`dist/` uses relative asset paths (`base: './'`), so the console server can serve it
from any path prefix. The built `index.html` carries a strict Content-Security-Policy
meta tag (`default-src 'self'`, `connect-src 'self'`, no inline scripts). Headers the
meta tag cannot carry (e.g. `frame-ancestors`, `X-Content-Type-Options`) should be sent
by the console server.

## How it is served

`chainworks console` serves `dist/` and a small same-origin API. The console only
uses relative URLs and only talks to these endpoints (see `../docs/API.md`):

| endpoint | use |
|---|---|
| `GET /api/manifest` | network identity + node list (`nodes[].proxy`) |
| `GET /api/deployment` | export file list with SHA-256 checksums |
| `GET /api/recovery` | snapshots / backups found in the network directory |
| `GET /api/keys` | public key inventory (role, label, address, pubkey) |
| `GET /proxy/<node>/v1/...` | read-only passthrough to a node's public API |
| `POST /proxy/<node>/v1/transactions` | passthrough of an **already signed** hex transaction |

Every manifest node is polled every 3 s (`/v1/health`, `/v1/network`). A node is shown
as UNREACHABLE (proxy 502/504, timeout, network error), REACHABLE — UNHEALTHY (status
not `ok`, critical alert, or an API error), WRONG CHAIN (its `chain_id` /
`genesis_hash` differs from the manifest, regardless of health) or HEALTHY. An
observation older than 10 s is labelled STALE with its age. The header's *query node*
selector picks the node used by the explorer pages (default: first reachable node on
the manifest chain; the choice is remembered in `localStorage`).

During `npm run dev`, Vite proxies `/api` and `/proxy` to `http://127.0.0.1:8787`.

## Security posture

* **Read-only.** Every call is a GET, except the signed-transaction passthrough.
* **No signing, no keys.** The console never asks for private keys, keystore
  passphrases or seed phrases, and has no input for them. Transactions are signed in
  the `chainworks` CLI wallet; the console only forwards the hex bytes
  (`{"tx":"<hex>"}`) after checking they are even-length hex. Acceptance by a mempool
  is shown as *pending*, never as included.
* **No admin API.** The console never calls or proxies `/admin/v1` (peer actions,
  snapshots, mining, shutdown). Recovery procedures are shown as CLI text only.
* **No editing of consensus-critical settings.** Profile, monetary/fee policy and
  limits are displayed read-only; they change only via on-chain governance (PoS/PoA)
  or a new network (PoW).
* **Approvals are on-chain.** Treasury and governance views display proposals; clicks
  in the console are never approvals.
* **Issuer-supplied data is labelled.** Token symbols, names and metadata URIs are
  marked *issuer-supplied*; duplicate symbols are flagged; metadata URIs are never
  fetched. Amounts are formatted from base-unit strings with `BigInt` (no floats).
* The console shows a permanent "Development network — not production-secure" banner.

## Collections section

Eight pages under **Collections** (`src/pages/nft/`): Collections (dashboards, roles,
administrative powers, creation wizard preview), Assets (gallery/table, token detail with
chain-authoritative owner next to the index cache, metadata, revisions, storage health,
provenance, JSON export), Minting, Transfers, Media, Permissions, Listings, Activity. They
read `/api/nft/*` and `/media/<sha256>` from `chainworks console`. The wizard only
previews (`POST /api/nft/wizard-preview`); signing is done with the CLI wallet. Screenshots
taken against a live demonstration network are in `../results/collections/console/`. The
mock server does not synthesise collections data; against it these pages show the
"Collections data unavailable" notice.

## Mock server (development only)

`mock/server.mjs` (no dependencies) serves `dist/` plus synthetic responses for every
endpoint above, for one PoW network with three nodes:

* `node0` healthy miner,
* `node1` healthy but on a different genesis hash (WRONG CHAIN), no peers,
* `node2` answers for the first `NODE2_UP_MS` ms (default 6000), then the proxy returns
  502 → STALE, then UNREACHABLE.

```sh
npm run build
node mock/server.mjs                     # http://127.0.0.1:8787
MOCK_PROFILE=pos node mock/server.mjs    # BFT-shaped variant (also: poa)
```

`mock/screenshots.cjs` drives the mock with Playwright Chromium (resolved from the
environment, not a project dependency), runs text checks on every page, reports
console errors and writes `screenshots/*.png`:

```sh
node mock/screenshots.cjs        # PoW, writes screenshots
node mock/screenshots.cjs pos    # PoS render checks only
```

The mock's shapes for `/v1/mempool`, `/v1/multisigs/{address}`, `/v1/proposals`,
`/api/deployment`, `/api/recovery` and `/api/keys` are assumptions where `docs/API.md`
gives no exact JSON; the console reads them defensively (missing fields render "—").

## Layout

```
src/lib/api.ts        fetch helpers, response types (all fields optional)
src/lib/format.ts     BigInt amount formatting, hashes, durations
src/lib/hooks.ts      polling hook, clock, tiny hash router
src/lib/state.tsx     manifest, per-node observations, chain check, query node
src/components/ui.tsx badges, notices, tables, cyan SVG bars/sparklines
src/pages/*.tsx       one file per page
mock/                 development mock + browser check script
```
