import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';

// Strict CSP for the built console only (the dev server injects an inline
// React-refresh preamble that a strict policy would block).
const CSP =
  "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; " +
  "script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; " +
  "form-action 'none'";

function cspMeta(): Plugin {
  return {
    name: 'aureom-csp-meta',
    apply: 'build',
    transformIndexHtml(html) {
      return html.replace(
        '<meta charset="UTF-8" />',
        `<meta charset="UTF-8" />\n    <meta http-equiv="Content-Security-Policy" content="${CSP}" />`,
      );
    },
  };
}

// Relative asset paths so the console server can mount dist/ under any prefix.
// During `npm run dev`, /api and /proxy are forwarded to a running console server
// (or the mock: `node mock/server.mjs`, default port 8787).
export default defineConfig({
  base: './',
  plugins: [react(), cspMeta()],
  build: { outDir: 'dist', sourcemap: false },
  server: {
    proxy: {
      '/api': 'http://127.0.0.1:8787',
      '/proxy': 'http://127.0.0.1:8787',
    },
  },
});
