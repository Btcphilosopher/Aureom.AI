#!/usr/bin/env bash
# Build aureom-chainworks:0.1.0 from locally built release binaries.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"; root="$(dirname "$here")"
mkdir -p "$here/bin"
cp "$root/rust/target/release/aureom-node" "$root/rust/target/release/aureom-cli" "$here/bin/"
if [ -x "$root/tools/bin/cometbft" ]; then cp "$root/tools/bin/cometbft" "$here/bin/"; else cp "$(command -v cometbft)" "$here/bin/"; fi
docker build ${BASE:+--build-arg BASE=$BASE} -t aureom-chainworks:0.1.0 "$here"
