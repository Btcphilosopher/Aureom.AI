# Container deployment

* `build-image.sh` — builds `aureom-chainworks:0.1.0` from the locally built release
  binaries (`rust/target/release`) and CometBFT (`tools/bin/cometbft`, built by
  `tools/build-cometbft.sh`). Set `BASE=<registry>/ubuntu:24.04` to use a mirror.
* `Dockerfile.source` — multi-stage source build (Rust + Go); provided for reproducible
  builds elsewhere; **not exercised** in the delivery environment.
* Compose files are generated per network: `chainworks network compose <dir>`.
  - `target=docker` (`chainworks init --target docker`): bridge network, container
    hostnames in configs, APIs published on the host's `127.0.0.1` only. BFT nodes are
    two containers (application + CometBFT) sharing one network namespace.
  - `target=local`: host networking (Linux).
* `docker-compose.explorer.yml` — optional PostgreSQL for the explorer index (derived
  data; drop and rebuild at will). Provide `secrets/explorer-db.password`.

Secrets are never baked into images: the network directory (with `secrets/`, mode 0700)
is mounted at runtime. Each validator key must be active in exactly one container.
