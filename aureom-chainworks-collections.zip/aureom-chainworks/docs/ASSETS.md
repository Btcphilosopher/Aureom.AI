# Native coin, tokens, distribution, vesting and treasury

## Three kinds of asset — kept distinct
| kind | what it is | where defined | v1 status |
|---|---|---|---|
| **Native coin** | the chain's built-in asset: fees, PoW rewards, PoS stake and rewards | genesis `native_asset` + `monetary_policy` | implemented |
| **Token** | an asset issued through the native token module (`TokenCreate`) | on-chain transaction; id = `H("AUREOM/TOKEN/v1", creator ‖ nonce)[0..20]` | implemented |
| **Wrapped / bridged asset** | a representation of an asset on another system | requires a separately specified bridge with explicit trust assumptions | **not implemented** |

Creating any of these gives it no monetary value, reserve backing, exchange acceptance or
legal status. Tickers and symbols are display labels, not identifiers.

## Native-coin creation (launch wizard → network.json → genesis)
Name, ticker, decimals (≤ 18), genesis supply and allocation recipients (validated:
bech32m with the network prefix, no duplicates, integer base units, u128 overflow,
`≤ max_supply`), maximum supply, issuance policy, block/staking rewards, fee
denomination (always the native coin), fee burn (`burn_bps`) and recipient
(proposer|treasury), treasury allocation (multisig), vesting schedules (block heights).
`chainworks genesis preview` shows a supply projection under stated assumptions.
After genesis these settings are consensus-critical: editing network.json or a console
field does not change a running network (nodes pin the genesis hash).

## Monetary policies
1. **fixed** — all supply created at genesis; no minting authority; rewards 0.
2. **scheduled** — `reward(h) = initial_block_reward >> (h / halving_interval_blocks)`,
   capped by `max_supply`. PoW: to the miner (immature). PoS/PoA: to signers of the
   previous block pro rata by power (floor), remainder to the proposer.
3. **authority** — `NativeMint` by `mint_authority` (default: the genesis treasury
   multisig), at most `max_mint_per_window` per `window_blocks`, never above `max_supply`
   (an explicit cap is mandatory).

Consensus choice and monetary policy are independent (e.g. PoS with fixed supply, PoA
with scheduled issuance are valid).

Definitions (PROTOCOL.md 6.4): total = genesis + minted − burned; locked = unvested
vesting; immature = unmatured PoW payouts; staked = bonded + unbonding; escrow =
open claim distributions; circulating = total − locked − immature − staked − escrow −
genesis-treasury balances. Reward rounding is floor; remainders are assigned
deterministically. Burns: holder `NativeBurn`/`TokenBurn`, the fee burn share, slashing.

## Token module
Create (symbol, name, decimals, initial supply and recipient, optional cap, optional
mint authority, optional admin, opt-in `pausable` / `freezable`, issuer metadata URI),
transfer, holder burn, capped mint by the mint authority, renounce/transfer mint
authority, pause/freeze **only** if opted in at creation. Default is minimal privilege:
no authority, no admin → fixed supply nobody can pause, freeze or mint. Permissions are
enforced by the state machine. There is no clawback or metadata change. This module is
**not** ERC-20 compatible (no EVM, no ERC-20 interface).

`chainworks asset create-token` prints the permissions and asks for confirmation;
`aureom-cli tx review` warns about admin powers and uncapped mint authorities.

## Distribution and vesting
* Genesis allocations (with optional vesting).
* Reviewed batch distributions — `chainworks distribute plan` produces a preview
  (recipients, amounts, fees, balances before/after) and rejects invalid addresses,
  duplicates (unless `--merge-duplicates`) and insufficient funds; `run --approve
  <plan_id>` signs every payment once with a fixed nonce into a journal **before**
  submission; `resume` resubmits identical bytes, which cannot pay twice.
* Claim-based distributions — Merkle commitment of (index, address, amount); claimant
  submits a proof; each index claimable once; creator reclaims after the deadline.
* Linear and cliff vesting — `VestedTransfer` or genesis vesting; locked amount derived
  from block height (calendar dates are estimates).
* Treasury grants — treasury multisig proposals whose inner action is `Transfer` or
  `VestedTransfer`.

## Treasury
Genesis treasury = on-chain multisig (signers + threshold). Budgets and payment records
(`chainworks treasury budget|propose|approve|report`) are off-chain guard rails;
proposal, approval, signing and settlement are separate steps and every approval is a
separately signed transaction. Treasury keys live in signers' own keystores, never in
the web application.

## Asset-launch workflow
Network: choose network → define coin → review issuance (`genesis preview`) → allocate
supply → validate genesis → launch nodes → verify balances (`/v1/supply`, reconciled) →
publish network information (`asset info-package`, `export`).
Token: define → review permissions → simulate (`tx review`) → sign → submit → verify
(`/v1/tokens/{id}`) → distribute.

The asset information package (`asset-information.json`, `ASSET-INFORMATION.md`,
checksums) contains chain id, genesis hash, coin and token identifiers, supply policy,
administrative powers, allocation table, vesting rules, wallet/RPC configuration,
source-tree hash and known limitations — no private keys.

## Wallet and explorer
Wallet (CLI) shows native total/available/locked/immature/bonded/unbonding, vesting
schedules, token balances with token ids and issuer permissions, fees and finality or
confirmations. The explorer API/console show issuance, burns, transfers, treasury
movements and administrative changes from on-chain receipts, and label issuer-supplied
descriptions separately from verified on-chain facts.
