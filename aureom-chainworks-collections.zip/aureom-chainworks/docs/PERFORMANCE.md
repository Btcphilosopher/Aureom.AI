# Performance measurements

Measured in the delivery environment (Linux x86_64, 4 vCPU, release builds). Raw data: `results/performance/`. These are development-network figures on one machine, not capacity claims.

## State machine (`aureom-cli bench`, single thread)

| txs | state entries | sig verify tx/s | block execution tx/s (incl. sig verify) | block execution ms | state-root recompute ms |
|---|---|---|---|---|---|
| 2000 | 1025 | 15561 | 12643 | 158.19 | 0.18 |
| 2000 | 100025 | 18485 | 16325 | 122.51 | 18.27 |
| 5000 | 10025 | 17899 | 17217 | 290.41 | 1.68 |

The state root is recomputed over all leaves each block (O(n)): ~18 ms at 100k entries. Execution is dominated by Ed25519 verification.

## Live networks (`chainworks.perf`, 6 senders × 50 transfers, pre-signed)

| profile | nodes | submitted | included | refused at submission | seconds until all accepted txs included | blocks | tx/s |
|---|---|---|---|---|---|---|---|
| pos | 4 | 300 | 300 | 0 | 2.48 | 2 | 121.2 |
| pow | 3 | 300 | 198 | 102 | 1.61 | 5 | 123.1 |

Notes:
* PoW: the 102 refused transactions are exactly 17 per sender — the mempool policy accepts at most 32 nonces ahead of the account nonce (node policy, documented). Accepted ones were included within ~1.6 s.
* PoS: all 300 finalised within 2 blocks (~2.5 s); throughput here is bounded by the 1 s commit timeout and HTTP submission, not execution.
* An earlier attempt with 100 txs per sender hit the 64-pending-per-sender limit; an attempt routing one sender's consecutive nonces to different BFT nodes saw out-of-order rejections (strict nonce order in CheckTx). Both are documented limitations, not hidden.
* Throughput with tiny sample sizes on one machine says little about real deployments.
