# AUREOM COLLECTIONS — build and test results

Recorded in this delivery's build environment (Linux x86_64, Rust 1.97, Python 3.13, Node 22). Raw logs: `results/collections/logs/`; demonstration evidence: `results/collections/demo/`; console screenshots (live demo network): `results/collections/console/`. Nothing here is estimated.

## Rust (`cargo test --release --workspace`)

* aureom-core: **60 passed, 0 failed** (43 pre-existing + 17 collections-module tests); aureom-node: **6 passed, 0 failed**.
* Collections-module tests (`crates/aureom-core/src/nft_tests.rs`). Every block in these tests also asserts the native, token and NFT reconciliation invariants and that every receipt round-trips through the canonical decoder:

  * `nft_tests::all_actions_roundtrip_and_json`
  * `nft_tests::burning_where_permitted_and_ids_not_reused`
  * `nft_tests::claim_based_drop`
  * `nft_tests::collection_creation_defaults_and_explicit_powers`
  * `nft_tests::deterministic_and_undo_restores_nft_state`
  * `nft_tests::genesis_module_validation`
  * `nft_tests::marketplace_atomic_settlement_and_accounting`
  * `nft_tests::marketplace_revalidates_and_fails_atomically`
  * `nft_tests::marketplace_token_currency`
  * `nft_tests::metadata_freeze_token_and_collection`
  * `nft_tests::metadata_mutable_with_recorded_revisions`
  * `nft_tests::minting_permissions_supply_limit_and_unique_ids`
  * `nft_tests::module_must_be_enabled_in_genesis`
  * `nft_tests::multisig_can_hold_collection_roles`
  * `nft_tests::pause_and_forced_transfer_require_opt_in`
  * `nft_tests::simulation_never_commits_and_checks_everything_but_the_signature`
  * `nft_tests::transfers_approvals_and_operators`

* `cargo clippy --release --workspace`: 8 warnings, all in pre-existing code untouched by this extension (lints added in the newer toolchain, e.g. `is_multiple_of`, manual checked division); 0 in the new module files.

## Python (`pytest`)

* **35 passed, 0 failed** (20 pre-existing + 15 collections tests in `tests/test_nft.py`, using a scripted fake node for reorganisation, finality-violation and unknown-outcome cases):

  * `test_bft_finality_violation_is_not_silently_reindexed`
  * `test_claims_are_reviewed_off_chain`
  * `test_indexer_derives_ownership_and_records_failed_txs`
  * `test_indexer_reorg_reconciles_to_winning_branch`
  * `test_local_store_verifies_and_detects_tampering`
  * `test_media_rejections`
  * `test_metadata_canonical_hash_and_roundtrip`
  * `test_metadata_rules`
  * `test_migrations_are_checksummed`
  * `test_png_validated_from_content_with_dimensions_and_cid`
  * `test_rebuild_from_chain_events_reproduces_index`
  * `test_requests_idempotent_and_unknown_outcome_reconciled`
  * `test_requests_resubmit_identical_bytes_only`
  * `test_sigv4_matches_aws_documented_example`
  * `test_token_gate_requires_signature_and_current_ownership`

* The SigV4 test reproduces AWS's published example signature; the CID test reproduces the known IPFS CIDv1 of the empty file.

## Console

* `npm run build` (strict `tsc --noEmit` + Vite): success (`logs/console-build.log`).
* Playwright visit of all eight Collections pages, a token detail page and the wizard against the live demo network: all rendered, **0 browser console errors**.

## Demonstration (`chainworks demo collections`) — 20/20 steps passed in 111.9 s

Live 3-node proof-of-work development network (real mining, p2p, mempools); `confirmations_recommended = 3` for pacing.

| # | step | result |
|---|---|---|
| 1 | Launch a 3-node PoW development network with the collections module and demo marketplace enabled | PASS |
| 2 | Upload media and metadata: content-type sniffing, checksums, alt text, rights; unsafe/invalid uploads rejected; nothing on chain yet | PASS |
| 3 | Storage monitoring: re-fetch every stored copy, compare SHA-256, detect a tampered copy, record maintainer | PASS |
| 4 | Create the collection: wizard -> administrative powers shown -> simulate -> sign (aureom-cli) -> submit -> confirm -> index | PASS |
| 5 | Mint one token -> verify ownership on chain (authoritative) and in the index; duplicate mint request deduplicated | PASS |
| 6 | Unique identifiers: minting an existing token id fails in simulation and on chain (fee charged, owner unchanged) | PASS |
| 7 | Reviewed batch minting: invalid plans rejected, approval required, interrupted run resumed, re-run mints nothing twice | PASS |
| 8 | Optional claim-based distribution: Merkle drop, eligible claim mints, someone else's proof is refused | PASS |
| 9 | Transfer an asset (collector -> buyer), confirmed and indexed | PASS |
| 10 | Reject an unauthorised transfer (mallory): refused in simulation and on chain; owner unchanged; failure indexed | PASS |
| 11 | Inspect and revoke an approval: single-token approval shown with its scope; collection-wide operator flagged as high risk; revoked approval no longer works | PASS |
| 12 | Update permitted metadata: metadata admin creates revision 1 (history kept); stale revision and token holder are refused | PASS |
| 13 | Freeze metadata: preview shows exact reference, freeze signs that hash; further changes rejected (simulation and chain) | PASS |
| 14 | Fixed-price sale: seller listing, buyer review, atomic settlement (price, royalty, platform fee, network fee kept separate), duplicate and replay rejected | PASS |
| 15 | Settlement revalidates ownership: a listing is invalidated when the seller transfers the token away | PASS |
| 16 | Token-gated access: signed single-use challenge + on-chain ownership; impersonation, replay and non-holders refused | PASS |
| 17 | Authenticity claims need evidence and review (off-chain); a ledger entry is not proof of issuer claims | PASS |
| 18 | PoW reorganisation: an index following the minority branch reconciles to the winning chain (conflicting transfer dropped) | PASS |
| 19 | Rebuild the index from chain events: identical ownership and sales; verified against chain state | PASS |
| 20 | Export provenance (JSON + CSV) and check ledger invariants (native, token and NFT reconciliation) | PASS |

### Selected evidence (verbatim from `collections-results.json`)

* Sale settlement (step 14): price 1234567 base units; balance deltas `{"collector": 1141975, "artist": 61728, "platform": 30864, "buyer": -1237567}`; expected `{"collector": 1141975, "artist": 61728, "platform": 30864, "buyer": -1237567}`; exact = True. Second buyer: `LISTING_INACTIVE`; replay of the signed purchase: `bad_nonce`; same bytes with another chain id: `wrong_chain`; buyer committed to a different price: `STALE`.
* Reorganisation (step 18): node reorg depth 3 at fork height 132; index reorg log `[{"fork_height": 132, "old_tip_height": 134, "blocks_removed": 2, "events_removed": 1}]`; minority transfer now `dropped`; index and chain agree on the winning owner: True; verification of 12 records found 0 mismatches.
* Rebuild (step 19): `{"blocks_added": 139, "events_added": 29, "indexed_height": 139, "events_before_rebuild": 29}`; ownership identical: True; sales identical: True.
* Invariants at the end (step 20): `{"reconciled": true, "tokens_reconciled": true, "nfts_reconciled": true}`; provenance export sha256 `ab311e6504eff235dbae9d48f4dc6a3e437f9638d257be6b25f6181ccbb070af`.

## Not exercised in this delivery

* BFT profiles (PoS/PoA) end to end: CometBFT was not built in this environment. The module is profile-independent state-machine code covered by unit tests; the indexer's BFT finality handling is tested against a fake node.
* A live IPFS node and a live S3-compatible bucket (none available); see COLLECTIONS.md §12.
