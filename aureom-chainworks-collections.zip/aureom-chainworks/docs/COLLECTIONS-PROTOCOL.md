# AUREOM COLLECTIONS — native NFT module, protocol specification

Status: **development specification**, normative for `aureom_core::nft`
(`rust/crates/aureom-core/src/nft.rs`). Extends [PROTOCOL.md](PROTOCOL.md) v1; every rule
there (encoding, signatures, fees, nonces, receipts, state commitment) applies unchanged.

## 1. Implementation choice

The requirement offered two options: a native module in the Chainworks state machine, or
standards-based contracts on an implemented compatible runtime. **Chainworks has no
contract runtime** (no VM; see [EXTENSIONS.md](EXTENSIONS.md)), so the second option does
not exist here. The collections module is therefore a **native state-machine module**:

* Ownership is a key in the consensus state, committed in the state root of every block
  (PoW header `state_root`, BFT `app_hash`). It changes only through the transitions below.
* It is **not** ERC-721 or ERC-1155 compatible: there is no EVM, no ABI, no
  `ownerOf`/`safeTransferFrom` interface, and wallets or marketplaces built for those
  standards cannot interact with it. Concepts are similar (owner, single-token approval,
  operator approval) but the encoding and semantics are this document's.
* Application databases (`python/chainworks/nft`) index and cache state; they never assign
  ownership (see COLLECTIONS.md §Index).

## 2. Enabling the module (genesis)

```json
"modules": { "collections": {
    "activation_height": 0,              // u64, default 0
    "marketplace": true,                 // enables tags 72–74, default false
    "marketplace_fee_bps": 250,          // 0..=1000, default 0
    "marketplace_fee_recipient": "aurd1…" // required iff fee_bps > 0
} }
```

* The field is optional. A genesis document without it has exactly the genesis hash it had
  before this module existed (the field is absent, not null), so existing networks and
  test vectors are unaffected — and those networks reject every tag 60–79 as
  `unsupported_action`.
* Software without module support rejects a genesis containing `modules`
  (`deny_unknown_fields`), so incompatible nodes fail at start-up rather than diverge.
* Before `activation_height`, NFT transactions are inadmissible (`unsupported_action`).
* Enabling the module on an already running network is a consensus change: a new genesis
  (new network) or a coordinated upgrade. This delivery does not add a live-activation
  path; `PROTOCOL_VERSION` stays 1 because it is bound into every signature.

## 3. Identifiers

| object | identifier | display |
|---|---|---|
| collection | `H("AUREOM/COLLECTION/v1", creator ‖ u64(nonce))[0..20]` | bech32m, HRP `<address_hrp>col` |
| token | `u64` chosen by the minter, unique per collection, **never reused** (burned records stay) | decimal |
| listing | `H("AUREOM/LISTING/v1", seller ‖ u64(nonce))` | hex |
| drop | `H("AUREOM/NFT-DROP/v1", creator ‖ u64(nonce))` | hex |
| slug | `[a-z][a-z0-9-]{0,31}`, unique per network | display/lookup only |

Global reference (unambiguous across networks):
`aureom:<chain_id>:<genesis_hash[0..8] hex>/<collection bech32>/<token_id>`.
Names and slugs are labels; the collection id identifies the collection.

## 4. Actions (tags 60–76; 77–79 reserved)

`MetadataRef = { uri: string(128), hash: [32] }` — `hash` is SHA-256 of the exact
metadata document bytes; must be non-zero. URIs are printable ASCII.

```
60 CollectionCreate { slug: string(32), name: string(64), collection_metadata: MetadataRef,
                      max_supply: Option<u64>, mint_authority: Option<[20]>,
                      metadata_policy: u8 (1 mutable | 2 freezable | 3 immutable),
                      metadata_admin: Option<[20]>, admin: Option<[20]>,
                      flags: u8 (bit0 pausable, bit1 forced_transfer, bit2 owner_burn),
                      transfer_policy: u8 (0 transferable | 1 non-transferable),
                      royalty: Option<{ recipient: [20], bps: u16 }>,
                      rights_holder: string(64), rights: MetadataRef }
61 Mint             { collection: [20], item: MintItem }
62 MintBatch        { collection: [20], items: Vec<MintItem>(32) }    // all-or-nothing
   MintItem = { token_id: u64, to: [20], metadata: MetadataRef }
63 Transfer         { collection, token_id: u64, to: [20] }
64 Approve          { collection, token_id, approved: Option<[20]>, expiry_height: u64 }   // None = revoke
65 SetOperator      { collection, operator: [20], approved: bool, expiry_height: u64 }
66 Burn             { collection, token_id }
67 UpdateMetadata   { collection, token_id, metadata: MetadataRef, expected_revision: u32 }
68 FreezeMetadata   { collection, scope: 0x01 u64 token_id | 0x02 (collection), expected: [32] }
69 SetPaused        { collection, paused: bool }
70 SetRole          { collection, role: u8 (1 admin | 2 mint_authority | 3 metadata_admin | 4 royalty_recipient), new: Option<[20]> }
71 ForceTransfer    { collection, token_id, to: [20], reason_hash: [32] }
72 ListingCreate    { collection, token_id, price: u128, currency: AssetId, expiry_height: u64 }
73 ListingCancel    { listing_id: [32] }
74 ListingBuy       { listing_id: [32], price: u128, currency: AssetId }
75 DropCreate       { collection, merkle_root: [32], claim_deadline_height: u64, max_claims: u32 }
76 DropClaim        { drop_id: [32], index: u32, token_id: u64, metadata: MetadataRef, proof: Vec<ProofStep>(32) }
```

`MultisigPropose.inner` may additionally carry tags 61, 62, 67, 68, 69, 70, 71, 75, so a
threshold multisig can hold collection roles. Transfers, approvals and purchases are not
allowed as inner actions (holders sign their own).

## 5. State keys

| key | value |
|---|---|
| `0x40 ‖ collection` | `Collection { spec, creator, created_height, minted: u64, burned: u64, paused, frozen_all, frozen_height, authority_changes: u32 }` |
| `0x41 ‖ slug` | collection id |
| `0x42 ‖ collection ‖ u64 token` | `NftRecord { owner, approved: Option, approval_expiry, metadata: MetadataRef, revision: u32, frozen, minted_height, minted_by, burned, transfers, last_change_height }` |
| `0x43 ‖ collection ‖ u64 token ‖ u32 rev` | `MetadataRevision { metadata, height, by }` (rev 0 = mint) |
| `0x44 ‖ collection ‖ owner ‖ operator` | `u64 expiry_height` (0 = none) |
| `0x46 ‖ collection ‖ u32 seq` | `AuthorityChange { role, old, new, height, by }` |
| `0x47 ‖ listing_id` | `Listing { seller, collection, token_id, price, currency, expiry_height, created_height, status, buyer, closed_height, royalty_paid, royalty_recipient, platform_fee_paid, seller_proceeds }` |
| `0x48 ‖ collection ‖ u64 token` | active listing id |
| `0x49 ‖ drop_id` | `Drop { collection, creator, merkle_root, claim_deadline_height, max_claims, claims }` |
| `0x4A ‖ drop_id ‖ u32 index` | `0x01` (claimed) |

Listing status: 0 active, 1 sold, 2 cancelled, 3 invalidated, 4 expired (superseded).

## 6. Semantics

New error codes: `16 STALE` (an expected value in the transaction no longer matches),
`17 METADATA_FROZEN`, `18 NON_TRANSFERABLE`, `19 LISTING_INACTIVE`. As everywhere in v1, a
failed action reverts all of its effects; fee and nonce are still consumed.

**Create.** Minimal privileges by default. `flags & (pausable|forced_transfer) ≠ 0` ⇔
`admin` is set. Policies 1–2 require a `metadata_admin`; policy 3 forbids one.
`royalty.bps ∈ 1..=2500`. `max_supply ≠ 0`. Slug must be unused. The creator has no power
that is not also given to it as a role.

**Mint / MintBatch / DropClaim.** Sender = `mint_authority` (DropClaim: authorised by the
mint authority's DropCreate commitment; claimant = sender). Not paused. Token id not
previously used in the collection (including burned ids) → else `ALREADY_EXISTS`.
`minted + 1 ≤ max_supply` per token → else `SUPPLY_CAP` (burns do not free capacity).
Policy 3, or a collection already frozen, mints the token with `frozen = true`.
Drop leaf: `H("AUREOM/NFT-CLAIM/v1", u32 index ‖ claimant ‖ u64 token_id ‖ MetadataRef)`.

**Transfer.** Collection not paused and transferable; token not burned; sender is the
owner, the token's unexpired approved address, or an unexpired operator of the owner in
this collection. `to ≠ owner`. Every ownership change (transfer, forced transfer, sale)
clears the token approval and invalidates an active listing of the token.

**Approve / SetOperator.** Approve: owner only, narrow (one token), optional expiry.
SetOperator: scoped to one collection, covers all of the owner's tokens in it (including
later ones), optional expiry; revoking a non-existent grant → `NOT_FOUND`.

**Burn.** Only with `owner_burn`, by the owner, not paused. The record stays (`burned`).

**Metadata.** UpdateMetadata: sender = `metadata_admin`, policy 1 or 2, token and
collection not frozen, `expected_revision == revision` (else `STALE`), new ref differs.
Each revision is stored under `0x43`. FreezeMetadata (policy 2 only): token scope requires
`expected == current metadata hash`; collection scope requires
`expected == metadata_root(collection)` where
`metadata_root = merkle_root([H("AUREOM/NFT-META/v1", u64 id ‖ hash ‖ u32 revision) for live tokens by id])`.
A collection freeze is permanent, covers future mints and removes the metadata admin
(logged). Policy 1 has no freeze; policy 3 never changes.

**Pause / ForceTransfer.** Only if the flag was set at creation and sender = `admin`.
ForceTransfer requires a non-zero `reason_hash` (commitment to an off-chain justification)
and is emitted as `nft_transfer` with `authority = forced_by_admin`.

**SetRole.** Only the current holder of a role may reassign or renounce it. Renouncing is
permanent. Every change is appended to the authority log.

**Listings.** ListingCreate: marketplace enabled; seller = owner; transferable, not paused;
`price > 0`; `h < expiry ≤ h + 1 000 000`; one active listing per token (an expired active
listing is superseded with status `expired`). The listing itself is the seller's
authorisation to settle at exactly that price; no operator approval is involved.
ListingCancel: seller only, active only.

**ListingBuy (atomic settlement).** In one state transition, after revalidating
everything: listing active and unexpired (`LISTING_INACTIVE`); `price` and `currency`
equal the listing (`STALE` — the buyer signs what they reviewed); buyer ≠ seller;
collection not paused, transferable; the token exists, is not burned and is still owned
by the seller (`LISTING_INACTIVE`). Then:

```
royalty      = floor(price × royalty_bps / 10000)        (0 if no royalty)
platform_fee = floor(price × fee_bps / 10000)            (0 if no fee recipient)
seller       = price − royalty − platform_fee            (remainder to the seller)
```

The buyer is debited `price` (native: available balance; token: unfrozen balance of an
unpaused token), recipients are credited, the listing is closed as sold with the
breakdown, the NFT moves to the buyer. Any failure reverts all of it. The network fee is
the ordinary transaction fee, paid by the buyer, separate from `price`.

**Replay.** Signatures bind `chain_id` (PROTOCOL.md 5.2); each `(sender, nonce)` is
consumed once; a sold listing cannot be bought again. Listing ids derive from
`(seller, nonce)` and are only meaningful on the network that created them.

## 7. Events (receipts)

`nft_collection_create`, `nft_mint`, `nft_mint_batch`, `nft_transfer` (attr `authority`:
`owner | token_approval | operator | forced_by_admin | listing_sale`), `nft_approval`
(`scope: token | operator_all_tokens_in_collection`), `nft_burn`, `nft_metadata`
(`op: update | freeze_token | freeze_collection`), `nft_admin`, `nft_authority`,
`nft_listing` (`op: create | cancel | invalidated | expired_superseded`), `nft_sale`
(full settlement breakdown and `chain_id`), `nft_drop`. All attribute values fit the
receipt limits (≤ 128 bytes; token metadata URIs are capped at 128 for this reason).
Events are sufficient to rebuild ownership, approvals, listings and sales.

## 8. Invariants (checked after every block in tests; `/v1/supply → nfts_reconciled`)

* per collection: `minted ≤ max_supply`; token records = `minted`; live records = `minted − burned`;
* every active-listing pointer names an active listing whose seller currently owns the token;
* native and token supply invariants of PROTOCOL.md 6.4 hold across sales.

## 9. Node API (read-only, authoritative state)

`/v1/nft/collections`, `/v1/nft/collections/{id|slug}`, `/v1/nft/collections/{id}/tokens?owner=`,
`/v1/nft/collections/{id}/authority-log`, `/v1/nft/tokens/{collection}/{token}`,
`/v1/nft/owners/{address}`, `/v1/nft/listings?status=`, `/v1/nft/listings/{id}`,
`/v1/nft/drops/{id}`, and `POST /v1/simulate {"unsigned_tx": hex}` — executes an unsigned
transaction against the node's current state on a throw-away overlay (all checks except
the signature), never commits or broadcasts. See [API.md](API.md).
