# Threat model (development networks)

## Assets to protect
Ledger integrity (balances, supply, token permissions), consensus safety, validator and
account keys, treasury funds, the genesis document and its hash, node availability,
operator credentials (admin tokens), audit trail (blocks, receipts).

## Trust boundaries
1. **Peers** (untrusted): every message is length-bounded before allocation, decoded
   strictly, rate limited, scored; invalid blocks/transactions penalise and ban.
2. **API clients** (untrusted): public API is read-only except submission of signed
   transactions, which pass the same validity rules as peer transactions.
3. **Operators** (trusted for availability, not for ledger content): the admin API is
   authenticated, loopback-bound and cannot sign, execute shell commands, write the
   database, edit balances or change validators.
4. **Governance participants** (validators/authorities): consensus-critical changes
   only via signed on-chain proposals/approvals or a new genesis.
5. **Imported data** (snapshots, backups, genesis files, migration inputs): untrusted
   until verified (digest + state root vs a locally validated block or an out-of-band
   checkpoint; backup checksums; genesis hash pinning).
6. **Console users**: read-only views; never asked for keys or seed phrases.

## Threats and mitigations

| threat | mitigation | residual risk |
|---|---|---|
| Transaction forgery | Ed25519 strict verification over a domain-separated message binding chain id, protocol version and action type | key theft |
| Cross-chain / cross-type replay | chain id + type bound in signature; different chains → invalid | — |
| Replay / double spend | per-account nonce consumed exactly once by deterministic execution | — |
| Arithmetic overflow | checked arithmetic, 256-bit mul-div; failure not wrap | — |
| Non-determinism / consensus split | no clocks/randomness/config in execution; cross-implementation vectors; replay audits; CometBFT app-hash check | untested platforms |
| Malformed / oversized messages | pre-allocation length checks, strict decoding, frame limits, ban scoring | resource use below limits |
| Invalid blocks (PoW) | full header/body validation, invalid marking, peer ban | — |
| Majority hash power (PoW) | none beyond documentation | **total on dev networks** |
| ≥ 1/3 Byzantine power (BFT) | none (protocol assumption) | safety lost |
| > 1/3 offline (BFT) | none (protocol assumption) | liveness lost until quorum returns |
| Equivocation | CometBFT double-sign protection; evidence → slashing/removal; orchestrator key lock | operator copying keys manually |
| Long-range attack | trusted recent checkpoint required for joiners; exposed in `/v1/sync` | operators skipping it |
| Unauthorised minting / validator change | permissions in the state machine; no admin key | compromised authority keys |
| Wrong-chain node | genesis hash pinned in config, checked in handshakes and InitChain; console flags WRONG CHAIN | — |
| Unaudited dashboard edits of consensus parameters | console has no edit controls; genesis rebuild refused; profile switch refused | editing files directly creates a different network that nodes refuse |
| Admin API abuse | bearer token (constant-time compare), loopback bind, no dangerous endpoints | token theft on the host |
| Secret leakage | keys outside genesis/exports; export secret scan; no key logging | dev passphrase files |
| Crash / power loss | single ACID transaction per block, state-root check on start, CometBFT handshake replay | disk corruption → restore |
| Corrupted / tampered snapshot or backup | digest + state root + trusted root; checksum manifest | trusted root obtained carelessly |
| Asset spoofing | stable token ids; duplicate-symbol warnings; issuer data labelled | users ignoring ids |
| Double payment in distributions | pre-signed fixed-nonce journal; idempotent resubmission | manual review of consumed nonces |
| Treasury misuse | threshold approvals by distinct signed transactions; budgets as guard rails | collusion of threshold signers |
