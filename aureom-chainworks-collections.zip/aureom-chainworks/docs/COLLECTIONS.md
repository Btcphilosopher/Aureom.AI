# AUREOM COLLECTIONS — NFT issuance and management

A traceable extension of Chainworks for creating collections, issuing unique digital
assets, managing media and metadata, transferring ownership and inspecting provenance on
Chainworks development networks. Development software; not audited; see §12.

| layer | where | what |
|---|---|---|
| ledger module | `rust/crates/aureom-core/src/nft.rs` (+ `nft_tests.rs`) | state transitions, ownership, permissions, metadata policy, listings, atomic settlement — spec in [COLLECTIONS-PROTOCOL.md](COLLECTIONS-PROTOCOL.md) |
| node API | `rust/crates/aureom-node/src/nft_views.rs`, `api.rs` | `/v1/nft/*` read views, `POST /v1/simulate` |
| wallet / signing | `aureom-cli` (`tx prepare/review/sign`, `message sign`, `drop-tree`, `derive`) | keys stay in encrypted keystores; nothing else ever sees them |
| application | `python/chainworks/nft/` | media validation, storage adapters, metadata documents, request lifecycle, indexer, provenance, token gating, claim reviews, console API |
| database | `python/chainworks/nft/migrations/*.sql` (SQLite) | rebuildable chain index (0001) + application data (0002) |
| interface | `console/src/pages/nft/*` | Collections · Assets · Minting · Transfers · Media · Permissions · Listings · Activity |
| CLI | `chainworks nft …`, `chainworks init --collections`, `chainworks demo collections` | |
| devnet script | `tools/collections-devnet.sh` | launch network + DB + console |
| fixtures | `fixtures/collections/` (`tools/make_collection_fixtures.py`) | original artwork, metadata, plans |

## 1. Protocol choice

Native module in the Chainworks state machine — the only implementable option, because
Chainworks has no contract runtime. Ownership is consensus state committed in every block's
state root. **Not ERC-721 / ERC-1155 compatible** (no EVM, no ABI). Details and all rules:
[COLLECTIONS-PROTOCOL.md](COLLECTIONS-PROTOCOL.md).

## 2. Entities and where they live

| entity | authoritative home | application representation |
|---|---|---|
| Collection | chain `0x40` (`Collection`) | `collections_cache` (derived) |
| CollectionPermissions | chain: `admin`, `mint_authority`, `metadata_admin`, flags, transfer policy, royalty recipient; authority log `0x46` | console Permissions, `/v1/nft/collections/{id}` → `administrative_powers` |
| NFT | chain `0x42` (`NftRecord`) | `ownership_cache` (derived, `as_of_height`) |
| MetadataRevision | chain `0x43` (uri + sha256 per revision) | `metadata_documents` (the off-chain bytes) |
| MediaAsset | off chain (bytes) — committed through the metadata hash | `media_assets`, `storage_locations`, `storage_checks` |
| MintRequest | off chain | `module_requests` (`kind = mint | mint_batch | drop`) + `request_transitions` |
| TransferRequest | off chain | `module_requests` (`kind = transfer`) |
| Approval | chain: token approval in `NftRecord`, operators `0x44` | `ownership_cache.approved`, `operator_cache` |
| Listing | chain `0x47`, `0x48` | `listings_cache` |
| Sale | chain: closed `Listing` with breakdown + `nft_sale` event | `sales_cache` (adds the buyer's network fee) |
| ProvenanceEvent | chain receipts (`nft_*` events) | `provenance_events`, `chain_tx_outcomes` |

Global reference: `aureom:<chain_id>:<genesis prefix>/<collection id>/<token id>`.

**Distinct roles.** *Creator* (who signed CollectionCreate — no residual power),
*current owner* (NftRecord.owner), *approved operator* (token approval or collection
operator), *metadata administrator*, and the *intellectual-property rights holder* (a
named party in the rights statement, not an address). Owning a token never transfers
copyright or a physical object; every metadata document states
`token_owner_receives_copyright: false`.

## 3. Collection creation (wizard)

Console → Collections → *New collection wizard* (preview) or
`chainworks nft collection-create --from <label> --answers answers.json` (example:
`fixtures/collections/wizard-answers.example.json`). Inputs: name, description and artwork
(collection metadata document), identifier (slug), supply policy, minting permission,
metadata policy, transfer restrictions, optional royalty, rights statement.

Before anything is signed the tool shows **every administrative power** with holder,
limit and risk, plus `aureom-cli tx review` warnings, and simulates the transaction
against the node. Defaults are minimal: no admin, no pause, no forced transfer. Pausing
and forced transfer exist only if opted into at creation, are held by an explicit admin,
and every forced transfer is a public `nft_transfer` event with `authority = forced_by_admin`
and a reason hash. Metadata replacement exists only under policies 1–2 and is recorded.

## 4. Minting

`prepare → validate (simulate) → preview permissions and fees → sign → submit → confirm/finalise → index`

* **Individual**: `chainworks nft mint --collection … --token-id … --to … --metadata-sha256 …`.
* **Reviewed batch**: `nft batch-plan` validates the whole allocation (duplicate ids,
  invalid recipients, unregistered metadata, ids already on chain, supply limit) and
  prints a plan id; `nft batch-run <plan> --approve <plan>` signs chunks of ≤ 32 as
  atomic `MintBatch` transactions. Re-running resumes and never mints twice.
* **Recipient allocation**: per-recipient counts are part of the plan review.
* **Claim-based distribution**: `aureom-cli drop-tree` + `DropCreate`/`DropClaim`; each
  leaf binds claimant, token id and metadata hash.
* **Supply limits** are enforced by the ledger (`SUPPLY_CAP`) and pre-checked in plans.
* **Simulation**: `POST /v1/simulate` runs the unsigned transaction through the real
  state machine (all checks but the signature) and commits nothing.

Idempotency: every request has an idempotency key (`mint:<collection>:<token>` by
default); creating it again returns the existing request. A request is signed once and its
exact bytes are stored. If submission's outcome is unknown (timeout), the request becomes
`unknown` and is **reconciled by txid on every node before any retry**; a retry resends the
same bytes (same nonce — the ledger can include it at most once). A failed simulation
stops the request before signing. *A completed upload is not a mint; a submitted
transaction is not a confirmed NFT*: status advances only on chain evidence.

## 5. Media and metadata

* **Validation** (`nft/media.py`): type decided from the bytes; extension must agree;
  PNG chunk CRCs and IEND, JPEG markers, WAV RIFF size, PDF trailer; SVG with scripts,
  event handlers, `foreignObject`, DOCTYPE/ENTITY or external references is rejected; PDF
  with JavaScript/launch/embedded files/open actions is rejected; size limits per kind.
  Images, audio, video, documents (PDF, text) and structured JSON are supported.
* **Accessibility**: alt text (≥ 10 chars) required for images and video; transcripts
  recommended for audio/video (warning).
* **Checksums**: SHA-256 for every file; CIDv1 (raw, sha2-256) computed locally — equal to
  an IPFS node's CID for `--raw-leaves --cid-version=1` only for files ≤ 256 KiB (single
  chunk); larger files get the CID the IPFS node returns.
* **Metadata documents** (`aureom-nft-metadata/v1`): canonical JSON bytes (sorted keys,
  no whitespace, integers only); their SHA-256 is the on-chain commitment; media are named
  by SHA-256 inside. Rights and licence fields are mandatory. A personal-data lint refuses
  documents with e-mail addresses, phone-like numbers, account numbers or identity terms.
* **On-chain vs off-chain**: the chain holds `{uri ≤ 128 chars, sha256}` per revision; the
  bytes live in storage.
* **Adapters** (`nft/storage.py`): local content-addressed store (atomic write +
  read-back verify), S3-compatible (stdlib SigV4, credentials from environment), IPFS
  (optional; Kubo HTTP API, add + pin), HTTP (read-only checks).

**Persistence, stated accurately.** A copy exists only while its maintainer keeps it.
An IPFS CID names content; it does not mean anyone hosts it — pinning on our node says
nothing about other nodes, and when our node stops, the content may become unretrievable.
Every stored copy records *who maintains it* and *how availability is monitored*;
`chainworks nft storage-check` re-fetches every copy and compares SHA-256, and the Media
page shows the last result per copy. The default demo URIs
(`http://127.0.0.1:8787/media/<sha256>`) are local development URLs, labelled as not
publicly resolvable; production deployments must configure a real public base.

## 6. Metadata lifecycle

1. **mutable** — the metadata admin may publish new revisions forever; each is kept on chain.
2. **freezable** — revisions until a permanent freeze of a token or the whole collection.
3. **immutable** — fixed at mint; no admin role exists.

Immutability is a ledger rule, never an interface choice. Before freezing,
`chainworks nft freeze-preview` lists exactly which token references and metadata hashes
become permanent and the value the freeze transaction must commit to (the token's
metadata hash, or the collection's metadata root); a mismatch fails with `STALE`.
Revisions and authority changes are preserved on chain and shown in Assets / Permissions.

## 7. Ownership and permissions

Owner queries come from chain state (`/v1/nft/tokens/…`, `chainworks nft owner` shows chain
and index side by side). Transfers, single-token approvals (with optional expiry),
revocation, collection operators and burns follow COLLECTIONS-PROTOCOL.md §6; the ledger
validates owner, signature, chain id and approval scope. Approval risk is explicit:
`aureom-cli tx review` flags a collection-wide operator as **COLLECTION-WIDE OPERATOR … ALL
your tokens**, the CLI refuses it without `--i-understand-collection-wide-risk`, and the
Permissions page lists every operator with its risk. Selling uses a listing (narrower than
any approval). Private keys never enter the console or the Python service.

## 8. Management interface

Console section **Collections**: Collections (dashboards, roles, powers, wizard) ·
Assets (gallery + table, token detail with chain-vs-index ownership, metadata inspection,
revisions with storage health, provenance timeline, JSON export) · Minting (request
progress through the lifecycle) · Transfers (with authority used, rejected attempts) ·
Media (files, checksums, CIDs, copies, maintainers, last checks) · Permissions (powers,
authority log, operators, approvals) · Listings (listings, settlement receipts) ·
Activity (every module transaction incl. failures, settlement state, reorganisations).

Settlement labels follow the chain: PoW shows `INCLUDED k/n conf` then `CONFIRMED`
(probabilistic, reorganisable); BFT shows `FINALISED`. The console is read-only: it never
signs; it relays already-signed bytes and proxies `/v1/simulate` (no state change).

**Index and reorganisations.** The indexer records each consumed block id; before each
sync it compares the stored tip with the node and, on PoW, walks back to the fork point,
deletes all rows above it, records the reorganisation and re-derives every cache by
replaying retained events. On BFT a changed committed block is reported as a finality
violation and the index is left untouched. `nft index rebuild` drops all chain-derived rows
and re-indexes from chain events; `nft index verify` compares the cache with chain state.

## 9. Demonstration marketplace

Enabled per genesis. Seller-authorised listings (native coin or any token), expiry,
cancellation, buyer review (`tx review` shows the exact price; the transaction commits to
price and currency), settlement receipts. **Atomic**: payment, royalty, platform fee and
NFT move in one ledger state transition; nothing is split across separate operations.
Ownership, listing status, expiry, price and currency are revalidated at settlement; a
second purchase fails with `LISTING_INACTIVE`; replays fail on nonce, cross-network replays
fail on chain id.

## 10. Royalties and proceeds

A collection's royalty is a **creator preference** stored on chain. It is **enforced only
by this native marketplace** (`ListingBuy`). A direct `Transfer` carries no payment, and
another marketplace (or an off-chain sale followed by a transfer) can ignore it; metadata
alone never enforces anything. Integer arithmetic, documented rounding:
`royalty = floor(price·bps/10000)`, `platform_fee = floor(price·fee_bps/10000)`,
`seller = price − royalty − platform_fee`. Platform fees, creator proceeds, royalties and
network fees are recorded separately (Listings page, `sales_cache`, `nft_sale` event).

## 11. Access and authenticity

**Token gating** (`nft/gating.py`): a single-use challenge naming network, audience,
collection/token, address, nonce and expiry; signed with `aureom-cli message sign`
(domain `AUREOM/MSG/v1`, can never be a transaction); verified for key↔address match,
Ed25519 signature, expiry, single use, and **current on-chain ownership**. A public
address alone grants nothing.

**Claims** (`nft/authenticity.py`): "verified artist", "authentic work", "physical asset
backed" and similar statements are off-chain claims with evidence hashes and a human
review outcome (claimants cannot review their own). A ledger entry proves that a
transaction was recorded, not that an issuer's claims are true. Keep personal data and
confidential documents off the ledger and out of public metadata; store only hashes.

## 12. Security assumptions and limitations

* Development software, not audited. Inherits all limits in
  [SECURITY-LIMITATIONS.md](SECURITY-LIMITATIONS.md): PoW settlement is probabilistic and a
  majority-hash attacker can rewrite NFT history; BFT safety needs < 1/3 Byzantine power.
* Not ERC-721/1155: no interoperability with Ethereum wallets, marketplaces or tooling.
* Enabling the module requires a genesis that declares it; there is no live activation.
* Metadata and media availability depends entirely on storage maintainers; the demo uses
  a local store and local URLs. IPFS integration is optional and was not exercised against
  a live IPFS node in this delivery (none was available); the CID computation is tested
  against the known empty-file CID.
* The S3 adapter's signing is tested against AWS's published SigV4 example; it was not
  exercised against a live bucket.
* SVG/PDF sanitisation is rejection-based pattern matching, not a full parser; serve
  user media from a separate origin with the restrictive CSP the console server sends
  (`sandbox`, `default-src 'none'`).
* The console wizard only previews; signing requires the CLI wallet. The console server
  has no authentication of its own — bind it to localhost (default).
* Token gating checks ownership at verification time only; ownership can change after.
* Royalties are not universally enforceable (§10). Authenticity reviews are only as good
  as the reviewers and evidence (§11).
* The SQLite index is a single-process cache; it is not a multi-writer production store.
* Scans in `/v1/nft/owners/…` and `metadata_root` are O(n) over module state — fine for
  development networks, not for large production collections.
* PoW reorganisations deeper than the node's undo retention halt the node (PROTOCOL.md 10.4);
  the index follows whatever the node reports.

## 13. Walkthrough

```bash
tools/collections-devnet.sh ./collections-net pow 8787          # network + DB + console
chainworks nft media-add --dir ./collections-net fixtures/collections/media/lantern-01.png --alt "Six lanterns …"
chainworks nft metadata-put --dir ./collections-net token-1.json  # -> {uri, sha256}
chainworks nft collection-create --dir ./collections-net --from artist --answers answers.json
chainworks nft mint --dir ./collections-net --collection <id> --token-id 1 --to collector --metadata-sha256 <sha>
chainworks nft owner --dir ./collections-net --collection <id> --token-id 1
chainworks nft transfer --dir ./collections-net --from collector --collection <id> --token-id 1 --to buyer --key gift-1
chainworks nft provenance --dir ./collections-net --collection <id> --token-id 1 --out prov.json
chainworks demo collections --dir ./demo/collections              # the full recorded demonstration
```
