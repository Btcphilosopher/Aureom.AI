# Extension boundaries

## Smart-contract platform adapter (not implemented)
No virtual machine is included: an untested VM would expand the feature list without
justified security. The boundary for a **maintained** platform (e.g. an EVM via `revm`,
or CosmWasm/`wasmtime`) is specified as `aureom_core::extension::ExecutionExtension`:

* Action tags **100–199** are reserved for an extension; tags are rejected as
  `unsupported_action` unless the network's genesis enables an extension (a future
  genesis-format change, i.e. a new network or coordinated upgrade).
* The extension receives the sender, the block context and a state overlay restricted
  to its own key prefix (`0x80…`), plus a native-coin debit/credit interface that keeps
  the supply invariants.
* It must provide: deterministic execution, gas metering converted to the native fee,
  deployment permissions (who may deploy), events for receipts, and a state root
  contribution through the ordinary state commitment.
* Its execution rules, gas schedule, tooling and security model must be documented
  separately and tested with their own vectors before activation.

Bridges, DEXs, lending and token sales are separate projects requiring their own
specifications, trust assumptions and validation.

## External signing adapter (implemented in the CLI)
`aureom-cli tx prepare` writes `signing_message_hex`. Any external signer (HSM, hardware
wallet bridge, air-gapped machine) produces an Ed25519 signature over those bytes;
`aureom-cli tx attach-signature --in unsigned.json --signature <hex> --out signed.json`
verifies the signature against the sender key before writing the signed transaction.
Construction, review, signing and submission are separate steps.

## Operating-system credential stores (not implemented)
The keystore passphrase can come from a file, the `AUREOM_KEYSTORE_PASSPHRASE`
environment variable or an interactive prompt. Integration with OS keychains is a
planned extension.
