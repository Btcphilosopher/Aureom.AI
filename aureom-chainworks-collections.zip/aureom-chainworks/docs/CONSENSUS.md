# Consensus profiles and backends

The profile is chosen **once, at genesis** (`consensus.profile`). It is part of the
genesis hash, every node configuration pins that hash, and a node refuses to start if its
configured profile differs from the genesis profile. There is no selector that switches
a running network between profiles; a different profile is a new network (see
MIGRATION.md).

## Two backends, one management interface

| | PoW | PoS | PoA |
|---|---|---|---|
| backend | **aureom-nakamoto** (this repository) | **CometBFT 0.38** + Aureom ABCI app | **CometBFT 0.38** + Aureom ABCI app |
| processes per node | 1 (`aureom-node`) | 2 (`aureom-node` ABCI app + `cometbft`) | 2 |
| p2p | Aureom TCP protocol (authenticated, not encrypted) | CometBFT SecretConnection (authenticated + encrypted) | same as PoS |
| mempool | Aureom bounded mempool | CometBFT mempool; Aureom `CheckTx` | same as PoS |
| block format | `PowHeader` + txs (PROTOCOL.md 10.1) | CometBFT blocks; app stores an `AppBlock` record | same as PoS |
| block id | `H("AUREOM/BLOCK/v1", header)` | CometBFT block hash | same |
| settlement | probabilistic (confirmations) | deterministic finality on commit | same |
| fork choice | greatest cumulative work | none (no forks under < 1/3 Byzantine power) | same |
| validator set | none | stake-weighted, epochs, slashing | explicit authorities, governance |
| state machine | shared (`aureom-core::exec`) | shared | shared |

The **management interface is common**: the same `/v1` API paths, CLI commands,
console pages, backup/snapshot/replay commands and export format work for all
profiles. Fields that do not exist for a backend are reported explicitly (for example
`/v1/validators` on PoW says there is no validator set; `POST /admin/v1/peer-actions` on
BFT answers `501` because CometBFT manages its own peers). Nothing is faked to look
interchangeable.

## Framework research and choice

Maintained options examined (licences from the projects' repositories):

| option | language | licence | fit |
|---|---|---|---|
| **CometBFT** (Tendermint consensus), v0.38 LTS line and v1.0 | Go | Apache-2.0 | Mature BFT engine with a language-neutral ABCI socket protocol, evidence handling, double-sign protection, light-client/state-sync. **Chosen** for PoS/PoA. v0.38 chosen over v1.0 because the `tendermint-proto` Rust crate (0.41) ships v0.38 protobufs. |
| Malachite (Tendermint in Rust) | Rust | Apache-2.0 | Promising library, but younger; would require writing networking/mempool integration ourselves. |
| hotstuff-rs | Rust | Apache-2.0 | Smaller ecosystem; fewer operational tools (evidence, light clients). |
| Cosmos SDK | Go | Apache-2.0 | Full application framework (staking, slashing modules); would replace the Rust state machine required here. |
| Substrate / Polkadot SDK | Rust | Apache-2.0 / GPL-3.0 (parts) | Full framework; very large surface; would replace most of this design. |

PoW has no comparably small, maintained, embeddable Rust library with the required
documentation, so the Nakamoto rules (work function, retargeting, MTP timestamps,
cumulative-work fork choice, reorganisation) are implemented here on top of SHA-256
from RustCrypto; no cryptographic primitive is implemented.

## Proof of work (aureom-nakamoto)

* Work function: `pow_hash = SHA-256(H("AUREOM/POW/v1", header))`, valid iff
  `pow_hash <= target`; `work = floor(2^256/(target+1))`.
* Retarget every `retarget_interval` blocks, timespan clamped to [¼, 4]× (512-bit
  intermediate arithmetic), bounded by `pow_limit`.
* Timestamps: strictly above the median of the previous 11; at most
  `max_future_drift_ms` ahead of the local clock (acceptance rule, not invalidity).
* Fork choice: most cumulative work; ties keep the first seen tip.
* Reorganisation: undo logs per block; disconnect + connect in memory, persisted in one
  redb transaction; on any invalid block the original chain is restored. Disconnected
  transactions return to the mempool and are re-validated (demo: depth-17 reorg,
  transaction re-included exactly once).
* Coinbase: reward + fee remainder to the miner as an immature balance
  (`coinbase_maturity`).
* Development miner: CPU, throttled by `max_hashes_per_sec`; difficulty is deliberately
  low. **A small development network has no resistance to a party with more hash power
  than the honest miners combined.** Confirmations are probabilistic settlement.
* Sync: header pre-validation of each received batch (linkage + PoW) before any body
  is executed, then full validation; orphans pooled (bounded) and parents requested.
* Trust anchor: the genesis block (bound to the genesis hash); optional configured
  checkpoint that the chain must contain.

## Proof of stake (CometBFT)

Quorum and fault assumption (CometBFT/Tendermint): a block commits when validators with
**more than 2/3 of voting power** precommit it. **Safety** holds while Byzantine voting
power is **less than 1/3**; **liveness** additionally requires **more than 2/3** of
voting power online and eventual synchrony. With 4 equal validators the network
tolerates 1 faulty validator; demonstrated live: 3/4 online keeps committing, 2/4
online stops committing (no forks), and commits resume when quorum returns.

* Stake deposits: `ValidatorCreate` / `ValidatorBond` move coins from the operator's
  available balance into `bonded`. Delegation is not implemented (v1).
* Eligibility: not jailed/tombstoned, `bonded >= min_self_bond`, top `max_validators`
  by stake.
* Voting power: `floor(bonded / power_unit)`.
* Proposer selection: CometBFT weighted round-robin (proposer priority); the app does
  not influence it.
* Epochs: set recomputed every `epoch_length` blocks and immediately after jailing,
  slashing, unbonding or key rotation; updates take effect at H+2 (CometBFT rule). The
  application never submits an empty set.
* Finality: immediate on commit; finalised history is never rolled back by this software.
* Unbonding: `unbonding_period_blocks`; unbonding stake is slashable for earlier
  infractions.
* Rewards: scheduled issuance split pro rata among signers of the previous block;
  remainder to the proposer; fees to the proposer (or treasury), minus the burn share.
* Proven misconduct: `DuplicateVoteEvidence` / `LightClientAttackEvidence` verified
  by CometBFT → slash `slash_double_sign_bps` of bonded and eligible unbonding stake,
  tombstone. Only objectively verifiable offences are slashed.
* Downtime (not misconduct): more than `downtime_max_missed` missed blocks in
  `downtime_window` → jail for `jail_duration_blocks`, `slash_downtime_bps` penalty;
  `ValidatorUnjail` afterwards (demonstrated live).
* Validator-key protection: CometBFT `priv_validator_state.json` prevents a single
  instance from double signing across restarts; the orchestrator refuses to start a
  second instance holding the same consensus key (lock file), restores never move the
  signing state backwards, and backups for other machines are warned against.
* Long-range attacks: keys of fully unbonded validators can sign alternative histories
  at no cost. Joining nodes therefore need a **recent trusted checkpoint** (height + hash
  obtained out of band, younger than the unbonding period). `network add-node
  --trust-from` records one; `/v1/sync` shows the current trust anchor. In this release
  joining nodes use blocksync from genesis (commits verified from the genesis set);
  CometBFT state sync is not offered by the application (snapshot ABCI methods reject).

## Proof of authority (CometBFT)

* Same engine and the same < 1/3 Byzantine / > 2/3 online assumptions.
* Authorities are explicit identities in genesis (operator address, consensus key,
  power). No stake.
* Changes: `GovPropose{AddAuthority|RemoveAuthority}` by an authority, approved by
  separately signed `GovApprove` transactions until approving power > 2/3 (configurable,
  never below 2/3). Non-authority proposals fail `UNAUTHORIZED` (demonstrated).
* Key rotation: `ValidatorRotateKey` signed by the authority's operator key
  (demonstrated: old key stops counting at H+2, node restarted with the new key signs).
* No administrator key can replace validators or mint balances. A permissioned
  authority network is **not decentralised** merely because it has several nodes; its
  security rests on the authority operators.
