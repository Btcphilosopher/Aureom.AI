# Build and test results

Recorded in the delivery environment (Linux x86_64, 4 vCPU, Rust 1.97, Python 3.13, Node 22, Go 1.24, CometBFT v0.38.26 built from source, Docker 29). Every figure below is copied by `tools/make_results.py` from the raw files in `results/`.

## Rust unit and integration tests (`cargo test --release --workspace`)

```
test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
test codec::tests::big_endian_fixed_width ... ok
test codec::tests::rejects_oversized_length_before_alloc ... ok
test crypto::tests::address_roundtrip_and_hrp_check ... ok
test codec::tests::rejects_bad_bool_and_trailing ... ok
test crypto::tests::signature_verify_strict ... ok
test exec_tests::arithmetic_overflow_is_failure_not_wrap ... ok
test exec_tests::coinbase_maturity ... ok
test exec_tests::authority_mint_limits ... ok
test exec_tests::claim_distribution_no_double_claim ... ok
test exec_tests::expiry_enforced ... ok
test exec_tests::insufficient_funds_fails_but_charges_fee ... ok
test exec_tests::invalid_signature_wrong_chain_low_fee ... ok
test exec_tests::key_rotation_updates_valset ... ok
test exec_tests::pos_downtime_jails_without_tombstone ... ok
test exec_tests::pos_equivocation_slash_and_tombstone ... ok
test exec_tests::pos_new_validator_joins_at_epoch ... ok
test exec_tests::poa_authorised_add_and_unauthorised_rejected ... ok
test exec_tests::pos_rewards_and_unbonding ... ok
test exec_tests::replay_and_conflicting_nonce_rejected ... ok
test exec_tests::token_freeze_requires_opt_in_flag ... ok
test exec_tests::token_lifecycle_cap_and_permissions ... ok
test exec_tests::treasury_multisig_threshold ... ok
test exec_tests::tx_size_limit_and_malformed ... ok
test exec_tests::upgrade_halts_unsupported_version ... ok
test exec_tests::vesting_unlock_boundary ... ok
test exec_tests::transfer_fee_and_nonce ... ok
test exec_tests::deterministic_execution_and_undo ... ok
test genesis::tests::genesis_hash_is_key_order_independent ... ok
test genesis::tests::rejects_duplicate_and_oversupply ... ok
test genesis::tests::dev_genesis_valid_all_profiles ... ok
test merkle::tests::proofs_verify_for_all_sizes ... ok
test merkle::tests::odd_promotion_differs_from_duplication ... ok
test pow::tests::mtp ... ok
test pow::tests::retarget_clamps_and_respects_limit ... ok
test pow::tests::header_checks ... ok
test pow::tests::work_monotonic ... ok
test state::tests::apply_revert_restores_root ... ok
test state::tests::overlay_layers ... ok
test types::tests::multisig_nesting_rejected ... ok
test types::tests::vesting_boundaries ... ok
test types::tests::tx_roundtrip_and_strict ... ok
test types::tests::signature_bound_to_chain_and_type ... ok
test keystore::tests::roundtrip_and_wrong_pass ... ok
test result: ok. 43 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
test p2p::tests::roundtrip_and_bounds ... ok
test abci::tests::init_chain_rejects_mismatched_genesis ... ok
test abci::tests::process_proposal_rejects_malformed_and_invalid_blocks ... ok
test abci::tests::finalize_commit_persists_and_recovers ... ok
test pow_chain::tests::invalid_block_is_rejected_and_marked ... ok
test pow_chain::tests::cumulative_work_reorg_restores_state_and_mempool ... ok
test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
```

## Python tests (`pytest -v python/tests`)

```
plugins: anyio-4.15.1
collecting ... collected 20 items

tests/test_genesis_and_tools.py::test_genesis_python_rust_hash_agree PASSED [  5%]
tests/test_genesis_and_tools.py::test_validate_network_ok PASSED         [ 10%]
tests/test_genesis_and_tools.py::test_genesis_rebuild_refused PASSED     [ 15%]
tests/test_genesis_and_tools.py::test_invalid_genesis_rejected_by_both[<lambda>-duplicate] PASSED [ 20%]
tests/test_genesis_and_tools.py::test_invalid_genesis_rejected_by_both[<lambda>-exceeds max_supply] PASSED [ 25%]
tests/test_genesis_and_tools.py::test_invalid_genesis_rejected_by_both[<lambda>-schema0] PASSED [ 30%]
tests/test_genesis_and_tools.py::test_invalid_genesis_rejected_by_both[<lambda>-checksum] PASSED [ 35%]
tests/test_genesis_and_tools.py::test_invalid_genesis_rejected_by_both[<lambda>-schema1] PASSED [ 40%]
tests/test_genesis_and_tools.py::test_genesis_contains_no_secrets PASSED [ 45%]
tests/test_genesis_and_tools.py::test_keystores_encrypted_and_private PASSED [ 50%]
tests/test_genesis_and_tools.py::test_supply_preview_scheduled PASSED    [ 55%]
tests/test_genesis_and_tools.py::test_amount_parsing_exact PASSED        [ 60%]
tests/test_genesis_and_tools.py::test_bech32m_rejects_wrong_prefix_and_case PASSED [ 65%]
tests/test_genesis_and_tools.py::test_patch_toml_requires_known_keys PASSED [ 70%]
tests/test_genesis_and_tools.py::test_export_scan_detects_secrets PASSED [ 75%]
tests/test_genesis_and_tools.py::test_console_proxy_allowlist PASSED     [ 80%]
tests/test_vectors.py::test_addresses PASSED                             [ 85%]
tests/test_vectors.py::test_hashing_and_merkle PASSED                    [ 90%]
tests/test_vectors.py::test_transactions_encoding_signatures_ids PASSED  [ 95%]
tests/test_vectors.py::test_genesis_hash_state_root_and_transition PASSED [100%]

============================== 20 passed in 0.55s ==============================
```

## Console (`tsc --noEmit` strict, `vite build`)

```
tsc exit 0

> aureom-chainworks-console@0.1.0 build
> tsc --noEmit && vite build

vite v5.4.11 building for production...
transforming...
✓ 51 modules transformed.
rendering chunks...
computing gzip size...
dist/index.html                   0.64 kB │ gzip:  0.38 kB
dist/assets/index-DMLhA4X5.css   11.79 kB │ gzip:  3.36 kB
dist/assets/index-9YksCR0g.js   224.47 kB │ gzip: 71.16 kB
✓ built in 996ms
```

## Clippy

```
3 warning: unnecessary use of `clone` to create a slice from a reference
      2 warning: manual implementation of `.is_multiple_of()`
      1 warning: you seem to want to iterate on a map's keys
      1 warning: you seem to be trying to use `match` for destructuring a single pattern. Consider using `if let`
      1 warning: writing `&PathBuf` instead of `&Path` involves a new object where a slice will do
      1 warning: this function has too many arguments (8/7)
      1 warning: the variable `expect` is used as a loop counter
      1 warning: manual checked division
      1 warning: `aureom-node` (bin "aureom-node") generated 4 warnings (4 duplicates)
      1 warning: `aureom-node` (bin "aureom-node" test) generated 4 warnings (run `cargo clippy --fix --bin "aureom-node" -p aureom-node --tests -- ` to apply 1 suggestion)
      1 warning: `aureom-core` (lib) generated 4 warnings (run `cargo clippy --fix --lib -p aureom-core -- ` to apply 3 suggestions)
      1 warning: `aureom-core` (lib test) generated 7 warnings (4 duplicates) (run `cargo clippy --fix --lib -p aureom-core --tests -- ` to apply 3 suggestions)
(all items are style lints; no clippy::correctness findings)
```

## Reproducible demonstrations (live multi-node networks)

| demo | passed | total | seconds |
|---|---|---|---|
| pow | 27 | 27 | 72.5 |
| pos | 24 | 24 | 223.5 |
| poa | 23 | 23 | 81.7 |
| assets | 18 | 18 | 65.7 |

### pow

* PASS — Generate configuration and keys (0.12 s)
* PASS — Build and validate genesis (0.07 s)
* PASS — Launch three mining nodes (0.07 s)
* PASS — Nodes produce and agree on blocks (1.01 s)
* PASS — Submit a signed transfer (alice -> bob, 2.5 ADC) (0.53 s)
* PASS — Reject an invalid signature (0.02 s)
* PASS — Reject a replayed transaction (same signed bytes, two nodes) (0.0 s)
* PASS — Confirmation depth is reported as probabilistic settlement (1.01 s)
* PASS — API permissions: admin API requires token, is loopback-bound, absent from public port (0.0 s)
* PASS — Partition node2 from the majority (operator bans via admin API) (3.01 s)
* PASS — Transaction included only on the minority branch (2.55 s)
* PASS — Competing branches: both sides mine; majority accumulates more work (10.56 s)
* PASS — Reconnect: node2 reorganises to the chain with most cumulative work; its tx returns to the mempool and is re-validated (2.02 s)
* PASS — Disconnected-branch transaction re-included on the winning chain exactly once (2.0 s)
* PASS — Malformed block from an authenticated peer: rejected, peer banned (0.06 s)
* PASS — Block with an easier-than-required target (valid PoW for the wrong target): rejected, peer banned (0.05 s)
* PASS — Block whose hash does not meet its target: rejected, peer banned (0.05 s)
* PASS — Oversized length prefix (2 GiB frame claim): connection dropped without allocation, node unaffected (0.04 s)
* PASS — Restart a node: state root verified on start, catches up (4.31 s)
* PASS — Delayed messages (400 ms on every node2 send): network keeps agreeing (20.72 s)
* PASS — Database interruption: process aborted inside the commit of a block; restart recovers last committed state (12.92 s)
* PASS — Synchronise a new node from genesis (full validation) (0.31 s)
* PASS — Snapshot: create, verify against a validated block root, reject tampered/untrusted (0.01 s)
* PASS — Back up, corrupt the database (refused on start), restore with checksum verification, resync (4.13 s)
* PASS — Replay from a validated snapshot and full-chain re-execution audit (6.42 s)
* PASS — Inspect explorer results (blocks, tx, address index, events, supply) (0.0 s)
* PASS — Difficulty adjustment observed (target retargeted from genesis value) (0.0 s)

### pos

* PASS — Generate configuration and keys (accounts, CometBFT node + validator keys) (0.34 s)
* PASS — Build genesis; validate genesis and CometBFT genesis consistency across all nodes (0.19 s)
* PASS — Launch four validators (0.87 s)
* PASS — Validators commit blocks and agree (7.08 s)
* PASS — Submit a signed transfer (alice -> bob, 2.5 ADC) (1.02 s)
* PASS — Reject an invalid signature (0.02 s)
* PASS — Reject a replayed transaction (same signed bytes, two nodes) (0.0 s)
* PASS — API permissions: admin API requires token, is loopback-bound, absent from public port (0.0 s)
* PASS — Finality: committed transaction reported as finalised (BFT), not probabilistic (0.0 s)
* PASS — Scheduled block rewards paid to signing validators; supply reconciles (4.03 s)
* PASS — Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up (6.01 s)
* PASS — Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers (3.02 s)
* PASS — Restart a validator: state root verified against committed app hash; rejoins (3.42 s)
* PASS — Snapshot: create, verify against a validated block root, reject tampered/untrusted (0.01 s)
* PASS — Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up (3.85 s)
* PASS — Replay stored blocks from a validated snapshot; full re-execution audit from genesis (5.42 s)
* PASS — Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing (16.7 s)
* PASS — Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) (12.11 s)
* PASS — Restart the 2nd validator: quorum restored, commits resume (8.25 s)
* PASS — Downtime: node3 (offline) exceeds missed-block limit -> jailed, 1% downtime penalty, removed from set (not tombstoned) (46.04 s)
* PASS — Unjail: refused before jail period ends; accepted after; validator re-enters the set (70.17 s)
* PASS — New node synchronises, its operator bonds stake; it joins the validator set at the next epoch and signs (33.38 s)
* PASS — Unbonding: stake moves to an unbonding entry (still slashable) that pays out after unbonding_period_blocks (0.52 s)
* PASS — Inspect explorer results (blocks, tx, address index, events, supply) (0.0 s)

### poa

* PASS — Generate configuration and keys (accounts, CometBFT node + validator keys) (0.31 s)
* PASS — Build genesis; validate genesis and CometBFT genesis consistency across all nodes (0.21 s)
* PASS — Launch four validators (0.87 s)
* PASS — Validators commit blocks and agree (7.08 s)
* PASS — Submit a signed transfer (alice -> bob, 2.5 ADC) (1.02 s)
* PASS — Reject an invalid signature (0.02 s)
* PASS — Reject a replayed transaction (same signed bytes, two nodes) (0.0 s)
* PASS — API permissions: admin API requires token, is loopback-bound, absent from public port (0.0 s)
* PASS — No staking on PoA: validator_create rejected at submission (0.02 s)
* PASS — Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up (6.02 s)
* PASS — Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers (3.62 s)
* PASS — Restart a validator: state root verified against committed app hash; rejoins (3.31 s)
* PASS — Snapshot: create, verify against a validated block root, reject tampered/untrusted (0.01 s)
* PASS — Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up (3.84 s)
* PASS — Replay stored blocks from a validated snapshot; full re-execution audit from genesis (5.32 s)
* PASS — Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing (8.25 s)
* PASS — Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) (12.21 s)
* PASS — Restart the 2nd validator: quorum restored, commits resume (5.24 s)
* PASS — Restart the 4th authority (0.21 s)
* PASS — Unauthorised validator-set change (non-authority proposes adding an authority): rejected by the state machine (4.04 s)
* PASS — Authorised validator-set change: authority proposes, others approve with separately signed txs; executes at > 2/3; node4 signs (9.12 s)
* PASS — Key rotation: authority rotates its consensus key (signed by operator key); old key stops counting; node restarts with new key and signs (9.98 s)
* PASS — Inspect explorer results (blocks, tx, address index, events, supply) (0.0 s)

### assets

* PASS — Launch the Aureom Development Network (PoA, fixed-supply native coin, treasury, vesting) (6.37 s)
* PASS — Verify genesis supply against the genesis document (0.0 s)
* PASS — Transfer the native coin (1.02 s)
* PASS — Pay transaction fees: 20% burned (supply decreases), 80% to the block proposer (0.0 s)
* PASS — Define token -> review permissions -> sign -> submit -> verify (capped, mintable by issuer, no pause/freeze) (1.53 s)
* PASS — Enforce the token supply cap (2.55 s)
* PASS — Reject unauthorised minting (token and native coin) (1.04 s)
* PASS — Spoofing resistance: a second token with an identical symbol/name gets a distinct token id (1.52 s)
* PASS — Distribute the token: reviewed preview (duplicates/invalid rejected), interrupted run, resume, no duplicate payments (1.1 s)
* PASS — Claim-based distribution (Merkle commitment): claim once; double claim and inflated claim rejected (5.11 s)
* PASS — Vesting: locked before the cliff; linear unlock by block height after it (13.14 s)
* PASS — Treasury: budget, proposal by one signer, approval by another (separately signed), settlement on-chain, report (4.08 s)
* PASS — Reconcile supply against state transitions (genesis - burns = total; token supply = holder balances) (0.01 s)
* PASS — Restart recovery preserves balances and supply invariants (0.31 s)
* PASS — Optional PostgreSQL explorer index (derived, rebuildable) of issuance/burn/admin events (3.25 s)
* PASS — Export wallet connection details, asset documentation and the deployment package (secret scan, checksums) (0.05 s)
* PASS — Management console against the live network: manifest, proxied reads; admin proxy and non-tx POST refused (23.92 s)
* PASS — Export a consensus migration proposal (new network; no implied continuity) (0.01 s)

Full per-step evidence (JSON observed from the nodes): `results/demos/*-results.md|json`.

## Docker Compose smoke test (`tools/docker_smoke.py`)

| profile | ok | services | transfer | heights |
|---|---|---|---|---|
| pow | True | 3 | included | {'node0': 30, 'node1': 30, 'node2': 30} |
| pos | True | 8 | finalised | {'node0': 6, 'node1': 6, 'node2': 6, 'node3': 6} |
| poa | True | 8 | finalised | {'node0': 6, 'node1': 6, 'node2': 6, 'node3': 6} |

## Not exercised / known gaps (stated, not hidden)

* `deploy/Dockerfile.source` (multi-stage source build) was not built here; images were built from local release binaries.
* Live equivocation (a validator double-signing) was not induced; slashing of CometBFT duplicate-vote evidence is covered by state-machine tests with synthetic evidence.
* CometBFT state sync is not offered by the application; joining BFT nodes used blocksync from genesis.
* No fuzzing, no external audit, no long-running soak tests; demonstrations run minutes, not days.
* The console was exercised in headless Chromium against the live Aureom Development Network (screenshots in `results/console/`) and against a mock for PoW/PoS/PoA layouts; no manual browser QA.

