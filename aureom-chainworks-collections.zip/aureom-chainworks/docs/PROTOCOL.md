# Aureom Chainworks Ledger Protocol — Specification v1

Status: **development specification**. Written before the implementation and kept
normative: where code and this document disagree, the code has a bug or this document
must be revised through a protocol-version change. Nothing in this document claims
production security; see `SECURITY-LIMITATIONS.md`.

Protocol version: `1` (`PROTOCOL_VERSION = 1`). Genesis format: `1`.

---

## 1. Scope

The ledger is a small, deterministic, account-based state machine with:

* one **native coin** (fees, PoW rewards, PoS stake and rewards),
* a **native token module** (issued assets with explicit, opt-in administrative powers),
* **vesting** schedules (block-height based),
* **threshold-approval multisignature accounts** (treasury),
* **claim-based distributions** (Merkle commitments),
* profile-specific **validator / governance** operations (PoS and PoA only).

No smart contracts, bridges, wrapped assets or external backing exist in v1. Creating an
asset on this ledger gives it no monetary value, reserve backing, exchange listing or
legal status.

Three **consensus profiles** are selected once, at genesis, and cannot be switched on a
running network:

| profile | engine | settlement |
|---|---|---|
| `pow` | Aureom Nakamoto engine (this repository, Rust) | probabilistic, by confirmations |
| `pos` | CometBFT 0.38 (Tendermint BFT) + Aureom ABCI application | deterministic finality on commit |
| `poa` | CometBFT 0.38 (Tendermint BFT) + Aureom ABCI application | deterministic finality on commit |

The state machine (sections 4–9) is shared by all profiles. Sections 10–12 are profile
specific.

## 2. Primitives

| purpose | algorithm | implementation |
|---|---|---|
| hashing | SHA-256 | RustCrypto `sha2`; Python `hashlib` |
| signatures | Ed25519 (RFC 8032), strict verification | `ed25519-dalek` 2.x `verify_strict`; Python `cryptography` |
| addresses | Bech32m (BIP-350) | `bech32` crate; reference Python codec in `python/chainworks/bech32m.py` |
| keystore KDF | Argon2id | RustCrypto `argon2` |
| keystore cipher | XChaCha20-Poly1305 | RustCrypto `chacha20poly1305` |
| PoW work function | SHA-256d over domain-tagged header | `sha2` |
| 256-bit integers | — | `primitive-types` U256 |

No primitive is implemented in this repository. The Merkle tree construction (section
2.3) and canonical encoding (section 3) are constructions built from these primitives.

### 2.1 Domain-separated hash

```
H(domain, data) = SHA-256( u8(len(domain)) || ASCII(domain) || data )
```

Domains in v1:

| domain | used for |
|---|---|
| `AUREOM/ADDR/v1` | account address derivation |
| `AUREOM/TXSIG/v1` | prefix of the transaction signing message (not hashed, see 5.2) |
| `AUREOM/TXID/v1` | transaction identifier |
| `AUREOM/BLOCK/v1` | PoW block identifier |
| `AUREOM/POW/v1` | PoW work hash (inner hash) |
| `AUREOM/LEAF/v1`, `AUREOM/NODE/v1`, `AUREOM/EMPTY/v1` | Merkle tree |
| `AUREOM/STATE/v1` | state-commitment leaf |
| `AUREOM/RECEIPT/v1` | receipt hash |
| `AUREOM/GENESIS/v1` | genesis hash |
| `AUREOM/TOKEN/v1` | token identifier |
| `AUREOM/MSIG/v1` | multisignature account address |
| `AUREOM/DIST/v1` | distribution identifier |
| `AUREOM/CLAIM/v1` | distribution claim leaf |
| `AUREOM/P2P-HANDSHAKE/v1` | PoW peer authentication |
| `AUREOM/SNAPSHOT/v1` | snapshot file digest |

### 2.2 Addresses

```
address_bytes = H("AUREOM/ADDR/v1", 0x01 || ed25519_public_key)[0..20]
address       = bech32m(hrp = genesis.native_asset.address_hrp, address_bytes)
```

`0x01` is the key-scheme tag (Ed25519). Multisignature accounts use addresses derived in
section 7.4 and have no key. Token identifiers are 20 bytes and are displayed with HRP
`address_hrp + "tok"`. A HRP mismatch is a decoding error. Human-facing tickers and
token symbols are **display labels only** and never identify an asset.

### 2.3 Merkle tree

```
leaf(x)      = H("AUREOM/LEAF/v1", x)
node(l, r)   = H("AUREOM/NODE/v1", l || r)
root([])     = H("AUREOM/EMPTY/v1", "")
root([a])    = leaf(a)
```
Levels are built pairwise left to right; an odd final element is **promoted unchanged**
to the next level (never duplicated). A proof step is `(side: u8, sibling: [32])` where
`side = 0` means the sibling is on the left.

## 3. Canonical binary encoding

All consensus objects have exactly one valid encoding. Decoders MUST reject any input
that is not the unique encoding.

| type | encoding |
|---|---|
| `u8,u16,u32,u64,u128` | fixed-width big-endian |
| `bool` | `0x00` or `0x01`; any other byte is an error |
| `[u8; N]` | N raw bytes |
| `bytes(max)` | `u32` length, then bytes; length > max is rejected **before allocation** |
| `string(max)` | as `bytes(max)`, must be valid UTF-8; identifier fields restrict the charset further |
| `Option<T>` | `0x00` or `0x01 || T` |
| `Vec<T>(max)` | `u32` count, then items; count > max, or count × minimum item size > remaining input, is rejected before allocation |
| enum | `u8` tag, then payload; unknown tags are rejected |
| struct | fields in declaration order, no padding, no field names |

A complete decode MUST consume the entire input; trailing bytes are an error.

JSON representations used by APIs and files are **not** consensus encodings, except the
genesis document (section 9.1). In JSON, all `u64` amounts/fees and all `u128` amounts
are decimal strings; heights and timestamps are JSON integers.

## 4. Size limits and constants

| constant | value | notes |
|---|---|---|
| `MAX_CHAIN_ID_LEN` | 64 | `[a-z0-9-]`, must start with a letter |
| `MAX_MEMO_BYTES` | 256 | genesis may lower |
| `MAX_TX_BYTES` | genesis `limits.max_tx_bytes`, ≤ 65 536 | |
| `MAX_BLOCK_BYTES` | genesis `limits.max_block_bytes`, ≤ 4 194 304 | |
| `MAX_BLOCK_TXS` | genesis `limits.max_block_txs`, ≤ 10 000 | |
| `MAX_MSIG_SIGNERS` | 16 | |
| `MAX_PROOF_STEPS` | 32 | distribution proofs |
| `MAX_SYMBOL_LEN` | 12 | `[A-Z0-9]` |
| `MAX_NAME_LEN` | 64 | printable ASCII |
| `MAX_URI_LEN` | 200 | printable ASCII, issuer-supplied, unverified |
| `MAX_P2P_FRAME` | `MAX_BLOCK_BYTES + 65 536` | PoW networking |
| `MAX_TOKEN_DECIMALS` | 18 | native coin also ≤ 18 |

## 5. Transactions

### 5.1 Structure

```
UnsignedTx {
  version:        u16        // = 1
  chain_id:       string(64) // must equal genesis.chain_id
  nonce:          u64        // must equal sender account nonce
  fee:            u64        // native base units, paid in full
  expiry_height:  u64        // 0 = no expiry; otherwise valid only while block height <= expiry_height
  sender_pubkey:  [u8; 32]   // Ed25519
  action:         Action
  memo:           bytes(256)
}
SignedTx { tx: UnsignedTx, signature: [u8; 64] }
```

### 5.2 Signing message and identifiers

```
signing_message = u8(15) || "AUREOM/TXSIG/v1"
                  || string(chain_id) || u16(PROTOCOL_VERSION) || u8(action_tag)
                  || encode(UnsignedTx)
signature       = Ed25519.sign(sender_secret, signing_message)
txid            = H("AUREOM/TXID/v1", encode(UnsignedTx))
```

The chain identifier, protocol version and transaction type are bound explicitly (and
again inside the encoded body). A signature for one chain, protocol version or action
type never verifies for another. `txid` excludes the signature, so a transaction cannot
be re-identified by mutating its signature, and the same body always has the same id.

### 5.3 Actions (tags)

```
 1 Transfer           { to: [20], amount: u128 }
 2 VestedTransfer     { to: [20], amount: u128, start_height: u64, cliff_height: u64, end_height: u64 }
 3 NativeMint         { to: [20], amount: u128 }                          // authority policy only
 4 NativeBurn         { amount: u128 }
10 TokenCreate        { symbol: string(12), name: string(64), decimals: u8,
                        initial_supply: u128, initial_recipient: [20],
                        max_supply: Option<u128>, mint_authority: Option<[20]>,
                        admin: Option<[20]>, flags: u8, metadata_uri: string(200) }
                        // flags bit0 = pausable, bit1 = freezable; other bits must be 0
11 TokenTransfer      { token: [20], to: [20], amount: u128 }
12 TokenMint          { token: [20], to: [20], amount: u128 }
13 TokenBurn          { token: [20], amount: u128 }
14 TokenSetPaused     { token: [20], paused: bool }
15 TokenSetFrozen     { token: [20], account: [20], frozen: bool }
16 TokenSetMintAuthority { token: [20], new_authority: Option<[20]> }     // None = renounce, irreversible
20 MultisigCreate     { signers: Vec<[20]>(16), threshold: u8 }
21 MultisigPropose    { multisig: [20], inner: Action, expiry_height: u64 }
22 MultisigApprove    { multisig: [20], proposal_id: u64 }
30 DistributionCreate { asset: AssetId, total: u128, merkle_root: [32], claim_deadline_height: u64 }
31 DistributionClaim  { dist_id: [32], index: u32, amount: u128, proof: Vec<ProofStep>(32) }
32 DistributionReclaim{ dist_id: [32] }
40 ValidatorCreate    { consensus_pubkey: [32], self_bond: u128, moniker: string(64) }   // pos
41 ValidatorBond      { amount: u128 }                                                    // pos
42 ValidatorUnbond    { amount: u128 }                                                    // pos
43 ValidatorUnjail    { }                                                                 // pos
44 ValidatorRotateKey { new_consensus_pubkey: [32] }                                      // pos, poa
50 GovPropose         { kind: GovKind, expiry_height: u64 }                               // pos, poa
51 GovApprove         { proposal_id: u64 }                                                // pos, poa

AssetId   = 0x00 (native) | 0x01 [20] (token)
ProofStep = { side: u8, sibling: [32] }
GovKind   = 0x01 AddAuthority { operator: [20], consensus_pubkey: [32], power: u64, moniker: string(64) }  // poa
          | 0x02 RemoveAuthority { operator: [20] }                                                         // poa
          | 0x03 ProtocolUpgrade { name: string(64), protocol_version: u16, activation_height: u64 }
          | 0x04 Text { title: string(64), uri: string(200) }
```

`MultisigPropose.inner` is restricted to tags `1, 2, 3, 11, 12, 16` (no nesting).

### 5.4 Fee calculation

```
size     = len(encode(SignedTx))
min_fee  = fee_policy.base_fee + fee_policy.per_byte_fee * size      (checked u64; overflow => invalid)
```
`tx.fee >= min_fee` is required and the **whole** `tx.fee` is charged. Distribution:
```
burned    = floor(tx.fee * fee_policy.burn_bps / 10000)
remainder = tx.fee - burned  ->  block proposer/miner ("proposer") or the treasury ("treasury")
```
For PoW the miner's share is added to the coinbase payout (immature, section 10.6).

### 5.5 Inclusion validity

A transaction MUST NOT appear in a valid block unless, at its position in the block:

1. `size <= limits.max_tx_bytes` and it decodes canonically;
2. `version == 1` and `chain_id == genesis.chain_id`;
3. the signature verifies strictly over `signing_message`;
4. `expiry_height == 0 || block_height <= expiry_height`;
5. `nonce == account(sender).nonce`;
6. `fee >= min_fee` and `fee <= available_native(sender)` (section 6.2);
7. the action tag is enabled for the network's profile and monetary policy;
8. `memo` length `<= limits.max_memo_bytes`.

If valid, execution **always** increments the sender nonce and charges the fee, then
executes the action. If the action fails, every effect of the action is reverted
(fee and nonce are not) and the receipt has `status = failed` with an error code.
This gives deterministic replay protection: each `(sender, nonce)` is consumed exactly
once, and a re-broadcast of an included transaction is invalid (rule 5).

Execution never reads wall-clock time, randomness, node configuration, the local
mempool or any other non-consensus input. Its only inputs are the prior state, the
genesis parameters, the block height, the block proposer and the ordered transactions
(plus, for BFT profiles, the ABCI `misbehavior` and `decided_last_commit` lists, which
are themselves consensus outputs).

### 5.6 Arithmetic

All amounts are unsigned integers of base units. Every addition, subtraction and
multiplication is checked. Overflow or underflow inside an action makes that action fail
(`ERR_OVERFLOW`); in fee validation it makes the transaction invalid. Ratios use
`floor(a * b / c)` computed in 256-bit arithmetic. Basis points (`bps`) are out of
10 000. There is no floating point anywhere in consensus code.

### 5.7 Transaction lifecycle

| state | meaning |
|---|---|
| `received` | bytes arrived at a node API or peer |
| `validated` | passed stateless and mempool-level stateful checks on that node |
| `pending` | held in that node's mempool (no guarantee of inclusion) |
| `included` | in a block on the node's current best chain |
| `confirmed` | PoW: included with ≥ `confirmations` blocks on top (probabilistic) |
| `finalised` | BFT: block committed by > 2/3 voting power (irreversible under the fault assumption) |
| `rejected` | failed validation; never entered the mempool |
| `dropped` | left the mempool without inclusion (evicted, expired, invalidated by a reorg or a conflicting tx) |

A transaction accepted by one node's mempool may still never be included.

## 6. State

### 6.1 Keyspace

State is a sorted map `key -> value` of canonical encodings.

| key | value |
|---|---|
| `0x00` | `genesis_hash: [32]` (binds the state to its genesis) |
| `0x01 ‖ addr` | `Account { balance: u128, nonce: u64, vesting: Vec<Vesting>, immature: Vec<Immature> }` |
| `0x02 ‖ token_id` | `TokenInfo` |
| `0x03 ‖ token_id ‖ addr` | `TokenBalance { amount: u128, frozen: bool }` |
| `0x04 ‖ msig` | `Multisig { signers, threshold, next_proposal_id }` |
| `0x05 ‖ msig ‖ u64 id` | `MsigProposal { proposer, inner, approvals, expiry_height, status }` |
| `0x06 ‖ dist_id` | `Distribution { creator, asset, total, remaining, merkle_root, claim_deadline_height, closed }` |
| `0x07 ‖ dist_id ‖ u32 index` | `0x01` (claimed marker) |
| `0x10 ‖ operator` | `Validator` |
| `0x11 ‖ consensus_addr20` | `operator: [20]` (all historical consensus keys) |
| `0x12 ‖ u64 complete_height ‖ operator ‖ u64 seq` | `Unbonding { amount, start_height }` |
| `0x13` | applied validator set `Vec<(pubkey, power)>` |
| `0x14` | `ValidatorCounters { unbonding_seq }` |
| `0x20 ‖ u64 id` | `GovProposal` |
| `0x21` | `GovState { next_id, scheduled_upgrades }` |
| `0x30` | `Supply { genesis, minted, burned, total }` |
| `0x31 ‖ u64 window` | natively minted amount in an authority-mint window |
| `0x32 ‖ token_id` | none — token supply lives in `TokenInfo.supply` |

`Vesting = { total, start_height, cliff_height, end_height }`,
`Immature = { mature_height: u64, amount: u128 }`.

### 6.2 Balances

```
vested(v, h) = 0                                       if h < v.cliff_height
             = v.total                                 if h >= v.end_height
             = floor(v.total * (h - v.start_height) / (v.end_height - v.start_height))   otherwise
locked(a, h)    = Σ (v.total - vested(v, h)) over a.vesting
immature(a, h)  = Σ i.amount over a.immature where h < i.mature_height
available(a, h) = a.balance - locked(a, h) - immature(a, h)
```
Vesting requires `start <= cliff <= end` and `start < end`. Heights, not timestamps,
are used; real-time unlock dates are only estimates (PoW block times vary; BFT block
times depend on validator timeouts). Fully vested and matured entries are pruned
deterministically whenever an account is written.

### 6.3 State commitment

```
state_leaf(k, v) = H("AUREOM/STATE/v1", u32(len k) || k || u32(len v) || v)
state_root       = merkle_root([ state_leaf(k, v) for (k, v) in state sorted by k ])
```
(The Merkle construction of 2.3 is applied to the 32-byte `state_leaf` values; the
leaf function of 2.3 is applied on top.) The state root after a block is committed in
the PoW header and returned as the ABCI `app_hash` for BFT profiles.

### 6.4 Supply accounting

`Supply.total = genesis + minted - burned` (checked). The protocol invariant, tested
after every block in the test suite and available on demand at `/v1/supply`, is:

```
Supply.total = Σ account.balance + Σ validator.bonded + Σ unbonding.amount
             + Σ distribution.remaining (native)
```
and for every token: `TokenInfo.supply = Σ balances + Σ distribution.remaining (token)`.

Reported (non-consensus) quantities: `locked_vesting`, `immature`, `staked`, `escrow`,
`treasury` (balances of genesis-declared treasury accounts), and
`circulating = total - locked_vesting - immature - staked - escrow - treasury`.
Coins held by lost or inaccessible keys are **not** distinguishable from circulating
coins; only `NativeBurn`, fee burns and slashing are provable removals.

## 7. Action semantics

Error codes: `1 INSUFFICIENT_FUNDS, 2 OVERFLOW, 3 UNAUTHORIZED, 4 NOT_FOUND,
5 SUPPLY_CAP, 6 PAUSED, 7 FROZEN, 8 INVALID_ARGUMENT, 9 ALREADY_EXISTS, 10 EXPIRED,
11 ALREADY_CLAIMED, 12 BAD_PROOF, 13 MINT_LIMIT, 14 NOT_ELIGIBLE, 15 JAILED`.

### 7.1 Native coin
* `Transfer`: `available(sender) >= amount`; moves `amount`. Self-transfer allowed.
* `VestedTransfer`: as `Transfer`, and appends `Vesting{amount, start, cliff, end}` to the
  recipient. Requires `start <= cliff <= end`, `start < end` and `amount > 0`
  (`INVALID_ARGUMENT` otherwise); a `start` in the past is allowed and simply vests
  earlier. At most 8 vesting entries per account (`INVALID_ARGUMENT` beyond).
* `NativeMint`: only when `monetary_policy.kind == "authority"`; sender (or executing
  multisig) must equal `mint_authority`; `minted_in_window(h / window_blocks) + amount
  <= max_mint_per_window` (`MINT_LIMIT`); `total + amount <= max_supply` (`SUPPLY_CAP`).
* `NativeBurn`: holder-initiated; reduces balance and `total`; increases `burned`.

### 7.2 Tokens
* `token_id = H("AUREOM/TOKEN/v1", sender_addr || u64(tx.nonce))[0..20]` — stable,
  unique, independent of symbol or name.
* `TokenCreate`: symbol `[A-Z0-9]{1,12}`; decimals ≤ 18; `initial_supply <= max_supply`
  if capped; `flags != 0` requires `admin`. Default is minimal privileges: no mint
  authority, no admin, flags 0 → a fixed-supply token nobody can pause, freeze or mint.
* `TokenMint`: sender == `mint_authority`; not paused; `supply + amount <= max_supply`.
* `TokenTransfer`: not paused; neither party frozen; sufficient balance.
* `TokenBurn`: holder-initiated; not paused; holder not frozen.
* `TokenSetPaused` / `TokenSetFrozen`: only if the capability flag was set at creation
  and sender == `admin`.
* `TokenSetMintAuthority`: sender == current `mint_authority`; `None` renounces forever.
* There is no clawback, no metadata change and no admin transfer in v1.

### 7.3 Claim-based distributions
* `dist_id = H("AUREOM/DIST/v1", sender || u64(nonce))`; `total` is moved from the
  creator into escrow (`remaining`).
* claim leaf: `H("AUREOM/CLAIM/v1", u32(index) || claimant_addr || u128(amount))`, root
  computed with 2.3. The claimant is the transaction sender.
* `DistributionClaim` requires `h <= claim_deadline_height`, unclaimed `index`, valid
  proof, `amount <= remaining`; writes the claimed marker (double claims fail with
  `ALREADY_CLAIMED`).
* `DistributionReclaim`: creator only, `h > claim_deadline_height`; returns `remaining`.

### 7.4 Multisignature accounts (treasury)
* `msig = H("AUREOM/MSIG/v1", sender || u64(nonce))[0..20]` (genesis treasury:
  `H("AUREOM/MSIG/v1", 0x00*20 || u64(index))[0..20]`).
* Signers are distinct addresses, `1 <= threshold <= len(signers) <= 16`.
* `MultisigPropose` (signer only) stores the inner action and counts the proposer's
  approval. `MultisigApprove` (signer only, once per signer, before expiry) adds an
  approval. When approvals reach the threshold the inner action executes in the same
  transaction **as the multisig account** (the multisig is the sender of the inner
  action; the approving signer pays only the outer fee). A failed inner execution marks
  the proposal `failed`; it is never retried.
* Every approval is a separately Ed25519-signed transaction from a distinct key. This is
  on-chain threshold approval, not a threshold-signature scheme. Dashboard clicks are
  never approvals.

### 7.5 Validators (PoS)
See section 11. `ValidatorRotateKey` (PoS and PoA) replaces the consensus key; the old
key's consensus address remains mapped to the operator so that evidence about past
signatures is still attributable.

### 7.6 Governance (PoS, PoA)
See section 13.

## 8. Receipts

```
Receipt { txid: [32], status: u8 (1 success | 2 failed), error_code: u16,
          fee_paid: u64, events: Vec<Event>(64) }
Event   { kind: string(32), attrs: Vec<(string(32), string(128))>(16) }
receipt_root = merkle_root([ H("AUREOM/RECEIPT/v1", encode(r)) for r in receipts ])
```
Events record supply-relevant facts (`mint`, `burn`, `fee`, `reward`, `slash`,
`token_create`, `token_admin`, `vesting`, `msig_execute`, `validator_update`, `gov`),
and are indexed (rebuildably) for explorer queries.

## 9. Genesis

### 9.1 Genesis document and hash

The genesis document is JSON validated by `schemas/genesis.schema.json`. All strings
are printable ASCII. Amounts are decimal strings. The genesis hash is

```
genesis_hash = H("AUREOM/GENESIS/v1", JCS(genesis_document))
```

where `JCS` is RFC 8785 canonical JSON (for this ASCII, integer-only document: object
keys sorted by code point, no insignificant whitespace). Python and Rust compute it
independently and the test suite cross-checks them. Every node refuses to start if its
genesis hash differs from the expected hash in its node configuration, and BFT nodes
additionally refuse `InitChain` if CometBFT's `app_state_bytes` hash differs.

Private keys never appear in genesis or in ordinary exports.

### 9.2 Genesis state construction

1. `state[0x00] = genesis_hash`.
2. For each allocation: credit `balance`; if `vesting` present, add a `Vesting` entry.
   Duplicate addresses are a validation error (never merged silently).
3. Treasury multisigs: create `Multisig` at the derived address; credit its allocation.
4. PoS validators: create `Validator` with `bonded = self_bond` (not part of any balance).
   PoA authorities: create `Validator` with fixed `power`, `bonded = 0`.
5. `Supply.genesis = Σ balances + Σ bonded`; must be `<= max_supply` if set.

## 10. Proof-of-work profile

### 10.1 Header

```
PowHeader {
  version: u16, chain_id: string(64), height: u64, prev_id: [32], timestamp_ms: u64,
  tx_root: [32], receipt_root: [32], state_root: [32], miner: [20],
  target: [32] (big-endian U256), nonce: u64
}
Block { header: PowHeader, txs: Vec<SignedTx>(MAX_BLOCK_TXS) }
block_id  = H("AUREOM/BLOCK/v1", encode(header))
pow_hash  = SHA-256( H("AUREOM/POW/v1", encode(header)) )
work(t)   = floor( (2^256 - 1 - t) / (t + 1) ) + 1      // = floor(2^256 / (t+1))
```
A header satisfies its target iff `U256(pow_hash) <= target` and
`0 < target <= pow_limit`.

### 10.2 Difficulty adjustment
Retarget every `retarget_interval` blocks (height `h` with `h % interval == 0`, `h > 0`):
```
actual   = ts(h-1) - ts(h-1-interval)    (or ts(h-1) - ts(0) when that index < 0), min 1
expected = target_block_time_ms * interval
actual   = clamp(actual, expected / 4, expected * 4)
new      = min(pow_limit, floor(target(h-1) * actual / expected))   (U256, overflow saturates to pow_limit)
```
Otherwise `target(h) = target(h-1)`. Blocks with any other target are invalid.

### 10.3 Timestamps
`timestamp_ms > median(last 11 ancestor timestamps)` (consensus rule) and
`timestamp_ms <= local_now + max_future_drift_ms` (acceptance rule: a block failing it
is not marked invalid; it is ignored and may be accepted later).

### 10.4 Fork choice
The best chain is the valid chain with the greatest cumulative work
`Σ work(target)`; ties keep the first-seen tip. A reorganisation disconnects blocks to
the common ancestor using per-block undo logs, then connects the new branch, fully
re-validating every block. If any new block is invalid the node restores the original
chain in the same database transaction. Transactions from disconnected blocks are
returned to the mempool and re-validated; those that are no longer valid are `dropped`.

Reorganisations deeper than the node's undo retention (`pruning.keep_undo_blocks`)
cannot be performed automatically: the node halts and reports a critical alert.

### 10.5 Settlement
PoW settlement is **probabilistic**. A transaction with `k` confirmations can still be
reversed by a branch with more cumulative work. A small development network with a few
CPU miners offers no resistance to any party with more hash power than the honest
miners combined; the confirmation count reported by the API is a convenience, not a
finality guarantee.

### 10.6 Rewards and maturity
The miner receives `reward(h) + Σ fee remainders` as an `Immature` entry maturing at
`h + coinbase_maturity`. Scheduled policy: `reward(h) = initial_block_reward >>
(h / halving_interval_blocks)` (0 after 127 halvings), capped so that `total <= max_supply`.
Fixed and authority policies have `reward(h) = 0`.

## 11. Proof-of-stake profile (CometBFT)

* **Engine**: CometBFT v0.38 (Tendermint consensus), Apache-2.0, ABCI 2.0. Aureom
  implements the ABCI application. CometBFT provides p2p, mempool, block storage,
  proposer selection, voting, evidence handling and double-sign protection
  (`priv_validator_state.json`).
* **Fault assumption**: safety holds if validators controlling **less than 1/3 of the
  total voting power** are Byzantine. Liveness additionally requires that **more than
  2/3 of the voting power** is online and honest and the network is eventually
  synchronous. A block is final when CometBFT commits it with precommits from > 2/3 of
  the voting power; finalised history is never rolled back by this software.
* **Stake deposit**: `ValidatorCreate` moves `self_bond` from the operator's available
  balance into `Validator.bonded`; `ValidatorBond` adds more. Delegation is not supported in v1.
* **Eligibility**: not jailed, not tombstoned, `bonded >= min_self_bond`, among the top
  `max_validators` by `bonded` (ties: lower operator address first).
* **Voting power**: `floor(bonded / power_unit)`; validators with power 0 are inactive.
* **Proposer selection**: CometBFT's weighted round-robin by voting power (proposer
  priority algorithm); the application does not influence it.
* **Epochs**: the validator set is recomputed at heights `h % epoch_length == 0` and
  immediately after a jailing/slash. Updates returned at height `h` take effect at
  `h + 2` (CometBFT rule). The set can never be emptied by the application.
* **Unbonding**: `ValidatorUnbond` moves stake to an unbonding entry that pays out at
  `h + unbonding_period_blocks`. Unbonding stake remains slashable for infractions
  committed before the unbond started.
* **Rewards**: per block, `reward(h)` (scheduled policy) is distributed to the
  validators that signed the previous block (`decided_last_commit`), pro rata by power,
  floor; the remainder goes to the proposer.
* **Proven misconduct (equivocation)**: CometBFT `DuplicateVoteEvidence` (and
  `LightClientAttackEvidence`) delivered in `FinalizeBlock.misbehavior`: slash
  `slash_double_sign_bps` of bonded and of eligible unbonding stake (burned), tombstone
  (permanent jail). Evidence older than `evidence_max_age_blocks` is ignored by CometBFT;
  genesis validation requires `evidence_max_age_blocks < unbonding_period_blocks`.
* **Downtime** (not misconduct): a validator that misses more than
  `downtime_max_missed` of the last `downtime_window` blocks is jailed for
  `jail_duration_blocks` and slashed `slash_downtime_bps` (default 0). `ValidatorUnjail`
  restores eligibility after the jail period. Downtime is never treated as equivocation.
* **Long-range attacks / weak subjectivity**: a new node syncing from genesis trusts the
  genesis validator set and follows validator-set changes; keys of validators that have
  fully unbonded can sign alternative histories at no cost. New nodes must therefore be
  given a **recent trusted checkpoint** (height + block hash obtained out-of-band from an
  operator they trust) no older than the unbonding period; the node configuration
  exposes `trust_height`, `trust_hash` and `trust_period`, and the console displays the
  node's current trust anchor.

## 12. Proof-of-authority profile (CometBFT)

* Same engine and fault assumption as PoS (< 1/3 Byzantine voting power for safety,
  > 2/3 online for liveness). Each authority has an explicit fixed `power`.
* Authorities are explicit identities listed in genesis (operator address + consensus
  key + moniker). There is no stake, no reward-for-stake, and no administrator key.
* Validator-set changes happen only through `GovPropose{AddAuthority|RemoveAuthority}`
  approved by authorities (section 13). Proposals from non-authorities are rejected.
* Key rotation: `ValidatorRotateKey` signed by the authority's operator key.
* Equivocation evidence removes the authority (power 0) and records the evidence; it can
  only be re-admitted by a new governance proposal.
* A PoA network is **permissioned** and its security rests on the honesty of the
  authority operators. Several nodes run by one organisation are not decentralised.

## 13. Governance and upgrades

| question | PoW | PoS | PoA |
|---|---|---|---|
| who may propose | nobody on-chain | any active validator operator | any authority operator |
| who approves | node operators by running software | active validators, > `approval_threshold` of voting power | authorities, > `approval_threshold` of voting power |
| activation | `upgrades[]` in genesis / release notes, by height | `ProtocolUpgrade.activation_height` | same as PoS |

`approval_threshold` is a fraction `num/den` from genesis with `num/den >= 2/3`; a
proposal is approved when `approving_power * den > total_power * num`. Approved
proposals execute in the block that reaches the threshold. Proposals expire at
`expiry_height`.

* **Coordinated upgrades** are required for any change to sections 2–12 (encoding,
  hashing, validity, execution, consensus parameters). These are scheduled by
  `ProtocolUpgrade` (BFT) or a release with an activation height (PoW).
* **Incompatible version detection**: (a) PoW peers exchange protocol version ranges
  and disconnect on no overlap; (b) at an activated upgrade height, a node whose
  `SUPPORTED_PROTOCOL_VERSION` is lower **halts** with an explicit error instead of
  executing blocks with the wrong rules; (c) the genesis hash and `chain_id` are checked
  on every handshake and at `InitChain`.
* **Operational administration** (peer actions, snapshots, shutdown) is a separate,
  authenticated, local-only API and cannot change consensus state, balances or
  validators.
* There is no administrative "rollback" of finalised history. Software rollback is
  permitted only between versions that share a protocol version and database version.

## 14. Consensus migration

The profile is fixed at genesis. Moving to another profile means launching a **new
network**. `chainworks migrate propose` exports: the source checkpoint (height, block id,
state root), an account-state mapping (balances, vesting, tokens), a target genesis
draft and a validation report. This preserves neither security nor continuity of
history: users must decide independently whether to recognise the new chain.

## 15. Test vectors

`test-vectors/*.json` are generated by `aureom-cli vectors` and verified independently
by the Python reference implementation (`python/chainworks/protocol.py`):
encoding, hashing, address derivation, signatures, txids, Merkle roots, and state
transitions (pre-state, block, expected post-state root and receipts).

## 16. Native modules

Genesis may declare optional native modules under `modules` (absent in documents that
predate them, so their hashes are unchanged). v1 defines one: **collections** (NFTs),
action tags 60–76, state prefixes `0x40`–`0x4A`, error codes `16 STALE`,
`17 METADATA_FROZEN`, `18 NON_TRANSFERABLE`, `19 LISTING_INACTIVE`, specified in
[COLLECTIONS-PROTOCOL.md](COLLECTIONS-PROTOCOL.md). Networks without the module reject
those tags as `unsupported_action`.
