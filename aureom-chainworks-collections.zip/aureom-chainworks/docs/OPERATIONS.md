# Operations: launch, monitoring, backup, recovery, upgrades

## Launch workflow
```
chainworks init --profile pow|pos|poa --dir NET [--interactive] [--target local|docker]
# edit NET/network.json (launch-wizard answers) if needed
chainworks genesis build NET          # keys, genesis.json, genesis.hash, node + CometBFT configs
chainworks genesis preview NET        # supply preview, state root
chainworks validate NET               # every consistency check; non-zero exit on failure
chainworks network up NET             # validates again, then launches
chainworks network status NET         # reachable? healthy? on the intended chain?
chainworks export NET                 # deployment package (no secrets), CHECKSUMS.sha256
chainworks network down NET
```
Docker: `deploy/build-image.sh` then `chainworks network compose NET && (cd NET && docker compose up -d)`.

## Storage and durability
* redb (embedded, ACID). One write transaction per block (PoW: per extension or whole
  reorganisation) contains state changes, block, receipts, undo log, explorer indexes
  and the tip pointer.
* Start-up recovery check: the stored state root must equal the tip block's state
  root (PoW) or the last committed app hash (BFT); otherwise the node refuses to start.
* Database version (`db_version`) is checked on open; incompatible versions refuse to start.
* BFT: if the app crashes between `FinalizeBlock` and `Commit`, CometBFT's handshake
  replays the block (demonstrated with `AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT`).
* Signing-protection records (`priv_validator_state.json`) are CometBFT's; restores
  never move them backwards.

## Backups
```
chainworks backup NET --node node2            # stops the node, consistent copy, checksums, restarts
chainworks restore NET --node node2 --from NET/backups/node2-<ts>
```
* Contents: `chain.redb` (+ CometBFT `data/` for BFT nodes) and `backup-manifest.json`
  with SHA-256 per file; restore verifies every checksum first and keeps the replaced
  data directory aside.
* Never restore a validator backup onto a second machine while the original runs.

## Snapshots, verification and replay
```
chainworks snapshot create NET --node node0
chainworks snapshot verify NET --file F --against-node node1
chainworks replay NET --node node1 --snapshot F [--repair]     # node stopped
aureom-node verify-chain --config NET/nodes/node1/node.json    # full re-execution from genesis
aureom-node reindex --config ...                               # rebuild explorer indexes
```
A snapshot is accepted only when its digest matches, its recomputed state root matches
its header, and that root matches a block the node validated itself (or an out-of-band
checkpoint). `--repair` rewrites a damaged state table from the replayed state.

## Pruning
* PoW: `pruning.keep_undo_blocks` (default 1000) bounds automatic reorganisation depth.
* BFT: `pruning.keep_blocks` → CometBFT `retain_height`.
* Explorer indexes are rebuildable and can be dropped.

## Monitoring
* `/metrics` (Prometheus text): height, peers, mempool, PoW hashes/reorgs, BFT commit
  participation. `export` writes `monitoring/prometheus.yml` and `alerts.yml`.
* `/v1/health` alerts: `no_peers`, `stale_tip`, `halted`, `recent_reorg`,
  `consensus_engine_unreachable`, `fault_injection_active`.
* The console labels observations older than 10 s as STALE and compares each node's
  chain id/genesis hash with the manifest (a reachable node is not necessarily healthy
  or on the intended chain).

## Fault injection (development only, environment variables)
* `AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT=N` — abort inside the commit of height N.
* `AUREOM_FAULT_P2P_DELAY_MS=N` — PoW: delay every outbound message.
* `chainworks.faults.RawPeer` — authenticated malicious PoW peer (malformed blocks,
  wrong targets, insufficient work, oversized frames).
* SIGSTOP/SIGCONT of a CometBFT process — delayed BFT messages.

## Upgrades and rollback
* Consensus-affecting changes require a coordinated upgrade with an activation height
  (BFT: `ProtocolUpgrade` governance proposal; PoW: release with activation height in
  genesis `upgrades`). Nodes that do not support an activated version halt with an
  explicit error rather than execute with the wrong rules.
* Software rollback is permitted only between releases with the same protocol version
  and database version. There is no administrative rollback of finalised history.
