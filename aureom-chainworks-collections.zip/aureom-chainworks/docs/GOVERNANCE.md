# Governance and upgrades

| question | PoW | PoS | PoA |
|---|---|---|---|
| Who may propose consensus changes? | no on-chain proposals; maintainers publish releases | active validator operators (`GovPropose`) | authority operators (`GovPropose`) |
| Who approves? | node operators, by choosing to run a release | validators with > `num/den` (≥ 2/3) of voting power, each with a signed `GovApprove` | authorities with > `num/den` (≥ 2/3) of power |
| Validator-set changes | none (open mining) | staking rules (bond, unbond, jail, slash) — not governance | `AddAuthority` / `RemoveAuthority` proposals |
| Activation scheduling | `upgrades[]` activation height in genesis/release | `ProtocolUpgrade.activation_height` | same |
| Expiry | — | `expiry_height` ≤ now + `proposal_max_ttl_blocks` | same |

## Changes that require coordinated node upgrades
Anything in PROTOCOL.md sections 2–13: encoding, hashing, signatures, validity rules,
execution semantics, fee and reward formulas, consensus parameters, state layout.

## Incompatible-version detection
1. PoW handshake: protocol version ranges must overlap; chain id and genesis hash must
   match.
2. BFT: `InitChain` checks the genesis hash; CometBFT checks app hashes every block.
3. At an activated `ProtocolUpgrade` whose version exceeds `SUPPORTED_PROTOCOL_VERSION`,
   the node halts with an explicit message (unit-tested) instead of executing blocks
   under the wrong rules.
4. `db_version` mismatch refuses to open the database.

## Separation of powers
* **Operational administration** (admin API: peer actions, snapshots, mining toggle,
  shutdown) cannot change ledger state or validators.
* **Consensus governance** happens only through signed transactions processed by
  consensus.
* The console has no edit controls for consensus-critical configuration.
* There is no administrative rollback of finalised history. Software may be rolled back
  only between releases with identical protocol and database versions.
