# Consensus selection and migration

* Consensus is chosen at genesis. A dropdown or config edit cannot switch a running
  network between PoW, PoS and PoA: nodes pin the genesis hash and refuse a config whose
  profile differs from the genesis profile.
* Changing profile requires a **new network**.

`chainworks migrate propose NET --target-profile pos --out DIR` exports:

| file | content |
|---|---|
| `checkpoint.json` | source chain id, genesis hash, height, block id, state root (from a verified snapshot) |
| `account-mapping.json` | every account balance (bonded stake converted to liquid), vesting entries, token holder tables |
| `target-genesis.draft.json` | draft genesis for the target profile (validators must still be added) |
| `validation-report.json` | totals, tokens needing re-issuance, open distributions, and warnings |

The proposal preserves **neither security nor continuity**: the target is a different
chain with a different chain id, validator set and history. Users and operators must
decide independently whether to recognise it. A real migration protocol (e.g. with
cross-chain proofs) would need its own specification and is out of scope.
