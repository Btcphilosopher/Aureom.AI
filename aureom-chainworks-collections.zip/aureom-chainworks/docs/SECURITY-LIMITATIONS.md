# Security limitations

**AUREOM CHAINWORKS 0.1.0 is development software. It has not been audited and is not
production-secure.** Its purpose is to launch and study development networks whose
protocol, genesis, ledger, consensus and recovery are explicit and testable.

## Protocol and implementation
* No external security review, fuzzing campaign or formal verification has been done.
  The test suite (TEST-RESULTS.md) exercises the listed properties only.
* The state commitment recomputes a Merkle root over all state leaves every block
  (O(n)); fine for development sizes (≈18 ms at 100k entries), not for large states.
  No state proofs are served by the API.
* Whole state is held in memory and loaded at start-up.
* Accounts are identified by a hash of a single Ed25519 key; account keys cannot be
  rotated (consensus keys can).
* Multisignature is on-chain threshold approval of separately signed transactions,
  implemented and tested here; it is not a threshold-signature scheme and has had no
  external review.
* Token module: no clawback, no metadata change, no admin transfer; tokens cannot be
  defined in genesis v1.
* Fees are flat (base + per byte); there is no gas metering because there is no
  general-purpose execution.

## Proof of work
* Development difficulty is tiny. **Any party with more hash power than the honest
  miners can rewrite history.** Confirmations are probabilistic only.
* The p2p transport authenticates peers (Ed25519 challenge-response bound to chain id
  and genesis) but does **not encrypt** traffic.
* Undo logs are pruned beyond `keep_undo_blocks`; deeper reorganisations halt the node
  for manual resynchronisation.
* Block-time rules use local clocks for the future-drift acceptance rule.
* Peer discovery is off by default (explicit peers); eclipse resistance is minimal.
* Mempool policy: at most 32 nonces ahead of the account nonce and 64 pending per
  sender (measured: 102 of 300 rapid-fire transactions were refused by these limits).

## BFT profiles
* Safety requires < 1/3 Byzantine voting power; liveness requires > 2/3 online. Four
  validators tolerate one fault; a network of 1–3 validators tolerates none.
* CometBFT `CheckTx` in this application enforces strict per-sender nonce order:
  transactions of one sender must reach a node in nonce order (submit them to one node).
* No state sync, no light-client verification in the console, no remote signer
  integration (CometBFT `priv_validator_laddr` could be used; not tested here).
* Live equivocation was not induced in the demonstrations; slashing for duplicate-vote
  evidence is covered by state-machine unit tests with synthetic CometBFT evidence.
* Weak subjectivity: joining nodes must be given a recent trusted checkpoint by the
  operator; the software cannot obtain one securely by itself.

## Keys and operations
* Development networks store keystore passphrases next to the keystores
  (`secrets/passphrases`, mode 0600) for unattended demos. **Never do this for real
  value.** Keystores use Argon2id with the minimum development cost when `fast_kdf` is set.
* PoW node identity keys and CometBFT keys are plaintext files (mode 0600), as required
  for unattended processes.
* Admin tokens are bearer tokens on a loopback listener; there is no TLS on any API.
* No operating-system credential store integration (documented extension).
* The console has no authentication; it is read-only and relays only already-signed
  transactions, and it is intended to be bound to loopback.

## Assets
* Creating a coin or token does not give it monetary value, reserve backing, exchange
  acceptance or legal status. Tickers and symbols are display labels; identify assets by
  chain id + token id. Issuer-supplied names and metadata URIs are never verified.
* Lost or inaccessible coins cannot be proven removed; only burns, fee burns and
  slashing are provable removals.
* Wrapped/bridged assets, smart contracts, DEXs, lending and token sales are out of
  scope and require separate specifications and validation.

## Collections (NFT) module
See [COLLECTIONS.md §12](COLLECTIONS.md#12-security-assumptions-and-limitations). In short:
not ERC-721/1155 compatible; NFT history on PoW is as reversible as any PoW history;
storage availability depends on maintainers (an IPFS CID is not hosting); royalties are
enforced only by the native marketplace; ownership of a token conveys no copyright or
physical object; authenticity claims are off-chain reviews, not chain facts.
