# Demo results: pow

27/27 steps passed in 72.5 s (2026-11-27T13:31:17Z).

| # | step | result | seconds |
|---|---|---|---|
| 1 | Generate configuration and keys | PASS | 0.12 |
| 2 | Build and validate genesis | PASS | 0.07 |
| 3 | Launch three mining nodes | PASS | 0.07 |
| 4 | Nodes produce and agree on blocks | PASS | 1.01 |
| 5 | Submit a signed transfer (alice -> bob, 2.5 ADC) | PASS | 0.53 |
| 6 | Reject an invalid signature | PASS | 0.02 |
| 7 | Reject a replayed transaction (same signed bytes, two nodes) | PASS | 0.0 |
| 8 | Confirmation depth is reported as probabilistic settlement | PASS | 1.01 |
| 9 | API permissions: admin API requires token, is loopback-bound, absent from public port | PASS | 0.0 |
| 10 | Partition node2 from the majority (operator bans via admin API) | PASS | 3.01 |
| 11 | Transaction included only on the minority branch | PASS | 2.55 |
| 12 | Competing branches: both sides mine; majority accumulates more work | PASS | 10.56 |
| 13 | Reconnect: node2 reorganises to the chain with most cumulative work; its tx returns to the mempool and is re-validated | PASS | 2.02 |
| 14 | Disconnected-branch transaction re-included on the winning chain exactly once | PASS | 2.0 |
| 15 | Malformed block from an authenticated peer: rejected, peer banned | PASS | 0.06 |
| 16 | Block with an easier-than-required target (valid PoW for the wrong target): rejected, peer banned | PASS | 0.05 |
| 17 | Block whose hash does not meet its target: rejected, peer banned | PASS | 0.05 |
| 18 | Oversized length prefix (2 GiB frame claim): connection dropped without allocation, node unaffected | PASS | 0.04 |
| 19 | Restart a node: state root verified on start, catches up | PASS | 4.31 |
| 20 | Delayed messages (400 ms on every node2 send): network keeps agreeing | PASS | 20.72 |
| 21 | Database interruption: process aborted inside the commit of a block; restart recovers last committed state | PASS | 12.92 |
| 22 | Synchronise a new node from genesis (full validation) | PASS | 0.31 |
| 23 | Snapshot: create, verify against a validated block root, reject tampered/untrusted | PASS | 0.01 |
| 24 | Back up, corrupt the database (refused on start), restore with checksum verification, resync | PASS | 4.13 |
| 25 | Replay from a validated snapshot and full-chain re-execution audit | PASS | 6.42 |
| 26 | Inspect explorer results (blocks, tx, address index, events, supply) | PASS | 0.0 |
| 27 | Difficulty adjustment observed (target retargeted from genesis value) | PASS | 0.0 |

## 1. Generate configuration and keys — PASS
```json
{
 "accounts": 15,
 "spec": "/tmp/claude-0/-home-user-Aureom-AI/23553bbd-f3eb-56fa-86d6-8b98dae88aae/scratchpad/final-run/pow/network.json"
}
```
## 2. Build and validate genesis — PASS
```json
{
 "genesis_hash": "54dbac23717c8721f56e22bc42c5e07135af80e0973fb456194e6559605e4000",
 "state_root": "accd5872893d23eaa8cc00d6cc3c412badc7864d3e13520889a758acf4fcc896",
 "warnings": [],
 "chain_id": "aureom-dev-pow-1",
 "validation_ok": true
}
```
## 3. Launch three mining nodes — PASS
```json
[
 "started",
 "started",
 "started"
]
```
## 4. Nodes produce and agree on blocks — PASS
```json
{
 "height": 45,
 "ids": {
  "node0": "48ebd6585cd90818535c02fc5452de4de48de10a8b3cae836e7add77d5662850",
  "node1": "48ebd6585cd90818535c02fc5452de4de48de10a8b3cae836e7add77d5662850",
  "node2": "48ebd6585cd90818535c02fc5452de4de48de10a8b3cae836e7add77d5662850"
 }
}
```
## 5. Submit a signed transfer (alice -> bob, 2.5 ADC) — PASS
```json
{
 "txid": "6c03eb745ea828216510582c74cbd2677a0c70f711616e84fe2365cc12fc8151",
 "status": "included",
 "block_height": 49,
 "receipt_status": "success",
 "fee_paid": "2830",
 "bob_before": "500000000000",
 "bob_after": "500002500000"
}
```
## 6. Reject an invalid signature — PASS
```json
{
 "http_status": 400,
 "response": {
  "error": {
   "code": "bad_signature",
   "message": "invalid signature"
  }
 }
}
```
## 7. Reject a replayed transaction (same signed bytes, two nodes) — PASS
```json
{
 "same_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: expected 1, got 0"
   }
  }
 },
 "other_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: expected 1, got 0"
   }
  }
 }
}
```
## 8. Confirmation depth is reported as probabilistic settlement — PASS
```json
{
 "first": {
  "status": "included",
  "confirmations": 3
 },
 "later": {
  "status": "confirmed",
  "confirmations": 14,
  "finality": "probabilistic"
 }
}
```
## 9. API permissions: admin API requires token, is loopback-bound, absent from public port — PASS
```json
{
 "admin_no_token": 401,
 "admin_wrong_token": 401,
 "admin_status_with_token": 200,
 "public_port_has_no_admin_routes": 404,
 "admin_listen": "127.0.0.1:18101"
}
```
## 10. Partition node2 from the majority (operator bans via admin API) — PASS
```json
{
 "node0": [
  "269febe72374"
 ],
 "node1": [
  "824f94e9c915"
 ],
 "node2": []
}
```
## 11. Transaction included only on the minority branch — PASS
```json
{
 "minority_status": "included",
 "minority_block": 66,
 "majority_view": "unknown"
}
```
## 12. Competing branches: both sides mine; majority accumulates more work — PASS
```json
{
 "majority": {
  "height": 84,
  "work": "12206080",
  "tip": "06b3ec554c11be49"
 },
 "minority": {
  "height": 68,
  "work": "4079616",
  "tip": "0273ae5e567938ad"
 }
}
```
## 13. Reconnect: node2 reorganises to the chain with most cumulative work; its tx returns to the mempool and is re-validated — PASS
```json
{
 "node2_reorgs": [
  {
   "at_ms": 1795786225058,
   "depth": 8,
   "dropped": 0,
   "fork_height": 62,
   "new_tip": "99119beb34b4442b9156e46ed2a25b5acf4fc0613176b6c82dd138299e37daf1",
   "old_tip": "5951da1f28aba2686413936034375faae0ebcae287b32a1ca8a78383479628d0",
   "returned_to_mempool": 1
  }
 ],
 "minority_tx_after_reorg": {
  "status": "pending",
  "block_height": null,
  "reason": null
 }
}
```
## 14. Disconnected-branch transaction re-included on the winning chain exactly once — PASS
```json
{
 "status": "included",
 "block_height": 87
}
```
## 15. Malformed block from an authenticated peer: rejected, peer banned — PASS
```json
{
 "disconnect_reason": "banned: malformed block: length 1734439522 exceeds maximum 64",
 "banned_ids": [
  "127.0.0.1:53310",
  "258cbfd7a94ae36d"
 ]
}
```
## 16. Block with an easier-than-required target (valid PoW for the wrong target): rejected, peer banned — PASS
```json
{
 "disconnect_reason": "banned: invalid header: target mismatch: expected fffffffffffffffffffffffffffffffffffffffffffffffffffffffffff, got ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
 "tip_unchanged_by_injection": true
}
```
## 17. Block whose hash does not meet its target: rejected, peer banned — PASS
```json
{
 "disconnect_reason": "banned: invalid header: proof of work does not meet target"
}
```
## 18. Oversized length prefix (2 GiB frame claim): connection dropped without allocation, node unaffected — PASS
```json
{
 "result": "connection closed (ConnectionError)",
 "node_still_healthy": true
}
```
## 19. Restart a node: state root verified on start, catches up — PASS
```json
{
 "height_before": 87,
 "after": {
  "node1": 90
 },
 "state_root_verified_on_start": true
}
```
## 20. Delayed messages (400 ms on every node2 send): network keeps agreeing — PASS
```json
{
 "heights_under_delay": {
  "node0": 99,
  "node1": 99,
  "node2": 99
 },
 "fault_alert": [
  {
   "code": "fault_injection_active",
   "level": "warning",
   "message": "p2p_delay_ms=400"
  }
 ],
 "agreement": {
  "height": 96,
  "ids": {
   "node0": "1ee5c12f98db4a54fd1271fa892477d6f3b065ec64cb40dfd40c0529888fce5b",
   "node1": "1ee5c12f98db4a54fd1271fa892477d6f3b065ec64cb40dfd40c0529888fce5b",
   "node2": "1ee5c12f98db4a54fd1271fa892477d6f3b065ec64cb40dfd40c0529888fce5b"
  }
 }
}
```
## 21. Database interruption: process aborted inside the commit of a block; restart recovers last committed state — PASS
```json
{
 "abort_height": 102,
 "aborted": true,
 "height_on_restart": 101,
 "recovered": {
  "node0": 102,
  "node1": 101
 }
}
```
## 22. Synchronise a new node from genesis (full validation) — PASS
```json
{
 "agreement": {
  "height": 100,
  "ids": {
   "node0": "e00cc6925bbe2ee16fa1df719b02549e081759e2a014ca56102b1eabb6aae3fd",
   "node3": "e00cc6925bbe2ee16fa1df719b02549e081759e2a014ca56102b1eabb6aae3fd"
  }
 },
 "sync": {
  "local_height": 102,
  "best_known_height": 102,
  "trust_anchor": {
   "hash": "6cd484a54b3fc2aaa356aec7bb6132638f930fd62b0c53017df8c6444b9bb217",
   "height": 0,
   "kind": "genesis",
   "note": "full validation from the genesis block (hash bound to the genesis document)"
  },
  "validation": "full: proof of work, targets, timestamps, signatures, state transitions"
 }
}
```
## 23. Snapshot: create, verify against a validated block root, reject tampered/untrusted — PASS
```json
{
 "snapshot": {
  "height": 102,
  "state_root": "ff1cc2a097d3feb1370c7c08ff8d4b77c59d746c368f24197989fbad63b61107",
  "bytes": 1578
 },
 "verify_against_validated_block": true,
 "tampered_file": {
  "error": "digest mismatch (file corrupted or tampered)",
  "ok": false
 },
 "untrusted_root": {
  "ok": false,
  "problems": [
   "state root does not match the trusted root"
  ]
 }
}
```
## 24. Back up, corrupt the database (refused on start), restore with checksum verification, resync — PASS
```json
{
 "backup": {
  "tip_height": 102
 },
 "corrupt_db_refused": true,
 "restore": {
  "restored": "node2",
  "tip_height": 102,
  "verified_checksums": 1
 },
 "heights": {
  "node0": 105,
  "node1": 105,
  "node2": 105,
  "node3": 105
 }
}
```
## 25. Replay from a validated snapshot and full-chain re-execution audit — PASS
```json
{
 "replay": {
  "ok": true,
  "repaired": false,
  "replayed_to": 113,
  "snapshot_height": 105,
  "state_root": "5c5d17edcb1568d8443d1cd28ff36e8f95f343567a7605becab08ccbf58c3dae",
  "stored_state_matched": true
 },
 "verify_chain": {
  "ok": true,
  "profile": "pow",
  "state_root": "5c5d17edcb1568d8443d1cd28ff36e8f95f343567a7605becab08ccbf58c3dae",
  "verified_height": 113
 }
}
```
## 26. Inspect explorer results (blocks, tx, address index, events, supply) — PASS
```json
{
 "latest_blocks": [
  [
   113,
   "1784d8a99b24e3ca",
   0
  ],
  [
   112,
   "dfe19f7923103d31",
   0
  ],
  [
   111,
   "d0ab9b76e13ff420",
   0
  ],
  [
   110,
   "33437bd15c008c28",
   0
  ],
  [
   109,
   "529c9e7d8b6d69b2",
   0
  ]
 ],
 "tx_status": "confirmed",
 "tx_block": 49,
 "alice_tx_count_indexed": 1,
 "recent_event_kinds": [
  "reward"
 ],
 "supply": {
  "total": "1817949998868",
  "genesis": "1812300000000",
  "minted": "5650000000",
  "burned": "1132",
  "circulating": "1612499998868",
  "reconciled": true,
  "tokens_reconciled": true
 }
}
```
## 27. Difficulty adjustment observed (target retargeted from genesis value) — PASS
```json
{
 "height": 113,
 "target": "00000eb98c7e28240b780346dc5d63886594af4f0d844d013a92a305532617c0",
 "difficulty": "1139384",
 "target_block_time_ms": 2000,
 "retarget_interval": 20,
 "recent_block_times_ms": [
  1403,
  1797,
  4860,
  1678,
  3574,
  2596,
  7732,
  6323,
  1871,
  1470,
  133,
  2861,
  945,
  738,
  356,
  689,
  263,
  1616,
  303,
  495
 ]
}
```
