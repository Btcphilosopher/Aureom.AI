# Demo results: pos

24/24 steps passed in 223.5 s (2026-11-27T13:35:00Z).

| # | step | result | seconds |
|---|---|---|---|
| 1 | Generate configuration and keys (accounts, CometBFT node + validator keys) | PASS | 0.34 |
| 2 | Build genesis; validate genesis and CometBFT genesis consistency across all nodes | PASS | 0.19 |
| 3 | Launch four validators | PASS | 0.87 |
| 4 | Validators commit blocks and agree | PASS | 7.08 |
| 5 | Submit a signed transfer (alice -> bob, 2.5 ADC) | PASS | 1.02 |
| 6 | Reject an invalid signature | PASS | 0.02 |
| 7 | Reject a replayed transaction (same signed bytes, two nodes) | PASS | 0.0 |
| 8 | API permissions: admin API requires token, is loopback-bound, absent from public port | PASS | 0.0 |
| 9 | Finality: committed transaction reported as finalised (BFT), not probabilistic | PASS | 0.0 |
| 10 | Scheduled block rewards paid to signing validators; supply reconciles | PASS | 4.03 |
| 11 | Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up | PASS | 6.01 |
| 12 | Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers | PASS | 3.02 |
| 13 | Restart a validator: state root verified against committed app hash; rejoins | PASS | 3.42 |
| 14 | Snapshot: create, verify against a validated block root, reject tampered/untrusted | PASS | 0.01 |
| 15 | Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up | PASS | 3.85 |
| 16 | Replay stored blocks from a validated snapshot; full re-execution audit from genesis | PASS | 5.42 |
| 17 | Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing | PASS | 16.7 |
| 18 | Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) | PASS | 12.11 |
| 19 | Restart the 2nd validator: quorum restored, commits resume | PASS | 8.25 |
| 20 | Downtime: node3 (offline) exceeds missed-block limit -> jailed, 1% downtime penalty, removed from set (not tombstoned) | PASS | 46.04 |
| 21 | Unjail: refused before jail period ends; accepted after; validator re-enters the set | PASS | 70.17 |
| 22 | New node synchronises, its operator bonds stake; it joins the validator set at the next epoch and signs | PASS | 33.38 |
| 23 | Unbonding: stake moves to an unbonding entry (still slashable) that pays out after unbonding_period_blocks | PASS | 0.52 |
| 24 | Inspect explorer results (blocks, tx, address index, events, supply) | PASS | 0.0 |

## 1. Generate configuration and keys (accounts, CometBFT node + validator keys) — PASS
```json
{
 "keys": 17
}
```
## 2. Build genesis; validate genesis and CometBFT genesis consistency across all nodes — PASS
```json
{
 "genesis_hash": "dc472af551180f6521306449cd95277d2a3c8a1f721586aa21003a236e7e62c2",
 "state_root": "124cee811a9545018cdea0715bfe2949d519fe12ec840c8cfe50b6ec70b56891",
 "warnings": [
  "4 validators: tolerates up to 1 Byzantine (n >= 3f+1); liveness lost if more than 1 of equal power are offline"
 ],
 "chain_id": "aureom-dev-pos-1",
 "validation": [
  {
   "check": "node0: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node1: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node2: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node3: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "all CometBFT genesis files identical",
   "ok": true,
   "detail": "38e9d164bb050da749b3ea3439ba53eceac7a814ac388bdc9bff3c42aacbd2c4"
  },
  {
   "check": "no validator key is shared between nodes",
   "ok": true,
   "detail": ""
  }
 ],
 "ok": true
}
```
## 3. Launch four validators — PASS
```json
[
 "started",
 "started",
 "started",
 "started"
]
```
## 4. Validators commit blocks and agree — PASS
```json
{
 "height": 3,
 "ids": {
  "node0": "68d0a09f7be24f98c03368de2eb4d6424ec9370ebe4d168ae142d4f154117ac0",
  "node1": "68d0a09f7be24f98c03368de2eb4d6424ec9370ebe4d168ae142d4f154117ac0",
  "node2": "68d0a09f7be24f98c03368de2eb4d6424ec9370ebe4d168ae142d4f154117ac0",
  "node3": "68d0a09f7be24f98c03368de2eb4d6424ec9370ebe4d168ae142d4f154117ac0"
 }
}
```
## 5. Submit a signed transfer (alice -> bob, 2.5 ADC) — PASS
```json
{
 "txid": "e46e5de216757e6d07a9d85183c216993c7b2fc9378121eacf1cefe8afae3d93",
 "status": "finalised",
 "block_height": 6,
 "receipt_status": "success",
 "fee_paid": "2830",
 "bob_before": "500000000000",
 "bob_after": "500002500000"
}
```
## 6. Reject an invalid signature — PASS
```json
{
 "http_status": 400,
 "response": {
  "error": {
   "code": "bad_signature",
   "message": "invalid signature"
  }
 }
}
```
## 7. Reject a replayed transaction (same signed bytes, two nodes) — PASS
```json
{
 "same_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: account nonce is 1, transaction nonce 0 was already used"
   }
  }
 },
 "other_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: account nonce is 1, transaction nonce 0 was already used"
   }
  }
 }
}
```
## 8. API permissions: admin API requires token, is loopback-bound, absent from public port — PASS
```json
{
 "admin_no_token": 401,
 "admin_wrong_token": 401,
 "admin_status_with_token": 200,
 "public_port_has_no_admin_routes": 404,
 "admin_listen": "127.0.0.1:18201"
}
```
## 9. Finality: committed transaction reported as finalised (BFT), not probabilistic — PASS
```json
{
 "status": "finalised",
 "finality": "final"
}
```
## 10. Scheduled block rewards paid to signing validators; supply reconciles — PASS
```json
{
 "op1_balance_delta": 3750000,
 "minted_so_far": "40000000",
 "reconciled": true
}
```
## 11. Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up — PASS
```json
{
 "node0_height_during_pause": [
  9,
  11
 ],
 "node1_caught_up": {
  "node0": 11,
  "node1": 10
 }
}
```
## 12. Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers — PASS
```json
{
 "abort_height": 13,
 "aborted": true,
 "app_height_on_restart": 12,
 "after": {
  "node0": 13,
  "node1": 12
 },
 "note": "CometBFT handshake replayed the uncommitted block to the application"
}
```
## 13. Restart a validator: state root verified against committed app hash; rejoins — PASS
```json
{
 "state_root_verified_on_start": true,
 "heights": {
  "node0": 13,
  "node2": 13
 }
}
```
## 14. Snapshot: create, verify against a validated block root, reject tampered/untrusted — PASS
```json
{
 "snapshot": {
  "height": 13,
  "state_root": "e5b794edeacfacbb54dbb338b43402779493c8f9729c2c4463975520817f4c70",
  "bytes": 2248
 },
 "verify_against_validated_block": true,
 "tampered_file": {
  "error": "digest mismatch (file corrupted or tampered)",
  "ok": false
 },
 "untrusted_root": {
  "ok": false,
  "problems": [
   "state root does not match the trusted root"
  ]
 }
}
```
## 15. Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up — PASS
```json
{
 "backup_height": 13,
 "corrupt_db_refused": true,
 "restore": {
  "restored": "node2",
  "tip_height": 13,
  "verified_checksums": 1
 },
 "heights": {
  "node0": 15,
  "node1": 14,
  "node2": 13,
  "node3": 14
 }
}
```
## 16. Replay stored blocks from a validated snapshot; full re-execution audit from genesis — PASS
```json
{
 "replay": {
  "ok": true,
  "repaired": false,
  "replayed_to": 18,
  "snapshot_height": 15,
  "state_root": "27d90e3c95bcc25d1f0c2a4b00f00d6138427e85ce2a907f18fbf03e74fe7389",
  "stored_state_matched": true
 },
 "verify_chain": {
  "ok": true,
  "profile": "pos",
  "state_root": "27d90e3c95bcc25d1f0c2a4b00f00d6138427e85ce2a907f18fbf03e74fe7389",
  "verified_height": 18
 }
}
```
## 17. Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing — PASS
```json
{
 "stopped": {
  "node": "node3",
  "status": "stopped"
 },
 "progress": {
  "from": 19,
  "to": 22
 },
 "last_commit": {
  "height": 21,
  "signed_power": 30000,
  "signers": 3,
  "total_power": 40000,
  "validators": 4,
  "total_power_now": 40000
 }
}
```
## 18. Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) — PASS
```json
{
 "stopped": {
  "node": "node2",
  "status": "stopped"
 },
 "observation": {
  "height_before": 22,
  "height_after": 22,
  "seconds": 12,
  "advanced": 0
 },
 "round_state": "23/0/4"
}
```
## 19. Restart the 2nd validator: quorum restored, commits resume — PASS
```json
{
 "started": "started",
 "progress": {
  "from": 22,
  "to": 25
 }
}
```
## 20. Downtime: node3 (offline) exceeds missed-block limit -> jailed, 1% downtime penalty, removed from set (not tombstoned) — PASS
```json
{
 "node3": {
  "status": "jailed",
  "power": 0,
  "bonded": "9900000000",
  "jailed_until": 96
 },
 "total_power": 30000,
 "slash_events": [
  {
   "attrs": {
    "burned": "100000000",
    "jailed_until": "96",
    "operator": "aurd1cdda8khv653s46upl3wjmx35jtty765zdyeh2z",
    "reason": "downtime"
   },
   "height": 46,
   "kind": "slash",
   "source": "on-chain receipt",
   "txid": null
  }
 ]
}
```
## 21. Unjail: refused before jail period ends; accepted after; validator re-enters the set — PASS
```json
{
 "unjail_before_expiry": "JAILED",
 "unjail_after_expiry": "success",
 "node3_now": {
  "status": "active",
  "power": 9900
 }
}
```
## 22. New node synchronises, its operator bonds stake; it joins the validator set at the next epoch and signs — PASS
```json
{
 "create_receipt": "success",
 "included_at": 103,
 "node4": {
  "status": "active",
  "power": 20000,
  "bonded": "20000000000"
 },
 "epoch_length": 20,
 "participation": {
  "height": 122,
  "signed_power": 59900,
  "signers": 5,
  "total_power": 59900,
  "validators": 5,
  "total_power_now": 59900
 },
 "sync": {
  "hash": "dc472af551180f6521306449cd95277d2a3c8a1f721586aa21003a236e7e62c2",
  "height": 0,
  "kind": "genesis",
  "note": "blocksync from genesis: commits verified from the genesis validator set. A recent trusted checkpoint is required to rule out long-range attacks by unbonded keys."
 }
}
```
## 23. Unbonding: stake moves to an unbonding entry (still slashable) that pays out after unbonding_period_blocks — PASS
```json
{
 "receipt": "success",
 "unbonding": "5000000000",
 "bonded": "15000000000",
 "power_now": 15000,
 "completes_at": "324"
}
```
## 24. Inspect explorer results (blocks, tx, address index, events, supply) — PASS
```json
{
 "latest_blocks": [
  [
   124,
   "a09d7836ba560787",
   1
  ],
  [
   123,
   "a698646fb0d770e2",
   0
  ],
  [
   122,
   "e55f89b3b5a3ee48",
   0
  ],
  [
   121,
   "7a449ca5e0fb2bfa",
   0
  ],
  [
   120,
   "b31dff10083eb70b",
   0
  ]
 ],
 "tx_status": "finalised",
 "tx_block": 6,
 "alice_tx_count_indexed": 2,
 "recent_event_kinds": [
  "reward",
  "validator_update"
 ],
 "supply": {
  "total": "1856814996746",
  "genesis": "1856300000000",
  "minted": "615000000",
  "burned": "100003254",
  "circulating": "1596914996746",
  "reconciled": true,
  "tokens_reconciled": true
 }
}
```
