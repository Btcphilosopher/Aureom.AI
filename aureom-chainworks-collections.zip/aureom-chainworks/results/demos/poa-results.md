# Demo results: poa

23/23 steps passed in 81.7 s (2026-11-27T13:36:22Z).

| # | step | result | seconds |
|---|---|---|---|
| 1 | Generate configuration and keys (accounts, CometBFT node + validator keys) | PASS | 0.31 |
| 2 | Build genesis; validate genesis and CometBFT genesis consistency across all nodes | PASS | 0.21 |
| 3 | Launch four validators | PASS | 0.87 |
| 4 | Validators commit blocks and agree | PASS | 7.08 |
| 5 | Submit a signed transfer (alice -> bob, 2.5 ADC) | PASS | 1.02 |
| 6 | Reject an invalid signature | PASS | 0.02 |
| 7 | Reject a replayed transaction (same signed bytes, two nodes) | PASS | 0.0 |
| 8 | API permissions: admin API requires token, is loopback-bound, absent from public port | PASS | 0.0 |
| 9 | No staking on PoA: validator_create rejected at submission | PASS | 0.02 |
| 10 | Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up | PASS | 6.02 |
| 11 | Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers | PASS | 3.62 |
| 12 | Restart a validator: state root verified against committed app hash; rejoins | PASS | 3.31 |
| 13 | Snapshot: create, verify against a validated block root, reject tampered/untrusted | PASS | 0.01 |
| 14 | Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up | PASS | 3.84 |
| 15 | Replay stored blocks from a validated snapshot; full re-execution audit from genesis | PASS | 5.32 |
| 16 | Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing | PASS | 8.25 |
| 17 | Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) | PASS | 12.21 |
| 18 | Restart the 2nd validator: quorum restored, commits resume | PASS | 5.24 |
| 19 | Restart the 4th authority | PASS | 0.21 |
| 20 | Unauthorised validator-set change (non-authority proposes adding an authority): rejected by the state machine | PASS | 4.04 |
| 21 | Authorised validator-set change: authority proposes, others approve with separately signed txs; executes at > 2/3; node4 signs | PASS | 9.12 |
| 22 | Key rotation: authority rotates its consensus key (signed by operator key); old key stops counting; node restarts with new key and signs | PASS | 9.98 |
| 23 | Inspect explorer results (blocks, tx, address index, events, supply) | PASS | 0.0 |

## 1. Generate configuration and keys (accounts, CometBFT node + validator keys) — PASS
```json
{
 "keys": 17
}
```
## 2. Build genesis; validate genesis and CometBFT genesis consistency across all nodes — PASS
```json
{
 "genesis_hash": "c94860650db8cb6b54dc104e524eec7f28b6284e4f173349fb01d8ec6caf032e",
 "state_root": "9d3ba804763f3d40729ef866162da1112a5c0c866a183f3d77350cdbb98d3273",
 "warnings": [
  "4 validators: tolerates up to 1 Byzantine (n >= 3f+1); liveness lost if more than 1 of equal power are offline"
 ],
 "chain_id": "aureom-dev-poa-1",
 "validation": [
  {
   "check": "node0: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node1: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node2: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "node3: CometBFT app_state hashes to the Aureom genesis",
   "ok": true,
   "detail": ""
  },
  {
   "check": "all CometBFT genesis files identical",
   "ok": true,
   "detail": "6b36eb47238288214c930fbdf1ec9688caf30f3e4b5d56b35c7b7d95370b5862"
  },
  {
   "check": "no validator key is shared between nodes",
   "ok": true,
   "detail": ""
  }
 ],
 "ok": true
}
```
## 3. Launch four validators — PASS
```json
[
 "started",
 "started",
 "started",
 "started"
]
```
## 4. Validators commit blocks and agree — PASS
```json
{
 "height": 3,
 "ids": {
  "node0": "8aa94284e2693dba07d5dd239c38f2617347381fd6d990919317a5ac4cdcf239",
  "node1": "8aa94284e2693dba07d5dd239c38f2617347381fd6d990919317a5ac4cdcf239",
  "node2": "8aa94284e2693dba07d5dd239c38f2617347381fd6d990919317a5ac4cdcf239",
  "node3": "8aa94284e2693dba07d5dd239c38f2617347381fd6d990919317a5ac4cdcf239"
 }
}
```
## 5. Submit a signed transfer (alice -> bob, 2.5 ADC) — PASS
```json
{
 "txid": "6dfd120690665e2d07691280a6282cd3d7bbae015896835cd02c57d94a0ed211",
 "status": "finalised",
 "block_height": 6,
 "receipt_status": "success",
 "fee_paid": "2830",
 "bob_before": "500000000000",
 "bob_after": "500002500000"
}
```
## 6. Reject an invalid signature — PASS
```json
{
 "http_status": 400,
 "response": {
  "error": {
   "code": "bad_signature",
   "message": "invalid signature"
  }
 }
}
```
## 7. Reject a replayed transaction (same signed bytes, two nodes) — PASS
```json
{
 "same_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: account nonce is 1, transaction nonce 0 was already used"
   }
  }
 },
 "other_node": {
  "http_status": 400,
  "response": {
   "error": {
    "code": "bad_nonce",
    "message": "bad nonce: account nonce is 1, transaction nonce 0 was already used"
   }
  }
 }
}
```
## 8. API permissions: admin API requires token, is loopback-bound, absent from public port — PASS
```json
{
 "admin_no_token": 401,
 "admin_wrong_token": 401,
 "admin_status_with_token": 200,
 "public_port_has_no_admin_routes": 404,
 "admin_listen": "127.0.0.1:18301"
}
```
## 9. No staking on PoA: validator_create rejected at submission — PASS
```json
[
 400,
 {
  "error": {
   "code": "unsupported_action",
   "message": "action not supported on this network: staking actions exist only on proof-of-stake networks"
  }
 }
]
```
## 10. Delayed messages: node1's consensus process frozen 6 s (SIGSTOP), then resumed; it catches up — PASS
```json
{
 "node0_height_during_pause": [
  6,
  8
 ],
 "node1_caught_up": {
  "node0": 8,
  "node1": 7
 }
}
```
## 11. Database interruption: application aborted inside a block commit; restart + CometBFT handshake replay recovers — PASS
```json
{
 "abort_height": 10,
 "aborted": true,
 "app_height_on_restart": 9,
 "after": {
  "node0": 10,
  "node1": 9
 },
 "note": "CometBFT handshake replayed the uncommitted block to the application"
}
```
## 12. Restart a validator: state root verified against committed app hash; rejoins — PASS
```json
{
 "state_root_verified_on_start": true,
 "heights": {
  "node0": 12,
  "node2": 10
 }
}
```
## 13. Snapshot: create, verify against a validated block root, reject tampered/untrusted — PASS
```json
{
 "snapshot": {
  "height": 12,
  "state_root": "d21f42de48c9bc434bea331cc369d810f8a16d98efe2f9e68d5b7b810f0bb6b9",
  "bytes": 2248
 },
 "verify_against_validated_block": true,
 "tampered_file": {
  "error": "digest mismatch (file corrupted or tampered)",
  "ok": false
 },
 "untrusted_root": {
  "ok": false,
  "problems": [
   "state root does not match the trusted root"
  ]
 }
}
```
## 14. Back up (app DB + CometBFT data), corrupt, restore with checksums and signing-state protection, catch up — PASS
```json
{
 "backup_height": 10,
 "corrupt_db_refused": true,
 "restore": {
  "restored": "node2",
  "tip_height": 10,
  "verified_checksums": 1
 },
 "heights": {
  "node0": 12,
  "node1": 12,
  "node2": 10,
  "node3": 12
 }
}
```
## 15. Replay stored blocks from a validated snapshot; full re-execution audit from genesis — PASS
```json
{
 "replay": {
  "ok": true,
  "repaired": false,
  "replayed_to": 16,
  "snapshot_height": 12,
  "state_root": "d21f42de48c9bc434bea331cc369d810f8a16d98efe2f9e68d5b7b810f0bb6b9",
  "stored_state_matched": true
 },
 "verify_chain": {
  "ok": true,
  "profile": "poa",
  "state_root": "d21f42de48c9bc434bea331cc369d810f8a16d98efe2f9e68d5b7b810f0bb6b9",
  "verified_height": 16
 }
}
```
## 16. Stop 1 of 4 equal-power validators (75% online > 2/3): chain keeps committing — PASS
```json
{
 "stopped": {
  "node": "node3",
  "status": "stopped"
 },
 "progress": {
  "from": 16,
  "to": 19
 },
 "last_commit": {
  "height": 18,
  "signed_power": 30,
  "signers": 3,
  "total_power": 40,
  "validators": 4,
  "total_power_now": 40
 }
}
```
## 17. Stop a 2nd validator (50% online, not > 2/3): no block can be committed (liveness lost, safety kept) — PASS
```json
{
 "stopped": {
  "node": "node2",
  "status": "stopped"
 },
 "observation": {
  "height_before": 19,
  "height_after": 19,
  "seconds": 12,
  "advanced": 0
 },
 "round_state": "20/0/4"
}
```
## 18. Restart the 2nd validator: quorum restored, commits resume — PASS
```json
{
 "started": "started",
 "progress": {
  "from": 19,
  "to": 22
 }
}
```
## 19. Restart the 4th authority — PASS
```json
{
 "started": "started",
 "sync": {
  "height": 14,
  "ids": {
   "node0": "1aa9aa5b63008643ff7963427e477cfc7e7617610e4b6ce636553a1573897c20",
   "node3": "1aa9aa5b63008643ff7963427e477cfc7e7617610e4b6ce636553a1573897c20"
  }
 }
}
```
## 20. Unauthorised validator-set change (non-authority proposes adding an authority): rejected by the state machine — PASS
```json
{
 "receipt": "failed",
 "error": "UNAUTHORIZED",
 "validators": 4
}
```
## 21. Authorised validator-set change: authority proposes, others approve with separately signed txs; executes at > 2/3; node4 signs — PASS
```json
{
 "after_2_of_4": {
  "status": "pending",
  "approving_power": 20,
  "total_power": 40
 },
 "duplicate_approval": "ALREADY_EXISTS",
 "after_3_of_4": "executed",
 "executed_height": 27,
 "validators_active": 5,
 "participation": {
  "height": 29,
  "signed_power": 50,
  "signers": 5,
  "total_power": 50,
  "validators": 5,
  "total_power_now": 50
 }
}
```
## 22. Key rotation: authority rotates its consensus key (signed by operator key); old key stops counting; node restarts with new key and signs — PASS
```json
{
 "rotate_receipt": "success",
 "signing_with_old_key_after_activation": false,
 "new_key_active": true,
 "signing_with_new_key": true,
 "participation": {
  "height": 36,
  "signed_power": 50,
  "signers": 5,
  "total_power": 50,
  "validators": 5,
  "total_power_now": 50
 }
}
```
## 23. Inspect explorer results (blocks, tx, address index, events, supply) — PASS
```json
{
 "latest_blocks": [
  [
   37,
   "a7350618fa99c522",
   0
  ],
  [
   36,
   "d1a04ca5f33d4102",
   0
  ],
  [
   35,
   "9d1c0461cd3c9335",
   0
  ],
  [
   34,
   "eb22d1303b8ffccf",
   0
  ],
  [
   33,
   "78ded70103c02b0c",
   0
  ]
 ],
 "tx_status": "finalised",
 "tx_block": 6,
 "alice_tx_count_indexed": 1,
 "recent_event_kinds": [
  "gov",
  "transfer",
  "validator_update"
 ],
 "supply": {
  "total": "1816299996046",
  "genesis": "1816300000000",
  "minted": "0",
  "burned": "3954",
  "circulating": "1547966662712",
  "reconciled": true,
  "tokens_reconciled": true
 }
}
```
