# Demo results: assets

18/18 steps passed in 65.7 s (2026-11-27T13:37:28Z).

| # | step | result | seconds |
|---|---|---|---|
| 1 | Launch the Aureom Development Network (PoA, fixed-supply native coin, treasury, vesting) | PASS | 6.37 |
| 2 | Verify genesis supply against the genesis document | PASS | 0.0 |
| 3 | Transfer the native coin | PASS | 1.02 |
| 4 | Pay transaction fees: 20% burned (supply decreases), 80% to the block proposer | PASS | 0.0 |
| 5 | Define token -> review permissions -> sign -> submit -> verify (capped, mintable by issuer, no pause/freeze) | PASS | 1.53 |
| 6 | Enforce the token supply cap | PASS | 2.55 |
| 7 | Reject unauthorised minting (token and native coin) | PASS | 1.04 |
| 8 | Spoofing resistance: a second token with an identical symbol/name gets a distinct token id | PASS | 1.52 |
| 9 | Distribute the token: reviewed preview (duplicates/invalid rejected), interrupted run, resume, no duplicate payments | PASS | 1.1 |
| 10 | Claim-based distribution (Merkle commitment): claim once; double claim and inflated claim rejected | PASS | 5.11 |
| 11 | Vesting: locked before the cliff; linear unlock by block height after it | PASS | 13.14 |
| 12 | Treasury: budget, proposal by one signer, approval by another (separately signed), settlement on-chain, report | PASS | 4.08 |
| 13 | Reconcile supply against state transitions (genesis - burns = total; token supply = holder balances) | PASS | 0.01 |
| 14 | Restart recovery preserves balances and supply invariants | PASS | 0.31 |
| 15 | Optional PostgreSQL explorer index (derived, rebuildable) of issuance/burn/admin events | PASS | 3.25 |
| 16 | Export wallet connection details, asset documentation and the deployment package (secret scan, checksums) | PASS | 0.05 |
| 17 | Management console against the live network: manifest, proxied reads; admin proxy and non-tx POST refused | PASS | 23.92 |
| 18 | Export a consensus migration proposal (new network; no implied continuity) | PASS | 0.01 |

## 1. Launch the Aureom Development Network (PoA, fixed-supply native coin, treasury, vesting) — PASS
```json
{
 "genesis_hash": "a888f69298c6db82a573ce50cec83b6ad6805cfe67d6dc3f221c4842f9755cdc",
 "validation_ok": true,
 "heights": {
  "node0": 3,
  "node1": 3,
  "node2": 3,
  "node3": 3
 },
 "policy": "fixed (no minting authority)"
}
```
## 2. Verify genesis supply against the genesis document — PASS
```json
{
 "genesis_document_sum": "1816300000000",
 "node_reported_total": "1816300000000",
 "genesis": "1816300000000",
 "minted": "0",
 "locked_vesting": "100000000000",
 "treasury": "200000000000",
 "circulating": "1516300000000",
 "reconciled": true
}
```
## 3. Transfer the native coin — PASS
```json
{
 "status": "finalised",
 "dave_delta": 1000000000,
 "receipt": "success"
}
```
## 4. Pay transaction fees: 20% burned (supply decreases), 80% to the block proposer — PASS
```json
{
 "fee_paid": "2820",
 "burned": "564",
 "to_proposer": "2256",
 "burn_bps": 2000,
 "supply_burned_total": "564",
 "total_now": "1816299999436",
 "recent_proposer_payouts": [
  {
   "amount": "2256",
   "to": "aurd1wqayd0w89psh74dlyewn7ypmjmaaefk2llkt7e"
  }
 ]
}
```
## 5. Define token -> review permissions -> sign -> submit -> verify (capped, mintable by issuer, no pause/freeze) — PASS
```json
{
 "review_before_signing": {
  "summary": "create token GLDX (admin: None)",
  "warnings": [
   "no expiry height: this transaction stays valid until its nonce is used"
  ]
 },
 "status": "finalised",
 "token_id": "aurdtok1vapjjn5yatq3e29zwqr6tzy0x7wn7a88kpm3jh",
 "on_chain": {
  "symbol": "GLDX",
  "supply": "10000000",
  "max_supply": "100000000",
  "mint_authority": "aurd1grxj65hygadtc73fxmra82je282lwjj2hey2cm",
  "admin": null,
  "pausable": false,
  "freezable": false
 }
}
```
## 6. Enforce the token supply cap — PASS
```json
{
 "mint_to_cap": "success",
 "mint_beyond_cap": "SUPPLY_CAP",
 "supply": "100000000"
}
```
## 7. Reject unauthorised minting (token and native coin) — PASS
```json
{
 "token_mint_by_non_authority": "UNAUTHORIZED",
 "native_mint_on_fixed_supply": {
  "http": 400,
  "code": "unsupported_action"
 }
}
```
## 8. Spoofing resistance: a second token with an identical symbol/name gets a distinct token id — PASS
```json
{
 "tokens_with_symbol_GLDX": [
  {
   "token_id": "aurdtok1xc075qfhpzzppqmv4urvazdv5kchenasqwh7ws",
   "creator": "aurd1j9xw8ymsa2lvzm05s9sm2knqg42g046cxfyshy",
   "supply": "500"
  },
  {
   "token_id": "aurdtok1vapjjn5yatq3e29zwqr6tzy0x7wn7a88kpm3jh",
   "creator": "aurd1grxj65hygadtc73fxmra82je282lwjj2hey2cm",
   "supply": "100000000"
  }
 ],
 "ids_distinct": true,
 "identify_by": "token_id (symbols and names are issuer-supplied labels)"
}
```
## 9. Distribute the token: reviewed preview (duplicates/invalid rejected), interrupted run, resume, no duplicate payments — PASS
```json
{
 "rejected_plan_problems": [
  "row 3: duplicate recipient aurd1lszcnm8hje9q20ftwd2kce9tnnhsga57zuhhtr (first at row 0); pass merge_duplicates to combine",
  "row 4: invalid address 'aurd1invalid'"
 ],
 "preview": {
  "amount": "10000",
  "fees": "12840",
  "sender_balance_before": "100000000",
  "sender_balance_after": "99990000"
 },
 "interrupted_run": {
  "interrupted": true,
  "submitted_this_run": 2,
  "journal": "/tmp/claude-0/-home-user-Aureom-AI/23553bbd-f3eb-56fa-86d6-8b98dae88aae/scratchpad/final-run/assets/distributions/gold-airdrop/journal.json"
 },
 "resume": {
  "finalised": 4
 },
 "second_resume": {
  "finalised": 4
 },
 "balance_deltas_equal_plan": true
}
```
## 10. Claim-based distribution (Merkle commitment): claim once; double claim and inflated claim rejected — PASS
```json
{
 "create": "success",
 "claim": "success",
 "double_claim": "ALREADY_CLAIMED",
 "inflated_claim": "BAD_PROOF",
 "remaining_in_escrow": "700000000"
}
```
## 11. Vesting: locked before the cliff; linear unlock by block height after it — PASS
```json
{
 "schedule": {
  "start_height": 0,
  "cliff_height": 20,
  "end_height": 120
 },
 "before_cliff": "INSUFFICIENT_FUNDS",
 "at_height": 23,
 "available_after_cliff": 19176663846,
 "vesting": [
  {
   "cliff_height": 20,
   "end_height": 120,
   "locked": "80833333334",
   "start_height": 0,
   "total": "100000000000",
   "vested": "19166666666"
  }
 ],
 "partial_unlock_spend": "success",
 "spend_beyond_vested": "INSUFFICIENT_FUNDS"
}
```
## 12. Treasury: budget, proposal by one signer, approval by another (separately signed), settlement on-chain, report — PASS
```json
{
 "proposal": 0,
 "after_proposal": "pending (1 of 2)",
 "non_signer_approval": "UNAUTHORIZED",
 "after_second_signer": "executed",
 "carol_received": 1000000000,
 "over_budget_proposal": "budget exceeded for grants: spent/proposed 1000000000 + 60000000000 > 50000000000",
 "report_budgets": {
  "grants": {
   "limit": "50000000000",
   "executed": "1000000000"
  }
 },
 "treasury_balance": "199000000000"
}
```
## 13. Reconcile supply against state transitions (genesis - burns = total; token supply = holder balances) — PASS
```json
{
 "genesis": "1816300000000",
 "burned": "13020",
 "burned_sum_of_fee_receipts": "13020",
 "total": "1816299986980",
 "genesis_minus_burned": "1816299986980",
 "node_reconciled": true,
 "tokens_reconciled": true,
 "token_supply": "100000000",
 "sum_of_holder_balances": "100000000",
 "fee_events_counted": 21
}
```
## 14. Restart recovery preserves balances and supply invariants — PASS
```json
{
 "total_before": "1816299986980",
 "total_after": "1816299986980",
 "reconciled": true
}
```
## 15. Optional PostgreSQL explorer index (derived, rebuildable) of issuance/burn/admin events — PASS
```json
{
 "postgres": "16 (docker)",
 "first_index": {
  "indexed_blocks": 29,
  "from": 1,
  "tip": 29,
  "rolled_back": 0
 },
 "incremental": {
  "indexed_blocks": 0,
  "from": 30,
  "tip": 29,
  "rolled_back": 0
 },
 "rebuild": {
  "indexed_blocks": 29,
  "from": 1,
  "tip": 29,
  "rolled_back": 0
 },
 "counts_blocks_txs_events": [
  29,
  21,
  37
 ],
 "supply_event_kinds": [
  "mint",
  "msig_execute",
  "token_create"
 ]
}
```
## 16. Export wallet connection details, asset documentation and the deployment package (secret scan, checksums) — PASS
```json
{
 "asset_package": {
  "package": "/tmp/claude-0/-home-user-Aureom-AI/23553bbd-f3eb-56fa-86d6-8b98dae88aae/scratchpad/final-run/assets/asset-package",
  "tokens": 2
 },
 "deployment": {
  "files": 34,
  "secret_scan": "clean"
 },
 "checksums_verify": true,
 "wallet_connection": {
  "nodes": [
   {
    "name": "node0",
    "rpc": "http://127.0.0.1:18400"
   },
   {
    "name": "node1",
    "rpc": "http://127.0.0.1:18410"
   },
   {
    "name": "node2",
    "rpc": "http://127.0.0.1:18420"
   },
   {
    "name": "node3",
    "rpc": "http://127.0.0.1:18430"
   }
  ],
  "address_hrp": "aurd",
  "token_hrp": "aurdtok",
  "chain_id": "aureom-devnet-1",
  "decimals": 6,
  "signature_scheme": "ed25519, domain-separated (PROTOCOL.md 5.2)"
 },
 "admin_powers": {
  "policy": "fixed",
  "mint_authority": null,
  "statement": "no account can mint the native coin"
 }
}
```
## 17. Management console against the live network: manifest, proxied reads; admin proxy and non-tx POST refused — PASS
```json
{
 "manifest_nodes": 4,
 "proxied_health": "ok",
 "admin_via_console": 403,
 "post_non_tx": 403,
 "post_bad_body": 400,
 "keys_have_no_secrets": true,
 "screenshots": [
  "accounts.png",
  "assets.png",
  "nodes.png",
  "treasury.png",
  "validators.png"
 ],
 "browser": "{\"errors\":[]}"
}
```
## 18. Export a consensus migration proposal (new network; no implied continuity) — PASS
```json
{
 "checkpoint": {
  "chain_id": "aureom-devnet-1",
  "genesis_hash": "a888f69298c6db82a573ce50cec83b6ad6805cfe67d6dc3f221c4842f9755cdc",
  "height": 47,
  "block_id": "a9089d623f6a6d4cbb53f71ffe7754fe8768d0adbd3060d0c8bfaf824722e13a",
  "state_root": "562ae088e329065a89b04f28b97be1a4416a1ae9a838b121c405ab71e6159af0"
 },
 "accounts_mapped": 14,
 "warnings": [
  "This is a NEW network. It does not inherit the source chain's security, history, finality or validator set.",
  "Validators/authorities for the target must be added before the draft genesis is valid (validators: [])."
 ],
 "tokens": {
  "aurdtok1xc075qfhpzzppqmv4urvazdv5kchenasqwh7ws": 1,
  "aurdtok1vapjjn5yatq3e29zwqr6tzy0x7wn7a88kpm3jh": 5
 }
}
```
