# Demo results: collections

20/20 steps passed in 111.9 s (2026-11-27T14:46:48Z).

| # | step | result | seconds |
|---|---|---|---|
| 1 | Launch a 3-node PoW development network with the collections module and demo marketplace enabled | PASS | 0.69 |
| 2 | Upload media and metadata: content-type sniffing, checksums, alt text, rights; unsafe/invalid uploads rejected; nothing on chain yet | PASS | 0.89 |
| 3 | Storage monitoring: re-fetch every stored copy, compare SHA-256, detect a tampered copy, record maintainer | PASS | 0.05 |
| 4 | Create the collection: wizard -> administrative powers shown -> simulate -> sign (aureom-cli) -> submit -> confirm -> index | PASS | 1.17 |
| 5 | Mint one token -> verify ownership on chain (authoritative) and in the index; duplicate mint request deduplicated | PASS | 1.05 |
| 6 | Unique identifiers: minting an existing token id fails in simulation and on chain (fee charged, owner unchanged) | PASS | 1.05 |
| 7 | Reviewed batch minting: invalid plans rejected, approval required, interrupted run resumed, re-run mints nothing twice | PASS | 7.74 |
| 8 | Optional claim-based distribution: Merkle drop, eligible claim mints, someone else's proof is refused | PASS | 10.24 |
| 9 | Transfer an asset (collector -> buyer), confirmed and indexed | PASS | 3.58 |
| 10 | Reject an unauthorised transfer (mallory): refused in simulation and on chain; owner unchanged; failure indexed | PASS | 1.04 |
| 11 | Inspect and revoke an approval: single-token approval shown with its scope; collection-wide operator flagged as high risk; revoked approval no longer works | PASS | 22.3 |
| 12 | Update permitted metadata: metadata admin creates revision 1 (history kept); stale revision and token holder are refused | PASS | 10.24 |
| 13 | Freeze metadata: preview shows exact reference, freeze signs that hash; further changes rejected (simulation and chain) | PASS | 5.2 |
| 14 | Fixed-price sale: seller listing, buyer review, atomic settlement (price, royalty, platform fee, network fee kept separate), duplicate and replay rejected | PASS | 18.26 |
| 15 | Settlement revalidates ownership: a listing is invalidated when the seller transfers the token away | PASS | 9.69 |
| 16 | Token-gated access: signed single-use challenge + on-chain ownership; impersonation, replay and non-holders refused | PASS | 0.04 |
| 17 | Authenticity claims need evidence and review (off-chain); a ledger entry is not proof of issuer claims | PASS | 0.0 |
| 18 | PoW reorganisation: an index following the minority branch reconciles to the winning chain (conflicting transfer dropped) | PASS | 17.9 |
| 19 | Rebuild the index from chain events: identical ownership and sales; verified against chain state | PASS | 0.27 |
| 20 | Export provenance (JSON + CSV) and check ledger invariants (native, token and NFT reconciliation) | PASS | 0.01 |

## 1. Launch a 3-node PoW development network with the collections module and demo marketplace enabled — PASS
```json
{
 "genesis_hash": "e3447906c331bc23215500ac6282c2a3155266e3f69850d16cae3b777d95aafa",
 "validation_ok": true,
 "modules": {
  "collections": {
   "activation_height": 0,
   "enabled": true,
   "implementation": "native state-machine module (not a smart contract; not ERC-721/ERC-1155 compatible)",
   "marketplace": true,
   "marketplace_fee_bps": 250,
   "marketplace_fee_recipient": "aurd12t7xnpykhj0h7whez978e3m09g32s4ts9djpyk"
  }
 },
 "heights": {
  "node0": 32,
  "node1": 33,
  "node2": 33
 }
}
```
## 2. Upload media and metadata: content-type sniffing, checksums, alt text, rights; unsafe/invalid uploads rejected; nothing on chain yet — PASS
```json
{
 "collection_metadata": "3ae2ba085f936b8a67d3d4d9d66763a865c432e2838ce32b797837b98d56fb4a",
 "token_metadata_docs": 12,
 "token1": {
  "uri": "http://127.0.0.1:8787/media/98c3bb1c5a66bd16de078c5d5f8e4ffae17e414e42e136b0c9b23e24df94c5d7",
  "sha256": "98c3bb1c5a66bd16de078c5d5f8e4ffae17e414e42e136b0c9b23e24df94c5d7",
  "preview": {
   "schema": "aureom-nft-metadata/v1",
   "name": "Harbour at First Light",
   "description": "Tidewater Lanterns no. 1: Digital illustration: 4 small glowing paper lanterns float on dark tidal water beneath a pale moon, their warm reflections streaking toward the viewer; violet hour sky fading to deep sea colours.",
   "image": {
    "uri": "http://127.0.0.1:8787/media/0de0cda496996539e7a27ca068781317fe2c8cf6bc34dbef552138e9a87b8d5e",
    "sha256": "0de0cda496996539e7a27ca068781317fe2c8cf6bc34dbef552138e9a87b8d5e",
    "mime": "image/png",
    "width": 192,
    "height": 192,
    "alt_text": "Digital illustration: 4 small glowing paper lanterns float on dark tidal water beneath a pale moon, their warm reflections streaking toward the viewer; violet hour sky fading to deep sea colours."
   },
   "media": [
    {
     "role": "audio",
     "uri": "http://127.0.0.1:8787/media/d9536a3b75b2f3354dff27efd60b23e1f31262b93372aeebdb7c92f013e0b2df",
     "mime": "audio/wav",
     "sha256": "d9536a3b75b2f3354dff27efd60b23e1f31262b93372aeebdb7c92f013e0b2df"
    },
    {
     "role": "document",
     "uri": "http://127.0.0.1:8787/media/2bc713a0eb474cc663db8da587b64cc667ac90d5a931b910c467b14a9dd29d2d",
     "mime": "application/pdf",
     "sha256": "2bc713a0eb474cc663db8da587b64cc667ac90d5a931b910c467b14a9dd29d2d"
    }
   ],
   "attributes": [
    {
     "trait_type": "Lanterns",
     "value": 4
    },
    {
     "trait_type": "Palette",
     "value": "Violet Hour"
    },
    {
     "trait_type": "Moon",
     "value": "high"
    }
   ],
   "rights": {
    "holder": "Lumen Atelier (fictional studio)",
    "licence": "CC-BY-4.0",
    "licence_uri": "https://creativecommons.org/licenses/by/4.0/",
    "statement": "Original digital illustration by Lumen Atelier (fictional), licensed under CC BY 4.0. Token ownership conveys no copyright.",
    "token_owner_receives_copyright": false,
    "note": "Owning this token is a ledger record of control over the token. It does not transfer copyright, other intellectual-property rights or any physical object unless a separate agreement says so."
   },
   "sha256": "98c3bb1c5a66bd16de078c5d5f8e4ffae17e414e42e136b0c9b23e24df94c5d7"
  }
 },
 "media_types": [
  "application/pdf",
  "audio/wav",
  "image/png",
  "image/svg+xml"
 ],
 "rejected_uploads": {
  "evil.svg": "SVG contains active or external content: script element",
  "photo.png": "file name extension .png does not match detected type image/gif",
  "noalt.png": "an accessibility description (alt text, >= 10 characters) is required for images and video",
  "metadata with e-mail": "possible personal information in a public metadata document: e-mail address \u2014 do not publish personal data; keep it in private storage"
 },
 "collections_on_chain_after_upload": 0,
 "note": "an upload is not a mint: nothing exists on chain yet"
}
```
## 3. Storage monitoring: re-fetch every stored copy, compare SHA-256, detect a tampered copy, record maintainer — PASS
```json
{
 "locations_checked": 29,
 "healthy": 29,
 "tamper_detected": [
  "CONTENT CHANGED: hash mismatch"
 ],
 "after_restore_problems": 0,
 "ipfs_node_available": false,
 "maintainers": [
  "network operator (local disk)"
 ],
 "note": "IPFS integration is optional; with no IPFS node reachable nothing was pinned, and the demo does not claim IPFS persistence"
}
```
## 4. Create the collection: wizard -> administrative powers shown -> simulate -> sign (aureom-cli) -> submit -> confirm -> index — PASS
```json
{
 "derived_before_signing": "aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5",
 "on_chain_id": "aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5",
 "powers_shown_before_signing": [
  {
   "power": "mint new tokens",
   "holder": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
   "limit": "at most 16 tokens ever",
   "risk": "normal"
  },
  {
   "power": "change token metadata",
   "holder": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
   "limit": "recorded revisions until a permanent freeze",
   "risk": "medium"
  },
  {
   "power": "burn own token",
   "holder": "each owner",
   "limit": "holder right; ids never reused",
   "risk": "none"
  },
  {
   "power": "receive royalties on native-marketplace sales",
   "holder": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
   "limit": "500 bps; other marketplaces and direct transfers may ignore it",
   "risk": "none"
  }
 ],
 "review_warnings": [
  "ADMINISTRATIVE POWERS: mint authority=aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf (max supply 16), metadata policy=freezable admin=aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf, admin=nobody pausable=false forced_transfer=false, owner_burn=true, transferable=true",
  "royalty 500 bps to aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf is enforced only by the native Chainworks marketplace",
  "no expiry height: this transaction stays valid until its nonce is used"
 ],
 "simulation": {
  "admissible": true,
  "status": "success",
  "error": null,
  "events": [
   "fee",
   "nft_collection_create"
  ],
  "height": 60,
  "note": "simulated against this node's state at the next height; the real outcome can differ if state changes before inclusion. Nothing was committed or broadcast."
 },
 "request_status": "indexed",
 "roles": {
  "admin": null,
  "creator": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
  "metadata_admin": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
  "mint_authority": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
  "note": "creator, owner, operator, metadata administrator and intellectual-property rights holder are distinct; owning a token transfers no copyright and no physical object",
  "rights_holder": "Lumen Atelier (fictional studio)",
  "royalty_recipient": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf"
 },
 "admin_powers": [
  "mint new tokens",
  "replace token metadata (recorded revisions) until frozen",
  "burn own token (holder right, not an admin power)",
  "reassign or renounce a role"
 ],
 "pausable": false,
 "forced_transfer": false
}
```
## 5. Mint one token -> verify ownership on chain (authoritative) and in the index; duplicate mint request deduplicated — PASS
```json
{
 "status": "indexed",
 "txid": "63b82e89de8798589afa5e95a3144048022d992c290b2d118dc347d0919ffa38",
 "owner": {
  "ref": "aureom:aureom-collections-1:e3447906c331bc23/aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5/1",
  "owner": "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d",
  "burned": false,
  "chain_height": 69,
  "source": "chain (authoritative)",
  "index": {
   "owner": "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d",
   "as_of_height": 69
  },
  "index_agrees": true
 },
 "duplicate_request_deduplicated": true,
 "history": [
  "prepared",
  "validated",
  "signed",
  "submitted",
  "confirmed",
  "indexed"
 ]
}
```
## 6. Unique identifiers: minting an existing token id fails in simulation and on chain (fee charged, owner unchanged) — PASS
```json
{
 "simulation": {
  "admissible": true,
  "status": "failed",
  "error": "ALREADY_EXISTS",
  "events": [
   "fee"
  ],
  "height": 71,
  "note": "simulated against this node's state at the next height; the real outcome can differ if state changes before inclusion. Nothing was committed or broadcast."
 },
 "on_chain_status": "failed",
 "error": "ALREADY_EXISTS",
 "owner_unchanged": "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d"
}
```
## 7. Reviewed batch minting: invalid plans rejected, approval required, interrupted run resumed, re-run mints nothing twice — PASS
```json
{
 "rejected_plan_problems": [
  "row 9: duplicate token_id 3 in plan",
  "row 10: invalid recipient 'nobody-here'",
  "row 11: metadata document '0000000000000000000000000000000000000000000000000000000000000000' not registered (upload is not minting: register the document first)",
  "row 12: token 1 already exists on chain"
 ],
 "over_supply_plan": [
  "supply limit: 1 minted + 20 planned > max_supply 16"
 ],
 "unapproved_run": "batch minting requires --approve <plan_id> of the reviewed plan",
 "plan": {
  "plan_id": "4d229b329ff1a213",
  "chunks": 1,
  "per_recipient": {
   "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d": 4,
   "aurd1zg6mhsu2vn9ux9z5nvhp68g54mwnwxdf5hklcn": 5
  }
 },
 "interrupted": {
  "plan_id": "4d229b329ff1a213",
  "chunks": [
   {
    "chunk": 0,
    "request_id": "req_3cb0c177a0014734",
    "status": "indexed",
    "txid": "b073eb24235c6a486e89ad14522166c8f5f6a4dc4f6a534e6938f77431644982",
    "tokens": 4
   }
  ],
  "interrupted": true
 },
 "resume": [
  "skipped:already done",
  "indexed",
  "indexed"
 ],
 "rerun": [
  "already done",
  "already done",
  "already done"
 ],
 "minted_total": 10,
 "owners_match_plan": true
}
```
## 8. Optional claim-based distribution: Merkle drop, eligible claim mints, someone else's proof is refused — PASS
```json
{
 "drop": "indexed",
 "claim_by_eligible": "indexed",
 "owner_11": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
 "mallory_with_stolen_proof": "rejected",
 "mallory_error": "BAD_PROOF",
 "drop_state": {
  "claim_deadline_height": 487,
  "claims": 1,
  "collection_id": "aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5",
  "creator": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
  "drop_id": "653cd75995f62f687d8dc39621f1f6c3f16782b356daab38b5b4880cf7a2ebaa",
  "max_claims": 2,
  "merkle_root": "0bc1d05dc070be98270c379f0ca6867f71fadd7b0433c69aa0040c0169315186",
  "observed_at_ms": 1795790720234,
  "open": true,
  "source": "authoritative on-chain state of the queried node at `height` (an application index is only a cache of this)",
  "state_height": 94
 }
}
```
## 9. Transfer an asset (collector -> buyer), confirmed and indexed — PASS
```json
{
 "status": "indexed",
 "owner_chain": {
  "ref": "aureom:aureom-collections-1:e3447906c331bc23/aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5/3",
  "owner": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
  "burned": false,
  "chain_height": 98,
  "source": "chain (authoritative)",
  "index": {
   "owner": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
   "as_of_height": 98
  },
  "index_agrees": true
 }
}
```
## 10. Reject an unauthorised transfer (mallory): refused in simulation and on chain; owner unchanged; failure indexed — PASS
```json
{
 "simulation_error": "UNAUTHORIZED",
 "on_chain": "failed",
 "receipt_error": "UNAUTHORIZED",
 "owner_still": "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d",
 "index_records_failure": {
  "status": "failed",
  "error": "UNAUTHORIZED"
 }
}
```
## 11. Inspect and revoke an approval: single-token approval shown with its scope; collection-wide operator flagged as high risk; revoked approval no longer works — PASS
```json
{
 "grant": "indexed",
 "inspected_token_approvals": [
  {
   "approved": "aurd1mtvrgst6d33cftsnxxfwlz5alfdaq02yyzgarp",
   "collection_id": "aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5",
   "expiry_height": 0,
   "risk": "the approved address can transfer this one token until revoked, used or expired",
   "scope": "this token only",
   "token_id": "7"
  }
 ],
 "operator_warning_in_review": [
  "COLLECTION-WIDE OPERATOR: aurd1mtvrgst6d33cftsnxxfwlz5alfdaq02yyzgarp could transfer ALL your tokens in aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5 (including future ones) with NO expiry. Prefer a single-token approval or a fixed-price listing."
 ],
 "revoke": "indexed",
 "approvals_after_revoke": [],
 "courier_after_revoke": "UNAUTHORIZED"
}
```
## 12. Update permitted metadata: metadata admin creates revision 1 (history kept); stale revision and token holder are refused — PASS
```json
{
 "status": "indexed",
 "revision": 1,
 "revisions": [
  [
   0,
   "1ab73baea59e972f"
  ],
  [
   1,
   "dfaca2664474a786"
  ]
 ],
 "stale_revision": "STALE",
 "update_by_token_holder": "UNAUTHORIZED"
}
```
## 13. Freeze metadata: preview shows exact reference, freeze signs that hash; further changes rejected (simulation and chain) — PASS
```json
{
 "preview_affects": [
  [
   "aureom:aureom-collections-1:e3447906c331bc23/aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5/2",
   "dfaca2664474a786",
   {
    "name": "Seven Lanterns Drifting (restored colours)",
    "media_sha256": [
     "d07201dc546a62c12c89523d6d12c59da0a66ed9bb72a27546ee9503b4b6b54b"
    ]
   }
  ]
 ],
 "expected_signed": "dfaca2664474a7866981e4fd1b5de46757f49d6faa39ea3da2f60470629e18ee",
 "review_warnings": [
  "freezing metadata is permanent and cannot be undone",
  "no expiry height: this transaction stays valid until its nonce is used"
 ],
 "freeze": "indexed",
 "token_frozen": true,
 "update_after_freeze_sim": "METADATA_FROZEN",
 "update_after_freeze_chain": "METADATA_FROZEN",
 "collection_freeze_preview": {
  "expected_root": "793b504628180fdcc70c02d6156731983b1e35003708fda15b5c39991f7190e2",
  "tokens_affected": 11,
  "also": "every token minted later is frozen from birth; the metadata administrator role is removed"
 }
}
```
## 14. Fixed-price sale: seller listing, buyer review, atomic settlement (price, royalty, platform fee, network fee kept separate), duplicate and replay rejected — PASS
```json
{
 "listing": {
  "status": "active",
  "price": "1234567",
  "currency": "native",
  "expiry_height": 414,
  "seller": "aurd1k4c85j3hzamlnax8vdtmltl67san9sp4960j6d"
 },
 "buyer_review": "buy listing 93263b7bd7ed8db78b3e9c570cb7b41026052b08b36d84869fabd9e4927482ce for exactly 1234567 base units of ADC (plus the network fee)",
 "wrong_price_commitment": "STALE",
 "buy": "indexed",
 "new_owner": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
 "settlement": {
  "platform_fee": "30864",
  "rounding": "royalty and platform fee are floor(price \u00d7 bps / 10000); the seller receives the remainder; the network fee is paid separately by the buyer",
  "royalty": "61728",
  "royalty_recipient": "aurd1604xrfeyhf7e7j7d490aynz3gssfl65x057atf",
  "seller_proceeds": "1141975"
 },
 "balance_deltas": {
  "collector": 1141975,
  "artist": 61728,
  "platform": 30864,
  "buyer": -1237567
 },
 "expected_deltas": {
  "collector": 1141975,
  "artist": 61728,
  "platform": 30864,
  "buyer": -1237567
 },
 "accounting_exact": true,
 "duplicate_purchase": "LISTING_INACTIVE",
 "replay_same_bytes": {
  "http": 400,
  "code": "bad_nonce"
 },
 "replay_other_chain": {
  "http": 400,
  "code": "wrong_chain"
 }
}
```
## 15. Settlement revalidates ownership: a listing is invalidated when the seller transfers the token away — PASS
```json
{
 "listing_status_after_seller_moved_token": "invalidated",
 "buy_attempt": "LISTING_INACTIVE"
}
```
## 16. Token-gated access: signed single-use challenge + on-chain ownership; impersonation, replay and non-holders refused — PASS
```json
{
 "holder": {
  "granted": true,
  "reason": "signature valid and ownership confirmed on chain",
  "chain_height": 132,
  "address": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
  "note": "ownership can change at any time; re-check for long-lived sessions"
 },
 "replay": "challenge already used (replay)",
 "address_only_impersonation": "public key does not belong to the challenged address",
 "valid_signer_without_token": "signature valid, but the address does not currently own a qualifying token"
}
```
## 17. Authenticity claims need evidence and review (off-chain); a ledger entry is not proof of issuer claims — PASS
```json
{
 "verified_artist": "accepted by reviewer (off-chain review, not a chain fact)",
 "physical_backing": "rejected by reviewer",
 "on_chain": [
  false,
  false
 ]
}
```
## 18. PoW reorganisation: an index following the minority branch reconciles to the winning chain (conflicting transfer dropped) — PASS
```json
{
 "minority_index_owner": true,
 "minority_sync": {
  "indexed_height": 134,
  "blocks_added": 2
 },
 "node_reorgs": [
  {
   "at_ms": 1795790807775,
   "depth": 3,
   "dropped": 1,
   "fork_height": 132,
   "new_tip": "8af417860575d8eedc7e85b868c63eed4d5591bfe985820a4c11f4cbe4f9b3eb",
   "old_tip": "381d40d3a5eda9bb2b81ac9d856729b8f90625b1e52c57ca40ec14f91f078302",
   "returned_to_mempool": 0
  }
 ],
 "index_reorgs": [
  {
   "fork_height": 132,
   "old_tip_height": 134,
   "blocks_removed": 2,
   "events_removed": 1
  }
 ],
 "after_sync_reorgs": [
  {
   "fork_height": 132,
   "old_tip_height": 134,
   "blocks_removed": 2,
   "events_removed": 1
  }
 ],
 "index_owner_after": true,
 "chain_owner_after": true,
 "minority_tx_now": "dropped",
 "verify": {
  "checked": 12,
  "mismatches": [],
  "consistent": true,
  "index_height": 139,
  "note": "chain state is authoritative; on mismatch run sync (or rebuild) \u2014 never edit the index by hand"
 }
}
```
## 19. Rebuild the index from chain events: identical ownership and sales; verified against chain state — PASS
```json
{
 "rebuild": {
  "blocks_added": 139,
  "events_added": 29,
  "indexed_height": 139,
  "events_before_rebuild": 29
 },
 "ownership_identical": true,
 "sales_identical": true,
 "verify_against_chain": {
  "checked": 12,
  "consistent": true,
  "mismatches": []
 }
}
```
## 20. Export provenance (JSON + CSV) and check ledger invariants (native, token and NFT reconciliation) — PASS
```json
{
 "ref": "aureom:aureom-collections-1:e3447906c331bc23/aurdcol102h3jhtpwl7y800es7trrfvatmx73eh8zg95p5/9",
 "event_kinds": [
  "nft_collection_create",
  "nft_mint",
  "nft_listing:create",
  "nft_transfer:listing_sale",
  "nft_sale"
 ],
 "current_owner": "aurd1tts4re2xq6zp8xuajwdqhltc9kt8l3y0tvxw9m",
 "revisions": 1,
 "storage_of_metadata": [
  {
   "adapter": "local",
   "locator": "/tmp/claude-0/-home-user-Aureom-AI/1adc73ac-ea1a-5e3d-923d-055aa4447a5a/scratchpad/demo/collections/collections/objects/47/47c5ec64a5f50c83110b7cf44a82d0328c81bafdedccf76ed7a3622157a2008f",
   "public_uri": "http://127.0.0.1:8787/media/47c5ec64a5f50c83110b7cf44a82d0328c81bafdedccf76ed7a3622157a2008f",
   "maintainer": "network operator (local disk)",
   "monitoring": "chainworks nft storage check (re-reads the file and compares SHA-256)",
   "last_available": 1,
   "last_checked_ms": 1795790698977
  }
 ],
 "export_sha256": "ab311e6504eff235dbae9d48f4dc6a3e437f9638d257be6b25f6181ccbb070af",
 "written": [
  "provenance-token-9.json",
  "provenance-token-9.csv"
 ],
 "supply_invariants": {
  "reconciled": true,
  "tokens_reconciled": true,
  "nfts_reconciled": true
 }
}
```
