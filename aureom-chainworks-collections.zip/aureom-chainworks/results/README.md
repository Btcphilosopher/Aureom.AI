# Results recorded during delivery
* `demos/` — per-step evidence of the final fresh run of all four demonstrations (JSON + Markdown + console log).
* `logs/` — cargo test, pytest, console build, clippy outputs.
* `docker-smoke.json` — Docker Compose launch of PoW, PoS and PoA networks with a transfer each.
* `performance/` — state-machine benchmark and live-network throughput.
* `console/` — headless-Chromium screenshots of the console against the live Aureom Development Network.
Network directories (which contain development secrets) are deliberately not included.
