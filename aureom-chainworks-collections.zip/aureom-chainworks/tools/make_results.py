"""Compile docs/TEST-RESULTS.md from recorded outputs in results/ (no hand-entered numbers).
Usage: python3 tools/make_results.py <repo-root>"""
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
res = root / "results"
md = ["# Build and test results", "",
      "Recorded in the delivery environment (Linux x86_64, 4 vCPU, Rust 1.97, Python 3.13, Node 22, Go 1.24, CometBFT v0.38.26 built from source, Docker 29). "
      "Every figure below is copied by `tools/make_results.py` from the raw files in `results/`.", ""]

log = (res / "logs" / "cargo-test.log").read_text()
md += ["## Rust unit and integration tests (`cargo test --release --workspace`)", "", "```"]
md += [ln for ln in log.splitlines() if ln.startswith("test ") or "test result" in ln]
md += ["```", ""]
py = (res / "logs" / "pytest.log").read_text()
md += ["## Python tests (`pytest -v python/tests`)", "", "```", py.strip(), "```", ""]
cb = (res / "logs" / "console-build.log").read_text()
md += ["## Console (`tsc --noEmit` strict, `vite build`)", "", "```", cb.strip()[-900:], "```", ""]
cl = res / "logs" / "clippy.log"
if cl.exists():
    md += ["## Clippy", "", "```", cl.read_text().strip()[-1500:], "```", ""]

md += ["## Reproducible demonstrations (live multi-node networks)", "",
       "| demo | passed | total | seconds |", "|---|---|---|---|"]
demos = []
for n in ("pow", "pos", "poa", "assets"):
    p = res / "demos" / f"{n}-results.json"
    if p.exists():
        r = json.loads(p.read_text())
        demos.append(r)
        md.append(f"| {n} | {r['passed']} | {r['total']} | {r['seconds']} |")
md.append("")
for r in demos:
    md += [f"### {r['demo']}", ""]
    for s in r["steps"]:
        md.append(f"* {'PASS' if s['ok'] else '**FAIL**'} — {s['title']} ({s['seconds']} s)")
    md.append("")
md += ["Full per-step evidence (JSON observed from the nodes): `results/demos/*-results.md|json`.", ""]

ds = res / "docker-smoke.json"
if ds.exists():
    md += ["## Docker Compose smoke test (`tools/docker_smoke.py`)", "", "| profile | ok | services | transfer | heights |", "|---|---|---|---|---|"]
    for r in json.loads(ds.read_text()):
        md.append(f"| {r['profile']} | {r.get('ok')} | {len(r.get('services') or [])} | {(r.get('transfer') or {}).get('status')} | {r.get('heights')} |")
    md.append("")

md += ["## Not exercised / known gaps (stated, not hidden)", "",
       "* `deploy/Dockerfile.source` (multi-stage source build) was not built here; images were built from local release binaries.",
       "* Live equivocation (a validator double-signing) was not induced; slashing of CometBFT duplicate-vote evidence is covered by state-machine tests with synthetic evidence.",
       "* CometBFT state sync is not offered by the application; joining BFT nodes used blocksync from genesis.",
       "* No fuzzing, no external audit, no long-running soak tests; demonstrations run minutes, not days.",
       "* The console was exercised in headless Chromium against the live Aureom Development Network (screenshots in `results/console/`) and against a mock for PoW/PoS/PoA layouts; no manual browser QA.",
       ""]
(root / "docs" / "TEST-RESULTS.md").write_text("\n".join(md) + "\n")
print("wrote", root / "docs" / "TEST-RESULTS.md")
