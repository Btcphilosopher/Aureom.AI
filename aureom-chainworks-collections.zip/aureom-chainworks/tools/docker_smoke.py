"""Docker Compose smoke test: for each profile, init a docker-target network, build
genesis, compose up, wait for agreement, submit a transfer, compose down.
Usage: PYTHONPATH=python python3 tools/docker_smoke.py <work-dir> <results-json>"""
import json
import pathlib
import shutil
import subprocess
import sys
import time

from chainworks.network import Network
from chainworks.util import get, try_get, wait_for
from chainworks.wallet import Wallet

work, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
results = []
for i, prof in enumerate(("pow", "pos", "poa")):
    d = work / f"docker-{prof}"
    if d.exists():
        shutil.rmtree(d)
    net = Network.init(d, prof, base_port=19000 + i * 100, target="docker")
    net.build_genesis()
    v = net.validate()
    from chainworks import compose
    compose.write(net, d)
    t0 = time.time()
    up = subprocess.run(["docker", "compose", "up", "-d"], cwd=d, capture_output=True, text=True)
    rec = {"profile": prof, "validate_ok": v["ok"], "compose_up_rc": up.returncode, "services": None}
    try:
        names = [n["name"] for n in net.nodes()]
        wait_for(lambda: all((try_get(net.api(n) + "/v1/health") or {}).get("height", 0) >= 5 for n in names), 120, 1, "heights")
        ps = subprocess.run(["docker", "compose", "ps", "--format", "{{.Name}} {{.State}}"], cwd=d, capture_output=True, text=True).stdout.split("\n")
        rec["services"] = [x for x in ps if x]
        r = Wallet(net, "node0").transfer("alice", "bob", 1_000_000)
        rec["transfer"] = {"status": r.get("status"), "block_height": r.get("block_height"), "receipt": (r.get("receipt") or {}).get("status")}
        rec["heights"] = {n: get(net.api(n) + "/v1/health")["height"] for n in names}
        rec["genesis_hash_reported"] = {n: get(net.api(n) + "/v1/network")["genesis_hash"] == net.genesis_hash for n in names}
        rec["seconds"] = round(time.time() - t0, 1)
        rec["ok"] = rec["transfer"]["receipt"] == "success" and all(rec["genesis_hash_reported"].values())
    except Exception as e:  # noqa: BLE001
        rec["ok"] = False
        rec["error"] = str(e)
        rec["logs"] = subprocess.run(["docker", "compose", "logs", "--tail", "20"], cwd=d, capture_output=True, text=True).stdout[-3000:]
    finally:
        subprocess.run(["docker", "compose", "down"], cwd=d, capture_output=True)
    results.append(rec)
    print(json.dumps(rec), flush=True)
out.write_text(json.dumps(results, indent=2))
