#!/usr/bin/env python3
"""Regenerate fixtures/collections/: original demonstration artwork and synthetic inputs
for AUREOM COLLECTIONS. Deterministic; run from the repository root:
    PYTHONPATH=python python3 tools/make_collection_fixtures.py
"""
import hashlib
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "python"))
from chainworks.nft import art, media  # noqa: E402
from chainworks.nft import metadata as md  # noqa: E402

out = pathlib.Path(__file__).resolve().parents[1] / "fixtures" / "collections"
(out / "media").mkdir(parents=True, exist_ok=True)
(out / "metadata").mkdir(exist_ok=True)
manifest = []


def put(name, data, alt=None, transcript=None):
    v = media.validate(data, name, alt, transcript)
    (out / "media" / name).write_bytes(data)
    manifest.append({"file": f"media/{name}", "sha256": v["sha256"], "mime": v["mime"], "bytes": v["bytes"], "cid_raw_v1": v["cid_raw_v1"], "alt_text": alt, "transcript": transcript})
    return v


rights = md.rights_block("Lumen Atelier (fictional studio)", "CC-BY-4.0", "Original digital illustration by Lumen Atelier (fictional), licensed under CC BY 4.0. Token ownership conveys no copyright.")
CHAIN, GEN = "aureom-dev-pow-1", "0" * 64  # placeholders: real documents name the target network
put("tidewater.svg", art.collection_svg(), "Collection artwork: nine glowing lanterns drifting on a dark harbour under a pale moon.")
put("harbour-bell.wav", art.chime_wav(), transcript="A single soft harbour bell chime fading over about one second.")
put("rights-statement.pdf", art.statement_pdf(["Tidewater Lanterns - rights statement (fictional demonstration)", "Rights holder: Lumen Atelier (fictional studio)", "Licence: CC BY 4.0.", "Owning a token does not transfer copyright or any physical object."]))
rows = []
for i in range(1, 13):
    png, tr = art.illustration(i)
    v = put(f"lantern-{i:02d}.png", png, art.alt_text(i, tr))
    doc = md.token_document(name=art.TITLES[i - 1], description=f"Tidewater Lanterns no. {i}: {art.alt_text(i, tr)}", collection_slug="tidewater-lanterns", chain_id=CHAIN,
                            genesis_hash=GEN, token_id=i, image=md.media_ref(v, f"http://127.0.0.1:8787/media/{v['sha256']}"), attributes=tr["attributes"], creator="Lumen Atelier (fictional)", rights=rights)
    b = md.canonical_bytes(doc)
    (out / "metadata" / f"token-{i:02d}.json").write_bytes(b)
    rows.append({"token_id": i, "to": "collector" if i % 2 else "buyer", "metadata_sha256": hashlib.sha256(b).hexdigest()})
(out / "batch-rows.json").write_text(json.dumps(rows[1:10], indent=2) + "\n")
(out / "wizard-answers.example.json").write_text(json.dumps({
    "slug": "tidewater-lanterns", "name": "Tidewater Lanterns", "collection_metadata": {"uri": "<from `chainworks nft metadata-put`>", "sha256": "<64 hex>"},
    "max_supply": 16, "mint_authority": "artist", "metadata_policy": "freezable", "metadata_admin": "artist", "owner_burn": True,
    "pausable": False, "forced_transfer": False, "transfer_policy": "transferable", "royalty": {"recipient": "artist", "bps": 500},
    "rights_holder": "Lumen Atelier (fictional studio)", "rights": {"uri": "<from `chainworks nft metadata-put`>", "sha256": "<64 hex>"}}, indent=2) + "\n")
(out / "claim-evidence.example.json").write_text(json.dumps([{"description": "studio attestation PDF (kept in private storage)", "sha256": hashlib.sha256(b"attestation").hexdigest(), "held_by": "Lumen Atelier registrar (fictional)"}], indent=2) + "\n")
(out / "MANIFEST.json").write_text(json.dumps({"collection": "Tidewater Lanterns (fictional)", "creator": "Lumen Atelier (fictional studio)",
    "licence": "CC BY 4.0 — all files generated procedurally by python/chainworks/nft/art.py", "placeholder_network": {"chain_id": CHAIN, "genesis_hash": GEN}, "files": manifest}, indent=2) + "\n")
print(f"wrote {len(manifest)} media files and 12 metadata documents to {out}")
