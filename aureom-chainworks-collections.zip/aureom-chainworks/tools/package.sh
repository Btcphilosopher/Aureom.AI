#!/usr/bin/env bash
# Build the distributable zip: sources, docs, built console, own release binaries,
# results. Excludes build caches, node_modules, network directories (which contain
# secrets) and third-party binaries. Fails if any secret marker is found.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
out="$(realpath -m "${1:?usage: package.sh <out.zip>}")"
stage="$(mktemp -d "${TMPDIR:-/tmp}/aureom-pkg.XXXXXX")"
dest="$stage/aureom-chainworks"
mkdir -p "$dest"
tar -C "$root" \
  --exclude='./rust/target' --exclude='./console/node_modules' --exclude='__pycache__' --exclude='.pytest_cache' \
  --exclude='./tools/bin' --exclude='./deploy/bin' --exclude='*.egg-info' -cf - . | tar -C "$dest" -xf -
mkdir -p "$dest/bin/linux-x86_64"
cp "$root/rust/target/release/aureom-node" "$root/rust/target/release/aureom-cli" "$dest/bin/linux-x86_64/"
( cd "$dest/bin/linux-x86_64" && sha256sum aureom-node aureom-cli > SHA256SUMS )
if grep -rIlE '"seed"[[:space:]]*:|"priv_key"[[:space:]]*:|"ciphertext"[[:space:]]*:|PRIVATE KEY' "$dest" \
     --exclude-dir=src --exclude-dir=chainworks --exclude-dir=tests --exclude='*.md' --exclude='*.rs' --exclude='*.py' --exclude='*.tsx' --exclude='*.ts' --exclude='*.sh'; then
  echo "secret markers found in package — aborting" >&2; exit 1
fi
( cd "$dest" && find . -type f ! -name CHECKSUMS.sha256 -print0 | sort -z | xargs -0 sha256sum > CHECKSUMS.sha256 )
rm -f "$out"
( cd "$stage" && zip -qr -X "$out" aureom-chainworks )
rm -rf "$stage"
ls -la "$out"
