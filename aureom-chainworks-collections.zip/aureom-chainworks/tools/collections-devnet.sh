#!/usr/bin/env bash
# Launch a local development network with AUREOM COLLECTIONS enabled, create the
# collections database and serve the console. Development use only.
#   tools/collections-devnet.sh ./collections-net [pow|pos|poa] [console-port]
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
dir="${1:-./collections-net}"; profile="${2:-pow}"; port="${3:-8787}"
export PYTHONPATH="$root/python${PYTHONPATH:+:$PYTHONPATH}"
cw() { python3 -m chainworks "$@"; }
if [ ! -f "$dir/genesis.json" ]; then
  cw init --profile "$profile" --dir "$dir" --collections --marketplace-fee-bps 250
  # creator / collector accounts for the walkthrough in docs/COLLECTIONS.md
  python3 - "$dir" <<'PY'
import json, sys, pathlib
p = pathlib.Path(sys.argv[1]) / "network.json"
s = json.loads(p.read_text())
have = {a["label"] for a in s["accounts"]}
for l in ("artist", "collector", "buyer"):
    if l not in have:
        s["accounts"].append({"label": l, "role": "account", "allocation": str(50_000 * 10**6)})
p.write_text(json.dumps(s, indent=2) + "\n")
PY
  cw genesis build "$dir"
fi
cw validate "$dir"
cw network up "$dir"
cw nft db-migrate --dir "$dir"
echo "network up. console: http://127.0.0.1:$port  (Ctrl-C stops the console; 'chainworks network down $dir' stops the nodes)"
cw console "$dir" --port "$port"
