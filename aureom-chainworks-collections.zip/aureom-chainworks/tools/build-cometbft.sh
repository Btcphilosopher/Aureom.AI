#!/usr/bin/env bash
# Build CometBFT from source through the Go module proxy (checksums verified by sum.golang.org).
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
CGO_ENABLED=0 GOBIN="$here/bin" go install github.com/cometbft/cometbft/cmd/cometbft@v0.38.26
"$here/bin/cometbft" version
