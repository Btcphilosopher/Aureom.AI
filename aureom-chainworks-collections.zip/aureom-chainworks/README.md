# AUREOM CHAINWORKS — Blockchain Launch & Management

A workbench for configuring, launching, operating and inspecting **independent
development blockchain networks** in which every network has an explicit protocol, a
reproducible genesis, a verifiable ledger, observable consensus and a documented recovery
procedure.

> **Development software — not production-secure.** Not audited. Proof-of-work
> development networks offer no resistance to a majority-hash-power attacker; BFT
> networks are safe only while less than 1/3 of voting power is Byzantine. Creating a coin
> or token gives it no monetary value, reserve backing, exchange listing or legal status.
> See [docs/SECURITY-LIMITATIONS.md](docs/SECURITY-LIMITATIONS.md).

## What is in the package

| component | path | language |
|---|---|---|
| Protocol specification (written first), API, consensus, assets, governance, threat model, operations | `docs/` | — |
| Genesis JSON schema | `schemas/genesis.schema.json` | — |
| Cross-implementation test vectors (Rust-generated, Python-verified) | `test-vectors/` | — |
| Ledger core: canonical encoding, hashing, Merkle, state machine, genesis, PoW rules, keystore, snapshots | `rust/crates/aureom-core` | Rust |
| Node: redb storage, PoW engine + p2p + miner, CometBFT ABCI app (PoS/PoA), public + admin HTTP APIs | `rust/crates/aureom-node` | Rust |
| Keys / development wallet / tx prepare-review-sign-submit / external-signer adapter / vectors / bench | `rust/crates/aureom-cli` | Rust |
| `chainworks` CLI: init, genesis, validate, network up/down/status, wallet, tokens, distribution, treasury, backup/restore/snapshot/replay, export, migration, explorer, console, demos | `python/chainworks` | Python |
| Management console (Aureom identity) | `console/` (built `dist/` included) | React + TypeScript |
| Container definitions, compose generation, optional explorer DB | `deploy/`, `python/chainworks/compose.py` | Docker |
| Demo results, performance measurements, test logs from this delivery | `results/` | — |

## Architecture

```
            ┌──────────── chainworks (Python) ────────────┐        console (React)
 network.json → genesis.json (hash pinned) → node configs   │◀──── console server: read-only + signed-tx relay
            │   validate · up/down · backup · export · demos │
            └───────────────┬────────────────────────────────┘
                            │ aureom-cli (keys, signing — keys never enter Python)
   PoW profile              ▼                         PoS / PoA profiles
 ┌───────────────────────────────┐        ┌───────────────────────┐  ABCI 2.0  ┌──────────────┐
 │ aureom-node (aureom-nakamoto) │        │ aureom-node (ABCI app)│◀──────────▶│ CometBFT 0.38│
 │ p2p · mempool · miner · chain │        │ CheckTx/Prepare/      │            │ p2p, mempool,│
 │ fork choice · reorg (undo)    │        │ Process/Finalize/     │            │ BFT voting,  │
 │        aureom-core            │        │ Commit · aureom-core  │            │ evidence     │
 │   redb (atomic per block)     │        │ redb (atomic/commit)  │            └──────────────┘
 └───────────────────────────────┘        └───────────────────────┘
        /v1 public API (common)   ·   /admin/v1 (separate loopback listener, bearer token)
```

The **deterministic state machine** (`aureom-core::exec`) is shared by all profiles:
native coin (transfers, fees, burns, authority/scheduled issuance), token module,
vesting, threshold multisig treasury, claim distributions, PoS staking/slashing, PoA
authority governance, protocol-upgrade scheduling. PoW uses this repository's Nakamoto
engine; PoS and PoA use **CometBFT** (maintained BFT engine, Apache-2.0). The backends
differ and that is documented rather than hidden ([docs/CONSENSUS.md](docs/CONSENSUS.md)).

## AUREOM COLLECTIONS (NFT issuance and management)

A native NFT module of the state machine (not a smart contract; not ERC-721/1155
compatible) plus an application layer for media, metadata, minting workflows, indexing,
provenance, token gating and a fixed-price demonstration marketplace with atomic
settlement. Enable it at genesis (`chainworks init --collections`) — see
[docs/COLLECTIONS.md](docs/COLLECTIONS.md), [docs/COLLECTIONS-PROTOCOL.md](docs/COLLECTIONS-PROTOCOL.md),
results in [docs/COLLECTIONS-TEST-RESULTS.md](docs/COLLECTIONS-TEST-RESULTS.md).

```bash
tools/collections-devnet.sh ./collections-net          # PoW devnet + collections DB + console
chainworks demo collections --dir ./demo/collections   # 20-step recorded demonstration
```

## Quick start

Requirements: Rust (stable), Python ≥ 3.10 with `click`, `cryptography`, `jsonschema`,
Go (only to build CometBFT), Node 20+ (only to rebuild the console), Docker (optional).

```bash
cd rust && cargo build --release && cd ..
tools/build-cometbft.sh                      # PoS/PoA only; builds CometBFT v0.38.26 from source
pip install -e python                        # or: export PYTHONPATH=$PWD/python
```

```bash
chainworks init --profile pos --dir ./mynet          # or pow | poa ; --interactive for the wizard
chainworks genesis build ./mynet
chainworks validate ./mynet
chainworks network up ./mynet
chainworks network status ./mynet
chainworks transfer --dir ./mynet --from alice --to bob --amount 2.5
chainworks console ./mynet                           # http://127.0.0.1:8787
chainworks export ./mynet                            # deployment package, no secrets
chainworks network down ./mynet
```

Step-by-step wallet flow (construction separate from signing):
```bash
chainworks tx prepare --dir ./mynet --from alice --action '{"type":"transfer","to":"<aurd1…>","amount":"1000000"}' --out u.json
chainworks tx review  --dir ./mynet u.json
chainworks tx sign    --dir ./mynet --from alice --in u.json --out s.json
chainworks tx submit  --dir ./mynet --in s.json --wait
```

Reproducible demonstrations (each creates a fresh network and records every step):
```bash
chainworks demo pow    --dir ./demo/pow       # 27 steps: reorg, malformed/invalid blocks, crash recovery, sync …
chainworks demo pos    --dir ./demo/pos       # 24 steps: quorum loss, downtime jailing, staking join …
chainworks demo poa    --dir ./demo/poa       # 23 steps: authorised/unauthorised authority changes, key rotation …
chainworks demo assets --dir ./demo/assets    # 18 steps: Aureom Development Network coin + token lifecycle
chainworks demo collections --dir ./demo/collections  # 20 steps: NFT collections, minting, sale, reorg reconciliation
```

## Delivery results

Actual results from this delivery's build environment are in
[docs/TEST-RESULTS.md](docs/TEST-RESULTS.md) and [docs/PERFORMANCE.md](docs/PERFORMANCE.md),
with raw per-step evidence under `results/`. Nothing there is estimated.

## Documentation map
* [PROTOCOL.md](docs/PROTOCOL.md) — normative specification (encoding, hashes, signatures, addresses, ids, state commitment, limits, timestamps, fees, arithmetic, profiles)
* [API.md](docs/API.md) — node, admin and console-server APIs
* [CONSENSUS.md](docs/CONSENSUS.md) — profiles, backends, framework research, quorum/fault assumptions
* [ASSETS.md](docs/ASSETS.md) — native coin vs tokens vs wrapped assets, monetary policies, distribution, vesting, treasury
* [GOVERNANCE.md](docs/GOVERNANCE.md) · [MIGRATION.md](docs/MIGRATION.md) · [EXTENSIONS.md](docs/EXTENSIONS.md)
* [OPERATIONS.md](docs/OPERATIONS.md) — launch, monitoring, backup, restore, snapshots, replay, pruning, upgrades
* [THREAT-MODEL.md](docs/THREAT-MODEL.md) · [SECURITY-LIMITATIONS.md](docs/SECURITY-LIMITATIONS.md)
* [DEPENDENCIES.md](docs/DEPENDENCIES.md) — dependency inventory with licences

Licence: Apache-2.0 (this repository's code). Third-party components keep their own licences.
