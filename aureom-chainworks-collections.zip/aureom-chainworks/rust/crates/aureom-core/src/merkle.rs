//! Merkle construction (PROTOCOL.md 2.3): odd elements are promoted, never duplicated.

use crate::crypto::{hash_domain, Hash32};

pub fn leaf(x: &[u8]) -> Hash32 {
    hash_domain("AUREOM/LEAF/v1", x)
}

pub fn node(l: &Hash32, r: &Hash32) -> Hash32 {
    let mut d = [0u8; 64];
    d[..32].copy_from_slice(l);
    d[32..].copy_from_slice(r);
    hash_domain("AUREOM/NODE/v1", &d)
}

pub fn empty_root() -> Hash32 {
    hash_domain("AUREOM/EMPTY/v1", b"")
}

/// Root over already-hashed leaf inputs (each item is passed through `leaf`).
pub fn root<I: AsRef<[u8]>>(items: &[I]) -> Hash32 {
    if items.is_empty() {
        return empty_root();
    }
    let level: Vec<Hash32> = items.iter().map(|x| leaf(x.as_ref())).collect();
    root_from_leaves(level)
}

pub fn root_from_leaves(mut level: Vec<Hash32>) -> Hash32 {
    if level.is_empty() {
        return empty_root();
    }
    while level.len() > 1 {
        let mut next = Vec::with_capacity(level.len().div_ceil(2));
        let mut i = 0;
        while i < level.len() {
            if i + 1 < level.len() {
                next.push(node(&level[i], &level[i + 1]));
            } else {
                next.push(level[i]);
            }
            i += 2;
        }
        level = next;
    }
    level[0]
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProofStep {
    /// 0 = sibling on the left, 1 = sibling on the right
    pub side: u8,
    pub sibling: Hash32,
}

pub fn proof(items: &[impl AsRef<[u8]>], index: usize) -> Vec<ProofStep> {
    let mut level: Vec<Hash32> = items.iter().map(|x| leaf(x.as_ref())).collect();
    let mut idx = index;
    let mut out = vec![];
    while level.len() > 1 {
        let sib = idx ^ 1;
        if sib < level.len() {
            out.push(ProofStep { side: if sib < idx { 0 } else { 1 }, sibling: level[sib] });
        }
        let mut next = Vec::with_capacity(level.len().div_ceil(2));
        let mut i = 0;
        while i < level.len() {
            if i + 1 < level.len() {
                next.push(node(&level[i], &level[i + 1]));
            } else {
                next.push(level[i]);
            }
            i += 2;
        }
        level = next;
        idx /= 2;
    }
    out
}

pub fn verify_proof(item: &[u8], proof: &[ProofStep], root: &Hash32) -> bool {
    let mut h = leaf(item);
    for s in proof {
        h = match s.side {
            0 => node(&s.sibling, &h),
            1 => node(&h, &s.sibling),
            _ => return false,
        };
    }
    &h == root
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn proofs_verify_for_all_sizes() {
        for n in 1..20usize {
            let items: Vec<Vec<u8>> = (0..n).map(|i| vec![i as u8; 3]).collect();
            let r = root(&items);
            for i in 0..n {
                let p = proof(&items, i);
                assert!(verify_proof(&items[i], &p, &r), "n={n} i={i}");
                assert!(!verify_proof(b"other", &p, &r));
            }
        }
    }

    #[test]
    fn odd_promotion_differs_from_duplication() {
        let a = root(&[b"a", b"b", b"c"]);
        let b = root(&[b"a", b"b", b"c", b"c"]);
        assert_ne!(a, b);
    }
}
