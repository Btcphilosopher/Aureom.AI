//! Thin wrappers over maintained cryptographic libraries (no primitives here).

use bech32::{Bech32m, Hrp};
use ed25519_dalek::{Signature, Signer, SigningKey, VerifyingKey};
use rand_core::OsRng;
use sha2::{Digest, Sha256};
use zeroize::Zeroize;

pub type Hash32 = [u8; 32];
pub type Addr = [u8; 20];

/// H(domain, data) = SHA-256(u8(len(domain)) || domain || data)
pub fn hash_domain(domain: &str, data: &[u8]) -> Hash32 {
    debug_assert!(domain.len() < 256);
    let mut h = Sha256::new();
    h.update([domain.len() as u8]);
    h.update(domain.as_bytes());
    h.update(data);
    h.finalize().into()
}

pub fn sha256(data: &[u8]) -> Hash32 {
    Sha256::digest(data).into()
}

pub fn address_from_pubkey(pk: &[u8; 32]) -> Addr {
    let mut d = Vec::with_capacity(33);
    d.push(0x01);
    d.extend_from_slice(pk);
    let h = hash_domain("AUREOM/ADDR/v1", &d);
    h[..20].try_into().unwrap()
}

/// CometBFT consensus address: first 20 bytes of SHA-256(pubkey).
pub fn comet_address(pk: &[u8; 32]) -> Addr {
    sha256(pk)[..20].try_into().unwrap()
}

pub fn bech32_encode(hrp: &str, data: &[u8]) -> String {
    let hrp = Hrp::parse(hrp).expect("valid hrp");
    bech32::encode::<Bech32m>(hrp, data).expect("encodable")
}

#[derive(Debug, thiserror::Error)]
pub enum AddrError {
    #[error("invalid bech32m string")]
    Invalid,
    #[error("wrong prefix: expected {expected}, got {got}")]
    WrongHrp { expected: String, got: String },
    #[error("wrong length")]
    Length,
    #[error("not bech32m (checksum variant)")]
    Variant,
}

pub fn bech32_decode20(expected_hrp: &str, s: &str) -> Result<Addr, AddrError> {
    let checked = bech32::primitives::decode::CheckedHrpstring::new::<Bech32m>(s)
        .map_err(|_| AddrError::Variant)?;
    let hrp = checked.hrp();
    if hrp.as_str() != expected_hrp {
        return Err(AddrError::WrongHrp { expected: expected_hrp.into(), got: hrp.to_string() });
    }
    // Reject mixed/upper case to keep one canonical textual form.
    if s.chars().any(|c| c.is_ascii_uppercase()) {
        return Err(AddrError::Invalid);
    }
    let data: Vec<u8> = checked.byte_iter().collect();
    data.try_into().map_err(|_| AddrError::Length)
}

/// Ed25519 keypair. The secret is zeroized on drop by ed25519-dalek.
pub struct Keypair {
    sk: SigningKey,
}

impl Keypair {
    pub fn generate() -> Self {
        Self { sk: SigningKey::generate(&mut OsRng) }
    }
    pub fn from_seed(seed: &[u8; 32]) -> Self {
        Self { sk: SigningKey::from_bytes(seed) }
    }
    pub fn seed(&self) -> [u8; 32] {
        self.sk.to_bytes()
    }
    pub fn public(&self) -> [u8; 32] {
        self.sk.verifying_key().to_bytes()
    }
    pub fn address(&self) -> Addr {
        address_from_pubkey(&self.public())
    }
    pub fn sign(&self, msg: &[u8]) -> [u8; 64] {
        self.sk.sign(msg).to_bytes()
    }
}

/// Deterministic test key from a label (tests and vectors only — never for real funds).
pub fn test_keypair(label: &str) -> Keypair {
    let mut seed = hash_domain("AUREOM/TEST-KEY/v1", label.as_bytes());
    let kp = Keypair::from_seed(&seed);
    seed.zeroize();
    kp
}

/// Strict Ed25519 verification (rejects small-order / non-canonical encodings).
pub fn verify(pk: &[u8; 32], msg: &[u8], sig: &[u8; 64]) -> bool {
    let Ok(vk) = VerifyingKey::from_bytes(pk) else { return false };
    let sig = Signature::from_bytes(sig);
    vk.verify_strict(msg, &sig).is_ok()
}

pub fn is_valid_pubkey(pk: &[u8; 32]) -> bool {
    VerifyingKey::from_bytes(pk).map(|k| !k.is_weak()).unwrap_or(false)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn address_roundtrip_and_hrp_check() {
        let kp = test_keypair("alice");
        let a = kp.address();
        let s = bech32_encode("aurd", &a);
        assert!(s.starts_with("aurd1"));
        assert_eq!(bech32_decode20("aurd", &s).unwrap(), a);
        assert!(matches!(bech32_decode20("aur", &s), Err(AddrError::WrongHrp { .. })));
        let mut bad = s.clone();
        bad.pop();
        bad.push(if s.ends_with('q') { 'p' } else { 'q' });
        assert!(bech32_decode20("aurd", &bad).is_err());
    }

    #[test]
    fn signature_verify_strict() {
        let kp = test_keypair("bob");
        let sig = kp.sign(b"hello");
        assert!(verify(&kp.public(), b"hello", &sig));
        assert!(!verify(&kp.public(), b"hellp", &sig));
    }
}

/// Off-chain message signing (e.g. token-gated access challenges). The domain prefix
/// differs from the transaction signing prefix (`AUREOM/TXSIG/v1`), so a signed message
/// can never be valid as a transaction signature and vice versa.
pub fn message_signing_bytes(msg: &[u8]) -> Vec<u8> {
    let d = "AUREOM/MSG/v1";
    let mut v = Vec::with_capacity(msg.len() + d.len() + 5);
    v.push(d.len() as u8);
    v.extend_from_slice(d.as_bytes());
    v.extend_from_slice(&(msg.len() as u32).to_be_bytes());
    v.extend_from_slice(msg);
    v
}
