//! Proof-of-work header, work function, difficulty adjustment and timestamp rules
//! (PROTOCOL.md section 10).

use crate::codec::*;
use crate::crypto::{hash_domain, sha256, Addr, Hash32};
use crate::genesis::ChainParams;
use crate::types::*;
use crate::U256;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PowHeader {
    pub version: u16,
    pub chain_id: String,
    pub height: u64,
    pub prev_id: Hash32,
    pub timestamp_ms: u64,
    pub tx_root: Hash32,
    pub receipt_root: Hash32,
    pub state_root: Hash32,
    pub miner: Addr,
    pub target: [u8; 32],
    pub nonce: u64,
}

impl Encode for PowHeader {
    fn encode_to(&self, w: &mut Writer) {
        w.u16(self.version);
        w.string(&self.chain_id);
        w.u64(self.height);
        w.fixed(&self.prev_id);
        w.u64(self.timestamp_ms);
        w.fixed(&self.tx_root);
        w.fixed(&self.receipt_root);
        w.fixed(&self.state_root);
        w.fixed(&self.miner);
        w.fixed(&self.target);
        w.u64(self.nonce);
    }
}
impl Decode for PowHeader {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(PowHeader {
            version: r.u16()?,
            chain_id: r.string(MAX_CHAIN_ID_LEN)?,
            height: r.u64()?,
            prev_id: r.fixed()?,
            timestamp_ms: r.u64()?,
            tx_root: r.fixed()?,
            receipt_root: r.fixed()?,
            state_root: r.fixed()?,
            miner: r.fixed()?,
            target: r.fixed()?,
            nonce: r.u64()?,
        })
    }
}

impl PowHeader {
    pub fn id(&self) -> Hash32 {
        hash_domain("AUREOM/BLOCK/v1", &self.encode())
    }
    pub fn pow_hash(&self) -> Hash32 {
        sha256(&hash_domain("AUREOM/POW/v1", &self.encode()))
    }
    pub fn target_u256(&self) -> U256 {
        U256::from_big_endian(&self.target)
    }
    pub fn meets_target(&self) -> bool {
        U256::from_big_endian(&self.pow_hash()) <= self.target_u256()
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Block {
    pub header: PowHeader,
    pub txs: Vec<SignedTx>,
}

/// Smallest encoding of a signed tx, used to bound preallocation.
const MIN_TX_BYTES: usize = 2 + 4 + 8 + 8 + 8 + 32 + 1 + 4 + 64;

impl Encode for Block {
    fn encode_to(&self, w: &mut Writer) {
        self.header.encode_to(w);
        w.vec(&self.txs, |w, t| t.encode_to(w));
    }
}
impl Decode for Block {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Block { header: PowHeader::decode_from(r)?, txs: r.vec(10_000, MIN_TX_BYTES, SignedTx::decode_from)? })
    }
}

pub fn u256_to_bytes(v: U256) -> [u8; 32] {
    v.to_big_endian()
}

/// work(t) = floor(2^256 / (t + 1))
pub fn work(target: U256) -> U256 {
    if target == U256::MAX {
        return U256::one();
    }
    if target.is_zero() {
        return U256::MAX;
    }
    // (2^256 - 1 - t) / (t + 1) + 1
    (U256::MAX - target) / (target + U256::one()) + U256::one()
}

/// Expected number of hashes per block for a target (= work).
pub fn difficulty(target: U256) -> f64 {
    let w = work(target);
    // lossy, display only
    let bytes = w.to_big_endian();
    bytes.iter().fold(0f64, |acc, b| acc * 256.0 + *b as f64)
}

/// Target required for the block at `height`, given ancestor timestamps/targets.
/// `ancestor(h)` returns (timestamp_ms, target) of the main-branch ancestor at height h.
pub fn next_target(p: &ChainParams, height: u64, ancestor: &dyn Fn(u64) -> (u64, U256)) -> U256 {
    let pp = p.pow();
    if height == 0 {
        return p.pow_initial_target;
    }
    let (_, prev_target) = ancestor(height - 1);
    let n = pp.retarget_interval;
    if height % n != 0 {
        return prev_target;
    }
    let first = height.saturating_sub(1 + n);
    let (t_last, _) = ancestor(height - 1);
    let (t_first, _) = ancestor(first);
    let span_blocks = (height - 1 - first).max(1);
    let expected = pp.target_block_time_ms.saturating_mul(span_blocks).max(1);
    let actual = t_last.saturating_sub(t_first).clamp((expected / 4).max(1), expected.saturating_mul(4));
    // 512-bit intermediate: target * actual / expected
    let q = prev_target.full_mul(U256::from(actual)) / primitive_types::U512::from(expected);
    let new = U256::try_from(q).unwrap_or(p.pow_limit);
    new.min(p.pow_limit).max(U256::one())
}

/// Median of up to 11 previous timestamps.
pub fn median_time_past(ts: &[u64]) -> u64 {
    if ts.is_empty() {
        return 0;
    }
    let mut v: Vec<u64> = ts.iter().rev().take(11).copied().collect();
    v.sort();
    v[v.len() / 2]
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum HeaderInvalid {
    #[error("wrong version or chain id")]
    Identity,
    #[error("height {got} does not follow parent height {parent}")]
    Height { parent: u64, got: u64 },
    #[error("target mismatch: expected {expected}, got {got}")]
    WrongTarget { expected: String, got: String },
    #[error("proof of work does not meet target")]
    InsufficientWork,
    #[error("timestamp {ts} not greater than median time past {mtp}")]
    TimestampTooOld { ts: u64, mtp: u64 },
    #[error("target outside (0, pow_limit]")]
    TargetRange,
}

/// Context-dependent header checks (everything except the future-drift acceptance rule).
pub fn check_header(p: &ChainParams, h: &PowHeader, parent_height: u64, expected_target: U256, mtp: u64) -> Result<(), HeaderInvalid> {
    if h.version != PROTOCOL_VERSION || h.chain_id != p.doc.chain_id {
        return Err(HeaderInvalid::Identity);
    }
    if h.height != parent_height + 1 {
        return Err(HeaderInvalid::Height { parent: parent_height, got: h.height });
    }
    let t = h.target_u256();
    if t.is_zero() || t > p.pow_limit {
        return Err(HeaderInvalid::TargetRange);
    }
    if t != expected_target {
        return Err(HeaderInvalid::WrongTarget { expected: format!("{expected_target:x}"), got: format!("{t:x}") });
    }
    if !h.meets_target() {
        return Err(HeaderInvalid::InsufficientWork);
    }
    if h.timestamp_ms <= mtp {
        return Err(HeaderInvalid::TimestampTooOld { ts: h.timestamp_ms, mtp });
    }
    Ok(())
}

/// The genesis block (height 0): no transactions, state root of the genesis state.
pub fn genesis_block(p: &ChainParams, genesis_state_root: Hash32) -> Block {
    Block {
        header: PowHeader {
            version: PROTOCOL_VERSION,
            chain_id: p.doc.chain_id.clone(),
            height: 0,
            prev_id: p.hash,
            timestamp_ms: p.doc.genesis_time_ms,
            tx_root: crate::merkle::empty_root(),
            receipt_root: crate::merkle::empty_root(),
            state_root: genesis_state_root,
            miner: [0; 20],
            target: u256_to_bytes(p.pow_initial_target),
            nonce: 0,
        },
        txs: vec![],
    }
}

/// Search nonces; returns true if a solution was found within `max_iters`.
pub fn mine(h: &mut PowHeader, max_iters: u64) -> bool {
    for _ in 0..max_iters {
        if h.meets_target() {
            return true;
        }
        h.nonce = h.nonce.wrapping_add(1);
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::genesis::tests::dev_genesis;

    fn params() -> ChainParams {
        ChainParams::from_value(&dev_genesis("pow")).unwrap()
    }

    #[test]
    fn work_monotonic() {
        let a = U256::from(1000u64);
        assert!(work(a) > work(a * 2));
        assert_eq!(work(U256::MAX), U256::one());
        assert_eq!(work(U256::zero()), U256::MAX); // 2^256/1 saturates, never used (target > 0)
    }

    #[test]
    fn retarget_clamps_and_respects_limit() {
        let p = params();
        let t0 = p.pow_initial_target;
        // blocks 100x too slow -> clamp to 4x easier, capped at pow_limit
        let slow = |h: u64| (h * 100_000, t0);
        let t = next_target(&p, 10, &slow);
        assert_eq!(t, std::cmp::min(t0 * U256::from(4u64), p.pow_limit));
        // blocks instantaneous -> clamp to 1/4
        let fast = |h: u64| (h, t0);
        assert_eq!(next_target(&p, 10, &fast), t0 / U256::from(4u64));
        // exact schedule -> unchanged
        let exact = |h: u64| (h * 1000, t0);
        assert_eq!(next_target(&p, 10, &exact), t0);
        // non-boundary keeps parent target
        assert_eq!(next_target(&p, 11, &fast), t0);
    }

    #[test]
    fn header_checks() {
        let p = params();
        let gb = genesis_block(&p, [1; 32]);
        let mut h = PowHeader { height: 1, prev_id: gb.header.id(), timestamp_ms: gb.header.timestamp_ms + 1, ..gb.header.clone() };
        assert!(mine(&mut h, 10_000_000));
        assert_eq!(check_header(&p, &h, 0, p.pow_initial_target, gb.header.timestamp_ms), Ok(()));
        // wrong target
        let mut bad = h.clone();
        bad.target = u256_to_bytes(p.pow_initial_target / 2);
        assert!(matches!(check_header(&p, &bad, 0, p.pow_initial_target, 0), Err(HeaderInvalid::WrongTarget { .. })));
        // insufficient work: find a nonce that fails
        let mut w = h.clone();
        while w.meets_target() {
            w.nonce += 1;
        }
        assert_eq!(check_header(&p, &w, 0, p.pow_initial_target, 0), Err(HeaderInvalid::InsufficientWork));
        // timestamp not above MTP
        assert!(matches!(check_header(&p, &h, 0, p.pow_initial_target, h.timestamp_ms), Err(HeaderInvalid::TimestampTooOld { .. })));
        // target above pow limit
        let mut big = h.clone();
        big.target = [0xff; 32];
        assert_eq!(check_header(&p, &big, 0, p.pow_initial_target, 0), Err(HeaderInvalid::TargetRange));
    }

    #[test]
    fn mtp() {
        assert_eq!(median_time_past(&[1, 2, 3, 100, 5]), 3);
        assert_eq!(median_time_past(&(0..20).collect::<Vec<_>>()), 14);
    }
}
