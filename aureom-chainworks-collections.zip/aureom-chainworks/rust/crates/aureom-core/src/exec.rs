//! Deterministic state transition function (PROTOCOL.md sections 5–7, 10.6, 11–13).
//!
//! Inputs are limited to: prior state, chain parameters (genesis), block height, block
//! proposer, the ordered transactions and (BFT) the consensus-provided vote and
//! misbehaviour lists. No clocks, randomness, configuration or I/O.

use crate::codec::{Decode, Encode};
use crate::crypto::{comet_address, hash_domain, is_valid_pubkey, Addr, Hash32};
use crate::genesis::{ChainParams, Profile};
use crate::merkle;
use crate::state::{keys, Overlay, State};
use crate::types::*;
use std::collections::{BTreeMap, BTreeSet};

pub mod err {
    pub const INSUFFICIENT_FUNDS: u16 = 1;
    pub const OVERFLOW: u16 = 2;
    pub const UNAUTHORIZED: u16 = 3;
    pub const NOT_FOUND: u16 = 4;
    pub const SUPPLY_CAP: u16 = 5;
    pub const PAUSED: u16 = 6;
    pub const FROZEN: u16 = 7;
    pub const INVALID_ARGUMENT: u16 = 8;
    pub const ALREADY_EXISTS: u16 = 9;
    pub const EXPIRED: u16 = 10;
    pub const ALREADY_CLAIMED: u16 = 11;
    pub const BAD_PROOF: u16 = 12;
    pub const MINT_LIMIT: u16 = 13;
    pub const NOT_ELIGIBLE: u16 = 14;
    pub const JAILED: u16 = 15;
    /// Expected state in the transaction (revision, hash, price) no longer matches.
    pub const STALE: u16 = 16;
    pub const METADATA_FROZEN: u16 = 17;
    pub const NON_TRANSFERABLE: u16 = 18;
    pub const LISTING_INACTIVE: u16 = 19;

    pub fn name(c: u16) -> &'static str {
        match c {
            0 => "OK",
            1 => "INSUFFICIENT_FUNDS",
            2 => "OVERFLOW",
            3 => "UNAUTHORIZED",
            4 => "NOT_FOUND",
            5 => "SUPPLY_CAP",
            6 => "PAUSED",
            7 => "FROZEN",
            8 => "INVALID_ARGUMENT",
            9 => "ALREADY_EXISTS",
            10 => "EXPIRED",
            11 => "ALREADY_CLAIMED",
            12 => "BAD_PROOF",
            13 => "MINT_LIMIT",
            14 => "NOT_ELIGIBLE",
            15 => "JAILED",
            16 => "STALE",
            17 => "METADATA_FROZEN",
            18 => "NON_TRANSFERABLE",
            19 => "LISTING_INACTIVE",
            _ => "UNKNOWN",
        }
    }
}
use err::*;

/// Reasons a transaction is not admissible in a block (PROTOCOL.md 5.5).
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum TxInvalid {
    #[error("malformed transaction: {0}")]
    Decode(String),
    #[error("transaction too large: {size} > {max}")]
    TooLarge { size: usize, max: usize },
    #[error("unsupported transaction version {0}")]
    Version(u16),
    #[error("wrong chain id {0:?}")]
    WrongChain(String),
    #[error("invalid signature")]
    BadSignature,
    #[error("transaction expired at height {0}")]
    Expired(u64),
    #[error("bad nonce: expected {expected}, got {got}")]
    BadNonce { expected: u64, got: u64 },
    #[error("fee {fee} below minimum {min}")]
    FeeTooLow { fee: u64, min: u64 },
    #[error("fee computation overflow")]
    FeeOverflow,
    #[error("insufficient available balance for fee: available {available}, fee {fee}")]
    InsufficientFee { available: u128, fee: u64 },
    #[error("action not supported on this network: {0}")]
    Unsupported(&'static str),
    #[error("memo too long")]
    MemoTooLong,
}

impl TxInvalid {
    pub fn code(&self) -> &'static str {
        match self {
            TxInvalid::Decode(_) => "malformed",
            TxInvalid::TooLarge { .. } => "too_large",
            TxInvalid::Version(_) => "bad_version",
            TxInvalid::WrongChain(_) => "wrong_chain",
            TxInvalid::BadSignature => "bad_signature",
            TxInvalid::Expired(_) => "expired",
            TxInvalid::BadNonce { .. } => "bad_nonce",
            TxInvalid::FeeTooLow { .. } => "fee_too_low",
            TxInvalid::FeeOverflow => "fee_overflow",
            TxInvalid::InsufficientFee { .. } => "insufficient_fee_balance",
            TxInvalid::Unsupported(_) => "unsupported_action",
            TxInvalid::MemoTooLong => "memo_too_long",
        }
    }
}

/// Per-block execution context.
pub struct BlockCtx {
    pub height: u64,
    /// PoW: miner address. BFT: proposer operator address (if mapped).
    pub proposer: Option<Addr>,
    /// Fee remainders owed to the proposer (paid by `pow_coinbase` / `end_block_bft`).
    pub proposer_fees: u128,
}

impl BlockCtx {
    pub fn new(height: u64, proposer: Option<Addr>) -> Self {
        Self { height, proposer, proposer_fees: 0 }
    }
}

pub fn min_fee(p: &ChainParams, size: usize) -> Option<u64> {
    let base = p.doc.fee_policy.base_fee.0 as u64;
    let per = p.doc.fee_policy.per_byte_fee.0 as u64;
    per.checked_mul(size as u64)?.checked_add(base)
}

pub fn decode_tx(p: &ChainParams, bytes: &[u8]) -> Result<SignedTx, TxInvalid> {
    if bytes.len() > p.doc.limits.max_tx_bytes as usize {
        return Err(TxInvalid::TooLarge { size: bytes.len(), max: p.doc.limits.max_tx_bytes as usize });
    }
    SignedTx::decode(bytes).map_err(|e| TxInvalid::Decode(e.to_string()))
}

/// Checks that do not depend on state (rules 1–3, 7, 8 and the fee minimum).
pub fn stateless_check(p: &ChainParams, tx: &SignedTx, size: usize) -> Result<(), TxInvalid> {
    stateless_check_inner(p, tx, size, true)
}

/// Simulation of an unsigned transaction: every stateless rule except the signature.
/// `size` must include the 64-byte signature that will be attached.
pub fn simulate(st: &State, p: &ChainParams, height: u64, u: &UnsignedTx) -> Result<Receipt, TxInvalid> {
    let tx = SignedTx { tx: u.clone(), signature: [0; 64] };
    let size = tx.encode().len();
    stateless_check_inner(p, &tx, size, false)?;
    let mut ov = st.overlay();
    let mut ctx = BlockCtx::new(height, None);
    apply_tx_prechecked(&mut ov, p, &mut ctx, &tx)
    // the overlay is dropped: nothing is committed
}

fn stateless_check_inner(p: &ChainParams, tx: &SignedTx, size: usize, verify_sig: bool) -> Result<(), TxInvalid> {
    let max = p.doc.limits.max_tx_bytes as usize;
    if size > max {
        return Err(TxInvalid::TooLarge { size, max });
    }
    let t = &tx.tx;
    if t.version != TX_VERSION {
        return Err(TxInvalid::Version(t.version));
    }
    if t.chain_id != p.doc.chain_id {
        return Err(TxInvalid::WrongChain(t.chain_id.clone()));
    }
    if t.memo.len() > p.doc.limits.max_memo_bytes as usize {
        return Err(TxInvalid::MemoTooLong);
    }
    action_supported(p, &t.action)?;
    let min = min_fee(p, size).ok_or(TxInvalid::FeeOverflow)?;
    if t.fee < min {
        return Err(TxInvalid::FeeTooLow { fee: t.fee, min });
    }
    if verify_sig && !tx.verify_signature() {
        return Err(TxInvalid::BadSignature);
    }
    Ok(())
}

fn action_supported(p: &ChainParams, a: &Action) -> Result<(), TxInvalid> {
    let prof = p.profile;
    match a {
        Action::Nft(n) => match &p.collections {
            None => Err(TxInvalid::Unsupported("the collections (NFT) module is not enabled in this network's genesis")),
            Some(m) if n.is_marketplace() && !m.marketplace => Err(TxInvalid::Unsupported("the demonstration marketplace is not enabled in this network's genesis")),
            _ => Ok(()),
        },
        Action::MultisigPropose { inner, .. } => action_supported(p, inner),
        Action::NativeMint { .. } if p.doc.monetary_policy.kind != "authority" => {
            Err(TxInvalid::Unsupported("native_mint requires the authority monetary policy"))
        }
        Action::ValidatorCreate { .. }
        | Action::ValidatorBond { .. }
        | Action::ValidatorUnbond { .. }
        | Action::ValidatorUnjail
            if prof != Profile::Pos =>
        {
            Err(TxInvalid::Unsupported("staking actions exist only on proof-of-stake networks"))
        }
        Action::ValidatorRotateKey { .. } if prof == Profile::Pow => {
            Err(TxInvalid::Unsupported("proof-of-work networks have no validators"))
        }
        Action::GovPropose { .. } | Action::GovApprove { .. } if prof == Profile::Pow => {
            Err(TxInvalid::Unsupported("proof-of-work networks have no on-chain governance"))
        }
        Action::GovPropose { kind: GovKind::AddAuthority { .. } | GovKind::RemoveAuthority { .. }, .. }
            if prof != Profile::Poa =>
        {
            Err(TxInvalid::Unsupported("authority changes exist only on proof-of-authority networks"))
        }
        _ => Ok(()),
    }
}

/// `stateful_check` plus module activation (needs chain parameters).
pub fn stateful_check_p(ov: &Overlay, p: &ChainParams, h: u64, tx: &SignedTx) -> Result<(), TxInvalid> {
    let nft = match &tx.tx.action {
        Action::Nft(_) => true,
        Action::MultisigPropose { inner, .. } => matches!(**inner, Action::Nft(_)),
        _ => false,
    };
    if nft {
        if let Some(m) = &p.collections {
            if h < m.activation_height {
                return Err(TxInvalid::Unsupported("the collections (NFT) module is not active yet at this height"));
            }
        }
    }
    stateful_check(ov, h, tx)
}

/// State-dependent admissibility (rules 4–6).
pub fn stateful_check(ov: &Overlay, h: u64, tx: &SignedTx) -> Result<(), TxInvalid> {
    let t = &tx.tx;
    if t.expiry_height != 0 && h > t.expiry_height {
        return Err(TxInvalid::Expired(t.expiry_height));
    }
    let acct = ov.account(&t.sender());
    if t.nonce != acct.nonce {
        return Err(TxInvalid::BadNonce { expected: acct.nonce, got: t.nonce });
    }
    let available = acct.available(h);
    if (t.fee as u128) > available {
        return Err(TxInvalid::InsufficientFee { available, fee: t.fee });
    }
    Ok(())
}

type ActResult = Result<Vec<Event>, u16>;

/// Apply one transaction. `Err` means the transaction is not admissible (the block
/// containing it is invalid); `Ok(receipt)` may still carry `status = failed`.
pub fn apply_tx(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, tx: &SignedTx, size: usize) -> Result<Receipt, TxInvalid> {
    stateless_check(p, tx, size)?;
    apply_tx_prechecked(ov, p, ctx, tx)
}

/// As `apply_tx` but assumes `stateless_check` already passed (signature verified).
pub fn apply_tx_prechecked(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, tx: &SignedTx) -> Result<Receipt, TxInvalid> {
    let h = ctx.height;
    stateful_check_p(ov, p, h, tx)?;
    let t = &tx.tx;
    let sender = t.sender();
    let txid = tx.txid();

    // fee + nonce (always applied for admissible transactions)
    let mut acct = ov.account(&sender);
    acct.balance -= t.fee as u128; // fee <= available <= balance
    acct.nonce += 1;
    acct.prune(h);
    ov.put_account(&sender, &acct);
    let mut events = vec![];
    let burned = crate::mul_div(t.fee as u128, p.doc.fee_policy.burn_bps as u128, 10_000);
    let remainder = t.fee as u128 - burned;
    if burned > 0 {
        let mut s = ov.supply();
        s.burned += burned;
        s.total -= burned;
        ov.put_supply(&s);
    }
    match p.fee_treasury() {
        Some(tr) if remainder > 0 => {
            let mut ta = ov.account(&tr);
            ta.balance = ta.balance.checked_add(remainder).expect("bounded by supply");
            ov.put_account(&tr, &ta);
        }
        _ => ctx.proposer_fees += remainder,
    }
    events.push(Event::new("fee").attr("paid", t.fee).attr("burned", burned).attr("to_recipient", remainder));
    ov.commit_tx();

    let result = exec_action(ov, p, ctx, &sender, t.nonce, &t.action);
    let (status, code) = match result {
        Ok(evs) => {
            ov.commit_tx();
            events.extend(evs);
            (STATUS_SUCCESS, 0)
        }
        Err(c) => {
            ov.rollback_tx();
            (STATUS_FAILED, c)
        }
    };
    Ok(Receipt { txid, status, error_code: code, fee_paid: t.fee, events })
}

pub(crate) fn debit_native(ov: &mut Overlay, h: u64, a: &Addr, amount: u128) -> Result<(), u16> {
    let mut acct = ov.account(a);
    if acct.available(h) < amount {
        return Err(INSUFFICIENT_FUNDS);
    }
    acct.balance -= amount;
    acct.prune(h);
    ov.put_account(a, &acct);
    Ok(())
}

pub(crate) fn credit_native(ov: &mut Overlay, h: u64, a: &Addr, amount: u128) -> Result<(), u16> {
    let mut acct = ov.account(a);
    acct.balance = acct.balance.checked_add(amount).ok_or(OVERFLOW)?;
    acct.prune(h);
    ov.put_account(a, &acct);
    Ok(())
}

fn mint_native(ov: &mut Overlay, p: &ChainParams, amount: u128) -> Result<(), u16> {
    let mut s = ov.supply();
    let total = s.total.checked_add(amount).ok_or(OVERFLOW)?;
    if total > p.max_supply {
        return Err(SUPPLY_CAP);
    }
    s.total = total;
    s.minted = s.minted.checked_add(amount).ok_or(OVERFLOW)?;
    ov.put_supply(&s);
    Ok(())
}

fn burn_native(ov: &mut Overlay, amount: u128) {
    let mut s = ov.supply();
    s.total -= amount;
    s.burned += amount;
    ov.put_supply(&s);
}

fn derive_id(domain: &str, sender: &Addr, nonce: u64) -> Hash32 {
    let mut d = sender.to_vec();
    d.extend_from_slice(&nonce.to_be_bytes());
    hash_domain(domain, &d)
}

pub fn token_id(creator: &Addr, nonce: u64) -> Addr {
    derive_id("AUREOM/TOKEN/v1", creator, nonce)[..20].try_into().unwrap()
}
pub fn multisig_address(creator: &Addr, nonce: u64) -> Addr {
    derive_id("AUREOM/MSIG/v1", creator, nonce)[..20].try_into().unwrap()
}
pub fn distribution_id(creator: &Addr, nonce: u64) -> Hash32 {
    derive_id("AUREOM/DIST/v1", creator, nonce)
}

fn valid_symbol(s: &str) -> bool {
    !s.is_empty() && s.len() <= MAX_SYMBOL_LEN && s.bytes().all(|b| b.is_ascii_uppercase() || b.is_ascii_digit())
}
fn printable(s: &str, max: usize) -> bool {
    s.len() <= max && s.bytes().all(|b| (0x20..0x7f).contains(&b))
}

fn hexs(b: &[u8]) -> String {
    hex::encode(b)
}

pub fn exec_action(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, sender: &Addr, nonce: u64, a: &Action) -> ActResult {
    let h = ctx.height;
    match a {
        Action::Transfer { to, amount } => {
            debit_native(ov, h, sender, *amount)?;
            credit_native(ov, h, to, *amount)?;
            Ok(vec![Event::new("transfer").attr("from", p.addr(sender)).attr("to", p.addr(to)).attr("amount", amount)])
        }
        Action::VestedTransfer { to, amount, start_height, cliff_height, end_height } => {
            if !(*start_height <= *cliff_height && *cliff_height <= *end_height && *start_height < *end_height) || *amount == 0 {
                return Err(INVALID_ARGUMENT);
            }
            debit_native(ov, h, sender, *amount)?;
            let mut acct = ov.account(to);
            acct.prune(h);
            if acct.vesting.len() >= MAX_VESTING_ENTRIES {
                return Err(INVALID_ARGUMENT);
            }
            acct.balance = acct.balance.checked_add(*amount).ok_or(OVERFLOW)?;
            acct.vesting.push(Vesting { total: *amount, start_height: *start_height, cliff_height: *cliff_height, end_height: *end_height });
            ov.put_account(to, &acct);
            Ok(vec![Event::new("vesting")
                .attr("from", p.addr(sender))
                .attr("to", p.addr(to))
                .attr("amount", amount)
                .attr("start", start_height)
                .attr("cliff", cliff_height)
                .attr("end", end_height)])
        }
        Action::NativeMint { to, amount } => {
            let Some(auth) = &p.doc.monetary_policy.authority else { return Err(UNAUTHORIZED) };
            if p.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            let window = h / auth.window_blocks;
            let k = keys::mint_window(window);
            let used = ov.get(&k).map(|v| decode_u128(&v).expect("canonical")).unwrap_or(0);
            let new_used = used.checked_add(*amount).ok_or(OVERFLOW)?;
            if new_used > auth.max_mint_per_window.0 {
                return Err(MINT_LIMIT);
            }
            mint_native(ov, p, *amount)?;
            ov.put(k, u128_value(new_used));
            credit_native(ov, h, to, *amount)?;
            Ok(vec![Event::new("mint").attr("asset", "native").attr("to", p.addr(to)).attr("amount", amount).attr("authority", p.addr(sender))])
        }
        Action::NativeBurn { amount } => {
            debit_native(ov, h, sender, *amount)?;
            burn_native(ov, *amount);
            Ok(vec![Event::new("burn").attr("asset", "native").attr("from", p.addr(sender)).attr("amount", amount)])
        }
        Action::TokenCreate { symbol, name, decimals, initial_supply, initial_recipient, max_supply, mint_authority, admin, flags, metadata_uri } => {
            if !valid_symbol(symbol)
                || name.is_empty()
                || !printable(name, MAX_NAME_LEN)
                || !printable(metadata_uri, MAX_URI_LEN)
                || *decimals > MAX_TOKEN_DECIMALS
                || flags & !(FLAG_PAUSABLE | FLAG_FREEZABLE) != 0
                || (*flags != 0 && admin.is_none())
                || (*flags == 0 && admin.is_some())
            {
                return Err(INVALID_ARGUMENT);
            }
            if let Some(m) = max_supply {
                if initial_supply > m {
                    return Err(SUPPLY_CAP);
                }
            }
            let id = token_id(sender, nonce);
            if ov.token(&id).is_some() {
                return Err(ALREADY_EXISTS);
            }
            let info = TokenInfo {
                symbol: symbol.clone(),
                name: name.clone(),
                decimals: *decimals,
                supply: *initial_supply,
                max_supply: *max_supply,
                creator: *sender,
                mint_authority: *mint_authority,
                admin: *admin,
                flags: *flags,
                paused: false,
                metadata_uri: metadata_uri.clone(),
                created_height: h,
            };
            ov.put_token(&id, &info);
            if *initial_supply > 0 {
                ov.put_token_balance(&id, initial_recipient, &TokenBalance { amount: *initial_supply, frozen: false });
            }
            Ok(vec![Event::new("token_create")
                .attr("token", p.token(&id))
                .attr("symbol", symbol)
                .attr("creator", p.addr(sender))
                .attr("initial_supply", initial_supply)
                .attr("max_supply", max_supply.map(|m| m.to_string()).unwrap_or_else(|| "none".into()))
                .attr("mint_authority", mint_authority.map(|m| p.addr(&m)).unwrap_or_else(|| "none".into()))
                .attr("flags", flags)])
        }
        Action::TokenTransfer { token, to, amount } => {
            let info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.paused {
                return Err(PAUSED);
            }
            let mut fb = ov.token_balance(token, sender);
            let mut tb = ov.token_balance(token, to);
            if fb.frozen || tb.frozen {
                return Err(FROZEN);
            }
            if fb.amount < *amount {
                return Err(INSUFFICIENT_FUNDS);
            }
            if sender != to {
                fb.amount -= amount;
                tb.amount = tb.amount.checked_add(*amount).ok_or(OVERFLOW)?;
                ov.put_token_balance(token, sender, &fb);
                ov.put_token_balance(token, to, &tb);
            }
            Ok(vec![Event::new("token_transfer").attr("token", p.token(token)).attr("from", p.addr(sender)).attr("to", p.addr(to)).attr("amount", amount)])
        }
        Action::TokenMint { token, to, amount } => {
            let mut info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if info.paused {
                return Err(PAUSED);
            }
            let ns = info.supply.checked_add(*amount).ok_or(OVERFLOW)?;
            if let Some(m) = info.max_supply {
                if ns > m {
                    return Err(SUPPLY_CAP);
                }
            }
            let mut tb = ov.token_balance(token, to);
            if tb.frozen {
                return Err(FROZEN);
            }
            tb.amount = tb.amount.checked_add(*amount).ok_or(OVERFLOW)?;
            info.supply = ns;
            ov.put_token(token, &info);
            ov.put_token_balance(token, to, &tb);
            Ok(vec![Event::new("mint").attr("asset", p.token(token)).attr("to", p.addr(to)).attr("amount", amount).attr("authority", p.addr(sender))])
        }
        Action::TokenBurn { token, amount } => {
            let mut info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.paused {
                return Err(PAUSED);
            }
            let mut b = ov.token_balance(token, sender);
            if b.frozen {
                return Err(FROZEN);
            }
            if b.amount < *amount {
                return Err(INSUFFICIENT_FUNDS);
            }
            b.amount -= amount;
            info.supply -= amount;
            ov.put_token(token, &info);
            ov.put_token_balance(token, sender, &b);
            Ok(vec![Event::new("burn").attr("asset", p.token(token)).attr("from", p.addr(sender)).attr("amount", amount)])
        }
        Action::TokenSetPaused { token, paused } => {
            let mut info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.flags & FLAG_PAUSABLE == 0 || info.admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            info.paused = *paused;
            ov.put_token(token, &info);
            Ok(vec![Event::new("token_admin").attr("token", p.token(token)).attr("op", if *paused { "pause" } else { "unpause" }).attr("admin", p.addr(sender))])
        }
        Action::TokenSetFrozen { token, account, frozen } => {
            let info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.flags & FLAG_FREEZABLE == 0 || info.admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            let mut b = ov.token_balance(token, account);
            b.frozen = *frozen;
            ov.put_token_balance(token, account, &b);
            Ok(vec![Event::new("token_admin")
                .attr("token", p.token(token))
                .attr("op", if *frozen { "freeze" } else { "unfreeze" })
                .attr("account", p.addr(account))
                .attr("admin", p.addr(sender))])
        }
        Action::TokenSetMintAuthority { token, new_authority } => {
            let mut info = ov.token(token).ok_or(NOT_FOUND)?;
            if info.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            info.mint_authority = *new_authority;
            ov.put_token(token, &info);
            Ok(vec![Event::new("token_admin")
                .attr("token", p.token(token))
                .attr("op", if new_authority.is_some() { "set_mint_authority" } else { "renounce_mint_authority" })
                .attr("new", new_authority.map(|a| p.addr(&a)).unwrap_or_else(|| "none".into()))])
        }
        Action::MultisigCreate { signers, threshold } => {
            let set: BTreeSet<_> = signers.iter().collect();
            if set.len() != signers.len() || signers.is_empty() || signers.len() > MAX_MSIG_SIGNERS || *threshold == 0 || *threshold as usize > signers.len() {
                return Err(INVALID_ARGUMENT);
            }
            let addr = multisig_address(sender, nonce);
            if ov.multisig(&addr).is_some() || !ov.account(&addr).is_empty() {
                return Err(ALREADY_EXISTS);
            }
            ov.put_multisig(&addr, &Multisig { signers: signers.clone(), threshold: *threshold, next_proposal_id: 0 });
            Ok(vec![Event::new("msig_create").attr("multisig", p.addr(&addr)).attr("threshold", threshold).attr("signers", signers.len())])
        }
        Action::MultisigPropose { multisig, inner, expiry_height } => {
            let mut ms = ov.multisig(multisig).ok_or(NOT_FOUND)?;
            if !ms.signers.contains(sender) {
                return Err(UNAUTHORIZED);
            }
            if !inner.allowed_in_multisig() {
                return Err(INVALID_ARGUMENT);
            }
            if *expiry_height <= h || *expiry_height > h.saturating_add(p.doc.governance.proposal_max_ttl_blocks) {
                return Err(INVALID_ARGUMENT);
            }
            let id = ms.next_proposal_id;
            ms.next_proposal_id += 1;
            ov.put_multisig(multisig, &ms);
            let mut prop = MsigProposal { proposer: *sender, inner: (**inner).clone(), approvals: vec![*sender], expiry_height: *expiry_height, status: PROP_PENDING, error_code: 0 };
            let mut evs = vec![Event::new("msig_propose").attr("multisig", p.addr(multisig)).attr("proposal", id).attr("inner", inner.type_name()).attr("by", p.addr(sender))];
            if prop.approvals.len() >= ms.threshold as usize {
                evs.extend(msig_execute(ov, p, ctx, multisig, id, &mut prop));
            }
            ov.put_msig_proposal(multisig, id, &prop);
            Ok(evs)
        }
        Action::MultisigApprove { multisig, proposal_id } => {
            let ms = ov.multisig(multisig).ok_or(NOT_FOUND)?;
            let mut prop = ov.msig_proposal(multisig, *proposal_id).ok_or(NOT_FOUND)?;
            if !ms.signers.contains(sender) {
                return Err(UNAUTHORIZED);
            }
            if prop.status != PROP_PENDING {
                return Err(INVALID_ARGUMENT);
            }
            if h > prop.expiry_height {
                return Err(EXPIRED);
            }
            if prop.approvals.contains(sender) {
                return Err(ALREADY_EXISTS);
            }
            prop.approvals.push(*sender);
            let mut evs = vec![Event::new("msig_approve").attr("multisig", p.addr(multisig)).attr("proposal", proposal_id).attr("by", p.addr(sender)).attr("approvals", prop.approvals.len())];
            if prop.approvals.len() >= ms.threshold as usize {
                evs.extend(msig_execute(ov, p, ctx, multisig, *proposal_id, &mut prop));
            }
            ov.put_msig_proposal(multisig, *proposal_id, &prop);
            Ok(evs)
        }
        Action::DistributionCreate { asset, total, merkle_root, claim_deadline_height } => {
            if *total == 0 || *claim_deadline_height <= h {
                return Err(INVALID_ARGUMENT);
            }
            match asset {
                AssetId::Native => debit_native(ov, h, sender, *total)?,
                AssetId::Token(t) => {
                    let info = ov.token(t).ok_or(NOT_FOUND)?;
                    if info.paused {
                        return Err(PAUSED);
                    }
                    let mut b = ov.token_balance(t, sender);
                    if b.frozen {
                        return Err(FROZEN);
                    }
                    if b.amount < *total {
                        return Err(INSUFFICIENT_FUNDS);
                    }
                    b.amount -= total;
                    ov.put_token_balance(t, sender, &b);
                }
            }
            let id = distribution_id(sender, nonce);
            if ov.distribution(&id).is_some() {
                return Err(ALREADY_EXISTS);
            }
            ov.put_distribution(&id, &Distribution { creator: *sender, asset: asset.clone(), total: *total, remaining: *total, merkle_root: *merkle_root, claim_deadline_height: *claim_deadline_height, closed: false, claims: 0 });
            Ok(vec![Event::new("distribution_create").attr("dist_id", hexs(&id)).attr("total", total).attr("asset", asset_label(p, asset))])
        }
        Action::DistributionClaim { dist_id, index, amount, proof } => {
            let mut d = ov.distribution(dist_id).ok_or(NOT_FOUND)?;
            if d.closed || h > d.claim_deadline_height {
                return Err(EXPIRED);
            }
            let ck = keys::claimed(dist_id, *index);
            if ov.get(&ck).is_some() {
                return Err(ALREADY_CLAIMED);
            }
            let leaf = claim_leaf(*index, sender, *amount);
            if !merkle::verify_proof(&leaf, proof, &d.merkle_root) {
                return Err(BAD_PROOF);
            }
            if *amount > d.remaining {
                return Err(INSUFFICIENT_FUNDS);
            }
            credit_asset(ov, h, &d.asset, sender, *amount)?;
            d.remaining -= amount;
            d.claims += 1;
            ov.put_distribution(dist_id, &d);
            ov.put(ck, vec![1]);
            Ok(vec![Event::new("distribution_claim").attr("dist_id", hexs(dist_id)).attr("index", index).attr("to", p.addr(sender)).attr("amount", amount)])
        }
        Action::DistributionReclaim { dist_id } => {
            let mut d = ov.distribution(dist_id).ok_or(NOT_FOUND)?;
            if &d.creator != sender {
                return Err(UNAUTHORIZED);
            }
            if d.closed || h <= d.claim_deadline_height {
                return Err(INVALID_ARGUMENT);
            }
            let amt = d.remaining;
            credit_asset(ov, h, &d.asset, sender, amt)?;
            d.remaining = 0;
            d.closed = true;
            ov.put_distribution(dist_id, &d);
            Ok(vec![Event::new("distribution_reclaim").attr("dist_id", hexs(dist_id)).attr("amount", amt)])
        }
        Action::ValidatorCreate { consensus_pubkey, self_bond, moniker } => {
            let pos = p.pos();
            if ov.validator(sender).is_some() {
                return Err(ALREADY_EXISTS);
            }
            if !is_valid_pubkey(consensus_pubkey) || !printable(moniker, MAX_NAME_LEN) {
                return Err(INVALID_ARGUMENT);
            }
            let ca = comet_address(consensus_pubkey);
            if ov.operator_of_consaddr(&ca).is_some() {
                return Err(ALREADY_EXISTS);
            }
            if *self_bond < pos.min_self_bond.0 {
                return Err(NOT_ELIGIBLE);
            }
            debit_native(ov, h, sender, *self_bond)?;
            ov.put_validator(&Validator {
                operator: *sender,
                consensus_pubkey: *consensus_pubkey,
                moniker: moniker.clone(),
                bonded: *self_bond,
                fixed_power: 0,
                jailed_until: 0,
                tombstoned: false,
                missed_in_window: 0,
                window_start: h,
                created_height: h,
                removed: false,
            });
            ov.put(keys::consaddr(&ca), sender.to_vec());
            Ok(vec![Event::new("validator_create").attr("operator", p.addr(sender)).attr("self_bond", self_bond)])
        }
        Action::ValidatorBond { amount } => {
            let mut v = ov.validator(sender).ok_or(NOT_FOUND)?;
            if v.tombstoned {
                return Err(NOT_ELIGIBLE);
            }
            debit_native(ov, h, sender, *amount)?;
            v.bonded = v.bonded.checked_add(*amount).ok_or(OVERFLOW)?;
            ov.put_validator(&v);
            Ok(vec![Event::new("stake").attr("operator", p.addr(sender)).attr("bond", amount).attr("bonded", v.bonded)])
        }
        Action::ValidatorUnbond { amount } => {
            let mut v = ov.validator(sender).ok_or(NOT_FOUND)?;
            if *amount == 0 || *amount > v.bonded {
                return Err(INSUFFICIENT_FUNDS);
            }
            v.bonded -= amount;
            ov.put_validator(&v);
            let complete = h + p.pos().unbonding_period_blocks;
            let seq = next_unbonding_seq(ov);
            ov.put(keys::unbonding(complete, sender, seq), Unbonding { amount: *amount, start_height: h }.encode());
            ov.mark_valset_dirty();
            Ok(vec![Event::new("stake").attr("operator", p.addr(sender)).attr("unbond", amount).attr("completes_at", complete)])
        }
        Action::ValidatorUnjail => {
            let mut v = ov.validator(sender).ok_or(NOT_FOUND)?;
            if v.tombstoned {
                return Err(NOT_ELIGIBLE);
            }
            if v.jailed_until == 0 {
                return Err(INVALID_ARGUMENT);
            }
            if v.jailed_until > h {
                return Err(JAILED);
            }
            v.jailed_until = 0;
            v.missed_in_window = 0;
            v.window_start = h;
            ov.put_validator(&v);
            ov.mark_valset_dirty();
            Ok(vec![Event::new("validator_update").attr("operator", p.addr(sender)).attr("op", "unjail")])
        }
        Action::ValidatorRotateKey { new_consensus_pubkey } => {
            let mut v = ov.validator(sender).ok_or(NOT_FOUND)?;
            if v.removed || v.tombstoned {
                return Err(NOT_ELIGIBLE);
            }
            if !is_valid_pubkey(new_consensus_pubkey) {
                return Err(INVALID_ARGUMENT);
            }
            let ca = comet_address(new_consensus_pubkey);
            if ov.operator_of_consaddr(&ca).is_some() {
                return Err(ALREADY_EXISTS);
            }
            let old = v.consensus_pubkey;
            v.consensus_pubkey = *new_consensus_pubkey;
            ov.put_validator(&v);
            ov.put(keys::consaddr(&ca), sender.to_vec());
            ov.mark_valset_dirty();
            Ok(vec![Event::new("validator_update")
                .attr("operator", p.addr(sender))
                .attr("op", "rotate_key")
                .attr("old_key", hexs(&old))
                .attr("new_key", hexs(new_consensus_pubkey))])
        }
        Action::GovPropose { kind, expiry_height } => {
            let govs = governors(ov);
            if !govs.contains_key(sender) {
                return Err(UNAUTHORIZED);
            }
            if *expiry_height <= h || *expiry_height > h.saturating_add(p.doc.governance.proposal_max_ttl_blocks) {
                return Err(INVALID_ARGUMENT);
            }
            validate_gov_kind(ov, h, kind)?;
            let mut gs = ov.gov_state();
            let id = gs.next_id;
            gs.next_id += 1;
            ov.put_gov_state(&gs);
            let mut prop = GovProposal { id, proposer: *sender, kind: kind.clone(), created_height: h, expiry_height: *expiry_height, approvals: vec![*sender], status: PROP_PENDING, executed_height: 0 };
            let mut evs = vec![Event::new("gov").attr("op", "propose").attr("proposal", id).attr("by", p.addr(sender)).attr("kind", gov_kind_name(kind))];
            evs.extend(gov_try_execute(ov, p, h, &mut prop, &govs));
            ov.put_gov_proposal(&prop);
            Ok(evs)
        }
        Action::GovApprove { proposal_id } => {
            let govs = governors(ov);
            if !govs.contains_key(sender) {
                return Err(UNAUTHORIZED);
            }
            let mut prop = ov.gov_proposal(*proposal_id).ok_or(NOT_FOUND)?;
            if prop.status != PROP_PENDING {
                return Err(INVALID_ARGUMENT);
            }
            if h > prop.expiry_height {
                return Err(EXPIRED);
            }
            if prop.approvals.contains(sender) {
                return Err(ALREADY_EXISTS);
            }
            prop.approvals.push(*sender);
            let mut evs = vec![Event::new("gov").attr("op", "approve").attr("proposal", proposal_id).attr("by", p.addr(sender))];
            evs.extend(gov_try_execute(ov, p, h, &mut prop, &govs));
            ov.put_gov_proposal(&prop);
            Ok(evs)
        }
        Action::Nft(n) => crate::nft::exec(ov, p, ctx, sender, nonce, n),
    }
}

fn asset_label(p: &ChainParams, a: &AssetId) -> String {
    match a {
        AssetId::Native => "native".into(),
        AssetId::Token(t) => p.token(t),
    }
}

fn credit_asset(ov: &mut Overlay, h: u64, asset: &AssetId, to: &Addr, amount: u128) -> Result<(), u16> {
    match asset {
        AssetId::Native => credit_native(ov, h, to, amount),
        AssetId::Token(t) => {
            let mut b = ov.token_balance(t, to);
            if b.frozen {
                return Err(FROZEN);
            }
            b.amount = b.amount.checked_add(amount).ok_or(OVERFLOW)?;
            ov.put_token_balance(t, to, &b);
            Ok(())
        }
    }
}

fn msig_execute(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, msig: &Addr, id: u64, prop: &mut MsigProposal) -> Vec<Event> {
    let sp = ov.tx_savepoint();
    match exec_action(ov, p, ctx, msig, id, &prop.inner.clone()) {
        Ok(mut evs) => {
            prop.status = PROP_EXECUTED;
            evs.insert(0, Event::new("msig_execute").attr("multisig", p.addr(msig)).attr("proposal", id).attr("result", "executed"));
            evs
        }
        Err(c) => {
            ov.tx_restore(sp);
            prop.status = PROP_FAILED;
            prop.error_code = c;
            vec![Event::new("msig_execute").attr("multisig", p.addr(msig)).attr("proposal", id).attr("result", "failed").attr("error", err::name(c))]
        }
    }
}

fn next_unbonding_seq(ov: &mut Overlay) -> u64 {
    let k = keys::valcounters();
    let cur = ov.get(&k).map(|v| decode_u64(&v).expect("canonical")).unwrap_or(0);
    ov.put(k, (cur + 1).to_be_bytes().to_vec());
    cur
}

/// Current governors: operators of the applied validator set with power > 0.
pub fn governors(ov: &Overlay) -> BTreeMap<Addr, u64> {
    let mut m = BTreeMap::new();
    for (pk, power) in ov.valset().0 {
        if power == 0 {
            continue;
        }
        if let Some(op) = ov.operator_of_consaddr(&comet_address(&pk)) {
            *m.entry(op).or_insert(0) += power;
        }
    }
    m
}

fn gov_kind_name(k: &GovKind) -> &'static str {
    match k {
        GovKind::AddAuthority { .. } => "add_authority",
        GovKind::RemoveAuthority { .. } => "remove_authority",
        GovKind::ProtocolUpgrade { .. } => "protocol_upgrade",
        GovKind::Text { .. } => "text",
    }
}

fn validate_gov_kind(ov: &Overlay, h: u64, k: &GovKind) -> Result<(), u16> {
    match k {
        GovKind::AddAuthority { operator, consensus_pubkey, power, moniker } => {
            if *power == 0 || !is_valid_pubkey(consensus_pubkey) || !printable(moniker, MAX_NAME_LEN) {
                return Err(INVALID_ARGUMENT);
            }
            if let Some(v) = ov.validator(operator) {
                if !v.removed {
                    return Err(ALREADY_EXISTS);
                }
            }
            if let Some(op) = ov.operator_of_consaddr(&comet_address(consensus_pubkey)) {
                if &op != operator {
                    return Err(ALREADY_EXISTS);
                }
            }
            Ok(())
        }
        GovKind::RemoveAuthority { operator } => match ov.validator(operator) {
            Some(v) if !v.removed => Ok(()),
            _ => Err(NOT_FOUND),
        },
        GovKind::ProtocolUpgrade { name, protocol_version, activation_height } => {
            if *protocol_version <= PROTOCOL_VERSION || *activation_height <= h || !printable(name, MAX_NAME_LEN) {
                return Err(INVALID_ARGUMENT);
            }
            Ok(())
        }
        GovKind::Text { title, uri } => {
            if !printable(title, MAX_NAME_LEN) || !printable(uri, MAX_URI_LEN) {
                return Err(INVALID_ARGUMENT);
            }
            Ok(())
        }
    }
}

fn gov_try_execute(ov: &mut Overlay, p: &ChainParams, h: u64, prop: &mut GovProposal, govs: &BTreeMap<Addr, u64>) -> Vec<Event> {
    let total: u128 = govs.values().map(|x| *x as u128).sum();
    let approving: u128 = prop.approvals.iter().filter_map(|a| govs.get(a)).map(|x| *x as u128).sum();
    let g = &p.doc.governance;
    if approving * (g.approval_threshold_den as u128) <= total * (g.approval_threshold_num as u128) {
        return vec![];
    }
    // re-validate at execution time (state may have changed since proposal)
    if let Err(c) = validate_gov_kind(ov, h, &prop.kind) {
        prop.status = PROP_FAILED;
        prop.executed_height = h;
        return vec![Event::new("gov").attr("op", "execute").attr("proposal", prop.id).attr("result", "failed").attr("error", err::name(c))];
    }
    let mut evs = vec![];
    match &prop.kind {
        GovKind::AddAuthority { operator, consensus_pubkey, power, moniker } => {
            let mut v = ov.validator(operator).unwrap_or(Validator {
                operator: *operator,
                consensus_pubkey: *consensus_pubkey,
                moniker: moniker.clone(),
                bonded: 0,
                fixed_power: *power,
                jailed_until: 0,
                tombstoned: false,
                missed_in_window: 0,
                window_start: h,
                created_height: h,
                removed: false,
            });
            v.removed = false;
            v.tombstoned = false;
            v.consensus_pubkey = *consensus_pubkey;
            v.fixed_power = *power;
            v.moniker = moniker.clone();
            ov.put_validator(&v);
            ov.put(keys::consaddr(&comet_address(consensus_pubkey)), operator.to_vec());
            ov.mark_valset_dirty();
            evs.push(Event::new("validator_update").attr("operator", p.addr(operator)).attr("op", "add_authority").attr("power", power));
        }
        GovKind::RemoveAuthority { operator } => {
            let active = ov.validators().iter().filter(|v| !v.removed && !v.tombstoned).count();
            if active <= 1 {
                prop.status = PROP_FAILED;
                prop.executed_height = h;
                return vec![Event::new("gov").attr("op", "execute").attr("proposal", prop.id).attr("result", "failed").attr("error", "would_empty_validator_set")];
            }
            let mut v = ov.validator(operator).expect("validated");
            v.removed = true;
            ov.put_validator(&v);
            ov.mark_valset_dirty();
            evs.push(Event::new("validator_update").attr("operator", p.addr(operator)).attr("op", "remove_authority"));
        }
        GovKind::ProtocolUpgrade { name, protocol_version, activation_height } => {
            let mut gs = ov.gov_state();
            gs.upgrades.push(ScheduledUpgrade { name: name.clone(), protocol_version: *protocol_version, activation_height: *activation_height });
            ov.put_gov_state(&gs);
            evs.push(Event::new("gov").attr("op", "schedule_upgrade").attr("version", protocol_version).attr("height", activation_height));
        }
        GovKind::Text { .. } => {}
    }
    prop.status = PROP_EXECUTED;
    prop.executed_height = h;
    evs.insert(0, Event::new("gov").attr("op", "execute").attr("proposal", prop.id).attr("result", "executed"));
    evs
}

/// Halts execution at an activated upgrade this software does not implement (PROTOCOL.md 13).
pub fn check_upgrade_halt(ov: &Overlay, h: u64) -> Result<(), String> {
    for u in ov.gov_state().upgrades {
        if h >= u.activation_height && u.protocol_version > crate::SUPPORTED_PROTOCOL_VERSION {
            return Err(format!(
                "upgrade {:?} to protocol v{} activated at height {}; this software supports v{} — halting (install the upgraded release)",
                u.name, u.protocol_version, u.activation_height, crate::SUPPORTED_PROTOCOL_VERSION
            ));
        }
    }
    Ok(())
}

/// Scheduled issuance for height `h` (before cap).
pub fn scheduled_reward(p: &ChainParams, h: u64) -> u128 {
    match (&p.doc.monetary_policy.kind[..], &p.doc.monetary_policy.scheduled) {
        ("scheduled", Some(s)) => {
            let halvings = h / s.halving_interval_blocks;
            if halvings >= 128 {
                0
            } else {
                s.initial_block_reward.0 >> halvings
            }
        }
        _ => 0,
    }
}

fn capped_reward(ov: &Overlay, p: &ChainParams, r: u128) -> u128 {
    let s = ov.supply();
    r.min(p.max_supply.saturating_sub(s.total))
}

/// PoW coinbase: reward + fee remainder to the miner as an immature balance.
pub fn pow_coinbase(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, miner: &Addr) -> Vec<Event> {
    let h = ctx.height;
    let reward = capped_reward(ov, p, scheduled_reward(p, h));
    if reward > 0 {
        mint_native(ov, p, reward).expect("capped");
    }
    let payout = reward + std::mem::take(&mut ctx.proposer_fees);
    let mut evs = vec![];
    if payout > 0 {
        let mut a = ov.account(miner);
        a.prune(h);
        a.balance += payout;
        a.immature.push(Immature { mature_height: h + p.pow().coinbase_maturity, amount: payout });
        ov.put_account(miner, &a);
        evs.push(Event::new("reward").attr("to", p.addr(miner)).attr("minted", reward).attr("fees", payout - reward).attr("mature_height", h + p.pow().coinbase_maturity));
    }
    ov.commit_tx();
    evs
}

#[derive(Clone, Debug)]
pub struct VoteInfo {
    pub consensus_address: Addr,
    pub power: u64,
    pub signed: bool,
}

#[derive(Clone, Debug)]
pub struct Misbehavior {
    pub consensus_address: Addr,
    pub height: u64,
    pub kind: String,
}

/// BFT begin-of-block processing: upgrade halt, evidence, liveness, rewards.
pub fn begin_block_bft(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, votes: &[VoteInfo], evidence: &[Misbehavior]) -> Result<Vec<Event>, String> {
    let h = ctx.height;
    check_upgrade_halt(ov, h)?;
    let mut evs = vec![];
    // ---- proven misconduct (verified by CometBFT before delivery)
    for e in evidence {
        let Some(op) = ov.operator_of_consaddr(&e.consensus_address) else { continue };
        let Some(mut v) = ov.validator(&op) else { continue };
        if v.tombstoned {
            continue;
        }
        match p.profile {
            Profile::Pos => {
                let bps = p.pos().slash_double_sign_bps as u128;
                let mut slashed = crate::mul_div(v.bonded, bps, 10_000);
                v.bonded -= slashed;
                // unbonding stake that started after the infraction is still slashable
                for (k, val) in ov.scan_prefix(&[0x12]) {
                    if k[9..29] != op[..] {
                        continue;
                    }
                    let mut u = Unbonding::decode(&val).expect("canonical");
                    if u.start_height >= e.height {
                        let s = crate::mul_div(u.amount, bps, 10_000);
                        u.amount -= s;
                        slashed += s;
                        ov.put(k, u.encode());
                    }
                }
                if slashed > 0 {
                    burn_native(ov, slashed);
                }
                v.tombstoned = true;
                v.jailed_until = u64::MAX;
                evs.push(Event::new("slash").attr("operator", p.addr(&op)).attr("reason", "equivocation").attr("evidence", &e.kind).attr("infraction_height", e.height).attr("burned", slashed));
            }
            _ => {
                v.tombstoned = true;
                v.removed = true;
                evs.push(Event::new("slash").attr("operator", p.addr(&op)).attr("reason", "equivocation").attr("evidence", &e.kind).attr("infraction_height", e.height).attr("action", "authority_removed"));
            }
        }
        ov.put_validator(&v);
        ov.mark_valset_dirty();
    }
    // ---- liveness (PoS only; downtime is not misconduct)
    if p.profile == Profile::Pos {
        let pos = p.pos();
        for vote in votes {
            let Some(op) = ov.operator_of_consaddr(&vote.consensus_address) else { continue };
            let Some(mut v) = ov.validator(&op) else { continue };
            if v.tombstoned || v.jailed_until > h {
                continue;
            }
            if h >= v.window_start + pos.downtime_window {
                v.window_start = h;
                v.missed_in_window = 0;
            }
            if !vote.signed {
                v.missed_in_window += 1;
            }
            if v.missed_in_window > pos.downtime_max_missed {
                let slashed = crate::mul_div(v.bonded, pos.slash_downtime_bps as u128, 10_000);
                v.bonded -= slashed;
                if slashed > 0 {
                    burn_native(ov, slashed);
                }
                v.jailed_until = h + pos.jail_duration_blocks;
                v.missed_in_window = 0;
                v.window_start = h;
                ov.mark_valset_dirty();
                evs.push(Event::new("slash").attr("operator", p.addr(&op)).attr("reason", "downtime").attr("burned", slashed).attr("jailed_until", v.jailed_until));
            }
            ov.put_validator(&v);
        }
    }
    // ---- rewards to signers of the previous block, pro rata by power
    let reward = capped_reward(ov, p, scheduled_reward(p, h));
    let signers: Vec<(Addr, u64)> = votes
        .iter()
        .filter(|v| v.signed && v.power > 0)
        .filter_map(|v| ov.operator_of_consaddr(&v.consensus_address).map(|op| (op, v.power)))
        .collect();
    let total_power: u128 = signers.iter().map(|(_, p)| *p as u128).sum();
    if reward > 0 && total_power > 0 {
        let mut distributed = 0u128;
        for (op, pw) in &signers {
            let share = crate::mul_div(reward, *pw as u128, total_power);
            if share > 0 {
                credit_native(ov, h, op, share).expect("bounded by supply");
                distributed += share;
            }
        }
        let remainder = reward - distributed;
        let mut minted = distributed;
        if remainder > 0 {
            if let Some(prop) = ctx.proposer {
                credit_native(ov, h, &prop, remainder).expect("bounded");
                minted += remainder;
            }
        }
        mint_native(ov, p, minted).expect("capped");
        evs.push(Event::new("reward").attr("minted", minted).attr("recipients", signers.len()));
    }
    ov.commit_tx();
    Ok(evs)
}

/// BFT end-of-block: proposer fees, unbonding maturity, validator-set update.
/// Returns validator updates `(pubkey, power)` for CometBFT (power 0 = remove).
pub fn end_block_bft(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx) -> (Vec<([u8; 32], u64)>, Vec<Event>) {
    let h = ctx.height;
    let mut evs = vec![];
    let fees = std::mem::take(&mut ctx.proposer_fees);
    if fees > 0 {
        match ctx.proposer {
            Some(prop) => {
                credit_native(ov, h, &prop, fees).expect("bounded");
                evs.push(Event::new("fee_payout").attr("to", p.addr(&prop)).attr("amount", fees));
            }
            None => {
                burn_native(ov, fees);
                evs.push(Event::new("burn").attr("asset", "native").attr("reason", "unmapped_proposer_fees").attr("amount", fees));
            }
        }
    }
    if p.profile == Profile::Pos {
        let mut end = keys::unbonding(h, &[0xff; 20], u64::MAX);
        end.push(0xff);
        for (k, v) in ov.scan_prefix(&[0x12]) {
            if k > end {
                break;
            }
            let op: Addr = k[9..29].try_into().unwrap();
            let u = Unbonding::decode(&v).expect("canonical");
            if u.amount > 0 {
                credit_native(ov, h, &op, u.amount).expect("bounded");
            }
            ov.delete(k);
            evs.push(Event::new("stake").attr("operator", p.addr(&op)).attr("unbonding_complete", u.amount));
        }
    }
    let dirty = ov.get(&keys::valset_dirty()).is_some();
    let epoch = p.profile == Profile::Poa || h % p.pos().epoch_length == 0;
    let mut updates = vec![];
    if dirty || epoch {
        let new = compute_valset(ov, p, h);
        let old = ov.valset();
        if new.0.is_empty() {
            evs.push(Event::new("validator_update").attr("op", "refused_empty_set"));
        } else if new != old {
            let oldm: BTreeMap<_, _> = old.0.iter().cloned().collect();
            let newm: BTreeMap<_, _> = new.0.iter().cloned().collect();
            for (k, _) in &oldm {
                if !newm.contains_key(k) {
                    updates.push((*k, 0));
                }
            }
            for (k, pw) in &newm {
                if oldm.get(k) != Some(pw) {
                    updates.push((*k, *pw));
                }
            }
            updates.sort();
            ov.put(keys::valset(), new.encode());
            evs.push(Event::new("validator_update").attr("op", "set_changed").attr("updates", updates.len()).attr("size", new.0.len()));
        }
        ov.delete(keys::valset_dirty());
    }
    ov.commit_tx();
    (updates, evs)
}

pub fn compute_valset(ov: &Overlay, p: &ChainParams, h: u64) -> ValSet {
    let vals = ov.validators();
    let mut set: Vec<([u8; 32], u64)> = match p.profile {
        Profile::Pos => {
            let pos = p.pos();
            let mut c: Vec<&Validator> = vals
                .iter()
                .filter(|v| !v.tombstoned && v.jailed_until <= h && v.bonded >= pos.min_self_bond.0 && v.bonded / pos.power_unit.0 >= 1)
                .collect();
            c.sort_by(|a, b| b.bonded.cmp(&a.bonded).then(a.operator.cmp(&b.operator)));
            c.truncate(pos.max_validators as usize);
            c.iter().map(|v| (v.consensus_pubkey, (v.bonded / pos.power_unit.0) as u64)).collect()
        }
        _ => vals.iter().filter(|v| !v.removed && !v.tombstoned && v.fixed_power > 0).map(|v| (v.consensus_pubkey, v.fixed_power)).collect(),
    };
    set.sort();
    ValSet(set)
}

/// Execute an ordered list of transactions. Returns receipts or the index of the
/// first inadmissible transaction.
pub fn execute_txs(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, txs: &[SignedTx]) -> Result<Vec<Receipt>, (usize, TxInvalid)> {
    let mut out = Vec::with_capacity(txs.len());
    for (i, tx) in txs.iter().enumerate() {
        let size = tx.encode().len();
        out.push(apply_tx(ov, p, ctx, tx, size).map_err(|e| (i, e))?);
    }
    Ok(out)
}

// ------------------------------------------------------------------ supply reconciliation

#[derive(Clone, Debug, Default, serde::Serialize)]
pub struct SupplyReport {
    pub total: String,
    pub genesis: String,
    pub minted: String,
    pub burned: String,
    pub sum_balances: String,
    pub staked: String,
    pub unbonding: String,
    pub escrow: String,
    pub locked_vesting: String,
    pub immature: String,
    pub treasury: String,
    pub circulating: String,
    pub max_supply: String,
    pub reconciled: bool,
    pub tokens_reconciled: bool,
    /// Collections module: token records vs minted/burned counters, listing pointers.
    pub nfts_reconciled: bool,
    pub problems: Vec<String>,
}

/// Recompute every balance and check the supply invariants (PROTOCOL.md 6.4).
pub fn reconcile(st: &State, p: &ChainParams, h: u64) -> SupplyReport {
    let s = st.supply();
    let mut balances = 0u128;
    let mut locked = 0u128;
    let mut immature = 0u128;
    let mut treasury = 0u128;
    let mut staked = 0u128;
    let mut unbonding = 0u128;
    let mut escrow = 0u128;
    let mut token_sums: BTreeMap<Addr, u128> = BTreeMap::new();
    let mut token_supply: BTreeMap<Addr, u128> = BTreeMap::new();
    let mut problems = vec![];
    for (k, v) in st.entries() {
        match k[0] {
            0x01 => {
                let a = Account::decode(v).expect("canonical");
                balances += a.balance;
                locked += a.locked(h);
                immature += a.immature_amount(h);
                let addr: Addr = k[1..21].try_into().unwrap();
                if p.treasury_addrs.contains(&addr) {
                    treasury += a.balance;
                }
            }
            0x02 => {
                let t = TokenInfo::decode(v).expect("canonical");
                token_supply.insert(k[1..21].try_into().unwrap(), t.supply);
            }
            0x03 => {
                let b = TokenBalance::decode(v).expect("canonical");
                *token_sums.entry(k[1..21].try_into().unwrap()).or_default() += b.amount;
            }
            0x06 => {
                let d = Distribution::decode(v).expect("canonical");
                match d.asset {
                    AssetId::Native => escrow += d.remaining,
                    AssetId::Token(t) => *token_sums.entry(t).or_default() += d.remaining,
                }
            }
            0x10 => staked += Validator::decode(v).expect("canonical").bonded,
            0x12 => unbonding += Unbonding::decode(v).expect("canonical").amount,
            _ => {}
        }
    }
    let accounted = balances + staked + unbonding + escrow;
    let ok = accounted == s.total && s.genesis + s.minted - s.burned == s.total;
    if !ok {
        problems.push(format!("native supply mismatch: recorded {} vs accounted {}", s.total, accounted));
    }
    let mut tok_ok = true;
    for (t, sup) in &token_supply {
        let sum = token_sums.get(t).copied().unwrap_or(0);
        if sum != *sup {
            tok_ok = false;
            problems.push(format!("token {} supply {} != balances {}", p.token(t), sup, sum));
        }
    }
    let nft_entries: Vec<(&Vec<u8>, &Vec<u8>)> = st.entries().filter(|(k, _)| (0x40..=0x4A).contains(&k[0])).collect();
    let (nft_ok, nft_problems) = crate::nft::reconcile(&nft_entries, p);
    problems.extend(nft_problems);
    let circulating = s.total.saturating_sub(locked).saturating_sub(immature).saturating_sub(staked + unbonding).saturating_sub(escrow).saturating_sub(treasury);
    SupplyReport {
        total: s.total.to_string(),
        genesis: s.genesis.to_string(),
        minted: s.minted.to_string(),
        burned: s.burned.to_string(),
        sum_balances: balances.to_string(),
        staked: staked.to_string(),
        unbonding: unbonding.to_string(),
        escrow: escrow.to_string(),
        locked_vesting: locked.to_string(),
        immature: immature.to_string(),
        treasury: treasury.to_string(),
        circulating: circulating.to_string(),
        max_supply: if p.max_supply == u128::MAX { "none".into() } else { p.max_supply.to_string() },
        reconciled: ok,
        tokens_reconciled: tok_ok,
        nfts_reconciled: nft_ok,
        problems,
    }
}

