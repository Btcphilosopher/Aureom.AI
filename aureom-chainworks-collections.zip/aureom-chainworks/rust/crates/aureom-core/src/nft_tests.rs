//! Collections-module tests: supply limits, unique identifiers, permissions, duplicate
//! mint requests, failed transactions, ownership changes, approvals, metadata policies
//! and freezing, marketplace settlement accounting and replay, drops, reconciliation,
//! receipt encodability, determinism and undo (reorganisation).

use crate::codec::{Decode, Encode};
use crate::crypto::{test_keypair, Addr, Keypair};
use crate::exec::{self, err, BlockCtx, TxInvalid};
use crate::genesis::{tests::dev_genesis, ChainParams};
use crate::merkle;
use crate::nft::{self, *};
use crate::state::State;
use crate::types::*;

struct Net {
    p: ChainParams,
    st: State,
    h: u64,
}

fn genesis_with(market: bool, fee_bps: u32) -> serde_json::Value {
    let mut g = dev_genesis("pow");
    let fee_to = crate::crypto::bech32_encode("aurd", &kp("platform").address());
    let mut c = serde_json::json!({"activation_height": 0, "marketplace": market});
    if market && fee_bps > 0 {
        c["marketplace_fee_bps"] = fee_bps.into();
        c["marketplace_fee_recipient"] = fee_to.into();
    }
    g["modules"] = serde_json::json!({ "collections": c });
    // fund the NFT actors
    for (l, amt) in [("artist", "1000000000"), ("collector", "1000000000"), ("buyer", "1000000000"), ("buyer2", "1000000000"), ("op", "1000000000"), ("poor", "20000"), ("t1", "1000000000"), ("t2", "1000000000")] {
        g["allocations"].as_array_mut().unwrap().push(serde_json::json!({"address": crate::crypto::bech32_encode("aurd", &kp(l).address()), "amount": amt, "label": l}));
    }
    g
}

impl Net {
    fn new() -> Self {
        Self::from(genesis_with(true, 250))
    }
    fn from(g: serde_json::Value) -> Self {
        let p = ChainParams::from_value(&g).unwrap();
        let st = p.genesis_state();
        Net { p, st, h: 0 }
    }
    fn tx(&self, k: &Keypair, nonce: u64, a: Action) -> SignedTx {
        UnsignedTx { version: 1, chain_id: self.p.doc.chain_id.clone(), nonce, fee: 20_000, expiry_height: 0, sender_pubkey: k.public(), action: a, memo: vec![] }.sign(k)
    }
    fn nonce(&self, k: &Keypair) -> u64 {
        self.st.account(&k.address()).nonce
    }
    fn block(&mut self, txs: &[SignedTx]) -> Result<Vec<Receipt>, TxInvalid> {
        let h = self.h + 1;
        let miner = kp("miner").address();
        let mut ctx = BlockCtx::new(h, Some(miner));
        let mut ov = self.st.overlay();
        let r = exec::execute_txs(&mut ov, &self.p, &mut ctx, txs).map_err(|e| e.1)?;
        exec::pow_coinbase(&mut ov, &self.p, &mut ctx, &miner);
        let cs = ov.into_changes();
        self.st.apply(&cs);
        self.h = h;
        let rep = exec::reconcile(&self.st, &self.p, h);
        assert!(rep.reconciled && rep.tokens_reconciled && rep.nfts_reconciled, "invariant violated: {:?}", rep.problems);
        for rc in &r {
            // receipts must stay within the canonical decoder's limits (event sizes)
            assert_eq!(&Receipt::decode(&rc.encode()).expect("receipt decodes"), rc);
        }
        Ok(r)
    }
    fn send(&mut self, k: &Keypair, a: NftAction) -> Receipt {
        self.send_action(k, Action::Nft(a))
    }
    fn send_action(&mut self, k: &Keypair, a: Action) -> Receipt {
        let t = self.tx(k, self.nonce(k), a);
        self.block(&[t]).unwrap().remove(0)
    }
    fn tok(&self, c: &Addr, id: u64) -> NftRecord {
        nft::token(&self.st.overlay(), c, id).expect("token exists")
    }
    fn col(&self, c: &Addr) -> Collection {
        nft::collection(&self.st.overlay(), c).unwrap()
    }
    fn bal(&self, k: &Keypair) -> u128 {
        self.st.account(&k.address()).balance
    }
}

fn kp(l: &str) -> Keypair {
    test_keypair(l)
}
fn h32(s: &str) -> [u8; 32] {
    crate::crypto::sha256(s.as_bytes())
}
fn meta(s: &str) -> MetadataRef {
    MetadataRef { uri: format!("ipfs://bafkdemo{s}/metadata.json"), hash: h32(s) }
}
fn ok(r: &Receipt) {
    assert_eq!(r.status, STATUS_SUCCESS, "expected success, got {}", err::name(r.error_code));
}
fn fail(r: &Receipt, code: u16) {
    assert_eq!((r.status, err::name(r.error_code)), (STATUS_FAILED, err::name(code)));
}

fn spec(slug: &str, policy: u8) -> CollectionSpec {
    CollectionSpec {
        slug: slug.into(),
        name: "Tidewater Lanterns".into(),
        collection_metadata: meta("collection"),
        max_supply: Some(5),
        mint_authority: Some(kp("artist").address()),
        metadata_policy: policy,
        metadata_admin: if policy == POLICY_IMMUTABLE { None } else { Some(kp("artist").address()) },
        admin: None,
        flags: CFLAG_OWNER_BURN,
        transfer_policy: TRANSFER_FREE,
        royalty: Some(Royalty { recipient: kp("artist").address(), bps: 500 }),
        rights_holder: "Lumen Atelier (fictional)".into(),
        rights: meta("rights"),
    }
}

/// Create a collection by `artist`; returns its id.
fn create(n: &mut Net, s: CollectionSpec) -> Addr {
    let nonce = n.nonce(&kp("artist"));
    ok(&n.send(&kp("artist"), NftAction::CollectionCreate(s)));
    collection_id(&kp("artist").address(), nonce)
}

fn mint(n: &mut Net, c: Addr, id: u64, to: &str) -> Receipt {
    n.send(&kp("artist"), NftAction::Mint { collection: c, item: MintItem { token_id: id, to: kp(to).address(), metadata: meta(&format!("tok{id}")) } })
}

#[test]
fn module_must_be_enabled_in_genesis() {
    let p = ChainParams::from_value(&dev_genesis("pow")).unwrap();
    let st = p.genesis_state();
    let k = kp("alice");
    let t = UnsignedTx { version: 1, chain_id: p.doc.chain_id.clone(), nonce: 0, fee: 20_000, expiry_height: 0, sender_pubkey: k.public(), action: Action::Nft(NftAction::CollectionCreate(spec("x", 1))), memo: vec![] }.sign(&k);
    let mut ov = st.overlay();
    let mut ctx = BlockCtx::new(1, None);
    let e = exec::execute_txs(&mut ov, &p, &mut ctx, &[t]).unwrap_err().1;
    assert_eq!(e.code(), "unsupported_action");
    // marketplace disabled while the module is enabled
    let mut n = Net::from(genesis_with(false, 0));
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "artist"));
    let t = n.tx(&kp("artist"), n.nonce(&kp("artist")), Action::Nft(NftAction::ListingCreate { collection: c, token_id: 1, price: 10, currency: AssetId::Native, expiry_height: 100 }));
    assert_eq!(n.block(&[t]).unwrap_err().code(), "unsupported_action");
    // activation height
    let mut g = genesis_with(true, 0);
    g["modules"]["collections"]["activation_height"] = 5.into();
    let mut n = Net::from(g);
    let t = n.tx(&kp("artist"), 0, Action::Nft(NftAction::CollectionCreate(spec("early", 1))));
    assert_eq!(n.block(&[t]).unwrap_err().code(), "unsupported_action");
    for _ in 0..4 {
        n.block(&[]).unwrap();
    }
    let t = n.tx(&kp("artist"), 0, Action::Nft(NftAction::CollectionCreate(spec("early", 1))));
    ok(&n.block(&[t]).unwrap()[0]);
}

#[test]
fn genesis_module_validation() {
    let mut g = genesis_with(true, 0);
    g["modules"]["collections"]["marketplace_fee_bps"] = 5000.into();
    assert!(ChainParams::from_value(&g).unwrap_err().contains("marketplace_fee_bps"));
    let mut g = genesis_with(true, 0);
    g["modules"]["collections"]["marketplace_fee_bps"] = 100.into();
    assert!(ChainParams::from_value(&g).unwrap_err().contains("requires marketplace_fee_recipient"));
    let mut g = genesis_with(true, 0);
    g["modules"]["collections"]["unknown"] = 1.into();
    assert!(ChainParams::from_value(&g).is_err());
    // genesis without modules hashes exactly as before (field absent, not null)
    let a = crate::genesis::genesis_hash_of_value(&dev_genesis("pow")).unwrap();
    assert_eq!(ChainParams::from_value(&dev_genesis("pow")).unwrap().hash, a);
}

#[test]
fn collection_creation_defaults_and_explicit_powers() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_FREEZABLE));
    let col = n.col(&c);
    assert_eq!((col.spec.admin, col.spec.flags & CFLAG_ADMIN_POWERS, col.paused), (None, 0, false));
    assert_eq!(col.creator, kp("artist").address());
    // slug is unique network-wide
    let r = n.send(&kp("collector"), NftAction::CollectionCreate(spec("lanterns", POLICY_FREEZABLE)));
    fail(&r, err::ALREADY_EXISTS);
    // admin powers without an admin, admin without powers, mutable without metadata admin
    let mut s = spec("a1", 1);
    s.flags |= CFLAG_PAUSABLE;
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("a2", 1);
    s.admin = Some(kp("artist").address());
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("a3", 1);
    s.metadata_admin = None;
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("a4", POLICY_IMMUTABLE);
    s.metadata_admin = Some(kp("artist").address());
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("a5", 1);
    s.royalty = Some(Royalty { recipient: kp("artist").address(), bps: 2501 });
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("Bad_Slug", 1);
    s.slug = "Bad_Slug".into();
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
    let mut s = spec("a6", 1);
    s.collection_metadata.hash = [0; 32];
    fail(&n.send(&kp("artist"), NftAction::CollectionCreate(s)), err::INVALID_ARGUMENT);
}

#[test]
fn minting_permissions_supply_limit_and_unique_ids() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    // unauthorised minting
    let r = n.send(&kp("collector"), NftAction::Mint { collection: c, item: MintItem { token_id: 1, to: kp("collector").address(), metadata: meta("x") } });
    fail(&r, err::UNAUTHORIZED);
    ok(&mint(&mut n, c, 1, "collector"));
    assert_eq!(n.tok(&c, 1).owner, kp("collector").address());
    // duplicate token id: never minted twice
    fail(&mint(&mut n, c, 1, "buyer"), err::ALREADY_EXISTS);
    assert_eq!(n.tok(&c, 1).owner, kp("collector").address());
    // duplicate submission of the same signed mint request: rejected by nonce
    let t = n.tx(&kp("artist"), n.nonce(&kp("artist")), Action::Nft(NftAction::Mint { collection: c, item: MintItem { token_id: 2, to: kp("buyer").address(), metadata: meta("tok2") } }));
    ok(&n.block(&[t.clone()]).unwrap()[0]);
    assert!(matches!(n.block(&[t]), Err(TxInvalid::BadNonce { .. })));
    // batch: all-or-nothing (item 4 duplicates id 1)
    let items = |ids: &[u64]| ids.iter().map(|i| MintItem { token_id: *i, to: kp("buyer").address(), metadata: meta(&format!("b{i}")) }).collect::<Vec<_>>();
    let r = n.send(&kp("artist"), NftAction::MintBatch { collection: c, items: items(&[3, 4, 1]) });
    fail(&r, err::ALREADY_EXISTS);
    assert!(nft::token(&n.st.overlay(), &c, 3).is_none(), "failed batch must not mint anything");
    assert_eq!(n.col(&c).minted, 2);
    let r = n.send(&kp("artist"), NftAction::MintBatch { collection: c, items: items(&[3, 4, 5]) });
    ok(&r);
    assert_eq!(r.events.iter().filter(|e| e.kind == "nft_mint").count(), 3);
    // supply limit 5 reached
    fail(&mint(&mut n, c, 6, "buyer"), err::SUPPLY_CAP);
    // failed transaction still pays its fee and consumes its nonce
    let before = n.bal(&kp("artist"));
    let nonce = n.nonce(&kp("artist"));
    fail(&mint(&mut n, c, 7, "buyer"), err::SUPPLY_CAP);
    assert_eq!(n.bal(&kp("artist")), before - 20_000);
    assert_eq!(n.nonce(&kp("artist")), nonce + 1);
    // oversize batch is rejected by the decoder
    let big = Action::Nft(NftAction::MintBatch { collection: c, items: items(&(100..133).collect::<Vec<_>>()) });
    assert!(Action::decode(&big.encode()).is_err());
}

#[test]
fn transfers_approvals_and_operators() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    ok(&mint(&mut n, c, 2, "collector"));
    // unauthorised transfer
    let r = n.send(&kp("buyer"), NftAction::Transfer { collection: c, token_id: 1, to: kp("buyer").address() });
    fail(&r, err::UNAUTHORIZED);
    // even the creator/mint authority has no transfer power
    fail(&n.send(&kp("artist"), NftAction::Transfer { collection: c, token_id: 1, to: kp("artist").address() }), err::UNAUTHORIZED);
    // single-token approval (narrowest scope)
    ok(&n.send(&kp("collector"), NftAction::Approve { collection: c, token_id: 1, approved: Some(kp("op").address()), expiry_height: 0 }));
    // the approval does not extend to token 2
    fail(&n.send(&kp("op"), NftAction::Transfer { collection: c, token_id: 2, to: kp("buyer").address() }), err::UNAUTHORIZED);
    let r = n.send(&kp("op"), NftAction::Transfer { collection: c, token_id: 1, to: kp("buyer").address() });
    ok(&r);
    let t = n.tok(&c, 1);
    assert_eq!((t.owner, t.approved, t.transfers), (kp("buyer").address(), None, 1), "approval cleared on transfer");
    // revoke before use
    ok(&n.send(&kp("collector"), NftAction::Approve { collection: c, token_id: 2, approved: Some(kp("op").address()), expiry_height: 0 }));
    ok(&n.send(&kp("collector"), NftAction::Approve { collection: c, token_id: 2, approved: None, expiry_height: 0 }));
    fail(&n.send(&kp("op"), NftAction::Transfer { collection: c, token_id: 2, to: kp("op").address() }), err::UNAUTHORIZED);
    // operator approval with an expiry, scoped to this collection only
    let exp = n.h + 3;
    ok(&n.send(&kp("collector"), NftAction::SetOperator { collection: c, operator: kp("op").address(), approved: true, expiry_height: exp }));
    assert_eq!(nft::operator_expiry(&n.st.overlay(), &c, &kp("collector").address(), &kp("op").address()), Some(exp));
    n.block(&[]).unwrap();
    n.block(&[]).unwrap();
    n.block(&[]).unwrap();
    fail(&n.send(&kp("op"), NftAction::Transfer { collection: c, token_id: 2, to: kp("op").address() }), err::UNAUTHORIZED);
    ok(&n.send(&kp("collector"), NftAction::SetOperator { collection: c, operator: kp("op").address(), approved: true, expiry_height: 0 }));
    ok(&n.send(&kp("op"), NftAction::Transfer { collection: c, token_id: 2, to: kp("op").address() }));
    ok(&n.send(&kp("collector"), NftAction::SetOperator { collection: c, operator: kp("op").address(), approved: false, expiry_height: 0 }));
    fail(&n.send(&kp("collector"), NftAction::SetOperator { collection: c, operator: kp("op").address(), approved: false, expiry_height: 0 }), err::NOT_FOUND);
    // approving yourself / approving with expiry in the past
    fail(&n.send(&kp("buyer"), NftAction::Approve { collection: c, token_id: 1, approved: Some(kp("buyer").address()), expiry_height: 0 }), err::INVALID_ARGUMENT);
    fail(&n.send(&kp("buyer"), NftAction::Approve { collection: c, token_id: 1, approved: Some(kp("op").address()), expiry_height: 1 }), err::INVALID_ARGUMENT);
    // non-transferable collection
    let mut s = spec("badges", POLICY_IMMUTABLE);
    s.transfer_policy = TRANSFER_NONE;
    let b = create(&mut n, s);
    ok(&mint(&mut n, b, 1, "collector"));
    fail(&n.send(&kp("collector"), NftAction::Transfer { collection: b, token_id: 1, to: kp("buyer").address() }), err::NON_TRANSFERABLE);
}

#[test]
fn burning_where_permitted_and_ids_not_reused() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    fail(&n.send(&kp("artist"), NftAction::Burn { collection: c, token_id: 1 }), err::UNAUTHORIZED);
    ok(&n.send(&kp("collector"), NftAction::Burn { collection: c, token_id: 1 }));
    assert!(n.tok(&c, 1).burned);
    assert_eq!((n.col(&c).minted, n.col(&c).burned), (1, 1));
    fail(&mint(&mut n, c, 1, "collector"), err::ALREADY_EXISTS);
    fail(&n.send(&kp("collector"), NftAction::Transfer { collection: c, token_id: 1, to: kp("buyer").address() }), err::NOT_FOUND);
    // burn not permitted by the collection
    let mut s = spec("noburn", POLICY_MUTABLE);
    s.flags = 0;
    let c2 = create(&mut n, s);
    ok(&mint(&mut n, c2, 1, "collector"));
    fail(&n.send(&kp("collector"), NftAction::Burn { collection: c2, token_id: 1 }), err::UNAUTHORIZED);
}

#[test]
fn metadata_mutable_with_recorded_revisions() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    // owner is not the metadata administrator
    fail(&n.send(&kp("collector"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v1"), expected_revision: 0 }), err::UNAUTHORIZED);
    ok(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v1"), expected_revision: 0 }));
    // stale expected revision (concurrent edit protection)
    fail(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v2"), expected_revision: 0 }), err::STALE);
    ok(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v2"), expected_revision: 1 }));
    let ov = n.st.overlay();
    let revs: Vec<MetadataRevision> = (0..3).map(|r| MetadataRevision::decode(&ov.get(&nft::keys::revision(&c, 1, r)).unwrap()).unwrap()).collect();
    assert_eq!(revs.iter().map(|r| r.metadata.hash).collect::<Vec<_>>(), vec![h32("tok1"), h32("v1"), h32("v2")]);
    // policy 1 has no freeze
    fail(&n.send(&kp("artist"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Token(1), expected: h32("v2") }), err::INVALID_ARGUMENT);
    // metadata administrator role transfer is recorded
    ok(&n.send(&kp("artist"), NftAction::SetRole { collection: c, role: ROLE_METADATA_ADMIN, new: Some(kp("op").address()) }));
    fail(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v3"), expected_revision: 2 }), err::UNAUTHORIZED);
    ok(&n.send(&kp("op"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v3"), expected_revision: 2 }));
    let log = AuthorityChange::decode(&n.st.overlay().get(&nft::keys::authority_log(&c, 0)).unwrap()).unwrap();
    assert_eq!((log.role, log.old, log.new), (ROLE_METADATA_ADMIN, Some(kp("artist").address()), Some(kp("op").address())));
    // only the current holder may reassign a role
    fail(&n.send(&kp("collector"), NftAction::SetRole { collection: c, role: ROLE_MINT_AUTHORITY, new: Some(kp("collector").address()) }), err::UNAUTHORIZED);
    // renouncing the mint authority is permanent: nobody can mint afterwards
    ok(&n.send(&kp("artist"), NftAction::SetRole { collection: c, role: ROLE_MINT_AUTHORITY, new: None }));
    fail(&mint(&mut n, c, 9, "collector"), err::UNAUTHORIZED);
    assert_eq!(n.col(&c).authority_changes, 2);
}

#[test]
fn metadata_freeze_token_and_collection() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_FREEZABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    ok(&mint(&mut n, c, 2, "collector"));
    ok(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v1"), expected_revision: 0 }));
    // the freeze names exactly what it freezes: a wrong expected hash is refused
    fail(&n.send(&kp("artist"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Token(1), expected: h32("tok1") }), err::STALE);
    fail(&n.send(&kp("collector"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Token(1), expected: h32("v1") }), err::UNAUTHORIZED);
    let r = n.send(&kp("artist"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Token(1), expected: h32("v1") });
    ok(&r);
    assert!(n.tok(&c, 1).frozen);
    fail(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("v2"), expected_revision: 1 }), err::METADATA_FROZEN);
    // token 2 is still editable
    ok(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 2, metadata: meta("t2v1"), expected_revision: 0 }));
    // collection-wide freeze commits to the metadata root of all live tokens
    let root = metadata_root(&n.st.overlay(), &c);
    fail(&n.send(&kp("artist"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Collection, expected: h32("wrong") }), err::STALE);
    ok(&n.send(&kp("artist"), NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Collection, expected: root }));
    let col = n.col(&c);
    assert!(col.frozen_all);
    assert_eq!(col.spec.metadata_admin, None, "metadata admin removed by the freeze");
    fail(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: c, token_id: 2, metadata: meta("t2v2"), expected_revision: 1 }), err::METADATA_FROZEN);
    fail(&n.send(&kp("artist"), NftAction::SetRole { collection: c, role: ROLE_METADATA_ADMIN, new: Some(kp("artist").address()) }), err::METADATA_FROZEN);
    // tokens minted after a collection freeze are frozen from birth
    ok(&mint(&mut n, c, 3, "collector"));
    assert!(n.tok(&c, 3).frozen);
    // immutable policy: frozen from creation
    let i = create(&mut n, spec("permanent", POLICY_IMMUTABLE));
    ok(&mint(&mut n, i, 1, "collector"));
    assert!(n.tok(&i, 1).frozen);
    fail(&n.send(&kp("artist"), NftAction::UpdateMetadata { collection: i, token_id: 1, metadata: meta("x"), expected_revision: 0 }), err::METADATA_FROZEN);
}

#[test]
fn pause_and_forced_transfer_require_opt_in() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    fail(&n.send(&kp("artist"), NftAction::SetPaused { collection: c, paused: true }), err::UNAUTHORIZED);
    fail(&n.send(&kp("artist"), NftAction::ForceTransfer { collection: c, token_id: 1, to: kp("artist").address(), reason_hash: h32("r") }), err::UNAUTHORIZED);
    let mut s = spec("managed", POLICY_MUTABLE);
    s.admin = Some(kp("op").address());
    s.flags |= CFLAG_PAUSABLE | CFLAG_FORCED_TRANSFER;
    let m = create(&mut n, s);
    ok(&mint(&mut n, m, 1, "collector"));
    ok(&n.send(&kp("op"), NftAction::SetPaused { collection: m, paused: true }));
    fail(&n.send(&kp("collector"), NftAction::Transfer { collection: m, token_id: 1, to: kp("buyer").address() }), err::PAUSED);
    fail(&mint(&mut n, m, 2, "collector"), err::PAUSED);
    let r = n.send(&kp("op"), NftAction::ForceTransfer { collection: m, token_id: 1, to: kp("buyer").address(), reason_hash: h32("court order #demo") });
    ok(&r);
    assert_eq!(r.events[1].attrs.iter().find(|(k, _)| k == "authority").unwrap().1, "forced_by_admin");
    // admin renounces: powers become unusable for everyone
    ok(&n.send(&kp("op"), NftAction::SetRole { collection: m, role: ROLE_ADMIN, new: None }));
    fail(&n.send(&kp("op"), NftAction::SetPaused { collection: m, paused: false }), err::UNAUTHORIZED);
}

#[test]
fn multisig_can_hold_collection_roles() {
    let mut n = Net::new();
    let tre = crate::genesis::treasury_address(0);
    let mut s = spec("treasury-art", POLICY_MUTABLE);
    s.mint_authority = Some(tre);
    let c = create(&mut n, s);
    let inner = Action::Nft(NftAction::Mint { collection: c, item: MintItem { token_id: 1, to: kp("collector").address(), metadata: meta("m") } });
    ok(&n.send_action(&kp("t1"), Action::MultisigPropose { multisig: tre, inner: Box::new(inner), expiry_height: n.h + 50 }));
    assert!(nft::token(&n.st.overlay(), &c, 1).is_none(), "one approval of two is not enough");
    // t1 is a genesis treasury signer without funds in dev genesis? fund check above passed; approve with t2
    ok(&n.send_action(&kp("t2"), Action::MultisigApprove { multisig: tre, proposal_id: 0 }));
    assert_eq!(n.tok(&c, 1).owner, kp("collector").address());
    // transfers are not allowed as multisig inner actions (holders sign their own)
    let bad = Action::MultisigPropose { multisig: tre, inner: Box::new(Action::Nft(NftAction::Transfer { collection: c, token_id: 1, to: tre })), expiry_height: 99 };
    assert!(Action::decode(&bad.encode()).is_err());
}

#[test]
fn marketplace_atomic_settlement_and_accounting() {
    let mut n = Net::new(); // platform fee 250 bps
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE)); // royalty 500 bps to artist
    ok(&mint(&mut n, c, 1, "collector"));
    let seller = kp("collector");
    let nonce = n.nonce(&seller);
    let price: u128 = 1_000_003; // odd price to exercise rounding
    // only the owner may list
    fail(&n.send(&kp("buyer"), NftAction::ListingCreate { collection: c, token_id: 1, price, currency: AssetId::Native, expiry_height: n.h + 100 }), err::UNAUTHORIZED);
    let nonce = nonce.max(n.nonce(&seller));
    ok(&n.send(&seller, NftAction::ListingCreate { collection: c, token_id: 1, price, currency: AssetId::Native, expiry_height: n.h + 100 }));
    let lid = listing_id(&seller.address(), nonce);
    // a second active listing for the same token is refused
    fail(&n.send(&seller, NftAction::ListingCreate { collection: c, token_id: 1, price: 5, currency: AssetId::Native, expiry_height: n.h + 100 }), err::ALREADY_EXISTS);
    // buyer committed to a different price: refused, nothing moves
    fail(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: lid, price: price - 1, currency: AssetId::Native }), err::STALE);
    let (b0, s0, a0, f0) = (n.bal(&kp("buyer")), n.bal(&seller), n.bal(&kp("artist")), n.bal(&kp("platform")));
    let buy = n.tx(&kp("buyer"), n.nonce(&kp("buyer")), Action::Nft(NftAction::ListingBuy { listing_id: lid, price, currency: AssetId::Native }));
    let r = n.block(&[buy.clone()]).unwrap().remove(0);
    ok(&r);
    let expect = split_proceeds(price, 500, 250);
    assert_eq!(expect, Proceeds { royalty: 50_000, platform_fee: 25_000, seller: 925_003 });
    assert_eq!(n.bal(&kp("buyer")), b0 - price - 20_000, "buyer pays price + network fee (separate)");
    assert_eq!(n.bal(&seller), s0 + expect.seller);
    assert_eq!(n.bal(&kp("artist")), a0 + expect.royalty);
    assert_eq!(n.bal(&kp("platform")), f0 + expect.platform_fee);
    assert_eq!(n.tok(&c, 1).owner, kp("buyer").address());
    let l = nft::listing(&n.st.overlay(), &lid).unwrap();
    assert_eq!((l.status, l.buyer, l.royalty_paid, l.platform_fee_paid, l.seller_proceeds), (LISTING_SOLD, Some(kp("buyer").address()), 50_000, 25_000, 925_003));
    // replay of the same signed purchase: rejected by nonce
    assert!(matches!(n.block(&[buy.clone()]), Err(TxInvalid::BadNonce { .. })));
    // replay on another network: the signature does not verify for another chain id
    let mut other = buy.clone();
    other.tx.chain_id = "aureom-other-chain".into();
    assert!(matches!(n.block(&[other]), Err(TxInvalid::WrongChain(_))));
    let sig_other = UnsignedTx { chain_id: "aureom-other-chain".into(), ..buy.tx.clone() };
    let mixed = SignedTx { tx: sig_other, signature: buy.signature };
    assert!(!mixed.verify_signature());
    // duplicate purchase by a second buyer (fresh nonce): listing no longer active
    fail(&n.send(&kp("buyer2"), NftAction::ListingBuy { listing_id: lid, price, currency: AssetId::Native }), err::LISTING_INACTIVE);
    assert_eq!(n.tok(&c, 1).owner, kp("buyer").address());
}

#[test]
fn marketplace_revalidates_and_fails_atomically() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    ok(&mint(&mut n, c, 2, "collector"));
    let s = kp("collector");
    // listing invalidated when the seller transfers the token away
    let n1 = n.nonce(&s);
    ok(&n.send(&s, NftAction::ListingCreate { collection: c, token_id: 1, price: 1_000, currency: AssetId::Native, expiry_height: n.h + 100 }));
    let l1 = listing_id(&s.address(), n1);
    let r = n.send(&s, NftAction::Transfer { collection: c, token_id: 1, to: kp("op").address() });
    ok(&r);
    assert!(r.events.iter().any(|e| e.kind == "nft_listing"));
    assert_eq!(nft::listing(&n.st.overlay(), &l1).unwrap().status, LISTING_INVALIDATED);
    fail(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: l1, price: 1_000, currency: AssetId::Native }), err::LISTING_INACTIVE);
    // insufficient funds: the failed purchase moves neither payment nor NFT
    let n2 = n.nonce(&s);
    ok(&n.send(&s, NftAction::ListingCreate { collection: c, token_id: 2, price: 10_000_000_000, currency: AssetId::Native, expiry_height: n.h + 100 }));
    let l2 = listing_id(&s.address(), n2);
    let seller_before = n.bal(&s);
    fail(&n.send(&kp("poor"), NftAction::ListingBuy { listing_id: l2, price: 10_000_000_000, currency: AssetId::Native }), err::INSUFFICIENT_FUNDS);
    assert_eq!(n.tok(&c, 2).owner, s.address());
    assert_eq!(n.bal(&s), seller_before);
    assert_eq!(nft::listing(&n.st.overlay(), &l2).unwrap().status, LISTING_ACTIVE);
    // cancellation: seller only
    fail(&n.send(&kp("buyer"), NftAction::ListingCancel { listing_id: l2 }), err::UNAUTHORIZED);
    ok(&n.send(&s, NftAction::ListingCancel { listing_id: l2 }));
    fail(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: l2, price: 10_000_000_000, currency: AssetId::Native }), err::LISTING_INACTIVE);
    // expiry
    let n3 = n.nonce(&s);
    ok(&n.send(&s, NftAction::ListingCreate { collection: c, token_id: 2, price: 500, currency: AssetId::Native, expiry_height: n.h + 2 }));
    let l3 = listing_id(&s.address(), n3);
    n.block(&[]).unwrap();
    n.block(&[]).unwrap();
    fail(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: l3, price: 500, currency: AssetId::Native }), err::LISTING_INACTIVE);
    // seller cannot buy own listing
    let n4 = n.nonce(&s);
    ok(&n.send(&s, NftAction::ListingCreate { collection: c, token_id: 2, price: 500, currency: AssetId::Native, expiry_height: n.h + 20 }));
    let l4 = listing_id(&s.address(), n4);
    fail(&n.send(&s, NftAction::ListingBuy { listing_id: l4, price: 500, currency: AssetId::Native }), err::INVALID_ARGUMENT);
}

#[test]
fn marketplace_token_currency() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    ok(&mint(&mut n, c, 1, "collector"));
    let nonce = n.nonce(&kp("buyer"));
    ok(&n.send_action(&kp("buyer"), Action::TokenCreate {
        symbol: "USDX".into(), name: "Demo Stable Units".into(), decimals: 2, initial_supply: 1_000_000, initial_recipient: kp("buyer").address(),
        max_supply: None, mint_authority: None, admin: None, flags: 0, metadata_uri: String::new(),
    }));
    let tid = exec::token_id(&kp("buyer").address(), nonce);
    let s = kp("collector");
    let ln = n.nonce(&s);
    ok(&n.send(&s, NftAction::ListingCreate { collection: c, token_id: 1, price: 10_000, currency: AssetId::Token(tid), expiry_height: n.h + 100 }));
    let lid = listing_id(&s.address(), ln);
    // currency mismatch in the buyer's commitment
    fail(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: lid, price: 10_000, currency: AssetId::Native }), err::STALE);
    ok(&n.send(&kp("buyer"), NftAction::ListingBuy { listing_id: lid, price: 10_000, currency: AssetId::Token(tid) }));
    let ov = n.st.overlay();
    assert_eq!(ov.token_balance(&tid, &s.address()).amount, 9_250);
    assert_eq!(ov.token_balance(&tid, &kp("artist").address()).amount, 500);
    assert_eq!(ov.token_balance(&tid, &kp("platform").address()).amount, 250);
    assert_eq!(ov.token_balance(&tid, &kp("buyer").address()).amount, 990_000);
}

#[test]
fn claim_based_drop() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    let leaves = [
        drop_leaf(0, &kp("collector").address(), 10, &meta("d10")),
        drop_leaf(1, &kp("buyer").address(), 11, &meta("d11")),
        drop_leaf(2, &kp("op").address(), 12, &meta("d12")),
    ];
    let root = merkle::root(&leaves);
    fail(&n.send(&kp("collector"), NftAction::DropCreate { collection: c, merkle_root: root, claim_deadline_height: n.h + 50, max_claims: 3 }), err::UNAUTHORIZED);
    let nonce = n.nonce(&kp("artist"));
    ok(&n.send(&kp("artist"), NftAction::DropCreate { collection: c, merkle_root: root, claim_deadline_height: n.h + 50, max_claims: 3 }));
    let did = drop_id(&kp("artist").address(), nonce);
    let claim = |i: usize, tok: u64, m: &str| NftAction::DropClaim { drop_id: did, index: i as u32, item_token_id: tok, metadata: meta(m), proof: merkle::proof(&leaves, i) };
    ok(&n.send(&kp("collector"), claim(0, 10, "d10")));
    assert_eq!(n.tok(&c, 10).owner, kp("collector").address());
    fail(&n.send(&kp("collector"), claim(0, 10, "d10")), err::ALREADY_CLAIMED);
    // someone else presenting buyer's proof
    fail(&n.send(&kp("collector"), claim(1, 11, "d11")), err::BAD_PROOF);
    // claimant tries different metadata or token id than committed
    fail(&n.send(&kp("buyer"), claim(1, 11, "forged")), err::BAD_PROOF);
    ok(&n.send(&kp("buyer"), claim(1, 11, "d11")));
    assert_eq!(n.col(&c).minted, 2);
}

#[test]
fn all_actions_roundtrip_and_json() {
    let p = Net::new().p;
    let c = collection_id(&[1; 20], 0);
    let acts = vec![
        NftAction::CollectionCreate(spec("x", 2)),
        NftAction::Mint { collection: c, item: MintItem { token_id: 1, to: [2; 20], metadata: meta("a") } },
        NftAction::MintBatch { collection: c, items: vec![MintItem { token_id: 1, to: [2; 20], metadata: meta("a") }] },
        NftAction::Transfer { collection: c, token_id: 1, to: [3; 20] },
        NftAction::Approve { collection: c, token_id: 1, approved: Some([3; 20]), expiry_height: 9 },
        NftAction::SetOperator { collection: c, operator: [3; 20], approved: true, expiry_height: 0 },
        NftAction::Burn { collection: c, token_id: 1 },
        NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("b"), expected_revision: 3 },
        NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Token(1), expected: [4; 32] },
        NftAction::FreezeMetadata { collection: c, scope: FreezeScope::Collection, expected: [4; 32] },
        NftAction::SetPaused { collection: c, paused: true },
        NftAction::SetRole { collection: c, role: ROLE_ROYALTY_RECIPIENT, new: None },
        NftAction::ForceTransfer { collection: c, token_id: 1, to: [3; 20], reason_hash: [5; 32] },
        NftAction::ListingCreate { collection: c, token_id: 1, price: 7, currency: AssetId::Token([6; 20]), expiry_height: 10 },
        NftAction::ListingCancel { listing_id: [7; 32] },
        NftAction::ListingBuy { listing_id: [7; 32], price: 7, currency: AssetId::Native },
        NftAction::DropCreate { collection: c, merkle_root: [8; 32], claim_deadline_height: 10, max_claims: 2 },
        NftAction::DropClaim { drop_id: [9; 32], index: 0, item_token_id: 3, metadata: meta("c"), proof: vec![merkle::ProofStep { side: 1, sibling: [1; 32] }] },
    ];
    for a in acts {
        let act = Action::Nft(a);
        let bytes = act.encode();
        assert_eq!(Action::decode(&bytes).unwrap(), act, "binary roundtrip {}", act.type_name());
        let j = crate::json::action_json(&p, &act);
        assert_eq!(crate::json::action_from_json(&p, &j).unwrap(), act, "json roundtrip {}", act.type_name());
        let mut trailing = bytes.clone();
        trailing.push(0);
        assert!(Action::decode(&trailing).is_err());
    }
    // unknown tag inside the module range
    assert!(Action::decode(&[77]).is_err());
}

#[test]
fn deterministic_and_undo_restores_nft_state() {
    // the same NFT history on two states gives identical roots; reverting the undo log of
    // each block (as a PoW reorganisation does) restores every earlier root.
    let mut a = Net::new();
    let mut b = Net::new();
    let mut roots = vec![a.st.root()];
    let mut undos = vec![];
    let script = |n: &Net, step: usize| -> Vec<SignedTx> {
        let c = collection_id(&kp("artist").address(), 0);
        let act = match step {
            0 => NftAction::CollectionCreate(spec("lanterns", POLICY_FREEZABLE)),
            1 => NftAction::Mint { collection: c, item: MintItem { token_id: 1, to: kp("collector").address(), metadata: meta("1") } },
            2 => NftAction::Transfer { collection: c, token_id: 1, to: kp("buyer").address() },
            3 => NftAction::UpdateMetadata { collection: c, token_id: 1, metadata: meta("1b"), expected_revision: 0 },
            _ => NftAction::Burn { collection: c, token_id: 1 },
        };
        let signer = match step {
            0 | 1 | 3 => kp("artist"),
            2 => kp("collector"),
            _ => kp("buyer"),
        };
        vec![n.tx(&signer, n.nonce(&signer), Action::Nft(act))]
    };
    for step in 0..5 {
        let txs = script(&a, step);
        let h = a.h + 1;
        let mut ctx = BlockCtx::new(h, Some(kp("miner").address()));
        let mut ov = a.st.overlay();
        let rc = exec::execute_txs(&mut ov, &a.p, &mut ctx, &txs).unwrap();
        assert_eq!(rc[0].status, STATUS_SUCCESS, "step {step}: {}", err::name(rc[0].error_code));
        exec::pow_coinbase(&mut ov, &a.p, &mut ctx, &kp("miner").address());
        let cs = ov.into_changes();
        undos.push(a.st.apply(&cs));
        a.h = h;
        b.block(&script(&b, step)).unwrap();
        assert_eq!(a.st.root(), b.st.root(), "step {step} diverged");
        roots.push(a.st.root());
    }
    for (i, u) in undos.iter().enumerate().rev() {
        a.st.revert(u);
        assert_eq!(a.st.root(), roots[i]);
    }
    assert!(nft::collection(&a.st.overlay(), &collection_id(&kp("artist").address(), 0)).is_none());
}

#[test]
fn simulation_never_commits_and_checks_everything_but_the_signature() {
    let mut n = Net::new();
    let c = create(&mut n, spec("lanterns", POLICY_MUTABLE));
    let root = n.st.root();
    let k = kp("mallory");
    let u = |a: NftAction, chain: &str| UnsignedTx { version: 1, chain_id: chain.into(), nonce: 0, fee: 20_000, expiry_height: 0, sender_pubkey: k.public(), action: Action::Nft(a), memo: vec![] };
    // unfunded sender: inadmissible
    let e = exec::simulate(&n.st, &n.p, n.h + 1, &u(NftAction::Burn { collection: c, token_id: 1 }, &n.p.doc.chain_id)).unwrap_err();
    assert!(matches!(e, TxInvalid::InsufficientFee { .. }));
    // funded, unauthorised mint: admissible but the action fails
    let k = kp("collector");
    let tx = UnsignedTx { sender_pubkey: k.public(), ..u(NftAction::Mint { collection: c, item: MintItem { token_id: 1, to: k.address(), metadata: meta("x") } }, &n.p.doc.chain_id) };
    let r = exec::simulate(&n.st, &n.p, n.h + 1, &tx).unwrap();
    assert_eq!((r.status, r.error_code), (STATUS_FAILED, err::UNAUTHORIZED));
    // wrong chain is caught without a signature
    let wrong = UnsignedTx { chain_id: "aureom-elsewhere".into(), ..tx.clone() };
    assert!(matches!(exec::simulate(&n.st, &n.p, n.h + 1, &wrong), Err(TxInvalid::WrongChain(_))));
    assert_eq!(n.st.root(), root, "simulation must not change state");
}
