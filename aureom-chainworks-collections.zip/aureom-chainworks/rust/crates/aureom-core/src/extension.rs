//! Adapter boundary for an optional, separately specified smart-contract platform
//! (docs/EXTENSIONS.md). Nothing implements this trait in v1 and no action tag in the
//! reserved range is accepted; it documents the interface an integration must satisfy.

use crate::crypto::Addr;
use crate::state::Overlay;
use crate::types::Event;

/// Reserved action tag range for an execution extension.
pub const EXTENSION_TAGS: std::ops::RangeInclusive<u8> = 100..=199;
/// State key prefix owned by the extension.
pub const EXTENSION_STATE_PREFIX: u8 = 0x80;

pub struct ExtensionCtx {
    pub height: u64,
    pub sender: Addr,
    /// Fee paid by the outer transaction (native base units), the gas budget source.
    pub fee_budget: u64,
}

pub struct ExtensionResult {
    pub gas_used: u64,
    pub events: Vec<Event>,
}

pub trait ExecutionExtension {
    /// Stable identifier and version of the integrated platform (e.g. "revm-x.y").
    fn platform(&self) -> &'static str;
    /// Deterministic execution of an extension action. Must only touch keys under
    /// `EXTENSION_STATE_PREFIX` and move native coins through the core's debit/credit
    /// functions so the supply invariants keep holding. Errors revert all effects.
    fn execute(&self, ov: &mut Overlay, ctx: &ExtensionCtx, tag: u8, payload: &[u8]) -> Result<ExtensionResult, u16>;
    /// Whether `deployer` may deploy new code (deployment permissions).
    fn may_deploy(&self, ov: &Overlay, deployer: &Addr) -> bool;
}
