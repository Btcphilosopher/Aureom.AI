//! Canonical binary encoding (PROTOCOL.md section 3).
//!
//! Every consensus object has exactly one encoding. The decoder is strict: it rejects
//! non-canonical booleans/tags, lengths above their declared maximum (before
//! allocating), invalid UTF-8 and trailing bytes.

use thiserror::Error;

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum DecodeError {
    #[error("unexpected end of input")]
    Eof,
    #[error("length {0} exceeds maximum {1}")]
    TooLong(usize, usize),
    #[error("invalid boolean byte {0}")]
    BadBool(u8),
    #[error("invalid tag {0} for {1}")]
    BadTag(u8, &'static str),
    #[error("invalid utf-8")]
    BadUtf8,
    #[error("trailing bytes: {0}")]
    Trailing(usize),
    #[error("invalid value: {0}")]
    Invalid(&'static str),
}

pub type DResult<T> = Result<T, DecodeError>;

#[derive(Default, Clone)]
pub struct Writer {
    pub buf: Vec<u8>,
}

impl Writer {
    pub fn new() -> Self {
        Self { buf: Vec::with_capacity(256) }
    }
    pub fn u8(&mut self, v: u8) {
        self.buf.push(v)
    }
    pub fn u16(&mut self, v: u16) {
        self.buf.extend_from_slice(&v.to_be_bytes())
    }
    pub fn u32(&mut self, v: u32) {
        self.buf.extend_from_slice(&v.to_be_bytes())
    }
    pub fn u64(&mut self, v: u64) {
        self.buf.extend_from_slice(&v.to_be_bytes())
    }
    pub fn u128(&mut self, v: u128) {
        self.buf.extend_from_slice(&v.to_be_bytes())
    }
    pub fn bool(&mut self, v: bool) {
        self.buf.push(v as u8)
    }
    pub fn fixed(&mut self, v: &[u8]) {
        self.buf.extend_from_slice(v)
    }
    pub fn bytes(&mut self, v: &[u8]) {
        self.u32(v.len() as u32);
        self.buf.extend_from_slice(v)
    }
    pub fn string(&mut self, v: &str) {
        self.bytes(v.as_bytes())
    }
    pub fn opt<T>(&mut self, v: &Option<T>, f: impl FnOnce(&mut Self, &T)) {
        match v {
            None => self.u8(0),
            Some(x) => {
                self.u8(1);
                f(self, x)
            }
        }
    }
    pub fn vec<T>(&mut self, v: &[T], mut f: impl FnMut(&mut Self, &T)) {
        self.u32(v.len() as u32);
        for x in v {
            f(self, x)
        }
    }
    pub fn finish(self) -> Vec<u8> {
        self.buf
    }
}

pub struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        Self { data, pos: 0 }
    }
    pub fn remaining(&self) -> usize {
        self.data.len() - self.pos
    }
    fn take(&mut self, n: usize) -> DResult<&'a [u8]> {
        if self.remaining() < n {
            return Err(DecodeError::Eof);
        }
        let s = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }
    pub fn u8(&mut self) -> DResult<u8> {
        Ok(self.take(1)?[0])
    }
    pub fn u16(&mut self) -> DResult<u16> {
        Ok(u16::from_be_bytes(self.take(2)?.try_into().unwrap()))
    }
    pub fn u32(&mut self) -> DResult<u32> {
        Ok(u32::from_be_bytes(self.take(4)?.try_into().unwrap()))
    }
    pub fn u64(&mut self) -> DResult<u64> {
        Ok(u64::from_be_bytes(self.take(8)?.try_into().unwrap()))
    }
    pub fn u128(&mut self) -> DResult<u128> {
        Ok(u128::from_be_bytes(self.take(16)?.try_into().unwrap()))
    }
    pub fn bool(&mut self) -> DResult<bool> {
        match self.u8()? {
            0 => Ok(false),
            1 => Ok(true),
            b => Err(DecodeError::BadBool(b)),
        }
    }
    pub fn fixed<const N: usize>(&mut self) -> DResult<[u8; N]> {
        Ok(self.take(N)?.try_into().unwrap())
    }
    pub fn bytes(&mut self, max: usize) -> DResult<Vec<u8>> {
        let len = self.u32()? as usize;
        if len > max {
            return Err(DecodeError::TooLong(len, max));
        }
        Ok(self.take(len)?.to_vec())
    }
    pub fn string(&mut self, max: usize) -> DResult<String> {
        String::from_utf8(self.bytes(max)?).map_err(|_| DecodeError::BadUtf8)
    }
    pub fn opt<T>(&mut self, f: impl FnOnce(&mut Self) -> DResult<T>) -> DResult<Option<T>> {
        match self.u8()? {
            0 => Ok(None),
            1 => Ok(Some(f(self)?)),
            b => Err(DecodeError::BadTag(b, "option")),
        }
    }
    /// `min_item` is the minimum encoded size of one item; it bounds preallocation so a
    /// malicious count cannot cause a large allocation.
    pub fn vec<T>(
        &mut self,
        max: usize,
        min_item: usize,
        mut f: impl FnMut(&mut Self) -> DResult<T>,
    ) -> DResult<Vec<T>> {
        let n = self.u32()? as usize;
        if n > max {
            return Err(DecodeError::TooLong(n, max));
        }
        if n.saturating_mul(min_item.max(1)) > self.remaining() {
            return Err(DecodeError::Eof);
        }
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            out.push(f(self)?);
        }
        Ok(out)
    }
    pub fn end(&self) -> DResult<()> {
        if self.remaining() != 0 {
            return Err(DecodeError::Trailing(self.remaining()));
        }
        Ok(())
    }
}

pub trait Encode {
    fn encode_to(&self, w: &mut Writer);
    fn encode(&self) -> Vec<u8> {
        let mut w = Writer::new();
        self.encode_to(&mut w);
        w.finish()
    }
}

pub trait Decode: Sized {
    fn decode_from(r: &mut Reader) -> DResult<Self>;
    /// Strict decode of a complete buffer.
    fn decode(data: &[u8]) -> DResult<Self> {
        let mut r = Reader::new(data);
        let v = Self::decode_from(&mut r)?;
        r.end()?;
        Ok(v)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_bad_bool_and_trailing() {
        assert_eq!(Reader::new(&[2]).bool(), Err(DecodeError::BadBool(2)));
        let r = Reader::new(&[0, 1]);
        assert!(r.end().is_err());
    }

    #[test]
    fn rejects_oversized_length_before_alloc() {
        // length field claims 4 GiB
        let data = [0xff, 0xff, 0xff, 0xff, 1, 2, 3];
        let mut r = Reader::new(&data);
        assert!(matches!(r.bytes(1024), Err(DecodeError::TooLong(_, 1024))));
        let mut r = Reader::new(&data);
        assert!(r.vec(usize::MAX, 1, |r| r.u8()).is_err());
    }

    #[test]
    fn big_endian_fixed_width() {
        let mut w = Writer::new();
        w.u64(1);
        w.u16(0x0102);
        assert_eq!(w.finish(), vec![0, 0, 0, 0, 0, 0, 0, 1, 1, 2]);
    }
}
