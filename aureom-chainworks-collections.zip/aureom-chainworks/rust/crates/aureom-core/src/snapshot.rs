//! State snapshots. A snapshot is untrusted input: it is accepted only if (1) its digest
//! matches, (2) the recomputed state root equals the root in its header, and (3) the
//! caller confirms that root against a trusted block (a validated header on the local
//! chain, or an out-of-band trusted checkpoint). A peer-supplied hash alone is never
//! sufficient.

use crate::codec::*;
use crate::crypto::{hash_domain, Hash32};
use crate::state::State;

pub const MAGIC: &[u8; 8] = b"AURSNAP1";

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SnapshotHeader {
    pub chain_id: String,
    pub genesis_hash: Hash32,
    pub height: u64,
    pub block_id: Hash32,
    pub state_root: Hash32,
    pub entries: u64,
}

pub fn write(h: &SnapshotHeader, st: &State) -> Vec<u8> {
    let mut w = Writer::new();
    w.fixed(MAGIC);
    w.string(&h.chain_id);
    w.fixed(&h.genesis_hash);
    w.u64(h.height);
    w.fixed(&h.block_id);
    w.fixed(&h.state_root);
    w.u64(st.len() as u64);
    for (k, v) in st.entries() {
        w.bytes(k);
        w.bytes(v);
    }
    let mut out = w.finish();
    let d = hash_domain("AUREOM/SNAPSHOT/v1", &out);
    out.extend_from_slice(&d);
    out
}

#[derive(Debug, thiserror::Error)]
pub enum SnapshotError {
    #[error("not a snapshot file")]
    Magic,
    #[error("digest mismatch (file corrupted or tampered)")]
    Digest,
    #[error("decode: {0}")]
    Decode(#[from] DecodeError),
    #[error("entries not strictly sorted")]
    Order,
    #[error("state root mismatch: header {header}, computed {computed}")]
    Root { header: String, computed: String },
}

/// Verify a snapshot's internal consistency and return its header and state.
pub fn read_verified(data: &[u8]) -> Result<(SnapshotHeader, State), SnapshotError> {
    if data.len() < 8 + 32 || &data[..8] != MAGIC {
        return Err(SnapshotError::Magic);
    }
    let (body, digest) = data.split_at(data.len() - 32);
    if hash_domain("AUREOM/SNAPSHOT/v1", body) != digest {
        return Err(SnapshotError::Digest);
    }
    let mut r = Reader::new(&body[8..]);
    let mut h = SnapshotHeader {
        chain_id: r.string(64)?,
        genesis_hash: r.fixed()?,
        height: r.u64()?,
        block_id: r.fixed()?,
        state_root: r.fixed()?,
        entries: 0,
    };
    let n = r.u64()?;
    h.entries = n;
    if n as usize > r.remaining() / 8 {
        return Err(SnapshotError::Decode(DecodeError::Eof));
    }
    let mut entries = Vec::with_capacity(n as usize);
    let mut prev: Option<Vec<u8>> = None;
    for _ in 0..n {
        let k = r.bytes(1 << 16)?;
        let v = r.bytes(1 << 24)?;
        if let Some(p) = &prev {
            if &k <= p {
                return Err(SnapshotError::Order);
            }
        }
        prev = Some(k.clone());
        entries.push((k, v));
    }
    r.end()?;
    let st = State::from_entries(entries);
    let root = st.root();
    if root != h.state_root {
        return Err(SnapshotError::Root { header: hex::encode(h.state_root), computed: hex::encode(root) });
    }
    Ok((h, st))
}
