//! State-machine tests: replay, conflicts, overflow, fees, supply invariants, tokens,
//! vesting, multisig, distributions, staking, slashing, PoA governance, upgrades,
//! determinism.

use crate::codec::Encode;
use crate::crypto::{comet_address, test_keypair, Keypair};
use crate::exec::{self, err, BlockCtx, Misbehavior, TxInvalid, VoteInfo};
use crate::genesis::{tests::dev_genesis, ChainParams};
use crate::merkle;
use crate::state::State;
use crate::types::*;

struct Net {
    p: ChainParams,
    st: State,
    h: u64,
}

impl Net {
    fn new(profile: &str) -> Self {
        Self::from_value(dev_genesis(profile))
    }
    fn from_value(g: serde_json::Value) -> Self {
        let p = ChainParams::from_value(&g).unwrap();
        let st = p.genesis_state();
        Net { p, st, h: 0 }
    }
    fn tx(&self, kp: &Keypair, nonce: u64, action: Action) -> SignedTx {
        UnsignedTx { version: 1, chain_id: self.p.doc.chain_id.clone(), nonce, fee: 5000, expiry_height: 0, sender_pubkey: kp.public(), action, memo: vec![] }.sign(kp)
    }
    fn nonce(&self, kp: &Keypair) -> u64 {
        self.st.account(&kp.address()).nonce
    }
    /// Apply a block; returns receipts or the inadmissible tx error.
    fn block(&mut self, txs: &[SignedTx]) -> Result<Vec<Receipt>, TxInvalid> {
        let h = self.h + 1;
        let miner = test_keypair("miner").address();
        let mut ctx = BlockCtx::new(h, Some(miner));
        let mut ov = self.st.overlay();
        let r = if self.p.profile.is_bft() {
            exec::begin_block_bft(&mut ov, &self.p, &mut ctx, &[], &[]).unwrap();
            let r = exec::execute_txs(&mut ov, &self.p, &mut ctx, txs).map_err(|e| e.1)?;
            exec::end_block_bft(&mut ov, &self.p, &mut ctx);
            r
        } else {
            let r = exec::execute_txs(&mut ov, &self.p, &mut ctx, txs).map_err(|e| e.1)?;
            exec::pow_coinbase(&mut ov, &self.p, &mut ctx, &miner);
            r
        };
        let cs = ov.into_changes();
        self.st.apply(&cs);
        self.h = h;
        let rep = exec::reconcile(&self.st, &self.p, h);
        assert!(rep.reconciled && rep.tokens_reconciled, "supply invariant violated: {:?}", rep.problems);
        Ok(r)
    }
    fn send(&mut self, kp: &Keypair, action: Action) -> Receipt {
        let t = self.tx(kp, self.nonce(kp), action);
        self.block(&[t]).unwrap().remove(0)
    }
    fn empty_blocks(&mut self, n: u64) {
        for _ in 0..n {
            self.block(&[]).unwrap();
        }
    }
    fn bft_block(&mut self, votes: &[VoteInfo], ev: &[Misbehavior], txs: &[SignedTx]) -> (Vec<Receipt>, Vec<([u8; 32], u64)>) {
        let h = self.h + 1;
        let mut ctx = BlockCtx::new(h, None);
        let mut ov = self.st.overlay();
        exec::begin_block_bft(&mut ov, &self.p, &mut ctx, votes, ev).unwrap();
        let r = exec::execute_txs(&mut ov, &self.p, &mut ctx, txs).unwrap();
        let (u, _) = exec::end_block_bft(&mut ov, &self.p, &mut ctx);
        let cs = ov.into_changes();
        self.st.apply(&cs);
        self.h = h;
        let rep = exec::reconcile(&self.st, &self.p, h);
        assert!(rep.reconciled, "{:?}", rep.problems);
        (r, u)
    }
    fn bal(&self, a: &[u8; 20]) -> u128 {
        self.st.account(a).balance
    }
}

fn alice() -> Keypair {
    test_keypair("alice")
}
fn bob() -> Keypair {
    test_keypair("bob")
}

#[test]
fn transfer_fee_and_nonce() {
    let mut n = Net::new("pow");
    let a0 = n.bal(&alice().address());
    let r = n.send(&alice(), Action::Transfer { to: bob().address(), amount: 100 });
    assert_eq!(r.status, STATUS_SUCCESS);
    assert_eq!(n.bal(&alice().address()), a0 - 100 - 5000);
    assert_eq!(n.nonce(&alice()), 1);
    // 20% of the fee burned
    assert_eq!(n.st.supply().burned, 1000);
}

#[test]
fn replay_and_conflicting_nonce_rejected() {
    let mut n = Net::new("pow");
    let t = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 });
    n.block(&[t.clone()]).unwrap();
    assert!(matches!(n.block(&[t.clone()]), Err(TxInvalid::BadNonce { expected: 1, got: 0 })));
    // two different txs with the same nonce in one block: second is inadmissible
    let a = n.tx(&alice(), 1, Action::Transfer { to: bob().address(), amount: 1 });
    let b = n.tx(&alice(), 1, Action::Transfer { to: bob().address(), amount: 2 });
    assert!(matches!(n.block(&[a, b]), Err(TxInvalid::BadNonce { .. })));
}

#[test]
fn invalid_signature_wrong_chain_low_fee() {
    let mut n = Net::new("pow");
    let mut t = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 });
    t.signature[0] ^= 1;
    assert_eq!(n.block(&[t]), Err(TxInvalid::BadSignature));
    let mut u = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 }).tx;
    u.chain_id = "aureom-other".into();
    assert!(matches!(n.block(&[u.clone().sign(&alice())]), Err(TxInvalid::WrongChain(_))));
    let mut u2 = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 }).tx;
    u2.fee = 10;
    assert!(matches!(n.block(&[u2.sign(&alice())]), Err(TxInvalid::FeeTooLow { .. })));
    // signature from another key over the same body
    let mut t3 = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 });
    t3.signature = bob().sign(&t3.tx.signing_message());
    assert_eq!(n.block(&[t3]), Err(TxInvalid::BadSignature));
}

#[test]
fn insufficient_funds_fails_but_charges_fee() {
    let mut n = Net::new("pow");
    let a0 = n.bal(&alice().address());
    let r = n.send(&alice(), Action::Transfer { to: bob().address(), amount: u128::MAX });
    assert_eq!((r.status, r.error_code), (STATUS_FAILED, err::INSUFFICIENT_FUNDS));
    assert_eq!(n.bal(&alice().address()), a0 - 5000);
    assert_eq!(n.nonce(&alice()), 1);
}

#[test]
fn expiry_enforced() {
    let mut n = Net::new("pow");
    let mut u = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 }).tx;
    u.expiry_height = 0;
    n.empty_blocks(3);
    u.expiry_height = 2;
    assert!(matches!(n.block(&[u.sign(&alice())]), Err(TxInvalid::Expired(2))));
}

#[test]
fn coinbase_maturity() {
    let mut n = Net::new("pow");
    let miner = test_keypair("miner").address();
    n.block(&[]).unwrap();
    let a = n.st.account(&miner);
    assert_eq!(a.balance, 50_000_000);
    assert_eq!(a.available(1), 0);
    assert_eq!(a.available(6), 50_000_000); // maturity 5
}

#[test]
fn vesting_unlock_boundary() {
    let mut n = Net::new("pow");
    let v = test_keypair("vest");
    // fund fee
    n.send(&alice(), Action::Transfer { to: v.address(), amount: 100_000 });
    // h=2 < cliff 10: locked
    let r = n.send(&v, Action::Transfer { to: bob().address(), amount: 1_000_000 });
    assert_eq!(r.error_code, err::INSUFFICIENT_FUNDS);
    n.empty_blocks(7); // now at h=9; next block h=10 == cliff -> 10/110 vested = 9_090_909_090
    let r = n.send(&v, Action::Transfer { to: bob().address(), amount: 9_000_000_000 });
    assert_eq!(r.status, STATUS_SUCCESS, "{}", err::name(r.error_code));
    // h=11: vested 10_000_000_000, already spent 9e9 -> 9e9 more is not available
    let r = n.send(&v, Action::Transfer { to: bob().address(), amount: 9_000_000_000 });
    assert_eq!(r.error_code, err::INSUFFICIENT_FUNDS);
}

#[test]
fn token_lifecycle_cap_and_permissions() {
    let mut n = Net::new("pow");
    let create = Action::TokenCreate {
        symbol: "GLD".into(),
        name: "Demo Gold".into(),
        decimals: 2,
        initial_supply: 1000,
        initial_recipient: alice().address(),
        max_supply: Some(1500),
        mint_authority: Some(alice().address()),
        admin: None,
        flags: 0,
        metadata_uri: "".into(),
    };
    let nonce = n.nonce(&alice());
    assert_eq!(n.send(&alice(), create.clone()).status, STATUS_SUCCESS);
    let tid = exec::token_id(&alice().address(), nonce);
    // same symbol again creates a different id (symbols are labels)
    let nonce2 = n.nonce(&alice());
    assert_eq!(n.send(&alice(), create).status, STATUS_SUCCESS);
    assert_ne!(tid, exec::token_id(&alice().address(), nonce2));
    assert_eq!(n.send(&alice(), Action::TokenMint { token: tid, to: bob().address(), amount: 500 }).status, STATUS_SUCCESS);
    assert_eq!(n.send(&alice(), Action::TokenMint { token: tid, to: bob().address(), amount: 1 }).error_code, err::SUPPLY_CAP);
    // unauthorised mint
    n.send(&alice(), Action::Transfer { to: bob().address(), amount: 1_000_000 });
    assert_eq!(n.send(&bob(), Action::TokenMint { token: tid, to: bob().address(), amount: 1 }).error_code, err::UNAUTHORIZED);
    // pause not opted-in -> unauthorised even for creator
    assert_eq!(n.send(&alice(), Action::TokenSetPaused { token: tid, paused: true }).error_code, err::UNAUTHORIZED);
    // holder burn
    assert_eq!(n.send(&bob(), Action::TokenBurn { token: tid, amount: 100 }).status, STATUS_SUCCESS);
    let mut ov = n.st.overlay();
    assert_eq!(ov.token(&tid).unwrap().supply, 1400);
    // renounce mint authority
    ov.rollback_tx();
    drop(ov);
    assert_eq!(n.send(&alice(), Action::TokenSetMintAuthority { token: tid, new_authority: None }).status, STATUS_SUCCESS);
    assert_eq!(n.send(&alice(), Action::TokenMint { token: tid, to: bob().address(), amount: 1 }).error_code, err::UNAUTHORIZED);
}

#[test]
fn token_freeze_requires_opt_in_flag() {
    let mut n = Net::new("pow");
    let nonce = n.nonce(&alice());
    let r = n.send(&alice(), Action::TokenCreate {
        symbol: "FRZ".into(), name: "Freezable".into(), decimals: 0, initial_supply: 10,
        initial_recipient: alice().address(), max_supply: None, mint_authority: None,
        admin: Some(alice().address()), flags: FLAG_FREEZABLE, metadata_uri: "".into(),
    });
    assert_eq!(r.status, STATUS_SUCCESS);
    let tid = exec::token_id(&alice().address(), nonce);
    assert_eq!(n.send(&alice(), Action::TokenSetFrozen { token: tid, account: bob().address(), frozen: true }).status, STATUS_SUCCESS);
    assert_eq!(n.send(&alice(), Action::TokenTransfer { token: tid, to: bob().address(), amount: 1 }).error_code, err::FROZEN);
    // flags without admin are invalid
    let r = n.send(&alice(), Action::TokenCreate {
        symbol: "BAD".into(), name: "Bad".into(), decimals: 0, initial_supply: 1,
        initial_recipient: alice().address(), max_supply: None, mint_authority: None,
        admin: None, flags: FLAG_PAUSABLE, metadata_uri: "".into(),
    });
    assert_eq!(r.error_code, err::INVALID_ARGUMENT);
}

#[test]
fn treasury_multisig_threshold() {
    let mut n = Net::new("pow");
    let tre = n.p.treasury_addrs[0];
    let (t1, t2, t3) = (test_keypair("t1"), test_keypair("t2"), test_keypair("t3"));
    for k in [&t1, &t2, &t3] {
        n.send(&alice(), Action::Transfer { to: k.address(), amount: 100_000 });
    }
    let inner = Action::Transfer { to: bob().address(), amount: 7_000 };
    let b0 = n.bal(&bob().address());
    let r = n.send(&t1, Action::MultisigPropose { multisig: tre, inner: Box::new(inner), expiry_height: n.h + 100 });
    assert_eq!(r.status, STATUS_SUCCESS);
    assert_eq!(n.bal(&bob().address()), b0); // 1 of 2
    // non-signer approval rejected
    assert_eq!(n.send(&alice(), Action::MultisigApprove { multisig: tre, proposal_id: 0 }).error_code, err::UNAUTHORIZED);
    // duplicate approval rejected
    assert_eq!(n.send(&t1, Action::MultisigApprove { multisig: tre, proposal_id: 0 }).error_code, err::ALREADY_EXISTS);
    assert_eq!(n.send(&t2, Action::MultisigApprove { multisig: tre, proposal_id: 0 }).status, STATUS_SUCCESS);
    assert_eq!(n.bal(&bob().address()), b0 + 7_000);
    // executed proposals cannot execute again
    assert_eq!(n.send(&t3, Action::MultisigApprove { multisig: tre, proposal_id: 0 }).error_code, err::INVALID_ARGUMENT);
    assert_eq!(n.bal(&bob().address()), b0 + 7_000);
}

#[test]
fn claim_distribution_no_double_claim() {
    let mut n = Net::new("pow");
    let b = bob();
    let c = test_keypair("carol");
    n.send(&alice(), Action::Transfer { to: c.address(), amount: 100_000 });
    let leaves: Vec<[u8; 32]> = vec![claim_leaf(0, &b.address(), 300), claim_leaf(1, &c.address(), 700)];
    let root = merkle::root(&leaves);
    let nonce = n.nonce(&alice());
    assert_eq!(n.send(&alice(), Action::DistributionCreate { asset: AssetId::Native, total: 1000, merkle_root: root, claim_deadline_height: 50 }).status, STATUS_SUCCESS);
    let did = exec::distribution_id(&alice().address(), nonce);
    let proof = merkle::proof(&leaves, 1);
    let claim = Action::DistributionClaim { dist_id: did, index: 1, amount: 700, proof: proof.clone() };
    assert_eq!(n.send(&c, claim.clone()).status, STATUS_SUCCESS);
    assert_eq!(n.send(&c, claim).error_code, err::ALREADY_CLAIMED);
    // wrong amount -> bad proof
    let bad = Action::DistributionClaim { dist_id: did, index: 0, amount: 999, proof: merkle::proof(&leaves, 0) };
    assert_eq!(n.send(&b, bad).error_code, err::BAD_PROOF);
}

#[test]
fn arithmetic_overflow_is_failure_not_wrap() {
    let mut g = dev_genesis("pow");
    g["monetary_policy"] = serde_json::json!({"kind": "fixed"});
    let mut n = Net::from_value(g);
    let nonce = n.nonce(&alice());
    n.send(&alice(), Action::TokenCreate {
        symbol: "MAX".into(), name: "Max".into(), decimals: 0, initial_supply: u128::MAX,
        initial_recipient: alice().address(), max_supply: None, mint_authority: Some(alice().address()),
        admin: None, flags: 0, metadata_uri: "".into(),
    });
    let tid = exec::token_id(&alice().address(), nonce);
    assert_eq!(n.send(&alice(), Action::TokenMint { token: tid, to: bob().address(), amount: 1 }).error_code, err::OVERFLOW);
}

#[test]
fn authority_mint_limits() {
    let mut g = dev_genesis("pow");
    let auth = crate::crypto::bech32_encode("aurd", &alice().address());
    g["monetary_policy"] = serde_json::json!({"kind": "authority", "max_supply": "1800000001000",
        "authority": {"mint_authority": auth, "max_mint_per_window": "600", "window_blocks": 100}});
    let mut n = Net::from_value(g);
    assert_eq!(n.send(&alice(), Action::NativeMint { to: bob().address(), amount: 500 }).status, STATUS_SUCCESS);
    assert_eq!(n.send(&alice(), Action::NativeMint { to: bob().address(), amount: 200 }).error_code, err::MINT_LIMIT);
    n.send(&alice(), Action::Transfer { to: bob().address(), amount: 100_000 });
    assert_eq!(n.send(&bob(), Action::NativeMint { to: bob().address(), amount: 1 }).error_code, err::UNAUTHORIZED);
    // mint unsupported under scheduled policy
    let mut n2 = Net::new("pow");
    let t = n2.tx(&alice(), 0, Action::NativeMint { to: bob().address(), amount: 1 });
    assert!(matches!(n2.block(&[t]), Err(TxInvalid::Unsupported(_))));
}

fn votes_all(n: &Net, signed: &[bool]) -> Vec<VoteInfo> {
    n.st.overlay().valset().0.iter().zip(signed).map(|((pk, pw), s)| VoteInfo { consensus_address: comet_address(pk), power: *pw, signed: *s }).collect()
}

#[test]
fn pos_equivocation_slash_and_tombstone() {
    let mut n = Net::new("pos");
    let ck = test_keypair("cons0").public();
    let op = test_keypair("val0").address();
    let s0 = n.st.supply().total;
    let (_, upd) = n.bft_block(&[], &[Misbehavior { consensus_address: comet_address(&ck), height: 0, kind: "duplicate_vote".into() }], &[]);
    let v = n.st.overlay().validator(&op).unwrap();
    assert!(v.tombstoned);
    assert_eq!(v.bonded, 10_000_000 - 500_000); // 5%
    assert_eq!(n.st.supply().total, s0 - 500_000);
    assert_eq!(upd, vec![(ck, 0)]);
    // unjail impossible after tombstone
    let t = n.tx(&test_keypair("val0"), 0, Action::ValidatorUnjail);
    n.send(&alice(), Action::Transfer { to: op, amount: 100_000 });
    let _ = t;
    let r = n.send(&test_keypair("val0"), Action::ValidatorUnjail);
    assert_eq!(r.error_code, err::NOT_ELIGIBLE);
}

#[test]
fn pos_downtime_jails_without_tombstone() {
    let mut n = Net::new("pos");
    let vs = n.st.overlay().valset();
    let missing_pk = vs.0[0].0;
    let op = n.st.overlay().operator_of_consaddr(&comet_address(&missing_pk)).unwrap();
    let mut jailed_at = None;
    for _ in 0..12 {
        let votes = votes_all(&n, &[false, true, true, true]);
        let (_, upd) = n.bft_block(&votes, &[], &[]);
        if !upd.is_empty() {
            jailed_at = Some(n.h);
            assert_eq!(upd, vec![(missing_pk, 0)]);
            break;
        }
    }
    assert!(jailed_at.is_some(), "validator should be jailed after > downtime_max_missed misses");
    let v = n.st.overlay().validator(&op).unwrap();
    assert!(!v.tombstoned && v.jailed_until > n.h);
    assert_eq!(v.bonded, 10_000_000 - 100_000); // 1% downtime slash
    // after jail period it can unjail and rejoin
    let vkp = (0..4).map(|i| test_keypair(&format!("val{i}"))).find(|k| k.address() == op).unwrap();
    n.send(&alice(), Action::Transfer { to: op, amount: 100_000 });
    assert_eq!(n.send(&vkp, Action::ValidatorUnjail).error_code, err::JAILED);
    for _ in 0..20 {
        n.bft_block(&[], &[], &[]);
    }
    let t = n.tx(&vkp, n.nonce(&vkp), Action::ValidatorUnjail);
    let (r, upd) = n.bft_block(&[], &[], &[t]);
    assert_eq!(r[0].status, STATUS_SUCCESS);
    assert_eq!(upd, vec![(missing_pk, 9)]);
}

#[test]
fn pos_rewards_and_unbonding() {
    let mut n = Net::new("pos");
    let op = test_keypair("val1").address();
    let b0 = n.bal(&op);
    let votes = votes_all(&n, &[true, true, true, true]);
    n.bft_block(&votes, &[], &[]);
    // 50_000_000 reward split across 4 equal validators
    assert_eq!(n.bal(&op), b0 + 12_500_000);
    n.send(&alice(), Action::Transfer { to: op, amount: 100_000 });
    let vkp = test_keypair("val1");
    let before = n.bal(&op);
    let r = n.send(&vkp, Action::ValidatorUnbond { amount: 5_000_000 });
    assert_eq!(r.status, STATUS_SUCCESS);
    for _ in 0..100 {
        n.bft_block(&[], &[], &[]);
    }
    assert_eq!(n.bal(&op), before - 5000 + 5_000_000);
}

#[test]
fn pos_new_validator_joins_at_epoch() {
    let mut n = Net::new("pos");
    let nv = test_keypair("newval");
    n.send(&alice(), Action::Transfer { to: nv.address(), amount: 50_000_000 });
    let ck = test_keypair("newcons").public();
    let r = n.send(&nv, Action::ValidatorCreate { consensus_pubkey: ck, self_bond: 20_000_000, moniker: "new".into() });
    assert_eq!(r.status, STATUS_SUCCESS);
    let mut joined = false;
    for _ in 0..12 {
        let (_, upd) = n.bft_block(&[], &[], &[]);
        if upd.contains(&(ck, 20)) {
            assert_eq!(n.h % 10, 0, "joins only at an epoch boundary");
            joined = true;
            break;
        }
    }
    assert!(joined);
}

#[test]
fn poa_authorised_add_and_unauthorised_rejected() {
    let mut n = Net::new("poa");
    let newop = test_keypair("auth-new").address();
    let ck = test_keypair("auth-new-cons").public();
    let kind = GovKind::AddAuthority { operator: newop, consensus_pubkey: ck, power: 10, moniker: "auth4".into() };
    // fund authorities for fees
    for i in 0..4 {
        n.send(&alice(), Action::Transfer { to: test_keypair(&format!("val{i}")).address(), amount: 100_000 });
    }
    n.send(&alice(), Action::Transfer { to: bob().address(), amount: 100_000 });
    // unauthorised proposer
    let r = n.send(&bob(), Action::GovPropose { kind: kind.clone(), expiry_height: n.h + 50 });
    assert_eq!(r.error_code, err::UNAUTHORIZED);
    let v0 = test_keypair("val0");
    let r = n.send(&v0, Action::GovPropose { kind, expiry_height: n.h + 50 });
    assert_eq!(r.status, STATUS_SUCCESS);
    let pid = 1; // proposal 0 was not created (failed); ids are only consumed on success
    let _ = pid;
    let gs = n.st.overlay().gov_state();
    let id = gs.next_id - 1;
    // 2 of 4 approvals: not > 2/3
    let t = n.tx(&test_keypair("val1"), n.nonce(&test_keypair("val1")), Action::GovApprove { proposal_id: id });
    let (_, upd) = n.bft_block(&[], &[], &[t]);
    assert!(upd.is_empty());
    // 3 of 4: 30*3 = 90 > 40*2 = 80 -> executes
    let t = n.tx(&test_keypair("val2"), n.nonce(&test_keypair("val2")), Action::GovApprove { proposal_id: id });
    let (r, upd) = n.bft_block(&[], &[], &[t]);
    assert_eq!(r[0].status, STATUS_SUCCESS);
    assert_eq!(upd, vec![(ck, 10)]);
    // unauthorised validator-set change via staking actions is unsupported on PoA
    let t = n.tx(&bob(), n.nonce(&bob()), Action::ValidatorCreate { consensus_pubkey: ck, self_bond: 1, moniker: "x".into() });
    assert!(matches!(n.block(&[t]), Err(TxInvalid::Unsupported(_))));
}

#[test]
fn key_rotation_updates_valset() {
    let mut n = Net::new("poa");
    let v0 = test_keypair("val0");
    n.send(&alice(), Action::Transfer { to: v0.address(), amount: 100_000 });
    let old = test_keypair("cons0").public();
    let new = test_keypair("cons0-rotated").public();
    let t = n.tx(&v0, n.nonce(&v0), Action::ValidatorRotateKey { new_consensus_pubkey: new });
    let (r, upd) = n.bft_block(&[], &[], &[t]);
    assert_eq!(r[0].status, STATUS_SUCCESS);
    assert!(upd.contains(&(old, 0)) && upd.contains(&(new, 10)));
    // old key still attributable for evidence
    assert_eq!(n.st.overlay().operator_of_consaddr(&comet_address(&old)), Some(v0.address()));
}

#[test]
fn upgrade_halts_unsupported_version() {
    let mut n = Net::new("poa");
    for i in 0..4 {
        n.send(&alice(), Action::Transfer { to: test_keypair(&format!("val{i}")).address(), amount: 100_000 });
    }
    let act = n.h + 5;
    let kind = GovKind::ProtocolUpgrade { name: "v2".into(), protocol_version: 2, activation_height: act };
    n.send(&test_keypair("val0"), Action::GovPropose { kind, expiry_height: n.h + 50 });
    let id = n.st.overlay().gov_state().next_id - 1;
    n.send(&test_keypair("val1"), Action::GovApprove { proposal_id: id });
    n.send(&test_keypair("val2"), Action::GovApprove { proposal_id: id });
    while n.h + 1 < act {
        n.bft_block(&[], &[], &[]);
    }
    let mut ov = n.st.overlay();
    let mut ctx = BlockCtx::new(act, None);
    let e = exec::begin_block_bft(&mut ov, &n.p, &mut ctx, &[], &[]).unwrap_err();
    assert!(e.contains("halting"), "{e}");
}

#[test]
fn deterministic_execution_and_undo() {
    // Same random transaction stream executed on two independent states -> same roots;
    // undo logs restore every intermediate root exactly.
    let keys: Vec<Keypair> = ["alice", "bob", "carol", "dave"].iter().map(|l| test_keypair(l)).collect();
    let mut a = Net::new("pow");
    let mut b = Net::new("pow");
    let mut seed = 42u64;
    let mut rnd = || {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        seed
    };
    // fund everyone
    for k in &keys[1..] {
        let t = a.tx(&keys[0], a.nonce(&keys[0]), Action::Transfer { to: k.address(), amount: 10_000_000 });
        a.block(&[t.clone()]).unwrap();
        b.block(&[t]).unwrap();
    }
    let mut roots = vec![a.st.root()];
    let mut undos = vec![];
    for _ in 0..30 {
        let mut txs = vec![];
        let mut nonces: Vec<u64> = keys.iter().map(|k| a.nonce(k)).collect();
        for _ in 0..(rnd() % 6) {
            let s = (rnd() % 4) as usize;
            let r = (rnd() % 4) as usize;
            let amt = (rnd() % 3_000_000) as u128;
            txs.push(a.tx(&keys[s], nonces[s], Action::Transfer { to: keys[r].address(), amount: amt }));
            nonces[s] += 1;
        }
        let h = a.h + 1;
        let miner = test_keypair("miner").address();
        let mut ctx = BlockCtx::new(h, Some(miner));
        let mut ov = a.st.overlay();
        exec::execute_txs(&mut ov, &a.p, &mut ctx, &txs).unwrap();
        exec::pow_coinbase(&mut ov, &a.p, &mut ctx, &miner);
        let cs = ov.into_changes();
        undos.push(a.st.apply(&cs));
        a.h = h;
        b.block(&txs).unwrap();
        assert_eq!(a.st.root(), b.st.root());
        roots.push(a.st.root());
    }
    for (i, u) in undos.iter().enumerate().rev() {
        a.st.revert(u);
        assert_eq!(a.st.root(), roots[i]);
    }
}

#[test]
fn tx_size_limit_and_malformed() {
    let n = Net::new("pow");
    let t = n.tx(&alice(), 0, Action::Transfer { to: bob().address(), amount: 1 });
    let mut bytes = t.encode();
    bytes.push(0);
    assert!(matches!(exec::decode_tx(&n.p, &bytes), Err(TxInvalid::Decode(_))));
    let big = vec![0u8; 70_000];
    assert!(matches!(exec::decode_tx(&n.p, &big), Err(TxInvalid::TooLarge { .. })));
}
