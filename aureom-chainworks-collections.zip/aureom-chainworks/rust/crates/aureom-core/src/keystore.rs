//! Encrypted keystore: Argon2id key derivation + XChaCha20-Poly1305 (RustCrypto).
//! The address and public key are bound as associated data, so a keystore cannot be
//! silently relabelled. Decrypted seeds are zeroized after use.

use crate::crypto::{bech32_encode, Keypair};
use argon2::{Algorithm, Argon2, Params, Version};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use rand_core::{OsRng, RngCore};
use serde::{Deserialize, Serialize};
use zeroize::Zeroizing;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Kdf {
    pub name: String,
    pub m_kib: u32,
    pub t: u32,
    pub p: u32,
    pub salt: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Cipher {
    pub name: String,
    pub nonce: String,
    pub ciphertext: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Keystore {
    pub aureom_keystore: u32,
    pub role: String,
    pub label: String,
    pub address_hrp: String,
    pub address: String,
    pub pubkey: String,
    pub kdf: Kdf,
    pub cipher: Cipher,
}

#[derive(Debug, thiserror::Error)]
pub enum KeystoreError {
    #[error("wrong passphrase or corrupted keystore")]
    Decrypt,
    #[error("unsupported keystore: {0}")]
    Unsupported(String),
    #[error("kdf parameters too weak: {0}")]
    Weak(String),
    #[error("keystore address/pubkey mismatch")]
    Mismatch,
}

pub const MIN_M_KIB: u32 = 8 * 1024;

fn derive(pass: &[u8], salt: &[u8], k: &Kdf) -> Result<Zeroizing<[u8; 32]>, KeystoreError> {
    if k.name != "argon2id" {
        return Err(KeystoreError::Unsupported(k.name.clone()));
    }
    if k.m_kib < MIN_M_KIB || k.t < 1 {
        return Err(KeystoreError::Weak(format!("m_kib={} t={}", k.m_kib, k.t)));
    }
    let params = Params::new(k.m_kib, k.t, k.p, Some(32)).map_err(|e| KeystoreError::Unsupported(e.to_string()))?;
    let a = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    let mut out = Zeroizing::new([0u8; 32]);
    a.hash_password_into(pass, salt, out.as_mut()).map_err(|e| KeystoreError::Unsupported(e.to_string()))?;
    Ok(out)
}

fn aad(ks_address: &str, pubkey: &str) -> Vec<u8> {
    format!("AUREOM/KEYSTORE/v1|{ks_address}|{pubkey}").into_bytes()
}

impl Keystore {
    /// `fast_kdf` uses the minimum allowed Argon2id cost (development networks only).
    pub fn encrypt(kp: &Keypair, pass: &[u8], hrp: &str, role: &str, label: &str, fast_kdf: bool) -> Keystore {
        let mut salt = [0u8; 16];
        OsRng.fill_bytes(&mut salt);
        let mut nonce = [0u8; 24];
        OsRng.fill_bytes(&mut nonce);
        let kdf = Kdf {
            name: "argon2id".into(),
            m_kib: if fast_kdf { MIN_M_KIB } else { 64 * 1024 },
            t: if fast_kdf { 1 } else { 3 },
            p: 1,
            salt: hex::encode(salt),
        };
        let key = derive(pass, &salt, &kdf).expect("valid params");
        let address = bech32_encode(hrp, &kp.address());
        let pubkey = hex::encode(kp.public());
        let cipher = XChaCha20Poly1305::new(key.as_ref().into());
        let seed = Zeroizing::new(kp.seed());
        let ct = cipher
            .encrypt(XNonce::from_slice(&nonce), Payload { msg: seed.as_ref(), aad: &aad(&address, &pubkey) })
            .expect("encrypt");
        Keystore {
            aureom_keystore: 1,
            role: role.into(),
            label: label.into(),
            address_hrp: hrp.into(),
            address,
            pubkey,
            kdf,
            cipher: Cipher { name: "xchacha20poly1305".into(), nonce: hex::encode(nonce), ciphertext: hex::encode(ct) },
        }
    }

    pub fn decrypt(&self, pass: &[u8]) -> Result<Keypair, KeystoreError> {
        if self.aureom_keystore != 1 || self.cipher.name != "xchacha20poly1305" {
            return Err(KeystoreError::Unsupported("version/cipher".into()));
        }
        let salt = hex::decode(&self.kdf.salt).map_err(|_| KeystoreError::Decrypt)?;
        let nonce = hex::decode(&self.cipher.nonce).map_err(|_| KeystoreError::Decrypt)?;
        let ct = hex::decode(&self.cipher.ciphertext).map_err(|_| KeystoreError::Decrypt)?;
        if nonce.len() != 24 {
            return Err(KeystoreError::Decrypt);
        }
        let key = derive(pass, &salt, &self.kdf)?;
        let cipher = XChaCha20Poly1305::new(key.as_ref().into());
        let pt = Zeroizing::new(
            cipher
                .decrypt(XNonce::from_slice(&nonce), Payload { msg: &ct, aad: &aad(&self.address, &self.pubkey) })
                .map_err(|_| KeystoreError::Decrypt)?,
        );
        let seed: Zeroizing<[u8; 32]> = Zeroizing::new(pt.as_slice().try_into().map_err(|_| KeystoreError::Decrypt)?);
        let kp = Keypair::from_seed(&seed);
        if hex::encode(kp.public()) != self.pubkey || bech32_encode(&self.address_hrp, &kp.address()) != self.address {
            return Err(KeystoreError::Mismatch);
        }
        Ok(kp)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_and_wrong_pass() {
        let kp = Keypair::generate();
        let ks = Keystore::encrypt(&kp, b"correct horse", "aurd", "account", "test", true);
        let s = serde_json::to_string(&ks).unwrap();
        assert!(!s.contains(&hex::encode(kp.seed())));
        let ks2: Keystore = serde_json::from_str(&s).unwrap();
        assert_eq!(ks2.decrypt(b"correct horse").unwrap().public(), kp.public());
        assert!(matches!(ks2.decrypt(b"wrong"), Err(KeystoreError::Decrypt)));
        let mut tampered = ks2.clone();
        tampered.address = bech32_encode("aurd", &[0u8; 20]);
        assert!(tampered.decrypt(b"correct horse").is_err());
    }
}
