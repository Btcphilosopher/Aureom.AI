//! Consensus types and their canonical encodings (PROTOCOL.md sections 5–8).

use crate::codec::*;
use crate::crypto::{address_from_pubkey, hash_domain, Addr, Hash32};
use crate::merkle::ProofStep;

pub const PROTOCOL_VERSION: u16 = 1;
pub const TX_VERSION: u16 = 1;
pub const MAX_CHAIN_ID_LEN: usize = 64;
pub const MAX_MEMO_BYTES: usize = 256;
pub const MAX_MSIG_SIGNERS: usize = 16;
pub const MAX_PROOF_STEPS: usize = 32;
pub const MAX_SYMBOL_LEN: usize = 12;
pub const MAX_NAME_LEN: usize = 64;
pub const MAX_URI_LEN: usize = 200;
pub const MAX_TOKEN_DECIMALS: u8 = 18;
pub const MAX_VESTING_ENTRIES: usize = 8;
pub const MAX_EVENTS: usize = 64;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum AssetId {
    Native,
    Token(Addr),
}

impl Encode for AssetId {
    fn encode_to(&self, w: &mut Writer) {
        match self {
            AssetId::Native => w.u8(0),
            AssetId::Token(t) => {
                w.u8(1);
                w.fixed(t)
            }
        }
    }
}
impl Decode for AssetId {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        match r.u8()? {
            0 => Ok(AssetId::Native),
            1 => Ok(AssetId::Token(r.fixed()?)),
            t => Err(DecodeError::BadTag(t, "asset")),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum GovKind {
    AddAuthority { operator: Addr, consensus_pubkey: [u8; 32], power: u64, moniker: String },
    RemoveAuthority { operator: Addr },
    ProtocolUpgrade { name: String, protocol_version: u16, activation_height: u64 },
    Text { title: String, uri: String },
}

impl Encode for GovKind {
    fn encode_to(&self, w: &mut Writer) {
        match self {
            GovKind::AddAuthority { operator, consensus_pubkey, power, moniker } => {
                w.u8(1);
                w.fixed(operator);
                w.fixed(consensus_pubkey);
                w.u64(*power);
                w.string(moniker);
            }
            GovKind::RemoveAuthority { operator } => {
                w.u8(2);
                w.fixed(operator);
            }
            GovKind::ProtocolUpgrade { name, protocol_version, activation_height } => {
                w.u8(3);
                w.string(name);
                w.u16(*protocol_version);
                w.u64(*activation_height);
            }
            GovKind::Text { title, uri } => {
                w.u8(4);
                w.string(title);
                w.string(uri);
            }
        }
    }
}
impl Decode for GovKind {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(match r.u8()? {
            1 => GovKind::AddAuthority {
                operator: r.fixed()?,
                consensus_pubkey: r.fixed()?,
                power: r.u64()?,
                moniker: r.string(MAX_NAME_LEN)?,
            },
            2 => GovKind::RemoveAuthority { operator: r.fixed()? },
            3 => GovKind::ProtocolUpgrade {
                name: r.string(MAX_NAME_LEN)?,
                protocol_version: r.u16()?,
                activation_height: r.u64()?,
            },
            4 => GovKind::Text { title: r.string(MAX_NAME_LEN)?, uri: r.string(MAX_URI_LEN)? },
            t => return Err(DecodeError::BadTag(t, "gov kind")),
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Action {
    Transfer { to: Addr, amount: u128 },
    VestedTransfer { to: Addr, amount: u128, start_height: u64, cliff_height: u64, end_height: u64 },
    NativeMint { to: Addr, amount: u128 },
    NativeBurn { amount: u128 },
    TokenCreate {
        symbol: String,
        name: String,
        decimals: u8,
        initial_supply: u128,
        initial_recipient: Addr,
        max_supply: Option<u128>,
        mint_authority: Option<Addr>,
        admin: Option<Addr>,
        flags: u8,
        metadata_uri: String,
    },
    TokenTransfer { token: Addr, to: Addr, amount: u128 },
    TokenMint { token: Addr, to: Addr, amount: u128 },
    TokenBurn { token: Addr, amount: u128 },
    TokenSetPaused { token: Addr, paused: bool },
    TokenSetFrozen { token: Addr, account: Addr, frozen: bool },
    TokenSetMintAuthority { token: Addr, new_authority: Option<Addr> },
    MultisigCreate { signers: Vec<Addr>, threshold: u8 },
    MultisigPropose { multisig: Addr, inner: Box<Action>, expiry_height: u64 },
    MultisigApprove { multisig: Addr, proposal_id: u64 },
    DistributionCreate { asset: AssetId, total: u128, merkle_root: Hash32, claim_deadline_height: u64 },
    DistributionClaim { dist_id: Hash32, index: u32, amount: u128, proof: Vec<ProofStep> },
    DistributionReclaim { dist_id: Hash32 },
    ValidatorCreate { consensus_pubkey: [u8; 32], self_bond: u128, moniker: String },
    ValidatorBond { amount: u128 },
    ValidatorUnbond { amount: u128 },
    ValidatorUnjail,
    ValidatorRotateKey { new_consensus_pubkey: [u8; 32] },
    GovPropose { kind: GovKind, expiry_height: u64 },
    GovApprove { proposal_id: u64 },
    /// AUREOM COLLECTIONS native NFT module (tags 60–79, see nft.rs).
    Nft(crate::nft::NftAction),
}

pub const FLAG_PAUSABLE: u8 = 1;
pub const FLAG_FREEZABLE: u8 = 2;

impl Action {
    pub fn tag(&self) -> u8 {
        use Action::*;
        match self {
            Transfer { .. } => 1,
            VestedTransfer { .. } => 2,
            NativeMint { .. } => 3,
            NativeBurn { .. } => 4,
            TokenCreate { .. } => 10,
            TokenTransfer { .. } => 11,
            TokenMint { .. } => 12,
            TokenBurn { .. } => 13,
            TokenSetPaused { .. } => 14,
            TokenSetFrozen { .. } => 15,
            TokenSetMintAuthority { .. } => 16,
            MultisigCreate { .. } => 20,
            MultisigPropose { .. } => 21,
            MultisigApprove { .. } => 22,
            DistributionCreate { .. } => 30,
            DistributionClaim { .. } => 31,
            DistributionReclaim { .. } => 32,
            ValidatorCreate { .. } => 40,
            ValidatorBond { .. } => 41,
            ValidatorUnbond { .. } => 42,
            ValidatorUnjail => 43,
            ValidatorRotateKey { .. } => 44,
            GovPropose { .. } => 50,
            GovApprove { .. } => 51,
            Nft(a) => a.tag(),
        }
    }

    pub fn type_name(&self) -> &'static str {
        use Action::*;
        match self {
            Transfer { .. } => "transfer",
            VestedTransfer { .. } => "vested_transfer",
            NativeMint { .. } => "native_mint",
            NativeBurn { .. } => "native_burn",
            TokenCreate { .. } => "token_create",
            TokenTransfer { .. } => "token_transfer",
            TokenMint { .. } => "token_mint",
            TokenBurn { .. } => "token_burn",
            TokenSetPaused { .. } => "token_set_paused",
            TokenSetFrozen { .. } => "token_set_frozen",
            TokenSetMintAuthority { .. } => "token_set_mint_authority",
            MultisigCreate { .. } => "multisig_create",
            MultisigPropose { .. } => "multisig_propose",
            MultisigApprove { .. } => "multisig_approve",
            DistributionCreate { .. } => "distribution_create",
            DistributionClaim { .. } => "distribution_claim",
            DistributionReclaim { .. } => "distribution_reclaim",
            ValidatorCreate { .. } => "validator_create",
            ValidatorBond { .. } => "validator_bond",
            ValidatorUnbond { .. } => "validator_unbond",
            ValidatorUnjail => "validator_unjail",
            ValidatorRotateKey { .. } => "validator_rotate_key",
            GovPropose { .. } => "gov_propose",
            GovApprove { .. } => "gov_approve",
            Nft(a) => a.type_name(),
        }
    }

    /// Inner actions a multisig may execute (PROTOCOL.md 5.3).
    pub fn allowed_in_multisig(&self) -> bool {
        match self {
            Action::Nft(a) => a.allowed_in_multisig(),
            _ => matches!(self.tag(), 1 | 2 | 3 | 11 | 12 | 16),
        }
    }
}

impl Encode for Action {
    fn encode_to(&self, w: &mut Writer) {
        use Action::*;
        w.u8(self.tag());
        match self {
            Transfer { to, amount } => {
                w.fixed(to);
                w.u128(*amount)
            }
            VestedTransfer { to, amount, start_height, cliff_height, end_height } => {
                w.fixed(to);
                w.u128(*amount);
                w.u64(*start_height);
                w.u64(*cliff_height);
                w.u64(*end_height);
            }
            NativeMint { to, amount } => {
                w.fixed(to);
                w.u128(*amount)
            }
            NativeBurn { amount } => w.u128(*amount),
            TokenCreate {
                symbol,
                name,
                decimals,
                initial_supply,
                initial_recipient,
                max_supply,
                mint_authority,
                admin,
                flags,
                metadata_uri,
            } => {
                w.string(symbol);
                w.string(name);
                w.u8(*decimals);
                w.u128(*initial_supply);
                w.fixed(initial_recipient);
                w.opt(max_supply, |w, v| w.u128(*v));
                w.opt(mint_authority, |w, v| w.fixed(v));
                w.opt(admin, |w, v| w.fixed(v));
                w.u8(*flags);
                w.string(metadata_uri);
            }
            TokenTransfer { token, to, amount } | TokenMint { token, to, amount } => {
                w.fixed(token);
                w.fixed(to);
                w.u128(*amount)
            }
            TokenBurn { token, amount } => {
                w.fixed(token);
                w.u128(*amount)
            }
            TokenSetPaused { token, paused } => {
                w.fixed(token);
                w.bool(*paused)
            }
            TokenSetFrozen { token, account, frozen } => {
                w.fixed(token);
                w.fixed(account);
                w.bool(*frozen)
            }
            TokenSetMintAuthority { token, new_authority } => {
                w.fixed(token);
                w.opt(new_authority, |w, v| w.fixed(v))
            }
            MultisigCreate { signers, threshold } => {
                w.vec(signers, |w, s| w.fixed(s));
                w.u8(*threshold)
            }
            MultisigPropose { multisig, inner, expiry_height } => {
                w.fixed(multisig);
                inner.encode_to(w);
                w.u64(*expiry_height)
            }
            MultisigApprove { multisig, proposal_id } => {
                w.fixed(multisig);
                w.u64(*proposal_id)
            }
            DistributionCreate { asset, total, merkle_root, claim_deadline_height } => {
                asset.encode_to(w);
                w.u128(*total);
                w.fixed(merkle_root);
                w.u64(*claim_deadline_height)
            }
            DistributionClaim { dist_id, index, amount, proof } => {
                w.fixed(dist_id);
                w.u32(*index);
                w.u128(*amount);
                w.vec(proof, |w, p| {
                    w.u8(p.side);
                    w.fixed(&p.sibling)
                })
            }
            DistributionReclaim { dist_id } => w.fixed(dist_id),
            ValidatorCreate { consensus_pubkey, self_bond, moniker } => {
                w.fixed(consensus_pubkey);
                w.u128(*self_bond);
                w.string(moniker)
            }
            ValidatorBond { amount } | ValidatorUnbond { amount } => w.u128(*amount),
            ValidatorUnjail => {}
            ValidatorRotateKey { new_consensus_pubkey } => w.fixed(new_consensus_pubkey),
            GovPropose { kind, expiry_height } => {
                kind.encode_to(w);
                w.u64(*expiry_height)
            }
            GovApprove { proposal_id } => w.u64(*proposal_id),
            Nft(a) => a.encode_body(w),
        }
    }
}

fn decode_action(r: &mut Reader, depth: u8) -> DResult<Action> {
    use Action::*;
    let tag = r.u8()?;
    Ok(match tag {
        1 => Transfer { to: r.fixed()?, amount: r.u128()? },
        2 => VestedTransfer {
            to: r.fixed()?,
            amount: r.u128()?,
            start_height: r.u64()?,
            cliff_height: r.u64()?,
            end_height: r.u64()?,
        },
        3 => NativeMint { to: r.fixed()?, amount: r.u128()? },
        4 => NativeBurn { amount: r.u128()? },
        10 => TokenCreate {
            symbol: r.string(MAX_SYMBOL_LEN)?,
            name: r.string(MAX_NAME_LEN)?,
            decimals: r.u8()?,
            initial_supply: r.u128()?,
            initial_recipient: r.fixed()?,
            max_supply: r.opt(|r| r.u128())?,
            mint_authority: r.opt(|r| r.fixed())?,
            admin: r.opt(|r| r.fixed())?,
            flags: r.u8()?,
            metadata_uri: r.string(MAX_URI_LEN)?,
        },
        11 => TokenTransfer { token: r.fixed()?, to: r.fixed()?, amount: r.u128()? },
        12 => TokenMint { token: r.fixed()?, to: r.fixed()?, amount: r.u128()? },
        13 => TokenBurn { token: r.fixed()?, amount: r.u128()? },
        14 => TokenSetPaused { token: r.fixed()?, paused: r.bool()? },
        15 => TokenSetFrozen { token: r.fixed()?, account: r.fixed()?, frozen: r.bool()? },
        16 => TokenSetMintAuthority { token: r.fixed()?, new_authority: r.opt(|r| r.fixed())? },
        20 => MultisigCreate { signers: r.vec(MAX_MSIG_SIGNERS, 20, |r| r.fixed())?, threshold: r.u8()? },
        21 => {
            if depth > 0 {
                return Err(DecodeError::Invalid("nested multisig proposal"));
            }
            let multisig = r.fixed()?;
            let inner = decode_action(r, depth + 1)?;
            if !inner.allowed_in_multisig() {
                return Err(DecodeError::Invalid("action not allowed in multisig"));
            }
            MultisigPropose { multisig, inner: Box::new(inner), expiry_height: r.u64()? }
        }
        22 => MultisigApprove { multisig: r.fixed()?, proposal_id: r.u64()? },
        30 => DistributionCreate {
            asset: AssetId::decode_from(r)?,
            total: r.u128()?,
            merkle_root: r.fixed()?,
            claim_deadline_height: r.u64()?,
        },
        31 => DistributionClaim {
            dist_id: r.fixed()?,
            index: r.u32()?,
            amount: r.u128()?,
            proof: r.vec(MAX_PROOF_STEPS, 33, |r| {
                let side = r.u8()?;
                if side > 1 {
                    return Err(DecodeError::BadTag(side, "proof side"));
                }
                Ok(ProofStep { side, sibling: r.fixed()? })
            })?,
        },
        32 => DistributionReclaim { dist_id: r.fixed()? },
        40 => ValidatorCreate {
            consensus_pubkey: r.fixed()?,
            self_bond: r.u128()?,
            moniker: r.string(MAX_NAME_LEN)?,
        },
        41 => ValidatorBond { amount: r.u128()? },
        42 => ValidatorUnbond { amount: r.u128()? },
        43 => ValidatorUnjail,
        44 => ValidatorRotateKey { new_consensus_pubkey: r.fixed()? },
        50 => GovPropose { kind: GovKind::decode_from(r)?, expiry_height: r.u64()? },
        51 => GovApprove { proposal_id: r.u64()? },
        60..=79 => Nft(crate::nft::decode_body(tag, r)?),
        t => return Err(DecodeError::BadTag(t, "action")),
    })
}

impl Decode for Action {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        decode_action(r, 0)
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct UnsignedTx {
    pub version: u16,
    pub chain_id: String,
    pub nonce: u64,
    pub fee: u64,
    pub expiry_height: u64,
    pub sender_pubkey: [u8; 32],
    pub action: Action,
    pub memo: Vec<u8>,
}

impl Encode for UnsignedTx {
    fn encode_to(&self, w: &mut Writer) {
        w.u16(self.version);
        w.string(&self.chain_id);
        w.u64(self.nonce);
        w.u64(self.fee);
        w.u64(self.expiry_height);
        w.fixed(&self.sender_pubkey);
        self.action.encode_to(w);
        w.bytes(&self.memo);
    }
}
impl Decode for UnsignedTx {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(UnsignedTx {
            version: r.u16()?,
            chain_id: r.string(MAX_CHAIN_ID_LEN)?,
            nonce: r.u64()?,
            fee: r.u64()?,
            expiry_height: r.u64()?,
            sender_pubkey: r.fixed()?,
            action: Action::decode_from(r)?,
            memo: r.bytes(MAX_MEMO_BYTES)?,
        })
    }
}

impl UnsignedTx {
    pub fn sender(&self) -> Addr {
        address_from_pubkey(&self.sender_pubkey)
    }
    /// PROTOCOL.md 5.2
    pub fn signing_message(&self) -> Vec<u8> {
        let mut w = Writer::new();
        let d = "AUREOM/TXSIG/v1";
        w.u8(d.len() as u8);
        w.fixed(d.as_bytes());
        w.string(&self.chain_id);
        w.u16(PROTOCOL_VERSION);
        w.u8(self.action.tag());
        self.encode_to(&mut w);
        w.finish()
    }
    pub fn txid(&self) -> Hash32 {
        hash_domain("AUREOM/TXID/v1", &self.encode())
    }
    pub fn sign(self, kp: &crate::crypto::Keypair) -> SignedTx {
        let signature = kp.sign(&self.signing_message());
        SignedTx { tx: self, signature }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SignedTx {
    pub tx: UnsignedTx,
    pub signature: [u8; 64],
}

impl Encode for SignedTx {
    fn encode_to(&self, w: &mut Writer) {
        self.tx.encode_to(w);
        w.fixed(&self.signature);
    }
}
impl Decode for SignedTx {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(SignedTx { tx: UnsignedTx::decode_from(r)?, signature: r.fixed()? })
    }
}

impl SignedTx {
    pub fn txid(&self) -> Hash32 {
        self.tx.txid()
    }
    pub fn verify_signature(&self) -> bool {
        crate::crypto::verify(&self.tx.sender_pubkey, &self.tx.signing_message(), &self.signature)
    }
    pub fn size(&self) -> usize {
        self.encode().len()
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct Event {
    pub kind: String,
    pub attrs: Vec<(String, String)>,
}

impl Event {
    pub fn new(kind: &str) -> Self {
        Event { kind: kind.into(), attrs: vec![] }
    }
    pub fn attr(mut self, k: &str, v: impl ToString) -> Self {
        self.attrs.push((k.into(), v.to_string()));
        self
    }
}

impl Encode for Event {
    fn encode_to(&self, w: &mut Writer) {
        w.string(&self.kind);
        w.vec(&self.attrs, |w, (k, v)| {
            w.string(k);
            w.string(v)
        });
    }
}
impl Decode for Event {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Event {
            kind: r.string(32)?,
            attrs: r.vec(16, 8, |r| Ok((r.string(32)?, r.string(128)?)))?,
        })
    }
}

pub const STATUS_SUCCESS: u8 = 1;
pub const STATUS_FAILED: u8 = 2;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Receipt {
    pub txid: Hash32,
    pub status: u8,
    pub error_code: u16,
    pub fee_paid: u64,
    pub events: Vec<Event>,
}

impl Encode for Receipt {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.txid);
        w.u8(self.status);
        w.u16(self.error_code);
        w.u64(self.fee_paid);
        w.vec(&self.events, |w, e| e.encode_to(w));
    }
}
impl Decode for Receipt {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Receipt {
            txid: r.fixed()?,
            status: r.u8()?,
            error_code: r.u16()?,
            fee_paid: r.u64()?,
            events: r.vec(MAX_EVENTS, 8, Event::decode_from)?,
        })
    }
}

impl Receipt {
    pub fn hash(&self) -> Hash32 {
        hash_domain("AUREOM/RECEIPT/v1", &self.encode())
    }
}

pub fn receipt_root(receipts: &[Receipt]) -> Hash32 {
    let hs: Vec<Hash32> = receipts.iter().map(|r| r.hash()).collect();
    crate::merkle::root(&hs)
}

pub fn tx_root(txs: &[SignedTx]) -> Hash32 {
    let ids: Vec<Hash32> = txs.iter().map(|t| t.txid()).collect();
    crate::merkle::root(&ids)
}

// ------------------------------------------------------------------ state values

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Vesting {
    pub total: u128,
    pub start_height: u64,
    pub cliff_height: u64,
    pub end_height: u64,
}

impl Vesting {
    pub fn vested(&self, h: u64) -> u128 {
        if h < self.cliff_height {
            0
        } else if h >= self.end_height {
            self.total
        } else {
            let num = (h - self.start_height) as u128;
            let den = (self.end_height - self.start_height) as u128;
            crate::mul_div(self.total, num, den)
        }
    }
    pub fn locked(&self, h: u64) -> u128 {
        self.total - self.vested(h)
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Immature {
    pub mature_height: u64,
    pub amount: u128,
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct Account {
    pub balance: u128,
    pub nonce: u64,
    pub vesting: Vec<Vesting>,
    pub immature: Vec<Immature>,
}

impl Account {
    pub fn locked(&self, h: u64) -> u128 {
        self.vesting.iter().map(|v| v.locked(h)).sum()
    }
    pub fn immature_amount(&self, h: u64) -> u128 {
        self.immature.iter().filter(|i| h < i.mature_height).map(|i| i.amount).sum()
    }
    pub fn available(&self, h: u64) -> u128 {
        self.balance.saturating_sub(self.locked(h)).saturating_sub(self.immature_amount(h))
    }
    /// Deterministic pruning of fully vested / matured entries.
    pub fn prune(&mut self, h: u64) {
        self.vesting.retain(|v| v.locked(h) > 0);
        self.immature.retain(|i| h < i.mature_height);
    }
    pub fn is_empty(&self) -> bool {
        self.balance == 0 && self.nonce == 0 && self.vesting.is_empty() && self.immature.is_empty()
    }
}

impl Encode for Account {
    fn encode_to(&self, w: &mut Writer) {
        w.u128(self.balance);
        w.u64(self.nonce);
        w.vec(&self.vesting, |w, v| {
            w.u128(v.total);
            w.u64(v.start_height);
            w.u64(v.cliff_height);
            w.u64(v.end_height);
        });
        w.vec(&self.immature, |w, i| {
            w.u64(i.mature_height);
            w.u128(i.amount);
        });
    }
}
impl Decode for Account {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Account {
            balance: r.u128()?,
            nonce: r.u64()?,
            vesting: r.vec(1024, 40, |r| {
                Ok(Vesting {
                    total: r.u128()?,
                    start_height: r.u64()?,
                    cliff_height: r.u64()?,
                    end_height: r.u64()?,
                })
            })?,
            immature: r.vec(1 << 20, 24, |r| Ok(Immature { mature_height: r.u64()?, amount: r.u128()? }))?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TokenInfo {
    pub symbol: String,
    pub name: String,
    pub decimals: u8,
    pub supply: u128,
    pub max_supply: Option<u128>,
    pub creator: Addr,
    pub mint_authority: Option<Addr>,
    pub admin: Option<Addr>,
    pub flags: u8,
    pub paused: bool,
    pub metadata_uri: String,
    pub created_height: u64,
}

impl Encode for TokenInfo {
    fn encode_to(&self, w: &mut Writer) {
        w.string(&self.symbol);
        w.string(&self.name);
        w.u8(self.decimals);
        w.u128(self.supply);
        w.opt(&self.max_supply, |w, v| w.u128(*v));
        w.fixed(&self.creator);
        w.opt(&self.mint_authority, |w, v| w.fixed(v));
        w.opt(&self.admin, |w, v| w.fixed(v));
        w.u8(self.flags);
        w.bool(self.paused);
        w.string(&self.metadata_uri);
        w.u64(self.created_height);
    }
}
impl Decode for TokenInfo {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(TokenInfo {
            symbol: r.string(MAX_SYMBOL_LEN)?,
            name: r.string(MAX_NAME_LEN)?,
            decimals: r.u8()?,
            supply: r.u128()?,
            max_supply: r.opt(|r| r.u128())?,
            creator: r.fixed()?,
            mint_authority: r.opt(|r| r.fixed())?,
            admin: r.opt(|r| r.fixed())?,
            flags: r.u8()?,
            paused: r.bool()?,
            metadata_uri: r.string(MAX_URI_LEN)?,
            created_height: r.u64()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct TokenBalance {
    pub amount: u128,
    pub frozen: bool,
}
impl Encode for TokenBalance {
    fn encode_to(&self, w: &mut Writer) {
        w.u128(self.amount);
        w.bool(self.frozen);
    }
}
impl Decode for TokenBalance {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(TokenBalance { amount: r.u128()?, frozen: r.bool()? })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Multisig {
    pub signers: Vec<Addr>,
    pub threshold: u8,
    pub next_proposal_id: u64,
}
impl Encode for Multisig {
    fn encode_to(&self, w: &mut Writer) {
        w.vec(&self.signers, |w, s| w.fixed(s));
        w.u8(self.threshold);
        w.u64(self.next_proposal_id);
    }
}
impl Decode for Multisig {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Multisig {
            signers: r.vec(MAX_MSIG_SIGNERS, 20, |r| r.fixed())?,
            threshold: r.u8()?,
            next_proposal_id: r.u64()?,
        })
    }
}

pub const PROP_PENDING: u8 = 0;
pub const PROP_EXECUTED: u8 = 1;
pub const PROP_FAILED: u8 = 2;
pub const PROP_EXPIRED: u8 = 3;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MsigProposal {
    pub proposer: Addr,
    pub inner: Action,
    pub approvals: Vec<Addr>,
    pub expiry_height: u64,
    pub status: u8,
    pub error_code: u16,
}
impl Encode for MsigProposal {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.proposer);
        self.inner.encode_to(w);
        w.vec(&self.approvals, |w, s| w.fixed(s));
        w.u64(self.expiry_height);
        w.u8(self.status);
        w.u16(self.error_code);
    }
}
impl Decode for MsigProposal {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(MsigProposal {
            proposer: r.fixed()?,
            inner: decode_action(r, 1)?,
            approvals: r.vec(MAX_MSIG_SIGNERS, 20, |r| r.fixed())?,
            expiry_height: r.u64()?,
            status: r.u8()?,
            error_code: r.u16()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Distribution {
    pub creator: Addr,
    pub asset: AssetId,
    pub total: u128,
    pub remaining: u128,
    pub merkle_root: Hash32,
    pub claim_deadline_height: u64,
    pub closed: bool,
    pub claims: u32,
}
impl Encode for Distribution {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.creator);
        self.asset.encode_to(w);
        w.u128(self.total);
        w.u128(self.remaining);
        w.fixed(&self.merkle_root);
        w.u64(self.claim_deadline_height);
        w.bool(self.closed);
        w.u32(self.claims);
    }
}
impl Decode for Distribution {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Distribution {
            creator: r.fixed()?,
            asset: AssetId::decode_from(r)?,
            total: r.u128()?,
            remaining: r.u128()?,
            merkle_root: r.fixed()?,
            claim_deadline_height: r.u64()?,
            closed: r.bool()?,
            claims: r.u32()?,
        })
    }
}

pub fn claim_leaf(index: u32, claimant: &Addr, amount: u128) -> Hash32 {
    let mut w = Writer::new();
    w.u32(index);
    w.fixed(claimant);
    w.u128(amount);
    hash_domain("AUREOM/CLAIM/v1", &w.finish())
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Validator {
    pub operator: Addr,
    pub consensus_pubkey: [u8; 32],
    pub moniker: String,
    pub bonded: u128,
    /// PoA: fixed power; PoS: unused (power derives from `bonded`).
    pub fixed_power: u64,
    pub jailed_until: u64,
    pub tombstoned: bool,
    pub missed_in_window: u32,
    pub window_start: u64,
    pub created_height: u64,
    pub removed: bool,
}
impl Encode for Validator {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.operator);
        w.fixed(&self.consensus_pubkey);
        w.string(&self.moniker);
        w.u128(self.bonded);
        w.u64(self.fixed_power);
        w.u64(self.jailed_until);
        w.bool(self.tombstoned);
        w.u32(self.missed_in_window);
        w.u64(self.window_start);
        w.u64(self.created_height);
        w.bool(self.removed);
    }
}
impl Decode for Validator {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Validator {
            operator: r.fixed()?,
            consensus_pubkey: r.fixed()?,
            moniker: r.string(MAX_NAME_LEN)?,
            bonded: r.u128()?,
            fixed_power: r.u64()?,
            jailed_until: r.u64()?,
            tombstoned: r.bool()?,
            missed_in_window: r.u32()?,
            window_start: r.u64()?,
            created_height: r.u64()?,
            removed: r.bool()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Unbonding {
    pub amount: u128,
    pub start_height: u64,
}
impl Encode for Unbonding {
    fn encode_to(&self, w: &mut Writer) {
        w.u128(self.amount);
        w.u64(self.start_height);
    }
}
impl Decode for Unbonding {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Unbonding { amount: r.u128()?, start_height: r.u64()? })
    }
}

/// Applied validator set: (consensus pubkey, power), sorted by pubkey.
#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct ValSet(pub Vec<([u8; 32], u64)>);
impl Encode for ValSet {
    fn encode_to(&self, w: &mut Writer) {
        w.vec(&self.0, |w, (k, p)| {
            w.fixed(k);
            w.u64(*p)
        });
    }
}
impl Decode for ValSet {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(ValSet(r.vec(10_000, 40, |r| Ok((r.fixed()?, r.u64()?)))?))
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct GovProposal {
    pub id: u64,
    pub proposer: Addr,
    pub kind: GovKind,
    pub created_height: u64,
    pub expiry_height: u64,
    pub approvals: Vec<Addr>,
    pub status: u8,
    pub executed_height: u64,
}
impl Encode for GovProposal {
    fn encode_to(&self, w: &mut Writer) {
        w.u64(self.id);
        w.fixed(&self.proposer);
        self.kind.encode_to(w);
        w.u64(self.created_height);
        w.u64(self.expiry_height);
        w.vec(&self.approvals, |w, a| w.fixed(a));
        w.u8(self.status);
        w.u64(self.executed_height);
    }
}
impl Decode for GovProposal {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(GovProposal {
            id: r.u64()?,
            proposer: r.fixed()?,
            kind: GovKind::decode_from(r)?,
            created_height: r.u64()?,
            expiry_height: r.u64()?,
            approvals: r.vec(10_000, 20, |r| r.fixed())?,
            status: r.u8()?,
            executed_height: r.u64()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct ScheduledUpgrade {
    pub name: String,
    pub protocol_version: u16,
    pub activation_height: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct GovState {
    pub next_id: u64,
    pub upgrades: Vec<ScheduledUpgrade>,
}
impl Encode for GovState {
    fn encode_to(&self, w: &mut Writer) {
        w.u64(self.next_id);
        w.vec(&self.upgrades, |w, u| {
            w.string(&u.name);
            w.u16(u.protocol_version);
            w.u64(u.activation_height);
        });
    }
}
impl Decode for GovState {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(GovState {
            next_id: r.u64()?,
            upgrades: r.vec(1024, 14, |r| {
                Ok(ScheduledUpgrade {
                    name: r.string(MAX_NAME_LEN)?,
                    protocol_version: r.u16()?,
                    activation_height: r.u64()?,
                })
            })?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct Supply {
    pub genesis: u128,
    pub minted: u128,
    pub burned: u128,
    pub total: u128,
}
impl Encode for Supply {
    fn encode_to(&self, w: &mut Writer) {
        w.u128(self.genesis);
        w.u128(self.minted);
        w.u128(self.burned);
        w.u128(self.total);
    }
}
impl Decode for Supply {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Supply { genesis: r.u128()?, minted: r.u128()?, burned: r.u128()?, total: r.u128()? })
    }
}

pub fn u128_value(v: u128) -> Vec<u8> {
    v.to_be_bytes().to_vec()
}
pub fn decode_u128(v: &[u8]) -> DResult<u128> {
    let mut r = Reader::new(v);
    let x = r.u128()?;
    r.end()?;
    Ok(x)
}
pub fn decode_u64(v: &[u8]) -> DResult<u64> {
    let mut r = Reader::new(v);
    let x = r.u64()?;
    r.end()?;
    Ok(x)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::crypto::test_keypair;

    fn sample() -> UnsignedTx {
        UnsignedTx {
            version: 1,
            chain_id: "aureom-dev-1".into(),
            nonce: 7,
            fee: 1000,
            expiry_height: 0,
            sender_pubkey: test_keypair("alice").public(),
            action: Action::Transfer { to: [9; 20], amount: 5 },
            memo: b"hi".to_vec(),
        }
    }

    #[test]
    fn tx_roundtrip_and_strict() {
        let s = sample().sign(&test_keypair("alice"));
        let bytes = s.encode();
        assert_eq!(SignedTx::decode(&bytes).unwrap(), s);
        let mut extra = bytes.clone();
        extra.push(0);
        assert!(SignedTx::decode(&extra).is_err());
        assert!(s.verify_signature());
    }

    #[test]
    fn signature_bound_to_chain_and_type() {
        let kp = test_keypair("alice");
        let s = sample().sign(&kp);
        let mut other_chain = s.clone();
        other_chain.tx.chain_id = "aureom-dev-2".into();
        assert!(!other_chain.verify_signature());
        let mut other_type = s.clone();
        other_type.tx.action = Action::TokenTransfer { token: [0; 20], to: [9; 20], amount: 5 };
        assert!(!other_type.verify_signature());
    }

    #[test]
    fn multisig_nesting_rejected() {
        let inner = Action::MultisigApprove { multisig: [1; 20], proposal_id: 0 };
        let a = Action::MultisigPropose { multisig: [1; 20], inner: Box::new(inner), expiry_height: 10 };
        assert!(Action::decode(&a.encode()).is_err());
    }

    #[test]
    fn vesting_boundaries() {
        let v = Vesting { total: 1000, start_height: 10, cliff_height: 20, end_height: 110 };
        assert_eq!(v.vested(19), 0);
        assert_eq!(v.vested(20), 100);
        assert_eq!(v.vested(60), 500);
        assert_eq!(v.vested(109), 990);
        assert_eq!(v.vested(110), 1000);
        let big = Vesting { total: u128::MAX, start_height: 0, cliff_height: 0, end_height: 3 };
        assert_eq!(big.vested(1), u128::MAX / 3);
    }
}
