//! In-memory sorted state with a Merkle commitment, write overlays and undo logs.

use crate::codec::{Decode, Encode};
use crate::crypto::{hash_domain, Addr, Hash32};
use crate::merkle;
use crate::types::*;
use std::collections::BTreeMap;

pub mod keys {
    use crate::crypto::{Addr, Hash32};
    pub fn genesis() -> Vec<u8> {
        vec![0x00]
    }
    pub fn account(a: &Addr) -> Vec<u8> {
        [&[0x01][..], a].concat()
    }
    pub fn token(t: &Addr) -> Vec<u8> {
        [&[0x02][..], t].concat()
    }
    pub fn token_balance(t: &Addr, a: &Addr) -> Vec<u8> {
        [&[0x03][..], t, a].concat()
    }
    pub fn multisig(m: &Addr) -> Vec<u8> {
        [&[0x04][..], m].concat()
    }
    pub fn msig_proposal(m: &Addr, id: u64) -> Vec<u8> {
        [&[0x05][..], m, &id.to_be_bytes()].concat()
    }
    pub fn distribution(d: &Hash32) -> Vec<u8> {
        [&[0x06][..], d].concat()
    }
    pub fn claimed(d: &Hash32, idx: u32) -> Vec<u8> {
        [&[0x07][..], d, &idx.to_be_bytes()].concat()
    }
    pub fn validator(op: &Addr) -> Vec<u8> {
        [&[0x10][..], op].concat()
    }
    pub fn consaddr(c: &Addr) -> Vec<u8> {
        [&[0x11][..], c].concat()
    }
    pub fn unbonding(h: u64, op: &Addr, seq: u64) -> Vec<u8> {
        [&[0x12][..], &h.to_be_bytes(), op, &seq.to_be_bytes()].concat()
    }
    pub fn valset() -> Vec<u8> {
        vec![0x13]
    }
    pub fn valcounters() -> Vec<u8> {
        vec![0x14]
    }
    pub fn valset_dirty() -> Vec<u8> {
        vec![0x15]
    }
    pub fn gov_proposal(id: u64) -> Vec<u8> {
        [&[0x20][..], &id.to_be_bytes()].concat()
    }
    pub fn gov_state() -> Vec<u8> {
        vec![0x21]
    }
    pub fn supply() -> Vec<u8> {
        vec![0x30]
    }
    pub fn mint_window(w: u64) -> Vec<u8> {
        [&[0x31][..], &w.to_be_bytes()].concat()
    }
}

pub type ChangeSet = BTreeMap<Vec<u8>, Option<Vec<u8>>>;
/// Undo log: previous values of every key a change set touched.
pub type Undo = Vec<(Vec<u8>, Option<Vec<u8>>)>;

pub fn state_leaf(k: &[u8], v: &[u8]) -> Hash32 {
    let mut d = Vec::with_capacity(k.len() + v.len() + 8);
    d.extend_from_slice(&(k.len() as u32).to_be_bytes());
    d.extend_from_slice(k);
    d.extend_from_slice(&(v.len() as u32).to_be_bytes());
    d.extend_from_slice(v);
    hash_domain("AUREOM/STATE/v1", &d)
}

#[derive(Clone, Default)]
pub struct State {
    map: BTreeMap<Vec<u8>, Vec<u8>>,
    /// merkle::leaf(state_leaf(k, v)) per key
    leaves: BTreeMap<Vec<u8>, Hash32>,
}

impl State {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn from_entries(entries: impl IntoIterator<Item = (Vec<u8>, Vec<u8>)>) -> Self {
        let mut s = State::new();
        for (k, v) in entries {
            s.leaves.insert(k.clone(), merkle::leaf(&state_leaf(&k, &v)));
            s.map.insert(k, v);
        }
        s
    }
    pub fn len(&self) -> usize {
        self.map.len()
    }
    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }
    pub fn get(&self, k: &[u8]) -> Option<&Vec<u8>> {
        self.map.get(k)
    }
    pub fn entries(&self) -> impl Iterator<Item = (&Vec<u8>, &Vec<u8>)> {
        self.map.iter()
    }
    pub fn scan_prefix<'a>(&'a self, prefix: &'a [u8]) -> impl Iterator<Item = (&'a Vec<u8>, &'a Vec<u8>)> + 'a {
        self.map.range(prefix.to_vec()..).take_while(move |(k, _)| k.starts_with(prefix))
    }
    pub fn root(&self) -> Hash32 {
        merkle::root_from_leaves(self.leaves.values().copied().collect())
    }
    /// Apply a change set; returns the undo log.
    pub fn apply(&mut self, cs: &ChangeSet) -> Undo {
        let mut undo = Vec::with_capacity(cs.len());
        for (k, v) in cs {
            let old = match v {
                Some(v) => {
                    self.leaves.insert(k.clone(), merkle::leaf(&state_leaf(k, v)));
                    self.map.insert(k.clone(), v.clone())
                }
                None => {
                    self.leaves.remove(k);
                    self.map.remove(k)
                }
            };
            undo.push((k.clone(), old));
        }
        undo
    }
    pub fn revert(&mut self, undo: &Undo) {
        for (k, old) in undo.iter().rev() {
            match old {
                Some(v) => {
                    self.leaves.insert(k.clone(), merkle::leaf(&state_leaf(k, v)));
                    self.map.insert(k.clone(), v.clone());
                }
                None => {
                    self.leaves.remove(k);
                    self.map.remove(k);
                }
            }
        }
    }
    pub fn overlay(&self) -> Overlay<'_> {
        Overlay { base: self, block: BTreeMap::new(), tx: BTreeMap::new() }
    }

    // typed reads
    pub fn account(&self, a: &Addr) -> Account {
        self.get(&keys::account(a)).map(|v| Account::decode(v).expect("valid state")).unwrap_or_default()
    }
    pub fn supply(&self) -> Supply {
        self.get(&keys::supply()).map(|v| Supply::decode(v).expect("valid state")).unwrap_or_default()
    }
}

pub fn encode_undo(u: &Undo) -> Vec<u8> {
    let mut w = crate::codec::Writer::new();
    w.vec(u, |w, (k, v)| {
        w.bytes(k);
        w.opt(v, |w, v| w.bytes(v));
    });
    w.finish()
}
pub fn decode_undo(b: &[u8]) -> crate::codec::DResult<Undo> {
    let mut r = crate::codec::Reader::new(b);
    let u = r.vec(usize::MAX, 5, |r| Ok((r.bytes(1 << 20)?, r.opt(|r| r.bytes(1 << 24))?)))?;
    r.end()?;
    Ok(u)
}
pub fn encode_changes(cs: &ChangeSet) -> Vec<u8> {
    let mut w = crate::codec::Writer::new();
    let v: Vec<_> = cs.iter().collect();
    w.vec(&v, |w, (k, v)| {
        w.bytes(k);
        w.opt(v, |w, v| w.bytes(v));
    });
    w.finish()
}

/// Two-level write overlay: `tx` writes can be committed into `block` writes or discarded.
pub struct Overlay<'a> {
    base: &'a State,
    block: ChangeSet,
    tx: ChangeSet,
}

impl<'a> Overlay<'a> {
    pub fn get(&self, k: &[u8]) -> Option<Vec<u8>> {
        if let Some(v) = self.tx.get(k) {
            return v.clone();
        }
        if let Some(v) = self.block.get(k) {
            return v.clone();
        }
        self.base.get(k).cloned()
    }
    pub fn put(&mut self, k: Vec<u8>, v: Vec<u8>) {
        self.tx.insert(k, Some(v));
    }
    pub fn delete(&mut self, k: Vec<u8>) {
        self.tx.insert(k, None);
    }
    pub fn commit_tx(&mut self) {
        let tx = std::mem::take(&mut self.tx);
        self.block.extend(tx);
    }
    pub fn rollback_tx(&mut self) {
        self.tx.clear();
    }
    pub fn tx_savepoint(&self) -> ChangeSet {
        self.tx.clone()
    }
    pub fn tx_restore(&mut self, sp: ChangeSet) {
        self.tx = sp;
    }
    pub fn into_changes(mut self) -> ChangeSet {
        self.commit_tx();
        // drop no-op writes so change sets are minimal and deterministic
        let base = self.base;
        self.block.into_iter().filter(|(k, v)| base.get(k) != v.as_ref()).collect()
    }
    /// Merged prefix scan over base, block and tx layers (sorted by key).
    pub fn scan_prefix(&self, prefix: &[u8]) -> Vec<(Vec<u8>, Vec<u8>)> {
        let mut m: BTreeMap<Vec<u8>, Option<Vec<u8>>> =
            self.base.scan_prefix(prefix).map(|(k, v)| (k.clone(), Some(v.clone()))).collect();
        for layer in [&self.block, &self.tx] {
            for (k, v) in layer.range(prefix.to_vec()..).take_while(|(k, _)| k.starts_with(prefix)) {
                m.insert(k.clone(), v.clone());
            }
        }
        m.into_iter().filter_map(|(k, v)| v.map(|v| (k, v))).collect()
    }

    fn typed<T: Decode>(&self, k: &[u8]) -> Option<T> {
        self.get(k).map(|v| T::decode(&v).expect("state values are canonical"))
    }

    pub fn account(&self, a: &Addr) -> Account {
        self.typed(&keys::account(a)).unwrap_or_default()
    }
    pub fn put_account(&mut self, a: &Addr, acct: &Account) {
        if acct.is_empty() {
            self.delete(keys::account(a))
        } else {
            self.put(keys::account(a), acct.encode())
        }
    }
    pub fn token(&self, t: &Addr) -> Option<TokenInfo> {
        self.typed(&keys::token(t))
    }
    pub fn put_token(&mut self, t: &Addr, info: &TokenInfo) {
        self.put(keys::token(t), info.encode())
    }
    pub fn token_balance(&self, t: &Addr, a: &Addr) -> TokenBalance {
        self.typed(&keys::token_balance(t, a)).unwrap_or_default()
    }
    pub fn put_token_balance(&mut self, t: &Addr, a: &Addr, b: &TokenBalance) {
        if b.amount == 0 && !b.frozen {
            self.delete(keys::token_balance(t, a))
        } else {
            self.put(keys::token_balance(t, a), b.encode())
        }
    }
    pub fn multisig(&self, m: &Addr) -> Option<Multisig> {
        self.typed(&keys::multisig(m))
    }
    pub fn put_multisig(&mut self, m: &Addr, ms: &Multisig) {
        self.put(keys::multisig(m), ms.encode())
    }
    pub fn msig_proposal(&self, m: &Addr, id: u64) -> Option<MsigProposal> {
        self.typed(&keys::msig_proposal(m, id))
    }
    pub fn put_msig_proposal(&mut self, m: &Addr, id: u64, p: &MsigProposal) {
        self.put(keys::msig_proposal(m, id), p.encode())
    }
    pub fn distribution(&self, d: &Hash32) -> Option<Distribution> {
        self.typed(&keys::distribution(d))
    }
    pub fn put_distribution(&mut self, d: &Hash32, x: &Distribution) {
        self.put(keys::distribution(d), x.encode())
    }
    pub fn validator(&self, op: &Addr) -> Option<Validator> {
        self.typed(&keys::validator(op))
    }
    pub fn put_validator(&mut self, v: &Validator) {
        self.put(keys::validator(&v.operator), v.encode())
    }
    pub fn validators(&self) -> Vec<Validator> {
        self.scan_prefix(&[0x10]).into_iter().map(|(_, v)| Validator::decode(&v).expect("canonical")).collect()
    }
    pub fn operator_of_consaddr(&self, c: &Addr) -> Option<Addr> {
        self.get(&keys::consaddr(c)).map(|v| v.try_into().expect("20 bytes"))
    }
    pub fn valset(&self) -> ValSet {
        self.typed(&keys::valset()).unwrap_or_default()
    }
    pub fn gov_state(&self) -> GovState {
        self.typed(&keys::gov_state()).unwrap_or_default()
    }
    pub fn put_gov_state(&mut self, g: &GovState) {
        self.put(keys::gov_state(), g.encode())
    }
    pub fn gov_proposal(&self, id: u64) -> Option<GovProposal> {
        self.typed(&keys::gov_proposal(id))
    }
    pub fn put_gov_proposal(&mut self, p: &GovProposal) {
        self.put(keys::gov_proposal(p.id), p.encode())
    }
    pub fn supply(&self) -> Supply {
        self.typed(&keys::supply()).unwrap_or_default()
    }
    pub fn put_supply(&mut self, s: &Supply) {
        self.put(keys::supply(), s.encode())
    }
    pub fn mark_valset_dirty(&mut self) {
        self.put(keys::valset_dirty(), vec![1])
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn apply_revert_restores_root() {
        let mut s = State::from_entries(vec![(vec![1], vec![1]), (vec![2], vec![2])]);
        let r0 = s.root();
        let mut cs = ChangeSet::new();
        cs.insert(vec![1], None);
        cs.insert(vec![3], Some(vec![3]));
        cs.insert(vec![2], Some(vec![9]));
        let undo = s.apply(&cs);
        assert_ne!(s.root(), r0);
        s.revert(&undo);
        assert_eq!(s.root(), r0);
    }

    #[test]
    fn overlay_layers() {
        let s = State::from_entries(vec![(vec![1, 1], vec![1]), (vec![1, 2], vec![2])]);
        let mut o = s.overlay();
        o.put(vec![1, 3], vec![3]);
        o.commit_tx();
        o.delete(vec![1, 1]);
        assert_eq!(o.scan_prefix(&[1]).len(), 2);
        o.rollback_tx();
        assert_eq!(o.scan_prefix(&[1]).len(), 3);
        let cs = o.into_changes();
        assert_eq!(cs.len(), 1);
    }
}
