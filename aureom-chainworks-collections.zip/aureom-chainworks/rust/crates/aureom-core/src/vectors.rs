//! Cross-implementation test vectors (PROTOCOL.md section 15). Deterministic: uses
//! labelled test keys only. Regenerate with `aureom-cli vectors --out test-vectors/`.

use crate::codec::Encode;
use crate::crypto::{address_from_pubkey, bech32_encode, hash_domain, test_keypair};
use crate::exec::{self, BlockCtx};
use crate::genesis::{genesis_hash_of_value, tests::dev_genesis, ChainParams};
use crate::merkle;
use crate::pow;
use crate::types::*;
use serde_json::{json, Value};

pub fn addresses() -> Value {
    let v: Vec<Value> = ["alice", "bob", "carol", "val0"]
        .iter()
        .map(|l| {
            let kp = test_keypair(l);
            let a = address_from_pubkey(&kp.public());
            json!({"label": l, "public_test_seed": hex::encode(kp.seed()), "pubkey": hex::encode(kp.public()),
                   "address_bytes": hex::encode(a), "address": bech32_encode("aurd", &a)})
        })
        .collect();
    json!({"description": "address = bech32m(hrp, H('AUREOM/ADDR/v1', 0x01||pubkey)[0..20]); public_test_seed = H('AUREOM/TEST-KEY/v1', label): PUBLIC test keys, never use for value", "hrp": "aurd", "cases": v})
}

pub fn hashing() -> Value {
    let items: Vec<Vec<u8>> = (0..5u8).map(|i| vec![i; 4]).collect();
    let roots: Vec<Value> = (0..=5usize)
        .map(|n| json!({"items": items[..n].iter().map(hex::encode).collect::<Vec<_>>(), "root": hex::encode(merkle::root(&items[..n]))}))
        .collect();
    let proof = merkle::proof(&items, 4);
    json!({
        "domain_hash": [
            {"domain": "AUREOM/TXID/v1", "data": "", "hash": hex::encode(hash_domain("AUREOM/TXID/v1", b""))},
            {"domain": "AUREOM/GENESIS/v1", "data": hex::encode(b"{}"), "hash": hex::encode(hash_domain("AUREOM/GENESIS/v1", b"{}"))},
        ],
        "merkle_roots": roots,
        "merkle_proof": {"items": items.iter().map(hex::encode).collect::<Vec<_>>(), "index": 4,
            "proof": proof.iter().map(|s| json!({"side": s.side, "sibling": hex::encode(s.sibling)})).collect::<Vec<_>>()},
        "claim_leaf": {"index": 3, "address": hex::encode(test_keypair("alice").address()), "amount": "1000",
            "leaf": hex::encode(claim_leaf(3, &test_keypair("alice").address(), 1000))},
        "state_leaf": {"key": "01aa", "value": "bbcc", "leaf": hex::encode(crate::state::state_leaf(&[1, 0xaa], &[0xbb, 0xcc]))},
    })
}

fn sample_actions(p: &ChainParams) -> Vec<Action> {
    let bob = test_keypair("bob").address();
    vec![
        Action::Transfer { to: bob, amount: 1_234_567 },
        Action::VestedTransfer { to: bob, amount: 1000, start_height: 5, cliff_height: 10, end_height: 100 },
        Action::NativeBurn { amount: 42 },
        Action::TokenCreate {
            symbol: "GLD".into(),
            name: "Demo Gold Token".into(),
            decimals: 2,
            initial_supply: 100_000,
            initial_recipient: bob,
            max_supply: Some(1_000_000),
            mint_authority: Some(test_keypair("alice").address()),
            admin: None,
            flags: 0,
            metadata_uri: "".into(),
        },
        Action::TokenTransfer { token: exec::token_id(&test_keypair("alice").address(), 0), to: bob, amount: 5 },
        Action::MultisigApprove { multisig: p.treasury_addrs[0], proposal_id: 3 },
    ]
}

pub fn transactions() -> Value {
    let p = ChainParams::from_value(&dev_genesis("pow")).unwrap();
    let kp = test_keypair("alice");
    let cases: Vec<Value> = sample_actions(&p)
        .into_iter()
        .enumerate()
        .map(|(i, a)| {
            let u = UnsignedTx {
                version: 1,
                chain_id: p.doc.chain_id.clone(),
                nonce: i as u64,
                fee: 5000,
                expiry_height: if i % 2 == 0 { 0 } else { 1000 },
                sender_pubkey: kp.public(),
                action: a,
                memo: if i == 0 { b"vector".to_vec() } else { vec![] },
            };
            let json = crate::json::unsigned_tx_json(&p, &u);
            let signed = u.clone().sign(&kp);
            json!({
                "tx_json": json,
                "unsigned_hex": hex::encode(u.encode()),
                "signing_message_hex": hex::encode(u.signing_message()),
                "txid": hex::encode(u.txid()),
                "signature": hex::encode(signed.signature),
                "signed_hex": hex::encode(signed.encode()),
                "signed_size": signed.encode().len(),
                "min_fee": exec::min_fee(&p, signed.encode().len()),
            })
        })
        .collect();
    let u = UnsignedTx {
        version: 1,
        chain_id: "another-chain".into(),
        nonce: 0,
        fee: 5000,
        expiry_height: 0,
        sender_pubkey: kp.public(),
        action: Action::Transfer { to: [7; 20], amount: 1 },
        memo: vec![],
    };
    json!({
        "description": "Ed25519 over signing_message; txid = H('AUREOM/TXID/v1', unsigned). Signer seed: addresses.json label 'alice'.",
        "chain_id": p.doc.chain_id,
        "cases": cases,
        "negative": [{
            "why": "signature made for chain 'another-chain' must not verify after changing chain_id to the vector chain",
            "signed_hex": hex::encode(u.sign(&kp).encode())
        }]
    })
}

/// Genesis hash + genesis state root + one PoW block of transfers with expected results.
pub fn state_transition() -> Value {
    let g = dev_genesis("pow");
    let p = ChainParams::from_value(&g).unwrap();
    let mut st = p.genesis_state();
    let genesis_root = st.root();
    let alice = test_keypair("alice");
    let bob = test_keypair("bob");
    let carol = test_keypair("carol").address();
    let mk = |kp: &crate::crypto::Keypair, nonce, to, amount| {
        UnsignedTx { version: 1, chain_id: p.doc.chain_id.clone(), nonce, fee: 2000, expiry_height: 0, sender_pubkey: kp.public(), action: Action::Transfer { to, amount }, memo: vec![] }.sign(kp)
    };
    let txs = vec![
        mk(&alice, 0, bob.address(), 1_000_000),
        mk(&alice, 1, carol, 250),
        mk(&bob, 0, carol, 999_999_999_999_999), // fails: insufficient funds (fee still charged)
    ];
    let miner = test_keypair("miner").address();
    let mut ctx = BlockCtx::new(1, Some(miner));
    let mut ov = st.overlay();
    let receipts = exec::execute_txs(&mut ov, &p, &mut ctx, &txs).unwrap();
    exec::pow_coinbase(&mut ov, &p, &mut ctx, &miner);
    let cs = ov.into_changes();
    st.apply(&cs);
    let post: Vec<Value> = st.entries().map(|(k, v)| json!([hex::encode(k), hex::encode(v)])).collect();
    let gb = pow::genesis_block(&p, genesis_root);
    json!({
        "description": "Execute txs at height 1 with miner; PoW profile; see PROTOCOL.md 5.5, 10.6",
        "genesis": g,
        "genesis_hash": hex::encode(genesis_hash_of_value(&g).unwrap()),
        "genesis_jcs": crate::genesis::jcs(&g).unwrap(),
        "genesis_state_root": hex::encode(genesis_root),
        "genesis_block": {"header_hex": hex::encode(gb.header.encode()), "block_id": hex::encode(gb.header.id()), "pow_hash": hex::encode(gb.header.pow_hash())},
        "height": 1,
        "miner": hex::encode(miner),
        "txs": txs.iter().map(|t| hex::encode(t.encode())).collect::<Vec<_>>(),
        "tx_root": hex::encode(tx_root(&txs)),
        "receipts": receipts.iter().map(|r| hex::encode(r.encode())).collect::<Vec<_>>(),
        "receipt_root": hex::encode(receipt_root(&receipts)),
        "expected_status": receipts.iter().map(|r| r.status).collect::<Vec<_>>(),
        "post_state_root": hex::encode(st.root()),
        "post_state": post,
    })
}

pub fn all() -> Vec<(&'static str, Value)> {
    vec![("addresses.json", addresses()), ("hashing.json", hashing()), ("transactions.json", transactions()), ("state_transition.json", state_transition())]
}
