//! AUREOM COLLECTIONS — native NFT module (docs/COLLECTIONS-PROTOCOL.md).
//!
//! A module of the Chainworks state machine, not a smart contract: there is no VM and
//! this module is **not** ERC-721 or ERC-1155 compatible (no EVM, no ABI, no Solidity
//! interface). Ownership is authoritative only in this ledger's state; indexers and
//! application databases cache it.
//!
//! Enabled per network by the genesis field `modules.collections`. Action tags 60–79.

use crate::codec::*;
use crate::crypto::{hash_domain, Addr, Hash32};
use crate::exec::{err::*, BlockCtx};
use crate::genesis::ChainParams;
use crate::merkle::{self, ProofStep};
use crate::state::Overlay;
use crate::types::{AssetId, Event, TokenBalance};

pub const MAX_SLUG_LEN: usize = 32;
pub const MAX_NFT_URI_LEN: usize = 128; // event attribute values are <= 128 bytes
pub const MAX_RIGHTS_HOLDER_LEN: usize = 64;
pub const MAX_BATCH_MINT: usize = 32;
pub const MAX_ROYALTY_BPS: u16 = 2500;
pub const MAX_MARKETPLACE_FEE_BPS: u32 = 1000;
pub const MAX_LISTING_TTL_BLOCKS: u64 = 1_000_000;

pub const POLICY_MUTABLE: u8 = 1;
pub const POLICY_FREEZABLE: u8 = 2;
pub const POLICY_IMMUTABLE: u8 = 3;

pub const TRANSFER_FREE: u8 = 0;
pub const TRANSFER_NONE: u8 = 1;

/// Administrative capability flags; each must be opted into at creation and requires `admin`.
pub const CFLAG_PAUSABLE: u8 = 1;
pub const CFLAG_FORCED_TRANSFER: u8 = 2;
/// Holder right (not an admin power): owners may burn their own tokens.
pub const CFLAG_OWNER_BURN: u8 = 4;
pub const CFLAG_ADMIN_POWERS: u8 = CFLAG_PAUSABLE | CFLAG_FORCED_TRANSFER;

pub const ROLE_ADMIN: u8 = 1;
pub const ROLE_MINT_AUTHORITY: u8 = 2;
pub const ROLE_METADATA_ADMIN: u8 = 3;
pub const ROLE_ROYALTY_RECIPIENT: u8 = 4;

pub const LISTING_ACTIVE: u8 = 0;
pub const LISTING_SOLD: u8 = 1;
pub const LISTING_CANCELLED: u8 = 2;
pub const LISTING_INVALIDATED: u8 = 3;
/// An active listing past its expiry that was superseded by a new listing of the token.
pub const LISTING_EXPIRED: u8 = 4;

pub mod keys {
    use crate::crypto::{Addr, Hash32};
    pub fn collection(c: &Addr) -> Vec<u8> {
        [&[0x40][..], c].concat()
    }
    pub fn slug(s: &str) -> Vec<u8> {
        [&[0x41][..], s.as_bytes()].concat()
    }
    pub fn token(c: &Addr, id: u64) -> Vec<u8> {
        [&[0x42][..], c, &id.to_be_bytes()].concat()
    }
    pub fn tokens_of(c: &Addr) -> Vec<u8> {
        [&[0x42][..], c].concat()
    }
    pub fn revision(c: &Addr, id: u64, rev: u32) -> Vec<u8> {
        [&[0x43][..], c, &id.to_be_bytes(), &rev.to_be_bytes()].concat()
    }
    pub fn operator(c: &Addr, owner: &Addr, op: &Addr) -> Vec<u8> {
        [&[0x44][..], c, owner, op].concat()
    }
    pub fn authority_log(c: &Addr, seq: u32) -> Vec<u8> {
        [&[0x46][..], c, &seq.to_be_bytes()].concat()
    }
    pub fn listing(l: &Hash32) -> Vec<u8> {
        [&[0x47][..], l].concat()
    }
    pub fn active_listing(c: &Addr, id: u64) -> Vec<u8> {
        [&[0x48][..], c, &id.to_be_bytes()].concat()
    }
    pub fn drop(d: &Hash32) -> Vec<u8> {
        [&[0x49][..], d].concat()
    }
    pub fn drop_claimed(d: &Hash32, idx: u32) -> Vec<u8> {
        [&[0x4A][..], d, &idx.to_be_bytes()].concat()
    }
}

// ------------------------------------------------------------------ value types

/// On-chain reference to an off-chain metadata document. `hash` = SHA-256 of the exact
/// document bytes (canonical JSON, see docs/COLLECTIONS.md). The document in turn names
/// media files by their own SHA-256. Nothing here proves the document is still hosted.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MetadataRef {
    pub uri: String,
    pub hash: Hash32,
}

impl MetadataRef {
    fn enc(&self, w: &mut Writer) {
        w.string(&self.uri);
        w.fixed(&self.hash);
    }
    fn dec(r: &mut Reader) -> DResult<Self> {
        Ok(MetadataRef { uri: r.string(MAX_NFT_URI_LEN)?, hash: r.fixed()? })
    }
    fn valid(&self) -> bool {
        !self.uri.is_empty() && printable(&self.uri, MAX_NFT_URI_LEN) && self.hash != [0; 32]
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Royalty {
    pub recipient: Addr,
    pub bps: u16,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CollectionSpec {
    pub slug: String,
    pub name: String,
    pub collection_metadata: MetadataRef,
    pub max_supply: Option<u64>,
    pub mint_authority: Option<Addr>,
    pub metadata_policy: u8,
    pub metadata_admin: Option<Addr>,
    pub admin: Option<Addr>,
    pub flags: u8,
    pub transfer_policy: u8,
    pub royalty: Option<Royalty>,
    pub rights_holder: String,
    pub rights: MetadataRef,
}

impl CollectionSpec {
    fn enc(&self, w: &mut Writer) {
        w.string(&self.slug);
        w.string(&self.name);
        self.collection_metadata.enc(w);
        w.opt(&self.max_supply, |w, v| w.u64(*v));
        w.opt(&self.mint_authority, |w, v| w.fixed(v));
        w.u8(self.metadata_policy);
        w.opt(&self.metadata_admin, |w, v| w.fixed(v));
        w.opt(&self.admin, |w, v| w.fixed(v));
        w.u8(self.flags);
        w.u8(self.transfer_policy);
        w.opt(&self.royalty, |w, v| {
            w.fixed(&v.recipient);
            w.u16(v.bps)
        });
        w.string(&self.rights_holder);
        self.rights.enc(w);
    }
    fn dec(r: &mut Reader) -> DResult<Self> {
        Ok(CollectionSpec {
            slug: r.string(MAX_SLUG_LEN)?,
            name: r.string(crate::types::MAX_NAME_LEN)?,
            collection_metadata: MetadataRef::dec(r)?,
            max_supply: r.opt(|r| r.u64())?,
            mint_authority: r.opt(|r| r.fixed())?,
            metadata_policy: r.u8()?,
            metadata_admin: r.opt(|r| r.fixed())?,
            admin: r.opt(|r| r.fixed())?,
            flags: r.u8()?,
            transfer_policy: r.u8()?,
            royalty: r.opt(|r| Ok(Royalty { recipient: r.fixed()?, bps: r.u16()? }))?,
            rights_holder: r.string(MAX_RIGHTS_HOLDER_LEN)?,
            rights: MetadataRef::dec(r)?,
        })
    }
}

/// Collection state. `creator` keeps no power after creation unless it also holds a role.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Collection {
    pub spec: CollectionSpec,
    pub creator: Addr,
    pub created_height: u64,
    pub minted: u64,
    pub burned: u64,
    pub paused: bool,
    /// Policy 2 only: every token's metadata (present and future) is frozen.
    pub frozen_all: bool,
    pub frozen_height: u64,
    pub authority_changes: u32,
}

impl Encode for Collection {
    fn encode_to(&self, w: &mut Writer) {
        self.spec.enc(w);
        w.fixed(&self.creator);
        w.u64(self.created_height);
        w.u64(self.minted);
        w.u64(self.burned);
        w.bool(self.paused);
        w.bool(self.frozen_all);
        w.u64(self.frozen_height);
        w.u32(self.authority_changes);
    }
}
impl Decode for Collection {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Collection {
            spec: CollectionSpec::dec(r)?,
            creator: r.fixed()?,
            created_height: r.u64()?,
            minted: r.u64()?,
            burned: r.u64()?,
            paused: r.bool()?,
            frozen_all: r.bool()?,
            frozen_height: r.u64()?,
            authority_changes: r.u32()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct NftRecord {
    pub owner: Addr,
    pub approved: Option<Addr>,
    pub approval_expiry: u64,
    pub metadata: MetadataRef,
    pub revision: u32,
    pub frozen: bool,
    pub minted_height: u64,
    pub minted_by: Addr,
    pub burned: bool,
    pub transfers: u32,
    pub last_change_height: u64,
}

impl Encode for NftRecord {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.owner);
        w.opt(&self.approved, |w, v| w.fixed(v));
        w.u64(self.approval_expiry);
        self.metadata.enc(w);
        w.u32(self.revision);
        w.bool(self.frozen);
        w.u64(self.minted_height);
        w.fixed(&self.minted_by);
        w.bool(self.burned);
        w.u32(self.transfers);
        w.u64(self.last_change_height);
    }
}
impl Decode for NftRecord {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(NftRecord {
            owner: r.fixed()?,
            approved: r.opt(|r| r.fixed())?,
            approval_expiry: r.u64()?,
            metadata: MetadataRef::dec(r)?,
            revision: r.u32()?,
            frozen: r.bool()?,
            minted_height: r.u64()?,
            minted_by: r.fixed()?,
            burned: r.bool()?,
            transfers: r.u32()?,
            last_change_height: r.u64()?,
        })
    }
}

impl NftRecord {
    pub fn approval_active(&self, h: u64) -> Option<Addr> {
        match self.approved {
            Some(a) if self.approval_expiry == 0 || h <= self.approval_expiry => Some(a),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MetadataRevision {
    pub metadata: MetadataRef,
    pub height: u64,
    pub by: Addr,
}
impl Encode for MetadataRevision {
    fn encode_to(&self, w: &mut Writer) {
        self.metadata.enc(w);
        w.u64(self.height);
        w.fixed(&self.by);
    }
}
impl Decode for MetadataRevision {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(MetadataRevision { metadata: MetadataRef::dec(r)?, height: r.u64()?, by: r.fixed()? })
    }
}

/// Recorded authority change (role reassignment, renunciation, freeze-driven removal).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AuthorityChange {
    pub role: u8,
    pub old: Option<Addr>,
    pub new: Option<Addr>,
    pub height: u64,
    pub by: Addr,
}
impl Encode for AuthorityChange {
    fn encode_to(&self, w: &mut Writer) {
        w.u8(self.role);
        w.opt(&self.old, |w, v| w.fixed(v));
        w.opt(&self.new, |w, v| w.fixed(v));
        w.u64(self.height);
        w.fixed(&self.by);
    }
}
impl Decode for AuthorityChange {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(AuthorityChange { role: r.u8()?, old: r.opt(|r| r.fixed())?, new: r.opt(|r| r.fixed())?, height: r.u64()?, by: r.fixed()? })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Listing {
    pub seller: Addr,
    pub collection: Addr,
    pub token_id: u64,
    pub price: u128,
    pub currency: AssetId,
    pub expiry_height: u64,
    pub created_height: u64,
    pub status: u8,
    pub buyer: Option<Addr>,
    pub closed_height: u64,
    pub royalty_paid: u128,
    pub royalty_recipient: Option<Addr>,
    pub platform_fee_paid: u128,
    pub seller_proceeds: u128,
}
impl Encode for Listing {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.seller);
        w.fixed(&self.collection);
        w.u64(self.token_id);
        w.u128(self.price);
        self.currency.encode_to(w);
        w.u64(self.expiry_height);
        w.u64(self.created_height);
        w.u8(self.status);
        w.opt(&self.buyer, |w, v| w.fixed(v));
        w.u64(self.closed_height);
        w.u128(self.royalty_paid);
        w.opt(&self.royalty_recipient, |w, v| w.fixed(v));
        w.u128(self.platform_fee_paid);
        w.u128(self.seller_proceeds);
    }
}
impl Decode for Listing {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Listing {
            seller: r.fixed()?,
            collection: r.fixed()?,
            token_id: r.u64()?,
            price: r.u128()?,
            currency: AssetId::decode_from(r)?,
            expiry_height: r.u64()?,
            created_height: r.u64()?,
            status: r.u8()?,
            buyer: r.opt(|r| r.fixed())?,
            closed_height: r.u64()?,
            royalty_paid: r.u128()?,
            royalty_recipient: r.opt(|r| r.fixed())?,
            platform_fee_paid: r.u128()?,
            seller_proceeds: r.u128()?,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Drop {
    pub collection: Addr,
    pub creator: Addr,
    pub merkle_root: Hash32,
    pub claim_deadline_height: u64,
    pub max_claims: u32,
    pub claims: u32,
}
impl Encode for Drop {
    fn encode_to(&self, w: &mut Writer) {
        w.fixed(&self.collection);
        w.fixed(&self.creator);
        w.fixed(&self.merkle_root);
        w.u64(self.claim_deadline_height);
        w.u32(self.max_claims);
        w.u32(self.claims);
    }
}
impl Decode for Drop {
    fn decode_from(r: &mut Reader) -> DResult<Self> {
        Ok(Drop { collection: r.fixed()?, creator: r.fixed()?, merkle_root: r.fixed()?, claim_deadline_height: r.u64()?, max_claims: r.u32()?, claims: r.u32()? })
    }
}

// ------------------------------------------------------------------ actions

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MintItem {
    pub token_id: u64,
    pub to: Addr,
    pub metadata: MetadataRef,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FreezeScope {
    Token(u64),
    Collection,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum NftAction {
    CollectionCreate(CollectionSpec),
    Mint { collection: Addr, item: MintItem },
    MintBatch { collection: Addr, items: Vec<MintItem> },
    Transfer { collection: Addr, token_id: u64, to: Addr },
    Approve { collection: Addr, token_id: u64, approved: Option<Addr>, expiry_height: u64 },
    SetOperator { collection: Addr, operator: Addr, approved: bool, expiry_height: u64 },
    Burn { collection: Addr, token_id: u64 },
    UpdateMetadata { collection: Addr, token_id: u64, metadata: MetadataRef, expected_revision: u32 },
    /// `expected` = current metadata hash (token scope) or `metadata_root` (collection scope):
    /// the signer commits to exactly what becomes frozen.
    FreezeMetadata { collection: Addr, scope: FreezeScope, expected: Hash32 },
    SetPaused { collection: Addr, paused: bool },
    SetRole { collection: Addr, role: u8, new: Option<Addr> },
    ForceTransfer { collection: Addr, token_id: u64, to: Addr, reason_hash: Hash32 },
    ListingCreate { collection: Addr, token_id: u64, price: u128, currency: AssetId, expiry_height: u64 },
    ListingCancel { listing_id: Hash32 },
    /// Buyer commits to the exact price and currency reviewed before signing.
    ListingBuy { listing_id: Hash32, price: u128, currency: AssetId },
    DropCreate { collection: Addr, merkle_root: Hash32, claim_deadline_height: u64, max_claims: u32 },
    DropClaim { drop_id: Hash32, index: u32, item_token_id: u64, metadata: MetadataRef, proof: Vec<ProofStep> },
}

impl NftAction {
    pub fn tag(&self) -> u8 {
        use NftAction::*;
        match self {
            CollectionCreate(_) => 60,
            Mint { .. } => 61,
            MintBatch { .. } => 62,
            Transfer { .. } => 63,
            Approve { .. } => 64,
            SetOperator { .. } => 65,
            Burn { .. } => 66,
            UpdateMetadata { .. } => 67,
            FreezeMetadata { .. } => 68,
            SetPaused { .. } => 69,
            SetRole { .. } => 70,
            ForceTransfer { .. } => 71,
            ListingCreate { .. } => 72,
            ListingCancel { .. } => 73,
            ListingBuy { .. } => 74,
            DropCreate { .. } => 75,
            DropClaim { .. } => 76,
        }
    }
    pub fn type_name(&self) -> &'static str {
        use NftAction::*;
        match self {
            CollectionCreate(_) => "nft_collection_create",
            Mint { .. } => "nft_mint",
            MintBatch { .. } => "nft_mint_batch",
            Transfer { .. } => "nft_transfer",
            Approve { .. } => "nft_approve",
            SetOperator { .. } => "nft_set_operator",
            Burn { .. } => "nft_burn",
            UpdateMetadata { .. } => "nft_update_metadata",
            FreezeMetadata { .. } => "nft_freeze_metadata",
            SetPaused { .. } => "nft_set_paused",
            SetRole { .. } => "nft_set_role",
            ForceTransfer { .. } => "nft_force_transfer",
            ListingCreate { .. } => "nft_listing_create",
            ListingCancel { .. } => "nft_listing_cancel",
            ListingBuy { .. } => "nft_listing_buy",
            DropCreate { .. } => "nft_drop_create",
            DropClaim { .. } => "nft_drop_claim",
        }
    }
    pub fn is_marketplace(&self) -> bool {
        matches!(self.tag(), 72..=74)
    }
    /// Collection-administration actions a multisig may execute.
    pub fn allowed_in_multisig(&self) -> bool {
        matches!(self.tag(), 61 | 62 | 67 | 68 | 69 | 70 | 71 | 75)
    }

    pub fn encode_body(&self, w: &mut Writer) {
        use NftAction::*;
        let item = |w: &mut Writer, i: &MintItem| {
            w.u64(i.token_id);
            w.fixed(&i.to);
            i.metadata.enc(w);
        };
        match self {
            CollectionCreate(s) => s.enc(w),
            Mint { collection, item: i } => {
                w.fixed(collection);
                item(w, i)
            }
            MintBatch { collection, items } => {
                w.fixed(collection);
                w.vec(items, |w, i| item(w, i))
            }
            Transfer { collection, token_id, to } => {
                w.fixed(collection);
                w.u64(*token_id);
                w.fixed(to)
            }
            Approve { collection, token_id, approved, expiry_height } => {
                w.fixed(collection);
                w.u64(*token_id);
                w.opt(approved, |w, v| w.fixed(v));
                w.u64(*expiry_height)
            }
            SetOperator { collection, operator, approved, expiry_height } => {
                w.fixed(collection);
                w.fixed(operator);
                w.bool(*approved);
                w.u64(*expiry_height)
            }
            Burn { collection, token_id } => {
                w.fixed(collection);
                w.u64(*token_id)
            }
            UpdateMetadata { collection, token_id, metadata, expected_revision } => {
                w.fixed(collection);
                w.u64(*token_id);
                metadata.enc(w);
                w.u32(*expected_revision)
            }
            FreezeMetadata { collection, scope, expected } => {
                w.fixed(collection);
                match scope {
                    FreezeScope::Token(t) => {
                        w.u8(1);
                        w.u64(*t)
                    }
                    FreezeScope::Collection => w.u8(2),
                }
                w.fixed(expected)
            }
            SetPaused { collection, paused } => {
                w.fixed(collection);
                w.bool(*paused)
            }
            SetRole { collection, role, new } => {
                w.fixed(collection);
                w.u8(*role);
                w.opt(new, |w, v| w.fixed(v))
            }
            ForceTransfer { collection, token_id, to, reason_hash } => {
                w.fixed(collection);
                w.u64(*token_id);
                w.fixed(to);
                w.fixed(reason_hash)
            }
            ListingCreate { collection, token_id, price, currency, expiry_height } => {
                w.fixed(collection);
                w.u64(*token_id);
                w.u128(*price);
                currency.encode_to(w);
                w.u64(*expiry_height)
            }
            ListingCancel { listing_id } => w.fixed(listing_id),
            ListingBuy { listing_id, price, currency } => {
                w.fixed(listing_id);
                w.u128(*price);
                currency.encode_to(w)
            }
            DropCreate { collection, merkle_root, claim_deadline_height, max_claims } => {
                w.fixed(collection);
                w.fixed(merkle_root);
                w.u64(*claim_deadline_height);
                w.u32(*max_claims)
            }
            DropClaim { drop_id, index, item_token_id, metadata, proof } => {
                w.fixed(drop_id);
                w.u32(*index);
                w.u64(*item_token_id);
                metadata.enc(w);
                w.vec(proof, |w, p| {
                    w.u8(p.side);
                    w.fixed(&p.sibling)
                })
            }
        }
    }
}

fn dec_item(r: &mut Reader) -> DResult<MintItem> {
    Ok(MintItem { token_id: r.u64()?, to: r.fixed()?, metadata: MetadataRef::dec(r)? })
}

pub fn decode_body(tag: u8, r: &mut Reader) -> DResult<NftAction> {
    use NftAction::*;
    Ok(match tag {
        60 => CollectionCreate(CollectionSpec::dec(r)?),
        61 => Mint { collection: r.fixed()?, item: dec_item(r)? },
        // minimum item size: 8 + 20 + 4 + 32
        62 => MintBatch { collection: r.fixed()?, items: r.vec(MAX_BATCH_MINT, 64, dec_item)? },
        63 => Transfer { collection: r.fixed()?, token_id: r.u64()?, to: r.fixed()? },
        64 => Approve { collection: r.fixed()?, token_id: r.u64()?, approved: r.opt(|r| r.fixed())?, expiry_height: r.u64()? },
        65 => SetOperator { collection: r.fixed()?, operator: r.fixed()?, approved: r.bool()?, expiry_height: r.u64()? },
        66 => Burn { collection: r.fixed()?, token_id: r.u64()? },
        67 => UpdateMetadata { collection: r.fixed()?, token_id: r.u64()?, metadata: MetadataRef::dec(r)?, expected_revision: r.u32()? },
        68 => {
            let collection = r.fixed()?;
            let scope = match r.u8()? {
                1 => FreezeScope::Token(r.u64()?),
                2 => FreezeScope::Collection,
                t => return Err(DecodeError::BadTag(t, "freeze scope")),
            };
            FreezeMetadata { collection, scope, expected: r.fixed()? }
        }
        69 => SetPaused { collection: r.fixed()?, paused: r.bool()? },
        70 => SetRole { collection: r.fixed()?, role: r.u8()?, new: r.opt(|r| r.fixed())? },
        71 => ForceTransfer { collection: r.fixed()?, token_id: r.u64()?, to: r.fixed()?, reason_hash: r.fixed()? },
        72 => ListingCreate { collection: r.fixed()?, token_id: r.u64()?, price: r.u128()?, currency: AssetId::decode_from(r)?, expiry_height: r.u64()? },
        73 => ListingCancel { listing_id: r.fixed()? },
        74 => ListingBuy { listing_id: r.fixed()?, price: r.u128()?, currency: AssetId::decode_from(r)? },
        75 => DropCreate { collection: r.fixed()?, merkle_root: r.fixed()?, claim_deadline_height: r.u64()?, max_claims: r.u32()? },
        76 => DropClaim {
            drop_id: r.fixed()?,
            index: r.u32()?,
            item_token_id: r.u64()?,
            metadata: MetadataRef::dec(r)?,
            proof: r.vec(crate::types::MAX_PROOF_STEPS, 33, |r| {
                let side = r.u8()?;
                if side > 1 {
                    return Err(DecodeError::BadTag(side, "proof side"));
                }
                Ok(ProofStep { side, sibling: r.fixed()? })
            })?,
        },
        t => return Err(DecodeError::BadTag(t, "nft action")),
    })
}

// ------------------------------------------------------------------ identifiers

fn derive(domain: &str, sender: &Addr, nonce: u64) -> Hash32 {
    let mut d = sender.to_vec();
    d.extend_from_slice(&nonce.to_be_bytes());
    hash_domain(domain, &d)
}
pub fn collection_id(creator: &Addr, nonce: u64) -> Addr {
    derive("AUREOM/COLLECTION/v1", creator, nonce)[..20].try_into().unwrap()
}
pub fn listing_id(seller: &Addr, nonce: u64) -> Hash32 {
    derive("AUREOM/LISTING/v1", seller, nonce)
}
pub fn drop_id(creator: &Addr, nonce: u64) -> Hash32 {
    derive("AUREOM/NFT-DROP/v1", creator, nonce)
}

/// Leaf of a claim-based drop: binds claimant, token id and the exact metadata reference.
pub fn drop_leaf(index: u32, claimant: &Addr, token_id: u64, m: &MetadataRef) -> Hash32 {
    let mut w = Writer::new();
    w.u32(index);
    w.fixed(claimant);
    w.u64(token_id);
    m.enc(&mut w);
    hash_domain("AUREOM/NFT-CLAIM/v1", &w.finish())
}

/// Commitment to the metadata of every live token (sorted by id), signed into a
/// collection-wide freeze so the signer commits to exactly what becomes frozen.
pub fn metadata_root(ov: &Overlay, c: &Addr) -> Hash32 {
    let leaves: Vec<Hash32> = ov
        .scan_prefix(&keys::tokens_of(c))
        .into_iter()
        .filter_map(|(k, v)| {
            let r = NftRecord::decode(&v).expect("canonical");
            if r.burned {
                return None;
            }
            let mut w = Writer::new();
            w.fixed(&k[21..29]);
            w.fixed(&r.metadata.hash);
            w.u32(r.revision);
            Some(hash_domain("AUREOM/NFT-META/v1", &w.finish()))
        })
        .collect();
    merkle::root(&leaves)
}

/// Globally unambiguous reference: network identity + collection + token.
pub fn nft_ref(p: &ChainParams, c: &Addr, token_id: u64) -> String {
    format!("aureom:{}:{}/{}/{}", p.doc.chain_id, hex::encode(&p.hash[..8]), p.collection(c), token_id)
}

// ------------------------------------------------------------------ overlay helpers

fn get<T: Decode>(ov: &Overlay, k: &[u8]) -> Option<T> {
    ov.get(k).map(|v| T::decode(&v).expect("canonical"))
}
pub fn collection(ov: &Overlay, c: &Addr) -> Option<Collection> {
    get(ov, &keys::collection(c))
}
pub fn token(ov: &Overlay, c: &Addr, id: u64) -> Option<NftRecord> {
    get(ov, &keys::token(c, id))
}
pub fn listing(ov: &Overlay, l: &Hash32) -> Option<Listing> {
    get(ov, &keys::listing(l))
}
pub fn operator_expiry(ov: &Overlay, c: &Addr, owner: &Addr, op: &Addr) -> Option<u64> {
    ov.get(&keys::operator(c, owner, op)).map(|v| crate::types::decode_u64(&v).expect("canonical"))
}
fn operator_active(ov: &Overlay, h: u64, c: &Addr, owner: &Addr, op: &Addr) -> bool {
    matches!(operator_expiry(ov, c, owner, op), Some(e) if e == 0 || h <= e)
}

fn printable(s: &str, max: usize) -> bool {
    s.len() <= max && s.bytes().all(|b| (0x20..0x7f).contains(&b))
}
fn valid_slug(s: &str) -> bool {
    !s.is_empty() && s.len() <= MAX_SLUG_LEN && s.as_bytes()[0].is_ascii_lowercase() && s.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
}

fn log_authority(ov: &mut Overlay, cid: &Addr, col: &mut Collection, ch: AuthorityChange) {
    ov.put(keys::authority_log(cid, col.authority_changes), ch.encode());
    col.authority_changes += 1;
}

fn role_name(r: u8) -> &'static str {
    match r {
        ROLE_ADMIN => "admin",
        ROLE_MINT_AUTHORITY => "mint_authority",
        ROLE_METADATA_ADMIN => "metadata_admin",
        ROLE_ROYALTY_RECIPIENT => "royalty_recipient",
        _ => "unknown",
    }
}

fn opt_s(p: &ChainParams, a: &Option<Addr>) -> String {
    a.map(|x| p.addr(&x)).unwrap_or_else(|| "none".into())
}

type ActResult = Result<Vec<Event>, u16>;

#[allow(clippy::too_many_arguments)]
/// Every ownership change goes through here: clears the single-token approval and
/// invalidates any active listing for the token (its seller no longer owns it).
fn move_token(ov: &mut Overlay, p: &ChainParams, h: u64, cid: &Addr, tid: u64, rec: &mut NftRecord, to: &Addr, evs: &mut Vec<Event>) {
    rec.owner = *to;
    rec.approved = None;
    rec.approval_expiry = 0;
    rec.transfers = rec.transfers.saturating_add(1);
    rec.last_change_height = h;
    invalidate_listing(ov, p, h, cid, tid, evs);
    ov.put(keys::token(cid, tid), rec.encode());
}

fn invalidate_listing(ov: &mut Overlay, _p: &ChainParams, h: u64, cid: &Addr, tid: u64, evs: &mut Vec<Event>) {
    let ak = keys::active_listing(cid, tid);
    if let Some(lid) = ov.get(&ak) {
        let lid: Hash32 = lid.try_into().expect("32 bytes");
        if let Some(mut l) = listing(ov, &lid) {
            if l.status == LISTING_ACTIVE {
                l.status = LISTING_INVALIDATED;
                l.closed_height = h;
                ov.put(keys::listing(&lid), l.encode());
                evs.push(Event::new("nft_listing").attr("op", "invalidated").attr("listing", hex::encode(lid)).attr("reason", "owner_changed"));
            }
        }
        ov.delete(ak);
    }
}

fn mint_one(ov: &mut Overlay, p: &ChainParams, h: u64, sender: &Addr, cid: &Addr, col: &mut Collection, it: &MintItem) -> Result<Event, u16> {
    if !it.metadata.valid() {
        return Err(INVALID_ARGUMENT);
    }
    if token(ov, cid, it.token_id).is_some() {
        // burned tokens keep their record: an id is never reused
        return Err(ALREADY_EXISTS);
    }
    let minted = col.minted.checked_add(1).ok_or(OVERFLOW)?;
    if let Some(m) = col.spec.max_supply {
        if minted > m {
            return Err(SUPPLY_CAP);
        }
    }
    col.minted = minted;
    let frozen = col.spec.metadata_policy == POLICY_IMMUTABLE || col.frozen_all;
    let rec = NftRecord {
        owner: it.to,
        approved: None,
        approval_expiry: 0,
        metadata: it.metadata.clone(),
        revision: 0,
        frozen,
        minted_height: h,
        minted_by: *sender,
        burned: false,
        transfers: 0,
        last_change_height: h,
    };
    ov.put(keys::token(cid, it.token_id), rec.encode());
    ov.put(keys::revision(cid, it.token_id, 0), MetadataRevision { metadata: it.metadata.clone(), height: h, by: *sender }.encode());
    Ok(Event::new("nft_mint")
        .attr("collection", p.collection(cid))
        .attr("token_id", it.token_id)
        .attr("to", p.addr(&it.to))
        .attr("by", p.addr(sender))
        .attr("metadata_uri", &it.metadata.uri)
        .attr("metadata_hash", hex::encode(it.metadata.hash))
        .attr("frozen", frozen))
}

fn debit_asset(ov: &mut Overlay, h: u64, asset: &AssetId, from: &Addr, amount: u128) -> Result<(), u16> {
    match asset {
        AssetId::Native => crate::exec::debit_native(ov, h, from, amount),
        AssetId::Token(t) => {
            let info = ov.token(t).ok_or(NOT_FOUND)?;
            if info.paused {
                return Err(PAUSED);
            }
            let mut b = ov.token_balance(t, from);
            if b.frozen {
                return Err(FROZEN);
            }
            if b.amount < amount {
                return Err(INSUFFICIENT_FUNDS);
            }
            b.amount -= amount;
            ov.put_token_balance(t, from, &b);
            Ok(())
        }
    }
}

fn credit_asset(ov: &mut Overlay, h: u64, asset: &AssetId, to: &Addr, amount: u128) -> Result<(), u16> {
    if amount == 0 {
        return Ok(());
    }
    match asset {
        AssetId::Native => crate::exec::credit_native(ov, h, to, amount),
        AssetId::Token(t) => {
            let mut b: TokenBalance = ov.token_balance(t, to);
            if b.frozen {
                return Err(FROZEN);
            }
            b.amount = b.amount.checked_add(amount).ok_or(OVERFLOW)?;
            ov.put_token_balance(t, to, &b);
            Ok(())
        }
    }
}

/// Split of a sale price (integer, floor rounding; the seller receives the remainder).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Proceeds {
    pub royalty: u128,
    pub platform_fee: u128,
    pub seller: u128,
}

pub fn split_proceeds(price: u128, royalty_bps: u16, fee_bps: u32) -> Proceeds {
    let royalty = crate::mul_div(price, royalty_bps as u128, 10_000);
    let platform_fee = crate::mul_div(price, fee_bps as u128, 10_000);
    // royalty_bps <= 2500 and fee_bps <= 1000, so royalty + fee <= 35% of price
    Proceeds { royalty, platform_fee, seller: price - royalty - platform_fee }
}

fn asset_s(p: &ChainParams, a: &AssetId) -> String {
    match a {
        AssetId::Native => "native".into(),
        AssetId::Token(t) => p.token(t),
    }
}

pub fn exec(ov: &mut Overlay, p: &ChainParams, ctx: &mut BlockCtx, sender: &Addr, nonce: u64, a: &NftAction) -> ActResult {
    let h = ctx.height;
    let module = p.collections.as_ref().ok_or(UNAUTHORIZED)?;
    let col_of = |ov: &Overlay, c: &Addr| collection(ov, c).ok_or(NOT_FOUND);
    match a {
        NftAction::CollectionCreate(s) => {
            let admin_needed = s.flags & CFLAG_ADMIN_POWERS != 0;
            let policy_ok = match s.metadata_policy {
                POLICY_MUTABLE | POLICY_FREEZABLE => s.metadata_admin.is_some(),
                POLICY_IMMUTABLE => s.metadata_admin.is_none(),
                _ => false,
            };
            if !valid_slug(&s.slug)
                || s.name.is_empty()
                || !printable(&s.name, crate::types::MAX_NAME_LEN)
                || !printable(&s.rights_holder, MAX_RIGHTS_HOLDER_LEN)
                || s.rights_holder.is_empty()
                || !s.collection_metadata.valid()
                || !s.rights.valid()
                || !policy_ok
                || s.flags & !(CFLAG_PAUSABLE | CFLAG_FORCED_TRANSFER | CFLAG_OWNER_BURN) != 0
                || admin_needed != s.admin.is_some()
                || s.transfer_policy > TRANSFER_NONE
                || s.max_supply == Some(0)
                || s.royalty.as_ref().is_some_and(|r| r.bps == 0 || r.bps > MAX_ROYALTY_BPS)
            {
                return Err(INVALID_ARGUMENT);
            }
            let cid = collection_id(sender, nonce);
            if collection(ov, &cid).is_some() || ov.get(&keys::slug(&s.slug)).is_some() {
                return Err(ALREADY_EXISTS);
            }
            ov.put(keys::slug(&s.slug), cid.to_vec());
            let col = Collection { spec: s.clone(), creator: *sender, created_height: h, minted: 0, burned: 0, paused: false, frozen_all: false, frozen_height: 0, authority_changes: 0 };
            ov.put(keys::collection(&cid), col.encode());
            Ok(vec![Event::new("nft_collection_create")
                .attr("collection", p.collection(&cid))
                .attr("slug", &s.slug)
                .attr("creator", p.addr(sender))
                .attr("max_supply", s.max_supply.map(|m| m.to_string()).unwrap_or_else(|| "none".into()))
                .attr("mint_authority", opt_s(p, &s.mint_authority))
                .attr("metadata_policy", s.metadata_policy)
                .attr("metadata_admin", opt_s(p, &s.metadata_admin))
                .attr("admin", opt_s(p, &s.admin))
                .attr("flags", s.flags)
                .attr("transfer_policy", s.transfer_policy)
                .attr("royalty_bps", s.royalty.as_ref().map(|r| r.bps).unwrap_or(0))
                .attr("metadata_hash", hex::encode(s.collection_metadata.hash))
                .attr("rights_hash", hex::encode(s.rights.hash))])
        }
        NftAction::Mint { collection: cid, item } => {
            let mut col = col_of(ov, cid)?;
            if col.spec.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if col.paused {
                return Err(PAUSED);
            }
            let ev = mint_one(ov, p, h, sender, cid, &mut col, item)?;
            ov.put(keys::collection(cid), col.encode());
            Ok(vec![ev])
        }
        NftAction::MintBatch { collection: cid, items } => {
            let mut col = col_of(ov, cid)?;
            if col.spec.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if col.paused {
                return Err(PAUSED);
            }
            if items.is_empty() || items.len() > MAX_BATCH_MINT {
                return Err(INVALID_ARGUMENT);
            }
            // all-or-nothing: any failing item fails the whole action (and reverts it)
            let mut evs = vec![];
            for it in items {
                evs.push(mint_one(ov, p, h, sender, cid, &mut col, it)?);
            }
            ov.put(keys::collection(cid), col.encode());
            evs.push(Event::new("nft_mint_batch").attr("collection", p.collection(cid)).attr("count", items.len()));
            Ok(evs)
        }
        NftAction::Transfer { collection: cid, token_id, to } => {
            let col = col_of(ov, cid)?;
            let mut rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if col.paused {
                return Err(PAUSED);
            }
            if col.spec.transfer_policy == TRANSFER_NONE {
                return Err(NON_TRANSFERABLE);
            }
            let via = if &rec.owner == sender {
                "owner"
            } else if rec.approval_active(h).as_ref() == Some(sender) {
                "token_approval"
            } else if operator_active(ov, h, cid, &rec.owner, sender) {
                "operator"
            } else {
                return Err(UNAUTHORIZED);
            };
            if to == &rec.owner {
                return Err(INVALID_ARGUMENT);
            }
            let from = rec.owner;
            let mut evs = vec![];
            move_token(ov, p, h, cid, *token_id, &mut rec, to, &mut evs);
            evs.insert(0, Event::new("nft_transfer")
                .attr("collection", p.collection(cid))
                .attr("token_id", token_id)
                .attr("from", p.addr(&from))
                .attr("to", p.addr(to))
                .attr("by", p.addr(sender))
                .attr("authority", via));
            Ok(evs)
        }
        NftAction::Approve { collection: cid, token_id, approved, expiry_height } => {
            col_of(ov, cid)?;
            let mut rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if &rec.owner != sender {
                return Err(UNAUTHORIZED);
            }
            if approved.as_ref() == Some(sender) || (*expiry_height != 0 && *expiry_height <= h) || (approved.is_none() && *expiry_height != 0) {
                return Err(INVALID_ARGUMENT);
            }
            rec.approved = *approved;
            rec.approval_expiry = *expiry_height;
            ov.put(keys::token(cid, *token_id), rec.encode());
            Ok(vec![Event::new("nft_approval")
                .attr("collection", p.collection(cid))
                .attr("token_id", token_id)
                .attr("owner", p.addr(sender))
                .attr("scope", "token")
                .attr("op", if approved.is_some() { "approve" } else { "revoke" })
                .attr("approved", opt_s(p, approved))
                .attr("expiry_height", expiry_height)])
        }
        NftAction::SetOperator { collection: cid, operator, approved, expiry_height } => {
            col_of(ov, cid)?;
            if operator == sender || (*expiry_height != 0 && *expiry_height <= h) || (!approved && *expiry_height != 0) {
                return Err(INVALID_ARGUMENT);
            }
            let k = keys::operator(cid, sender, operator);
            if *approved {
                ov.put(k, expiry_height.to_be_bytes().to_vec());
            } else {
                if ov.get(&k).is_none() {
                    return Err(NOT_FOUND);
                }
                ov.delete(k);
            }
            Ok(vec![Event::new("nft_approval")
                .attr("collection", p.collection(cid))
                .attr("owner", p.addr(sender))
                .attr("scope", "operator_all_tokens_in_collection")
                .attr("op", if *approved { "approve" } else { "revoke" })
                .attr("approved", p.addr(operator))
                .attr("expiry_height", expiry_height)])
        }
        NftAction::Burn { collection: cid, token_id } => {
            let mut col = col_of(ov, cid)?;
            let mut rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if col.spec.flags & CFLAG_OWNER_BURN == 0 || &rec.owner != sender {
                return Err(UNAUTHORIZED);
            }
            if col.paused {
                return Err(PAUSED);
            }
            let mut evs = vec![];
            rec.burned = true;
            rec.approved = None;
            rec.approval_expiry = 0;
            rec.last_change_height = h;
            invalidate_listing(ov, p, h, cid, *token_id, &mut evs);
            ov.put(keys::token(cid, *token_id), rec.encode());
            col.burned += 1;
            ov.put(keys::collection(cid), col.encode());
            evs.insert(0, Event::new("nft_burn").attr("collection", p.collection(cid)).attr("token_id", token_id).attr("owner", p.addr(sender)));
            Ok(evs)
        }
        NftAction::UpdateMetadata { collection: cid, token_id, metadata, expected_revision } => {
            let col = col_of(ov, cid)?;
            let mut rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if col.spec.metadata_policy == POLICY_IMMUTABLE || rec.frozen || col.frozen_all {
                return Err(METADATA_FROZEN);
            }
            if col.spec.metadata_admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if *expected_revision != rec.revision {
                return Err(STALE);
            }
            if !metadata.valid() || metadata == &rec.metadata {
                return Err(INVALID_ARGUMENT);
            }
            let prev = rec.metadata.hash;
            rec.revision = rec.revision.checked_add(1).ok_or(OVERFLOW)?;
            rec.metadata = metadata.clone();
            rec.last_change_height = h;
            ov.put(keys::token(cid, *token_id), rec.encode());
            ov.put(keys::revision(cid, *token_id, rec.revision), MetadataRevision { metadata: metadata.clone(), height: h, by: *sender }.encode());
            Ok(vec![Event::new("nft_metadata")
                .attr("collection", p.collection(cid))
                .attr("token_id", token_id)
                .attr("op", "update")
                .attr("revision", rec.revision)
                .attr("metadata_uri", &metadata.uri)
                .attr("metadata_hash", hex::encode(metadata.hash))
                .attr("previous_hash", hex::encode(prev))
                .attr("by", p.addr(sender))])
        }
        NftAction::FreezeMetadata { collection: cid, scope, expected } => {
            let mut col = col_of(ov, cid)?;
            if col.spec.metadata_policy == POLICY_IMMUTABLE || col.frozen_all {
                return Err(METADATA_FROZEN);
            }
            if col.spec.metadata_policy != POLICY_FREEZABLE {
                // policy 1 is "mutable with recorded revisions": no freeze exists
                return Err(INVALID_ARGUMENT);
            }
            if col.spec.metadata_admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            match scope {
                FreezeScope::Token(t) => {
                    let mut rec = token(ov, cid, *t).ok_or(NOT_FOUND)?;
                    if rec.burned {
                        return Err(NOT_FOUND);
                    }
                    if rec.frozen {
                        return Err(METADATA_FROZEN);
                    }
                    if &rec.metadata.hash != expected {
                        return Err(STALE);
                    }
                    rec.frozen = true;
                    rec.last_change_height = h;
                    ov.put(keys::token(cid, *t), rec.encode());
                    Ok(vec![Event::new("nft_metadata")
                        .attr("collection", p.collection(cid))
                        .attr("token_id", t)
                        .attr("op", "freeze_token")
                        .attr("revision", rec.revision)
                        .attr("metadata_uri", &rec.metadata.uri)
                        .attr("metadata_hash", hex::encode(rec.metadata.hash))
                        .attr("by", p.addr(sender))])
                }
                FreezeScope::Collection => {
                    let root = metadata_root(ov, cid);
                    if &root != expected {
                        return Err(STALE);
                    }
                    col.frozen_all = true;
                    col.frozen_height = h;
                    let old = col.spec.metadata_admin.take();
                    log_authority(ov, cid, &mut col, AuthorityChange { role: ROLE_METADATA_ADMIN, old, new: None, height: h, by: *sender });
                    ov.put(keys::collection(cid), col.encode());
                    Ok(vec![
                        Event::new("nft_metadata").attr("collection", p.collection(cid)).attr("op", "freeze_collection").attr("metadata_root", hex::encode(root)).attr("live_tokens", col.minted - col.burned).attr("by", p.addr(sender)),
                        Event::new("nft_authority").attr("collection", p.collection(cid)).attr("role", "metadata_admin").attr("old", opt_s(p, &old)).attr("new", "none").attr("reason", "collection_frozen"),
                    ])
                }
            }
        }
        NftAction::SetPaused { collection: cid, paused } => {
            let mut col = col_of(ov, cid)?;
            if col.spec.flags & CFLAG_PAUSABLE == 0 || col.spec.admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            col.paused = *paused;
            ov.put(keys::collection(cid), col.encode());
            Ok(vec![Event::new("nft_admin").attr("collection", p.collection(cid)).attr("op", if *paused { "pause" } else { "unpause" }).attr("admin", p.addr(sender))])
        }
        NftAction::SetRole { collection: cid, role, new } => {
            let mut col = col_of(ov, cid)?;
            let current = match *role {
                ROLE_ADMIN => col.spec.admin,
                ROLE_MINT_AUTHORITY => col.spec.mint_authority,
                ROLE_METADATA_ADMIN => {
                    if col.frozen_all || col.spec.metadata_policy == POLICY_IMMUTABLE {
                        return Err(METADATA_FROZEN);
                    }
                    col.spec.metadata_admin
                }
                ROLE_ROYALTY_RECIPIENT => col.spec.royalty.as_ref().map(|r| r.recipient),
                _ => return Err(INVALID_ARGUMENT),
            };
            // only the current holder may reassign or renounce its own role
            if current.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if new == &current {
                return Err(INVALID_ARGUMENT);
            }
            // mutable/freezable metadata needs an admin; renouncing it makes metadata
            // effectively immutable but the policy label stays as declared at creation
            match *role {
                ROLE_ADMIN => col.spec.admin = *new,
                ROLE_MINT_AUTHORITY => col.spec.mint_authority = *new,
                ROLE_METADATA_ADMIN => col.spec.metadata_admin = *new,
                _ => match new {
                    Some(n) => col.spec.royalty.as_mut().expect("checked").recipient = *n,
                    None => col.spec.royalty = None,
                },
            }
            log_authority(ov, cid, &mut col, AuthorityChange { role: *role, old: current, new: *new, height: h, by: *sender });
            ov.put(keys::collection(cid), col.encode());
            Ok(vec![Event::new("nft_authority")
                .attr("collection", p.collection(cid))
                .attr("role", role_name(*role))
                .attr("old", opt_s(p, &current))
                .attr("new", opt_s(p, new))
                .attr("by", p.addr(sender))])
        }
        NftAction::ForceTransfer { collection: cid, token_id, to, reason_hash } => {
            let col = col_of(ov, cid)?;
            if col.spec.flags & CFLAG_FORCED_TRANSFER == 0 || col.spec.admin.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            let mut rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if to == &rec.owner || reason_hash == &[0; 32] {
                return Err(INVALID_ARGUMENT);
            }
            let from = rec.owner;
            let mut evs = vec![];
            move_token(ov, p, h, cid, *token_id, &mut rec, to, &mut evs);
            evs.insert(0, Event::new("nft_transfer")
                .attr("collection", p.collection(cid))
                .attr("token_id", token_id)
                .attr("from", p.addr(&from))
                .attr("to", p.addr(to))
                .attr("by", p.addr(sender))
                .attr("authority", "forced_by_admin")
                .attr("reason_hash", hex::encode(reason_hash)));
            Ok(evs)
        }
        NftAction::ListingCreate { collection: cid, token_id, price, currency, expiry_height } => {
            if !module.marketplace {
                return Err(UNAUTHORIZED);
            }
            let col = col_of(ov, cid)?;
            let rec = token(ov, cid, *token_id).ok_or(NOT_FOUND)?;
            if rec.burned {
                return Err(NOT_FOUND);
            }
            if &rec.owner != sender {
                return Err(UNAUTHORIZED);
            }
            if col.paused {
                return Err(PAUSED);
            }
            if col.spec.transfer_policy == TRANSFER_NONE {
                return Err(NON_TRANSFERABLE);
            }
            if *price == 0 || *expiry_height <= h || *expiry_height > h.saturating_add(MAX_LISTING_TTL_BLOCKS) {
                return Err(INVALID_ARGUMENT);
            }
            if let AssetId::Token(t) = currency {
                ov.token(t).ok_or(NOT_FOUND)?;
            }
            let ak = keys::active_listing(cid, *token_id);
            let mut pre = vec![];
            if let Some(old) = ov.get(&ak) {
                let old: Hash32 = old.try_into().expect("32 bytes");
                let mut ol = listing(ov, &old).ok_or(NOT_FOUND)?;
                if ol.status == LISTING_ACTIVE && h <= ol.expiry_height {
                    return Err(ALREADY_EXISTS);
                }
                if ol.status == LISTING_ACTIVE {
                    ol.status = LISTING_EXPIRED;
                    ol.closed_height = h;
                    ov.put(keys::listing(&old), ol.encode());
                    pre.push(Event::new("nft_listing").attr("op", "expired_superseded").attr("listing", hex::encode(old)).attr("collection", p.collection(cid)).attr("token_id", token_id));
                }
            }
            let lid = listing_id(sender, nonce);
            if listing(ov, &lid).is_some() {
                return Err(ALREADY_EXISTS);
            }
            let l = Listing {
                seller: *sender,
                collection: *cid,
                token_id: *token_id,
                price: *price,
                currency: currency.clone(),
                expiry_height: *expiry_height,
                created_height: h,
                status: LISTING_ACTIVE,
                buyer: None,
                closed_height: 0,
                royalty_paid: 0,
                royalty_recipient: None,
                platform_fee_paid: 0,
                seller_proceeds: 0,
            };
            ov.put(keys::listing(&lid), l.encode());
            ov.put(ak, lid.to_vec());
            Ok(pre.into_iter().chain([Event::new("nft_listing")
                .attr("op", "create")
                .attr("listing", hex::encode(lid))
                .attr("collection", p.collection(cid))
                .attr("token_id", token_id)
                .attr("seller", p.addr(sender))
                .attr("price", price)
                .attr("currency", asset_s(p, currency))
                .attr("expiry_height", expiry_height)]).collect())
        }
        NftAction::ListingCancel { listing_id: lid } => {
            let mut l = listing(ov, lid).ok_or(NOT_FOUND)?;
            if &l.seller != sender {
                return Err(UNAUTHORIZED);
            }
            if l.status != LISTING_ACTIVE {
                return Err(LISTING_INACTIVE);
            }
            l.status = LISTING_CANCELLED;
            l.closed_height = h;
            ov.put(keys::listing(lid), l.encode());
            ov.delete(keys::active_listing(&l.collection, l.token_id));
            Ok(vec![Event::new("nft_listing").attr("op", "cancel").attr("listing", hex::encode(lid)).attr("collection", p.collection(&l.collection)).attr("token_id", l.token_id)])
        }
        NftAction::ListingBuy { listing_id: lid, price, currency } => {
            if !module.marketplace {
                return Err(UNAUTHORIZED);
            }
            let mut l = listing(ov, lid).ok_or(NOT_FOUND)?;
            // --- revalidate everything at settlement time
            if l.status != LISTING_ACTIVE || h > l.expiry_height {
                return Err(LISTING_INACTIVE);
            }
            if &l.price != price || &l.currency != currency {
                return Err(STALE);
            }
            if &l.seller == sender {
                return Err(INVALID_ARGUMENT);
            }
            let cid = l.collection;
            let col = col_of(ov, &cid)?;
            if col.paused {
                return Err(PAUSED);
            }
            let mut rec = token(ov, &cid, l.token_id).ok_or(NOT_FOUND)?;
            if rec.burned || rec.owner != l.seller {
                return Err(LISTING_INACTIVE);
            }
            if col.spec.transfer_policy == TRANSFER_NONE {
                return Err(NON_TRANSFERABLE);
            }
            // --- atomic settlement: one state transition; any failure reverts all of it
            let royalty_bps = col.spec.royalty.as_ref().map(|r| r.bps).unwrap_or(0);
            let fee_bps = if module.fee_recipient.is_some() { module.fee_bps } else { 0 };
            let pr = split_proceeds(l.price, royalty_bps, fee_bps);
            debit_asset(ov, h, &l.currency, sender, l.price)?;
            let royalty_to = col.spec.royalty.as_ref().map(|r| r.recipient);
            if let Some(rt) = &royalty_to {
                credit_asset(ov, h, &l.currency, rt, pr.royalty)?;
            }
            if let Some(fr) = &module.fee_recipient {
                credit_asset(ov, h, &l.currency, fr, pr.platform_fee)?;
            }
            credit_asset(ov, h, &l.currency, &l.seller, pr.seller)?;
            // close the listing before moving the token (move_token would invalidate it)
            ov.delete(keys::active_listing(&cid, l.token_id));
            l.status = LISTING_SOLD;
            l.buyer = Some(*sender);
            l.closed_height = h;
            l.royalty_paid = pr.royalty;
            l.royalty_recipient = royalty_to;
            l.platform_fee_paid = pr.platform_fee;
            l.seller_proceeds = pr.seller;
            ov.put(keys::listing(lid), l.encode());
            let mut evs = vec![];
            move_token(ov, p, h, &cid, l.token_id, &mut rec, sender, &mut evs);
            let mut out = vec![
                Event::new("nft_transfer")
                    .attr("collection", p.collection(&cid))
                    .attr("token_id", l.token_id)
                    .attr("from", p.addr(&l.seller))
                    .attr("to", p.addr(sender))
                    .attr("by", p.addr(sender))
                    .attr("authority", "listing_sale")
                    .attr("listing", hex::encode(lid)),
                Event::new("nft_sale")
                    .attr("listing", hex::encode(lid))
                    .attr("collection", p.collection(&cid))
                    .attr("token_id", l.token_id)
                    .attr("seller", p.addr(&l.seller))
                    .attr("buyer", p.addr(sender))
                    .attr("price", l.price)
                    .attr("currency", asset_s(p, &l.currency))
                    .attr("royalty", pr.royalty)
                    .attr("royalty_to", opt_s(p, &royalty_to))
                    .attr("platform_fee", pr.platform_fee)
                    .attr("platform_to", opt_s(p, &module.fee_recipient))
                    .attr("seller_proceeds", pr.seller)
                    .attr("chain_id", &p.doc.chain_id),
            ];
            out.extend(evs);
            Ok(out)
        }
        NftAction::DropCreate { collection: cid, merkle_root, claim_deadline_height, max_claims } => {
            let col = col_of(ov, cid)?;
            if col.spec.mint_authority.as_ref() != Some(sender) {
                return Err(UNAUTHORIZED);
            }
            if *claim_deadline_height <= h || *max_claims == 0 {
                return Err(INVALID_ARGUMENT);
            }
            let did = drop_id(sender, nonce);
            if ov.get(&keys::drop(&did)).is_some() {
                return Err(ALREADY_EXISTS);
            }
            ov.put(keys::drop(&did), Drop { collection: *cid, creator: *sender, merkle_root: *merkle_root, claim_deadline_height: *claim_deadline_height, max_claims: *max_claims, claims: 0 }.encode());
            Ok(vec![Event::new("nft_drop")
                .attr("op", "create")
                .attr("drop", hex::encode(did))
                .attr("collection", p.collection(cid))
                .attr("merkle_root", hex::encode(merkle_root))
                .attr("deadline", claim_deadline_height)
                .attr("max_claims", max_claims)])
        }
        NftAction::DropClaim { drop_id: did, index, item_token_id, metadata, proof } => {
            let mut d: Drop = get(ov, &keys::drop(did)).ok_or(NOT_FOUND)?;
            if h > d.claim_deadline_height {
                return Err(EXPIRED);
            }
            if d.claims >= d.max_claims {
                return Err(SUPPLY_CAP);
            }
            let ck = keys::drop_claimed(did, *index);
            if ov.get(&ck).is_some() {
                return Err(ALREADY_CLAIMED);
            }
            let leaf = drop_leaf(*index, sender, *item_token_id, metadata);
            if !merkle::verify_proof(&leaf, proof, &d.merkle_root) {
                return Err(BAD_PROOF);
            }
            let cid = d.collection;
            let mut col = col_of(ov, &cid)?;
            if col.paused {
                return Err(PAUSED);
            }
            let item = MintItem { token_id: *item_token_id, to: *sender, metadata: metadata.clone() };
            let creator = d.creator;
            let ev = mint_one(ov, p, h, &creator, &cid, &mut col, &item)?;
            ov.put(keys::collection(&cid), col.encode());
            d.claims += 1;
            ov.put(keys::drop(did), d.encode());
            ov.put(ck, vec![1]);
            Ok(vec![ev, Event::new("nft_drop").attr("op", "claim").attr("drop", hex::encode(did)).attr("index", index).attr("claimant", p.addr(sender)).attr("token_id", item_token_id)])
        }
    }
}

/// NFT reconciliation: for each collection, live token records == minted − burned, and
/// every active-listing pointer refers to an active listing by the current owner.
pub fn reconcile(entries: &[(&Vec<u8>, &Vec<u8>)], p: &ChainParams) -> (bool, Vec<String>) {
    use std::collections::BTreeMap;
    let mut live: BTreeMap<Addr, u64> = BTreeMap::new();
    let mut total: BTreeMap<Addr, u64> = BTreeMap::new();
    let mut cols: BTreeMap<Addr, Collection> = BTreeMap::new();
    let mut owners: BTreeMap<(Addr, u64), Addr> = BTreeMap::new();
    let mut listings: BTreeMap<Hash32, Listing> = BTreeMap::new();
    let mut pointers = vec![];
    for (k, v) in entries {
        match k[0] {
            0x40 => {
                cols.insert(k[1..21].try_into().unwrap(), Collection::decode(v).expect("canonical"));
            }
            0x42 => {
                let c: Addr = k[1..21].try_into().unwrap();
                let id = u64::from_be_bytes(k[21..29].try_into().unwrap());
                let r = NftRecord::decode(v).expect("canonical");
                *total.entry(c).or_default() += 1;
                if !r.burned {
                    *live.entry(c).or_default() += 1;
                    owners.insert((c, id), r.owner);
                }
            }
            0x47 => {
                listings.insert(k[1..33].try_into().unwrap(), Listing::decode(v).expect("canonical"));
            }
            0x48 => pointers.push(((k[1..21].try_into().unwrap(), u64::from_be_bytes(k[21..29].try_into().unwrap())), v.to_vec())),
            _ => {}
        }
    }
    let mut problems = vec![];
    for (c, col) in &cols {
        let l = live.get(c).copied().unwrap_or(0);
        let t = total.get(c).copied().unwrap_or(0);
        if l != col.minted - col.burned || t != col.minted {
            problems.push(format!("collection {}: minted {} burned {} but {} records / {} live", p.collection(c), col.minted, col.burned, t, l));
        }
        if let Some(m) = col.spec.max_supply {
            if col.minted > m {
                problems.push(format!("collection {} minted {} > max_supply {}", p.collection(c), col.minted, m));
            }
        }
    }
    for ((c, id), lid) in pointers {
        let lid: Hash32 = lid.try_into().unwrap_or([0; 32]);
        match listings.get(&lid) {
            Some(l) if l.status == LISTING_ACTIVE && owners.get(&(c, id)) == Some(&l.seller) => {}
            _ => problems.push(format!("active-listing pointer for {}/{} is stale", p.collection(&c), id)),
        }
    }
    (problems.is_empty(), problems)
}
