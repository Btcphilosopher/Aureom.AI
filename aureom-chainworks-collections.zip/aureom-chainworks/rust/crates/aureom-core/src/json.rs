//! JSON views (API / CLI). Not consensus encodings: amounts are decimal strings.

use crate::exec::err;
use crate::genesis::{decode_b64_pubkey, ChainParams};
use crate::merkle::ProofStep;
use crate::types::*;
use base64::Engine;
use serde_json::{json, Value};

fn opt_addr(p: &ChainParams, a: &Option<[u8; 20]>) -> Value {
    a.map(|x| Value::String(p.addr(&x))).unwrap_or(Value::Null)
}

pub fn gov_kind_json(p: &ChainParams, k: &GovKind) -> Value {
    match k {
        GovKind::AddAuthority { operator, consensus_pubkey, power, moniker } => json!({
            "kind": "add_authority", "operator": p.addr(operator),
            "consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(consensus_pubkey),
            "power": power, "moniker": moniker}),
        GovKind::RemoveAuthority { operator } => json!({"kind": "remove_authority", "operator": p.addr(operator)}),
        GovKind::ProtocolUpgrade { name, protocol_version, activation_height } => json!({
            "kind": "protocol_upgrade", "name": name, "protocol_version": protocol_version, "activation_height": activation_height}),
        GovKind::Text { title, uri } => json!({"kind": "text", "title": title, "uri": uri}),
    }
}

pub fn action_json(p: &ChainParams, a: &Action) -> Value {
    use Action::*;
    let mut v = match a {
        Transfer { to, amount } => json!({"to": p.addr(to), "amount": amount.to_string()}),
        VestedTransfer { to, amount, start_height, cliff_height, end_height } => json!({
            "to": p.addr(to), "amount": amount.to_string(), "start_height": start_height,
            "cliff_height": cliff_height, "end_height": end_height}),
        NativeMint { to, amount } => json!({"to": p.addr(to), "amount": amount.to_string()}),
        NativeBurn { amount } => json!({"amount": amount.to_string()}),
        TokenCreate { symbol, name, decimals, initial_supply, initial_recipient, max_supply, mint_authority, admin, flags, metadata_uri } => json!({
            "symbol": symbol, "name": name, "decimals": decimals, "initial_supply": initial_supply.to_string(),
            "initial_recipient": p.addr(initial_recipient), "max_supply": max_supply.map(|m| m.to_string()),
            "mint_authority": opt_addr(p, mint_authority), "admin": opt_addr(p, admin),
            "pausable": flags & FLAG_PAUSABLE != 0, "freezable": flags & FLAG_FREEZABLE != 0, "metadata_uri": metadata_uri}),
        TokenTransfer { token, to, amount } | TokenMint { token, to, amount } => json!({"token": p.token(token), "to": p.addr(to), "amount": amount.to_string()}),
        TokenBurn { token, amount } => json!({"token": p.token(token), "amount": amount.to_string()}),
        TokenSetPaused { token, paused } => json!({"token": p.token(token), "paused": paused}),
        TokenSetFrozen { token, account, frozen } => json!({"token": p.token(token), "account": p.addr(account), "frozen": frozen}),
        TokenSetMintAuthority { token, new_authority } => json!({"token": p.token(token), "new_authority": opt_addr(p, new_authority)}),
        MultisigCreate { signers, threshold } => json!({"signers": signers.iter().map(|s| p.addr(s)).collect::<Vec<_>>(), "threshold": threshold}),
        MultisigPropose { multisig, inner, expiry_height } => json!({"multisig": p.addr(multisig), "inner": action_json(p, inner), "expiry_height": expiry_height}),
        MultisigApprove { multisig, proposal_id } => json!({"multisig": p.addr(multisig), "proposal_id": proposal_id}),
        DistributionCreate { asset, total, merkle_root, claim_deadline_height } => json!({
            "asset": asset_json(p, asset), "total": total.to_string(), "merkle_root": hex::encode(merkle_root), "claim_deadline_height": claim_deadline_height}),
        DistributionClaim { dist_id, index, amount, proof } => json!({
            "dist_id": hex::encode(dist_id), "index": index, "amount": amount.to_string(),
            "proof": proof.iter().map(|s| json!({"side": s.side, "sibling": hex::encode(s.sibling)})).collect::<Vec<_>>()}),
        DistributionReclaim { dist_id } => json!({"dist_id": hex::encode(dist_id)}),
        ValidatorCreate { consensus_pubkey, self_bond, moniker } => json!({
            "consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(consensus_pubkey), "self_bond": self_bond.to_string(), "moniker": moniker}),
        ValidatorBond { amount } | ValidatorUnbond { amount } => json!({"amount": amount.to_string()}),
        ValidatorUnjail => json!({}),
        ValidatorRotateKey { new_consensus_pubkey } => json!({"new_consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(new_consensus_pubkey)}),
        GovPropose { kind, expiry_height } => json!({"proposal": gov_kind_json(p, kind), "expiry_height": expiry_height}),
        GovApprove { proposal_id } => json!({"proposal_id": proposal_id}),
        Nft(n) => nft_action_json(p, n),
    };
    v["type"] = Value::String(a.type_name().into());
    v
}

pub fn asset_json(p: &ChainParams, a: &AssetId) -> Value {
    match a {
        AssetId::Native => Value::String("native".into()),
        AssetId::Token(t) => Value::String(p.token(t)),
    }
}

pub fn unsigned_tx_json(p: &ChainParams, t: &UnsignedTx) -> Value {
    json!({
        "id": hex::encode(t.txid()),
        "version": t.version,
        "chain_id": t.chain_id,
        "sender": p.addr(&t.sender()),
        "sender_pubkey": hex::encode(t.sender_pubkey),
        "nonce": t.nonce,
        "fee": t.fee.to_string(),
        "expiry_height": t.expiry_height,
        "action": action_json(p, &t.action),
        "memo": String::from_utf8_lossy(&t.memo),
    })
}

pub fn receipt_json(r: &Receipt) -> Value {
    json!({
        "txid": hex::encode(r.txid),
        "status": if r.status == STATUS_SUCCESS { "success" } else { "failed" },
        "error": if r.error_code == 0 { Value::Null } else { Value::String(err::name(r.error_code).into()) },
        "error_code": r.error_code,
        "fee_paid": r.fee_paid.to_string(),
        "events": r.events.iter().map(|e| {
            let mut m = serde_json::Map::new();
            for (k, v) in &e.attrs { m.insert(k.clone(), Value::String(v.clone())); }
            json!({"kind": e.kind, "attrs": m})
        }).collect::<Vec<_>>(),
    })
}

// ------------------------------------------------------------------ parsing (CLI)

fn s<'a>(v: &'a Value, k: &str) -> Result<&'a str, String> {
    v.get(k).and_then(|x| x.as_str()).ok_or(format!("missing string field {k:?}"))
}
fn amt(v: &Value, k: &str) -> Result<u128, String> {
    let x = v.get(k).ok_or(format!("missing field {k:?}"))?;
    let st = match x {
        Value::String(s) => s.clone(),
        Value::Number(n) if n.is_u64() => n.to_string(),
        _ => return Err(format!("field {k:?} must be an integer amount in base units (string)")),
    };
    if st.is_empty() || !st.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("field {k:?}: {st:?} is not a base-unit integer"));
    }
    st.parse().map_err(|_| format!("field {k:?} overflows u128"))
}
fn u64f(v: &Value, k: &str) -> Result<u64, String> {
    v.get(k).and_then(|x| x.as_u64().or_else(|| x.as_str().and_then(|s| s.parse().ok()))).ok_or(format!("missing integer field {k:?}"))
}
fn opt_u128(v: &Value, k: &str) -> Result<Option<u128>, String> {
    match v.get(k) {
        None | Some(Value::Null) => Ok(None),
        _ => amt(v, k).map(Some),
    }
}
fn addr(p: &ChainParams, v: &Value, k: &str) -> Result<[u8; 20], String> {
    p.parse_addr(s(v, k)?).map_err(|e| format!("{k}: {e}"))
}
fn opt_addr_p(p: &ChainParams, v: &Value, k: &str) -> Result<Option<[u8; 20]>, String> {
    match v.get(k) {
        None | Some(Value::Null) => Ok(None),
        _ => addr(p, v, k).map(Some),
    }
}
fn token(p: &ChainParams, v: &Value, k: &str) -> Result<[u8; 20], String> {
    p.parse_token(s(v, k)?).map_err(|e| format!("{k}: {e}"))
}
fn hex32(v: &Value, k: &str) -> Result<[u8; 32], String> {
    hex::decode(s(v, k)?).map_err(|e| e.to_string())?.try_into().map_err(|_| format!("{k}: expected 32 bytes hex"))
}
fn b64k(v: &Value, k: &str) -> Result<[u8; 32], String> {
    decode_b64_pubkey(s(v, k)?)
}

pub fn action_from_json(p: &ChainParams, v: &Value) -> Result<Action, String> {
    use Action::*;
    let t = s(v, "type")?;
    Ok(match t {
        "transfer" => Transfer { to: addr(p, v, "to")?, amount: amt(v, "amount")? },
        "vested_transfer" => VestedTransfer {
            to: addr(p, v, "to")?,
            amount: amt(v, "amount")?,
            start_height: u64f(v, "start_height")?,
            cliff_height: u64f(v, "cliff_height")?,
            end_height: u64f(v, "end_height")?,
        },
        "native_mint" => NativeMint { to: addr(p, v, "to")?, amount: amt(v, "amount")? },
        "native_burn" => NativeBurn { amount: amt(v, "amount")? },
        "token_create" => {
            let mut flags = 0;
            if v.get("pausable").and_then(|x| x.as_bool()).unwrap_or(false) {
                flags |= FLAG_PAUSABLE;
            }
            if v.get("freezable").and_then(|x| x.as_bool()).unwrap_or(false) {
                flags |= FLAG_FREEZABLE;
            }
            TokenCreate {
                symbol: s(v, "symbol")?.into(),
                name: s(v, "name")?.into(),
                decimals: u64f(v, "decimals")? as u8,
                initial_supply: amt(v, "initial_supply")?,
                initial_recipient: addr(p, v, "initial_recipient")?,
                max_supply: opt_u128(v, "max_supply")?,
                mint_authority: opt_addr_p(p, v, "mint_authority")?,
                admin: opt_addr_p(p, v, "admin")?,
                flags,
                metadata_uri: v.get("metadata_uri").and_then(|x| x.as_str()).unwrap_or("").into(),
            }
        }
        "token_transfer" => TokenTransfer { token: token(p, v, "token")?, to: addr(p, v, "to")?, amount: amt(v, "amount")? },
        "token_mint" => TokenMint { token: token(p, v, "token")?, to: addr(p, v, "to")?, amount: amt(v, "amount")? },
        "token_burn" => TokenBurn { token: token(p, v, "token")?, amount: amt(v, "amount")? },
        "token_set_paused" => TokenSetPaused { token: token(p, v, "token")?, paused: v["paused"].as_bool().ok_or("paused")? },
        "token_set_frozen" => TokenSetFrozen { token: token(p, v, "token")?, account: addr(p, v, "account")?, frozen: v["frozen"].as_bool().ok_or("frozen")? },
        "token_set_mint_authority" => TokenSetMintAuthority { token: token(p, v, "token")?, new_authority: opt_addr_p(p, v, "new_authority")? },
        "multisig_create" => MultisigCreate {
            signers: v["signers"].as_array().ok_or("signers")?.iter().map(|x| p.parse_addr(x.as_str().unwrap_or(""))).collect::<Result<_, _>>()?,
            threshold: u64f(v, "threshold")? as u8,
        },
        "multisig_propose" => {
            let inner = action_from_json(p, v.get("inner").ok_or("inner")?)?;
            if !inner.allowed_in_multisig() {
                return Err("inner action not allowed in a multisig proposal".into());
            }
            MultisigPropose { multisig: addr(p, v, "multisig")?, inner: Box::new(inner), expiry_height: u64f(v, "expiry_height")? }
        }
        "multisig_approve" => MultisigApprove { multisig: addr(p, v, "multisig")?, proposal_id: u64f(v, "proposal_id")? },
        "distribution_create" => DistributionCreate {
            asset: match s(v, "asset")? {
                "native" => AssetId::Native,
                tk => AssetId::Token(p.parse_token(tk)?),
            },
            total: amt(v, "total")?,
            merkle_root: hex32(v, "merkle_root")?,
            claim_deadline_height: u64f(v, "claim_deadline_height")?,
        },
        "distribution_claim" => DistributionClaim {
            dist_id: hex32(v, "dist_id")?,
            index: u64f(v, "index")? as u32,
            amount: amt(v, "amount")?,
            proof: v["proof"]
                .as_array()
                .ok_or("proof")?
                .iter()
                .map(|st| Ok(ProofStep { side: u64f(st, "side")? as u8, sibling: hex32(st, "sibling")? }))
                .collect::<Result<_, String>>()?,
        },
        "distribution_reclaim" => DistributionReclaim { dist_id: hex32(v, "dist_id")? },
        "validator_create" => ValidatorCreate { consensus_pubkey: b64k(v, "consensus_pubkey")?, self_bond: amt(v, "self_bond")?, moniker: s(v, "moniker")?.into() },
        "validator_bond" => ValidatorBond { amount: amt(v, "amount")? },
        "validator_unbond" => ValidatorUnbond { amount: amt(v, "amount")? },
        "validator_unjail" => ValidatorUnjail,
        "validator_rotate_key" => ValidatorRotateKey { new_consensus_pubkey: b64k(v, "new_consensus_pubkey")? },
        "gov_propose" => {
            let pr = v.get("proposal").ok_or("proposal")?;
            let kind = match s(pr, "kind")? {
                "add_authority" => GovKind::AddAuthority {
                    operator: addr(p, pr, "operator")?,
                    consensus_pubkey: b64k(pr, "consensus_pubkey")?,
                    power: u64f(pr, "power")?,
                    moniker: s(pr, "moniker")?.into(),
                },
                "remove_authority" => GovKind::RemoveAuthority { operator: addr(p, pr, "operator")? },
                "protocol_upgrade" => GovKind::ProtocolUpgrade {
                    name: s(pr, "name")?.into(),
                    protocol_version: u64f(pr, "protocol_version")? as u16,
                    activation_height: u64f(pr, "activation_height")?,
                },
                "text" => GovKind::Text { title: s(pr, "title")?.into(), uri: pr.get("uri").and_then(|x| x.as_str()).unwrap_or("").into() },
                k => return Err(format!("unknown proposal kind {k}")),
            };
            GovPropose { kind, expiry_height: u64f(v, "expiry_height")? }
        }
        "gov_approve" => GovApprove { proposal_id: u64f(v, "proposal_id")? },
        t if t.starts_with("nft_") => Nft(nft_action_from_json(p, t, v)?),
        other => return Err(format!("unknown action type {other:?}")),
    })
}

// ------------------------------------------------------------------ collections module

use crate::nft::*;

pub fn metadata_json(m: &MetadataRef) -> Value {
    json!({"uri": m.uri, "sha256": hex::encode(m.hash)})
}

pub fn spec_json(p: &ChainParams, s: &CollectionSpec) -> Value {
    json!({
        "slug": s.slug, "name": s.name, "collection_metadata": metadata_json(&s.collection_metadata),
        "max_supply": s.max_supply.map(|m| m.to_string()),
        "mint_authority": opt_addr(p, &s.mint_authority),
        "metadata_policy": policy_name(s.metadata_policy),
        "metadata_admin": opt_addr(p, &s.metadata_admin),
        "admin": opt_addr(p, &s.admin),
        "pausable": s.flags & CFLAG_PAUSABLE != 0,
        "forced_transfer": s.flags & CFLAG_FORCED_TRANSFER != 0,
        "owner_burn": s.flags & CFLAG_OWNER_BURN != 0,
        "transfer_policy": if s.transfer_policy == TRANSFER_NONE { "non_transferable" } else { "transferable" },
        "royalty": s.royalty.as_ref().map(|r| json!({"recipient": p.addr(&r.recipient), "bps": r.bps})),
        "rights_holder": s.rights_holder,
        "rights": metadata_json(&s.rights),
    })
}

pub fn policy_name(x: u8) -> &'static str {
    match x {
        POLICY_MUTABLE => "mutable",
        POLICY_FREEZABLE => "freezable",
        POLICY_IMMUTABLE => "immutable",
        _ => "unknown",
    }
}

fn item_json(p: &ChainParams, i: &MintItem) -> Value {
    json!({"token_id": i.token_id.to_string(), "to": p.addr(&i.to), "metadata": metadata_json(&i.metadata)})
}

pub fn nft_action_json(p: &ChainParams, a: &NftAction) -> Value {
    use NftAction::*;
    match a {
        CollectionCreate(s) => spec_json(p, s),
        Mint { collection, item } => json!({"collection": p.collection(collection), "item": item_json(p, item)}),
        MintBatch { collection, items } => json!({"collection": p.collection(collection), "items": items.iter().map(|i| item_json(p, i)).collect::<Vec<_>>()}),
        Transfer { collection, token_id, to } => json!({"collection": p.collection(collection), "token_id": token_id.to_string(), "to": p.addr(to)}),
        Approve { collection, token_id, approved, expiry_height } => json!({"collection": p.collection(collection), "token_id": token_id.to_string(), "approved": opt_addr(p, approved), "expiry_height": expiry_height}),
        SetOperator { collection, operator, approved, expiry_height } => json!({"collection": p.collection(collection), "operator": p.addr(operator), "approved": approved, "expiry_height": expiry_height}),
        Burn { collection, token_id } => json!({"collection": p.collection(collection), "token_id": token_id.to_string()}),
        UpdateMetadata { collection, token_id, metadata, expected_revision } => json!({"collection": p.collection(collection), "token_id": token_id.to_string(), "metadata": metadata_json(metadata), "expected_revision": expected_revision}),
        FreezeMetadata { collection, scope, expected } => json!({"collection": p.collection(collection),
            "scope": match scope { FreezeScope::Token(t) => json!({"token_id": t.to_string()}), FreezeScope::Collection => json!("collection") },
            "expected": hex::encode(expected)}),
        SetPaused { collection, paused } => json!({"collection": p.collection(collection), "paused": paused}),
        SetRole { collection, role, new } => json!({"collection": p.collection(collection), "role": match *role { ROLE_ADMIN => "admin", ROLE_MINT_AUTHORITY => "mint_authority", ROLE_METADATA_ADMIN => "metadata_admin", ROLE_ROYALTY_RECIPIENT => "royalty_recipient", _ => "unknown" }, "new": opt_addr(p, new)}),
        ForceTransfer { collection, token_id, to, reason_hash } => json!({"collection": p.collection(collection), "token_id": token_id.to_string(), "to": p.addr(to), "reason_hash": hex::encode(reason_hash)}),
        ListingCreate { collection, token_id, price, currency, expiry_height } => json!({"collection": p.collection(collection), "token_id": token_id.to_string(), "price": price.to_string(), "currency": asset_json(p, currency), "expiry_height": expiry_height}),
        ListingCancel { listing_id } => json!({"listing_id": hex::encode(listing_id)}),
        ListingBuy { listing_id, price, currency } => json!({"listing_id": hex::encode(listing_id), "price": price.to_string(), "currency": asset_json(p, currency)}),
        DropCreate { collection, merkle_root, claim_deadline_height, max_claims } => json!({"collection": p.collection(collection), "merkle_root": hex::encode(merkle_root), "claim_deadline_height": claim_deadline_height, "max_claims": max_claims}),
        DropClaim { drop_id, index, item_token_id, metadata, proof } => json!({"drop_id": hex::encode(drop_id), "index": index, "token_id": item_token_id.to_string(), "metadata": metadata_json(metadata),
            "proof": proof.iter().map(|s| json!({"side": s.side, "sibling": hex::encode(s.sibling)})).collect::<Vec<_>>()}),
    }
}

fn coll(p: &ChainParams, v: &Value, k: &str) -> Result<[u8; 20], String> {
    p.parse_collection(s(v, k)?).map_err(|e| format!("{k}: {e}"))
}
fn meta(v: &Value, k: &str) -> Result<MetadataRef, String> {
    let m = v.get(k).ok_or(format!("missing object {k:?}"))?;
    Ok(MetadataRef { uri: s(m, "uri")?.into(), hash: hex32(m, "sha256")? })
}
fn item(p: &ChainParams, v: &Value) -> Result<MintItem, String> {
    Ok(MintItem { token_id: u64f(v, "token_id")?, to: addr(p, v, "to")?, metadata: meta(v, "metadata")? })
}
fn asset(p: &ChainParams, v: &Value, k: &str) -> Result<AssetId, String> {
    Ok(match v.get(k).and_then(|x| x.as_str()).unwrap_or("native") {
        "native" => AssetId::Native,
        t => AssetId::Token(p.parse_token(t)?),
    })
}
fn flag(v: &Value, k: &str) -> bool {
    v.get(k).and_then(|x| x.as_bool()).unwrap_or(false)
}

pub fn nft_action_from_json(p: &ChainParams, t: &str, v: &Value) -> Result<NftAction, String> {
    use NftAction::*;
    Ok(match t {
        "nft_collection_create" => {
            let mut flags = 0;
            if flag(v, "pausable") {
                flags |= CFLAG_PAUSABLE;
            }
            if flag(v, "forced_transfer") {
                flags |= CFLAG_FORCED_TRANSFER;
            }
            if flag(v, "owner_burn") {
                flags |= CFLAG_OWNER_BURN;
            }
            let policy = match s(v, "metadata_policy")? {
                "mutable" => POLICY_MUTABLE,
                "freezable" => POLICY_FREEZABLE,
                "immutable" => POLICY_IMMUTABLE,
                x => return Err(format!("metadata_policy {x:?} must be mutable|freezable|immutable")),
            };
            let transfer_policy = match v.get("transfer_policy").and_then(|x| x.as_str()).unwrap_or("transferable") {
                "transferable" => TRANSFER_FREE,
                "non_transferable" => TRANSFER_NONE,
                x => return Err(format!("transfer_policy {x:?} must be transferable|non_transferable")),
            };
            let royalty = match v.get("royalty") {
                None | Some(Value::Null) => None,
                Some(r) => Some(Royalty { recipient: addr(p, r, "recipient")?, bps: u64f(r, "bps")? as u16 }),
            };
            CollectionCreate(CollectionSpec {
                slug: s(v, "slug")?.into(),
                name: s(v, "name")?.into(),
                collection_metadata: meta(v, "collection_metadata")?,
                max_supply: match v.get("max_supply") {
                    None | Some(Value::Null) => None,
                    _ => Some(u64f(v, "max_supply")?),
                },
                mint_authority: opt_addr_p(p, v, "mint_authority")?,
                metadata_policy: policy,
                metadata_admin: opt_addr_p(p, v, "metadata_admin")?,
                admin: opt_addr_p(p, v, "admin")?,
                flags,
                transfer_policy,
                royalty,
                rights_holder: s(v, "rights_holder")?.into(),
                rights: meta(v, "rights")?,
            })
        }
        "nft_mint" => Mint { collection: coll(p, v, "collection")?, item: item(p, v.get("item").ok_or("item")?)? },
        "nft_mint_batch" => MintBatch {
            collection: coll(p, v, "collection")?,
            items: v["items"].as_array().ok_or("items")?.iter().map(|i| item(p, i)).collect::<Result<_, _>>()?,
        },
        "nft_transfer" => Transfer { collection: coll(p, v, "collection")?, token_id: u64f(v, "token_id")?, to: addr(p, v, "to")? },
        "nft_approve" => Approve {
            collection: coll(p, v, "collection")?,
            token_id: u64f(v, "token_id")?,
            approved: opt_addr_p(p, v, "approved")?,
            expiry_height: v.get("expiry_height").and_then(|x| x.as_u64()).unwrap_or(0),
        },
        "nft_set_operator" => SetOperator {
            collection: coll(p, v, "collection")?,
            operator: addr(p, v, "operator")?,
            approved: v["approved"].as_bool().ok_or("approved")?,
            expiry_height: v.get("expiry_height").and_then(|x| x.as_u64()).unwrap_or(0),
        },
        "nft_burn" => Burn { collection: coll(p, v, "collection")?, token_id: u64f(v, "token_id")? },
        "nft_update_metadata" => UpdateMetadata {
            collection: coll(p, v, "collection")?,
            token_id: u64f(v, "token_id")?,
            metadata: meta(v, "metadata")?,
            expected_revision: u64f(v, "expected_revision")? as u32,
        },
        "nft_freeze_metadata" => FreezeMetadata {
            collection: coll(p, v, "collection")?,
            scope: match v.get("scope") {
                Some(Value::String(x)) if x == "collection" => FreezeScope::Collection,
                Some(sc @ Value::Object(_)) => FreezeScope::Token(u64f(sc, "token_id")?),
                _ => return Err("scope must be \"collection\" or {\"token_id\": n}".into()),
            },
            expected: hex32(v, "expected")?,
        },
        "nft_set_paused" => SetPaused { collection: coll(p, v, "collection")?, paused: v["paused"].as_bool().ok_or("paused")? },
        "nft_set_role" => SetRole {
            collection: coll(p, v, "collection")?,
            role: match s(v, "role")? {
                "admin" => ROLE_ADMIN,
                "mint_authority" => ROLE_MINT_AUTHORITY,
                "metadata_admin" => ROLE_METADATA_ADMIN,
                "royalty_recipient" => ROLE_ROYALTY_RECIPIENT,
                x => return Err(format!("unknown role {x:?}")),
            },
            new: opt_addr_p(p, v, "new")?,
        },
        "nft_force_transfer" => ForceTransfer { collection: coll(p, v, "collection")?, token_id: u64f(v, "token_id")?, to: addr(p, v, "to")?, reason_hash: hex32(v, "reason_hash")? },
        "nft_listing_create" => ListingCreate {
            collection: coll(p, v, "collection")?,
            token_id: u64f(v, "token_id")?,
            price: amt(v, "price")?,
            currency: asset(p, v, "currency")?,
            expiry_height: u64f(v, "expiry_height")?,
        },
        "nft_listing_cancel" => ListingCancel { listing_id: hex32(v, "listing_id")? },
        "nft_listing_buy" => ListingBuy { listing_id: hex32(v, "listing_id")?, price: amt(v, "price")?, currency: asset(p, v, "currency")? },
        "nft_drop_create" => DropCreate {
            collection: coll(p, v, "collection")?,
            merkle_root: hex32(v, "merkle_root")?,
            claim_deadline_height: u64f(v, "claim_deadline_height")?,
            max_claims: u64f(v, "max_claims")? as u32,
        },
        "nft_drop_claim" => DropClaim {
            drop_id: hex32(v, "drop_id")?,
            index: u64f(v, "index")? as u32,
            item_token_id: u64f(v, "token_id")?,
            metadata: meta(v, "metadata")?,
            proof: v["proof"]
                .as_array()
                .ok_or("proof")?
                .iter()
                .map(|st| Ok(ProofStep { side: u64f(st, "side")? as u8, sibling: hex32(st, "sibling")? }))
                .collect::<Result<_, String>>()?,
        },
        other => return Err(format!("unknown action type {other:?}")),
    })
}
