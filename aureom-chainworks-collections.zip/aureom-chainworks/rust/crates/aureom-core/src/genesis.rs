//! Genesis document, validation, hash and initial state (PROTOCOL.md section 9).

use crate::crypto::{bech32_decode20, bech32_encode, hash_domain, is_valid_pubkey, Addr, Hash32};
use crate::state::{keys, State};
use crate::types::*;
use base64::Engine;
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::collections::BTreeSet;

/// u128 amount serialised as a decimal string.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default, PartialOrd, Ord)]
pub struct Amount(pub u128);

impl Serialize for Amount {
    fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.0.to_string())
    }
}
impl<'de> Deserialize<'de> for Amount {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let s = String::deserialize(d)?;
        if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) || (s.len() > 1 && s.starts_with('0')) {
            return Err(serde::de::Error::custom(format!("invalid amount string {s:?}")));
        }
        s.parse::<u128>().map(Amount).map_err(|_| serde::de::Error::custom("amount exceeds u128"))
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Genesis {
    pub genesis_format: u32,
    pub protocol_version: u16,
    pub network_name: String,
    pub chain_id: String,
    pub genesis_time_ms: u64,
    pub consensus: ConsensusConfig,
    pub native_asset: NativeAsset,
    pub monetary_policy: MonetaryPolicy,
    pub fee_policy: FeePolicy,
    pub limits: Limits,
    pub allocations: Vec<Allocation>,
    #[serde(default)]
    pub treasuries: Vec<TreasurySpec>,
    #[serde(default)]
    pub validators: Vec<GenesisValidator>,
    pub governance: GovernanceParams,
    #[serde(default)]
    pub upgrades: Vec<UpgradeSpec>,
    /// Optional native modules. Absent in genesis documents that predate them, so their
    /// genesis hashes are unchanged; software without module support rejects the field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub modules: Option<Modules>,
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct Modules {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub collections: Option<CollectionsModuleSpec>,
}

/// `modules.collections` (docs/COLLECTIONS-PROTOCOL.md).
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CollectionsModuleSpec {
    #[serde(default)]
    pub activation_height: u64,
    /// Enables the fixed-price demonstration marketplace (tags 72–74).
    #[serde(default)]
    pub marketplace: bool,
    #[serde(default)]
    pub marketplace_fee_bps: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub marketplace_fee_recipient: Option<String>,
}

/// Decoded collections-module parameters.
#[derive(Clone, Debug)]
pub struct CollectionsParams {
    pub activation_height: u64,
    pub marketplace: bool,
    pub fee_bps: u32,
    pub fee_recipient: Option<Addr>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ConsensusConfig {
    pub profile: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pow: Option<PowParams>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pos: Option<PosParams>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub poa: Option<PoaParams>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PowParams {
    /// 64 hex chars, big-endian U256
    pub initial_target: String,
    pub pow_limit: String,
    pub target_block_time_ms: u64,
    pub retarget_interval: u64,
    pub max_future_drift_ms: u64,
    pub coinbase_maturity: u64,
    pub confirmations_recommended: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PosParams {
    pub epoch_length: u64,
    pub unbonding_period_blocks: u64,
    pub min_self_bond: Amount,
    pub max_validators: u32,
    pub power_unit: Amount,
    pub slash_double_sign_bps: u32,
    pub slash_downtime_bps: u32,
    pub downtime_window: u64,
    pub downtime_max_missed: u32,
    pub jail_duration_blocks: u64,
    pub evidence_max_age_blocks: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PoaParams {
    pub evidence_max_age_blocks: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NativeAsset {
    pub name: String,
    pub ticker: String,
    pub decimals: u8,
    pub address_hrp: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MonetaryPolicy {
    /// "fixed" | "scheduled" | "authority"
    pub kind: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_supply: Option<Amount>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub scheduled: Option<ScheduledIssuance>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub authority: Option<AuthorityIssuance>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ScheduledIssuance {
    pub initial_block_reward: Amount,
    pub halving_interval_blocks: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AuthorityIssuance {
    pub mint_authority: String,
    pub max_mint_per_window: Amount,
    pub window_blocks: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FeePolicy {
    pub base_fee: Amount,
    pub per_byte_fee: Amount,
    pub burn_bps: u32,
    /// "proposer" | "treasury"
    pub recipient: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Limits {
    pub max_block_bytes: u64,
    pub max_block_txs: u32,
    pub max_tx_bytes: u32,
    pub max_memo_bytes: u32,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Allocation {
    pub address: String,
    pub amount: Amount,
    #[serde(default)]
    pub label: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub vesting: Option<VestingSpec>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VestingSpec {
    pub start_height: u64,
    pub cliff_height: u64,
    pub end_height: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TreasurySpec {
    pub label: String,
    pub signers: Vec<String>,
    pub threshold: u8,
    pub amount: Amount,
    /// Derived address; if present it must match the derivation.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub address: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GenesisValidator {
    pub operator: String,
    /// base64 Ed25519 public key (CometBFT consensus key)
    pub consensus_pubkey: String,
    pub moniker: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub self_bond: Option<Amount>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub power: Option<u64>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GovernanceParams {
    pub approval_threshold_num: u64,
    pub approval_threshold_den: u64,
    pub proposal_max_ttl_blocks: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UpgradeSpec {
    pub name: String,
    pub protocol_version: u16,
    pub activation_height: u64,
}

// ------------------------------------------------------------------ canonical JSON

/// RFC 8785 canonical JSON for the restricted genesis domain (ASCII strings, integers).
pub fn jcs(v: &serde_json::Value) -> Result<String, String> {
    use serde_json::Value;
    Ok(match v {
        Value::Null => "null".into(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => {
            if n.is_f64() {
                return Err("floating point numbers are not allowed in genesis".into());
            }
            n.to_string()
        }
        Value::String(s) => {
            if !s.bytes().all(|b| (0x20..0x7f).contains(&b)) {
                return Err(format!("non-printable-ASCII string in genesis: {s:?}"));
            }
            serde_json::to_string(s).unwrap()
        }
        Value::Array(a) => {
            let parts: Result<Vec<_>, _> = a.iter().map(jcs).collect();
            format!("[{}]", parts?.join(","))
        }
        Value::Object(m) => {
            let mut keys: Vec<&String> = m.keys().collect();
            keys.sort();
            let mut parts = vec![];
            for k in keys {
                parts.push(format!("{}:{}", serde_json::to_string(k).unwrap(), jcs(&m[k])?));
            }
            format!("{{{}}}", parts.join(","))
        }
    })
}

pub fn genesis_hash_of_value(v: &serde_json::Value) -> Result<Hash32, String> {
    Ok(hash_domain("AUREOM/GENESIS/v1", jcs(v)?.as_bytes()))
}

/// A loaded genesis: the parsed document plus its hash and decoded parameters.
#[derive(Clone, Debug)]
pub struct ChainParams {
    pub doc: Genesis,
    pub hash: Hash32,
    pub profile: Profile,
    pub hrp: String,
    pub max_supply: u128,
    pub treasury_addrs: Vec<Addr>,
    pub mint_authority: Option<Addr>,
    pub pow_initial_target: crate::U256,
    pub pow_limit: crate::U256,
    pub collections: Option<CollectionsParams>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Profile {
    Pow,
    Pos,
    Poa,
}

impl Profile {
    pub fn as_str(&self) -> &'static str {
        match self {
            Profile::Pow => "pow",
            Profile::Pos => "pos",
            Profile::Poa => "poa",
        }
    }
    pub fn is_bft(&self) -> bool {
        !matches!(self, Profile::Pow)
    }
}

pub fn treasury_address(index: u64) -> Addr {
    let mut d = vec![0u8; 20];
    d.extend_from_slice(&index.to_be_bytes());
    hash_domain("AUREOM/MSIG/v1", &d)[..20].try_into().unwrap()
}

#[derive(Debug, Default, Serialize)]
pub struct ValidationReport {
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
}

impl ValidationReport {
    pub fn ok(&self) -> bool {
        self.errors.is_empty()
    }
}

fn printable(s: &str) -> bool {
    s.bytes().all(|b| (0x20..0x7f).contains(&b))
}

pub fn parse_hex_u256(s: &str) -> Result<crate::U256, String> {
    let b = hex::decode(s).map_err(|e| format!("bad hex: {e}"))?;
    if b.len() != 32 {
        return Err("expected 32-byte hex".into());
    }
    Ok(crate::U256::from_big_endian(&b))
}

pub fn decode_b64_pubkey(s: &str) -> Result<[u8; 32], String> {
    let b = base64::engine::general_purpose::STANDARD.decode(s).map_err(|e| format!("bad base64: {e}"))?;
    b.try_into().map_err(|_| "consensus pubkey must be 32 bytes".to_string())
}

impl ChainParams {
    /// Parse and fully validate a genesis document. Fails on any validation error.
    pub fn from_json_str(s: &str) -> Result<ChainParams, String> {
        let value: serde_json::Value = serde_json::from_str(s).map_err(|e| format!("genesis json: {e}"))?;
        Self::from_value(&value)
    }

    pub fn from_value(value: &serde_json::Value) -> Result<ChainParams, String> {
        let hash = genesis_hash_of_value(value)?;
        let doc: Genesis = serde_json::from_value(value.clone()).map_err(|e| format!("genesis schema: {e}"))?;
        let rep = validate(&doc);
        if !rep.ok() {
            return Err(format!("genesis invalid: {}", rep.errors.join("; ")));
        }
        let profile = match doc.consensus.profile.as_str() {
            "pow" => Profile::Pow,
            "pos" => Profile::Pos,
            _ => Profile::Poa,
        };
        let hrp = doc.native_asset.address_hrp.clone();
        let treasury_addrs = (0..doc.treasuries.len() as u64).map(treasury_address).collect();
        let mint_authority = doc
            .monetary_policy
            .authority
            .as_ref()
            .map(|a| bech32_decode20(&hrp, &a.mint_authority).unwrap());
        let (t, l) = match &doc.consensus.pow {
            Some(p) => (parse_hex_u256(&p.initial_target)?, parse_hex_u256(&p.pow_limit)?),
            None => (crate::U256::zero(), crate::U256::zero()),
        };
        let collections = doc.modules.as_ref().and_then(|m| m.collections.as_ref()).map(|c| CollectionsParams {
            activation_height: c.activation_height,
            marketplace: c.marketplace,
            fee_bps: c.marketplace_fee_bps,
            fee_recipient: c.marketplace_fee_recipient.as_ref().map(|a| bech32_decode20(&hrp, a).unwrap()),
        });
        Ok(ChainParams {
            collections,
            max_supply: doc.monetary_policy.max_supply.map(|a| a.0).unwrap_or(u128::MAX),
            doc,
            hash,
            profile,
            hrp,
            treasury_addrs,
            mint_authority,
            pow_initial_target: t,
            pow_limit: l,
        })
    }

    pub fn addr(&self, a: &Addr) -> String {
        bech32_encode(&self.hrp, a)
    }
    pub fn token_hrp(&self) -> String {
        format!("{}tok", self.hrp)
    }
    pub fn token(&self, t: &Addr) -> String {
        bech32_encode(&self.token_hrp(), t)
    }
    pub fn parse_addr(&self, s: &str) -> Result<Addr, String> {
        bech32_decode20(&self.hrp, s).map_err(|e| e.to_string())
    }
    pub fn parse_token(&self, s: &str) -> Result<Addr, String> {
        bech32_decode20(&self.token_hrp(), s).map_err(|e| e.to_string())
    }
    /// Collection identifiers are displayed with HRP `address_hrp + "col"`.
    pub fn collection_hrp(&self) -> String {
        format!("{}col", self.hrp)
    }
    pub fn collection(&self, c: &Addr) -> String {
        bech32_encode(&self.collection_hrp(), c)
    }
    pub fn parse_collection(&self, s: &str) -> Result<Addr, String> {
        bech32_decode20(&self.collection_hrp(), s).map_err(|e| e.to_string())
    }
    pub fn pow(&self) -> &PowParams {
        self.doc.consensus.pow.as_ref().expect("pow params")
    }
    pub fn pos(&self) -> &PosParams {
        self.doc.consensus.pos.as_ref().expect("pos params")
    }
    pub fn chain_id(&self) -> &str {
        &self.doc.chain_id
    }
    pub fn fee_treasury(&self) -> Option<Addr> {
        if self.doc.fee_policy.recipient == "treasury" {
            self.treasury_addrs.first().copied()
        } else {
            None
        }
    }

    /// Build the genesis state (PROTOCOL.md 9.2).
    pub fn genesis_state(&self) -> State {
        let mut st = State::new();
        let mut ov = st.overlay();
        ov.put(keys::genesis(), self.hash.to_vec());
        let mut total: u128 = 0;
        for a in &self.doc.allocations {
            let addr = self.parse_addr(&a.address).unwrap();
            let mut acct = Account { balance: a.amount.0, ..Default::default() };
            if let Some(v) = &a.vesting {
                acct.vesting.push(Vesting {
                    total: a.amount.0,
                    start_height: v.start_height,
                    cliff_height: v.cliff_height,
                    end_height: v.end_height,
                });
            }
            total += a.amount.0;
            ov.put_account(&addr, &acct);
        }
        for (i, t) in self.doc.treasuries.iter().enumerate() {
            let addr = treasury_address(i as u64);
            let signers = t.signers.iter().map(|s| self.parse_addr(s).unwrap()).collect();
            ov.put_multisig(&addr, &Multisig { signers, threshold: t.threshold, next_proposal_id: 0 });
            if t.amount.0 > 0 {
                ov.put_account(&addr, &Account { balance: t.amount.0, ..Default::default() });
            }
            total += t.amount.0;
        }
        let mut valset = vec![];
        for v in &self.doc.validators {
            let op = self.parse_addr(&v.operator).unwrap();
            let pk = decode_b64_pubkey(&v.consensus_pubkey).unwrap();
            let bonded = v.self_bond.map(|a| a.0).unwrap_or(0);
            total += bonded;
            let val = Validator {
                operator: op,
                consensus_pubkey: pk,
                moniker: v.moniker.clone(),
                bonded,
                fixed_power: v.power.unwrap_or(0),
                jailed_until: 0,
                tombstoned: false,
                missed_in_window: 0,
                window_start: 0,
                created_height: 0,
                removed: false,
            };
            let power = match self.profile {
                Profile::Pos => (bonded / self.pos().power_unit.0) as u64,
                _ => val.fixed_power,
            };
            valset.push((pk, power));
            ov.put_validator(&val);
            ov.put(keys::consaddr(&crate::crypto::comet_address(&pk)), op.to_vec());
        }
        if self.profile.is_bft() {
            valset.sort();
            ov.put(keys::valset(), ValSet(valset).encode_vec());
        }
        let ups = self
            .doc
            .upgrades
            .iter()
            .map(|u| ScheduledUpgrade {
                name: u.name.clone(),
                protocol_version: u.protocol_version,
                activation_height: u.activation_height,
            })
            .collect();
        ov.put_gov_state(&GovState { next_id: 0, upgrades: ups });
        ov.put_supply(&Supply { genesis: total, minted: 0, burned: 0, total });
        let cs = ov.into_changes();
        st.apply(&cs);
        st
    }
}

trait EncodeVec {
    fn encode_vec(&self) -> Vec<u8>;
}
impl<T: crate::codec::Encode> EncodeVec for T {
    fn encode_vec(&self) -> Vec<u8> {
        self.encode()
    }
}

/// Full structural and economic validation of a genesis document.
pub fn validate(g: &Genesis) -> ValidationReport {
    let mut r = ValidationReport::default();
    let mut err = |s: String| r.errors.push(s);
    if g.genesis_format != 1 {
        err(format!("unsupported genesis_format {}", g.genesis_format));
    }
    if g.protocol_version != PROTOCOL_VERSION {
        err(format!("unsupported protocol_version {}", g.protocol_version));
    }
    let cid = &g.chain_id;
    if cid.is_empty()
        || cid.len() > MAX_CHAIN_ID_LEN
        || !cid.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
        || !cid.as_bytes()[0].is_ascii_lowercase()
    {
        err(format!("chain_id {cid:?} must match ^[a-z][a-z0-9-]{{0,63}}$"));
    }
    if g.network_name.is_empty() || g.network_name.len() > MAX_NAME_LEN || !printable(&g.network_name) {
        err("network_name must be 1..64 printable ASCII".into());
    }
    let na = &g.native_asset;
    if na.decimals > MAX_TOKEN_DECIMALS {
        err("native_asset.decimals must be <= 18".into());
    }
    if na.ticker.is_empty() || na.ticker.len() > MAX_SYMBOL_LEN || !na.ticker.bytes().all(|b| b.is_ascii_uppercase() || b.is_ascii_digit()) {
        err("native_asset.ticker must be 1..12 of [A-Z0-9] (a display label, not a unique identifier)".into());
    }
    if na.name.is_empty() || na.name.len() > MAX_NAME_LEN || !printable(&na.name) {
        err("native_asset.name must be 1..64 printable ASCII".into());
    }
    let hrp = &na.address_hrp;
    if hrp.is_empty() || hrp.len() > 10 || !hrp.bytes().all(|b| b.is_ascii_lowercase()) {
        err("native_asset.address_hrp must be 1..10 lowercase letters".into());
        return r;
    }
    let l = &g.limits;
    if l.max_tx_bytes == 0 || l.max_tx_bytes > 65_536 {
        err("limits.max_tx_bytes must be in 1..=65536".into());
    }
    if l.max_block_bytes < l.max_tx_bytes as u64 || l.max_block_bytes > 4_194_304 {
        err("limits.max_block_bytes must be >= max_tx_bytes and <= 4194304".into());
    }
    if l.max_block_txs == 0 || l.max_block_txs > 10_000 {
        err("limits.max_block_txs must be in 1..=10000".into());
    }
    if l.max_memo_bytes as usize > MAX_MEMO_BYTES {
        err("limits.max_memo_bytes must be <= 256".into());
    }
    let fp = &g.fee_policy;
    if fp.burn_bps > 10_000 {
        err("fee_policy.burn_bps must be <= 10000".into());
    }
    if fp.base_fee.0 > u64::MAX as u128 || fp.per_byte_fee.0 > u64::MAX as u128 {
        err("fee_policy fees must fit u64".into());
    }
    if fp.recipient != "proposer" && fp.recipient != "treasury" {
        err("fee_policy.recipient must be proposer|treasury".into());
    }
    if fp.recipient == "treasury" && g.treasuries.is_empty() {
        err("fee_policy.recipient=treasury requires a treasury".into());
    }
    if fp.base_fee.0 == 0 && fp.per_byte_fee.0 == 0 {
        r.warnings.push("zero fees: mempool spam is limited only by node policy".into());
    }

    // ---- allocations
    let mut seen = BTreeSet::new();
    let mut total: u128 = 0;
    let mut overflow = false;
    let mut add = |total: &mut u128, x: u128| match total.checked_add(x) {
        Some(t) => *total = t,
        None => overflow = true,
    };
    let mut errors = vec![];
    for (i, a) in g.allocations.iter().enumerate() {
        match bech32_decode20(hrp, &a.address) {
            Ok(addr) => {
                if !seen.insert(addr) {
                    errors.push(format!("allocations[{i}]: duplicate recipient {}", a.address));
                }
            }
            Err(e) => errors.push(format!("allocations[{i}]: invalid address {}: {e}", a.address)),
        }
        if a.amount.0 == 0 {
            errors.push(format!("allocations[{i}]: zero amount"));
        }
        if !printable(&a.label) || a.label.len() > MAX_NAME_LEN {
            errors.push(format!("allocations[{i}]: label must be <= 64 printable ASCII"));
        }
        if let Some(v) = &a.vesting {
            if !(v.start_height <= v.cliff_height && v.cliff_height <= v.end_height && v.start_height < v.end_height) {
                errors.push(format!("allocations[{i}]: vesting requires start <= cliff <= end and start < end"));
            }
        }
        add(&mut total, a.amount.0);
    }
    for (i, t) in g.treasuries.iter().enumerate() {
        let derived = bech32_encode(hrp, &treasury_address(i as u64));
        if let Some(addr) = &t.address {
            if addr != &derived {
                errors.push(format!("treasuries[{i}]: address {addr} does not match derived {derived}"));
            }
        }
        if !seen.insert(treasury_address(i as u64)) {
            errors.push(format!("treasuries[{i}]: address collides with an allocation"));
        }
        let mut ss = BTreeSet::new();
        for s in &t.signers {
            match bech32_decode20(hrp, s) {
                Ok(a) => {
                    if !ss.insert(a) {
                        errors.push(format!("treasuries[{i}]: duplicate signer {s}"));
                    }
                }
                Err(e) => errors.push(format!("treasuries[{i}]: invalid signer {s}: {e}")),
            }
        }
        if t.signers.is_empty() || t.signers.len() > MAX_MSIG_SIGNERS {
            errors.push(format!("treasuries[{i}]: 1..16 signers required"));
        }
        if t.threshold == 0 || t.threshold as usize > t.signers.len() {
            errors.push(format!("treasuries[{i}]: threshold must be in 1..=signers"));
        }
        if t.threshold == 1 && t.signers.len() > 1 {
            r.warnings.push(format!("treasuries[{i}]: threshold 1 lets any single signer spend"));
        }
        add(&mut total, t.amount.0);
    }

    // ---- consensus profile
    let profile = g.consensus.profile.as_str();
    match profile {
        "pow" => match &g.consensus.pow {
            None => errors.push("consensus.pow parameters required".into()),
            Some(p) => {
                match (parse_hex_u256(&p.initial_target), parse_hex_u256(&p.pow_limit)) {
                    (Ok(t), Ok(lim)) => {
                        if t.is_zero() || t > lim {
                            errors.push("pow: need 0 < initial_target <= pow_limit".into());
                        }
                    }
                    (Err(e), _) | (_, Err(e)) => errors.push(format!("pow target: {e}")),
                }
                if p.target_block_time_ms < 100 {
                    errors.push("pow.target_block_time_ms must be >= 100".into());
                }
                if p.retarget_interval < 2 {
                    errors.push("pow.retarget_interval must be >= 2".into());
                }
                if p.coinbase_maturity == 0 {
                    r.warnings.push("pow.coinbase_maturity = 0: rewards spendable before they can be reorganised away".into());
                }
                if !g.validators.is_empty() {
                    errors.push("pow networks have no validator set; remove validators".into());
                }
                if g.consensus.pos.is_some() || g.consensus.poa.is_some() {
                    errors.push("only the selected profile's parameters may be present".into());
                }
            }
        },
        "pos" | "poa" => {
            if g.consensus.pow.is_some() {
                errors.push("only the selected profile's parameters may be present".into());
            }
            if g.validators.is_empty() {
                errors.push(format!("{profile}: at least one genesis validator required"));
            }
            let mut ops = BTreeSet::new();
            let mut pks = BTreeSet::new();
            let mut total_power: u128 = 0;
            for (i, v) in g.validators.iter().enumerate() {
                if bech32_decode20(hrp, &v.operator).map(|a| !ops.insert(a)).unwrap_or_else(|_| {
                    errors.push(format!("validators[{i}]: invalid operator address"));
                    false
                }) {
                    errors.push(format!("validators[{i}]: duplicate operator"));
                }
                match decode_b64_pubkey(&v.consensus_pubkey) {
                    Ok(pk) => {
                        if !is_valid_pubkey(&pk) {
                            errors.push(format!("validators[{i}]: invalid ed25519 key"));
                        }
                        if !pks.insert(pk) {
                            errors.push(format!("validators[{i}]: duplicate consensus key"));
                        }
                    }
                    Err(e) => errors.push(format!("validators[{i}]: {e}")),
                }
                if !printable(&v.moniker) || v.moniker.len() > MAX_NAME_LEN {
                    errors.push(format!("validators[{i}]: bad moniker"));
                }
                if profile == "pos" {
                    if v.power.is_some() {
                        errors.push(format!("validators[{i}]: pos power derives from self_bond; remove power"));
                    }
                    match (v.self_bond, &g.consensus.pos) {
                        (Some(b), Some(p)) => {
                            if b.0 < p.min_self_bond.0 {
                                errors.push(format!("validators[{i}]: self_bond below min_self_bond"));
                            }
                            if p.power_unit.0 > 0 {
                                total_power += b.0 / p.power_unit.0;
                            }
                            add(&mut total, b.0);
                        }
                        _ => errors.push(format!("validators[{i}]: self_bond required")),
                    }
                } else {
                    if v.self_bond.is_some() {
                        errors.push(format!("validators[{i}]: poa authorities have no stake; remove self_bond"));
                    }
                    match v.power {
                        Some(p) if p > 0 => total_power += p as u128,
                        _ => errors.push(format!("validators[{i}]: power > 0 required")),
                    }
                }
            }
            if total_power > (i64::MAX / 8) as u128 {
                errors.push("total voting power exceeds CometBFT maximum".into());
            }
            let n = g.validators.len();
            if n > 0 && n < 4 {
                r.warnings.push(format!(
                    "{n} validator(s): BFT tolerates f Byzantine validators only when n >= 3f+1, so this set tolerates 0 faults"
                ));
            }
            if profile == "pos" {
                match &g.consensus.pos {
                    None => errors.push("consensus.pos parameters required".into()),
                    Some(p) => {
                        if p.power_unit.0 == 0 {
                            errors.push("pos.power_unit must be > 0".into());
                        }
                        if p.epoch_length == 0 {
                            errors.push("pos.epoch_length must be > 0".into());
                        }
                        if p.max_validators == 0 {
                            errors.push("pos.max_validators must be > 0".into());
                        }
                        if p.evidence_max_age_blocks >= p.unbonding_period_blocks {
                            errors.push("pos.evidence_max_age_blocks must be < unbonding_period_blocks (otherwise misconduct could go unpunished)".into());
                        }
                        if p.slash_double_sign_bps > 10_000 || p.slash_downtime_bps > 10_000 {
                            errors.push("pos slash bps must be <= 10000".into());
                        }
                        if p.downtime_window == 0 || p.downtime_max_missed as u64 >= p.downtime_window {
                            errors.push("pos: need 0 < downtime_max_missed < downtime_window".into());
                        }
                        if g.consensus.poa.is_some() {
                            errors.push("only the selected profile's parameters may be present".into());
                        }
                    }
                }
            } else if g.consensus.poa.is_none() || g.consensus.pos.is_some() {
                errors.push("consensus.poa parameters required (and only those)".into());
            }
        }
        other => errors.push(format!("consensus.profile {other:?} must be pow|pos|poa")),
    }

    // ---- monetary policy
    let mp = &g.monetary_policy;
    let max_supply = mp.max_supply.map(|a| a.0);
    match mp.kind.as_str() {
        "fixed" => {
            if mp.scheduled.is_some() || mp.authority.is_some() {
                errors.push("fixed supply: no scheduled or authority issuance allowed".into());
            }
            if profile == "pow" {
                r.warnings.push("fixed supply on PoW: miners are paid by fees only".into());
            }
        }
        "scheduled" => match &mp.scheduled {
            None => errors.push("scheduled policy requires monetary_policy.scheduled".into()),
            Some(s) => {
                if s.halving_interval_blocks == 0 {
                    errors.push("scheduled.halving_interval_blocks must be > 0".into());
                }
                if mp.authority.is_some() {
                    errors.push("scheduled policy must not define an authority".into());
                }
                if max_supply.is_none() {
                    r.warnings.push("scheduled issuance without max_supply: supply bounded only by the halving schedule".into());
                }
            }
        },
        "authority" => match &mp.authority {
            None => errors.push("authority policy requires monetary_policy.authority".into()),
            Some(a) => {
                match bech32_decode20(hrp, &a.mint_authority) {
                    Ok(addr) => {
                        let is_treasury = (0..g.treasuries.len() as u64).any(|i| treasury_address(i) == addr);
                        if !is_treasury {
                            r.warnings.push("mint_authority is a single key, not a genesis multisig treasury".into());
                        }
                    }
                    Err(e) => errors.push(format!("authority.mint_authority invalid: {e}")),
                }
                if a.window_blocks == 0 {
                    errors.push("authority.window_blocks must be > 0".into());
                }
                if max_supply.is_none() {
                    errors.push("authority issuance requires an explicit max_supply cap".into());
                }
                if mp.scheduled.is_some() {
                    errors.push("authority policy must not define a schedule".into());
                }
            }
        },
        k => errors.push(format!("monetary_policy.kind {k:?} must be fixed|scheduled|authority")),
    }
    if overflow {
        errors.push("allocation total overflows u128".into());
    } else if let Some(m) = max_supply {
        if total > m {
            errors.push(format!("genesis supply {total} exceeds max_supply {m}"));
        }
    }
    if total == 0 {
        r.warnings.push("genesis supply is zero".into());
    }

    let gv = &g.governance;
    if gv.approval_threshold_den == 0
        || gv.approval_threshold_num > gv.approval_threshold_den
        || (gv.approval_threshold_num as u128) * 3 < (gv.approval_threshold_den as u128) * 2
    {
        errors.push("governance approval threshold must satisfy 2/3 <= num/den <= 1".into());
    }
    for (i, u) in g.upgrades.iter().enumerate() {
        if u.protocol_version <= PROTOCOL_VERSION {
            errors.push(format!("upgrades[{i}]: protocol_version must be > {PROTOCOL_VERSION}"));
        }
    }
    if let Some(c) = g.modules.as_ref().and_then(|m| m.collections.as_ref()) {
        if c.marketplace_fee_bps > crate::nft::MAX_MARKETPLACE_FEE_BPS {
            errors.push(format!("modules.collections.marketplace_fee_bps must be <= {}", crate::nft::MAX_MARKETPLACE_FEE_BPS));
        }
        if !c.marketplace && (c.marketplace_fee_bps > 0 || c.marketplace_fee_recipient.is_some()) {
            errors.push("modules.collections: marketplace fee settings require marketplace = true".into());
        }
        match &c.marketplace_fee_recipient {
            Some(a) => {
                if let Err(e) = bech32_decode20(hrp, a) {
                    errors.push(format!("modules.collections.marketplace_fee_recipient invalid: {e}"));
                }
            }
            None if c.marketplace_fee_bps > 0 => errors.push("modules.collections.marketplace_fee_bps > 0 requires marketplace_fee_recipient".into()),
            None => {}
        }
    }
    r.errors.extend(errors);
    r
}

/// Example genesis documents (deterministic test keys) used by tests and test vectors.
pub mod tests {
    use super::*;
    use crate::crypto::test_keypair;

    pub fn dev_genesis(profile: &str) -> serde_json::Value {
        let hrp = "aurd";
        let a = |l: &str| bech32_encode(hrp, &test_keypair(l).address());
        let mut g = serde_json::json!({
            "genesis_format": 1,
            "protocol_version": 1,
            "network_name": "Test Network",
            "chain_id": format!("aureom-test-{profile}"),
            "genesis_time_ms": 1_700_000_000_000u64,
            "consensus": {"profile": profile},
            "native_asset": {"name": "Aureom Dev Coin", "ticker": "ADC", "decimals": 6, "address_hrp": hrp},
            "monetary_policy": {"kind": "scheduled", "max_supply": "21000000000000",
                "scheduled": {"initial_block_reward": "50000000", "halving_interval_blocks": 1000}},
            "fee_policy": {"base_fee": "1000", "per_byte_fee": "1", "burn_bps": 2000, "recipient": "proposer"},
            "limits": {"max_block_bytes": 1_000_000, "max_block_txs": 2000, "max_tx_bytes": 16384, "max_memo_bytes": 256},
            "allocations": [
                {"address": a("alice"), "amount": "1000000000000", "label": "alice"},
                {"address": a("bob"), "amount": "500000000000", "label": "bob"},
                {"address": a("vest"), "amount": "100000000000", "label": "team", "vesting": {"start_height": 0, "cliff_height": 10, "end_height": 110}}
            ],
            "treasuries": [{"label": "treasury", "signers": [a("t1"), a("t2"), a("t3")], "threshold": 2, "amount": "200000000000"}],
            "governance": {"approval_threshold_num": 2, "approval_threshold_den": 3, "proposal_max_ttl_blocks": 1000},
            "upgrades": []
        });
        match profile {
            "pow" => {
                g["consensus"]["pow"] = serde_json::json!({
                    "initial_target": "00ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
                    "pow_limit": "0fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
                    "target_block_time_ms": 1000, "retarget_interval": 10, "max_future_drift_ms": 15000,
                    "coinbase_maturity": 5, "confirmations_recommended": 6
                });
            }
            "pos" => {
                g["consensus"]["pos"] = serde_json::json!({
                    "epoch_length": 10, "unbonding_period_blocks": 100, "min_self_bond": "1000000",
                    "max_validators": 10, "power_unit": "1000000", "slash_double_sign_bps": 500,
                    "slash_downtime_bps": 100, "downtime_window": 20, "downtime_max_missed": 10,
                    "jail_duration_blocks": 20, "evidence_max_age_blocks": 50
                });
                let vals: Vec<_> = (0..4).map(|i| {
                    let ck = test_keypair(&format!("cons{i}")).public();
                    serde_json::json!({"operator": a(&format!("val{i}")),
                        "consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(ck),
                        "moniker": format!("val{i}"), "self_bond": "10000000"})
                }).collect();
                g["validators"] = serde_json::Value::Array(vals);
            }
            _ => {
                g["consensus"]["poa"] = serde_json::json!({"evidence_max_age_blocks": 100});
                g["monetary_policy"] = serde_json::json!({"kind": "fixed", "max_supply": "21000000000000"});
                let vals: Vec<_> = (0..4).map(|i| {
                    let ck = test_keypair(&format!("cons{i}")).public();
                    serde_json::json!({"operator": a(&format!("val{i}")),
                        "consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(ck),
                        "moniker": format!("auth{i}"), "power": 10})
                }).collect();
                g["validators"] = serde_json::Value::Array(vals);
            }
        }
        g
    }

    #[test]
    fn dev_genesis_valid_all_profiles() {
        for p in ["pow", "pos", "poa"] {
            let cp = ChainParams::from_value(&dev_genesis(p)).unwrap_or_else(|e| panic!("{p}: {e}"));
            let st = cp.genesis_state();
            assert_ne!(st.root(), [0; 32]);
        }
    }

    #[test]
    fn rejects_duplicate_and_oversupply() {
        let mut g = dev_genesis("pow");
        let first = g["allocations"][0].clone();
        g["allocations"].as_array_mut().unwrap().push(first);
        let e = ChainParams::from_value(&g).unwrap_err();
        assert!(e.contains("duplicate recipient"), "{e}");
        let mut g = dev_genesis("pow");
        g["monetary_policy"]["max_supply"] = "1".into();
        assert!(ChainParams::from_value(&g).unwrap_err().contains("exceeds max_supply"));
        let mut g = dev_genesis("pow");
        g["allocations"][0]["amount"] = "1.5".into();
        assert!(ChainParams::from_value(&g).is_err());
        let mut g = dev_genesis("pow");
        g["unknown_field"] = 1.into();
        assert!(ChainParams::from_value(&g).is_err());
    }

    #[test]
    fn genesis_hash_is_key_order_independent() {
        let g = dev_genesis("pos");
        let s1 = serde_json::to_string(&g).unwrap();
        let v: serde_json::Value = serde_json::from_str(&s1).unwrap();
        assert_eq!(genesis_hash_of_value(&g).unwrap(), genesis_hash_of_value(&v).unwrap());
        let mut g2 = g.clone();
        g2["network_name"] = "Other".into();
        assert_ne!(genesis_hash_of_value(&g).unwrap(), genesis_hash_of_value(&g2).unwrap());
    }
}
