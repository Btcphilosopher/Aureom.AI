//! aureom-cli — keys, development wallet, transaction preparation/review/signing,
//! genesis hashing, snapshot verification and test vectors.
//!
//! Construction (`tx prepare`) is separate from signing (`tx sign`): an unsigned
//! transaction file can be reviewed (`tx review`) on any machine before the key holder
//! signs it. Private keys are never printed or logged.

use anyhow::{bail, Context, Result};
use aureom_core::codec::{Decode, Encode};
use aureom_core::crypto::{bech32_encode, Keypair};
use aureom_core::exec;
use aureom_core::genesis::{genesis_hash_of_value, validate, ChainParams, Genesis};
use aureom_core::keystore::Keystore;
use aureom_core::types::*;
use base64::Engine;
use clap::{Parser, Subcommand};
use serde_json::{json, Value};
use std::path::{Path, PathBuf};

#[derive(Parser)]
#[command(name = "aureom-cli", version, about = "AUREOM CHAINWORKS keys, wallet and protocol tools (development software)")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    #[command(subcommand)]
    Keys(Keys),
    #[command(subcommand)]
    Genesis(GenesisCmd),
    #[command(subcommand)]
    Tx(Tx),
    #[command(subcommand)]
    Wallet(Wallet),
    #[command(subcommand)]
    Snapshot(Snap),
    /// Write cross-implementation test vectors.
    Vectors {
        #[arg(long)]
        out: PathBuf,
    },
    /// Build a claim-distribution Merkle tree: input JSON [{"index","address","amount"}].
    Merkle {
        #[arg(long)]
        genesis: PathBuf,
        #[arg(long)]
        claims: PathBuf,
        #[arg(long)]
        out: PathBuf,
    },
    /// Local performance measurements of the state machine (single thread, release build).
    Bench {
        #[arg(long, default_value_t = 2000)]
        txs: usize,
        #[arg(long, default_value_t = 10000)]
        accounts: usize,
    },
    /// Off-chain message signing (token-gated access challenges); never a transaction.
    #[command(subcommand)]
    Message(MessageCmd),
    /// Build a claim-based NFT drop tree: input JSON [{"index","address","token_id","uri","sha256"}].
    DropTree {
        #[arg(long)]
        genesis: PathBuf,
        #[arg(long)]
        claims: PathBuf,
        #[arg(long)]
        out: PathBuf,
    },
    /// Derive identifiers deterministically.
    Derive {
        #[arg(long)]
        genesis: PathBuf,
        /// token | multisig | distribution | collection | listing | drop
        #[arg(long)]
        kind: String,
        #[arg(long)]
        creator: String,
        #[arg(long)]
        nonce: u64,
    },
}

#[derive(Subcommand)]
enum MessageCmd {
    /// Sign UTF-8 message text with a keystore key (domain "AUREOM/MSG/v1").
    Sign {
        #[arg(long)]
        keystore: PathBuf,
        #[arg(long)]
        passphrase_file: Option<PathBuf>,
        /// Message text, or @file to read it from a file.
        #[arg(long)]
        message: String,
    },
    /// Verify a message signature against a hex public key.
    Verify {
        #[arg(long)]
        pubkey: String,
        #[arg(long)]
        message: String,
        #[arg(long)]
        signature: String,
        #[arg(long, default_value = "aurd")]
        hrp: String,
    },
}

#[derive(Subcommand)]
enum Keys {
    /// Create a key. account: encrypted keystore. node: PoW p2p identity (0600 plaintext,
    /// needed unattended). validator: CometBFT-format consensus key (0600).
    Create {
        #[arg(long, default_value = "account")]
        role: String,
        #[arg(long, default_value = "")]
        label: String,
        #[arg(long, default_value = "aurd")]
        hrp: String,
        #[arg(long)]
        out: PathBuf,
        #[arg(long)]
        passphrase_file: Option<PathBuf>,
        /// Minimum Argon2id cost (development networks only).
        #[arg(long)]
        fast_kdf: bool,
    },
    /// Show public information of a key file (never the secret).
    Show {
        file: PathBuf,
        #[arg(long, default_value = "aurd")]
        hrp: String,
    },
}

#[derive(Subcommand)]
enum GenesisCmd {
    /// Validate and hash a genesis document.
    Hash { file: PathBuf },
    /// Full validation report (errors and warnings) as JSON.
    Validate { file: PathBuf },
    /// Genesis state root and supply preview.
    Inspect { file: PathBuf },
}

#[derive(Subcommand)]
enum Tx {
    /// Construct an unsigned transaction (no key material involved).
    Prepare {
        #[arg(long)]
        genesis: PathBuf,
        /// Sender: keystore file (public part only is read) or hex pubkey.
        #[arg(long)]
        from: String,
        /// Nonce, or "auto" to query --node.
        #[arg(long, default_value = "auto")]
        nonce: String,
        /// Fee in base units, or "auto" for the protocol minimum.
        #[arg(long, default_value = "auto")]
        fee: String,
        #[arg(long, default_value_t = 0)]
        expiry_height: u64,
        #[arg(long, default_value = "")]
        memo: String,
        /// Action JSON, e.g. '{"type":"transfer","to":"aurd1...","amount":"1000"}' or @file.json
        #[arg(long)]
        action: String,
        #[arg(long)]
        node: Option<String>,
        #[arg(long)]
        out: PathBuf,
    },
    /// Human review of an unsigned (or signed) transaction file.
    Review {
        file: PathBuf,
        #[arg(long)]
        genesis: PathBuf,
    },
    /// Sign an unsigned transaction file with a keystore.
    Sign {
        #[arg(long = "in")]
        input: PathBuf,
        #[arg(long)]
        genesis: PathBuf,
        #[arg(long)]
        keystore: PathBuf,
        #[arg(long)]
        passphrase_file: Option<PathBuf>,
        #[arg(long)]
        out: PathBuf,
    },
    /// External-signing adapter: attach an Ed25519 signature produced elsewhere over
    /// `signing_message_hex`; the signature is verified before the file is written.
    AttachSignature {
        #[arg(long = "in")]
        input: PathBuf,
        #[arg(long)]
        signature: String,
        #[arg(long)]
        out: PathBuf,
    },
    /// Submit a signed transaction to a node.
    Submit {
        #[arg(long = "in")]
        input: PathBuf,
        #[arg(long)]
        node: String,
    },
    /// Query transaction status / receipt.
    Status {
        #[arg(long)]
        id: String,
        #[arg(long)]
        node: String,
    },
}

#[derive(Subcommand)]
enum Wallet {
    /// Create an account keystore (alias of keys create --role account).
    Create {
        #[arg(long, default_value = "")]
        label: String,
        #[arg(long, default_value = "aurd")]
        hrp: String,
        #[arg(long)]
        out: PathBuf,
        #[arg(long)]
        passphrase_file: Option<PathBuf>,
        #[arg(long)]
        fast_kdf: bool,
    },
    /// Balances (native and tokens) for an address.
    Balance {
        #[arg(long)]
        address: String,
        #[arg(long)]
        node: String,
    },
}

#[derive(Subcommand)]
enum Snap {
    /// Verify a snapshot file; with --trusted-root also checks it against a trusted state root.
    Verify {
        file: PathBuf,
        #[arg(long)]
        trusted_root: Option<String>,
        #[arg(long)]
        genesis: Option<PathBuf>,
    },
}

fn read_pass(file: &Option<PathBuf>, confirm: bool) -> Result<String> {
    if let Some(f) = file {
        return Ok(std::fs::read_to_string(f).with_context(|| format!("read passphrase file {}", f.display()))?.trim_end_matches(['\n', '\r']).to_string());
    }
    if let Ok(p) = std::env::var("AUREOM_KEYSTORE_PASSPHRASE") {
        return Ok(p);
    }
    let p = rpassword::prompt_password("Keystore passphrase: ")?;
    if confirm && rpassword::prompt_password("Repeat passphrase: ")? != p {
        bail!("passphrases differ");
    }
    if p.len() < 8 {
        bail!("passphrase must be at least 8 characters");
    }
    Ok(p)
}

fn write_private(path: &Path, content: &str) -> Result<()> {
    if path.exists() {
        bail!("refusing to overwrite existing key file {}", path.display());
    }
    if let Some(d) = path.parent() {
        std::fs::create_dir_all(d)?;
    }
    #[cfg(unix)]
    {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        let mut f = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(path)?;
        f.write_all(content.as_bytes())?;
    }
    #[cfg(not(unix))]
    std::fs::write(path, content)?;
    Ok(())
}

fn load_params(p: &Path) -> Result<ChainParams> {
    ChainParams::from_json_str(&std::fs::read_to_string(p)?).map_err(|e| anyhow::anyhow!(e))
}

fn create_account(label: &str, hrp: &str, out: &Path, pf: &Option<PathBuf>, fast: bool, role: &str) -> Result<Value> {
    let pass = read_pass(pf, true)?;
    let kp = Keypair::generate();
    let ks = Keystore::encrypt(&kp, pass.as_bytes(), hrp, role, label, fast);
    write_private(out, &serde_json::to_string_pretty(&ks)?)?;
    Ok(json!({"role": role, "label": label, "address": ks.address, "pubkey": ks.pubkey, "keystore": out.display().to_string(),
        "kdf": format!("argon2id m={}KiB t={}", ks.kdf.m_kib, ks.kdf.t)}))
}

fn http() -> reqwest::blocking::Client {
    reqwest::blocking::Client::builder().timeout(std::time::Duration::from_secs(10)).build().unwrap()
}

fn get_json(url: &str) -> Result<Value> {
    let r = http().get(url).send()?;
    Ok(r.json()?)
}

fn load_unsigned(v: &Value) -> Result<UnsignedTx> {
    let h = v["unsigned_hex"].as_str().context("unsigned_hex missing")?;
    UnsignedTx::decode(&hex::decode(h)?).map_err(|e| anyhow::anyhow!("invalid unsigned tx: {e}"))
}

fn review(p: &ChainParams, u: &UnsignedTx, signed: Option<&SignedTx>) -> Value {
    let mut warnings = vec![];
    let na = &p.doc.native_asset;
    let fmt = |x: u128| {
        let d = na.decimals as u32;
        let base = 10u128.pow(d);
        if d == 0 { format!("{x} {}", na.ticker) } else { format!("{}.{:0width$} {}", x / base, x % base, na.ticker, width = d as usize) }
    };
    if u.chain_id != p.doc.chain_id {
        warnings.push(format!("CHAIN MISMATCH: tx is for {:?}, genesis is {:?}", u.chain_id, p.doc.chain_id));
    }
    let size = u.encode().len() + 64;
    let min = exec::min_fee(p, size).unwrap_or(u64::MAX);
    if u.fee < min {
        warnings.push(format!("fee {} below protocol minimum {}", u.fee, min));
    }
    if u.fee > min.saturating_mul(100) {
        warnings.push(format!("fee {} is more than 100x the minimum {}", fmt(u.fee as u128), fmt(min as u128)));
    }
    let summary = match &u.action {
        Action::Transfer { to, amount } => format!("send {} to {}", fmt(*amount), p.addr(to)),
        Action::TokenTransfer { token, to, amount } => format!("send {amount} base units of token {} to {} (verify the token id, not the symbol)", p.token(token), p.addr(to)),
        Action::TokenCreate { symbol, max_supply, mint_authority, admin, flags, .. } => {
            if *flags != 0 {
                warnings.push(format!("token grants admin powers: pausable={} freezable={}", flags & FLAG_PAUSABLE != 0, flags & FLAG_FREEZABLE != 0));
            }
            if mint_authority.is_some() && max_supply.is_none() {
                warnings.push("uncapped token with a mint authority: supply can grow without limit".into());
            }
            format!("create token {symbol} (admin: {:?})", admin.map(|a| p.addr(&a)))
        }
        Action::Nft(n) => nft_review(p, n, &mut warnings),
        a => format!("{} action", a.type_name()),
    };
    if u.expiry_height == 0 {
        warnings.push("no expiry height: this transaction stays valid until its nonce is used".into());
    }
    json!({
        "summary": summary, "chain_id": u.chain_id, "sender": p.addr(&u.sender()), "nonce": u.nonce,
        "fee": fmt(u.fee as u128), "fee_base_units": u.fee.to_string(), "min_fee": min, "expiry_height": u.expiry_height,
        "txid": hex::encode(u.txid()), "action": aureom_core::json::action_json(p, &u.action),
        "signed": signed.is_some(), "signature_valid": signed.map(|s| s.verify_signature()),
        "warnings": warnings,
    })
}

/// Human-readable summary and risk warnings for collections-module actions.
fn nft_review(p: &ChainParams, n: &aureom_core::nft::NftAction, warnings: &mut Vec<String>) -> String {
    use aureom_core::nft::*;
    let opt = |a: &Option<[u8; 20]>| a.map(|x| p.addr(&x)).unwrap_or_else(|| "nobody".into());
    match n {
        NftAction::CollectionCreate(s) => {
            warnings.push(format!(
                "ADMINISTRATIVE POWERS: mint authority={} (max supply {}), metadata policy={} admin={}, admin={} pausable={} forced_transfer={}, owner_burn={}, transferable={}",
                opt(&s.mint_authority), s.max_supply.map(|m| m.to_string()).unwrap_or_else(|| "UNCAPPED".into()),
                aureom_core::json::policy_name(s.metadata_policy), opt(&s.metadata_admin), opt(&s.admin),
                s.flags & CFLAG_PAUSABLE != 0, s.flags & CFLAG_FORCED_TRANSFER != 0, s.flags & CFLAG_OWNER_BURN != 0, s.transfer_policy == TRANSFER_FREE));
            if s.flags & CFLAG_FORCED_TRANSFER != 0 {
                warnings.push("FORCED TRANSFER enabled: the admin can move any holder's token without their signature".into());
            }
            if s.mint_authority.is_some() && s.max_supply.is_none() {
                warnings.push("uncapped collection with a mint authority: supply can grow without limit".into());
            }
            if let Some(r) = &s.royalty {
                warnings.push(format!("royalty {} bps to {} is enforced only by the native Chainworks marketplace", r.bps, p.addr(&r.recipient)));
            }
            format!("create collection {:?} ({}) — rights holder: {}", s.slug, s.name, s.rights_holder)
        }
        NftAction::SetOperator { collection, operator, approved: true, expiry_height } => {
            warnings.push(format!("COLLECTION-WIDE OPERATOR: {} could transfer ALL your tokens in {} (including future ones){}. Prefer a single-token approval or a fixed-price listing.",
                p.addr(operator), p.collection(collection), if *expiry_height == 0 { " with NO expiry".to_string() } else { format!(" until height {expiry_height}") }));
            format!("grant operator {} on {}", p.addr(operator), p.collection(collection))
        }
        NftAction::Approve { collection, token_id, approved, .. } => format!("{} single-token approval for {}/{token_id} to {}", if approved.is_some() { "grant" } else { "revoke" }, p.collection(collection), opt(approved)),
        NftAction::Transfer { collection, token_id, to } => format!("transfer {}/{token_id} to {} (no payment is attached; royalties do not apply)", p.collection(collection), p.addr(to)),
        NftAction::ForceTransfer { collection, token_id, to, .. } => {
            warnings.push("forced transfer: moves a token without its owner's signature; publicly recorded".into());
            format!("FORCE-transfer {}/{token_id} to {}", p.collection(collection), p.addr(to))
        }
        NftAction::FreezeMetadata { collection, scope, expected } => {
            warnings.push("freezing metadata is permanent and cannot be undone".into());
            match scope {
                FreezeScope::Token(t) => format!("freeze metadata of {}/{t}; expected current metadata sha256 {}", p.collection(collection), hex::encode(expected)),
                FreezeScope::Collection => format!("freeze ALL metadata of {} (and of future mints); expected metadata root {}", p.collection(collection), hex::encode(expected)),
            }
        }
        NftAction::ListingBuy { listing_id, price, currency } => format!("buy listing {} for exactly {price} base units of {} (plus the network fee)", hex::encode(listing_id),
            match currency { AssetId::Native => p.doc.native_asset.ticker.clone(), AssetId::Token(t) => p.token(t) }),
        NftAction::ListingCreate { collection, token_id, price, expiry_height, .. } => format!("list {}/{token_id} for {price} base units until height {expiry_height}; any buyer can settle at that price", p.collection(collection)),
        NftAction::SetRole { collection, new: None, .. } => {
            warnings.push("renouncing a role is permanent".into());
            format!("renounce a role on {}", p.collection(collection))
        }
        a => format!("{} action", a.type_name()),
    }
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let out: Value = match cli.cmd {
        Cmd::Keys(Keys::Create { role, label, hrp, out, passphrase_file, fast_kdf }) => match role.as_str() {
            "account" | "treasury-signer" | "operator" | "validator-operator" => create_account(&label, &hrp, &out, &passphrase_file, fast_kdf, &role)?,
            "node" => {
                let kp = Keypair::generate();
                let content = json!({"role": "node", "label": label, "pubkey": hex::encode(kp.public()), "seed": hex::encode(kp.seed()),
                    "warning": "plaintext node identity key (p2p authentication only, holds no funds); keep mode 0600"});
                write_private(&out, &serde_json::to_string_pretty(&content)?)?;
                json!({"role": "node", "peer_id": hex::encode(kp.public()), "file": out.display().to_string()})
            }
            "validator" => {
                let kp = Keypair::generate();
                let b64 = base64::engine::general_purpose::STANDARD;
                let mut sk = kp.seed().to_vec();
                sk.extend_from_slice(&kp.public());
                let addr = hex::encode_upper(aureom_core::crypto::comet_address(&kp.public()));
                let content = json!({"address": addr, "pub_key": {"type": "tendermint/PubKeyEd25519", "value": b64.encode(kp.public())},
                    "priv_key": {"type": "tendermint/PrivKeyEd25519", "value": b64.encode(&sk)}});
                write_private(&out, &serde_json::to_string_pretty(&content)?)?;
                json!({"role": "validator", "consensus_pubkey": b64.encode(kp.public()), "consensus_address": addr, "file": out.display().to_string(),
                    "warning": "never run two active instances with this key: CometBFT double-sign protection is per-instance (priv_validator_state.json)"})
            }
            r => bail!("unknown role {r} (account|node|validator|treasury-signer|operator)"),
        },
        Cmd::Keys(Keys::Show { file, hrp }) => {
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&file)?)?;
            if v.get("aureom_keystore").is_some() {
                json!({"type": "keystore", "role": v["role"], "label": v["label"], "address": v["address"], "pubkey": v["pubkey"]})
            } else if v.get("priv_key").is_some() {
                json!({"type": "cometbft-validator-key", "consensus_pubkey": v["pub_key"]["value"], "consensus_address": v["address"]})
            } else if v.get("seed").is_some() {
                let pk = v["pubkey"].as_str().unwrap_or("");
                let pkb: [u8; 32] = hex::decode(pk)?.try_into().map_err(|_| anyhow::anyhow!("pubkey"))?;
                json!({"type": "node-key", "peer_id": pk, "address": bech32_encode(&hrp, &aureom_core::crypto::address_from_pubkey(&pkb))})
            } else {
                bail!("unrecognised key file")
            }
        }
        Cmd::Genesis(GenesisCmd::Hash { file }) => {
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&file)?)?;
            let h = genesis_hash_of_value(&v).map_err(|e| anyhow::anyhow!(e))?;
            let p = ChainParams::from_value(&v).map_err(|e| anyhow::anyhow!(e))?;
            json!({"genesis_hash": hex::encode(h), "chain_id": p.doc.chain_id, "profile": p.profile.as_str(), "state_root": hex::encode(p.genesis_state().root())})
        }
        Cmd::Genesis(GenesisCmd::Validate { file }) => {
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&file)?)?;
            match serde_json::from_value::<Genesis>(v.clone()) {
                Err(e) => json!({"ok": false, "errors": [format!("schema: {e}")], "warnings": []}),
                Ok(g) => {
                    let r = validate(&g);
                    let jcs_err = aureom_core::genesis::jcs(&v).err();
                    let mut errors = r.errors.clone();
                    if let Some(e) = jcs_err {
                        errors.push(e);
                    }
                    json!({"ok": errors.is_empty(), "errors": errors, "warnings": r.warnings,
                        "genesis_hash": genesis_hash_of_value(&v).ok().map(hex::encode)})
                }
            }
        }
        Cmd::Genesis(GenesisCmd::Inspect { file }) => {
            let p = load_params(&file)?;
            let st = p.genesis_state();
            let rep = exec::reconcile(&st, &p, 0);
            json!({"genesis_hash": hex::encode(p.hash), "state_root": hex::encode(st.root()), "supply": rep,
                "treasuries": p.treasury_addrs.iter().map(|a| p.addr(a)).collect::<Vec<_>>()})
        }
        Cmd::Tx(Tx::Prepare { genesis, from, nonce, fee, expiry_height, memo, action, node, out }) => {
            let p = load_params(&genesis)?;
            let pubkey: [u8; 32] = if Path::new(&from).exists() {
                let v: Value = serde_json::from_str(&std::fs::read_to_string(&from)?)?;
                hex::decode(v["pubkey"].as_str().context("keystore pubkey")?)?.try_into().map_err(|_| anyhow::anyhow!("pubkey"))?
            } else {
                hex::decode(&from)?.try_into().map_err(|_| anyhow::anyhow!("--from must be a keystore path or 32-byte hex pubkey"))?
            };
            let aj: Value = if let Some(f) = action.strip_prefix('@') { serde_json::from_str(&std::fs::read_to_string(f)?)? } else { serde_json::from_str(&action)? };
            let act = aureom_core::json::action_from_json(&p, &aj).map_err(|e| anyhow::anyhow!(e))?;
            let sender = aureom_core::crypto::address_from_pubkey(&pubkey);
            let nonce: u64 = if nonce == "auto" {
                let n = node.as_ref().context("--nonce auto needs --node")?;
                let v = get_json(&format!("{n}/v1/accounts/{}", p.addr(&sender)))?;
                v["nonce"].as_u64().context("nonce from node")?
            } else {
                nonce.parse()?
            };
            let mut u = UnsignedTx { version: TX_VERSION, chain_id: p.doc.chain_id.clone(), nonce, fee: 0, expiry_height, sender_pubkey: pubkey, action: act, memo: memo.into_bytes() };
            u.fee = if fee == "auto" {
                // fee field width is fixed, so size does not depend on its value
                exec::min_fee(&p, u.encode().len() + 64).context("fee overflow")?
            } else {
                fee.parse()?
            };
            let rv = review(&p, &u, None);
            let doc = json!({"kind": "aureom-unsigned-tx", "unsigned_hex": hex::encode(u.encode()), "signing_message_hex": hex::encode(u.signing_message()),
                "external_signing": "an external signer (HSM, hardware wallet adapter) signs signing_message_hex with Ed25519; combine with `tx attach-signature`", "review": rv});
            std::fs::write(&out, serde_json::to_string_pretty(&doc)?)?;
            json!({"written": out.display().to_string(), "txid": rv["txid"], "review": rv})
        }
        Cmd::Tx(Tx::Review { file, genesis }) => {
            let p = load_params(&genesis)?;
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&file)?)?;
            if let Some(sh) = v["signed_hex"].as_str() {
                let s = SignedTx::decode(&hex::decode(sh)?).map_err(|e| anyhow::anyhow!("{e}"))?;
                review(&p, &s.tx, Some(&s))
            } else {
                review(&p, &load_unsigned(&v)?, None)
            }
        }
        Cmd::Tx(Tx::Sign { input, genesis, keystore, passphrase_file, out }) => {
            let p = load_params(&genesis)?;
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&input)?)?;
            let u = load_unsigned(&v)?;
            if u.chain_id != p.doc.chain_id {
                bail!("refusing to sign: transaction chain id {:?} differs from genesis {:?}", u.chain_id, p.doc.chain_id);
            }
            let ks: Keystore = serde_json::from_str(&std::fs::read_to_string(&keystore)?)?;
            if ks.pubkey != hex::encode(u.sender_pubkey) {
                bail!("keystore {} is not the sender of this transaction", ks.address);
            }
            let pass = read_pass(&passphrase_file, false)?;
            let kp = ks.decrypt(pass.as_bytes()).map_err(|e| anyhow::anyhow!("{e}"))?;
            let s = u.sign(&kp);
            drop(kp);
            let doc = json!({"kind": "aureom-signed-tx", "txid": hex::encode(s.txid()), "signed_hex": hex::encode(s.encode()), "review": review(&p, &s.tx, Some(&s))});
            std::fs::write(&out, serde_json::to_string_pretty(&doc)?)?;
            json!({"written": out.display().to_string(), "txid": hex::encode(s.txid())})
        }
        Cmd::Tx(Tx::AttachSignature { input, signature, out }) => {
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&input)?)?;
            let u = load_unsigned(&v)?;
            let sig: [u8; 64] = hex::decode(&signature)?.try_into().map_err(|_| anyhow::anyhow!("signature must be 64 bytes hex"))?;
            let s = SignedTx { tx: u, signature: sig };
            if !s.verify_signature() {
                bail!("signature does not verify for this transaction and sender key");
            }
            let doc = json!({"kind": "aureom-signed-tx", "txid": hex::encode(s.txid()), "signed_hex": hex::encode(s.encode())});
            std::fs::write(&out, serde_json::to_string_pretty(&doc)?)?;
            json!({"written": out.display().to_string(), "txid": hex::encode(s.txid()), "signature_verified": true})
        }
        Cmd::Tx(Tx::Submit { input, node }) => {
            let v: Value = serde_json::from_str(&std::fs::read_to_string(&input)?)?;
            let sh = v["signed_hex"].as_str().context("not a signed transaction file")?;
            let r = http().post(format!("{node}/v1/transactions")).json(&json!({"tx": sh})).send()?;
            let status = r.status().as_u16();
            let body: Value = r.json().unwrap_or(Value::Null);
            json!({"http_status": status, "response": body})
        }
        Cmd::Tx(Tx::Status { id, node }) => get_json(&format!("{node}/v1/transactions/{id}"))?,
        Cmd::Wallet(Wallet::Create { label, hrp, out, passphrase_file, fast_kdf }) => create_account(&label, &hrp, &out, &passphrase_file, fast_kdf, "account")?,
        Cmd::Wallet(Wallet::Balance { address, node }) => get_json(&format!("{node}/v1/accounts/{address}"))?,
        Cmd::Snapshot(Snap::Verify { file, trusted_root, genesis }) => {
            let data = std::fs::read(&file)?;
            match aureom_core::snapshot::read_verified(&data) {
                Err(e) => json!({"ok": false, "error": e.to_string()}),
                Ok((h, st)) => {
                    let mut problems = vec![];
                    if let Some(g) = genesis {
                        let p = load_params(&g)?;
                        if p.hash != h.genesis_hash {
                            problems.push("snapshot genesis hash differs from the given genesis".to_string());
                        }
                        let rep = exec::reconcile(&st, &p, h.height + 1);
                        if !rep.reconciled || !rep.tokens_reconciled {
                            problems.push(format!("supply invariants fail: {:?}", rep.problems));
                        }
                    }
                    let trusted = match &trusted_root {
                        Some(t) if t.to_lowercase() == hex::encode(h.state_root) => Some(true),
                        Some(_) => {
                            problems.push("state root does not match the trusted root".into());
                            Some(false)
                        }
                        None => None,
                    };
                    json!({"ok": problems.is_empty(), "internally_consistent": true, "chain_id": h.chain_id, "genesis_hash": hex::encode(h.genesis_hash),
                        "height": h.height, "block_id": hex::encode(h.block_id), "state_root": hex::encode(h.state_root), "entries": h.entries,
                        "matches_trusted_root": trusted, "problems": problems,
                        "note": if trusted_root.is_none() { "integrity verified; NOT yet trusted — compare state_root with a block you validated yourself" } else { "" }})
                }
            }
        }
        Cmd::Vectors { out } => {
            std::fs::create_dir_all(&out)?;
            let mut files = vec![];
            for (name, v) in aureom_core::vectors::all() {
                std::fs::write(out.join(name), serde_json::to_string_pretty(&v)?)?;
                files.push(name);
            }
            json!({"written": files})
        }
        Cmd::Merkle { genesis, claims, out } => {
            let p = load_params(&genesis)?;
            let v: Vec<Value> = serde_json::from_str(&std::fs::read_to_string(&claims)?)?;
            let mut leaves = vec![];
            let mut seen = std::collections::BTreeSet::new();
            for (i, c) in v.iter().enumerate() {
                let idx = c["index"].as_u64().context("index")? as u32;
                if idx as usize != i {
                    bail!("claims must be listed with index = position (0..n)");
                }
                let a = p.parse_addr(c["address"].as_str().context("address")?).map_err(|e| anyhow::anyhow!("claim {i}: {e}"))?;
                if !seen.insert(a) {
                    bail!("duplicate claimant {} at index {i}", p.addr(&a));
                }
                let amt: u128 = c["amount"].as_str().context("amount string")?.parse()?;
                leaves.push(claim_leaf(idx, &a, amt));
            }
            let root = aureom_core::merkle::root(&leaves);
            let proofs: Vec<Value> = (0..leaves.len())
                .map(|i| {
                    let pr = aureom_core::merkle::proof(&leaves, i);
                    json!({"index": i, "address": v[i]["address"], "amount": v[i]["amount"],
                        "proof": pr.iter().map(|s| json!({"side": s.side, "sibling": hex::encode(s.sibling)})).collect::<Vec<_>>()})
                })
                .collect();
            let total: u128 = v.iter().map(|c| c["amount"].as_str().unwrap_or("0").parse::<u128>().unwrap_or(0)).sum();
            let doc = json!({"merkle_root": hex::encode(root), "total": total.to_string(), "claims": proofs});
            std::fs::write(&out, serde_json::to_string_pretty(&doc)?)?;
            json!({"merkle_root": hex::encode(root), "claims": leaves.len(), "total": total.to_string(), "written": out.display().to_string()})
        }
        Cmd::Bench { txs, accounts } => bench(txs, accounts)?,
        Cmd::Message(MessageCmd::Sign { keystore, passphrase_file, message }) => {
            let text = match message.strip_prefix('@') {
                Some(f) => std::fs::read_to_string(f)?,
                None => message,
            };
            if text.contains("AUREOM/TXSIG") {
                bail!("refusing to sign: message mentions the transaction signing domain");
            }
            let ks: Keystore = serde_json::from_str(&std::fs::read_to_string(&keystore)?)?;
            let pass = read_pass(&passphrase_file, false)?;
            let kp = ks.decrypt(pass.as_bytes()).map_err(|e| anyhow::anyhow!("{e}"))?;
            let sig = kp.sign(&aureom_core::crypto::message_signing_bytes(text.as_bytes()));
            drop(kp);
            json!({"address": ks.address, "pubkey": ks.pubkey, "signature": hex::encode(sig), "domain": "AUREOM/MSG/v1",
                "note": "an off-chain signature; it is not a transaction and cannot move assets"})
        }
        Cmd::Message(MessageCmd::Verify { pubkey, message, signature, hrp }) => {
            let pk: [u8; 32] = hex::decode(&pubkey)?.try_into().map_err(|_| anyhow::anyhow!("pubkey must be 32 bytes hex"))?;
            let sig: [u8; 64] = hex::decode(&signature)?.try_into().map_err(|_| anyhow::anyhow!("signature must be 64 bytes hex"))?;
            let ok = aureom_core::crypto::verify(&pk, &aureom_core::crypto::message_signing_bytes(message.as_bytes()), &sig);
            json!({"valid": ok, "address": bech32_encode(&hrp, &aureom_core::crypto::address_from_pubkey(&pk))})
        }
        Cmd::DropTree { genesis, claims, out } => {
            let p = load_params(&genesis)?;
            let v: Vec<Value> = serde_json::from_str(&std::fs::read_to_string(&claims)?)?;
            let mut leaves = vec![];
            let mut ids = std::collections::BTreeSet::new();
            for (i, c) in v.iter().enumerate() {
                if c["index"].as_u64() != Some(i as u64) {
                    bail!("claims must be listed with index = position (0..n)");
                }
                let a = p.parse_addr(c["address"].as_str().context("address")?).map_err(|e| anyhow::anyhow!("claim {i}: {e}"))?;
                let tid: u64 = match &c["token_id"] {
                    Value::String(s) => s.parse().with_context(|| format!("claim {i}: token_id"))?,
                    v => v.as_u64().with_context(|| format!("claim {i}: token_id"))?,
                };
                if !ids.insert(tid) {
                    bail!("duplicate token id {tid} at index {i}");
                }
                let hash: [u8; 32] = hex::decode(c["sha256"].as_str().context("sha256")?)?.try_into().map_err(|_| anyhow::anyhow!("sha256 must be 32 bytes"))?;
                let m = aureom_core::nft::MetadataRef { uri: c["uri"].as_str().context("uri")?.into(), hash };
                leaves.push(aureom_core::nft::drop_leaf(i as u32, &a, tid, &m));
            }
            let root = aureom_core::merkle::root(&leaves);
            let proofs: Vec<Value> = (0..leaves.len())
                .map(|i| {
                    let pr = aureom_core::merkle::proof(&leaves, i);
                    json!({"index": i, "address": v[i]["address"], "token_id": v[i]["token_id"], "uri": v[i]["uri"], "sha256": v[i]["sha256"],
                        "proof": pr.iter().map(|s| json!({"side": s.side, "sibling": hex::encode(s.sibling)})).collect::<Vec<_>>()})
                })
                .collect();
            let doc = json!({"merkle_root": hex::encode(root), "claims": proofs});
            std::fs::write(&out, serde_json::to_string_pretty(&doc)?)?;
            json!({"merkle_root": hex::encode(root), "claims": leaves.len(), "written": out.display().to_string()})
        }
        Cmd::Derive { genesis, kind, creator, nonce } => {
            let p = load_params(&genesis)?;
            let c = p.parse_addr(&creator).map_err(|e| anyhow::anyhow!(e))?;
            match kind.as_str() {
                "token" => json!({"token_id": p.token(&exec::token_id(&c, nonce))}),
                "multisig" => json!({"multisig": p.addr(&exec::multisig_address(&c, nonce))}),
                "distribution" => json!({"dist_id": hex::encode(exec::distribution_id(&c, nonce))}),
                "collection" => {
                    let id = aureom_core::nft::collection_id(&c, nonce);
                    json!({"collection_id": p.collection(&id)})
                }
                "listing" => json!({"listing_id": hex::encode(aureom_core::nft::listing_id(&c, nonce))}),
                "drop" => json!({"drop_id": hex::encode(aureom_core::nft::drop_id(&c, nonce))}),
                k => bail!("unknown kind {k}"),
            }
        }
    };
    println!("{}", serde_json::to_string_pretty(&out)?);
    Ok(())
}

fn bench(n: usize, accounts: usize) -> Result<Value> {
    use aureom_core::crypto::test_keypair;
    use std::time::Instant;
    let g = aureom_core::genesis::tests::dev_genesis("pow");
    let p = ChainParams::from_value(&g).map_err(|e| anyhow::anyhow!(e))?;
    let senders: Vec<Keypair> = (0..16).map(|i| test_keypair(&format!("bench{i}"))).collect();
    let mut st = p.genesis_state();
    // fund senders and create filler accounts
    let mut ov = st.overlay();
    for k in &senders {
        ov.put_account(&k.address(), &Account { balance: 1_000_000_000_000, ..Default::default() });
    }
    for i in 0..accounts {
        let mut a = [0u8; 20];
        a[..8].copy_from_slice(&(i as u64).to_be_bytes());
        a[19] = 0xAB;
        ov.put_account(&a, &Account { balance: 1, ..Default::default() });
    }
    let cs = ov.into_changes();
    st.apply(&cs);
    let t = Instant::now();
    let txs: Vec<SignedTx> = (0..n)
        .map(|i| {
            let k = &senders[i % senders.len()];
            UnsignedTx { version: 1, chain_id: p.doc.chain_id.clone(), nonce: (i / senders.len()) as u64, fee: 5000, expiry_height: 0, sender_pubkey: k.public(),
                action: Action::Transfer { to: senders[(i + 1) % senders.len()].address(), amount: 1 }, memo: vec![] }.sign(k)
        })
        .collect();
    let sign_s = t.elapsed().as_secs_f64();
    let t = Instant::now();
    for tx in &txs {
        assert!(tx.verify_signature());
    }
    let verify_s = t.elapsed().as_secs_f64();
    let t = Instant::now();
    let mut ctx = exec::BlockCtx::new(1, Some([1; 20]));
    let mut ov = st.overlay();
    let rc = exec::execute_txs(&mut ov, &p, &mut ctx, &txs).map_err(|(i, e)| anyhow::anyhow!("tx {i}: {e}"))?;
    exec::pow_coinbase(&mut ov, &p, &mut ctx, &[1; 20]);
    let cs = ov.into_changes();
    let exec_s = t.elapsed().as_secs_f64();
    let t = Instant::now();
    st.apply(&cs);
    let root = st.root();
    let root_s = t.elapsed().as_secs_f64();
    let t = Instant::now();
    let _ = st.root();
    let root2_s = t.elapsed().as_secs_f64();
    Ok(json!({
        "transactions": n, "state_entries": st.len(), "all_succeeded": rc.iter().all(|r| r.status == STATUS_SUCCESS),
        "sign_tx_per_s": (n as f64 / sign_s).round(), "verify_tx_per_s": (n as f64 / verify_s).round(),
        "execute_block_tx_per_s_including_sig_verify": (n as f64 / exec_s).round(), "execute_block_ms": (exec_s * 1000.0 * 100.0).round() / 100.0,
        "apply_and_state_root_ms": (root_s * 1000.0 * 100.0).round() / 100.0, "state_root_recompute_ms": (root2_s * 1000.0 * 100.0).round() / 100.0,
        "state_root": hex::encode(root),
        "note": "single-threaded release build on the build machine; state root is recomputed over all leaves each block (O(n))"
    }))
}
