//! Public node API (/v1) and separately bound, token-authenticated admin API (/admin/v1).

use crate::abci::BftNode;
use crate::pow_node::PowNode;
use crate::store::T;
use crate::views::{self, with_observed};
use axum::extract::{Path, Query, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use serde::Deserialize;
use serde_json::{json, Value};
use std::sync::atomic::Ordering;
use std::sync::Arc;

#[derive(Debug)]
pub struct ApiError {
    pub status: u16,
    pub code: String,
    pub message: String,
}

impl ApiError {
    pub fn code(status: u16, code: &str, msg: &str) -> Self {
        ApiError { status, code: code.into(), message: msg.into() }
    }
    pub fn bad(m: impl ToString) -> Self {
        Self::code(400, "bad_request", &m.to_string())
    }
    pub fn not_found(m: &str) -> Self {
        Self::code(404, "not_found", m)
    }
    pub fn internal(m: impl ToString) -> Self {
        Self::code(500, "internal", &m.to_string())
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        let st = StatusCode::from_u16(self.status).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
        (st, Json(json!({"error": {"code": self.code, "message": self.message}}))).into_response()
    }
}

type R = Result<Json<Value>, ApiError>;

pub enum Backend {
    Pow(Arc<PowNode>),
    Bft(Arc<BftNode>),
}

pub type B = Arc<Backend>;

#[derive(Deserialize)]
pub struct ListQ {
    before: Option<u64>,
    limit: Option<usize>,
    kind: Option<String>,
}

async fn network(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.network(),
        Backend::Bft(n) => n.network(),
    }))
}
async fn health(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.health(),
        Backend::Bft(n) => n.health().await,
    }))
}
async fn block(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.block(&id)?,
        Backend::Bft(n) => n.block(&id)?,
    }))
}
async fn blocks(State(b): State<B>, Query(q): Query<ListQ>) -> R {
    let lim = q.limit.unwrap_or(20).min(100);
    Ok(Json(match &*b {
        Backend::Pow(n) => n.blocks(q.before, lim),
        Backend::Bft(n) => n.blocks(q.before, lim),
    }))
}
async fn account(State(b): State<B>, Path(a): Path<String>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.account(&a)?,
        Backend::Bft(n) => n.account(&a)?,
    }))
}
async fn account_txs(State(b): State<B>, Path(a): Path<String>, Query(q): Query<ListQ>) -> R {
    let lim = q.limit.unwrap_or(50).min(500);
    Ok(Json(match &*b {
        Backend::Pow(n) => n.account_txs(&a, lim)?,
        Backend::Bft(n) => n.account_txs(&a, lim)?,
    }))
}
async fn transaction(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.transaction(&id)?,
        Backend::Bft(n) => n.transaction(&id)?,
    }))
}

#[derive(Deserialize)]
struct SubmitReq {
    tx: String,
}

async fn submit(State(b): State<B>, Json(req): Json<SubmitReq>) -> Result<(StatusCode, Json<Value>), ApiError> {
    let v = match &*b {
        Backend::Pow(n) => {
            let bytes = hex::decode(req.tx.trim_start_matches("0x")).map_err(|_| ApiError::bad("tx must be hex"))?;
            let id = n.submit_tx_bytes(&bytes, None).map_err(|e| ApiError::code(400, e.code(), &e.message()))?;
            json!({"id": hex::encode(id), "status": "pending", "note": "accepted by this node's mempool; inclusion is not guaranteed"})
        }
        Backend::Bft(n) => n.submit(&req.tx).await?,
    };
    Ok((StatusCode::ACCEPTED, Json(with_observed(v))))
}

async fn mempool(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => {
            let c = n.chain.lock();
            with_observed(c.mempool.snapshot(&n.p, 100))
        }
        Backend::Bft(n) => n.mempool(),
    }))
}
async fn consensus(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.consensus(),
        Backend::Bft(n) => n.consensus().await,
    }))
}
async fn validators(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => {
            let c = n.chain.lock();
            with_observed(views::validators_view(&c.state, &n.p, c.height() + 1, None))
        }
        Backend::Bft(n) => n.validators(),
    }))
}
async fn peers(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.peers_json(),
        Backend::Bft(n) => n.peers().await,
    }))
}
async fn sync(State(b): State<B>) -> R {
    Ok(Json(match &*b {
        Backend::Pow(n) => n.sync(),
        Backend::Bft(n) => n.sync().await,
    }))
}

/// Run `f` over (state, params, next height, store) for either backend.
fn with_state<F: FnOnce(&aureom_core::state::State, &aureom_core::genesis::ChainParams, u64, &crate::store::Store) -> Result<Value, ApiError>>(b: &Backend, f: F) -> Result<Value, ApiError> {
    match b {
        Backend::Pow(n) => {
            let c = n.chain.lock();
            f(&c.state, &n.p, c.height() + 1, &c.store)
        }
        Backend::Bft(n) => {
            let a = n.app.lock();
            f(&a.state, &n.p, a.last_height + 1, &a.store)
        }
    }
}

async fn supply(State(b): State<B>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| Ok(views::supply_view(st, p, h)))?)))
}
async fn tokens(State(b): State<B>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, _, _| Ok(views::tokens_view(st, p)))?)))
}
async fn token(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, _, _| {
        let t = p.parse_token(&id).map_err(ApiError::bad)?;
        let info = st.overlay().token(&t).ok_or(ApiError::not_found("unknown token"))?;
        Ok(views::token_view(p, &t, &info))
    })?)))
}
async fn multisig(State(b): State<B>, Path(a): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let ad = p.parse_addr(&a).map_err(ApiError::bad)?;
        views::multisig_view(st, p, h, &ad).ok_or(ApiError::not_found("not a multisig account"))
    })?)))
}
async fn distribution(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, _, _| {
        let d: [u8; 32] = hex::decode(&id).ok().and_then(|x| x.try_into().ok()).ok_or(ApiError::bad("dist id must be 64 hex"))?;
        views::distribution_view(st, p, &d).ok_or(ApiError::not_found("unknown distribution"))
    })?)))
}
async fn proposals(State(b): State<B>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        if p.profile == aureom_core::genesis::Profile::Pow {
            return Ok(json!({"profile": "pow", "proposals": [], "note": "Proof-of-work networks have no on-chain governance; upgrades are coordinated releases with activation heights."}));
        }
        Ok(views::proposals_view(st, p, h))
    })?)))
}
async fn events(State(b): State<B>, Query(q): Query<ListQ>) -> R {
    let lim = q.limit.unwrap_or(50).min(500);
    let kinds: Vec<String> = match q.kind {
        Some(k) => vec![k],
        None => ["mint", "burn", "token_create", "token_admin", "vesting", "msig_execute", "slash", "reward", "validator_update", "gov", "transfer", "token_transfer",
            "nft_collection_create", "nft_mint", "nft_transfer", "nft_approval", "nft_burn", "nft_metadata", "nft_admin", "nft_authority", "nft_listing", "nft_sale", "nft_drop"].iter().map(|s| s.to_string()).collect(),
    };
    Ok(Json(with_observed(with_state(&b, |_, _, _, store| {
        let mut out = vec![];
        for k in kinds {
            let mut prefix = k.as_bytes().to_vec();
            prefix.push(0);
            for (_, v) in store.scan(T::Events, &prefix, lim, true).map_err(ApiError::internal)? {
                if let Ok(j) = serde_json::from_slice::<Value>(&v) {
                    out.push(j);
                }
            }
        }
        out.sort_by(|a, b| b["height"].as_u64().cmp(&a["height"].as_u64()));
        out.truncate(lim);
        Ok(json!({"events": out, "source": "rebuildable index of on-chain receipts"}))
    })?)))
}

// ------------------------------------------------------------------ collections module (/v1/nft)

use crate::nft_views as nv;

#[derive(Deserialize)]
pub struct NftQ {
    owner: Option<String>,
    status: Option<String>,
    limit: Option<usize>,
}

fn need_module(p: &aureom_core::genesis::ChainParams) -> Result<(), ApiError> {
    if p.collections.is_none() {
        return Err(ApiError::code(404, "module_disabled", "the collections (NFT) module is not enabled in this network's genesis"));
    }
    Ok(())
}

fn col_id(st: &aureom_core::state::State, p: &aureom_core::genesis::ChainParams, s: &str) -> Result<(aureom_core::crypto::Addr, aureom_core::nft::Collection), ApiError> {
    need_module(p)?;
    let id = nv::resolve_collection(st, p, s).ok_or(ApiError::not_found("unknown collection (give the collection id or its slug)"))?;
    let c = aureom_core::nft::collection(&st.overlay(), &id).ok_or(ApiError::not_found("unknown collection"))?;
    Ok((id, c))
}

async fn nft_collections(State(b): State<B>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| Ok(nv::collections_view(st, p, h)))?)))
}
async fn nft_collection(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let (cid, c) = col_id(st, p, &id)?;
        Ok(nv::collection_view(st, p, h, &cid, &c))
    })?)))
}
async fn nft_collection_tokens(State(b): State<B>, Path(id): Path<String>, Query(q): Query<NftQ>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let (cid, _) = col_id(st, p, &id)?;
        let owner = match &q.owner {
            Some(o) => Some(p.parse_addr(o).map_err(ApiError::bad)?),
            None => None,
        };
        Ok(nv::tokens_view(st, p, h, &cid, owner, q.limit.unwrap_or(500).min(5000)))
    })?)))
}
async fn nft_authority_log(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let (cid, c) = col_id(st, p, &id)?;
        Ok(nv::authority_log_view(st, p, h, &cid, &c))
    })?)))
}
async fn nft_token(State(b): State<B>, Path((id, tok)): Path<(String, String)>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let (cid, _) = col_id(st, p, &id)?;
        let tid: u64 = tok.parse().map_err(|_| ApiError::bad("token id must be an unsigned integer"))?;
        let r = aureom_core::nft::token(&st.overlay(), &cid, tid).ok_or(ApiError::not_found("token was never minted in this collection"))?;
        Ok(nv::token_view(st, p, h, &cid, tid, &r, true))
    })?)))
}
async fn nft_owner(State(b): State<B>, Path(a): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        need_module(p)?;
        let ad = p.parse_addr(&a).map_err(ApiError::bad)?;
        Ok(nv::owner_view(st, p, h, &ad))
    })?)))
}
async fn nft_listings(State(b): State<B>, Query(q): Query<NftQ>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        need_module(p)?;
        Ok(nv::listings_view(st, p, h, q.status.as_deref(), q.limit.unwrap_or(200).min(2000)))
    })?)))
}
fn hex32p(s: &str) -> Result<[u8; 32], ApiError> {
    hex::decode(s).ok().and_then(|x| x.try_into().ok()).ok_or(ApiError::bad("id must be 64 hex characters"))
}
async fn nft_listing(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        need_module(p)?;
        let lid = hex32p(&id)?;
        let l = aureom_core::nft::listing(&st.overlay(), &lid).ok_or(ApiError::not_found("unknown listing"))?;
        let mut v = nv::listing_view(p, h, &lid, &l);
        v["state_height"] = h.saturating_sub(1).into();
        v["source"] = nv::SOURCE.into();
        Ok(v)
    })?)))
}
async fn nft_drop(State(b): State<B>, Path(id): Path<String>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        need_module(p)?;
        nv::drop_view(st, p, h, &hex32p(&id)?).ok_or(ApiError::not_found("unknown drop"))
    })?)))
}

#[derive(Deserialize)]
struct SimReq {
    unsigned_tx: String,
}

/// Dry-run an UNSIGNED transaction against this node's current state (never committed).
async fn simulate(State(b): State<B>, Json(req): Json<SimReq>) -> R {
    Ok(Json(with_observed(with_state(&b, |st, p, h, _| {
        let bytes = hex::decode(req.unsigned_tx.trim_start_matches("0x")).map_err(|_| ApiError::bad("unsigned_tx must be hex"))?;
        let u = <aureom_core::types::UnsignedTx as aureom_core::codec::Decode>::decode(&bytes).map_err(|e| ApiError::code(400, "malformed", &e.to_string()))?;
        let note = "simulated against this node's state at the next height; the real outcome can differ if state changes before inclusion. Nothing was committed or broadcast.";
        Ok(match aureom_core::exec::simulate(st, p, h, &u) {
            Ok(r) => json!({"admissible": true, "receipt": aureom_core::json::receipt_json(&r), "simulated_height": h, "txid": hex::encode(u.txid()), "note": note}),
            Err(e) => json!({"admissible": false, "error": {"code": e.code(), "message": e.to_string()}, "simulated_height": h, "txid": hex::encode(u.txid()), "note": note}),
        })
    })?)))
}

async fn metrics(State(b): State<B>) -> Response {
    let (h, peers, mp, extra) = match &*b {
        Backend::Pow(n) => {
            let c = n.chain.lock();
            let p = n.peers.lock().len();
            (c.height(), p, c.mempool.len(), format!("aureom_pow_hashes_total {}\naureom_pow_reorgs_total {}\n", n.hashes.load(Ordering::Relaxed), c.reorgs.len()))
        }
        Backend::Bft(n) => {
            let a = n.app.lock();
            (a.last_height, 0, a.pending_ids.len(), format!("aureom_bft_last_commit_signed_power {}\naureom_bft_last_commit_total_power {}\n", a.last_commit.signed_power, a.last_commit.total_power))
        }
    };
    let body = format!("# TYPE aureom_height gauge\naureom_height {h}\naureom_peers {peers}\naureom_mempool_txs {mp}\n{extra}");
    ([("content-type", "text/plain; version=0.0.4")], body).into_response()
}

pub fn public_router(b: B) -> Router {
    Router::new()
        .route("/v1/network", get(network))
        .route("/v1/health", get(health))
        .route("/v1/blocks", get(blocks))
        .route("/v1/blocks/{id}", get(block))
        .route("/v1/accounts/{addr}", get(account))
        .route("/v1/accounts/{addr}/transactions", get(account_txs))
        .route("/v1/transactions/{id}", get(transaction))
        .route("/v1/transactions", post(submit))
        .route("/v1/simulate", post(simulate))
        .route("/v1/mempool", get(mempool))
        .route("/v1/consensus/status", get(consensus))
        .route("/v1/validators", get(validators))
        .route("/v1/peers", get(peers))
        .route("/v1/sync", get(sync))
        .route("/v1/supply", get(supply))
        .route("/v1/tokens", get(tokens))
        .route("/v1/tokens/{id}", get(token))
        .route("/v1/multisigs/{addr}", get(multisig))
        .route("/v1/distributions/{id}", get(distribution))
        .route("/v1/proposals", get(proposals))
        .route("/v1/events", get(events))
        .route("/v1/nft/collections", get(nft_collections))
        .route("/v1/nft/collections/{id}", get(nft_collection))
        .route("/v1/nft/collections/{id}/tokens", get(nft_collection_tokens))
        .route("/v1/nft/collections/{id}/authority-log", get(nft_authority_log))
        .route("/v1/nft/tokens/{id}/{token}", get(nft_token))
        .route("/v1/nft/owners/{addr}", get(nft_owner))
        .route("/v1/nft/listings", get(nft_listings))
        .route("/v1/nft/listings/{id}", get(nft_listing))
        .route("/v1/nft/drops/{id}", get(nft_drop))
        .route("/metrics", get(metrics))
        .layer(axum::extract::DefaultBodyLimit::max(256 * 1024))
        .layer(tower_http::cors::CorsLayer::new().allow_origin(tower_http::cors::Any).allow_methods([axum::http::Method::GET, axum::http::Method::POST]).allow_headers([axum::http::header::CONTENT_TYPE]))
        .with_state(b)
}

// ------------------------------------------------------------------ admin

#[derive(Clone)]
pub struct AdminState {
    pub b: B,
    pub token: Arc<String>,
}

fn authorised(h: &HeaderMap, token: &str) -> bool {
    use subtle::ConstantTimeEq;
    let Some(v) = h.get("authorization").and_then(|v| v.to_str().ok()) else { return false };
    let Some(t) = v.strip_prefix("Bearer ") else { return false };
    t.len() == token.len() && bool::from(t.as_bytes().ct_eq(token.as_bytes()))
}

fn deny() -> ApiError {
    ApiError::code(401, "unauthorized", "admin API requires a valid bearer token")
}

async fn admin_status(State(s): State<AdminState>, h: HeaderMap) -> R {
    if !authorised(&h, &s.token) {
        return Err(deny());
    }
    Ok(Json(with_observed(json!({"admin": true, "faults": crate::faults::any_enabled(),
        "capabilities": ["peer-actions (pow)", "snapshots", "mining (pow)", "shutdown"],
        "not_available": ["signing", "shell", "database writes", "balance or validator edits"]}))))
}

#[derive(Deserialize)]
struct PeerAction {
    action: String,
    peer: String,
}

async fn admin_peer(State(s): State<AdminState>, h: HeaderMap, Json(a): Json<PeerAction>) -> R {
    if !authorised(&h, &s.token) {
        return Err(deny());
    }
    let Backend::Pow(n) = &*s.b else {
        return Err(ApiError::code(501, "not_supported", "peer management for BFT profiles is done in CometBFT (config.toml persistent_peers / unsafe RPC); this API does not proxy it"));
    };
    let now = views::now_ms();
    match a.action.as_str() {
        "connect" => {
            n.manual.lock().push(a.peer.clone());
        }
        "disconnect" | "ban" => {
            if a.action == "ban" {
                n.bans.lock().insert(a.peer.clone(), now + 3_600_000);
            }
            let mut peers = n.peers.lock();
            let ids: Vec<u64> = peers.iter().filter(|(_, p)| p.addr == a.peer || p.id == a.peer || p.listen_addr.as_deref() == Some(&a.peer)).map(|(k, _)| *k).collect();
            for k in &ids {
                if let Some(p) = peers.remove(k) {
                    let _ = p.tx.try_send(crate::p2p::Msg::Disconnect(format!("operator {}", a.action)));
                    if a.action == "ban" {
                        let mut bans = n.bans.lock();
                        bans.insert(p.id.clone(), now + 3_600_000);
                        bans.insert(p.addr.clone(), now + 3_600_000);
                        if let Some(l) = &p.listen_addr {
                            bans.insert(l.clone(), now + 3_600_000);
                        }
                    }
                }
            }
            if a.action == "disconnect" {
                n.manual.lock().retain(|x| x != &a.peer);
            }
            tracing::warn!("admin {} {} ({} connection(s))", a.action, a.peer, ids.len());
        }
        "unban" => {
            n.bans.lock().clear();
        }
        _ => return Err(ApiError::bad("action must be connect|disconnect|ban|unban")),
    }
    Ok(Json(with_observed(json!({"ok": true, "action": a.action, "peer": a.peer}))))
}

async fn admin_snapshot(State(s): State<AdminState>, h: HeaderMap) -> R {
    if !authorised(&h, &s.token) {
        return Err(deny());
    }
    let v = match &*s.b {
        Backend::Pow(n) => n.snapshot(),
        Backend::Bft(n) => n.snapshot(),
    }
    .map_err(ApiError::internal)?;
    Ok(Json(with_observed(v)))
}

#[derive(Deserialize)]
struct Mining {
    enabled: bool,
}

async fn admin_mining(State(s): State<AdminState>, h: HeaderMap, Json(m): Json<Mining>) -> R {
    if !authorised(&h, &s.token) {
        return Err(deny());
    }
    let Backend::Pow(n) = &*s.b else { return Err(ApiError::code(501, "not_supported", "mining exists only in the PoW profile")) };
    n.mining_enabled.store(m.enabled, Ordering::Relaxed);
    Ok(Json(with_observed(json!({"mining": m.enabled}))))
}

async fn admin_shutdown(State(s): State<AdminState>, h: HeaderMap) -> R {
    if !authorised(&h, &s.token) {
        return Err(deny());
    }
    match &*s.b {
        Backend::Pow(n) => {
            n.shutdown.store(true, Ordering::Relaxed);
            n.shutdown_notify.notify_waiters();
        }
        Backend::Bft(n) => n.shutdown_notify.notify_waiters(),
    }
    tokio::spawn(async {
        tokio::time::sleep(std::time::Duration::from_millis(300)).await;
        tracing::warn!("shutdown requested via admin API");
        std::process::exit(0);
    });
    Ok(Json(json!({"shutting_down": true})))
}

pub fn admin_router(s: AdminState) -> Router {
    Router::new()
        .route("/admin/v1/status", get(admin_status))
        .route("/admin/v1/peer-actions", post(admin_peer))
        .route("/admin/v1/snapshots", post(admin_snapshot))
        .route("/admin/v1/mining", post(admin_mining))
        .route("/admin/v1/shutdown", post(admin_shutdown))
        .layer(axum::extract::DefaultBodyLimit::max(16 * 1024))
        .with_state(s)
}
