use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NodeConfig {
    pub node_name: String,
    pub profile: String,
    pub genesis_path: PathBuf,
    /// Hex genesis hash this node must run; refusing to start otherwise.
    pub expected_genesis_hash: String,
    pub data_dir: PathBuf,
    pub api_listen: String,
    pub admin_listen: String,
    pub admin_token_path: PathBuf,
    #[serde(default)]
    pub pow: Option<PowConfig>,
    #[serde(default)]
    pub bft: Option<BftConfig>,
    #[serde(default)]
    pub mempool: MempoolConfig,
    #[serde(default)]
    pub pruning: PruningConfig,
    #[serde(default = "default_snapshot_dir")]
    pub snapshot_dir: PathBuf,
}

fn default_snapshot_dir() -> PathBuf {
    PathBuf::from("snapshots")
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PowConfig {
    pub p2p_listen: String,
    pub node_key_path: PathBuf,
    #[serde(default)]
    pub bootstrap_peers: Vec<String>,
    #[serde(default = "default_max_peers")]
    pub max_peers: usize,
    /// Learn addresses from peers (off for the first demonstrations).
    #[serde(default)]
    pub discovery: bool,
    #[serde(default)]
    pub mining: MiningConfig,
    /// Optional trusted checkpoint: the chain must contain this block.
    #[serde(default)]
    pub checkpoint: Option<Checkpoint>,
    /// Peer ids (hex pubkeys) allowed to connect; empty = any authenticated peer.
    #[serde(default)]
    pub allowed_peers: Vec<String>,
}

fn default_max_peers() -> usize {
    16
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct MiningConfig {
    pub enabled: bool,
    #[serde(default)]
    pub miner_address: String,
    /// Development throttle; 0 = unthrottled.
    #[serde(default)]
    pub max_hashes_per_sec: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Checkpoint {
    pub height: u64,
    pub block_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BftConfig {
    pub abci_listen: String,
    pub cometbft_rpc: String,
    pub cometbft_home: PathBuf,
    /// Trusted checkpoint for a joining node (weak subjectivity); informational for
    /// blocksync, enforced by CometBFT state sync when enabled there.
    #[serde(default)]
    pub trust_height: Option<u64>,
    #[serde(default)]
    pub trust_hash: Option<String>,
    #[serde(default)]
    pub trust_period: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MempoolConfig {
    pub max_txs: usize,
    pub max_bytes: usize,
    pub max_per_sender: usize,
    pub max_nonce_gap: u64,
    pub ttl_ms: u64,
}

impl Default for MempoolConfig {
    fn default() -> Self {
        MempoolConfig { max_txs: 5000, max_bytes: 8 << 20, max_per_sender: 64, max_nonce_gap: 32, ttl_ms: 600_000 }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PruningConfig {
    /// PoW: undo logs kept for this many blocks below the tip (max automatic reorg depth).
    pub keep_undo_blocks: u64,
    /// BFT: CometBFT retain height distance (0 = keep everything).
    pub keep_blocks: u64,
}

impl Default for PruningConfig {
    fn default() -> Self {
        PruningConfig { keep_undo_blocks: 1000, keep_blocks: 0 }
    }
}

impl NodeConfig {
    pub fn load(path: &Path) -> Result<(NodeConfig, PathBuf)> {
        let s = std::fs::read_to_string(path).with_context(|| format!("read config {}", path.display()))?;
        let mut c: NodeConfig = serde_json::from_str(&s).with_context(|| "parse node config")?;
        let base = path.parent().unwrap_or(Path::new(".")).to_path_buf();
        let fix = |p: &mut PathBuf| {
            if p.is_relative() {
                *p = base.join(&*p);
            }
        };
        fix(&mut c.genesis_path);
        fix(&mut c.data_dir);
        fix(&mut c.admin_token_path);
        fix(&mut c.snapshot_dir);
        if let Some(p) = c.pow.as_mut() {
            fix(&mut p.node_key_path);
        }
        if let Some(b) = c.bft.as_mut() {
            fix(&mut b.cometbft_home);
        }
        Ok((c, base))
    }
}
