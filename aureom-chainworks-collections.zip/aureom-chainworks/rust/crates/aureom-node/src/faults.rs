//! Development fault injection, controlled only by environment variables so that it can
//! never be enabled through configuration exports or the console.
//!
//! * `AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT=N` — abort the process inside the database
//!   write transaction that would commit height N (simulates a crash / power loss).
//! * `AUREOM_FAULT_P2P_DELAY_MS=N` — PoW: delay every outbound p2p message by N ms.

pub fn abort_height() -> Option<u64> {
    std::env::var("AUREOM_FAULT_ABORT_BEFORE_COMMIT_HEIGHT").ok()?.parse().ok()
}

pub fn p2p_delay_ms() -> u64 {
    std::env::var("AUREOM_FAULT_P2P_DELAY_MS").ok().and_then(|v| v.parse().ok()).unwrap_or(0)
}

pub fn any_enabled() -> Vec<String> {
    let mut v = vec![];
    if let Some(h) = abort_height() {
        v.push(format!("abort_before_commit_height={h}"));
    }
    let d = p2p_delay_ms();
    if d > 0 {
        v.push(format!("p2p_delay_ms={d}"));
    }
    v
}
