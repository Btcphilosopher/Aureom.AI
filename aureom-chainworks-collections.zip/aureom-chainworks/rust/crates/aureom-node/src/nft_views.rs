//! JSON views over the collections module's committed state (/v1/nft/*).
//! These read the authoritative ledger state of this node at its current height.

use aureom_core::codec::Decode;
use aureom_core::crypto::Addr;
use aureom_core::genesis::ChainParams;
use aureom_core::json::{asset_json, metadata_json, policy_name, spec_json};
use aureom_core::nft::{self, *};
use aureom_core::state::State;
use serde_json::{json, Value};

pub const SOURCE: &str = "authoritative on-chain state of the queried node at `height` (an application index is only a cache of this)";

fn opt_addr(p: &ChainParams, a: &Option<Addr>) -> Value {
    a.map(|x| Value::String(p.addr(&x))).unwrap_or(Value::Null)
}

pub fn module_json(p: &ChainParams) -> Value {
    match &p.collections {
        None => json!({"enabled": false}),
        Some(m) => json!({"enabled": true, "activation_height": m.activation_height, "marketplace": m.marketplace,
            "marketplace_fee_bps": m.fee_bps, "marketplace_fee_recipient": opt_addr(p, &m.fee_recipient),
            "implementation": "native state-machine module (not a smart contract; not ERC-721/ERC-1155 compatible)"}),
    }
}

/// Plain-language list of every administrative power, shown before creation and after.
pub fn powers(p: &ChainParams, c: &Collection) -> Vec<Value> {
    let s = &c.spec;
    let mut v = vec![];
    let who = |a: &Option<Addr>| a.map(|x| p.addr(&x)).unwrap_or_else(|| "nobody (renounced or never set)".into());
    v.push(json!({"power": "mint new tokens", "holder": who(&s.mint_authority), "limit": s.max_supply.map(|m| format!("at most {m} tokens ever (burns do not free capacity)")).unwrap_or_else(|| "UNCAPPED".into()), "risk": if s.mint_authority.is_some() && s.max_supply.is_none() { "high" } else { "normal" }}));
    v.push(match s.metadata_policy {
        POLICY_IMMUTABLE => json!({"power": "change metadata", "holder": "nobody", "limit": "immutable from creation (content hash fixed at mint)", "risk": "none"}),
        _ if c.frozen_all => json!({"power": "change metadata", "holder": "nobody", "limit": format!("collection frozen at height {}", c.frozen_height), "risk": "none"}),
        POLICY_FREEZABLE => json!({"power": "replace token metadata (recorded revisions) until frozen", "holder": who(&s.metadata_admin), "limit": "per-token or whole-collection freeze is permanent", "risk": "medium"}),
        _ => json!({"power": "replace token metadata (recorded revisions, no freeze available)", "holder": who(&s.metadata_admin), "limit": "every revision is kept on-chain", "risk": "medium"}),
    });
    if s.flags & CFLAG_PAUSABLE != 0 {
        v.push(json!({"power": "pause transfers, minting and sales", "holder": who(&s.admin), "limit": "reversible", "risk": "high"}));
    }
    if s.flags & CFLAG_FORCED_TRANSFER != 0 {
        v.push(json!({"power": "FORCE-TRANSFER any token without the owner's signature", "holder": who(&s.admin), "limit": "each use is a visible nft_transfer event with authority=forced_by_admin and a reason hash", "risk": "critical"}));
    }
    if s.flags & CFLAG_OWNER_BURN != 0 {
        v.push(json!({"power": "burn own token (holder right, not an admin power)", "holder": "each current owner", "limit": "token id is never reused", "risk": "none"}));
    }
    v.push(json!({"power": "reassign or renounce a role", "holder": "only the current holder of that role", "limit": "recorded in the authority log", "risk": "normal"}));
    v
}

pub fn collection_view(st: &State, p: &ChainParams, h: u64, id: &Addr, c: &Collection) -> Value {
    let ov = st.overlay();
    let s = &c.spec;
    json!({
        "collection_id": p.collection(id),
        "network": {"chain_id": p.doc.chain_id, "genesis_hash": hex::encode(p.hash)},
        "spec": spec_json(p, s),
        "roles": {
            "creator": p.addr(&c.creator),
            "admin": opt_addr(p, &s.admin),
            "mint_authority": opt_addr(p, &s.mint_authority),
            "metadata_admin": opt_addr(p, &s.metadata_admin),
            "royalty_recipient": s.royalty.as_ref().map(|r| p.addr(&r.recipient)),
            "rights_holder": s.rights_holder,
            "note": "creator, owner, operator, metadata administrator and intellectual-property rights holder are distinct; owning a token transfers no copyright and no physical object",
        },
        "administrative_powers": powers(p, c),
        "minted": c.minted, "burned": c.burned, "live": c.minted - c.burned,
        "max_supply": s.max_supply.map(|m| m.to_string()),
        "paused": c.paused,
        "metadata_policy": policy_name(s.metadata_policy),
        "metadata_frozen_all": c.frozen_all, "frozen_height": c.frozen_height,
        "metadata_root": hex::encode(nft::metadata_root(&ov, id)),
        "authority_changes": c.authority_changes,
        "royalty": s.royalty.as_ref().map(|r| json!({"recipient": p.addr(&r.recipient), "bps": r.bps,
            "enforced_by": "the native Chainworks marketplace (ListingBuy) only; direct transfers and other marketplaces may ignore it"})),
        "created_height": c.created_height,
        "state_height": h.saturating_sub(1), "source": SOURCE,
    })
}

pub fn collections_view(st: &State, p: &ChainParams, h: u64) -> Value {
    let v: Vec<Value> = st
        .scan_prefix(&[0x40])
        .map(|(k, v)| {
            let id: Addr = k[1..21].try_into().unwrap();
            let c = Collection::decode(v).unwrap();
            json!({"collection_id": p.collection(&id), "slug": c.spec.slug, "name": c.spec.name, "creator": p.addr(&c.creator),
                "minted": c.minted, "burned": c.burned, "max_supply": c.spec.max_supply.map(|m| m.to_string()),
                "metadata_policy": policy_name(c.spec.metadata_policy), "frozen_all": c.frozen_all, "paused": c.paused,
                "admin_powers": c.spec.flags & CFLAG_ADMIN_POWERS != 0, "created_height": c.created_height})
        })
        .collect();
    json!({"module": module_json(p), "collections": v, "state_height": h.saturating_sub(1), "source": SOURCE})
}

pub fn resolve_collection(st: &State, p: &ChainParams, s: &str) -> Option<Addr> {
    if let Ok(a) = p.parse_collection(s) {
        return Some(a);
    }
    st.get(&nft::keys::slug(s)).and_then(|v| v.clone().try_into().ok())
}

pub fn token_view(st: &State, p: &ChainParams, h: u64, cid: &Addr, tid: u64, r: &NftRecord, full: bool) -> Value {
    let ov = st.overlay();
    let active_listing = ov.get(&nft::keys::active_listing(cid, tid)).map(hex::encode);
    let mut v = json!({
        "ref": nft_ref(p, cid, tid),
        "collection_id": p.collection(cid), "token_id": tid.to_string(),
        "owner": if r.burned { Value::Null } else { Value::String(p.addr(&r.owner)) },
        "last_owner": p.addr(&r.owner),
        "burned": r.burned,
        "approved": opt_addr(p, &r.approval_active(h)),
        "approval_expiry_height": r.approval_expiry,
        "metadata": metadata_json(&r.metadata), "revision": r.revision, "metadata_frozen": r.frozen,
        "minted_height": r.minted_height, "minted_by": p.addr(&r.minted_by), "transfers": r.transfers,
        "last_change_height": r.last_change_height, "active_listing": active_listing,
        "state_height": h.saturating_sub(1), "source": SOURCE,
    });
    if full {
        let revs: Vec<Value> = (0..=r.revision)
            .filter_map(|i| ov.get(&nft::keys::revision(cid, tid, i)).map(|b| (i, MetadataRevision::decode(&b).unwrap())))
            .map(|(i, m)| json!({"revision": i, "metadata": metadata_json(&m.metadata), "height": m.height, "by": p.addr(&m.by)}))
            .collect();
        v["revisions"] = Value::Array(revs);
        // collection-wide operators of the current owner
        let mut prefix = vec![0x44];
        prefix.extend_from_slice(cid);
        prefix.extend_from_slice(&r.owner);
        let ops: Vec<Value> = st
            .scan_prefix(&prefix)
            .map(|(k, v)| {
                let op: Addr = k[41..61].try_into().unwrap();
                let e = aureom_core::types::decode_u64(v).unwrap();
                json!({"operator": p.addr(&op), "expiry_height": e, "active": e == 0 || h <= e})
            })
            .collect();
        v["owner_operators"] = Value::Array(ops);
    }
    v
}

pub fn tokens_view(st: &State, p: &ChainParams, h: u64, cid: &Addr, owner: Option<Addr>, limit: usize) -> Value {
    let v: Vec<Value> = st
        .scan_prefix(&nft::keys::tokens_of(cid))
        .filter_map(|(k, v)| {
            let r = NftRecord::decode(v).unwrap();
            if owner.is_some_and(|o| r.burned || r.owner != o) {
                return None;
            }
            Some(token_view(st, p, h, cid, u64::from_be_bytes(k[21..29].try_into().unwrap()), &r, false))
        })
        .take(limit)
        .collect();
    json!({"collection_id": p.collection(cid), "tokens": v, "state_height": h.saturating_sub(1), "source": SOURCE})
}

/// Every token held by `owner` across collections, plus every approval it has granted.
pub fn owner_view(st: &State, p: &ChainParams, h: u64, owner: &Addr) -> Value {
    let mut toks = vec![];
    let mut token_approvals = vec![];
    for (k, v) in st.scan_prefix(&[0x42]) {
        let r = NftRecord::decode(v).unwrap();
        if r.burned || &r.owner != owner {
            continue;
        }
        let cid: Addr = k[1..21].try_into().unwrap();
        let tid = u64::from_be_bytes(k[21..29].try_into().unwrap());
        if let Some(a) = r.approval_active(h) {
            token_approvals.push(json!({"collection_id": p.collection(&cid), "token_id": tid.to_string(), "approved": p.addr(&a), "expiry_height": r.approval_expiry,
                "scope": "this token only", "risk": "the approved address can transfer this one token until revoked, used or expired"}));
        }
        toks.push(token_view(st, p, h, &cid, tid, &r, false));
    }
    let mut operators = vec![];
    for (k, v) in st.scan_prefix(&[0x44]) {
        if &k[21..41] != owner {
            continue;
        }
        let cid: Addr = k[1..21].try_into().unwrap();
        let op: Addr = k[41..61].try_into().unwrap();
        let e = aureom_core::types::decode_u64(v).unwrap();
        operators.push(json!({"collection_id": p.collection(&cid), "operator": p.addr(&op), "expiry_height": e, "active": e == 0 || h <= e,
            "scope": "ALL of this owner's tokens in this collection, including ones acquired later",
            "risk": if e == 0 { "high: no expiry — the operator can move every token in the collection until revoked" } else { "elevated: collection-wide until expiry" }}));
    }
    json!({"address": p.addr(owner), "tokens": toks, "token_approvals": token_approvals, "operator_approvals": operators, "state_height": h.saturating_sub(1), "source": SOURCE})
}

pub fn listing_status(l: &Listing, h: u64) -> &'static str {
    match l.status {
        LISTING_ACTIVE if h > l.expiry_height => "expired",
        LISTING_ACTIVE => "active",
        LISTING_SOLD => "sold",
        LISTING_CANCELLED => "cancelled",
        LISTING_INVALIDATED => "invalidated",
        LISTING_EXPIRED => "expired",
        _ => "unknown",
    }
}

pub fn listing_view(p: &ChainParams, h: u64, id: &[u8; 32], l: &Listing) -> Value {
    json!({
        "listing_id": hex::encode(id), "seller": p.addr(&l.seller), "collection_id": p.collection(&l.collection), "token_id": l.token_id.to_string(),
        "ref": nft_ref(p, &l.collection, l.token_id),
        "price": l.price.to_string(), "currency": asset_json(p, &l.currency), "expiry_height": l.expiry_height, "created_height": l.created_height,
        "status": listing_status(l, h), "buyer": opt_addr(p, &l.buyer), "closed_height": l.closed_height,
        "settlement": if l.status == LISTING_SOLD { json!({"royalty": l.royalty_paid.to_string(), "royalty_recipient": opt_addr(p, &l.royalty_recipient),
            "platform_fee": l.platform_fee_paid.to_string(), "seller_proceeds": l.seller_proceeds.to_string(),
            "rounding": "royalty and platform fee are floor(price × bps / 10000); the seller receives the remainder; the network fee is paid separately by the buyer"}) } else { Value::Null },
        "chain_id": p.doc.chain_id,
    })
}

pub fn listings_view(st: &State, p: &ChainParams, h: u64, status: Option<&str>, limit: usize) -> Value {
    let v: Vec<Value> = st
        .scan_prefix(&[0x47])
        .filter_map(|(k, v)| {
            let id: [u8; 32] = k[1..33].try_into().unwrap();
            let l = Listing::decode(v).unwrap();
            if status.is_some_and(|s| s != listing_status(&l, h)) {
                return None;
            }
            Some(listing_view(p, h, &id, &l))
        })
        .take(limit)
        .collect();
    json!({"module": module_json(p), "listings": v, "state_height": h.saturating_sub(1), "source": SOURCE})
}

pub fn authority_log_view(st: &State, p: &ChainParams, h: u64, cid: &Addr, c: &Collection) -> Value {
    let ov = st.overlay();
    let v: Vec<Value> = (0..c.authority_changes)
        .filter_map(|i| ov.get(&nft::keys::authority_log(cid, i)).map(|b| (i, AuthorityChange::decode(&b).unwrap())))
        .map(|(i, a)| {
            let role = match a.role {
                ROLE_ADMIN => "admin",
                ROLE_MINT_AUTHORITY => "mint_authority",
                ROLE_METADATA_ADMIN => "metadata_admin",
                _ => "royalty_recipient",
            };
            json!({"seq": i, "role": role, "old": opt_addr(p, &a.old), "new": opt_addr(p, &a.new), "height": a.height, "by": p.addr(&a.by)})
        })
        .collect();
    json!({"collection_id": p.collection(cid), "authority_changes": v, "state_height": h.saturating_sub(1), "source": SOURCE})
}

pub fn drop_view(st: &State, p: &ChainParams, h: u64, id: &[u8; 32]) -> Option<Value> {
    let b = st.get(&nft::keys::drop(id))?;
    let d = Drop::decode(b).unwrap();
    Some(json!({"drop_id": hex::encode(id), "collection_id": p.collection(&d.collection), "creator": p.addr(&d.creator), "merkle_root": hex::encode(d.merkle_root),
        "claim_deadline_height": d.claim_deadline_height, "max_claims": d.max_claims, "claims": d.claims, "open": h <= d.claim_deadline_height && d.claims < d.max_claims,
        "state_height": h.saturating_sub(1), "source": SOURCE}))
}
