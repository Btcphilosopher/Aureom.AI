//! JSON views over committed state shared by all backends, and explorer index writers.

use crate::store::{index_key_addr, index_key_event, Batch, T};
use aureom_core::codec::Decode;
use aureom_core::crypto::{comet_address, Addr};
use aureom_core::exec;
use aureom_core::genesis::{ChainParams, Profile};
use aureom_core::state::State;
use aureom_core::types::*;
use base64::Engine;
use serde_json::{json, Value};
use std::collections::BTreeSet;

pub fn now_ms() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64
}

pub fn with_observed(mut v: Value) -> Value {
    if let Value::Object(m) = &mut v {
        m.insert("observed_at_ms".into(), now_ms().into());
    }
    v
}

fn opt_addr(p: &ChainParams, a: &Option<Addr>) -> Value {
    a.map(|x| Value::String(p.addr(&x))).unwrap_or(Value::Null)
}

pub fn token_view(p: &ChainParams, id: &Addr, t: &TokenInfo) -> Value {
    json!({
        "token_id": p.token(id),
        "symbol": t.symbol, "name": t.name, "decimals": t.decimals,
        "supply": t.supply.to_string(),
        "max_supply": t.max_supply.map(|m| m.to_string()),
        "creator": p.addr(&t.creator),
        "mint_authority": opt_addr(p, &t.mint_authority),
        "admin": opt_addr(p, &t.admin),
        "pausable": t.flags & FLAG_PAUSABLE != 0,
        "freezable": t.flags & FLAG_FREEZABLE != 0,
        "paused": t.paused,
        "metadata_uri": t.metadata_uri,
        "created_height": t.created_height,
        "verified": "on-chain facts: token_id, supply, max_supply, creator, permissions; issuer-supplied (unverified): name, symbol, metadata_uri",
    })
}

pub fn account_view(st: &State, p: &ChainParams, h: u64, addr: &Addr) -> Value {
    let a = st.account(addr);
    let ov = st.overlay();
    let mut bonded = 0u128;
    let mut unbonding = 0u128;
    if let Some(v) = ov.validator(addr) {
        bonded = v.bonded;
    }
    for (k, v) in st.scan_prefix(&[0x12]) {
        if &k[9..29] == addr {
            unbonding += Unbonding::decode(v).unwrap().amount;
        }
    }
    let mut tokens = vec![];
    for (k, v) in st.scan_prefix(&[0x03]) {
        if &k[21..41] != addr {
            continue;
        }
        let tid: Addr = k[1..21].try_into().unwrap();
        let b = TokenBalance::decode(v).unwrap();
        if let Some(t) = ov.token(&tid) {
            tokens.push(json!({
                "token_id": p.token(&tid), "symbol": t.symbol, "name": t.name, "decimals": t.decimals,
                "balance": b.amount.to_string(), "frozen": b.frozen,
                "issuer_permissions": {"mint_authority": opt_addr(p, &t.mint_authority), "admin": opt_addr(p, &t.admin),
                    "pausable": t.flags & FLAG_PAUSABLE != 0, "freezable": t.flags & FLAG_FREEZABLE != 0, "paused": t.paused},
            }));
        }
    }
    let ms = ov.multisig(addr).map(|m| json!({"signers": m.signers.iter().map(|s| p.addr(s)).collect::<Vec<_>>(), "threshold": m.threshold, "next_proposal_id": m.next_proposal_id}));
    json!({
        "address": p.addr(addr),
        "nonce": a.nonce,
        "height": h,
        "native": {
            "total": a.balance.to_string(),
            "available": a.available(h).to_string(),
            "locked_vesting": a.locked(h).to_string(),
            "immature": a.immature_amount(h).to_string(),
            "bonded": bonded.to_string(),
            "unbonding": unbonding.to_string(),
        },
        "vesting": a.vesting.iter().map(|v| json!({"total": v.total.to_string(), "start_height": v.start_height,
            "cliff_height": v.cliff_height, "end_height": v.end_height, "vested": v.vested(h).to_string(), "locked": v.locked(h).to_string()})).collect::<Vec<_>>(),
        "immature": a.immature.iter().filter(|i| h < i.mature_height).map(|i| json!({"amount": i.amount.to_string(), "mature_height": i.mature_height})).collect::<Vec<_>>(),
        "tokens": tokens,
        "multisig": ms,
    })
}

pub fn tokens_view(st: &State, p: &ChainParams) -> Value {
    let v: Vec<Value> = st
        .scan_prefix(&[0x02])
        .map(|(k, v)| token_view(p, &k[1..21].try_into().unwrap(), &TokenInfo::decode(v).unwrap()))
        .collect();
    json!({"tokens": v})
}

pub fn multisig_view(st: &State, p: &ChainParams, h: u64, addr: &Addr) -> Option<Value> {
    let ov = st.overlay();
    let m = ov.multisig(addr)?;
    let mut props = vec![];
    for id in 0..m.next_proposal_id {
        if let Some(pr) = ov.msig_proposal(addr, id) {
            let status = match pr.status {
                PROP_PENDING if h > pr.expiry_height => "expired",
                PROP_PENDING => "pending",
                PROP_EXECUTED => "executed",
                PROP_FAILED => "failed",
                _ => "expired",
            };
            props.push(json!({"id": id, "proposer": p.addr(&pr.proposer), "inner": aureom_core::json::action_json(p, &pr.inner),
                "approvals": pr.approvals.iter().map(|a| p.addr(a)).collect::<Vec<_>>(), "threshold": m.threshold,
                "expiry_height": pr.expiry_height, "status": status,
                "error": if pr.error_code == 0 { Value::Null } else { exec::err::name(pr.error_code).into() }}));
        }
    }
    Some(json!({"address": p.addr(addr), "signers": m.signers.iter().map(|s| p.addr(s)).collect::<Vec<_>>(),
        "threshold": m.threshold, "balance": st.account(addr).balance.to_string(), "proposals": props,
        "note": "approvals are separately signed on-chain transactions"}))
}

pub fn distribution_view(st: &State, p: &ChainParams, id: &[u8; 32]) -> Option<Value> {
    let d = st.overlay().distribution(id)?;
    Some(json!({"dist_id": hex::encode(id), "creator": p.addr(&d.creator), "asset": aureom_core::json::asset_json(p, &d.asset),
        "total": d.total.to_string(), "remaining": d.remaining.to_string(), "merkle_root": hex::encode(d.merkle_root),
        "claim_deadline_height": d.claim_deadline_height, "closed": d.closed, "claims": d.claims}))
}

pub fn proposals_view(st: &State, p: &ChainParams, h: u64) -> Value {
    let ov = st.overlay();
    let govs = exec::governors(&ov);
    let total: u64 = govs.values().sum();
    let mut v = vec![];
    for (_, val) in st.scan_prefix(&[0x20]) {
        let pr = GovProposal::decode(val).unwrap();
        let approving: u64 = pr.approvals.iter().filter_map(|a| govs.get(a)).sum();
        let status = match pr.status {
            PROP_PENDING if h > pr.expiry_height => "expired",
            PROP_PENDING => "pending",
            PROP_EXECUTED => "executed",
            PROP_FAILED => "failed",
            _ => "expired",
        };
        v.push(json!({"id": pr.id, "proposer": p.addr(&pr.proposer), "kind": aureom_core::json::gov_kind_json(p, &pr.kind),
            "created_height": pr.created_height, "expiry_height": pr.expiry_height, "executed_height": pr.executed_height,
            "approvals": pr.approvals.iter().map(|a| p.addr(a)).collect::<Vec<_>>(),
            "approving_power": approving, "total_power": total, "status": status}));
    }
    let gs = ov.gov_state();
    json!({"profile": p.profile.as_str(), "proposals": v,
        "threshold": format!("> {}/{} of governor voting power", p.doc.governance.approval_threshold_num, p.doc.governance.approval_threshold_den),
        "scheduled_upgrades": gs.upgrades.iter().map(|u| json!({"name": u.name, "protocol_version": u.protocol_version, "activation_height": u.activation_height})).collect::<Vec<_>>()})
}

pub fn validators_view(st: &State, p: &ChainParams, h: u64, signed_last: Option<&BTreeSet<Addr>>) -> Value {
    if p.profile == Profile::Pow {
        return json!({"profile": "pow", "validators": [], "total_power": 0, "note": "Proof-of-work networks have no validator set; block production is open to any miner."});
    }
    let ov = st.overlay();
    let set = ov.valset();
    let mut total = 0u64;
    let mut out = vec![];
    for v in ov.validators() {
        let power = set.0.iter().find(|(k, _)| *k == v.consensus_pubkey).map(|x| x.1).unwrap_or(0);
        total += power;
        let status = if v.removed {
            "removed"
        } else if v.tombstoned {
            "tombstoned"
        } else if v.jailed_until > h {
            "jailed"
        } else if power > 0 {
            "active"
        } else {
            "inactive"
        };
        let ca = comet_address(&v.consensus_pubkey);
        out.push(json!({"operator": p.addr(&v.operator), "moniker": v.moniker,
            "consensus_pubkey": base64::engine::general_purpose::STANDARD.encode(v.consensus_pubkey),
            "consensus_address": hex::encode_upper(ca), "power": power, "bonded": v.bonded.to_string(),
            "status": status, "jailed_until": if v.jailed_until == u64::MAX { Value::String("forever".into()) } else { v.jailed_until.into() },
            "missed_in_window": v.missed_in_window,
            "signed_last_block": signed_last.map(|s| Value::Bool(s.contains(&ca))).unwrap_or(Value::Null)}));
    }
    json!({"profile": p.profile.as_str(), "total_power": total, "validators": out,
        "note": if p.profile == Profile::Poa { "Permissioned network: authorities are explicit identities; several nodes run by one organisation are not decentralised." } else { "Voting power = floor(bonded / power_unit)." }})
}

pub fn supply_view(st: &State, p: &ChainParams, h: u64) -> Value {
    let rep = exec::reconcile(st, p, h);
    let mut v = serde_json::to_value(rep).unwrap();
    v["height"] = h.into();
    v["asset"] = json!({"name": p.doc.native_asset.name, "ticker": p.doc.native_asset.ticker, "decimals": p.doc.native_asset.decimals});
    v["policy"] = serde_json::to_value(&p.doc.monetary_policy).unwrap();
    v["note"] = "circulating excludes vesting-locked, immature, staked, unbonding, escrowed and genesis-treasury balances; coins at lost keys cannot be distinguished and are counted as circulating".into();
    v
}

/// Addresses touched by an action (for the explorer address index).
pub fn touched(tx: &SignedTx) -> Vec<Addr> {
    use Action::*;
    let mut v = vec![tx.tx.sender()];
    let mut add = |a: &Addr| {
        if !v.contains(a) {
            v.push(*a)
        }
    };
    match &tx.tx.action {
        Transfer { to, .. } | VestedTransfer { to, .. } | NativeMint { to, .. } | TokenTransfer { to, .. } | TokenMint { to, .. } => add(to),
        TokenCreate { initial_recipient, .. } => add(initial_recipient),
        TokenSetFrozen { account, .. } => add(account),
        MultisigPropose { multisig, inner, .. } => {
            add(multisig);
            if let Transfer { to, .. } | VestedTransfer { to, .. } | NativeMint { to, .. } | TokenTransfer { to, .. } | TokenMint { to, .. } = &**inner {
                add(to)
            }
        }
        MultisigApprove { multisig, .. } => add(multisig),
        Nft(n) => {
            use aureom_core::nft::NftAction as N;
            match n {
                N::Mint { item, .. } => add(&item.to),
                N::MintBatch { items, .. } => items.iter().for_each(|i| add(&i.to)),
                N::Transfer { to, .. } | N::ForceTransfer { to, .. } => add(to),
                N::Approve { approved: Some(a), .. } => add(a),
                N::SetOperator { operator, .. } => add(operator),
                _ => {}
            }
        }
        _ => {}
    }
    v
}

/// Write explorer index entries for a connected block (`del = true` removes them).
pub fn index_block(b: &mut Batch, height: u64, block_id: &[u8; 32], txs: &[SignedTx], receipts: &[Receipt], block_events: &[Event], del: bool) {
    for (i, (tx, r)) in txs.iter().zip(receipts).enumerate() {
        let id = tx.txid();
        if del {
            b.del(T::TxIndex, id.to_vec());
        } else {
            let mut v = height.to_be_bytes().to_vec();
            v.extend_from_slice(block_id);
            v.extend_from_slice(&(i as u32).to_be_bytes());
            b.put(T::TxIndex, id.to_vec(), v);
        }
        for a in touched(tx) {
            let k = index_key_addr(&a, height, i as u32);
            if del {
                b.del(T::AddrIndex, k)
            } else {
                b.put(T::AddrIndex, k, id.to_vec())
            }
        }
        for (j, e) in r.events.iter().enumerate() {
            let k = index_key_event(&e.kind, height, (i as u32) * 64 + j as u32);
            if del {
                b.del(T::Events, k);
            } else {
                b.put(T::Events, k, event_json(height, Some(&id), e).to_string().into_bytes());
            }
        }
    }
    for (j, e) in block_events.iter().enumerate() {
        let k = index_key_event(&e.kind, height, 0xFFFF_0000 + j as u32);
        if del {
            b.del(T::Events, k);
        } else {
            b.put(T::Events, k, event_json(height, None, e).to_string().into_bytes());
        }
    }
}

pub fn event_json(height: u64, txid: Option<&[u8; 32]>, e: &Event) -> Value {
    let mut m = serde_json::Map::new();
    for (k, v) in &e.attrs {
        m.insert(k.clone(), Value::String(v.clone()));
    }
    json!({"height": height, "txid": txid.map(hex::encode), "kind": e.kind, "attrs": m, "source": "on-chain receipt"})
}

pub fn decode_txindex(v: &[u8]) -> (u64, [u8; 32], u32) {
    (u64::from_be_bytes(v[0..8].try_into().unwrap()), v[8..40].try_into().unwrap(), u32::from_be_bytes(v[40..44].try_into().unwrap()))
}
