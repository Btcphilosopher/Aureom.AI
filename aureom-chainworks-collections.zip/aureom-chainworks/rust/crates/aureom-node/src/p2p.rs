//! PoW peer-to-peer protocol: length-prefixed canonical frames over TCP with an
//! Ed25519 challenge-response handshake binding chain id, genesis hash and both peer
//! identities. Frames are bounded before allocation; every peer has rate limits, a
//! misbehaviour score and a bounded outbound queue (backpressure).
//!
//! Limitation: the transport is authenticated but NOT encrypted (all data is public
//! chain data; see SECURITY-LIMITATIONS.md).

use aureom_core::codec::*;
use aureom_core::crypto::Hash32;

pub const P2P_PROTOCOL_MIN: u16 = 1;
pub const P2P_PROTOCOL_MAX: u16 = 1;

#[derive(Clone, Debug)]
pub enum Msg {
    Hello {
        protocol_min: u16,
        protocol_max: u16,
        chain_id: String,
        genesis_hash: Hash32,
        node_pubkey: [u8; 32],
        challenge: [u8; 32],
        best_height: u64,
        best_work: [u8; 32],
        listen_port: u16,
        software: String,
    },
    HelloAck { signature: [u8; 64] },
    Ping(u64),
    Pong(u64),
    Tx(Vec<u8>),
    Block(Vec<u8>),
    GetBlocks { locator: Vec<Hash32>, max: u32 },
    Blocks(Vec<Vec<u8>>),
    GetPeers,
    Peers(Vec<String>),
    Tip { height: u64, work: [u8; 32], id: Hash32 },
    Disconnect(String),
}

#[allow(dead_code)]
impl Msg {
    pub fn kind(&self) -> &'static str {
        match self {
            Msg::Hello { .. } => "hello",
            Msg::HelloAck { .. } => "hello_ack",
            Msg::Ping(_) => "ping",
            Msg::Pong(_) => "pong",
            Msg::Tx(_) => "tx",
            Msg::Block(_) => "block",
            Msg::GetBlocks { .. } => "get_blocks",
            Msg::Blocks(_) => "blocks",
            Msg::GetPeers => "get_peers",
            Msg::Peers(_) => "peers",
            Msg::Tip { .. } => "tip",
            Msg::Disconnect(_) => "disconnect",
        }
    }
}

pub fn encode(m: &Msg) -> Vec<u8> {
    let mut w = Writer::new();
    match m {
        Msg::Hello { protocol_min, protocol_max, chain_id, genesis_hash, node_pubkey, challenge, best_height, best_work, listen_port, software } => {
            w.u8(0);
            w.u16(*protocol_min);
            w.u16(*protocol_max);
            w.string(chain_id);
            w.fixed(genesis_hash);
            w.fixed(node_pubkey);
            w.fixed(challenge);
            w.u64(*best_height);
            w.fixed(best_work);
            w.u16(*listen_port);
            w.string(software);
        }
        Msg::HelloAck { signature } => {
            w.u8(1);
            w.fixed(signature);
        }
        Msg::Ping(n) => {
            w.u8(2);
            w.u64(*n)
        }
        Msg::Pong(n) => {
            w.u8(3);
            w.u64(*n)
        }
        Msg::Tx(b) => {
            w.u8(4);
            w.bytes(b)
        }
        Msg::Block(b) => {
            w.u8(5);
            w.bytes(b)
        }
        Msg::GetBlocks { locator, max } => {
            w.u8(6);
            w.vec(locator, |w, h| w.fixed(h));
            w.u32(*max);
        }
        Msg::Blocks(v) => {
            w.u8(7);
            w.vec(v, |w, b| w.bytes(b));
        }
        Msg::GetPeers => w.u8(8),
        Msg::Peers(v) => {
            w.u8(9);
            w.vec(v, |w, s| w.string(s));
        }
        Msg::Tip { height, work, id } => {
            w.u8(10);
            w.u64(*height);
            w.fixed(work);
            w.fixed(id);
        }
        Msg::Disconnect(r) => {
            w.u8(11);
            w.string(r)
        }
    }
    w.finish()
}

pub fn decode(b: &[u8], max_block: usize) -> DResult<Msg> {
    let mut r = Reader::new(b);
    let m = match r.u8()? {
        0 => Msg::Hello {
            protocol_min: r.u16()?,
            protocol_max: r.u16()?,
            chain_id: r.string(64)?,
            genesis_hash: r.fixed()?,
            node_pubkey: r.fixed()?,
            challenge: r.fixed()?,
            best_height: r.u64()?,
            best_work: r.fixed()?,
            listen_port: r.u16()?,
            software: r.string(64)?,
        },
        1 => Msg::HelloAck { signature: r.fixed()? },
        2 => Msg::Ping(r.u64()?),
        3 => Msg::Pong(r.u64()?),
        4 => Msg::Tx(r.bytes(65_536)?),
        5 => Msg::Block(r.bytes(max_block)?),
        6 => Msg::GetBlocks { locator: r.vec(64, 32, |r| r.fixed())?, max: r.u32()? },
        7 => Msg::Blocks(r.vec(256, 4, |r| r.bytes(max_block))?),
        8 => Msg::GetPeers,
        9 => Msg::Peers(r.vec(64, 4, |r| r.string(128))?),
        10 => Msg::Tip { height: r.u64()?, work: r.fixed()?, id: r.fixed()? },
        11 => Msg::Disconnect(r.string(256)?),
        t => return Err(DecodeError::BadTag(t, "p2p message")),
    };
    r.end()?;
    Ok(m)
}

/// Handshake signature message.
pub fn handshake_message(chain_id: &str, genesis: &Hash32, peer_challenge: &[u8; 32], signer_pubkey: &[u8; 32], peer_pubkey: &[u8; 32]) -> Vec<u8> {
    let mut w = Writer::new();
    let d = "AUREOM/P2P-HANDSHAKE/v1";
    w.u8(d.len() as u8);
    w.fixed(d.as_bytes());
    w.string(chain_id);
    w.fixed(genesis);
    w.fixed(peer_challenge);
    w.fixed(signer_pubkey);
    w.fixed(peer_pubkey);
    w.finish()
}

/// Simple token bucket.
pub struct Bucket {
    pub capacity: f64,
    pub tokens: f64,
    pub refill_per_ms: f64,
    pub last_ms: u64,
}

impl Bucket {
    pub fn new(capacity: f64, per_sec: f64, now: u64) -> Self {
        Bucket { capacity, tokens: capacity, refill_per_ms: per_sec / 1000.0, last_ms: now }
    }
    pub fn take(&mut self, n: f64, now: u64) -> bool {
        let dt = now.saturating_sub(self.last_ms) as f64;
        self.tokens = (self.tokens + dt * self.refill_per_ms).min(self.capacity);
        self.last_ms = now;
        if self.tokens >= n {
            self.tokens -= n;
            true
        } else {
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip_and_bounds() {
        let m = Msg::GetBlocks { locator: vec![[1; 32]; 3], max: 10 };
        let b = encode(&m);
        assert!(matches!(decode(&b, 1000).unwrap(), Msg::GetBlocks { .. }));
        // claimed 1M locator entries
        let mut bad = vec![6u8];
        bad.extend_from_slice(&1_000_000u32.to_be_bytes());
        assert!(decode(&bad, 1000).is_err());
        let big = encode(&Msg::Block(vec![0; 2000]));
        assert!(decode(&big, 1000).is_err());
    }
}
