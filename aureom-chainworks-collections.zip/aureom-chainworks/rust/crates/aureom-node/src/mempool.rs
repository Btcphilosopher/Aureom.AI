//! Bounded mempool (PoW profile): limits on total bytes, transaction count, per-sender
//! count, nonce gap and age. Acceptance here is local node policy and guarantees nothing
//! about inclusion.

use crate::config::MempoolConfig;
use aureom_core::crypto::{Addr, Hash32};
use aureom_core::exec::{self, TxInvalid};
use aureom_core::genesis::ChainParams;
use aureom_core::state::State;
use aureom_core::types::SignedTx;
use std::collections::{BTreeMap, HashMap, VecDeque};

#[derive(Clone)]
pub struct Entry {
    pub tx: SignedTx,
    pub size: usize,
    pub added_ms: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Reject {
    Invalid(TxInvalid),
    Duplicate,
    NonceTooHigh,
    Conflict,
    SenderLimit,
    Full,
}

impl Reject {
    pub fn code(&self) -> &'static str {
        match self {
            Reject::Invalid(e) => e.code(),
            Reject::Duplicate => "duplicate",
            Reject::NonceTooHigh => "nonce_gap_too_large",
            Reject::Conflict => "conflicting_nonce",
            Reject::SenderLimit => "sender_limit",
            Reject::Full => "mempool_full",
        }
    }
    pub fn message(&self) -> String {
        match self {
            Reject::Invalid(e) => e.to_string(),
            Reject::Duplicate => "transaction already known".into(),
            Reject::NonceTooHigh => "nonce too far ahead of account nonce".into(),
            Reject::Conflict => "another transaction with this nonce is pending (replacement needs a fee at least 10% higher)".into(),
            Reject::SenderLimit => "too many pending transactions from this sender".into(),
            Reject::Full => "mempool full and fee too low to evict".into(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct StatusRec {
    pub status: &'static str,
    pub reason: Option<String>,
    pub at_ms: u64,
}

pub struct Mempool {
    pub cfg: MempoolConfig,
    pub by_id: HashMap<Hash32, Entry>,
    by_sender: BTreeMap<Addr, BTreeMap<u64, Hash32>>,
    pub bytes: usize,
    /// Recent terminal statuses for transactions no longer in the pool (bounded).
    pub history: HashMap<Hash32, StatusRec>,
    history_order: VecDeque<Hash32>,
}

const HISTORY_MAX: usize = 20_000;

impl Mempool {
    pub fn new(cfg: MempoolConfig) -> Self {
        Mempool { cfg, by_id: HashMap::new(), by_sender: BTreeMap::new(), bytes: 0, history: HashMap::new(), history_order: VecDeque::new() }
    }

    pub fn record(&mut self, id: Hash32, status: &'static str, reason: Option<String>) {
        if !self.history.contains_key(&id) {
            self.history_order.push_back(id);
            if self.history_order.len() > HISTORY_MAX {
                if let Some(old) = self.history_order.pop_front() {
                    self.history.remove(&old);
                }
            }
        }
        self.history.insert(id, StatusRec { status, reason, at_ms: crate::views::now_ms() });
    }

    pub fn len(&self) -> usize {
        self.by_id.len()
    }

    fn remove(&mut self, id: &Hash32) -> Option<Entry> {
        let e = self.by_id.remove(id)?;
        self.bytes -= e.size;
        let s = e.tx.tx.sender();
        if let Some(m) = self.by_sender.get_mut(&s) {
            m.remove(&e.tx.tx.nonce);
            if m.is_empty() {
                self.by_sender.remove(&s);
            }
        }
        Some(e)
    }

    /// Admit a transaction. `h` is the height of the next block.
    pub fn add(&mut self, p: &ChainParams, st: &State, h: u64, tx: SignedTx, size: usize, now: u64) -> Result<Hash32, Reject> {
        let id = tx.txid();
        if self.by_id.contains_key(&id) {
            return Err(Reject::Duplicate);
        }
        exec::stateless_check(p, &tx, size).map_err(Reject::Invalid)?;
        let t = &tx.tx;
        if t.expiry_height != 0 && t.expiry_height < h {
            return Err(Reject::Invalid(TxInvalid::Expired(t.expiry_height)));
        }
        let sender = t.sender();
        let acct = st.account(&sender);
        if t.nonce < acct.nonce {
            return Err(Reject::Invalid(TxInvalid::BadNonce { expected: acct.nonce, got: t.nonce }));
        }
        if t.nonce > acct.nonce + self.cfg.max_nonce_gap {
            return Err(Reject::NonceTooHigh);
        }
        // fee affordability counting this sender's other pending fees
        let pending_fees: u128 = self.by_sender.get(&sender).map(|m| m.values().filter_map(|i| self.by_id.get(i)).map(|e| e.tx.tx.fee as u128).sum()).unwrap_or(0);
        let avail = acct.available(h);
        if pending_fees + t.fee as u128 > avail {
            return Err(Reject::Invalid(TxInvalid::InsufficientFee { available: avail.saturating_sub(pending_fees), fee: t.fee }));
        }
        if let Some(existing) = self.by_sender.get(&sender).and_then(|m| m.get(&t.nonce)).copied() {
            let old_fee = self.by_id[&existing].tx.tx.fee;
            if (t.fee as u128) * 10 < (old_fee as u128) * 11 {
                return Err(Reject::Conflict);
            }
            self.remove(&existing);
            self.record(existing, "dropped", Some("replaced by higher-fee transaction".into()));
        }
        if self.by_sender.get(&sender).map(|m| m.len()).unwrap_or(0) >= self.cfg.max_per_sender {
            return Err(Reject::SenderLimit);
        }
        while self.by_id.len() >= self.cfg.max_txs || self.bytes + size > self.cfg.max_bytes {
            // evict the lowest fee-per-byte transaction that is the last of its sender
            let victim = self
                .by_sender
                .values()
                .filter_map(|m| m.values().next_back())
                .filter_map(|i| self.by_id.get(i).map(|e| (*i, e.tx.tx.fee as u128 * 1_000_000 / e.size as u128)))
                .min_by_key(|x| x.1);
            match victim {
                Some((vid, rate)) if rate < t.fee as u128 * 1_000_000 / size as u128 => {
                    self.remove(&vid);
                    self.record(vid, "dropped", Some("evicted: mempool full".into()));
                }
                _ => return Err(Reject::Full),
            }
        }
        self.bytes += size;
        self.by_sender.entry(sender).or_default().insert(t.nonce, id);
        self.by_id.insert(id, Entry { tx, size, added_ms: now });
        self.history.remove(&id);
        Ok(id)
    }

    /// Select transactions for a block template: per-sender nonce order, highest
    /// fee-per-byte head first, within byte/count limits.
    pub fn select(&self, st: &State, max_bytes: usize, max_txs: usize) -> Vec<SignedTx> {
        let mut queues: Vec<VecDeque<&Entry>> = vec![];
        for (sender, m) in &self.by_sender {
            let mut expect = st.account(sender).nonce;
            let mut q = VecDeque::new();
            for (n, id) in m {
                if *n != expect {
                    break;
                }
                q.push_back(&self.by_id[id]);
                expect += 1;
            }
            if !q.is_empty() {
                queues.push(q);
            }
        }
        let mut out = vec![];
        let mut bytes = 0;
        while out.len() < max_txs {
            let best = queues
                .iter()
                .enumerate()
                .filter_map(|(i, q)| q.front().map(|e| (i, e.tx.tx.fee as u128 * 1_000_000 / e.size as u128)))
                .max_by_key(|x| x.1);
            let Some((i, _)) = best else { break };
            let e = queues[i].pop_front().unwrap();
            if bytes + e.size > max_bytes {
                queues[i].clear();
                continue;
            }
            bytes += e.size;
            out.push(e.tx.clone());
        }
        out
    }

    /// After the tip changed: drop included / invalidated / expired / aged-out entries.
    pub fn revalidate(&mut self, st: &State, h: u64, now: u64, included: &[Hash32]) {
        for id in included {
            if self.remove(id).is_some() {
                self.history.remove(id);
            }
        }
        let ids: Vec<Hash32> = self.by_id.keys().copied().collect();
        for id in ids {
            let e = &self.by_id[&id];
            let t = &e.tx.tx;
            let acct = st.account(&t.sender());
            let reason = if t.nonce < acct.nonce {
                Some("nonce already used by another included transaction")
            } else if t.expiry_height != 0 && t.expiry_height < h {
                Some("expired")
            } else if now.saturating_sub(e.added_ms) > self.cfg.ttl_ms {
                Some("mempool ttl exceeded")
            } else {
                None
            };
            if let Some(r) = reason {
                self.remove(&id);
                self.record(id, "dropped", Some(r.into()));
            }
        }
    }

    pub fn snapshot(&self, p: &ChainParams, limit: usize) -> serde_json::Value {
        let mut v: Vec<_> = self.by_id.iter().collect();
        v.sort_by_key(|(_, e)| e.added_ms);
        serde_json::json!({
            "count": self.by_id.len(), "bytes": self.bytes, "max_count": self.cfg.max_txs, "max_bytes": self.cfg.max_bytes,
            "max_per_sender": self.cfg.max_per_sender,
            "txs": v.iter().take(limit).map(|(id, e)| serde_json::json!({"id": hex::encode(id), "sender": p.addr(&e.tx.tx.sender()),
                "nonce": e.tx.tx.nonce, "fee": e.tx.tx.fee.to_string(), "size": e.size, "type": e.tx.tx.action.type_name(), "added_ms": e.added_ms})).collect::<Vec<_>>(),
            "note": "acceptance by this node's mempool does not guarantee inclusion",
        })
    }
}
