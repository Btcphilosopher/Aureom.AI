//! Proof-of-work chain: block index, cumulative-work fork choice, reorganisation with
//! undo logs, atomic persistence, crash recovery and block templates.

use crate::mempool::Mempool;
use crate::store::{Batch, Store, T};
use crate::views;
use anyhow::{bail, Context, Result};
use aureom_core::codec::{Decode, Encode, Reader, Writer};
use aureom_core::crypto::{Addr, Hash32};
use aureom_core::exec::{self, BlockCtx};
use aureom_core::genesis::ChainParams;
use aureom_core::pow::{self, Block, HeaderInvalid, PowHeader};
use aureom_core::state::{decode_undo, encode_undo, State, Undo};
use aureom_core::types::*;
use aureom_core::U256;
use serde_json::{json, Value};
use std::collections::{BTreeSet, HashMap, VecDeque};
use std::sync::Arc;

pub const ST_STORED: u8 = 1;
pub const ST_VALID: u8 = 2;
pub const ST_INVALID: u8 = 3;

#[derive(Clone, Debug)]
pub struct BlockMeta {
    pub height: u64,
    pub parent: Hash32,
    pub cumwork: U256,
    pub timestamp_ms: u64,
    pub target: U256,
    pub status: u8,
}

impl BlockMeta {
    fn encode(&self) -> Vec<u8> {
        let mut w = Writer::new();
        w.u64(self.height);
        w.fixed(&self.parent);
        w.fixed(&self.cumwork.to_big_endian());
        w.u64(self.timestamp_ms);
        w.fixed(&self.target.to_big_endian());
        w.u8(self.status);
        w.finish()
    }
    fn decode(b: &[u8]) -> Result<Self> {
        let mut r = Reader::new(b);
        let m = BlockMeta {
            height: r.u64()?,
            parent: r.fixed()?,
            cumwork: U256::from_big_endian(&r.fixed::<32>()?),
            timestamp_ms: r.u64()?,
            target: U256::from_big_endian(&r.fixed::<32>()?),
            status: r.u8()?,
        };
        r.end()?;
        Ok(m)
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum Accepted {
    Extended,
    Reorg { depth: u64, fork_height: u64 },
    SideChain,
    Duplicate,
    Orphan,
}

#[derive(Debug, Clone, thiserror::Error)]
pub enum BlockReject {
    #[error("malformed block: {0}")]
    Malformed(String),
    #[error("invalid header: {0}")]
    Header(#[from] HeaderInvalid),
    #[error("invalid block body: {0}")]
    Body(String),
    #[error("timestamp too far in the future")]
    FutureTime,
    #[error("block or ancestor previously marked invalid")]
    KnownInvalid,
    #[error("node halted: {0}")]
    Halted(String),
    #[error("conflicts with trusted checkpoint")]
    Checkpoint,
    #[error("storage error: {0}")]
    Storage(String),
}

impl BlockReject {
    /// Whether the sender should be penalised (objectively invalid data).
    pub fn is_misbehaviour(&self) -> bool {
        matches!(self, BlockReject::Malformed(_) | BlockReject::Header(_) | BlockReject::Body(_) | BlockReject::KnownInvalid)
    }
}

#[derive(Clone, Debug, serde::Serialize)]
pub struct ReorgRecord {
    pub at_ms: u64,
    pub depth: u64,
    pub fork_height: u64,
    pub old_tip: String,
    pub new_tip: String,
    pub returned_to_mempool: usize,
    pub dropped: usize,
}

pub struct Chain {
    pub p: Arc<ChainParams>,
    pub store: Store,
    pub state: State,
    pub index: HashMap<Hash32, BlockMeta>,
    pub main: Vec<Hash32>,
    pub mempool: Mempool,
    orphans: HashMap<Hash32, Vec<Block>>,
    orphan_count: usize,
    pub reorgs: VecDeque<ReorgRecord>,
    pub checkpoint: Option<(u64, Hash32)>,
    pub keep_undo: u64,
    pub halted: Option<String>,
    pub tip_changed_seq: u64,
}

const MAX_ORPHANS: usize = 128;

impl Chain {
    pub fn open(p: Arc<ChainParams>, store: Store, mempool: Mempool, keep_undo: u64, checkpoint: Option<(u64, Hash32)>) -> Result<Chain> {
        let mut c = Chain {
            p: p.clone(),
            store,
            state: State::new(),
            index: HashMap::new(),
            main: vec![],
            mempool,
            orphans: HashMap::new(),
            orphan_count: 0,
            reorgs: VecDeque::new(),
            checkpoint,
            keep_undo,
            halted: None,
            tip_changed_seq: 0,
        };
        match c.store.tip_height()? {
            None => c.init_genesis()?,
            Some(tip_h) => c.load(tip_h)?,
        }
        Ok(c)
    }

    fn init_genesis(&mut self) -> Result<()> {
        let st = self.p.genesis_state();
        let gb = pow::genesis_block(&self.p, st.root());
        let id = gb.header.id();
        let meta = BlockMeta { height: 0, parent: [0; 32], cumwork: pow::work(self.p.pow_initial_target), timestamp_ms: gb.header.timestamp_ms, target: self.p.pow_initial_target, status: ST_VALID };
        let mut b = Batch::default();
        b.put(T::Blocks, id.to_vec(), gb.encode());
        b.put(T::BlockMeta, id.to_vec(), meta.encode());
        b.put(T::Receipts, id.to_vec(), receipts_encode(&[]));
        b.height(0, Some(id.to_vec()));
        for (k, v) in st.entries() {
            b.put(T::State, k.clone(), v.clone());
        }
        b.meta("tip_height", 0u64.to_be_bytes().to_vec());
        b.meta("tip_id", id.to_vec());
        b.meta("genesis_hash", self.p.hash.to_vec());
        b.meta("profile", b"pow".to_vec());
        self.store.write(b)?;
        self.state = st;
        self.index.insert(id, meta);
        self.main = vec![id];
        Ok(())
    }

    fn load(&mut self, tip_h: u64) -> Result<()> {
        let gh = self.store.meta("genesis_hash")?.context("missing genesis hash in database")?;
        if gh != self.p.hash {
            bail!("database belongs to genesis {} but node is configured for {}", hex::encode(gh), hex::encode(self.p.hash));
        }
        for (k, v) in self.store.all(T::BlockMeta)? {
            self.index.insert(k.try_into().unwrap(), BlockMeta::decode(&v)?);
        }
        for h in 0..=tip_h {
            let id = self.store.height(h)?.with_context(|| format!("missing main-chain block at height {h}"))?;
            self.main.push(id.try_into().unwrap());
        }
        self.state = self.store.load_state()?;
        let tip = self.block(&self.tip())?.context("tip block missing")?;
        let root = self.state.root();
        if root != tip.header.state_root {
            bail!(
                "crash-recovery check failed: stored state root {} != tip header state root {} at height {}; restore from backup or snapshot and replay",
                hex::encode(root),
                hex::encode(tip.header.state_root),
                tip_h
            );
        }
        Ok(())
    }

    pub fn tip(&self) -> Hash32 {
        *self.main.last().unwrap()
    }
    pub fn height(&self) -> u64 {
        self.main.len() as u64 - 1
    }
    pub fn tip_meta(&self) -> &BlockMeta {
        &self.index[&self.tip()]
    }
    pub fn is_main(&self, id: &Hash32) -> bool {
        self.index.get(id).map(|m| self.main.get(m.height as usize) == Some(id)).unwrap_or(false)
    }
    pub fn block(&self, id: &Hash32) -> Result<Option<Block>> {
        Ok(match self.store.get(T::Blocks, id)? {
            Some(b) => Some(Block::decode(&b).map_err(|e| anyhow::anyhow!("corrupt block: {e}"))?),
            None => None,
        })
    }
    pub fn receipts(&self, id: &Hash32) -> Result<Vec<Receipt>> {
        Ok(match self.store.get(T::Receipts, id)? {
            Some(b) => receipts_decode(&b)?,
            None => vec![],
        })
    }

    /// Ancestor of `from` at `height` (walks the branch, shortcut via main chain).
    pub fn ancestor(&self, from: &Hash32, height: u64) -> Hash32 {
        let mut cur = *from;
        loop {
            let m = &self.index[&cur];
            if m.height == height {
                return cur;
            }
            if self.is_main(&cur) {
                return self.main[height as usize];
            }
            cur = m.parent;
        }
    }

    fn expected_target(&self, parent: &Hash32, height: u64) -> U256 {
        let f = |h: u64| {
            let id = self.ancestor(parent, h);
            let m = &self.index[&id];
            (m.timestamp_ms, m.target)
        };
        pow::next_target(&self.p, height, &f)
    }

    fn mtp(&self, parent: &Hash32) -> u64 {
        let mut ts = vec![];
        let mut cur = *parent;
        for _ in 0..11 {
            let m = &self.index[&cur];
            ts.push(m.timestamp_ms);
            if m.height == 0 {
                break;
            }
            cur = m.parent;
        }
        ts.reverse();
        pow::median_time_past(&ts)
    }

    /// Context-free and header checks without storing anything.
    pub fn check_block_header(&self, b: &Block, now: u64) -> Result<(), BlockReject> {
        let parent = self.index.get(&b.header.prev_id).ok_or(BlockReject::Body("unknown parent".into()))?;
        if parent.status == ST_INVALID {
            return Err(BlockReject::KnownInvalid);
        }
        let expected = self.expected_target(&b.header.prev_id, parent.height + 1);
        pow::check_header(&self.p, &b.header, parent.height, expected, self.mtp(&b.header.prev_id))?;
        if b.header.timestamp_ms > now + self.p.pow().max_future_drift_ms {
            return Err(BlockReject::FutureTime);
        }
        Ok(())
    }

    pub fn accept_block(&mut self, b: Block, now: u64) -> Result<Accepted, BlockReject> {
        if let Some(h) = &self.halted {
            return Err(BlockReject::Halted(h.clone()));
        }
        let id = b.header.id();
        if let Some(m) = self.index.get(&id) {
            return if m.status == ST_INVALID { Err(BlockReject::KnownInvalid) } else { Ok(Accepted::Duplicate) };
        }
        let lim = &self.p.doc.limits;
        let size = b.encode().len();
        if size as u64 > lim.max_block_bytes + 1024 || b.txs.len() > lim.max_block_txs as usize {
            return Err(BlockReject::Malformed(format!("block exceeds limits ({size} bytes, {} txs)", b.txs.len())));
        }
        if !self.index.contains_key(&b.header.prev_id) {
            if self.orphan_count < MAX_ORPHANS {
                self.orphans.entry(b.header.prev_id).or_default().push(b);
                self.orphan_count += 1;
            }
            return Ok(Accepted::Orphan);
        }
        self.check_block_header(&b, now)?;
        if aureom_core::types::tx_root(&b.txs) != b.header.tx_root {
            return Err(BlockReject::Body("tx_root mismatch".into()));
        }
        let mut seen = BTreeSet::new();
        for t in &b.txs {
            if !seen.insert(t.txid()) {
                return Err(BlockReject::Body("duplicate transaction in block".into()));
            }
        }
        let parent = self.index[&b.header.prev_id].clone();
        let meta = BlockMeta {
            height: parent.height + 1,
            parent: b.header.prev_id,
            cumwork: parent.cumwork.saturating_add(pow::work(b.header.target_u256())),
            timestamp_ms: b.header.timestamp_ms,
            target: b.header.target_u256(),
            status: ST_STORED,
        };
        let mut batch = Batch::default();
        batch.put(T::Blocks, id.to_vec(), b.encode());
        batch.put(T::BlockMeta, id.to_vec(), meta.encode());
        self.store.write(batch).map_err(|e| BlockReject::Storage(e.to_string()))?;
        self.index.insert(id, meta.clone());

        let result = if meta.cumwork > self.tip_meta().cumwork {
            self.switch_to(id, now)?
        } else {
            Accepted::SideChain
        };
        // connect any orphans waiting for this block
        if let Some(children) = self.orphans.remove(&id) {
            self.orphan_count -= children.len();
            for c in children {
                let _ = self.accept_block(c, now);
            }
        }
        Ok(result)
    }

    fn mark_invalid(&mut self, id: &Hash32) {
        let mut batch = Batch::default();
        // the block and every known descendant
        let mut bad = vec![*id];
        let mut changed = true;
        while changed {
            changed = false;
            for (k, m) in &self.index {
                if bad.contains(&m.parent) && !bad.contains(k) {
                    bad.push(*k);
                    changed = true;
                }
            }
        }
        for k in bad {
            if let Some(m) = self.index.get_mut(&k) {
                m.status = ST_INVALID;
                batch.put(T::BlockMeta, k.to_vec(), m.encode());
            }
        }
        let _ = self.store.write(batch);
    }

    /// Execute a block on the current state (which must be at its parent).
    fn connect(&mut self, b: &Block) -> Result<(Undo, Vec<Receipt>, Vec<Event>), String> {
        let h = b.header.height;
        let mut ctx = BlockCtx::new(h, Some(b.header.miner));
        let mut ov = self.state.overlay();
        if let Err(e) = exec::check_upgrade_halt(&ov, h) {
            return Err(format!("HALT: {e}"));
        }
        let receipts = exec::execute_txs(&mut ov, &self.p, &mut ctx, &b.txs).map_err(|(i, e)| format!("tx {i}: {e}"))?;
        let evs = exec::pow_coinbase(&mut ov, &self.p, &mut ctx, &b.header.miner);
        let cs = ov.into_changes();
        let undo = self.state.apply(&cs);
        if self.state.root() != b.header.state_root {
            self.state.revert(&undo);
            return Err("state_root mismatch".into());
        }
        if receipt_root(&receipts) != b.header.receipt_root {
            self.state.revert(&undo);
            return Err("receipt_root mismatch".into());
        }
        Ok((undo, receipts, evs))
    }

    /// Make `new_tip` the best chain (extend or reorganise), atomically.
    fn switch_to(&mut self, new_tip: Hash32, now: u64) -> Result<Accepted, BlockReject> {
        let mut branch = vec![];
        let mut cur = new_tip;
        while !self.is_main(&cur) {
            branch.push(cur);
            cur = self.index[&cur].parent;
        }
        branch.reverse();
        let fork = cur;
        let fork_h = self.index[&fork].height;
        let old_tip = self.tip();
        let old_h = self.height();
        let depth = old_h - fork_h;
        if let Some((cph, cpid)) = self.checkpoint {
            if fork_h < cph && branch.iter().any(|b| self.index[b].height == cph && *b != cpid) {
                return Err(BlockReject::Checkpoint);
            }
        }
        if depth > self.keep_undo {
            let msg = format!("reorganisation of depth {depth} exceeds undo retention {}; manual resync required", self.keep_undo);
            self.halted = Some(msg.clone());
            return Err(BlockReject::Halted(msg));
        }
        let backup_state = self.state.clone();
        let backup_main = self.main.clone();
        let mut batch = Batch::default();
        let mut touched: BTreeSet<Vec<u8>> = BTreeSet::new();
        let mut disconnected: Vec<SignedTx> = vec![];
        // ---- disconnect
        for h in (fork_h + 1..=old_h).rev() {
            let id = self.main[h as usize];
            let undo_b = self.store.get(T::Undo, &id).map_err(|e| BlockReject::Storage(e.to_string()))?.ok_or_else(|| BlockReject::Storage(format!("missing undo for height {h}")))?;
            let undo = decode_undo(&undo_b).map_err(|e| BlockReject::Storage(e.to_string()))?;
            for (k, _) in &undo {
                touched.insert(k.clone());
            }
            self.state.revert(&undo);
            let blk = self.block(&id).map_err(|e| BlockReject::Storage(e.to_string()))?.unwrap();
            let rc = self.receipts(&id).unwrap_or_default();
            views::index_block(&mut batch, h, &id, &blk.txs, &rc, &[], true);
            batch.height(h, None);
            disconnected.extend(blk.txs);
            self.main.pop();
        }
        // ---- connect
        let mut included = vec![];
        for id in &branch {
            let blk = self.block(id).map_err(|e| BlockReject::Storage(e.to_string()))?.unwrap();
            match self.connect(&blk) {
                Ok((undo, receipts, evs)) => {
                    for (k, _) in &undo {
                        touched.insert(k.clone());
                    }
                    let h = blk.header.height;
                    batch.put(T::Undo, id.to_vec(), encode_undo(&undo));
                    batch.put(T::Receipts, id.to_vec(), receipts_encode(&receipts));
                    views::index_block(&mut batch, h, id, &blk.txs, &receipts, &evs, false);
                    batch.height(h, Some(id.to_vec()));
                    let m = self.index.get_mut(id).unwrap();
                    m.status = ST_VALID;
                    batch.put(T::BlockMeta, id.to_vec(), m.encode());
                    if let Some(prune_h) = h.checked_sub(self.keep_undo + 1) {
                        if let Some(old) = backup_main.get(prune_h as usize).or(self.main.get(prune_h as usize)) {
                            batch.del(T::Undo, old.to_vec());
                        }
                    }
                    included.extend(blk.txs.iter().map(|t| t.txid()));
                    self.main.push(*id);
                }
                Err(e) => {
                    self.state = backup_state;
                    self.main = backup_main;
                    if e.starts_with("HALT") {
                        self.halted = Some(e.clone());
                        return Err(BlockReject::Halted(e));
                    }
                    self.mark_invalid(id);
                    return Err(BlockReject::Body(e));
                }
            }
        }
        for k in &touched {
            match self.state.get(k) {
                Some(v) => batch.put(T::State, k.clone(), v.clone()),
                None => batch.del(T::State, k.clone()),
            }
        }
        let new_h = self.height();
        batch.meta("tip_height", new_h.to_be_bytes().to_vec());
        batch.meta("tip_id", self.tip().to_vec());
        if let Err(e) = self.store.write(batch) {
            self.state = backup_state;
            self.main = backup_main;
            return Err(BlockReject::Storage(e.to_string()));
        }
        self.tip_changed_seq += 1;
        // ---- mempool: return disconnected txs, then revalidate everything
        let inc: BTreeSet<Hash32> = included.iter().copied().collect();
        let mut returned = 0;
        let mut dropped = 0;
        let next_h = new_h + 1;
        for tx in disconnected {
            let id = tx.txid();
            if inc.contains(&id) {
                continue;
            }
            let size = tx.encode().len();
            match self.mempool.add(&self.p, &self.state, next_h, tx, size, now) {
                Ok(_) => returned += 1,
                Err(e) => {
                    dropped += 1;
                    self.mempool.record(id, "dropped", Some(format!("invalid after reorganisation: {}", e.message())));
                }
            }
        }
        self.mempool.revalidate(&self.state, next_h, now, &included);
        if depth > 0 {
            self.reorgs.push_back(ReorgRecord {
                at_ms: now,
                depth,
                fork_height: fork_h,
                old_tip: hex::encode(old_tip),
                new_tip: hex::encode(self.tip()),
                returned_to_mempool: returned,
                dropped,
            });
            if self.reorgs.len() > 50 {
                self.reorgs.pop_front();
            }
            tracing::warn!(depth, fork_h, "chain reorganisation: {} -> {}", hex::encode(&old_tip[..6]), hex::encode(&self.tip()[..6]));
            Ok(Accepted::Reorg { depth, fork_height: fork_h })
        } else {
            Ok(Accepted::Extended)
        }
    }

    /// Build a block template for `miner` (header not yet solved).
    pub fn template(&self, miner: Addr, now: u64) -> Block {
        let h = self.height() + 1;
        let lim = &self.p.doc.limits;
        let cand = self.mempool.select(&self.state, lim.max_block_bytes as usize - 1024, lim.max_block_txs as usize);
        let mut ctx = BlockCtx::new(h, Some(miner));
        let mut ov = self.state.overlay();
        let mut txs = vec![];
        let mut receipts = vec![];
        for t in cand {
            let size = t.encode().len();
            if let Ok(r) = exec::apply_tx(&mut ov, &self.p, &mut ctx, &t, size) {
                txs.push(t);
                receipts.push(r);
            }
        }
        exec::pow_coinbase(&mut ov, &self.p, &mut ctx, &miner);
        let cs = ov.into_changes();
        let mut st = self.state.clone();
        st.apply(&cs);
        let root = st.root();
        let parent = self.tip();
        let ts = now.max(self.mtp(&parent) + 1);
        let target = self.expected_target(&parent, h);
        Block {
            header: PowHeader {
                version: PROTOCOL_VERSION,
                chain_id: self.p.doc.chain_id.clone(),
                height: h,
                prev_id: parent,
                timestamp_ms: ts,
                tx_root: tx_root(&txs),
                receipt_root: receipt_root(&receipts),
                state_root: root,
                miner,
                target: target.to_big_endian(),
                nonce: 0,
            },
            txs,
        }
    }

    /// Locator: ids at tip, tip-1, tip-2, tip-4, ..., genesis.
    pub fn locator(&self) -> Vec<Hash32> {
        let mut v = vec![];
        let mut step = 1u64;
        let mut h = self.height() as i64;
        while h > 0 && v.len() < 60 {
            v.push(self.main[h as usize]);
            if v.len() > 8 {
                step *= 2;
            }
            h -= step as i64;
        }
        v.push(self.main[0]);
        v
    }

    /// Main-chain blocks after the first locator entry we know on our main chain.
    pub fn blocks_after(&self, locator: &[Hash32], max: usize, max_bytes: usize) -> Vec<Vec<u8>> {
        let start = locator.iter().find(|id| self.is_main(id)).map(|id| self.index[id].height + 1).unwrap_or(1);
        let mut out = vec![];
        let mut bytes = 0;
        for h in start..=self.height() {
            if out.len() >= max {
                break;
            }
            if let Ok(Some(b)) = self.store.get(T::Blocks, &self.main[h as usize]) {
                bytes += b.len();
                if bytes > max_bytes && !out.is_empty() {
                    break;
                }
                out.push(b);
            }
        }
        out
    }

    pub fn block_json(&self, id: &Hash32) -> Result<Option<Value>> {
        let Some(b) = self.block(id)? else { return Ok(None) };
        let m = &self.index[id];
        let on_main = self.is_main(id);
        let receipts = if on_main { self.receipts(id)? } else { vec![] };
        let conf = if on_main { self.height() - m.height + 1 } else { 0 };
        let p = &self.p;
        Ok(Some(json!({
            "height": m.height, "id": hex::encode(id), "prev_id": hex::encode(b.header.prev_id),
            "timestamp_ms": b.header.timestamp_ms, "proposer": p.addr(&b.header.miner), "tx_count": b.txs.len(),
            "size_bytes": b.encode().len(), "state_root": hex::encode(b.header.state_root),
            "tx_root": hex::encode(b.header.tx_root), "receipt_root": hex::encode(b.header.receipt_root),
            "txs": b.txs.iter().map(|t| aureom_core::json::unsigned_tx_json(p, &t.tx)).collect::<Vec<_>>(),
            "receipts": receipts.iter().map(aureom_core::json::receipt_json).collect::<Vec<_>>(),
            "consensus": {"pow": {"target": format!("{:064x}", b.header.target_u256()), "nonce": b.header.nonce.to_string(),
                "pow_hash": hex::encode(b.header.pow_hash()), "work": pow::work(b.header.target_u256()).to_string(),
                "cumulative_work": m.cumwork.to_string()}},
            "status": match m.status { ST_VALID => "valid", ST_INVALID => "invalid", _ => "stored-unvalidated" },
            "on_main_chain": on_main, "confirmations": conf, "finality": "probabilistic",
        })))
    }

    pub fn block_summary(&self, h: u64) -> Option<Value> {
        let id = self.main.get(h as usize)?;
        let b = self.block(id).ok()??;
        Some(json!({"height": h, "id": hex::encode(id), "timestamp_ms": b.header.timestamp_ms,
            "proposer": self.p.addr(&b.header.miner), "tx_count": b.txs.len(), "confirmations": self.height() - h + 1}))
    }

    /// Re-execute the main chain from genesis and check every state root (offline audit).
    pub fn verify_chain(&self) -> Result<u64> {
        let mut st = self.p.genesis_state();
        let g = self.block(&self.main[0])?.unwrap();
        if g.header.state_root != st.root() || g.header.prev_id != self.p.hash {
            bail!("genesis block does not match genesis document");
        }
        for h in 1..=self.height() {
            let b = self.block(&self.main[h as usize])?.unwrap();
            let mut ctx = BlockCtx::new(h, Some(b.header.miner));
            let mut ov = st.overlay();
            exec::execute_txs(&mut ov, &self.p, &mut ctx, &b.txs).map_err(|(i, e)| anyhow::anyhow!("height {h} tx {i}: {e}"))?;
            exec::pow_coinbase(&mut ov, &self.p, &mut ctx, &b.header.miner);
            let cs = ov.into_changes();
            st.apply(&cs);
            if st.root() != b.header.state_root {
                bail!("state root mismatch at height {h}");
            }
        }
        if st.root() != self.state.root() {
            bail!("replayed state differs from stored state");
        }
        Ok(self.height())
    }
}

pub fn receipts_encode(r: &[Receipt]) -> Vec<u8> {
    let mut w = Writer::new();
    w.vec(r, |w, x| x.encode_to(w));
    w.finish()
}
pub fn receipts_decode(b: &[u8]) -> Result<Vec<Receipt>> {
    let mut r = Reader::new(b);
    let v = r.vec(100_000, 8, Receipt::decode_from)?;
    r.end()?;
    Ok(v)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::MempoolConfig;
    use aureom_core::crypto::test_keypair;
    use aureom_core::genesis::tests::dev_genesis;

    struct Tmp(std::path::PathBuf);
    impl Drop for Tmp {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }
    fn chain(tag: &str) -> (Chain, Tmp) {
        let p = Arc::new(ChainParams::from_value(&dev_genesis("pow")).unwrap());
        let d = std::env::temp_dir().join(format!("aureom-chain-{tag}-{}-{}", std::process::id(), crate::views::now_ms()));
        let c = Chain::open(p, Store::open(&d).unwrap(), Mempool::new(MempoolConfig::default()), 1000, None).unwrap();
        (c, Tmp(d))
    }
    fn mine_next(c: &mut Chain, miner: &str, t: u64) -> Block {
        let mut b = c.template(test_keypair(miner).address(), t);
        assert!(aureom_core::pow::mine(&mut b.header, 10_000_000));
        assert!(matches!(c.accept_block(b.clone(), t), Ok(Accepted::Extended)));
        b
    }
    fn transfer(c: &Chain, nonce: u64) -> SignedTx {
        let kp = test_keypair("alice");
        UnsignedTx { version: 1, chain_id: c.p.doc.chain_id.clone(), nonce, fee: 5000, expiry_height: 0, sender_pubkey: kp.public(),
            action: Action::Transfer { to: test_keypair("bob").address(), amount: 7 }, memo: vec![] }.sign(&kp)
    }

    #[test]
    fn cumulative_work_reorg_restores_state_and_mempool() {
        let (mut a, _ta) = chain("a");
        let (mut b, _tb) = chain("b");
        let t0 = a.p.doc.genesis_time_ms;
        // branch A: 2 blocks, the first containing a transfer
        let tx = transfer(&a, 0);
        let size = tx.encode().len();
        {
            let Chain { mempool, state, p, .. } = &mut a;
            mempool.add(p, state, 1, tx.clone(), size, t0).unwrap();
        }
        let a1 = mine_next(&mut a, "minerA", t0 + 1000);
        assert_eq!(a1.txs.len(), 1);
        mine_next(&mut a, "minerA", t0 + 2000);
        // branch B: 3 empty blocks (more cumulative work at equal targets)
        let bs: Vec<Block> = (1..=3).map(|i| mine_next(&mut b, "minerB", t0 + 1000 * i)).collect();
        let b_root = b.state.root();
        for blk in &bs {
            let _ = a.accept_block(blk.clone(), t0 + 10_000);
        }
        assert_eq!(a.tip(), b.tip(), "A switched to the branch with more work");
        assert_eq!(a.state.root(), b_root, "state equals the winning branch exactly");
        assert_eq!(a.reorgs.back().unwrap().depth, 2);
        assert!(a.mempool.by_id.contains_key(&tx.txid()), "disconnected tx returned to mempool");
        // persisted atomically: reopen from disk
        let p = a.p.clone();
        let path = a.store.path.parent().unwrap().to_path_buf();
        drop(a);
        let a2 = Chain::open(p, Store::open(&path).unwrap(), Mempool::new(MempoolConfig::default()), 1000, None).unwrap();
        assert_eq!(a2.state.root(), b_root);
        assert_eq!(a2.verify_chain().unwrap(), 3);
    }

    #[test]
    fn invalid_block_is_rejected_and_marked() {
        let (mut a, _ta) = chain("inv");
        let t0 = a.p.doc.genesis_time_ms;
        let mut blk = a.template(test_keypair("m").address(), t0 + 1000);
        blk.header.state_root = [9; 32]; // wrong state commitment
        assert!(aureom_core::pow::mine(&mut blk.header, 10_000_000));
        let r = a.accept_block(blk.clone(), t0 + 1000);
        assert!(matches!(r, Err(BlockReject::Body(ref m)) if m.contains("state_root")), "{r:?}");
        assert!(matches!(a.accept_block(blk, t0 + 1000), Err(BlockReject::KnownInvalid)));
        assert_eq!(a.height(), 0);
        // future timestamp beyond drift: ignored, not marked invalid
        let mut f = a.template(test_keypair("m").address(), t0 + 1000);
        f.header.timestamp_ms = t0 + 10_000_000;
        assert!(aureom_core::pow::mine(&mut f.header, 10_000_000));
        assert!(matches!(a.accept_block(f, t0 + 1000), Err(BlockReject::FutureTime)));
    }
}
