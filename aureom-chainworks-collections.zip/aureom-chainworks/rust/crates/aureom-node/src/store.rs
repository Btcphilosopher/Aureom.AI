//! Embedded transactional storage (redb). Every block application is one ACID write
//! transaction: state changes, block data, receipts, undo log, indexes and the tip
//! pointer commit together or not at all.

use anyhow::{bail, Context, Result};
use aureom_core::state::State;
use redb::{Database, ReadableDatabase, ReadableTable, TableDefinition};
use std::path::{Path, PathBuf};

pub const DB_VERSION: u32 = 1;

pub const META: TableDefinition<&str, &[u8]> = TableDefinition::new("meta");
pub const STATE: TableDefinition<&[u8], &[u8]> = TableDefinition::new("state");
pub const BLOCKS: TableDefinition<&[u8], &[u8]> = TableDefinition::new("blocks");
pub const BLOCKMETA: TableDefinition<&[u8], &[u8]> = TableDefinition::new("block_meta");
pub const HEIGHTS: TableDefinition<u64, &[u8]> = TableDefinition::new("heights");
pub const RECEIPTS: TableDefinition<&[u8], &[u8]> = TableDefinition::new("receipts");
pub const UNDO: TableDefinition<&[u8], &[u8]> = TableDefinition::new("undo");
// Explorer indexes: derived data, rebuildable, never consulted by consensus.
pub const TXINDEX: TableDefinition<&[u8], &[u8]> = TableDefinition::new("idx_tx");
pub const ADDRINDEX: TableDefinition<&[u8], &[u8]> = TableDefinition::new("idx_addr");
pub const EVENTS: TableDefinition<&[u8], &[u8]> = TableDefinition::new("idx_events");

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum T {
    Meta,
    State,
    Blocks,
    BlockMeta,
    Receipts,
    Undo,
    TxIndex,
    AddrIndex,
    Events,
}

#[derive(Default)]
pub struct Batch {
    ops: Vec<(T, Vec<u8>, Option<Vec<u8>>)>,
    heights: Vec<(u64, Option<Vec<u8>>)>,
}

impl Batch {
    pub fn put(&mut self, t: T, k: impl Into<Vec<u8>>, v: impl Into<Vec<u8>>) {
        self.ops.push((t, k.into(), Some(v.into())));
    }
    pub fn del(&mut self, t: T, k: impl Into<Vec<u8>>) {
        self.ops.push((t, k.into(), None));
    }
    pub fn height(&mut self, h: u64, id: Option<Vec<u8>>) {
        self.heights.push((h, id));
    }
    pub fn meta(&mut self, k: &str, v: impl Into<Vec<u8>>) {
        self.put(T::Meta, k.as_bytes().to_vec(), v);
    }
    pub fn state_changes(&mut self, cs: &aureom_core::state::ChangeSet) {
        for (k, v) in cs {
            match v {
                Some(v) => self.put(T::State, k.clone(), v.clone()),
                None => self.del(T::State, k.clone()),
            }
        }
    }
}

pub struct Store {
    pub db: Database,
    pub path: PathBuf,
}

fn tdef(t: T) -> TableDefinition<'static, &'static [u8], &'static [u8]> {
    match t {
        T::State => STATE,
        T::Blocks => BLOCKS,
        T::BlockMeta => BLOCKMETA,
        T::Receipts => RECEIPTS,
        T::Undo => UNDO,
        T::TxIndex => TXINDEX,
        T::AddrIndex => ADDRINDEX,
        T::Events => EVENTS,
        T::Meta => unreachable!(),
    }
}

impl Store {
    pub fn open(dir: &Path) -> Result<Store> {
        std::fs::create_dir_all(dir)?;
        let path = dir.join("chain.redb");
        let db = Database::create(&path).with_context(|| format!("open database {}", path.display()))?;
        let s = Store { db, path };
        // create tables / check version
        let w = s.db.begin_write()?;
        {
            let mut m = w.open_table(META)?;
            let existing = m.get("db_version")?.map(|v| v.value().to_vec());
            match existing {
                None => {
                    m.insert("db_version", DB_VERSION.to_be_bytes().as_slice())?;
                }
                Some(v) => {
                    let ver = u32::from_be_bytes(v.as_slice().try_into().unwrap_or([0; 4]));
                    if ver != DB_VERSION {
                        bail!("database version {ver} is not supported by this software (expects {DB_VERSION}); restore a compatible backup or run a migration");
                    }
                }
            }
            for t in [T::State, T::Blocks, T::BlockMeta, T::Receipts, T::Undo, T::TxIndex, T::AddrIndex, T::Events] {
                w.open_table(tdef(t))?;
            }
            w.open_table(HEIGHTS)?;
        }
        w.commit()?;
        Ok(s)
    }

    pub fn write(&self, b: Batch) -> Result<()> {
        let w = self.db.begin_write()?;
        {
            for (t, k, v) in &b.ops {
                if *t == T::Meta {
                    let mut tb = w.open_table(META)?;
                    let key = std::str::from_utf8(k)?;
                    match v {
                        Some(v) => tb.insert(key, v.as_slice())?,
                        None => tb.remove(key)?,
                    };
                } else {
                    let mut tb = w.open_table(tdef(*t))?;
                    match v {
                        Some(v) => tb.insert(k.as_slice(), v.as_slice())?,
                        None => tb.remove(k.as_slice())?,
                    };
                }
            }
            let mut ht = w.open_table(HEIGHTS)?;
            for (h, id) in &b.heights {
                match id {
                    Some(id) => ht.insert(*h, id.as_slice())?,
                    None => ht.remove(*h)?,
                };
            }
        }
        if let Some(h) = crate::faults::abort_height() {
            if b.ops.iter().any(|(t, k, v)| *t == T::Meta && k == b"tip_height" && v.as_ref().map(|v| v.as_slice() == h.to_be_bytes()).unwrap_or(false)) {
                eprintln!("FAULT INJECTION: aborting process before committing height {h} (transaction is discarded)");
                std::process::abort();
            }
        }
        w.commit()?;
        Ok(())
    }

    pub fn meta(&self, k: &str) -> Result<Option<Vec<u8>>> {
        let r = self.db.begin_read()?;
        let t = r.open_table(META)?;
        let v = t.get(k)?.map(|v| v.value().to_vec());
        Ok(v)
    }
    pub fn get(&self, t: T, k: &[u8]) -> Result<Option<Vec<u8>>> {
        let r = self.db.begin_read()?;
        let tb = r.open_table(tdef(t))?;
        let v = tb.get(k)?.map(|v| v.value().to_vec());
        Ok(v)
    }
    pub fn height(&self, h: u64) -> Result<Option<Vec<u8>>> {
        let r = self.db.begin_read()?;
        let tb = r.open_table(HEIGHTS)?;
        let v = tb.get(h)?.map(|v| v.value().to_vec());
        Ok(v)
    }
    pub fn scan(&self, t: T, prefix: &[u8], limit: usize, reverse: bool) -> Result<Vec<(Vec<u8>, Vec<u8>)>> {
        let r = self.db.begin_read()?;
        let tb = r.open_table(tdef(t))?;
        let mut end = prefix.to_vec();
        // exclusive upper bound for the prefix
        let upper = loop {
            match end.pop() {
                None => break None,
                Some(0xff) => continue,
                Some(b) => {
                    end.push(b + 1);
                    break Some(end);
                }
            }
        };
        let mut out = vec![];
        let iter: Box<dyn Iterator<Item = _>> = match (&upper, reverse) {
            (Some(u), false) => Box::new(tb.range(prefix..u.as_slice())?),
            (Some(u), true) => Box::new(tb.range(prefix..u.as_slice())?.rev()),
            (None, false) => Box::new(tb.range(prefix..)?),
            (None, true) => Box::new(tb.range(prefix..)?.rev()),
        };
        for item in iter {
            let (k, v) = item?;
            out.push((k.value().to_vec(), v.value().to_vec()));
            if out.len() >= limit {
                break;
            }
        }
        Ok(out)
    }
    pub fn load_state(&self) -> Result<State> {
        let r = self.db.begin_read()?;
        let tb = r.open_table(STATE)?;
        let mut v = vec![];
        for item in tb.iter()? {
            let (k, val) = item?;
            v.push((k.value().to_vec(), val.value().to_vec()));
        }
        Ok(State::from_entries(v))
    }
    pub fn all(&self, t: T) -> Result<Vec<(Vec<u8>, Vec<u8>)>> {
        self.scan(t, &[], usize::MAX, false)
    }
    pub fn db_bytes(&self) -> u64 {
        std::fs::metadata(&self.path).map(|m| m.len()).unwrap_or(0)
    }
    pub fn clear(&self, t: T) -> Result<()> {
        let w = self.db.begin_write()?;
        {
            let mut tb = w.open_table(tdef(t))?;
            tb.retain(|_, _| false)?;
        }
        w.commit()?;
        Ok(())
    }
    pub fn tip_height(&self) -> Result<Option<u64>> {
        Ok(self.meta("tip_height")?.map(|v| u64::from_be_bytes(v.as_slice().try_into().unwrap())))
    }
    /// Consistent online copy of the whole database (single read transaction).
    pub fn backup_to(&self, dest_dir: &Path) -> Result<PathBuf> {
        std::fs::create_dir_all(dest_dir)?;
        let dest = dest_dir.join("chain.redb");
        if dest.exists() {
            bail!("backup destination {} already exists", dest.display());
        }
        let out = Database::create(&dest)?;
        let r = self.db.begin_read()?;
        let w = out.begin_write()?;
        {
            let m = r.open_table(META)?;
            let mut om = w.open_table(META)?;
            for item in m.iter()? {
                let (k, v) = item?;
                om.insert(k.value(), v.value())?;
            }
            for t in [T::State, T::Blocks, T::BlockMeta, T::Receipts, T::Undo, T::TxIndex, T::AddrIndex, T::Events] {
                let src = r.open_table(tdef(t))?;
                let mut dst = w.open_table(tdef(t))?;
                for item in src.iter()? {
                    let (k, v) = item?;
                    dst.insert(k.value(), v.value())?;
                }
            }
            let src = r.open_table(HEIGHTS)?;
            let mut dst = w.open_table(HEIGHTS)?;
            for item in src.iter()? {
                let (k, v) = item?;
                dst.insert(k.value(), v.value())?;
            }
        }
        w.commit()?;
        Ok(dest)
    }
}

pub fn index_key_addr(addr: &[u8; 20], height: u64, idx: u32) -> Vec<u8> {
    [&addr[..], &height.to_be_bytes(), &idx.to_be_bytes()].concat()
}
pub fn index_key_event(kind: &str, height: u64, seq: u32) -> Vec<u8> {
    [kind.as_bytes(), &[0u8], &height.to_be_bytes(), &seq.to_be_bytes()].concat()
}
