package com.example

import com.example.data.engine.SyntheticMarketEngine
import com.example.data.model.ClientTier
import com.example.data.model.MetalAsset
import com.example.data.model.OrderSide
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBlackScholesCallAndPutPricing() {
        val spot = 4188.30
        val strike = 4188.30
        val dte = 45
        val vol = 18.5

        val (callPrice, callGreeks) = SyntheticMarketEngine.calculateBlackScholes(spot, strike, dte, vol, isCall = true)
        val (putPrice, putGreeks) = SyntheticMarketEngine.calculateBlackScholes(spot, strike, dte, vol, isCall = false)

        assertTrue("Call price should be positive", callPrice > 0.0)
        assertTrue("Put price should be positive", putPrice > 0.0)
        assertTrue("ATM Call delta should be between 0.35 and 0.65", callGreeks.delta in 0.35..0.65)
        assertTrue("ATM Put delta should be between -0.65 and -0.35", putGreeks.delta in -0.65..-0.35)
        assertTrue("Gamma should be positive", callGreeks.gamma > 0.0)
        assertTrue("Vega should be positive", callGreeks.vega > 0.0)
        assertTrue("Theta should be negative for long option", callGreeks.theta < 0.0)
    }

    @Test
    fun testRfqPricingMatrix() {
        val spot = 4188.30
        val quoteBuy = SyntheticMarketEngine.priceRfq(spot, 500.0, OrderSide.BUY, ClientTier.TIER_1_SOVEREIGN, 18.5, MetalAsset.GOLD)
        val quoteSell = SyntheticMarketEngine.priceRfq(spot, 500.0, OrderSide.SELL, ClientTier.TIER_1_SOVEREIGN, 18.5, MetalAsset.GOLD)

        assertTrue("Buy quote must be higher than reference spot", quoteBuy.finalPricePerOz > spot)
        assertTrue("Sell quote must be lower than reference spot", quoteSell.finalPricePerOz < spot)
        assertTrue("Offer quote must be strictly higher than Bid quote", quoteBuy.offerQuotePerOz > quoteBuy.bidQuotePerOz)
        assertEquals("Seconds remaining initialized to 15s", 15, quoteBuy.secondsRemaining)
    }

    @Test
    fun testFuturesCurveTermStructure() {
        val spot = 4188.30
        val curve = SyntheticMarketEngine.generateFuturesCurve(MetalAsset.GOLD, spot)

        assertEquals("Curve should contain 7 contracts", 7, curve.contracts.size)
        assertTrue("Furthest contract price should be higher than spot in Contango", curve.contracts.last().lastPrice > spot)
        assertTrue("Annualized roll yield should be positive in contango", curve.contracts.first().annualizedRollYieldPercent > 0.0)
    }

    @Test
    fun testValueAtRiskComputation() {
        val portfolioVal = 12_482_910.0
        val risk = SyntheticMarketEngine.computeVaR(portfolioVal, 0.65, 0.25)

        assertTrue("Historical VaR should be positive", risk.historicalVaR99Usd > 0.0)
        assertTrue("CVaR (Expected Shortfall) must exceed VaR", risk.conditionalVaR99Usd > risk.parametricVaR99Usd)
        assertTrue("Sharpe ratio should be reasonable", risk.annualSharpeRatio > 1.0)
    }

    @Test
    fun testStandardNormalCdf() {
        val cdf0 = SyntheticMarketEngine.standardNormalCdf(0.0)
        assertEquals(0.5, cdf0, 0.001)

        val cdf2 = SyntheticMarketEngine.standardNormalCdf(1.96)
        assertEquals(0.975, cdf2, 0.005)
    }
}
