package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PortfolioHolding
import com.example.data.model.RiskMetrics
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun StressTestLab(
    portfolioHoldings: List<PortfolioHolding>,
    currentRisk: RiskMetrics,
    modifier: Modifier = Modifier
) {
    var goldShock by remember { mutableStateOf(-10f) }
    var silverShock by remember { mutableStateOf(-20f) }
    var usdShock by remember { mutableStateOf(5f) }
    var volShock by remember { mutableStateOf(50f) }

    val totalPortfolioVal = portfolioHoldings.sumOf { it.marketValueUsd }
    val goldExposure = portfolioHoldings.filter { it.assetName.contains("Gold", ignoreCase = true) }.sumOf { it.marketValueUsd }
    val silverExposure = portfolioHoldings.filter { it.assetName.contains("Silver", ignoreCase = true) }.sumOf { it.marketValueUsd }

    val simulatedGoldLoss = goldExposure * (goldShock / 100.0)
    val simulatedSilverLoss = silverExposure * (silverShock / 100.0)
    val totalNetLoss = simulatedGoldLoss + simulatedSilverLoss
    val netLossPct = if (totalPortfolioVal > 0) (totalNetLoss / totalPortfolioVal) * 100.0 else 0.0

    val stressedVaR = currentRisk.monteCarloVaR99Usd * (1.0 + (volShock / 100.0) * 0.4)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stress_test_lab"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MACRO & LIQUIDITY STRESS TESTING LAB",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Deterministic Multi-Factor Portfolio Sensitivity Simulator",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (totalNetLoss < 0) RiskCrimsonBg else TerminalGreenBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${if (totalNetLoss >= 0) "+" else ""}${String.format("%.2f", netLossPct)}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (totalNetLoss < 0) RiskCrimson else TerminalGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stressed Outcome Dashboard Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ESTIMATED P&L IMPACT", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp))
                    Text(
                        text = "${if (totalNetLoss >= 0) "+" else "-"}$${String.format("%,.0f", abs(totalNetLoss))}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = if (totalNetLoss < 0) RiskCrimson else TerminalGreen,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
                Column {
                    Text("STRESSED 99% VaR", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp))
                    Text(
                        text = "$${String.format("%,.0f", stressedVaR)}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = AlertAmber,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
                Column {
                    Text("MARGIN RISK", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp))
                    Text(
                        text = if (abs(netLossPct) > 15) "MODERATE" else "SOLVENT (100%)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = if (abs(netLossPct) > 15) AlertAmber else TerminalGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sliders
            StressSlider(
                label = "GOLD SPOT SHOCK",
                value = goldShock,
                range = -30f..30f,
                unit = "%",
                onValueChange = { goldShock = it }
            )

            StressSlider(
                label = "SILVER SPOT SHOCK",
                value = silverShock,
                range = -50f..50f,
                unit = "%",
                onValueChange = { silverShock = it }
            )

            StressSlider(
                label = "USD INDEX (DXY) SHOCK",
                value = usdShock,
                range = -10f..10f,
                unit = "%",
                onValueChange = { usdShock = it }
            )

            StressSlider(
                label = "COMMODITY VOLATILITY SURGE",
                value = volShock,
                range = 0f..100f,
                unit = "%",
                onValueChange = { volShock = it }
            )
        }
    }
}

@Composable
private fun StressSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
            Text(
                text = "${if (value > 0) "+" else ""}${String.format("%.1f", value)}$unit",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (value < 0) RiskCrimson else if (value > 0) TerminalGreen else TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = BullionGoldPrimary,
                activeTrackColor = BullionGoldDark,
                inactiveTrackColor = ObsidianBorder
            ),
            modifier = Modifier.height(24.dp)
        )
    }
}
