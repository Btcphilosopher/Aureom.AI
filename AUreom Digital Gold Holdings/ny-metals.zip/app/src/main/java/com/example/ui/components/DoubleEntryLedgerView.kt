package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun DoubleEntryLedgerView(
    clientBalance: ClientLedgerBalance,
    transactions: List<JournalTransaction>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("double_entry_ledger_view"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header with Invariant Balance Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DOUBLE-ENTRY METAL & MONEY LEDGER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Separate Physical Custody & Fiat Settlement Rails",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalGreenBg)
                        .border(1.dp, TerminalGreen.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = TerminalGreen, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LEDGER BALANCED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TerminalGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.5.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Balance Rail Summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("USD CASH (FIAT)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("$${String.format("%,.2f", clientBalance.usdCashBalance)}", style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("ALLOCATED GOLD", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("${String.format("%,.2f", clientBalance.goldAllocatedOz)} oz t", style = MaterialTheme.typography.labelMedium.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold))
                    Text("Unallocated: ${clientBalance.goldUnallocatedOz} oz", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                }
                Column {
                    Text("ALLOCATED SILVER", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("${String.format("%,.0f", clientBalance.silverAllocatedOz)} oz t", style = MaterialTheme.typography.labelMedium.copy(color = BullionSilverBright, fontWeight = FontWeight.Bold))
                    Text("Unallocated: ${clientBalance.silverUnallocatedOz} oz", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Journal Entries List
            Text(
                text = "AUDITABLE TRANSACTION JOURNAL ENTRIES",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                transactions.take(4).forEach { tx ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${tx.transactionId} • ${tx.type.displayName}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = BullionGoldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = tx.auditHash.take(16) + "...",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSubtle,
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }

                        Text(
                            text = tx.description,
                            style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontSize = 10.sp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )

                        Divider(color = ObsidianBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))

                        // Double Entry Debit / Credit Lines
                        tx.lines.forEach { line ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 1.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${if (line.isDebit) "DR: " else "CR: "}${line.accountName}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (line.isDebit) TerminalGreen else BullionSilverPrimary,
                                        fontSize = 9.sp
                                    )
                                )
                                Text(
                                    text = "${if (line.assetType == LedgerAssetType.USD_CASH) "$" else ""}${String.format("%,.2f", line.amount)} ${if (line.assetType != LedgerAssetType.USD_CASH) "oz" else ""}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
