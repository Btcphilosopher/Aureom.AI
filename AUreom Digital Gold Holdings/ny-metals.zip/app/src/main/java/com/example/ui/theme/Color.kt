package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// New York Metals Institutional Dark Palette
val ObsidianBg = Color(0xFF080A0F)
val ObsidianSurface = Color(0xFF0E131F)
val ObsidianElevated = Color(0xFF151C2C)
val ObsidianCard = Color(0xFF121824)
val ObsidianBorder = Color(0xFF222C3E)
val ObsidianBorderActive = Color(0xFF3B4861)

// Precious Metal Accents
val BullionGoldPrimary = Color(0xFFD4AF37) // 24k Gold
val BullionGoldBright = Color(0xFFF59E0B)  // High karat gold
val BullionGoldDark = Color(0xFF996515)    // Deep bullion gold
val BullionGoldGlow = Color(0x33D4AF37)    // Subtle gold sheen

val BullionSilverPrimary = Color(0xFFCBD5E1) // 999.0 Fine Silver
val BullionSilverBright = Color(0xFFF1F5F9)  // Lustrous silver
val BullionSilverMuted = Color(0xFF64748B)   // Industrial silver

// Market & Risk Signals
val TerminalGreen = Color(0xFF10B981) // Up tick / settled / safe
val TerminalGreenBg = Color(0x1A10B981)
val RiskCrimson = Color(0xFFEF4444)   // Down tick / breached / sell
val RiskCrimsonBg = Color(0x1AEF4444)
val AlertAmber = Color(0xFFF59E0B)    // Pending / warning / RFQ timer
val AlertAmberBg = Color(0x1AF59E0B)
val InfoNavy = Color(0xFF38BDF8)      // Macro / informational

// Neutral Text
val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val TextSubtle = Color(0xFF64748B)
val TextDark = Color(0xFF0F172A)
