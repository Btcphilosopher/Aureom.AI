package com.example.data.model

enum class MetalAsset(val symbol: String, val displayName: String, val standardUnit: String, val isPrimary: Boolean) {
    GOLD("XAU/USD", "Spot Gold", "oz t", true),
    SILVER("XAG/USD", "Spot Silver", "oz t", true),
    PLATINUM("XPT/USD", "Spot Platinum", "oz t", false),
    PALLADIUM("XPD/USD", "Spot Palladium", "oz t", false),
    RHODIUM("XRH/USD", "Spot Rhodium", "oz t", false)
}

data class SpotPrice(
    val asset: MetalAsset,
    val bid: Double,
    val ask: Double,
    val last: Double,
    val changeAmount: Double,
    val changePercent: Double,
    val volumeOz: Double,
    val openInterest: Long,
    val sessionHigh: Double,
    val sessionLow: Double,
    val settlementPrice: Double,
    val timestamp: Long = System.currentTimeMillis()
) {
    val spreadUsd: Double get() = ask - bid
    val spreadBps: Double get() = (spreadUsd / last) * 10_000.0
}

data class CandleStick(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class OrderBookLevel(
    val price: Double,
    val quantityOz: Double,
    val totalOz: Double,
    val orderCount: Int
)

data class OrderBook(
    val asset: MetalAsset,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val timestamp: Long = System.currentTimeMillis()
) {
    val bestBid: Double get() = bids.firstOrNull()?.price ?: 0.0
    val bestAsk: Double get() = asks.firstOrNull()?.price ?: 0.0
    val spread: Double get() = bestAsk - bestBid
    val totalBidDepth: Double get() = bids.sumOf { it.quantityOz }
    val totalAskDepth: Double get() = asks.sumOf { it.quantityOz }
    val imbalancePercent: Double get() {
        val total = totalBidDepth + totalAskDepth
        return if (total > 0) ((totalBidDepth - totalAskDepth) / total) * 100.0 else 0.0
    }
}

data class FuturesContract(
    val ticker: String,        // e.g. "GCZ6", "GCG7"
    val metal: MetalAsset,
    val monthName: String,     // "Dec 2026", "Feb 2027"
    val lastPrice: Double,
    val bid: Double,
    val ask: Double,
    val settlement: Double,
    val volume: Long,
    val openInterest: Long,
    val daysToExpiry: Int,
    val impliedBasisUsd: Double,
    val annualizedRollYieldPercent: Double,
    val isContango: Boolean
)

data class FuturesCurveComparison(
    val metal: MetalAsset,
    val contracts: List<FuturesContract>,
    val prevClosePrices: List<Double>,
    val oneWeekAgoPrices: List<Double>,
    val oneMonthAgoPrices: List<Double>,
    val scenarioPrices: List<Double>
)

data class GoldSilverRatioMetrics(
    val currentRatio: Double,
    val changePercent: Double,
    val percentile3Y: Double,
    val zScore: Double,
    val ma50: Double,
    val ma200: Double,
    val volatility30D: Double,
    val regime: String, // "High Dispersion / Reversion Watch"
    val historicalSeries: List<Pair<Long, Double>>
)

data class MacroCorrelation(
    val dxyDollarIndex: Double,
    val dxyChange: Double,
    val us10YRealYield: Double, // % (TIPS)
    val us10YRealYieldChange: Double,
    val sp500: Double,
    val sp500Change: Double,
    val wtiCrudeOil: Double,
    val wtiChange: Double,
    val usInflationExpectations: Double, // 10Y Breakeven %
    val goldDxyCorrelation: Double,
    val goldYieldCorrelation: Double,
    val silverIndustrialCorrelation: Double
)

enum class MarketRegime(val label: String, val description: String) {
    NORMAL("Normal Market", "Standard liquidity, tight institutional spreads, balanced flow"),
    VOLATILITY_SHOCK("Volatility Shock", "+50% IV spike, widening spreads, fast market conditions"),
    INFLATION_SHOCK("Inflation Shock", "Yield curve shifts, precious metals rally, flight to hard assets"),
    USD_SHOCK("USD Shock", "DXY sudden +3.5% spike, liquidity drainage, margin recalibrations"),
    LIQUIDITY_CRISIS("Liquidity Crisis", "-40% market depth, high slippage, OTC bilateral preference"),
    PM_RALLY("Metals Rally", "Sustained institutional and sovereign bullion accumulation"),
    PM_SELLOFF("Metals Selloff", "Aggressive CTA liquidation and macro deleveraging")
}
