package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.*
import com.example.ui.components.VaultDigitalTwinMap
import com.example.ui.theme.*

@Composable
fun PhysicalVaultScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val bullionBars by repository.bullionBars.collectAsState()
    val vaultInfo by repository.vaultFacility.collectAsState()
    val deliveryInstructions by repository.deliveryInstructions.collectAsState()

    var showDeliveryDialog by remember { mutableStateOf(false) }
    var deliveryAddress by remember { mutableStateOf("200 West Street, 38th Floor Treasury, New York, NY 10282") }
    var selectedBarForDelivery by remember { mutableStateOf<String?>(null) }
    var deliverySuccessMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("physical_vault_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Image of Manhattan Depository 03
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_vault_hero),
                    contentDescription = "New York Vault 03 Subterranean Depository",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.95f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "NEW YORK CENTRAL VAULT 03",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Subterranean Manhattan Bedrock • Serialized Good Delivery Physical Bullion Custody",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontSize = 9.sp)
                    )
                }
            }
        }

        // Vault Digital Twin Floor Map Component
        VaultDigitalTwinMap(
            vaultInfo = vaultInfo,
            bars = bullionBars,
            onBarSelected = { /* handled in component dialog */ },
            onToggleAllocation = { barId ->
                repository.toggleBarAllocation(barId)
            }
        )

        // Physical Delivery & Logistics Dispatch
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ARMORED PHYSICAL DISPATCH & LOGISTICS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = BullionGoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Brinks & Loomis High-Security Armored Transport Logistics",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                        )
                    }

                    Button(
                        onClick = { showDeliveryDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BullionGoldPrimary, contentColor = TextDark),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(32.dp).testTag("dispatch_delivery_btn")
                    ) {
                        Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextDark)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DISPATCH BULLION", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                deliveryInstructions.forEach { dlv ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(dlv.instructionId, style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text(dlv.status, style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                        }
                        Text("Destination: ${dlv.destinationAddress}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        Text("Bars: ${dlv.barIds.joinToString(", ")} • Total: ${dlv.totalFineOz} oz ($${String.format("%,.0f", dlv.declaredValueUsd)} USD)", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontSize = 9.sp))
                        Text("Airway Bill: ${dlv.trackingAirwayBill} • Provider: ${dlv.logisticsProvider}", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                    }
                }
            }
        }
    }

    if (showDeliveryDialog) {
        val allocatedBars = bullionBars.filter { it.status == BarStatus.ALLOCATED }
        AlertDialog(
            onDismissRequest = { showDeliveryDialog = false },
            title = { Text("REQUEST ARMORED PHYSICAL DELIVERY", style = MaterialTheme.typography.titleMedium.copy(color = BullionGoldPrimary)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select an allocated bar in Manhattan Depository 03 for armored logistics dispatch:", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))

                    allocatedBars.forEach { b ->
                        val isSelected = b.barId == selectedBarForDelivery
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) ObsidianCard else ObsidianElevated)
                                .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedBarForDelivery = b.barId }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${b.barId} (${b.fineWeightOz} oz)", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text(b.refinerName, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        }
                    }

                    OutlinedTextField(
                        value = deliveryAddress,
                        onValueChange = { deliveryAddress = it },
                        label = { Text("Delivery Address", fontSize = 10.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BullionGoldPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val barId = selectedBarForDelivery ?: allocatedBars.firstOrNull()?.barId
                        if (barId != null) {
                            repository.submitDeliveryInstruction(
                                metal = MetalAsset.GOLD,
                                barIds = listOf(barId),
                                destinationAddress = deliveryAddress
                            )
                            showDeliveryDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BullionGoldPrimary, contentColor = TextDark)
                ) {
                    Text("AUTHORIZE ARMORED DISPATCH", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeliveryDialog = false }) {
                    Text("CANCEL", color = TextMuted)
                }
            },
            containerColor = ObsidianElevated
        )
    }
}
