package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.*
import com.example.ui.components.InteractiveMarketChart
import com.example.ui.components.OrderBookVisualizer
import com.example.ui.theme.*

@Composable
fun TerminalScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val spotPrices by repository.spotPrices.collectAsState()
    val selectedAsset by repository.selectedAsset.collectAsState()
    val orderBook by repository.orderBook.collectAsState()
    val candleSeries by repository.candleSeries.collectAsState()
    val macroData by repository.macroData.collectAsState()

    var orderSide by remember { mutableStateOf(OrderSide.BUY) }
    var orderType by remember { mutableStateOf(OrderType.MARKET) }
    var quantityText by remember { mutableStateOf("100") }
    var limitPriceText by remember { mutableStateOf("") }
    var executionVenue by remember { mutableStateOf(ExecutionVenue.NYM_DARK) }
    var showSuccessSnackbar by remember { mutableStateOf<String?>(null) }

    val currentSpot = spotPrices[selectedAsset]?.last ?: 4188.30

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("terminal_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Header Price Banner
        val price = spotPrices[selectedAsset]
        if (price != null) {
            val isUp = price.changeAmount >= 0
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = selectedAsset.displayName.uppercase(),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedAsset.isPrimary) BullionGoldPrimary else BullionSilverPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${selectedAsset.symbol}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "COMEX / NYMEX SYNTHETIC CONTINUOUS GATEWAY",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$${String.format("%,.2f", price.last)}",
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${if (isUp) "+" else ""}$${String.format("%.2f", price.changeAmount)} (${if (isUp) "+" else ""}${String.format("%.2f", price.changePercent)}%)",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (isUp) TerminalGreen else RiskCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Vol: ${String.format("%,.0f", price.volumeOz)} oz",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                            )
                        }
                    }
                }
            }
        }

        // Interactive Candlestick Chart
        InteractiveMarketChart(candles = candleSeries, asset = selectedAsset)

        // Order Book Visualizer
        OrderBookVisualizer(orderBook = orderBook)

        // Institutional Order Entry Ticket
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("order_entry_card"),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldDark.copy(alpha = 0.5f)))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "DIRECT ORDER EXECUTION TICKET",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Deterministic Matching Engine • 1.5 bps Clearing Fee",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Buy / Sell Side Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (orderSide == OrderSide.BUY) TerminalGreen else ObsidianElevated)
                            .border(1.dp, if (orderSide == OrderSide.BUY) TerminalGreen else ObsidianBorder, RoundedCornerShape(4.dp))
                            .clickable { orderSide = OrderSide.BUY }
                            .padding(vertical = 8.dp)
                            .testTag("order_side_buy"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "BUY / ALLOCATE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (orderSide == OrderSide.BUY) TextDark else TerminalGreen
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (orderSide == OrderSide.SELL) RiskCrimson else ObsidianElevated)
                            .border(1.dp, if (orderSide == OrderSide.SELL) RiskCrimson else ObsidianBorder, RoundedCornerShape(4.dp))
                            .clickable { orderSide = OrderSide.SELL }
                            .padding(vertical = 8.dp)
                            .testTag("order_side_sell"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SELL / LIQUIDATE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (orderSide == OrderSide.SELL) TextWhite else RiskCrimson
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Order Type Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(OrderType.MARKET, OrderType.LIMIT, OrderType.STOP, OrderType.TWAP, OrderType.VWAP).forEach { type ->
                        val isSelected = type == orderType
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSelected) BullionGoldPrimary else ObsidianElevated)
                                .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(3.dp))
                                .clickable { orderType = type }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = type.displayName.take(6),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) TextDark else TextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quantity & Price Fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity (${selectedAsset.standardUnit})", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("order_quantity_input"),
                        textStyle = MaterialTheme.typography.labelMedium.copy(color = TextWhite),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BullionGoldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedLabelColor = BullionGoldBright,
                            unfocusedLabelColor = TextMuted
                        ),
                        singleLine = true
                    )

                    if (orderType != OrderType.MARKET) {
                        OutlinedTextField(
                            value = limitPriceText.ifEmpty { String.format("%.2f", currentSpot) },
                            onValueChange = { limitPriceText = it },
                            label = { Text("Limit Price ($)", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("order_limit_price_input"),
                            textStyle = MaterialTheme.typography.labelMedium.copy(color = TextWhite),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BullionGoldPrimary,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedLabelColor = BullionGoldBright,
                                unfocusedLabelColor = TextMuted
                            ),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Venue Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("EXECUTION ROUTE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text(
                        text = executionVenue.fullName,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.5.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Execution Button
                val qty = quantityText.toDoubleOrNull() ?: 100.0
                val totalEst = qty * currentSpot

                Button(
                    onClick = {
                        val limitPrice = if (orderType != OrderType.MARKET) limitPriceText.toDoubleOrNull() else null
                        val order = repository.placeOrder(
                            asset = selectedAsset,
                            side = orderSide,
                            type = orderType,
                            quantityOz = qty,
                            limitPrice = limitPrice,
                            venue = executionVenue
                        )
                        showSuccessSnackbar = "Order ${order.orderId} executed! $qty oz ${selectedAsset.displayName} @ $${String.format("%.2f", order.averageExecutionPrice)}"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("submit_order_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (orderSide == OrderSide.BUY) TerminalGreen else RiskCrimson,
                        contentColor = TextDark
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "TRANSMIT ${orderSide.displayName} ORDER (~$${String.format("%,.0f", totalEst)} USD)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (orderSide == OrderSide.BUY) TextDark else TextWhite
                        )
                    )
                }

                showSuccessSnackbar?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalGreenBg)
                            .border(1.dp, TerminalGreen, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(text = msg, style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        // Macro Asset Intermarket Correlation
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CROSS-ASSET MACRO TELEMETRY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MacroMetricItem("DXY INDEX", "${macroData.dxyDollarIndex}", "${macroData.dxyChange}%", macroData.dxyChange >= 0, Modifier.weight(1f))
                    MacroMetricItem("US 10Y TIPS", "${macroData.us10YRealYield}%", "${macroData.us10YRealYieldChange}%", macroData.us10YRealYieldChange >= 0, Modifier.weight(1f))
                    MacroMetricItem("S&P 500", "${macroData.sp500}", "+${macroData.sp500Change}%", true, Modifier.weight(1f))
                    MacroMetricItem("WTI OIL", "$${macroData.wtiCrudeOil}", "+${macroData.wtiChange}%", true, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MacroMetricItem(
    title: String,
    value: String,
    change: String,
    isUp: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(ObsidianElevated)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.sp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp))
        Text(change, style = MaterialTheme.typography.labelSmall.copy(color = if (isUp) TerminalGreen else RiskCrimson, fontSize = 8.5.sp))
    }
}
