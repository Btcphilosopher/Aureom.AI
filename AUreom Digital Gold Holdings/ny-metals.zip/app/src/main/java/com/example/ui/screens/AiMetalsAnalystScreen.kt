package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.GeminiAnalystService
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "USER" or "METALS AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Composable
fun AiMetalsAnalystScreen(
    repository: NewYorkMetalsRepository,
    analystService: GeminiAnalystService,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    sender = "METALS AI",
                    text = "Welcome to METALS AI — Senior Quantitative Commodities Analyst for NEW YORK METALS.\nI have real-time access to the platform's spot tickers, COMEX futures curves, physical bar registry in Vault 03, double-entry ledger balances, and 5,000-path Monte Carlo risk models.\n\nSelect a query below or type your question."
                )
            )
        )
    }

    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val quickQuestions = listOf(
        "Why is the gold/silver ratio rising?",
        "Show my physical gold exposure.",
        "Stress the portfolio with a 15% silver decline.",
        "Compare the December and June gold futures curves.",
        "How much gold is allocated to Client 0194?",
        "Calculate the P&L if gold rises 8%."
    )

    fun sendQuery(query: String) {
        if (query.isBlank() || isLoading) return
        val userMsg = ChatMessage("USER", query)
        messages = messages + userMsg
        inputText = ""
        isLoading = true

        coroutineScope.launch {
            val responseText = analystService.askMetalsAnalyst(query)
            messages = messages + ChatMessage("METALS AI", responseText)
            isLoading = false
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(12.dp)
            .testTag("ai_metals_analyst_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = BullionGoldPrimary, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "METALS AI — QUANTITATIVE ANALYST",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = BullionGoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Gemini 3.5 Engine • Context-Aware Telemetry • Zero Hallucination",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalGreenBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("ONLINE", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold, fontSize = 8.5.sp))
                }
            }
        }

        // Quick Query Chips Row
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("SUGGESTED INSTITUTIONAL INQUIRIES:", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                quickQuestions.take(3).forEach { q ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(3.dp))
                            .clickable { sendQuery(q) }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(q, style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontSize = 8.sp), maxLines = 1)
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                quickQuestions.drop(3).forEach { q ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(3.dp))
                            .clickable { sendQuery(q) }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(q, style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontSize = 8.sp), maxLines = 1)
                    }
                }
            }
        }

        // Messages Conversation Stream
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(ObsidianElevated)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { msg ->
                    val isAi = msg.sender == "METALS AI"
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isAi) ObsidianCard else ObsidianBorder.copy(alpha = 0.4f))
                            .border(1.dp, if (isAi) BullionGoldDark.copy(alpha = 0.3f) else Color.Transparent, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = msg.sender,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isAi) BullionGoldPrimary else TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextWhite,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }

                if (isLoading) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = BullionGoldPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Querying New York Metals telemetry engine...", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright))
                        }
                    }
                }
            }
        }

        // Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask METALS AI about curves, VaR, bars, or ratios...", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).testTag("ai_analyst_input"),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodySmall.copy(color = TextWhite),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BullionGoldPrimary,
                    unfocusedBorderColor = ObsidianBorder
                )
            )

            IconButton(
                onClick = { sendQuery(inputText) },
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(BullionGoldPrimary)
                    .testTag("ai_analyst_send_btn")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = TextDark, modifier = Modifier.size(18.dp))
            }
        }
    }
}
