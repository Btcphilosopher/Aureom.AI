package com.example.data.model

enum class BarStatus(val displayName: String) {
    ALLOCATED("Allocated (Client Title)"),
    UNALLOCATED("Unallocated Pool"),
    VAULT_AVAILABLE("Vault Available"),
    LOCKED_COLLATERAL("Locked (Margin Collateral)"),
    IN_TRANSIT_DELIVERY("In Armored Transit"),
    IN_REFINERY("Refinery Processing")
}

enum class BarStandard(val displayName: String, val approxOz: Double, val approxKg: Double) {
    GOLD_400_OZ("400 oz Good Delivery Bar", 400.0, 12.44),
    GOLD_100_OZ("100 oz Institutional Bar", 100.0, 3.11),
    GOLD_1_KG("1 Kilogram Bar (999.9)", 32.15, 1.00),
    GOLD_10_OZ("10 oz Cast Bar", 10.0, 0.311),
    GOLD_1_OZ("1 oz Fine Mint Ingot", 1.0, 0.0311),
    SILVER_1000_OZ("1,000 oz Good Delivery Ingot", 1000.0, 31.10),
    SILVER_100_OZ("100 oz Cast Silver Bar", 100.0, 3.11),
    SILVER_15_KG("15 Kilogram Industrial Ingot", 482.26, 15.0),
    SILVER_1_OZ("1 oz American Eagle Coin / Round", 1.0, 0.0311)
}

data class InspectionRecord(
    val inspectionId: String,
    val date: String,
    val inspectorName: String,
    val method: String, // "Ultrasound Density & XRF Assay"
    val result: String,
    val sealIntact: Boolean
)

data class CustodyMovement(
    val movementId: String,
    val timestamp: Long,
    val fromLocation: String,
    val toLocation: String,
    val authorizationOfficer: String,
    val actionType: String,
    val auditHash: String
)

data class BullionBar(
    val barId: String,               // "NYM-GLD-00018492"
    val metal: MetalAsset,
    val standard: BarStandard,
    val grossWeightKg: Double,
    val fineWeightKg: Double,
    val fineWeightOz: Double,
    val purity: Double,              // 999.9 or 999.5
    val refinerName: String,         // "Empire Refining Company", "Valcambi NYM"
    val serialNumber: String,        // "A893742"
    val assayCertificateNumber: String,
    val vaultFacility: String,       // "New York Vault 03 (Lower Manhattan)"
    val roomCode: String,            // "Room A - Heavy Bullion Safe"
    val cageCode: String,            // "Cage Tier-1"
    val shelfCode: String,           // "Shelf C-14"
    val palletId: String,            // "Pallet 09"
    val status: BarStatus,
    val ownerId: String,             // "CLIENT-0194 (Hudson Metals LLC)"
    val lastInspectionDate: String,
    val custodyHistory: List<CustodyMovement>,
    val inspectionRecords: List<InspectionRecord>
) {
    val isAllocated: Boolean get() = status == BarStatus.ALLOCATED
}

data class VaultFacilityInfo(
    val facilityId: String,
    val name: String,
    val locationDescription: String,
    val totalGoldKg: Double,
    val totalSilverKg: Double,
    val goldAllocatedKg: Double,
    val silverAllocatedKg: Double,
    val goldAvailableKg: Double,
    val silverAvailableKg: Double,
    val capacityUtilizationPercent: Double,
    val armedSecurityLevel: String, // "Class 3 Subterranean Fortified"
    val activeSensors: Int,
    val insuranceUnderwriter: String // "Lloyd's of London & Manhattan Syndicate ($10B Policy)"
)

data class DeliveryInstruction(
    val instructionId: String,
    val clientId: String,
    val destinationAddress: String,
    val metal: MetalAsset,
    val barIds: List<String>,
    val totalFineOz: Double,
    val totalGrossKg: Double,
    val declaredValueUsd: Double,
    val logisticsProvider: String, // "Brinks Global Armored Logistics NY"
    val dispatchDate: String,
    val estimatedArrivalDate: String,
    val trackingAirwayBill: String,
    val tamperSealCodes: List<String>,
    val status: String // "SUBMITTED", "APPROVED", "ARMORED_EN_ROUTE", "DELIVERED"
)
