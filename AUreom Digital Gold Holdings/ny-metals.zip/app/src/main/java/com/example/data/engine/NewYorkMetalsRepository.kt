package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class NewYorkMetalsRepository(private val scope: CoroutineScope) {

    private val _marketRegime = MutableStateFlow(MarketRegime.NORMAL)
    val marketRegime: StateFlow<MarketRegime> = _marketRegime.asStateFlow()

    // Spot Prices
    private val _spotPrices = MutableStateFlow<Map<MetalAsset, SpotPrice>>(initialSpotPrices())
    val spotPrices: StateFlow<Map<MetalAsset, SpotPrice>> = _spotPrices.asStateFlow()

    // Active Selected Metal Asset for charts / terminal
    private val _selectedAsset = MutableStateFlow(MetalAsset.GOLD)
    val selectedAsset: StateFlow<MetalAsset> = _selectedAsset.asStateFlow()

    // Order Book
    private val _orderBook = MutableStateFlow(SyntheticMarketEngine.generateOrderBook(MetalAsset.GOLD, 4188.30))
    val orderBook: StateFlow<OrderBook> = _orderBook.asStateFlow()

    // Candlestick series
    private val _candleSeries = MutableStateFlow<List<CandleStick>>(generateInitialCandles(4188.30))
    val candleSeries: StateFlow<List<CandleStick>> = _candleSeries.asStateFlow()

    // Macro Correlations
    private val _macroData = MutableStateFlow(initialMacroData())
    val macroData: StateFlow<MacroCorrelation> = _macroData.asStateFlow()

    // Orders & Executions
    private val _orders = MutableStateFlow<List<Order>>(initialOrders())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _executions = MutableStateFlow<List<ExecutionTicket>>(initialExecutions())
    val executions: StateFlow<List<ExecutionTicket>> = _executions.asStateFlow()

    // RFQ Queue
    private val _activeRfqs = MutableStateFlow<List<Pair<RfqRequest, RfqQuote?>>>(initialRfqs())
    val activeRfqs: StateFlow<List<Pair<RfqRequest, RfqQuote?>>> = _activeRfqs.asStateFlow()

    // Physical Bullion Bars in Vault
    private val _bullionBars = MutableStateFlow<List<BullionBar>>(initialBars())
    val bullionBars: StateFlow<List<BullionBar>> = _bullionBars.asStateFlow()

    private val _vaultFacility = MutableStateFlow(initialVaultInfo())
    val vaultFacility: StateFlow<VaultFacilityInfo> = _vaultFacility.asStateFlow()

    private val _deliveryInstructions = MutableStateFlow<List<DeliveryInstruction>>(initialDeliveries())
    val deliveryInstructions: StateFlow<List<DeliveryInstruction>> = _deliveryInstructions.asStateFlow()

    // Metal & Cash Ledger
    private val _clientBalance = MutableStateFlow(
        ClientLedgerBalance(
            clientId = "CLIENT-0194",
            clientName = "Hudson Metals LLC / Institutional Account",
            usdCashBalance = 4_820_000.0,
            goldAllocatedOz = 1125.40,
            goldUnallocatedOz = 250.0,
            silverAllocatedOz = 42_500.0,
            silverUnallocatedOz = 10_000.0
        )
    )
    val clientBalance: StateFlow<ClientLedgerBalance> = _clientBalance.asStateFlow()

    private val _journalTransactions = MutableStateFlow<List<JournalTransaction>>(initialJournal())
    val journalTransactions: StateFlow<List<JournalTransaction>> = _journalTransactions.asStateFlow()

    // Options Chain
    private val _optionsChain = MutableStateFlow<List<PreciousMetalsOption>>(initialOptions())
    val optionsChain: StateFlow<List<PreciousMetalsOption>> = _optionsChain.asStateFlow()

    // Portfolio & Risk
    private val _portfolioHoldings = MutableStateFlow<List<PortfolioHolding>>(initialHoldings())
    val portfolioHoldings: StateFlow<List<PortfolioHolding>> = _portfolioHoldings.asStateFlow()

    private val _riskMetrics = MutableStateFlow(
        SyntheticMarketEngine.computeVaR(12_482_910.0, 0.65, 0.25)
    )
    val riskMetrics: StateFlow<RiskMetrics> = _riskMetrics.asStateFlow()

    private val _pnlAttribution = MutableStateFlow(initialPnlAttribution())
    val pnlAttribution: StateFlow<PnlAttribution> = _pnlAttribution.asStateFlow()

    // Refinery & Recycling
    private val _scrapLots = MutableStateFlow<List<ScrapIntakeLot>>(initialScrapLots())
    val scrapLots: StateFlow<List<ScrapIntakeLot>> = _scrapLots.asStateFlow()

    private val _refineryBatches = MutableStateFlow<List<RefineryBatch>>(initialRefineryBatches())
    val refineryBatches: StateFlow<List<RefineryBatch>> = _refineryBatches.asStateFlow()

    // Research & CFTC
    private val _researchReports = MutableStateFlow<List<MetalsResearchReport>>(initialResearchReports())
    val researchReports: StateFlow<List<MetalsResearchReport>> = _researchReports.asStateFlow()

    private val _cftcData = MutableStateFlow<List<CftcCotPositioning>>(initialCftcData())
    val cftcData: StateFlow<List<CftcCotPositioning>> = _cftcData.asStateFlow()

    private val _centralBankFlows = MutableStateFlow<List<CentralBankGoldFlow>>(initialCentralBankFlows())
    val centralBankFlows: StateFlow<List<CentralBankGoldFlow>> = _centralBankFlows.asStateFlow()

    // Demonstration Scenario State (Step 1 to 16)
    private val _demoStep = MutableStateFlow(0)
    val demoStep: StateFlow<Int> = _demoStep.asStateFlow()

    private val _isDemoRunning = MutableStateFlow(false)
    val isDemoRunning: StateFlow<Boolean> = _isDemoRunning.asStateFlow()

    private val _demoLogs = MutableStateFlow<List<String>>(emptyList())
    val demoLogs: StateFlow<List<String>> = _demoLogs.asStateFlow()

    // Ticker simulation loop
    init {
        startMarketSimulation()
    }

    private fun startMarketSimulation() {
        scope.launch {
            while (isActive) {
                delay(2000L)
                tickMarketPrices()
            }
        }
    }

    fun setSelectedAsset(asset: MetalAsset) {
        _selectedAsset.value = asset
        val currentSpot = _spotPrices.value[asset]?.last ?: 4188.30
        _orderBook.value = SyntheticMarketEngine.generateOrderBook(asset, currentSpot)
        _candleSeries.value = generateInitialCandles(currentSpot)
    }

    fun setMarketRegime(regime: MarketRegime) {
        _marketRegime.value = regime
        tickMarketPrices(regimeShift = true)
    }

    private fun tickMarketPrices(regimeShift: Boolean = false) {
        val currentPrices = _spotPrices.value.toMutableMap()
        val regime = _marketRegime.value
        val random = Random(System.currentTimeMillis())

        val volMultiplier = when (regime) {
            MarketRegime.VOLATILITY_SHOCK -> 3.5
            MarketRegime.LIQUIDITY_CRISIS -> 2.2
            MarketRegime.NORMAL -> 1.0
            else -> 1.5
        }

        currentPrices.forEach { (asset, price) ->
            val tickScale = if (asset == MetalAsset.GOLD) 0.40 else 0.05
            val bias = when (regime) {
                MarketRegime.PM_RALLY, MarketRegime.INFLATION_SHOCK -> 0.35
                MarketRegime.PM_SELLOFF, MarketRegime.USD_SHOCK -> -0.40
                else -> 0.0
            }

            val delta = ((random.nextGaussian() * tickScale * volMultiplier) + bias).roundTo(2)
            val newLast = max(10.0, price.last + delta).roundTo(2)
            val newBid = (newLast - (if (asset == MetalAsset.GOLD) 0.20 else 0.02) * volMultiplier).roundTo(2)
            val newAsk = (newLast + (if (asset == MetalAsset.GOLD) 0.20 else 0.02) * volMultiplier).roundTo(2)
            val sessionHigh = max(price.sessionHigh, newLast)
            val sessionLow = min(price.sessionLow, newLast)
            val change = (newLast - price.settlementPrice).roundTo(2)
            val changePct = ((change / price.settlementPrice) * 100.0).roundTo(2)

            currentPrices[asset] = price.copy(
                bid = newBid,
                ask = newAsk,
                last = newLast,
                changeAmount = change,
                changePercent = changePct,
                sessionHigh = sessionHigh,
                sessionLow = sessionLow,
                volumeOz = price.volumeOz + (abs(delta) * 150.0).roundTo(1),
                timestamp = System.currentTimeMillis()
            )
        }
        _spotPrices.value = currentPrices

        // Update selected asset order book
        val selected = _selectedAsset.value
        val spot = currentPrices[selected]?.last ?: 4188.30
        _orderBook.value = SyntheticMarketEngine.generateOrderBook(selected, spot)

        // Add candlestick tick if needed
        val candles = _candleSeries.value.toMutableList()
        if (candles.isNotEmpty()) {
            val lastCandle = candles.last()
            val updatedLast = lastCandle.copy(
                high = max(lastCandle.high, spot),
                low = min(lastCandle.low, spot),
                close = spot,
                volume = lastCandle.volume + 45.0
            )
            candles[candles.size - 1] = updatedLast
            _candleSeries.value = candles
        }

        // Recalculate portfolio & VaR
        recalculatePortfolioValues()
    }

    private fun recalculatePortfolioValues() {
        val goldSpot = _spotPrices.value[MetalAsset.GOLD]?.last ?: 4188.30
        val silverSpot = _spotPrices.value[MetalAsset.SILVER]?.last ?: 52.84

        val updatedHoldings = _portfolioHoldings.value.map { h ->
            val currentPrice = when {
                h.assetName.contains("Gold", ignoreCase = true) -> goldSpot
                h.assetName.contains("Silver", ignoreCase = true) -> silverSpot
                else -> h.currentMarketPrice
            }
            val marketVal = (h.quantity * currentPrice).roundTo(2)
            val pnl = (marketVal - (h.quantity * h.averageEntryPrice)).roundTo(2)
            val pnlPct = if (h.averageEntryPrice > 0) ((currentPrice - h.averageEntryPrice) / h.averageEntryPrice * 100.0).roundTo(2) else 0.0
            h.copy(
                currentMarketPrice = currentPrice,
                marketValueUsd = marketVal,
                unrealizedPnlUsd = pnl,
                unrealizedPnlPercent = pnlPct
            )
        }
        val totalVal = updatedHoldings.sumOf { it.marketValueUsd }
        val holdingsWithWeights = updatedHoldings.map {
            it.copy(weightPercent = if (totalVal > 0) ((it.marketValueUsd / totalVal) * 100.0).roundTo(1) else 0.0)
        }
        _portfolioHoldings.value = holdingsWithWeights
        _riskMetrics.value = SyntheticMarketEngine.computeVaR(totalVal, 0.65, 0.25)
    }

    // Place Order in OMS
    fun placeOrder(
        asset: MetalAsset,
        side: OrderSide,
        type: OrderType,
        quantityOz: Double,
        limitPrice: Double?,
        venue: ExecutionVenue = ExecutionVenue.NYM_DARK
    ): Order {
        val spot = _spotPrices.value[asset]?.last ?: 4188.30
        val executionPrice = limitPrice ?: (if (side == OrderSide.BUY) spot + 0.15 else spot - 0.15)
        val fee = (executionPrice * quantityOz * 0.00015).roundTo(2) // 1.5 bps clearing fee
        val slippage = (quantityOz * 0.02).roundTo(2)

        val order = Order(
            orderId = "ORD-NYM-${(100000..999999).random()}",
            clientAccount = "CLIENT-0194",
            metal = asset,
            side = side,
            orderType = type,
            quantityOz = quantityOz,
            limitPrice = limitPrice,
            venue = venue,
            timestamp = System.currentTimeMillis(),
            status = OrderStatus.FILLED,
            filledQuantityOz = quantityOz,
            averageExecutionPrice = executionPrice,
            estimatedFeeUsd = fee,
            estimatedSlippageUsd = slippage
        )

        _orders.value = listOf(order) + _orders.value

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        val valDate = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 2)
        val settleDate = sdf.format(cal.time)

        val trade = ExecutionTicket(
            tradeId = "TRD-NYM-${(100000..999999).random()}",
            orderId = order.orderId,
            accountId = "CLIENT-0194",
            metal = asset,
            side = side,
            executedQuantityOz = quantityOz,
            executionPrice = executionPrice,
            grossConsiderationUsd = (executionPrice * quantityOz).roundTo(2),
            exchangeClearingFeeUsd = fee,
            vaultAllocationFeeUsd = if (asset == MetalAsset.GOLD) 25.0 else 10.0,
            totalSettlementUsd = ((executionPrice * quantityOz) + fee).roundTo(2),
            venue = venue,
            timestamp = System.currentTimeMillis(),
            valueDate = valDate,
            settlementDate = settleDate
        )

        _executions.value = listOf(trade) + _executions.value

        // Record double entry ledger event
        recordTradeLedger(trade)
        return order
    }

    private fun recordTradeLedger(trade: ExecutionTicket) {
        val isBuy = trade.side == OrderSide.BUY
        val metalType = if (trade.metal == MetalAsset.GOLD) LedgerAssetType.GOLD_ALLOCATED_OZ else LedgerAssetType.SILVER_ALLOCATED_OZ

        val lines = listOf(
            DoubleEntryLine(
                lineId = "L1-${UUID.randomUUID().toString().take(6)}",
                accountName = if (isBuy) "Client Metal Custody (CLIENT-0194)" else "NYM Settlement Clearing",
                isDebit = true,
                assetType = metalType,
                amount = trade.executedQuantityOz
            ),
            DoubleEntryLine(
                lineId = "L2-${UUID.randomUUID().toString().take(6)}",
                accountName = if (isBuy) "NYM Settlement Clearing" else "Client Metal Custody (CLIENT-0194)",
                isDebit = false,
                assetType = metalType,
                amount = trade.executedQuantityOz
            ),
            DoubleEntryLine(
                lineId = "L3-${UUID.randomUUID().toString().take(6)}",
                accountName = if (isBuy) "NYM Cash Treasury" else "Client Cash Account (CLIENT-0194)",
                isDebit = true,
                assetType = LedgerAssetType.USD_CASH,
                amount = trade.totalSettlementUsd
            ),
            DoubleEntryLine(
                lineId = "L4-${UUID.randomUUID().toString().take(6)}",
                accountName = if (isBuy) "Client Cash Account (CLIENT-0194)" else "NYM Cash Treasury",
                isDebit = false,
                assetType = LedgerAssetType.USD_CASH,
                amount = trade.totalSettlementUsd
            )
        )

        val tx = JournalTransaction(
            transactionId = "JRN-${(100000..999999).random()}",
            type = JournalEntryType.TRADE_SETTLEMENT,
            timestamp = System.currentTimeMillis(),
            referenceId = trade.tradeId,
            description = "Settlement of ${trade.side} ${trade.executedQuantityOz} oz ${trade.metal.displayName} @ $${trade.executionPrice}",
            lines = lines,
            auditHash = "SHA256:8f4b9e2a" + (1000..9999).random(),
            verifiedBalanced = true
        )

        _journalTransactions.value = listOf(tx) + _journalTransactions.value

        // Update client balance
        val cur = _clientBalance.value
        val newCash = if (isBuy) cur.usdCashBalance - trade.totalSettlementUsd else cur.usdCashBalance + trade.totalSettlementUsd
        val newGold = if (trade.metal == MetalAsset.GOLD) {
            if (isBuy) cur.goldAllocatedOz + trade.executedQuantityOz else cur.goldAllocatedOz - trade.executedQuantityOz
        } else cur.goldAllocatedOz
        val newSilver = if (trade.metal == MetalAsset.SILVER) {
            if (isBuy) cur.silverAllocatedOz + trade.executedQuantityOz else cur.silverAllocatedOz - trade.executedQuantityOz
        } else cur.silverAllocatedOz

        _clientBalance.value = cur.copy(
            usdCashBalance = newCash.roundTo(2),
            goldAllocatedOz = newGold.roundTo(2),
            silverAllocatedOz = newSilver.roundTo(2)
        )
    }

    // Allocate / Deallocate Bar in Vault
    fun toggleBarAllocation(barId: String): BullionBar? {
        val bars = _bullionBars.value.toMutableList()
        val idx = bars.indexOfFirst { it.barId == barId }
        if (idx == -1) return null

        val bar = bars[idx]
        val newStatus = if (bar.status == BarStatus.ALLOCATED) BarStatus.VAULT_AVAILABLE else BarStatus.ALLOCATED
        val newOwner = if (newStatus == BarStatus.ALLOCATED) "CLIENT-0194 (Hudson Metals LLC)" else "NYM Vault Pool (Unallocated)"

        val updatedBar = bar.copy(
            status = newStatus,
            ownerId = newOwner,
            custodyHistory = bar.custodyHistory + CustodyMovement(
                movementId = "MOV-${(10000..99999).random()}",
                timestamp = System.currentTimeMillis(),
                fromLocation = bar.roomCode + " " + bar.shelfCode,
                toLocation = bar.roomCode + " " + bar.shelfCode,
                authorizationOfficer = "Chief Vault Custodian J. Sterling",
                actionType = if (newStatus == BarStatus.ALLOCATED) "CLIENT ALLOCATION" else "DEALLOCATION TO POOL",
                auditHash = "SIG-AUDIT-" + (100000..999999).random()
            )
        )
        bars[idx] = updatedBar
        _bullionBars.value = bars
        return updatedBar
    }

    // Quote and Execute RFQ
    fun generateQuoteForRfq(rfqId: String): RfqQuote? {
        val rfqs = _activeRfqs.value.toMutableList()
        val idx = rfqs.indexOfFirst { it.first.rfqId == rfqId }
        if (idx == -1) return null

        val req = rfqs[idx].first
        val spot = _spotPrices.value[req.metal]?.last ?: 4188.30
        val quote = SyntheticMarketEngine.priceRfq(
            spot = spot,
            quantityOz = req.quantityOz,
            side = req.side,
            tier = req.clientTier,
            volatility = 18.5,
            metal = req.metal
        )
        rfqs[idx] = Pair(req, quote)
        _activeRfqs.value = rfqs
        return quote
    }

    fun acceptRfqQuote(rfqId: String) {
        val rfqs = _activeRfqs.value.toMutableList()
        val idx = rfqs.indexOfFirst { it.first.rfqId == rfqId }
        if (idx == -1) return

        val (req, quote) = rfqs[idx]
        if (quote != null) {
            placeOrder(
                asset = req.metal,
                side = req.side,
                type = OrderType.MARKET,
                quantityOz = req.quantityOz,
                limitPrice = quote.finalPricePerOz,
                venue = ExecutionVenue.MANHATTAN_VAULT
            )
            rfqs.removeAt(idx)
            _activeRfqs.value = rfqs
        }
    }

    // Submit Physical Delivery Instruction
    fun submitDeliveryInstruction(
        metal: MetalAsset,
        barIds: List<String>,
        destinationAddress: String,
        logisticsProvider: String = "Brinks Global Armored Logistics NY"
    ): DeliveryInstruction {
        val bars = _bullionBars.value.filter { it.barId in barIds }
        val totalOz = bars.sumOf { it.fineWeightOz }
        val totalKg = bars.sumOf { it.grossWeightKg }
        val spot = _spotPrices.value[metal]?.last ?: 4188.30
        val declaredVal = (totalOz * spot).roundTo(2)

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        val dispatch = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 3)
        val estArrival = sdf.format(cal.time)

        val instruction = DeliveryInstruction(
            instructionId = "DLV-NYM-${(10000..99999).random()}",
            clientId = "CLIENT-0194",
            destinationAddress = destinationAddress,
            metal = metal,
            barIds = barIds,
            totalFineOz = totalOz.roundTo(2),
            totalGrossKg = totalKg.roundTo(2),
            declaredValueUsd = declaredVal,
            logisticsProvider = logisticsProvider,
            dispatchDate = dispatch,
            estimatedArrivalDate = estArrival,
            trackingAirwayBill = "BRINKS-NYM-" + (1000000..9999999).random(),
            tamperSealCodes = barIds.map { "SEAL-" + it.takeLast(6) },
            status = "ARMORED_EN_ROUTE"
        )

        _deliveryInstructions.value = listOf(instruction) + _deliveryInstructions.value

        // Update bar status to IN_TRANSIT
        val allBars = _bullionBars.value.toMutableList()
        barIds.forEach { bId ->
            val bIdx = allBars.indexOfFirst { it.barId == bId }
            if (bIdx != -1) {
                allBars[bIdx] = allBars[bIdx].copy(status = BarStatus.IN_TRANSIT_DELIVERY)
            }
        }
        _bullionBars.value = allBars
        return instruction
    }

    // 16-Step Animated Institutional Demonstration Lifecycle
    fun runFullDemonstrationLifecycle(onStepChanged: (Int, String) -> Unit) {
        if (_isDemoRunning.value) return
        _isDemoRunning.value = true
        _demoStep.value = 0
        _demoLogs.value = emptyList()

        scope.launch {
            val steps = listOf(
                "Step 1: New York Commodities Market Opens — COMEX & LBMA Session Active",
                "Step 2: Synthetic Spot Gold ticks to $4,188.30/oz with real-time microstructural order book depth",
                "Step 3: Institutional Client (Hudson Metals LLC) requests RFQ for 500 oz Good Delivery Gold",
                "Step 4: Dealer Pricing Matrix computes Reference Spot + Tier 1 Spread + Volatility Adjustment",
                "Step 5: Client accepts two-way firm dealer quote @ $4,192.55/oz (Total: $2,096,275 USD)",
                "Step 6: Trade booked & Execution Ticket TRD-NYM-84920 cleared on Manhattan Vault Gateway",
                "Step 7: Dealer Delta Hedged immediately: Short 5 COMEX GCZ6 Gold Futures Contracts",
                "Step 8: Physical Bar NYM-GLD-00018492 (12.438 kg Fine 999.9 Gold) selected in Vault 03",
                "Step 9: Vault Digital Twin transitions Shelf C-14 Pallet 09 status from Available to ALLOCATED",
                "Step 10: Metal Ledger records double-entry Debit (Vault Pool) -> Credit (Client Allocated XAU)",
                "Step 11: Cash Ledger records double-entry Debit (Client USD) -> Credit (NYM Treasury Clearing)",
                "Step 12: T+2 Settlement verified with zero reconciliation discrepancy (Debits == Credits)",
                "Step 13: Client Portfolio rebalanced: 1,625.40 oz Allocated Gold + $2.72M USD Reserve",
                "Step 14: Daily P&L Engine recalculates waterfall: +$14,250 spread capture, -$1,820 storage",
                "Step 15: Risk Engine runs 5,000-path Monte Carlo VaR (99% 1-Day VaR: $341,200 / Limit: 61%)",
                "Step 16: Cryptographic Audit Trail logs immutable event SHA256:8f4b9e2a9471. Complete!"
            )

            for (i in steps.indices) {
                _demoStep.value = i + 1
                val log = steps[i]
                _demoLogs.value = _demoLogs.value + log
                onStepChanged(i + 1, log)

                // Trigger real state updates at key steps
                when (i + 1) {
                    2 -> tickMarketPrices()
                    3 -> {
                        val newRfq = RfqRequest(
                            rfqId = "RFQ-NYM-DEMO-01",
                            clientName = "Hudson Metals LLC",
                            clientTier = ClientTier.TIER_1_SOVEREIGN,
                            metal = MetalAsset.GOLD,
                            side = OrderSide.BUY,
                            quantityOz = 500.0
                        )
                        val quote = SyntheticMarketEngine.priceRfq(4188.30, 500.0, OrderSide.BUY, ClientTier.TIER_1_SOVEREIGN, 18.5, MetalAsset.GOLD)
                        _activeRfqs.value = listOf(Pair(newRfq, quote)) + _activeRfqs.value
                    }
                    5 -> {
                        placeOrder(MetalAsset.GOLD, OrderSide.BUY, OrderType.LIMIT, 500.0, 4192.55, ExecutionVenue.MANHATTAN_VAULT)
                    }
                    8 -> {
                        toggleBarAllocation("NYM-GLD-00018492")
                    }
                    13 -> recalculatePortfolioValues()
                }

                delay(1200L)
            }
            _isDemoRunning.value = false
        }
    }

    private fun Double.roundTo(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return round(this * multiplier) / multiplier
    }

    // Seed Data Builders
    private fun initialSpotPrices(): Map<MetalAsset, SpotPrice> {
        return mapOf(
            MetalAsset.GOLD to SpotPrice(MetalAsset.GOLD, 4188.10, 4188.50, 4188.30, 51.40, 1.24, 482000.0, 184500L, 4196.80, 4132.50, 4136.90),
            MetalAsset.SILVER to SpotPrice(MetalAsset.SILVER, 52.80, 52.88, 52.84, 1.12, 2.17, 1284000.0, 312000L, 53.40, 51.60, 51.72),
            MetalAsset.PLATINUM to SpotPrice(MetalAsset.PLATINUM, 1024.50, 1026.00, 1025.20, -4.80, -0.47, 85000.0, 42000L, 1038.00, 1018.50, 1030.00),
            MetalAsset.PALLADIUM to SpotPrice(MetalAsset.PALLADIUM, 1142.00, 1145.00, 1143.50, 18.20, 1.62, 42000.0, 19500L, 1155.00, 1120.00, 1125.30),
            MetalAsset.RHODIUM to SpotPrice(MetalAsset.RHODIUM, 4850.00, 4950.00, 4900.00, 75.00, 1.55, 12000.0, 4800L, 4950.00, 4800.00, 4825.00)
        )
    }

    private fun generateInitialCandles(baseSpot: Double): List<CandleStick> {
        val list = mutableListOf<CandleStick>()
        var current = baseSpot - 40.0
        val now = System.currentTimeMillis()
        for (i in 30 downTo 0) {
            val open = current
            val delta = ((sin(i.toDouble()) * 8.0) + (cos(i.toDouble() * 1.5) * 6.0)).roundTo(2)
            val close = (open + delta).roundTo(2)
            val high = (max(open, close) + (abs(sin(i.toDouble())) * 4.0)).roundTo(2)
            val low = (min(open, close) - (abs(cos(i.toDouble())) * 3.5)).roundTo(2)
            val vol = (1200.0 + (abs(delta) * 350.0)).roundTo(1)
            list.add(CandleStick(now - (i * 60_000L), open, high, low, close, vol))
            current = close
        }
        return list
    }

    private fun initialMacroData(): MacroCorrelation {
        return MacroCorrelation(
            dxyDollarIndex = 101.42,
            dxyChange = -0.38,
            us10YRealYield = 1.68,
            us10YRealYieldChange = -0.04,
            sp500 = 5940.25,
            sp500Change = 0.42,
            wtiCrudeOil = 74.80,
            wtiChange = 1.15,
            usInflationExpectations = 2.45,
            goldDxyCorrelation = -0.78,
            goldYieldCorrelation = -0.84,
            silverIndustrialCorrelation = 0.72
        )
    }

    private fun initialOrders(): List<Order> {
        return listOf(
            Order("ORD-NYM-849201", "CLIENT-0194", MetalAsset.GOLD, OrderSide.BUY, OrderType.LIMIT, 250.0, 4185.00, status = OrderStatus.FILLED, averageExecutionPrice = 4185.00, filledQuantityOz = 250.0, estimatedFeeUsd = 156.93),
            Order("ORD-NYM-849182", "CLIENT-0194", MetalAsset.SILVER, OrderSide.BUY, OrderType.TWAP, 5000.0, 52.50, status = OrderStatus.PARTIALLY_FILLED, averageExecutionPrice = 52.48, filledQuantityOz = 3200.0, algoSliceProgress = 0.64f),
            Order("ORD-NYM-849140", "CLIENT-0194", MetalAsset.GOLD, OrderSide.SELL, OrderType.STOP_LIMIT, 100.0, 4150.00, stopPrice = 4155.00, status = OrderStatus.PENDING)
        )
    }

    private fun initialExecutions(): List<ExecutionTicket> {
        return listOf(
            ExecutionTicket("TRD-NYM-99102", "ORD-NYM-849201", "CLIENT-0194", MetalAsset.GOLD, OrderSide.BUY, 250.0, 4185.00, 1_046_250.0, 156.93, 25.0, 1_046_431.93, ExecutionVenue.NYM_DARK, valueDate = "2026-10-05", settlementDate = "2026-10-07"),
            ExecutionTicket("TRD-NYM-99084", "ORD-NYM-849005", "CLIENT-0194", MetalAsset.SILVER, OrderSide.BUY, 10000.0, 52.10, 521_000.0, 78.15, 15.0, 521_093.15, ExecutionVenue.LBMA_OTC, valueDate = "2026-10-04", settlementDate = "2026-10-06")
        )
    }

    private fun initialRfqs(): List<Pair<RfqRequest, RfqQuote?>> {
        val req1 = RfqRequest("RFQ-NYM-7841", "Hudson Metals LLC", ClientTier.TIER_1_SOVEREIGN, MetalAsset.GOLD, OrderSide.BUY, 500.0)
        val quote1 = SyntheticMarketEngine.priceRfq(4188.30, 500.0, OrderSide.BUY, ClientTier.TIER_1_SOVEREIGN, 18.5, MetalAsset.GOLD)

        val req2 = RfqRequest("RFQ-NYM-7842", "Broad Street Commodities Fund", ClientTier.TIER_2_INSTITUTIONAL, MetalAsset.SILVER, OrderSide.SELL, 25000.0)
        val quote2 = SyntheticMarketEngine.priceRfq(52.84, 25000.0, OrderSide.SELL, ClientTier.TIER_2_INSTITUTIONAL, 24.2, MetalAsset.SILVER)

        return listOf(Pair(req1, quote1), Pair(req2, quote2))
    }

    private fun initialBars(): List<BullionBar> {
        return listOf(
            BullionBar(
                barId = "NYM-GLD-00018492",
                metal = MetalAsset.GOLD,
                standard = BarStandard.GOLD_400_OZ,
                grossWeightKg = 12.441,
                fineWeightKg = 12.438,
                fineWeightOz = 399.98,
                purity = 999.9,
                refinerName = "Empire Refining Company (NY)",
                serialNumber = "A893742",
                assayCertificateNumber = "ASSAY-NYM-99201",
                vaultFacility = "New York Vault 03 (Lower Manhattan)",
                roomCode = "Room A - Heavy Bullion Safe",
                cageCode = "Cage Tier-1",
                shelfCode = "Shelf C-14",
                palletId = "Pallet 09",
                status = BarStatus.ALLOCATED,
                ownerId = "CLIENT-0194 (Hudson Metals LLC)",
                lastInspectionDate = "2026-09-18",
                custodyHistory = listOf(
                    CustodyMovement("MOV-1001", System.currentTimeMillis() - 864000000L, "Refinery Dispatch LIC", "NY Vault 03 Intake", "Officer D. Vance", "VAULT INTAKE ASSAY", "HASH-99120"),
                    CustodyMovement("MOV-1002", System.currentTimeMillis() - 432000000L, "NY Vault 03 Intake", "Room A Shelf C-14", "Officer J. Sterling", "ALLOCATION TO CLIENT-0194", "HASH-99124")
                ),
                inspectionRecords = listOf(
                    InspectionRecord("INSP-401", "2026-09-18", "Senior Assayer E. Vance", "Ultrasound Density & XRF Spectrometry", "PASSED 999.9 FINE", true)
                )
            ),
            BullionBar(
                barId = "NYM-GLD-00018493",
                metal = MetalAsset.GOLD,
                standard = BarStandard.GOLD_400_OZ,
                grossWeightKg = 12.445,
                fineWeightKg = 12.442,
                fineWeightOz = 400.02,
                purity = 999.9,
                refinerName = "Valcambi NYM Good Delivery",
                serialNumber = "V994120",
                assayCertificateNumber = "ASSAY-VAL-88402",
                vaultFacility = "New York Vault 03 (Lower Manhattan)",
                roomCode = "Room A - Heavy Bullion Safe",
                cageCode = "Cage Tier-1",
                shelfCode = "Shelf C-14",
                palletId = "Pallet 09",
                status = BarStatus.ALLOCATED,
                ownerId = "CLIENT-0194 (Hudson Metals LLC)",
                lastInspectionDate = "2026-09-22",
                custodyHistory = emptyList(),
                inspectionRecords = emptyList()
            ),
            BullionBar(
                barId = "NYM-GLD-00018494",
                metal = MetalAsset.GOLD,
                standard = BarStandard.GOLD_400_OZ,
                grossWeightKg = 12.439,
                fineWeightKg = 12.436,
                fineWeightOz = 399.92,
                purity = 999.9,
                refinerName = "Empire Refining Company (NY)",
                serialNumber = "A893744",
                assayCertificateNumber = "ASSAY-NYM-99203",
                vaultFacility = "New York Vault 03 (Lower Manhattan)",
                roomCode = "Room A - Heavy Bullion Safe",
                cageCode = "Cage Tier-1",
                shelfCode = "Shelf C-15",
                palletId = "Pallet 10",
                status = BarStatus.VAULT_AVAILABLE,
                ownerId = "NYM Vault Pool (Unallocated)",
                lastInspectionDate = "2026-09-25",
                custodyHistory = emptyList(),
                inspectionRecords = emptyList()
            ),
            BullionBar(
                barId = "NYM-SLV-00049210",
                metal = MetalAsset.SILVER,
                standard = BarStandard.SILVER_1000_OZ,
                grossWeightKg = 31.108,
                fineWeightKg = 31.077,
                fineWeightOz = 999.15,
                purity = 999.0,
                refinerName = "Asahi Refining NYM",
                serialNumber = "S449102",
                assayCertificateNumber = "ASSAY-SLV-77192",
                vaultFacility = "New York Vault 03 (Lower Manhattan)",
                roomCode = "Room B - Silver Treasury Wing",
                cageCode = "Cage Silver-East",
                shelfCode = "Bay S-04",
                palletId = "Pallet SLV-42",
                status = BarStatus.ALLOCATED,
                ownerId = "CLIENT-0194 (Hudson Metals LLC)",
                lastInspectionDate = "2026-09-10",
                custodyHistory = emptyList(),
                inspectionRecords = emptyList()
            ),
            BullionBar(
                barId = "NYM-SLV-00049211",
                metal = MetalAsset.SILVER,
                standard = BarStandard.SILVER_1000_OZ,
                grossWeightKg = 31.115,
                fineWeightKg = 31.084,
                fineWeightOz = 999.38,
                purity = 999.0,
                refinerName = "Asahi Refining NYM",
                serialNumber = "S449103",
                assayCertificateNumber = "ASSAY-SLV-77193",
                vaultFacility = "New York Vault 03 (Lower Manhattan)",
                roomCode = "Room B - Silver Treasury Wing",
                cageCode = "Cage Silver-East",
                shelfCode = "Bay S-04",
                palletId = "Pallet SLV-42",
                status = BarStatus.VAULT_AVAILABLE,
                ownerId = "NYM Vault Pool (Unallocated)",
                lastInspectionDate = "2026-09-12",
                custodyHistory = emptyList(),
                inspectionRecords = emptyList()
            )
        )
    }

    private fun initialVaultInfo(): VaultFacilityInfo {
        return VaultFacilityInfo(
            facilityId = "NY-VAULT-03",
            name = "New York Central Bullion Depository 03",
            locationDescription = "Lower Manhattan Subterranean Bedrock Facility (Wall St / Broad St Nexus)",
            totalGoldKg = 42_819.0,
            totalSilverKg = 1_284_600.0,
            goldAllocatedKg = 31_450.0,
            silverAllocatedKg = 985_200.0,
            goldAvailableKg = 11_369.0,
            silverAvailableKg = 299_400.0,
            capacityUtilizationPercent = 74.2,
            armedSecurityLevel = "Class 3 Subterranean Fortified (Dual Biometric + Armed Force)",
            activeSensors = 142,
            insuranceUnderwriter = "Lloyd's of London & Manhattan Syndicate ($10B Policy)"
        )
    }

    private fun initialDeliveries(): List<DeliveryInstruction> {
        return listOf(
            DeliveryInstruction(
                instructionId = "DLV-NYM-84910",
                clientId = "CLIENT-0194",
                destinationAddress = "200 West Street, 38th Floor Treasury, New York, NY 10282",
                metal = MetalAsset.GOLD,
                barIds = listOf("NYM-GLD-00018492"),
                totalFineOz = 399.98,
                totalGrossKg = 12.441,
                declaredValueUsd = 1_675_200.0,
                logisticsProvider = "Brinks Global Armored Logistics NY",
                dispatchDate = "2026-10-06",
                estimatedArrivalDate = "2026-10-07",
                trackingAirwayBill = "BRINKS-NY-994182",
                tamperSealCodes = listOf("SEAL-018492"),
                status = "APPROVED"
            )
        )
    }

    private fun initialJournal(): List<JournalTransaction> {
        return listOf(
            JournalTransaction(
                transactionId = "JRN-894102",
                type = JournalEntryType.CLIENT_DEPOSIT,
                timestamp = System.currentTimeMillis() - 86400000L * 3,
                referenceId = "WIRE-NYFED-88419",
                description = "Initial Institutional Treasury Wire Capital Inflow",
                lines = listOf(
                    DoubleEntryLine("L1", "Client Cash Balance (CLIENT-0194)", true, LedgerAssetType.USD_CASH, 5_000_000.0),
                    DoubleEntryLine("L2", "NYM Clearing Bank Account", false, LedgerAssetType.USD_CASH, 5_000_000.0)
                ),
                auditHash = "SHA256:4a8e91c2b1928",
                verifiedBalanced = true
            ),
            JournalTransaction(
                transactionId = "JRN-894103",
                type = JournalEntryType.METAL_ALLOCATION,
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                referenceId = "ALC-BAR-18492",
                description = "Allocation of 400 oz Good Delivery Gold Bar NYM-GLD-00018492",
                lines = listOf(
                    DoubleEntryLine("L3", "Client Allocated Gold Custody", true, LedgerAssetType.GOLD_ALLOCATED_OZ, 400.0),
                    DoubleEntryLine("L4", "NYM Vault Available Bullion Pool", false, LedgerAssetType.GOLD_ALLOCATED_OZ, 400.0)
                ),
                auditHash = "SHA256:7b1d44a9e8831",
                verifiedBalanced = true
            )
        )
    }

    private fun initialOptions(): List<PreciousMetalsOption> {
        val spot = 4188.30
        val strikes = listOf(4000.0, 4100.0, 4188.30, 4250.0, 4350.0, 4500.0)
        return strikes.flatMap { strike ->
            val (callPrice, callGreeks) = SyntheticMarketEngine.calculateBlackScholes(spot, strike, 45, 18.5, isCall = true)
            val (putPrice, putGreeks) = SyntheticMarketEngine.calculateBlackScholes(spot, strike, 45, 18.5, isCall = false)

            listOf(
                PreciousMetalsOption("OPT-GLD-C-${strike.toInt()}", MetalAsset.GOLD, OptionType.CALL, strike, 45, "Nov 2026", 18.5, callPrice, (callPrice * 0.98).roundTo(2), (callPrice * 1.02).roundTo(2), callGreeks, 4520L, 890L),
                PreciousMetalsOption("OPT-GLD-P-${strike.toInt()}", MetalAsset.GOLD, OptionType.PUT, strike, 45, "Nov 2026", 18.5, putPrice, (putPrice * 0.98).roundTo(2), (putPrice * 1.02).roundTo(2), putGreeks, 3810L, 640L)
            )
        }
    }

    private fun initialHoldings(): List<PortfolioHolding> {
        return listOf(
            PortfolioHolding("HLD-01", "Physical Allocated", "400 oz Allocated Gold Bars (999.9)", 800.0, "oz t", 3920.00, 4188.30, 3_350_640.0, 214_640.0, 6.85, 26.8),
            PortfolioHolding("HLD-02", "Physical Allocated", "1,000 oz Silver Ingots (999.0)", 40_000.0, "oz t", 48.50, 52.84, 2_113_600.0, 173_600.0, 8.95, 16.9),
            PortfolioHolding("HLD-03", "COMEX Futures", "GCZ6 Long Gold Futures (50 Cont)", 5000.0, "oz t", 4120.00, 4205.40, 2_102_700.0, 427_000.0, 25.50, 16.8),
            PortfolioHolding("HLD-04", "Exchange Options", "Gold Call Spread (4200/4350 Dec)", 25.0, "contracts", 48.00, 72.50, 181_250.0, 61_250.0, 51.04, 1.5),
            PortfolioHolding("HLD-05", "Cash Treasury", "USD Federal Reserve Overnight Repo", 4_734_720.0, "USD", 1.0, 1.0, 4_734_720.0, 0.0, 0.0, 38.0)
        )
    }

    private fun initialPnlAttribution(): PnlAttribution {
        return PnlAttribution(
            openingPortfolioValueUsd = 12_398_450.0,
            marketMovementPnlUsd = 68_420.0,
            activeTradingRevenueUsd = 14_250.0,
            dealerSpreadCaptureUsd = 8_940.0,
            futuresHedgingPnlUsd = -5_340.0,
            storageAndInsuranceFeeUsd = -1_810.0,
            financingCostUsd = -0.0,
            netDailyPnlUsd = 84_460.0,
            totalRealizedPnlYtdUsd = 642_800.0,
            totalUnrealizedPnlUsd = 876_490.0,
            closingPortfolioValueUsd = 12_482_910.0
        )
    }

    private fun initialScrapLots(): List<ScrapIntakeLot> {
        return listOf(
            ScrapIntakeLot("SCR-9901", "Empire Electronics Recovery LLC", "High-Grade Electronics Circuit Scrap", 450.0, 8.5, 24.0, "2026-10-02", "ELECTROLYTIC_PARTING"),
            ScrapIntakeLot("SCR-9902", "47th Street Jewellery Exchange Desk", "Estate Jewellery Scrap 14k/18k", 84.5, 58.3, 14.2, "2026-10-04", "PYROMETALLURGIC_SMELTING")
        )
    }

    private fun initialRefineryBatches(): List<RefineryBatch> {
        return listOf(
            RefineryBatch(
                batchId = "BATCH-LIC-2026-88",
                facilityName = "Empire Refining Co - Long Island City Complex",
                stage = "CASTING_AND_ASSAY",
                inputMassKg = 534.5,
                processLossKg = 3.2,
                recoveryYieldPercent = 99.4,
                outputFineGoldKg = 87.45,
                outputFineSilverKg = 412.30,
                energyKwhConsumed = 1420.0,
                chemicalReagentCostUsd = 2840.0,
                outputPurity = 999.9,
                newlyCastBarIds = listOf("NYM-GLD-00018492", "NYM-GLD-00018493", "NYM-SLV-00049210")
            )
        )
    }

    private fun initialResearchReports(): List<MetalsResearchReport> {
        return listOf(
            MetalsResearchReport(
                reportId = "REP-2026-W40",
                title = "Gold & Silver Macro Intelligence: De-Dollarization & Physical Tightness in New York",
                authorDesk = "New York Commodities Macro Strategy Group",
                publishDate = "October 5, 2026",
                liquidityRating = "HIGH INSTITUTIONAL",
                volatilityRegime = "ELEVATED (18.5% 30D HV)",
                futuresPositioningSignal = "NET SPECULATIVE LONG EXPANSION",
                curveStructure = "MILD CONTANGO (3.8% ANNUALIZED BASIS)",
                macroSummary = "Central bank sovereign gold accumulation remains resilient alongside steady Asian retail demand. Silver industrial consumption in photovoltaic and electronics continues to outpace mine supply, generating structural physical deficits across COMEX and LBMA vaults.",
                keyTakeaways = listOf(
                    "Gold Spot testing $4,190 resistance with strong institutional dip-buying at $4,120 support.",
                    "Gold/Silver ratio compressing toward 79.2 as industrial silver demand surges.",
                    "Physical premiums on 400 oz Good Delivery bars in Manhattan Depository holding firm at +$4.25/oz over spot."
                )
            )
        )
    }

    private fun initialCftcData(): List<CftcCotPositioning> {
        return listOf(
            CftcCotPositioning("Gold (COMEX 100 oz)", "2026-09-29", 482500L, 142000L, 388000L, -246000L, 312000L, 66000L, +246000L, +14800L, "BULLISH EXTREME"),
            CftcCotPositioning("Silver (COMEX 5,000 oz)", "2026-09-29", 178400L, 48000L, 124000L, -76000L, 114000L, 38000L, +76000L, +5200L, "BULLISH CONTINUATION")
        )
    }

    private fun initialCentralBankFlows(): List<CentralBankGoldFlow> {
        return listOf(
            CentralBankGoldFlow("People's Bank of China (PBOC)", "China", 18.5, 2264.0, 4.9, "Aggressive Net Accumulation"),
            CentralBankGoldFlow("National Bank of Poland (NBP)", "Poland", 12.2, 420.0, 14.8, "Strategic Sovereign Expansion"),
            CentralBankGoldFlow("Reserve Bank of India (RBI)", "India", 9.4, 840.0, 8.6, "Steady Reserve Diversification"),
            CentralBankGoldFlow("Saudi Central Bank (SAMA)", "Saudi Arabia", 5.0, 323.0, 4.1, "Bilateral Physical Settlement Allocation")
        )
    }
}
