package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.engine.SyntheticMarketEngine
import com.example.data.model.MetalAsset
import com.example.ui.components.FuturesCurveChart
import com.example.ui.theme.*

@Composable
fun FuturesCurveScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val spotPrices by repository.spotPrices.collectAsState()
    var selectedMetal by remember { mutableStateOf(MetalAsset.GOLD) }

    val currentSpot = spotPrices[selectedMetal]?.last ?: (if (selectedMetal == MetalAsset.GOLD) 4188.30 else 52.84)
    val curveComparison = remember(selectedMetal, currentSpot) {
        SyntheticMarketEngine.generateFuturesCurve(selectedMetal, currentSpot)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("futures_curve_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header & Metal Asset Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COMEX PRECIOUS METALS FUTURES CURVE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Term Structure Analysis • Basis Implication • Annualized Roll Yield",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(MetalAsset.GOLD, MetalAsset.SILVER).forEach { asset ->
                        val isSelected = asset == selectedMetal
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) BullionGoldPrimary else ObsidianElevated)
                                .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = asset.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) TextDark else TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }

        // Multi-curve comparison visualizer
        FuturesCurveChart(curveComparison = curveComparison)

        // Basis & Roll Engine Mathematical Breakdown
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "THEORETICAL BASIS & CARRY ANALYSIS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("SPOT PRICE", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                        Text("$${String.format("%,.2f", currentSpot)}", style = MaterialTheme.typography.labelLarge.copy(color = TextWhite))
                        Text("Manhattan Benchmark", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("1Y FORWARD BASIS", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                        Text("+3.84%", style = MaterialTheme.typography.labelLarge.copy(color = TerminalGreen))
                        Text("SOFR + Depository Fee", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("REGIME", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                        Text("CONTANGO", style = MaterialTheme.typography.labelLarge.copy(color = BullionGoldBright))
                        Text("Full Storage Carry", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp))
                    }
                }
            }
        }
    }
}
