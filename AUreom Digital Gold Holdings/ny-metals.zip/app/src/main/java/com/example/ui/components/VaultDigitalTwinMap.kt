package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun VaultDigitalTwinMap(
    vaultInfo: VaultFacilityInfo,
    bars: List<BullionBar>,
    onBarSelected: (BullionBar) -> Unit,
    onToggleAllocation: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRoom by remember { mutableStateOf("Room A - Heavy Bullion Safe") }
    var selectedBarForDetail by remember { mutableStateOf<BullionBar?>(null) }

    val rooms = listOf(
        "Room A - Heavy Bullion Safe",
        "Room B - Silver Treasury Wing",
        "Room C - Security Ingot Cage"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("vault_digital_twin_map"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MANHATTAN VAULT 03 DIGITAL TWIN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Class 3 Subterranean Fortified • 142 Active Telemetry Sensors",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalGreenBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "SECURE SYNC",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Vault Global Capacity Metrics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TOTAL GOLD", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("${String.format("%,.0f", vaultInfo.totalGoldKg)} kg", style = MaterialTheme.typography.labelLarge.copy(color = BullionGoldBright))
                    Text("Allocated: ${String.format("%,.0f", vaultInfo.goldAllocatedKg)} kg", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp))
                }
                Column {
                    Text("TOTAL SILVER", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("${String.format("%,.0f", vaultInfo.totalSilverKg)} kg", style = MaterialTheme.typography.labelLarge.copy(color = BullionSilverBright))
                    Text("Allocated: ${String.format("%,.0f", vaultInfo.silverAllocatedKg)} kg", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp))
                }
                Column {
                    Text("UTILIZATION", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    Text("${String.format("%.1f", vaultInfo.capacityUtilizationPercent)}%", style = MaterialTheme.typography.labelLarge.copy(color = TerminalGreen))
                    Text("Policy: $10B Syndicate", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Room Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                rooms.forEach { room ->
                    val isSelected = room == selectedRoom
                    val shortName = when {
                        room.contains("Room A") -> "Room A (Gold)"
                        room.contains("Room B") -> "Room B (Silver)"
                        else -> "Room C (Ingot)"
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) ObsidianElevated else Color.Transparent)
                            .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedRoom = room }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = shortName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isSelected) BullionGoldBright else TextMuted,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.5.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Floor Grid Visualizer
            Text(
                text = "$selectedRoom — SHELVES & PALLETS",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
            )
            Spacer(modifier = Modifier.height(6.dp))

            val filteredBars = bars.filter {
                if (selectedRoom.contains("Room A")) it.metal == MetalAsset.GOLD
                else if (selectedRoom.contains("Room B")) it.metal == MetalAsset.SILVER
                else true
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                filteredBars.forEach { bar ->
                    val isAllocated = bar.status == BarStatus.ALLOCATED
                    val isClientOwned = bar.ownerId.contains("CLIENT-0194")
                    val statusColor = when (bar.status) {
                        BarStatus.ALLOCATED -> BullionGoldBright
                        BarStatus.VAULT_AVAILABLE -> TerminalGreen
                        BarStatus.IN_TRANSIT_DELIVERY -> AlertAmber
                        else -> TextMuted
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, if (isClientOwned) BullionGoldPrimary.copy(alpha = 0.6f) else ObsidianBorder, RoundedCornerShape(4.dp))
                            .clickable {
                                selectedBarForDetail = bar
                                onBarSelected(bar)
                            }
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = if (bar.metal == MetalAsset.GOLD) BullionGoldPrimary else BullionSilverPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = bar.barId,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = TextWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                    Text(
                                        text = "${bar.standard.displayName} • ${bar.purity} Fine • ${bar.refinerName}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(statusColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = bar.status.displayName,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.5.sp
                                        )
                                    )
                                }
                                Text(
                                    text = "${bar.shelfCode} (${bar.palletId})",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Bar Details Dialog
    selectedBarForDetail?.let { bar ->
        BullionCertificateDialog(
            bar = bar,
            onDismiss = { selectedBarForDetail = null },
            onToggleAllocation = {
                onToggleAllocation(bar.barId)
                selectedBarForDetail = null
            }
        )
    }
}
