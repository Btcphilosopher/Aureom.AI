package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FuturesCurveComparison
import com.example.ui.theme.*
import kotlin.math.max
import kotlin.math.min

@Composable
fun FuturesCurveChart(
    curveComparison: FuturesCurveComparison,
    modifier: Modifier = Modifier
) {
    var showPrevClose by remember { mutableStateOf(true) }
    var showOneWeek by remember { mutableStateOf(false) }
    var showOneMonth by remember { mutableStateOf(false) }
    var showScenario by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("futures_curve_chart"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COMEX ${curveComparison.metal.displayName.uppercase()} FUTURES CURVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "TERM STRUCTURE: CONTANGO (+3.8% ANNUALIZED ROLL)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalGreen,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Curve Toggle Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CurveToggleChip("Live", BullionGoldPrimary, true) { /* always on */ }
                CurveToggleChip("Prev Close", BullionSilverPrimary, showPrevClose) { showPrevClose = !showPrevClose }
                CurveToggleChip("-1W", InfoNavy, showOneWeek) { showOneWeek = !showOneWeek }
                CurveToggleChip("-1M", TextSubtle, showOneMonth) { showOneMonth = !showOneMonth }
                CurveToggleChip("Scenario", RiskCrimson, showScenario) { showScenario = !showScenario }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Canvas Forward Curve Plot
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val contracts = curveComparison.contracts
                    if (contracts.isEmpty()) return@Canvas

                    val allValues = mutableListOf<Double>()
                    allValues.addAll(contracts.map { it.lastPrice })
                    if (showPrevClose) allValues.addAll(curveComparison.prevClosePrices)
                    if (showOneWeek) allValues.addAll(curveComparison.oneWeekAgoPrices)
                    if (showOneMonth) allValues.addAll(curveComparison.oneMonthAgoPrices)
                    if (showScenario) allValues.addAll(curveComparison.scenarioPrices)

                    val minVal = (allValues.minOrNull() ?: 4000.0) * 0.995
                    val maxVal = (allValues.maxOrNull() ?: 4400.0) * 1.005
                    val valRange = max(maxVal - minVal, 1.0)

                    val xStep = size.width / max(contracts.size - 1, 1)

                    // Draw Grid
                    for (i in 0..4) {
                        val y = size.height * (i / 4f)
                        drawLine(
                            color = ObsidianBorder.copy(alpha = 0.5f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1f
                        )
                    }

                    // Helper to draw a curve line
                    fun drawCurveLine(prices: List<Double>, color: Color, isMain: Boolean = false) {
                        val path = Path()
                        prices.forEachIndexed { index, price ->
                            val x = index * xStep
                            val y = size.height * (1f - ((price - minVal) / valRange).toFloat())
                            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)

                            // Point Dot
                            drawCircle(
                                color = color,
                                radius = if (isMain) 4f else 2.5f,
                                center = Offset(x, y)
                            )
                        }
                        drawPath(
                            path = path,
                            color = color,
                            style = Stroke(width = if (isMain) 3f else 1.5f, cap = StrokeCap.Round)
                        )
                    }

                    if (showOneMonth) drawCurveLine(curveComparison.oneMonthAgoPrices, TextSubtle)
                    if (showOneWeek) drawCurveLine(curveComparison.oneWeekAgoPrices, InfoNavy)
                    if (showPrevClose) drawCurveLine(curveComparison.prevClosePrices, BullionSilverPrimary)
                    if (showScenario) drawCurveLine(curveComparison.scenarioPrices, RiskCrimson)
                    // Main current curve
                    drawCurveLine(contracts.map { it.lastPrice }, BullionGoldPrimary, isMain = true)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Contract Table Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("CONTRACT", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.5f))
                Text("LAST ($)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.5f))
                Text("BASIS", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.2f))
                Text("ROLL %", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.2f))
                Text("DTE", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(0.8f))
            }

            Divider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))

            curveComparison.contracts.take(5).forEach { c ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${c.ticker} (${c.monthName})", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1.5f))
                    Text(String.format("%,.2f", c.lastPrice), style = MaterialTheme.typography.labelSmall.copy(color = TextWhite), modifier = Modifier.weight(1.5f))
                    Text("+${String.format("%.2f", c.impliedBasisUsd)}", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen), modifier = Modifier.weight(1.2f))
                    Text("${String.format("%.2f", c.annualizedRollYieldPercent)}%", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1.2f))
                    Text("${c.daysToExpiry}d", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle), modifier = Modifier.weight(0.8f))
                }
            }
        }
    }
}

@Composable
private fun CurveToggleChip(
    label: String,
    color: Color,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (isActive) color.copy(alpha = 0.2f) else ObsidianElevated)
            .border(1.dp, if (isActive) color else ObsidianBorder, RoundedCornerShape(3.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isActive) color else TextSubtle,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
