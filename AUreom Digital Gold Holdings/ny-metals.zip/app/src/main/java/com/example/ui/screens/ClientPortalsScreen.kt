package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.MetalAsset
import com.example.ui.theme.*

enum class PortalPersona(val title: String, val subtitle: String) {
    HEDGE_FUND("Hedge Funds & CTAs", "Quantitative Execution • Cross-Commodity Basis • Dark Pools"),
    FAMILY_OFFICE("Family Offices & Ultra-HNW", "Direct Subterranean Physical Bullion Custody & Succession"),
    CORPORATE_TREASURY("Corporate Hedging", "Precious Metals Price Risk Mitigation & Treasury Swaps"),
    INDUSTRIAL_USER("Industrial Silver", "Photovoltaic & Electronics Bulk Forward Delivery Contracts"),
    PRIVATE_CLIENT("Private Banking Wealth", "Elite Bespoke Vault Allocations & Digital Gold Certificates")
}

@Composable
fun ClientPortalsScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    var selectedPersona by remember { mutableStateOf(PortalPersona.HEDGE_FUND) }
    val spotPrices by repository.spotPrices.collectAsState()
    val goldSpot = spotPrices[MetalAsset.GOLD]?.last ?: 4188.30
    val silverSpot = spotPrices[MetalAsset.SILVER]?.last ?: 52.84

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("client_portals_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Persona Selector Tabs
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SELECT CLIENT DESK PERSPECTIVE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                PortalPersona.values().forEach { persona ->
                    val isSelected = persona == selectedPersona
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) ObsidianElevated else Color.Transparent)
                            .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedPersona = persona }
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = persona.title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (isSelected) BullionGoldBright else TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = persona.subtitle,
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp)
                            )
                        }
                        if (isSelected) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = BullionGoldPrimary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Tailored Perspective Content Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = selectedPersona.title.uppercase(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                when (selectedPersona) {
                    PortalPersona.HEDGE_FUND -> {
                        Text("• Dark Liquidity Pool Access: NYM-DARK continuous execution gateway with sub-millisecond fill latency.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Portfolio Margin Efficiency: Cross-margining between COMEX synthetic futures and vaulted physical collateral.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Real-Time Risk Feeds: Real-time FIX API 4.4 and JSON WebSocket drop-copy streams.", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                    }
                    PortalPersona.FAMILY_OFFICE -> {
                        Text("• Direct Title Ownership: 100% segregated, allocated serialized 400 oz gold bars in Lower Manhattan bedrock.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Zero Counterparty Bail-In Risk: Metal held completely outside the commercial fractional banking system.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Bespoke Custody Certificates: Cryptographically signed assay titles for multigenerational estate planning.", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                    }
                    PortalPersona.CORPORATE_TREASURY -> {
                        Text("• Balance Sheet Inflation Hedging: Treasury reserve diversification into Tier-1 physical gold reserves.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Fixed Forward Purchasing: Lock in gold/silver forward prices up to 24 months out with T+2 delivery.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                    }
                    PortalPersona.INDUSTRIAL_USER -> {
                        Text("• Industrial Silver Procurement: Bulk 1,000 oz and 15 kg grain ingots for solar PV and semiconductor fabricators.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Guaranteed Delivery SLAs: Direct armored dispatch to manufacturing hubs in New York, New Jersey, and Ohio.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                    }
                    PortalPersona.PRIVATE_CLIENT -> {
                        Text("• Wall Street Private Banking: Direct access to Senior Bullion Partners in Lower Manhattan.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• Instant Physical Allocation: Convert fiat USD instantly into allocated bars with zero execution spread markups.", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                    }
                }
            }
        }
    }
}
