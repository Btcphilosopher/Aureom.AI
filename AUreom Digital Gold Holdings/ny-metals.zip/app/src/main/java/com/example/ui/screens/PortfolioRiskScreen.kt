package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.components.StressTestLab
import com.example.ui.theme.*

@Composable
fun PortfolioRiskScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val holdings by repository.portfolioHoldings.collectAsState()
    val risk by repository.riskMetrics.collectAsState()
    val pnl by repository.pnlAttribution.collectAsState()

    val totalValue = holdings.sumOf { it.marketValueUsd }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("portfolio_risk_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Portfolio Value Hero Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "INSTITUTIONAL PRECIOUS METALS PORTFOLIO",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = BullionGoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "CLIENT-0194 • Manhattan Master Custody Account",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalGreenBg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ACTIVE AUDIT",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TerminalGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "$${String.format("%,.2f", totalValue)} USD",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextWhite,
                        fontFamily = FontFamily.Monospace
                    )
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        text = "Net Daily P&L: +$${String.format("%,.2f", pnl.netDailyPnlUsd)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Realized YTD: +$${String.format("%,.2f", pnl.totalRealizedPnlYtdUsd)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright)
                    )
                }
            }
        }

        // Holdings Breakdown
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "PRECIOUS METALS & DERIVATIVES POSITIONS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                holdings.forEach { h ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(h.assetName, style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text("$${String.format("%,.2f", h.marketValueUsd)}", style = MaterialTheme.typography.labelMedium.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${String.format("%,.2f", h.quantity)} ${h.unit} • ${h.category}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                            Text("Unrealized: ${if (h.unrealizedPnlUsd >= 0) "+" else ""}$${String.format("%,.0f", h.unrealizedPnlUsd)} (${h.unrealizedPnlPercent}%)", style = MaterialTheme.typography.labelSmall.copy(color = if (h.unrealizedPnlUsd >= 0) TerminalGreen else RiskCrimson, fontSize = 9.sp))
                        }
                    }
                }
            }
        }

        // Risk Engine & VaR Metrics
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "QUANTITATIVE COMMODITIES RISK ANALYTICS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RiskMetricBox("99% 1D HISTORICAL VaR", "$${String.format("%,.0f", risk.historicalVaR99Usd)}", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    RiskMetricBox("5,000 MONTE CARLO VaR", "$${String.format("%,.0f", risk.monteCarloVaR99Usd)}", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    RiskMetricBox("CONDITIONAL VaR (CVaR)", "$${String.format("%,.0f", risk.conditionalVaR99Usd)}", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RiskMetricBox("PORTFOLIO BETA TO GOLD", "${risk.portfolioBetaToGold}", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    RiskMetricBox("ANNUAL SHARPE RATIO", "${risk.annualSharpeRatio}", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    RiskMetricBox("RISK UTILIZATION", "${String.format("%.1f", risk.riskLimitUtilizationPercent)}%", Modifier.weight(1f))
                }
            }
        }

        // Interactive Stress Testing Lab
        StressTestLab(portfolioHoldings = holdings, currentRisk = risk)
    }
}

@Composable
private fun RiskMetricBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(ObsidianElevated)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.sp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp))
    }
}
