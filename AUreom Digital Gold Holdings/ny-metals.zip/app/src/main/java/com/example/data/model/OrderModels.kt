package com.example.data.model

enum class OrderType(val displayName: String, val isAlgorithmic: Boolean) {
    MARKET("Market", false),
    LIMIT("Limit", false),
    STOP("Stop Loss", false),
    STOP_LIMIT("Stop Limit", false),
    IOC("Immediate-or-Cancel (IOC)", false),
    FOK("Fill-or-Kill (FOK)", false),
    GTC("Good 'Til Cancelled (GTC)", false),
    DAY("Day Order", false),
    TWAP("TWAP (Algo)", true),
    VWAP("VWAP (Algo)", true)
}

enum class OrderSide(val displayName: String) {
    BUY("BUY"),
    SELL("SELL")
}

enum class OrderStatus(val displayName: String) {
    PENDING("Pending"),
    ACCEPTED("Accepted"),
    PARTIALLY_FILLED("Partial Fill"),
    FILLED("Filled"),
    CANCELLED("Cancelled"),
    REJECTED("Rejected")
}

enum class ExecutionVenue(val venueCode: String, val fullName: String) {
    NYM_DARK("NYM-DARK", "New York Metals Dark Bullion Pool"),
    COMEX_SYNTH("COMEX-SYNTH", "CME/COMEX Synthetic Derivatives Gateway"),
    LBMA_OTC("LBMA-OTC", "London/New York OTC Direct Bullion Desk"),
    MANHATTAN_VAULT("NY-VAULT-03", "Manhattan Vault Custody Allocation Direct")
}

data class Order(
    val orderId: String,
    val clientAccount: String,
    val metal: MetalAsset,
    val side: OrderSide,
    val orderType: OrderType,
    val quantityOz: Double,
    val limitPrice: Double? = null,
    val stopPrice: Double? = null,
    val timeInForce: String = "GTC",
    val venue: ExecutionVenue = ExecutionVenue.NYM_DARK,
    val timestamp: Long = System.currentTimeMillis(),
    val status: OrderStatus = OrderStatus.PENDING,
    val filledQuantityOz: Double = 0.0,
    val averageExecutionPrice: Double = 0.0,
    val estimatedFeeUsd: Double = 0.0,
    val estimatedSlippageUsd: Double = 0.0,
    val realizedPnlUsd: Double = 0.0,
    val algoSliceProgress: Float = 0f // For TWAP/VWAP
)

data class ExecutionTicket(
    val tradeId: String,
    val orderId: String,
    val accountId: String,
    val metal: MetalAsset,
    val side: OrderSide,
    val executedQuantityOz: Double,
    val executionPrice: Double,
    val grossConsiderationUsd: Double,
    val exchangeClearingFeeUsd: Double,
    val vaultAllocationFeeUsd: Double,
    val totalSettlementUsd: Double,
    val venue: ExecutionVenue,
    val timestamp: Long = System.currentTimeMillis(),
    val valueDate: String,
    val settlementDate: String
)
