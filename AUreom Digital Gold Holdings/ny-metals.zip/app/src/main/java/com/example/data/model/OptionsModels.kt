package com.example.data.model

enum class OptionType {
    CALL,
    PUT
}

data class OptionGreeks(
    val delta: Double,
    val gamma: Double,
    val theta: Double, // $/day
    val vega: Double,  // $/1% IV
    val rho: Double
)

data class PreciousMetalsOption(
    val optionId: String,
    val underlying: MetalAsset,
    val type: OptionType,
    val strikePrice: Double,
    val daysToExpiry: Int,
    val expiryDate: String,
    val impliedVolatilityPercent: Double,
    val theoreticalPremium: Double,
    val marketBid: Double,
    val marketAsk: Double,
    val greeks: OptionGreeks,
    val openInterest: Long,
    val volume: Long
)

data class VolatilitySurfacePoint(
    val daysToExpiry: Int,
    val moneynessPercent: Double, // 80%, 90%, 100% (ATM), 110%, 120%
    val strike: Double,
    val impliedVolatility: Double
)

data class OptionStrategyLeg(
    val option: PreciousMetalsOption,
    val quantity: Int, // positive for long, negative for short
    val entryPremium: Double
)

data class OptionStrategyAnalysis(
    val strategyName: String,
    val legs: List<OptionStrategyLeg>,
    val netDebitCreditUsd: Double,
    val maxProfitUsd: String,
    val maxLossUsd: String,
    val breakevenPoints: List<Double>,
    val netDelta: Double,
    val netGamma: Double,
    val netTheta: Double,
    val netVega: Double
)
