package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.BullionBar
import com.example.data.model.MetalAsset
import com.example.ui.theme.*

@Composable
fun BullionCertificateDialog(
    bar: BullionBar,
    onDismiss: () -> Unit,
    onToggleAllocation: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("bullion_certificate_dialog"),
            colors = CardDefaults.cardColors(containerColor = ObsidianElevated),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header Stamp
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "NEW YORK METALS DEPOSITORY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = BullionGoldPrimary,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "OFFICIAL DIGITAL CUSTODY CERTIFICATE",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Divider(color = BullionGoldDark.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))

                // Bar ID & Serial Hero
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ObsidianCard)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = bar.barId,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        Text(
                            text = "SERIAL NO: ${bar.serialNumber} • ASSAY: ${bar.assayCertificateNumber}",
                            style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontSize = 10.sp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Assay & Physical Specs Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CertSpecItem("METAL", bar.metal.displayName, Modifier.weight(1f))
                    CertSpecItem("PURITY", "${bar.purity} Fine", Modifier.weight(1f))
                    CertSpecItem("REFINER", bar.refinerName, Modifier.weight(1.5f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CertSpecItem("GROSS WT", "${bar.grossWeightKg} kg", Modifier.weight(1f))
                    CertSpecItem("FINE WT (KG)", "${bar.fineWeightKg} kg", Modifier.weight(1f))
                    CertSpecItem("FINE WT (OZ)", "${String.format("%,.2f", bar.fineWeightOz)} oz t", Modifier.weight(1.2f))
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Vault Location & Custody
                Text(
                    text = "VAULT CUSTODY & REGISTRY",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ObsidianCard)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("FACILITY", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text(bar.vaultFacility, style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("COORDINATES", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("${bar.roomCode} • ${bar.shelfCode} (${bar.palletId})", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("OWNER TITLE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text(bar.ownerId, style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("STATUS", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text(bar.status.displayName, style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Button (Allocate / Deallocate)
                Button(
                    onClick = onToggleAllocation,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (bar.isAllocated) RiskCrimson else BullionGoldPrimary,
                        contentColor = TextDark
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(
                        imageVector = if (bar.isAllocated) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = if (bar.isAllocated) TextWhite else TextDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (bar.isAllocated) "DEALLOCATE TO VAULT POOL" else "ALLOCATE TO CLIENT-0194 TITLE",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (bar.isAllocated) TextWhite else TextDark
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun CertSpecItem(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(ObsidianCard)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.sp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            value,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            ),
            maxLines = 1
        )
    }
}
