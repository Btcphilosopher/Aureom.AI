package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.components.DoubleEntryLedgerView
import com.example.ui.theme.ObsidianBg

@Composable
fun LedgerSettlementScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val clientBalance by repository.clientBalance.collectAsState()
    val journalTransactions by repository.journalTransactions.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("ledger_settlement_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DoubleEntryLedgerView(
            clientBalance = clientBalance,
            transactions = journalTransactions
        )
    }
}
