package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CandleStick
import com.example.data.model.MetalAsset
import com.example.ui.theme.*
import kotlin.math.max
import kotlin.math.min

@Composable
fun InteractiveMarketChart(
    candles: List<CandleStick>,
    asset: MetalAsset,
    modifier: Modifier = Modifier
) {
    var selectedTimeframe by remember { mutableStateOf("1D") }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val timeframes = listOf("1M", "5M", "1H", "1D", "1W", "1Y")

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_market_chart"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header with Timeframe Selectors and Selected Candle Stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${asset.displayName.uppercase()} / USD — CME NYM FEED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    val activeCandle = selectedIndex?.let { candles.getOrNull(it) } ?: candles.lastOrNull()
                    if (activeCandle != null) {
                        Row(modifier = Modifier.padding(top = 2.dp)) {
                            Text(
                                text = "O: $${String.format("%.2f", activeCandle.open)}  ",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                            )
                            Text(
                                text = "H: $${String.format("%.2f", activeCandle.high)}  ",
                                style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen)
                            )
                            Text(
                                text = "L: $${String.format("%.2f", activeCandle.low)}  ",
                                style = MaterialTheme.typography.labelSmall.copy(color = RiskCrimson)
                            )
                            Text(
                                text = "C: $${String.format("%.2f", activeCandle.close)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (activeCandle.close >= activeCandle.open) TerminalGreen else RiskCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    timeframes.forEach { tf ->
                        val isSelected = tf == selectedTimeframe
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSelected) BullionGoldPrimary else ObsidianElevated)
                                .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                .pointerInput(Unit) {
                                    detectTapGestures { selectedTimeframe = tf }
                                }
                        ) {
                            Text(
                                text = tf,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) TextDark else TextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Canvas Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(candles) {
                            detectTapGestures(
                                onPress = { offset ->
                                    val candleWidth = size.width / max(candles.size, 1)
                                    val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                                    selectedIndex = index
                                }
                            )
                        }
                ) {
                    if (candles.isEmpty()) return@Canvas

                    val minPrice = candles.minOf { it.low } * 0.999
                    val maxPrice = candles.maxOf { it.high } * 1.001
                    val priceRange = max(maxPrice - minPrice, 0.01)

                    val maxVolume = candles.maxOf { it.volume }
                    val chartHeight = size.height * 0.75f
                    val volumeAreaHeight = size.height * 0.22f
                    val volumeAreaTop = size.height * 0.78f

                    val candleWidth = size.width / candles.size
                    val barWidth = candleWidth * 0.65f

                    // Draw Horizontal Grid Lines
                    val gridSteps = 4
                    for (i in 0..gridSteps) {
                        val y = chartHeight * (i.toFloat() / gridSteps)
                        drawLine(
                            color = ObsidianBorder.copy(alpha = 0.6f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1f
                        )
                    }

                    // Draw Candlesticks & Volume Bars
                    candles.forEachIndexed { index, candle ->
                        val xCenter = (index * candleWidth) + (candleWidth / 2f)
                        val isBullish = candle.close >= candle.open
                        val candleColor = if (isBullish) TerminalGreen else RiskCrimson

                        // Y calculations
                        val highY = chartHeight * (1f - ((candle.high - minPrice) / priceRange).toFloat())
                        val lowY = chartHeight * (1f - ((candle.low - minPrice) / priceRange).toFloat())
                        val openY = chartHeight * (1f - ((candle.open - minPrice) / priceRange).toFloat())
                        val closeY = chartHeight * (1f - ((candle.close - minPrice) / priceRange).toFloat())

                        // Wick
                        drawLine(
                            color = candleColor,
                            start = Offset(xCenter, highY),
                            end = Offset(xCenter, lowY),
                            strokeWidth = 1.5f
                        )

                        // Body
                        val bodyTop = min(openY, closeY)
                        val bodyBottom = max(openY, closeY)
                        val bodyHeight = max(bodyBottom - bodyTop, 2f)

                        drawRect(
                            color = candleColor,
                            topLeft = Offset(xCenter - (barWidth / 2f), bodyTop),
                            size = Size(barWidth, bodyHeight)
                        )

                        // Volume Bar
                        val volHeight = volumeAreaHeight * (candle.volume / max(maxVolume, 1.0)).toFloat()
                        val volTop = size.height - volHeight
                        drawRect(
                            color = candleColor.copy(alpha = 0.35f),
                            topLeft = Offset(xCenter - (barWidth / 2f), volTop),
                            size = Size(barWidth, volHeight)
                        )
                    }

                    // Draw Moving Average Line (20-Period)
                    if (candles.size >= 5) {
                        val maPath = Path()
                        var pathStarted = false
                        for (i in 4 until candles.size) {
                            val slice = candles.subList(max(0, i - 10), i + 1)
                            val maValue = slice.map { it.close }.average()
                            val x = (i * candleWidth) + (candleWidth / 2f)
                            val y = chartHeight * (1f - ((maValue - minPrice) / priceRange).toFloat())
                            if (!pathStarted) {
                                maPath.moveTo(x, y)
                                pathStarted = true
                            } else {
                                maPath.lineTo(x, y)
                            }
                        }
                        drawPath(
                            path = maPath,
                            color = BullionGoldBright,
                            style = Stroke(width = 2f, cap = StrokeCap.Round)
                        )
                    }

                    // Highlight selected candle crosshair
                    selectedIndex?.let { idx ->
                        if (idx in candles.indices) {
                            val xCross = (idx * candleWidth) + (candleWidth / 2f)
                            drawLine(
                                color = TextWhite.copy(alpha = 0.7f),
                                start = Offset(xCross, 0f),
                                end = Offset(xCross, size.height),
                                strokeWidth = 1f
                            )
                        }
                    }
                }
            }
        }
    }
}
