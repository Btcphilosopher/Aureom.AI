package com.example.data.model

data class ScrapIntakeLot(
    val lotId: String,
    val sourceSupplier: String,
    val materialType: String, // "High-Grade Electronics Scrap", "Jewellery Scrap 14k/18k", "Industrial Contact Points", "Mining Doré"
    val grossWeightKg: Double,
    val initialAssayEstimatedGoldPct: Double,
    val initialAssayEstimatedSilverPct: Double,
    val intakeDate: String,
    val status: String // "INTAKE", "SAMPLING", "PYROMETALLURGIC_SMELTING", "ELECTROLYTIC_PARTING", "CASTING_COMPLETED"
)

data class RefineryBatch(
    val batchId: String,
    val facilityName: String, // "Empire Refining Co - Long Island City Complex"
    val stage: String,
    val inputMassKg: Double,
    val processLossKg: Double,
    val recoveryYieldPercent: Double,
    val outputFineGoldKg: Double,
    val outputFineSilverKg: Double,
    val energyKwhConsumed: Double,
    val chemicalReagentCostUsd: Double,
    val outputPurity: Double, // 999.9
    val newlyCastBarIds: List<String>
)

data class CentralBankGoldFlow(
    val institutionName: String,
    val country: String,
    val netMonthlyPurchaseTonnes: Double,
    val totalReservesTonnes: Double,
    val percentOfTotalFxReserves: Double,
    val trend3Year: String
)

data class CftcCotPositioning(
    val metalName: String,
    val reportDate: String,
    val openInterestContracts: Long,
    val commercialLongs: Long,
    val commercialShorts: Long,
    val commercialNetPosition: Long,
    val nonCommercialLongs: Long, // Speculators / CTAs
    val nonCommercialShorts: Long,
    val nonCommercialNetPosition: Long,
    val weeklyNetChangeContracts: Long,
    val speculativeSentiment: String // "BULLISH EXTREME", "NEUTRAL REBALANCING", "BEARISH OVEREXTENDED"
)

data class MetalsResearchReport(
    val reportId: String,
    val title: String,
    val authorDesk: String,
    val publishDate: String,
    val liquidityRating: String, // "HIGH", "TIGHTENING"
    val volatilityRegime: String,
    val futuresPositioningSignal: String,
    val curveStructure: String, // "BACKWARDATION", "CONTANGO"
    val macroSummary: String,
    val keyTakeaways: List<String>
)
