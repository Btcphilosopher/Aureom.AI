package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.theme.*

@Composable
fun RefineryRecyclingScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val scrapLots by repository.scrapLots.collectAsState()
    val refineryBatches by repository.refineryBatches.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("refinery_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "EMPIRE REFINING CO. DIGITAL TWIN",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Long Island City Facility • Industrial Scrap & Doré • 999.9 Fine Casting",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalGreenBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("SMELTER ACTIVE", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold, fontSize = 8.5.sp))
                }
            }
        }

        // Active Smelting & Refining Batches
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE REFINERY BATCHES & CASTING",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                refineryBatches.forEach { b ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(b.batchId, style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text(b.stage, style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(b.facilityName, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Input: ${b.inputMassKg} kg", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite))
                            Text("Recovery: ${b.recoveryYieldPercent}%", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                            Text("Output Fine Gold: ${b.outputFineGoldKg} kg", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold))
                        }

                        Text("New Cast Good Delivery Bars: ${b.newlyCastBarIds.joinToString(", ")}", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                    }
                }
            }
        }

        // Scrap Intake & Recycling Stream
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "PRECIOUS METALS SCRAP INTAKE & RECYCLING",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                scrapLots.forEach { lot ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${lot.lotId} • ${lot.sourceSupplier}", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text(lot.status, style = MaterialTheme.typography.labelSmall.copy(color = AlertAmber, fontWeight = FontWeight.Bold, fontSize = 8.5.sp))
                        }
                        Text("${lot.materialType} • ${lot.grossWeightKg} kg • Assay Est: ${lot.initialAssayEstimatedGoldPct}% Au / ${lot.initialAssayEstimatedSilverPct}% Ag", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                    }
                }
            }
        }
    }
}
