package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderBook
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun OrderBookVisualizer(
    orderBook: OrderBook,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("order_book_visualizer"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LEVEL 2 MARKET DEPTH (COMEX/OTC)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "SPREAD: $${String.format("%.2f", orderBook.spread)}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Imbalance Gauge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(ObsidianElevated)
            ) {
                val totalDepth = max(orderBook.totalBidDepth + orderBook.totalAskDepth, 1.0)
                val bidRatio = (orderBook.totalBidDepth / totalDepth).toFloat()
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(bidRatio.coerceAtLeast(0.05f))
                        .background(TerminalGreen)
                )
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight((1f - bidRatio).coerceAtLeast(0.05f))
                        .background(RiskCrimson)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "BID DEPTH: ${String.format("%,.1f", orderBook.totalBidDepth)} oz",
                    style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontSize = 9.sp)
                )
                Text(
                    text = "ASK DEPTH: ${String.format("%,.1f", orderBook.totalAskDepth)} oz",
                    style = MaterialTheme.typography.labelSmall.copy(color = RiskCrimson, fontSize = 9.sp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Column Titles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("ORDERS", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1f))
                Text("SIZE (OZ)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.5f))
                Text("PRICE ($)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.8f))
                Text("TOTAL (OZ)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp), modifier = Modifier.weight(1.5f))
            }

            Divider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))

            // ASKS (Top 4, reversed so lowest ask is closest to spread)
            val topAsks = orderBook.asks.take(4).reversed()
            val maxAskTotal = orderBook.asks.maxOfOrNull { it.totalOz } ?: 1.0

            topAsks.forEach { level ->
                val depthRatio = (level.totalOz / maxAskTotal).toFloat().coerceIn(0.05f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                ) {
                    // Visual background depth bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(depthRatio)
                            .height(18.dp)
                            .align(Alignment.CenterEnd)
                            .background(RiskCrimsonBg)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${level.orderCount}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1f))
                        Text(String.format("%,.1f", level.quantityOz), style = MaterialTheme.typography.labelSmall.copy(color = TextWhite), modifier = Modifier.weight(1.5f))
                        Text(String.format("%.2f", level.price), style = MaterialTheme.typography.labelSmall.copy(color = RiskCrimson, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1.8f))
                        Text(String.format("%,.1f", level.totalOz), style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1.5f))
                    }
                }
            }

            // Central Spread Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(ObsidianElevated)
                    .padding(vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "— CME NYM SPREAD $${String.format("%.2f", orderBook.spread)} (${String.format("%.1f", (orderBook.spread / max(orderBook.bestBid, 1.0)) * 10000)} bps) —",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldBright,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }

            // BIDS (Top 4)
            val topBids = orderBook.bids.take(4)
            val maxBidTotal = orderBook.bids.maxOfOrNull { it.totalOz } ?: 1.0

            topBids.forEach { level ->
                val depthRatio = (level.totalOz / maxBidTotal).toFloat().coerceIn(0.05f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(depthRatio)
                            .height(18.dp)
                            .align(Alignment.CenterStart)
                            .background(TerminalGreenBg)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${level.orderCount}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1f))
                        Text(String.format("%,.1f", level.quantityOz), style = MaterialTheme.typography.labelSmall.copy(color = TextWhite), modifier = Modifier.weight(1.5f))
                        Text(String.format("%.2f", level.price), style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1.8f))
                        Text(String.format("%,.1f", level.totalOz), style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1.5f))
                    }
                }
            }
        }
    }
}
