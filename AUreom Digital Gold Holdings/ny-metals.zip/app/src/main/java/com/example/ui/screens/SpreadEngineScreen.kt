package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.MetalAsset
import com.example.ui.theme.*

@Composable
fun SpreadEngineScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val spotPrices by repository.spotPrices.collectAsState()
    val goldSpot = spotPrices[MetalAsset.GOLD]?.last ?: 4188.30
    val silverSpot = spotPrices[MetalAsset.SILVER]?.last ?: 52.84
    val ratio = goldSpot / silverSpot

    var spreadTradeSimulated by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("spread_engine_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Ratio Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "GOLD / SILVER RELATIVE-VALUE ENGINE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = BullionGoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Historical Ratio • Statistical Arbitrage • Mean-Reversion Signals",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalGreenBg)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "REVERSION WATCH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TerminalGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text("CURRENT SPREAD RATIO", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        Text(
                            text = String.format("%.2f", ratio),
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = BullionGoldBright,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Z-SCORE: +1.82 (84th Percentile)", style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        Text("50D MA: 82.10 • 200D MA: 85.40", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp))
                    }
                }
            }
        }

        // Relative Value Statistical Arbitrage Simulator
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "MEAN-REVERSION SPREAD SIMULATOR",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Hypothesis: Ratio compresses from ${String.format("%.1f", ratio)} to historical mean 65.0",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("LEG 1 (LONG SILVER)", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontSize = 8.5.sp, fontWeight = FontWeight.Bold))
                        Text("+50,000 oz XAG", style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        Text("Target: $64.40/oz", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("LEG 2 (SHORT GOLD)", style = MaterialTheme.typography.labelSmall.copy(color = RiskCrimson, fontSize = 8.5.sp, fontWeight = FontWeight.Bold))
                        Text("-630 oz XAU", style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        Text("Delta Neutral Cash", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { spreadTradeSimulated = true },
                    modifier = Modifier.fillMaxWidth().height(40.dp).testTag("simulate_spread_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BullionGoldPrimary, contentColor = TextDark),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("EXECUTE SPREAD ARBITRAGE SIMULATION", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                }

                if (spreadTradeSimulated) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalGreenBg)
                            .border(1.dp, TerminalGreen, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("SIMULATION ACTIVE: Projected Spread P&L +$580,200 USD upon 65.0 mean reversion.", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                            Text("Neutralized against systemic dollar moves and gold beta.", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontSize = 8.5.sp))
                        }
                    }
                }
            }
        }
    }
}
