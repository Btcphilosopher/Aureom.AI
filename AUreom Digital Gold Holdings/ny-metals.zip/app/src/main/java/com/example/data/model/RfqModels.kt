package com.example.data.model

enum class ClientTier(val displayName: String, val baseSpreadDiscountBps: Double) {
    TIER_1_SOVEREIGN("Tier 1 - Sovereign / Central Bank", 1.2),
    TIER_2_INSTITUTIONAL("Tier 2 - Hedge Fund / Bank", 2.0),
    TIER_3_COMMODITY_CORP("Tier 3 - Corporate Hedger / Industrial", 3.5),
    TIER_4_PRIVATE_OFFICE("Tier 4 - Family Office / Private Wealth", 5.0)
}

enum class RfqStatus {
    REQUESTED,
    QUOTED,
    ACCEPTED,
    EXPIRED,
    REJECTED
}

data class RfqRequest(
    val rfqId: String,
    val clientName: String,
    val clientTier: ClientTier,
    val metal: MetalAsset,
    val side: OrderSide,
    val quantityOz: Double,
    val purityRequired: String = "99.99% Fine",
    val settlementTerms: String = "T+2 Physical Allocated",
    val deliveryLocation: String = "Manhattan Vault 03",
    val requestTimestamp: Long = System.currentTimeMillis()
)

data class RfqQuote(
    val rfqId: String,
    val referenceSpotPrice: Double,
    val dealerSpreadUsd: Double,
    val clientTierAdjustmentUsd: Double,
    val liquidityAdjustmentUsd: Double,
    val volatilityAdjustmentUsd: Double,
    val physicalPremiumUsd: Double,
    val finalPricePerOz: Double,
    val totalGrossUsd: Double,
    val bidQuotePerOz: Double,
    val offerQuotePerOz: Double,
    val expiresAtTimestamp: Long,
    val secondsRemaining: Int,
    val hedgeFuturesContract: String = "GCZ6",
    val hedgeActionNeeded: String = "SELL 5 COMEX GC Contracts",
    val status: RfqStatus = RfqStatus.QUOTED
)
