package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.MetalAsset
import com.example.ui.components.DemonstrationRunner
import com.example.ui.theme.*

@Composable
fun ExecutiveCommandScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val spotPrices by repository.spotPrices.collectAsState()
    val vaultInfo by repository.vaultFacility.collectAsState()
    val riskMetrics by repository.riskMetrics.collectAsState()
    val demoStep by repository.demoStep.collectAsState()
    val isDemoRunning by repository.isDemoRunning.collectAsState()
    val demoLogs by repository.demoLogs.collectAsState()

    val goldSpot = spotPrices[MetalAsset.GOLD]?.last ?: 4188.30
    val silverSpot = spotPrices[MetalAsset.SILVER]?.last ?: 52.84
    val ratio = goldSpot / silverSpot

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("executive_command_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Wall Street Institutional Trading Desk Hero
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_institution_desk),
                    contentDescription = "Wall Street Trading Command Desk",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.95f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "NEW YORK METALS COMMAND CENTRE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Lower Manhattan Executive Clearing & Risk Surveillance Operations",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontSize = 9.sp)
                    )
                }
            }
        }

        // Executive KPI Matrix
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "GLOBAL INSTITUTIONAL MATRIX",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CommandKpiBox("SPOT GOLD", "$${String.format("%,.2f", goldSpot)}", "+1.24%", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("SPOT SILVER", "$${String.format("%,.2f", silverSpot)}", "+2.17%", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("G/S RATIO", String.format("%.2f", ratio), "84th Pct", true, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CommandKpiBox("PHYSICAL GOLD", "${String.format("%,.0f", vaultInfo.totalGoldKg)} kg", "31.4k Alloc", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("PHYSICAL SILVER", "${String.format("%,.0f", vaultInfo.totalSilverKg)} kg", "985k Alloc", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("VAULT UTIL", "${String.format("%.1f", vaultInfo.capacityUtilizationPercent)}%", "Class 3", true, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CommandKpiBox("OPEN ORDERS", "1,284", "Active OMS", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("RISK UTIL", "${String.format("%.0f", riskMetrics.riskLimitUtilizationPercent)}%", "Normal Limit", true, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    CommandKpiBox("SETTLEMENT", "98.7%", "T+2 Clearing", true, Modifier.weight(1f))
                }
            }
        }

        // 16-Step Demonstration Lifecycle Component
        DemonstrationRunner(
            currentStep = demoStep,
            isRunning = isDemoRunning,
            logs = demoLogs,
            onStartDemo = {
                repository.runFullDemonstrationLifecycle { _, _ -> }
            }
        )
    }
}

@Composable
private fun CommandKpiBox(
    title: String,
    value: String,
    subtext: String,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(ObsidianElevated)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.sp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            value,
            style = MaterialTheme.typography.labelMedium.copy(
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        )
        Text(
            subtext,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isPositive) TerminalGreen else RiskCrimson,
                fontSize = 8.sp,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}
