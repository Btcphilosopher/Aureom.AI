package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun OptionsLabScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val optionsChain by repository.optionsChain.collectAsState()
    var selectedOptionType by remember { mutableStateOf(OptionType.CALL) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("options_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PRECIOUS METALS OPTIONS LABORATORY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Black-Scholes-Merton Commodity Pricing • Greeks Risk Surface • 45 DTE",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selectedOptionType == OptionType.CALL) TerminalGreen else ObsidianElevated)
                            .border(1.dp, if (selectedOptionType == OptionType.CALL) TerminalGreen else ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CALLS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (selectedOptionType == OptionType.CALL) TextDark else TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Options Chain Table
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "GOLD 45-DAY CONTRACT CHAIN & GREEKS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Table Header
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("STRIKE", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp), modifier = Modifier.weight(1.2f))
                    Text("THEO ($)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp), modifier = Modifier.weight(1.2f))
                    Text("DELTA (Δ)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp), modifier = Modifier.weight(1.2f))
                    Text("GAMMA (Γ)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp), modifier = Modifier.weight(1.2f))
                    Text("VEGA (ν)", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp), modifier = Modifier.weight(1.2f))
                }
                Divider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))

                val filtered = optionsChain.filter { it.type == selectedOptionType }
                filtered.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("$${opt.strikePrice.toInt()}", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1.2f))
                        Text(String.format("%.2f", opt.theoreticalPremium), style = MaterialTheme.typography.labelSmall.copy(color = TextWhite), modifier = Modifier.weight(1.2f))
                        Text(String.format("%.3f", opt.greeks.delta), style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen), modifier = Modifier.weight(1.2f))
                        Text(String.format("%.4f", opt.greeks.gamma), style = MaterialTheme.typography.labelSmall.copy(color = TextMuted), modifier = Modifier.weight(1.2f))
                        Text(String.format("%.2f", opt.greeks.vega), style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle), modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }
    }
}
