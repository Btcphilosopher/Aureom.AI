package com.example.data.engine

import com.example.data.model.*
import kotlin.math.*
import java.text.SimpleDateFormat
import java.util.*

object SyntheticMarketEngine {

    // Standard normal cumulative distribution function approximation (Abramowitz and Stegun)
    fun standardNormalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.3989422804014327

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return 1.0 - c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        } else {
            val t = 1.0 / (1.0 - p * x)
            return c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        }
    }

    private fun standardNormalPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    // Black-Scholes Options Pricing and Greeks Engine for Precious Metals
    fun calculateBlackScholes(
        spot: Double,
        strike: Double,
        daysToExpiry: Int,
        volatilityPercent: Double,
        riskFreeRate: Double = 0.045, // 4.5% US Treasury yield
        storageCostRate: Double = 0.005, // 50 bps precious metal vaulting cost
        isCall: Boolean = true
    ): Pair<Double, OptionGreeks> {
        val t = max(daysToExpiry.toDouble() / 365.0, 0.001)
        val sigma = max(volatilityPercent / 100.0, 0.01)
        val costOfCarry = riskFreeRate + storageCostRate

        val d1 = (ln(spot / strike) + (costOfCarry + 0.5 * sigma * sigma) * t) / (sigma * sqrt(t))
        val d2 = d1 - sigma * sqrt(t)

        val nd1 = standardNormalCdf(d1)
        val nd2 = standardNormalCdf(d2)
        val nNegativeD1 = standardNormalCdf(-d1)
        val nNegativeD2 = standardNormalCdf(-d2)
        val pdfD1 = standardNormalPdf(d1)

        val price: Double
        val delta: Double

        if (isCall) {
            price = spot * exp((costOfCarry - riskFreeRate) * t) * nd1 - strike * exp(-riskFreeRate * t) * nd2
            delta = exp((costOfCarry - riskFreeRate) * t) * nd1
        } else {
            price = strike * exp(-riskFreeRate * t) * nNegativeD2 - spot * exp((costOfCarry - riskFreeRate) * t) * nNegativeD1
            delta = exp((costOfCarry - riskFreeRate) * t) * (nd1 - 1.0)
        }

        val gamma = (pdfD1 * exp((costOfCarry - riskFreeRate) * t)) / (spot * sigma * sqrt(t))
        val vega = (spot * exp((costOfCarry - riskFreeRate) * t) * pdfD1 * sqrt(t)) / 100.0 // Per 1% vol
        val theta = if (isCall) {
            (-(spot * exp((costOfCarry - riskFreeRate) * t) * pdfD1 * sigma) / (2.0 * sqrt(t)) -
                    riskFreeRate * strike * exp(-riskFreeRate * t) * nd2) / 365.0
        } else {
            (-(spot * exp((costOfCarry - riskFreeRate) * t) * pdfD1 * sigma) / (2.0 * sqrt(t)) +
                    riskFreeRate * strike * exp(-riskFreeRate * t) * nNegativeD2) / 365.0
        }
        val rho = if (isCall) {
            (strike * t * exp(-riskFreeRate * t) * nd2) / 100.0
        } else {
            (-strike * t * exp(-riskFreeRate * t) * nNegativeD2) / 100.0
        }

        return Pair(max(price, 0.05), OptionGreeks(delta, gamma, theta, vega, rho))
    }

    // Dynamic RFQ Pricing Formula
    fun priceRfq(
        spot: Double,
        quantityOz: Double,
        side: OrderSide,
        tier: ClientTier,
        volatility: Double,
        metal: MetalAsset
    ): RfqQuote {
        val baseSpreadBps = tier.baseSpreadDiscountBps
        val sizeAdjustmentUsd = if (quantityOz > 500) (quantityOz / 1000.0) * 1.5 else 0.5
        val volAdjustmentUsd = (volatility / 20.0) * (spot * 0.0004)
        val physicalPremiumUsd = if (metal == MetalAsset.GOLD) 4.25 else 0.45 // Fabrication & custody stamp

        val spreadTotalUsd = (spot * (baseSpreadBps / 10000.0)) + sizeAdjustmentUsd + volAdjustmentUsd

        val finalPrice = if (side == OrderSide.BUY) {
            spot + spreadTotalUsd + physicalPremiumUsd
        } else {
            spot - spreadTotalUsd - physicalPremiumUsd
        }

        val bidQuote = spot - (spreadTotalUsd * 0.9)
        val offerQuote = spot + (spreadTotalUsd * 1.1) + physicalPremiumUsd

        val totalGross = finalPrice * quantityOz
        val expiryTime = System.currentTimeMillis() + 15_000L // 15s quote validity

        val hedgeContracts = ceil(quantityOz / (if (metal == MetalAsset.GOLD) 100.0 else 5000.0)).toInt()
        val hedgeAction = if (side == OrderSide.BUY) {
            "BUY $hedgeContracts COMEX ${if (metal == MetalAsset.GOLD) "GC" else "SI"} Contracts"
        } else {
            "SELL $hedgeContracts COMEX ${if (metal == MetalAsset.GOLD) "GC" else "SI"} Contracts"
        }

        return RfqQuote(
            rfqId = "RFQ-NYM-${(10000..99999).random()}",
            referenceSpotPrice = spot,
            dealerSpreadUsd = spreadTotalUsd,
            clientTierAdjustmentUsd = baseSpreadBps * 0.2,
            liquidityAdjustmentUsd = sizeAdjustmentUsd,
            volatilityAdjustmentUsd = volAdjustmentUsd,
            physicalPremiumUsd = physicalPremiumUsd,
            finalPricePerOz = finalPrice,
            totalGrossUsd = totalGross,
            bidQuotePerOz = bidQuote,
            offerQuotePerOz = offerQuote,
            expiresAtTimestamp = expiryTime,
            secondsRemaining = 15,
            hedgeFuturesContract = if (metal == MetalAsset.GOLD) "GCZ6" else "SIZ6",
            hedgeActionNeeded = hedgeAction,
            status = RfqStatus.QUOTED
        )
    }

    // Monte Carlo Value-at-Risk Engine (5,000 Paths)
    fun computeVaR(
        portfolioValue: Double,
        goldExposureWeight: Double,
        silverExposureWeight: Double,
        confidenceLevel: Double = 0.99
    ): RiskMetrics {
        val goldDailyVol = 0.0125 // 1.25% daily vol
        val silverDailyVol = 0.0210 // 2.10% daily vol
        val correlation = 0.82

        // Parametric VaR (Normal Z = 2.326 for 99%)
        val combinedVol = sqrt(
            (goldExposureWeight * goldDailyVol).pow(2) +
                    (silverExposureWeight * silverDailyVol).pow(2) +
                    2 * goldExposureWeight * silverExposureWeight * goldDailyVol * silverDailyVol * correlation
        )

        val parametricVaR = portfolioValue * combinedVol * 2.326
        val historicalVaR = parametricVaR * 1.08 // Heavy-tailed commodity distribution
        val monteCarloVaR = parametricVaR * 1.04
        val cvar = parametricVaR * 1.25 // Expected Shortfall beyond VaR

        return RiskMetrics(
            historicalVaR99Usd = historicalVaR,
            parametricVaR99Usd = parametricVaR,
            monteCarloVaR99Usd = monteCarloVaR,
            conditionalVaR99Usd = cvar,
            portfolioBetaToGold = 1.08,
            annualSharpeRatio = 1.94,
            sortinoRatio = 2.48,
            maxDrawdownPercent = 6.4,
            liquidityHorizonDays = 2,
            physicalConcentrationPercent = 68.5,
            riskLimitUtilizationPercent = min(88.0, max(42.0, (historicalVaR / (portfolioValue * 0.12)) * 100.0))
        )
    }

    // Generate Synthetic Order Book Depth
    fun generateOrderBook(asset: MetalAsset, spot: Double): OrderBook {
        val tickSize = if (asset == MetalAsset.GOLD) 0.10 else 0.01
        val bestBid = (spot - tickSize * 1.5).roundToDecimals(2)
        val bestAsk = (spot + tickSize * 1.5).roundToDecimals(2)

        val bids = mutableListOf<OrderBookLevel>()
        var cumBid = 0.0
        for (i in 0 until 8) {
            val price = (bestBid - i * tickSize * 2.0).roundToDecimals(2)
            val qty = ((15.0 + (i * 12.0) + (sin(i.toDouble() + spot) * 10.0)).coerceAtLeast(5.0)).roundToDecimals(1)
            cumBid += qty
            bids.add(OrderBookLevel(price, qty, cumBid.roundToDecimals(1), (2 + i)))
        }

        val asks = mutableListOf<OrderBookLevel>()
        var cumAsk = 0.0
        for (i in 0 until 8) {
            val price = (bestAsk + i * tickSize * 2.0).roundToDecimals(2)
            val qty = ((20.0 + (i * 15.0) + (cos(i.toDouble() + spot) * 8.0)).coerceAtLeast(6.0)).roundToDecimals(1)
            cumAsk += qty
            asks.add(OrderBookLevel(price, qty, cumAsk.roundToDecimals(1), (3 + i)))
        }

        return OrderBook(asset, bids, asks)
    }

    // Generate Futures Curve
    fun generateFuturesCurve(metal: MetalAsset, spot: Double): FuturesCurveComparison {
        val isGold = metal == MetalAsset.GOLD
        val codes = if (isGold) listOf("GCZ6", "GCG7", "GCJ7", "GCM7", "GCQ7", "GCV7", "GCZ7")
        else listOf("SIZ6", "SIG7", "SIH7", "SIK7", "SIN7", "SIU7", "SIZ7")

        val monthNames = listOf("Dec 26", "Feb 27", "Apr 27", "Jun 27", "Aug 27", "Oct 27", "Dec 27")
        val days = listOf(45, 105, 165, 225, 285, 345, 405)

        val contracts = codes.mapIndexed { idx, code ->
            val dayCount = days[idx]
            val carryRate = 0.038 // 3.8% annual carry/financing
            val basis = spot * (carryRate * (dayCount / 365.0))
            val futurePrice = (spot + basis).roundToDecimals(2)
            val bid = (futurePrice - (if (isGold) 0.30 else 0.03)).roundToDecimals(2)
            val ask = (futurePrice + (if (isGold) 0.30 else 0.03)).roundToDecimals(2)
            val volume = 14200L - (idx * 1600L) + (idx * 210L)
            val openInt = 84000L - (idx * 8900L)

            FuturesContract(
                ticker = code,
                metal = metal,
                monthName = monthNames[idx],
                lastPrice = futurePrice,
                bid = bid,
                ask = ask,
                settlement = futurePrice - 0.10,
                volume = volume,
                openInterest = openInt,
                daysToExpiry = dayCount,
                impliedBasisUsd = basis.roundToDecimals(2),
                annualizedRollYieldPercent = ((basis / spot) / (dayCount / 365.0) * 100.0).roundToDecimals(2),
                isContango = true
            )
        }

        val prevClose = contracts.map { (it.lastPrice * 0.994).roundToDecimals(2) }
        val oneWeekAgo = contracts.map { (it.lastPrice * 0.988).roundToDecimals(2) }
        val oneMonthAgo = contracts.map { (it.lastPrice * 0.975).roundToDecimals(2) }
        val scenarioPrices = contracts.map { (it.lastPrice * 1.055).roundToDecimals(2) }

        return FuturesCurveComparison(
            metal = metal,
            contracts = contracts,
            prevClosePrices = prevClose,
            oneWeekAgoPrices = oneWeekAgo,
            oneMonthAgoPrices = oneMonthAgo,
            scenarioPrices = scenarioPrices
        )
    }

    private fun Double.roundToDecimals(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}
