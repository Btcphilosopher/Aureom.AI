package com.example.data.model

data class PortfolioHolding(
    val id: String,
    val category: String, // "Physical Allocated", "Spot Exposure", "COMEX Futures", "Exchange Options", "Cash Treasury"
    val assetName: String,
    val quantity: Double,
    val unit: String,
    val averageEntryPrice: Double,
    val currentMarketPrice: Double,
    val marketValueUsd: Double,
    val unrealizedPnlUsd: Double,
    val unrealizedPnlPercent: Double,
    val weightPercent: Double
)

data class RiskMetrics(
    val historicalVaR99Usd: Double,
    val parametricVaR99Usd: Double,
    val monteCarloVaR99Usd: Double,
    val conditionalVaR99Usd: Double, // CVaR / Expected Shortfall
    val portfolioBetaToGold: Double,
    val annualSharpeRatio: Double,
    val sortinoRatio: Double,
    val maxDrawdownPercent: Double,
    val liquidityHorizonDays: Int,
    val physicalConcentrationPercent: Double,
    val riskLimitUtilizationPercent: Double // e.g. 61%
)

data class StressScenarioResult(
    val scenarioName: String,
    val description: String,
    val goldShockPercent: Double,
    val silverShockPercent: Double,
    val usdShockPercent: Double,
    val volShockPercent: Double,
    val estimatedPortfolioLossUsd: Double,
    val estimatedLossPercent: Double,
    val marginDeficitRisk: String, // "LOW", "MODERATE", "CRITICAL MARGIN CALL"
    val suggestedHedgingAction: String
)

data class PnlAttribution(
    val openingPortfolioValueUsd: Double,
    val marketMovementPnlUsd: Double,
    val activeTradingRevenueUsd: Double,
    val dealerSpreadCaptureUsd: Double,
    val futuresHedgingPnlUsd: Double,
    val storageAndInsuranceFeeUsd: Double,
    val financingCostUsd: Double,
    val netDailyPnlUsd: Double,
    val totalRealizedPnlYtdUsd: Double,
    val totalUnrealizedPnlUsd: Double,
    val closingPortfolioValueUsd: Double
)
