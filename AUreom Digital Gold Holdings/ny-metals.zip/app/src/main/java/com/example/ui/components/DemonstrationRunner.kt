package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun DemonstrationRunner(
    currentStep: Int,
    isRunning: Boolean,
    logs: List<String>,
    onStartDemo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("demonstration_lifecycle_runner"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "16-STEP INSTITUTIONAL LIFECYCLE REPLAY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Market → Quote → Trade → Hedge → Allocate → Settle → Risk",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                    )
                }

                Button(
                    onClick = onStartDemo,
                    enabled = !isRunning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRunning) ObsidianElevated else BullionGoldPrimary,
                        contentColor = TextDark
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(34.dp).testTag("start_demo_btn")
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.HourglassEmpty else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (isRunning) TextMuted else TextDark
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isRunning) "STEP $currentStep / 16..." else "RUN REPLAY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isRunning) TextMuted else TextDark
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Step Progress Bar
            LinearProgressIndicator(
                progress = { (currentStep.toFloat() / 16f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = BullionGoldPrimary,
                trackColor = ObsidianElevated
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Scrollable Step Logs Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                if (logs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Tap 'RUN REPLAY' to trigger the full 16-step Wall Street precious metals lifecycle demonstration.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        itemsIndexed(logs) { index, log ->
                            val isLatest = index == logs.size - 1
                            Row(verticalAlignment = Alignment.Top) {
                                Text(
                                    text = "[$index] ",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isLatest) BullionGoldBright else TextSubtle,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp
                                    )
                                )
                                Text(
                                    text = log,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isLatest) TextWhite else TextMuted,
                                        fontWeight = if (isLatest) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 9.5.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
