package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun OrderManagementScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val orders by repository.orders.collectAsState()
    val executions by repository.executions.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0 = Active & Historical Orders, 1 = Cleared Executions

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("oms_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ORDER MANAGEMENT SYSTEM (OMS)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Institutional Routing • Dark Pool Matches • TWAP/VWAP Algorithms",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TabPill("ORDERS (${orders.size})", activeTab == 0) { activeTab = 0 }
                    TabPill("EXECUTIONS (${executions.size})", activeTab == 1) { activeTab = 1 }
                }
            }
        }

        if (activeTab == 0) {
            // Orders List
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                orders.forEach { ord ->
                    val statusColor = when (ord.status) {
                        OrderStatus.FILLED -> TerminalGreen
                        OrderStatus.PARTIALLY_FILLED -> AlertAmber
                        OrderStatus.PENDING -> TextWhite
                        else -> RiskCrimson
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${ord.orderId} • ${ord.side.displayName} ${ord.quantityOz} oz ${ord.metal.displayName}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (ord.side == OrderSide.BUY) TerminalGreen else RiskCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(statusColor.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = ord.status.displayName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = statusColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Type: ${ord.orderType.displayName} • Venue: ${ord.venue.venueCode}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                            Text("Avg Price: $${String.format("%,.2f", ord.averageExecutionPrice)}", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace))
                        }

                        if (ord.orderType.isAlgorithmic) {
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { ord.algoSliceProgress },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = BullionGoldPrimary,
                                trackColor = ObsidianCard
                            )
                        }
                    }
                }
            }
        } else {
            // Cleared Executions List
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                executions.forEach { exec ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(exec.tradeId, style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldPrimary, fontWeight = FontWeight.Bold))
                            Text("SETTLE: ${exec.settlementDate}", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                        }
                        Text("${exec.side.displayName} ${exec.executedQuantityOz} oz ${exec.metal.displayName} @ $${String.format("%,.2f", exec.executionPrice)}", style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        Text("Gross: $${String.format("%,.2f", exec.grossConsiderationUsd)} • Clearing Fee: $${String.format("%.2f", exec.exchangeClearingFeeUsd)} • Venue: ${exec.venue.venueCode}", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) BullionGoldPrimary else ObsidianElevated)
            .border(1.dp, if (isSelected) BullionGoldPrimary else ObsidianBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isSelected) TextDark else TextMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        )
    }
}
