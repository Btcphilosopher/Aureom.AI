package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
    spotPrices: Map<MetalAsset, SpotPrice>,
    macroData: MacroCorrelation,
    currentRegime: MarketRegime,
    onRegimeSelected: (MarketRegime) -> Unit,
    onAssetSelected: (MetalAsset) -> Unit,
    selectedAsset: MetalAsset,
    onOpenAiAnalyst: () -> Unit,
    onOpenCommandCenter: () -> Unit
) {
    var showRegimeMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsidianBg)
            .border(1.dp, ObsidianBorder)
    ) {
        // Upper Institutional Status Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(TerminalGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "NEW YORK METALS",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = BullionGoldPrimary
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LOWER MANHATTAN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSubtle,
                        fontSize = 9.sp
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Regime Selector Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ObsidianElevated)
                        .border(1.dp, BullionGoldDark.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .clickable { showRegimeMenu = true }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .testTag("regime_selector_chip")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Market Regime",
                            tint = BullionGoldBright,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentRegime.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = BullionGoldBright,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    DropdownMenu(
                        expanded = showRegimeMenu,
                        onDismissRequest = { showRegimeMenu = false },
                        modifier = Modifier.background(ObsidianElevated)
                    ) {
                        MarketRegime.values().forEach { regime ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(regime.label, color = TextWhite, fontWeight = FontWeight.Bold)
                                        Text(regime.description, color = TextMuted, fontSize = 10.sp)
                                    }
                                },
                                onClick = {
                                    onRegimeSelected(regime)
                                    showRegimeMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // AI Analyst Shortcut
                IconButton(
                    onClick = onOpenAiAnalyst,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(ObsidianElevated)
                        .testTag("topbar_ai_analyst_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = "Metals AI",
                        tint = BullionGoldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Command Center Shortcut
                IconButton(
                    onClick = onOpenCommandCenter,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(ObsidianElevated)
                        .testTag("topbar_command_center_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Dashboard,
                        contentDescription = "Command Center",
                        tint = TerminalGreen,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Divider(color = ObsidianBorder, thickness = 0.5.dp)

        // Live Real-Time Scrolling Ticker Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Precious Metals Spot Prices
            MetalAsset.values().forEach { asset ->
                val price = spotPrices[asset]
                if (price != null) {
                    val isSelected = asset == selectedAsset
                    val isUp = price.changeAmount >= 0
                    val changeColor = if (isUp) TerminalGreen else RiskCrimson

                    Box(
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) ObsidianCard else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) BullionGoldPrimary else ObsidianBorder,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { onAssetSelected(asset) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("ticker_${asset.name.lowercase()}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = asset.displayName.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (asset.isPrimary) BullionGoldPrimary else BullionSilverPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$${String.format("%,.2f", price.last)}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${if (isUp) "+" else ""}${String.format("%.2f", price.changePercent)}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = changeColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }

            // Gold/Silver Ratio Ticker Item
            val gold = spotPrices[MetalAsset.GOLD]?.last ?: 4188.30
            val silver = spotPrices[MetalAsset.SILVER]?.last ?: 52.84
            val ratio = gold / silver

            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "G/S RATIO",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = String.format("%.2f", ratio),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = BullionGoldBright
                        )
                    )
                }
            }

            // DXY & 10Y Yields
            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(ObsidianElevated)
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "DXY ${macroData.dxyDollarIndex}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "10Y TIPS ${macroData.us10YRealYield}%",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextWhite)
                    )
                }
            }
        }
    }
}
