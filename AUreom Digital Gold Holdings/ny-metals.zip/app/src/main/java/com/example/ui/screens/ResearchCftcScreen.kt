package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.theme.*

@Composable
fun ResearchCftcScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val researchReports by repository.researchReports.collectAsState()
    val cftcData by repository.cftcData.collectAsState()
    val centralBankFlows by repository.centralBankFlows.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("research_cftc_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PRECIOUS METALS RESEARCH & CFTC CoT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Institutional Macro Intelligence • CFTC Speculative Positioning • Central Bank Gold Reserves",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }
            }
        }

        // Weekly Research Report
        researchReports.firstOrNull()?.let { rep ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = rep.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = BullionGoldBright,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "${rep.authorDesk} • ${rep.publishDate}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BadgePill("Liquidity: ${rep.liquidityRating}", TerminalGreen)
                        BadgePill("Vol: ${rep.volatilityRegime}", AlertAmber)
                        BadgePill("Curve: ${rep.curveStructure}", BullionGoldPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(rep.macroSummary, style = MaterialTheme.typography.bodySmall.copy(color = TextWhite, lineHeight = 16.sp))

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("KEY STRATEGY TAKEAWAYS:", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                    rep.keyTakeaways.forEach { item ->
                        Text("• $item", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp))
                    }
                }
            }
        }

        // CFTC Commitments of Traders (COT)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CFTC COMMITMENTS OF TRADERS (CoT) POSITIONING",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                cftcData.forEach { cot ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(cot.metalName, style = MaterialTheme.typography.labelMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text(cot.speculativeSentiment, style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Open Interest: ${String.format("%,d", cot.openInterestContracts)}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text("Net Speculative Long: +${String.format("%,d", cot.nonCommercialNetPosition)} (${if (cot.weeklyNetChangeContracts >= 0) "+" else ""}${cot.weeklyNetChangeContracts} w/w)", style = MaterialTheme.typography.labelSmall.copy(color = BullionGoldBright, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Sovereign Central Bank Reserve Gold Accumulation
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SOVEREIGN CENTRAL BANK GOLD PURCHASES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                centralBankFlows.forEach { cb ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(ObsidianElevated)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(cb.institutionName, style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text("Total Reserves: ${String.format("%,.0f", cb.totalReservesTonnes)} tonnes (${cb.percentOfTotalFxReserves}% of FX)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.5.sp))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("+${cb.netMonthlyPurchaseTonnes} t/mo", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                            Text(cb.trend3Year, style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.sp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BadgePill(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall.copy(color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Bold))
    }
}
