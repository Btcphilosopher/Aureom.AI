package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.NewYorkMetalsRepository
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun DealerRfqScreen(
    repository: NewYorkMetalsRepository,
    modifier: Modifier = Modifier
) {
    val activeRfqs by repository.activeRfqs.collectAsState()
    val spotPrices by repository.spotPrices.collectAsState()

    var customQty by remember { mutableStateOf("250") }
    var customSide by remember { mutableStateOf(OrderSide.BUY) }
    var customAsset by remember { mutableStateOf(MetalAsset.GOLD) }
    var customTier by remember { mutableStateOf(ClientTier.TIER_1_SOVEREIGN) }
    var generatedQuoteResult by remember { mutableStateOf<RfqQuote?>(null) }
    var messageBanner by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("dealer_rfq_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Dealer Desk Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullionGoldPrimary))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEW YORK INSTITUTIONAL DEALER DESK",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = BullionGoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Real-Time RFQ Pricing Engine • Two-Way Firm Quotes • Auto COMEX Delta Hedge",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalGreenBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "DEALER ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        // Active RFQ Requests List
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "INCOMING CLIENT RFQ STREAM",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (activeRfqs.isEmpty()) {
                    Text(
                        text = "No pending client RFQs in queue.",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                } else {
                    activeRfqs.forEach { (req, quote) ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(ObsidianElevated)
                                .border(1.dp, ObsidianBorder, RoundedCornerShape(4.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${req.rfqId} • ${req.clientName}",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = TextWhite,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "${req.clientTier.displayName} • Settlement: ${req.settlementTerms}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (req.side == OrderSide.BUY) TerminalGreenBg else RiskCrimsonBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${req.side.displayName} ${String.format("%,.0f", req.quantityOz)} oz ${req.metal.displayName}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (req.side == OrderSide.BUY) TerminalGreen else RiskCrimson,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Divider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 6.dp))

                            if (quote != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "DEALER QUOTE: $${String.format("%,.2f", quote.finalPricePerOz)} / oz",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = BullionGoldBright,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Text(
                                            text = "Total Gross: $${String.format("%,.2f", quote.totalGrossUsd)} USD • Spread: +$${String.format("%.2f", quote.dealerSpreadUsd)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp)
                                        )
                                        Text(
                                            text = "HEDGE ACTION: ${quote.hedgeActionNeeded}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = AlertAmber, fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            repository.acceptRfqQuote(req.rfqId)
                                            messageBanner = "RFQ ${req.rfqId} accepted! Trade executed and ${quote.hedgeActionNeeded} placed on COMEX."
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BullionGoldPrimary, contentColor = TextDark),
                                        shape = RoundedCornerShape(3.dp),
                                        modifier = Modifier.height(32.dp).testTag("accept_rfq_btn_${req.rfqId}")
                                    ) {
                                        Text("ACCEPT & HEDGE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark))
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        repository.generateQuoteForRfq(req.rfqId)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ObsidianCard, contentColor = BullionGoldBright),
                                    shape = RoundedCornerShape(3.dp),
                                    modifier = Modifier.fillMaxWidth().height(32.dp)
                                ) {
                                    Text("COMPUTE DEALER PRICING MATRIX", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom RFQ Calculation & Simulator
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(ObsidianBorder))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CALCULATE NEW INSTITUTIONAL RFQ",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BullionGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customQty,
                        onValueChange = { customQty = it },
                        label = { Text("Quantity (oz)", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelMedium.copy(color = TextWhite),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BullionGoldPrimary,
                            unfocusedBorderColor = ObsidianBorder
                        )
                    )

                    Button(
                        onClick = {
                            val qty = customQty.toDoubleOrNull() ?: 250.0
                            val spot = spotPrices[customAsset]?.last ?: 4188.30
                            val q = com.example.data.engine.SyntheticMarketEngine.priceRfq(
                                spot = spot,
                                quantityOz = qty,
                                side = customSide,
                                tier = customTier,
                                volatility = 18.5,
                                metal = customAsset
                            )
                            generatedQuoteResult = q
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BullionGoldPrimary, contentColor = TextDark),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(52.dp).align(Alignment.CenterVertically).testTag("calc_rfq_btn")
                    ) {
                        Text("GENERATE 2-WAY QUOTE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark))
                    }
                }

                generatedQuoteResult?.let { q ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ObsidianElevated)
                            .border(1.dp, BullionGoldPrimary, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("FIRM BID (WE BUY)", style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
                            Text("FIRM OFFER (WE SELL)", style = MaterialTheme.typography.labelSmall.copy(color = RiskCrimson, fontWeight = FontWeight.Bold))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$${String.format("%,.2f", q.bidQuotePerOz)}", style = MaterialTheme.typography.titleMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                            Text("$${String.format("%,.2f", q.offerQuotePerOz)}", style = MaterialTheme.typography.titleMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        }
                        Divider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))
                        Text("Matrix Factors: Spot $$q.referenceSpotPrice | Spread $$q.dealerSpreadUsd | Fab Premium $$q.physicalPremiumUsd", style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 8.5.sp))
                    }
                }
            }
        }

        messageBanner?.let { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalGreenBg)
                    .border(1.dp, TerminalGreen, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Text(text = msg, style = MaterialTheme.typography.labelSmall.copy(color = TerminalGreen, fontWeight = FontWeight.Bold))
            }
        }
    }
}
