package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.data.engine.GeminiAnalystService
import com.example.data.engine.NewYorkMetalsRepository
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class AppNavigationDestination(
    val title: String,
    val icon: ImageVector,
    val category: String
) {
    TERMINAL("Terminal", Icons.Default.CandlestickChart, "Markets"),
    COMMAND_CENTER("Command", Icons.Default.Dashboard, "Executive"),
    PHYSICAL_VAULT("Vault 03", Icons.Default.Shield, "Custody"),
    DEALER_RFQ("Dealer RFQ", Icons.Default.Handshake, "Trading"),
    PORTFOLIO_RISK("Portfolio", Icons.Default.PieChart, "Risk"),
    FUTURES_CURVE("Futures", Icons.AutoMirrored.Filled.ShowChart, "Markets"),
    SPREAD_ENGINE("G/S Ratio", Icons.AutoMirrored.Filled.CompareArrows, "Markets"),
    OMS("OMS", Icons.AutoMirrored.Filled.ReceiptLong, "Trading"),
    LEDGER("Ledger", Icons.Default.AccountBalance, "Custody"),
    OPTIONS_LAB("Options", Icons.Default.AutoGraph, "Trading"),
    REFINERY("Refinery", Icons.Default.Factory, "Physical"),
    CLIENT_PORTALS("Portals", Icons.Default.Business, "Institutional"),
    RESEARCH_CFTC("Research", Icons.AutoMirrored.Filled.MenuBook, "Intelligence"),
    AI_ANALYST("Metals AI", Icons.Default.Psychology, "Intelligence")
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: NewYorkMetalsRepository
    private lateinit var analystService: GeminiAnalystService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = NewYorkMetalsRepository(lifecycleScope)
        analystService = GeminiAnalystService(repository)

        setContent {
            MyApplicationTheme {
                NewYorkMetalsApp(
                    repository = repository,
                    analystService = analystService
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewYorkMetalsApp(
    repository: NewYorkMetalsRepository,
    analystService: GeminiAnalystService
) {
    var currentDestination by remember { mutableStateOf(AppNavigationDestination.TERMINAL) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val spotPrices by repository.spotPrices.collectAsState()
    val macroData by repository.macroData.collectAsState()
    val currentRegime by repository.marketRegime.collectAsState()
    val selectedAsset by repository.selectedAsset.collectAsState()

    // Handle back button when navigating to sub-screens
    BackHandler(enabled = currentDestination != AppNavigationDestination.TERMINAL) {
        currentDestination = AppNavigationDestination.TERMINAL
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = ObsidianElevated,
                drawerContentColor = TextWhite,
                modifier = Modifier.width(310.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NEW YORK METALS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BullionGoldPrimary,
                                    letterSpacing = 1.2.sp
                                )
                            )
                            Text(
                                text = "LOWER MANHATTAN PLATFORM",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSubtle,
                                    fontSize = 8.5.sp
                                )
                            )
                        }
                        IconButton(onClick = { scope.launch { drawerState.close() } }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }

                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 12.dp))

                    Text(
                        text = "ALL INSTITUTIONAL WORKSPACES",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSubtle, fontSize = 9.sp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AppNavigationDestination.values().forEach { dest ->
                            val isSelected = dest == currentDestination
                            NavigationDrawerItem(
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = dest.title,
                                        tint = if (isSelected) BullionGoldPrimary else TextMuted
                                    )
                                },
                                label = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = dest.title,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = if (isSelected) BullionGoldBright else TextWhite,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        )
                                        Text(
                                            text = dest.category,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = TextSubtle,
                                                fontSize = 8.sp
                                            )
                                        )
                                    }
                                },
                                selected = isSelected,
                                onClick = {
                                    currentDestination = dest
                                    scope.launch { drawerState.close() }
                                },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = ObsidianCard,
                                    unselectedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(4.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        text = "DOUBLE-ENTRY RECONCILED • ALLOCATED TITLE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalGreen,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg),
            topBar = {
                Column(modifier = Modifier.statusBarsPadding()) {
                    TerminalTopBar(
                        spotPrices = spotPrices,
                        macroData = macroData,
                        currentRegime = currentRegime,
                        onRegimeSelected = { regime -> repository.setMarketRegime(regime) },
                        onAssetSelected = { asset -> repository.setSelectedAsset(asset) },
                        selectedAsset = selectedAsset,
                        onOpenAiAnalyst = { currentDestination = AppNavigationDestination.AI_ANALYST },
                        onOpenCommandCenter = { currentDestination = AppNavigationDestination.COMMAND_CENTER }
                    )
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = ObsidianElevated,
                    contentColor = TextWhite,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .border(1.dp, ObsidianBorder)
                ) {
                    val primaryTabs = listOf(
                        AppNavigationDestination.TERMINAL,
                        AppNavigationDestination.PHYSICAL_VAULT,
                        AppNavigationDestination.DEALER_RFQ,
                        AppNavigationDestination.PORTFOLIO_RISK,
                        AppNavigationDestination.COMMAND_CENTER
                    )

                    primaryTabs.forEach { tab ->
                        val isSelected = currentDestination == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) BullionGoldPrimary else TextMuted
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) BullionGoldBright else TextMuted,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 9.sp
                                    )
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = ObsidianCard
                            )
                        )
                    }

                    // More Menu Drawer Trigger
                    NavigationBarItem(
                        selected = false,
                        onClick = { scope.launch { drawerState.open() } },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "More Desks",
                                tint = TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = "Desks",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    fontSize = 9.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = ObsidianCard
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentDestination) {
                    AppNavigationDestination.TERMINAL -> TerminalScreen(repository = repository)
                    AppNavigationDestination.COMMAND_CENTER -> ExecutiveCommandScreen(repository = repository)
                    AppNavigationDestination.PHYSICAL_VAULT -> PhysicalVaultScreen(repository = repository)
                    AppNavigationDestination.DEALER_RFQ -> DealerRfqScreen(repository = repository)
                    AppNavigationDestination.PORTFOLIO_RISK -> PortfolioRiskScreen(repository = repository)
                    AppNavigationDestination.FUTURES_CURVE -> FuturesCurveScreen(repository = repository)
                    AppNavigationDestination.SPREAD_ENGINE -> SpreadEngineScreen(repository = repository)
                    AppNavigationDestination.OMS -> OrderManagementScreen(repository = repository)
                    AppNavigationDestination.LEDGER -> LedgerSettlementScreen(repository = repository)
                    AppNavigationDestination.OPTIONS_LAB -> OptionsLabScreen(repository = repository)
                    AppNavigationDestination.REFINERY -> RefineryRecyclingScreen(repository = repository)
                    AppNavigationDestination.CLIENT_PORTALS -> ClientPortalsScreen(repository = repository)
                    AppNavigationDestination.RESEARCH_CFTC -> ResearchCftcScreen(repository = repository)
                    AppNavigationDestination.AI_ANALYST -> AiMetalsAnalystScreen(
                        repository = repository,
                        analystService = analystService
                    )
                }
            }
        }
    }
}
