package com.example.data.model

enum class LedgerAssetType {
    USD_CASH,
    GOLD_ALLOCATED_OZ,
    GOLD_UNALLOCATED_OZ,
    SILVER_ALLOCATED_OZ,
    SILVER_UNALLOCATED_OZ
}

enum class JournalEntryType(val code: String, val displayName: String) {
    CLIENT_DEPOSIT("DEP", "Client Capital Deposit"),
    TRADE_SETTLEMENT("TRD", "Trade Cash/Metal Settlement"),
    METAL_ALLOCATION("ALC", "Physical Bar Allocation (Available -> Allocated)"),
    METAL_DEALLOCATION("DAL", "Bar Deallocation (Allocated -> Available)"),
    VAULT_STORAGE_FEE("STG", "Vault Custody & Insurance Storage Fee"),
    PHYSICAL_DELIVERY_OUT("DLV", "Physical Bullion Delivery Outflow"),
    REFINERY_YIELD_CREDIT("REF", "Refinery Poured Fine Bullion Inflow")
}

data class DoubleEntryLine(
    val lineId: String,
    val accountName: String,
    val isDebit: Boolean,
    val assetType: LedgerAssetType,
    val amount: Double
)

data class JournalTransaction(
    val transactionId: String,
    val type: JournalEntryType,
    val timestamp: Long,
    val referenceId: String, // e.g. tradeId or barId
    val description: String,
    val lines: List<DoubleEntryLine>,
    val auditHash: String,
    val verifiedBalanced: Boolean = true
)

data class ClientLedgerBalance(
    val clientId: String,
    val clientName: String,
    val usdCashBalance: Double,
    val goldAllocatedOz: Double,
    val goldUnallocatedOz: Double,
    val silverAllocatedOz: Double,
    val silverUnallocatedOz: Double
) {
    fun totalGoldOz(): Double = goldAllocatedOz + goldUnallocatedOz
    fun totalSilverOz(): Double = silverAllocatedOz + silverUnallocatedOz
    fun totalMarketValueUsd(goldSpot: Double, silverSpot: Double): Double {
        return usdCashBalance + (totalGoldOz() * goldSpot) + (totalSilverOz() * silverSpot)
    }
}

data class LedgerReconciliationSummary(
    val totalDebitsUsd: Double,
    val totalCreditsUsd: Double,
    val totalGoldDebitsOz: Double,
    val totalGoldCreditsOz: Double,
    val totalSilverDebitsOz: Double,
    val totalSilverCreditsOz: Double,
    val isCashBalanced: Boolean,
    val isMetalBalanced: Boolean,
    val totalVaultBarsWeightOz: Double,
    val totalAllocatedLedgerOz: Double,
    val physicalInventoryReconciliationDifferenceOz: Double
)
