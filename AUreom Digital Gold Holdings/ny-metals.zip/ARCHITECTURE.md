# ARCHITECTURE & SYSTEM DESIGN
## NEW YORK METALS

### 1. Dual-Rail Ledger Isolation
The platform maintains strict architectural segregation between:
- **Financial & Derivative Exposure**: COMEX synthetic futures, exchange options, and unallocated pool deposits.
- **Physical Bullion Custody**: 100% title-allocated serialized Good Delivery bars (e.g., 400 oz Gold bars with 999.9 purity assay certificates registered in subterranean Manhattan Vault 03).

### 2. State & Data Flow
- **Data Engine Layer** (`com.example.data.engine`):
  - `SyntheticMarketEngine`: Deterministic Black-Scholes options pricing, normal CDF calculations, order book depth generation, futures basis carry, and Monte Carlo VaR algorithms.
  - `NewYorkMetalsRepository`: Centralized state orchestrator exposing reactive Kotlin `StateFlow` streams for spot prices, active orders, vault floor allocations, double-entry journals, and 16-step demonstration state.
  - `GeminiAnalystService`: Context-enriched Gemini 3.5 API integration for real-time quantitative commodities analysis.
- **Presentation Layer** (`com.example.ui`):
  - Jetpack Compose with Material 3 luxury dark institutional theme (Obsidian background `#080A0F`, 24k Gold `#D4AF37`, 999 Fine Silver `#CBD5E1`, Terminal Green `#10B981`, and Risk Crimson `#EF4444`).
  - Edge-to-edge window insets handling, custom adaptive launcher icon, and high-security digital custody certificates.
