# NEW YORK METALS (NYM)
### Institutional Gold & Silver Trading, Bullion Markets, Physical Vault Digital Twin & Digital Custody Platform

Headquartered in Lower Manhattan (Wall Street / Broad Street nexus), **NEW YORK METALS** is an institutional-grade precious metals platform built with Kotlin and Jetpack Compose. It reflects the complete digital metals lifecycle:

$$\text{MARKET} \longrightarrow \text{PRICE} \longrightarrow \text{QUOTE} \longrightarrow \text{ORDER} \longrightarrow \text{EXECUTION} \longrightarrow \text{POSITION} \longrightarrow \text{METAL} \longrightarrow \text{VAULT} \longrightarrow \text{SETTLEMENT} \longrightarrow \text{RISK}$$

---

## 1. Core Architecture & Workspaces

1. **New York Market Terminal**: Live streaming spot prices (XAU/USD, XAG/USD, XPT/USD, XPD/USD, XRH/USD), Level 2 Order Book depth ladder, interactive candlestick charts, and cross-asset macro telemetry (DXY, 10Y TIPS real yields, S&P 500, WTI Crude Oil).
2. **Order Management System (OMS)**: Supports Market, Limit, Stop, Stop-Limit, IOC, FOK, GTC, Day, TWAP and VWAP algorithmic execution with deterministic matching, slippage models, and fee deduction.
3. **Institutional Dealer Desk & RFQ Engine**: Two-way firm quote matrix (reference spot + client tier discount + volatility adjustment + size penalty + fabrication premium) with dynamic 15-second countdown and automatic COMEX futures delta hedging.
4. **Physical Bullion Engine & Vault 03 Digital Twin**: Serialized 400 oz Good Delivery Gold and 1,000 oz Silver bar registry (`NYM-GLD-00018492`), Class 3 subterranean floor layout, assay certification inspector, and armored logistics dispatch (Brinks/Loomis).
5. **Double-Entry Metal & Money Ledger**: Dual-rail accounting isolating fiat USD cash settlement from physical allocated/unallocated metal custody with continuous invariant verification ($\sum \text{Debits} \equiv \sum \text{Credits}$).
6. **Futures Curve Engine**: Term structure analysis across COMEX contracts (GCZ6, GCG7, GCJ7, GCM7, etc.), implied basis calculations, and annualized roll yield.
7. **Gold/Silver Ratio & Relative Value Engine**: Historical percentile, Z-scores, moving average convergence, and mean-reversion statistical arbitrage simulator.
8. **Precious Metals Options Laboratory**: Black-Scholes-Merton options pricer, full Greeks surface ($\Delta, \Gamma, \Theta, \nu, \rho$), and volatility skew analysis.
9. **Portfolio & Quantitative Risk Engine**: $12.48M Master Portfolio, Historical VaR, Parametric VaR, 5,000-path Monte Carlo VaR, CVaR (Expected Shortfall), and multi-factor stress testing lab.
10. **Refinery & Recycling Digital Twin**: Empire Refining Co. (Long Island City) scrap intake, pyrometallurgical smelting, electrolytic recovery, and 999.9 Good Delivery casting.
11. **Institutional Client Desks**: Perspectives for Hedge Funds, Family Offices, Corporate Treasuries, Industrial Silver Users, and Private Wealth Banking.
12. **Research & CFTC CoT Module**: Weekly macro commodity intelligence reports, CFTC speculative positioning, and sovereign central bank reserve accumulation tracking.
13. **Metals AI Quantitative Analyst**: Powered by Gemini 3.5 with context-aware platform telemetry.
14. **16-Step Animated Lifecycle Replay**: Deterministic, replayable demonstration of the full Wall Street precious metals lifecycle.
