package com.example

import com.example.domain.Calculators
import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode

class ExampleUnitTest {
    @Test
    fun testGramsToOunces() {
        // 31.1034768 g should be exactly 1 oz
        val grams = BigDecimal("31.1034768")
        val oz = Calculators.gramsToOunces(grams)
        assertEquals(BigDecimal("1.00000000"), oz.setScale(8, RoundingMode.HALF_UP))
    }

    @Test
    fun testOuncesToGrams() {
        // 1 oz should be exactly 31.1034768 g
        val oz = BigDecimal("1.00000000")
        val grams = Calculators.ouncesToGrams(oz)
        assertEquals(BigDecimal("31.10347680"), grams.setScale(8, RoundingMode.HALF_UP))
    }

    @Test
    fun testKgToOunces() {
        // 1 kg = 1000g. 1000g / 31.1034768 = 32.15074657 oz
        val kg = BigDecimal("1")
        val oz = Calculators.kgToOunces(kg)
        assertEquals(BigDecimal("32.15074657"), oz.setScale(8, RoundingMode.HALF_UP))
    }

    @Test
    fun testOuncesToKg() {
        // 32.15074657 oz should be 1 kg
        val oz = BigDecimal("32.15074657")
        val kg = Calculators.ouncesToKg(oz)
        assertEquals(BigDecimal("1.00000000"), kg.setScale(8, RoundingMode.HALF_UP))
    }

    @Test
    fun testSilnikProby() {
        // 100g of 999.9 gold should be 99.99g of pure metal
        val brutto = BigDecimal("100.00")
        val czysty = Calculators.obliczCzystyMetal(brutto, 999.9)
        assertEquals(BigDecimal("99.9900"), czysty)

        // 50g of 585 gold should be 29.25g of pure metal
        val brutto2 = BigDecimal("50.00")
        val czysty2 = Calculators.obliczCzystyMetal(brutto2, 585.0)
        assertEquals(BigDecimal("29.2500"), czysty2)
    }
}
