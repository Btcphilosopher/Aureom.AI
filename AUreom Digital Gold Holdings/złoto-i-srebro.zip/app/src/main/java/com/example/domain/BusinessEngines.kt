package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode

// Polish Tax Engine Rules
data class RegulaPodatkowa(
    val jurysdykcja: String = "PL",
    val metal: String, // "ZŁOTO" / "SREBRO"
    val produktTyp: String, // "INWESTYCYJNY", "KOLEKCJONERSKI", "BIŻUTERIA", "ZŁOM"
    val stawkaVat: Double, // e.g. 0.0, 23.0
    val opisProcedury: String,
    val podstawaPrawna: String
)

object BusinessEngines {

    // 1. SILNIK PODATKOWY POLSKA
    private val regulyPodatkowe = listOf(
        RegulaPodatkowa(
            metal = "ZŁOTO",
            produktTyp = "INWESTYCYJNY",
            stawkaVat = 0.0,
            opisProcedury = "Zwolnienie z VAT dla złota inwestycyjnego",
            podstawaPrawna = "Art. 122 ustawy o VAT"
        ),
        RegulaPodatkowa(
            metal = "ZŁOTO",
            produktTyp = "BIŻUTERIA",
            stawkaVat = 23.0,
            opisProcedury = "Stawka podstawowa VAT 23%",
            podstawaPrawna = "Art. 41 ust. 1 ustawy o VAT"
        ),
        RegulaPodatkowa(
            metal = "ZŁOTO",
            produktTyp = "ZŁOM",
            stawkaVat = 23.0,
            opisProcedury = "Stawka podstawowa lub mechanizm odwrotnego obciążenia w określonych przypadkach",
            podstawaPrawna = "Art. 41 ust. 1 ustawy o VAT"
        ),
        RegulaPodatkowa(
            metal = "SREBRO",
            produktTyp = "INWESTYCYJNY",
            stawkaVat = 23.0,
            opisProcedury = "Srebro inwestycyjne (sztabki, monety bulionowe) podlega standardowej stawce 23% VAT w Polsce, chyba że stosowana jest procedura VAT Marża dla towarów używanych.",
            podstawaPrawna = "Art. 41 ust. 1 ustawy o VAT"
        ),
        RegulaPodatkowa(
            metal = "SREBRO",
            produktTyp = "KOLEKCJONERSKI",
            stawkaVat = 23.0,
            opisProcedury = "Szczególne zasady opodatkowania marży (VAT Marża) dla monet kolekcjonerskich lub przedmiotów kolekcjonerskich.",
            podstawaPrawna = "Art. 120 ustawy o VAT (Procedura marży dla dzieł sztuki, przedmiotów kolekcjonerskich i antyków)"
        )
    )

    fun pobierzRegulePodatkowa(metal: String, typ: String): RegulaPodatkowa {
        return regulyPodatkowe.firstOrNull { it.metal == metal && it.produktTyp == typ }
            ?: RegulaPodatkowa(
                metal = metal,
                produktTyp = typ,
                stawkaVat = 23.0,
                opisProcedury = "Stawka standardowa VAT",
                podstawaPrawna = "Art. 41 ust. 1 ustawy o VAT"
            )
    }

    /**
     * VAT MARŻA MODEL
     * Wzór: (Cena sprzedaży - Cena nabycia) = Marża brutto
     * VAT = Marża brutto - (Marża brutto / (1 + StawkaVAT))
     */
    fun obliczVatMarza(cenaSprzedazy: BigDecimal, cenaNabycia: BigDecimal, stawkaVat: Double): Map<String, BigDecimal> {
        val marzaBrutto = cenaSprzedazy.subtract(cenaNabycia).coerceAtLeast(BigDecimal.ZERO)
        val divisor = BigDecimal("1").add(BigDecimal(stawkaVat.toString()).divide(BigDecimal("100"), 4, RoundingMode.HALF_UP))
        val marzaNetto = marzaBrutto.divide(divisor, 2, RoundingMode.HALF_UP)
        val podatekVat = marzaBrutto.subtract(marzaNetto).setScale(2, RoundingMode.HALF_UP)
        return mapOf(
            "marzaBrutto" to marzaBrutto,
            "marzaNetto" to marzaNetto,
            "podatekVat" to podatekVat
        )
    }

    /**
     * SPLIT PAYMENT (MPP) Check
     * precious metals are subject to mandatory MPP if transaction value > 15 000 PLN and B2B
     */
    fun sprawdzSplitPayment(kwotaBrutto: BigDecimal, czyB2B: Boolean): Boolean {
        val limitMpp = BigDecimal("15000.00")
        return czyB2B && kwotaBrutto >= limitMpp
    }

    // 2. SILNIK CENOWY
    data class WyliczoneCenyPln(
        val goldSpotPlnPerOz: BigDecimal,
        val silverSpotPlnPerOz: BigDecimal,
        val goldSpotPlnPerGram: BigDecimal,
        val silverSpotPlnPerGram: BigDecimal
    )

    fun przeliczCenySpot(
        goldSpotUsd: BigDecimal,
        silverSpotUsd: BigDecimal,
        usdPln: BigDecimal
    ): WyliczoneCenyPln {
        val goldPlnOz = goldSpotUsd.multiply(usdPln).setScale(2, RoundingMode.HALF_UP)
        val silverPlnOz = silverSpotUsd.multiply(usdPln).setScale(2, RoundingMode.HALF_UP)

        val goldPlnGram = goldPlnOz.divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)
        val silverPlnGram = silverPlnOz.divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)

        return WyliczoneCenyPln(
            goldSpotPlnPerOz = goldPlnOz,
            silverSpotPlnPerOz = silverPlnOz,
            goldSpotPlnPerGram = goldPlnGram,
            silverSpotPlnPerGram = silverPlnGram
        )
    }

    // 3. SILNIK SPRZEDAŻY (Dealer Sell Price calculation)
    fun obliczCeneSprzedazy(
        spotPerGram: BigDecimal,
        proba: Double,
        masaBrutto: BigDecimal,
        premiaProcent: Double, // e.g. 4.5 (%)
        kosztOperacyjnyPln: BigDecimal,
        marzaDodatkowaPln: BigDecimal
    ): Map<String, BigDecimal> {
        val czystyMetal = Calculators.obliczCzystyMetal(masaBrutto, proba)
        val wartoscSpotMetalu = czystyMetal.multiply(spotPerGram).setScale(2, RoundingMode.HALF_UP)

        // premia dealera
        val premiaUłamek = BigDecimal(premiaProcent.toString()).divide(BigDecimal("100"), 4, RoundingMode.HALF_UP)
        val kwotaPremii = wartoscSpotMetalu.multiply(premiaUłamek).setScale(2, RoundingMode.HALF_UP)

        val cenaNetto = wartoscSpotMetalu
            .add(kwotaPremii)
            .add(kosztOperacyjnyPln)
            .add(marzaDodatkowaPln)
            .setScale(2, RoundingMode.HALF_UP)

        return mapOf(
            "wartoscSpotMetalu" to wartoscSpotMetalu,
            "kwotaPremii" to kwotaPremii,
            "cenaNetto" to cenaNetto
        )
    }

    // 4. SILNIK SKUPU (Dealer Buy Price calculation)
    fun obliczCeneSkupu(
        spotPerGram: BigDecimal,
        proba: Double,
        masaBrutto: BigDecimal,
        stanPrzedmiotu: String, // "IDEALNY", "UZYTKOWY", "ZŁOM"
        plynnoscRynkowa: String, // "WYSOKA", "ŚREDNIA", "NISKA"
        poziomZapasow: String, // "NISKI", "NORMALNY", "WYSOKI"
        zmiennoscSpot: String // "NISKA", "ZWYKŁA", "PANIKA"
    ): Map<String, BigDecimal> {
        val czystyMetal = Calculators.obliczCzystyMetal(masaBrutto, proba)
        val wartoscSpotMetalu = czystyMetal.multiply(spotPerGram).setScale(2, RoundingMode.HALF_UP)

        // Bazowa korekta (korekta ujemna od ceny spot - dealer spread)
        var korektaProcent = when (stanPrzedmiotu) {
            "IDEALNY" -> 1.5 // 1.5% pod spotem dla idealnych monet/sztabek
            "UZYTKOWY" -> 3.0 // 3.0% pod spotem dla uzywanej bizuterii
            "ZŁOM" -> 5.5 // 5.5% pod spotem dla zlomu
            else -> 4.0
        }

        // Korekta o płynność
        korektaProcent += when (plynnoscRynkowa) {
            "WYSOKA" -> -0.5 // zmniejsz spread dla top produktów
            "ŚREDNIA" -> 0.0
            "NISKA" -> 1.5 // zwieksz spread dla rzadkich monet
            else -> 0.0
        }

        // Korekta o poziom zapasów dealera (im wiecej mamy, tym mniej chcemy kupic)
        korektaProcent += when (poziomZapasow) {
            "NISKI" -> -0.75 // zachecamy do sprzedazy, oferujemy wyzsza cene
            "NORMALNY" -> 0.0
            "WYSOKI" -> 1.0 // mamy za duzo, obnizamy cene skupu
            else -> 0.0
        }

        // Korekta o zmiennosc rynku (panika rynkowa zwieksza rozpietosc spreadu ze wzgledu na ryzyko hedgingowe)
        korektaProcent += when (zmiennoscSpot) {
            "NISKA" -> -0.25
            "ZWYKŁA" -> 0.0
            "PANIKA" -> 2.5 // ogromne ryzyko gwałtownej przeceny
            else -> 0.0
        }

        // Upewnij sie, ze korekta nie spadnie ponizej 0.5% (dealer zawsze musi miec minimalny spread operacyjny)
        korektaProcent = korektaProcent.coerceAtLeast(0.5)

        val korektaUłamek = BigDecimal(korektaProcent.toString()).divide(BigDecimal("100"), 4, RoundingMode.HALF_UP)
        val kwotaKorekty = wartoscSpotMetalu.multiply(korektaUłamek).setScale(2, RoundingMode.HALF_UP)

        val cenaOferowana = wartoscSpotMetalu.subtract(kwotaKorekty).setScale(2, RoundingMode.HALF_UP)
        val spreadProcent = BigDecimal(korektaProcent.toString()).setScale(2, RoundingMode.HALF_UP)

        return mapOf(
            "wartoscSpotMetalu" to wartoscSpotMetalu,
            "kwotaKorekty" to kwotaKorekty,
            "cenaOferowana" to cenaOferowana,
            "spreadProcent" to spreadProcent
        )
    }
}
