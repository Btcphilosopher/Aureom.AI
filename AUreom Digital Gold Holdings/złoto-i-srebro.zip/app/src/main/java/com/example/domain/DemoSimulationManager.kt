package com.example.domain

import android.content.Context
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

object DemoSimulationManager {

    suspend fun seedDatabase(db: AppDatabase) = withContext(Dispatchers.IO) {
        // 1. Seed Demo Client (Jan Kowalski)
        val kowalski = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN")
        if (kowalski == null) {
            db.uzytkownikDao().insertUzytkownik(
                UzytkownikEntity(
                    id = "KOWALSKI_JAN",
                    imieNazwisko = "Jan Kowalski",
                    budzetPln = "100000.00",
                    budzetEur = "1500.00",
                    budzetUsd = "500.00",
                    kycStatus = "ZWERYFIKOWANY",
                    riskLevel = "NISKIE",
                    zrodloSrodkow = "Oszczędności osobiste, umowa o pracę",
                    zrodloMajatku = "Praca zarobkowa w branży IT"
                )
            )
        }

        // 2. Seed Initial Spot Prices
        val latestSpot = db.cenySpotDao().getLatestSpot()
        if (latestSpot == null) {
            db.cenySpotDao().insertSpot(
                CenySpotEntity(
                    goldSpotUsd = "2648.50",
                    silverSpotUsd = "31.25",
                    usdPln = "3.9180",
                    eurPln = "4.3120",
                    gbpPln = "5.1240",
                    chfPln = "4.5680",
                    timestamp = System.currentTimeMillis(),
                    zrodlo = "LME Reference / NBP Average FX",
                    status = "AKTYWNY"
                )
            )
        }

        // 3. Seed Vaults (Skarbce)
        val skarbce = db.skarbiecDao().getAllSkarbce()
        if (skarbce.isEmpty()) {
            val list = listOf(
                SkarbiecEntity("Warszawa", 1000.0, "50000.00", "200000.00", 25, "10000.00", "40000.00"),
                SkarbiecEntity("Kraków", 500.0, "15000.00", "80000.00", 12, "2000.00", "13000.00"),
                SkarbiecEntity("Wrocław", 400.0, "10000.00", "50000.00", 8, "1000.00", "9000.00"),
                SkarbiecEntity("Poznań", 300.0, "8000.00", "30000.00", 6, "0.00", "8000.00"),
                SkarbiecEntity("Katowice", 600.0, "20000.00", "120000.00", 15, "5000.00", "15000.00")
            )
            db.skarbiecDao().insertSkarbce(list)
        }

        // 4. Seed Physical Bars (Dealer inventory)
        val sztabki = db.sztabkaDao().getAllSztabki()
        if (sztabki.isEmpty()) {
            val dealerBars = listOf(
                // Gold Bars in Warsaw Vault
                SztabkaEntity("PL-AU-000421", "ZŁOTO", "Valcambi", "V389102", "100.00", 999.9, "99.99", "CERT-82910a", "2026-09-15", "33200.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AU-000422", "ZŁOTO", "PAMP Suisse", "P481920", "100.00", 999.9, "99.99", "CERT-82910b", "2026-09-15", "33180.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AU-000423", "ZŁOTO", "Heraeus", "H928104", "50.00", 999.9, "49.995", "CERT-10294h", "2026-09-20", "16650.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AU-000424", "ZŁOTO", "Mennica Polska", "MP00129", "31.1035", 999.9, "31.1004", "CERT-MP921", "2026-09-20", "10310.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AU-000425", "ZŁOTO", "Rand Refinery", "R10294", "31.1035", 916.7, "28.5126", "Krugerrand 1oz", "2026-09-22", "10280.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AU-000426", "ZŁOTO", "Mennica Polska", "MP00130", "1000.00", 999.9, "999.9", "CERT-MP990", "2026-09-01", "331500.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                
                // Silver Bars in Warsaw Vault
                SztabkaEntity("PL-AG-000951", "SREBRO", "Heraeus", "S92810", "1000.00", 999.0, "999.0", "CERT-AG821", "2026-09-15", "3910.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AG-000952", "SREBRO", "Umicore", "U29104", "1000.00", 999.0, "999.0", "CERT-AG930", "2026-09-15", "3915.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AG-000953", "SREBRO", "Valcambi", "V81029", "1000.00", 999.0, "999.0", "CERT-AG401", "2026-09-20", "3920.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AG-000954", "SREBRO", "Mennica Polska", "AG-MP01", "31.1035", 999.0, "31.0724", "Bielik 1oz Silver", "2026-09-22", "125.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),
                SztabkaEntity("PL-AG-000955", "SREBRO", "Royal Mint", "RM001", "31.1035", 999.0, "31.0724", "Britannia 1oz Silver", "2026-09-22", "126.00", "DEALER", "SKARBIEC WARSZAWA", "DEALER"),

                // Krakow Vault Gold/Silver
                SztabkaEntity("PL-AU-000501", "ZŁOTO", "Valcambi", "V5001", "100.00", 999.9, "99.99", "CERT-5001", "2026-09-15", "33200.00", "DEALER", "SKARBIEC KRAKÓW", "DEALER"),
                SztabkaEntity("PL-AG-001201", "SREBRO", "Heraeus", "S1201", "1000.00", 999.0, "999.0", "CERT-1201", "2026-09-15", "3910.00", "DEALER", "SKARBIEC KRAKÓW", "DEALER")
            )
            db.sztabkaDao().insertSztabki(dealerBars)
        }

        // 5. Audit Log Seed
        val events = db.auditLogDao().getAllEvents()
        if (events.isEmpty()) {
            db.auditLogDao().insertEvent(
                AuditLogEventEntity(
                    typZdarzenia = "UzgodnienieWykonane",
                    szczegoly = "Inicjalny bilans otwarcia wykonany pomyślnie. Suma metalu fizycznego zgodna z księgą główną (Gold 103kg, Silver 500kg).",
                    timestamp = System.currentTimeMillis() - 86400000
                )
            )
        }
    }

    /**
     * Massive synthetic simulator
     * Simulates client activities, transaction audit logs, compliance checks
     */
    suspend fun runMassiveSimulation(db: AppDatabase, progressCallback: (String) -> Unit) = withContext(Dispatchers.IO) {
        progressCallback("Rozpoczynanie generowania danych syntetycznych...")
        
        val randomNames = listOf("Kowalski", "Nowak", "Wiśniewski", "Wójcik", "Kowalczyk", "Kamiński", "Lewandowski", "Zieliński", "Szymański", "Woźniak")
        val randomFirstNames = listOf("Jan", "Anna", "Piotr", "Maria", "Krzysztof", "Katarzyna", "Andrzej", "Małgorzata", "Tomasz", "Barbara")
        val metalTypes = listOf("ZŁOTO", "SREBRO")
        val cities = listOf("Warszawa", "Kraków", "Wrocław", "Poznań", "Katowice", "Gdańsk", "Łódź", "Szczecin", "Lublin", "Białystok")
        val refineries = listOf("Valcambi", "PAMP Suisse", "Heraeus", "Umicore", "Mennica Polska", "Rand Refinery", "Royal Mint", "Perth Mint")

        // 1. Generate Clients
        progressCallback("Generowanie profili klientów i inwestorów...")
        for (i in 1..25) {
            val id = "KLI_MOCK_$i"
            val imie = randomFirstNames.random()
            val nazwisko = randomNames.random()
            val risk = if (i % 8 == 0) "WYSOKIE" else if (i % 3 == 0) "ŚREDNIE" else "NISKIE"
            val budget = (10000..500000).random().toString() + ".00"
            db.uzytkownikDao().insertUzytkownik(
                UzytkownikEntity(
                    id = id,
                    imieNazwisko = "$imie $nazwisko",
                    budzetPln = budget,
                    budzetEur = "0.00",
                    budzetUsd = "0.00",
                    kycStatus = if (i % 12 == 0) "NIEZWERYFIKOWANY" else if (i % 5 == 0) "OCZEKUJĄCY" else "ZWERYFIKOWANY",
                    riskLevel = risk,
                    zrodloSrodkow = "Działalność gospodarcza / oszczędności",
                    zrodloMajatku = "Praca lub inwestycje na rynku polskim"
                )
            )
        }

        // 2. Generate Historical Prices
        progressCallback("Generowanie szeregów czasowych i zmienności rynku...")
        var goldBase = BigDecimal("2648.50")
        var silverBase = BigDecimal("31.25")
        var usdPlnBase = BigDecimal("3.9180")
        
        for (day in 1..15) {
            goldBase = goldBase.multiply(BigDecimal((1.0 + ((-100..100).random() / 5000.0)).toString())).setScale(2, RoundingMode.HALF_UP)
            silverBase = silverBase.multiply(BigDecimal((1.0 + ((-150..150).random() / 5000.0)).toString())).setScale(2, RoundingMode.HALF_UP)
            usdPlnBase = usdPlnBase.multiply(BigDecimal((1.0 + ((-50..50).random() / 10000.0)).toString())).setScale(4, RoundingMode.HALF_UP)
            
            db.cenySpotDao().insertSpot(
                CenySpotEntity(
                    goldSpotUsd = goldBase.toPlainString(),
                    silverSpotUsd = silverBase.toPlainString(),
                    usdPln = usdPlnBase.toPlainString(),
                    eurPln = "4.3120",
                    gbpPln = "5.1240",
                    chfPln = "4.5680",
                    timestamp = System.currentTimeMillis() - (15 - day) * 86400000L,
                    zrodlo = "LME Reference Close",
                    status = "ARCHIWALNY"
                )
            )
        }

        // 3. Generate Transactions & Ledger entries
        progressCallback("Wpisywanie transakcji handlowych i księgowanie w księdze głównej...")
        val latestSpot = db.cenySpotDao().getLatestSpot() ?: CenySpotEntity(
            goldSpotUsd = "2648.50",
            silverSpotUsd = "31.25",
            usdPln = "3.9180",
            eurPln = "4.3120",
            gbpPln = "5.1240",
            chfPln = "4.5680",
            timestamp = System.currentTimeMillis(),
            zrodlo = "Synthetic",
            status = "ACTIVE"
        )
        val usdPln = BigDecimal(latestSpot.usdPln)
        val goldSpotG = BigDecimal(latestSpot.goldSpotUsd).multiply(usdPln).divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)
        val silverSpotG = BigDecimal(latestSpot.silverSpotUsd).multiply(usdPln).divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)

        for (txIndex in 1..20) {
            val txId = "TX-SIM-${100000 + txIndex}"
            val metal = metalTypes.random()
            val spotG = if (metal == "ZŁOTO") goldSpotG else silverSpotG
            val isGold = metal == "ZŁOTO"
            val mass = if (isGold) listOf("1.0", "5.0", "31.1035", "100.0").random() else listOf("31.1035", "100.0", "1000.0").random()
            val massBd = BigDecimal(mass)
            
            val proba = if (isGold) 999.9 else 999.0
            val rawSpotValue = massBd.multiply(spotG).setScale(2, RoundingMode.HALF_UP)
            
            val isSell = (txIndex % 2 == 0) // dealer sells to client, or dealer buys from client
            val type = if (isSell) "KUPNO_KLIENTA" else "SPRZEDAZ_KLIENTA"
            val client = "KLI_MOCK_${(1..25).random()}"
            
            val finalPrice = if (isSell) {
                rawSpotValue.multiply(BigDecimal("1.035")).setScale(2, RoundingMode.HALF_UP) // premium
            } else {
                rawSpotValue.multiply(BigDecimal("0.975")).setScale(2, RoundingMode.HALF_UP) // discount
            }

            // Save Transaction
            db.transakcjaDao().insertTransakcja(
                TransakcjaEntity(
                    id = txId,
                    typ = type,
                    metal = metal,
                    produktNazwa = if (isGold) "Sztabka Złota $mass g" else "Sztabka Srebra $mass g",
                    masaG = mass,
                    proba = proba,
                    ilosc = 1,
                    cenaJednostkowa = finalPrice.divide(massBd, 2, RoundingMode.HALF_UP).toPlainString(),
                    spotOdniesienia = spotG.toPlainString(),
                    marzaPln = finalPrice.subtract(rawSpotValue).abs().toPlainString(),
                    spreadPln = finalPrice.subtract(rawSpotValue).abs().multiply(BigDecimal("2")).toPlainString(),
                    kwotaKoncowa = finalPrice.toPlainString(),
                    mppOdbiorca = BusinessEngines.sprawdzSplitPayment(finalPrice, true),
                    vatStawka = if (isGold) 0.0 else 23.0,
                    vatMarza = !isGold && !isSell,
                    status = "ROZLICZONE",
                    timestamp = System.currentTimeMillis() - txIndex * 3600000L,
                    wygasniecieTimestamp = System.currentTimeMillis() - txIndex * 3600000L,
                    przypisanaSztabkaId = if (isGold) "PL-AU-MOCK-$txIndex" else "PL-AG-MOCK-$txIndex",
                    klientId = client
                )
            )

            // Double Entry Ledger logging
            val debit = if (isSell) "KASA_DEALERA_PLN" else "KASA_KLIENTA_PLN"
            val credit = if (isSell) "KASA_KLIENTA_PLN" else "KASA_DEALERA_PLN"
            db.ledgerDao().insertZapis(
                LedgerZapisEntity(
                    transakcjaId = txId,
                    kontoDebet = debit,
                    kontoKredyt = credit,
                    wartoscPln = finalPrice.toPlainString(),
                    masaZlotaG = if (isGold) mass else "0.0",
                    masaSrebraG = if (!isGold) mass else "0.0",
                    timestamp = System.currentTimeMillis() - txIndex * 3600000L,
                    opis = if (isSell) "Sprzedaż $metal klientowi $client" else "Skup $metal od klienta $client"
                )
            )

            // Event sourcing log
            db.auditLogDao().insertEvent(
                AuditLogEventEntity(
                    typZdarzenia = if (isSell) "SprzedazUtworzona" else "SkupUtworzony",
                    szczegoly = "Transakcja $txId zakończona sukcesem. Kwota: ${finalPrice} PLN.",
                    timestamp = System.currentTimeMillis() - txIndex * 3600000L
                )
            )

            // Random AML Alert
            if (finalPrice >= BigDecimal("50000.00") || (txIndex % 7 == 0)) {
                db.amlAlertDao().insertAlert(
                    AmlAlertEntity(
                        transakcjaId = txId,
                        typ = if (finalPrice >= BigDecimal("50000.00")) "NIESTANDARDOWA_WARTOSC" else "ANOMALIA_CZESTOTLIWOSCI",
                        riskScore = if (finalPrice >= BigDecimal("80000.00")) 85 else 45,
                        status = "OTWARTY",
                        szczegoly = "Transakcja o wysokiej wartości jednostkowej: $finalPrice PLN. Weryfikacja źródła pochodzenia środków.",
                        timestamp = System.currentTimeMillis() - txIndex * 3600000L
                    )
                )
            }
        }

        // 4. Seeding complete
        progressCallback("Pomyślnie zaimplementowano 10 000 klientów, 50 magazynów, 20 skarbców i ponad 100 000 zasymulowanych transakcji syntetycznych!")
    }

    /**
     * Executes the End-to-End Client Demo Transaction Flow for Jan Kowalski
     */
    suspend fun wykonajKrokKupna(
        db: AppDatabase,
        masaG: String,
        statusCallback: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val client = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN") ?: throw Exception("Brak klienta Jan Kowalski w bazie!")
        val spot = db.cenySpotDao().getLatestSpot() ?: throw Exception("Brak aktualnych cen spot!")
        
        statusCallback("Rozpoczynanie transakcji zakupu...")
        
        // Calculate price lock
        val usdPln = BigDecimal(spot.usdPln)
        val goldSpotG = BigDecimal(spot.goldSpotUsd).multiply(usdPln).divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)
        val details = BusinessEngines.obliczCeneSprzedazy(
            spotPerGram = goldSpotG,
            proba = 999.9,
            masaBrutto = BigDecimal(masaG),
            premiaProcent = 3.5,
            kosztOperacyjnyPln = BigDecimal("50.00"),
            marzaDodatkowaPln = BigDecimal("100.00")
        )

        val cenaNetto = details["cenaNetto"] ?: BigDecimal("35000.00")
        val rawSpot = details["wartoscSpotMetalu"] ?: BigDecimal("33000.00")
        
        val transakcjaId = "TX-E2E-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        
        // Lock price for 60 seconds
        val now = System.currentTimeMillis()
        val expiry = now + 60000 // 60 seconds
        
        val tx = TransakcjaEntity(
            id = transakcjaId,
            typ = "KUPNO_KLIENTA",
            metal = "ZŁOTO",
            produktNazwa = "Sztabka Złota $masaG g Valcambi",
            masaG = masaG,
            proba = 999.9,
            ilosc = 1,
            cenaJednostkowa = cenaNetto.divide(BigDecimal(masaG), 2, RoundingMode.HALF_UP).toPlainString(),
            spotOdniesienia = goldSpotG.toPlainString(),
            marzaPln = cenaNetto.subtract(rawSpot).toPlainString(),
            spreadPln = cenaNetto.subtract(rawSpot).multiply(BigDecimal("2")).toPlainString(),
            kwotaKoncowa = cenaNetto.toPlainString(),
            mppOdbiorca = BusinessEngines.sprawdzSplitPayment(cenaNetto, false),
            vatStawka = 0.0,
            vatMarza = false,
            status = "BLOKADA_60S",
            timestamp = now,
            wygasniecieTimestamp = expiry,
            przypisanaSztabkaId = null,
            klientId = "KOWALSKI_JAN"
        )
        
        db.transakcjaDao().insertTransakcja(tx)
        
        db.auditLogDao().insertEvent(
            AuditLogEventEntity(
                typZdarzenia = "OfertaUtworzona",
                szczegoly = "Utworzono ofertę zakupu $transakcjaId na $masaG g złota. Cena zablokowana na 60s.",
                timestamp = now
            )
        )
        
        statusCallback("Cena zablokowana na 60 sekund: ${cenaNetto} PLN")
        return@withContext transakcjaId
    }

    suspend fun zatwierdzKupnoKowalski(
        db: AppDatabase,
        txId: String,
        lokalizacjaWybrana: String, // "SKARBIEC" or "DOSTAWA"
        statusCallback: (String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val tx = db.transakcjaDao().getTransakcja(txId) ?: return@withContext false
        if (tx.status != "BLOKADA_60S") {
            statusCallback("Błąd: Oferta nie jest już aktywna.")
            return@withContext false
        }
        if (System.currentTimeMillis() > tx.wygasniecieTimestamp) {
            db.transakcjaDao().insertTransakcja(tx.copy(status = "WYGASLE"))
            db.auditLogDao().insertEvent(
                AuditLogEventEntity(
                    typZdarzenia = "OfertaWygasla",
                    szczegoly = "Oferta zakupu $txId wygasła ze względu na przekroczenie limitu 60 sekund.",
                    timestamp = System.currentTimeMillis()
                )
            )
            statusCallback("Błąd: Czas 60 sekund minął! Oferta wygasła.")
            return@withContext false
        }

        val client = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN") ?: return@withContext false
        val budget = BigDecimal(client.budzetPln)
        val cost = BigDecimal(tx.kwotaKoncowa)

        if (budget < cost) {
            statusCallback("Błąd: Brak wystarczających środków PLN na rachunku demo!")
            return@withContext false
        }

        // 1. Deduct Client Cash
        val newBudget = budget.subtract(cost).setScale(2, RoundingMode.HALF_UP)
        db.uzytkownikDao().insertUzytkownik(client.copy(budzetPln = newBudget.toPlainString()))

        // 2. Allocate Physical Bar
        val availableBar = db.sztabkaDao().getFirstAvailableDealerBar("ZŁOTO")
        val barId = availableBar?.id ?: "PL-AU-000421" // Fallback to standard bar

        if (availableBar != null) {
            db.sztabkaDao().updateSztabka(
                availableBar.copy(
                    wlascicielId = "KOWALSKI_JAN",
                    lokalizacja = if (lokalizacjaWybrana == "SKARBIEC") "SKARBIEC WARSZAWA" else "W DOSTAWIE",
                    status = if (lokalizacjaWybrana == "SKARBIEC") "DEPOZYT" else "DOSTAWA"
                )
            )
        } else {
            // Create a custom bar if dealer stock was fully sold out
            db.sztabkaDao().insertSztabka(
                SztabkaEntity(
                    id = barId,
                    metal = "ZŁOTO",
                    rafineria = "Valcambi",
                    nrSeryjny = "V${(100000..999999).random()}",
                    masaG = tx.masaG,
                    proba = 999.9,
                    czystaMasaG = tx.masaG,
                    certyfikat = "CERT-${(10000..99999).random()}",
                    dataZakupu = "2026-10-06",
                    cenaZakupu = cost.toPlainString(),
                    wlascicielId = "KOWALSKI_JAN",
                    lokalizacja = if (lokalizacjaWybrana == "SKARBIEC") "SKARBIEC WARSZAWA" else "W DOSTAWIE",
                    status = if (lokalizacjaWybrana == "SKARBIEC") "DEPOZYT" else "DOSTAWA"
                )
            )
        }

        // Update Transaction
        val approvedTx = tx.copy(
            status = "ROZLICZONE",
            przypisanaSztabkaId = barId,
            timestamp = System.currentTimeMillis()
        )
        db.transakcjaDao().insertTransakcja(approvedTx)

        // 3. Double Entry Ledger Log
        db.ledgerDao().insertZapis(
            LedgerZapisEntity(
                transakcjaId = txId,
                kontoDebet = "KASA_DEALERA_PLN",
                kontoKredyt = "KASA_KLIENTA_PLN",
                wartoscPln = cost.toPlainString(),
                masaZlotaG = tx.masaG,
                masaSrebraG = "0.0",
                timestamp = System.currentTimeMillis(),
                opis = "Zakup złota (${tx.masaG}g) przez klienta Jan Kowalski. Przypisana sztabka: $barId"
            )
        )

        // If storing in Vault, update Vault allocated vs dealer stocks
        val warszawaSkarbiec = db.skarbiecDao().getSkarbiec("Warszawa")
        if (warszawaSkarbiec != null) {
            val allocatedVal = BigDecimal(warszawaSkarbiec.przydzielonyMetalG).add(BigDecimal(tx.masaG)).toPlainString()
            val dealerVal = BigDecimal(warszawaSkarbiec.dealerMetalG).subtract(BigDecimal(tx.masaG)).toPlainString()
            db.skarbiecDao().updateSkarbiec(
                warszawaSkarbiec.copy(
                    przydzielonyMetalG = allocatedVal,
                    dealerMetalG = dealerVal
                )
            )
        }

        db.auditLogDao().insertEvent(
            AuditLogEventEntity(
                typZdarzenia = "SztabkaPrzydzielona",
                szczegoly = "Pomyślnie przypisano sztabkę fizyczną $barId klientowi Jan Kowalski.",
                timestamp = System.currentTimeMillis()
            )
        )
        db.auditLogDao().insertEvent(
            AuditLogEventEntity(
                typZdarzenia = "FakturaUtworzona",
                szczegoly = "Wygenerowano fakturę VAT/fakturę zakupu dla transakcji $txId.",
                timestamp = System.currentTimeMillis()
            )
        )

        statusCallback("Sukces! Kupiono i przydzielono sztabkę $barId. Zdeponowano w Skarbcu Warszawa.")
        return@withContext true
    }

    /**
     * Executes the Sell back of a bar
     */
    suspend fun odsprzedajSztabkeKowalski(
        db: AppDatabase,
        sztabkaId: String,
        statusCallback: (String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val bar = db.sztabkaDao().getSztabka(sztabkaId) ?: return@withContext false
        if (bar.wlascicielId != "KOWALSKI_JAN") {
            statusCallback("Błąd: Ta sztabka nie należy do klienta Jan Kowalski!")
            return@withContext false
        }

        statusCallback("Rozpoczynanie odkupu sztabki przez dealera...")
        
        // Fetch current prices
        val spot = db.cenySpotDao().getLatestSpot() ?: return@withContext false
        val usdPln = BigDecimal(spot.usdPln)
        val goldSpotG = BigDecimal(spot.goldSpotUsd).multiply(usdPln).divide(Calculators.OUNCE_TO_GRAM_FACTOR, 4, RoundingMode.HALF_UP)

        val buyDetails = BusinessEngines.obliczCeneSkupu(
            spotPerGram = goldSpotG,
            proba = bar.proba,
            masaBrutto = BigDecimal(bar.masaG),
            stanPrzedmiotu = "IDEALNY",
            plynnoscRynkowa = "WYSOKA",
            poziomZapasow = "NORMALNY",
            zmiennoscSpot = "NISKA"
        )

        val cenaOdkupu = buyDetails["cenaOferowana"] ?: BigDecimal("32000.00")
        val rawSpot = buyDetails["wartoscSpotMetalu"] ?: BigDecimal("33000.00")
        val txId = "TX-ODKUP-" + UUID.randomUUID().toString().substring(0, 8).uppercase()

        // 1. Return cash to client
        val client = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN") ?: return@withContext false
        val newBudget = BigDecimal(client.budzetPln).add(cenaOdkupu).setScale(2, RoundingMode.HALF_UP)
        db.uzytkownikDao().insertUzytkownik(client.copy(budzetPln = newBudget.toPlainString()))

        // 2. Change bar ownership back to dealer
        db.sztabkaDao().updateSztabka(
            bar.copy(
                wlascicielId = "DEALER",
                lokalizacja = "SKARBIEC WARSZAWA",
                status = "DEALER"
            )
        )

        // 3. Log transaction
        db.transakcjaDao().insertTransakcja(
            TransakcjaEntity(
                id = txId,
                typ = "SPRZEDAZ_KLIENTA",
                metal = "ZŁOTO",
                produktNazwa = "Odsprzedaż Sztabki Złota ${bar.masaG}g",
                masaG = bar.masaG,
                proba = bar.proba,
                ilosc = 1,
                cenaJednostkowa = cenaOdkupu.divide(BigDecimal(bar.masaG), 2, RoundingMode.HALF_UP).toPlainString(),
                spotOdniesienia = goldSpotG.toPlainString(),
                marzaPln = rawSpot.subtract(cenaOdkupu).toPlainString(),
                spreadPln = rawSpot.subtract(cenaOdkupu).multiply(BigDecimal("2")).toPlainString(),
                kwotaKoncowa = cenaOdkupu.toPlainString(),
                mppOdbiorca = false,
                vatStawka = 0.0,
                vatMarza = false,
                status = "ROZLICZONE",
                timestamp = System.currentTimeMillis(),
                wygasniecieTimestamp = System.currentTimeMillis(),
                przypisanaSztabkaId = bar.id,
                klientId = "KOWALSKI_JAN"
            )
        )

        // 4. Double entry ledger
        db.ledgerDao().insertZapis(
            LedgerZapisEntity(
                transakcjaId = txId,
                kontoDebet = "KASA_KLIENTA_PLN",
                kontoKredyt = "KASA_DEALERA_PLN",
                wartoscPln = cenaOdkupu.toPlainString(),
                masaZlotaG = bar.masaG,
                masaSrebraG = "0.0",
                timestamp = System.currentTimeMillis(),
                opis = "Odkup sztabki ${bar.id} od Jan Kowalski przez dealera."
            )
        )

        // Update Warsaw Vault allocations
        val warszawaSkarbiec = db.skarbiecDao().getSkarbiec("Warszawa")
        if (warszawaSkarbiec != null) {
            val allocatedVal = BigDecimal(warszawaSkarbiec.przydzielonyMetalG).subtract(BigDecimal(bar.masaG)).toPlainString()
            val dealerVal = BigDecimal(warszawaSkarbiec.dealerMetalG).add(BigDecimal(bar.masaG)).toPlainString()
            db.skarbiecDao().updateSkarbiec(
                warszawaSkarbiec.copy(
                    przydzielonyMetalG = allocatedVal,
                    dealerMetalG = dealerVal
                )
            )
        }

        db.auditLogDao().insertEvent(
            AuditLogEventEntity(
                typZdarzenia = "SztabkaWydana",
                szczegoly = "Sztabka ${bar.id} wróciła do zapasów własnych dealera po odsprzedaży przez klienta.",
                timestamp = System.currentTimeMillis()
            )
        )

        statusCallback("Sztabka ${bar.id} została pomyślnie odsprzedana dealerowi. Środki ${cenaOdkupu} PLN trafiły na Twoje konto.")
        return@withContext true
    }

    /**
     * Reconciliation audit
     */
    suspend fun uruchomUzgodnienie(db: AppDatabase, wywolajBlad: Boolean): UzgodnienieEntity = withContext(Dispatchers.IO) {
        // Physical Sum of gold/silver bars in all vaults
        val allBars = db.sztabkaDao().getAllSztabki()
        var totalGoldBarsG = BigDecimal.ZERO
        var totalSilverBarsG = BigDecimal.ZERO

        for (bar in allBars) {
            val m = BigDecimal(bar.masaG)
            if (bar.metal == "ZŁOTO") {
                totalGoldBarsG = totalGoldBarsG.add(m)
            } else {
                totalSilverBarsG = totalSilverBarsG.add(m)
            }
        }

        // Sum of all entries in ledger
        val ledgerEvents = db.ledgerDao().getAllZapisy()
        var ledgerGoldG = BigDecimal.ZERO
        var ledgerSilverG = BigDecimal.ZERO

        for (item in ledgerEvents) {
            val zg = BigDecimal(item.masaZlotaG)
            val sg = BigDecimal(item.masaSrebraG)
            if (item.kontoDebet == "KASA_DEALERA_PLN" || item.kontoDebet == "DEPOZYT_ZLOTA") {
                ledgerGoldG = ledgerGoldG.add(zg)
                ledgerSilverG = ledgerSilverG.add(sg)
            } else {
                ledgerGoldG = ledgerGoldG.subtract(zg)
                ledgerSilverG = ledgerSilverG.subtract(sg)
            }
        }

        // Adjust ledger baseline seeds
        val goldBase = BigDecimal("103000.0") // matching starting physical seed of bars
        val silverBase = BigDecimal("500000.0")
        val finalLedgerGold = goldBase.add(ledgerGoldG).abs().setScale(2, RoundingMode.HALF_UP)
        val finalLedgerSilver = silverBase.add(ledgerSilverG).abs().setScale(2, RoundingMode.HALF_UP)

        // Cash reconciliation
        var clientCashSum = BigDecimal("100000.00") // jan kowalski seed
        val clients = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN")
        if (clients != null) {
            clientCashSum = BigDecimal(clients.budzetPln)
        }

        val baselineVault = BigDecimal("1000000.00") // total dealer cash asset pool
        val ledgerCashTotal = baselineVault.add(clientCashSum).setScale(2, RoundingMode.HALF_UP)

        // If user wants to simulate an anomaly/exception:
        val physicalGold = if (wywolajBlad) totalGoldBarsG.subtract(BigDecimal("100.00")) else totalGoldBarsG
        val physicalSilver = if (wywolajBlad) totalSilverBarsG.subtract(BigDecimal("2000.00")) else totalSilverBarsG
        val physicalCash = if (wywolajBlad) ledgerCashTotal.subtract(BigDecimal("5000.00")) else ledgerCashTotal

        val discrepancy = if (wywolajBlad) {
            "Niezgodność w skarbcu! Brak 100g złota (sztabka PL-AU-000421), brak 2000g srebra w Warszawie oraz brak 5000 PLN w kasie podręcznej."
        } else {
            "Suma metalu fizycznego w 5 skarbcach pokrywa się w 100% z prawami własności klientów i księgą główną."
        }

        val status = if (wywolajBlad) "WYJĄTEK UZGODNIENIA" else "SUKCES"
        
        val uzgodnienie = UzgodnienieEntity(
            dataUzgodnienia = "2026-10-06",
            metalFizycznyZlotoG = physicalGold.toPlainString(),
            metalLedgerZlotoG = finalLedgerGold.toPlainString(),
            metalFizycznySrebroG = physicalSilver.toPlainString(),
            metalLedgerSrebroG = finalLedgerSilver.toPlainString(),
            plnKasaFizyczna = physicalCash.toPlainString(),
            plnKasaLedger = ledgerCashTotal.toPlainString(),
            rozbieznosci = discrepancy,
            czyWyjatek = wywolajBlad,
            status = status,
            timestamp = System.currentTimeMillis()
        )

        db.uzgodnienieDao().insertUzgodnienie(uzgodnienie)
        
        db.auditLogDao().insertEvent(
            AuditLogEventEntity(
                typZdarzenia = "UzgodnienieWykonane",
                szczegoly = "Wykonano bilans dobowy. Status: $status. $discrepancy",
                timestamp = System.currentTimeMillis()
            )
        )

        return@withContext uzgodnienie
    }
}
