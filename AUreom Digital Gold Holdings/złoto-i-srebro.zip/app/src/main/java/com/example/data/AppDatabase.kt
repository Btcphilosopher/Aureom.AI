package com.example.data

import android.content.Context
import androidx.room.*
import java.math.BigDecimal
import java.math.RoundingMode

// Entities

@Entity(tableName = "uzytkownicy")
data class UzytkownikEntity(
    @PrimaryKey val id: String,
    val imieNazwisko: String,
    val budzetPln: String, // stored as String for BigDecimal precision
    val budzetEur: String,
    val budzetUsd: String,
    val kycStatus: String, // "ZWERYFIKOWANY", "OCZEKUJĄCY", "NIEZWERYFIKOWANY"
    val riskLevel: String, // "NISKIE", "ŚREDNIE", "WYSOKIE"
    val zrodloSrodkow: String,
    val zrodloMajatku: String
)

@Entity(tableName = "ceny_spot")
data class CenySpotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val goldSpotUsd: String,
    val silverSpotUsd: String,
    val usdPln: String,
    val eurPln: String,
    val gbpPln: String,
    val chfPln: String,
    val timestamp: Long,
    val zrodlo: String,
    val status: String
)

@Entity(tableName = "skarbce")
data class SkarbiecEntity(
    @PrimaryKey val miasto: String, // "Warszawa", "Kraków", etc.
    val pojemnoscKg: Double,
    val zlotoMasaG: String,
    val srebroMasaG: String,
    val liczbaSztabek: Int,
    val przydzielonyMetalG: String,
    val dealerMetalG: String
)

@Entity(tableName = "sztabki")
data class SztabkaEntity(
    @PrimaryKey val id: String, // e.g. "PL-AU-000421"
    val metal: String, // "ZŁOTO" / "SREBRO"
    val rafineria: String,
    val nrSeryjny: String,
    val masaG: String,
    val proba: Double,
    val czystaMasaG: String,
    val certyfikat: String,
    val dataZakupu: String,
    val cenaZakupu: String,
    val wlascicielId: String, // "DEALER" or client ID "KOWALSKI_JAN"
    val lokalizacja: String, // "SKARBIEC WARSZAWA", "DEPOZYT", "W DOSTAWIE"
    val status: String // "PRZYDZIELONA", "DEPOZYT", "DEALER", "DOSTAWA"
)

@Entity(tableName = "transakcje")
data class TransakcjaEntity(
    @PrimaryKey val id: String, // Idempotency-Key can be used here
    val typ: String, // "KUPNO_KLIENTA", "SPRZEDAZ_KLIENTA", "SKUP_BIZUTERII"
    val metal: String, // "ZŁOTO" / "SREBRO"
    val produktNazwa: String,
    val masaG: String,
    val proba: Double,
    val ilosc: Int,
    val cenaJednostkowa: String,
    val spotOdniesienia: String,
    val marzaPln: String,
    val spreadPln: String,
    val kwotaKoncowa: String,
    val mppOdbiorca: Boolean,
    val vatStawka: Double, // e.g. 0.0 (gold), 23.0 (silver/jewelry)
    val vatMarza: Boolean,
    val status: String, // "BLOKADA_60S", "ROZLICZONE", "WYGASLE", "BLOKADA_ZAAKCEPTOWANA"
    val timestamp: Long,
    val wygasniecieTimestamp: Long,
    val przypisanaSztabkaId: String?,
    val klientId: String
)

@Entity(tableName = "ledger_zapisy")
data class LedgerZapisEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transakcjaId: String,
    val kontoDebet: String,  // e.g. "KASA_KLIENTA_PLN", "DEPOZYT_ZLOTA", "SKARBIEC_ZLOTA"
    val kontoKredyt: String,
    val wartoscPln: String,
    val masaZlotaG: String,
    val masaSrebraG: String,
    val timestamp: Long,
    val opis: String
)

@Entity(tableName = "audit_log")
data class AuditLogEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val typZdarzenia: String, // e.g. "CenaZaktualizowana", "OfertaUtworzona"
    val szczegoly: String,
    val timestamp: Long
)

@Entity(tableName = "aml_alerty")
data class AmlAlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transakcjaId: String,
    val typ: String, // "NIESTANDARDOWA_WARTOSC", "ANOMALIA_CZESTOTLIWOSCI", "RYZYKO_OPERACYJNE"
    val riskScore: Int, // 0-100
    val status: String, // "OTWARTY", "ZAMKNIĘTY_ZAAKCEPTOWANY", "WERYFIKACJA"
    val szczegoly: String,
    val timestamp: Long
)

@Entity(tableName = "uzgodnienia")
data class UzgodnienieEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dataUzgodnienia: String, // e.g. "2026-10-06"
    val metalFizycznyZlotoG: String,
    val metalLedgerZlotoG: String,
    val metalFizycznySrebroG: String,
    val metalLedgerSrebroG: String,
    val plnKasaFizyczna: String,
    val plnKasaLedger: String,
    val rozbieznosci: String,
    val czyWyjatek: Boolean, // true if reconciliation exception occurs
    val status: String, // "SUKCES", "WYJĄTEK UZGODNIENIA"
    val timestamp: Long
)

// DAOs

@Dao
interface UzytkownikDao {
    @Query("SELECT * FROM uzytkownicy WHERE id = :id")
    suspend fun getUzytkownik(id: String): UzytkownikEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUzytkownik(uzytkownik: UzytkownikEntity)
}

@Dao
interface CenySpotDao {
    @Query("SELECT * FROM ceny_spot ORDER BY id DESC LIMIT 1")
    suspend fun getLatestSpot(): CenySpotEntity?

    @Query("SELECT * FROM ceny_spot ORDER BY id DESC LIMIT 50")
    suspend fun getRecentSpotHistory(): List<CenySpotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpot(spot: CenySpotEntity)
}

@Dao
interface SkarbiecDao {
    @Query("SELECT * FROM skarbce")
    suspend fun getAllSkarbce(): List<SkarbiecEntity>

    @Query("SELECT * FROM skarbce WHERE miasto = :miasto")
    suspend fun getSkarbiec(miasto: String): SkarbiecEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkarbce(skarbce: List<SkarbiecEntity>)

    @Update
    suspend fun updateSkarbiec(skarbiec: SkarbiecEntity)
}

@Dao
interface SztabkaDao {
    @Query("SELECT * FROM sztabki")
    suspend fun getAllSztabki(): List<SztabkaEntity>

    @Query("SELECT * FROM sztabki WHERE wlascicielId = :wlascicielId")
    suspend fun getSztabkiByOwner(wlascicielId: String): List<SztabkaEntity>

    @Query("SELECT * FROM sztabki WHERE id = :id")
    suspend fun getSztabka(id: String): SztabkaEntity?

    @Query("SELECT * FROM sztabki WHERE metal = :metal AND status = 'DEALER' LIMIT 1")
    suspend fun getFirstAvailableDealerBar(metal: String): SztabkaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSztabka(sztabka: SztabkaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSztabki(sztabki: List<SztabkaEntity>)

    @Update
    suspend fun updateSztabka(sztabka: SztabkaEntity)
}

@Dao
interface TransakcjaDao {
    @Query("SELECT * FROM transakcje ORDER BY timestamp DESC")
    suspend fun getAllTransakcje(): List<TransakcjaEntity>

    @Query("SELECT * FROM transakcje WHERE klientId = :klientId ORDER BY timestamp DESC")
    suspend fun getTransakcjeByKlient(klientId: String): List<TransakcjaEntity>

    @Query("SELECT * FROM transakcje WHERE id = :id")
    suspend fun getTransakcja(id: String): TransakcjaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransakcja(transakcja: TransakcjaEntity)

    @Update
    suspend fun updateTransakcja(transakcja: TransakcjaEntity)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_zapisy ORDER BY timestamp DESC")
    suspend fun getAllZapisy(): List<LedgerZapisEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertZapis(zapis: LedgerZapisEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_log ORDER BY timestamp DESC")
    suspend fun getAllEvents(): List<AuditLogEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: AuditLogEventEntity)
}

@Dao
interface AmlAlertDao {
    @Query("SELECT * FROM aml_alerty ORDER BY timestamp DESC")
    suspend fun getAllAlerts(): List<AmlAlertEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: AmlAlertEntity)

    @Update
    suspend fun updateAlert(alert: AmlAlertEntity)
}

@Dao
interface UzgodnienieDao {
    @Query("SELECT * FROM uzgodnienia ORDER BY timestamp DESC")
    suspend fun getAllUzgodnienia(): List<UzgodnienieEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUzgodnienie(uzgodnienie: UzgodnienieEntity)
}

// Database

@Database(
    entities = [
        UzytkownikEntity::class,
        CenySpotEntity::class,
        SkarbiecEntity::class,
        SztabkaEntity::class,
        TransakcjaEntity::class,
        LedgerZapisEntity::class,
        AuditLogEventEntity::class,
        AmlAlertEntity::class,
        UzgodnienieEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun uzytkownikDao(): UzytkownikDao
    abstract fun cenySpotDao(): CenySpotDao
    abstract fun skarbiecDao(): SkarbiecDao
    abstract fun sztabkaDao(): SztabkaDao
    abstract fun transakcjaDao(): TransakcjaDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun amlAlertDao(): AmlAlertDao
    abstract fun uzgodnienieDao(): UzgodnienieDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zloto_srebro_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
