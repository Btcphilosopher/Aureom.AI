package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepGraphite = Color(0xFF11161B)
val DarkNavy = Color(0xFF141D26)
val MutedGold = Color(0xFFC5A059)
val RichGoldAccent = Color(0xFFE2C07D)
val Silver = Color(0xFF8E9AA6)
val Steel = Color(0xFF4E5E6C)
val DarkGreen = Color(0xFF1B3B2B)
val CrimsonAlert = Color(0xFF7A2021)
val WarmWhite = Color(0xFFFAF9F6)
val SoftGray = Color(0xFFE9ECEF)
val BorderGray = Color(0xFFDCDFE3)
val CardBackgroundLight = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1F2937)
val TextLight = Color(0xFFF9FAFB)
