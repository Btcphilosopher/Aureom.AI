package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.domain.Calculators
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

// Helper for Polish currency formatting (e.g. 12 500,00 zł)
fun formatPln(amount: BigDecimal): String {
    val symbols = DecimalFormatSymbols(Locale("pl", "PL"))
    symbols.groupingSeparator = ' '
    symbols.decimalSeparator = ','
    val format = DecimalFormat("#,##0.00", symbols)
    return "${format.format(amount)} zł"
}

// Helper for other currency formatting
fun formatCurrency(amount: BigDecimal, currency: String): String {
    val symbols = DecimalFormatSymbols(Locale("pl", "PL"))
    symbols.groupingSeparator = ' '
    symbols.decimalSeparator = ','
    val format = DecimalFormat("#,##0.00", symbols)
    return "${format.format(amount)} $currency"
}

// Helper for mass formatting (e.g. 123,45 g)
fun formatMass(mass: BigDecimal, unit: String = "g"): String {
    val symbols = DecimalFormatSymbols(Locale("pl", "PL"))
    symbols.decimalSeparator = ','
    symbols.groupingSeparator = ' '
    val format = DecimalFormat("#,##0.0000", symbols)
    return "${format.format(mass).trimEnd('0').trimEnd(',')} $unit"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZlotoSrebroMainScreen(viewModel: ZlotoSrebroViewModel) {
    val scrollState = rememberScrollState()
    
    Scaffold(
        topBar = {
            Column {
                // Ticker Bar (Pasek Cenowy)
                TickerBarComponent(viewModel)
                
                // Header Panel
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.AccountBalance,
                                contentDescription = "Logo",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "ZŁOTO I SREBRO",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground,
                                letterSpacing = 2.sp,
                                fontSize = 20.sp
                            )
                        }
                    },
                    actions = {
                        Text(
                            text = "PRODUKCJA / API / SYMULACJA",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                    },
                    colors = TopAppBarDefaults.mediumTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = viewModel.currentScreen == "HOME",
                    onClick = { viewModel.currentScreen = "HOME" },
                    label = { Text("Rynek") },
                    icon = { Icon(Icons.Filled.TrendingUp, contentDescription = "Rynek") }
                )
                NavigationBarItem(
                    selected = viewModel.currentScreen == "KALKULATOR" || viewModel.currentScreen == "SKUP_BIZU",
                    onClick = { viewModel.currentScreen = "KALKULATOR" },
                    label = { Text("Kalkulator") },
                    icon = { Icon(Icons.Filled.Calculate, contentDescription = "Kalkulator") }
                )
                NavigationBarItem(
                    selected = viewModel.currentScreen == "MOJE_METALE",
                    onClick = { viewModel.currentScreen = "MOJE_METALE" },
                    label = { Text("Moje Metale") },
                    icon = { Icon(Icons.Filled.AccountBalanceWallet, contentDescription = "Moje Metale") }
                )
                NavigationBarItem(
                    selected = viewModel.currentScreen == "TERMINAL_DEALERA",
                    onClick = { viewModel.currentScreen = "TERMINAL_DEALERA" },
                    label = { Text("Dealer Desk") },
                    icon = { Icon(Icons.Filled.Security, contentDescription = "Dealer Desk") }
                )
                NavigationBarItem(
                    selected = viewModel.currentScreen == "MAPA",
                    onClick = { viewModel.currentScreen = "MAPA" },
                    label = { Text("Skarbce") },
                    icon = { Icon(Icons.Filled.Map, contentDescription = "Skarbce") }
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (viewModel.currentScreen) {
                "HOME" -> HomeScreenContent(viewModel)
                "KALKULATOR" -> CalculatorsScreenContent(viewModel)
                "SKUP_BIZU" -> JewelryScreenContent(viewModel)
                "MOJE_METALE" -> ClientDashboardContent(viewModel)
                "TERMINAL_DEALERA" -> DealerDeskContent(viewModel)
                "MAPA" -> PolandMapContent(viewModel)
                "DOKUMENTY" -> DocumentViewerContent(viewModel)
            }
        }
    }
}

// 1. STAŁY PASEK CENOWY (TICKER BAR)
@Composable
fun TickerBarComponent(viewModel: ZlotoSrebroViewModel) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale("pl", "PL")) }
    val formattedTime = formatter.format(Date())

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .border(width = 0.5.dp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(Color(0xFF2E7D32), CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "RYNEK LIVE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32)
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        Divider(modifier = Modifier.height(14.dp).width(1.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.3f))
        Spacer(modifier = Modifier.width(16.dp))

        // Gold Ticker
        Text(text = "ZŁOTO: ", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = "${formatPln(viewModel.computedGoldPlnG)}/g", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = viewModel.goldChangePercent,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (viewModel.goldChangePercent.startsWith("+")) Color(0xFF2E7D32) else Color(0xFFC62828)
        )

        Spacer(modifier = Modifier.width(16.dp))
        Divider(modifier = Modifier.height(14.dp).width(1.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.3f))
        Spacer(modifier = Modifier.width(16.dp))

        // Silver Ticker
        Text(text = "SREBRO: ", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = "${formatPln(viewModel.computedSilverPlnG)}/g", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = viewModel.silverChangePercent,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (viewModel.silverChangePercent.startsWith("+")) Color(0xFF2E7D32) else Color(0xFFC62828)
        )

        Spacer(modifier = Modifier.width(16.dp))
        Divider(modifier = Modifier.height(14.dp).width(1.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.3f))
        Spacer(modifier = Modifier.width(16.dp))

        // USD/PLN Ticker
        Text(text = "USD/PLN: ", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = String.format(Locale.US, "%.4f", viewModel.usdPln), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)

        Spacer(modifier = Modifier.width(16.dp))
        Divider(modifier = Modifier.height(14.dp).width(1.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.3f))
        Spacer(modifier = Modifier.width(16.dp))

        // Ratio Ticker
        val ratio = viewModel.goldSpotUsd.divide(viewModel.silverSpotUsd, 2, RoundingMode.HALF_UP)
        Text(text = "Gold/Silver Ratio: ", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(text = ratio.toPlainString(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Spacer(modifier = Modifier.width(16.dp))
        Divider(modifier = Modifier.height(14.dp).width(1.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.3f))
        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = "Źródło: LBMA | Odświeżono: $formattedTime",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f)
        )
    }
}

// 2. HOME SCREEN CONTENT
@Composable
fun HomeScreenContent(viewModel: ZlotoSrebroViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Hero Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(0.2f), RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "ZŁOTO I SREBRO",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 28.sp
                )
                Text(
                    text = "KUPUJEMY I SPRZEDAJEMY METALE SZLACHETNE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Text(
                    text = "Bezpieczne depozyty skarbcowe w największych miastach Polski. Pełna asygnowana fizyczna własność kruszcu.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(0.7f),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic pricing panels (Złoto / Srebro)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Gold Panel
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(0.1f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(MaterialTheme.colorScheme.primary.copy(0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Star, contentDescription = "Złoto", tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "ZŁOTO", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "CENA SPOT:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                    val spotOz = viewModel.goldSpotUsd.multiply(viewModel.usdPln).setScale(2, RoundingMode.HALF_UP)
                    Text(text = "${formatPln(spotOz)} / oz", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    Text(text = "${formatPln(viewModel.computedGoldPlnG)} / g", fontWeight = FontWeight.Normal, fontSize = 13.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text(text = "SKUP (BID)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                            val bidVal = viewModel.computedGoldPlnG.multiply(BigDecimal("0.985")).setScale(2, RoundingMode.HALF_UP)
                            Text(text = formatPln(bidVal), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "SPRZEDAŻ (ASK)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                            val askVal = viewModel.computedGoldPlnG.multiply(BigDecimal("1.035")).setScale(2, RoundingMode.HALF_UP)
                            Text(text = formatPln(askVal), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Spread: 5.0% (${formatPln(viewModel.computedGoldPlnG.multiply(BigDecimal("0.05")))}/g)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Silver Panel
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.secondary.copy(0.1f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(MaterialTheme.colorScheme.secondary.copy(0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Paid, contentDescription = "Srebro", tint = MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "SREBRO", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "CENA SPOT:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                    val spotOzS = viewModel.silverSpotUsd.multiply(viewModel.usdPln).setScale(2, RoundingMode.HALF_UP)
                    Text(text = "${formatPln(spotOzS)} / oz", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = "${formatPln(viewModel.computedSilverPlnG)} / g", fontWeight = FontWeight.Normal, fontSize = 13.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text(text = "SKUP (BID)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                            val bidVal = viewModel.computedSilverPlnG.multiply(BigDecimal("0.97")).setScale(2, RoundingMode.HALF_UP)
                            Text(text = formatPln(bidVal), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "SPRZEDAŻ (ASK)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                            val askVal = viewModel.computedSilverPlnG.multiply(BigDecimal("1.045")).setScale(2, RoundingMode.HALF_UP)
                            Text(text = formatPln(askVal), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Spread: 7.5% (${formatPln(viewModel.computedSilverPlnG.multiply(BigDecimal("0.075")))}/g)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Two Primary Interactive Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    viewModel.currentScreen = "KALKULATOR"
                },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("buy_gold_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.ArrowUpward, contentDescription = "KUP", tint = MaterialTheme.colorScheme.onPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "KUP OD NAS", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, fontSize = 16.sp)
            }

            Button(
                onClick = {
                    viewModel.currentScreen = "KALKULATOR"
                },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("sell_gold_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = "SPRZEDAJ")
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "SPRZEDAJ NAM", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Price Chart Visualizer (Custom Canvas Drawing)
        Text(text = "HISTORIA NOTOWAŃ (XAU/PLN)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        PriceChartComponent(viewModel)

        Spacer(modifier = Modifier.height(24.dp))

        // Featured Polish Products Showcase
        Text(text = "MONETY BULIONOWE & SZTABKI (KATALOG)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        FeaturedProductsCatalog()
    }
}

// Custom Interactive Chart Component using DrawBehind
@Composable
fun PriceChartComponent(viewModel: ZlotoSrebroViewModel) {
    val graphColor = MaterialTheme.colorScheme.primary
    val baseValue = viewModel.computedGoldPlnG.multiply(BigDecimal("31.1034768")) // gold per oz

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f), RoundedCornerShape(12.dp))
            .drawBehind {
                val strokeWidth = 3.dp.toPx()
                val path = androidx.compose.ui.graphics.Path()

                // Drawing mock historical points
                val mockPoints = listOf(0.95f, 0.94f, 0.96f, 0.98f, 0.97f, 0.99f, 0.985f, 1.0f, 1.01f, 1.005f)
                val segmentWidth = size.width / (mockPoints.size - 1)

                mockPoints.forEachIndexed { i, p ->
                    val x = i * segmentWidth
                    // map y range between 0.2 size.height to 0.8 size.height
                    val y = size.height - (p - 0.9f) / 0.15f * size.height * 0.6f - size.height * 0.1f
                    if (i == 0) {
                        path.moveTo(x, y)
                    } else {
                        path.lineTo(x, y)
                    }
                }

                // Fill gradient underneath the chart line
                val fillPath = androidx.compose.ui.graphics.Path().apply {
                    addPath(path)
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(graphColor.copy(0.2f), Color.Transparent)
                    )
                )

                drawPath(
                    path = path,
                    color = graphColor,
                    style = Stroke(width = strokeWidth)
                )

                // Grid lines
                for (grid in 1..3) {
                    val gy = size.height * grid / 4f
                    drawLine(
                        color = Color.White.copy(0.05f),
                        start = Offset(0f, gy),
                        end = Offset(size.width, gy),
                        strokeWidth = 1f
                    )
                }
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Aktualnie: ${formatPln(baseValue)} / oz", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(text = "-10 dni", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f))
        }
    }
}

// Catalog list Component
@Composable
fun FeaturedProductsCatalog() {
    val items = listOf(
        Triple("Orzeł Bielik 1 oz Gold (NBP)", "NBP | 500 PLN | Polska", "11 520,00 zł"),
        Triple("Krugerrand 1 oz Gold", "Rand Refinery | RPA", "11 380,00 zł"),
        Triple("Sztabka Valcambi 100g Gold", "Valcambi | Szwajcaria", "35 240,00 zł"),
        Triple("Bielik 1 oz Silver (NBP)", "NBP | 20 PLN | Polska", "165,00 zł"),
        Triple("Sztabka Heraeus 1kg Silver", "Heraeus | Niemcy", "4 280,00 zł")
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (name, sub, price) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (name.contains("Silver")) Icons.Filled.Paid else Icons.Filled.Stars,
                        contentDescription = "Moneta",
                        tint = if (name.contains("Silver")) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                    }
                }
                Text(text = price, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
            }
        }
    }
}

// 3. CALCULATORS SCREEN (GOLD / SILVER SPLIT)
@Composable
fun CalculatorsScreenContent(viewModel: ZlotoSrebroViewModel) {
    var activeTab by remember { mutableStateOf("ZLOTO") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Tab Headers
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            TabHeaderButton(
                text = "SKUP ZŁOTA",
                isSelected = activeTab == "ZLOTO",
                modifier = Modifier.weight(1f)
            ) {
                activeTab = "ZLOTO"
            }
            TabHeaderButton(
                text = "SKUP SREBRA",
                isSelected = activeTab == "SREBRO",
                modifier = Modifier.weight(1f)
            ) {
                activeTab = "SREBRO"
            }
            TabHeaderButton(
                text = "BIŻUTERIA",
                isSelected = activeTab == "BIZU",
                modifier = Modifier.weight(1f)
            ) {
                viewModel.currentScreen = "SKUP_BIZU"
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (activeTab == "ZLOTO") {
            CalculatorForm(
                metalName = "Złoto",
                weight = viewModel.calcGoldWeight,
                onWeightChange = {
                    viewModel.calcGoldWeight = it
                    viewModel.recalculateCalculators()
                },
                probaList = listOf(999.9, 999.0, 995.0, 916.7, 750.0, 585.0, 375.0),
                selectedProba = viewModel.calcGoldProba,
                onProbaChange = {
                    viewModel.calcGoldProba = it
                    viewModel.recalculateCalculators()
                },
                spotPrice = viewModel.computedGoldPlnG,
                spotValue = viewModel.calcGoldSpotValue,
                markdown = viewModel.calcGoldMarkdown,
                offerPrice = viewModel.calcGoldResultPrice,
                viewModel = viewModel
            )
        } else {
            CalculatorForm(
                metalName = "Srebro",
                weight = viewModel.calcSilverWeight,
                onWeightChange = {
                    viewModel.calcSilverWeight = it
                    viewModel.recalculateCalculators()
                },
                probaList = listOf(999.0, 999.9, 925.0),
                selectedProba = viewModel.calcSilverProba,
                onProbaChange = {
                    viewModel.calcSilverProba = it
                    viewModel.recalculateCalculators()
                },
                spotPrice = viewModel.computedSilverPlnG,
                spotValue = viewModel.calcSilverSpotValue,
                markdown = viewModel.calcSilverMarkdown,
                offerPrice = viewModel.calcSilverResultPrice,
                viewModel = viewModel
            )
        }
    }
}

@Composable
fun TabHeaderButton(text: String, isSelected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(40.dp)
            .padding(horizontal = 2.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
            contentColor = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f)
        ),
        shape = RoundedCornerShape(6.dp),
        contentPadding = PaddingValues(0.dp),
        elevation = if (isSelected) ButtonDefaults.buttonElevation(defaultElevation = 2.dp) else null
    ) {
        Text(text = text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun CalculatorForm(
    metalName: String,
    weight: String,
    onWeightChange: (String) -> Unit,
    probaList: List<Double>,
    selectedProba: Double,
    onProbaChange: (Double) -> Unit,
    spotPrice: BigDecimal,
    spotValue: BigDecimal,
    markdown: BigDecimal,
    offerPrice: BigDecimal,
    viewModel: ZlotoSrebroViewModel
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "FORMULARZ WYCENY - $metalName", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(16.dp))

            // Weight input
            OutlinedTextField(
                value = weight,
                onValueChange = onWeightChange,
                label = { Text("Masa przedmiotu (g)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Purity choice
            Text(text = "Próba metalu (promile)", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                probaList.forEach { p ->
                    FilterChip(
                        selected = selectedProba == p,
                        onClick = { onProbaChange(p) },
                        label = { Text(text = p.toString()) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
            Spacer(modifier = Modifier.height(16.dp))

            // Calculation Breakdown Table
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(text = "Cena spot za gram:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                Text(text = formatPln(spotPrice), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(text = "Czysta zawartość kruszcu:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                val rawW = weight.toDoubleOrNull() ?: 0.0
                val pure = Calculators.obliczCzystyMetal(BigDecimal(rawW.toString()), selectedProba)
                Text(text = "${formatMass(pure)} g", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(text = "Wartość giełdowa (SPOT):", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                Text(text = formatPln(spotValue), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(text = "Korekta/Marża dealera:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                Text(text = "- " + formatPln(markdown), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color(0xFFC62828))
            }

            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(0.08f), RoundedCornerShape(8.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "NASZA OFERTA WYCENY:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = formatPln(offerPrice), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    // Trigger E2E Jan Kowalski flow starting with locking the price for the chosen weight
                    viewModel.e2eLockPrice(weight)
                    viewModel.currentScreen = "MOJE_METALE" // jump to user panel to see locked countdown
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Filled.FlashOn, contentDescription = "RFQ")
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "ZABLOKUJ CENĘ I POPROŚ O OFERTĘ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

// 4. JEWELRY SPECIAL BUY BACK FORM
@Composable
fun JewelryScreenContent(viewModel: ZlotoSrebroViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.currentScreen = "KALKULATOR" }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Powrót")
            }
            Text(text = "SKUP ZŁOTEJ BIŻUTERII", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "PARAMETRY FIZYCZNE BIŻUTERII", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = viewModel.calcJewelryWeight,
                    onValueChange = {
                        viewModel.calcJewelryWeight = it
                        viewModel.recalculateCalculators()
                    },
                    label = { Text("Masa brutto wyrobu (g)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Próba złota w wyrobie", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(333.0, 375.0, 585.0, 750.0, 916.0, 999.0).forEach { p ->
                        FilterChip(
                            selected = viewModel.calcJewelryProba == p,
                            onClick = {
                                viewModel.calcJewelryProba = p
                                viewModel.recalculateCalculators()
                            },
                            label = { Text(text = "Próba $p") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stones / ornaments
                Text(text = "Zawartość kamieni szlachetnych / innych materiałów", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Brak / Znikome", "Drobne diamenty (+150 PLN)", "Inne syntetyczne (odliczane z wagi)").forEach { item ->
                        FilterChip(
                            selected = viewModel.calcJewelryStones == item,
                            onClick = {
                                viewModel.calcJewelryStones = item
                                viewModel.recalculateCalculators()
                            },
                            label = { Text(text = item) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Condition
                Text(text = "Stan zachowania wyrobu", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("IDEALNY", "UZYTKOWY", "ZŁOM").forEach { cond ->
                        FilterChip(
                            selected = viewModel.calcJewelryCondition == cond,
                            onClick = {
                                viewModel.calcJewelryCondition = cond
                                viewModel.recalculateCalculators()
                            },
                            label = { Text(text = if (cond == "ZŁOM") "Złom złota (połamane)" else if (cond == "IDEALNY") "Stan sklepowy" else "Stan używany") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Assaying method
                Text(text = "Metoda badania w laboratorium", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("XRF (Spektrometr)", "Próba kwasowa", "Gęstość hydrostatyczna").forEach { m ->
                        FilterChip(
                            selected = viewModel.calcJewelryMethod == m,
                            onClick = {
                                viewModel.calcJewelryMethod = m
                                viewModel.recalculateCalculators()
                            },
                            label = { Text(text = m) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE57373).copy(0.1f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, contentDescription = "Ważne", tint = Color(0xFFC62828))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CENA ORIENTACYJNA: Końcowa wycena i testy próby złota zostaną przeprowadzone w laboratorium dealera za pomocą spektrometru XRF.",
                            fontSize = 11.sp,
                            color = Color(0xFFC62828),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Szacowana zawartość czystego Au:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                    val brute = viewModel.calcJewelryWeight.toDoubleOrNull() ?: 0.0
                    val pureAu = Calculators.obliczCzystyMetal(BigDecimal(brute.toString()), viewModel.calcJewelryProba)
                    Text(text = "${formatMass(pureAu)} g", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary.copy(0.08f), RoundedCornerShape(8.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "SZACOWANA OFERTA SKUPU:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        var finalVal = viewModel.calcJewelryResultPrice
                        if (viewModel.calcJewelryStones.contains("diamenty")) {
                            finalVal = finalVal.add(BigDecimal("150.00"))
                        }
                        Text(text = formatPln(finalVal), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.currentScreen = "MOJE_METALE"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "ZAREZERWUJ WIZYTĘ W PLACÓWCE SKUPU", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 5. CLIENT PORTFOLIO & JAN KOWALSKI DEMO JOURNEY
@Composable
fun ClientDashboardContent(viewModel: ZlotoSrebroViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Welcome client header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "DASHBOARD KLIENTA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(text = "Jan Kowalski (Warszawa)", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        Box(modifier = Modifier.size(6.dp).background(Color(0xFF2E7D32), CircleShape))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Status KYC: ZWERYFIKOWANY", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                    }
                }
                Icon(
                    imageVector = Icons.Filled.AccountCircle,
                    contentDescription = "Avatar",
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Balance sheets
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "STAN SALDA I PORTFEL METALI", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "DOSTĘPNA GOTÓWKA (PLN):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                        Text(text = formatPln(viewModel.clientPlnBalance), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val gVal = viewModel.clientGoldBalanceG.multiply(viewModel.computedGoldPlnG)
                        val sVal = viewModel.clientSilverBalanceG.multiply(viewModel.computedSilverPlnG)
                        val totalVal = gVal.add(sVal)
                        Text(text = "WARTOŚĆ METALU:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                        Text(text = formatPln(totalVal), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Złoto w skarbcach (depozyt):", fontSize = 13.sp)
                    }
                    Text(text = "${formatMass(viewModel.clientGoldBalanceG)} g", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(MaterialTheme.colorScheme.secondary, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Srebro w skarbcach (depozyt):", fontSize = 13.sp)
                    }
                    Text(text = "${formatMass(viewModel.clientSilverBalanceG)} g", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // E2E Active Price Lock segment
        if (viewModel.activeTxId != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "BLOKADA CENY AKTYWNA", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFE57373).copy(0.15f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(text = "${viewModel.activeTxSecondsLeft} s", fontWeight = FontWeight.ExtraBold, color = Color(0xFFC62828), fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = viewModel.activeTxStatus, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

                    if (viewModel.activeTxLockPrice != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Kwota transakcji:", fontSize = 13.sp)
                            Text(text = formatPln(viewModel.activeTxLockPrice!!), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { viewModel.e2eConfirmPurchase("SKARBIEC") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(text = "AKCEPTUJĘ (DEPOZYT)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                        }
                        Button(
                            onClick = { viewModel.e2eConfirmPurchase("DOSTAWA") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Text(text = "AKCEPTUJĘ (DOSTAWA)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondary)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // List of Client Physical Bars (Moje Sztabki & Paszporty)
        Text(text = "MOJE ASYGNATY & SZTABKI (PASZPORT METALU)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (viewModel.clientBars.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Brak przydzielonych sztabek w depozycie.", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f))
            }
        } else {
            for (bar in viewModel.clientBars) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "PASZPORT METALU: ${bar.id}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text(text = "PRZYDZIELONA", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Kruszec / Rafineria: ${bar.metal} | ${bar.rafineria}", fontSize = 12.sp)
                            Text(text = "Nr seryjny: ${bar.nrSeryjny}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Masa brutto: ${bar.masaG}g (Próba ${bar.proba})", fontSize = 12.sp)
                            Text(text = "Lokalizacja: ${bar.lokalizacja}", fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    // Sell back bar to dealer instantly
                                    viewModel.e2eSellBack(bar.id)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(text = "ODSPRZEDAJ DEALEROWI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // History of transactions
        Text(text = "HISTORIA ZAMÓWIEŃ & ROZLICZEŃ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (viewModel.clientTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Brak zarejestrowanych transakcji.", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f))
            }
        } else {
            viewModel.clientTransactions.forEach { tx ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                        .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = tx.produktNazwa, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        val formattedDate = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("pl", "PL")).format(Date(tx.timestamp))
                        Text(text = "$formattedDate | Typ: ${tx.typ}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val amt = BigDecimal(tx.kwotaKoncowa)
                        Text(text = formatPln(amt), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Button(
                            onClick = {
                                viewModel.selectedInvoiceTx = tx
                                viewModel.currentScreen = "DOKUMENTY"
                            },
                            modifier = Modifier.height(26.dp),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "FAKTURA", fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

// 6. DEALER DESK (ADMIN CONSOLE)
@Composable
fun DealerDeskContent(viewModel: ZlotoSrebroViewModel) {
    var activeSubscreen by remember { mutableStateOf("VAULTS") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "TERMINAL OPERACYJNY DEALERA", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))

        // Navigation sub tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            TabHeaderButton("SKARBCY", activeSubscreen == "VAULTS", Modifier.weight(1f)) { activeSubscreen = "VAULTS" }
            TabHeaderButton("ALERTY AML", activeSubscreen == "AML", Modifier.weight(1f)) { activeSubscreen = "AML" }
            TabHeaderButton("AUDYT", activeSubscreen == "AUDIT", Modifier.weight(1f)) { activeSubscreen = "AUDIT" }
            TabHeaderButton("LEDGER", activeSubscreen == "LEDGER", Modifier.weight(1f)) { activeSubscreen = "LEDGER" }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (activeSubscreen) {
            "VAULTS" -> {
                Text(text = "POLSKI SKARBIEC (STAN MAGAZYNOWY)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                viewModel.allSkarbce.forEach { vault ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(8.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "Skarbiec ${vault.miasto}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                val totG = BigDecimal(vault.zlotoMasaG).add(BigDecimal(vault.srebroMasaG))
                                val capLimit = BigDecimal(vault.pojemnoscKg).multiply(BigDecimal("1000"))
                                val utilPercent = totG.divide(capLimit, 4, RoundingMode.HALF_UP).multiply(BigDecimal("100")).toDouble()
                                Text(text = "${String.format(Locale.US, "%.1f", utilPercent)}% pojemności", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            // Capacity indicator progress bar
                            LinearProgressIndicator(
                                progress = (BigDecimal(vault.zlotoMasaG).add(BigDecimal(vault.srebroMasaG)).divide(BigDecimal(vault.pojemnoscKg).multiply(BigDecimal("1000")), 2, RoundingMode.HALF_UP).toFloat()).coerceAtMost(1f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "Złoto: ${formatMass(BigDecimal(vault.zlotoMasaG))} | Srebro: ${formatMass(BigDecimal(vault.srebroMasaG))}", fontSize = 11.sp)
                                Text(text = "Przydzielony: ${formatMass(BigDecimal(vault.przydzielonyMetalG))} | Dealer: ${formatMass(BigDecimal(vault.dealerMetalG))}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))
                            }
                        }
                    }
                }
            }
            "AML" -> {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "MONITORING TRANSAKCJI AML", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Box(modifier = Modifier.background(Color(0xFFE57373).copy(0.15f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Text(text = "SYSTEM REGULACYJNY", fontSize = 10.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                if (viewModel.allAmlAlerts.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(text = "Brak aktywnych ostrzeżeń AML.", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f))
                    }
                } else {
                    viewModel.allAmlAlerts.forEach { alert ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, if (alert.riskScore > 60) Color(0xFFC62828) else Color(0xFFEF6C00), RoundedCornerShape(8.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(text = "AML_ALERT: ${alert.typ}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (alert.riskScore > 60) Color(0xFFC62828) else Color(0xFFEF6C00))
                                    Text(text = "Risk Score: ${alert.riskScore}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = alert.szczegoly, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "Transakcja: ${alert.transakcjaId}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                                    Button(
                                        onClick = {
                                            // Close alert
                                            viewModel.allAmlAlerts = viewModel.allAmlAlerts.map {
                                                if (it.id == alert.id) it.copy(status = "ZAMKNIĘTY_ZAAKCEPTOWANY") else it
                                            }
                                        },
                                        modifier = Modifier.height(26.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = if (alert.status == "OTWARTY") "ZATWIERDŹ KYC" else "ZWERYFIKOWANO", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "AUDIT" -> {
                Text(text = "UZGODNIENIE SALD DOBOWYCH", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { viewModel.triggerDailyReconciliation(false) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text(text = "UZGODNIJ DOBĘ (SUKCES)", fontSize = 11.sp, color = Color.White)
                    }
                    Button(
                        onClick = { viewModel.triggerDailyReconciliation(true) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                    ) {
                        Text(text = "TRIGGER RECON EXCEPTION", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                viewModel.allUzgodnienia.forEach { u ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(1.dp, if (u.czyWyjatek) Color(0xFFC62828) else Color(0xFF2E7D32), RoundedCornerShape(8.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "RAPORT BILANSU: ${u.dataUzgodnienia}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = u.status,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (u.czyWyjatek) Color(0xFFC62828) else Color(0xFF2E7D32)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = u.rozbieznosci, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.1f))
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "Złoto fizyczne: ${formatMass(BigDecimal(u.metalFizycznyZlotoG))} / Ledger: ${formatMass(BigDecimal(u.metalLedgerZlotoG))}", fontSize = 11.sp)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(text = "Srebro fizyczne: ${formatMass(BigDecimal(u.metalFizycznySrebroG))} / Ledger: ${formatMass(BigDecimal(u.metalLedgerSrebroG))}", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            "LEDGER" -> {
                Text(text = "KSIĘGA GŁÓWNA - WYCIĄG Z LEDGERA", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                viewModel.allLedgerZapisy.forEach { zapis ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .border(0.5.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = zapis.opis, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "Debet: ${zapis.kontoDebet} | Kredyt: ${zapis.kontoKredyt}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                        }
                        Text(text = formatPln(BigDecimal(zapis.wartoscPln)), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Synthetic Massive simulation trigger card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "GENERATOR SYMULACJI RYNKOWEJ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Uruchomienie generatora zasymuluje 10 000 klientów, 50 magazynów, 20 skarbców oraz ogromne wolumeny transakcji w bazie danych do analizy ryzyka rynkowego i płynności.", fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                if (viewModel.isSimulating) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Text(text = viewModel.simulationProgress, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                } else {
                    Button(
                        onClick = { viewModel.triggerMassiveSimulation() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "URUCHOM SYMULACJĘ (SEED 42)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// 7. POLAND MAP (INTERACTIVE CUSTOM CANVAS MAP)
@Composable
fun PolandMapContent(viewModel: ZlotoSrebroViewModel) {
    var selectedCityInfo by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(text = "POLSKA MAPA HANDLOWA & SKARBCY", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Lokalizacje skarbców, magazynów oraz punktów badania metali szlachetnych.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f))

        Spacer(modifier = Modifier.height(16.dp))

        // Poland Map Vector drawing inside Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.15f), RoundedCornerShape(12.dp))
                .clickable {
                    // Click somewhere on canvas clears or shows info
                }
                .drawBehind {
                    // Draw a simplified silhouette outline of Poland
                    val width = size.width
                    val height = size.height

                    val shapeBrush = Brush.linearGradient(
                        colors = listOf(Color(0xFF1F2937), Color(0xFF111827))
                    )

                    // Standard Polish geographical outline points scaled to fit Canvas
                    val polandPath = androidx.compose.ui.graphics.Path().apply {
                        moveTo(width * 0.45f, height * 0.12f) // Baltic Sea start
                        lineTo(width * 0.55f, height * 0.12f)
                        lineTo(width * 0.70f, height * 0.15f) // Gdansk Bay
                        lineTo(width * 0.85f, height * 0.20f) // Suwalki corner
                        lineTo(width * 0.88f, height * 0.40f) // Eastern border (Bialystok)
                        lineTo(width * 0.82f, height * 0.65f) // Lublin corner
                        lineTo(width * 0.75f, height * 0.85f) // Bieszczady corner
                        lineTo(width * 0.50f, height * 0.88f) // Tatry (Zakopane)
                        lineTo(width * 0.25f, height * 0.82f) // Sudety (Klodzko)
                        lineTo(width * 0.15f, height * 0.65f) // Western border (Zgorzelec)
                        lineTo(width * 0.12f, height * 0.35f) // Szczecin Bay
                        lineTo(width * 0.30f, height * 0.20f) // Baltic Coast West
                        close()
                    }

                    drawPath(
                        path = polandPath,
                        brush = shapeBrush
                    )

                    drawPath(
                        path = polandPath,
                        color = Color.White.copy(0.15f),
                        style = Stroke(width = 2f)
                    )

                    // City coordinates overlay (Fictional coordinates representing real Poland cities relative to canvas)
                    val cities = listOf(
                        Triple("Warszawa", width * 0.65f, height * 0.48f),
                        Triple("Kraków", width * 0.58f, height * 0.80f),
                        Triple("Wrocław", width * 0.35f, height * 0.68f),
                        Triple("Poznań", width * 0.34f, height * 0.44f),
                        Triple("Katowice", width * 0.51f, height * 0.78f)
                    )

                    // Draw City pins
                    cities.forEach { (name, px, py) ->
                        drawCircle(
                            color = Color(0xFFC5A059),
                            radius = 18f,
                            center = Offset(px, py)
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 6f,
                            center = Offset(px, py)
                        )
                    }
                }
        ) {
            // Hotspots click actions simulation via buttons on top of absolute layout canvas
            Box(modifier = Modifier.fillMaxSize()) {
                CityPinButton("Warszawa", 0.65f, 0.48f, "Warszawa: Skarbiec Główny (Złoto: 50kg, Silver: 200kg). Wykorzystanie: 25.0%") { selectedCityInfo = it }
                CityPinButton("Kraków", 0.58f, 0.80f, "Kraków: Skarbiec Małopolski (Złoto: 15kg, Silver: 80kg). Wykorzystanie: 19.0%") { selectedCityInfo = it }
                CityPinButton("Wrocław", 0.35f, 0.68f, "Wrocław: Skarbiec Dolnośląski (Złoto: 10kg, Silver: 50kg). Wykorzystanie: 15.0%") { selectedCityInfo = it }
                CityPinButton("Poznań", 0.34f, 0.44f, "Poznań: Punkt Skupu i Depozyt (Złoto: 8kg, Silver: 30kg). Wykorzystanie: 12.6%") { selectedCityInfo = it }
                CityPinButton("Katowice", 0.51f, 0.78f, "Katowice: Skarbiec Górnośląski (Złoto: 20kg, Silver: 120kg). Wykorzystanie: 23.3%") { selectedCityInfo = it }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "SZCZEGÓŁY WYBRANEJ LOKALIZACJI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = selectedCityInfo ?: "Kliknij dowolny złoty punkt na mapie Polski powyżej, aby zobaczyć szczegółowe dane techniczne skarbca i wolumeny depozytów.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun BoxScope.CityPinButton(name: String, rx: Float, ry: Float, info: String, onClick: (String) -> Unit) {
    val configuration = LocalConfiguration.current
    val w = configuration.screenWidthDp.dp - 32.dp // approximate canvas boundary
    val h = 300.dp

    Box(
        modifier = Modifier
            .offset(x = w * rx - 18.dp, y = h * ry - 18.dp)
            .size(36.dp)
            .clickable { onClick(info) }
    )
}

// 8. PDF-STYLE DOCUMENTS, INVOICES & STATEMENTS VIEWER
@Composable
fun DocumentViewerContent(viewModel: ZlotoSrebroViewModel) {
    val tx = viewModel.selectedInvoiceTx

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.currentScreen = "MOJE_METALE" }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Powrót")
            }
            Text(text = "DOKUMENTY I POTWIERDZENIA", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (tx == null) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(text = "Wybierz transakcję z historii konta, aby wygenerować dokument.", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f))
            }
        } else {
            // Elegant PDF layout representation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(0.2f), RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    // Document header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "ZŁOTO I SREBRO S.A.", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color.Black)
                            Text(text = "ul. Marszałkowska 100/102", fontSize = 10.sp, color = Color.Gray)
                            Text(text = "00-010 Warszawa", fontSize = 10.sp, color = Color.Gray)
                            Text(text = "NIP: 525-000-11-22", fontSize = 10.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "FAKTURA VAT", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                            Text(text = "Nr: FV/${tx.id}", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            val formattedDate = SimpleDateFormat("dd.MM.yyyy", Locale("pl", "PL")).format(Date(tx.timestamp))
                            Text(text = "Data wystawienia: $formattedDate", fontSize = 10.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Client details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "SPRZEDAWCA / DEALER", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                            Text(text = "Złoto i Srebro S.A.", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "NABYWCA / KLIENT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                            Text(text = "Jan Kowalski", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                            Text(text = "Adres: Warszawa, Polska", fontSize = 10.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Line items table
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFEEEEEE))
                            .padding(8.dp)
                    ) {
                        Text(text = "Nazwa towaru / usługi", modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                        Text(text = "Masa", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End)
                        Text(text = "VAT", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End)
                        Text(text = "Wartość brutto", modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                        Text(text = tx.produktNazwa, modifier = Modifier.weight(2f), fontSize = 11.sp, color = Color.Black)
                        Text(text = "${tx.masaG}g", modifier = Modifier.weight(1f), fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End)
                        val vatText = if (tx.vatStawka == 0.0) "zw." else "${tx.vatStawka}%"
                        Text(text = vatText, modifier = Modifier.weight(0.5f), fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End)
                        val priceAmt = BigDecimal(tx.kwotaKoncowa)
                        Text(text = formatPln(priceAmt), modifier = Modifier.weight(1.5f), fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                    Divider(color = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Totals
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.End
                    ) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.width(200.dp)) {
                            Text(text = "Razem Netto:", fontSize = 11.sp, color = Color.Gray)
                            val finalP = BigDecimal(tx.kwotaKoncowa)
                            Text(text = formatPln(finalP), fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.width(200.dp)) {
                            Text(text = "Podatek VAT:", fontSize = 11.sp, color = Color.Gray)
                            Text(text = "0,00 zł", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.width(200.dp)) {
                            Text(text = "SUMA DO ZAPŁATY:", fontSize = 13.sp, color = Color.Black, fontWeight = FontWeight.ExtraBold)
                            val finalP = BigDecimal(tx.kwotaKoncowa)
                            Text(text = formatPln(finalP), fontSize = 13.sp, color = Color.Black, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    // Split Payment Badge if applicable
                    if (tx.mppOdbiorca) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFFC62828), RoundedCornerShape(4.dp))
                                .background(Color(0xFFC62828).copy(0.05f))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = "METODA PODZIELONEJ PŁATNOŚCI (MPP) - WYMAGANA",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFFC62828)
                                )
                                Text(
                                    text = "Transakcja podlega mechanizmowi podzielonej płatności na podstawie polskich przepisów podatkowych ze względu na przekroczenie limitu 15 000 PLN na wyroby z metali szlachetnych.",
                                    fontSize = 10.sp,
                                    color = Color.Black.copy(0.8f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    // Signatures
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(150.dp)) {
                            Divider(color = Color.LightGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Odebrał (Jan Kowalski)", fontSize = 9.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(150.dp)) {
                            Divider(color = Color.LightGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Wystawił (Dealer)", fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
