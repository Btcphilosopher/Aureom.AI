package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MutedGold,
    onPrimary = DeepGraphite,
    primaryContainer = Steel,
    onPrimaryContainer = Color.White,
    secondary = Silver,
    onSecondary = DeepGraphite,
    background = DeepGraphite,
    onBackground = TextLight,
    surface = DarkNavy,
    onSurface = TextLight,
    surfaceVariant = Steel,
    onSurfaceVariant = TextLight,
    error = CrimsonAlert,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = MutedGold,
    onPrimary = Color.White,
    primaryContainer = RichGoldAccent,
    onPrimaryContainer = DeepGraphite,
    secondary = Steel,
    onSecondary = Color.White,
    background = WarmWhite,
    onBackground = TextDark,
    surface = CardBackgroundLight,
    onSurface = TextDark,
    surfaceVariant = SoftGray,
    onSurfaceVariant = TextDark,
    error = CrimsonAlert,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We intentionally force darkTheme or let it follow system,
    // let's follow the system theme but design the look as an ultra-high-end banking terminal
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
