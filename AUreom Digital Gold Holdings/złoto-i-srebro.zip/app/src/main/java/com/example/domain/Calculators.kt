package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode

object Calculators {
    // 1 oz t = 31.1034768 g
    val OUNCE_TO_GRAM_FACTOR = BigDecimal("31.1034768")
    val KG_TO_GRAM_FACTOR = BigDecimal("1000")

    fun gramsToOunces(grams: BigDecimal): BigDecimal {
        return grams.divide(OUNCE_TO_GRAM_FACTOR, 8, RoundingMode.HALF_UP)
    }

    fun ouncesToGrams(ounces: BigDecimal): BigDecimal {
        return ounces.multiply(OUNCE_TO_GRAM_FACTOR).setScale(8, RoundingMode.HALF_UP)
    }

    fun kgToOunces(kg: BigDecimal): BigDecimal {
        val grams = kg.multiply(KG_TO_GRAM_FACTOR)
        return gramsToOunces(grams)
    }

    fun ouncesToKg(ounces: BigDecimal): BigDecimal {
        val grams = ouncesToGrams(ounces)
        return grams.divide(KG_TO_GRAM_FACTOR, 8, RoundingMode.HALF_UP)
    }

    /**
     * Silnik Próby (Purity Engine)
     * wzór: masa brutto * próba_ułamek = masa czystego metalu
     * np. 100g próby 999.9 (0.9999) = 99.99g czystego metalu
     * np. 100g próby 585 (0.585) = 58.5g czystego metalu
     */
    fun obliczCzystyMetal(masaBrutto: BigDecimal, proba: Double): BigDecimal {
        val probaUlemek = BigDecimal(proba.toString()).divide(BigDecimal("1000"), 6, RoundingMode.HALF_UP)
        return masaBrutto.multiply(probaUlemek).setScale(4, RoundingMode.HALF_UP)
    }
}
