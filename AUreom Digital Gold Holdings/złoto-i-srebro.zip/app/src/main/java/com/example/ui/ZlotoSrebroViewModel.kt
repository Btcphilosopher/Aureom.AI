package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.domain.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ZlotoSrebroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)

    // Current Navigation Screen
    var currentScreen by mutableStateOf("HOME")

    // Price Feeds & Markets
    var goldSpotUsd by mutableStateOf(BigDecimal("2648.50"))
    var silverSpotUsd by mutableStateOf(BigDecimal("31.25"))
    var usdPln by mutableStateOf(BigDecimal("3.9180"))
    var computedGoldPlnG by mutableStateOf(BigDecimal("333.68"))
    var computedSilverPlnG by mutableStateOf(BigDecimal("3.94"))
    var goldChangePercent by mutableStateOf("+0.34%")
    var silverChangePercent by mutableStateOf("-0.12%")

    // Client Form & Calculators Inputs
    var calcGoldWeight by mutableStateOf("10.0")
    var calcGoldProba by mutableStateOf(999.9) // 999.9, 585, etc.
    var calcGoldResultPrice by mutableStateOf(BigDecimal.ZERO)
    var calcGoldSpotValue by mutableStateOf(BigDecimal.ZERO)
    var calcGoldMarkdown by mutableStateOf(BigDecimal.ZERO)

    var calcSilverWeight by mutableStateOf("100.0")
    var calcSilverProba by mutableStateOf(999.0)
    var calcSilverResultPrice by mutableStateOf(BigDecimal.ZERO)
    var calcSilverSpotValue by mutableStateOf(BigDecimal.ZERO)
    var calcSilverMarkdown by mutableStateOf(BigDecimal.ZERO)

    // Jewelry specific inputs
    var calcJewelryWeight by mutableStateOf("18.5")
    var calcJewelryProba by mutableStateOf(585.0) // 585, 333, etc.
    var calcJewelryStones by mutableStateOf("Brak / Znikome")
    var calcJewelryCondition by mutableStateOf("UZYTKOWY") // "IDEALNY", "UZYTKOWY", "ZŁOM"
    var calcJewelryMethod by mutableStateOf("XRF (Spektrometr)") // "XRF (Spektrometr)", "Próba kwasowa", "Gęstość hydrostatyczna"
    var calcJewelryResultPrice by mutableStateOf(BigDecimal.ZERO)

    // E2E Jan Kowalski Demo Process State
    var activeTxId by mutableStateOf<String?>(null)
    var activeTxLockPrice by mutableStateOf<BigDecimal?>(null)
    var activeTxSecondsLeft by mutableStateOf(60)
    var activeTxTimerJob by mutableStateOf<Job?>(null)
    var activeTxStatus by mutableStateOf("")

    // Simulated Lists for UI Display (updated reactively)
    var clientPlnBalance by mutableStateOf(BigDecimal("100000.00"))
    var clientGoldBalanceG by mutableStateOf(BigDecimal("0.0"))
    var clientSilverBalanceG by mutableStateOf(BigDecimal("0.0"))
    var clientTransactions by mutableStateOf<List<TransakcjaEntity>>(emptyList())
    var clientBars by mutableStateOf<List<SztabkaEntity>>(emptyList())

    // Admin Panel Lists
    var allSkarbce by mutableStateOf<List<SkarbiecEntity>>(emptyList())
    var allTransactions by mutableStateOf<List<TransakcjaEntity>>(emptyList())
    var allLedgerZapisy by mutableStateOf<List<LedgerZapisEntity>>(emptyList())
    var allAuditEvents by mutableStateOf<List<AuditLogEventEntity>>(emptyList())
    var allAmlAlerts by mutableStateOf<List<AmlAlertEntity>>(emptyList())
    var allUzgodnienia by mutableStateOf<List<UzgodnienieEntity>>(emptyList())

    // Simulated Invoice details
    var selectedInvoiceTx by mutableStateOf<TransakcjaEntity?>(null)

    // Simulation Loading States
    var isSimulating by mutableStateOf(false)
    var simulationProgress by mutableStateOf("")

    // Price Ticker background loop
    private var priceTickerJob: Job? = null

    init {
        viewModelScope.launch {
            // Seed Database with Jan Kowalski, vaults, standard prices and physical bars
            DemoSimulationManager.seedDatabase(db)
            refreshAllState()
            recalculateCalculators()
            startPriceTicker()
        }
    }

    private fun startPriceTicker() {
        priceTickerJob?.cancel()
        priceTickerJob = viewModelScope.launch {
            while (true) {
                delay(8000) // update price ticks every 8s
                // Generate a random swing (-0.1% to +0.15%)
                val goldSwing = 1.0 + ((-10..15).random() / 10000.0)
                val silverSwing = 1.0 + ((-15..20).random() / 10000.0)
                val usdPlnSwing = 1.0 + ((-5..5).random() / 10000.0)

                goldSpotUsd = goldSpotUsd.multiply(BigDecimal(goldSwing.toString())).setScale(2, RoundingMode.HALF_UP)
                silverSpotUsd = silverSpotUsd.multiply(BigDecimal(silverSwing.toString())).setScale(2, RoundingMode.HALF_UP)
                usdPln = usdPln.multiply(BigDecimal(usdPlnSwing.toString())).setScale(4, RoundingMode.HALF_UP)

                val calc = BusinessEngines.przeliczCenySpot(goldSpotUsd, silverSpotUsd, usdPln)
                computedGoldPlnG = calc.goldSpotPlnPerGram
                computedSilverPlnG = calc.silverSpotPlnPerGram

                goldChangePercent = if (goldSwing >= 1.0) "+${String.format(Locale.US, "%.3f", (goldSwing - 1.0) * 100)}%" else "-${String.format(Locale.US, "%.3f", (1.0 - goldSwing) * 100)}%"
                silverChangePercent = if (silverSwing >= 1.0) "+${String.format(Locale.US, "%.3f", (silverSwing - 1.0) * 100)}%" else "-${String.format(Locale.US, "%.3f", (1.0 - silverSwing) * 100)}%"

                // Log price updated event to database
                db.cenySpotDao().insertSpot(
                    CenySpotEntity(
                        goldSpotUsd = goldSpotUsd.toPlainString(),
                        silverSpotUsd = silverSpotUsd.toPlainString(),
                        usdPln = usdPln.toPlainString(),
                        eurPln = "4.3120",
                        gbpPln = "5.1240",
                        chfPln = "4.5680",
                        timestamp = System.currentTimeMillis(),
                        zrodlo = "LME Live Ticker",
                        status = "AKTYWNY"
                    )
                )

                recalculateCalculators()
                refreshAllState()
            }
        }
    }

    suspend fun refreshAllState() {
        // Refresh User Wallet State
        val user = db.uzytkownikDao().getUzytkownik("KOWALSKI_JAN")
        if (user != null) {
            clientPlnBalance = BigDecimal(user.budzetPln)
        }

        // Fetch User Bars
        val userBarsList = db.sztabkaDao().getSztabkiByOwner("KOWALSKI_JAN")
        clientBars = userBarsList
        var gBal = BigDecimal.ZERO
        var sBal = BigDecimal.ZERO
        for (bar in userBarsList) {
            val m = BigDecimal(bar.masaG)
            if (bar.metal == "ZŁOTO") {
                gBal = gBal.add(m)
            } else {
                sBal = sBal.add(m)
            }
        }
        clientGoldBalanceG = gBal
        clientSilverBalanceG = sBal

        // Fetch User transactions
        clientTransactions = db.transakcjaDao().getTransakcjeByKlient("KOWALSKI_JAN")

        // Fetch Admin structures
        allSkarbce = db.skarbiecDao().getAllSkarbce()
        allTransactions = db.transakcjaDao().getAllTransakcje()
        allLedgerZapisy = db.ledgerDao().getAllZapisy()
        allAuditEvents = db.auditLogDao().getAllEvents()
        allAmlAlerts = db.amlAlertDao().getAllAlerts()
        allUzgodnienia = db.uzgodnienieDao().getAllUzgodnienia()
    }

    fun recalculateCalculators() {
        // Gold Calculator calculation
        val gWeight = calcGoldWeight.toBigDecimalOrNull() ?: BigDecimal.ZERO
        val goldDetails = BusinessEngines.obliczCeneSkupu(
            spotPerGram = computedGoldPlnG,
            proba = calcGoldProba,
            masaBrutto = gWeight,
            stanPrzedmiotu = "IDEALNY",
            plynnoscRynkowa = "WYSOKA",
            poziomZapasow = "NORMALNY",
            zmiennoscSpot = "NISKA"
        )
        calcGoldResultPrice = goldDetails["cenaOferowana"] ?: BigDecimal.ZERO
        calcGoldSpotValue = goldDetails["wartoscSpotMetalu"] ?: BigDecimal.ZERO
        calcGoldMarkdown = goldDetails["kwotaKorekty"] ?: BigDecimal.ZERO

        // Silver Calculator calculation
        val sWeight = calcSilverWeight.toBigDecimalOrNull() ?: BigDecimal.ZERO
        val silverDetails = BusinessEngines.obliczCeneSkupu(
            spotPerGram = computedSilverPlnG,
            proba = calcSilverProba,
            masaBrutto = sWeight,
            stanPrzedmiotu = "IDEALNY",
            plynnoscRynkowa = "WYSOKA",
            poziomZapasow = "NORMALNY",
            zmiennoscSpot = "NISKA"
        )
        calcSilverResultPrice = silverDetails["cenaOferowana"] ?: BigDecimal.ZERO
        calcSilverSpotValue = silverDetails["wartoscSpotMetalu"] ?: BigDecimal.ZERO
        calcSilverMarkdown = silverDetails["kwotaKorekty"] ?: BigDecimal.ZERO

        // Jewelry buy back Calculator calculation
        val jWeight = calcJewelryWeight.toBigDecimalOrNull() ?: BigDecimal.ZERO
        val jewelryDetails = BusinessEngines.obliczCeneSkupu(
            spotPerGram = computedGoldPlnG,
            proba = calcJewelryProba,
            masaBrutto = jWeight,
            stanPrzedmiotu = calcJewelryCondition,
            plynnoscRynkowa = "ŚREDNIA",
            poziomZapasow = "NORMALNY",
            zmiennoscSpot = "NISKA"
        )
        calcJewelryResultPrice = jewelryDetails["cenaOferowana"] ?: BigDecimal.ZERO
    }

    // Jan Kowalski - E2E Step 1: Lock Price for 100g gold bar
    fun e2eLockPrice(masaG: String) {
        viewModelScope.launch {
            activeTxId = DemoSimulationManager.wykonajKrokKupna(db, masaG) { status ->
                activeTxStatus = status
            }
            // Fetch locked price
            val tx = db.transakcjaDao().getTransakcja(activeTxId ?: "")
            if (tx != null) {
                activeTxLockPrice = BigDecimal(tx.kwotaKoncowa)
            }
            activeTxSecondsLeft = 60
            startLockTimer()
            refreshAllState()
        }
    }

    private fun startLockTimer() {
        activeTxTimerJob?.cancel()
        activeTxTimerJob = viewModelScope.launch {
            while (activeTxSecondsLeft > 0) {
                delay(1000)
                activeTxSecondsLeft--
            }
            // Expired
            if (activeTxId != null) {
                val tx = db.transakcjaDao().getTransakcja(activeTxId ?: "")
                if (tx != null && tx.status == "BLOKADA_60S") {
                    db.transakcjaDao().insertTransakcja(tx.copy(status = "WYGASLE"))
                    db.auditLogDao().insertEvent(
                        AuditLogEventEntity(
                            typZdarzenia = "OfertaWygasla",
                            szczegoly = "Oferta zakupu ${tx.id} wygasła. Limit 60 sekund minął.",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                    activeTxStatus = "OFERTA WYGASŁA. Klient musi uzyskać nową cenę."
                    refreshAllState()
                }
            }
        }
    }

    // Jan Kowalski - E2E Step 2: Confirm Purchase (Payment and physical bar allocation)
    fun e2eConfirmPurchase(lokalizacja: String) {
        viewModelScope.launch {
            val success = DemoSimulationManager.zatwierdzKupnoKowalski(db, activeTxId ?: "", lokalizacja) { status ->
                activeTxStatus = status
            }
            if (success) {
                activeTxTimerJob?.cancel()
                activeTxId = null
                activeTxLockPrice = null
            }
            refreshAllState()
        }
    }

    // Jan Kowalski - E2E Step 3: Sell Back the bar
    fun e2eSellBack(barId: String) {
        viewModelScope.launch {
            DemoSimulationManager.odsprzedajSztabkeKowalski(db, barId) { status ->
                activeTxStatus = status
            }
            refreshAllState()
        }
    }

    // Run massive synthetic simulation worker
    fun triggerMassiveSimulation() {
        if (isSimulating) return
        isSimulating = true
        viewModelScope.launch {
            DemoSimulationManager.runMassiveSimulation(db) { progress ->
                simulationProgress = progress
            }
            isSimulating = false
            refreshAllState()
        }
    }

    // Run Daily Reconciliation check
    fun triggerDailyReconciliation(wywolajBlad: Boolean) {
        viewModelScope.launch {
            DemoSimulationManager.uruchomUzgodnienie(db, wywolajBlad)
            refreshAllState()
        }
    }

    override fun onCleared() {
        super.onCleared()
        priceTickerJob?.cancel()
        activeTxTimerJob?.cancel()
    }
}
