package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Jinrui Prestigious Color Scheme
val InkBlackBg = Color(0xFF0F0E0D)
val WarmSurface = Color(0xFF161513)
val CardSurface = Color(0xFF22201D)
val BorderBronze = Color(0xFF332F2A)

val GoldPrimary = Color(0xFFC5A059)
val GoldSecondary = Color(0xFF8F7643)
val WarmIvory = Color(0xFFEFECE6)
val ChineseRed = Color(0xFF9E2A2B)
val DarkJade = Color(0xFF2E6540)
val MutedGrey = Color(0xFF8E8A82)
val GoldAccent = Color(0xFFF9E7B9)
