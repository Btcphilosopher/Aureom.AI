package com.example.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// Core Metals & Standard Units
enum class MetalType(val code: String, val cnName: String, val enName: String, val defaultPurity: Int) {
    GOLD("Au", "黄金", "Gold", 9999),
    SILVER("Ag", "白银", "Silver", 9990),
    PLATINUM("Pt", "铂金", "Platinum", 9995)
}

// User role permissions
enum class UserRole(val cnName: String, val enName: String) {
    ADMIN("管理员", "Administrator"),
    TRADER("交易员", "Trader"),
    RISK_MANAGER("风控经理", "Risk Manager"),
    TREASURY_FINANCE("财务主管", "Treasury & Finance"),
    VAULT_KEEPER("金库管理员", "Vault Keeper"),
    MERCHANT("零售商户", "Retail Merchant")
}

// Client categories for SGE network
enum class ClientCategory(val cnName: String, val enName: String) {
    RETAIL("零售客户", "Retail Customer"),
    JEWELLER("珠宝商", "Jeweller"),
    BULLION_TRADER("黄金贸易商", "Bullion Trader"),
    REFINERY("精炼企业", "Refinery"),
    FINANCIAL_INSTITUTION("金融机构", "Financial Institution"),
    FAMILY_OFFICE("家族办公室", "Family Office")
}

// Vault locations in Chinese market
enum class VaultLocation(val cnName: String, val enName: String, val isInternational: Boolean = false) {
    SHANGHAI("上海金库", "Shanghai Vault"),
    SHENZHEN("深圳金库", "Shenzhen Vault"),
    BEIJING("北京金库", "Beijing Vault"),
    GUANGZHOU("广州金库", "Guangzhou Vault"),
    ZHENGZHOU("郑州金库", "Zhengzhou Vault"),
    HONG_KONG("香港离岸金库", "Hong Kong Offshore", true)
}

// Client profile
data class ClientProfile(
    val id: String,
    val nameCn: String,
    val nameEn: String,
    val cityCn: String,
    val cityEn: String,
    val category: ClientCategory,
    val tier: String, // V1 - V5
    val creditLimit: BigDecimal,
    var creditUsed: BigDecimal,
    val riskLevel: String, // 低 / 中 / 高
    val settlementTerms: String, // T+0, T+1, T+2
    val kycStatus: String, // 已认证 / 审核中
    val averageGoldCost: BigDecimal,
    val goldExposure: BigDecimal,
    val silverExposure: BigDecimal
) {
    fun remainingCredit(): BigDecimal = creditLimit.subtract(creditUsed).max(BigDecimal.ZERO)
}

// Physical Bullion Bar Entity
data class BullionBar(
    val id: String,
    val serialNumber: String,
    val metalType: MetalType,
    val purity: Int, // e.g. 9999 means 99.99%
    val grossWeight: BigDecimal, // in grams
    val manufacturer: String,
    val productionDate: String,
    val certificateNo: String,
    var location: VaultLocation,
    var ownerNameCn: String,
    var ownerNameEn: String,
    var statusCn: String,
    var statusEn: String
) {
    // Calculates fine weight: Gross Weight * Purity / 10000
    fun getFineWeight(): BigDecimal {
        return grossWeight.multiply(BigDecimal(purity))
            .divide(BigDecimal(10000), 4, RoundingMode.HALF_UP)
    }
}

// Request for Quote (RFQ)
data class RFQRecord(
    val id: String,
    val clientName: String,
    val metalType: MetalType,
    val spec: String, // e.g. "Au99.99", "1kg Bar"
    val purity: Int,
    val quantityGrams: BigDecimal,
    val deliveryLocation: VaultLocation,
    val settlementDate: String,
    val basePrice: BigDecimal, // CNY/g base
    var dealerBid: BigDecimal = BigDecimal.ZERO,
    var dealerOffer: BigDecimal = BigDecimal.ZERO,
    val status: String, // "待处理" / "已报价" / "已成交" / "已过期"
    val expiryTimestamp: Long,
    val traderName: String
)

// Execution / Trade
data class MetalTrade(
    val id: String,
    val rfqId: String?,
    val clientName: String,
    val metalType: MetalType,
    val productSpec: String,
    val quantityGrams: BigDecimal,
    val executedPrice: BigDecimal, // CNY/g
    val premium: BigDecimal, // CNY/g
    val side: String, // "BUY" (买入) / "SELL" (卖出)
    val settlementDate: String,
    val deliveryLocation: VaultLocation,
    val timestamp: String,
    val totalAmount: BigDecimal,
    val status: String // "待交割", "运输中", "已交割", "已结算"
)

// Double-Entry Accounting Ledger Entry
data class LedgerEntry(
    val id: String,
    val timestamp: String,
    val accountDebit: String, // Account to debit
    val accountCredit: String, // Account to credit
    val amount: BigDecimal,
    val currency: String, // CNY, AuGrams, AgKilograms
    val tradeId: String,
    val memoCn: String,
    val memoEn: String
)

// Assay / Testing Record
data class AssayRecord(
    val id: String,
    val barSerial: String,
    val metalType: MetalType,
    val grossWeight: BigDecimal,
    val declaredPurity: Int,
    val assayedPurity: Int,
    val method: String, // "XRF检测", "火法熔炼", "高精度比重"
    val agency: String, // "国家首饰质量监督检验中心", "上海黄金交易所联合实验室"
    val inspectorCn: String,
    val date: String,
    val certificateNo: String,
    val status: String // "收货", "取样", "检测", "复核", "已确认"
)

// Retail Jewellery Product
data class JewelleryProduct(
    val id: String,
    val barcode: String,
    val nameCn: String,
    val nameEn: String,
    val categoryCn: String,
    val categoryEn: String,
    val purity: Int, // 750 (18K), 916 (22K), 999 (足金), 9999 (万足金)
    val grossWeight: BigDecimal, // grams
    val netGoldWeight: BigDecimal, // grams
    val gemWeightCarat: BigDecimal,
    val makingChargePerGram: BigDecimal, //工费
    val certificateNo: String,
    val imagePrompt: String
) {
    fun calculateRetailPrice(goldPriceToday: BigDecimal, discount: BigDecimal = BigDecimal.ONE): BigDecimal {
        val baseGoldCost = netGoldWeight.multiply(goldPriceToday)
        val makingCharge = grossWeight.multiply(makingChargePerGram)
        val grossCost = baseGoldCost.add(makingCharge)
        // Add 13% tax & profit margin estimate
        val taxAndMargin = grossCost.multiply(BigDecimal("0.15"))
        val subtotal = grossCost.add(taxAndMargin)
        return subtotal.multiply(discount).setScale(2, RoundingMode.HALF_UP)
    }
}

// Procedural Deterministic Data Generator
object JinruiDataGenerator {
    private val random = Random(888) // Reproducible seed

    val CHINESE_CITIES = listOf("上海", "北京", "深圳", "广州", "杭州", "苏州", "成都", "重庆", "武汉", "西安", "郑州", "沈阳", "昆明", "南京")
    val ENGLISH_CITIES = listOf("Shanghai", "Beijing", "Shenzhen", "Guangzhou", "Hangzhou", "Suzhou", "Chengdu", "Chongqing", "Wuhan", "Xi'an", "Zhengzhou", "Shenyang", "Kunming", "Nanjing")

    val CLIENT_NAMES_CN = listOf(
        "华东金业贸易有限公司", "深圳瑞华黄金珠宝集团", "国信贵金属资产管理公司", "上海城投贵金属储备基金", "精艺黄金首饰制造厂",
        "大湾区贵金属精炼厂", "紫金大宗商品投资公司", "浙商黄金珠宝零售连锁", "中原金银冶炼集团", "西北贵金属储备托管银行",
        "西南黄金艺术品公司", "苏杭家私与纪念金币行", "华北工业白银商贸公司", "陆家嘴大宗商品对冲基金"
    )
    val CLIENT_NAMES_EN = listOf(
        "East China Gold Trading Co.", "Shenzhen Ruihua Jewelry Group", "Guoxin Precious Metals Asset Management", "Shanghai Urban Precious Metal Fund", "Jingyi Gold Jewelry Manufacturing",
        "Greater Bay Area Refining Corp.", "Zijin Commodity Investments Ltd.", "Zheshang Gold Retail Chain", "Zhongyuan Gold & Silver Smelting Group", "Northwest Precious Metals Vault & Bank",
        "Southwest Gold Artworks Co.", "Suhang Commemorative Coin Dealers", "North China Industrial Silver Trading", "Lujiazui Commodities Hedge Fund"
    )

    // Generate static list of 12 robust client profiles
    fun generateClients(): List<ClientProfile> {
        return CLIENT_NAMES_CN.mapIndexed { idx, cnName ->
            val cityIdx = idx % CHINESE_CITIES.size
            val category = when (idx % 6) {
                0 -> ClientCategory.BULLION_TRADER
                1 -> ClientCategory.JEWELLER
                2 -> ClientCategory.FINANCIAL_INSTITUTION
                3 -> ClientCategory.REFINERY
                4 -> ClientCategory.FAMILY_OFFICE
                else -> ClientCategory.RETAIL
            }
            val limit = BigDecimal(10000000 + (idx * 5000000))
            ClientProfile(
                id = "CL-CN-${2026000 + idx}",
                nameCn = cnName,
                nameEn = CLIENT_NAMES_EN[idx],
                cityCn = CHINESE_CITIES[cityIdx],
                cityEn = ENGLISH_CITIES[cityIdx],
                category = category,
                tier = "V${(idx % 5) + 1}",
                creditLimit = limit,
                creditUsed = BigDecimal(1000000 + (idx * 400000)),
                riskLevel = if (idx % 4 == 0) "中" else if (idx % 7 == 0) "高" else "低",
                settlementTerms = "T+${idx % 3}",
                kycStatus = "已认证",
                averageGoldCost = BigDecimal("550.40").add(BigDecimal(idx * 2)),
                goldExposure = BigDecimal(500 + idx * 120),
                silverExposure = BigDecimal(4000 + idx * 500)
            )
        }
    }

    // Generate 15 distinct Physical Gold & Silver Bars
    fun generateBars(): List<BullionBar> {
        val list = mutableListOf<BullionBar>()
        val refiners = listOf("上海造币厂", "山东黄金集团", "紫金矿业", "贺利氏(中国)", "国控金银精炼厂")
        
        // 10 Gold Bars
        for (i in 1..10) {
            val gross = when (i % 4) {
                0 -> BigDecimal("1000.00")
                1 -> BigDecimal("3000.00")
                2 -> BigDecimal("5000.00")
                else -> BigDecimal("100.00")
            }
            val purity = if (i % 3 == 0) 9995 else 9999
            val vault = VaultLocation.values()[i % VaultLocation.values().size]
            val clientIdx = i % CLIENT_NAMES_CN.size

            list.add(
                BullionBar(
                    id = "BAR-AU-${100000 + i}",
                    serialNumber = "CN-AU-${purity}-${10004800 + i}",
                    metalType = MetalType.GOLD,
                    purity = purity,
                    grossWeight = gross,
                    manufacturer = refiners[i % refiners.size],
                    productionDate = "2026-03-${10 + i}",
                    certificateNo = "CERT-AU-${99000 + i}",
                    location = vault,
                    ownerNameCn = if (i % 2 == 0) CLIENT_NAMES_CN[clientIdx] else "金瑞金库托管",
                    ownerNameEn = if (i % 2 == 0) CLIENT_NAMES_EN[clientIdx] else "JINRUI Custody",
                    statusCn = if (i % 5 == 0) "运输中" else if (i % 6 == 0) "检测中" else "已分配",
                    statusEn = if (i % 5 == 0) "In Transit" else if (i % 6 == 0) "Assaying" else "Allocated"
                )
            )
        }

        // 5 Silver Bars
        for (i in 1..5) {
            val gross = when (i % 3) {
                0 -> BigDecimal("15000.00")
                1 -> BigDecimal("30000.00")
                else -> BigDecimal("10000.00")
            }
            val purity = 9990
            val vault = VaultLocation.values()[(i + 2) % VaultLocation.values().size]
            val clientIdx = (i + 2) % CLIENT_NAMES_CN.size

            list.add(
                BullionBar(
                    id = "BAR-AG-${200000 + i}",
                    serialNumber = "CN-AG-9990-${20008800 + i}",
                    metalType = MetalType.SILVER,
                    purity = purity,
                    grossWeight = gross,
                    manufacturer = "中国金银冶炼总厂",
                    productionDate = "2026-02-${15 + i}",
                    certificateNo = "CERT-AG-${88000 + i}",
                    location = vault,
                    ownerNameCn = if (i % 2 == 0) CLIENT_NAMES_CN[clientIdx] else "金瑞金库托管",
                    ownerNameEn = if (i % 2 == 0) CLIENT_NAMES_EN[clientIdx] else "JINRUI Custody",
                    statusCn = "已分配",
                    statusEn = "Allocated"
                )
            )
        }
        return list
    }

    // Generate 8 stunning retail jewellery products
    fun generateJewelleries(): List<JewelleryProduct> {
        return listOf(
            JewelleryProduct(
                id = "JW-001",
                barcode = "6901234560012",
                nameCn = "24K 万足金经典如意手镯",
                nameEn = "24K Classic Ruyi Gold Bangle",
                categoryCn = "手镯",
                categoryEn = "Bangle",
                purity = 9999,
                grossWeight = BigDecimal("38.40"),
                netGoldWeight = BigDecimal("38.40"),
                gemWeightCarat = BigDecimal.ZERO,
                makingChargePerGram = BigDecimal("45.00"), //工费45元/克
                certificateNo = "GJW-2026-88001",
                imagePrompt = "luxury gold bangle with dragon motif"
            ),
            JewelleryProduct(
                id = "JW-002",
                barcode = "6901234560029",
                nameCn = "18K 玫瑰金祥云镶钻吊坠",
                nameEn = "18K Rose Gold Lucky Cloud Diamond Pendant",
                categoryCn = "吊坠",
                categoryEn = "Pendant",
                purity = 750,
                grossWeight = BigDecimal("6.80"),
                netGoldWeight = BigDecimal("5.10"),
                gemWeightCarat = BigDecimal("0.45"),
                makingChargePerGram = BigDecimal("85.00"),
                certificateNo = "GJW-2026-88002",
                imagePrompt = "delicate rose gold pendant cloud shape with small diamonds"
            ),
            JewelleryProduct(
                id = "JW-003",
                barcode = "6901234560036",
                nameCn = "999 足金福禄双全项链",
                nameEn = "999 Pure Gold Fu Lu Double Happiness Necklace",
                categoryCn = "项链",
                categoryEn = "Necklace",
                purity = 999,
                grossWeight = BigDecimal("24.50"),
                netGoldWeight = BigDecimal("24.50"),
                gemWeightCarat = BigDecimal.ZERO,
                makingChargePerGram = BigDecimal("38.00"),
                certificateNo = "GJW-2026-88003",
                imagePrompt = "intricate Chinese gold chain necklace with gourd charms"
            ),
            JewelleryProduct(
                id = "JW-004",
                barcode = "6901234560043",
                nameCn = "22K 传世复古麻花黄金戒指",
                nameEn = "22K Heritage Vintage Braided Gold Ring",
                categoryCn = "戒指",
                categoryEn = "Ring",
                purity = 916,
                grossWeight = BigDecimal("8.20"),
                netGoldWeight = BigDecimal("7.51"),
                gemWeightCarat = BigDecimal.ZERO,
                makingChargePerGram = BigDecimal("50.00"),
                certificateNo = "GJW-2026-88004",
                imagePrompt = "traditional thick braided yellow gold ring"
            ),
            JewelleryProduct(
                id = "JW-005",
                barcode = "6901234560050",
                nameCn = "999 足金转运珠编织手链",
                nameEn = "999 Gold Fortune Bead Braided Bracelet",
                categoryCn = "手链",
                categoryEn = "Bracelet",
                purity = 999,
                grossWeight = BigDecimal("4.50"),
                netGoldWeight = BigDecimal("4.50"),
                gemWeightCarat = BigDecimal.ZERO,
                makingChargePerGram = BigDecimal("30.00"),
                certificateNo = "GJW-2026-88005",
                imagePrompt = "red braided cord bracelet with 3 pure gold beads"
            )
        )
    }
}
