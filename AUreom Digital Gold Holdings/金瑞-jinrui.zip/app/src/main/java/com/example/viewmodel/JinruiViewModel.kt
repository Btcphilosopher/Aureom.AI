package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// Base Currency Conversion Factor: 1 Troy Ounce = 31.1034768 grams
private val GRAMS_PER_OZ = BigDecimal("31.1034768")
private val OZ_PER_KG = BigDecimal("32.1507466")

data class JinruiUiState(
    // System Config
    val isEnglish: Boolean = false,
    val activeTab: Int = 0, // 0: 市场总览, 1: 行情终端, 2: 交易大厅(RFQ/Dealer), 3: 实物库存(Bullion), 4: 珠宝商户(POS/Recycling), 5: 风险与套保, 6: 金瑞AI助手
    val activeRole: UserRole = UserRole.TRADER,
    
    // Live Market Inputs
    val intlGoldUsdOz: BigDecimal = BigDecimal("2645.50"), // USD/oz
    val intlSilverUsdOz: BigDecimal = BigDecimal("31.25"),  // USD/oz
    val fxUsdCny: BigDecimal = BigDecimal("7.1524"),        // USD/CNY
    val domesticPremiumGold: BigDecimal = BigDecimal("4.20"), // CNY/g
    val domesticPremiumSilver: BigDecimal = BigDecimal("150.00"), // CNY/kg
    
    // Derived Domestic Spot Prices (CNY/g)
    val spotGoldCnyG: BigDecimal = BigDecimal("608.50"),
    val spotSilverCnyKg: BigDecimal = BigDecimal("7180.00"),
    
    // RFQ Workspace
    val rfqList: List<RFQRecord> = emptyList(),
    val activeRfqId: String? = null,
    
    // Physical Bullion & Vault
    val bullionBars: List<BullionBar> = emptyList(),
    val scannedBar: BullionBar? = null,
    val barcodeInput: String = "",
    
    // Jewellery POS & Recycling Workspace
    val jewelleryList: List<JewelleryProduct> = emptyList(),
    val selectedJewellCustomerId: String? = null,
    val recycleGrossWeight: String = "38.40",
    val recyclePurityType: String = "916 (22K)", // "916 (22K)", "999 (足金)", "750 (18K)"
    val recycleReceipt: String? = null,
    val exchangeOldWeight: String = "20.00",
    val exchangeNewProductCode: String = "JW-001",
    val exchangeResultTextCn: String = "",
    val exchangeResultTextEn: String = "",

    // Client Directory & Exposure
    val clients: List<ClientProfile> = emptyList(),
    val activeClientId: String? = null,
    
    // Trade Book & Double Entry Ledger
    val trades: List<MetalTrade> = emptyList(),
    val ledgerEntries: List<LedgerEntry> = emptyList(),
    val ledgerBalanceCny: BigDecimal = BigDecimal.ZERO,
    
    // Risk Engine & Hedging
    val physicalGoldExposureG: BigDecimal = BigDecimal("4285000"), // 4,285 kg
    val physicalSilverExposureG: BigDecimal = BigDecimal("28450000"), // 28,450 kg
    val goldHedgeGrams: BigDecimal = BigDecimal("3000000"), // 3,000 kg hedged
    val silverHedgeGrams: BigDecimal = BigDecimal("20000000"), // 20,000 kg hedged
    val goldLimitGrams: BigDecimal = BigDecimal("5000000"),
    val riskWarningMsgCn: String? = null,
    val riskWarningMsgEn: String? = null,
    
    // Scenario Simulation Modifiers
    val scenarioGoldChangePct: Double = 0.0, // slider -15% to +15%
    val scenarioSilverChangePct: Double = 0.0,
    val scenarioCnyDepreciationPct: Double = 0.0, // slider 0% to +10%
    val isClientDefaultStressed: Boolean = false,
    
    // AI Assistant Workspace
    val aiMessages: List<AiMessage> = emptyList(),
    val aiInputText: String = "",
    
    // Audit & Statistics
    val totalDebitsCny: BigDecimal = BigDecimal.ZERO,
    val totalCreditsCny: BigDecimal = BigDecimal.ZERO,
    val dailyPnlCny: BigDecimal = BigDecimal("154800.00"),
    val goldAssetBalanceGrams: BigDecimal = BigDecimal("4285000"),
    val initialGoldBalanceGrams: BigDecimal = BigDecimal("4285000"),
    val goldReceiptsGrams: BigDecimal = BigDecimal.ZERO,
    val goldDeliveriesGrams: BigDecimal = BigDecimal.ZERO
)

data class AiMessage(
    val sender: String, // "USER" or "AI"
    val content: String,
    val timestamp: String
)

class JinruiViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(JinruiUiState())
    val uiState: StateFlow<JinruiUiState> = _uiState.asStateFlow()

    private var tickerJob: Job? = null
    private val random = kotlin.random.Random(1688)

    init {
        // Load initial seed data
        val initialBars = JinruiDataGenerator.generateBars()
        val initialClients = JinruiDataGenerator.generateClients()
        val initialJewelleries = JinruiDataGenerator.generateJewelleries()

        _uiState.update {
            it.copy(
                bullionBars = initialBars,
                clients = initialClients,
                jewelleryList = initialJewelleries,
                rfqList = createInitialRfqs(),
                scannedBar = initialBars.firstOrNull()
            )
        }

        // Run authorative pricing calculations
        recalculatePrices()
        // Setup initial accounting balance
        calculateLedgerInvariants()

        // Start real-time simulated market ticker
        startMarketTicker()
    }

    private fun startMarketTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (true) {
                delay(4000) // tick every 4s
                // Small random fluctuation to SGE prices
                val gDiff = BigDecimal((random.nextDouble() - 0.49) * 0.8).setScale(2, RoundingMode.HALF_UP)
                val sDiff = BigDecimal((random.nextDouble() - 0.51) * 0.04).setScale(4, RoundingMode.HALF_UP)
                val fxDiff = BigDecimal((random.nextDouble() - 0.5) * 0.002).setScale(4, RoundingMode.HALF_UP)

                _uiState.update { current ->
                    val newIntlGold = current.intlGoldUsdOz.add(gDiff).max(BigDecimal("1000.00"))
                    val newIntlSilver = current.intlSilverUsdOz.add(sDiff).max(BigDecimal("10.00"))
                    val newFx = current.fxUsdCny.add(fxDiff).max(BigDecimal("5.00"))
                    current.copy(
                        intlGoldUsdOz = newIntlGold,
                        intlSilverUsdOz = newIntlSilver,
                        fxUsdCny = newFx
                    )
                }
                recalculatePrices()
                checkRiskThresholds()
            }
        }
    }

    // High-Prestige Pricing Engine (CNY Formula Converter)
    // USD/oz -> USD/kg -> RMB/kg -> RMB/g -> Purity adjusted
    private fun recalculatePrices() {
        _uiState.update { current ->
            // Gold conversion
            // 1. USD/oz to USD/kg: multiply by 32.1507466
            val goldUsdKg = current.intlGoldUsdOz.multiply(OZ_PER_KG)
            // 2. USD/kg to RMB/kg: multiply by FX rate
            val goldRmbKg = goldUsdKg.multiply(current.fxUsdCny)
            // 3. RMB/kg to RMB/g: divide by 1000
            val goldRmbG_Base = goldRmbKg.divide(BigDecimal("1000"), 4, RoundingMode.HALF_UP)
            // 4. Spot Price = Base + Premium
            var finalSpotGold = goldRmbG_Base.add(current.domesticPremiumGold)

            // Silver conversion
            val silverUsdKg = current.intlSilverUsdOz.multiply(OZ_PER_KG)
            val silverRmbKg_Base = silverUsdKg.multiply(current.fxUsdCny)
            var finalSpotSilverKg = silverRmbKg_Base.add(current.domesticPremiumSilver)

            // Apply Scenario modifiers dynamically if active
            if (current.scenarioGoldChangePct != 0.0) {
                val multiplier = BigDecimal.valueOf(1.0 + (current.scenarioGoldChangePct / 100.0))
                finalSpotGold = finalSpotGold.multiply(multiplier)
            }
            if (current.scenarioSilverChangePct != 0.0) {
                val multiplier = BigDecimal.valueOf(1.0 + (current.scenarioSilverChangePct / 100.0))
                finalSpotSilverKg = finalSpotSilverKg.multiply(multiplier)
            }
            if (current.scenarioCnyDepreciationPct != 0.0) {
                val multiplier = BigDecimal.valueOf(1.0 + (current.scenarioCnyDepreciationPct / 100.0))
                finalSpotGold = finalSpotGold.multiply(multiplier)
                finalSpotSilverKg = finalSpotSilverKg.multiply(multiplier)
            }

            current.copy(
                spotGoldCnyG = finalSpotGold.setScale(2, RoundingMode.HALF_UP),
                spotSilverCnyKg = finalSpotSilverKg.setScale(2, RoundingMode.HALF_UP)
            )
        }
    }

    private fun checkRiskThresholds() {
        _uiState.update { current ->
            // Invariant & limit checks
            val goldExposureG = current.physicalGoldExposureG.subtract(current.goldHedgeGrams)
            val limit = current.goldLimitGrams
            val ratio = goldExposureG.multiply(BigDecimal("100")).divide(limit, 1, RoundingMode.HALF_UP)
            
            val limitExceeded = goldExposureG > limit
            val warningMsgCn = if (limitExceeded) {
                "【风控预警】黄金敞口净头寸超过限额！当前敞口: ${(goldExposureG.divide(BigDecimal("1000"))).setScale(1, RoundingMode.HALF_UP)}kg, 限额: ${(limit.divide(BigDecimal("1000"))).setScale(1, RoundingMode.HALF_UP)}kg (${ratio}%)"
            } else if (ratio > BigDecimal("90")) {
                "【风险关注】黄金持仓集中度较高。已使用额度: ${ratio}%"
            } else null

            val warningMsgEn = if (limitExceeded) {
                "[Risk Warning] Net gold exposure exceeded limit! Current: ${(goldExposureG.divide(BigDecimal("1000"))).setScale(1, RoundingMode.HALF_UP)}kg, Limit: ${(limit.divide(BigDecimal("1000"))).setScale(1, RoundingMode.HALF_UP)}kg (${ratio}%)"
            } else if (ratio > BigDecimal("90")) {
                "[Risk Attention] High gold position concentration. Utilized: ${ratio}%"
            } else null

            current.copy(
                riskWarningMsgCn = warningMsgCn,
                riskWarningMsgEn = warningMsgEn
            )
        }
    }

    // Double-Entry Bookkeeping Accounting Engine & Metal balance checks
    private fun calculateLedgerInvariants() {
        _uiState.update { current ->
            var debits = BigDecimal.ZERO
            var credits = BigDecimal.ZERO
            current.ledgerEntries.forEach {
                debits = debits.add(it.amount)
                credits = credits.add(it.amount)
            }
            current.copy(
                totalDebitsCny = debits,
                totalCreditsCny = credits,
                ledgerBalanceCny = debits.subtract(credits)
            )
        }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(isEnglish = !it.isEnglish) }
    }

    fun selectTab(tabIdx: Int) {
        _uiState.update { it.copy(activeTab = tabIdx) }
    }

    fun selectRole(role: UserRole) {
        _uiState.update { it.copy(activeRole = role) }
    }

    // RFQ Workflow Actions
    fun createRFQ(clientName: String, metal: MetalType, weightKg: BigDecimal, purity: Int) {
        val qtyGrams = weightKg.multiply(BigDecimal("1000"))
        val spec = "${metal.cnName} $purity / ${weightKg}kg"
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
        val settleDate = format.format(Date(System.currentTimeMillis() + 86400000 * 2)) // T+2
        val base = if (metal == MetalType.GOLD) _uiState.value.spotGoldCnyG else _uiState.value.spotSilverCnyKg.divide(BigDecimal("1000"))

        val newRfq = RFQRecord(
            id = "RFQ-CN-2026-${String.format("%06d", random.nextInt(100000))}",
            clientName = clientName,
            metalType = metal,
            spec = spec,
            purity = purity,
            quantityGrams = qtyGrams,
            deliveryLocation = VaultLocation.SHANGHAI,
            settlementDate = settleDate,
            basePrice = base,
            dealerBid = base.subtract(BigDecimal("0.50")),
            dealerOffer = base.add(BigDecimal("0.60")),
            status = "待处理",
            expiryTimestamp = System.currentTimeMillis() + 180000, // 3 minutes
            traderName = "JINRUI Trader"
        )
        _uiState.update { it.copy(rfqList = listOf(newRfq) + it.rfqList, activeRfqId = newRfq.id) }
    }

    fun submitDealerPrice(rfqId: String, bid: BigDecimal, offer: BigDecimal) {
        _uiState.update { current ->
            val updated = current.rfqList.map {
                if (it.id == rfqId) {
                    it.copy(dealerBid = bid, dealerOffer = offer, status = "已报价")
                } else it
            }
            current.copy(rfqList = updated)
        }
    }

    // Execute Trade Ticket & Post Double Entry Bookkeeping Invariants
    fun executeTrade(rfqId: String?, side: String, clientName: String, metal: MetalType, grams: BigDecimal, priceG: BigDecimal, premium: BigDecimal) {
        val tradeId = "TXN-${UUID.randomUUID().toString().substring(0, 8).uppercase()}"
        val finalPriceG = priceG.add(premium)
        val totalAmount = grams.multiply(finalPriceG).setScale(2, RoundingMode.HALF_UP)
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        
        val newTrade = MetalTrade(
            id = tradeId,
            rfqId = rfqId,
            clientName = clientName,
            metalType = metal,
            productSpec = if (metal == MetalType.GOLD) "Au${metal.defaultPurity}" else "Ag${metal.defaultPurity}",
            quantityGrams = grams,
            executedPrice = finalPriceG,
            premium = premium,
            side = side,
            settlementDate = "T+0 (今日)",
            deliveryLocation = VaultLocation.SHANGHAI,
            timestamp = format.format(Date()),
            totalAmount = totalAmount,
            status = "已结算"
        )

        // DOUBLE-ENTRY POSTING RULES:
        // Cash Account <---> Metal Clearing Account
        val memoCn = if (side == "BUY") {
            "自【$clientName】处买入 ${grams}g ${metal.cnName} (单价: ¥${finalPriceG})"
        } else {
            "向【$clientName】销售 ${grams}g ${metal.cnName} (单价: ¥${finalPriceG})"
        }
        val memoEn = if (side == "BUY") {
            "Purchased ${grams}g ${metal.enName} from [$clientName] at ¥${finalPriceG}/g"
        } else {
            "Sold ${grams}g ${metal.enName} to [$clientName] at ¥${finalPriceG}/g"
        }

        val debitAcc = if (side == "BUY") "METAL_INVENTORY_LOT" else "BANK_CNY_CASH"
        val creditAcc = if (side == "BUY") "BANK_CNY_CASH" else "METAL_INVENTORY_LOT"

        val firstEntry = LedgerEntry(
            id = "LEDGER-${UUID.randomUUID().toString().substring(0, 6).uppercase()}",
            timestamp = format.format(Date()),
            accountDebit = debitAcc,
            accountCredit = creditAcc,
            amount = totalAmount,
            currency = "CNY",
            tradeId = tradeId,
            memoCn = memoCn,
            memoEn = memoEn
        )

        _uiState.update { current ->
            // Dynamic allocation of physical bar upon sales or purchase
            val updatedBars = current.bullionBars.toMutableList()
            if (side == "SELL") {
                // Find available bar matching metal and subtract / reassign
                val barToAllocate = updatedBars.find { it.metalType == metal && it.statusCn == "已分配" }
                if (barToAllocate != null) {
                    barToAllocate.ownerNameCn = clientName
                    barToAllocate.ownerNameEn = clientName
                }
            }

            // Adjust physical gold exposure & dynamic balances
            val goldOffset = if (metal == MetalType.GOLD) {
                if (side == "BUY") grams else grams.negate()
            } else BigDecimal.ZERO

            val silverOffset = if (metal == MetalType.SILVER) {
                if (side == "BUY") grams else grams.negate()
            } else BigDecimal.ZERO

            val updatedRfqs = current.rfqList.map {
                if (it.id == rfqId) it.copy(status = "已成交") else it
            }

            val pnlGain = if (side == "SELL") totalAmount.multiply(BigDecimal("0.0025")) else BigDecimal.ZERO

            current.copy(
                trades = listOf(newTrade) + current.trades,
                ledgerEntries = listOf(firstEntry) + current.ledgerEntries,
                rfqList = updatedRfqs,
                physicalGoldExposureG = current.physicalGoldExposureG.add(goldOffset),
                physicalSilverExposureG = current.physicalSilverExposureG.add(silverOffset),
                dailyPnlCny = current.dailyPnlCny.add(pnlGain),
                goldDeliveriesGrams = current.goldDeliveriesGrams.add(if (side == "SELL" && metal == MetalType.GOLD) grams else BigDecimal.ZERO),
                goldReceiptsGrams = current.goldReceiptsGrams.add(if (side == "BUY" && metal == MetalType.GOLD) grams else BigDecimal.ZERO)
            )
        }

        calculateLedgerInvariants()
        checkRiskThresholds()
    }

    // Barcode Scanning / Registration Actions
    fun enterBarcode(code: String) {
        _uiState.update { it.copy(barcodeInput = code) }
    }

    fun triggerBarcodeScan() {
        val code = _uiState.value.barcodeInput.trim()
        val found = _uiState.value.bullionBars.find { it.serialNumber == code || it.id == code }
        if (found != null) {
            _uiState.update { it.copy(scannedBar = found) }
        } else {
            // Find a random bar or create a new custom one
            val randomBar = _uiState.value.bullionBars.randomOrNull()
            _uiState.update { it.copy(scannedBar = randomBar) }
        }
    }

    fun selectBar(bar: BullionBar) {
        _uiState.update { it.copy(scannedBar = bar) }
    }

    // Jewellery POS Operations
    fun sellJewelleryProduct(product: JewelleryProduct, discount: BigDecimal) {
        val totalAmount = product.calculateRetailPrice(_uiState.value.spotGoldCnyG, discount)
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        val tradeId = "JW-TXN-${UUID.randomUUID().toString().substring(0, 6).uppercase()}"

        val mockTrade = MetalTrade(
            id = tradeId,
            rfqId = null,
            clientName = "零售客户 (Walk-in Customer)",
            metalType = if (product.purity >= 900) MetalType.GOLD else MetalType.GOLD,
            productSpec = product.nameCn,
            quantityGrams = product.grossWeight,
            executedPrice = totalAmount.divide(product.grossWeight, 2, RoundingMode.HALF_UP),
            premium = product.makingChargePerGram,
            side = "SELL",
            settlementDate = "T+0 (实时结算)",
            deliveryLocation = VaultLocation.SHENZHEN,
            timestamp = format.format(Date()),
            totalAmount = totalAmount,
            status = "已结算"
        )

        val ledger = LedgerEntry(
            id = "LEDGER-POS-${UUID.randomUUID().toString().substring(0, 5).uppercase()}",
            timestamp = format.format(Date()),
            accountDebit = "RETAIL_CASH_CNY",
            accountCredit = "JEWELLERY_INVENTORY",
            amount = totalAmount,
            currency = "CNY",
            tradeId = tradeId,
            memoCn = "零售POS销售: ${product.nameCn} (克重: ${product.grossWeight}g, 工费: ¥${product.makingChargePerGram}/g)",
            memoEn = "POS Sale: ${product.nameEn} (${product.grossWeight}g, making fee ¥${product.makingChargePerGram}/g)"
        )

        _uiState.update { current ->
            current.copy(
                trades = listOf(mockTrade) + current.trades,
                ledgerEntries = listOf(ledger) + current.ledgerEntries,
                dailyPnlCny = current.dailyPnlCny.add(totalAmount.multiply(BigDecimal("0.12"))) // estimated 12% retail margin profit
            )
        }
        calculateLedgerInvariants()
    }

    // Gold Recycling Calculations & Workflow
    fun performGoldRecycling(gross: Double, purityType: String) {
        val ratio = when {
            purityType.contains("9999") -> BigDecimal("0.9999")
            purityType.contains("999") -> BigDecimal("0.999")
            purityType.contains("916") -> BigDecimal("0.916")
            purityType.contains("750") -> BigDecimal("0.750")
            else -> BigDecimal("0.916")
        }
        val grossBigDecimal = BigDecimal.valueOf(gross)
        val fineGold = grossBigDecimal.multiply(ratio).setScale(4, RoundingMode.HALF_UP)
        
        // Deduction items (e.g. melting loss fee 2%, assay fee 5元/克)
        val rawBase = _uiState.value.spotGoldCnyG
        val recyclePricePerG = rawBase.multiply(BigDecimal("0.97")).setScale(2, RoundingMode.HALF_UP) // 3% commercial discount fee
        val totalPayout = fineGold.multiply(recyclePricePerG).setScale(2, RoundingMode.HALF_UP)

        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
        val billId = "RECYCLE-${UUID.randomUUID().toString().substring(0, 6).uppercase()}"

        val receiptText = """
            ==============================
                   金瑞 JINRUI · 黄金回收单
                GOLD RECYCLING SETTLEMENT
            ==============================
            单据编号 / Bill ID: $billId
            操作时间 / Time: ${format.format(Date())}
            
            客户姓名 / Client: 散客 (李女士)
            回收材质 / Metal: 黄金手镯 (Bracelet)
            声明纯度 / Declared Purity: $purityType
            实际克重 / Gross Weight: ${grossBigDecimal.setScale(2, RoundingMode.HALF_UP)} g
            折纯重量 / Fine Gold: $fineGold g
            
            基准金价 / Base Market: ¥${rawBase.setScale(2, RoundingMode.HALF_UP)} /克
            回收单价 / Net Price: ¥$recyclePricePerG /克
            折旧扣减 /熔炼损耗: 3% (熔耗与检测费)
            
            结算总额 / PAYOUT AMOUNT:
            👉 ¥${totalPayout} RMB
            ==============================
            【金瑞回收中心 · 鉴定通过】
        """.trimIndent()

        _uiState.update { current ->
            current.copy(
                recycleReceipt = receiptText,
                physicalGoldExposureG = current.physicalGoldExposureG.add(fineGold) // Recycled metal added to physical pool
            )
        }
    }

    // Old-For-New Gold Exchange Retail Workflow (以旧换新)
    fun performOldForNewExchange(oldWeightStr: String, newProductCode: String) {
        val oldW = oldWeightStr.toDoubleOrNull() ?: 0.0
        val product = _uiState.value.jewelleryList.find { it.id == newProductCode } ?: return

        // Calculation: 
        // Old gold value = Old weight * 95% * Spot Gold Price
        // New jewellery cost = New product retail cost
        val oldVal = BigDecimal.valueOf(oldW)
            .multiply(BigDecimal("0.95")) // 5% trade-in premium depreciation
            .multiply(_uiState.value.spotGoldCnyG)
            .setScale(2, RoundingMode.HALF_UP)

        val newVal = product.calculateRetailPrice(_uiState.value.spotGoldCnyG, BigDecimal.ONE)
        val diff = newVal.subtract(oldVal)

        val cnResult = "以旧换新试算成功：旧金回收估值 ¥$oldVal (${oldW}g)，新商品【${product.nameCn}】售价 ¥$newVal。客户需补差价：¥$diff"
        val enResult = "Trade-in calculation success: Old gold value ¥$oldVal (${oldW}g), new item [${product.nameEn}] priced at ¥$newVal. Client cash due: ¥$diff"

        _uiState.update { it.copy(
            exchangeResultTextCn = cnResult,
            exchangeResultTextEn = enResult
        )}
    }

    // Scenario Analysis Lab
    fun updateScenarioGold(pct: Double) {
        _uiState.update { it.copy(scenarioGoldChangePct = pct) }
        recalculatePrices()
    }

    fun updateScenarioSilver(pct: Double) {
        _uiState.update { it.copy(scenarioSilverChangePct = pct) }
        recalculatePrices()
    }

    fun updateScenarioCnyDeprec(pct: Double) {
        _uiState.update { it.copy(scenarioCnyDepreciationPct = pct) }
        recalculatePrices()
    }

    fun triggerClientDefaultStress(active: Boolean) {
        _uiState.update { current ->
            val updatedClients = current.clients.map {
                if (it.nameCn.contains("华东")) {
                    it.copy(creditUsed = if (active) it.creditLimit.multiply(BigDecimal("1.1")) else BigDecimal("1400000"))
                } else it
            }
            current.copy(
                isClientDefaultStressed = active,
                clients = updatedClients
            )
        }
    }

    // Dynamic SGE Vault Transfer / Movements
    fun transferBarVault(barSerial: String, toVault: VaultLocation) {
        _uiState.update { current ->
            val updated = current.bullionBars.map {
                if (it.serialNumber == barSerial) {
                    // Log movement
                    it.copy(location = toVault, statusCn = "运输中", statusEn = "In Transit")
                } else it
            }
            current.copy(bullionBars = updated)
        }
    }

    // Bilingual Chinese-First Jinrui AI Assistant
    // Solves complex structural queries against actual dynamic state
    fun sendAiMessage() {
        val input = _uiState.value.aiInputText.trim()
        if (input.isEmpty()) return

        val format = SimpleDateFormat("HH:mm", Locale.CHINA)
        val userMsg = AiMessage("USER", input, format.format(Date()))
        val updatedMsgs = _uiState.value.aiMessages + userMsg

        _uiState.update { it.copy(aiMessages = updatedMsgs, aiInputText = "") }

        viewModelScope.launch {
            delay(1000) // simulation delay
            val aiResponse = generateLocalAiResponse(input)
            val aiMsg = AiMessage("AI", aiResponse, format.format(Date()))
            _uiState.update { it.copy(aiMessages = _uiState.value.aiMessages + aiMsg) }
        }
    }

    fun setAiInputText(txt: String) {
        _uiState.update { it.copy(aiInputText = txt) }
    }

    private fun generateLocalAiResponse(query: String): String {
        val isEng = _uiState.value.isEnglish
        val state = _uiState.value
        
        // Exact real-time metrics computed dynamically from state!
        val goldExposureKg = state.physicalGoldExposureG.divide(BigDecimal("1000"), 2, RoundingMode.HALF_UP)
        val silverExposureKg = state.physicalSilverExposureG.divide(BigDecimal("1000"), 2, RoundingMode.HALF_UP)
        val shVaultGold = state.bullionBars.filter { it.location == VaultLocation.SHANGHAI && it.metalType == MetalType.GOLD }
            .fold(BigDecimal.ZERO) { acc, bar -> acc.add(bar.grossWeight) }
            .divide(BigDecimal("1000"), 2, RoundingMode.HALF_UP)
        
        val maxClient = state.clients.maxByOrNull { it.creditUsed }
        val pnl = state.dailyPnlCny
        val goldPrice = state.spotGoldCnyG

        val lowerQuery = query.lowercase()

        return when {
            lowerQuery.contains("库存") || lowerQuery.contains("inventory") || lowerQuery.contains("how much gold") -> {
                if (isEng) {
                    "Currently, the system is holding $goldExposureKg kg of Physical Gold and $silverExposureKg kg of Physical Silver. Shanghai Vault holds $shVaultGold kg of Gold Bullion directly."
                } else {
                    "金瑞系统当前实物黄金总头寸为：$goldExposureKg 公斤 (kg)，白银总头寸为：$silverExposureKg 公斤 (kg)。其中上海分库直接管理金条共计 $shVaultGold 公斤。"
                }
            }
            lowerQuery.contains("上海金库") || lowerQuery.contains("shanghai vault") -> {
                if (isEng) {
                    "Shanghai Main Vault is fully operational. Dynamic physical gold bars stored: $shVaultGold kg. Security status: High Secure Level A."
                } else {
                    "金瑞上海主金库处于全面运营状态。实物保管金条：$shVaultGold 公斤。安全级别：高能A级，配备区块链交割追溯系统。"
                }
            }
            lowerQuery.contains("华东") || lowerQuery.contains("east china") || lowerQuery.contains("biggest") || lowerQuery.contains("最大持仓") -> {
                if (maxClient != null) {
                    if (isEng) {
                        "The largest active client account is [${maxClient.nameEn}]. Approved Credit Limit: ¥${maxClient.creditLimit.divide(BigDecimal("1000000"))}M, Current Used: ¥${maxClient.creditUsed.divide(BigDecimal("10000"))}万元."
                    } else {
                        "当前持仓与授信使用最高客户为：【${maxClient.nameCn}】。核定授信额度: ¥${maxClient.creditLimit.divide(BigDecimal("1000000"))}百万，当前已用额度: ¥${maxClient.creditUsed.divide(BigDecimal("10000"), 2, RoundingMode.HALF_UP)}万元。"
                    }
                } else {
                    if (isEng) "No active clients found in directory." else "客户目录中未找到有效持仓客户。"
                }
            }
            lowerQuery.contains("损益") || lowerQuery.contains("pnl") || lowerQuery.contains("today's pnl") || lowerQuery.contains("收益") -> {
                if (isEng) {
                    "Today's Realized Merchant P&L is ¥$pnl CNY, driven by retail gold sales, trade premiums, and SGE lease interest spread."
                } else {
                    "今日交易损益已实现收益：¥$pnl 元 (RMB)。该收益来自黄金珠宝POS销售溢价、大宗交易升贴水收益以及对冲套保账簿变动。"
                }
            }
            lowerQuery.contains("白银") || lowerQuery.contains("silver") -> {
                val silverPrice = state.spotSilverCnyKg
                if (isEng) {
                    "Domestic spot Silver price is currently ¥$silverPrice / kg. Total physical silver vault inventory: $silverExposureKg kg."
                } else {
                    "国内即期白银市场价格为：¥$silverPrice / 千克。金瑞系统实物白银持仓总额为：$silverExposureKg 公斤。"
                }
            }
            lowerQuery.contains("金价") || lowerQuery.contains("gold price") || lowerQuery.contains("黄金价格") -> {
                if (isEng) {
                    "The current live simulated domestic gold spot price is ¥$goldPrice / gram (CNY/g). International reference is USD $${state.intlGoldUsdOz} / oz."
                } else {
                    "金瑞即期黄金结算底价为：¥$goldPrice /克。国际市场参考价为：$${state.intlGoldUsdOz} 美元/盎司，RMB汇率中间价：${state.fxUsdCny}。"
                }
            }
            lowerQuery.contains("额度") || lowerQuery.contains("over limit") || lowerQuery.contains("超过") || lowerQuery.contains("limit") -> {
                val overLimits = state.clients.filter { it.creditUsed > it.creditLimit }
                if (overLimits.isNotEmpty()) {
                    val names = overLimits.joinToString { it.nameCn }
                    if (isEng) "Warning: Clients exceeding limits: $names" else "风控警告：以下客户已超过其授信限额：$names"
                } else {
                    if (isEng) "Excellent! All clients are currently within healthy credit limits." else "极佳！当前所有商户及机构客户均在核定授信额度内，交易状态正常。"
                }
            }
            else -> {
                if (isEng) {
                    "Welcome to JINRUI Financial Command Center. I can assist you with Live Inventory (黄金库存), SGE Vault details (上海金库), Exposure analysis (最大持仓), daily P&L (今日损益), or Gold price lookups (黄金价格)."
                } else {
                    "您好！我是金瑞金政指令中心 AI。我可以帮您动态查询【黄金库存】、【上海金库状态】、【客户最大持仓】、【今日交易损益】或【实时金价变动】。"
                }
            }
        }
    }

    private fun createInitialRfqs(): List<RFQRecord> {
        return listOf(
            RFQRecord(
                id = "RFQ-CN-2026-004821",
                clientName = "华东金业贸易有限公司",
                metalType = MetalType.GOLD,
                spec = "Au99.99 / 10kg Bar",
                purity = 9999,
                quantityGrams = BigDecimal("10000.00"),
                deliveryLocation = VaultLocation.SHANGHAI,
                settlementDate = "2026-10-08",
                basePrice = BigDecimal("608.20"),
                dealerBid = BigDecimal("607.70"),
                dealerOffer = BigDecimal("608.90"),
                status = "待处理",
                expiryTimestamp = System.currentTimeMillis() + 300000,
                traderName = "SGE Operator"
            ),
            RFQRecord(
                id = "RFQ-CN-2026-004819",
                clientName = "深圳瑞华黄金珠宝集团",
                metalType = MetalType.GOLD,
                spec = "Au99.95 / 5kg Bar",
                purity = 9995,
                quantityGrams = BigDecimal("5000.00"),
                deliveryLocation = VaultLocation.SHENZHEN,
                settlementDate = "2026-10-07",
                basePrice = BigDecimal("605.10"),
                dealerBid = BigDecimal("604.50"),
                dealerOffer = BigDecimal("605.80"),
                status = "已报价",
                expiryTimestamp = System.currentTimeMillis() + 600000,
                traderName = "SGE Operator"
            )
        )
    }
}
