package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JinruiColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = InkBlackBg,
    primaryContainer = GoldSecondary,
    onPrimaryContainer = WarmIvory,
    secondary = GoldAccent,
    onSecondary = InkBlackBg,
    background = InkBlackBg,
    onBackground = WarmIvory,
    surface = WarmSurface,
    onSurface = WarmIvory,
    surfaceVariant = CardSurface,
    onSurfaceVariant = WarmIvory,
    error = ChineseRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JinruiColorScheme,
        typography = Typography,
        content = content
    )
}
