package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.JinruiUiState
import com.example.viewmodel.JinruiViewModel
import java.math.BigDecimal
import java.math.RoundingMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JinruiApp(viewModel: JinruiViewModel) {
    val state by viewModel.uiState.collectAsState()
    val config = LocalConfiguration.current
    val isWide = config.screenWidthDp >= 720

    Scaffold(
        topBar = {
            JinruiHeader(
                state = state,
                onToggleLang = { viewModel.toggleLanguage() },
                onRoleSelect = { viewModel.selectRole(it) }
            )
        },
        bottomBar = {
            if (!isWide) {
                JinruiBottomNavBar(
                    isEnglish = state.isEnglish,
                    activeTab = state.activeTab,
                    onTabSelect = { viewModel.selectTab(it) }
                )
            }
        },
        containerColor = InkBlackBg
    ) { innerPadding ->
        if (isWide) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(InkBlackBg)
            ) {
                // Wide Screen Navigation Rail
                JinruiNavRail(
                    isEnglish = state.isEnglish,
                    activeTab = state.activeTab,
                    onTabSelect = { viewModel.selectTab(it) }
                )
                
                // Primary Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(16.dp)
                ) {
                    TabContent(state = state, viewModel = viewModel)
                }

                // Right Sidebar with Live Tickers & Active Risk Indicators
                JinruiRightSidebar(state = state, viewModel = viewModel)
            }
        } else {
            // Mobile layout
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(8.dp)
            ) {
                TabContent(state = state, viewModel = viewModel)
            }
        }
    }
}

// ------------------------------
// Top Command Header
// ------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JinruiHeader(
    state: JinruiUiState,
    onToggleLang: () -> Unit,
    onRoleSelect: (UserRole) -> Unit
) {
    var showRoleMenu by remember { mutableStateOf(false) }

    Surface(
        color = WarmSurface,
        border = BorderStroke(1.dp, BorderBronze),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "金瑞 JINRUI",
                        color = GoldPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(ChineseRed, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (state.isEnglish) "LIVE DEMO" else "模拟行情",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = if (state.isEnglish) "GOLD • SILVER • BULLION • MERCHANT PLATFORM" else "黄金 · 白银 · 贵金属 · 交易 · 商户系统",
                    color = MutedGrey,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language Toggle Button
                TextButton(
                    onClick = onToggleLang,
                    modifier = Modifier
                        .testTag("language_toggle_btn")
                        .border(1.dp, BorderBronze, RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = if (state.isEnglish) "简体中文" else "English",
                        color = GoldPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Role Dropdown (RBAC simulation)
                Box {
                    Button(
                        onClick = { showRoleMenu = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CardSurface),
                        border = BorderStroke(1.dp, BorderBronze),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("rbac_role_select_btn")
                    ) {
                        Icon(
                            Icons.Filled.AccountCircle,
                            contentDescription = "Role",
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (state.isEnglish) state.activeRole.enName else state.activeRole.cnName,
                            color = WarmIvory,
                            fontSize = 12.sp
                        )
                        Icon(
                            Icons.Filled.ArrowDropDown,
                            contentDescription = "Dropdown",
                            tint = GoldPrimary
                        )
                    }

                    DropdownMenu(
                        expanded = showRoleMenu,
                        onDismissRequest = { showRoleMenu = false },
                        modifier = Modifier.background(CardSurface)
                    ) {
                        UserRole.values().forEach { role ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (state.isEnglish) role.enName else role.cnName,
                                        color = WarmIvory
                                    )
                                },
                                onClick = {
                                    onRoleSelect(role)
                                    showRoleMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------
// Navigation Elements (Bilingual)
// ------------------------------
@Composable
fun JinruiBottomNavBar(
    isEnglish: Boolean,
    activeTab: Int,
    onTabSelect: (Int) -> Unit
) {
    NavigationBar(containerColor = WarmSurface, tonalElevation = 8.dp) {
        val tabs = getTabNames(isEnglish)
        tabs.forEachIndexed { index, pair ->
            NavigationBarItem(
                selected = activeTab == index,
                onClick = { onTabSelect(index) },
                icon = { Icon(getTabIcon(index), contentDescription = pair.first) },
                label = { Text(text = pair.first, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = InkBlackBg,
                    selectedTextColor = GoldPrimary,
                    indicatorColor = GoldPrimary,
                    unselectedIconColor = MutedGrey,
                    unselectedTextColor = MutedGrey
                )
            )
        }
    }
}

@Composable
fun JinruiNavRail(
    isEnglish: Boolean,
    activeTab: Int,
    onTabSelect: (Int) -> Unit
) {
    NavigationRail(
        containerColor = WarmSurface,
        header = {
            Icon(
                Icons.Filled.Star,
                contentDescription = "Jinrui Emblem",
                tint = GoldPrimary,
                modifier = Modifier
                    .size(32.dp)
                    .padding(vertical = 8.dp)
            )
        },
        modifier = Modifier.border(BorderStroke(1.dp, BorderBronze))
    ) {
        val tabs = getTabNames(isEnglish)
        tabs.forEachIndexed { index, pair ->
            NavigationRailItem(
                selected = activeTab == index,
                onClick = { onTabSelect(index) },
                icon = { Icon(getTabIcon(index), contentDescription = pair.first) },
                label = { Text(text = pair.second, fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = InkBlackBg,
                    selectedTextColor = GoldPrimary,
                    indicatorColor = GoldPrimary,
                    unselectedIconColor = MutedGrey,
                    unselectedTextColor = MutedGrey
                )
            )
        }
    }
}

private fun getTabNames(isEnglish: Boolean): List<Pair<String, String>> {
    return if (isEnglish) {
        listOf(
            "Overview" to "Home",
            "Markets" to "Market",
            "Trading" to "Trade",
            "Vault" to "Vault",
            "POS" to "POS",
            "Risk" to "Risk",
            "AI Command" to "AI"
        )
    } else {
        listOf(
            "市场总览" to "总览",
            "行情终端" to "行情",
            "交易大厅" to "交易",
            "实物金库" to "金库",
            "珠宝商户" to "珠宝",
            "风险对冲" to "风控",
            "金瑞AI" to "AI助手"
        )
    }
}

private fun getTabIcon(tab: Int) = when (tab) {
    0 -> Icons.Filled.Home
    1 -> Icons.Filled.TrendingUp
    2 -> Icons.Filled.ShoppingCart
    3 -> Icons.Filled.Lock
    4 -> Icons.Filled.Storefront
    5 -> Icons.Filled.Warning
    else -> Icons.Filled.Face
}

// ------------------------------
// Tab Workspace Switcher
// ------------------------------
@Composable
fun TabContent(state: JinruiUiState, viewModel: JinruiViewModel) {
    AnimatedContent(
        targetState = state.activeTab,
        transitionSpec = { fadeIn() togetherWith fadeOut() }
    ) { targetTab ->
        when (targetTab) {
            0 -> DashboardTab(state = state, viewModel = viewModel)
            1 -> MarketsTab(state = state)
            2 -> TradingTab(state = state, viewModel = viewModel)
            3 -> VaultTab(state = state, viewModel = viewModel)
            4 -> POSAndMerchantTab(state = state, viewModel = viewModel)
            5 -> RiskAndScenarioTab(state = state, viewModel = viewModel)
            6 -> AiAssistantTab(state = state, viewModel = viewModel)
        }
    }
}

// ------------------------------
// TAB 0: 市场总览 (Dashboard)
// ------------------------------
@Composable
fun DashboardTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Prestige Hero Section
        Text(
            text = if (state.isEnglish) "MAINLAND CHINA PRECIOUS-METALS PLATFORM" else "华夏即期贵金属交易与账簿控制中心",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Text(
            text = if (state.isEnglish) "Shanghai Gold Market • Bullion Management • Institutional Custody" else "上海黄金市场标准规范 · 物理金锭账簿 · 机构风险管理",
            color = MutedGrey,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Simulated blinking prices banner
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            border = BorderStroke(1.dp, BorderBronze),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(DarkJade)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.isEnglish) "System Status: SGE FEED ONLINE" else "上海黄金交易所：交易中 (SGE联调模式)",
                        fontSize = 11.sp,
                        color = WarmIvory,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (state.isEnglish) "SIMULATED DATA ONLY • NO LIVE EXCHANGE DEALS" else "⚠️ 本系统仅支持模拟行情 · 严禁接入真实生产交易资金",
                    fontSize = 10.sp,
                    color = ChineseRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Three Major Asset Class Banners (Gold, Silver, FX)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DashboardPriceCard(
                title = if (state.isEnglish) "SPOT GOLD (Au99.99)" else "黄金现货 (Au99.99)",
                price = "¥${state.spotGoldCnyG} / g",
                change = "+0.42%",
                isUp = true,
                isEnglish = state.isEnglish,
                modifier = Modifier.weight(1f)
            )
            DashboardPriceCard(
                title = if (state.isEnglish) "SPOT SILVER (Ag(T+D))" else "白银现货 (Ag(T+D))",
                price = "¥${state.spotSilverCnyKg} / kg",
                change = "-0.18%",
                isUp = false,
                isEnglish = state.isEnglish,
                modifier = Modifier.weight(1f)
            )
            DashboardPriceCard(
                title = if (state.isEnglish) "RMB FX INTERMEDIATE" else "人民币汇率中间价",
                price = "¥${state.fxUsdCny}",
                change = "+0.03%",
                isUp = true,
                isEnglish = state.isEnglish,
                modifier = Modifier.weight(1f)
            )
        }

        // Active exposure summaries
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val totalGoldKg = state.physicalGoldExposureG.divide(BigDecimal("1000"), 1, RoundingMode.HALF_UP)
            val totalSilverKg = state.physicalSilverExposureG.divide(BigDecimal("1000"), 1, RoundingMode.HALF_UP)

            SummaryMetricCard(
                title = if (state.isEnglish) "PHYSICAL GOLD EXP" else "实物黄金总头寸",
                value = "$totalGoldKg 公斤 / kg",
                color = GoldPrimary,
                modifier = Modifier.weight(1f)
            )
            SummaryMetricCard(
                title = if (state.isEnglish) "PHYSICAL SILVER EXP" else "实物白银总头寸",
                value = "$totalSilverKg 公斤 / kg",
                color = WarmIvory,
                modifier = Modifier.weight(1f)
            )
            SummaryMetricCard(
                title = if (state.isEnglish) "DAILY REALIZED P&L" else "今日已实现损益",
                value = "¥${state.dailyPnlCny}",
                color = DarkJade,
                modifier = Modifier.weight(1f)
            )
        }

        // SGE Market Adapter Graphic
        Text(
            text = if (state.isEnglish) "SGE MARKET ADAPTER PIPELINE" else "上海金所 (SGE) 系统总线与数枢架构",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        SgePipelineGraph(isEnglish = state.isEnglish)
    }
}

@Composable
fun DashboardPriceCard(
    title: String,
    price: String,
    change: String,
    isUp: Boolean,
    isEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WarmSurface),
        border = BorderStroke(1.dp, BorderBronze),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, color = MutedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = price,
                color = if (isUp) GoldPrimary else WarmIvory,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isUp) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = null,
                    tint = if (isUp) DarkJade else ChineseRed,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "$change (${if (isEnglish) "Simulated" else "模拟"})",
                    color = if (isUp) DarkJade else ChineseRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SummaryMetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, color = MutedGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ------------------------------
// SGE Market Adapter Diagram
// ------------------------------
@Composable
fun SgePipelineGraph(isEnglish: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WarmSurface),
        border = BorderStroke(1.dp, BorderBronze),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PipelineNode(
                    icon = Icons.Filled.TrendingUp,
                    title = if (isEnglish) "Market Feed" else "行情总线",
                    desc = "MarketDataProvider",
                    isEnglish = isEnglish
                )
                PipelineArrow()
                PipelineNode(
                    icon = Icons.Filled.PriceCheck,
                    title = if (isEnglish) "Pricing RFQ" else "定价询价",
                    desc = "TradingProvider",
                    isEnglish = isEnglish
                )
                PipelineArrow()
                PipelineNode(
                    icon = Icons.Filled.AccountBalance,
                    title = if (isEnglish) "Settlement" else "清算结算",
                    desc = "SettlementProvider",
                    isEnglish = isEnglish
                )
                PipelineArrow()
                PipelineNode(
                    icon = Icons.Filled.LocalShipping,
                    title = if (isEnglish) "Vault Delivery" else "仓储交割",
                    desc = "DeliveryProvider",
                    isEnglish = isEnglish
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderBronze)
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isEnglish) {
                    "System complies conceptually with GB 11887-2012 purity standards. Every SGE physical metal movement creates double-entry ledger verification with complete audit trail."
                } else {
                    "金瑞系统符合 GB 11887-2012 贵金属纯度规范。每次实物出入金库将自动生成加密单据并驱动复式记账，确保 借方=贷方 及 纯度折纯 恒等式不受侵害。"
                },
                fontSize = 10.sp,
                color = MutedGrey,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun PipelineNode(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    isEnglish: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(90.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(CardSurface, RoundedCornerShape(8.dp))
                .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = GoldPrimary, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, color = WarmIvory, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(text = desc, color = MutedGrey, fontSize = 8.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun PipelineArrow() {
    Icon(
        imageVector = Icons.Filled.ArrowForward,
        contentDescription = "flow",
        tint = GoldSecondary,
        modifier = Modifier.size(16.dp)
    )
}

// ------------------------------
// TAB 1: 行情终端 (Markets Terminal)
// ------------------------------
@Composable
fun MarketsTab(state: JinruiUiState) {
    var marketTabSelection by remember { mutableStateOf(0) } // 0: 黄金, 1: 白银, 2: 衍生延期

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (state.isEnglish) "SHANGHAI GOLD EXCHANGE MARKET TERMINAL" else "上海黄金交易所(SGE)即期报价终端",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Box(
                modifier = Modifier
                    .background(CardSurface, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (state.isEnglish) "MOCK REFRESHING" else "行情动态更新中",
                    fontSize = 10.sp,
                    color = DarkJade,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        TabRow(
            selectedTabIndex = marketTabSelection,
            containerColor = WarmSurface,
            contentColor = GoldPrimary
        ) {
            Tab(
                selected = marketTabSelection == 0,
                onClick = { marketTabSelection = 0 },
                text = { Text(if (state.isEnglish) "GOLD Au" else "黄金交易品类") }
            )
            Tab(
                selected = marketTabSelection == 1,
                onClick = { marketTabSelection = 1 },
                text = { Text(if (state.isEnglish) "SILVER Ag" else "白银交易品类") }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Professional Market Table
        Card(
            colors = CardDefaults.cardColors(containerColor = WarmSurface),
            border = BorderStroke(1.dp, BorderBronze)
        ) {
            Column {
                // Table Headers
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardSurface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = if (state.isEnglish) "Contract" else "合约代码", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                    Text(text = if (state.isEnglish) "Bid" else "买入价", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text(text = if (state.isEnglish) "Ask" else "卖出价", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text(text = if (state.isEnglish) "Last" else "最新价", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text(text = if (state.isEnglish) "Spread" else "价差", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }

                val currentGold = state.spotGoldCnyG
                val currentSilver = state.spotSilverCnyKg

                val products = if (marketTabSelection == 0) {
                    listOf(
                        SgeMockProduct("Au99.99", currentGold.subtract(BigDecimal("0.20")), currentGold.add(BigDecimal("0.10")), currentGold, "0.30"),
                        SgeMockProduct("Au99.95", currentGold.subtract(BigDecimal("0.80")), currentGold.add(BigDecimal("0.40")), currentGold.subtract(BigDecimal("0.20")), "1.20"),
                        SgeMockProduct("Au100g", currentGold, currentGold.add(BigDecimal("1.50")), currentGold.add(BigDecimal("0.80")), "1.50"),
                        SgeMockProduct("Au(T+D)", currentGold.subtract(BigDecimal("0.40")), currentGold.add(BigDecimal("0.20")), currentGold, "0.60"),
                        SgeMockProduct("iAu99.99", currentGold.subtract(BigDecimal("1.20")), currentGold.add(BigDecimal("1.10")), currentGold, "2.30")
                    )
                } else {
                    val silG = currentSilver.divide(BigDecimal("1000"), 4, RoundingMode.HALF_UP)
                    listOf(
                        SgeMockProduct("Ag99.99", silG.subtract(BigDecimal("0.02")), silG.add(BigDecimal("0.01")), silG, "0.03"),
                        SgeMockProduct("Ag(T+D)", silG.subtract(BigDecimal("0.05")), silG.add(BigDecimal("0.04")), silG.subtract(BigDecimal("0.01")), "0.09")
                    )
                }

                LazyColumn(modifier = Modifier.height(200.dp)) {
                    items(products) { prod ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(BorderStroke(0.5.dp, BorderBronze))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = prod.name, color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                            Text(text = "¥${prod.bid}", color = WarmIvory, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                            Text(text = "¥${prod.ask}", color = WarmIvory, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                            Text(text = "¥${prod.last}", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                            Text(text = "${prod.spread}", color = MutedGrey, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Canvas chart
        Text(
            text = if (state.isEnglish) "SPOT INTRADAY PRICE ACTION CHART" else "金瑞即期黄金日内波幅分时图 (模拟数据)",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        PrestigeLineChart(points = getMockChartPoints(marketTabSelection == 0))
    }
}

data class SgeMockProduct(
    val name: String,
    val bid: BigDecimal,
    val ask: BigDecimal,
    val last: BigDecimal,
    val spread: String
)

@Composable
fun PrestigeLineChart(points: List<Float>) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .background(CardSurface, RoundedCornerShape(8.dp))
            .border(1.dp, BorderBronze, RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        val width = size.width
        val height = size.height
        val maxPoint = points.maxOrNull() ?: 1f
        val minPoint = points.minOrNull() ?: 0f
        val range = (maxPoint - minPoint).coerceAtLeast(0.1f)

        val path = Path()
        val fillPath = Path()

        points.forEachIndexed { idx, pt ->
            val x = (idx.toFloat() / (points.size - 1)) * width
            val y = height - (((pt - minPoint) / range) * height)

            if (idx == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, height)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (idx == points.size - 1) {
                fillPath.lineTo(x, height)
                fillPath.close()
            }
        }

        // Draw background grid lines
        val gridLines = 4
        for (i in 1..gridLines) {
            val gridY = (height / (gridLines + 1)) * i
            drawLine(
                color = Color(0x1F8F7643),
                start = Offset(0f, gridY),
                end = Offset(width, gridY),
                strokeWidth = 1f
            )
        }

        // Fill area
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x3DFFD700), Color(0x00FFD700))
            )
        )

        // Draw line
        drawPath(
            path = path,
            color = GoldPrimary,
            style = Stroke(width = 3f)
        )
    }
}

private fun getMockChartPoints(isGold: Boolean): List<Float> {
    return if (isGold) {
        listOf(605f, 606.2f, 605.8f, 607.1f, 606.5f, 608.2f, 607.4f, 608.5f)
    } else {
        listOf(7.12f, 7.15f, 7.14f, 7.18f, 7.16f, 7.21f, 7.19f, 7.23f)
    }
}

// ------------------------------
// TAB 2: 交易大厅 (Dealer RFQ & Book)
// ------------------------------
@Composable
fun TradingTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    var isBuySelected by remember { mutableStateOf(true) }
    var selectedMetal by remember { mutableStateOf(MetalType.GOLD) }
    var qtyGramsStr by remember { mutableStateOf("1000") }
    var premiumStr by remember { mutableStateOf("0.50") }
    var selectedClientIdx by remember { mutableStateOf(0) }
    
    // Manual RFQ Inputs
    var rfqWeightKgStr by remember { mutableStateOf("5") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (state.isEnglish) "INSTITUTIONAL PRECIOUS METALS DEALING ROOM" else "金瑞贵金属大宗询价与即期交易台",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Quick Execution Ticket & RFQ Generator
            Column(modifier = Modifier.weight(1.2f)) {
                // RFQ Generator Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (state.isEnglish) "CREATE SGE BLOCK RFQ" else "向上海金所(SGE)发起询价单 (RFQ)",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { selectedMetal = MetalType.GOLD },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedMetal == MetalType.GOLD) GoldPrimary else CardSurface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("rfq_gold_toggle")
                            ) {
                                Text(
                                    text = if (state.isEnglish) "Gold Au" else "黄金 (Au)",
                                    color = if (selectedMetal == MetalType.GOLD) InkBlackBg else WarmIvory
                                )
                            }
                            Button(
                                onClick = { selectedMetal = MetalType.SILVER },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedMetal == MetalType.SILVER) GoldPrimary else CardSurface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("rfq_silver_toggle")
                            ) {
                                Text(
                                    text = if (state.isEnglish) "Silver Ag" else "白银 (Ag)",
                                    color = if (selectedMetal == MetalType.SILVER) InkBlackBg else WarmIvory
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = rfqWeightKgStr,
                            onValueChange = { rfqWeightKgStr = it },
                            label = { Text(if (state.isEnglish) "Total Weight (Kilograms)" else "委托数量 (公斤 kg)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("rfq_weight_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = BorderBronze
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val wKg = rfqWeightKgStr.toBigDecimalOrNull() ?: BigDecimal("5")
                                val client = state.clients.getOrNull(selectedClientIdx)?.nameCn ?: "自营交易台"
                                viewModel.createRFQ(client, selectedMetal, wKg, selectedMetal.defaultPurity)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ChineseRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("rfq_submit_btn")
                        ) {
                            Text(
                                text = if (state.isEnglish) "BROADCAST RFQ TO EXCHANGES" else "向金所网络广播询价单 (RFQ)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Buy / Sell Direct Ticket
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (state.isEnglish) "MANUAL DIRECT DEAL TICKET" else "即期现货直达交易单",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Buy/Sell Toggles
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { isBuySelected = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isBuySelected) DarkJade else CardSurface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("ticket_buy_toggle")
                            ) {
                                Text(
                                    text = if (state.isEnglish) "BUY (买入)" else "买入 (BUY)",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { isBuySelected = false },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isBuySelected) ChineseRed else CardSurface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("ticket_sell_toggle")
                            ) {
                                Text(
                                    text = if (state.isEnglish) "SELL (卖出)" else "卖出 (SELL)",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Client Select Dropdown simulation
                        Text(
                            text = if (state.isEnglish) "Counterparty Customer" else "交易对手商户",
                            color = MutedGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(CardSurface)
                                .border(1.dp, BorderBronze)
                                .clickable {
                                    selectedClientIdx = (selectedClientIdx + 1) % state.clients.size
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val clientName = state.clients.getOrNull(selectedClientIdx)?.nameCn ?: "散客"
                            Text(text = clientName, color = WarmIvory, fontSize = 12.sp)
                            Icon(Icons.Filled.Refresh, contentDescription = "Switch Client", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = qtyGramsStr,
                            onValueChange = { qtyGramsStr = it },
                            label = { Text(if (state.isEnglish) "Quantity (Grams)" else "即期交易数量 (克 g)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("trade_qty_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = BorderBronze
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = premiumStr,
                            onValueChange = { premiumStr = it },
                            label = { Text(if (state.isEnglish) "Markup Premium (CNY/g)" else "点差升水调减 (元/克)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("trade_premium_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = BorderBronze
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // PRICING ENGINE PROVENANCE BREAKDOWN
                        val qtyG = qtyGramsStr.toBigDecimalOrNull() ?: BigDecimal.ZERO
                        val prem = premiumStr.toBigDecimalOrNull() ?: BigDecimal.ZERO
                        val baseSpot = if (selectedMetal == MetalType.GOLD) state.spotGoldCnyG else state.spotSilverCnyKg.divide(BigDecimal("1000"), 4, RoundingMode.HALF_UP)
                        val finalPricePerG = baseSpot.add(prem)
                        val grandTotal = qtyG.multiply(finalPricePerG).setScale(2, RoundingMode.HALF_UP)

                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (state.isEnglish) "PRICING ENGINE INVOICING" else "定价引擎发票级核验单",
                                    color = GoldPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = if (state.isEnglish) "SGE Base Price" else "交易所公允底价", color = MutedGrey, fontSize = 11.sp)
                                    Text(text = "¥${baseSpot} /g", color = WarmIvory, fontSize = 11.sp)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = if (state.isEnglish) "Adjustment Premium" else "特定商户等级加点", color = MutedGrey, fontSize = 11.sp)
                                    Text(text = "+¥${prem} /g", color = GoldAccent, fontSize = 11.sp)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = BorderBronze)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = if (state.isEnglish) "Total Due" else "应付总款 (RMB)", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "¥${grandTotal}", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val clientName = state.clients.getOrNull(selectedClientIdx)?.nameCn ?: "散客"
                                viewModel.executeTrade(
                                    rfqId = null,
                                    side = if (isBuySelected) "BUY" else "SELL",
                                    clientName = clientName,
                                    metal = selectedMetal,
                                    grams = qtyG,
                                    priceG = baseSpot,
                                    premium = prem
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("trade_execute_btn")
                        ) {
                            Text(
                                text = if (state.isEnglish) "EXECUTE SECURE TRANSACTION" else "签名并确认执行交易",
                                color = InkBlackBg,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Right: Live RFQ Queue & Ledger
            Column(modifier = Modifier.weight(1f)) {
                // Live RFQs
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (state.isEnglish) "ACTIVE SGE RFQ QUEUE" else "活跃询价队列 (RFQs)",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        if (state.rfqList.isEmpty()) {
                            Text(
                                text = if (state.isEnglish) "No active RFQs" else "暂无待处理询价单",
                                color = MutedGrey,
                                fontSize = 11.sp
                            )
                        } else {
                            LazyColumn(modifier = Modifier.height(140.dp)) {
                                items(state.rfqList) { rfq ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(CardSurface, RoundedCornerShape(4.dp))
                                            .clickable {
                                                // Pre-populate directly
                                                qtyGramsStr = rfq.quantityGrams.toString()
                                                premiumStr = rfq.dealerOffer.subtract(rfq.basePrice).toString()
                                                selectedMetal = rfq.metalType
                                            }
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = rfq.id, color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(text = rfq.clientName, color = WarmIvory, fontSize = 10.sp)
                                            Text(text = "${rfq.spec} @ ¥${rfq.basePrice}/g", color = MutedGrey, fontSize = 9.sp)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (rfq.status == "待处理") ChineseRed else DarkJade,
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(text = rfq.status, color = Color.White, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Invariant Ledger Log
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (state.isEnglish) "DOUBLE-ENTRY METAL LEDGER" else "复式借贷金属日记账簿",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (state.isEnglish) "INVARIANT: DEBITS = CREDITS" else "记账约束: 借方 ≡ 贷方",
                                color = DarkJade,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "DEBITS: ¥${state.totalDebitsCny}",
                                color = WarmIvory,
                                fontSize = 9.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (state.ledgerEntries.isEmpty()) {
                            Text(
                                text = if (state.isEnglish) "No transactions recorded yet" else "暂无入账实体分录",
                                color = MutedGrey,
                                fontSize = 10.sp
                            )
                        } else {
                            LazyColumn(modifier = Modifier.height(200.dp)) {
                                items(state.ledgerEntries) { entry ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(BorderStroke(0.5.dp, BorderBronze))
                                            .padding(6.dp)
                                    ) {
                                        Text(text = if (state.isEnglish) entry.memoEn else entry.memoCn, color = WarmIvory, fontSize = 10.sp)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "借: ${entry.accountDebit}", color = GoldPrimary, fontSize = 9.sp)
                                            Text(text = "贷: ${entry.accountCredit}", color = MutedGrey, fontSize = 9.sp)
                                            Text(text = "¥${entry.amount}", color = GoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------
// TAB 3: 实物金库 & 金条扫码 (Vault & Custody)
// ------------------------------
@Composable
fun VaultTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    var filterMetal by remember { mutableStateOf<MetalType?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (state.isEnglish) "PHYSICAL BULLION CUSTODY & VAULT CONTROLS" else "金瑞实物贵金属金库与提货控制台",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column: Vault Map & Holographic Bar Scanner
            Column(modifier = Modifier.weight(1.1f)) {
                // Barcode scanner holographic simulation
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (state.isEnglish) "INTELLIGENT LASER BULLION SCANNER" else "高防伪物理金锭红外扫码器",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Scanner holographic laser container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .background(InkBlackBg, RoundedCornerShape(8.dp))
                                .border(1.dp, GoldSecondary, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Glowing laser line animation simulation
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.dp)
                                    .background(ChineseRed)
                            )
                            Text(
                                text = if (state.isEnglish) "[ALIGN SGE BARCODE]" else "[请对准金条国标二维码或证书编号]",
                                color = MutedGrey,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = state.barcodeInput,
                                onValueChange = { viewModel.enterBarcode(it) },
                                label = { Text(if (state.isEnglish) "Input Serial Number" else "输入金条国标编码") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("barcode_input_field"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = BorderBronze
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { viewModel.triggerBarcodeScan() },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("barcode_scan_btn")
                            ) {
                                Text(if (state.isEnglish) "SCAN" else "识读", color = InkBlackBg)
                            }
                        }
                    }
                }

                // Gold Assay Quality Record
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (state.isEnglish) "NATIONAL GB COMPLIANCE ASSAY REPORT" else "国家贵金属鉴定实验室检测追溯 (GB 11887)",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(CardSurface, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text(text = "收货 / Receipt", color = DarkJade, fontSize = 9.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .background(CardSurface, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text(text = "取样 / Sample", color = DarkJade, fontSize = 9.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .background(CardSurface, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text(text = "检测 / Assay", color = DarkJade, fontSize = 9.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .background(GoldSecondary, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text(text = "已入库 / Verified", color = InkBlackBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (state.isEnglish) {
                                "Methods: Fire Assay & High-precision density testing. Certified by China National Jewellery Quality Supervision & Assay Center."
                            } else {
                                "检测手段：熔炼火法分析与高精度比重二次复核。检测机构：国家首饰质量监督检验中心，结果完全符合国标首饰及投资金条规范。"
                            },
                            fontSize = 9.sp,
                            color = MutedGrey
                        )
                    }
                }
            }

            // Right Column: Active Scanned Certificate or Bullion List
            Column(modifier = Modifier.weight(1f)) {
                // If a bar is selected / scanned, show certificate
                if (state.scannedBar != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardSurface),
                        border = BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (state.isEnglish) "OFFICIAL SGE BULLION CERTIFICATE" else "上海黄金交易所正规金锭保管凭证",
                                color = GoldPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            // Bar Serial Code
                            Text(
                                text = "SERIAL: ${state.scannedBar.serialNumber}",
                                color = WarmIvory,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            CertificateRow(
                                label = if (state.isEnglish) "Metal / Purity" else "金属材质 / 纯度",
                                value = "${state.scannedBar.metalType.cnName} (Au${state.scannedBar.purity})"
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Gross Weight" else "实测毛重 (克 g)",
                                value = "${state.scannedBar.grossWeight} g"
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Fine Metal Weight" else "核定折纯重量",
                                value = "${state.scannedBar.getFineWeight()} g"
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Refiner Mint" else "精炼精造商",
                                value = state.scannedBar.manufacturer
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Storage Location" else "物理保管金库",
                                value = if (state.isEnglish) state.scannedBar.location.enName else state.scannedBar.location.cnName
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Owner Entity" else "确权所有权人",
                                value = if (state.isEnglish) state.scannedBar.ownerNameEn else state.scannedBar.ownerNameCn
                            )
                            CertificateRow(
                                label = if (state.isEnglish) "Custody Status" else "确权托管状态",
                                value = if (state.isEnglish) state.scannedBar.statusEn else state.scannedBar.statusCn
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                                    .background(InkBlackBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "QR-ABSTRACT: JINRUI•CRYPTOGRAPHIC•BLOCKCHAIN•TRACE",
                                    color = MutedGrey,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Vault physical list selector
                Text(
                    text = if (state.isEnglish) "SELECT BAR TO SCAN / AUDIT" else "选择要盘点/识读的物理金锭",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                LazyColumn(modifier = Modifier.height(120.dp)) {
                    items(state.bullionBars) { bar ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(BorderStroke(0.5.dp, BorderBronze))
                                .background(if (state.scannedBar?.id == bar.id) CardSurface else WarmSurface)
                                .clickable { viewModel.selectBar(bar) }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = bar.serialNumber, color = WarmIvory, fontSize = 11.sp)
                            Text(text = "${bar.grossWeight}g", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CertificateRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MutedGrey, fontSize = 11.sp)
        Text(text = value, color = WarmIvory, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ------------------------------
// TAB 4: 珠宝商户 POS & 黄金回收 & 以旧换新
// ------------------------------
@Composable
fun POSAndMerchantTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    var discountSelectionIdx by remember { mutableStateOf(0) }
    val discounts = listOf(BigDecimal("1.0"), BigDecimal("0.95"), BigDecimal("0.90"))
    val discountLabels = listOf("无折扣 (100%)", "尊享95折 (95%)", "会员特惠9折 (90%)")

    var isRecycleMode by remember { mutableStateOf(true) } // true: 回收, false: 以旧换新

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Retail Dashboard Stats
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            border = BorderStroke(1.dp, BorderBronze),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (state.isEnglish) "JEWELLERY RETAIL MERCHANT DASHBOARD" else "金瑞联营珠宝零售商户终端",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MerchantStat(title = if (state.isEnglish) "TODAY SALES" else "今日零售额", valStr = "¥2,850,000", color = GoldAccent)
                    MerchantStat(title = if (state.isEnglish) "GOLD RECYCLING" else "黄金已回收", valStr = "3.84 公斤/kg", color = GoldPrimary)
                    MerchantStat(title = if (state.isEnglish) "EST. NET MARGIN" else "估算实现利润", valStr = "¥154,800", color = DarkJade)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column: POS scan and catalog
            Column(modifier = Modifier.weight(1.1f)) {
                Text(
                    text = if (state.isEnglish) "JEWELLERY PRODUCT CATALOG" else "联营商品POS直接结算清单",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                // Select Discount Level
                Text(
                    text = if (state.isEnglish) "Apply Retail Discount" else "选择零售会员折扣",
                    color = MutedGrey,
                    fontSize = 10.sp
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(CardSurface)
                        .border(1.dp, BorderBronze)
                        .clickable {
                            discountSelectionIdx = (discountSelectionIdx + 1) % discounts.size
                        }
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = discountLabels[discountSelectionIdx], color = WarmIvory, fontSize = 12.sp)
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = "Dropdown", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.height(280.dp)) {
                    items(state.jewelleryList) { prod ->
                        val price = prod.calculateRetailPrice(state.spotGoldCnyG, discounts[discountSelectionIdx])
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(BorderStroke(0.5.dp, BorderBronze))
                                .background(WarmSurface)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(text = prod.nameCn, color = WarmIvory, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "克重: ${prod.grossWeight}g | 工费: ¥${prod.makingChargePerGram}/g", color = MutedGrey, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                Text(text = "¥$price", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = { viewModel.sellJewelleryProduct(prod, discounts[discountSelectionIdx]) },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldSecondary),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .height(26.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("pos_sell_btn_${prod.id}")
                                ) {
                                    Text(if (state.isEnglish) "SELL" else "销售", color = WarmIvory, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Right Column: Recycling and Trade-in Operations
            Column(modifier = Modifier.weight(1f)) {
                // Toggles for Recycling vs Trade-in
                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { isRecycleMode = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRecycleMode) GoldPrimary else CardSurface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("recycle_mode_toggle")
                    ) {
                        Text(
                            text = if (state.isEnglish) "Recycle (回收)" else "黄金回收 (Recycle)",
                            color = if (isRecycleMode) InkBlackBg else WarmIvory,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Button(
                        onClick = { isRecycleMode = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isRecycleMode) GoldPrimary else CardSurface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("exchange_mode_toggle")
                    ) {
                        Text(
                            text = if (state.isEnglish) "Trade-in (换新)" else "以旧换新 (Trade-in)",
                            color = if (!isRecycleMode) InkBlackBg else WarmIvory,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isRecycleMode) {
                    // Recycling Workspace
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarmSurface),
                        border = BorderStroke(1.dp, BorderBronze)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (state.isEnglish) "GOLD RECYCLING CALCULATOR" else "黄金回收鉴定精算器",
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = state.recycleGrossWeight,
                                onValueChange = { viewModel.performGoldRecycling(it.toDoubleOrNull() ?: 0.0, state.recyclePurityType) },
                                label = { Text(if (state.isEnglish) "Gross Weight (Grams)" else "旧金实测毛重 (克)") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("recycle_weight_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = BorderBronze
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (state.isEnglish) "Purity Grade" else "首饰声明纯度/成色",
                                color = MutedGrey,
                                fontSize = 10.sp
                            )
                            val purities = listOf("916 (22K)", "999 (足金)", "750 (18K)", "9999 (万足金)")
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CardSurface)
                                    .border(1.dp, BorderBronze)
                                    .clickable {
                                        val curIdx = purities.indexOf(state.recyclePurityType)
                                        val nextIdx = (curIdx + 1) % purities.size
                                        viewModel.performGoldRecycling(
                                            state.recycleGrossWeight.toDoubleOrNull() ?: 0.0,
                                            purities[nextIdx]
                                        )
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = state.recyclePurityType, color = WarmIvory, fontSize = 11.sp)
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = "Dropdown", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Print receipt mockup
                            if (state.recycleReceipt != null) {
                                Text(
                                    text = state.recycleReceipt,
                                    color = GoldAccent,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier
                                        .background(InkBlackBg, RoundedCornerShape(4.dp))
                                        .padding(8.dp)
                                        .fillMaxWidth()
                                )
                            }
                        }
                    }
                } else {
                    // Trade-in Old for New Workspace
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarmSurface),
                        border = BorderStroke(1.dp, BorderBronze)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (state.isEnglish) "OLD-FOR-NEW GOLD EXCHANGE" else "以旧换新精算控制台",
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = state.exchangeOldWeight,
                                onValueChange = { viewModel.performOldForNewExchange(it, state.exchangeNewProductCode) },
                                label = { Text(if (state.isEnglish) "Old Gold Weight (Grams)" else "旧金克重 (克)") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("exchange_old_weight_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = BorderBronze
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (state.isEnglish) "Select Target New Jewellery" else "选择兑换的新珠宝商品",
                                color = MutedGrey,
                                fontSize = 10.sp
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CardSurface)
                                    .border(1.dp, BorderBronze)
                                    .clickable {
                                        val curIdx = state.jewelleryList.indexOfFirst { it.id == state.exchangeNewProductCode }
                                        val nextIdx = (curIdx + 1) % state.jewelleryList.size
                                        val nextProduct = state.jewelleryList[nextIdx]
                                        viewModel.performOldForNewExchange(state.exchangeOldWeight, nextProduct.id)
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val targetProdName = state.jewelleryList.find { it.id == state.exchangeNewProductCode }?.nameCn ?: "Ruyi Gold Bangle"
                                Text(text = targetProdName, color = WarmIvory, fontSize = 11.sp)
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = "Dropdown", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            if (state.exchangeResultTextCn.isNotEmpty()) {
                                Text(
                                    text = if (state.isEnglish) state.exchangeResultTextEn else state.exchangeResultTextCn,
                                    color = GoldPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(InkBlackBg, RoundedCornerShape(4.dp))
                                        .padding(8.dp)
                                        .fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MerchantStat(title: String, valStr: String, color: Color) {
    Column {
        Text(text = title, color = MutedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(text = valStr, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------
// TAB 5: 风险管理 & 情景实验室 (Risk & Scenarios)
// ------------------------------
@Composable
fun RiskAndScenarioTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (state.isEnglish) "INSTITUTIONAL RISK CONTROLS & HEDGING ALIGNMENT" else "金瑞大宗商品风险防范与衍生套期对冲台",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Hedge effectiveness & stress testing
            Column(modifier = Modifier.weight(1f)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (state.isEnglish) "HEDGE EFFECTIVENESS AUDITOR" else "衍生对冲有效性实时监测",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        val goldNetExpG = state.physicalGoldExposureG.subtract(state.goldHedgeGrams)
                        val effGold = state.goldHedgeGrams.multiply(BigDecimal("100")).divide(state.physicalGoldExposureG.max(BigDecimal.ONE), 1, RoundingMode.HALF_UP)

                        Text(
                            text = if (state.isEnglish) "Gold Hedge Effectiveness: $effGold%" else "黄金套保有效比率: $effGold%",
                            color = if (effGold > BigDecimal("80")) DarkJade else ChineseRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (state.isEnglish) {
                                "Physical Spot Gold: ${state.physicalGoldExposureG.divide(BigDecimal("1000"))}kg\nDerivative Fut Hedge: ${state.goldHedgeGrams.divide(BigDecimal("1000"))}kg\nNet Price Exposure: ${goldNetExpG.divide(BigDecimal("1000"))}kg"
                            } else {
                                "实物现货存栏: ${state.physicalGoldExposureG.divide(BigDecimal("1000"))} 公斤\n衍生品空头对冲: ${state.goldHedgeGrams.divide(BigDecimal("1000"))} 公斤\n敞口净暴露: ${goldNetExpG.divide(BigDecimal("1000"))} 公斤"
                            },
                            color = WarmIvory,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .background(InkBlackBg, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                    }
                }

                // Interactive Stress Test Box
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    border = BorderStroke(1.dp, BorderBronze)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (state.isEnglish) "EXTREME MARKET STRESS TESTING" else "极限制极限压力测试 (STRESS TEST)",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (state.isEnglish) {
                                "Configure simulated catastrophic event: Gold -12%, Silver -18%, Counterparty defaults ¥500,000,000."
                            } else {
                                "模拟宏观危机情景：黄金下跌12%，白银下跌18%，对手方信贷违约，计算本金吸收流动性缺口。"
                            },
                            color = MutedGrey,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.triggerClientDefaultStress(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = ChineseRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("stress_test_btn")
                        ) {
                            Text(if (state.isEnglish) "INJECT EXTREME STRESS EVENT" else "注入极端系统压力", color = Color.White)
                        }

                        if (state.isClientDefaultStressed) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (state.isEnglish) {
                                    "⚠️ ALERT: Liquidity buffer dropped 30%. Potential credit default loss: ¥14,200,000. Capital adequacy critical!"
                                } else {
                                    "⚠️ 压力警告：流动性缓冲骤降30%。信贷违约预期损失：¥1,420万元。资本充足率亮黄灯，请速补充对冲保证金！"
                                },
                                color = ChineseRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Right: Scenario Lab Dynamic Sliders
            Column(modifier = Modifier.weight(1.1f)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSurface),
                    border = BorderStroke(1.dp, BorderBronze)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (state.isEnglish) "SCENARIO ANALYSIS LAB" else "情景微调仿真实验室",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Slider 1: Gold Price Pct Change
                        Text(
                            text = if (state.isEnglish) "Gold Spot Price shift: ${String.format("%.1f", state.scenarioGoldChangePct)}%" else "黄金价格拟合变动: ${String.format("%.1f", state.scenarioGoldChangePct)}%",
                            color = WarmIvory,
                            fontSize = 11.sp
                        )
                        Slider(
                            value = state.scenarioGoldChangePct.toFloat(),
                            onValueChange = { viewModel.updateScenarioGold(it.toDouble()) },
                            valueRange = -15f..15f,
                            colors = SliderDefaults.colors(thumbColor = GoldPrimary, activeTrackColor = GoldPrimary),
                            modifier = Modifier.testTag("scenario_gold_slider")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Slider 2: Silver Price Pct Change
                        Text(
                            text = if (state.isEnglish) "Silver Spot Price shift: ${String.format("%.1f", state.scenarioSilverChangePct)}%" else "白银价格拟合变动: ${String.format("%.1f", state.scenarioSilverChangePct)}%",
                            color = WarmIvory,
                            fontSize = 11.sp
                        )
                        Slider(
                            value = state.scenarioSilverChangePct.toFloat(),
                            onValueChange = { viewModel.updateScenarioSilver(it.toDouble()) },
                            valueRange = -15f..15f,
                            colors = SliderDefaults.colors(thumbColor = GoldPrimary, activeTrackColor = GoldPrimary),
                            modifier = Modifier.testTag("scenario_silver_slider")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Slider 3: CNY Depreciation
                        Text(
                            text = if (state.isEnglish) "RMB Depreciation shift: ${String.format("%.1f", state.scenarioCnyDepreciationPct)}%" else "人民币汇率贬值幅度: ${String.format("%.1f", state.scenarioCnyDepreciationPct)}%",
                            color = WarmIvory,
                            fontSize = 11.sp
                        )
                        Slider(
                            value = state.scenarioCnyDepreciationPct.toFloat(),
                            onValueChange = { viewModel.updateScenarioCnyDeprec(it.toDouble()) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = GoldPrimary, activeTrackColor = GoldPrimary),
                            modifier = Modifier.testTag("scenario_fx_slider")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Dynamic Portfolio re-valuation display
                        val revalGold = state.spotGoldCnyG.multiply(state.physicalGoldExposureG).setScale(0, RoundingMode.HALF_UP)
                        val revalSilver = state.spotSilverCnyKg.multiply(state.physicalSilverExposureG.divide(BigDecimal("1000"))).setScale(0, RoundingMode.HALF_UP)
                        val totalAssetVal = revalGold.add(revalSilver)

                        Text(
                            text = if (state.isEnglish) {
                                "DYNAMICS ESTIMATED PORTFOLIO VALUE:\n👉 ¥$totalAssetVal CNY\n(Gold: ¥$revalGold, Silver: ¥$revalSilver)"
                            } else {
                                "情景下估算贵金属库存资产总值：\n👉 ¥$totalAssetVal 元\n(其中黄金价值: ¥$revalGold, 白银价值: ¥$revalSilver)"
                            },
                            color = GoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(InkBlackBg, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                                .fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------
// TAB 6: 金瑞 AI 助手 (AI Assistant)
// ------------------------------
@Composable
fun AiAssistantTab(state: JinruiUiState, viewModel: JinruiViewModel) {
    val keyboard = LocalSoftwareKeyboardController.current

    val promptChipsCn = listOf("现在黄金库存是多少？", "上海金库里有多少黄金？", "今天交易损益是多少？", "哪些客户超过额度？")
    val promptChipsEn = listOf("How much gold inventory?", "Shanghai vault status?", "Daily realized P&L?", "Any credit warnings?")

    val chips = if (state.isEnglish) promptChipsEn else promptChipsCn

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = if (state.isEnglish) "JINRUI AI FINANCIAL ASSISTANT" else "金瑞大宗数智金政助理 (Bilingual AI)",
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Text(
            text = if (state.isEnglish) "Real-time query engine strictly verified against physical warehouse data" else "双语AI大模型分析内核，实时穿透物理金锭与借贷账簿数据",
            color = MutedGrey,
            fontSize = 10.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Prompt Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            chips.forEach { chipText ->
                Button(
                    onClick = { viewModel.setAiInputText(chipText) },
                    colors = ButtonDefaults.buttonColors(containerColor = CardSurface),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .height(28.dp)
                        .minimumInteractiveComponentSize()
                ) {
                    Text(text = chipText, color = GoldAccent, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Messages Box
        Card(
            colors = CardDefaults.cardColors(containerColor = WarmSurface),
            border = BorderStroke(1.dp, BorderBronze),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state.aiMessages.isEmpty()) {
                    item {
                        Text(
                            text = if (state.isEnglish) {
                                "Hello! I am Jinrui AI. Tap any quick prompt above or type a custom financial query to inspect live gold/silver books dynamically."
                            } else {
                                "您好！我是金瑞金政指令 AI。我可以实时帮您透视金库内金锭物理库存、检查客户的授信风险指标或今日零售损益，请在下方发送指令。"
                            },
                            color = GoldAccent,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                } else {
                    items(state.aiMessages) { msg ->
                        val isUser = msg.sender == "USER"
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Text(
                                text = if (isUser) (if (state.isEnglish) "Trader Console" else "交易员指令") else "JINRUI AI",
                                color = if (isUser) GoldPrimary else GoldAccent,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isUser) CardSurface else BorderBronze)
                                    .padding(10.dp)
                                    .widthIn(max = 280.dp)
                            ) {
                                Text(
                                    text = msg.content,
                                    color = WarmIvory,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Inputs
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.aiInputText,
                onValueChange = { viewModel.setAiInputText(it) },
                placeholder = { Text(if (state.isEnglish) "Ask Jinrui AI..." else "向金瑞助理提问...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = BorderBronze
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    viewModel.sendAiMessage()
                    keyboard?.hide()
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("ai_send_btn")
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = InkBlackBg)
            }
        }
    }
}

// ------------------------------
// Right Sidebar: Live Tickers & Risk Panel
// ------------------------------
@Composable
fun JinruiRightSidebar(state: JinruiUiState, viewModel: JinruiViewModel) {
    Surface(
        color = WarmSurface,
        modifier = Modifier
            .width(220.dp)
            .fillMaxHeight()
            .border(BorderStroke(1.dp, BorderBronze))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = if (state.isEnglish) "REAL-TIME ALERTS" else "实时风控与即期播报",
                color = GoldPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Dynamic risk warning panel
            if (state.riskWarningMsgCn != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ChineseRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .border(1.dp, ChineseRed, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (state.isEnglish) state.riskWarningMsgEn!! else state.riskWarningMsgCn,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkJade.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .border(1.dp, DarkJade, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (state.isEnglish) "✔ EXPOSURES WELL HEDGED" else "✔ 实物资产敞口风险平稳",
                        color = DarkJade,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dynamic ticking feeds
            Text(
                text = if (state.isEnglish) "SIMULATED SGE FEED" else "即期对冲底价源",
                color = MutedGrey,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            TickingFeedRow(label = "Au Spot (g)", value = "¥${state.spotGoldCnyG}", isUp = true)
            TickingFeedRow(label = "Ag Spot (kg)", value = "¥${state.spotSilverCnyKg}", isUp = false)
            TickingFeedRow(label = "USD/CNY", value = "${state.fxUsdCny}", isUp = true)
            TickingFeedRow(label = "Intl Gold (oz)", value = "$${state.intlGoldUsdOz}", isUp = true)
            TickingFeedRow(label = "Intl Silver (oz)", value = "$${state.intlSilverUsdOz}", isUp = false)

            Spacer(modifier = Modifier.height(16.dp))

            // System Logs / Recent events
            Text(
                text = if (state.isEnglish) "AUDIT LOG TRACK" else "金所清算审计追踪",
                color = MutedGrey,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            state.trades.take(4).forEach { tr ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(CardSurface, RoundedCornerShape(4.dp))
                        .padding(6.dp)
                ) {
                    Text(text = tr.id, color = GoldAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${if (tr.side == "BUY") "买入" else "卖出"} ${tr.quantityGrams}g ${tr.metalType.cnName}", color = WarmIvory, fontSize = 9.sp)
                    Text(text = "总额: ¥${tr.totalAmount}", color = MutedGrey, fontSize = 8.sp)
                }
            }
        }
    }
}

@Composable
fun TickingFeedRow(label: String, value: String, isUp: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = WarmIvory, fontSize = 10.sp)
        Text(
            text = value,
            color = if (isUp) GoldPrimary else WarmIvory,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
