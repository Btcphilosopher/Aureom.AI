package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.foundation.shape.CircleShape
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChinaGreenDown
import com.example.ui.theme.ChinaRedUp
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SilverGray

// ================== 1. 首页 (HomeScreen) ==================
@Composable
fun HomeScreen(vm: MainViewModel) {
    val gold by vm.goldPrice.collectAsState()
    val silver by vm.silverPrice.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_scroll")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Premium Logo Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "金银超级零售",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = PremiumGold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "中国黄金白银数字化交割与超级零售终端",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Hero 行情双核卡片
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 黄金行情核
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { vm.currentTab = "MARKET" },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderBorder(PremiumGold.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(PremiumGold)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("今日黄金", fontSize = 12.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "¥${String.format("%.2f", gold.buyPrice)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        PriceChangeIndicator(gold.changeAmount, gold.changeRate)
                    }
                }

                // 白银行情核
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { vm.currentTab = "MARKET" },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderBorder(SilverGray.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(SilverGray)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("今日白银", fontSize = 12.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "¥${String.format("%.2f", silver.buyPrice)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        PriceChangeIndicator(silver.changeAmount, silver.changeRate)
                    }
                }
            }
        }

        // 核心四大服务入口 CTA
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("贵金属核心业务", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ServiceItem(Icons.Default.ShoppingBag, "立即买金", "SHOP") { vm.currentTab = "SHOP" }
                        ServiceItem(Icons.Default.CompareArrows, "以旧换新", "DEMO") {
                            vm.currentTab = "DEMO"
                            vm.currentDemoIndex = 2
                        }
                        ServiceItem(Icons.Default.Payments, "黄金回购", "MINE") {
                            vm.currentTab = "DEMO"
                            vm.currentDemoIndex = 0 // 指引去回购区
                        }
                        ServiceItem(Icons.Default.Security, "数字金库", "VAULT") { vm.currentTab = "VAULT" }
                    }
                }
            }
        }

        // 我的实时数字化资产概要
        item {
            val totalWorth = (vm.userGoldBalance * gold.buyPrice) + (vm.userSilverBalance * silver.buyPrice)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderBorder(PremiumGold.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(PremiumGold.copy(alpha = 0.08f), Color.Transparent)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("数字化托管账户", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "实名认证会员",
                            color = PremiumGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("托管估值总额 (元)", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = "¥${String.format("%,.2f", totalWorth)}",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PremiumGold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        AssetMiniLabel("黄金总资产", "${String.format("%.2f", vm.userGoldBalance)}g")
                        AssetMiniLabel("白银总资产", "${String.format("%.1f", vm.userSilverBalance)}g")
                        AssetMiniLabel("预付准备金", "¥${String.format("%,.0f", vm.userCashBalance)}")
                    }
                }
            }
        }

        // 品牌三大信誉担保保障
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    GuaranteeItem("100%物理储备", "客户资产与金库实体严格1:1对应")
                    GuaranteeItem("国家质检认证", "全品类原厂出库配NGSTC国检一品一证")
                    GuaranteeItem("双重复式记账", "每笔交割同步登记贵金属与资金账本")
                }
            }
        }

        // 金银红包与大额定制卡片
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("『福泽百年』黄金红包礼赠卡", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("春节、婚庆、满月极具分量的实体黄金电子礼赠，随时可兑，真实实物担保。", fontSize = 11.sp, color = Color.Gray)
                    }
                    Button(
                        onClick = {
                            vm.currentTab = "DEMO"
                            vm.currentDemoIndex = 2 // 导向首饰/礼赠换金
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ChinaRedUp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("去选购", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ServiceItem(icon: androidx.compose.ui.graphics.vector.ImageVector, name: String, tag: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag("service_item_$tag")
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(PremiumGold.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = name, tint = PremiumGold, modifier = Modifier.size(24.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AssetMiniLabel(label: String, valStr: String) {
    Column {
        Text(label, fontSize = 10.sp, color = Color.Gray)
        Text(valStr, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun GuaranteeItem(title: String, desc: String) {
    Column(
        modifier = Modifier.width(90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = PremiumGold, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(desc, fontSize = 8.sp, color = Color.Gray, textAlign = TextAlign.Center, lineHeight = 10.sp)
    }
}


// ================== 2. 行情中心 (MarketScreen) ==================
@Composable
fun MarketScreen(vm: MainViewModel) {
    val gold by vm.goldPrice.collectAsState()
    val silver by vm.silverPrice.collectAsState()
    val history by vm.priceHistory.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: 黄金, 1: 白银, 2: 金银比与研究

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("market_screen_root")
    ) {
        TabRow(
            selectedTabIndex = activeSubTab,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = PremiumGold
        ) {
            Tab(selected = activeSubTab == 0, onClick = { activeSubTab = 0 }) {
                Text("实时黄金", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Tab(selected = activeSubTab == 1, onClick = { activeSubTab = 1 }) {
                Text("实时白银", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Tab(selected = activeSubTab == 2, onClick = { activeSubTab = 2 }) {
                Text("金银比/研究室", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SGE 适配层声明
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, tint = PremiumGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("上海黄金交易所行情适配器 (SGEDataAdapter)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("默认使用：SyntheticSGEProvider 进行高拟真撮合竞价模拟。数据每3秒自动跳动，报价LIVE生效。", fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }
            }

            if (activeSubTab == 0) {
                item {
                    MarketTickerDetailCard(gold, isGold = true)
                }
                item {
                    MiniPriceChart(history, isGold = true)
                }
                item {
                    MarketPricingEngineCard(gold, isGold = true)
                }
            } else if (activeSubTab == 1) {
                item {
                    MarketTickerDetailCard(silver, isGold = false)
                }
                item {
                    MiniPriceChart(history, isGold = false)
                }
                item {
                    MarketPricingEngineCard(silver, isGold = false)
                }
            } else {
                // 金银比与研究院
                item {
                    val ratio = gold.buyPrice / silver.buyPrice
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Gold/Silver Ratio (当前金银比)", fontSize = 12.sp, color = Color.Gray)
                            Text(
                                text = String.format("%.2f", ratio),
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PremiumGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "金银比表示1盎司黄金能购买多少盎司白银。历史中轴线在 65.0 - 75.0。当前数值处于 ${if(ratio>75) "白银被严重低估区，可能具有更高的反弹投资弹性" else "正常比例波动区间"}。仅作为研究指标，不构成个性化投资建议。",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                item {
                    Text("金银研究院 - 深度分析报告", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                }

                item {
                    ResearchReportCard("【宏观】全球央行持续增持黄金储备对人民币汇率的影响", "报告指出全球去美元化叙事下，各主要央行实物黄金购买吨数创历史新高，强力筑牢金价底部，对冲人民币长期信用溢价具有重要作用。发布时间：2026年10月。")
                }

                item {
                    ResearchReportCard("【工业】光伏银浆与半导体工业白银消耗供需缺口白皮书", "白银作为工业敏感型贵金属，随着双玻光伏组件大量排产，高纯度超细银粉消耗年均复合增长达12%。中长期白银实物库存调拨呈偏紧态势，白银金融溢价存在修复空间。发布时间：2026年10月。")
                }
            }
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun MarketTickerDetailCard(price: MetalPrice, isGold: Boolean) {
    val themeColor = if (isGold) PremiumGold else SilverGray
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderBorder(themeColor.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(if (isGold) "实时黄金 (XAU/CNY)" else "实时白银 (XAG/CNY)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("行情来源: ${price.source}", fontSize = 10.sp, color = Color.Gray)
                }
                LiveBadge(price.quality)
            }
            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1.5f)) {
                    Text("人民币申报价", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = "¥${String.format("%.2f", price.buyPrice)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (price.changeAmount >= 0) ChinaRedUp else ChinaGreenDown
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("上海金基准克价", fontSize = 10.sp, color = Color.Gray)
                    Text("¥${String.format("%.2f", price.benchmarkCnyGram)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("国际伦敦现货价", fontSize = 10.sp, color = Color.Gray)
                    Text("$${String.format("%.2f", price.benchmarkUsd)} / oz", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MarketPricingEngineCard(price: MetalPrice, isGold: Boolean) {
    val themeColor = if (isGold) PremiumGold else SilverGray
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("双向交易申报价差结构", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = themeColor)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("零售申买入价 (含税及流通渠道)", fontSize = 11.sp, color = Color.Gray)
                Text("¥${String.format("%.2f", price.buyPrice)} / 克", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("官方实物贴水回购价", fontSize = 11.sp, color = Color.Gray)
                Text("¥${String.format("%.2f", price.buybackPrice)} / 克", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("官方回收折旧点位差", fontSize = 11.sp, color = Color.Gray)
                Text("¥${String.format("%.2f", price.buyPrice - price.buybackPrice)} / 克", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
            }
        }
    }
}

@Composable
fun ResearchReportCard(title: String, summary: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(summary, fontSize = 11.sp, color = Color.Gray, lineHeight = 14.sp)
        }
    }
}


// ================== 3. 商城模块 (ShopScreen) ==================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(vm: MainViewModel) {
    var selectedCategoryIndex by remember { mutableStateOf(0) }
    val categories = listOf("全部商品", "投资金条", "投资金币", "黄金首饰", "投资白银")

    // 根据选择的类别过滤
    val filteredProducts = remember(selectedCategoryIndex) {
        when (selectedCategoryIndex) {
            1 -> SimulationData.initialProducts.filter { it.category == ProductCategory.INVESTMENT_BAR && it.metalType == MetalType.GOLD }
            2 -> SimulationData.initialProducts.filter { it.category == ProductCategory.INVESTMENT_COIN && it.metalType == MetalType.GOLD }
            3 -> SimulationData.initialProducts.filter { it.category == ProductCategory.JEWELRY && it.metalType == MetalType.GOLD }
            4 -> SimulationData.initialProducts.filter { it.metalType == MetalType.SILVER }
            else -> SimulationData.initialProducts
        }
    }

    val gold by vm.goldPrice.collectAsState()
    val silver by vm.silverPrice.collectAsState()

    var showLockDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("shop_screen_root")
    ) {
        // 分类 ScrollableTabRow
        ScrollableTabRow(
            selectedTabIndex = selectedCategoryIndex,
            containerColor = MaterialTheme.colorScheme.background,
            edgePadding = 16.dp,
            indicator = {},
            divider = {}
        ) {
            categories.forEachIndexed { i, title ->
                val isSel = selectedCategoryIndex == i
                Tab(
                    selected = isSel,
                    onClick = { selectedCategoryIndex = i },
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isSel) PremiumGold.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.surface
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSel) PremiumGold else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                ) {
                    Text(
                        text = title,
                        color = if (isSel) PremiumGold else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "品质精选大宗贵金属",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "实时双重账本清算",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }

            items(filteredProducts) { p ->
                val activeBase = if (p.metalType == MetalType.GOLD) gold.buyPrice else silver.buyPrice
                val computedPrice = RetailPricingEngine.calculateRetailPrice(p, activeBase)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_card_${p.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = p.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row {
                                    ProductTag("纯度: ${if (p.metalType == MetalType.GOLD) "足金 999.9" else "足银 99.99"}")
                                    Spacer(modifier = Modifier.width(6.dp))
                                    ProductTag("重量: ${p.weight}g")
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "¥${String.format("%,.2f", computedPrice)}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PremiumGold
                                )
                                Text(
                                    text = "约¥${String.format("%.2f", computedPrice / p.weight)}/g",
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = p.description,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            lineHeight = 14.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "库存: ${p.inStock} 件 | ${p.certificateType.substringBefore("检测")}",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )

                            Button(
                                onClick = {
                                    vm.currentSelectedProduct = p
                                    vm.orderQuantity = 1
                                    // 直接切入Demo1或在商城内锁价付款：
                                    // 最佳实践：为了向用户展示强大的60秒实时锁价交割，我们把客户导向到 DEMO 控制台直接运行 Demo 1 购买此商品，或在这里弹窗也可以！
                                    // 为了能让用户看到 4 大核心端到端演示，直接跳转 Demo 控制台，这样体验最连贯。
                                    vm.currentDemoIndex = 1 // 触发黄金购买托管
                                    vm.currentTab = "DEMO"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("buy_btn_${p.id}")
                            ) {
                                Text("立即锁价申购", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun ProductTag(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text, fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
    }
}


// ================== 4. 金库与数字孪生 (VaultScreen) ==================
@Composable
fun VaultScreen(vm: MainViewModel) {
    val goldList by vm.userGoldBars.collectAsState()
    val silverList by vm.userSilverBars.collectAsState()
    val vaultsList by vm.vaults.collectAsState()

    var selectedVault by remember { mutableStateOf(VaultLocation.SHANGHAI) }
    val activeTwin = remember(selectedVault, vaultsList) {
        vaultsList.find { it.location == selectedVault } ?: vaultsList[0]
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("vault_screen_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 头部
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("数字金库孪生监控舱", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                Text("全实物储备资产数字凭证系统（一物一码，链上审计）", fontSize = 10.sp, color = Color.Gray)
            }
        }

        // 金库存托汇总仪表盘
        item {
            // 在库黄金和白银数量
            val inVaultGold = goldList.filter { it.status == AssetStatus.IN_VAULT }.sumOf { it.weight }
            val inVaultSilver = silverList.filter { it.status == AssetStatus.IN_VAULT }.sumOf { it.weight }
            
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderBorder(PremiumGold)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("当前金库实物存托总量", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("托管实物黄金", fontSize = 11.sp, color = Color.Gray)
                            Text("${String.format("%.2f", inVaultGold)} 克", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = PremiumGold)
                        }
                        Column {
                            Text("托管实物白银", fontSize = 11.sp, color = Color.Gray)
                            Text("${String.format("%.1f", inVaultSilver)} 克", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = SilverGray)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("所有在库资产已登记“数字实物护照”，拥有独立物理货架定位。", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        // 交互选择不同的金库进行孪生模拟
        item {
            Column {
                Text("物理交割金库列表", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VaultLocation.values().forEach { loc ->
                        val isSel = loc == selectedVault
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSel) PremiumGold.copy(alpha = 0.2f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSel) PremiumGold else MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedVault = loc }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = loc.cityName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) PremiumGold else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }

        // 选中金库数字孪生状态卡
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(activeTwin.location.displayName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ChinaRedUp.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(activeTwin.securityStatus, fontSize = 9.sp, color = ChinaRedUp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            VaultParam("库容极限", "${activeTwin.capacityKg} kg")
                            VaultParam("存储黄金", "${activeTwin.storedGoldKg} kg")
                            VaultParam("高精度温度", "${String.format("%.1f", activeTwin.temperatureCelsius)} ℃")
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            VaultParam("托管账户数", "${activeTwin.customerAssetsCount} 户")
                            VaultParam("存储白银", "${activeTwin.storedSilverKg} kg")
                            VaultParam("高精度湿度", "${String.format("%.1f", activeTwin.humidityPercent)} %")
                        }
                    }
                }
            }
        }

        // 护照资产卡片列表
        item {
            Text("名下存托资产·数字实物护照", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
        }

        val nonSoldGold = goldList.filter { it.status != AssetStatus.SOLD }
        val nonSoldSilver = silverList.filter { it.status != AssetStatus.SOLD }

        if (nonSoldGold.isEmpty() && nonSoldSilver.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("当前暂无在库托管资产凭证", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            items(nonSoldGold) { bar ->
                DigitalPassportView(
                    serial = bar.serialNumber,
                    manufacturer = bar.manufacturer,
                    weight = bar.weight,
                    purity = bar.purity,
                    cert = bar.certificate,
                    date = bar.productionDate,
                    owner = bar.owner,
                    location = bar.vaultLocation.displayName,
                    status = bar.status,
                    price = bar.purchasePrice,
                    isGold = true
                )
            }
            items(nonSoldSilver) { bar ->
                DigitalPassportView(
                    serial = bar.serialNumber,
                    manufacturer = bar.manufacturer,
                    weight = bar.weight,
                    purity = bar.purity,
                    cert = bar.certificate,
                    date = bar.productionDate,
                    owner = bar.owner,
                    location = bar.vaultLocation.displayName,
                    status = bar.status,
                    price = bar.purchasePrice,
                    isGold = false
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun VaultParam(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = Color.Gray)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
    }
}


// ================== 5. 我的资产与家庭共享账本 (MineScreen) ==================
@Composable
fun MineScreen(vm: MainViewModel) {
    val ledger by vm.ledgerHistory.collectAsState()
    val auditLog by vm.auditHistory.collectAsState()
    val alerts by vm.riskAlerts.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: 财务账本, 1: 合规审计, 2: 资产设置与家庭账本

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("mine_screen_root")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 头部个人卡片
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(PremiumGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "张华",
                            fontWeight = FontWeight.ExtraBold,
                            color = PremiumGold,
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("张华 (SH_USER_0821)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = PremiumGold, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("实名会员: ${if(vm.isUserKycVerified) "已通过人防反洗钱核验" else "仅限演示额度"}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (vm.isUserKycVerified) ChinaRedUp.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.2f))
                            .clickable {
                                vm.isUserKycVerified = !vm.isUserKycVerified
                                SimulationData.auditHistory.add(
                                    0, AuditLogEntry(
                                        action = "实名KYC核验修改",
                                        targetObject = "张华",
                                        oldState = if (!vm.isUserKycVerified) "未核验" else "已核验",
                                        newState = if (vm.isUserKycVerified) "未核验" else "已核验"
                                    )
                                )
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (vm.isUserKycVerified) "取消实名" else "去实名",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (vm.isUserKycVerified) ChinaRedUp else MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }

        // 人民币准备金账户
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderBorder(PremiumGold.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("人民币可用头寸账户 (备付金)", fontSize = 11.sp, color = Color.Gray)
                        Text(
                            text = "¥${String.format("%,.2f", vm.userCashBalance)}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Row {
                        Button(
                            onClick = { vm.depositCny(50000.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("充值5万", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 分类Tab
        item {
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = PremiumGold
            ) {
                Tab(selected = activeSubTab == 0, onClick = { activeSubTab = 0 }) {
                    Text("双重金融账本", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Tab(selected = activeSubTab == 1, onClick = { activeSubTab = 1 }) {
                    Text("合规审计/风控", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Tab(selected = activeSubTab == 2, onClick = { activeSubTab = 2 }) {
                    Text("家庭资产共享", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        if (activeSubTab == 0) {
            // 双向记账总账
            item {
                Text("DoubleEntryLedger 复式财务日记账", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
            }
            items(ledger) { entry ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(entry.transactionType, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            val dateStr = SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date(entry.timestamp))
                            Text(dateStr, fontSize = 10.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("借方科目 (Debit)", fontSize = 9.sp, color = Color.Gray)
                                Text(entry.debitAccount, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("贷方科目 (Credit)", fontSize = 9.sp, color = Color.Gray)
                                Text(entry.creditAccount, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "涉及克数: ${if (entry.metalGrams > 0) "${entry.metalGrams}g" else "无"}",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            Text(
                                "记账金额: ¥${String.format("%.2f", entry.amountCny)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PremiumGold
                            )
                        }
                    }
                }
            }
        } else if (activeSubTab == 1) {
            // 风控与拦截
            if (alerts.isNotEmpty()) {
                item {
                    Text("实时合规官监控触发列表", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                }
                items(alerts) { alert ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderBorder(if (alert.severity == "高") ChinaRedUp else PremiumGold)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(alert.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (alert.severity == "高") ChinaRedUp else MaterialTheme.colorScheme.onBackground)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (alert.status == "放行") ChinaGreenDown.copy(alpha = 0.2f) else ChinaRedUp.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(alert.status, fontSize = 9.sp, color = if (alert.status == "放行") ChinaGreenDown else ChinaRedUp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(alert.description, fontSize = 10.sp, color = Color.Gray, lineHeight = 13.sp)
                        }
                    }
                }
            }

            // 审计日志
            item {
                Text("全链合规审计追踪记录 (AuditLog)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
            }
            items(auditLog) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("操作: ${log.action}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("RID: ${log.requestId.substring(0, 8)}", fontSize = 9.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("操作对象: ${log.targetObject}", fontSize = 10.sp, color = Color.Gray)
                        Text("状态漂移: ${log.oldState} → ${log.newState}", fontSize = 10.sp, color = PremiumGold)
                    }
                }
            }
        } else {
            // 家庭账本共享
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("家庭联名贵金属共享账户", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                            Icon(imageVector = Icons.Default.FamilyRestroom, contentDescription = null, tint = PremiumGold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "允许添加直系亲属（配偶、父母、子女）共同查看或指派数字金库托管资产。共享规则明细遵循独立物权法，提货权和变现回购操作仍需主账户实名授权及双重密码核签。",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            lineHeight = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // 模拟两个直系亲属
                        FamilyMemberItem("妻子 (李静)", "权限：仅限查看、定投协同 | 占家庭资产：34%")
                        Spacer(modifier = Modifier.height(8.dp))
                        FamilyMemberItem("儿子 (张小华)", "权限：仅限查看、赠予接收 | 占家庭资产：15%")
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun FamilyMemberItem(name: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.background)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PremiumGold.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = PremiumGold, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 10.sp, color = Color.Gray)
        }
    }
}
