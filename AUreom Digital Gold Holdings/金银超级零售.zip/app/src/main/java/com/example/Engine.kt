package com.example

import kotlin.math.roundToInt

// 1. 贵金属单位换算引擎
object PreciousMetalUnitEngine {
    const val OUNCE_TO_GRAM = 31.1034768

    enum class Unit(val code: String, val displayName: String, val ratioToGram: Double) {
        GRAM("g", "克", 1.0),
        KILOGRAM("kg", "千克", 1000.0),
        TROY_OUNCE("oz", "金衡盎司", OUNCE_TO_GRAM),
        MILLIGRAM("mg", "毫克", 0.001)
    }

    fun convert(value: Double, from: Unit, to: Unit): Double {
        val grams = value * from.ratioToGram
        return grams / to.ratioToGram
    }

    fun formatWeight(grams: Double): String {
        return String.format("%.2f克", grams)
    }
}

// 2. 实时行情与定价引擎 (综合 GoldPriceEngine & SilverPriceEngine)
class PriceEngine {
    // 基础金价 (元/克) 与 基础银价 (元/克)
    var goldBase = 562.50
    var silverBase = 7.15

    // 基础现货美元价格
    var goldUsdBase = 2480.0
    var silverUsdBase = 29.50

    // 模拟产生新行情
    fun tickPrices(): Pair<MetalPrice, MetalPrice> {
        // 金价产生 -0.80 到 +1.20 的随机浮动
        val goldTick = (Math.random() * 2.0 - 0.8)
        goldBase += goldTick
        goldUsdBase += goldTick * 4.40

        // 银价产生 -0.04 到 +0.06 的随机浮动
        val silverTick = (Math.random() * 0.1 - 0.04)
        silverBase += silverTick
        silverUsdBase += silverTick * 4.12

        val goldPrice = MetalPrice(
            metalType = MetalType.GOLD,
            benchmarkUsd = (goldUsdBase * 100).roundToInt() / 100.0,
            benchmarkCnyGram = (goldBase * 100).roundToInt() / 100.0,
            buyPrice = ((goldBase + 8.5) * 100).roundToInt() / 100.0, // 零售基准买入（含渠道服务）
            buybackPrice = ((goldBase - 2.0) * 100).roundToInt() / 100.0, // 回购价（一般贴水2元）
            quality = PriceQuality.LIVE,
            source = "上海黄金交易所(模拟竞价)",
            changeAmount = (goldTick * 100).roundToInt() / 100.0,
            changeRate = ((goldTick / (goldBase - goldTick)) * 10000).roundToInt() / 100.0
        )

        val silverPrice = MetalPrice(
            metalType = MetalType.SILVER,
            benchmarkUsd = (silverUsdBase * 100).roundToInt() / 100.0,
            benchmarkCnyGram = (silverBase * 100).roundToInt() / 100.0,
            buyPrice = ((silverBase + 0.5) * 100).roundToInt() / 100.0,
            buybackPrice = ((silverBase - 0.25) * 100).roundToInt() / 100.0,
            quality = PriceQuality.LIVE,
            source = "上海黄金交易所(模拟竞价)",
            changeAmount = (silverTick * 100).roundToInt() / 100.0,
            changeRate = ((silverTick / (silverBase - silverTick)) * 10000).roundToInt() / 100.0
        )

        return Pair(goldPrice, silverPrice)
    }
}

// 3. 零售价格计算引擎 (RetailPricingEngine)
object RetailPricingEngine {
    /**
     * 计算消费者最终购买价格：
     * 消费者价格 = 基准金价 * 克重 + 产品溢价 * 克重 + 加工费 * 克重 + 适用税费
     */
    fun calculateRetailPrice(
        product: Product,
        benchmarkPricePerGram: Double,
        quantity: Int = 1
    ): Double {
        val baseMetalCost = benchmarkPricePerGram * product.weight
        val premiumCost = product.premiumPerGram * product.weight
        val laborCost = product.laborFeePerGram * product.weight
        val singlePreTax = baseMetalCost + premiumCost + laborCost
        
        // 计算税金 (包含在最终报价中)
        val taxDetail = ChinaTaxEngine.calculateTax(product, singlePreTax)
        
        return (singlePreTax + taxDetail.totalTax) * quantity
    }
}

// 4. 版本化中国税务规则引擎 (ChinaTaxEngine)
object ChinaTaxEngine {
    data class TaxRule(
        val ruleId: String,
        val version: String,
        val effectiveFrom: String,
        val productCategory: ProductCategory,
        val vatRate: Double,            // 增值税率 (例如 13% 或 0%)
        val consumptionTaxRate: Double, // 消费税率 (例如 5% 或 0%)
        val description: String,
        val legalReference: String
    )

    // 系统支持版本化税务规则，随时适应政策变更
    private val activeRules = listOf(
        TaxRule(
            ruleId = "TAX-GOLD-INV-01",
            version = "v2026.1",
            effectiveFrom = "2024-01-01",
            productCategory = ProductCategory.INVESTMENT_BAR,
            vatRate = 0.0, // 投资性金条免征增值税
            consumptionTaxRate = 0.0, // 投资金条不征收消费税
            description = "符合国税总局投资金条免税优惠政策",
            legalReference = "国税发[2003]42号文"
        ),
        TaxRule(
            ruleId = "TAX-GOLD-COIN-01",
            version = "v2026.1",
            effectiveFrom = "2024-01-01",
            productCategory = ProductCategory.INVESTMENT_COIN,
            vatRate = 0.0, // 熊猫金币等投资金币免征增值税
            consumptionTaxRate = 0.0,
            description = "投资性贵金属纪念币免税政策",
            legalReference = "财税[2012]11号"
        ),
        TaxRule(
            ruleId = "TAX-JEWELRY-01",
            version = "v2026.1",
            effectiveFrom = "2024-01-01",
            productCategory = ProductCategory.JEWELRY,
            vatRate = 0.13, // 珠宝首饰类适用常规增值税 13%
            consumptionTaxRate = 0.05, // 零售环节金银首饰征收5%消费税
            description = "金银首饰零售环节征收消费税政策",
            legalReference = "财税[1994]095号"
        ),
        TaxRule(
            ruleId = "TAX-COLLECTIBLE-01",
            version = "v2026.1",
            effectiveFrom = "2024-01-01",
            productCategory = ProductCategory.COLLECTIBLE,
            vatRate = 0.13,
            consumptionTaxRate = 0.0, // 收藏级摆件等不属于纯首饰的，零售环不征消费税
            description = "贵金属摆件普通增值税政策",
            legalReference = "增值税暂行条例"
        ),
        TaxRule(
            ruleId = "TAX-SILVER-01",
            version = "v2026.1",
            effectiveFrom = "2024-01-01",
            productCategory = ProductCategory.INDUSTRIAL_THEME,
            vatRate = 0.13,
            consumptionTaxRate = 0.0,
            description = "工业主题银条制品征税政策",
            legalReference = "增值税暂行条例"
        )
    )

    fun calculateTax(product: Product, preTaxAmount: Double): TaxDetail {
        val rule = activeRules.find { it.productCategory == product.category }
            ?: TaxRule("DEFAULT", "1.0", "2024-01-01", product.category, 0.13, 0.0, "默认税率", "增值税暂行条例")

        // 增值税计算 (包含在产品售价内/或附加)
        val vat = preTaxAmount * rule.vatRate
        
        // 消费税 (金银首饰在零售环节以不含增值税的销售额为计税依据：销售额 / (1+13%) * 5%)
        val consumptionTax = if (rule.consumptionTaxRate > 0.0) {
            val baseCST = preTaxAmount / (1.0 + rule.vatRate)
            baseCST * rule.consumptionTaxRate
        } else {
            0.0
        }

        return TaxDetail(
            basePrice = preTaxAmount,
            valueAddedTax = (vat * 100).roundToInt() / 100.0,
            consumptionTax = (consumptionTax * 100).roundToInt() / 100.0,
            totalTax = ((vat + consumptionTax) * 100).roundToInt() / 100.0,
            effectiveRate = rule.vatRate + rule.consumptionTaxRate,
            legalReference = rule.legalReference
        )
    }
}

// 5. 风险与合规控制中心 (RiskEngine)
object RiskEngine {
    /**
     * 检测洗钱及合规风险：
     * - 单笔交易金额 >= 5万 人民币 或 黄金克数 >= 1000g，必须触发 KYC
     * - 频繁下单 (这里模拟检测)
     * - 实名制状态
     */
    fun evaluateTransactionRisk(
        userIsVerified: Boolean,
        amount: Double,
        weight: Double,
        frequencyCountInMinute: Int
    ): Pair<String, RiskAlert?> {
        if (!userIsVerified && amount >= 50000.0) {
            val alert = RiskAlert(
                type = "反洗钱 (AML) - 未实名大额交易限制",
                severity = "高",
                description = "用户未进行实名KYC，尝试提交单笔超过50,000元的黄金交易。系统已智能拦截。",
                status = "合规官已拦截"
            )
            return Pair("BLOCKED_KYC", alert)
        }

        if (amount >= 200000.0) {
            val alert = RiskAlert(
                type = "大额资金风险监控 (AML)",
                severity = "中",
                description = "检测到单笔交易金额 ${String.format("%.2f", amount)} 元，触发高净值大额交易审核备案，已自动记录审计追踪日志。",
                status = "放行"
            )
            return Pair("WARNING_AML", alert)
        }

        if (frequencyCountInMinute >= 3) {
            val alert = RiskAlert(
                type = "高频异常下单监控 (Anti-Fraud)",
                severity = "高",
                description = "该设备在1分钟内高频提交了 $frequencyCountInMinute 笔交易，疑似自动化黄牛脚本抢单或DDOS。已实施临时频控锁定。",
                status = "合规官已拦截"
            )
            return Pair("BLOCKED_FRAUD", alert)
        }

        return Pair("CLEARED", null)
    }
}
