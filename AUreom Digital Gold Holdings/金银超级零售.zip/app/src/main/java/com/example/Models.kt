package com.example

import java.util.UUID

/**
 * 黄金规格：1g, 2g, 5g, 10g, 20g, 30g, 50g, 100g, 200g, 500g, 1000g
 * 白银规格：10g, 20g, 50g, 100g, 250g, 500g, 1000g, 5000g, 15000g
 */

enum class MetalType {
    GOLD, SILVER
}

enum class ProductCategory {
    INVESTMENT_BAR,    // 投资金/银条
    INVESTMENT_COIN,   // 投资金/银币
    JEWELRY,           // 首饰
    COLLECTIBLE,       // 收藏级
    INDUSTRIAL_THEME   // 工业银主题
}

enum class VaultLocation(val cityName: String, val displayName: String) {
    BEIJING("北京", "华北中心金库"),
    SHANGHAI("上海", "上海自贸区保税金库"),
    SHENZHEN("深圳", "华南总部保税金库"),
    GUANGZHOU("广州", "大湾区交割金库"),
    HANGZHOU("杭州", "华东数字化储备金库")
}

enum class AssetStatus(val displayName: String) {
    IN_VAULT("金库存储"),
    DELIVERING("在途配送"),
    DELIVERED("已提货持有"),
    LOCKED("已锁定"),
    SOLD("已售出/回购")
}

// 黄金实物资产（金条）对象
data class GoldBar(
    val id: String = UUID.randomUUID().toString(),
    val serialNumber: String,
    val manufacturer: String,
    val weight: Double,            // 单位：克
    val purity: Double,            // 纯度：例如 0.9999 (足金999.9)
    val fineGoldWeight: Double,    // 含金量
    val certificate: String,       // 证书编号
    val productionDate: String,    // 生产日期
    val owner: String,             // 持有人
    val vaultLocation: VaultLocation,
    val status: AssetStatus,
    val purchasePrice: Double,     // 购买价 (元)
    val currentValue: Double       // 当前估值 (元)
)

// 白银实物资产（银条）对象
data class SilverBar(
    val id: String = UUID.randomUUID().toString(),
    val serialNumber: String,
    val manufacturer: String,
    val weight: Double,            // 单位：克
    val purity: Double,            // 纯度：例如 0.999 (足银99.9)
    val fineSilverWeight: Double,  // 含银量
    val certificate: String,       // 证书编号
    val productionDate: String,    // 生产日期
    val owner: String,             // 持有人
    val vaultLocation: VaultLocation,
    val status: AssetStatus,
    val purchasePrice: Double,     // 购买价 (元)
    val currentValue: Double       // 当前估值 (元)
)

// 零售商品定义 (用于商城)
data class Product(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val metalType: MetalType,
    val category: ProductCategory,
    val weight: Double,            // 克重
    val purity: Double,            // 纯度
    val brand: String,             // 品牌
    val manufacturer: String,      // 生产商
    val premiumPerGram: Double,    // 每克溢价 (元)
    val laborFeePerGram: Double,   // 每克工费 (元) (首饰)
    val iconUrl: String = "",      // 占位
    val description: String,       // 描述
    val inStock: Int,              // 库存数量
    val certificateType: String    // 证书类别
)

// 金银价格质量
enum class PriceQuality {
    LIVE, DELAYED, SYNTHETIC, STALE, UNAVAILABLE
}

// 价格包
data class MetalPrice(
    val metalType: MetalType,
    val benchmarkUsd: Double,      // 国际现货价 (美元/金衡盎司)
    val benchmarkCnyGram: Double,  // 人民币参考价 (元/克)
    val buyPrice: Double,          // 零售买入基准价 (元/克)
    val buybackPrice: Double,      // 官方回购价 (元/克)
    val quality: PriceQuality,
    val source: String,            // 上海黄金交易所(模拟) / 国际现货
    val changeAmount: Double,      // 涨跌额
    val changeRate: Double,        // 涨跌幅
    val timestamp: Long = System.currentTimeMillis()
)

// 报价锁定包
data class PriceLock(
    val lockId: String = UUID.randomUUID().toString(),
    val metalType: MetalType,
    val lockedPrice: Double,       // 锁定的每克基准价格 (元/克)
    val totalCost: Double,         // 计算得出的总金额
    val expiresAt: Long,           // 过期时间戳
    val isUsed: Boolean = false
)

// 订单
enum class OrderStatus(val displayName: String) {
    CREATED("订单已创建"),
    PRICE_LOCKED("价格已锁定"),
    PAID("已支付"),
    APPROVED("合规审核通过"),
    ALLOCATING("库存实物分配中"),
    SHIPPING("在途配送中"),
    IN_VAULT_STORED("已存入数字金库"),
    DELIVERED("已签收"),
    COMPLETED("完成")
}

data class Order(
    val orderId: String = "ORD-${System.currentTimeMillis() % 10000000}",
    val product: Product,
    val quantity: Int,
    val lockedPricePerGram: Double,
    val laborFee: Double,          // 总工费
    val premium: Double,           // 总溢价
    val taxAmount: Double,         // 税额
    val totalAmount: Double,       // 实付金额 (元)
    val status: OrderStatus,
    val purchaseDate: Long = System.currentTimeMillis(),
    val targetType: DeliveryType,   // 配送/金库存储
    val serialAllocated: String? = null // 分配的实物编号
)

enum class DeliveryType(val displayName: String) {
    SHIPPING("快递安全配送"),
    VAULT_STORE("数字金库存储"),
    STORE_PICKUP("线下门店自提")
}

// 回购订单
enum class BuybackStatus(val displayName: String) {
    REQUESTED("回购申请中"),
    VALUATED("鉴定评估完成"),
    APPROVED("合规审核通过"),
    PAID_OUT("已放款"),
    COMPLETED("完成")
}

data class BuybackOrder(
    val orderId: String = "BBK-${System.currentTimeMillis() % 10000000}",
    val metalType: MetalType,
    val weight: Double,
    val claimedPurity: Double,
    val itemType: String,          // 金条/首饰/旧金等
    val valuationStatus: String,   // 鉴定状态
    val estimatedPrice: Double,    // 预计回购价
    val finalPrice: Double? = null, // 最终定价
    val status: BuybackStatus,
    val createdTime: Long = System.currentTimeMillis(),
    val serialNumber: String? = null
)

// 以旧换新订单
data class ExchangeOrder(
    val orderId: String = "EXC-${System.currentTimeMillis() % 10000000}",
    val oldMetalWeight: Double,
    val oldMetalPurity: Double,
    val oldMetalType: String,
    val oldRecycleValue: Double,   // 旧金抵扣价值 (元)
    val newProduct: Product,
    val newProductValue: Double,   // 新商品价值 (元)
    val laborFee: Double,          // 新首饰加工费 (元)
    val cashDifference: Double,    // 应付差额 (元)
    val createdTime: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false
)

// 金库数字孪生实体
data class VaultTwin(
    val location: VaultLocation,
    val capacityKg: Double,
    val storedGoldKg: Double,
    val storedSilverKg: Double,
    val customerAssetsCount: Int,
    val securityStatus: String,    // "特级安防", "防御警戒中"
    val temperatureCelsius: Double,
    val humidityPercent: Double
)

// 用户现金与金属账本账户
data class CashAccount(
    val userId: String = "USER_CNY_01",
    val balance: Double            // 余额 (元)
)

data class MetalAccount(
    val userId: String = "USER_MTL_01",
    val goldBalance: Double,       // 黄金持有克数
    val silverBalance: Double      // 白银持有克数
)

// 复式记账(Double-Entry Ledger)明细
data class LedgerEntry(
    val entryId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val transactionType: String,   // 购买 / 回购 / 充值 / 以旧换新
    val debitAccount: String,      // 借方科目
    val creditAccount: String,     // 贷方科目
    val amountCny: Double,         // 金额 (元)
    val metalGrams: Double = 0.0,  // 涉及金属克数
    val metalType: MetalType? = null
)

// 风险合规审计日志
data class AuditLogEntry(
    val logId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val user: String = "当前用户",
    val action: String,            // 例如："价格锁定", "下单支付", "实物指派", "金库存入"
    val targetObject: String,
    val oldState: String,
    val newState: String,
    val requestId: String = UUID.randomUUID().toString()
)

// 行情历史数据点
data class PriceHistoryPoint(
    val timeLabel: String,         // "09:30", "10:30" 等
    val goldPrice: Double,
    val silverPrice: Double
)

// 税务计算明细
data class TaxDetail(
    val basePrice: Double,
    val valueAddedTax: Double,     // 增值税
    val consumptionTax: Double,    // 消费税 (零售环节)
    val totalTax: Double,
    val effectiveRate: Double,
    val legalReference: String
)

// 门店信息
data class Store(
    val id: String,
    val name: String,
    val city: String,
    val address: String,
    val goldStockKg: Double,
    val silverStockKg: Double,
    val activeReservations: Int
)

// 异常监控事件
data class RiskAlert(
    val alertId: String = "ALT-${System.currentTimeMillis() % 100000}",
    val timestamp: Long = System.currentTimeMillis(),
    val type: String,              // "反洗钱 (AML)", "反欺诈 (Fraud)"
    val severity: String,          // "低", "中", "高"
    val description: String,
    val status: String             // "待处理", "合规官已拦截", "放行"
)
