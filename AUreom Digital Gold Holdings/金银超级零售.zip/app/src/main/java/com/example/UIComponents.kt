package com.example

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChinaGreenDown
import com.example.ui.theme.ChinaRedUp
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SilverGray

// 1. 实时行情闪烁指示灯
@Composable
fun LiveBadge(status: PriceQuality) {
    val alpha = remember { Animatable(1f) }
    LaunchedEffect(status) {
        if (status == PriceQuality.LIVE) {
            alpha.animateTo(
                targetValue = 0.2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color.Black.copy(alpha = 0.4f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(
                    if (status == PriceQuality.LIVE) ChinaRedUp.copy(alpha = alpha.value)
                    else Color.Gray
                )
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = when (status) {
                PriceQuality.LIVE -> "LIVE 实物申报价"
                PriceQuality.DELAYED -> "DELAYED 延时"
                PriceQuality.SYNTHETIC -> "模拟数据"
                else -> "OFFLINE"
            },
            color = if (status == PriceQuality.LIVE) PremiumGold else Color.Gray,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// 2. 红涨绿跌指示器
@Composable
fun PriceChangeIndicator(changeAmount: Double, changeRate: Double) {
    val isUp = changeAmount >= 0
    val color = if (isUp) ChinaRedUp else ChinaGreenDown
    val icon = if (isUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown
    val textPrefix = if (isUp) "+" else ""

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.End
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(2.dp))
        Text(
            text = "$textPrefix${String.format("%.2f", changeAmount)} ($textPrefix${String.format("%.2f", changeRate)}%)",
            color = color,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// 3. 贵金属精致折线图 Canvas
@Composable
fun MiniPriceChart(
    points: List<PriceHistoryPoint>,
    isGold: Boolean = true,
    modifier: Modifier = Modifier
) {
    val lineColor = if (isGold) PremiumGold else SilverGray
    val gradientColor = if (isGold) PremiumGold.copy(alpha = 0.15f) else SilverGray.copy(alpha = 0.15f)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderBorder(MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = if (isGold) "今日黄金走势（元/克）" else "今日白银走势（元/克）",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (points.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("暂无趋势数据", color = Color.Gray, fontSize = 12.sp)
                }
            } else {
                val data = points.map { if (isGold) it.goldPrice else it.silverPrice }
                val minVal = (data.minOrNull() ?: 0.0) * 0.999
                val maxVal = (data.maxOrNull() ?: 1.0) * 1.001
                val valueRange = (maxVal - minVal).coerceAtLeast(0.1)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val spacing = width / (data.size - 1).coerceAtLeast(1)

                    val path = Path()
                    val fillPath = Path()

                    data.forEachIndexed { i, d ->
                        val x = i * spacing
                        val y = (height - ((d - minVal) / valueRange * height)).toFloat()

                        if (i == 0) {
                            path.moveTo(x, y)
                            fillPath.moveTo(x, height)
                            fillPath.lineTo(x, y)
                        } else {
                            path.lineTo(x, y)
                            fillPath.lineTo(x, y)
                        }

                        if (i == data.size - 1) {
                            fillPath.lineTo(x, height)
                            fillPath.close()
                        }
                    }

                    // 绘制阴影填充
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(gradientColor, Color.Transparent),
                            startY = 0f,
                            endY = height
                        )
                    )

                    // 绘制折线
                    drawPath(
                        path = path,
                        color = lineColor,
                        style = Stroke(width = 4f)
                    )
                }

                // 底部时间轴
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    points.forEachIndexed { i, p ->
                        if (i == 0 || i == points.size / 2 || i == points.size - 1) {
                            Text(p.timeLabel, fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

fun BorderBorder(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)

// 4. 金属数字护照组件 (金条/银条数字孪生展示)
@Composable
fun DigitalPassportView(
    serial: String,
    manufacturer: String,
    weight: Double,
    purity: Double,
    cert: String,
    date: String,
    owner: String,
    location: String,
    status: AssetStatus,
    price: Double,
    isGold: Boolean = true
) {
    val themeColor = if (isGold) PremiumGold else SilverGray
    val prefix = if (isGold) "AU" else "AG"

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderBorder(themeColor.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("digital_passport_${serial}")
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            themeColor.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isGold) "中国黄金 · 数字化资产护照" else "华通白银 · 数字化资产护照",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColor
                    )
                    Text(
                        text = "PASSPORT ID: $prefix-${serial.hashCode().coerceAtLeast(0)}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(themeColor.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = status.displayName,
                        color = themeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Spec Grid
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    PassportField("唯一钢印号", serial)
                    PassportField("成色纯度", if (isGold) "足金 999.9" else "足银 99.99")
                    PassportField("法定所有人", owner)
                }
                Column(modifier = Modifier.weight(1f)) {
                    PassportField("实物克重", "${weight}g")
                    PassportField("质检证书", cert)
                    PassportField("托管仓库", location)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("登记生产商: $manufacturer", fontSize = 10.sp, color = Color.Gray)
                    Text("确权签署时间: $date", fontSize = 10.sp, color = Color.Gray)
                }
                Text(
                    text = "交割价格: ¥${String.format("%,.2f", price)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

@Composable
fun PassportField(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, fontSize = 10.sp, color = Color.Gray)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
    }
}
