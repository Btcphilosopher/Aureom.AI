package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 中国金银超级零售高端财务配色
val CharcoalDark = Color(0xFF101014)     // 墨色背景/深色卡片
val CharcoalLight = Color(0xFF1C1C22)    // 次级深色卡片
val WarmWhite = Color(0xFFFAF9F6)        // 暖白背景
val PureWhite = Color(0xFFFFFFFF)        // 纯白卡片

// 核心强调色：香槟金 / 华丽金
val PremiumGold = Color(0xFFD4AF37)      // 经典黄金色
val DeepGold = Color(0xFFC5A02B)         // 深金/点击
val ChampagneGold = Color(0xFFF3E5AB)    // 香槟金色
val SilverGray = Color(0xFFB0B3B8)       // 银白色

// 中国金融市场特色：红涨绿跌
val ChinaRedUp = Color(0xFFD2232A)       // 涨：中国红
val ChinaGreenDown = Color(0xFF2E8B57)   // 跌：中性松石绿 / 绿色

// 文本与辅助色
val TextPrimaryDark = Color(0xFFE4E6EB)
val TextSecondaryDark = Color(0xFFB0B3B8)
val TextPrimaryLight = Color(0xFF1C1C22)
val TextSecondaryLight = Color(0xFF5A5C62)

val BorderColorLight = Color(0xFFE2E4E8)
val BorderColorDark = Color(0xFF2C2C32)
