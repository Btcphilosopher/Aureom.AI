package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChinaGreenDown
import com.example.ui.theme.ChinaRedUp
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SilverGray

@Composable
fun DemoScreen(vm: MainViewModel) {
    val currentDemo = vm.currentDemoIndex
    val alerts by vm.riskAlerts.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("demo_screen_root")
    ) {
        // 顶部切换区
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            DemoHeaderTab(0, "演示中心", currentDemo == 0) { vm.currentDemoIndex = 0 }
            DemoHeaderTab(1, "①黄金购买", currentDemo == 1) { vm.currentDemoIndex = 1 }
            DemoHeaderTab(2, "②以旧换新", currentDemo == 2) { vm.currentDemoIndex = 2 }
            DemoHeaderTab(3, "③白银申购", currentDemo == 3) { vm.currentDemoIndex = 3 }
            DemoHeaderTab(4, "④管理后台", currentDemo == 4) { vm.currentDemoIndex = 4 }
        }

        Spacer(modifier = Modifier.height(1.dp).fillMaxWidth().background(MaterialTheme.colorScheme.outlineVariant))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (currentDemo) {
                0 -> {
                    // 演示大厅：提供4大端到端演示的卡片指引 + 重置系统按钮
                    item {
                        Column {
                            Text("演示控制中心 & 体验沙盒", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                            Text("在这里，您可以通过真实的控制步骤，体验大宗贵金属超级零售的底层业务全闭环流程。", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { vm.resetAllData() },
                                colors = ButtonDefaults.buttonColors(containerColor = ChinaRedUp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                                    .testTag("reset_data_btn")
                            ) {
                                Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("重置演示系统（恢复默认15万可用头寸）", fontSize = 12.sp, color = Color.White)
                            }
                        }
                    }

                    item {
                        DemoGuideCard(
                            title = "① 黄金100克申购与数字实物护照托管",
                            desc = "用户下单 -> 触发60秒基准价格锁定机制 -> 人行AML合规引擎核验 -> 复式对账扣款 -> 指派唯一厂印钢印钢号 -> 生成防伪数字化护照 -> 分配华东/华南数字化储备金库安全托收。",
                            tag = "DEMO_1",
                            actionText = "开始体验黄金申购流程"
                        ) {
                            vm.currentDemoIndex = 1
                            vm.demo1Step = 1
                        }
                    }

                    item {
                        DemoGuideCard(
                            title = "② 古法祥云金首饰『以旧换新』",
                            desc = "输入旧黄金克重与成色折率 -> 按实时官方回购价计算折价价值 -> 选择新首饰(如古法祥云手镯)并自动叠加加工费、产品溢价与零售消费税率 -> 双重账本扣除现金差额，交付新首饰入账。",
                            tag = "DEMO_2",
                            actionText = "开始体验以旧换新计算"
                        ) {
                            vm.currentDemoIndex = 2
                            vm.calculateTradeIn()
                        }
                    }

                    item {
                        DemoGuideCard(
                            title = "③ 白银大宗5公斤批量申购托管",
                            desc = "购买 5kg 足银国标投资银条 -> 极速分配5根对应的独立白银数字护照 -> 存入上海自贸区保税金库 -> 实现客户总托管白银账户资产增量与人民币现金备付金的同步双向复式登记。",
                            tag = "DEMO_3",
                            actionText = "开始体验大额白银购买"
                        ) {
                            vm.currentDemoIndex = 3
                            vm.demo3Step = 1
                        }
                    }

                    item {
                        DemoGuideCard(
                            title = "④ 贵金属供应链、异常拦截及大屏驾驶舱",
                            desc = "进入金银商户/珠宝商管理后台 -> 实时查看宏观大屏驾驶舱(全网今日累计销售额、回购额、总托库容) -> 自动运行模拟100万级用户订单撮合跳动 -> 监控自动风控警报(未实名大额拦截、高频异常设备熔断、双重账本对账等)。",
                            tag = "DEMO_4",
                            actionText = "进入宏观管理后台大屏"
                        ) {
                            vm.currentDemoIndex = 4
                        }
                    }

                    // 快速嵌入AI面板
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }

                    item {
                        Text("金银 AI 智能助手", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                    }

                    item {
                        AiAssistantPanel(vm)
                    }
                }

                1 -> {
                    // Demo 1: 100g 黄金购买与托管
                    item {
                        Column {
                            Text("演示一：黄金100克申购与数字实物护照托管", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                            Text("体验核心不变量：买入黄金吨数必须100%有金库物理储备支持，不凭空超发。", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    item {
                        // 步骤指示
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StepIndicator(1, "价格锁定", vm.demo1Step >= 1)
                            StepIndicator(2, "对账结款", vm.demo1Step >= 2)
                            StepIndicator(3, "分配钢印", vm.demo1Step >= 3)
                            StepIndicator(4, "确权托管", vm.demo1Step >= 4)
                        }
                    }

                    when (vm.demo1Step) {
                        1 -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("申购商品：", fontSize = 11.sp, color = Color.Gray)
                                        Text("「中国黄金」足金999.9投资金条 100g", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("规格：100.00克 | 纯度：足金999.9", fontSize = 12.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(12.dp))

                                        val goldP by vm.goldPrice.collectAsState()
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("上海金实时申报价:", fontSize = 12.sp)
                                            Text("¥${String.format("%.2f", goldP.buyPrice)} / 克", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))
                                        Button(
                                            onClick = { vm.runDemo1Step1_LockPrice() },
                                            colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(42.dp)
                                                .testTag("lock_price_btn")
                                        ) {
                                            Text("立即锁定最新申报价 (60秒有效)", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            item {
                                val lock = vm.activePriceLock
                                if (lock != null) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderBorder(PremiumGold)
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("已安全锁定申报价", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                                Text("倒计时 ${vm.priceLockTimeLeft}s", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                                            }
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("锁定基准克价:", fontSize = 12.sp, color = Color.Gray)
                                                Text("¥${String.format("%.2f", lock.lockedPrice)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("首饰/大宗溢价+工费:", fontSize = 12.sp, color = Color.Gray)
                                                val p = vm.currentSelectedProduct!!
                                                Text("¥${String.format("%.2f", (p.premiumPerGram + p.laborFeePerGram) * p.weight)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("符合中国投资金免税:", fontSize = 12.sp, color = Color.Gray)
                                                Text("0% (免税)", fontSize = 12.sp, color = ChinaGreenDown, fontWeight = FontWeight.Bold)
                                            }

                                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("应付总额:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                                Text("¥${String.format("%,.2f", lock.totalCost)}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = PremiumGold)
                                            }

                                            Spacer(modifier = Modifier.height(16.dp))

                                            // 托管选择
                                            Text("实物提货/托收方式:", fontSize = 11.sp, color = Color.Gray)
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (vm.demo1SelectedDelivery == DeliveryType.VAULT_STORE) PremiumGold.copy(alpha = 0.2f) else MaterialTheme.colorScheme.background)
                                                        .border(width = 1.dp, color = if (vm.demo1SelectedDelivery == DeliveryType.VAULT_STORE) PremiumGold else Color.Transparent, shape = RoundedCornerShape(8.dp))
                                                        .clickable { vm.demo1SelectedDelivery = DeliveryType.VAULT_STORE }
                                                        .padding(8.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("数字金库存储", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (vm.demo1SelectedDelivery == DeliveryType.SHIPPING) PremiumGold.copy(alpha = 0.2f) else MaterialTheme.colorScheme.background)
                                                        .border(width = 1.dp, color = if (vm.demo1SelectedDelivery == DeliveryType.SHIPPING) PremiumGold else Color.Transparent, shape = RoundedCornerShape(8.dp))
                                                        .clickable { vm.demo1SelectedDelivery = DeliveryType.SHIPPING }
                                                        .padding(8.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("快递安全配送", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("分配物理托管金库:", fontSize = 11.sp, color = Color.Gray)
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                VaultLocation.values().forEach { loc ->
                                                    val isSel = loc == vm.demo1SelectedVault
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSel) PremiumGold.copy(alpha = 0.2f) else MaterialTheme.colorScheme.background)
                                                            .border(width = 1.dp, color = if (isSel) PremiumGold else Color.Transparent, shape = RoundedCornerShape(6.dp))
                                                            .clickable { vm.demo1SelectedVault = loc }
                                                            .padding(vertical = 6.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(loc.cityName, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(16.dp))
                                            Button(
                                                onClick = { vm.runDemo1Step2_Pay() },
                                                colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(42.dp)
                                                    .testTag("pay_cny_btn")
                                            ) {
                                                Text("确认支付并对账交割", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        3 -> {
                            // 购买成功后，指派钢号，生成护照
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderBorder(PremiumGold)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("双向金融对账已完成！", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("现金准备金扣款和物理黄金库存入库已原子化登记。", fontSize = 11.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(16.dp))

                                        Text("系统正在执行物理配对：", fontSize = 11.sp, color = Color.Gray)
                                        Text("厂印钢印号：${vm.demo1AllocatedSerial}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("物理检测纯度：足金 999.9（精炼无损光谱通过）", fontSize = 11.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(16.dp))

                                        Button(
                                            onClick = { vm.demo1Step = 4 },
                                            colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(40.dp)
                                                .testTag("generate_passport_btn")
                                        ) {
                                            Text("生成防伪数字化资产护照", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        4 -> {
                            item {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("恭喜，100g 黄金已存入数字金库！", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("可在『数字金库』与『我的资产』中随时查阅、回购或提货。", fontSize = 11.sp, color = Color.Gray)
                                    Spacer(modifier = Modifier.height(16.dp))

                                    // 显示新护照
                                    val p = vm.currentSelectedProduct!!
                                    DigitalPassportView(
                                        serial = vm.demo1AllocatedSerial,
                                        manufacturer = p.manufacturer,
                                        weight = p.weight,
                                        purity = p.purity,
                                        cert = "NGSTC-2026-${(10000 + Math.random() * 90000).toInt()}",
                                        date = "2026年10月06日",
                                        owner = "张华 (当前用户)",
                                        location = vm.demo1SelectedVault.displayName,
                                        status = if (vm.demo1SelectedDelivery == DeliveryType.VAULT_STORE) AssetStatus.IN_VAULT else AssetStatus.DELIVERING,
                                        price = vm.activePriceLock?.totalCost ?: 57100.0,
                                        isGold = true
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = {
                                            vm.demo1Step = 1
                                            vm.currentDemoIndex = 0
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier.width(180.dp)
                                    ) {
                                        Text("返回控制台", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Demo 2: 古法首饰以旧换新
                    item {
                        Column {
                            Text("演示二：古法祥云金首饰『以旧换新』", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                            Text("体验我国金饰零售中极高频的增值折旧与差额计算服务。", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("第一步：输入您要回收的旧金参数", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = vm.tradeInOldWeight,
                                        onValueChange = {
                                            vm.tradeInOldWeight = it
                                            vm.calculateTradeIn()
                                        },
                                        label = { Text("旧黄金克重 (g)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        colors = textColors(),
                                        modifier = Modifier.weight(1f)
                                    )

                                    OutlinedTextField(
                                        value = vm.tradeInOldPurity,
                                        onValueChange = {
                                            vm.tradeInOldPurity = it
                                            vm.calculateTradeIn()
                                        },
                                        label = { Text("旧金成色纯度") },
                                        colors = textColors(),
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                Text("第二步：选择要换购的新商品 (水贝直供)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Spacer(modifier = Modifier.height(8.dp))

                                // 列出首饰
                                SimulationData.initialProducts.filter { it.category == ProductCategory.JEWELRY }.forEach { item ->
                                    val isSel = vm.tradeInSelectedNewProduct?.id == item.id
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSel) PremiumGold.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background)
                                            .clickable {
                                                vm.tradeInSelectedNewProduct = item
                                                vm.calculateTradeIn()
                                            }
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(item.name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("规格: ${item.weight}g | 纯度: 足金999", fontSize = 10.sp, color = Color.Gray)
                                        }
                                        Icon(
                                            imageVector = Icons.Default.CompareArrows,
                                            contentDescription = null,
                                            tint = if (isSel) PremiumGold else Color.Gray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Text("第三步：以旧换新透明差价清算公式", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("旧黄金回收估值 (抵扣项):", fontSize = 11.sp, color = Color.Gray)
                                    Text("- ¥${String.format("%.2f", vm.tradeInResultEstimatedValue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
                                }
                                Row(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                    Text("新金料基本价格 (金价+溢价):", fontSize = 11.sp, color = Color.Gray)
                                    Text("+ ¥${String.format("%.2f", vm.tradeInResultNewValue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                    Text("古法非遗手工艺加工费:", fontSize = 11.sp, color = Color.Gray)
                                    Text("+ ¥${String.format("%.2f", vm.tradeInResultLaborFee)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                    Text("零售环节消费税 (5%)+增值税率 (包含):", fontSize = 11.sp, color = Color.Gray)
                                    Text("ChinaTaxEngine 计算通过", fontSize = 10.sp, color = PremiumGold, fontWeight = FontWeight.Bold)
                                }

                                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("最终需付补差:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("¥${String.format("%,.2f", vm.tradeInResultPayAmount)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = ChinaRedUp)
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { vm.executeTradeIn() },
                                    colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                        .testTag("execute_swap_btn")
                                ) {
                                    Text("确认以旧换新对账（微信/支付宝演示授权）", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // Demo 3: 大额白银定投及托管
                    item {
                        Column {
                            Text("演示三：白银大宗5公斤批量申购托管", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                            Text("购买足银国标投资银条，大容量实物避险配置演示。", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    when (vm.demo3Step) {
                        1 -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("选定投资级白银大宗：", fontSize = 11.sp, color = Color.Gray)
                                        Text("「华通白银」足银99.99国标投资银条 1kg", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("申购数量:", fontSize = 12.sp)
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(onClick = { if (vm.demo3Quantity > 1) vm.demo3Quantity-- }) {
                                                    Icon(imageVector = Icons.Default.Remove, contentDescription = null, tint = PremiumGold)
                                                }
                                                Text("${vm.demo3Quantity} 块 (共 ${vm.demo3Quantity}000g)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                IconButton(onClick = { vm.demo3Quantity++ }) {
                                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = PremiumGold)
                                                }
                                            }
                                        }

                                        val silP by vm.silverPrice.collectAsState()
                                        val singleSil = RetailPricingEngine.calculateRetailPrice(SimulationData.initialProducts.find { it.id == "S-BAR-1000" }!!, silP.buyPrice)
                                        val totalCost = singleSil * vm.demo3Quantity

                                        Row(
                                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                            Text("实时单价:", fontSize = 12.sp)
                                            Text("¥${String.format("%.2f", singleSil)} / 克", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("申购总成本:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text("¥${String.format("%,.2f", totalCost)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = PremiumGold)
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))
                                        Button(
                                            onClick = { vm.executeDemo3SilverPurchase() },
                                            colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(42.dp)
                                                .testTag("buy_silver_btn")
                                        ) {
                                            Text("极速安全锁定并支付", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderBorder(SilverGray)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("大宗白银申购分配完成！", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("已为您的 ${vm.demo3Quantity}kg 白银指派唯一的足银钢印号，并在上海保税金库确权托管。可至数字金库中查看完整的白银数字孪生护照明细。", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)

                                        Spacer(modifier = Modifier.height(16.dp))
                                        Button(
                                            onClick = {
                                                vm.demo3Step = 1
                                                vm.currentDemoIndex = 0
                                                vm.currentTab = "VAULT" // 引导其查看金库
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                            modifier = Modifier.width(180.dp)
                                        ) {
                                            Text("去查看我的金库", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // Demo 4: 珠宝商供应链与管理驾驶舱 (大屏驾驶舱、异常警报监控、模拟百万交易行为)
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("国家特许贵金属超级零售驾驶舱", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(PremiumGold.copy(alpha = 0.15f))
                                        .clickable { vm.runCockpitSimulation() }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = PremiumGold, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (vm.isSimulatingCockpit) "高频交易模拟中" else "一键模拟大宗并发交易", fontSize = 10.sp, color = PremiumGold, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Text("实时监控全国门店及金库吞吐，自动风控拦截预警终端。", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    // 驾驶舱大屏数据矩阵
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("今日全国实时营业汇总指标", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    CockpitWidget("今日零售额", "¥${String.format("%,.0f", SimulationData.cockpitTodaySalesCny)}")
                                    CockpitWidget("今日黄金克数", "${String.format("%,.0f", SimulationData.cockpitTodayGoldGrams)}g")
                                    CockpitWidget("今日订单量", "${SimulationData.cockpitOrderCount} 笔")
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    CockpitWidget("累计托管黄金", "${String.format("%,.1f", SimulationData.cockpitTotalVaultGoldKg)}kg")
                                    CockpitWidget("累计托管白银", "${String.format("%,.1f", SimulationData.cockpitTotalVaultSilverKg)}kg")
                                    CockpitWidget("全国总注册户数", "${String.format("%,d", SimulationData.cockpitCustomerCount)}户")
                                }
                            }
                        }
                    }

                    // 珠宝商批量采购询价 RFQ (B2B商户服务)
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderBorder(PremiumGold.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("金银商户/珠宝大宗批量询价 (RFQ)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Text("支持黄金原料、批量金条金料一键大宗询价对账", fontSize = 10.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = vm.rfqQuantity,
                                        onValueChange = { vm.rfqQuantity = it },
                                        label = { Text("批量采购件数 (件)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        colors = textColors(),
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    Button(
                                        onClick = {
                                            vm.currentSelectedProduct = SimulationData.initialProducts[0] // 默认100g金条
                                            vm.executeRFQ()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(top = 8.dp)
                                            .height(52.dp)
                                    ) {
                                        Text("大宗询价", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (vm.rfqIsSuccess) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(ChinaGreenDown.copy(alpha = 0.15f))
                                            .padding(10.dp)
                                    ) {
                                        Column {
                                            Text("【报价单生成成功 - 96折特惠】", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ChinaGreenDown)
                                            Text("产品: ${SimulationData.initialProducts[0].name}", fontSize = 11.sp)
                                            Text("询价总额: ¥${String.format("%,.2f", vm.rfqQuoteCny)} 元 (已减免商户优惠返点)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text("报价有效期: ${vm.rfqExpiresIn} 秒 (失效自动熔断)", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 回购计算器
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("实物回购对账计算器 (Buyback Center)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = vm.buybackWeight,
                                        onValueChange = {
                                            vm.buybackWeight = it
                                            vm.calculateBuyback()
                                        },
                                        label = { Text("重量 (g)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        colors = textColors(),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = vm.buybackPurity,
                                        onValueChange = {
                                            vm.buybackPurity = it
                                            vm.calculateBuyback()
                                        },
                                        label = { Text("纯度系数 (如0.9999)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        colors = textColors(),
                                        modifier = Modifier.weight(1.2f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("预计总回购结清价:", fontSize = 11.sp, color = Color.Gray)
                                        Text("¥${String.format("%,.2f", vm.buybackEstimatedValue)} 元", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = ChinaGreenDown)
                                    }
                                    Button(
                                        onClick = { vm.submitBuyback() },
                                        colors = ButtonDefaults.buttonColors(containerColor = ChinaGreenDown),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("确认回购变现", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }

                    // 投资收益计算器
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("金银投资定投收益计算器 (Precious Metal ROI)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedTextField(
                                        value = vm.calcPurchasePrice,
                                        onValueChange = { vm.calcPurchasePrice = it; vm.runCalc() },
                                        label = { Text("买入克价") },
                                        colors = textColors(),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = vm.calcWeight,
                                        onValueChange = { vm.calcWeight = it; vm.runCalc() },
                                        label = { Text("持有重量") },
                                        colors = textColors(),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = vm.calcCurrentPrice,
                                        onValueChange = { vm.calcCurrentPrice = it; vm.runCalc() },
                                        label = { Text("目标克价") },
                                        colors = textColors(),
                                        modifier = Modifier.weight(1.2f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                vm.runCalc()
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("计算投资总成本 (含0.2%手续费):", fontSize = 11.sp, color = Color.Gray)
                                    Text("¥${String.format("%,.2f", vm.calcResultCost)} 元", fontSize = 11.sp)
                                }
                                Row(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                    Text("目标变现估值:", fontSize = 11.sp, color = Color.Gray)
                                    Text("¥${String.format("%,.2f", vm.calcResultValue)} 元", fontSize = 11.sp)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("测算浮动盈亏 (ROI):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${if(vm.calcResultProfit>=0) "+" else ""}${String.format("%,.2f", vm.calcResultProfit)} 元 (${if(vm.calcResultProfit>=0) "+" else ""}${String.format("%.2f", vm.calcResultRate)}%)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (vm.calcResultProfit >= 0) ChinaRedUp else ChinaGreenDown
                                    )
                                }
                            }
                        }
                    }

                    // 异常警告日志
                    if (alerts.isNotEmpty()) {
                        item {
                            Text("风控与欺诈拦截日志", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                        }
                        items(alerts) { alert ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .border(width = 1.dp, color = if (alert.severity == "高") ChinaRedUp.copy(alpha = 0.5f) else Color.Transparent, shape = RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = ChinaRedUp, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(alert.type, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ChinaRedUp)
                                            Text(alert.status, fontSize = 10.sp, color = PremiumGold, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(alert.description, fontSize = 10.sp, color = Color.Gray, lineHeight = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
}

@Composable
fun DemoHeaderTab(index: Int, name: String, isSel: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSel) PremiumGold.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name,
            color = if (isSel) PremiumGold else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun DemoGuideCard(title: String, desc: String, tag: String, actionText: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderBorder(PremiumGold.copy(alpha = 0.3f)),
        modifier = Modifier.testTag("demo_guide_$tag")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, fontSize = 11.sp, color = Color.Gray, lineHeight = 14.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = PremiumGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
            ) {
                Text(actionText, fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StepIndicator(step: Int, label: String, isActive: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(70.dp)) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (isActive) PremiumGold else MaterialTheme.colorScheme.outlineVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(step.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isActive) PremiumGold else Color.Gray)
    }
}

@Composable
fun CockpitWidget(label: String, value: String) {
    Column(
        modifier = Modifier.width(90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PremiumGold, textAlign = TextAlign.Center)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun textColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = PremiumGold,
    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
    focusedLabelColor = PremiumGold,
    cursorColor = PremiumGold
)

// AI 智能问答面板
@Composable
fun AiAssistantPanel(vm: MainViewModel) {
    val chatHistory by vm.aiChatHistory.collectAsState()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Chat List
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(MaterialTheme.colorScheme.background, shape = RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LazyColumn(modifier = Modifier.fillMaxSize(), reverseLayout = false) {
                    items(chatHistory) { pair ->
                        val isAi = pair.first == "AI"
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isAi) Alignment.Start else Alignment.End
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isAi) PremiumGold.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = pair.second,
                                    fontSize = 11.sp,
                                    color = if (isAi) PremiumGold else MaterialTheme.colorScheme.onBackground,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = vm.aiQuery,
                    onValueChange = { vm.aiQuery = it },
                    placeholder = { Text("输入关于黄金价格、托管估值的问题...", fontSize = 11.sp) },
                    colors = textColors(),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = { vm.sendAiMessage() },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(PremiumGold)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "发送", tint = Color.Black, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
