package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainViewModel : ViewModel() {

    // 1. 核心导航 Tab
    var currentTab by mutableStateOf("HOME") // "HOME", "MARKET", "SHOP", "VAULT", "MINE", "DEMO"

    // 2. 实时行情数据流
    private val _goldPrice = MutableStateFlow(
        MetalPrice(MetalType.GOLD, 2480.0, 562.50, 571.0, 560.50, PriceQuality.LIVE, "上海黄金交易所(模拟)", 1.20, 0.21)
    )
    val goldPrice: StateFlow<MetalPrice> = _goldPrice.asStateFlow()

    private val _silverPrice = MutableStateFlow(
        MetalPrice(MetalType.SILVER, 29.50, 7.15, 7.65, 6.90, PriceQuality.LIVE, "上海黄金交易所(模拟)", 0.05, 0.70)
    )
    val silverPrice: StateFlow<MetalPrice> = _silverPrice.asStateFlow()

    // 价格历史
    private val _priceHistory = MutableStateFlow<List<PriceHistoryPoint>>(SimulationData.goldHistoryPoints)
    val priceHistory: StateFlow<List<PriceHistoryPoint>> = _priceHistory.asStateFlow()

    // 价格引擎
    private val priceEngine = PriceEngine()
    private var priceTickJob: Job? = null

    // 3. 账户状态 (关联 SimulationData 中的数据，支持响应式 UI 更新)
    var userCashBalance by mutableStateOf(SimulationData.userCash.balance)
    var userGoldBalance by mutableStateOf(SimulationData.userMetal.goldBalance)
    var userSilverBalance by mutableStateOf(SimulationData.userMetal.silverBalance)

    // 用户实物资产护照列表 (克隆并由 ViewModel 驱动)
    var userGoldBars = MutableStateFlow<List<GoldBar>>(SimulationData.userGoldBars.toList())
    var userSilverBars = MutableStateFlow<List<SilverBar>>(SimulationData.userSilverBars.toList())

    // 双重账本记录
    var ledgerHistory = MutableStateFlow<List<LedgerEntry>>(SimulationData.ledgerHistory.toList())

    // 审计与安全合规
    var auditHistory = MutableStateFlow<List<AuditLogEntry>>(SimulationData.auditHistory.toList())
    var riskAlerts = MutableStateFlow<List<RiskAlert>>(SimulationData.riskAlerts.toList())

    // 4. 门店与金库 (数字孪生)
    var vaults = MutableStateFlow<List<VaultTwin>>(SimulationData.initialVaults)
    var stores = MutableStateFlow<List<Store>>(SimulationData.initialStores)

    // 5. 商业采购询价 RFQ 与 门店转移
    var rfqProduct by mutableStateOf<Product?>(null)
    var rfqQuantity by mutableStateOf("10")
    var rfqQuoteCny by mutableStateOf(0.0)
    var rfqExpiresIn by mutableStateOf(0)
    var rfqIsSuccess by mutableStateOf(false)
    private var rfqTimerJob: Job? = null

    // 6. 购物车与价格锁定机制
    var currentSelectedProduct by mutableStateOf<Product?>(null)
    var orderQuantity by mutableStateOf(1)
    var isPriceLocked by mutableStateOf(false)
    var priceLockTimeLeft by mutableStateOf(0) // 秒
    var activePriceLock by mutableStateOf<PriceLock?>(null)
    private var priceLockJob: Job? = null

    // 7. 以旧换新临时计算器
    var tradeInOldWeight by mutableStateOf("20.0")
    var tradeInOldPurity by mutableStateOf("足金999") // "足金999" 或 "足金999.9"
    var tradeInSelectedNewProduct by mutableStateOf<Product?>(null)
    var tradeInResultEstimatedValue by mutableStateOf(0.0) // 旧金回收价
    var tradeInResultNewValue by mutableStateOf(0.0)       // 新金商品价
    var tradeInResultLaborFee by mutableStateOf(0.0)       // 新金加工工费
    var tradeInResultPayAmount by mutableStateOf(0.0)      // 差额

    // 8. 黄金/白银回购模块
    var buybackMetalType by mutableStateOf(MetalType.GOLD)
    var buybackWeight by mutableStateOf("50.0")
    var buybackPurity by mutableStateOf("0.9999")
    var buybackItemType by mutableStateOf("投资金条") // 投资金条 / 黄金首饰 / 投资银条
    var buybackSerialNumber by mutableStateOf("")
    var buybackEstimatedValue by mutableStateOf(0.0)

    // 9. 定投/收益计算器
    var calcPurchasePrice by mutableStateOf("520.0")
    var calcWeight by mutableStateOf("100")
    var calcCurrentPrice by mutableStateOf("562.5")
    var calcFeeRate by mutableStateOf("0.2") // %
    var calcResultCost by mutableStateOf(0.0)
    var calcResultValue by mutableStateOf(0.0)
    var calcResultProfit by mutableStateOf(0.0)
    var calcResultRate by mutableStateOf(0.0)

    // 10. AI 智能金银助手
    var aiQuery by mutableStateOf("")
    val aiChatHistory = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "AI" to "您好！我是『金银超级零售』AI贵金属助手。我可以帮您计算100克金条当前托管价值、解释今日黄金白银行情涨跌原因、模拟资产在金价波动时的损益等。请问有什么可以帮您？"
        )
    )

    // 11. 实名 KYC 状态 (演示用)
    var isUserKycVerified by mutableStateOf(false)

    // 12. 4大核心端到端演示流程管理
    var currentDemoIndex by mutableStateOf(0) // 0: 演示大厅, 1: 100g黄金购买与托管, 2: 古法首饰以旧换新, 3: 白银大额定投, 4: 珠宝商供应链与管理驾驶舱
    var demo1Step by mutableStateOf(1) // Step 1: 询价, Step 2: 锁定价格, Step 3: 付款, Step 4: 实物分配, Step 5: 生成护照, Step 6: 托管/提货完成
    var demo1SelectedVault by mutableStateOf(VaultLocation.SHANGHAI)
    var demo1SelectedDelivery by mutableStateOf(DeliveryType.VAULT_STORE)
    var demo1AllocatedSerial by mutableStateOf("")

    // 初始化启动价格自动更新
    init {
        // 每隔3秒自动跳动一下模拟金价和银价，模拟实时上金所竞价行情
        priceTickJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                val (g, s) = priceEngine.tickPrices()
                _goldPrice.value = g
                _silverPrice.value = s

                // 更新行情走势图点位（保持最后7个点）
                val curHistory = _priceHistory.value.toMutableList()
                val nextTime = SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date())
                curHistory.add(PriceHistoryPoint(nextTime.substring(0, 5), g.benchmarkCnyGram, s.benchmarkCnyGram))
                if (curHistory.size > 8) {
                    curHistory.removeAt(0)
                }
                _priceHistory.value = curHistory

                // 顺便让金库孪生数据产生一些微妙的监控跳动 (如温湿度、库存微调)
                updateVaultsMonitoring()
            }
        }

        // 初始化以旧换新新商品
        tradeInSelectedNewProduct = SimulationData.initialProducts.find { it.id == "G-JEW-BRACE" }
        calculateTradeIn()
    }

    private fun updateVaultsMonitoring() {
        val updated = vaults.value.map {
            it.copy(
                temperatureCelsius = it.temperatureCelsius + (Math.random() * 0.4 - 0.2),
                humidityPercent = (it.humidityPercent + (Math.random() * 0.6 - 0.3)).coerceIn(40.0, 50.0)
            )
        }
        vaults.value = updated
    }

    // 更新用户本地数据
    private fun syncUserBalances() {
        userCashBalance = SimulationData.userCash.balance
        userGoldBalance = SimulationData.userMetal.goldBalance
        userSilverBalance = SimulationData.userMetal.silverBalance
        userGoldBars.value = SimulationData.userGoldBars.toList()
        userSilverBars.value = SimulationData.userSilverBars.toList()
        ledgerHistory.value = SimulationData.ledgerHistory.toList()
        auditHistory.value = SimulationData.auditHistory.toList()
        riskAlerts.value = SimulationData.riskAlerts.toList()
    }

    // 充值人民币 (方便测试)
    fun depositCny(amount: Double) {
        SimulationData.userCash = SimulationData.userCash.copy(balance = SimulationData.userCash.balance + amount)
        SimulationData.ledgerHistory.add(
            LedgerEntry(
                transactionType = "演示账户充值",
                debitAccount = "客户资产-现金账户",
                creditAccount = "系统充值渠道",
                amountCny = amount
            )
        )
        SimulationData.auditHistory.add(
            AuditLogEntry(
                action = "现金账户充值",
                targetObject = "张华",
                oldState = "¥${String.format("%.2f", userCashBalance)}",
                newState = "¥${String.format("%.2f", SimulationData.userCash.balance)}"
            )
        )
        syncUserBalances()
    }

    // 重置全部数据
    fun resetAllData() {
        SimulationData.userCash = CashAccount("USER_CNY_01", balance = 150000.0)
        SimulationData.userMetal = MetalAccount("USER_MTL_01", goldBalance = 150.0, silverBalance = 1000.0)
        SimulationData.userGoldBars.clear()
        SimulationData.userGoldBars.addAll(
            listOf(
                GoldBar(
                    id = "GB-INIT-1",
                    serialNumber = "AU9999-BJ-20260401-081",
                    manufacturer = "北京精炼总厂",
                    weight = 100.0,
                    purity = 0.9999,
                    fineGoldWeight = 100.0,
                    certificate = "NGSTC-2026-89104",
                    productionDate = "2026年04月01日",
                    owner = "张华 (当前用户)",
                    vaultLocation = VaultLocation.BEIJING,
                    status = AssetStatus.IN_VAULT,
                    purchasePrice = 54200.0,
                    currentValue = 56250.0
                ),
                GoldBar(
                    id = "GB-INIT-2",
                    serialNumber = "AU9999-SZ-20260812-421",
                    manufacturer = "深圳水贝加工厂",
                    weight = 50.0,
                    purity = 0.9999,
                    fineGoldWeight = 50.0,
                    certificate = "NGSTC-2026-11492",
                    productionDate = "2026年08月12日",
                    owner = "张华 (当前用户)",
                    vaultLocation = VaultLocation.SHENZHEN,
                    status = AssetStatus.IN_VAULT,
                    purchasePrice = 27150.0,
                    currentValue = 28125.0
                )
            )
        )
        SimulationData.userSilverBars.clear()
        SimulationData.userSilverBars.addAll(
            listOf(
                SilverBar(
                    id = "SB-INIT-1",
                    serialNumber = "AG999-SH-20260520-011",
                    manufacturer = "上海造币厂",
                    weight = 1000.0,
                    purity = 0.999,
                    fineSilverWeight = 1000.0,
                    certificate = "AGSTC-2026-55421",
                    productionDate = "2026年05月20日",
                    owner = "张华 (当前用户)",
                    vaultLocation = VaultLocation.SHANGHAI,
                    status = AssetStatus.IN_VAULT,
                    purchasePrice = 6900.0,
                    currentValue = 7150.0
                )
            )
        )
        SimulationData.ledgerHistory.clear()
        SimulationData.ledgerHistory.addAll(
            listOf(
                LedgerEntry(
                    transactionType = "系统初始化账户",
                    debitAccount = "客户资产-现金账户",
                    creditAccount = "系统存托发行",
                    amountCny = 150000.0,
                    metalGrams = 0.0
                ),
                LedgerEntry(
                    transactionType = "实物资产初始入库",
                    debitAccount = "客户资产-实物托管金账户 (150.0g 黄金)",
                    creditAccount = "系统存托发行",
                    amountCny = 81350.0,
                    metalGrams = 150.0,
                    metalType = MetalType.GOLD
                ),
                LedgerEntry(
                    transactionType = "实物资产初始入库",
                    debitAccount = "客户资产-实物托管银账户 (1000.0g 白银)",
                    creditAccount = "系统存托发行",
                    amountCny = 6900.0,
                    metalGrams = 1000.0,
                    metalType = MetalType.SILVER
                )
            )
        )
        SimulationData.riskAlerts.clear()
        SimulationData.riskAlerts.add(
            RiskAlert(
                type = "反洗钱 (AML) - 日常自动监控机制",
                severity = "低",
                description = "超级零售系统已连接人行反洗钱大额上报系统，所有超过5万元人民币的贵金属购买、回购和以旧换新均需实名登记。",
                status = "放行"
            )
        )
        SimulationData.auditHistory.clear()
        SimulationData.auditHistory.addAll(
            listOf(
                AuditLogEntry(
                    action = "数字账户重置与重建",
                    targetObject = "张华 (USER_CNY_01)",
                    oldState = "RESETTING",
                    newState = "ACTIVE"
                )
            )
        )
        isUserKycVerified = false
        demo1Step = 1
        syncUserBalances()
    }

    // ================== DEMO 1: 100g黄金购买与托管 ==================
    fun runDemo1Step1_LockPrice() {
        val p = SimulationData.initialProducts.find { product -> product.id == "G-BAR-100" } ?: return
        currentSelectedProduct = p
        orderQuantity = 1

        val currentBenchmark = _goldPrice.value.buyPrice
        val finalSinglePrice = RetailPricingEngine.calculateRetailPrice(p, currentBenchmark)
        val totalCost = finalSinglePrice * orderQuantity

        activePriceLock = PriceLock(
            metalType = MetalType.GOLD,
            lockedPrice = currentBenchmark,
            totalCost = totalCost,
            expiresAt = System.currentTimeMillis() + 60000
        )

        isPriceLocked = true
        priceLockTimeLeft = 60

        // 开启锁价60s倒计时
        priceLockJob?.cancel()
        priceLockJob = viewModelScope.launch {
            while (priceLockTimeLeft > 0) {
                delay(1000)
                priceLockTimeLeft--
            }
            isPriceLocked = false
            activePriceLock = null
            if (demo1Step == 2) {
                demo1Step = 1 // 超时自动退回第1步
                SimulationData.auditHistory.add(
                    AuditLogEntry(
                        action = "锁定报价超时失效",
                        targetObject = "G-BAR-100 (60秒)",
                        oldState = "LOCKED",
                        newState = "EXPIRED"
                    )
                )
                syncUserBalances()
            }
        }

        demo1Step = 2 // 前进到锁定价格待支付步骤
        SimulationData.auditHistory.add(
            AuditLogEntry(
                action = "锁定黄金基准报价",
                targetObject = "G-BAR-100 (100g金条)",
                oldState = "LIVE",
                newState = "LOCKED [¥${String.format("%.2f", currentBenchmark)}/g]"
            )
        )
        syncUserBalances()
    }

    fun runDemo1Step2_Pay() {
        val lock = activePriceLock ?: return
        val p = currentSelectedProduct ?: return

        // 检查合规与大额洗钱风险
        val (riskCode, alert) = RiskEngine.evaluateTransactionRisk(
            isUserKycVerified,
            lock.totalCost,
            p.weight * orderQuantity,
            1
        )

        if (alert != null) {
            SimulationData.riskAlerts.add(0, alert)
        }

        if (riskCode == "BLOCKED_KYC") {
            demo1Step = 1 // 退回
            syncUserBalances()
            return
        }

        // 检查用户现金是否足够
        if (userCashBalance < lock.totalCost) {
            // 自动补足资金方便演示
            depositCny(lock.totalCost - userCashBalance + 5000.0)
        }

        // 扣款记账
        demo1AllocatedSerial = "AU9999-SH-202610-${(100000 + Math.random() * 900000).toInt()}"
        val success = SimulationData.executeDoubleEntryPurchase(
            order = Order(
                product = p,
                quantity = orderQuantity,
                lockedPricePerGram = lock.lockedPrice,
                laborFee = p.laborFeePerGram * p.weight * orderQuantity,
                premium = p.premiumPerGram * p.weight * orderQuantity,
                taxAmount = ChinaTaxEngine.calculateTax(p, lock.totalCost).totalTax,
                totalAmount = lock.totalCost,
                status = OrderStatus.PAID,
                targetType = demo1SelectedDelivery,
                serialAllocated = demo1AllocatedSerial
            ),
            allocatedSerialNumber = demo1AllocatedSerial,
            targetVault = demo1SelectedVault
        )

        if (success) {
            priceLockJob?.cancel()
            isPriceLocked = false
            demo1Step = 3 // 成功跳转到生成数字护照与托管状态
            syncUserBalances()
        }
    }

    // ================== DEMO 2: 首饰古法金以旧换新 ==================
    fun calculateTradeIn() {
        val oldWeight = tradeInOldWeight.toDoubleOrNull() ?: 0.0
        val p = tradeInSelectedNewProduct ?: return

        // 1. 旧金回收价公式: 当前回购价 - 贴水 
        // 假设旧金为足金999 (成色折率0.999)
        val purityFactor = if (tradeInOldPurity == "足金999.9") 1.0 else 0.99
        val goldBackPrice = _goldPrice.value.buybackPrice
        val oldUnitValue = goldBackPrice * purityFactor
        val recycleVal = oldWeight * oldUnitValue

        // 2. 新首饰价值: (金价 + 溢价) * 克重
        val currentGoldBuy = _goldPrice.value.buyPrice
        val newVal = (currentGoldBuy + p.premiumPerGram) * p.weight

        // 3. 首饰加工费
        val labor = p.laborFeePerGram * p.weight

        // 4. 应付差额 = 新首饰总价 + 加工费 - 旧金回收抵扣额
        val diff = newVal + labor - recycleVal

        tradeInResultEstimatedValue = (recycleVal * 100).roundToInt() / 100.0
        tradeInResultNewValue = (newVal * 100).roundToInt() / 100.0
        tradeInResultLaborFee = (labor * 100).roundToInt() / 100.0
        tradeInResultPayAmount = (diff * 100).roundToInt() / 100.0
    }

    fun executeTradeIn() {
        calculateTradeIn()
        val p = tradeInSelectedNewProduct ?: return

        if (userCashBalance < tradeInResultPayAmount) {
            depositCny(tradeInResultPayAmount - userCashBalance + 2000.0)
        }

        val success = SimulationData.executeDoubleEntryExchange(
            ExchangeOrder(
                oldMetalWeight = tradeInOldWeight.toDoubleOrNull() ?: 0.0,
                oldMetalPurity = if (tradeInOldPurity == "足金999.9") 0.9999 else 0.999,
                oldMetalType = "足金旧首饰",
                oldRecycleValue = tradeInResultEstimatedValue,
                newProduct = p,
                newProductValue = tradeInResultNewValue,
                laborFee = tradeInResultLaborFee,
                cashDifference = tradeInResultPayAmount
            )
        )

        if (success) {
            syncUserBalances()
        }
    }

    // ================== DEMO 3: 大额白银定投及托管 ==================
    var demo3Quantity = 5 // 购买5个 1kg 银条
    var demo3SelectedVault = VaultLocation.SHANGHAI
    var demo3Step by mutableStateOf(1) // 1: 询价, 2: 锁定支付, 3: 完成

    fun executeDemo3SilverPurchase() {
        val p = SimulationData.initialProducts.find { it.id == "S-BAR-1000" } ?: return
        val currentBenchmark = _silverPrice.value.buyPrice
        val finalSinglePrice = RetailPricingEngine.calculateRetailPrice(p, currentBenchmark)
        val totalCost = finalSinglePrice * demo3Quantity

        // 检查余额
        if (userCashBalance < totalCost) {
            depositCny(totalCost - userCashBalance + 1000.0)
        }

        // 分配 5 个唯一的白银编号
        for (i in 1..demo3Quantity) {
            val serial = "AG9999-SH-202610-S${(10000 + Math.random() * 90000).toInt()}"
            SimulationData.executeDoubleEntryPurchase(
                order = Order(
                    product = p,
                    quantity = 1,
                    lockedPricePerGram = currentBenchmark,
                    laborFee = p.laborFeePerGram * p.weight,
                    premium = p.premiumPerGram * p.weight,
                    taxAmount = ChinaTaxEngine.calculateTax(p, finalSinglePrice).totalTax,
                    totalAmount = finalSinglePrice,
                    status = OrderStatus.PAID,
                    targetType = DeliveryType.VAULT_STORE,
                    serialAllocated = serial
                ),
                allocatedSerialNumber = serial,
                targetVault = demo3SelectedVault
            )
        }

        demo3Step = 2
        syncUserBalances()
    }

    // ================== DEMO 4: 模拟百万笔全自动化大屏驾驶舱运行 ==================
    var isSimulatingCockpit by mutableStateOf(false)

    fun runCockpitSimulation() {
        viewModelScope.launch {
            isSimulatingCockpit = true
            // 快速更新，模拟并发行为
            for (i in 1..5) {
                delay(400)
                SimulationData.cockpitTodaySalesCny += (100000.0 + Math.random() * 400000.0)
                SimulationData.cockpitTodayGoldGrams += (200.0 + Math.random() * 500.0)
                SimulationData.cockpitTodaySilverGrams += (1000.0 + Math.random() * 3000.0)
                SimulationData.cockpitCustomerCount += (5 + Math.random() * 15).toInt()
                SimulationData.cockpitOrderCount += (2 + Math.random() * 8).toInt()

                // 随机增加一些审计和反洗钱日志，制造活跃状态
                SimulationData.auditHistory.add(
                    0, AuditLogEntry(
                        action = "大额批发交割对账",
                        targetObject = "金库调拨单 TX-${(10000 + Math.random() * 90000).toInt()}",
                        oldState = "TRANSIT",
                        newState = "CONFIRMED"
                    )
                )

                if (Math.random() > 0.7) {
                    SimulationData.riskAlerts.add(
                        0, RiskAlert(
                            type = "反欺诈 (Fraud) - 自动风控防御拦截",
                            severity = "中",
                            description = "深圳门店IP检测到异常登录碰撞，设备指纹校验异常。系统已经自动拒绝其提现及黄金转移请求。",
                            status = "合规官已拦截"
                        )
                    )
                }
            }
            isSimulatingCockpit = false
            syncUserBalances()
        }
    }

    // ================== RFQ 商家报价 ==================
    fun executeRFQ() {
        val p = currentSelectedProduct ?: return
        val qty = rfqQuantity.toIntOrNull() ?: 10
        val baseQuote = _goldPrice.value.buyPrice
        
        // 批发大额采购价格：扣减品牌溢价，给商户返点
        val singlePrice = baseQuote * p.weight
        val total = singlePrice * qty * 0.96 // 96折
        rfqQuoteCny = (total * 100).roundToInt() / 100.0
        rfqExpiresIn = 30
        rfqIsSuccess = true

        rfqTimerJob?.cancel()
        rfqTimerJob = viewModelScope.launch {
            while (rfqExpiresIn > 0) {
                delay(1000)
                rfqExpiresIn--
            }
            rfqIsSuccess = false
        }
    }

    // ================== 回购计算器 ==================
    fun calculateBuyback() {
        val w = buybackWeight.toDoubleOrNull() ?: 0.0
        val basePrice = if (buybackMetalType == MetalType.GOLD) _goldPrice.value.buybackPrice else _silverPrice.value.buybackPrice
        val factor = buybackPurity.toDoubleOrNull() ?: 0.9999
        val value = w * basePrice * (factor / 0.9999)
        buybackEstimatedValue = (value * 100).roundToInt() / 100.0
    }

    fun submitBuyback() {
        calculateBuyback()
        val w = buybackWeight.toDoubleOrNull() ?: 0.0
        val isGold = buybackMetalType == MetalType.GOLD

        // 检查名下是否有实物可以回购，如果有，优先标为 SOLD
        var realSerial: String? = null
        if (isGold) {
            val availableBar = SimulationData.userGoldBars.find { it.status == AssetStatus.IN_VAULT }
            if (availableBar != null) {
                realSerial = availableBar.serialNumber
            }
        } else {
            val availableBar = SimulationData.userSilverBars.find { it.status == AssetStatus.IN_VAULT }
            if (availableBar != null) {
                realSerial = availableBar.serialNumber
            }
        }

        val success = SimulationData.executeDoubleEntryBuyback(
            BuybackOrder(
                metalType = buybackMetalType,
                weight = w,
                claimedPurity = buybackPurity.toDoubleOrNull() ?: 0.9999,
                itemType = buybackItemType,
                valuationStatus = "检测完毕-100%符合国标",
                estimatedPrice = buybackEstimatedValue,
                finalPrice = buybackEstimatedValue,
                status = BuybackStatus.COMPLETED,
                serialNumber = realSerial
            )
        )

        if (success) {
            syncUserBalances()
        }
    }

    // ================== 定投/收益计算器 ==================
    fun runCalc() {
        val buyP = calcPurchasePrice.toDoubleOrNull() ?: 500.0
        val w = calcWeight.toDoubleOrNull() ?: 10.0
        val curP = calcCurrentPrice.toDoubleOrNull() ?: 550.0
        val feeRateVal = calcFeeRate.toDoubleOrNull() ?: 0.2

        val cost = buyP * w
        val fee = cost * (feeRateVal / 100.0)
        val totalCost = cost + fee

        val currentVal = curP * w
        val outFee = currentVal * (feeRateVal / 100.0)
        val profit = currentVal - totalCost - outFee
        val profitRate = (profit / totalCost) * 100.0

        calcResultCost = (totalCost * 100).roundToInt() / 100.0
        calcResultValue = (currentVal * 100).roundToInt() / 100.0
        calcResultProfit = (profit * 100).roundToInt() / 100.0
        calcResultRate = (profitRate * 100).roundToInt() / 100.0
    }

    // ================== AI 智能金银助手 ==================
    fun sendAiMessage() {
        if (aiQuery.isBlank()) return
        val userMsg = aiQuery
        aiChatHistory.value = aiChatHistory.value + ("User" to userMsg)
        aiQuery = ""

        viewModelScope.launch {
            delay(800) // 模拟轻量智能思考
            val response = generateAiResponse(userMsg)
            aiChatHistory.value = aiChatHistory.value + ("AI" to response)
        }
    }

    private fun generateAiResponse(query: String): String {
        val gBuy = _goldPrice.value.buyPrice
        val gBack = _goldPrice.value.buybackPrice
        val sBuy = _silverPrice.value.buyPrice
        val sBack = _silverPrice.value.buybackPrice
        val ratio = gBuy / sBuy

        return when {
            query.contains("金") && query.contains("值") -> {
                "根据实时双重账本，您当前持有黄金 $userGoldBalance 克。按照今日零售买入参考价 ¥${String.format("%.2f", gBuy)}/克计算，您的黄金估值约为 ¥${String.format("%.2f", userGoldBalance * gBuy)} 元。如需变现，按官方回购参考价 ¥${String.format("%.2f", gBack)}/克，折合回购变现额约为 ¥${String.format("%.2f", userGoldBalance * gBack)} 元（最终价格以实物光谱测定为准）。"
            }
            query.contains("银") && query.contains("值") -> {
                "您名下持有白银 $userSilverBalance 克。按今日零售买入参考价 ¥${String.format("%.2f", sBuy)}/克，资产估值约为 ¥${String.format("%.2f", userSilverBalance * sBuy)} 元。官方回购变现估值约为 ¥${String.format("%.2f", userSilverBalance * sBack)} 元。"
            }
            query.contains("涨") || query.contains("为什么") || query.contains("行情") -> {
                "【金银超级零售研究院分析】今日黄金表现强势（现报 ¥${String.format("%.2f", gBuy)}/克），主要受地缘避险买盘和美联储降息预期提振。同时，白银由于光伏双玻组件等工业需求强劲，比价效应明显（现报 ¥${String.format("%.2f", sBuy)}/克）。金银比率（Gold/Silver Ratio）目前为 ${String.format("%.1f", ratio)}，处于历史中轴区间，白银投资弹性相对偏大。"
            }
            query.contains("差") || query.contains("多少钱") || query.contains("算") -> {
                "根据大宗商品 RetailPricingEngine，中国投资金条通常在实时金价基础上增加 10~15元/克的渠道服务溢价；而古法金首饰由于涉及国家级非遗工艺，溢价通常在 45~60元/克，且另收 30~50元/克的工费。因此古法金首饰适合消费美化，投资避险应首选足金999.9投资金条。"
            }
            else -> {
                "关于贵金属超级零售：今日黄金买入价 ¥${String.format("%.2f", gBuy)}，回购价 ¥${String.format("%.2f", gBack)}；白银买入价 ¥${String.format("%.2f", sBuy)}，回购价 ¥${String.format("%.2f", sBack)}。您的可用投资备付金余额为 ¥${String.format("%.2f", userCashBalance)}。您可以直接向我询问您的资产折算或进行投资计算模拟！"
            }
        }
    }

    override fun onCleared() {
        priceTickJob?.cancel()
        priceLockJob?.cancel()
        rfqTimerJob?.cancel()
        super.onCleared()
    }
}
