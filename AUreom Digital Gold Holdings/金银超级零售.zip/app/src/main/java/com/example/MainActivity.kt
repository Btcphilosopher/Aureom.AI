package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PremiumGold

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 开启全屏沉浸式边缘到边缘
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
                    bottomBar = {
                        BottomNavBar(
                            currentTab = viewModel.currentTab,
                            onTabSelected = { tab -> viewModel.currentTab = tab }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // 自定义 BackHandler，按下物理返回键自动返回首页
                        if (viewModel.currentTab != "HOME") {
                            BackHandler {
                                viewModel.currentTab = "HOME"
                            }
                        }

                        // 各模块屏幕切换渲染
                        when (viewModel.currentTab) {
                            "HOME" -> HomeScreen(viewModel)
                            "MARKET" -> MarketScreen(viewModel)
                            "SHOP" -> ShopScreen(viewModel)
                            "VAULT" -> VaultScreen(viewModel)
                            "MINE" -> MineScreen(viewModel)
                            "DEMO" -> DemoScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

// 首页底部高端导航
@Composable
fun BottomNavBar(currentTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("bottom_navigation_bar")
    ) {
        NavigationBarItem(
            selected = currentTab == "HOME",
            onClick = { onTabSelected("HOME") },
            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "首页") },
            label = { Text("首页", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_home_tab")
        )
        NavigationBarItem(
            selected = currentTab == "MARKET",
            onClick = { onTabSelected("MARKET") },
            icon = { Icon(imageVector = Icons.Default.Analytics, contentDescription = "行情") },
            label = { Text("行情", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_market_tab")
        )
        NavigationBarItem(
            selected = currentTab == "SHOP",
            onClick = { onTabSelected("SHOP") },
            icon = { Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = "商城") },
            label = { Text("商城", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_shop_tab")
        )
        NavigationBarItem(
            selected = currentTab == "VAULT",
            onClick = { onTabSelected("VAULT") },
            icon = { Icon(imageVector = Icons.Default.Security, contentDescription = "金库") },
            label = { Text("金库", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_vault_tab")
        )
        NavigationBarItem(
            selected = currentTab == "MINE",
            onClick = { onTabSelected("MINE") },
            icon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = "我的") },
            label = { Text("资产", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_mine_tab")
        )
        NavigationBarItem(
            selected = currentTab == "DEMO",
            onClick = { onTabSelected("DEMO") },
            icon = { Icon(imageVector = Icons.Default.Storefront, contentDescription = "演示") },
            label = { Text("演示", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = itemColors(),
            modifier = Modifier.testTag("nav_demo_tab")
        )
    }
}

@Composable
fun itemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = PremiumGold,
    selectedTextColor = PremiumGold,
    indicatorColor = PremiumGold.copy(alpha = 0.15f),
    unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
    unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
)
