package com.example

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// 模拟数据源与双重记账系统
object SimulationData {

    // 1. 初始化预置商品
    val initialProducts = listOf(
        // 投资金条
        Product(
            id = "G-BAR-100",
            name = "「中国黄金」足金999.9投资金条 100g",
            metalType = MetalType.GOLD,
            category = ProductCategory.INVESTMENT_BAR,
            weight = 100.0,
            purity = 0.9999,
            brand = "中国黄金",
            manufacturer = "深圳大金库精炼厂",
            premiumPerGram = 10.0, // 低溢价
            laborFeePerGram = 2.0,  // 极低加工费
            description = "纯度足金999.9，上海黄金交易所标准交割条，配权威无损检测证书。收藏、投资、抗通胀首选。",
            inStock = 120,
            certificateType = "国家金银制品质量检验检测中心(NGSTC)证书"
        ),
        Product(
            id = "G-BAR-50",
            name = "「中钞国鼎」足金999.9投资金条 50g",
            metalType = MetalType.GOLD,
            category = ProductCategory.INVESTMENT_BAR,
            weight = 50.0,
            purity = 0.9999,
            brand = "中钞国鼎",
            manufacturer = "中国印钞造币集团",
            premiumPerGram = 12.0,
            laborFeePerGram = 3.0,
            description = "国家印钞工艺精制，双重防伪暗记，高纯度实物投资金条。",
            inStock = 340,
            certificateType = "中钞特种防伪证书"
        ),
        Product(
            id = "G-BAR-10",
            name = "「招金银楼」传世金条 10g",
            metalType = MetalType.GOLD,
            category = ProductCategory.INVESTMENT_BAR,
            weight = 10.0,
            purity = 0.999,
            brand = "招金银楼",
            manufacturer = "山东招金金艺科技",
            premiumPerGram = 15.0,
            laborFeePerGram = 5.0,
            description = "轻量级高纯度黄金积存与实物兑换条，非常适合家庭资产阶梯式配置。",
            inStock = 950,
            certificateType = "招金质检证书"
        ),
        // 熊猫金币
        Product(
            id = "G-COIN-30",
            name = "2026版中国熊猫普制金币 30g",
            metalType = MetalType.GOLD,
            category = ProductCategory.INVESTMENT_COIN,
            weight = 30.0,
            purity = 0.999,
            brand = "中国人民银行",
            manufacturer = "深圳国宝造币有限公司",
            premiumPerGram = 25.0,
            laborFeePerGram = 0.0,
            description = "中华人民共和国法定货币，世界五大投资金币之一。兼具投资与艺术收藏双重价值。",
            inStock = 45,
            certificateType = "中国人民银行鉴定说明书"
        ),
        // 黄金首饰
        Product(
            id = "G-JEW-BRACE",
            name = "「古法金」传家祥云足金手镯 30g",
            metalType = MetalType.GOLD,
            category = ProductCategory.JEWELRY,
            weight = 30.0,
            purity = 0.999,
            brand = "金银超级零售",
            manufacturer = "深圳水贝黄金创意园",
            premiumPerGram = 45.0, // 首饰溢价高
            laborFeePerGram = 35.0, // 首饰加工工费高
            description = "采用中国传统花丝镶嵌与哑光古法工艺，手感温润，色泽温雅，祥云纹饰寓意福瑞绵延。",
            inStock = 18,
            certificateType = "广东地质科研所珠宝鉴定证书"
        ),
        Product(
            id = "G-JEW-NECK",
            name = "「足金999」经典黄金锁骨项链 10g",
            metalType = MetalType.GOLD,
            category = ProductCategory.JEWELRY,
            weight = 10.0,
            purity = 0.999,
            brand = "周大福(合作)",
            manufacturer = "周大福珠宝制造厂",
            premiumPerGram = 58.0,
            laborFeePerGram = 40.0,
            description = "极简抛光工艺，流光溢彩。不仅是日常精美配饰，亦可用于保值保底资产。",
            inStock = 35,
            certificateType = "国家首饰质量监督检验中心证书"
        ),
        // 投资银条
        Product(
            id = "S-BAR-1000",
            name = "「华通白银」足银99.99国标投资银条 1kg",
            metalType = MetalType.SILVER,
            category = ProductCategory.INDUSTRIAL_THEME,
            weight = 1000.0,
            purity = 0.9999,
            brand = "华通白银",
            manufacturer = "郴州白银冶炼总厂",
            premiumPerGram = 0.8,
            laborFeePerGram = 0.1,
            description = "国标1号银，白银工业核心需求精炼。双重钢印，带质检证书。实物投资、大额避险佳品。",
            inStock = 150,
            certificateType = "国家贵金属质检中心检测报告"
        ),
        Product(
            id = "S-BAR-100",
            name = "「金银超级零售」财富尊享足银条 100g",
            metalType = MetalType.SILVER,
            category = ProductCategory.INDUSTRIAL_THEME,
            weight = 100.0,
            purity = 0.999,
            brand = "金银超级零售",
            manufacturer = "深圳水贝白银创意工厂",
            premiumPerGram = 1.2,
            laborFeePerGram = 0.3,
            description = "镜面抛光工艺，适合送礼、小额定投或物理储备。",
            inStock = 890,
            certificateType = "本厂贵金属防伪证书"
        )
    )

    // 2. 初始化金库列表
    val initialVaults = listOf(
        VaultTwin(
            location = VaultLocation.BEIJING,
            capacityKg = 5000.0,
            storedGoldKg = 3120.5,
            storedSilverKg = 41200.0,
            customerAssetsCount = 14200,
            securityStatus = "特级安防监控中",
            temperatureCelsius = 20.2,
            humidityPercent = 45.0
        ),
        VaultTwin(
            location = VaultLocation.SHANGHAI,
            capacityKg = 10000.0,
            storedGoldKg = 8450.2,
            storedSilverKg = 98000.0,
            customerAssetsCount = 38900,
            securityStatus = "海关监管隔离区",
            temperatureCelsius = 19.8,
            humidityPercent = 44.5
        ),
        VaultTwin(
            location = VaultLocation.SHENZHEN,
            capacityKg = 8000.0,
            storedGoldKg = 5210.8,
            storedSilverKg = 61200.0,
            customerAssetsCount = 29400,
            securityStatus = "智能机器人值守",
            temperatureCelsius = 20.5,
            humidityPercent = 45.2
        ),
        VaultTwin(
            location = VaultLocation.GUANGZHOU,
            capacityKg = 4000.0,
            storedGoldKg = 1890.3,
            storedSilverKg = 25000.0,
            customerAssetsCount = 8900,
            securityStatus = "特级安防监控中",
            temperatureCelsius = 21.0,
            humidityPercent = 46.1
        ),
        VaultTwin(
            location = VaultLocation.HANGZHOU,
            capacityKg = 3000.0,
            storedGoldKg = 1420.1,
            storedSilverKg = 18000.0,
            customerAssetsCount = 6700,
            securityStatus = "区块链审计多重存证",
            temperatureCelsius = 20.1,
            humidityPercent = 43.9
        )
    )

    // 3. 预置门店列表
    val initialStores = listOf(
        Store("ST-01", "北京王府井旗舰店", "北京", "东城区王府井大街255号", 150.0, 500.0, 12),
        Store("ST-02", "上海南京东路金座", "上海", "黄浦区南京东路422号", 220.0, 800.0, 18),
        Store("ST-03", "深圳水贝总部展厅", "深圳", "罗湖区贝丽北路特力珠宝大厦", 350.0, 1200.0, 32),
        Store("ST-04", "广州北京路精品店", "广州", "越秀区北京路商业步行街", 90.0, 300.0, 9),
        Store("ST-05", "杭州武林广场旗舰店", "杭州", "拱墅区延安路546号", 110.0, 400.0, 14)
    )

    // 4. 用户初始资产账本
    var userCash = CashAccount("USER_CNY_01", balance = 150000.0) // 15万人民币初始资金
    var userMetal = MetalAccount("USER_MTL_01", goldBalance = 150.0, silverBalance = 1000.0) // 初始150g黄金，1000g白银持仓

    // 5. 初始名下持有的实物黄金与白银列表 (数字孪生护照)
    val userGoldBars = mutableListOf(
        GoldBar(
            id = "GB-INIT-1",
            serialNumber = "AU9999-BJ-20260401-081",
            manufacturer = "北京精炼总厂",
            weight = 100.0,
            purity = 0.9999,
            fineGoldWeight = 100.0,
            certificate = "NGSTC-2026-89104",
            productionDate = "2026年04月01日",
            owner = "张华 (当前用户)",
            vaultLocation = VaultLocation.BEIJING,
            status = AssetStatus.IN_VAULT,
            purchasePrice = 54200.0,
            currentValue = 56250.0
        ),
        GoldBar(
            id = "GB-INIT-2",
            serialNumber = "AU9999-SZ-20260812-421",
            manufacturer = "深圳水贝加工厂",
            weight = 50.0,
            purity = 0.9999,
            fineGoldWeight = 50.0,
            certificate = "NGSTC-2026-11492",
            productionDate = "2026年08月12日",
            owner = "张华 (当前用户)",
            vaultLocation = VaultLocation.SHENZHEN,
            status = AssetStatus.IN_VAULT,
            purchasePrice = 27150.0,
            currentValue = 28125.0
        )
    )

    val userSilverBars = mutableListOf(
        SilverBar(
            id = "SB-INIT-1",
            serialNumber = "AG999-SH-20260520-011",
            manufacturer = "上海造币厂",
            weight = 1000.0,
            purity = 0.999,
            fineSilverWeight = 1000.0,
            certificate = "AGSTC-2026-55421",
            productionDate = "2026年05月20日",
            owner = "张华 (当前用户)",
            vaultLocation = VaultLocation.SHANGHAI,
            status = AssetStatus.IN_VAULT,
            purchasePrice = 6900.0,
            currentValue = 7150.0
        )
    )

    // 6. 双重记账 Ledger（复式记账法）
    val ledgerHistory = mutableListOf(
        LedgerEntry(
            transactionType = "系统初始化账户",
            debitAccount = "客户资产-现金账户",
            creditAccount = "系统存托发行",
            amountCny = 150000.0,
            metalGrams = 0.0
        ),
        LedgerEntry(
            transactionType = "实物资产初始入库",
            debitAccount = "客户资产-实物托管金账户 (150.0g 黄金)",
            creditAccount = "系统存托发行",
            amountCny = 81350.0,
            metalGrams = 150.0,
            metalType = MetalType.GOLD
        ),
        LedgerEntry(
            transactionType = "实物资产初始入库",
            debitAccount = "客户资产-实物托管银账户 (1000.0g 白银)",
            creditAccount = "系统存托发行",
            amountCny = 6900.0,
            metalGrams = 1000.0,
            metalType = MetalType.SILVER
        )
    )

    // 7. 异常警报记录
    val riskAlerts = mutableListOf(
        RiskAlert(
            type = "反洗钱 (AML) - 日常自动监控机制",
            severity = "低",
            description = "超级零售系统已连接人行反洗钱大额上报系统，所有超过5万元人民币的贵金属购买、回购和以旧换新均需实名登记。",
            status = "放行"
        )
    )

    // 8. 审计追踪日志
    val auditHistory = mutableListOf(
        AuditLogEntry(
            action = "数字账户创建",
            targetObject = "张华 (USER_CNY_01)",
            oldState = "NONE",
            newState = "ACTIVE"
        ),
        AuditLogEntry(
            action = "金库数字孪生同步",
            targetObject = "全域5个主力金库",
            oldState = "OFFLINE",
            newState = "CONNECTED_REALTIME"
        )
    )

    // 9. 宏观宏观演示大盘指标 (模拟 100万+ 消费者产生的大屏驾驶舱数据)
    var cockpitTodaySalesCny = 12458920.00   // 今日销售额：1245.89万
    var cockpitTodayGoldGrams = 22150.0       // 今日黄金销量：22150克
    var cockpitTodaySilverGrams = 354000.0    // 今日白银销量：354000克
    var cockpitTodayBuybackCny = 3895400.00   // 今日回购金额：389.54万
    var cockpitTotalVaultGoldKg = 20121.9     // 托管黄金总克数
    var cockpitTotalVaultSilverKg = 243200.0  // 托管白银总克数
    var cockpitCustomerCount = 1150420        // 总客户数：115万
    var cockpitOrderCount = 4210              // 今日订单数：4210笔

    // 10. 行情历史记录数据点 (24h走势)
    val goldHistoryPoints = mutableListOf(
        PriceHistoryPoint("09:00", 558.0, 7.05),
        PriceHistoryPoint("10:00", 559.2, 7.08),
        PriceHistoryPoint("11:00", 560.1, 7.11),
        PriceHistoryPoint("12:00", 559.5, 7.10),
        PriceHistoryPoint("13:00", 561.4, 7.12),
        PriceHistoryPoint("14:00", 562.5, 7.15),
        PriceHistoryPoint("15:00", 562.0, 7.14)
    )

    // 11. 执行记账并扣款 (Double Entry Transaction)
    @Synchronized
    fun executeDoubleEntryPurchase(
        order: Order,
        allocatedSerialNumber: String,
        targetVault: VaultLocation = VaultLocation.SHANGHAI
    ): Boolean {
        // 安全性检查
        if (userCash.balance < order.totalAmount) return false

        // 1. 扣减现金账户
        val oldCash = userCash.balance
        userCash = userCash.copy(balance = oldCash - order.totalAmount)

        // 2. 增加金属账户
        val oldMetalGold = userMetal.goldBalance
        val oldMetalSilver = userMetal.silverBalance

        val p = order.product
        if (p.metalType == MetalType.GOLD) {
            userMetal = userMetal.copy(goldBalance = oldMetalGold + (p.weight * order.quantity))
            
            // 3. 生成金条实物及数字护照 (如果是金条)
            if (p.category == ProductCategory.INVESTMENT_BAR || p.category == ProductCategory.INVESTMENT_COIN) {
                userGoldBars.add(
                    GoldBar(
                        serialNumber = allocatedSerialNumber,
                        manufacturer = p.manufacturer,
                        weight = p.weight,
                        purity = p.purity,
                        fineGoldWeight = p.weight * p.purity,
                        certificate = "NGSTC-2026-${(10000 + Math.random() * 90000).toInt()}",
                        productionDate = SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA).format(Date()),
                        owner = "张华 (当前用户)",
                        vaultLocation = targetVault,
                        status = if (order.targetType == DeliveryType.VAULT_STORE) AssetStatus.IN_VAULT else AssetStatus.DELIVERING,
                        purchasePrice = order.totalAmount,
                        currentValue = order.totalAmount
                    )
                )
            }
        } else {
            userMetal = userMetal.copy(silverBalance = oldMetalSilver + (p.weight * order.quantity))
            
            // 4. 生成白银数字护照
            if (p.category == ProductCategory.INDUSTRIAL_THEME) {
                userSilverBars.add(
                    SilverBar(
                        serialNumber = allocatedSerialNumber,
                        manufacturer = p.manufacturer,
                        weight = p.weight,
                        purity = p.purity,
                        fineSilverWeight = p.weight * p.purity,
                        certificate = "AGSTC-2026-${(10000 + Math.random() * 90000).toInt()}",
                        productionDate = SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA).format(Date()),
                        owner = "张华 (当前用户)",
                        vaultLocation = targetVault,
                        status = if (order.targetType == DeliveryType.VAULT_STORE) AssetStatus.IN_VAULT else AssetStatus.DELIVERING,
                        purchasePrice = order.totalAmount,
                        currentValue = order.totalAmount
                    )
                )
            }
        }

        // 5. 登记复式记账明细 (Double-Entry Ledger)
        ledgerHistory.add(
            LedgerEntry(
                transactionType = "购买商品 - ${p.name} x${order.quantity}",
                debitAccount = "客户资产-实物托管${if (p.metalType == MetalType.GOLD) "金" else "银"}账户",
                creditAccount = "客户资产-现金账户",
                amountCny = order.totalAmount,
                metalGrams = p.weight * order.quantity,
                metalType = p.metalType
            )
        )

        // 6. 今日宏观数据增加
        cockpitTodaySalesCny += order.totalAmount
        if (p.metalType == MetalType.GOLD) {
            cockpitTodayGoldGrams += p.weight * order.quantity
        } else {
            cockpitTodaySilverGrams += p.weight * order.quantity
        }
        cockpitOrderCount += 1

        // 7. 写入合规审计
        auditHistory.add(
            AuditLogEntry(
                action = "购买交易记账完成",
                targetObject = order.orderId,
                oldState = "PRICE_LOCKED",
                newState = "COMPLETED"
            )
        )

        return true
    }

    // 12. 执行回购结款 (Buyback entry)
    @Synchronized
    fun executeDoubleEntryBuyback(
        order: BuybackOrder
    ): Boolean {
        // 回购：系统收回金银实物，给用户打入现金
        // 在该Demo中，我们模拟把名下的某张金条或银条卖掉，或者从总账中扣除

        // 1. 增加现金账户余额
        val oldCash = userCash.balance
        userCash = userCash.copy(balance = oldCash + order.estimatedPrice)

        // 2. 扣减对应的金属克数
        val oldGold = userMetal.goldBalance
        val oldSilver = userMetal.silverBalance
        if (order.metalType == MetalType.GOLD) {
            userMetal = userMetal.copy(goldBalance = (oldGold - order.weight).coerceAtLeast(0.0))
            
            // 如果指派了实物编号，把用户名下的金条状态改为 SOLD
            if (order.serialNumber != null) {
                val index = userGoldBars.indexOfFirst { it.serialNumber == order.serialNumber }
                if (index != -1) {
                    userGoldBars[index] = userGoldBars[index].copy(status = AssetStatus.SOLD)
                }
            }
        } else {
            userMetal = userMetal.copy(silverBalance = (oldSilver - order.weight).coerceAtLeast(0.0))
            if (order.serialNumber != null) {
                val index = userSilverBars.indexOfFirst { it.serialNumber == order.serialNumber }
                if (index != -1) {
                    userSilverBars[index] = userSilverBars[index].copy(status = AssetStatus.SOLD)
                }
            }
        }

        // 3. 记账
        ledgerHistory.add(
            LedgerEntry(
                transactionType = "官方回购结算 - ${order.itemType} 重量 ${order.weight}g",
                debitAccount = "客户资产-现金账户",
                creditAccount = "客户资产-实物托管${if (order.metalType == MetalType.GOLD) "金" else "银"}账户",
                amountCny = order.estimatedPrice,
                metalGrams = order.weight,
                metalType = order.metalType
            )
        )

        // 4. 增加今日回购销量
        cockpitTodayBuybackCny += order.estimatedPrice
        cockpitOrderCount += 1

        // 5. 写入合规审计
        auditHistory.add(
            AuditLogEntry(
                action = "回购清算记账完成",
                targetObject = order.orderId,
                oldState = "APPROVED",
                newState = "COMPLETED"
            )
        )

        return true
    }

    // 13. 执行以旧换新 (Exchange)
    @Synchronized
    fun executeDoubleEntryExchange(
        exchange: ExchangeOrder
    ): Boolean {
        val p = exchange.newProduct
        // 1. 扣减差额现金
        if (userCash.balance < exchange.cashDifference) return false
        val oldCash = userCash.balance
        userCash = userCash.copy(balance = oldCash - exchange.cashDifference)

        // 2. 扣减旧黄金克数，增加新黄金克数 (净增量 = 新克重 - 旧克重)
        val oldGold = userMetal.goldBalance
        val netAddGrams = p.weight - exchange.oldMetalWeight
        userMetal = userMetal.copy(goldBalance = oldGold + netAddGrams)

        // 3. 记账
        ledgerHistory.add(
            LedgerEntry(
                transactionType = "以旧换新 - 旧金(${exchange.oldMetalWeight}g) 换新(${p.name})",
                debitAccount = "客户资产-首饰投资账户 (增加 ${p.weight}g)",
                creditAccount = "旧金回收托收账户 (扣减 ${exchange.oldMetalWeight}g) & 现金差额 (${exchange.cashDifference}元)",
                amountCny = exchange.cashDifference,
                metalGrams = netAddGrams,
                metalType = MetalType.GOLD
            )
        )

        // 4. 写入审计
        auditHistory.add(
            AuditLogEntry(
                action = "以旧换新交割完成",
                targetObject = exchange.orderId,
                oldState = "CALCULATED",
                newState = "COMPLETED"
            )
        )

        return true
    }
}
