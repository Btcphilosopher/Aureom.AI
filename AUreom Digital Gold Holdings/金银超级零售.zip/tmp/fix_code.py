import re

def fix_file(path):
    print(f"Fixing {path}...")
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. Replace duplicate modifiers in Row/Column/Box
    # Pattern: modifier = Modifier.fillMaxWidth(),\s+horizontalArrangement = (.*?),\s+modifier = Modifier.padding\((.*?)\)
    # We will replace it with a chained modifier: modifier = Modifier.fillMaxWidth().padding(padding_params), horizontalArrangement = ...
    
    # Let's write a robust regex or replacement for specific duplicate modifier blocks we found:
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                                horizontalArrangement = Arrangement.SpaceBetween,\n                                                modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                                                horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                                horizontalArrangement = Arrangement.SpaceBetween,\n                                                modifier = Modifier.padding(bottom = 8.dp)',
        'modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),\n                                                horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                                horizontalArrangement = Arrangement.SpaceBetween,\n                                                modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                                                horizontalArrangement = Arrangement.SpaceBetween'
    )
    
    # General regex for: Row( modifier = Modifier..., horizontalArrangement = ..., modifier = Modifier... )
    # Let's write a regex that matches double modifiers and merges them
    # For example: Row(\n\s+modifier = Modifier.fillMaxWidth\(\),\n\s+horizontalArrangement = (.*?),\n\s+modifier = Modifier.padding\((.*?)\)\n\s+\)
    # But simpler, we can replace the exact lines:
    
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                        horizontalArrangement = Arrangement.SpaceBetween,\n                                        modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                                        horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                        horizontalArrangement = Arrangement.SpaceBetween,\n                                        modifier = Modifier.padding(bottom = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),\n                                        horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                        horizontalArrangement = Arrangement.SpaceBetween,\n                                        modifier = Modifier.padding(bottom = 8.dp)',
        'modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),\n                                        horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                            horizontalArrangement = Arrangement.SpaceBetween,\n                                            modifier = Modifier.padding(bottom = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),\n                                            horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                            horizontalArrangement = Arrangement.SpaceBetween,\n                                            modifier = Modifier.padding(bottom = 8.dp)',
        'modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),\n                                            horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                            horizontalArrangement = Arrangement.SpaceBetween,\n                                            modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                                            horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                            horizontalArrangement = Arrangement.SpaceBetween,\n                                            modifier = Modifier.padding(top = 8.dp)',
        'modifier = Modifier.fillMaxWidth().padding(top = 8.dp),\n                                            horizontalArrangement = Arrangement.SpaceBetween'
    )
    
    # In Screens.kt
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                horizontalArrangement = Arrangement.SpaceBetween,\n                modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                horizontalArrangement = Arrangement.SpaceBetween'
    )
    content = content.replace(
        'modifier = Modifier.fillMaxWidth(),\n                                horizontalArrangement = Arrangement.SpaceBetween,\n                                modifier = Modifier.padding(vertical = 4.dp)',
        'modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),\n                                horizontalArrangement = Arrangement.SpaceBetween'
    )

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

fix_file("app/src/main/java/com/example/DemoScreen.kt")
fix_file("app/src/main/java/com/example/Screens.kt")
print("Done!")
