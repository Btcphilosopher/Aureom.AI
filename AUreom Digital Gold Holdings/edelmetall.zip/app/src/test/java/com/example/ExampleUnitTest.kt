package com.example

import com.example.model.Bar
import com.example.model.BarStatus
import com.example.model.MetalType
import com.example.model.SimulationEngine
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode

class ExampleUnitTest {

    @Test
    fun testPreciousMetalsInvariants_GrossWeightToFineWeight() {
        // Critical Invariant: Gross Weight * (Fineness / 1000) = Fine Metal Weight
        val bar = Bar(
            serial = "DE-AU-9999-00048291",
            metal = MetalType.GOLD,
            fineness = 999.9,
            grossWeightG = 1000.12,
            fineWeightG = 1000.12 * (999.9 / 1000.0),
            refiner = "Heraeus Hanau",
            productionDate = "12.01.2026",
            certificateNo = "CERT-AU-1",
            warehouse = "Frankfurt",
            ownerId = "ORG-RHEIN-EM",
            status = BarStatus.AVAILABLE
        )

        val calculatedFineWeight = bar.grossWeightG * (bar.fineness / 1000.0)
        assertEquals(bar.fineWeightG, calculatedFineWeight, 0.00001)
    }

    @Test
    fun testTaxEngine_GermanVATExemptions() {
        // German UStG § 25c: Investment gold bars (fineness >= 995) are VAT exempt (0%)
        val investmentGoldFineness = 999.9
        val jewelryGoldFineness = 750.0

        val isGoldInvestmentExempt = investmentGoldFineness >= 995.0
        val isJewelryExempt = jewelryGoldFineness >= 995.0

        assertTrue("Investment gold >= 995 must be VAT exempt", isGoldInvestmentExempt)
        assertFalse("Jewellery (18K) gold is NOT VAT exempt", isJewelryExempt)
    }

    @Test
    fun testDoubleEntryLedger_DebitsEqualsCredits() {
        // Invariant: TOTAL DEBITS = TOTAL CREDITS
        val simEngine = SimulationEngine()
        simEngine.resetSimulation()

        val ledger = simEngine.doubleEntryLedger.value
        assertFalse("Ledger should not be empty", ledger.isEmpty())

        val totalDebits = ledger.sumOf { it.amountEur }
        val totalCredits = ledger.sumOf { it.amountEur }

        // Confirm mathematical balance
        assertEquals("Total Debits must equal Total Credits in double-entry bookkeeping", totalDebits, totalCredits, 0.001)
    }

    @Test
    fun testAI_AnsweringModelQuery() {
        val simEngine = SimulationEngine()
        simEngine.resetSimulation()

        // Test the AI Dispatcher on structured calculations
        val totalGoldKg = simEngine.bars.value.filter { it.metal == MetalType.GOLD }.sumOf { it.fineWeightG } / 1000.0
        val aiResponse = simEngine.askEdelmetallAI("Wie hoch ist unser Goldbestand?")
        
        // Assert that the AI answers with the EXACT live dynamic value
        assertTrue("AI response should contain actual gold balance", aiResponse.contains("${"%,.2f".format(totalGoldKg)} kg"))
    }
}
