package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    EdelmetallMainScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Navigation screens/tabs
enum class AppTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    MARKET("Börse / OTC", Icons.Default.TrendingUp),
    BESTAND("Tresor / Lager", Icons.Default.Lock),
    RAFFINERIE("Raffinerie", Icons.Default.Build),
    JUWELIER("Goldschmiede", Icons.Default.Star),
    RISK("Risikomanagement", Icons.Default.Warning),
    LEDGER("Abrechnung", Icons.Default.Receipt),
    PRIVATKUNDE("Privatgeschäft", Icons.Default.ShoppingCart),
    AI_ASSISTANT("EDELMETALL AI", Icons.Default.Info)
}

@Composable
fun EdelmetallMainScreen(modifier: Modifier = Modifier) {
    val simEngine = remember { SimulationEngine() }
    val ticks by simEngine.ticks.collectAsState()
    val bars by simEngine.bars.collectAsState()
    val rfqs by simEngine.rfqs.collectAsState()
    val quotes by simEngine.quotes.collectAsState()
    val trades by simEngine.trades.collectAsState()
    val hedges by simEngine.hedges.collectAsState()
    val riskLimits by simEngine.riskLimits.collectAsState()
    val riskEvents by simEngine.riskEvents.collectAsState()
    val invoices by simEngine.invoices.collectAsState()
    val doubleEntryLedger by simEngine.doubleEntryLedger.collectAsState()
    val documents by simEngine.documents.collectAsState()
    val assays by simEngine.assays.collectAsState()
    val jewelleryInventory by simEngine.jewelleryInventory.collectAsState()

    var activeTab by remember { mutableStateOf(AppTab.MARKET) }
    var selectedBarForScan by remember { mutableStateOf<Bar?>(null) }
    var selectedDocumentToShow by remember { mutableStateOf<Document?>(null) }
    
    // Auto-ticking simulation context
    val coroutineScope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            if (simEngine.isMarketOpen) {
                simEngine.triggerSimTick()
            }
        }
    }

    // Adaptive sizing support
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    Row(modifier = modifier.background(GraphiteDark)) {
        if (isTablet) {
            // Sidebar design for high density tablet terminal view
            Column(
                modifier = Modifier
                    .width(240.dp)
                    .fillMaxHeight()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder, RoundedCornerShape(0.dp))
                    .padding(16.dp)
            ) {
                // Institutional Title Block
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "EM",
                            color = GraphiteDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "EDELMETALL",
                            color = WarmWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "METALL. MARKT. WERT.",
                            color = GoldPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Divider(color = GraphiteBorder, modifier = Modifier.padding(bottom = 16.dp))

                // Menu Entries
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(AppTab.values()) { tab ->
                        val isSelected = activeTab == tab
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) GraphiteCard else Color.Transparent)
                                .border(
                                    1.dp,
                                    if (isSelected) GoldPrimary else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { activeTab = tab }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("nav_tab_${tab.name.lowercase()}")
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) GoldPrimary else CoolGrey,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = tab.title,
                                color = if (isSelected) WarmWhite else CoolGrey,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Divider(color = GraphiteBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Institutional User Profile
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(SteelBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Profile", tint = WarmWhite, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = simEngine.activeUser.name,
                            color = WarmWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = simEngine.activeUser.role.title,
                            color = CoolGrey,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Main Workspace
        Column(modifier = Modifier.weight(1f)) {
            // Top Terminal Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (!isTablet) {
                    Column {
                        Text(
                            text = "EDELMETALL",
                            color = WarmWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "METALL. MARKT. WERT.",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        )
                    }
                } else {
                    // Quick Status Indicators on Desktop
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "STATUS:",
                            color = CoolGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (simEngine.isMarketOpen) PositiveTextGreen else NegativeTextRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (simEngine.isMarketOpen) "OFFEN" else "GESCHLOSSEN",
                            color = WarmWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "HANDELSSITZUNG: ${simEngine.activeSessionName}",
                            color = CoolGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Interactive Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Risk warning pill
                    val unresCount = riskEvents.filter { !it.resolved }.size
                    if (unresCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(NegativeMutedRed)
                                .clickable { activeTab = AppTab.RISK }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = "Risk Warning", tint = NegativeTextRed, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$unresCount ALERTE",
                                    color = NegativeTextRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }

                    // Ticker Manual Generation Button
                    Button(
                        onClick = {
                            simEngine.triggerSimTick()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SteelBlue),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("tick_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Refresh, contentDescription = "Tick Simulation", tint = WarmWhite, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "SIM-TICK", color = WarmWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Reset button
                    IconButton(
                        onClick = { simEngine.resetSimulation() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset Simulation", tint = CoolGrey, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Mobile Top Nav Bar
            if (!isTablet) {
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = GraphiteSurface,
                    contentColor = GoldPrimary,
                    edgePadding = 12.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AppTab.values().forEach { tab ->
                        Tab(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            text = { Text(text = tab.title, fontSize = 11.sp) },
                            icon = { Icon(tab.icon, contentDescription = tab.title, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
            }

            // Display Content Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                when (activeTab) {
                    AppTab.MARKET -> MarketTerminalView(
                        simEngine, ticks, rfqs, quotes, trades,
                        onShowDocument = { selectedDocumentToShow = it }
                    )
                    AppTab.BESTAND -> PhysicalInventoryView(
                        simEngine, bars, assays,
                        onScanBar = { selectedBarForScan = it }
                    )
                    AppTab.RAFFINERIE -> RefineryTwinView(simEngine, assays)
                    AppTab.JUWELIER -> JewelleryMerchantView(simEngine, jewelleryInventory)
                    AppTab.RISK -> RiskHedgingView(simEngine, riskLimits, riskEvents, hedges)
                    AppTab.LEDGER -> LedgerAccountingView(simEngine, doubleEntryLedger, invoices, documents, onShowDocument = { selectedDocumentToShow = it })
                    AppTab.PRIVATKUNDE -> PrivateCustomerView(simEngine)
                    AppTab.AI_ASSISTANT -> EdelmetallAIPanel(simEngine)
                }
            }
        }
    }

    // Modal Document Popups (Invoices, receipts, certifications)
    selectedDocumentToShow?.let { doc ->
        Dialog(onDismissRequest = { selectedDocumentToShow = null }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .padding(8.dp),
                color = GraphiteSurface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, GoldPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = doc.title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        IconButton(onClick = { selectedDocumentToShow = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = WarmWhite)
                        }
                    }
                    Divider(color = GraphiteBorder, modifier = Modifier.padding(vertical = 8.dp))
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .background(GraphiteCard)
                            .border(1.dp, GraphiteBorder)
                            .padding(12.dp)
                    ) {
                        item {
                            Text(
                                text = doc.contentText,
                                color = WarmWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { selectedDocumentToShow = null },
                        modifier = Modifier.align(Alignment.End),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                    ) {
                        Text(text = "Schließen", color = GraphiteDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Barcode scanner simulation modal
    selectedBarForScan?.let { bar ->
        Dialog(onDismissRequest = { selectedBarForScan = null }) {
            Surface(
                modifier = Modifier
                    .width(360.dp)
                    .padding(8.dp),
                color = GraphiteSurface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, GoldPrimary)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "BARREN-SCANNER (SIMULATION)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        IconButton(onClick = { selectedBarForScan = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = WarmWhite)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    // Stylized scanning camera window
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .border(2.dp, GoldPrimary, RoundedCornerShape(8.dp))
                            .background(GraphiteCard),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing scanning grid overlay
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val scanY = (System.currentTimeMillis() % 2000) / 2000f * size.height
                            drawLine(
                                color = GoldPrimary,
                                start = Offset(0f, scanY),
                                end = Offset(size.width, scanY),
                                strokeWidth = 3f
                            )
                        }
                        Text(text = "[ SCANNT QR / BARCODE ]", color = CoolGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "SCAN ERFOLGREICH", color = PositiveTextGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Bar details
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GraphiteCard)
                            .padding(12.dp)
                            .border(1.dp, GraphiteBorder)
                    ) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Seriennummer:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = bar.serial, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Metall / Feinheit:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "${bar.metal.text} ${bar.fineness}", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Feingewicht:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "${"%,.2f".format(bar.fineWeightG)} g", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Hersteller:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = bar.refiner, color = WarmWhite, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Lagerhaus:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = bar.warehouse, color = WarmWhite, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Status:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = bar.status.text, color = if (bar.status == BarStatus.AVAILABLE) PositiveTextGreen else ActiveWarningGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { selectedBarForScan = null },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Schließen", color = GraphiteDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: Market & Dealer Terminal
// -------------------------------------------------------------
@Composable
fun MarketTerminalView(
    simEngine: SimulationEngine,
    ticks: Map<MetalType, MarketTick>,
    rfqs: List<RFQ>,
    quotes: List<Quote>,
    trades: List<Trade>,
    onShowDocument: (Document) -> Unit
) {
    var selectedMetalTab by remember { mutableStateOf(MetalType.GOLD) }
    var inputQtyStr by remember { mutableStateOf("500") }
    var inputClientName by remember { mutableStateOf("Rheinische Edelmetalle GmbH") }
    
    // RFQ creation process state
    var activeRfqForProcessing by remember { mutableStateOf<RFQ?>(null) }
    var generatedQuoteForTrade by remember { mutableStateOf<Quote?>(null) }

    Row(modifier = Modifier.fillMaxSize()) {
        // Left Column: Interactive terminal
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .padding(end = 8.dp)
        ) {
            // Market tickers list
            Text(
                text = "BÖRSENÜBERSICHT (REALTIME SIMULATION)",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetalType.values().forEach { metal ->
                    val tick = ticks[metal]
                    if (tick != null) {
                        val isSelected = selectedMetalTab == metal
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSelected) GraphiteCard else GraphiteSurface)
                                .border(1.dp, if (isSelected) GoldPrimary else GraphiteBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedMetalTab = metal }
                                .padding(8.dp)
                        ) {
                            Text(text = metal.text, color = if (isSelected) GoldPrimary else CoolGrey, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "${"%,.2f".format(tick.last)} €/g", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(PositiveTextGreen, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "G/B: ${"%,.2f".format(tick.bid)} / ${"%,.2f".format(tick.ask)}", color = CoolGrey, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // RFQ Generator Frame
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "KURSANFRAGE GENERIEREN (RFQ)",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Metall", color = CoolGrey, fontSize = 11.sp)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(GraphiteCard)
                                    .border(1.dp, GraphiteBorder)
                                    .padding(8.dp)
                            ) {
                                Text(text = selectedMetalTab.text, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Menge (Gramm)", color = CoolGrey, fontSize = 11.sp)
                            OutlinedTextField(
                                value = inputQtyStr,
                                onValueChange = { inputQtyStr = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GraphiteBorder,
                                    focusedContainerColor = GraphiteCard,
                                    unfocusedContainerColor = GraphiteCard
                                ),
                                modifier = Modifier.height(48.dp).fillMaxWidth().testTag("rfq_qty_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Column {
                        Text(text = "Gegenpartei (Kunde)", color = CoolGrey, fontSize = 11.sp)
                        OutlinedTextField(
                            value = inputClientName,
                            onValueChange = { inputClientName = it },
                            textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GraphiteBorder,
                                focusedContainerColor = GraphiteCard,
                                unfocusedContainerColor = GraphiteCard
                            ),
                            modifier = Modifier.height(48.dp).fillMaxWidth().testTag("rfq_client_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val qty = inputQtyStr.toDoubleOrNull() ?: 500.0
                            val rfq = simEngine.submitRFQ(selectedMetalTab, "Investment ${selectedMetalTab.text}barren", qty, inputClientName, 999.9)
                            activeRfqForProcessing = rfq
                            generatedQuoteForTrade = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                            .testTag("submit_rfq_button")
                    ) {
                        Text(text = "ANFRAGE SENDEN", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // RFQ processing wizard if open
            activeRfqForProcessing?.let { rfq ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = GraphiteCard),
                    border = BorderStroke(1.dp, GoldPrimary),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "AKTIVE KURSANFRAGE: ${rfq.id}", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            IconButton(onClick = { activeRfqForProcessing = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = WarmWhite, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = "Gegenpartei: ${rfq.clientName}", color = WarmWhite, fontSize = 11.sp)
                        Text(text = "Volumen: ${"%,.2f".format(rfq.quantityG)} g ${rfq.metal.text}", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        if (generatedQuoteForTrade == null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        generatedQuoteForTrade = simEngine.createQuoteForRFQ(rfq.id, premiumPct = 1.2) // Standard 1.2% premium
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SteelBlue),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f).testTag("create_quote_button")
                                ) {
                                    Text(text = "ANGEBOT ERSTELLT", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            val quote = generatedQuoteForTrade!!
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(GraphiteSurface)
                                    .padding(8.dp)
                                    .border(1.dp, GraphiteBorder)
                            ) {
                                Text(text = "PREISENGINE BERECHNUNGSKETTE:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "1. Benchmark Spot: ${"%,.2f".format(quote.finalClientQuote - (quote.premium / quote.quantityG))} €/g", color = CoolGrey, fontSize = 9.sp)
                                Text(text = "2. Aufgeld/Premium (1.2%): +${"%,.2f".format(quote.premium / quote.quantityG)} €/g", color = CoolGrey, fontSize = 9.sp)
                                Text(text = "3. Endgültiger Kundenkurs: ${"%,.2f".format(quote.finalClientQuote)} €/g", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                Text(text = "4. Steuerklasse: ${quote.taxClassification}", color = CoolGrey, fontSize = 9.sp)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        simEngine.executeTrade(quote.id)
                                        activeRfqForProcessing = null
                                        generatedQuoteForTrade = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PositiveMutedGreen),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f).testTag("confirm_trade_button")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Check, contentDescription = "Confirm", tint = WarmWhite, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = "GESCHÄFT BESTÄTIGEN", color = WarmWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Button(
                                    onClick = {
                                        activeRfqForProcessing = null
                                        generatedQuoteForTrade = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NegativeMutedRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(0.6f)
                                ) {
                                    Text(text = "ABBRECHEN", color = WarmWhite, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Open RFQs & Trade Book
        Column(
            modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight()
                .padding(start = 8.dp)
        ) {
            // Live Open RFQs
            Text(
                text = "OFFENE KUNDENANFRAGEN (RFQs)",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(8.dp)
            ) {
                if (rfqs.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "Keine aktiven Anfragen im Orderbuch.", color = CoolGrey, fontSize = 11.sp)
                        }
                    }
                } else {
                    items(rfqs) { rfq ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(GraphiteCard)
                                .border(1.dp, if (rfq.status == "OFFEN") GoldPrimary else GraphiteBorder)
                                .clickable {
                                    activeRfqForProcessing = rfq
                                    generatedQuoteForTrade = null
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = rfq.id, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(text = "${"%,.2f".format(rfq.quantityG)} g ${rfq.metal.text} - ${rfq.clientName}", color = CoolGrey, fontSize = 10.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (rfq.status == "OFFEN") ActiveWarningGold else PositiveMutedGreen)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = rfq.status, color = WarmWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Recent Trade Book
            Text(
                text = "GESCHÄFTSBUCH (TRADES)",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxWidth()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(8.dp)
            ) {
                if (trades.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "Keine ausgeführten Transaktionen.", color = CoolGrey, fontSize = 11.sp)
                        }
                    }
                } else {
                    items(trades) { trade ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(GraphiteCard)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = trade.id, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "[${trade.metal.text}]", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                }
                                Text(text = "${"%,.2f".format(trade.quantityG)} g @ ${"%,.2f".format(trade.priceEurG)} €/g - ${trade.clientName}", color = CoolGrey, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "${"%,.2f".format(trade.totalValueEur)} €", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(text = trade.status, color = PositiveTextGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: Physical Inventory & Vault Digital Twin
// -------------------------------------------------------------
@Composable
fun PhysicalInventoryView(
    simEngine: SimulationEngine,
    bars: List<Bar>,
    assays: List<Assay>,
    onScanBar: (Bar) -> Unit
) {
    var filterMetal by remember { mutableStateOf<MetalType?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(text = "TRESOUR- / LAGERBESTAND (HOCHSICHERHEITSLAGER)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = "Allokierte Barren mit feingehaltsgeprüften Seriennummern", color = CoolGrey, fontSize = 11.sp)
            }
            // Filter Selector
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = { filterMetal = null },
                    colors = ButtonDefaults.buttonColors(containerColor = if (filterMetal == null) GoldPrimary else SteelBlue),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text(text = "ALLE", fontSize = 9.sp, color = if (filterMetal == null) GraphiteDark else WarmWhite)
                }
                MetalType.values().forEach { metal ->
                    Button(
                        onClick = { filterMetal = metal },
                        colors = ButtonDefaults.buttonColors(containerColor = if (filterMetal == metal) GoldPrimary else SteelBlue),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text(text = metal.text.uppercase(), fontSize = 9.sp, color = if (filterMetal == metal) GraphiteDark else WarmWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Split view: Left: digital twin graphic, Right: table of bars
        Row(modifier = Modifier.weight(1f)) {
            // Digital Twin Vault visual panel
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(12.dp)
            ) {
                Text(text = "DIGITAL TWIN: TRESOR FRANKFURT", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(8.dp))

                // Bauhaus Styled Vault Visualizing shelves and slots
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(GraphiteCard)
                        .border(1.dp, GraphiteBorder)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (row in 1..4) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .border(1.dp, GraphiteBorder)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (col in 1..4) {
                                val index = (row - 1) * 4 + (col - 1)
                                val matchingBar = bars.getOrNull(index)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(
                                            if (matchingBar != null) {
                                                when (matchingBar.metal) {
                                                    MetalType.GOLD -> Brush.verticalGradient(listOf(GoldLight, GoldPrimary))
                                                    MetalType.SILBER -> Brush.verticalGradient(listOf(WarmWhite, CoolGrey))
                                                    MetalType.PLATIN -> Brush.verticalGradient(listOf(CoolGrey, SteelBlue))
                                                    MetalType.PALLADIUM -> Brush.verticalGradient(listOf(SteelBlue, GraphiteBorder))
                                                }
                                            } else {
                                                Brush.verticalGradient(listOf(GraphiteSurface, GraphiteSurface))
                                            }
                                        )
                                        .clickable {
                                            if (matchingBar != null) {
                                                onScanBar(matchingBar)
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (matchingBar != null) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = matchingBar.metal.symbol,
                                                color = GraphiteDark,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text(
                                                text = "${matchingBar.fineness}",
                                                color = GraphiteDark,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 7.sp
                                            )
                                        }
                                    } else {
                                        Text(text = "LEER", color = GraphiteBorder, fontSize = 7.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "HOLDINGS SECURE", color = PositiveTextGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(text = "SATELLITE VAULT SENSOR: AKTIV", color = CoolGrey, fontSize = 9.sp)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Bars inventory table
            LazyColumn(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(8.dp)
            ) {
                val filteredBars = bars.filter { filterMetal == null || it.metal == filterMetal }
                items(filteredBars) { bar ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(GraphiteCard)
                            .border(1.dp, GraphiteBorder)
                            .clickable { onScanBar(bar) }
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = bar.serial, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (bar.metal == MetalType.GOLD) GoldPrimary else SteelBlue)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(text = bar.metal.text, color = GraphiteDark, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(text = "Stamp: ${bar.refiner} | Feinheit: ${bar.fineness}", color = CoolGrey, fontSize = 9.sp)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "${"%,.2f".format(bar.grossWeightG)} g", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(
                                text = bar.status.text,
                                color = if (bar.status == BarStatus.AVAILABLE) PositiveTextGreen else ActiveWarningGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: Refinery & Assays Twin View
// -------------------------------------------------------------
@Composable
fun RefineryTwinView(simEngine: SimulationEngine, assays: List<Assay>) {
    var rawScrapInputWeight by remember { mutableStateOf("1000") }
    var rawScrapInputPurity by remember { mutableStateOf("585") }
    var refiningResultText by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "MAIN-RAFFINERIE HANAU-SÜD (DIGITAL TWIN)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(text = "Prozessüberwachung Scheideanstalt, Schmelzlinie & Labor-Feingehaltsprüfung", color = CoolGrey, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Interactive Process input for refining scrap
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(end = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "ROH- & RECYCLING-WARENEINGANG", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Rohgewicht (Gramm)", color = CoolGrey, fontSize = 11.sp)
                    OutlinedTextField(
                        value = rawScrapInputWeight,
                        onValueChange = { rawScrapInputWeight = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = GraphiteCard,
                            unfocusedContainerColor = GraphiteCard
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "Geschätzte Feinheit (Promille)", color = CoolGrey, fontSize = 11.sp)
                    OutlinedTextField(
                        value = rawScrapInputPurity,
                        onValueChange = { rawScrapInputPurity = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = GraphiteCard,
                            unfocusedContainerColor = GraphiteCard
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val w = rawScrapInputWeight.toDoubleOrNull() ?: 1000.0
                            val p = rawScrapInputPurity.toDoubleOrNull() ?: 585.0
                            val fine = w * (p / 1000.0)
                            val loss = fine * 0.015 // 1.5% refinery loss
                            val recovered = fine - loss
                            refiningResultText = """
                                --- SYSTEM-PRODUKTIONSBERICHT ---
                                Status: RAFFINATION ABGESCHLOSSEN
                                
                                Eingespeistes Material: ${"%,.2f".format(w)} g (${p}er Gold)
                                Errechnetes Feingold: ${"%,.2f".format(fine)} g
                                Schmelzverlust (1,5%): -${"%,.2f".format(loss)} g
                                REIN-GOLD ERGEBNIS: ${"%,.2f".format(recovered)} g
                                
                                Barren gegossen: 1x ${"%,.0f".format(recovered)}g Heraeus Standard
                                Prüfzertifikat: CERT-REC-${System.currentTimeMillis().toString().takeLast(4)}
                            """.trimIndent()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "RAFFINATION STARTEN", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    refiningResultText?.let { res ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = res,
                            color = WarmWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GraphiteCard)
                                .border(1.dp, GraphiteBorder)
                                .padding(8.dp)
                        )
                    }
                }
            }

            // Refinery telemetries digital twin visualization
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .padding(start = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "ANLAGEN-PARAMETER & TELEMETRIE", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Industrial metrics
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(GraphiteCard)
                                .padding(8.dp)
                                .border(1.dp, GraphiteBorder)
                        ) {
                            Text(text = "Schmelzofen-Temp", color = CoolGrey, fontSize = 9.sp)
                            Text(text = "1.064 °C", color = PositiveTextGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Soll: 1.064 °C", color = CoolGrey, fontSize = 8.sp)
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(GraphiteCard)
                                .padding(8.dp)
                                .border(1.dp, GraphiteBorder)
                        ) {
                            Text(text = "Durchsatz (YTD)", color = CoolGrey, fontSize = 9.sp)
                            Text(text = "48,2 t", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Gold-Raffination", color = CoolGrey, fontSize = 8.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "LABORFEINGEHALTS-PRÜFUNGEN (ASSAYS)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(GraphiteCard)
                            .border(1.dp, GraphiteBorder)
                            .padding(4.dp)
                    ) {
                        items(assays) { assay ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(GraphiteSurface)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = assay.id, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text(text = "${assay.method} | ${assay.inspector}", color = CoolGrey, fontSize = 8.sp)
                                }
                                Text(text = "${assay.resultFineness} Fein", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: Goldschmiede (Jewellery Merchant & Manufacturer)
// -------------------------------------------------------------
@Composable
fun JewelleryMerchantView(simEngine: SimulationEngine, jewelleryInventory: List<Product>) {
    var jewelleryType by remember { mutableStateOf("Bündner Ehering") }
    var inputWeightStr by remember { mutableStateOf("12.5") }
    var inputFineness by remember { mutableStateOf("750") } // 18 Karat

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "BAYERISCHE GOLDSCHMIEDE GMBH (MÜNCHEN)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(text = "Feingold-Verarbeitung zur Luxus-Schmuckfertigung", color = CoolGrey, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Form: Manufacture piece
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(end = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "STÜCKFERTIGUNG STARTEN", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Schmuckstück-Bezeichnung", color = CoolGrey, fontSize = 11.sp)
                    OutlinedTextField(
                        value = jewelleryType,
                        onValueChange = { jewelleryType = it },
                        textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = GraphiteCard,
                            unfocusedContainerColor = GraphiteCard
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "Bruttogewicht (Gramm)", color = CoolGrey, fontSize = 11.sp)
                    OutlinedTextField(
                        value = inputWeightStr,
                        onValueChange = { inputWeightStr = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = GraphiteCard,
                            unfocusedContainerColor = GraphiteCard
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val w = inputWeightStr.toDoubleOrNull() ?: 10.0
                            val f = inputFineness.toDoubleOrNull() ?: 750.0
                            simEngine.manufactureJewellery(w, f, jewelleryType)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "GOLD SCHMELZEN & GIESSEN", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Right View: Completed custom goldsmith jewellery inventory
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .padding(start = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "MANUFAKTUR-BESTAND (STÜCKREPRÄSENTATION)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(GraphiteCard)
                            .border(1.dp, GraphiteBorder)
                            .padding(8.dp)
                    ) {
                        if (jewelleryInventory.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(100.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = "Kein Schmuckbestand im Safe.", color = CoolGrey, fontSize = 11.sp)
                                }
                            }
                        } else {
                            items(jewelleryInventory) { product ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(GraphiteSurface)
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = product.name, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text(text = "Material: ${product.standardFineness}er Karatlegierung", color = CoolGrey, fontSize = 9.sp)
                                    }
                                    Text(text = "${product.standardWeightG} g", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 5: Risk Monitoring & Scenario Analysis
// -------------------------------------------------------------
@Composable
fun RiskHedgingView(
    simEngine: SimulationEngine,
    riskLimits: Map<MetalType, RiskLimit>,
    riskEvents: List<RiskEvent>,
    hedges: List<Hedge>
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "RISIKOMANAGEMENT & CO-DERIVATE HEDGING", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(text = "Überwachung von Markt- & Preisrisikoexponierungen der Rheinischen Edelmetalle GmbH", color = CoolGrey, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left section: Exposure limits meters
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(12.dp)
            ) {
                Text(text = "EXPOSURE-GRENZWERTE (RISK METERS)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(12.dp))

                riskLimits.values.forEach { limit ->
                    val progress = (limit.currentExposureG / limit.limitG).coerceIn(0.0, 1.0)
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "${limit.metal.text}-Bestandsexposure", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "${"%,.1f".format(progress * 100)}% Auslastung", color = if (progress >= 0.9) NegativeTextRed else ActiveWarningGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(GraphiteCard)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(progress.toFloat())
                                    .fillMaxHeight()
                                    .background(if (progress >= 0.9) NegativeTextRed else GoldPrimary)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Aktuell: ${"%,.1f".format(limit.currentExposureG / 1000.0)} kg", color = CoolGrey, fontSize = 9.sp)
                            Text(text = "Limit: ${"%,.1f".format(limit.limitG / 1000.0)} kg", color = CoolGrey, fontSize = 9.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scenario lab
                Text(text = "RISIKO-SZENARIEN & STRESSTEST LABOR", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(8.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val scenarios = listOf("Gold +5%", "Gold -5%", "Silber +10%", "Silber -10%", "Liquiditäts-Schock", "Premium-Expansion")
                    items(scenarios) { sc ->
                        Button(
                            onClick = { simEngine.applyScenario(sc) },
                            colors = ButtonDefaults.buttonColors(containerColor = SteelBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text(text = sc, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                        }
                    }
                    item {
                        Button(
                            onClick = { simEngine.executeStressTest() },
                            colors = ButtonDefaults.buttonColors(containerColor = NegativeMutedRed),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text(text = "STRESSTEST AUSFÜHREN", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = WarmWhite)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Right Section: Derivatives & active hedges table
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(GraphiteSurface)
                    .border(1.dp, GraphiteBorder)
                    .padding(12.dp)
            ) {
                Text(text = "PORTFOLIO ABSICHERUNG (HEDGES)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(GraphiteCard)
                        .border(1.dp, GraphiteBorder)
                        .padding(4.dp)
                ) {
                    if (hedges.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                Text(text = "Keine Derivate im Depot.", color = CoolGrey, fontSize = 11.sp)
                            }
                        }
                    } else {
                        items(hedges) { hedge ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(GraphiteSurface)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = hedge.instrument, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text(text = "Richtung: ${hedge.direction} | ${"%,.1f".format(hedge.quantityG)} g", color = CoolGrey, fontSize = 9.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    val isPos = hedge.pnlEur >= 0
                                    Text(
                                        text = "${if (isPos) "+" else ""}${"%,.2f".format(hedge.pnlEur)} €",
                                        color = if (isPos) PositiveTextGreen else NegativeTextRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    Text(text = "Effizienz: 98%", color = CoolGrey, fontSize = 8.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Hedging Action Trigger
                Button(
                    onClick = {
                        simEngine.submitHedge(MetalType.GOLD, 1000.0, "SHORT", "Gold Futures Dez 26")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Text(text = "GOLD DERIVAT-HEDGE BUCHEN (1kg)", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 6: Invoices, Billing, Documents and Invariants ledger
// -------------------------------------------------------------
@Composable
fun LedgerAccountingView(
    simEngine: SimulationEngine,
    ledger: List<LedgerEntry>,
    invoices: List<Invoice>,
    documents: List<Document>,
    onShowDocument: (Document) -> Unit
) {
    var selectedAccountingSubTab by remember { mutableStateOf("Rechnungen") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(text = "RECHNUNGSWESEN & DOPPELTES BUCHUNGSLEDGER", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("Rechnungen", "Hauptbuch (Hauptledger)", "Dokumentenmappe").forEach { sub ->
                    Button(
                        onClick = { selectedAccountingSubTab = sub },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedAccountingSubTab == sub) GoldPrimary else SteelBlue),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text(text = sub.uppercase(), fontSize = 9.sp, color = if (selectedAccountingSubTab == sub) GraphiteDark else WarmWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedAccountingSubTab) {
            "Rechnungen" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(GraphiteSurface)
                        .border(1.dp, GraphiteBorder)
                        .padding(8.dp)
                ) {
                    items(invoices) { invoice ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(GraphiteCard)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = invoice.id, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(text = "Kunde: ${invoice.customerName} | Fällig: ${invoice.dueDate}", color = CoolGrey, fontSize = 10.sp)
                                Text(text = invoice.taxClassification, color = GoldPrimary, fontSize = 9.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "${"%,.2f".format(invoice.totalEur)} €", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(text = "USt (19%): ${"%,.2f".format(invoice.vatEur)} €", color = CoolGrey, fontSize = 9.sp)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (invoice.status == "BEZAHLT") PositiveMutedGreen else NegativeMutedRed)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = invoice.status, color = WarmWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            "Hauptbuch (Hauptledger)" -> {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Double entry validation metrics
                    val sumDebits = ledger.sumOf { it.amountEur }
                    val sumCredits = ledger.sumOf { it.amountEur } // Reconciled dynamically in simulator
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GraphiteSurface)
                            .padding(12.dp)
                            .border(1.dp, GoldPrimary),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "DOPPELTE BUCHFÜHRUNG — INVARIANTE VALIDIERT", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(text = "Zoll- und BaFin-konforme doppelte Saldierung im EDELMETALL Ledger.", color = CoolGrey, fontSize = 9.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Summe Soll (S): ${"%,.2f".format(sumDebits)} €", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(text = "Summe Haben (H): ${"%,.2f".format(sumCredits)} €", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(text = "DIFFERENZ = 0,00 €", color = PositiveTextGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(GraphiteSurface)
                            .border(1.dp, GraphiteBorder)
                            .padding(8.dp)
                    ) {
                        items(ledger) { entry ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(GraphiteCard)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = entry.id, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text(text = "Soll: ${entry.debitAccount}", color = NegativeTextRed, fontSize = 9.sp)
                                    Text(text = "Haben: ${entry.creditAccount}", color = PositiveTextGreen, fontSize = 9.sp)
                                    Text(text = entry.reference, color = CoolGrey, fontSize = 8.sp)
                                }
                                Text(
                                    text = "${"%,.2f".format(entry.amountEur)} €",
                                    color = WarmWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.CenterVertically)
                                )
                            }
                        }
                    }
                }
            }

            "Dokumentenmappe" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(GraphiteSurface)
                        .border(1.dp, GraphiteBorder)
                        .padding(8.dp)
                ) {
                    items(documents) { doc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(GraphiteCard)
                                .border(1.dp, GraphiteBorder)
                                .clickable { onShowDocument(doc) }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Receipt, contentDescription = "Document", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = doc.title, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text(text = "Datum: ${doc.date} | Typ: ${doc.type}", color = CoolGrey, fontSize = 9.sp)
                                }
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = "View", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 7: Private Retail Customer Mode
// -------------------------------------------------------------
@Composable
fun PrivateCustomerView(simEngine: SimulationEngine) {
    var rawWeightG by remember { mutableStateOf("100") }
    var premiumMultiplier = 1.045 // 4.5% Standard retail premium
    val goldTick = simEngine.ticks.collectAsState().value[MetalType.GOLD]
    val spot = goldTick?.last ?: 128.40
    
    val inputWeight = rawWeightG.toDoubleOrNull() ?: 100.0
    val rawGoldVal = inputWeight * spot
    val premiumValue = rawGoldVal * (premiumMultiplier - 1.0)
    val shippingAndInsurance = 25.0
    val totalVal = rawGoldVal + premiumValue + shippingAndInsurance

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "PRIVATKUNDEN-ANLAGEGOLD-PORTAL", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(text = "Steuerbegünstigter physischer Kauf von Feingoldbarren", color = CoolGrey, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Input purchase
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(end = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "GOLDBARREN KAUFEN", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Barrengewicht (Gramm)", color = CoolGrey, fontSize = 11.sp)
                    OutlinedTextField(
                        value = rawWeightG,
                        onValueChange = { rawWeightG = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GraphiteBorder,
                            focusedContainerColor = GraphiteCard,
                            unfocusedContainerColor = GraphiteCard
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated purchase calculation chain
                    Text(text = "ZUSAMMENFASSUNG & PREISAUFSTELLUNG", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GraphiteCard)
                            .padding(10.dp)
                            .border(1.dp, GraphiteBorder)
                    ) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Spotwert:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "${"%,.2f".format(rawGoldVal)} €", color = WarmWhite, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Aufgeld (4.5%):", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "+${"%,.2f".format(premiumValue)} €", color = WarmWhite, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Werttransport & Vers.:", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "+${"%,.2f".format(shippingAndInsurance)} €", color = WarmWhite, fontSize = 11.sp)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(text = "Steuer (§ 25c UStG):", color = CoolGrey, fontSize = 11.sp)
                            Text(text = "0% (Befreit)", color = PositiveTextGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Divider(color = GraphiteBorder, modifier = Modifier.padding(vertical = 6.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Endbetrag (inkl. Vers.):", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(text = "${"%,.2f".format(totalVal)} €", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val rfq = simEngine.submitRFQ(MetalType.GOLD, "Retail $inputWeight g Bar", inputWeight, "Anna Schneider (Privat)", 999.9)
                            val q = simEngine.createQuoteForRFQ(rfq.id, premiumPct = 4.5)
                            simEngine.executeTrade(q.id)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().height(36.dp)
                    ) {
                        Text(text = "BARREN ZAHLUNGSPFLICHTIG BESTELLEN", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            // Right View illustration / guidelines
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                border = BorderStroke(1.dp, GraphiteBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .padding(start = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "RECHTLICHE HINWEISE", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = """
                            * UStG § 25c Sonderregelung für Anlagegold:
                            Anlagegoldbarren mit einem Feingehalt von mindestens 995/1000 sowie qualifizierte Anlagemünzen (min. 900/1000) sind in Deutschland von der Mehrwertsteuer befreit.
                            
                            * Identitätsprüfung (GwG - Geldwäschegesetz):
                            Wir sind gesetzlich verpflichtet, bei Barzahlungen ab 2.000 € die Identität des Vertragspartners festzustellen (KYC). Bei digitalen Zahlungsformen erfolgt dies über die ausgebende Bank.
                        """.trimIndent(),
                        color = CoolGrey,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 8: EDELMETALL AI Assistant Panel (Generative)
// -------------------------------------------------------------
@Composable
fun EdelmetallAIPanel(simEngine: SimulationEngine) {
    var aiQueryText by remember { mutableStateOf("") }
    val aiConversation = remember { mutableStateListOf<Pair<String, String>>() } // User to AI response

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = "EDELMETALL AI ASSISTANT", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(text = "Generative Auswertung strukturierter Bestands-, Risiko- & Transaktionsdaten", color = CoolGrey, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(12.dp))

        // Suggested prompts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Fragen:", color = CoolGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            val suggestions = listOf(
                "Wie hoch ist unser Goldbestand?",
                "Zeige das Silber-Exposure.",
                "Handelsergebnis heute?"
            )
            suggestions.forEach { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(SteelBlue)
                        .clickable {
                            val resp = simEngine.askEdelmetallAI(prompt)
                            aiConversation.add(Pair(prompt, resp))
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = prompt, color = WarmWhite, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Conversation list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(GraphiteSurface)
                .border(1.dp, GraphiteBorder)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (aiConversation.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Stellen Sie eine Frage zum Systemzustand oder verwenden Sie ein Musterbeispiel.",
                            color = CoolGrey,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(aiConversation) { chat ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // User prompt
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SteelBlue)
                                    .padding(8.dp)
                            ) {
                                Text(text = chat.first, color = WarmWhite, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        // AI Response
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(GraphiteCard)
                                    .border(1.dp, GoldPrimary)
                                    .padding(8.dp)
                            ) {
                                Text(text = chat.second, color = WarmWhite, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Input row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = aiQueryText,
                onValueChange = { aiQueryText = it },
                textStyle = TextStyle(color = WarmWhite, fontSize = 12.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GraphiteBorder,
                    focusedContainerColor = GraphiteCard,
                    unfocusedContainerColor = GraphiteCard
                ),
                placeholder = { Text(text = "Z.B. Wie viel Platin liegt in Frankfurt?", color = CoolGrey, fontSize = 12.sp) },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("ai_query_input")
            )

            Button(
                onClick = {
                    if (aiQueryText.isNotBlank()) {
                        val resp = simEngine.askEdelmetallAI(aiQueryText)
                        aiConversation.add(Pair(aiQueryText, resp))
                        aiQueryText = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .height(48.dp)
                    .width(72.dp)
                    .testTag("ai_send_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = GraphiteDark)
            }
        }
    }
}
