package com.example.model

enum class RBACRole(val title: String) {
    ADMINISTRATOR("Administrator"),
    HAENDLER("Händler"),
    TRADER("Trader"),
    SALES("Sales"),
    KEY_ACCOUNT_MANAGER("Key Account Manager"),
    RISK_MANAGER("Risk Manager"),
    CFO("CFO"),
    ACCOUNTING("Accounting"),
    OPERATIONS("Operations"),
    WAREHOUSE_MANAGER("Warehouse Manager"),
    VAULT_MANAGER("Vault Manager"),
    ASSAY_MANAGER("Assay Manager"),
    COMPLIANCE("Compliance"),
    AUDITOR("Auditor"),
    CORPORATE_CUSTOMER("Corporate Customer"),
    PRIVATE_CUSTOMER("Private Customer"),
    JEWELLER("Jeweller")
}

enum class CustomerType {
    PRIVATE, CORPORATE, INSTITUTIONAL, JEWELLER, INDUSTRY, REFINER
}

enum class MetalType(val symbol: String, val text: String) {
    GOLD("Au", "Gold"),
    SILBER("Ag", "Silber"),
    PLATIN("Pt", "Platin"),
    PALLADIUM("Pd", "Palladium")
}

enum class BarStatus(val text: String) {
    AVAILABLE("Verfügbar"),
    RESERVED("Reserviert"),
    ALLOCATED("Zugeordnet"),
    IN_TRANSIT("Unterwegs"),
    IN_ASSAY("In Prüfung"),
    IN_REFINING("In Raffination")
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: RBACRole
)

data class Customer(
    val id: String,
    val name: String,
    val organisationId: String,
    val type: CustomerType,
    val creditLimitEur: Double,
    val creditUsedEur: Double
)

data class Organisation(
    val id: String,
    val name: String,
    val city: String,
    val type: String
)

data class Merchant(
    val id: String,
    val name: String,
    val city: String
)

data class Account(
    val id: String,
    val name: String,
    val type: String
)

data class LedgerAccount(
    val id: String,
    val name: String,
    val type: String, // Debit, Credit
    val balanceEur: Double
)

data class LedgerEntry(
    val id: String,
    val debitAccount: String,
    val creditAccount: String,
    val amountEur: Double,
    val currency: String,
    val tradeId: String?,
    val counterparty: String,
    val timestamp: Long,
    val reference: String
)

data class Metal(
    val type: MetalType,
    val symbol: String,
    val atomicNumber: Int
)

data class Product(
    val id: String,
    val name: String,
    val metal: MetalType,
    val isPhysical: Boolean,
    val isInvestmentGold: Boolean,
    val standardFineness: Double,
    val standardWeightG: Double,
    val form: String // Barren, Münze, Schmuck, Industrie, Recycling
)

data class Bar(
    val serial: String,
    val metal: MetalType,
    val fineness: Double, // e.g. 999.9
    val grossWeightG: Double,
    val fineWeightG: Double, // Calculated (gross * fineness / 1000)
    val refiner: String,
    val productionDate: String,
    val certificateNo: String,
    val warehouse: String,
    val ownerId: String,
    val status: BarStatus
)

data class Assay(
    val id: String,
    val sampleId: String,
    val method: String, // XRF, Fire Assay, Density, Lab
    val inspector: String,
    val resultFineness: Double,
    val timestamp: Long,
    val certificateNo: String,
    val status: String // WARENEINGANG, PROBENAHME, ANALYSE, FREIGABE, ZERTIFIKAT, BESTAND
)

data class Certificate(
    val no: String,
    val issuer: String,
    val date: String,
    val purity: Double,
    val weightG: Double
)

data class InventoryLot(
    val id: String,
    val metal: MetalType,
    val qtyKg: Double,
    val category: String // Verfügbar, Reserviert, Zugeordnet, Unterwegs, In Prüfung, In Raffination
)

data class Warehouse(
    val id: String,
    val name: String,
    val city: String
)

data class Vault(
    val id: String,
    val location: String,
    val totalHoldingsKg: Map<MetalType, Double>,
    val allocatedKg: Map<MetalType, Double>,
    val unallocatedKg: Map<MetalType, Double>,
    val reservedKg: Map<MetalType, Double>,
    val incomingKg: Map<MetalType, Double>,
    val outgoingKg: Map<MetalType, Double>,
    val securityStatus: String,
    val insuranceValueEur: Double
)

data class CustodyRecord(
    val id: String,
    val ownerId: String,
    val ownerName: String,
    val custodian: String,
    val location: String,
    val barSerial: String,
    val weightG: Double,
    val fineness: Double,
    val valueEur: Double,
    val timestamp: Long
)

data class InventoryMovement(
    val id: String,
    val barSerial: String?,
    val metal: MetalType,
    val quantityG: Double,
    val fromLocation: String,
    val toLocation: String,
    val ownerId: String,
    val tradeId: String?,
    val status: String, // ERSTELLT, UNTERWEGS, EINGETROFFEN, GEPRÜFT, ABGESCHLOSSEN
    val timestamp: Long
)

data class MarketTick(
    val id: String,
    val metal: MetalType,
    val bid: Double, // EUR/g
    val ask: Double, // EUR/g
    val last: Double, // EUR/g
    val spread: Double, // bid - ask
    val volume: Double,
    val openInterest: Double,
    val high: Double,
    val low: Double,
    val prevSettlement: Double,
    val referencePrice: Double,
    val timestamp: Long
)

data class ReferencePrice(
    val metal: MetalType,
    val priceEurG: Double,
    val source: String, // "LBMA", "Deutsche Börse", "Mittelstand Standard"
    val timestamp: Long
)

data class FXRate(
    val pair: String, // EUR/USD
    val rate: Double,
    val timestamp: Long
)

data class Quote(
    val id: String,
    val rfqId: String,
    val metal: MetalType,
    val quantityG: Double,
    val bid: Double,
    val ask: Double,
    val finalClientQuote: Double,
    val premium: Double,
    val spread: Double,
    val taxClassification: String,
    val validUntil: Long
)

data class RFQ(
    val id: String,
    val metal: MetalType,
    val product: String,
    val purity: Double,
    val quantityG: Double,
    val clientName: String,
    val deliveryPlace: String,
    val deliveryDate: String,
    val paymentTerm: String,
    val status: String, // OFFEN, ANGEBOT_ERSTELLT, AKZEPTIERT, ABGELEHNT, ABGELAUFEN
    val date: String
)

data class Order(
    val id: String,
    val rfqId: String?,
    val customerId: String,
    val clientName: String,
    val metal: MetalType,
    val quantityG: Double,
    val priceEurG: Double,
    val orderType: String, // Spot, Limit, Physical, Security
    val status: String // PENDING, FILLED, CANCELLED
)

data class Trade(
    val id: String,
    val orderId: String?,
    val rfqId: String?,
    val metal: MetalType,
    val quantityG: Double,
    val priceEurG: Double,
    val totalValueEur: Double,
    val premiumEur: Double,
    val clientName: String,
    val timestamp: Long,
    val status: String // RECONCILED, PENDING_SETTLEMENT, COMPLETED
)

data class Position(
    val metal: MetalType,
    val quantityG: Double,
    val avgCostEurG: Double,
    val marketValueEur: Double,
    val realisedPnlEur: Double,
    val unrealisedPnlEur: Double
)

data class Hedge(
    val id: String,
    val instrument: String, // "Gold Futures Dec 26", etc.
    val metal: MetalType,
    val quantityG: Double,
    val entryPriceEurG: Double,
    val currentPriceEurG: Double,
    val direction: String, // LONG, SHORT
    val pnlEur: Double,
    val effectiveness: Double
)

data class RiskLimit(
    val metal: MetalType,
    val limitG: Double,
    val currentExposureG: Double,
    val thresholdWarningG: Double
)

data class RiskEvent(
    val id: String,
    val type: String, // PRICE_LIMIT, EXPOSURE_BREACH, SETTLEMENT_DELAY, CUSTOMER_CREDIT
    val severity: String, // INFO, WARNUNG, KRITISCH
    val description: String,
    val timestamp: Long,
    val resolved: Boolean
)

data class Invoice(
    val id: String,
    val tradeId: String,
    val customerName: String,
    val metal: MetalType,
    val weightG: Double,
    val amountEur: Double,
    val vatEur: Double,
    val totalEur: Double,
    val taxClassification: String,
    val date: String,
    val dueDate: String,
    val status: String // OFFEN, IN_BEARBEITUNG, BEZAHLT, STORNIERT
)

data class Payment(
    val id: String,
    val invoiceId: String,
    val counterparty: String,
    val amountEur: Double,
    val currency: String,
    val method: String, // Banküberweisung, Corporate Payment
    val reference: String,
    val status: String, // ERFOLGREICH, AUSSTEHEND, FEHLER
    val timestamp: Long
)

data class Settlement(
    val id: String,
    val tradeId: String,
    val status: String, // OFFEN, IN_BEARBEITUNG, ABGERECHNET, FEHLER
    val invoiceId: String?,
    val paymentId: String?,
    val deliveryId: String?,
    val date: String
)

data class Delivery(
    val id: String,
    val tradeId: String,
    val customerId: String,
    val customerName: String,
    val metal: MetalType,
    val quantityG: Double,
    val barSerials: List<String>,
    val fromLocation: String,
    val toLocation: String,
    val status: String, // ERSTELLT, RESERVIERT, KOMMISSIONIERUNG, VERSENDET, UNTERWEGS, EINGETROFFEN, GEPRÜFT, ABGESCHLOSSEN
    val date: String
)

data class Portfolio(
    val id: String,
    val clientName: String,
    val positions: Map<MetalType, Position>
)

data class PnlRecord(
    val id: String,
    val category: String, // Handel, Bestand, Spread, Premium, FX, Raffination, Retail
    val amountEur: Double,
    val timestamp: Long,
    val description: String
)

data class TaxClassification(
    val id: String,
    val label: String,
    val rulesSummary: String
)

data class TaxRule(
    val id: String,
    val label: String,
    val vatRate: Double,
    val minPurity: Double, // e.g. 995 for investment gold bars
    val form: String, // Bar, Coin, Jewellery, Industry
    val metal: MetalType,
    val isExempt: Boolean
)

data class RegulatoryRule(
    val id: String,
    val authority: String, // BaFin, GwG, UStG, GoBD
    val code: String,
    val title: String,
    val scope: String
)

data class Document(
    val id: String,
    val title: String,
    val type: String, // Angebot, Kursbestätigung, Auftragsbestätigung, Rechnung, Gutschrift, Lieferschein, Zertifikat, Bericht
    val date: String,
    val contentText: String
)

data class AuditEvent(
    val id: String,
    val action: String,
    val details: String,
    val actor: String,
    val timestamp: Long,
    val ipAddress: String
)
