package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val EdelmetallColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = GraphiteDark,
    primaryContainer = GoldDark,
    onPrimaryContainer = WarmWhite,
    secondary = CoolGrey,
    onSecondary = WarmWhite,
    secondaryContainer = GraphiteSurface,
    onSecondaryContainer = WarmWhite,
    background = GraphiteDark,
    onBackground = WarmWhite,
    surface = GraphiteSurface,
    onSurface = WarmWhite,
    surfaceVariant = GraphiteCard,
    onSurfaceVariant = WarmWhite,
    outline = GraphiteBorder,
    error = NegativeTextRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark mode as standard for the financial terminal Look
    dynamicColor: Boolean = false, // Keep branding colors clean and unified
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EdelmetallColorScheme,
        typography = Typography,
        content = content
    )
}
