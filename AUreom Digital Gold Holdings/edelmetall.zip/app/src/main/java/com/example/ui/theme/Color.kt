package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// EDELMETALL Premium Corporate Color Palette
val GoldPrimary = Color(0xFFC5A059)     // Restrained brushed gold
val GoldDark = Color(0xFF9E7E3F)        // Deep warm gold
val GoldLight = Color(0xFFE5D1A4)       // Brushed bright gold

val GraphiteDark = Color(0xFF0A0D14)    // Bauhaus dark background
val GraphiteSurface = Color(0xFF121620) // Slate/steel dark container surface
val GraphiteCard = Color(0xFF1A1F2D)    // High density table and card background
val GraphiteBorder = Color(0xFF283144)  // Metal edge drawing line

val SteelBlue = Color(0xFF4A5568)       // Cool industrial steel grey
val CoolGrey = Color(0xFF8A94A6)        // Secondary technical metadata
val WarmWhite = Color(0xFFF7FAFC)       // Clean high-contrast typography

// Status Colors
val PositiveMutedGreen = Color(0xFF1E4620) // Deep bank green
val PositiveTextGreen = Color(0xFF4ADE80)  // Active positive rate
val NegativeMutedRed = Color(0xFF5A1919)   // Muted risk warning background
val NegativeTextRed = Color(0xFFF87171)    // Active risk rate
val ActiveWarningGold = Color(0xFFD97706)  // Attention / Exposure threshold
