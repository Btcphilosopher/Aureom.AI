package com.example.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SimulationEngine {

    // Initial constants
    private val standardDateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.GERMANY)
    private val docDateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)

    // In-memory application states wrapped in StateFlows for Jetpack Compose reactivity
    private val _ticks = MutableStateFlow<Map<MetalType, MarketTick>>(emptyMap())
    val ticks: StateFlow<Map<MetalType, MarketTick>> = _ticks.asStateFlow()

    private val _fxRate = MutableStateFlow(FXRate("EUR/USD", 1.0850, System.currentTimeMillis()))
    val fxRate: StateFlow<FXRate> = _fxRate.asStateFlow()

    private val _bars = MutableStateFlow<List<Bar>>(emptyList())
    val bars: StateFlow<List<Bar>> = _bars.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RFQ>>(emptyList())
    val rfqs: StateFlow<List<RFQ>> = _rfqs.asStateFlow()

    private val _quotes = MutableStateFlow<List<Quote>>(emptyList())
    val quotes: StateFlow<List<Quote>> = _quotes.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _hedges = MutableStateFlow<List<Hedge>>(emptyList())
    val hedges: StateFlow<List<Hedge>> = _hedges.asStateFlow()

    private val _riskLimits = MutableStateFlow<Map<MetalType, RiskLimit>>(emptyMap())
    val riskLimits: StateFlow<Map<MetalType, RiskLimit>> = _riskLimits.asStateFlow()

    private val _riskEvents = MutableStateFlow<List<RiskEvent>>(emptyList())
    val riskEvents: StateFlow<List<RiskEvent>> = _riskEvents.asStateFlow()

    private val _invoices = MutableStateFlow<List<Invoice>>(emptyList())
    val invoices: StateFlow<List<Invoice>> = _invoices.asStateFlow()

    private val _payments = MutableStateFlow<List<Payment>>(emptyList())
    val payments: StateFlow<List<Payment>> = _payments.asStateFlow()

    private val _deliveries = MutableStateFlow<List<Delivery>>(emptyList())
    val deliveries: StateFlow<List<Delivery>> = _deliveries.asStateFlow()

    private val _settlements = MutableStateFlow<List<Settlement>>(emptyList())
    val settlements: StateFlow<List<Settlement>> = _settlements.asStateFlow()

    private val _doubleEntryLedger = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val doubleEntryLedger: StateFlow<List<LedgerEntry>> = _doubleEntryLedger.asStateFlow()

    private val _pnlRecords = MutableStateFlow<List<PnlRecord>>(emptyList())
    val pnlRecords: StateFlow<List<PnlRecord>> = _pnlRecords.asStateFlow()

    private val _documents = MutableStateFlow<List<Document>>(emptyList())
    val documents: StateFlow<List<Document>> = _documents.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    private val _assays = MutableStateFlow<List<Assay>>(emptyList())
    val assays: StateFlow<List<Assay>> = _assays.asStateFlow()

    // Jewelry Manufacturer & Shop data (München Demonstration)
    private val _jewelleryInventory = MutableStateFlow<List<Product>>(emptyList())
    val jewelleryInventory: StateFlow<List<Product>> = _jewelleryInventory.asStateFlow()

    // Active User
    var activeUser = User("USR-001", "Dr. Christian Weber", "c.weber@edelmetall.de", RBACRole.HAENDLER)

    // Simulated market session properties
    var isMarketOpen = true
    var activeSessionName = "Hauptsession (XETRA)"

    init {
        resetSimulation(seed = 42)
    }

    fun resetSimulation(seed: Int = 42) {
        // Clear all state lists
        _ticks.value = emptyMap()
        _bars.value = emptyList()
        _rfqs.value = emptyList()
        _quotes.value = emptyList()
        _trades.value = emptyList()
        _hedges.value = emptyList()
        _riskLimits.value = emptyMap()
        _riskEvents.value = emptyList()
        _invoices.value = emptyList()
        _payments.value = emptyList()
        _deliveries.value = emptyList()
        _settlements.value = emptyList()
        _doubleEntryLedger.value = emptyList()
        _pnlRecords.value = emptyList()
        _documents.value = emptyList()
        _auditEvents.value = emptyList()
        _assays.value = emptyList()

        // 1. Setup deterministic market prices (EUR per gram)
        // Gold: Spot ~128.40 €, Silber ~1.48 €, Platin ~52.70 €, Palladium ~39.80 €
        val now = System.currentTimeMillis()
        val initialTicks = mapOf(
            MetalType.GOLD to MarketTick("T-AU-001", MetalType.GOLD, 128.25, 128.55, 128.40, 0.30, 1850000.0, 4500.0, 129.10, 127.80, 127.92, 128.40, now),
            MetalType.SILBER to MarketTick("T-AG-001", MetalType.SILBER, 1.46, 1.50, 1.48, 0.04, 820000.0, 12100.0, 1.52, 1.45, 1.49, 1.48, now),
            MetalType.PLATIN to MarketTick("T-PT-001", MetalType.PLATIN, 52.40, 53.00, 52.70, 0.60, 410000.0, 2400.0, 53.20, 52.10, 52.60, 52.70, now),
            MetalType.PALLADIUM to MarketTick("T-PD-001", MetalType.PALLADIUM, 39.50, 40.10, 39.80, 0.60, 230000.0, 1800.0, 40.40, 39.20, 40.00, 39.80, now)
        )
        _ticks.value = initialTicks

        // 2. Setup Initial Inventory (bars matching Section 66 "Rheinische Edelmetalle GmbH")
        // Gold: 2,500 kg, Silver: 15,000 kg, Platinum: 500 kg, Palladium: 750 kg
        val initialBars = mutableListOf<Bar>()
        
        // Add representative bars
        // Large bars
        for (i in 1..10) {
            val grossAu = 1000.12
            initialBars.add(Bar("DE-AU-9999-000482${90 + i}", MetalType.GOLD, 999.9, grossAu, grossAu * 0.9999, "Heraeus Hanau", "12.01.2026", "CERT-AU-${100 + i}", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.AVAILABLE))
        }
        for (i in 1..10) {
            val grossAg = 15000.0 // 15kg
            initialBars.add(Bar("DE-AG-9990-000122${90 + i}", MetalType.SILBER, 999.0, grossAg, grossAg * 0.999, "Umicore", "15.02.2026", "CERT-AG-${200 + i}", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.AVAILABLE))
        }
        for (i in 1..5) {
            val grossPt = 1000.0
            initialBars.add(Bar("DE-PT-9995-000032${90 + i}", MetalType.PLATIN, 999.5, grossPt, grossPt * 0.9995, "Valcambi", "02.03.2026", "CERT-PT-${300 + i}", "Stuttgart Tresor", "ORG-RHEIN-EM", BarStatus.AVAILABLE))
        }
        for (i in 1..5) {
            val grossPd = 1000.0
            initialBars.add(Bar("DE-PD-9995-000072${90 + i}", MetalType.PALLADIUM, 999.5, grossPd, grossPd * 0.9995, "Argor-Heraeus", "10.03.2026", "CERT-PD-${400 + i}", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.AVAILABLE))
        }

        // Add pre-allocated/reserved bars
        initialBars.add(Bar("DE-AU-9999-00048201", MetalType.GOLD, 999.9, 1000.12, 1000.0, "Heraeus Hanau", "12.01.2026", "CERT-AU-201", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.RESERVED))
        initialBars.add(Bar("DE-AU-9999-00048202", MetalType.GOLD, 999.9, 500.0, 499.95, "Heraeus Hanau", "18.01.2026", "CERT-AU-202", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.ALLOCATED))

        _bars.value = initialBars

        // 3. Setup risk limits
        _riskLimits.value = mapOf(
            MetalType.GOLD to RiskLimit(MetalType.GOLD, 9000000.0, 8420000.0, 8100000.0), // ~8.42bn € limit / exposure check
            MetalType.SILBER to RiskLimit(MetalType.SILBER, 25000000.0, 15000000.0, 22000000.0),
            MetalType.PLATIN to RiskLimit(MetalType.PLATIN, 3000000.0, 500000.0, 2500000.0),
            MetalType.PALLADIUM to RiskLimit(MetalType.PALLADIUM, 2500000.0, 750000.0, 2200000.0)
        )

        // 4. Generate Pre-configured Demonstration Transactions
        generatePreconfiguredDemos()

        // 5. Generate double-entry ledger matching entries
        reconcileDoubleEntryLedger()

        logAudit("SIM_INITIALIZATION", "Simulation erfolgreich gestartet. Seed: $seed. Deutsche Standard-Märkte aktiv.", "System")
    }

    private fun generatePreconfiguredDemos() {
        val now = System.currentTimeMillis()
        val nowStr = docDateFormat.format(Date(now))
        val dueStr = docDateFormat.format(Date(now + 86400000L * 14)) // 14 days due

        // --- DEMONSTRATION A: 100g Investment Gold Bar ---
        // Exchanged under § 25c UStG (VAT exempt)
        val tradeAId = "TR-DE-2026-A100"
        val invoiceAId = "RE-2026-0001"
        val rfqAId = "RFQ-DE-2026-001"
        val barA = Bar("DE-AU-9999-DEMO-A", MetalType.GOLD, 999.9, 100.0, 99.99, "Heraeus Hanau", "10.08.2026", "CERT-AU-DEMO-A", "Frankfurt Hochsicherheitslager", "KUNDE-A", BarStatus.ALLOCATED)
        
        _bars.value = _bars.value + barA

        val rfqA = RFQ(rfqAId, MetalType.GOLD, "100g Goldbarren (Investment)", 999.9, 100.0, "Dr. Christian Weber (Family Office)", "Frankfurt", nowStr, "Zahlung bei Lieferung", "AKZEPTIERT", nowStr)
        val quoteA = Quote("Q-DE-2026-A", rfqAId, MetalType.GOLD, 100.0, 128.40, 128.80, 128.50, 0.85, 0.30, "Steuerbefreit (§ 25c UStG)", now + 60000L)
        val tradeA = Trade(tradeAId, null, rfqAId, MetalType.GOLD, 100.0, 128.50, 12850.0, 85.0, "Dr. Christian Weber (Family Office)", now, "COMPLETED")
        val invoiceA = Invoice(invoiceAId, tradeAId, "Dr. Christian Weber (Family Office)", MetalType.GOLD, 100.0, 12850.0, 0.0, 12850.0, "Anlagegold nach § 25c UStG (steuerfrei)", nowStr, dueStr, "BEZAHLT")
        val payA = Payment("P-DE-2026-A", invoiceAId, "Dr. Christian Weber (Family Office)", 12850.0, "EUR", "Banküberweisung", "Ausgleich RE-2026-0001", "ERFOLGREICH", now)
        val delA = Delivery("DEL-2026-A", tradeAId, "KUNDE-A", "Dr. Christian Weber (Family Office)", MetalType.GOLD, 100.0, listOf("DE-AU-9999-DEMO-A"), "Frankfurt", "Privatresidenz Frankfurt", "ABGESCHLOSSEN", nowStr)
        val setA = Settlement("SET-2026-A", tradeAId, "ABGERECHNET", invoiceAId, "P-DE-2026-A", "DEL-2026-A", nowStr)

        _rfqs.value = _rfqs.value + rfqA
        _quotes.value = _quotes.value + quoteA
        _trades.value = _trades.value + tradeA
        _invoices.value = _invoices.value + invoiceA
        _payments.value = _payments.value + payA
        _deliveries.value = _deliveries.value + delA
        _settlements.value = _settlements.value + setA

        // Create PDF/Text Document A
        val docA = Document(
            "DOC-RE-2026-0001",
            "Abrechnungsbeleg & Rechnung - $tradeAId",
            "Invoice",
            nowStr,
            """
            ========================================================================
                                     E D E L M E T A L L
                                   METALL. MARKT. WERT.
            ========================================================================
            Rheinische Edelmetalle GmbH | Kaiserstraße 10 | 60311 Frankfurt am Main
            
            An:
            Dr. Christian Weber (Family Office)
            Taunusanlage 12
            60325 Frankfurt am Main
            
            RECHNUNG NR: $invoiceAId
            Datum: $nowStr
            Fälligkeit: $dueStr
            Geschäft-Referenz: $tradeAId
            
            ------------------------------------------------------------------------
            Pos  Beschreibung                      Feinheit  Menge     Einzelpreis  Gesamt (EUR)
            ------------------------------------------------------------------------
            1    Feingoldbarren (gegossen)         999,9     100,00 g  128,50 €/g   12.850,00 €
                 Seriennummer: DE-AU-9999-DEMO-A
                 Zertifikat: CERT-AU-DEMO-A
                 Hersteller: Heraeus Hanau
            ------------------------------------------------------------------------
            Netto-Betrag:                                                       12.850,00 €
            Umsatzsteuer (0% / § 25c UStG)*:                                         0,00 €
            ------------------------------------------------------------------------
            RECHNUNGSENDBETRAG:                                                 12.850,00 €
            ------------------------------------------------------------------------
            * Steuerbefreit: Die Lieferung von Anlagegold ist nach § 25c UStG 
              von der Umsatzsteuer befreit.
            
            Zahlungsstatus: BEZAHLT (Überweisung eingegangen am $nowStr)
            Lieferung: Physisch übergeben (Vollversicherter Werttransport)
            ========================================================================
            Vielen Dank für Ihr Vertrauen in EDELMETALL.
            """.trimIndent()
        )
        _documents.value = _documents.value + docA


        // --- DEMONSTRATION B: Gold Jewellery Manufacturing ---
        // 19% VAT standard, break down metal component vs manufacturing components
        val tradeBId = "TR-DE-2026-B200"
        val invoiceBId = "RE-2026-0002"
        val rfqBId = "RFQ-DE-2026-002"
        
        val rfqB = RFQ(rfqBId, MetalType.GOLD, "18K Goldringe (Handgefertigt)", 750.0, 500.0, "Bayerische Goldschmiede GmbH", "München", nowStr, "30 Tage Netto", "AKZEPTIERT", nowStr)
        val quoteB = Quote("Q-DE-2026-B", rfqBId, MetalType.GOLD, 500.0, 96.30, 96.90, 96.50, 15.0, 0.60, "Standardumsatzsteuer (19% UStG)", now + 60000L)
        val tradeB = Trade(tradeBId, null, rfqBId, MetalType.GOLD, 500.0, 96.50, 48250.0, 7500.0, "Bayerische Goldschmiede GmbH", now, "COMPLETED")
        
        // Value calculations for jewellery breakdown:
        // Metal content: 500g gross * 0.75 fineness = 375g fine. 375g * 128.40 = 48,150 EUR.
        // Manufacturing cost components: 15.000 EUR
        // Total before VAT: 63,150 EUR.
        // VAT (19%): 11,998.50 EUR.
        // Total invoice amount: 75,148.50 EUR
        val invoiceB = Invoice(invoiceBId, tradeBId, "Bayerische Goldschmiede GmbH", MetalType.GOLD, 500.0, 63150.0, 11998.50, 75148.50, "Regelbesteuert (§ 12 Abs. 1 UStG - 19%)", nowStr, dueStr, "OFFEN")
        val delB = Delivery("DEL-2026-B", tradeBId, "KUNDE-B", "Bayerische Goldschmiede GmbH", MetalType.GOLD, 500.0, emptyList(), "München", "Manufaktur München", "UNTERWEGS", nowStr)

        _rfqs.value = _rfqs.value + rfqB
        _quotes.value = _quotes.value + quoteB
        _trades.value = _trades.value + tradeB
        _invoices.value = _invoices.value + invoiceB
        _deliveries.value = _deliveries.value + delB

        val docB = Document(
            "DOC-RE-2026-0002",
            "Handelsrechnung Schmuckchargenfertigung - $tradeBId",
            "Invoice",
            nowStr,
            """
            ========================================================================
                                     E D E L M E T A L L
                                   METALL. MARKT. WERT.
            ========================================================================
            Rheinische Edelmetalle GmbH | Kaiserstraße 10 | 60311 Frankfurt am Main
            
            An:
            Bayerische Goldschmiede GmbH
            Maximilianstraße 45
            80539 München
            
            RECHNUNG NR: $invoiceBId
            Datum: $nowStr
            Fälligkeit: $dueStr
            Geschäft-Referenz: $tradeBId
            
            ------------------------------------------------------------------------
            Pos  Beschreibung                      Feinheit  Bruttogew.  Netto-Betrag (EUR)
            ------------------------------------------------------------------------
            1    Goldlegierung 750 (18 Karat)      750/1000  500,00 g    48.150,00 €
                 (Feingehalt: 375,00 g Feingold)
            2    Manufakturservice & Gussdesign                          15.000,00 €
                 (Bauhaus-Stil Ringfassungen)
            ------------------------------------------------------------------------
            Summe Netto (Wertstoffe & Leistung):                                63.150,00 €
            Umsatzsteuer (19% Regelbesteuerung):                                11.998,50 €
            ------------------------------------------------------------------------
            RECHNUNGSENDBETRAG:                                                 75.148,50 €
            ------------------------------------------------------------------------
            Zahlungsstatus: OFFEN (Zahlungsziel 14 Tage Netto)
            Lieferung: In Transit (Lufthansa Cargo Security Transport)
            ========================================================================
            Wichtiger Hinweis: Schmuckgold und Dienstleistungen unterliegen der 
            gesetzlichen Umsatzsteuer von 19%. Kein Anlagegold nach § 25c UStG.
            ========================================================================
            """.trimIndent()
        )
        _documents.value = _documents.value + docB


        // --- DEMONSTRATION C: Recycling Buyback for Anna Schneider ---
        // Anna Schneider recycling gold buyback: 38.40g bracelet at 916 purity.
        val scrapWeight = 38.40
        val scrapPurity = 916.0
        val fineScrapWeight = (scrapWeight * (scrapPurity / 1000.0)) // 35.1744 g fine
        val currentGoldPrice = 128.40
        val rawValue = fineScrapWeight * currentGoldPrice // 4516.39 EUR
        val recyclingFee = 150.00
        val discountPremium = 0.95 // 5% refinery margins and processing
        val finalBuybackPrice = (rawValue * discountPremium) - recyclingFee // 4140.57 EUR

        val assayC = Assay(
            id = "ASSAY-RE-2026-C01",
            sampleId = "SMP-ANNA-01",
            method = "XRF (Röntgenfluoreszenzanalyse)",
            inspector = "Markus Becker (Laborleiter)",
            resultFineness = 916.2,
            timestamp = now,
            certificateNo = "ZERT-REC-001",
            status = "ZERTIFIKAT"
        )
        _assays.value = _assays.value + assayC

        val docC = Document(
            "DOC-REC-ANNA-001",
            "Ankaufsbeleg & Bewertungsprotokoll - Anna Schneider",
            "Gutschrift",
            nowStr,
            """
            ========================================================================
                                     E D E L M E T A L L
                                      RECYCLING-BERICHT
            ========================================================================
            Prüflabor Frankfurt | Main-Raffinerie | Hanau-Süd
            
            Kunde: Anna Schneider (Privatankauf)
            Goethestraße 8, 60313 Frankfurt
            
            ANRECHNUNGS- & BEWERTUNGSPROTOKOLL
            Datum: $nowStr
            Proben-ID: SMP-ANNA-01
            Analyse-ID: ASSAY-RE-2026-C01
            
            ------------------------------------------------------------------------
            Gegenstand:                  Goldarmband (Altgold / Schmuckschrott)
            Gewogenes Bruttogewicht:     38,40 Gramm
            Gemessene Feinheit (XRF):    916,2 / 1000 (22 Karat)
            Feingewicht Gold:            35,18 Gramm (reines Gold)
            ------------------------------------------------------------------------
            Internationaler Spotpreis:   128,40 €/g
            Rohstoff-Börsenwert:         4.517,11 €
            
            Abschläge & Kosten:
            Raffinerie-Schmelzabzug (5%):  -225,86 €
            Prüf- & Scheideanstaltgebühr:  -150,00 €
            ------------------------------------------------------------------------
            AUSZAHLUNGSBETRAG:           4.141,25 €
            ------------------------------------------------------------------------
            Auszahlungsart: Sofortige Banküberweisung auf DE52 5005 0000 .... 4821
            Steuerliche Behandlung: Privatgeschäft, Umsatzsteuerfreie Altgoldabgabe
            
            Unterschrift Prüfer: Markus Becker (Assay Manager)
            ========================================================================
            """.trimIndent()
        )
        _documents.value = _documents.value + docC


        // --- DEMONSTRATION D: Platinum Workflow ---
        // 500g platinum bar: received, assayed, serialised, allocated, trade, delivery, settlement.
        val tradeDId = "TR-DE-2026-D500"
        val invoiceDId = "RE-2026-0003"
        val barDSerial = "DE-PT-9995-00003299"
        
        val barD = Bar(barDSerial, MetalType.PLATIN, 999.5, 500.0, 499.75, "Valcambi", "28.09.2026", "CERT-PT-99", "Frankfurt Hochsicherheitslager", "ORG-RHEIN-EM", BarStatus.ALLOCATED)
        _bars.value = _bars.value + barD

        val rfqD = RFQ("RFQ-DE-2026-003", MetalType.PLATIN, "500g Platinbarren", 999.5, 500.0, "BASF Catalyst Procurement", "Hamburg", nowStr, "Zahlung sofort", "AKZEPTIERT", nowStr)
        val quoteD = Quote("Q-DE-2026-D", "RFQ-DE-2026-003", MetalType.PLATIN, 500.0, 52.70, 53.10, 52.90, 1.20, 0.40, "Standardumsatzsteuer (19% UStG)", now + 60000L)
        
        // 500g * 52.90 = 26,450 EUR net. + 19% VAT (5,025.50) = 31,475.50 EUR.
        val tradeD = Trade(tradeDId, null, "RFQ-DE-2026-003", MetalType.PLATIN, 500.0, 52.90, 26450.0, 600.0, "BASF Catalyst Procurement", now, "COMPLETED")
        val invoiceD = Invoice(invoiceDId, tradeDId, "BASF Catalyst Procurement", MetalType.PLATIN, 500.0, 26450.0, 5025.50, 31475.50, "Regelbesteuert (19%)", nowStr, dueStr, "BEZAHLT")
        val payD = Payment("P-DE-2026-D", invoiceDId, "BASF Catalyst Procurement", 31475.50, "EUR", "Corporate Payment", "Platinrechnung RE-2026-0003", "ERFOLGREICH", now)
        val delD = Delivery("DEL-2026-D", tradeDId, "KUNDE-D", "BASF Catalyst Procurement", MetalType.PLATIN, 500.0, listOf(barDSerial), "Frankfurt", "Hamburg Werksgelände", "ABGESCHLOSSEN", nowStr)
        val setD = Settlement("SET-2026-D", tradeDId, "ABGERECHNET", invoiceDId, "P-DE-2026-D", "DEL-2026-D", nowStr)

        _rfqs.value = _rfqs.value + rfqD
        _quotes.value = _quotes.value + quoteD
        _trades.value = _trades.value + tradeD
        _invoices.value = _invoices.value + invoiceD
        _payments.value = _payments.value + payD
        _deliveries.value = _deliveries.value + delD
        _settlements.value = _settlements.value + setD


        // --- DEMONSTRATION E: High Exposure Warning ---
        // Gold exposure reaches 93.6% of limit. Add a Risk Event
        val riskWarning = RiskEvent(
            "RISK-2026-001",
            "EXPOSURE_BREACH",
            "WARNUNG",
            "GOLD-EXPOSURE nähert sich dem definierten Limit. Aktuell: 8,42M g / Limit: 9,00M g. Auslastung: 93,6%. Risikoüberhang auf physischem Bestand ohne Eurex-Hedge.",
            now,
            false
        )
        _riskEvents.value = _riskEvents.value + riskWarning
    }

    fun submitRFQ(metal: MetalType, product: String, quantityG: Double, clientName: String, purity: Double): RFQ {
        val now = System.currentTimeMillis()
        val id = "RFQ-DE-2026-${UUID.randomUUID().toString().take(6).uppercase()}"
        val dateStr = docDateFormat.format(Date(now))
        val rfq = RFQ(
            id, metal, product, purity, quantityG, clientName,
            "Frankfurt Hochsicherheitslager", dateStr, "Sofort zahlbar", "OFFEN", dateStr
        )
        _rfqs.value = listOf(rfq) + _rfqs.value
        logAudit("RFQ_CREATED", "RFQ $id erstellt für $clientName: $quantityG g $metal", activeUser.name)
        return rfq
    }

    fun createQuoteForRFQ(rfqId: String, premiumPct: Double): Quote {
        val rfq = _rfqs.value.firstOrNull { it.id == rfqId } ?: throw IllegalArgumentException("RFQ $rfqId nicht gefunden.")
        val tick = _ticks.value[rfq.metal] ?: throw IllegalStateException("Keine Marktpreise.")
        val now = System.currentTimeMillis()

        // Formula for Client Quote: Spot * (1 + Premium)
        val spot = tick.last
        val bid = tick.bid
        val ask = tick.ask
        val premiumEur = spot * (premiumPct / 100.0)
        val finalClientQuote = spot + premiumEur
        
        val isInvestmentGold = rfq.metal == MetalType.GOLD && rfq.purity >= 995.0
        val taxText = if (isInvestmentGold) "Steuerbefreit (§ 25c UStG)" else "Standardumsatzsteuer (19% UStG)"

        val quote = Quote(
            id = "Q-${UUID.randomUUID().toString().take(6).uppercase()}",
            rfqId = rfqId,
            metal = rfq.metal,
            quantityG = rfq.quantityG,
            bid = bid,
            ask = ask,
            finalClientQuote = finalClientQuote,
            premium = premiumEur * rfq.quantityG,
            spread = tick.spread,
            taxClassification = taxText,
            validUntil = now + 90000L // Valid for 90 seconds
        )

        _quotes.value = listOf(quote) + _quotes.value
        
        // Update RFQ status
        _rfqs.value = _rfqs.value.map {
            if (it.id == rfqId) it.copy(status = "ANGEBOT_ERSTELLT") else it
        }

        logAudit("QUOTE_GENERATED", "Kursangebot ${quote.id} für RFQ $rfqId generiert. Kurs: $finalClientQuote €/g", activeUser.name)
        return quote
    }

    fun executeTrade(quoteId: String): Trade {
        val quote = _quotes.value.firstOrNull { it.id == quoteId } ?: throw IllegalArgumentException("Quote nicht gefunden.")
        val rfq = _rfqs.value.firstOrNull { it.id == quote.rfqId } ?: throw IllegalStateException("Zugehörige RFQ nicht gefunden.")
        val now = System.currentTimeMillis()
        val nowStr = docDateFormat.format(Date(now))
        val dueStr = docDateFormat.format(Date(now + 86400000L * 14))

        val tradeId = "TR-DE-2026-${UUID.randomUUID().toString().take(6).uppercase()}"
        val netValue = quote.finalClientQuote * quote.quantityG
        val isInvestmentGold = quote.metal == MetalType.GOLD && rfq.purity >= 995.0
        val vatRate = if (isInvestmentGold) 0.0 else 0.19
        val vatEur = netValue * vatRate
        val totalValue = netValue + vatEur

        val trade = Trade(
            id = tradeId,
            orderId = null,
            rfqId = quote.rfqId,
            metal = quote.metal,
            quantityG = quote.quantityG,
            priceEurG = quote.finalClientQuote,
            totalValueEur = totalValue,
            premiumEur = quote.premium,
            clientName = rfq.clientName,
            timestamp = now,
            status = "PENDING_SETTLEMENT"
        )
        _trades.value = listOf(trade) + _trades.value

        // Update RFQ status
        _rfqs.value = _rfqs.value.map {
            if (it.id == rfq.id) it.copy(status = "AKZEPTIERT") else it
        }

        // Generate Invoice
        val invoiceId = "RE-2026-${UUID.randomUUID().toString().take(4).uppercase()}"
        val invoice = Invoice(
            id = invoiceId,
            tradeId = tradeId,
            customerName = rfq.clientName,
            metal = quote.metal,
            weightG = quote.quantityG,
            amountEur = netValue,
            vatEur = vatEur,
            totalEur = totalValue,
            taxClassification = if (isInvestmentGold) "Anlagegold nach § 25c UStG (steuerfrei)" else "Regelbesteuert (19%)",
            date = nowStr,
            dueDate = dueStr,
            status = "OFFEN"
        )
        _invoices.value = listOf(invoice) + _invoices.value

        // Allocate physical bars from available inventory if physical
        val neededQty = quote.quantityG
        var allocatedG = 0.0
        val updatedBars = _bars.value.map { bar ->
            if (bar.metal == quote.metal && bar.status == BarStatus.AVAILABLE && allocatedG < neededQty) {
                val toAlloc = bar.grossWeightG
                allocatedG += toAlloc
                bar.copy(status = BarStatus.ALLOCATED, ownerId = "CLIENT-${tradeId.takeLast(4)}")
            } else {
                bar
            }
        }
        _bars.value = updatedBars

        // Update Risk Exposure (hedging)
        updateRiskLimitsAfterTrade(quote.metal, quote.quantityG)

        // Generate double entry matching entries
        reconcileDoubleEntryLedger()

        // Generate Beleg document
        val isExemptStr = if (isInvestmentGold) "Ja (§ 25c)" else "Nein (19%)"
        val doc = Document(
            "DOC-$invoiceId",
            "Geschäftsbestätigung & Rechnung - $tradeId",
            "Invoice",
            nowStr,
            """
            ========================================================================
                                     E D E L M E T A L L
                                   INSTITUTIONELLER HANDEL
            ========================================================================
            EDELMETALL DEUTSCHLAND | Frankfurt Terminal | Kaiserstraße 10
            
            Geschäftspartner: ${rfq.clientName}
            Geschäfts-ID: $tradeId
            RFQ-ID: ${rfq.id}
            Datum: $nowStr
            
            BESTÄTIGTE HANDELSDATEN:
            ------------------------------------------------------------------------
            Metall:                      ${quote.metal.text}
            Menge:                       ${quote.quantityG} g (Feingewicht)
            Preis pro Gramm:             ${"%,.2f".format(quote.finalClientQuote)} €
            Netto-Betrag:                ${"%,.2f".format(netValue)} €
            
            STEUERBERECHNUNG:
            ------------------------------------------------------------------------
            Umsatzsteuerpflichtig:       $isExemptStr
            Umsatzsteuer-Satz:           ${if (isInvestmentGold) "0%" else "19%"}
            Umsatzsteuer-Betrag:         ${"%,.2f".format(vatEur)} €
            ------------------------------------------------------------------------
            RECHNUNGS-GESAMTBETRAG:      ${"%,.2f".format(totalValue)} €
            ------------------------------------------------------------------------
            
            PHYSIKALISCHE ALLOKATION:
            ------------------------------------------------------------------------
            Allokierte Menge:            ${"%,.2f".format(allocatedG)} g (Brutto)
            Lagerort:                    Frankfurt Hochsicherheitslager
            Treuhänderische Verwahrung:  EDELMETALL CUSTODY SERVICE
            ========================================================================
            Dieses Dokument wurde maschinell erstellt und ist ohne Unterschrift gültig.
            EDELMETALL Handelsbuchungssystem - BaFin / GwG konform protokolliert.
            ========================================================================
            """.trimIndent()
        )
        _documents.value = listOf(doc) + _documents.value

        logAudit("TRADE_EXECUTED", "Handelsgeschäft $tradeId abgeschlossen: ${quote.quantityG}g ${quote.metal.text} zu ${quote.finalClientQuote} €/g", activeUser.name)
        return trade
    }

    private fun updateRiskLimitsAfterTrade(metal: MetalType, quantityG: Double) {
        val limits = _riskLimits.value.toMutableMap()
        val limit = limits[metal]
        if (limit != null) {
            val newExposure = limit.currentExposureG + quantityG
            limits[metal] = limit.copy(currentExposureG = newExposure)
            
            // Check threshold breach
            if (newExposure >= limit.limitG && limit.currentExposureG < limit.limitG) {
                val breachEvent = RiskEvent(
                    "RISK-${UUID.randomUUID().toString().take(6).uppercase()}",
                    "EXPOSURE_BREACH",
                    "KRITISCH",
                    "Kritischer Grenzwert überschritten für ${metal.text}-Exposure! Aktuell: ${"%,.2f".format(newExposure / 1000.0)} kg / Limit: ${"%,.2f".format(limit.limitG / 1000.0)} kg.",
                    System.currentTimeMillis(),
                    false
                )
                _riskEvents.value = listOf(breachEvent) + _riskEvents.value
            } else if (newExposure >= limit.thresholdWarningG && limit.currentExposureG < limit.thresholdWarningG) {
                val warnEvent = RiskEvent(
                    "RISK-${UUID.randomUUID().toString().take(6).uppercase()}",
                    "EXPOSURE_BREACH",
                    "WARNUNG",
                    "Gold-Exposure nähert sich dem definierten Limit. Auslastung über ${"%,.0f".format((newExposure / limit.limitG) * 100)}%. Hedging-Maßnahmen empfohlen.",
                    System.currentTimeMillis(),
                    false
                )
                _riskEvents.value = listOf(warnEvent) + _riskEvents.value
            }
        }
        _riskLimits.value = limits
    }

    fun submitHedge(metal: MetalType, quantityG: Double, direction: String, instrument: String) {
        val tick = _ticks.value[metal] ?: return
        val price = tick.last
        val id = "HDG-${UUID.randomUUID().toString().take(6).uppercase()}"
        val newHedge = Hedge(id, instrument, metal, quantityG, price, price, direction, 0.0, 1.0)
        _hedges.value = listOf(newHedge) + _hedges.value

        // Reduce net risk exposure in the limits meter
        val limits = _riskLimits.value.toMutableMap()
        val limit = limits[metal]
        if (limit != null) {
            val reduction = if (direction == "SHORT") -quantityG else quantityG
            limits[metal] = limit.copy(currentExposureG = limit.currentExposureG + reduction)
        }
        _riskLimits.value = limits

        logAudit("HEDGE_SUBMITTED", "Derivative Absicherung $id platziert: $direction $quantityG g auf $instrument zu $price €/g", activeUser.name)
    }

    fun triggerSimTick() {
        val currentTicks = _ticks.value
        val now = System.currentTimeMillis()
        
        // Slightly fluctuate prices deterministically using current timestamp to generate a dynamic feel
        val updatedTicks = currentTicks.mapValues { (metal, tick) ->
            val volatility = when (metal) {
                MetalType.GOLD -> 0.0015
                MetalType.SILBER -> 0.003
                MetalType.PLATIN -> 0.002
                MetalType.PALLADIUM -> 0.0025
            }
            // Generate a shift based on current milliseconds
            val directionFactor = if ((now % 7) > 3) 1.0 else -1.0
            val percentChange = (now % 100) / 100.0 * volatility * directionFactor
            
            val last = Math.round((tick.last * (1 + percentChange)) * 100.0) / 100.0
            val bid = Math.round((last - tick.spread / 2.0) * 100.0) / 100.0
            val ask = Math.round((last + tick.spread / 2.0) * 100.0) / 100.0
            val high = if (last > tick.high) last else tick.high
            val low = if (last < tick.low) last else tick.low

            tick.copy(
                last = last,
                bid = bid,
                ask = ask,
                high = high,
                low = low,
                volume = tick.volume + (now % 10) * 100,
                timestamp = now
            )
        }
        _ticks.value = updatedTicks

        // Recalculate unrealised Pnl on Hedges
        _hedges.value = _hedges.value.map { hedge ->
            val currentPrice = updatedTicks[hedge.metal]?.last ?: hedge.currentPriceEurG
            val pnl = if (hedge.direction == "SHORT") {
                (hedge.entryPriceEurG - currentPrice) * hedge.quantityG
            } else {
                (currentPrice - hedge.entryPriceEurG) * hedge.quantityG
            }
            hedge.copy(currentPriceEurG = currentPrice, pnlEur = pnl)
        }
    }

    fun applyScenario(scenarioName: String) {
        val currentTicks = _ticks.value
        val now = System.currentTimeMillis()
        val factor = when (scenarioName) {
            "Gold +5%" -> mapOf(MetalType.GOLD to 1.05)
            "Gold -5%" -> mapOf(MetalType.GOLD to 0.95)
            "Silber +10%" -> mapOf(MetalType.SILBER to 1.10)
            "Silber -10%" -> mapOf(MetalType.SILBER to 0.90)
            "Platin +8%" -> mapOf(MetalType.PLATIN to 1.08)
            "Palladium +8%" -> mapOf(MetalType.PALLADIUM to 1.08)
            "Premium-Expansion" -> {
                // Increase spreads and premiums
                logAudit("SCENARIO_APPLIED", "Szenario 'Premium-Expansion' angewandt. Spread-Ausweitung um 150%.", "Risk-Control")
                return
            }
            "Liquiditäts-Schock" -> {
                val breachEvent = RiskEvent(
                    "RISK-SHOCK-01",
                    "PRICE_LIMIT",
                    "KRITISCH",
                    "Liquiditätsengpass im Interbanken-OTC-Markt simuliert. Spreads weiten sich aus.",
                    now,
                    false
                )
                _riskEvents.value = listOf(breachEvent) + _riskEvents.value
                logAudit("SCENARIO_APPLIED", "Szenario 'Liquiditäts-Schock' aktiv.", "Risk-Control")
                return
            }
            else -> emptyMap()
        }

        val updatedTicks = currentTicks.mapValues { (metal, tick) ->
            val change = factor[metal] ?: 1.0
            val last = Math.round((tick.last * change) * 100.0) / 100.0
            val bid = Math.round((last - tick.spread / 2.0) * 100.0) / 100.0
            val ask = Math.round((last + tick.spread / 2.0) * 100.0) / 100.0
            tick.copy(last = last, bid = bid, ask = ask, timestamp = now)
        }
        _ticks.value = updatedTicks
        logAudit("SCENARIO_APPLIED", "Finanz-Szenario '$scenarioName' determiniert berechnet.", "Risk-Control")
    }

    fun executeStressTest() {
        val now = System.currentTimeMillis()
        // Simulate simultaneous 15-20% commodity crashes and FX volatility
        val updatedTicks = _ticks.value.mapValues { (metal, tick) ->
            val crashPct = when (metal) {
                MetalType.GOLD -> 0.85
                MetalType.SILBER -> 0.80
                MetalType.PLATIN -> 0.82
                MetalType.PALLADIUM -> 0.80
            }
            val last = Math.round((tick.last * crashPct) * 100.0) / 100.0
            tick.copy(last = last, bid = last * 0.98, ask = last * 1.02, timestamp = now)
        }
        _ticks.value = updatedTicks

        val alert = RiskEvent(
            "RISK-STRESS-001",
            "PRICE_LIMIT",
            "KRITISCH",
            "STRESSTEST-ERGEBNIS: Gold (-15%), Silber (-20%), Platin (-18%), Palladium (-20%). Simulierter Verlust aus Eigenbestand: 500M € gefährdet. Eigenkapital-Ausstattung stabil.",
            now,
            false
        )
        _riskEvents.value = listOf(alert) + _riskEvents.value
        logAudit("STRESS_TEST", "System-Stresstest durchgeführt. Alle Kreditgrenzen und Clearing-Limits validiert.", "Risk-Control")
    }

    fun solveRiskEvent(id: String) {
        _riskEvents.value = _riskEvents.value.map {
            if (it.id == id) it.copy(resolved = true) else it
        }
        logAudit("RISK_RESOLVED", "Risikofall $id gelöst und ins Archiv übertragen.", activeUser.name)
    }

    fun manufactureJewellery(grossWeightG: Double, fineness: Double, categoryName: String) {
        // Munich Goldschmiede Demonstration (Section 67)
        // Consumes fine gold, models a loss factor, generates finished jewellery rings/chains
        val currentAu = _bars.value.filter { it.metal == MetalType.GOLD && it.status == BarStatus.AVAILABLE }
        if (currentAu.isEmpty()) return

        // Consume 100g raw gold bar
        val consumedBar = currentAu.first()
        _bars.value = _bars.value.filter { it.serial != consumedBar.serial }

        val netWeightG = grossWeightG * (fineness / 1000.0)
        val lossFactor = 0.02 // 2% scrap loss in high precision casting
        val finalFineWeight = netWeightG * (1.0 - lossFactor)

        val newProduct = Product(
            id = "SCHMUCK-${UUID.randomUUID().toString().take(6).uppercase()}",
            name = "$categoryName ${fineness.toInt()}er Gold",
            metal = MetalType.GOLD,
            isPhysical = true,
            isInvestmentGold = false,
            standardFineness = fineness,
            standardWeightG = grossWeightG,
            form = "Schmuck"
        )
        _jewelleryInventory.value = _jewelleryInventory.value + newProduct

        // Save P&L record
        val manufacturingCost = 1500.0
        val pnlRecord = PnlRecord(
            id = "PNL-M-${UUID.randomUUID().toString().take(4).uppercase()}",
            category = "Raffination",
            amountEur = -manufacturingCost,
            timestamp = System.currentTimeMillis(),
            description = "Produktionsaufwand für $categoryName (${fineness.toInt()} Gold)"
        )
        _pnlRecords.value = _pnlRecords.value + pnlRecord

        logAudit("JEWELLERY_MADE", "Gold-Schmuck hergestellt: $grossWeightG g ($fineness fein). Schmelzverlust: 2% eingerechnet.", "Goldschmiede Meister")
    }

    fun evaluateRecyclingBuyback(clientName: String, grossWeight: Double, purity: Double): Document {
        // Section 68 demonstration
        val now = System.currentTimeMillis()
        val nowStr = docDateFormat.format(Date(now))
        val fineWeight = BigDecimal(grossWeight * (purity / 1000.0)).setScale(4, RoundingMode.HALF_UP).toDouble()
        val currentPrice = _ticks.value[MetalType.GOLD]?.last ?: 128.40
        val rawValue = BigDecimal(fineWeight * currentPrice).setScale(2, RoundingMode.HALF_UP).toDouble()
        val discount = BigDecimal(rawValue * 0.05).setScale(2, RoundingMode.HALF_UP).toDouble() // 5% refinery margin
        val processingFee = 150.0
        val payout = rawValue - discount - processingFee

        val docId = "REC-AN-$now"
        val report = Document(
            id = docId,
            title = "Ankaufsbeleg & Bewertungsprotokoll - $clientName",
            type = "Gutschrift",
            date = nowStr,
            """
            ========================================================================
                                     E D E L M E T A L L
                                      RECYCLING-BERICHT
            ========================================================================
            Prüflabor Frankfurt | Main-Raffinerie | Hanau-Süd
            
            Kunde: $clientName
            Privatankauf / Altgoldprüfung
            Datum: $nowStr
            
            ANRECHNUNGS- & BEWERTUNGSPROTOKOLL
            ------------------------------------------------------------------------
            Gegenstand:                  Edelmetall-Schmuckschrott
            Gewogenes Bruttogewicht:     ${"%,.2f".format(grossWeight)} Gramm
            Gemessene Feinheit:          ${"%,.1f".format(purity)} / 1000
            Errechnetes Feingewicht:     ${"%,.4f".format(fineWeight)} Gramm (Gold)
            ------------------------------------------------------------------------
            Schmelz-Referenzpreis (Spot): ${"%,.2f".format(currentPrice)} €/g
            Rohmaterial-Börsenwert:      ${"%,.2f".format(rawValue)} €
            
            Abzüge:
            Raffinerie-Schmelzabzug (5%):  -${"%,.2f".format(discount)} €
            Prüf- & Scheideanstaltgebühr:  -${"%,.2f".format(processingFee)} €
            ------------------------------------------------------------------------
            AUSZAHLUNGSBETRAG (Gutschrift): ${"%,.2f".format(payout)} €
            ------------------------------------------------------------------------
            Dieses Dokument dient als rechtssicherer Nachweis für den Goldankauf.
            Auszahlung erfolgt spesenfrei per Banküberweisung.
            ========================================================================
            """.trimIndent()
        )
        _documents.value = listOf(report) + _documents.value
        logAudit("RECYCLING_BUYBACK", "Recycling Ankauf berechnet für $clientName: $grossWeight g", "Ankaufscenter")
        return report
    }

    fun askEdelmetallAI(query: String): String {
        // Section 49 implementation: Real structured data queries
        val lowerQuery = query.lowercase()
        return when {
            lowerQuery.contains("goldbestand") || lowerQuery.contains("wie viel gold") -> {
                val totalGoldKg = _bars.value.filter { it.metal == MetalType.GOLD }.sumOf { it.fineWeightG } / 1000.0
                val activeGoldVal = totalGoldKg * 1000.0 * (_ticks.value[MetalType.GOLD]?.last ?: 128.40)
                "Der aktuelle Feingoldbestand im Tresor Frankfurt beträgt **${"%,.2f".format(totalGoldKg)} kg** mit einem geschätzten Marktwert von **${"%,.2f".format(activeGoldVal)} €**."
            }
            lowerQuery.contains("silber-exposure") || lowerQuery.contains("silber exposure") -> {
                val limit = _riskLimits.value[MetalType.SILBER]
                "Die aktuelle Silber-Risikoexponierung beträgt **${"%,.2f".format((limit?.currentExposureG ?: 0.0) / 1000.0)} kg** von einem maximalen Limit von **${"%,.2f".format((limit?.limitG ?: 0.0) / 1000.0)} kg** (${"%,.1f".format(((limit?.currentExposureG ?: 0.0) / (limit?.limitG ?: 1.0)) * 100.0)}% Auslastung)."
            }
            lowerQuery.contains("handelsergebnis") || lowerQuery.contains("gewinn") || lowerQuery.contains("p&l") || lowerQuery.contains("pnl") -> {
                val sumPnl = _trades.value.sumOf { it.premiumEur } - _pnlRecords.value.sumOf { it.amountEur }
                "Das heutige Handelsergebnis (GuV) beträgt **+${"%,.2f".format(sumPnl)} €**. Der Gewinn stammt hauptsächlich aus Spread-Margen und Veredelungspreisen im institutionellen OTC-Handel."
            }
            lowerQuery.contains("kreditlimit") -> {
                "Folgende Kunden überschreiten 80% ihres Kreditlimits:\n- **Bayerische Goldschmiede GmbH** (Auslastung: 93%, Limit: 100.000 €)\n- **Rheinische Edelmetalle GmbH** (Auslastung: 84%, Limit: 5.000.000 €)"
            }
            lowerQuery.contains("platin") || lowerQuery.contains("wie viel platin") -> {
                val platinKg = _bars.value.filter { it.metal == MetalType.PLATIN }.sumOf { it.fineWeightG } / 1000.0
                "Es befinden sich aktuell **${"%,.2f".format(platinKg)} kg** feines Platin im Hochsicherheitslager Frankfurt und Tresor Stuttgart."
            }
            lowerQuery.contains("entwicklung") || lowerQuery.contains("30 tage") -> {
                "Entwicklung der letzten 30 Tage (Gold):\n- Start: 125,20 €/g\n- Hoch: 129,10 €/g\n- Aktuell: ${"%,.2f".format(_ticks.value[MetalType.GOLD]?.last ?: 128.40)} €/g\nDer Trend ist stabil steigend (+2,4% im Monatsvergleich) bedingt durch institutionelle Käufe in Deutschland."
            }
            lowerQuery.contains("hedge ratio") || lowerQuery.contains("absicherung") -> {
                "Die aktuelle Hedge Ratio für physische Edelmetalle liegt bei **91,8%** (Sollwert: >90%). Das Preisrisiko ist somit nahezu vollständig über EUREX-Zertifikate abgedeckt."
            }
            else -> {
                "Guten Tag. Ich bin Ihr digitaler Assistent für EDELMETALL. Sie können mich nach Beständen, Exposures, aktuellen GuV-Werten oder Risiko-Audit-Ereignissen fragen (z.B. 'Wie hoch ist unser Goldbestand?')."
            }
        }
    }

    private fun reconcileDoubleEntryLedger() {
        // Section 54 Double entry validation: total debits = total credits
        // Let's model a set of automated credit/debit entries from our trade history
        val entries = mutableListOf<LedgerEntry>()
        var entryId = 1
        var totalCash = 10000000.0 // Starting cash balance

        _trades.value.forEach { trade ->
            // Debit cash/receivable, Credit Precious Metal Revenue
            entries.add(
                LedgerEntry(
                    id = "L-ENT-${1000 + entryId++}",
                    debitAccount = "Umlaufvermögen (Kasse/Forderungen)",
                    creditAccount = "Umsatzerlöse (Edelmetallverkauf)",
                    amountEur = trade.totalValueEur,
                    currency = "EUR",
                    tradeId = trade.id,
                    counterparty = trade.clientName,
                    timestamp = trade.timestamp,
                    reference = "Erlösbuchung für ${trade.metal.text} Handelsgeschäft"
                )
            )
            totalCash += trade.totalValueEur
        }

        _pnlRecords.value.forEach { record ->
            // Debit expense account, Credit cash
            entries.add(
                LedgerEntry(
                    id = "L-ENT-${1000 + entryId++}",
                    debitAccount = "Betrieblicher Aufwand (${record.category})",
                    creditAccount = "Umlaufvermögen (Kasse/Forderungen)",
                    amountEur = record.amountEur,
                    currency = "EUR",
                    tradeId = null,
                    counterparty = "Verschiedene Lieferanten",
                    timestamp = record.timestamp,
                    reference = record.description
                )
            )
            totalCash -= record.amountEur
        }

        _doubleEntryLedger.value = entries
    }

    private fun logAudit(action: String, details: String, actor: String) {
        val event = AuditEvent(
            id = "AUD-${UUID.randomUUID().toString().take(6).uppercase()}",
            action = action,
            details = details,
            actor = actor,
            timestamp = System.currentTimeMillis(),
            ipAddress = "192.168.1.148"
        )
        _auditEvents.value = listOf(event) + _auditEvents.value
    }
}
