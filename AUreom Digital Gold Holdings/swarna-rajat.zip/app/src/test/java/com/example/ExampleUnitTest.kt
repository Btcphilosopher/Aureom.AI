package com.example

import com.example.data.SimulationEngine
import com.example.model.BullionBar
import com.example.model.Fineness
import com.example.model.MetalType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testAccountingBalanceInvariant_alwaysEqual() {
        // Invariant check: Total Debits must equal Total Credits inside our system
        val isBalanced = SimulationEngine.verifyAccountingBalance()
        assertTrue("Double-entry bookkeeping must always have debits equal to credits", isBalanced)
    }

    @Test
    fun testMetalWeightPurityInvariants() {
        // Create a custom mock gold bar and verify that GROSS * PURITY = FINE weight
        val goldBar = BullionBar(
            serialNumber = "AU-TEST-001",
            metal = MetalType.GOLD,
            fineness = Fineness.GOLD_995,
            grossWeightGrams = 1000.35,
            refinery = "Test Refinery",
            productionDate = "05-Oct-2026",
            assayStatus = "CERTIFIED",
            location = "Jaipur",
            vaultCompartment = "COMP-01",
            owner = "Rajasthan Bullion",
            status = "AVAILABLE",
            estimatedValueInr = 74500000
        )

        val isFineWeightCorrect = SimulationEngine.verifyMetalInvariants(goldBar)
        assertTrue("Gross weight multiplied by purity must equal fine weight within delta limit", isFineWeightCorrect)
    }

    @Test
    fun testQuotationEngineCalculations() {
        // Calculate the base and total price for 10g Gold 999
        val pricing = SimulationEngine.calculateCommercialPrice(
            metal = MetalType.GOLD,
            fineness = Fineness.GOLD_999,
            weightGrams = 10.0,
            clientTier = "INSTITUTIONAL"
        )

        val basePrice = pricing["gross_base"] ?: 0L
        val subtotal = pricing["subtotal"] ?: 0L
        val gst = pricing["gst"] ?: 0L
        val total = pricing["total"] ?: 0L

        // GST is 3%
        val expectedGst = (subtotal * 0.03).toLong()
        assertEquals(expectedGst, gst)
        assertEquals(subtotal + gst, total)
    }
}
