package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

// 1. Precious Metal Market Status Header
@Composable
fun MarketStatusHeader(
    language: Language,
    marketOpen: Boolean,
    timestamp: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AntiqueGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = SlateGrey)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = SwarnaI18n.translate("app_title", language),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = AntiqueGold
                    )
                )
                Text(
                    text = SwarnaI18n.translate("app_subtitle", language),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedBrass,
                        letterSpacing = 0.5.sp
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (marketOpen) SuccessGreen else ErrorRed,
                                RoundedCornerShape(50)
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (marketOpen) SwarnaI18n.translate("market_open", language) else SwarnaI18n.translate("market_closed", language),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (marketOpen) SuccessGreen else ErrorRed
                        )
                    )
                }
                Text(
                    text = timestamp,
                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f))
                )
            }
        }
    }
}

// 2. Prestige Metal Price Card (Bilingual Support, Bid/Ask/Spread)
@Composable
fun MetalPriceCard(
    metal: MetalType,
    spotRateGramPaisa: Long,
    usdPerOz: Double,
    premiumPerGramInr: Double,
    language: Language,
    onBuyClicked: () -> Unit,
    onSellClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rateInr = spotRateGramPaisa / 100.0
    val bidRate = rateInr * 0.998 // 0.2% buy-back spread discount
    val askRate = rateInr * 1.002 // 0.2% premium ask spread
    val spread = askRate - bidRate

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MutedBrass.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SlateGrey)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Metal Name & Global Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (metal == MetalType.GOLD) Icons.Default.BrightnessHigh else Icons.Default.BrightnessMedium,
                        contentDescription = "Metal Icon",
                        tint = if (metal == MetalType.GOLD) AntiqueGold else Color.LightGray,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (metal == MetalType.GOLD) SwarnaI18n.translate("gold_price", language) else SwarnaI18n.translate("silver_price", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WarmIvory
                        )
                    )
                }
                
                // Int'l Spot tag
                Text(
                    text = "Global Spot: \$${"%,.2f".format(usdPerOz)} / oz",
                    style = MaterialTheme.typography.labelSmall.copy(color = MutedBrass)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Pricing Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "₹${"%,.2f".format(rateInr)} / ${if (metal == MetalType.GOLD) "10g" else "kg"}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AntiqueGold
                        )
                    )
                    Text(
                        text = "Domestic Premium: +₹${"%,.2f".format(premiumPerGramInr)} / ${if (metal == MetalType.GOLD) "10g" else "kg"}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Spread: ₹${"%.2f".format(spread)}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = SaffronAccent,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }

            Divider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = MutedBrass.copy(alpha = 0.2f)
            )

            // Bid & Ask Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (language == Language.ENGLISH) "BID (WE BUY)" else "खरीद भाव",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f))
                    )
                    Text(
                        text = "₹${"%,.2f".format(bidRate)}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (language == Language.ENGLISH) "ASK (WE SELL)" else "बिक्री भाव",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f))
                    )
                    Text(
                        text = "₹${"%,.2f".format(askRate)}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SaffronAccent
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tappable Action Targets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onBuyClicked,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("buy_button_${metal.name.lowercase()}"),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (metal == MetalType.GOLD) SwarnaI18n.translate("buy_gold", language) else SwarnaI18n.translate("buy_silver", language),
                        style = MaterialTheme.typography.labelLarge.copy(color = WarmIvory)
                    )
                }

                Button(
                    onClick = onSellClicked,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("sell_button_${metal.name.lowercase()}"),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (metal == MetalType.GOLD) SwarnaI18n.translate("sell_gold", language) else SwarnaI18n.translate("sell_silver", language),
                        style = MaterialTheme.typography.labelLarge.copy(color = DeepCharcoal)
                    )
                }
            }
        }
    }
}

// 3. Elegant Double-Entry Accounting Ledger View
@Composable
fun LedgerBookView(
    ledgerEntries: List<LedgerEntry>,
    language: Language,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = SlateGrey)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = SwarnaI18n.translate("double_ledger", language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = AntiqueGold,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "TOTAL DEBITS = TOTAL CREDITS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = SuccessGreen,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (ledgerEntries.isEmpty()) {
                Text(
                    text = "No entries in standard ledger.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextLight.copy(alpha = 0.5f))
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ledgerEntries.take(5).forEach { entry ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DeepCharcoal.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .border(0.5.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = entry.description,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WarmIvory
                                    )
                                )
                                Text(
                                    text = "₹${"%,.2f".format(entry.amountPaisa / 100.0)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = AntiqueGold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "DR: ${entry.debitAccount}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen)
                                )
                                Text(
                                    text = "CR: ${entry.creditAccount}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SaffronAccent)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "C/P: ${entry.counterparty}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                                )
                                Text(
                                    text = "Ref: ${entry.referenceId}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MutedBrass)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. PDF-Ready Luxury Invoice layout
@Composable
fun InvoiceReceiptView(
    invoice: Invoice,
    language: Language,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, AntiqueGold, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = WarmIvory)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Elegant top decorative bar (Jaipur styling)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(DeepMaroon)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Invoice Title & Metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = SwarnaI18n.translate("invoice_title", language).uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepMaroon,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Invoice: ${invoice.invoiceNumber}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextDark.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Text(
                    text = "Date: ${invoice.date}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextDark.copy(alpha = 0.7f))
                )
            }

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = DeepMaroon.copy(alpha = 0.2f))

            // Parties involved
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "FROM (SELLER):",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = DeepMaroon,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = invoice.sellerName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                    )
                    Text(
                        text = "GSTIN: ${invoice.sellerGst}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextDark.copy(alpha = 0.6f))
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(
                        text = "TO (BUYER):",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = DeepMaroon,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = invoice.buyerName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                    )
                    Text(
                        text = "GSTIN: ${invoice.buyerGst}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextDark.copy(alpha = 0.6f))
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Line Items
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color.Gray.copy(alpha = 0.5f))
                    .padding(8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Item Details",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark)
                        )
                        Text(
                            text = "Amount (INR)",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextDark)
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 6.dp))
                    
                    // Metal details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${invoice.metal.name} Bullion ${invoice.fineness.displayLabel} @ ${"%.2f".format(invoice.weightGrams)} g",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                        )
                        Text(
                            text = "₹${"%,.2f".format((invoice.ratePerGram / 100.0) * invoice.weightGrams)}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                        )
                    }

                    // Premium / Markup
                    if (invoice.premium > 0) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Dealer Premium / Making Charge",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                            )
                            Text(
                                text = "₹${"%,.2f".format(invoice.premium / 100.0)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                            )
                        }
                    }

                    // Taxes (GST 3%)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "GST (CGST 1.5% + SGST 1.5%)",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                        )
                        Text(
                            text = "₹${"%,.2f".format(invoice.taxValueInr / 100.0)}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDark)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Total Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "STATUS: ${invoice.paymentStatus}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "INVARIANT MATCHED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "TOTAL VALUE:",
                        style = MaterialTheme.typography.labelSmall.copy(color = DeepMaroon, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "₹${"%,.2f".format(invoice.totalAmountInr / 100.0)}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepMaroon
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onClose,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("close_invoice_button"),
                colors = ButtonDefaults.buttonColors(containerColor = DeepMaroon),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("Close Document", color = SoftWhite)
            }
        }
    }
}

// 5. Assay Certificate Presentation Card
@Composable
fun AssayCertificateCard(
    certificate: AssayCertificate,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MutedBrass, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = SlateGrey)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ASSAY & CONFORMANCE CERTIFICATE",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AntiqueGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )

                Box(
                    modifier = Modifier
                        .background(SuccessGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = certificate.result,
                        style = MaterialTheme.typography.labelSmall.copy(color = WarmIvory, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Certificate ID: ${certificate.certificateId}",
                style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f))
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Sample Code:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text(certificate.sampleCode, style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory, fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Verified Fineness:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text("${certificate.verifiedPurity * 1000} Fine", style = MaterialTheme.typography.bodySmall.copy(color = SaffronAccent, fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Gross Weight:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text("${"%,.3f".format(certificate.grossWeight)} g", style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Fine Weight Calculation:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text("${"%,.4f".format(certificate.fineWeight)} g", style = MaterialTheme.typography.bodySmall.copy(color = AntiqueGold, fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Analysis Method:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text(certificate.method, style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Assay Bureau / Laboratory:", style = MaterialTheme.typography.bodySmall.copy(color = TextLight))
                    Text(certificate.assayCentre, style = MaterialTheme.typography.bodySmall.copy(color = MutedBrass))
                }
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp), color = MutedBrass.copy(alpha = 0.2f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Assayer: ${certificate.assayerName}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                )
                Text(
                    text = certificate.dateCertified,
                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                )
            }
        }
    }
}

// 6. Interactive HUID Verifier Component
@Composable
fun HUIDVerifierWidget(
    language: Language,
    onVerify: (String) -> HUIDRecord?,
    modifier: Modifier = Modifier
) {
    var huidCode by remember { mutableStateOf("") }
    var resultRecord by remember { mutableStateOf<HUIDRecord?>(null) }
    var searched by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MutedBrass.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SlateGrey)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = SwarnaI18n.translate("verify_huid", language),
                style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Bureau of Indian Standards (BIS) Hallmarking Registry Database",
                style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = huidCode,
                    onValueChange = { if (it.length <= 6) huidCode = it.uppercase() },
                    placeholder = { Text(SwarnaI18n.translate("huid_desc", language), color = TextLight.copy(alpha = 0.4f)) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("huid_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = MutedBrass.copy(alpha = 0.5f),
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory
                    )
                )

                Button(
                    onClick = {
                        resultRecord = onVerify(huidCode)
                        searched = true
                    },
                    modifier = Modifier
                        .height(56.dp)
                        .testTag("verify_huid_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verify",
                        tint = DeepCharcoal
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(SwarnaI18n.translate("verify", language), color = DeepCharcoal)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Realism disclaimer
            Text(
                text = "BIS describes hallmarking as official content recording. HUID is a unique 6-character alphanumeric code for jewellery.",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = TextLight.copy(alpha = 0.4f))
            )

            AnimatedVisibility(visible = searched) {
                Spacer(modifier = Modifier.height(12.dp))
                val record = resultRecord
                if (record != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .border(1.dp, SuccessGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HUID: ${record.huid} [BIS VERIFIED]",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                            )
                            Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = SuccessGreen)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Article: ${record.articleType}",
                            style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Metal Content: ${record.metal.name} Bullion (${record.fineness.displayLabel})",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextLight)
                        )
                        Text(
                            text = "Certified Weight: ${"%.2f".format(record.grossWeightGrams)} g",
                            style = MaterialTheme.typography.bodySmall.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Assay Center: ${record.assayCentre}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextLight.copy(alpha = 0.7f))
                        )
                        Text(
                            text = "Hallmark Registration Date: ${record.dateHallmarked}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .border(1.dp, ErrorRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "HUID record not found or verification suspended in BIS master registry. Ensure code represents a valid 6-character alphanumeric serial.",
                            style = MaterialTheme.typography.bodySmall.copy(color = ErrorRed)
                        )
                    }
                }
            }
        }
    }
}
