package com.example.model

import java.util.UUID

// Language & Translation Helper
enum class Language {
    ENGLISH, HINDI
}

object SwarnaI18n {
    private val translations = mapOf(
        "app_title" to Pair("SWARNA//RAJAT", "स्वर्ण // रजत"),
        "app_subtitle" to Pair("GOLD • SILVER • BULLION • MERCHANTS", "सोना • चाँदी • बुलियन • व्यापारी"),
        "market_open" to Pair("MARKET OPEN", "बाज़ार खुला है"),
        "market_closed" to Pair("MARKET CLOSED", "बाज़ार बंद है"),
        "gold_price" to Pair("Gold Price", "सोने का भाव"),
        "silver_price" to Pair("Silver Price", "चाँदी का भाव"),
        "buy_gold" to Pair("Buy Gold", "सोना खरीदें"),
        "sell_gold" to Pair("Sell Gold", "सोना बेचें"),
        "buy_silver" to Pair("Buy Silver", "चाँदी खरीदें"),
        "sell_silver" to Pair("Sell Silver", "चाँदी बेचें"),
        "inventory" to Pair("Inventory", "भंडार"),
        "settlement" to Pair("Settlement", "निपटान"),
        "purity" to Pair("Purity", "शुद्धता"),
        "weight" to Pair("Weight", "वज़न"),
        "bullion" to Pair("Bullion", "बुलियन"),
        "assay" to Pair("Assay", "परीक्षण"),
        "vault" to Pair("Vault", "तिजोरी"),
        "clients" to Pair("Clients", "ग्राहक"),
        "risk" to Pair("Risk Monitor", "जोखिम निगरानी"),
        "swarna_ai" to Pair("Swarna AI", "स्वर्ण एआई"),
        "verify_huid" to Pair("Verify HUID", "HUID सत्यापित करें"),
        "jewellery_mode" to Pair("Jewellery Merchant", "आभूषण व्यापारी"),
        "scrap_mode" to Pair("Old Gold / Scrap", "पुराना सोना / स्क्रैप"),
        "hedging" to Pair("Hedging & MCX", "हेजिंग और एमसीएक्स"),
        "scenario_lab" to Pair("Scenario Lab", "सिमुलेशन लैब"),
        "invoice_title" to Pair("Tax Invoice", "कर बीजक"),
        "trade_book" to Pair("Trading Book", "ट्रेडिंग बुक"),
        "double_ledger" to Pair("Double-Entry Ledger", "दोहरी प्रविष्टि बही"),
        "fine_weight" to Pair("Fine Metal Weight", "शुद्ध धातु का वज़न"),
        "pnl" to Pair("P&L Attribution", "लाभ और हानि"),
        "audits" to Pair("Audit Trail", "ऑडिट रिपोर्ट"),
        "market_feed" to Pair("SIMULATED MARKET DATA FEED", "सिम्युलेटेड बाज़ार डेटा"),
        "home" to Pair("Home", "होम"),
        "market" to Pair("Market Terminal", "बाज़ार"),
        "dealer" to Pair("Dealer Terminal", "डीलर"),
        "huid_desc" to Pair("Enter 6-character HUID code", "६-अक्षरों का HUID कोड दर्ज करें"),
        "verify" to Pair("Verify", "सत्यापित करें")
    )

    fun translate(key: String, lang: Language): String {
        val pair = translations[key] ?: return key
        return if (lang == Language.ENGLISH) pair.first else pair.second
    }
}

// 1. Precious Metals & Fineness
enum class MetalType(val displayNameEn: String, val displayNameHi: String) {
    GOLD("Gold", "सोना"),
    SILVER("Silver", "चाँदी")
}

enum class Fineness(val purity: Double, val displayLabel: String) {
    // Gold finenesses
    GOLD_9999(0.9999, "999.9 (24K Pure)"),
    GOLD_999(0.999, "999 (24K Gold)"),
    GOLD_995(0.995, "995 (Standard Bullion)"),
    GOLD_916(0.916, "916 (22K Jewellery)"),
    GOLD_750(0.750, "750 (18K Premium)"),
    GOLD_585(0.585, "585 (14K Custom)"),
    
    // Silver finenesses
    SILVER_999(0.999, "999 (Fine Silver)"),
    SILVER_990(0.990, "990 (Standard Silver)"),
    SILVER_970(0.970, "970 (Artistic Articles)"),
    SILVER_925(0.925, "925 (Sterling Silver)"),
    SILVER_800(0.800, "800 (Silverware Articles)")
}

// 2. Physical Bullion Bar Model
data class BullionBar(
    val serialNumber: String,
    val metal: MetalType,
    val fineness: Fineness,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double = grossWeightGrams * fineness.purity,
    val refinery: String,
    val productionDate: String,
    val assayStatus: String, // RECEIVED, SAMPLED, TESTED, VERIFIED, CERTIFIED, INVENTORIED
    val location: String, // Mumbai, Delhi, Jaipur, Ahmedabad, Surat, Chennai, Kolkata, Bengaluru
    val vaultCompartment: String,
    val owner: String, // "Rajasthan Gold & Silver Pvt Ltd", "Sharma Jewellers", etc.
    val status: String, // ALLOCATED, AVAILABLE, IN_TRANSIT, RESERVED
    val estimatedValueInr: Long
)

// 3. Trade Confirmation Model
data class Trade(
    val id: String = "TRD-${UUID.randomUUID().toString().take(8).uppercase()}",
    val timestamp: Long = System.currentTimeMillis(),
    val metal: MetalType,
    val fineness: Fineness,
    val tradeType: String, // BUY, SELL
    val clientName: String,
    val quantityGrams: Double,
    val basePricePerGram: Long, // in Paisa (1/100 INR)
    val premiumPerGram: Long,   // in Paisa
    val grossValue: Long,       // in Paisa
    val totalCharges: Long,     // in Paisa
    val netValue: Long,         // in Paisa
    val settlementDate: String,
    val deliveryLocation: String,
    val status: String, // UNSETTLED, PENDING, SETTLED, FAILED
    val isHedgingLinked: Boolean = false,
    val hedgeReference: String? = null
)

// 4. Request for Quote (RFQ) Model
data class RFQ(
    val id: String = "RFQ-IND-2026-${(100000 + (Math.random() * 899999).toInt())}",
    val timestamp: Long = System.currentTimeMillis(),
    val clientName: String,
    val metal: MetalType,
    val fineness: Fineness,
    val quantityGrams: Double,
    val deliveryLocation: String,
    val settlementDate: String,
    val status: String = "OPEN", // OPEN, QUOTED, ACCEPTED, EXPIRED
    var quotedBidRate: Long = 0, // in Paisa
    var quotedAskRate: Long = 0, // in Paisa
    var quoteValiditySeconds: Int = 30
)

// 5. Invoice & Invoicing Engine Output
data class Invoice(
    val invoiceNumber: String = "INV-2026-${(10000 + (Math.random() * 89999).toInt())}",
    val date: String,
    val sellerName: String,
    val buyerName: String,
    val sellerGst: String,
    val buyerGst: String,
    val metal: MetalType,
    val fineness: Fineness,
    val weightGrams: Double,
    val ratePerGram: Long, // in Paisa
    val premium: Long, // in Paisa
    val makingCharges: Long = 0, // in Paisa
    val wastageGrams: Double = 0.0,
    val taxValueInr: Long, // in Paisa (CGST + SGST or IGST at 3% for precious metal)
    val totalAmountInr: Long, // in Paisa
    val paymentStatus: String, // UNPAID, PARTIALLY_PAID, PAID
    val settlementStatus: String // UNSETTLED, SETTLED
)

// 6. Double-Entry Accounting Ledger Entry
data class LedgerEntry(
    val id: String = "LEDG-${UUID.randomUUID().toString().take(10).uppercase()}",
    val timestamp: Long = System.currentTimeMillis(),
    val debitAccount: String,
    val creditAccount: String,
    val amountPaisa: Long,
    val description: String,
    val referenceId: String, // TradeID or InvoiceID
    val counterparty: String
)

// 7. Client & Portfolio Model
data class Client(
    val id: String,
    val name: String,
    val organisation: String,
    val city: String,
    val clientTier: String, // ELITE, GOLD, INSTITUTIONAL, RETAIL MERCHANT
    val creditLimitInr: Long, // in Paisa
    val tradingLimitInr: Long, // in Paisa
    val outstandingBalanceInr: Long, // in Paisa
    val goldPositionGrams: Double,
    val silverPositionGrams: Double,
    val kycStatus: String, // APPROVED, PENDING, WATCHLIST
    val riskStatus: String // LOW, MEDIUM, WATCH
)

// 8. MCX Hedging & Futures Contracts
data class HedgePosition(
    val contractSymbol: String, // MCX_GOLD_OCT2026, MCX_SILVER_DEC2026
    val metal: MetalType,
    val positionType: String, // LONG, SHORT
    val sizeKg: Double,
    val entryPrice: Long, // in Paisa per 10g (for Gold) or per kg (for Silver)
    val currentPrice: Long,
    val unrealisedPnlInr: Long // in Paisa
)

// 9. BIS HUID Hallmarked Registry
data class HUIDRecord(
    val huid: String, // 6 characters alphanumeric, e.g. "AB12CD"
    val articleType: String, // Necklace, Bangles, Ring, Coins
    val metal: MetalType,
    val fineness: Fineness,
    val grossWeightGrams: Double,
    val assayCentre: String, // Jaipur Hallmarking Ltd, Mumbai BIS Centre
    val dateHallmarked: String,
    val verificationStatus: String // VERIFIED, SUSPENDED, RECORD_NOT_FOUND
)

// 10. Assay Certificate Model
data class AssayCertificate(
    val certificateId: String = "ASY-IND-2026-${(1000 + (Math.random() * 8999).toInt())}",
    val sampleCode: String,
    val metal: MetalType,
    val grossWeight: Double,
    val fineWeight: Double,
    val verifiedPurity: Double,
    val method: String, // XRF (X-ray Fluorescence), Fire Assay (Cupellation)
    val assayCentre: String,
    val assayerName: String,
    val dateCertified: String,
    val result: String // CONFORMS, OUT_OF_SPECIFICATION
)
