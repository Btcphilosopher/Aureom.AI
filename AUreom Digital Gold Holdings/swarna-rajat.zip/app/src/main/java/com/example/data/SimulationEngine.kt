package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object SimulationEngine {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
    private val docDateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

    // Language state
    private val _currentLanguage = MutableStateFlow(Language.ENGLISH)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    fun setLanguage(language: Language) {
        _currentLanguage.value = language
    }

    // --- MARKET RATES (Configurable Inputs) ---
    private val _goldUsdPerOz = MutableStateFlow(2635.50) // USD per troy ounce (31.1034768 grams)
    val goldUsdPerOz: StateFlow<Double> = _goldUsdPerOz.asStateFlow()

    private val _silverUsdPerOz = MutableStateFlow(31.45) // USD per troy ounce
    val silverUsdPerOz: StateFlow<Double> = _silverUsdPerOz.asStateFlow()

    private val _usdInrRate = MutableStateFlow(83.45) // USD/INR
    val usdInrRate: StateFlow<Double> = _usdInrRate.asStateFlow()

    private val _domesticGoldPremiumPer10g = MutableStateFlow(2400.0) // INR premium over international import parity
    val domesticGoldPremiumPer10g: StateFlow<Double> = _domesticGoldPremiumPer10g.asStateFlow()

    private val _domesticSilverPremiumPerKg = MutableStateFlow(1850.0) // INR premium over international import parity
    val domesticSilverPremiumPerKg: StateFlow<Double> = _domesticSilverPremiumPerKg.asStateFlow()

    // Base commercial parameters
    var baseGstPercentage = 3.0 // BIS Standard 3% GST on Gold/Silver
    var fabricationChargeGoldPerGram = 120.0 // INR
    var makingChargeSilverPerGram = 45.0 // INR
    var logisticsChargePerKgGold = 8500.0 // INR
    var assayChargePerSample = 350.0 // INR

    // Derived Domestic Spot Prices (Paisa - Long representation for precision)
    // 1 Troy Ounce = 31.1034768 Grams
    private const val GRAMS_PER_TROY_OUNCE = 31.1034768

    fun getDerivedGoldSpotPerGramPaisa(multiplier: Double = 1.0): Long {
        val usdPerGram = (_goldUsdPerOz.value / GRAMS_PER_TROY_OUNCE) * multiplier
        val inrPerGram = usdPerGram * _usdInrRate.value
        val premiumPerGram = _domesticGoldPremiumPer10g.value / 10.0
        val finalRateInr = inrPerGram + premiumPerGram
        return (finalRateInr * 100.0).toLong()
    }

    fun getDerivedSilverSpotPerGramPaisa(multiplier: Double = 1.0): Long {
        val usdPerGram = (_silverUsdPerOz.value / GRAMS_PER_TROY_OUNCE) * multiplier
        val inrPerGram = usdPerGram * _usdInrRate.value
        val premiumPerGram = _domesticSilverPremiumPerKg.value / 1000.0
        val finalRateInr = inrPerGram + premiumPerGram
        return (finalRateInr * 100.0).toLong()
    }

    // --- REPOSITORIES ---
    private val _clients = MutableStateFlow<List<Client>>(emptyList())
    val clients: StateFlow<List<Client>> = _clients.asStateFlow()

    private val _bullionBars = MutableStateFlow<List<BullionBar>>(emptyList())
    val bullionBars: StateFlow<List<BullionBar>> = _bullionBars.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RFQ>>(emptyList())
    val rfqs: StateFlow<List<RFQ>> = _rfqs.asStateFlow()

    private val _ledgerEntries = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerEntries: StateFlow<List<LedgerEntry>> = _ledgerEntries.asStateFlow()

    private val _invoices = MutableStateFlow<List<Invoice>>(emptyList())
    val invoices: StateFlow<List<Invoice>> = _invoices.asStateFlow()

    private val _assayCertificates = MutableStateFlow<List<AssayCertificate>>(emptyList())
    val assayCertificates: StateFlow<List<AssayCertificate>> = _assayCertificates.asStateFlow()

    private val _huidRegistry = MutableStateFlow<List<HUIDRecord>>(emptyList())
    val huidRegistry: StateFlow<List<HUIDRecord>> = _huidRegistry.asStateFlow()

    private val _hedgePositions = MutableStateFlow<List<HedgePosition>>(emptyList())
    val hedgePositions: StateFlow<List<HedgePosition>> = _hedgePositions.asStateFlow()

    private val _alerts = MutableStateFlow<List<String>>(emptyList())
    val alerts: StateFlow<List<String>> = _alerts.asStateFlow()

    // --- SYSTEM DEMO METRICS & P&L ---
    private val _vaultCashBalancePaisa = MutableStateFlow(4500_000_000_00L) // Starting cash: 45 Crore INR
    val vaultCashBalancePaisa: StateFlow<Long> = _vaultCashBalancePaisa.asStateFlow()

    private val _realisedPnlPaisa = MutableStateFlow(12_450_000_00L) // Starting realised P&L: 1.24 Crore INR
    val realisedPnlPaisa: StateFlow<Long> = _realisedPnlPaisa.asStateFlow()

    private val _unrealisedPnlPaisa = MutableStateFlow(4_820_000_00L) // Unrealised revaluation
    val unrealisedPnlPaisa: StateFlow<Long> = _unrealisedPnlPaisa.asStateFlow()

    // Real-time market feed tick timestamp
    private val _lastMarketTick = MutableStateFlow(dateFormat.format(Date()))
    val lastMarketTick: StateFlow<String> = _lastMarketTick.asStateFlow()

    // --- SEED INITIALIZATION ---
    init {
        initializeSeedData()
    }

    private fun initializeSeedData() {
        // 1. Initial Clients & Merchants
        _clients.value = listOf(
            Client("CLI-RAJASTHAN", "Rajasthan Gold & Silver Pvt Ltd", "Rajasthan Bullion House", "Jaipur", "ELITE", 500_000_000_00L, 1000_000_000_00L, 12_000_000_00L, 2500000.0, 15000000.0, "APPROVED", "LOW"),
            Client("CLI-SHARMA", "Sharma Jewellers", "Sharma Heritage Jewellery", "Jaipur", "RETAIL MERCHANT", 50_000_000_00L, 100_000_000_00L, 0L, 10000.0, 50000.0, "APPROVED", "LOW"),
            Client("CLI-SHAH", "Shah & Sons Jewellers", "Shah Bullion Merchants", "Mumbai", "INSTITUTIONAL", 200_000_000_00L, 400_000_000_00L, 45_000_000_00L, 150000.0, 800000.0, "APPROVED", "MEDIUM"),
            Client("CLI-ANITA", "Anita Sharma", "Individual Customer", "Jaipur", "RETAIL MERCHANT", 0L, 10_000_000_00L, 0L, 0.0, 0.0, "APPROVED", "LOW"),
            Client("CLI-ZAVERI", "Zaveri Bazaar Wholesalers", "Zaveri Bullion Group", "Mumbai", "ELITE", 400_000_000_00L, 800_000_000_00L, 21_000_000_00L, 850000.0, 4200000.0, "APPROVED", "LOW"),
            Client("CLI-GUJARAT", "Surat Refineries Ltd", "Gujarat Refinery", "Surat", "ELITE", 300_000_000_00L, 600_000_000_00L, -5_000_000_00L, 500000.0, 2500000.0, "APPROVED", "LOW")
        )

        // 2. Initial Physical Bars in Vaults
        val initialBars = mutableListOf<BullionBar>()
        val cities = listOf("Mumbai", "Delhi", "Jaipur", "Ahmedabad", "Surat", "Chennai", "Kolkata", "Bengaluru")
        
        // Populate 10 Gold Bars of 1kg (995 fineness) and 10 Gold Bars of 1kg (999.9 fineness)
        for (i in 1..8) {
            val city = cities[i - 1]
            initialBars.add(
                BullionBar(
                    serialNumber = "AU-IND-995-000482${20 + i}",
                    metal = MetalType.GOLD,
                    fineness = Fineness.GOLD_995,
                    grossWeightGrams = 1000.35,
                    refinery = "Synthetic Indian Refinery, Mumbai",
                    productionDate = "14-Feb-2026",
                    assayStatus = "CERTIFIED",
                    location = city,
                    vaultCompartment = "COMP-G-0${i}",
                    owner = "Rajasthan Gold & Silver Pvt Ltd",
                    status = "ALLOCATED",
                    estimatedValueInr = 74_500_000
                )
            )
            initialBars.add(
                BullionBar(
                    serialNumber = "AU-IND-999-000495${10 + i}",
                    metal = MetalType.GOLD,
                    fineness = Fineness.GOLD_9999,
                    grossWeightGrams = 1000.00,
                    refinery = "MMTC-PAMP India",
                    productionDate = "22-May-2026",
                    assayStatus = "CERTIFIED",
                    location = city,
                    vaultCompartment = "COMP-G-0${i}B",
                    owner = "Sharma Jewellers",
                    status = "AVAILABLE",
                    estimatedValueInr = 75_000_000
                )
            )
            // Silver bar of 30kg (999 fineness)
            initialBars.add(
                BullionBar(
                    serialNumber = "AG-IND-999-000281${10 + i}",
                    metal = MetalType.SILVER,
                    fineness = Fineness.SILVER_999,
                    grossWeightGrams = 30000.0,
                    refinery = "Synthetic Indian Refinery, Surat",
                    productionDate = "10-Jan-2026",
                    assayStatus = "CERTIFIED",
                    location = city,
                    vaultCompartment = "COMP-S-1${i}",
                    owner = "Rajasthan Gold & Silver Pvt Ltd",
                    status = "AVAILABLE",
                    estimatedValueInr = 2_820_000
                )
            )
        }
        _bullionBars.value = initialBars

        // 3. Initial HUID database for verification
        _huidRegistry.value = listOf(
            HUIDRecord("AB12CD", "Bridal Gold Necklace", MetalType.GOLD, Fineness.GOLD_916, 38.40, "Jaipur Hallmarking Ltd", "01-Mar-2026", "VERIFIED"),
            HUIDRecord("XY89ZF", "Rajasthani Gold Bangles (Set of 4)", MetalType.GOLD, Fineness.GOLD_916, 64.20, "Surat BIS Centre", "12-May-2026", "VERIFIED"),
            HUIDRecord("KL45MN", "Sterling Silver Tea Set", MetalType.SILVER, Fineness.SILVER_925, 1250.00, "Jaipur Hallmarking Ltd", "18-Jun-2026", "VERIFIED"),
            HUIDRecord("SR77TR", "Fine Gold Ring 18K", MetalType.GOLD, Fineness.GOLD_750, 6.45, "Mumbai BIS Centre", "29-Jul-2026", "VERIFIED")
        )

        // 4. MCX Hedging positions
        _hedgePositions.value = listOf(
            HedgePosition("MCX_GOLD_OCT2026", MetalType.GOLD, "SHORT", 700.0, 7450000L, 7485000L, -24_500_000L),
            HedgePosition("MCX_SILVER_DEC2026", MetalType.SILVER, "SHORT", 12000.0, 9250000L, 9180000L, 8_400_000L)
        )

        // 5. Initial Ledger Setup & Double-Entry Verification (Invariant: Total Debits = Total Credits)
        // Set up starting ledger
        val list = mutableListOf<LedgerEntry>()
        list.add(LedgerEntry(debitAccount = "Cash / Bank at RBI", creditAccount = "Equity Capital", amountPaisa = 4500_000_000_00L, description = "Starting capital reservation", referenceId = "INIT-01", counterparty = "Bullion Treasury"))
        list.add(LedgerEntry(debitAccount = "Zaveri Bazaar Receivable", creditAccount = "Gold Sales Revenue", amountPaisa = 12_450_000_00L, description = "Clearing for institutional gold sale", referenceId = "INIT-02", counterparty = "Zaveri Bazaar Wholesalers"))
        list.add(LedgerEntry(debitAccount = "Gold Sales Revenue", creditAccount = "Zaveri Bazaar Receivable", amountPaisa = 12_450_000_00L, description = "Clearing for institutional gold sale offset", referenceId = "INIT-02", counterparty = "Zaveri Bazaar Wholesalers"))
        _ledgerEntries.value = list

        // 6. Set initial alerts
        _alerts.value = listOf(
            "GOLD INVENTORY WATCH: Current holding ₹842 crore is approaching the limit of ₹900 crore (93.6% utilisation).",
            "BIS ALERT: HUID registry synchronised with NSDL Bureau of Indian Standards master feed.",
            "MCX HEDGE LINKED: Automated short futures established at ₹74,850/10g."
        )
    }

    // --- RECONCILIATION INVARIANT CHECKERS ---
    fun verifyAccountingBalance(): Boolean {
        var totalDebits = 0L
        var totalCredits = 0L
        _ledgerEntries.value.forEach {
            totalDebits += it.amountPaisa
            totalCredits += it.amountPaisa // Since we record matching debit and credit accounts, each ledger entry represents a balanced debit-credit booking
        }
        return totalDebits == totalCredits
    }

    fun verifyMetalInvariants(bar: BullionBar): Boolean {
        // GROSS WEIGHT * PURITY = FINE WEIGHT
        val delta = Math.abs((bar.grossWeightGrams * bar.fineness.purity) - bar.fineWeightGrams)
        return delta < 0.01
    }

    // --- DETERMINISTIC TICKER UPDATE (Simulates Market Fluctuations) ---
    fun tickMarket(multiplier: Double = 1.0002) {
        _goldUsdPerOz.value = _goldUsdPerOz.value * multiplier
        _silverUsdPerOz.value = _silverUsdPerOz.value * (1.0 + (multiplier - 1.0) * 1.5) // Silver is typically more volatile
        _usdInrRate.value = _usdInrRate.value * (1.0 + (Math.random() - 0.5) * 0.0005) // Small forex flutter
        _lastMarketTick.value = dateFormat.format(Date())

        // Recalculate revaluation (Unrealised P&L)
        var totalReval = 0L
        _bullionBars.value.forEach { bar ->
            val ratePerGram = if (bar.metal == MetalType.GOLD) getDerivedGoldSpotPerGramPaisa() else getDerivedSilverSpotPerGramPaisa()
            val baseVal = (bar.fineWeightGrams * (ratePerGram / 100.0)).toLong()
            totalReval += baseVal
        }
        _unrealisedPnlPaisa.value = (totalReval * 0.01).toLong() // 1% simulated variance
    }

    // --- MANUAL SCENARIO SHOCK TEST ---
    fun applyScenarioShock(goldPct: Double, silverPct: Double, usdInrPct: Double, premiumInr: Double) {
        _goldUsdPerOz.value = _goldUsdPerOz.value * (1.0 + goldPct / 100.0)
        _silverUsdPerOz.value = _silverUsdPerOz.value * (1.0 + silverPct / 100.0)
        _usdInrRate.value = _usdInrRate.value * (1.0 + usdInrPct / 100.0)
        _domesticGoldPremiumPer10g.value = _domesticGoldPremiumPer10g.value + premiumInr
        _lastMarketTick.value = dateFormat.format(Date())

        _alerts.value = listOf("SCENARIO LAB: Shock scenario executed. Markets shifted. Portfolio revalued.") + _alerts.value
    }

    // --- DOUBLE ENTRY BOOKKEEPING ENGINE ---
    fun bookTransaction(debitAcc: String, creditAcc: String, amountPaisa: Long, desc: String, refId: String, counterparty: String) {
        val entry = LedgerEntry(
            debitAccount = debitAcc,
            creditAccount = creditAcc,
            amountPaisa = amountPaisa,
            description = desc,
            referenceId = refId,
            counterparty = counterparty
        )
        _ledgerEntries.value = listOf(entry) + _ledgerEntries.value
        
        // Adjust virtual cash balance if transaction involves cash
        if (debitAcc == "Cash / Bank at RBI") {
            _vaultCashBalancePaisa.value += amountPaisa
        } else if (creditAcc == "Cash / Bank at RBI") {
            _vaultCashBalancePaisa.value -= amountPaisa
        }
    }

    // --- QUOTATION ENGINE ---
    fun calculateCommercialPrice(
        metal: MetalType,
        fineness: Fineness,
        weightGrams: Double,
        clientTier: String,
        includeLogistics: Boolean = true,
        includeAssay: Boolean = false,
        includeFabrication: Boolean = false
    ): Map<String, Long> {
        val spotRateGramPaisa = if (metal == MetalType.GOLD) getDerivedGoldSpotPerGramPaisa() else getDerivedSilverSpotPerGramPaisa()
        
        // 1. Purity adjustment
        val basePurityPaisa = (spotRateGramPaisa * fineness.purity).toLong()
        val grossBasePaisa = (basePurityPaisa * weightGrams).toLong()

        // 2. Premium / Discount depending on Client Tier
        val tierAdjustmentFactor = when (clientTier) {
            "ELITE" -> -0.001 // 0.1% discount
            "INSTITUTIONAL" -> 0.000 // Spot
            "RETAIL MERCHANT" -> 0.005 // 0.5% merchant premium
            else -> 0.010 // 1% retail premium
        }
        val premiumDiscountPaisa = (grossBasePaisa * tierAdjustmentFactor).toLong()

        // 3. Logistics
        val logisticsPaisa = if (includeLogistics) {
            if (metal == MetalType.GOLD) {
                ((logisticsChargePerKgGold / 1000.0) * weightGrams * 100.0).toLong()
            } else {
                (3.50 * weightGrams * 100.0).toLong() // Silver logistics INR 3.5/g
            }
        } else 0L

        // 4. Fabrication / Making Charges
        val fabricationPaisa = if (includeFabrication) {
            if (metal == MetalType.GOLD) {
                (fabricationChargeGoldPerGram * weightGrams * 100.0).toLong()
            } else {
                (makingChargeSilverPerGram * weightGrams * 100.0).toLong()
            }
        } else 0L

        // 5. Assay Charges
        val assayPaisa = if (includeAssay) (assayChargePerSample * 100.0).toLong() else 0L

        // Subtotal
        val subtotalPaisa = grossBasePaisa + premiumDiscountPaisa + logisticsPaisa + fabricationPaisa + assayPaisa

        // 6. GST at 3%
        val gstPaisa = (subtotalPaisa * (baseGstPercentage / 100.0)).toLong()

        // Total
        val totalPaisa = subtotalPaisa + gstPaisa

        return mapOf(
            "spot_rate_gram" to spotRateGramPaisa,
            "purity_adjusted_rate" to basePurityPaisa,
            "gross_base" to grossBasePaisa,
            "premium_discount" to premiumDiscountPaisa,
            "logistics" to logisticsPaisa,
            "fabrication" to fabricationPaisa,
            "assay" to assayPaisa,
            "subtotal" to subtotalPaisa,
            "gst" to gstPaisa,
            "total" to totalPaisa
        )
    }

    // --- TRADE EXECUTION ---
    fun executeTrade(
        metal: MetalType,
        fineness: Fineness,
        tradeType: String,
        clientName: String,
        quantityGrams: Double,
        deliveryLocation: String,
        isHedging: Boolean = false
    ): Trade {
        val pricing = calculateCommercialPrice(metal, fineness, quantityGrams, "INSTITUTIONAL", includeLogistics = true)
        
        val basePrice = pricing["purity_adjusted_rate"] ?: 0L
        val gross = pricing["gross_base"] ?: 0L
        val premium = pricing["premium_discount"] ?: 0L
        val gst = pricing["gst"] ?: 0L
        val net = pricing["total"] ?: 0L

        val trade = Trade(
            metal = metal,
            fineness = fineness,
            tradeType = tradeType,
            clientName = clientName,
            quantityGrams = quantityGrams,
            basePricePerGram = basePrice,
            premiumPerGram = premium / quantityGrams.toLong().coerceAtLeast(1L),
            grossValue = gross,
            totalCharges = gst,
            netValue = net,
            settlementDate = docDateFormat.format(Date(System.currentTimeMillis() + 86400000)), // T+1
            deliveryLocation = deliveryLocation,
            status = "SETTLED",
            isHedgingLinked = isHedging,
            hedgeReference = if (isHedging) "MCX-${metal.name}-${UUID.randomUUID().toString().take(4).uppercase()}" else null
        )

        _trades.value = listOf(trade) + _trades.value

        // Execute accounting entries
        if (tradeType == "BUY") {
            // Debit Bullion Inventory, Credit Cash
            bookTransaction(
                debitAcc = "Physical Bullion Stock",
                creditAcc = "Cash / Bank at RBI",
                amountPaisa = net,
                desc = "Purchase of ${quantityGrams}g ${metal.name} from $clientName",
                refId = trade.id,
                counterparty = clientName
            )
            // Add custom physical bar to inventory representing the buy
            val newBar = BullionBar(
                serialNumber = "${if (metal == MetalType.GOLD) "AU" else "AG"}-IND-${fineness.purity.toString().replace(".","")}-${(100000 + (Math.random() * 899999).toInt())}",
                metal = metal,
                fineness = fineness,
                grossWeightGrams = quantityGrams,
                refinery = "MMTC-PAMP Recycled",
                productionDate = docDateFormat.format(Date()),
                assayStatus = "VERIFIED",
                location = deliveryLocation,
                vaultCompartment = "COMP-INCOMING",
                owner = "Rajasthan Gold & Silver Pvt Ltd",
                status = "AVAILABLE",
                estimatedValueInr = (net / 100).toLong()
            )
            _bullionBars.value = listOf(newBar) + _bullionBars.value

        } else {
            // SELL: Credit Inventory, Debit Cash (or Receivable)
            bookTransaction(
                debitAcc = "Cash / Bank at RBI",
                creditAcc = "Physical Bullion Stock",
                amountPaisa = net,
                desc = "Sale of ${quantityGrams}g ${metal.name} to $clientName",
                refId = trade.id,
                counterparty = clientName
            )
            
            // Allocate and deduct physical bar(s) if we have sufficient available bars of this metal
            val matchingBar = _bullionBars.value.firstOrNull { 
                it.metal == metal && it.status == "AVAILABLE" && it.grossWeightGrams >= quantityGrams 
            }
            if (matchingBar != null) {
                // If the bar is larger than quantity, we split it, otherwise we allocate it
                if (matchingBar.grossWeightGrams == quantityGrams) {
                    _bullionBars.value = _bullionBars.value.map {
                        if (it.serialNumber == matchingBar.serialNumber) it.copy(status = "ALLOCATED", owner = clientName) else it
                    }
                } else {
                    // Split bar
                    val updatedBar = matchingBar.copy(grossWeightGrams = matchingBar.grossWeightGrams - quantityGrams, status = "AVAILABLE")
                    val allocatedBar = matchingBar.copy(
                        serialNumber = "${matchingBar.serialNumber}-ALC",
                        grossWeightGrams = quantityGrams,
                        status = "ALLOCATED",
                        owner = clientName
                    )
                    _bullionBars.value = _bullionBars.value.filter { it.serialNumber != matchingBar.serialNumber } + listOf(updatedBar, allocatedBar)
                }
            }
        }

        // Generate Invoice
        val invoice = Invoice(
            date = docDateFormat.format(Date()),
            sellerName = "SWARNA//RAJAT Bullion House, Jaipur",
            buyerName = clientName,
            sellerGst = "GSTIN08AAECS1024K1Z2",
            buyerGst = "GSTIN08BBPDS4829A1Z9",
            metal = metal,
            fineness = fineness,
            weightGrams = quantityGrams,
            ratePerGram = basePrice,
            premium = premium,
            taxValueInr = gst,
            totalAmountInr = net,
            paymentStatus = "PAID",
            settlementStatus = "SETTLED"
        )
        _invoices.value = listOf(invoice) + _invoices.value

        // If MCX hedge linked, update short futures
        if (isHedging) {
            val hedgeSizeKg = quantityGrams / 1000.0
            val newHedge = HedgePosition(
                contractSymbol = "MCX_${metal.name}_OCT2026",
                metal = metal,
                positionType = "SHORT",
                sizeKg = hedgeSizeKg,
                entryPrice = basePrice,
                currentPrice = basePrice,
                unrealisedPnlInr = 0L
            )
            _hedgePositions.value = listOf(newHedge) + _hedgePositions.value
            _alerts.value = listOf("HEDGING AT MCX: Opened short cover of ${hedgeSizeKg}kg for ${metal.name} spot offset.") + _alerts.value
        }

        return trade
    }

    // --- RE-SEED / RESET DEMO STATES ---
    fun resetToDemoState() {
        initializeSeedData()
        _goldUsdPerOz.value = 2635.50
        _silverUsdPerOz.value = 31.45
        _usdInrRate.value = 83.45
        _domesticGoldPremiumPer10g.value = 2400.0
        _domesticSilverPremiumPerKg.value = 1850.0
        _vaultCashBalancePaisa.value = 4500_000_000_00L
        _realisedPnlPaisa.value = 12_450_000_00L
    }

    // --- HUID REGISTER SERVICE ---
    fun verifyHuidCode(code: String): HUIDRecord? {
        val uppercaseCode = code.trim().uppercase()
        val record = _huidRegistry.value.firstOrNull { it.huid == uppercaseCode }
        if (record != null) return record
        
        // Generate a mock record deterministically if code matches length rules to simulate broad database
        if (uppercaseCode.length == 6) {
            val isGold = uppercaseCode.startsWith("A") || uppercaseCode.startsWith("B") || uppercaseCode.startsWith("K")
            val metal = if (isGold) MetalType.GOLD else MetalType.SILVER
            val fineness = if (isGold) Fineness.GOLD_916 else Fineness.SILVER_925
            val weight = if (isGold) 12.50 else 180.0
            val recordNew = HUIDRecord(
                huid = uppercaseCode,
                articleType = if (isGold) "Fine Gold Ring 22K" else "Silver Ornate Bangle",
                metal = metal,
                fineness = fineness,
                grossWeightGrams = weight,
                assayCentre = "Jaipur Regional BIS Centre",
                dateHallmarked = docDateFormat.format(Date(System.currentTimeMillis() - 482000000)),
                verificationStatus = "VERIFIED"
            )
            _huidRegistry.value = _huidRegistry.value + recordNew
            return recordNew
        }
        return null
    }

    // --- OLD GOLD SCRAP CALCULATION ---
    fun processOldGoldScrap(
        articleName: String,
        grossWeight: Double,
        assayedPurity: Double,
        customerName: String
    ): Map<String, Any> {
        val metal = MetalType.GOLD
        // Find closest Fineness
        val fineness = Fineness.values().filter { it.purity > 0.5 && it.purity < 0.999 }.minByOrNull { Math.abs(it.purity - assayedPurity) } ?: Fineness.GOLD_916
        
        val spotRate = getDerivedGoldSpotPerGramPaisa()
        val fineWeight = grossWeight * assayedPurity
        val referenceValuePaisa = (fineWeight * spotRate).toLong()
        
        // Scrap deductions: 1.5% refinery melting loss, 1% commission
        val meltingLossPaisa = (referenceValuePaisa * 0.015).toLong()
        val commissionPaisa = (referenceValuePaisa * 0.010).toLong()
        val netPayoutPaisa = referenceValuePaisa - meltingLossPaisa - commissionPaisa

        val cert = AssayCertificate(
            sampleCode = "SAMP-${UUID.randomUUID().toString().take(6).uppercase()}",
            metal = metal,
            grossWeight = grossWeight,
            fineWeight = fineWeight,
            verifiedPurity = assayedPurity,
            method = "XRF Spectrometer Analysis",
            assayCentre = "Jaipur Bullion Assay Lab",
            assayerName = "P. Sharma, Chief Assayer",
            dateCertified = docDateFormat.format(Date()),
            result = "CONFORMS"
        )

        _assayCertificates.value = listOf(cert) + _assayCertificates.value

        return mapOf(
            "certificate" to cert,
            "fine_weight" to fineWeight,
            "spot_rate_gram" to spotRate,
            "gross_value" to referenceValuePaisa,
            "melting_loss" to meltingLossPaisa,
            "commission" to commissionPaisa,
            "net_payout" to netPayoutPaisa
        )
    }

    // --- BRIDAL JEWELLERY MANUFACTURING (Jaipur Workshop Converter) ---
    fun manufacture22KJewellery(
        rawGoldGrams9999: Double,
        wastagePercentage: Double,
        articleName: String
    ): Map<String, Any> {
        // Convert pure gold (999.9) to 22K jewellery alloy (91.6% pure gold, remaining alloy)
        // Weight of 22K alloy = (Raw Gold Weight * 0.9999) / 0.916
        val pureGoldWeight = rawGoldGrams9999 * 0.9999
        val resulting22KWeight = pureGoldWeight / 0.916
        val finalWeightMinusWastage = resulting22KWeight * (1.0 - (wastagePercentage / 100.0))

        // Create a unique HUID for this finished piece
        val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val numbers = "0123456789"
        val randomHuid = "" + letters[(Math.random() * 26).toInt()] + letters[(Math.random() * 26).toInt()] +
                numbers[(Math.random() * 10).toInt()] + numbers[(Math.random() * 10).toInt()] +
                letters[(Math.random() * 26).toInt()] + letters[(Math.random() * 26).toInt()]

        val newHuid = HUIDRecord(
            huid = randomHuid,
            articleType = articleName,
            metal = MetalType.GOLD,
            fineness = Fineness.GOLD_916,
            grossWeightGrams = finalWeightMinusWastage,
            assayCentre = "Jaipur Regional BIS Centre",
            dateHallmarked = docDateFormat.format(Date()),
            verificationStatus = "VERIFIED"
        )
        _huidRegistry.value = listOf(newHuid) + _huidRegistry.value

        _alerts.value = listOf("WORKSHOP: Manufactured 22K $articleName. BIS Hallmarked with HUID $randomHuid.") + _alerts.value

        return mapOf(
            "huid_record" to newHuid,
            "pure_gold_used" to rawGoldGrams9999,
            "fine_gold_content" to pureGoldWeight,
            "finished_weight" to finalWeightMinusWastage,
            "wastage_grams" to (resulting22KWeight * (wastagePercentage / 100.0)),
            "huid" to randomHuid
        )
    }

    // --- SWARNA AI RESPOND ENGINE (Rule-Based & Direct Collection Parsing) ---
    fun querySwarnaAI(question: String, lang: Language): String {
        val q = question.lowercase().trim()
        val isHi = lang == Language.HINDI

        return when {
            q.contains("gold exposure") || q.contains("exposure") || q.contains("एक्सपोजर") || q.contains("सोने का एक्सपोज़र") -> {
                val totalBars = _bullionBars.value.filter { it.metal == MetalType.GOLD }
                val totalGrams = totalBars.sumOf { it.fineWeightGrams }
                val totalValueInr = (totalGrams * (getDerivedGoldSpotPerGramPaisa() / 100.0)).toLong()
                val valueCrore = totalValueInr / 10000000.0
                
                if (isHi) {
                    "स्वर्ण // रजत का कुल सोने का एक्सपोज़र ${"%,.2f".format(totalGrams / 1000.0)} किलोग्राम है। कुल अनुमानित मूल्य ₹${"%,.2f".format(valueCrore)} करोड़ है।"
                } else {
                    "Swarna Rajat's total gold exposure is ${"%,.2f".format(totalGrams / 1000.0)} kg across all vaults. Total estimated holding value is ₹${"%,.2f".format(valueCrore)} Crore."
                }
            }
            q.contains("silver in mumbai") || q.contains("mumbai") || q.contains("मुंबई") || q.contains("चाँदी") -> {
                val mumbaiSilver = _bullionBars.value.filter { it.metal == MetalType.SILVER && it.location.lowercase().contains("mumbai") }
                val weightKg = mumbaiSilver.sumOf { it.grossWeightGrams } / 1000.0
                val totalVal = (weightKg * 1000.0 * (getDerivedSilverSpotPerGramPaisa() / 100.0)).toLong()
                
                if (isHi) {
                    "मुंबई तिजोरी में कुल ${"%,.2f".format(weightKg)} किलोग्राम चाँदी उपलब्ध है। इसका कुल मूल्य ₹${"%,.2f".format(totalVal / 100000.0)} लाख है।"
                } else {
                    "Mumbai Vault holds a total of ${"%,.2f".format(weightKg)} kg of fine silver bullion. The estimated physical value is ₹${"%,.2f".format(totalVal / 100000.0)} Lakh."
                }
            }
            q.contains("shah & sons") || q.contains("shah") || q.contains("बकाया") -> {
                val client = _clients.value.firstOrNull { it.id == "CLI-SHAH" }
                val balanceInr = (client?.outstandingBalanceInr ?: 0L) / 100L
                if (isHi) {
                    "Shah & Sons Jewellers का वर्तमान बकाया निपटान ₹${"%,.2f".format(balanceInr.toDouble())} है।"
                } else {
                    "Shah & Sons Jewellers' current outstanding settlement balance is ₹${"%,.2f".format(balanceInr.toDouble())}."
                }
            }
            q.contains("largest gold position") || q.contains("largest") || q.contains("बड़े") -> {
                val sorted = _clients.value.sortedByDescending { it.goldPositionGrams }.take(2)
                val responseEn = "Clients with largest gold positions:\n" + sorted.joinToString("\n") { 
                    "- ${it.name}: ${"%,.2f".format(it.goldPositionGrams / 1000.0)} kg holdings (City: ${it.city})"
                }
                val responseHi = "सबसे बड़ी सोने की पोजीशन वाले ग्राहक:\n" + sorted.joinToString("\n") { 
                    "- ${it.name}: ${"%,.2f".format(it.goldPositionGrams / 1000.0)} किलोग्राम (शहर: ${it.city})"
                }
                if (isHi) responseHi else responseEn
            }
            q.contains("unallocated") || q.contains("available") || q.contains("बिना आवंटित") -> {
                val unallocatedCount = _bullionBars.value.filter { it.status == "AVAILABLE" }.size
                val unallocatedGoldKg = _bullionBars.value.filter { it.status == "AVAILABLE" && it.metal == MetalType.GOLD }.sumOf { it.grossWeightGrams } / 1000.0
                val unallocatedSilverKg = _bullionBars.value.filter { it.status == "AVAILABLE" && it.metal == MetalType.SILVER }.sumOf { it.grossWeightGrams } / 1000.0
                
                if (isHi) {
                    "कुल $unallocatedCount अनअलोकेटेड बुलियन बार उपलब्ध हैं। इसमें सोने का वज़न ${"%,.2f".format(unallocatedGoldKg)} किलोग्राम और चाँदी का वज़न ${"%,.2f".format(unallocatedSilverKg)} किलोग्राम है।"
                } else {
                    "We have $unallocatedCount unallocated bars ready in inventory. This includes ${"%,.2f".format(unallocatedGoldKg)} kg of Gold and ${"%,.2f".format(unallocatedSilverKg)} kg of Silver."
                }
            }
            q.contains("p&l") || q.contains("profit") || q.contains("लाभ") -> {
                val realised = _realisedPnlPaisa.value / 100.0
                val unrealised = _unrealisedPnlPaisa.value / 100.0
                val total = realised + unrealised
                
                if (isHi) {
                    "आज का लाभ विवरण:\n- वास्तविक लाभ (Realised): ₹${"%,.2f".format(realised)}\n- अवास्तविक लाभ (Unrealised): ₹${"%,.2f".format(unrealised)}\n- कुल लाभ (Net P&L): ₹${"%,.2f".format(total)}"
                } else {
                    "Today's P&L Attribution:\n- Realised P&L: ₹${"%,.2f".format(realised)}\n- Unrealised Portfolio Revaluation: ₹${"%,.2f".format(unrealised)}\n- Net P&L: ₹${"%,.2f".format(total)}"
                }
            }
            else -> {
                if (isHi) {
                    "नमस्ते। मैं स्वर्ण एआई (Swarna AI) हूँ, आपका डिजिटल बुलियन ट्रेजरी सहायक। कृपया मुझसे संपर्क करें: एक्सपोज़र, तिजोरी भंडार, निपटान या लाभ से संबंधित प्रश्न पूछें।"
                } else {
                    "Greetings. I am Swarna AI, your bespoke treasury and dealer assistant. Ask me about our gold exposure, Mumbai vault holdings, client accounts, or today's P&L ledger."
                }
            }
        }
    }
}
