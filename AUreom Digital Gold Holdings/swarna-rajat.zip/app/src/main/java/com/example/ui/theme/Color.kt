package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Swarna Rajat High-Prestige Color Palette
val DeepCharcoal = Color(0xFF121212)
val SlateGrey = Color(0xFF1E1E1E)
val WarmIvory = Color(0xFFFAF9F6)
val SoftWhite = Color(0xFFFFFFFF)

val AntiqueGold = Color(0xFFD4AF37)
val MutedBrass = Color(0xFFC5A059)
val DeepMaroon = Color(0xFF800020)
val DarkEmerald = Color(0xFF0F5257)
val SaffronAccent = Color(0xFFFF9933)

val TextGold = Color(0xFFF3E5AB)
val TextDark = Color(0xFF212121)
val TextLight = Color(0xFFE0E0E0)

val ErrorRed = Color(0xFFD32F2F)
val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFEF6C00)
