package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AntiqueGold,
    secondary = MutedBrass,
    tertiary = SaffronAccent,
    background = DeepCharcoal,
    surface = SlateGrey,
    onPrimary = DeepCharcoal,
    onSecondary = DeepCharcoal,
    onBackground = WarmIvory,
    onSurface = WarmIvory,
    error = ErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = DeepMaroon,
    secondary = MutedBrass,
    tertiary = AntiqueGold,
    background = WarmIvory,
    surface = SoftWhite,
    onPrimary = SoftWhite,
    onSecondary = SoftWhite,
    onBackground = DeepCharcoal,
    onSurface = DeepCharcoal,
    error = ErrorRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep theme bespoke and luxury, disable Android 12 wallpaper color overrides
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
