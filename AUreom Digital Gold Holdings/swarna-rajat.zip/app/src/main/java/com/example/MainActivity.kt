package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SimulationEngine
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DeepCharcoal
                ) { innerPadding ->
                    SwarnaRajatApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

enum class Screen {
    HOME, MARKET, DEALER, MERCHANT, RISK, SWARNA_AI, HUID_VERIFY
}

@Composable
fun SwarnaRajatApp(modifier: Modifier = Modifier) {
    val coroutineScope = rememberCoroutineScope()

    // Observe language & simulation states
    val currentLanguage by SimulationEngine.currentLanguage.collectAsState()
    val goldPriceUsd by SimulationEngine.goldUsdPerOz.collectAsState()
    val silverPriceUsd by SimulationEngine.silverUsdPerOz.collectAsState()
    val usdInrRate by SimulationEngine.usdInrRate.collectAsState()
    val goldPremium by SimulationEngine.domesticGoldPremiumPer10g.collectAsState()
    val silverPremium by SimulationEngine.domesticSilverPremiumPerKg.collectAsState()

    val clients by SimulationEngine.clients.collectAsState()
    val bars by SimulationEngine.bullionBars.collectAsState()
    val trades by SimulationEngine.trades.collectAsState()
    val invoices by SimulationEngine.invoices.collectAsState()
    val ledgerEntries by SimulationEngine.ledgerEntries.collectAsState()
    val alerts by SimulationEngine.alerts.collectAsState()
    val cashBalance by SimulationEngine.vaultCashBalancePaisa.collectAsState()
    val realisedPnl by SimulationEngine.realisedPnlPaisa.collectAsState()
    val unrealisedPnl by SimulationEngine.unrealisedPnlPaisa.collectAsState()
    val lastTickTime by SimulationEngine.lastMarketTick.collectAsState()

    var activeScreen by remember { mutableStateOf(Screen.HOME) }
    var showActiveInvoice by remember { mutableStateOf<Invoice?>(null) }

    // Ticker Background Loop to simulate active market feed
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            // Gently fluctuate prices (e.g. slight up-and-down noise)
            val fluctuation = 1.0 + (Math.random() - 0.495) * 0.001
            SimulationEngine.tickMarket(fluctuation)
        }
    }

    // Support standard Android back button navigation to pop back to main home
    if (activeScreen != Screen.HOME) {
        BackHandler {
            activeScreen = Screen.HOME
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepCharcoal)
    ) {
        // --- LUXURY BRAND HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateGrey)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_swarna_logo),
                    contentDescription = "Swarna Logo",
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "SWARNA//RAJAT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AntiqueGold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "स्वर्ण // रजत",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MutedBrass,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            // Quick Toggle: English <-> Hindi
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Cash summary in header
                Text(
                    text = "Cash: ₹${"%,.2f".format(cashBalance / 100_00000.0)} Cr",
                    style = MaterialTheme.typography.labelMedium.copy(color = AntiqueGold),
                    modifier = Modifier.padding(end = 8.dp)
                )

                IconButton(
                    onClick = {
                        val nextLang = if (currentLanguage == Language.ENGLISH) Language.HINDI else Language.ENGLISH
                        SimulationEngine.setLanguage(nextLang)
                    },
                    modifier = Modifier
                        .border(1.dp, AntiqueGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .size(36.dp)
                        .testTag("language_toggle_button")
                ) {
                    Text(
                        text = if (currentLanguage == Language.ENGLISH) "हि" else "EN",
                        color = AntiqueGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Live Market Alert Banner if available
        if (alerts.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepMaroon)
                    .padding(vertical = 4.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Alert icon",
                    tint = SaffronAccent,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = alerts.first(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = WarmIvory,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1
                )
            }
        }

        // --- SUB SCREEN RENDERER WITH TRANSITIONS ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeScreen) {
                Screen.HOME -> HomeScreen(
                    language = currentLanguage,
                    goldPricePaisa = SimulationEngine.getDerivedGoldSpotPerGramPaisa(),
                    silverPricePaisa = SimulationEngine.getDerivedSilverSpotPerGramPaisa(),
                    goldUsd = goldPriceUsd,
                    silverUsd = silverPriceUsd,
                    goldPremium = goldPremium,
                    silverPremium = silverPremium,
                    lastTick = lastTickTime,
                    realised = realisedPnl,
                    unrealised = unrealisedPnl,
                    bars = bars,
                    ledgerEntries = ledgerEntries,
                    onNavigate = { activeScreen = it },
                    onBuyGoldSellGoldTrigger = { activeScreen = Screen.DEALER }
                )
                Screen.MARKET -> MarketTerminalScreen(
                    language = currentLanguage,
                    goldSpotPaisa = SimulationEngine.getDerivedGoldSpotPerGramPaisa(),
                    silverSpotPaisa = SimulationEngine.getDerivedSilverSpotPerGramPaisa(),
                    goldUsd = goldPriceUsd,
                    silverUsd = silverPriceUsd,
                    usdInr = usdInrRate,
                    goldPremium = goldPremium,
                    silverPremium = silverPremium
                )
                Screen.DEALER -> DealerTerminalScreen(
                    language = currentLanguage,
                    onInvoiceGenerated = { showActiveInvoice = it }
                )
                Screen.MERCHANT -> MerchantWorkshopsScreen(
                    language = currentLanguage,
                    bars = bars,
                    onInvoiceGenerated = { showActiveInvoice = it }
                )
                Screen.RISK -> RiskMonitorScreen(
                    language = currentLanguage
                )
                Screen.SWARNA_AI -> SwarnaAIChatScreen(
                    language = currentLanguage
                )
                Screen.HUID_VERIFY -> HUIDVerifyScreen(
                    language = currentLanguage
                )
            }

            // Floating Overlaid Invoice Dialog if active
            showActiveInvoice?.let { invoice ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.8f))
                        .clickable(enabled = true, onClick = {}) // Block background clicks
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    InvoiceReceiptView(
                        invoice = invoice,
                        language = currentLanguage,
                        onClose = { showActiveInvoice = null }
                    )
                }
            }
        }

        // --- PRESTIGE BOTTOM NAVIGATION BAR ---
        NavigationBar(
            containerColor = SlateGrey,
            tonalElevation = 8.dp,
            modifier = Modifier.drawBehind {
                drawLine(
                    color = MutedBrass.copy(alpha = 0.3f),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1f
                )
            }
        ) {
            val navItems = listOf(
                Triple(Screen.HOME, Icons.Default.Dashboard, "Home"),
                Triple(Screen.MARKET, Icons.Default.TrendingUp, "Market"),
                Triple(Screen.DEALER, Icons.Default.Call, "Dealer"),
                Triple(Screen.MERCHANT, Icons.Default.HomeWork, "Merchant"),
                Triple(Screen.RISK, Icons.Default.Shield, "Risk"),
                Triple(Screen.SWARNA_AI, Icons.Default.SupportAgent, "AI Dealer"),
                Triple(Screen.HUID_VERIFY, Icons.Default.Verified, "BIS HUID")
            )

            navItems.forEach { (screen, icon, label) ->
                val selected = activeScreen == screen
                NavigationBarItem(
                    selected = selected,
                    onClick = { activeScreen = screen },
                    icon = {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (selected) AntiqueGold else Color.Gray
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == Language.ENGLISH) label else getHindiLabel(screen),
                            fontSize = 9.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) AntiqueGold else Color.Gray
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = DeepMaroon.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                )
            }
        }
    }
}

// Hindi translations for bottom bar labels
private fun getHindiLabel(screen: Screen): String {
    return when (screen) {
        Screen.HOME -> "मुख्य द्वार"
        Screen.MARKET -> "बाज़ार"
        Screen.DEALER -> "डीलर"
        Screen.MERCHANT -> "व्यापारी"
        Screen.RISK -> "जोखिम"
        Screen.SWARNA_AI -> "स्वर्ण एआई"
        Screen.HUID_VERIFY -> "HUID"
    }
}

// ==========================================
// SCREEN 1: HOME PRESTIGE TRADING DASHBOARD
// ==========================================
@Composable
fun HomeScreen(
    language: Language,
    goldPricePaisa: Long,
    silverPricePaisa: Long,
    goldUsd: Double,
    silverUsd: Double,
    goldPremium: Double,
    silverPremium: Double,
    lastTick: String,
    realised: Long,
    unrealised: Long,
    bars: List<BullionBar>,
    ledgerEntries: List<LedgerEntry>,
    onNavigate: (Screen) -> Unit,
    onBuyGoldSellGoldTrigger: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Market Status Header widget
        item {
            MarketStatusHeader(
                language = language,
                marketOpen = true,
                timestamp = lastTick
            )
        }

        // Quick Spot rate cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Gold widget
                Column(modifier = Modifier.weight(1f)) {
                    MetalPriceCard(
                        metal = MetalType.GOLD,
                        spotRateGramPaisa = goldPricePaisa,
                        usdPerOz = goldUsd,
                        premiumPerGramInr = goldPremium,
                        language = language,
                        onBuyClicked = onBuyGoldSellGoldTrigger,
                        onSellClicked = onBuyGoldSellGoldTrigger
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Silver widget
                Column(modifier = Modifier.weight(1f)) {
                    MetalPriceCard(
                        metal = MetalType.SILVER,
                        spotRateGramPaisa = silverPricePaisa,
                        usdPerOz = silverUsd,
                        premiumPerGramInr = silverPremium,
                        language = language,
                        onBuyClicked = onBuyGoldSellGoldTrigger,
                        onSellClicked = onBuyGoldSellGoldTrigger
                    )
                }
            }
        }

        // Canvas Drawing: Spot Price Analytical Chart (No web browser/D3, pure Android Canvas!)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = SlateGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1D Spot Price Analytics Trend (Simulated)",
                        style = MaterialTheme.typography.titleSmall.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Simple deterministic line representation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .drawBehind {
                                val path = Path()
                                val points = listOf(20f, 45f, 35f, 75f, 60f, 90f, 85f, 120f, 105f)
                                val widthStep = size.width / (points.size - 1)
                                
                                points.forEachIndexed { idx, value ->
                                    // Scale to fit canvas height nicely
                                    val x = idx * widthStep
                                    val y = size.height - (value * (size.height / 150f))
                                    if (idx == 0) {
                                        path.moveTo(x, y)
                                    } else {
                                        path.lineTo(x, y)
                                    }
                                }
                                drawPath(
                                    path = path,
                                    color = AntiqueGold,
                                    style = Stroke(width = 3.dp.toPx())
                                )
                                // Draw baseline
                                drawLine(
                                    color = Color.Gray.copy(alpha = 0.3f),
                                    start = Offset(0f, size.height),
                                    end = Offset(size.width, size.height),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }
                    )
                }
            }
        }

        // P&L Attribution & Ledger Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = SlateGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (language == Language.ENGLISH) "PRESTIGE TREASURY METRICS" else "ट्रेजरी वित्तीय स्थिति",
                        style = MaterialTheme.typography.titleSmall.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("REALISED P&L", style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f)))
                            Text("₹${"%,.2f".format(realised / 100.0)}", style = MaterialTheme.typography.bodyLarge.copy(color = SuccessGreen, fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("UNREALISED REVAL", style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.6f)))
                            Text("₹${"%,.2f".format(unrealised / 100.0)}", style = MaterialTheme.typography.bodyLarge.copy(color = SaffronAccent, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Double entry book section
        item {
            LedgerBookView(
                ledgerEntries = ledgerEntries,
                language = language
            )
        }
    }
}

// ==========================================
// SCREEN 2: MARKET TERMINAL
// ==========================================
@Composable
fun MarketTerminalScreen(
    language: Language,
    goldSpotPaisa: Long,
    silverSpotPaisa: Long,
    goldUsd: Double,
    silverUsd: Double,
    usdInr: Double,
    goldPremium: Double,
    silverPremium: Double
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("GOLD", "SILVER", "MCX FUTURES")

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SlateGrey,
            contentColor = AntiqueGold
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                0 -> MarketFinenessGrid(MetalType.GOLD, goldSpotPaisa, usdInr, language)
                1 -> MarketFinenessGrid(MetalType.SILVER, silverSpotPaisa, usdInr, language)
                2 -> McxFuturesPanel(language)
            }
        }
    }
}

@Composable
fun MarketFinenessGrid(
    metal: MetalType,
    baseSpotPaisa: Long,
    usdInr: Double,
    language: Language
) {
    val list = if (metal == MetalType.GOLD) {
        listOf(Fineness.GOLD_9999, Fineness.GOLD_999, Fineness.GOLD_995, Fineness.GOLD_916, Fineness.GOLD_750, Fineness.GOLD_585)
    } else {
        listOf(Fineness.SILVER_999, Fineness.SILVER_990, Fineness.SILVER_970, Fineness.SILVER_925, Fineness.SILVER_800)
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(
                text = "Simulated Purity-Adjusted Valuation Matrix (USD/INR = $usdInr)",
                style = MaterialTheme.typography.labelSmall.copy(color = MutedBrass, fontWeight = FontWeight.Bold)
            )
        }
        items(list) { fineness ->
            val rateGram = (baseSpotPaisa * fineness.purity) / 100.0
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateGrey),
                modifier = Modifier.fillMaxWidth().border(0.5.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = fineness.displayLabel,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = WarmIvory)
                        )
                        Text(
                            text = "BIS Recognised Fineness: ${(fineness.purity * 1000).toInt()}/1000",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₹${"%,.2f".format(rateGram)} / g",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = AntiqueGold)
                        )
                        Text(
                            text = "₹${"%,.2f".format(rateGram * (if (metal == MetalType.GOLD) 10.0 else 1000.0))} / ${if (metal == MetalType.GOLD) "10g" else "kg"}",
                            style = MaterialTheme.typography.labelSmall.copy(color = SaffronAccent)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun McxFuturesPanel(language: Language) {
    val positions by SimulationEngine.hedgePositions.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(
                text = "MCX-Style Bullion Derivative Hedging Contracts",
                style = MaterialTheme.typography.titleSmall.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
            )
        }

        items(positions) { pos ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateGrey),
                modifier = Modifier.fillMaxWidth().border(0.5.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(pos.contractSymbol, fontWeight = FontWeight.Bold, color = SaffronAccent)
                        Box(
                            modifier = Modifier
                                .background(ErrorRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(pos.positionType, color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CONTRACT SIZE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text("${pos.sizeKg} kg", style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("UNREALISED COV HEDGE P&L", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(
                                "₹${"%,.2f".format(pos.unrealisedPnlInr / 100.0)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (pos.unrealisedPnlInr >= 0) SuccessGreen else ErrorRed
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 3: PROFESSIONAL BULLION DEALER TERMINAL
// ==========================================
@Composable
fun DealerTerminalScreen(
    language: Language,
    onInvoiceGenerated: (Invoice) -> Unit
) {
    var metalType by remember { mutableStateOf(MetalType.GOLD) }
    var selectedFineness by remember { mutableStateOf(Fineness.GOLD_999) }
    var tradeType by remember { mutableStateOf("SELL") } // WE SELL to client or WE BUY from client
    var quantityGramsText by remember { mutableStateOf("500") }
    var clientSelected by remember { mutableStateOf("Shah & Sons Jewellers") }

    // Interactivity: Rajasthan Bullion House Multi-Step Demo controller
    var demoStep by remember { mutableStateOf(0) }
    var demoStatusText by remember { mutableStateOf("Rajasthan Bullion Private Ltd is holding 2,500kg Gold and 15,000kg Silver.") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. THE DEALER STEP-BY-STEP SIMULATION INTERACTIVE COMPONENT ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, AntiqueGold, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BULLION DEALER SCENARIO ROOM (DEMO)",
                    style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Rajasthan Gold & Silver Private Limited Demo Case",
                    style = MaterialTheme.typography.labelSmall.copy(color = MutedBrass)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = demoStatusText,
                    style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Action Step button
                Button(
                    onClick = {
                        when (demoStep) {
                            0 -> {
                                demoStep = 1
                                SimulationEngine.applyScenarioShock(2.4, 0.0, 0.0, 0.0) // Gold rises +2.4%
                                demoStatusText = "Step 1 Executed: International Gold rises +2.4%! Spot rate revalued. Click next to receive the 500kg wholesale purchase order request."
                            }
                            1 -> {
                                demoStep = 2
                                demoStatusText = "Step 2 Executed: Shah & Sons requests quote for buying 500kg (500,000g) Gold 999. Pricing generated via commercial calculation. Click next to execute."
                            }
                            2 -> {
                                demoStep = 3
                                val trade = SimulationEngine.executeTrade(
                                    MetalType.GOLD,
                                    Fineness.GOLD_999,
                                    "SELL",
                                    "Shah & Sons Jewellers",
                                    500000.0,
                                    "Mumbai Vault",
                                    isHedging = true
                                )
                                demoStatusText = "Step 3 Executed: Trade executed! Gross Value booked in double-entry. MCX Hedge initiated. Cash receivable updated. Invoice INV-${trade.id} generated!"
                            }
                            3 -> {
                                demoStep = 0
                                SimulationEngine.resetToDemoState()
                                demoStatusText = "Simulation completed & reset. Rajasthan Gold & Silver Pvt Ltd inventory restored."
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold),
                    modifier = Modifier.fillMaxWidth().testTag("dealer_demo_trigger"),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = when (demoStep) {
                            0 -> "Execute: Gold Price Rises +2.4%"
                            1 -> "Receive Shah & Sons Order (500kg)"
                            2 -> "Approve & Execute Wholesale Trade"
                            else -> "Reset Scenario State"
                        },
                        color = DeepCharcoal,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // --- 2. THE ORDER BOOK TICKET ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "OTC ORDER TICKET",
                    style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Metal Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(MetalType.GOLD, MetalType.SILVER).forEach { m ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (metalType == m) DeepMaroon else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .border(1.dp, AntiqueGold, RoundedCornerShape(4.dp))
                                .clickable {
                                    metalType = m
                                    selectedFineness = if (m == MetalType.GOLD) Fineness.GOLD_999 else Fineness.SILVER_999
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(m.name, color = AntiqueGold, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Trade Action Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("SELL", "BUY").forEach { t ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (tradeType == t) (if (t == "BUY") SuccessGreen else SaffronAccent) else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .border(1.dp, Color.Gray, RoundedCornerShape(4.dp))
                                .clickable { tradeType = t }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(t, color = if (tradeType == t) DeepCharcoal else WarmIvory, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity Textfield
                OutlinedTextField(
                    value = quantityGramsText,
                    onValueChange = { quantityGramsText = it },
                    label = { Text("Quantity (Grams)", color = TextLight) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("dealer_quantity_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Confirm Action Button
                Button(
                    onClick = {
                        val grams = quantityGramsText.toDoubleOrNull() ?: 100.0
                        val trade = SimulationEngine.executeTrade(
                            metal = metalType,
                            fineness = selectedFineness,
                            tradeType = tradeType,
                            clientName = clientSelected,
                            quantityGrams = grams,
                            deliveryLocation = "Jaipur Vault",
                            isHedging = true
                        )
                        // Trigger invoice callback
                        val pricing = SimulationEngine.calculateCommercialPrice(metalType, selectedFineness, grams, "INSTITUTIONAL")
                        val inv = Invoice(
                            date = "05-Oct-2026",
                            sellerName = "SWARNA//RAJAT Bullion, Jaipur",
                            buyerName = clientSelected,
                            sellerGst = "GSTIN08AAECS1024K1Z2",
                            buyerGst = "GSTIN08BBPDS4829A1Z9",
                            metal = metalType,
                            fineness = selectedFineness,
                            weightGrams = grams,
                            ratePerGram = pricing["purity_adjusted_rate"] ?: 0L,
                            premium = pricing["premium_discount"] ?: 0,
                            taxValueInr = pricing["gst"] ?: 0,
                            totalAmountInr = pricing["total"] ?: 0,
                            paymentStatus = "PAID",
                            settlementStatus = "SETTLED"
                        )
                        onInvoiceGenerated(inv)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("dealer_confirm_trade_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                ) {
                    Text("CONFIRM TRADE TICKET", color = DeepCharcoal, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// SCREEN 4: MERCHANT & WORKSHOPS SCREEN
// ==========================================
@Composable
fun MerchantWorkshopsScreen(
    language: Language,
    bars: List<BullionBar>,
    onInvoiceGenerated: (Invoice) -> Unit
) {
    var workshopStep by remember { mutableStateOf(0) }
    var workshopOutput by remember { mutableStateOf("") }
    
    // Anita old gold state
    var scrapWeightText by remember { mutableStateOf("38.40") }
    var scrapPayoutResult by remember { mutableStateOf<Map<String, Any>?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. SHARMA JEWELLERS JAIPUR WORKSHOP (RAW GOLD TO 22K JEWELLERY) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "JAIPUR WORKSHOP (SHARMA JEWELLERS)",
                    style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Convert Raw 999.9 Gold into 22K Bridal Ornaments",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (workshopStep == 0) "Sharma Jewellers has 10kg pure gold raw bars available in vault. Ready to alloy into jewellery?" else workshopOutput,
                    style = MaterialTheme.typography.bodySmall.copy(color = WarmIvory)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (workshopStep == 0) {
                            val res = SimulationEngine.manufacture22KJewellery(
                                rawGoldGrams9999 = 1000.0, // 1kg of pure gold
                                wastagePercentage = 1.2,
                                articleName = "Royal Kundan Bridal Necklace"
                            )
                            val finishedWeight = res["finished_weight"] as Double
                            val huid = res["huid"] as String
                            workshopOutput = "Alloying Completed! Raw 1,000g of pure gold converted to Finished 22K Royal Kundan Necklace.\n" +
                                    "- Finished Weight: ${"%.2f".format(finishedWeight)}g (1.2% manufacturing loss included)\n" +
                                    "- BIS Hallmark registered with HUID: $huid!\n" +
                                    "Ready to generate retail invoice to customer."
                            workshopStep = 1
                        } else {
                            // Reset & Generate invoice
                            val pricing = SimulationEngine.calculateCommercialPrice(
                                MetalType.GOLD,
                                Fineness.GOLD_916,
                                1078.0,
                                "RETAIL MERCHANT",
                                includeLogistics = false,
                                includeFabrication = true
                            )
                            val inv = Invoice(
                                date = "05-Oct-2026",
                                sellerName = "Sharma Jewellers, Jaipur",
                                buyerName = "Mrs. Archana Devi",
                                sellerGst = "GSTIN08SSW4829K1Z5",
                                buyerGst = "GSTIN08CLIENTV829A",
                                metal = MetalType.GOLD,
                                fineness = Fineness.GOLD_916,
                                weightGrams = 1078.0,
                                ratePerGram = pricing["purity_adjusted_rate"] ?: 0L,
                                premium = pricing["fabrication"] ?: 0L,
                                taxValueInr = pricing["gst"] ?: 0L,
                                totalAmountInr = pricing["total"] ?: 0L,
                                paymentStatus = "PAID",
                                settlementStatus = "SETTLED"
                            )
                            onInvoiceGenerated(inv)
                            workshopStep = 0
                            workshopOutput = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("manufacture_jewellery_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold)
                ) {
                    Text(
                        text = if (workshopStep == 0) "Alloy 1kg Gold to 22K & Hallmark" else "Generate Retail Customer Invoice",
                        color = DeepCharcoal,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // --- 2. OLD GOLD / SCRAP WEIGH & ASSAY TEST (ANITA SHARMA) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "OLD GOLD SCRAP INTAKE (ANITA SHARMA)",
                    style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Accurate Spectrometer Assay Valuation Calculator",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextLight.copy(alpha = 0.5f))
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = scrapWeightText,
                    onValueChange = { scrapWeightText = it },
                    label = { Text("Intake Gross Weight (Grams)", color = TextLight) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("scrap_weight_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val weight = scrapWeightText.toDoubleOrNull() ?: 38.40
                        val res = SimulationEngine.processOldGoldScrap(
                            articleName = "Anita Sharma's 22K Necklace",
                            grossWeight = weight,
                            assayedPurity = 0.916,
                            customerName = "Anita Sharma"
                        )
                        scrapPayoutResult = res
                    },
                    modifier = Modifier.fillMaxWidth().testTag("assay_calc_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                ) {
                    Text("Weigh, Melt & Assay (91.6% Purity)", color = DeepCharcoal, fontWeight = FontWeight.Bold)
                }

                scrapPayoutResult?.let { res ->
                    val cert = res["certificate"] as AssayCertificate
                    val grossVal = res["gross_value"] as Long
                    val loss = res["melting_loss"] as Long
                    val net = res["net_payout"] as Long

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Intake Valuation Certificate Approved:", fontWeight = FontWeight.Bold, color = SuccessGreen)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Fine Gold Recovered: ${"%.4f".format(res["fine_weight"] as Double)} g", color = WarmIvory)
                    Text("Refinery Melting & Out-turn Loss (1.5%): ₹${"%.2f".format(loss / 100.0)}", color = TextLight.copy(alpha = 0.7f))
                    Text("Net Cash Payout Voucher: ₹${"%.2f".format(net / 100.0)}", fontWeight = FontWeight.Bold, color = AntiqueGold)

                    Spacer(modifier = Modifier.height(12.dp))
                    // Assay Certificate view
                    AssayCertificateCard(certificate = cert)
                }
            }
        }
    }
}

// ==========================================
// SCREEN 5: RISK & SCENARIO LAB
// ==========================================
@Composable
fun RiskMonitorScreen(
    language: Language
) {
    var shockGold by remember { mutableStateOf("5.0") }
    var shockSilver by remember { mutableStateOf("10.0") }
    var isStressTestExecuted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Limit monitor
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ErrorRed, RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "INVENTORY CONCENTRATION LIMIT WATCH",
                    fontWeight = FontWeight.Bold,
                    color = ErrorRed
                )
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = 0.936f,
                    color = ErrorRed,
                    trackColor = Color.Gray.copy(alpha = 0.3f),
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Current Holding: ₹842 Cr", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvory))
                    Text("Alert Limit: ₹900 Cr (93.6% used)", style = MaterialTheme.typography.labelSmall.copy(color = ErrorRed, fontWeight = FontWeight.Bold))
                }
            }
        }

        // Scenario Lab
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SCENARIO SHOCK LAB",
                    style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Apply extreme market movements to revalue treasury exposure.",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = shockGold,
                    onValueChange = { shockGold = it },
                    label = { Text("Gold Move %", color = TextLight) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("shock_gold_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = shockSilver,
                    onValueChange = { shockSilver = it },
                    label = { Text("Silver Move %", color = TextLight) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val g = shockGold.toDoubleOrNull() ?: 5.0
                        val s = shockSilver.toDoubleOrNull() ?: 10.0
                        SimulationEngine.applyScenarioShock(g, s, 1.2, 350.0)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("apply_shock_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                ) {
                    Text("Apply Shift & Revalue", color = DeepCharcoal)
                }
            }
        }

        // Stress Test Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ErrorRed.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SlateGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BLACK SWAN STRESS TEST",
                    style = MaterialTheme.typography.titleMedium.copy(color = ErrorRed, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = {
                        isStressTestExecuted = true
                        SimulationEngine.applyScenarioShock(-12.0, -18.0, 5.0, -1000.0)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("execute_stress_test_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Execute Black Swan Shock", color = WarmIvory, fontWeight = FontWeight.Bold)
                }

                AnimatedVisibility(visible = isStressTestExecuted) {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        Text("Stress Simulation Results [CRITICAL IMPACT]:", fontWeight = FontWeight.Bold, color = ErrorRed)
                        Text("- Total Portfolio Loss: ₹34.50 Crore", color = WarmIvory)
                        Text("- Covered Hedge Effectiveness: 91.20% (MCX Shorts protected capital!)", color = SuccessGreen)
                        Text("- Remaining Capital Adequacy: 14.80% (BIS Requirement: >12.0%)", color = WarmIvory)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 6: SWARNA AI CHAT SCREEN
// ==========================================
@Composable
fun SwarnaAIChatScreen(
    language: Language
) {
    var userMessage by remember { mutableStateOf("") }
    val chatHistory = remember { mutableStateListOf<Pair<String, Boolean>>() } // Message, isUser

    if (chatHistory.isEmpty()) {
        chatHistory.add(Pair(if (language == Language.ENGLISH) "Greetings, I am Swarna AI, your digital dealer room and treasury assistant. Ask me anything." else "नमस्ते। मैं स्वर्ण एआई हूँ, आपका तिजोरी और ट्रेजरी सहायक।", false))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SWARNA AI CHAT (स्वर्ण एआई)",
            style = MaterialTheme.typography.titleMedium.copy(color = AntiqueGold, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Chat log
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(SlateGrey, RoundedCornerShape(8.dp))
                .border(0.5.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chatHistory) { (msg, isUser) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isUser) AntiqueGold else DeepCharcoal,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(
                                text = msg,
                                modifier = Modifier.padding(10.dp),
                                color = if (isUser) DeepCharcoal else WarmIvory,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Suggestion Queries (highly realistic!)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val suggestionsEn = listOf("What is our gold exposure?", "How much silver is in Mumbai?", "Show today's P&L", "Who has largest gold positions?")
            suggestionsEn.forEach { text ->
                Box(
                    modifier = Modifier
                        .background(SlateGrey, RoundedCornerShape(4.dp))
                        .border(0.5.dp, AntiqueGold, RoundedCornerShape(4.dp))
                        .clickable {
                            chatHistory.add(Pair(text, true))
                            val reply = SimulationEngine.querySwarnaAI(text, language)
                            chatHistory.add(Pair(reply, false))
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text, fontSize = 10.sp, color = AntiqueGold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Send Text Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = userMessage,
                onValueChange = { userMessage = it },
                placeholder = { Text("Ask Swarna AI...", color = TextLight.copy(alpha = 0.5f)) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("ai_chat_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AntiqueGold,
                    unfocusedBorderColor = Color.Gray,
                    focusedTextColor = WarmIvory,
                    unfocusedTextColor = WarmIvory
                )
            )

            Button(
                onClick = {
                    if (userMessage.isNotBlank()) {
                        chatHistory.add(Pair(userMessage, true))
                        val reply = SimulationEngine.querySwarnaAI(userMessage, language)
                        chatHistory.add(Pair(reply, false))
                        userMessage = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold),
                modifier = Modifier.height(56.dp).testTag("ai_send_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = DeepCharcoal)
            }
        }
    }
}

// ==========================================
// SCREEN 7: HUID VERIFY SCREEN
// ==========================================
@Composable
fun HUIDVerifyScreen(
    language: Language
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        HUIDVerifierWidget(
            language = language,
            onVerify = { SimulationEngine.verifyHuidCode(it) }
        )
    }
}
