package com.example.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.ClientAccount
import com.example.data.ComplianceCase
import com.example.data.CustodyDocument
import com.example.data.DoubleEntryStatus
import com.example.data.GeminiClient
import com.example.data.GeminiContent
import com.example.data.GeminiPart
import com.example.data.GeminiRequest
import com.example.data.GoldBar
import com.example.data.GoldCoin
import com.example.data.GoldRepository
import com.example.data.LedgerEntry
import com.example.data.RfqQuote
import com.example.data.TaxRule
import com.example.data.VaultMetrics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GoldViewModel : ViewModel() {

    // Navigation Stack
    private val _backStack = mutableStateListOf("HOME")
    val currentScreen: String get() = _backStack.lastOrNull() ?: "HOME"

    fun navigateTo(screen: String) {
        if (_backStack.lastOrNull() != screen) {
            _backStack.add(screen)
        }
    }

    fun navigateBack(): Boolean {
        return if (_backStack.size > 1) {
            _backStack.removeAt(_backStack.size - 1)
            true
        } else {
            false
        }
    }

    // Connect state flows directly from the Repository
    val spotPrice: StateFlow<Double> = GoldRepository.spotPriceXAUCHF
    val clientAccount: StateFlow<ClientAccount> = GoldRepository.clientAccount
    val goldBars: StateFlow<List<GoldBar>> = GoldRepository.goldBars
    val goldCoins: StateFlow<List<GoldCoin>> = GoldRepository.goldCoins
    val ledgerEntries: StateFlow<List<LedgerEntry>> = GoldRepository.ledgerEntries
    val vaults: StateFlow<List<VaultMetrics>> = GoldRepository.vaults
    val taxRules: StateFlow<List<TaxRule>> = GoldRepository.taxRules.stateIn(
        viewModelScope, SharingStarted.Eagerly, emptyList()
    )
    val custodyDocuments: StateFlow<List<CustodyDocument>> = GoldRepository.custodyDocuments
    val complianceCase: StateFlow<ComplianceCase> = GoldRepository.complianceCase
    val reconciliationDiscrepancy: StateFlow<String?> = GoldRepository.reconciliationDiscrepancy

    // Active Selection State
    val selectedBar = mutableStateOf<GoldBar?>(null)
    val selectedVault = mutableStateOf<VaultMetrics?>(null)

    // Buy Screen Wizard State
    val selectedBuyProduct = mutableStateOf("BAR_100G")
    val selectedBuyWeightGrams = mutableStateOf(100.0)
    val activeQuote = mutableStateOf<RfqQuote?>(null)
    val purchaseSuccessMessage = mutableStateOf<String?>(null)
    val buyErrorMessage = mutableStateOf<String?>(null)

    // Chat Assistant State
    val chatHistory = mutableStateListOf<Pair<String, Boolean>>(
        Pair("Grüezi. I am AUREUS AI, your private gold advisor. How may I assist you with your Swiss physical gold custody today?", false)
    )
    val isChatLoading = mutableStateOf(false)
    val inputMessageText = mutableStateOf("")

    // Reconciliation Incident Toggle
    val isSimulationExceptionActive = mutableStateOf(false)
    val reconciliationMessage = mutableStateOf("Ready to reconcile.")

    // Initialise Periodic Spot Price Updates (Ticking)
    init {
        viewModelScope.launch {
            while (true) {
                delay(5000L) // tick every 5 seconds
                GoldRepository.tickGoldPrice()
            }
        }
    }

    // Request RFQ Quote
    fun requestRfqQuote() {
        buyErrorMessage.value = null
        purchaseSuccessMessage.value = null
        val rfq = GoldRepository.requestRfq(selectedBuyProduct.value, selectedBuyWeightGrams.value)
        activeQuote.value = rfq

        // Expire quote in 10 seconds locally to force re-quote
        viewModelScope.launch {
            delay(10000L)
            if (activeQuote.value?.rfqId == rfq.rfqId && activeQuote.value?.status == "PENDING") {
                activeQuote.value = rfq.copy(status = "EXPIRED")
            }
        }
    }

    // Confirm & Execute Purchase
    fun executePurchase() {
        val rfq = activeQuote.value ?: return
        if (rfq.status == "EXPIRED") {
            buyErrorMessage.value = "Quote expired. Please request a new price."
            return
        }

        viewModelScope.launch {
            val newBar = GoldRepository.executePurchase(rfq.rfqId)
            if (newBar != null) {
                purchaseSuccessMessage.value = "Transaction complete. Physical bar ${newBar.id} successfully cast, certified, vaulted in Zürich, and allocated to your legal custody."
                activeQuote.value = null
            } else {
                buyErrorMessage.value = "Liquidity/Balance check failed. Please deposit CHF before buying."
            }
        }
    }

    // Move compartment
    fun moveBarCompartment(barId: String, newCompartment: String) {
        val success = GoldRepository.moveBarCompartment(barId, newCompartment)
        if (success) {
            // Update selected bar state to refresh screen
            val updated = GoldRepository.goldBars.value.find { it.id == barId }
            selectedBar.value = updated
        }
    }

    // Request Physical Delivery
    fun requestPhysicalDelivery(barId: String, method: String) {
        val success = GoldRepository.requestPhysicalDelivery(barId, method)
        if (success) {
            val updated = GoldRepository.goldBars.value.find { it.id == barId }
            selectedBar.value = updated
        }
    }

    // Run Daily Reconciliation check
    fun checkReconciliation() {
        viewModelScope.launch {
            reconciliationMessage.value = "Running dual-audit sequence..."
            delay(1500L)
            reconciliationMessage.value = GoldRepository.runDailyReconciliation()
        }
    }

    // Toggle simulation exception discrepancy
    fun toggleSimulationException(enabled: Boolean) {
        isSimulationExceptionActive.value = enabled
        GoldRepository.triggerSimulationException(enabled)
        checkReconciliation()
    }

    // Clear simulation exception
    fun resolveException() {
        toggleSimulationException(false)
    }

    // Run Sanctions / AML screen
    fun runSanctionsScreen() {
        GoldRepository.verifyComplianceSanctions()
    }

    // Get Balanced Sheet stats
    fun getDoubleEntrySheet(): DoubleEntryStatus {
        return GoldRepository.getDoubleEntryBalanceSheet()
    }

    // Send Message to AUREUS AI
    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return
        chatHistory.add(Pair(userText, true))
        inputMessageText.value = ""
        isChatLoading.value = true

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    delay(1500L)
                    chatHistory.add(Pair(
                        "System Information: AUREUS AI API Key is currently unconfigured. [Local Offline Mode Activated]\n\nBased on client holdings, you currently own ${goldBars.value.size} allocated bars and sovereign coin reserves in Zürich ZH-01. Total portfolio valuation is CHF ${String.format("%,.2f", goldBars.value.sumOf { it.fineGoldOz * spotPrice.value })}.",
                        false
                    ))
                    isChatLoading.value = false
                    return@launch
                }

                // Compile live Swiss authorized ledger context
                val client = clientAccount.value
                val bars = goldBars.value
                val coins = goldCoins.value
                val price = spotPrice.value
                val ledger = ledgerEntries.value

                val systemPrompt = GeminiClient.buildSystemInstruction(client, bars, coins, price, ledger)

                // Request REST API
                val request = GeminiRequest(
                    contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = userText)))),
                    systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
                )

                val response = GeminiClient.apiService.generateContent(apiKey, request)
                val aiText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "No authorized response retrieved from the ledger network."

                chatHistory.add(Pair(aiText, false))
            } catch (e: Exception) {
                chatHistory.add(Pair("Advisor communication disrupted: ${e.message ?: "Unknown security error"}", false))
            } finally {
                isChatLoading.value = false
            }
        }
    }
}
