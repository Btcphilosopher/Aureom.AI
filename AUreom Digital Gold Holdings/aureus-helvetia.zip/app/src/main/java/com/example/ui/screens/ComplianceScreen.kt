package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

@Composable
fun ComplianceScreen(viewModel: GoldViewModel) {
    val complianceCase by viewModel.complianceCase.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "SWISS COMPLIANCE PORTAL",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Precious metals trade regulatory screenings & AML checks",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Section 1: Active AML Case
        item {
            Text(text = "AML JURISDICTION STATUS", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "CLIENT CASE PROFILE", color = SwissWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ForestGreen)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(text = complianceCase.screeningStatus, color = SwissWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                ComplianceValueRow(label = "COMPLIANCE ID CASE", value = complianceCase.caseId)
                ComplianceValueRow(label = "CLIENT RELATIONSHIP NAME", value = complianceCase.clientName)
                ComplianceValueRow(label = "BENEFICIAL OWNER RECORD", value = complianceCase.beneficialOwner)
                ComplianceValueRow(label = "JURISDICTION RISK LEVEL", value = complianceCase.amlRiskLevel)
                ComplianceValueRow(label = "SOURCE OF WEALTH DISCLOSURE", value = complianceCase.sourceOfWealth)

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Graphite, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Beneficial Owner Declarations", color = BrushedSteel, fontSize = 11.sp)
                    Icon(imageVector = Icons.Default.Check, contentDescription = "Signed", tint = Color.Green, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Section 2: Automated regulatory checks
        item {
            Text(text = "AUTOMATED AUDIT RUNNERS", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AuditCheckRow(
                    title = "SWISS SANCTIONS INDEX SCREENING",
                    description = "Verifying client details against SECO sanctions databases",
                    isChecked = complianceCase.sanctionsScreened
                )

                AuditCheckRow(
                    title = "PRECIOUS METALS ACT COMPLIANCE",
                    description = "Verifying transaction origin thresholds (limit CHF 15'000)",
                    isChecked = true
                )

                AuditCheckRow(
                    title = "UHNW BENEFICIAL IDENTITY MATCH",
                    description = "Federal Registry crosschecking of ultimate owners",
                    isChecked = complianceCase.customDeclarationSigned
                )

                Button(
                    onClick = { viewModel.runSanctionsScreen() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("run_compliance_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Sync, contentDescription = null, tint = MutedGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "FORCE COMPLIANCE SANCTIONS RE-SCREEN", color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun ComplianceValueRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = BrushedSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AuditCheckRow(title: String, description: String, isChecked: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Graphite, RoundedCornerShape(4.dp))
            .background(DeepBlack)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(text = description, color = BrushedSteel, fontSize = 9.sp)
        }
        Icon(
            imageVector = if (isChecked) Icons.Default.Verified else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isChecked) Color.Green else Color.Yellow,
            modifier = Modifier.size(20.dp)
        )
    }
}
