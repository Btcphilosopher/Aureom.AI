package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RfqQuote
import com.example.data.GoldRepository
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel
import kotlinx.coroutines.delay

@Composable
fun BuyScreen(viewModel: GoldViewModel) {
    val clientAccount by viewModel.clientAccount.collectAsState()
    val spotPrice by viewModel.spotPrice.collectAsState()

    val selectedProduct by viewModel.selectedBuyProduct
    val selectedWeightGrams by viewModel.selectedBuyWeightGrams
    val activeQuote by viewModel.activeQuote
    val purchaseSuccessMessage by viewModel.purchaseSuccessMessage
    val buyErrorMessage by viewModel.buyErrorMessage

    // Countdown state for RFQ quote expiry
    var quoteTimeRemaining by remember { mutableStateOf(10) }

    LaunchedEffect(activeQuote) {
        if (activeQuote != null && activeQuote?.status == "PENDING") {
            quoteTimeRemaining = 10
            while (quoteTimeRemaining > 0 && activeQuote?.status == "PENDING") {
                delay(1000L)
                quoteTimeRemaining--
            }
            if (quoteTimeRemaining == 0 && activeQuote?.status == "PENDING") {
                activeQuote?.status = "EXPIRED"
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "ACQUIRE PHYSICAL BULLION",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Swiss precious metals purchase & automatic secure allocation",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Available Balance Status Card
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "AVAILABLE CLEARING BALANCE", color = BrushedSteel, fontSize = 10.sp)
                    Text(
                        text = "CHF ${String.format("%,.2f", clientAccount.cashBalanceCHF).replace(',', '\'')}",
                        color = SwissWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = "SWISS CAPITAL ACCOUNT", color = MutedGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Product selection
        item {
            Text(text = "SELECT SPECIFICATION & WEIGHT", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    Triple("BAR_10G", "10 g Investment Gold Bar", 10.0),
                    Triple("BAR_100G", "100 g Investment Gold Bar", 100.0),
                    Triple("BAR_1KG", "1 kg Investment Gold Bar", 1000.0),
                    Triple("COIN_VRENELI", "Swiss Vreneli (20 CHF Sovereign Coin)", 5.807)
                ).forEach { (id, name, weight) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (selectedProduct == id) MutedGold else Graphite,
                                RoundedCornerShape(8.dp)
                            )
                            .background(if (selectedProduct == id) Graphite else DarkSteel)
                            .clickable {
                                viewModel.selectedBuyProduct.value = id
                                viewModel.selectedBuyWeightGrams.value = weight
                                viewModel.activeQuote.value = null
                                viewModel.purchaseSuccessMessage.value = null
                                viewModel.buyErrorMessage.value = null
                            }
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedProduct == id),
                                onClick = {
                                    viewModel.selectedBuyProduct.value = id
                                    viewModel.selectedBuyWeightGrams.value = weight
                                    viewModel.activeQuote.value = null
                                    viewModel.purchaseSuccessMessage.value = null
                                    viewModel.buyErrorMessage.value = null
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MutedGold)
                            )
                            Column {
                                Text(text = name, color = SwissWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Assay Fineness: 999.9‰ pure", color = BrushedSteel, fontSize = 10.sp)
                            }
                        }
                        Text(
                            text = "${String.format("%.1f", weight)} g",
                            color = MutedGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Request RFQ Pricing Button (Only shown if no active pending quote exists)
        if (activeQuote == null || activeQuote?.status != "PENDING") {
            item {
                Button(
                    onClick = { viewModel.requestRfqQuote() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("request_quote_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "REQUEST SECURE SPOT QUOTE", color = DeepBlack, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Dynamic RFQ Quote Screen representation
        if (activeQuote != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .background(DarkSteel)
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AUREUS PRICING ENGINE QUOTE",
                            color = MutedGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (activeQuote?.status == "PENDING") ForestGreen else Burgundy)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (activeQuote?.status == "PENDING") "SPOT RATE LOCKED" else "EXPIRED",
                                color = SwissWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    QuoteValueRow(label = "BULLION DESCRIPTION", value = activeQuote?.productName ?: "")
                    QuoteValueRow(label = "FINE WEIGHT (OUNCES)", value = "${String.format("%.4f", GoldRepository.gramsToOunces(activeQuote?.weightGrams ?: 0.0))} oz")
                    QuoteValueRow(label = "XAU/CHF REFERENCE SPOT", value = "CHF ${String.format("%,.2f", spotPrice).replace(',', '\'')}")

                    Divider(color = Graphite, modifier = Modifier.padding(vertical = 12.dp))

                    QuoteValueRow(label = "METAL BASE VALUE", value = "CHF ${String.format("%,.2f", activeQuote?.spotPriceCHF).replace(',', '\'')}")
                    QuoteValueRow(label = "SWISS MINTING PREMIUM", value = "CHF ${String.format("%,.2f", activeQuote?.premiumCHF).replace(',', '\'')}")
                    QuoteValueRow(label = "SWISS VAT STATUS", value = "0.00% VAT Exempt (Art 44)")

                    Divider(color = Graphite, modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "TOTAL TRANSACTION PRICE", color = SwissWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "CHF ${String.format("%,.2f", activeQuote?.totalCHF).replace(',', '\'')}",
                            color = MutedGold,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("quote_total_price")
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    if (activeQuote?.status == "PENDING") {
                        // Countdown and purchase
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "LOCKED VALUE EXPIRES IN: ${quoteTimeRemaining}s",
                                color = BrushedSteel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.executePurchase() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("confirm_purchase_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = "AUTHORISE PHYSICAL PURCHASE", color = SwissWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = { viewModel.requestRfqQuote() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "REQUEST RE-QUOTE", color = SwissWhite, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Error message view
        item {
            AnimatedVisibility(visible = buyErrorMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Burgundy, RoundedCornerShape(8.dp))
                        .background(Burgundy.copy(alpha = 0.15f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = buyErrorMessage ?: "", color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }

        // Success Confirmation receipt
        item {
            AnimatedVisibility(visible = purchaseSuccessMessage != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.Green.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .background(ForestGreen.copy(alpha = 0.15f))
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Success", tint = Color.Green)
                        Text(text = "BULLION CUSTODY ALLOCATED", color = Color.Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = purchaseSuccessMessage ?: "",
                        color = SwissWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Light
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    TextButton(
                        onClick = { viewModel.navigateTo("BARS") },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(text = "VIEW BAR PASSPORT", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = MutedGold, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun QuoteValueRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = BrushedSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
