package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaultMetrics
import com.example.data.VaultZone
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

@Composable
fun VaultScreen(viewModel: GoldViewModel) {
    val vaults by viewModel.vaults.collectAsState()
    val selectedVaultState = viewModel.selectedVault.value

    if (selectedVaultState != null) {
        VaultTwinDetailScreen(vault = selectedVaultState, viewModel = viewModel)
    } else {
        VaultListScreen(vaults = vaults, viewModel = viewModel)
    }
}

@Composable
fun VaultListScreen(vaults: List<VaultMetrics>, viewModel: GoldViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "SWISS CUSTODY VAULT NETWORK",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Digital Twin monitoring of heavy Swiss bullion vaults",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        items(vaults) { vault ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.selectedVault.value = vault
                    },
                colors = CardDefaults.cardColors(containerColor = DarkSteel),
                border = BorderStroke(1.dp, Graphite)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = vault.facilityName.uppercase(),
                            color = SwissWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ForestGreen)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = vault.securityStatus,
                                color = SwissWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "OCCUPIED BARS", color = BrushedSteel, fontSize = 9.sp)
                            Text(text = "${vault.totalOccupied} / ${vault.totalCapacity} Bars", color = MutedGold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "INSURANCE PROTECTION", color = BrushedSteel, fontSize = 9.sp)
                            Text(text = "CHF ${String.format("%,.0f", vault.insuranceLimitCHF).replace(',', '\'')}", color = SwissWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = Graphite, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Last audited on ${vault.lastAuditDate} • Status: ${vault.reconciliationStatus}",
                            color = BrushedSteel,
                            fontSize = 10.sp
                        )
                        Icon(imageVector = Icons.Default.Engineering, contentDescription = "Engineering layout", tint = MutedGold, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun VaultTwinDetailScreen(vault: VaultMetrics, viewModel: GoldViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Back Navigation
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.selectedVault.value = null }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Text(
                    text = "VAULT ${vault.city.uppercase()} DIGITAL TWIN",
                    color = MutedGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Environmental telemetry values (Haute Horlogerie / precision engineering styled dials)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TelemetryCard(
                    label = "ATMOSPHERIC TEMP",
                    value = "${vault.tempCelsius} °C",
                    status = "Optimal Status (Precision Range)",
                    modifier = Modifier.weight(1f)
                )
                TelemetryCard(
                    label = "RELATIVE HUMIDITY",
                    value = "${vault.humidityPercent} %",
                    status = "Anti-Corrosion Target Stable",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Technical Line Drawing Storage Blueprint Map Representation
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MutedGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(20.dp)
            ) {
                Text(
                    text = "SWISS VAULT ARCHITECTURE BLUEPRINT",
                    color = MutedGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Schematic line representation of physical fortress levels",
                    color = BrushedSteel,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Render technical map lines
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .border(1.dp, Graphite, RoundedCornerShape(4.dp))
                        .background(DeepBlack)
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Level 1: Perimeter
                        BlueprintLine(label = "SECURE OUTER PERIMETER", detail = "SEISMIC GRANITE FOUNDATION SENSORS ACTIVE")

                        // Level 2: Transit / Receiving
                        BlueprintLine(label = "RECEIVING DUAL TIME-LOCK CHAMBER", detail = "BIOMETRIC GATE CLOSED")

                        // Level 3: Assay / High Sec Vault
                        BlueprintLine(label = "HIGH-SECURITY BULLION STORAGE VAULTS", detail = "SWISS FEDERAL SEAL SECURED [RECONCILED]")

                        // Level 4: Compartment grid
                        BlueprintLine(label = "COMPARTMENTS A-01 TO B-90", detail = "INDIVIDUAL ARMED CUSTODY SYSTEM")
                    }
                }
            }
        }

        // Vault Zone occupancy grids
        item {
            Text(
                text = "SECURITY ZONE OCCUPANCY ANALYSIS",
                color = MutedGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(vault.zones) { zone ->
            ZoneOccupancyCard(zone = zone)
        }
    }
}

@Composable
fun TelemetryCard(label: String, value: String, status: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .border(1.dp, Graphite, RoundedCornerShape(8.dp))
            .background(DarkSteel)
            .padding(16.dp)
    ) {
        Text(text = label, color = BrushedSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = value, color = MutedGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = status, color = Color.Green, fontSize = 8.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BlueprintLine(label: String, detail: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, color = SwissWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(text = detail, color = BrushedSteel, fontSize = 8.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Divider(color = MutedGold.copy(alpha = 0.25f), thickness = 1.dp)
    }
}

@Composable
fun ZoneOccupancyCard(zone: VaultZone) {
    val occupancyRatio = zone.occupiedBars.toFloat() / zone.capacityBars.toFloat()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Graphite, RoundedCornerShape(8.dp))
            .background(DarkSteel)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "ZONE ${zone.zoneId}: ${zone.name}", color = SwissWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = zone.description, color = BrushedSteel, fontSize = 10.sp)
            }
            Text(
                text = "${String.format("%.1f", occupancyRatio * 100)}% OCCUPIED",
                color = MutedGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Linear Progress bar indicator
        LinearProgressIndicator(
            progress = occupancyRatio,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = MutedGold,
            trackColor = Graphite
        )

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Volume Capacity: ${zone.capacityBars} Bars", color = BrushedSteel, fontSize = 9.sp)
            Text(text = "Security level: ${zone.securityLevel}", color = MutedGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
