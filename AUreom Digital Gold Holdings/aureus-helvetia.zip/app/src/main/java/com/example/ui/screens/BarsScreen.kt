package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GoldBar
import com.example.data.PassportEvent
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BarsScreen(viewModel: GoldViewModel) {
    val goldBars by viewModel.goldBars.collectAsState()
    val selectedBarState = viewModel.selectedBar.value

    if (selectedBarState != null) {
        BarPassportScreen(bar = selectedBarState, viewModel = viewModel)
    } else {
        BarsListScreen(goldBars = goldBars, viewModel = viewModel)
    }
}

@Composable
fun BarsListScreen(goldBars: List<GoldBar>, viewModel: GoldViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "SWISS PHYSICAL INVENTORY",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Fully allocated physical bullion holdings",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        items(goldBars) { bar ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.selectedBar.value = bar
                    },
                colors = CardDefaults.cardColors(containerColor = DarkSteel),
                border = BorderStroke(1.dp, Graphite)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = bar.id,
                            color = SwissWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    when (bar.status) {
                                        "ALLOCATED" -> ForestGreen
                                        "DELIVERED" -> DarkSlate
                                        else -> Burgundy
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = bar.status,
                                color = SwissWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "FINE GOLD", color = BrushedSteel, fontSize = 10.sp)
                            Text(text = "${String.format("%.3f", bar.fineGoldOz)} oz", color = SwissWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "REFINER & FINENESS", color = BrushedSteel, fontSize = 10.sp)
                            Text(text = "${bar.refiner} (${bar.fineness}‰)", color = SwissWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = Graphite, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Vault facility: ${bar.vaultId} Compartment ${bar.compartment}",
                            color = BrushedSteel,
                            fontSize = 11.sp
                        )
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "View Certificate", tint = MutedGold, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun BarPassportScreen(bar: GoldBar, viewModel: GoldViewModel) {
    val spotPrice by viewModel.spotPrice.collectAsState()
    var isMoveSheetOpen by remember { mutableStateOf(false) }
    var isDeliverySheetOpen by remember { mutableStateOf(false) }

    var inputCompartment by remember { mutableStateOf(bar.compartment) }
    var selectedDeliveryMethod by remember { mutableStateOf("Courier Swiss Post Secure") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Top Back bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.selectedBar.value = null }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Text(
                    text = "SWISS GOLD BAR PASSPORT",
                    color = MutedGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Exquisite Physical Bullion Certificate representation
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MutedGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(24.dp)
            ) {
                // Seal of Switzerland
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(text = "SWISS PRESTIGE BULLION", color = MutedGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(text = "OFFICIAL DIGITAL TWIN CERTIFICATE", color = BrushedSteel, fontSize = 8.sp, letterSpacing = 1.sp)
                    }
                    Text(text = "CH-995‰+", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Bar Weight Display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Graphite, RoundedCornerShape(4.dp))
                        .background(DeepBlack)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "CERTIFIED MASS", color = BrushedSteel, fontSize = 9.sp, letterSpacing = 1.sp)
                        Text(
                            text = "${String.format("%,.0f", bar.weightGrams)} g",
                            color = MutedGold,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "FINE GOLD: ${String.format("%.3f", bar.fineGoldOz)} oz (Fineness: ${bar.fineness}‰)", color = SwissWhite, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Pedigree Specs
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SpecRow(label = "SERIAL NUMBER", value = bar.id)
                    SpecRow(label = "REFINER / BRAND", value = bar.refiner)
                    SpecRow(label = "ASSAY TECHNIQUE", value = bar.assayMethod)
                    SpecRow(label = "PHYSICAL VAULT", value = "${bar.vaultId} - Zürich Fortress")
                    SpecRow(label = "COMPARTMENT", value = bar.compartment)
                    SpecRow(label = "LEGAL CUSTODY OWNER", value = "FSO-2026-CH (Direct Allocation)")
                    SpecRow(label = "MARKET VALUE (CHF)", value = "CHF ${String.format("%,.2f", bar.fineGoldOz * spotPrice).replace(',', '\'')}")
                    SpecRow(label = "STATUS", value = bar.status)
                }

                Spacer(modifier = Modifier.height(20.dp))
                Divider(color = Graphite, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Auditable status mark
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Verified", tint = Color.Green, modifier = Modifier.size(16.dp))
                    Text(text = "PHYSICAL STATUS RECONCILED & AUDITED", color = Color.Green, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
            }
        }

        // Actions panel (Only available if bar is ALLOCATED and vaulted)
        if (bar.status == "ALLOCATED") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { isMoveSheetOpen = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_relocate"),
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        border = BorderStroke(1.dp, MutedGold.copy(alpha = 0.5f))
                    ) {
                        Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = MutedGold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Vault Move", color = SwissWhite, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { isDeliverySheetOpen = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_deliver"),
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                        border = BorderStroke(1.dp, MutedGold)
                    ) {
                        Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = DeepBlack)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Request Delivery", color = DeepBlack, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Vault Relocation Sheet Simulation
        if (isMoveSheetOpen) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                        .background(DarkSteel)
                        .padding(16.dp)
                ) {
                    Text(text = "VAULT INTERNAL RELOCATION", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Move this physical gold bar to another high-security vault compartment. This relocation will require dual-auditor approval and update the custody movement timeline.",
                        color = BrushedSteel,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    TextField(
                        value = inputCompartment,
                        onValueChange = { inputCompartment = it },
                        label = { Text("Target Compartment ID") },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = DeepBlack,
                            unfocusedContainerColor = DeepBlack,
                            focusedTextColor = SwissWhite,
                            unfocusedTextColor = SwissWhite
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { isMoveSheetOpen = false }) {
                            Text("Cancel", color = BrushedSteel)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                if (inputCompartment.isNotBlank()) {
                                    viewModel.moveBarCompartment(bar.id, inputCompartment)
                                    isMoveSheetOpen = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                        ) {
                            Text("Relocate", color = SwissWhite)
                        }
                    }
                }
            }
        }

        // Deliver Bar Request Sheet
        if (isDeliverySheetOpen) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                        .background(DarkSteel)
                        .padding(16.dp)
                ) {
                    Text(text = "PHYSICAL BULLION DELIVERY FORM", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "This physical bar will be dispatched from Zürich ZH-01 fortress. Physical delivery is subject to Swiss precious metal declarations and compliance clearance.",
                        color = BrushedSteel,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Courier Swiss Post Secure", "Loomis Secure Transport", "In-Person Zürich Vault Pickup").forEach { method ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        1.dp,
                                        if (selectedDeliveryMethod == method) MutedGold else Graphite,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(if (selectedDeliveryMethod == method) Graphite else DeepBlack)
                                    .clickable { selectedDeliveryMethod = method }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = method,
                                    color = if (selectedDeliveryMethod == method) MutedGold else BrushedSteel,
                                    fontSize = 9.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { isDeliverySheetOpen = false }) {
                            Text("Cancel", color = BrushedSteel)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                viewModel.requestPhysicalDelivery(bar.id, selectedDeliveryMethod)
                                isDeliverySheetOpen = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy)
                        ) {
                            Text("Authorise Delivery", color = SwissWhite)
                        }
                    }
                }
            }
        }

        // Chronological Provenance Event History Timeline
        item {
            Text(
                text = "CHRONOLOGICAL PROVENANCE TIMELINE",
                color = MutedGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        items(bar.passportEvents) { event ->
            ProvenanceTimelineItem(event = event)
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = BrushedSteel, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ProvenanceTimelineItem(event: PassportEvent) {
    val date = Date(event.timestamp)
    val formattedDate = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(date)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MutedGold)
            )
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(60.dp)
                    .background(Graphite)
            )
        }

        Column {
            Text(text = formattedDate, color = BrushedSteel, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = event.eventType, color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(1.dp))
            Text(text = event.description, color = SwissWhite, fontSize = 11.sp, fontWeight = FontWeight.Light)
            Spacer(modifier = Modifier.height(1.dp))
            Text(text = "Location: ${event.location} • Sign-off: ${event.operator}", color = BrushedSteel, fontSize = 9.sp)
        }
    }
}
