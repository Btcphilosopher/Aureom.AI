package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Swiss prestige gold, bullion & vaulting platform palette
val SwissGold = Color(0xFFD4AF37) // Bright champagne gold
val MutedGold = Color(0xFFC5A059) // Muted elegant gold
val Graphite = Color(0xFF2C2D30) // Dark charcoal graphite
val BrushedSteel = Color(0xFF8E9297) // Precision steel
val DarkSteel = Color(0xFF1A1C23) // Deep vault steel surface
val DeepBlack = Color(0xFF0B0C10) // Darkest background
val ForestGreen = Color(0xFF1E3A27) // Muted luxury green
val Burgundy = Color(0xFF58111A) // Elegant burgundy
val SwissWhite = Color(0xFFF5F6F8) // Clean white
val WarmIvory = Color(0xFFFAF7F2) // Premium paper ivory
val DarkSlate = Color(0xFF3A3D40) // Slate accent
val BronzeAccent = Color(0xFF967B4C) // Elegant bronze accent

