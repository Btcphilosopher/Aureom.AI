package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GoldViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepBlack),
                    topBar = { AureusTopBar(viewModel) },
                    bottomBar = { AureusBottomBar(viewModel) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AppNavigation(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun AureusTopBar(viewModel: GoldViewModel) {
    val spotPrice by viewModel.spotPrice.collectAsState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .background(DeepBlack)
            .border(0.5.dp, Graphite)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.aureus_logo_1791272428619),
                contentDescription = "Aureus Seal",
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(4.dp)),
                contentScale = ContentScale.Fit
            )
            Text(
                text = "AUREUS HELVETIA",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Green)
            )
            Text(
                text = "XAU/CHF: CHF ${String.format("%.2f", spotPrice).replace(',', '\'')}",
                color = SwissWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun AureusBottomBar(viewModel: GoldViewModel) {
    val current = viewModel.currentScreen

    NavigationBar(
        containerColor = DeepBlack,
        tonalElevation = 8.dp,
        modifier = Modifier
            .border(0.5.dp, Graphite)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = current == "HOME",
            onClick = { viewModel.navigateTo("HOME") },
            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home", tint = if (current == "HOME") MutedGold else BrushedSteel) },
            label = { Text("Home", color = if (current == "HOME") MutedGold else BrushedSteel, fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = Graphite)
        )
        NavigationBarItem(
            selected = current == "BARS" || current == "BAR_PASSPORT",
            onClick = { viewModel.navigateTo("BARS") },
            icon = { Icon(imageVector = Icons.Default.Grid4x4, contentDescription = "Bars", tint = if (current == "BARS" || current == "BAR_PASSPORT") MutedGold else BrushedSteel) },
            label = { Text("Bars", color = if (current == "BARS" || current == "BAR_PASSPORT") MutedGold else BrushedSteel, fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = Graphite)
        )
        NavigationBarItem(
            selected = current == "BUY",
            onClick = { viewModel.navigateTo("BUY") },
            icon = { Icon(imageVector = Icons.Default.AccountBalance, contentDescription = "Buy", tint = if (current == "BUY") MutedGold else BrushedSteel) },
            label = { Text("Buy", color = if (current == "BUY") MutedGold else BrushedSteel, fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = Graphite)
        )
        NavigationBarItem(
            selected = current == "ASSISTANT",
            onClick = { viewModel.navigateTo("ASSISTANT") },
            icon = { Icon(imageVector = Icons.Default.SupportAgent, contentDescription = "AI", tint = if (current == "ASSISTANT") MutedGold else BrushedSteel) },
            label = { Text("Advisor", color = if (current == "ASSISTANT") MutedGold else BrushedSteel, fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = Graphite)
        )
    }
}

@Composable
fun AppNavigation(viewModel: GoldViewModel) {
    val current = viewModel.currentScreen

    // Standard Android Back Button Interception
    BackHandler(enabled = current != "HOME") {
        viewModel.navigateBack()
    }

    AnimatedContent(
        targetState = current,
        transitionSpec = {
            slideInHorizontally { width -> width }.togetherWith(slideOutHorizontally { width -> -width })
        },
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            "HOME" -> HomeScreen(viewModel = viewModel)
            "BARS" -> BarsScreen(viewModel = viewModel)
            "BAR_PASSPORT" -> {
                val bar = viewModel.selectedBar.value
                if (bar != null) {
                    BarPassportScreen(bar = bar, viewModel = viewModel)
                } else {
                    HomeScreen(viewModel = viewModel)
                }
            }
            "VAULT" -> VaultScreen(viewModel = viewModel)
            "BUY" -> BuyScreen(viewModel = viewModel)
            "DOCUMENTS" -> DocumentsScreen(viewModel = viewModel)
            "ASSISTANT" -> AssistantScreen(viewModel = viewModel)
            "DEALER" -> DealerScreen(viewModel = viewModel)
            "COMPLIANCE" -> ComplianceScreen(viewModel = viewModel)
            else -> HomeScreen(viewModel = viewModel)
        }
    }
}
