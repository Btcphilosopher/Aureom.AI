package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustodyDocument
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

@Composable
fun DocumentsScreen(viewModel: GoldViewModel) {
    val custodyDocuments by viewModel.custodyDocuments.collectAsState()
    var selectedDocument by remember { mutableStateOf<CustodyDocument?>(null) }

    if (selectedDocument != null) {
        DocumentDetailScreen(doc = selectedDocument!!) {
            selectedDocument = null
        }
    } else {
        DocumentsListScreen(docs = custodyDocuments, viewModel = viewModel) { doc ->
            selectedDocument = doc
        }
    }
}

@Composable
fun DocumentsListScreen(docs: List<CustodyDocument>, viewModel: GoldViewModel, onSelect: (CustodyDocument) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "PRESTIGE CUSTODY STATEMENTS",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Authorized Swiss bank-grade statements and allocation certificates",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        items(docs) { doc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(doc) },
                colors = CardDefaults.cardColors(containerColor = DarkSteel),
                border = BorderStroke(1.dp, Graphite)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Graphite),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (doc.docType) {
                                    "STATEMENT" -> Icons.Default.Description
                                    "TRANSACTION_CONFIRM" -> Icons.Default.Payments
                                    else -> Icons.Default.ReceiptLong
                                },
                                contentDescription = null,
                                tint = MutedGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column {
                            Text(text = doc.title, color = SwissWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Document ID: ${doc.docNumber} • ${doc.dateString}", color = BrushedSteel, fontSize = 10.sp)
                        }
                    }

                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Open Document", tint = MutedGold, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun DocumentDetailScreen(doc: CustodyDocument, onDismiss: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Text(
                    text = "SWISS PRESTIGE DOCUMENT VIEWER",
                    color = MutedGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Prestige White Paper statement layout representation
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BrushedSteel.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .background(WarmIvory) // White/Ivory paper background for premium feel
                    .padding(24.dp)
            ) {
                // Header with subtle Swiss line
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AUREUS HELVETIA CUSTODY AG",
                            color = Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif,
                            letterSpacing = 1.sp
                        )
                        Text(text = "Zürich • Geneva • Lugano", color = Color.Gray, fontSize = 9.sp)
                    }
                    Text(text = "SWISS CONFEDERATION", color = Burgundy, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(24.dp))
                Divider(color = Color.Black, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Document metadata
                Text(
                    text = doc.title,
                    color = Color.Black,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "STATEMENT DATE: ${doc.dateString}", color = Color.DarkGray, fontSize = 10.sp)
                Text(text = "ACCOUNT NO: ${doc.clientId}", color = Color.DarkGray, fontSize = 10.sp)
                Text(text = "CLIENT: ${doc.clientName}", color = Color.DarkGray, fontSize = 10.sp)

                Spacer(modifier = Modifier.height(24.dp))

                // Detail specs list (table-like)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Holding specifications", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Certified quantities", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Divider(color = Color.Gray, thickness = 0.5.dp)

                    doc.details.forEach { (label, value) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = label, color = Color.DarkGray, fontSize = 11.sp)
                            Text(text = value, color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Divider(color = Color.Gray, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "ESTIMATED PORTFOLIO VALUE", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "CHF ${String.format("%,.2f", doc.valuationCHF)}",
                            color = Color.Black,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                // Auditor Signatures row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Beat de Montmollin", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Chief Auditor Sign-off", color = Color.Gray, fontSize = 8.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .width(80.dp)
                                .height(1.dp)
                                .background(Color.Gray)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "S. Bieri", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Senior Registrar Approval", color = Color.Gray, fontSize = 8.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .width(80.dp)
                                .height(1.dp)
                                .background(Color.Gray)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))

                // Cryptographic validation hash
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, Color.Gray, RoundedCornerShape(4.dp))
                        .background(Color.LightGray.copy(alpha = 0.2f))
                        .padding(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = Color.DarkGray, modifier = Modifier.size(12.dp))
                        Text(text = "CRYPTOGRAPHICS SWISS VERIFIED AUDIT CHAIN", color = Color.DarkGray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "SHA256: ${doc.verifiedHash}",
                        color = Color.Gray,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
