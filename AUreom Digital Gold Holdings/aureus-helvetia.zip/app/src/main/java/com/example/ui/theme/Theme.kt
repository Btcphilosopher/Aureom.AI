package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MutedGold,
    secondary = BrushedSteel,
    tertiary = ForestGreen,
    background = DeepBlack,
    surface = DarkSteel,
    onPrimary = DeepBlack,
    onSecondary = SwissWhite,
    onTertiary = SwissWhite,
    onBackground = SwissWhite,
    onSurface = SwissWhite,
    surfaceVariant = Graphite,
    onSurfaceVariant = BrushedSteel
  )

private val LightColorScheme =
  lightColorScheme(
    primary = BronzeAccent,
    secondary = DarkSlate,
    tertiary = ForestGreen,
    background = WarmIvory,
    surface = SwissWhite,
    onPrimary = SwissWhite,
    onSecondary = DeepBlack,
    onTertiary = DeepBlack,
    onBackground = DeepBlack,
    onSurface = DeepBlack,
    surfaceVariant = WarmIvory,
    onSurfaceVariant = DarkSlate
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
