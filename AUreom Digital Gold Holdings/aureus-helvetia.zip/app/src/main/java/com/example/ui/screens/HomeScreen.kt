package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GoldBar
import com.example.data.GoldRepository
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

@Composable
fun HomeScreen(viewModel: GoldViewModel) {
    val clientAccount by viewModel.clientAccount.collectAsState()
    val goldBars by viewModel.goldBars.collectAsState()
    val spotPrice by viewModel.spotPrice.collectAsState()

    // Aggregate holdings
    val totalAllocatedGrams = goldBars.filter { it.status == "ALLOCATED" }.sumOf { it.weightGrams }
    val totalAllocatedOz = GoldRepository.gramsToOunces(totalAllocatedGrams)
    val totalUnallocatedOz = clientAccount.unallocatedBalanceOz
    val totalFineOz = totalAllocatedOz + totalUnallocatedOz
    val totalValueCHF = totalFineOz * spotPrice

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Prestige Swiss Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, MutedGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .background(DarkSteel)
            ) {
                // Background image or decorative pattern
                Image(
                    painter = painterResource(id = R.drawable.aureus_logo_1791272428619),
                    contentDescription = "Aureus Prestige Logo",
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(130.dp)
                        .align(Alignment.CenterEnd)
                        .padding(end = 10.dp),
                    alpha = 0.25f,
                    contentScale = ContentScale.Fit
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "AUREUS HELVETIA",
                        color = MutedGold,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "SWISS PRESTIGE BULLION PLATFORM",
                        color = BrushedSteel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Main Portfolio Balance Layer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(24.dp)
            ) {
                Text(
                    text = "TOTAL PHYSICAL EXPOSURE",
                    color = BrushedSteel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CHF ${String.format("%,.2f", totalValueCHF).replace(',', '\'')}",
                        color = MutedGold,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("total_exposure_chf")
                    )
                    Text(
                        text = "${String.format("%.3f", totalFineOz)} oz",
                        color = SwissWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Graphite, thickness = 0.8.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Detailed Balance Allocation Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "ALLOCATED", color = BrushedSteel, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${String.format("%.3f", totalAllocatedOz)} oz",
                            color = SwissWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "UNALLOCATED", color = BrushedSteel, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${String.format("%.3f", totalUnallocatedOz)} oz",
                            color = SwissWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "SWISS VAULTED", color = BrushedSteel, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Zürich/Geneva",
                            color = SwissWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Switzerland Navigation Control Grid
        item {
            Text(
                text = "SWISS PRESTIGE PLATFORM WORKSPACE",
                color = MutedGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Service Grid Links
        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ServiceCard(
                        title = "YOUR BARS",
                        subtitle = "Inspect Digital Twin",
                        icon = Icons.Default.Grid4x4,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_bars"),
                        onClick = { viewModel.navigateTo("BARS") }
                    )
                    ServiceCard(
                        title = "VAULT TWIN",
                        subtitle = "Technical Layout",
                        icon = Icons.Default.Shield,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_vault"),
                        onClick = { viewModel.navigateTo("VAULT") }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ServiceCard(
                        title = "BUY BULLION",
                        subtitle = "RFQ Pricing Engine",
                        icon = Icons.Default.AccountBalance,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_buy"),
                        onClick = { viewModel.navigateTo("BUY") }
                    )
                    ServiceCard(
                        title = "DOCUMENTS",
                        subtitle = "Prestige Statements",
                        icon = Icons.Default.ReceiptLong,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_documents"),
                        onClick = { viewModel.navigateTo("DOCUMENTS") }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ServiceCard(
                        title = "AUREUS AI",
                        subtitle = "Swiss Gold Advisor",
                        icon = Icons.Default.SupportAgent,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_assistant"),
                        onClick = { viewModel.navigateTo("ASSISTANT") }
                    )
                    ServiceCard(
                        title = "DEALER DESK",
                        subtitle = "Audit & Controls",
                        icon = Icons.Default.VerifiedUser,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_dealer"),
                        onClick = { viewModel.navigateTo("DEALER") }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ServiceCard(
                        title = "COMPLIANCE",
                        subtitle = "KYC & AML Screener",
                        icon = Icons.Default.Gavel,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_compliance"),
                        onClick = { viewModel.navigateTo("COMPLIANCE") }
                    )
                }
            }
        }

        // Live Swiss Bullion Market Ticker
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE SWISS GOLD PRICE (XAU/CHF)",
                        color = BrushedSteel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Green)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "CHF ${String.format("%,.2f", spotPrice).replace(',', '\'')}",
                        color = MutedGold,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "+0.42% (Today)",
                        color = Color.Green,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // List of Allocated Gold Bars owned
        item {
            Text(
                text = "YOUR PHYSICAL ALLOCATIONS",
                color = MutedGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        val allocatedBars = goldBars.filter { it.status == "ALLOCATED" }
        if (allocatedBars.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No physical bars currently allocated. Secure a bar via the Buy Bullion interface.",
                        color = BrushedSteel,
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(allocatedBars) { bar ->
                BarAllocationRow(bar = bar) {
                    viewModel.selectedBar.value = bar
                    viewModel.navigateTo("BAR_PASSPORT")
                }
            }
        }
    }
}

@Composable
fun ServiceCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(84.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = DarkSteel),
        border = BorderStroke(0.8.dp, Graphite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Graphite),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MutedGold,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    color = SwissWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = BrushedSteel,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Light
                )
            }
        }
    }
}

@Composable
fun BarAllocationRow(bar: GoldBar, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Graphite, RoundedCornerShape(8.dp))
            .background(DarkSteel)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Graphite)
                    .border(0.5.dp, MutedGold.copy(alpha = 0.3f), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Symbolic representation of physical bar
                Text(
                    text = "AU",
                    color = MutedGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Column {
                Text(
                    text = bar.id,
                    color = SwissWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${bar.refiner} • ${bar.vaultId}",
                    color = BrushedSteel,
                    fontSize = 10.sp
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${String.format("%,.0f", bar.weightGrams)} g",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Purity ${bar.fineness}",
                color = BrushedSteel,
                fontSize = 10.sp
            )
        }
    }
}
