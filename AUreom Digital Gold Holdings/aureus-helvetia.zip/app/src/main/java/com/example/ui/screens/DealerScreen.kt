package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TaxRule
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel

@Composable
fun DealerScreen(viewModel: GoldViewModel) {
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()
    val reconciliationDiscrepancy by viewModel.reconciliationDiscrepancy.collectAsState()
    val reconciliationMessage by viewModel.reconciliationMessage
    val isSimulationExceptionActive by viewModel.isSimulationExceptionActive
    val taxRules by viewModel.taxRules.collectAsState()

    val balanceSheet = viewModel.getDoubleEntrySheet()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
                }
                Column {
                    Text(
                        text = "DEALER DESK & COMPLIANCE",
                        color = MutedGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Internal Swiss precious metal dual-control desk and audits",
                        color = BrushedSteel,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Section 1: Double-Entry Balance Audit Sheet
        item {
            Text(text = "SWISS DOUBLE-ENTRY JOURNAL STATS", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "CASH ASSETS / DEPOSITS", color = SwissWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "CHF ${String.format("%,.2f", balanceSheet.cashAssets).replace(',', '\'')}", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "CASH LIABILITIES", color = BrushedSteel, fontSize = 11.sp)
                    Text(text = "CHF ${String.format("%,.2f", balanceSheet.cashLiabilities).replace(',', '\'')}", color = SwissWhite, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = Graphite, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "METAL HOLDINGS (LEDGER)", color = SwissWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${String.format("%.3f", balanceSheet.metalAssetsOz)} oz", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "METAL ALLOCATIONS", color = BrushedSteel, fontSize = 11.sp)
                    Text(text = "${String.format("%.3f", balanceSheet.metalLiabilitiesOz)} oz", color = SwissWhite, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Graphite, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.DoneAll, contentDescription = "Balanced", tint = Color.Green, modifier = Modifier.size(16.dp))
                        Text(text = "JOURNAL BALANCE", color = Color.Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(text = "PERFECTLY BALANCED (0.000)", color = Color.Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section 2: Vault Daily Reconciliation
        item {
            Text(text = "DAILY FORTRESS RECONCILIATION", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(20.dp)
            ) {
                Text(
                    text = "RECONCILIATION OUTPUT REPORT",
                    color = BrushedSteel,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Graphite, RoundedCornerShape(4.dp))
                        .background(DeepBlack)
                        .padding(14.dp)
                ) {
                    Text(
                        text = reconciliationMessage,
                        color = if (reconciliationMessage.startsWith("EXCEPTION")) Color.Red else SwissWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("reconciliation_output_log")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.checkReconciliation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("run_reconciliation_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        border = BorderStroke(1.dp, MutedGold.copy(alpha = 0.4f))
                    ) {
                        Text(text = "Run Reconcile", color = SwissWhite, fontSize = 11.sp)
                    }

                    // Discrepancy Toggle Simulation button
                    Button(
                        onClick = { viewModel.toggleSimulationException(!isSimulationExceptionActive) },
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("simulate_exception_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSimulationExceptionActive) ForestGreen else Burgundy)
                    ) {
                        Text(
                            text = if (isSimulationExceptionActive) "Resolve Exception" else "Trigger Discrepancy",
                            color = SwissWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section 3: Swiss Tax Rules version administrative panel
        item {
            Text(text = "SWISS TAX REGULATORY VERSION CONTROLS", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        items(taxRules) { rule ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Graphite, RoundedCornerShape(8.dp))
                    .background(DarkSteel)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RULE ID: ${rule.ruleId}",
                        color = SwissWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ForestGreen)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = rule.approvalStatus, color = SwissWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                SpecValueRow(label = "EFFECTIVE DATE", value = rule.effectiveDate)
                SpecValueRow(label = "PRODUCT CLASSIFICATION", value = rule.productClassification)
                SpecValueRow(label = "FINENESS THRESHOLD", value = "${rule.finenessThreshold}‰")
                SpecValueRow(label = "VAT ASSESSMENT STATUS", value = rule.vatTreatment)
                SpecValueRow(label = "CUSTODIAL WAREHOUSE TREAT", value = rule.storageTreatment)
                SpecValueRow(label = "REGULATORY REFERENCE SOURCE", value = rule.sourceReference)
                SpecValueRow(label = "ENGINE VERSION CONFIG", value = "v${rule.version}")
            }
        }
    }
}

@Composable
fun SpecValueRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = BrushedSteel, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = SwissWhite, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}
