package com.example.data

import java.util.UUID

// Representation of a physical movement or custody state event
data class PassportEvent(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long,
    val eventType: String, // BAR_RECEIVED, BAR_ASSAYED, BAR_CERTIFIED, BAR_VAULTED, BAR_ALLOCATED, BAR_TRANSFERRED, BAR_DELIVERED
    val location: String,
    val operator: String,
    val description: String
)

// AUREUS HELVETIA Fundamental Digital Twin Object: The Physical Gold Bar
data class GoldBar(
    val id: String, // Serial number e.g. AU-CH-2026-004821
    val weightGrams: Double,
    val fineness: Double, // e.g. 999.9
    val fineGoldGrams: Double = weightGrams * (fineness / 1000.0),
    val refiner: String,
    val assayMethod: String,
    val vaultId: String, // ZH-01, GE-02, etc.
    val compartment: String, // A-17
    val ownerId: String,
    val status: String, // ALLOCATED, VAULTED, IN_TRANSIT, RELEASED, DELIVERED
    val manufactureDate: String,
    val passportEvents: List<PassportEvent> = emptyList(),
    val premiumPercent: Double = 0.85
) {
    val fineGoldOz: Double get() = fineGoldGrams / 31.1034768
}

// Sovereign Bullion & Investment Coins
data class GoldCoin(
    val id: String,
    val name: String,
    val country: String,
    val mint: String,
    val year: Int,
    val fineGoldWeightOz: Double,
    val fineness: Double, // e.g. 900.0, 999.9
    val grossWeightGrams: Double,
    val condition: String, // e.g. "Brilliant Uncirculated"
    val status: String, // VAULTED, DELIVERED
    val premiumPercent: Double,
    val costBasisCHF: Double
)

// Double-Entry Ledger System: Cash, Metal, and Custody Ledgers
data class LedgerEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long,
    val ledgerType: String, // "METAL" (oz), "CASH" (CHF), "CUSTODY" (Bar tracking)
    val accountId: String, // Client or Vault Account
    val debit: Double, // Cash or Metal Increase
    val credit: Double, // Cash or Metal Decrease
    val unit: String, // "CHF", "OUNCES", "BAR_COUNT"
    val description: String,
    val referenceId: String // OrderId, TransferId, etc.
)

// Swiss Vault Digital Twin Layout
data class VaultZone(
    val zoneId: String, // "A", "B", "C"
    val name: String,
    val description: String,
    val securityLevel: String, // "LEVEL_4_SEISMIC", "LEVEL_5_MILITARY_GRADE"
    val capacityBars: Int,
    val occupiedBars: Int
)

data class VaultMetrics(
    val vaultId: String,
    val city: String,
    val facilityName: String,
    val zones: List<VaultZone>,
    val reconciliationStatus: String, // RECONCILED, EXCEPTION
    val lastAuditDate: String,
    val insuranceLimitCHF: Double,
    val tempCelsius: Double,
    val humidityPercent: Double,
    val securityStatus: String // "SECURE_STANDBY", "ARMED_GUARD"
) {
    val totalCapacity: Int get() = zones.sumOf { it.capacityBars }
    val totalOccupied: Int get() = zones.sumOf { it.occupiedBars }
}

// Versioned Swiss VAT & Import Tax Engine
data class TaxRule(
    val ruleId: String,
    val jurisdiction: String, // de-CH, fr-CH, etc.
    val effectiveDate: String,
    val productClassification: String, // "INVESTMENT_GOLD_BAR", "GOLD_COIN_LEGAL_TENDER"
    val finenessThreshold: Double, // e.g. 995.0 for bars, 900.0 for coins
    val vatTreatment: String, // "VAT_EXEMPT_0_PCT", "STANDARD_7_7_PCT", "STANDARD_8_1_PCT"
    val importTreatment: String, // "DUTY_FREE", "DECLARATION_REQUIRED"
    val storageTreatment: String, // "VAT_FREE_WAREHOUSE_OCTG"
    val deliveryTreatment: String, // "DOMESTIC_SHIPPING_VAT"
    val version: String,
    val sourceReference: String,
    val approvalStatus: String // "APPROVED", "DRAFT"
)

// Professional RFQ (Request for Quote) Architecture
data class RfqQuote(
    val rfqId: String,
    val clientId: String,
    val productId: String, // e.g. "BAR_100G"
    val productName: String,
    val weightGrams: Double,
    val spotPriceCHF: Double,
    val premiumCHF: Double,
    val totalCHF: Double,
    val expiresAt: Long,
    var status: String // PENDING, ACCEPTED, EXPIRED, EXECUTED
)

// Client Account Representation
data class ClientAccount(
    val clientId: String,
    val name: String,
    val goldAccountType: String, // "PRIVATE_PRESTIGE", "FAMILY_OFFICE_MULTISIG", "INSTITUTIONAL"
    val segment: String, // "ZÜRICH_WH", "GENEVA_PB", "BASEL_INST"
    val cashBalanceCHF: Double,
    val unallocatedBalanceOz: Double,
    val status: String // "ACTIVE", "KYC_PENDING", "RECONCILING"
)

// Prestige Custody Document Generation Model
data class CustodyDocument(
    val id: String,
    val docNumber: String,
    val title: String,
    val docType: String, // STATEMENT, TRANSACTION_CONFIRM, TAX_REPORT, ALLOCATION_CERTIFICATE
    val dateString: String,
    val clientName: String,
    val clientId: String,
    val totalOunces: Double,
    val valuationCHF: Double,
    val details: Map<String, String>,
    val verifiedHash: String, // Cryptographically signed audit string
    val isSigned: Boolean = true
)

// Swiss Compliance Audit & Screening Model
data class ComplianceCase(
    val caseId: String,
    val clientName: String,
    val amlRiskLevel: String, // LOW, MEDIUM, HIGH
    val screeningStatus: String, // CLEARED, REVIEW_REQUIRED, SUSPONDED
    val sourceOfWealth: String, // "Inherited Estate", "Corporate Exit Zurich", etc.
    val beneficialOwner: String,
    val customDeclarationSigned: Boolean,
    val sanctionsScreened: Boolean,
    val transactionsFlagged: Int = 0
)

// Double-Entry Balanced Status
data class DoubleEntryStatus(
    val isBalanced: Boolean,
    val cashAssets: Double,
    val cashLiabilities: Double,
    val metalAssetsOz: Double,
    val metalLiabilitiesOz: Double,
    val discrepancy: String
)
