package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(val text: String)

@JsonClass(generateAdapter = true)
data class GeminiContent(val parts: List<GeminiPart>)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(val content: GeminiContent)

@JsonClass(generateAdapter = true)
data class GeminiResponse(val candidates: List<GeminiCandidate>?)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: GeminiApiService = retrofit.create(GeminiApiService::class.java)

    // Generates the authoritative context based on actual, live, authorized application state
    fun buildSystemInstruction(
        client: ClientAccount,
        bars: List<GoldBar>,
        coins: List<GoldCoin>,
        spotPrice: Double,
        ledger: List<LedgerEntry>
    ): String {
        val barsSummary = bars.joinToString("\n") { bar ->
            "- Serial: ${bar.id}, Weight: ${bar.weightGrams}g, Purity: ${bar.fineness}‰, Pure Gold: ${String.format("%.3f", bar.fineGoldOz)} oz, Status: ${bar.status}, Vault: ${bar.vaultId}, Compartment: ${bar.compartment}, Refiner: ${bar.refiner}"
        }

        val coinsSummary = coins.joinToString("\n") { coin ->
            "- ${coin.name} (${coin.year}), Weight: ${coin.fineGoldWeightOz} oz, Status: ${coin.status}, Premium: ${coin.premiumPercent}%"
        }

        val recentLedger = ledger.takeLast(10).joinToString("\n") { entry ->
            "- [${entry.ledgerType}] ${entry.description}: Debit=${entry.debit}, Credit=${entry.credit} ${entry.unit}"
        }

        return """
            You are AUREUS AI, the elite Swiss private gold vaulting assistant representing AUREUS HELVETIA.
            Your clients are ultra-high-net-worth individuals, family offices, and institutions who value security, precision, and complete technical accuracy.
            You have access to the client's actual, verified account records shown below.
            You must ONLY reply based on this data. NEVER fabricate ownership, serial numbers, balances, locations, or custody states. If asked about items not present in this data, state that you do not see them on the official ledger.
            When referencing bars or balances, cite their exact serial numbers and values.

            --- AUTHORITATIVE CLIENT LEDGER DATA ---
            Client ID: ${client.clientId}
            Client Name: ${client.name}
            Account Type: ${client.goldAccountType}
            Cash Balance: CHF ${String.format("%,.2f", client.cashBalanceCHF)}
            Unallocated Gold Balance: ${client.unallocatedBalanceOz} oz
            Current Gold Spot Price: CHF ${String.format("%,.2f", spotPrice)} per Ounce

            Allocated Gold Bars (Fundamental physical objects):
            $barsSummary

            Sovereign Bullion Coins:
            $coinsSummary

            Recent Accounting ledger (Double-entry history):
            $recentLedger
            
            Current Storage Cost Estimate: CHF 18,421 / year (Prestige premium insurance and armed guard custody included).
            
            Guidelines:
            - Keep your tone highly professional, calm, elite, and Swiss-focused.
            - Always cite the specific gold bar serial number (e.g., AU-CH-2026-004821) when discussing specific physical assets.
            - Use Swiss notation for numbers (e.g., CHF 8'421'550.00 or CHF 302'481.70).
            - Avoid emoji overload; be precise and sophisticated.
        """.trimIndent()
    }
}
