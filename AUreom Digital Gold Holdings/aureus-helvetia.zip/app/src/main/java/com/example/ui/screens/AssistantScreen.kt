package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.GoldViewModel
import kotlinx.coroutines.launch

@Composable
fun AssistantScreen(viewModel: GoldViewModel) {
    val chatHistory = viewModel.chatHistory
    val isChatLoading by viewModel.isChatLoading
    val inputMessage by viewModel.inputMessageText

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Scroll to bottom on new messages
    LaunchedEffect(chatHistory.size, isChatLoading) {
        if (chatHistory.isNotEmpty()) {
            coroutineScope.launch {
                listState.animateScrollToItem(chatHistory.size - 1)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        // Back Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedGold)
            }
            Column {
                Text(
                    text = "AUREUS HELVETIA PRIVATE ASSISTANT",
                    color = MutedGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Secure AI assistant verified against the client ledger",
                    color = BrushedSteel,
                    fontSize = 11.sp
                )
            }
        }

        Divider(color = Graphite, thickness = 0.8.dp)

        // Suggestion Chips (Pre-built quick Swiss private banking questions)
        val suggestions = listOf(
            "How much gold do I have in Zürich?",
            "What is my gold exposure in CHF?",
            "Which bars are currently available for delivery?",
            "What did storage cost me last year?"
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestions.take(2).forEach { suggest ->
                SuggestionChip(text = suggest) {
                    viewModel.sendChatMessage(suggest)
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestions.drop(2).forEach { suggest ->
                SuggestionChip(text = suggest) {
                    viewModel.sendChatMessage(suggest)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Chat Bubble list
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chatHistory) { (text, isUser) ->
                    ChatBubble(text = text, isUser = isUser)
                }

                if (isChatLoading) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                color = MutedGold,
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 1.5.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Consulting Swiss registers...", color = BrushedSteel, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Divider(color = Graphite, thickness = 0.8.dp)

        // Input bottom bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TextField(
                value = inputMessage,
                onValueChange = { viewModel.inputMessageText.value = it },
                placeholder = { Text("Ask about your bars, balances, storage...", color = BrushedSteel, fontSize = 13.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = DarkSteel,
                    unfocusedContainerColor = DarkSteel,
                    focusedTextColor = SwissWhite,
                    unfocusedTextColor = SwissWhite,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .testTag("assistant_input_text"),
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (inputMessage.isNotBlank()) {
                        viewModel.sendChatMessage(inputMessage)
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MutedGold)
                    .testTag("assistant_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = DeepBlack, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun SuggestionChip(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .border(0.8.dp, Graphite, RoundedCornerShape(20.dp))
            .background(DarkSteel)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = text, color = MutedGold, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ChatBubble(text: String, isUser: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 12.dp,
                        topEnd = 12.dp,
                        bottomStart = if (isUser) 12.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 12.dp
                    )
                )
                .background(if (isUser) MutedGold else DarkSteel)
                .padding(14.dp)
        ) {
            Text(
                text = text,
                color = if (isUser) DeepBlack else SwissWhite,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                fontWeight = if (isUser) FontWeight.SemiBold else FontWeight.Light
            )
        }
    }
}
