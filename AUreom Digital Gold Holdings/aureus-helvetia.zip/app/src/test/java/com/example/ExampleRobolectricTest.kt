package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GoldRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource matches Aureus Helvetia`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureus Helvetia", appName)
    }

    @Test
    fun `verify gold weight conversions are precise`() {
        val grams = 100.0
        val ounces = GoldRepository.gramsToOunces(grams)
        // 100g should be approx 3.215074 oz
        assertEquals(3.215074, ounces, 0.001)

        val backToGrams = GoldRepository.ouncesToGrams(ounces)
        assertEquals(grams, backToGrams, 0.001)
    }

    @Test
    fun `verify RFQ pricing calculations and premium sliding scale`() {
        // Request quote for 100g bar
        val rfq100g = GoldRepository.requestRfq("BAR_100G", 100.0)
        
        // Assert weight matches
        assertEquals(100.0, rfq100g.weightGrams, 0.01)
        
        // Assert total = spot + premium
        assertEquals(rfq100g.totalCHF, rfq100g.spotPriceCHF + rfq100g.premiumCHF, 0.01)

        // Request quote for 1kg bar (premium should be sliding scale smaller, i.e., 0.48%)
        val rfq1kg = GoldRepository.requestRfq("BAR_1KG", 1000.0)
        val expectedPremiumRatio = rfq1kg.premiumCHF / rfq1kg.spotPriceCHF
        assertEquals(0.0048, expectedPremiumRatio, 0.0001)
    }

    @Test
    fun `verify double entry ledger audit invariants`() {
        val balanceSheet = GoldRepository.getDoubleEntryBalanceSheet()
        
        // Assert double-entry balance sheets are strictly in balance with 0 discrepancy
        assertTrue(balanceSheet.isBalanced)
        assertEquals(balanceSheet.cashAssets, balanceSheet.cashLiabilities, 0.001)
        assertEquals(balanceSheet.metalAssetsOz, balanceSheet.metalLiabilitiesOz, 0.001)
    }

    @Test
    fun `verify vault daily reconciliation and exception reports`() {
        // Secure stable state
        GoldRepository.triggerSimulationException(false)
        val reconciledReport = GoldRepository.runDailyReconciliation()
        assertTrue(reconciledReport.startsWith("RECONCILED"))

        // Trigger discrepancy simulation
        GoldRepository.triggerSimulationException(true)
        val exceptionReport = GoldRepository.runDailyReconciliation()
        assertTrue(exceptionReport.startsWith("EXCEPTION"))
        
        // Clear again
        GoldRepository.triggerSimulationException(false)
        val recoveredReport = GoldRepository.runDailyReconciliation()
        assertTrue(recoveredReport.startsWith("RECONCILED"))
    }
}
