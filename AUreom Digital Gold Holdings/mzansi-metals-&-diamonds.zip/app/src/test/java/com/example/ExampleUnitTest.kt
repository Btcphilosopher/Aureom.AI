package com.example

import com.example.data.model.*
import com.example.data.pricing.PricingEngine
import com.example.data.repository.MzansiRepository
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal

class ExampleUnitTest {

    @Test
    fun testGoldPricingEngine() {
        val quote = PricingEngine.calculateGoldBuyPrice(
            grossWeightGrams = 100.0,
            purity = Purity.PURITY_9999,
            productType = ProductType.CAST_BAR
        )
        assertNotNull(quote)
        assertTrue(quote.totalNetZar > BigDecimal.ZERO)
        assertEquals(99.99, quote.fineWeightGrams, 0.01)
    }

    @Test
    fun testDiamondValuationEngine() {
        val valuation = PricingEngine.calculateIndicativeDiamondValuation(
            carat = 2.14,
            color = Color.G,
            clarity = Clarity.VS1,
            cut = CutGrade.EXCELLENT,
            shape = Shape.ROUND_BRILLIANT,
            fluorescence = "None"
        )
        assertTrue(valuation > BigDecimal.ZERO)
    }

    @Test
    fun testMzansiRepositoryTradeAndReconciliation() {
        val repo = MzansiRepository()
        val key = "TEST-KEY-1"

        val buyRes = repo.buyGold(
            productType = ProductType.CAST_BAR,
            grossGrams = 100.0,
            purity = Purity.PURITY_9999,
            vaultLocation = "Johannesburg Central Bullion Vault",
            idempotencyKey = key
        )

        assertTrue(buyRes.isSuccess)
        val bar = buyRes.getOrNull()
        assertNotNull(bar)
        assertEquals(AllocationStatus.ALLOCATED, bar?.allocationStatus)

        // Verify duplicate idempotency key fails
        val dupRes = repo.buyGold(
            productType = ProductType.CAST_BAR,
            grossGrams = 100.0,
            purity = Purity.PURITY_9999,
            vaultLocation = "Johannesburg Central Bullion Vault",
            idempotencyKey = key
        )
        assertTrue(dupRes.isFailure)

        // Run reconciliation
        val recon = repo.runReconciliation()
        assertNotNull(recon)
    }
}
