package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.LivePriceTickerBar
import com.example.ui.components.MzansiTopAppBar
import com.example.ui.screens.*
import com.example.ui.theme.CharcoalDark
import com.example.ui.theme.MzansiTheme
import com.example.ui.viewmodel.AppViewMode
import com.example.ui.viewmodel.MzansiViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MzansiTheme {
                val viewModel: MzansiViewModel = viewModel()
                val currentMode by viewModel.viewMode.collectAsState()
                val selectedCurrency by viewModel.selectedCurrency.collectAsState()
                val userMessage by viewModel.userMessage.collectAsState()

                val snackbarHostState = remember { SnackbarHostState() }
                val scope = rememberCoroutineScope()

                LaunchedEffect(userMessage) {
                    userMessage?.let { msg ->
                        scope.launch {
                            snackbarHostState.showSnackbar(msg)
                            viewModel.clearUserMessage()
                        }
                    }
                }

                Scaffold(
                    topBar = {
                        Column {
                            MzansiTopAppBar(
                                currentMode = currentMode,
                                onModeSelect = { viewModel.setViewMode(it) },
                                selectedCurrency = selectedCurrency,
                                onCurrencySelect = { viewModel.setSelectedCurrency(it) }
                            )
                            LivePriceTickerBar(selectedCurrency = selectedCurrency)
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = CharcoalDark
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentMode) {
                            AppViewMode.CUSTOMER_MOBILE -> CustomerMobileAppView(viewModel)
                            AppViewMode.INSTITUTIONAL_TERMINAL -> MerchantTerminalView(viewModel)
                            AppViewMode.GEOGRAPHIC_MAP -> SouthAfricanMapScreen(viewModel)
                            AppViewMode.DEMO_SIMULATOR -> DemoWalkthroughSimulatorScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}
