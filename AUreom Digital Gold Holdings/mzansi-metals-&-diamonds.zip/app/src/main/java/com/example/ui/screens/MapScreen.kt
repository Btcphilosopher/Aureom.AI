package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FacilityNode
import com.example.data.model.SACity
import com.example.ui.components.ComplianceBadge
import com.example.ui.components.DetailPair
import com.example.ui.theme.*
import com.example.ui.viewmodel.MzansiViewModel

@Composable
fun SouthAfricanMapScreen(viewModel: MzansiViewModel) {
    val facilities by viewModel.repository.facilities.collectAsState()
    var selectedFacility by remember { mutableStateOf<FacilityNode?>(facilities.firstOrNull()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("SOUTH AFRICAN PHYSICAL VAULT & LOGISTICS NETWORK", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Interactive node map of Johannesburg, Kimberley, Cape Town, Durban, Pretoria & OR Tambo Facilities.", fontSize = 11.sp, color = TextMuted)
        }

        item {
            // Stylized Geographic Node Map Canvas Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(Brush.radialGradient(listOf(Color(0xFF1E2430), SurfaceDark)))
                        .padding(16.dp)
                ) {
                    Column {
                        Text("REPUBLIC OF SOUTH AFRICA - SECURED NODES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldPrimary, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual Map Node Pins
                        Box(modifier = Modifier.fillMaxSize()) {
                            // JHB Node
                            MapNodePin(
                                city = SACity.JOHANNESBURG,
                                isSelected = selectedFacility?.city == SACity.JOHANNESBURG,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.JOHANNESBURG } },
                                modifier = Modifier.align(Alignment.Center)
                            )
                            // Pretoria
                            MapNodePin(
                                city = SACity.PRETORIA,
                                isSelected = selectedFacility?.city == SACity.PRETORIA,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.PRETORIA } },
                                modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp, start = 20.dp)
                            )
                            // Kimberley
                            MapNodePin(
                                city = SACity.KIMBERLEY,
                                isSelected = selectedFacility?.city == SACity.KIMBERLEY,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.KIMBERLEY } },
                                modifier = Modifier.align(Alignment.CenterStart).padding(start = 20.dp)
                            )
                            // Cape Town
                            MapNodePin(
                                city = SACity.CAPE_TOWN,
                                isSelected = selectedFacility?.city == SACity.CAPE_TOWN,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.CAPE_TOWN } },
                                modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 20.dp, start = 10.dp)
                            )
                            // Durban
                            MapNodePin(
                                city = SACity.DURBAN,
                                isSelected = selectedFacility?.city == SACity.DURBAN,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.DURBAN } },
                                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 20.dp)
                            )
                            // OR Tambo
                            MapNodePin(
                                city = SACity.OR_TAMBO,
                                isSelected = selectedFacility?.city == SACity.OR_TAMBO,
                                onClick = { selectedFacility = facilities.find { it.city == SACity.OR_TAMBO } },
                                modifier = Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = 30.dp)
                            )
                        }
                    }
                }
            }
        }

        selectedFacility?.let { fac ->
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(1.dp, GoldPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(fac.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = IvoryText)
                            ComplianceBadge(text = fac.securityLevel)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(fac.roleDescription, fontSize = 11.sp, color = TextMuted)

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = BorderDark)
                        Spacer(modifier = Modifier.height(14.dp))

                        Text("FACILITY PHYSICAL HOLDINGS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            DetailPair("Gold Vault", "${fac.goldVaultKg} kg")
                            DetailPair("Silver Vault", "${fac.silverVaultKg} kg")
                            DetailPair("Diamond Vault", "${fac.diamondVaultCarats} ct")
                        }
                    }
                }
            }
        }

        item {
            Text("ALL SOUTH AFRICAN FACILITY NODES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        }

        items(facilities) { fac ->
            Surface(
                onClick = { selectedFacility = fac },
                shape = RoundedCornerShape(10.dp),
                color = SurfaceDark,
                border = BorderStroke(1.dp, if (fac.id == selectedFacility?.id) GoldPrimary else BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = "Vault", tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(fac.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
                        Text(fac.roleDescription, fontSize = 10.sp, color = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun MapNodePin(
    city: SACity,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) GoldPrimary else SurfaceVariantDark,
        border = BorderStroke(1.dp, if (isSelected) GoldLight else BorderDark),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) Color.Black else GoldPrimary)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = city.label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.Black else IvoryText
            )
        }
    }
}
