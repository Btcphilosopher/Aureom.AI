package com.example.data.pricing

import com.example.data.model.*
import java.math.BigDecimal
import java.math.RoundingMode

object PricingEngine {
    // Synthetic Spot Benchmarks (USD)
    private var xauUsdSpot: Double = 2650.00 // Gold $/oz
    private var xagUsdSpot: Double = 31.50   // Silver $/oz
    private var usdZarRate: Double = 18.25   // USD/ZAR

    // FX Table relative to ZAR (1 Unit = X ZAR)
    private val fxMap = mutableMapOf(
        CurrencyCode.ZAR to 1.0,
        CurrencyCode.USD to 18.25,
        CurrencyCode.EUR to 19.80,
        CurrencyCode.GBP to 23.50,
        CurrencyCode.CHF to 21.10,
        CurrencyCode.AED to 4.97,
        CurrencyCode.SGD to 14.10,
        CurrencyCode.HKD to 2.34,
        CurrencyCode.CNY to 2.58,
        CurrencyCode.CNH to 2.57,
        CurrencyCode.JPY to 0.122,
        CurrencyCode.AUD to 12.35,
        CurrencyCode.INR to 0.218
    )

    fun getFxRateToZar(code: CurrencyCode): Double {
        return fxMap[code] ?: 1.0
    }

    fun getXauUsdSpot(): Double = xauUsdSpot
    fun getXagUsdSpot(): Double = xagUsdSpot
    fun getUsdZar(): Double = usdZarRate

    // Gold Price in ZAR per Gram
    fun getGoldSpotZarPerGram(): BigDecimal {
        // 1 oz = 31.1035 grams
        val zarPerOz = xauUsdSpot * usdZarRate
        val zarPerGram = zarPerOz / 31.1035
        return BigDecimal(zarPerGram).setScale(2, RoundingMode.HALF_UP)
    }

    fun getGoldSpotZarPerKg(): BigDecimal {
        val perGram = getGoldSpotZarPerGram()
        return perGram.multiply(BigDecimal(1000)).setScale(2, RoundingMode.HALF_UP)
    }

    // Silver Price in ZAR per Gram and Kg
    fun getSilverSpotZarPerGram(): BigDecimal {
        val zarPerOz = xagUsdSpot * usdZarRate
        val zarPerGram = zarPerOz / 31.1035
        return BigDecimal(zarPerGram).setScale(2, RoundingMode.HALF_UP)
    }

    fun getSilverSpotZarPerKg(): BigDecimal {
        val perGram = getSilverSpotZarPerGram()
        return perGram.multiply(BigDecimal(1000)).setScale(2, RoundingMode.HALF_UP)
    }

    data class MetalQuoteBreakdown(
        val fineWeightGrams: Double,
        val purityMultiplier: Double,
        val benchmarkZar: BigDecimal,
        val localPremiumZar: BigDecimal,
        val productPremiumZar: BigDecimal,
        val dealerSpreadZar: BigDecimal,
        val vaultCostZar: BigDecimal,
        val totalNetZar: BigDecimal
    )

    fun calculateGoldBuyPrice(
        grossWeightGrams: Double,
        purity: Purity,
        productType: ProductType,
        includeVaultFee: Boolean = true
    ): MetalQuoteBreakdown {
        val fineGrams = grossWeightGrams * purity.multiplier
        val spotPerGram = getGoldSpotZarPerGram()
        val benchmark = spotPerGram.multiply(BigDecimal(fineGrams))

        // Premiums
        val localPremiumPct = 0.008 // 0.8% SA local transport & refiner fee
        val productPremiumPct = when (productType) {
            ProductType.MINTED_BAR -> 0.025
            ProductType.INVESTMENT_COIN -> 0.035
            ProductType.CAST_BAR -> 0.015
            else -> 0.010
        }
        val dealerSpreadPct = 0.012 // 1.2% dealer margin
        val vaultFee = if (includeVaultFee) BigDecimal("450.00") else BigDecimal.ZERO

        val localPremium = benchmark.multiply(BigDecimal(localPremiumPct))
        val productPremium = benchmark.multiply(BigDecimal(productPremiumPct))
        val dealerSpread = benchmark.multiply(BigDecimal(dealerSpreadPct))

        val total = benchmark
            .add(localPremium)
            .add(productPremium)
            .add(dealerSpread)
            .add(vaultFee)
            .setScale(2, RoundingMode.HALF_UP)

        return MetalQuoteBreakdown(
            fineWeightGrams = fineGrams,
            purityMultiplier = purity.multiplier,
            benchmarkZar = benchmark.setScale(2, RoundingMode.HALF_UP),
            localPremiumZar = localPremium.setScale(2, RoundingMode.HALF_UP),
            productPremiumZar = productPremium.setScale(2, RoundingMode.HALF_UP),
            dealerSpreadZar = dealerSpread.setScale(2, RoundingMode.HALF_UP),
            vaultCostZar = vaultFee,
            totalNetZar = total
        )
    }

    fun calculateGoldSellPrice(
        grossWeightGrams: Double,
        purity: Purity,
        productType: ProductType
    ): MetalQuoteBreakdown {
        val fineGrams = grossWeightGrams * purity.multiplier
        val spotPerGram = getGoldSpotZarPerGram()
        val benchmark = spotPerGram.multiply(BigDecimal(fineGrams))

        val dealerBidDiscountPct = 0.008 // 0.8% bid discount
        val refinerDiscount = benchmark.multiply(BigDecimal(dealerBidDiscountPct))

        val totalNet = benchmark.subtract(refinerDiscount).setScale(2, RoundingMode.HALF_UP)

        return MetalQuoteBreakdown(
            fineWeightGrams = fineGrams,
            purityMultiplier = purity.multiplier,
            benchmarkZar = benchmark.setScale(2, RoundingMode.HALF_UP),
            localPremiumZar = BigDecimal.ZERO,
            productPremiumZar = BigDecimal.ZERO,
            dealerSpreadZar = refinerDiscount.setScale(2, RoundingMode.HALF_UP),
            vaultCostZar = BigDecimal.ZERO,
            totalNetZar = totalNet
        )
    }

    fun calculateSilverBuyPrice(
        grossWeightGrams: Double,
        purity: Purity,
        productType: ProductType
    ): MetalQuoteBreakdown {
        val fineGrams = grossWeightGrams * purity.multiplier
        val spotPerGram = getSilverSpotZarPerGram()
        val benchmark = spotPerGram.multiply(BigDecimal(fineGrams))

        val premiumPct = 0.045 // 4.5% premium on silver physical products
        val premium = benchmark.multiply(BigDecimal(premiumPct))
        val total = benchmark.add(premium).setScale(2, RoundingMode.HALF_UP)

        return MetalQuoteBreakdown(
            fineWeightGrams = fineGrams,
            purityMultiplier = purity.multiplier,
            benchmarkZar = benchmark.setScale(2, RoundingMode.HALF_UP),
            localPremiumZar = premium.setScale(2, RoundingMode.HALF_UP),
            productPremiumZar = BigDecimal.ZERO,
            dealerSpreadZar = BigDecimal.ZERO,
            vaultCostZar = BigDecimal.ZERO,
            totalNetZar = total
        )
    }

    // INDICATIVE SYNTHETIC DIAMOND VALUATION ENGINE
    fun calculateIndicativeDiamondValuation(
        carat: Double,
        color: Color,
        clarity: Clarity,
        cut: CutGrade,
        shape: Shape,
        fluorescence: String
    ): BigDecimal {
        // Base rate per carat in ZAR
        val baseRatePerCarat = 85000.0

        // Size jump factor (carat^1.5 for exponential size premium)
        val caratFactor = Math.pow(carat, 1.45)

        val colorMult = when (color) {
            Color.D -> 1.25
            Color.E -> 1.15
            Color.F -> 1.05
            Color.G -> 0.95
            Color.H -> 0.85
            Color.I -> 0.75
            Color.J -> 0.65
            Color.FANCY_YELLOW -> 1.30
        }

        val clarityMult = when (clarity) {
            Clarity.FL -> 1.35
            Clarity.IF -> 1.25
            Clarity.VVS1 -> 1.15
            Clarity.VVS2 -> 1.05
            Clarity.VS1 -> 0.95
            Clarity.VS2 -> 0.85
            Clarity.SI1 -> 0.72
            Clarity.SI2 -> 0.60
        }

        val cutMult = when (cut) {
            CutGrade.EXCELLENT -> 1.08
            CutGrade.VERY_GOOD -> 1.00
            CutGrade.GOOD -> 0.90
        }

        val fluorMult = if (fluorescence.contains("None", ignoreCase = true)) 1.0 else 0.92

        val totalZar = baseRatePerCarat * caratFactor * colorMult * clarityMult * cutMult * fluorMult
        return BigDecimal(totalZar).setScale(2, RoundingMode.HALF_UP)
    }

    fun convertZarToCurrency(amountZar: BigDecimal, currency: CurrencyCode): String {
        if (currency == CurrencyCode.ZAR) {
            return "R ${amountZar.toPlainString()}"
        }
        val rate = getFxRateToZar(currency)
        val converted = amountZar.toDouble() / rate
        return "${currency.symbol} ${String.format("%.2f", converted)}"
    }

    // Simulate small market tick for real-time feel
    fun updateMarketTick() {
        xauUsdSpot += (Math.random() - 0.49) * 1.5
        xagUsdSpot += (Math.random() - 0.49) * 0.08
        usdZarRate += (Math.random() - 0.49) * 0.02
        if (xauUsdSpot < 2400.0) xauUsdSpot = 2400.0
        if (xagUsdSpot < 25.0) xagUsdSpot = 25.0
        if (usdZarRate < 17.0) usdZarRate = 17.0
        fxMap[CurrencyCode.USD] = usdZarRate
    }
}
