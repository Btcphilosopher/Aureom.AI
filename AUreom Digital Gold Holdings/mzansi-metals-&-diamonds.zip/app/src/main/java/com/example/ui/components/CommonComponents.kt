package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.pricing.PricingEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppViewMode
import java.math.BigDecimal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MzansiTopAppBar(
    currentMode: AppViewMode,
    onModeSelect: (AppViewMode) -> Unit,
    selectedCurrency: CurrencyCode,
    onCurrencySelect: (CurrencyCode) -> Unit
) {
    var currencyMenuExpanded by remember { mutableStateOf(false) }

    Surface(
        color = CharcoalDark,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(GoldPrimary, GoldDark))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = "Logo",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "MZANSI METALS & DIAMONDS",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = IvoryText,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "SOUTH AFRICA • VAULT • BULLION • TENDER",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            color = GoldPrimary,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Currency Selector Dropdown
                Box {
                    Surface(
                        onClick = { currencyMenuExpanded = true },
                        shape = RoundedCornerShape(20.dp),
                        color = SurfaceVariantDark,
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Text(
                                text = selectedCurrency.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Currency",
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = currencyMenuExpanded,
                        onDismissRequest = { currencyMenuExpanded = false },
                        modifier = Modifier.background(SurfaceDark)
                    ) {
                        CurrencyCode.values().forEach { code ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "${code.name} - ${code.displayName}",
                                        color = if (code == selectedCurrency) GoldPrimary else IvoryText,
                                        fontSize = 13.sp
                                    )
                                },
                                onClick = {
                                    onCurrencySelect(code)
                                    currencyMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // View Mode Selector Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ModePill(
                    label = "Customer App",
                    icon = Icons.Outlined.Smartphone,
                    isSelected = currentMode == AppViewMode.CUSTOMER_MOBILE,
                    onClick = { onModeSelect(AppViewMode.CUSTOMER_MOBILE) },
                    modifier = Modifier.weight(1f)
                )
                ModePill(
                    label = "Merchant Terminal",
                    icon = Icons.Outlined.Computer,
                    isSelected = currentMode == AppViewMode.INSTITUTIONAL_TERMINAL,
                    onClick = { onModeSelect(AppViewMode.INSTITUTIONAL_TERMINAL) },
                    modifier = Modifier.weight(1.1f)
                )
                ModePill(
                    label = "SA Map",
                    icon = Icons.Outlined.Map,
                    isSelected = currentMode == AppViewMode.GEOGRAPHIC_MAP,
                    onClick = { onModeSelect(AppViewMode.GEOGRAPHIC_MAP) },
                    modifier = Modifier.weight(0.8f)
                )
                ModePill(
                    label = "Demo",
                    icon = Icons.Outlined.PlayCircle,
                    isSelected = currentMode == AppViewMode.DEMO_SIMULATOR,
                    onClick = { onModeSelect(AppViewMode.DEMO_SIMULATOR) },
                    modifier = Modifier.weight(0.8f)
                )
            }
        }
    }
}

@Composable
fun ModePill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) GoldPrimary else SurfaceVariantDark,
        border = BorderStroke(1.dp, if (isSelected) GoldLight else BorderDark),
        modifier = modifier.height(30.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) Color.Black else TextMuted,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.Black else IvoryText,
                maxLines = 1
            )
        }
    }
}

@Composable
fun LivePriceTickerBar(selectedCurrency: CurrencyCode) {
    val xauG = PricingEngine.getGoldSpotZarPerGram()
    val xagKg = PricingEngine.getSilverSpotZarPerKg()
    val usdZar = PricingEngine.getUsdZar()

    Surface(
        color = SurfaceDark,
        border = BorderStroke(1.dp, BorderDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TickerItem(label = "XAU/ZAR", value = "R ${xauG.toPlainString()}/g", color = GoldPrimary)
            TickerItem(label = "XAG/ZAR", value = "R ${xagKg.toPlainString()}/kg", color = DiamondPlatinum)
            TickerItem(label = "USD/ZAR", value = "R ${String.format("%.2f", usdZar)}", color = MzansiGreenLight)
            TickerItem(label = "XAU/USD", value = "$${String.format("%.1f", PricingEngine.getXauUsdSpot())}", color = GoldLight)
        }
    }
}

@Composable
fun TickerItem(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "$label: ", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Normal)
        Text(text = value, fontSize = 10.sp, color = IvoryText, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PortfolioSummaryCard(
    goldKg: Double,
    silverKg: Double,
    diamondCarats: Double,
    zarCash: BigDecimal,
    selectedCurrency: CurrencyCode
) {
    val goldValueZar = PricingEngine.getGoldSpotZarPerKg().multiply(BigDecimal(goldKg))
    val silverValueZar = PricingEngine.getSilverSpotZarPerKg().multiply(BigDecimal(silverKg))
    val diamondValueZar = BigDecimal(diamondCarats * 95000.0)
    val totalZar = goldValueZar.add(silverValueZar).add(diamondValueZar).add(zarCash)

    val displayTotal = PricingEngine.convertZarToCurrency(totalZar, selectedCurrency)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, BorderDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF232832), SurfaceDark),
                        radius = 800f
                    )
                )
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL METALS & STONES PORTFOLIO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        letterSpacing = 1.sp
                    )
                    ComplianceBadge(text = "SADPMR LICENSED")
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = displayTotal,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = IvoryText
                )

                Text(
                    text = "Consolidated Valuation across 6 SA Vault Nodes",
                    fontSize = 11.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = BorderDark, thickness = 1.dp)
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PortfolioAssetCol(
                        icon = Icons.Default.Shield,
                        label = "Gold",
                        quantity = "${String.format("%.2f", goldKg)} kg",
                        value = PricingEngine.convertZarToCurrency(goldValueZar, selectedCurrency),
                        color = GoldPrimary
                    )
                    PortfolioAssetCol(
                        icon = Icons.Default.Layers,
                        label = "Silver",
                        quantity = "${String.format("%.1f", silverKg)} kg",
                        value = PricingEngine.convertZarToCurrency(silverValueZar, selectedCurrency),
                        color = DiamondPlatinum
                    )
                    PortfolioAssetCol(
                        icon = Icons.Default.Diamond,
                        label = "Diamonds",
                        quantity = "${String.format("%.1f", diamondCarats)} ct",
                        value = PricingEngine.convertZarToCurrency(diamondValueZar, selectedCurrency),
                        color = DiamondAccent
                    )
                    PortfolioAssetCol(
                        icon = Icons.Default.AccountBalanceWallet,
                        label = "Cash",
                        quantity = "ZAR / USD",
                        value = PricingEngine.convertZarToCurrency(zarCash, selectedCurrency),
                        color = MzansiGreenLight
                    )
                }
            }
        }
    }
}

@Composable
fun PortfolioAssetCol(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    quantity: String,
    value: String,
    color: Color
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextMuted)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = quantity, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        Text(text = value, fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ComplianceBadge(text: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1B382B),
        border = BorderStroke(1.dp, MzansiGreen)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(MzansiGreenLight)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = MzansiGreenLight
            )
        }
    }
}

@Composable
fun GoldPassportCard(bar: GoldBar, selectedCurrency: CurrencyCode) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, GoldDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Brush.linearGradient(listOf(GoldLight, GoldPrimary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("AU", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = bar.serialNumber,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = IvoryText,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${bar.productType.label} • ${bar.purity.code}",
                            fontSize = 11.sp,
                            color = GoldPrimary
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF262010),
                    border = BorderStroke(1.dp, GoldPrimary)
                ) {
                    Text(
                        text = "ALLOCATED",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BorderDark)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                DetailPair("Refiner", bar.refiner)
                DetailPair("Fine Weight", "${bar.fineWeightGrams} g")
                DetailPair("Assay Ref", bar.assayReference)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Vault", tint = TextMuted, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = bar.currentVault, fontSize = 10.sp, color = TextMuted)
                }
                Text(
                    text = PricingEngine.convertZarToCurrency(bar.valuationZar, selectedCurrency),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldLight
                )
            }
        }
    }
}

@Composable
fun DiamondPassportCard(diamond: Diamond, selectedCurrency: CurrencyCode) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, DiamondDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Diamond, contentDescription = "Diamond", tint = DiamondAccent, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${diamond.caratWeight} ct ${diamond.shape.displayName}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = IvoryText
                        )
                        Text(
                            text = "Lab: ${diamond.certificate.lab} (${diamond.certificate.certificateNumber})",
                            fontSize = 10.sp,
                            color = DiamondAccent
                        )
                    }
                }
                ComplianceBadge(text = "KIMBERLEY CERTIFIED")
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BorderDark)
            Spacer(modifier = Modifier.height(10.dp))

            // 4Cs Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FourCChip(label = "CARAT", value = "${diamond.caratWeight} ct")
                FourCChip(label = "COLOUR", value = diamond.colour.name)
                FourCChip(label = "CLARITY", value = diamond.clarity.name)
                FourCChip(label = "CUT", value = diamond.cut.name)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Origin: ${diamond.originMine}",
                    fontSize = 10.sp,
                    color = TextMuted
                )
                Text(
                    text = PricingEngine.convertZarToCurrency(diamond.askingPriceZar, selectedCurrency),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DiamondAccent
                )
            }
        }
    }
}

@Composable
fun FourCChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = SurfaceVariantDark,
        border = BorderStroke(1.dp, BorderDark)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(text = label, fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text(text = value, fontSize = 11.sp, color = IvoryText, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DetailPair(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 9.sp, color = TextMuted)
        Text(text = value, fontSize = 11.sp, color = IvoryText, fontWeight = FontWeight.Medium)
    }
}
