package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.pricing.PricingEngine
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MzansiViewModel
import java.math.BigDecimal

@Composable
fun CustomerMobileAppView(viewModel: MzansiViewModel) {
    val currentTab by viewModel.customerTab.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    Scaffold(
        bottomBar = {
            CustomerBottomNavBar(
                selectedTab = currentTab,
                onTabSelect = { viewModel.setCustomerTab(it) }
            )
        },
        containerColor = CharcoalDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> CustomerHomeScreen(viewModel, currency)
                1 -> CustomerMarketScreen(viewModel, currency)
                2 -> CustomerBuySellScreen(viewModel, currency)
                3 -> CustomerPortfolioScreen(viewModel, currency)
                4 -> CustomerVaultPassportsScreen(viewModel, currency)
            }
        }
    }
}

@Composable
fun CustomerBottomNavBar(selectedTab: Int, onTabSelect: (Int) -> Unit) {
    NavigationBar(
        containerColor = SurfaceDark,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { onTabSelect(0) },
            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = GoldPrimary, indicatorColor = SurfaceVariantDark)
        )
        NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { onTabSelect(1) },
            icon = { Icon(imageVector = Icons.Default.ShowChart, contentDescription = "Market") },
            label = { Text("Market", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = GoldPrimary, indicatorColor = SurfaceVariantDark)
        )
        NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { onTabSelect(2) },
            icon = { Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = "Trade") },
            label = { Text("Buy/Sell", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = GoldPrimary, indicatorColor = SurfaceVariantDark)
        )
        NavigationBarItem(
            selected = selectedTab == 3,
            onClick = { onTabSelect(3) },
            icon = { Icon(imageVector = Icons.Default.PieChart, contentDescription = "Portfolio") },
            label = { Text("Portfolio", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = GoldPrimary, indicatorColor = SurfaceVariantDark)
        )
        NavigationBarItem(
            selected = selectedTab == 4,
            onClick = { onTabSelect(4) },
            icon = { Icon(imageVector = Icons.Default.Lock, contentDescription = "Vault") },
            label = { Text("Vault", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = GoldPrimary, indicatorColor = SurfaceVariantDark)
        )
    }
}

@Composable
fun CustomerHomeScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val goldBars by viewModel.repository.goldBars.collectAsState()
    val silverBars by viewModel.repository.silverBars.collectAsState()
    val diamonds by viewModel.repository.diamonds.collectAsState()
    val cust by viewModel.repository.customer.collectAsState()
    val auditEvents by viewModel.repository.auditEvents.collectAsState()

    val goldKg = goldBars.sumOf { it.fineWeightGrams } / 1000.0
    val silverKg = silverBars.sumOf { it.fineWeightGrams } / 1000.0
    val diamondCarats = diamonds.sumOf { it.caratWeight }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            PortfolioSummaryCard(
                goldKg = goldKg,
                silverKg = silverKg,
                diamondCarats = diamondCarats,
                zarCash = cust.zarCashBalance,
                selectedCurrency = currency
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.setCustomerTab(2) },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Buy", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("BUY METALS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.setCustomerTab(2) },
                    border = BorderStroke(1.dp, DiamondPlatinum),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Icon(imageVector = Icons.Default.Diamond, contentDescription = "Stones", tint = DiamondPlatinum, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("BUY DIAMONDS", color = DiamondPlatinum, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        item {
            Text(
                text = "RECENT VAULT & TRADE AUDIT EVENTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 0.8.sp
            )
        }

        items(auditEvents.take(5)) { ev ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = ev.eventType, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                        Text(text = ev.timestamp, fontSize = 10.sp, color = TextMuted)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = ev.payloadSummary, fontSize = 11.sp, color = IvoryText)
                }
            }
        }
    }
}

@Composable
fun CustomerMarketScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val spotGoldG = PricingEngine.getGoldSpotZarPerGram()
    val spotGoldKg = PricingEngine.getGoldSpotZarPerKg()
    val spotSilverKg = PricingEngine.getSilverSpotZarPerKg()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SOUTH AFRICAN SPOT BENCHMARK PRICES",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 1.sp
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("GOLD SPOT (XAU/ZAR)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                        Text(PricingEngine.convertZarToCurrency(spotGoldKg, currency) + " / kg", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Rand Refinery 999.9 Fine Gold Benchmark", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BorderDark)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PurityPriceChip("24K (999.9)", PricingEngine.convertZarToCurrency(spotGoldG, currency) + "/g")
                        PurityPriceChip("999 Fine", PricingEngine.convertZarToCurrency(spotGoldG.multiply(BigDecimal(0.999)), currency) + "/g")
                        PurityPriceChip("916 (22K)", PricingEngine.convertZarToCurrency(spotGoldG.multiply(BigDecimal(0.916)), currency) + "/g")
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SILVER SPOT (XAG/ZAR)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DiamondPlatinum)
                        Text(PricingEngine.convertZarToCurrency(spotSilverKg, currency) + " / kg", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DiamondPlatinum)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Mzansi 999 Fine Silver Industrial & Bullion Rate", fontSize = 11.sp, color = TextMuted)
                }
            }
        }
    }
}

@Composable
fun PurityPriceChip(label: String, price: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = SurfaceVariantDark,
        border = BorderStroke(1.dp, BorderDark)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(label, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text(price, fontSize = 11.sp, color = IvoryText, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerBuySellScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    var selectedCategory by remember { mutableStateOf(0) } // 0: Gold, 1: Silver, 2: Diamonds

    var selectedWeightGrams by remember { mutableStateOf(100.0) }
    var selectedPurity by remember { mutableStateOf(Purity.PURITY_9999) }
    var selectedProductType by remember { mutableStateOf(ProductType.CAST_BAR) }
    var selectedVault by remember { mutableStateOf("Johannesburg Central Bullion Vault") }

    val quote = PricingEngine.calculateGoldBuyPrice(selectedWeightGrams, selectedPurity, selectedProductType)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Category Tabs
        TabRow(
            selectedTabIndex = selectedCategory,
            containerColor = SurfaceDark,
            contentColor = GoldPrimary
        ) {
            Tab(selected = selectedCategory == 0, onClick = { selectedCategory = 0 }, text = { Text("GOLD BULLION") })
            Tab(selected = selectedCategory == 1, onClick = { selectedCategory = 1 }, text = { Text("SILVER BULLION") })
            Tab(selected = selectedCategory == 2, onClick = { selectedCategory = 2 }, text = { Text("DIAMONDS") })
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedCategory == 0) {
            // Gold Order Wizard
            LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Text("SELECT GOLD PRODUCT WEIGHT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(10.0 to "10g", 31.1035 to "1 oz", 100.0 to "100g", 500.0 to "500g", 1000.0 to "1 kg").forEach { (w, lbl) ->
                            FilterChip(
                                selected = selectedWeightGrams == w,
                                onClick = { selectedWeightGrams = w },
                                label = { Text(lbl) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }

                item {
                    Text("PURITY & TYPE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedProductType == ProductType.CAST_BAR,
                            onClick = { selectedProductType = ProductType.CAST_BAR },
                            label = { Text("Cast Bar") }
                        )
                        FilterChip(
                            selected = selectedProductType == ProductType.MINTED_BAR,
                            onClick = { selectedProductType = ProductType.MINTED_BAR },
                            label = { Text("Minted Bar") }
                        )
                        FilterChip(
                            selected = selectedProductType == ProductType.INVESTMENT_COIN,
                            onClick = { selectedProductType = ProductType.INVESTMENT_COIN },
                            label = { Text("Krugerrand Coin") }
                        )
                    }
                }

                item {
                    Text("ALLOCATED VAULT LOCATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedVault.contains("Johannesburg"),
                            onClick = { selectedVault = "Johannesburg Central Bullion Vault" },
                            label = { Text("Johannesburg") }
                        )
                        FilterChip(
                            selected = selectedVault.contains("Cape Town"),
                            onClick = { selectedVault = "Cape Town Private Wealth Vault" },
                            label = { Text("Cape Town") }
                        )
                        FilterChip(
                            selected = selectedVault.contains("Durban"),
                            onClick = { selectedVault = "Durban Maritime Freight Depot" },
                            label = { Text("Durban") }
                        )
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        border = BorderStroke(1.dp, GoldDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("ORDER PRICE BREAKDOWN (ZAR)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                            Spacer(modifier = Modifier.height(10.dp))
                            BreakdownRow("Spot Benchmark", "R ${quote.benchmarkZar}")
                            BreakdownRow("SA Refiner & Local Premium", "R ${quote.localPremiumZar}")
                            BreakdownRow("Product Minting Premium", "R ${quote.productPremiumZar}")
                            BreakdownRow("Dealer Spread (1.2%)", "R ${quote.dealerSpreadZar}")
                            BreakdownRow("Vault Deposit Fee", "R ${quote.vaultCostZar}")
                            Divider(color = BorderDark, modifier = Modifier.padding(vertical = 8.dp))
                            BreakdownRow("TOTAL NET COST", PricingEngine.convertZarToCurrency(quote.totalNetZar, currency), isBold = true)
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            viewModel.executeBuyGold(
                                productType = selectedProductType,
                                grossGrams = selectedWeightGrams,
                                purity = selectedPurity,
                                vaultLocation = selectedVault
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("EXECUTE BUY & ALLOCATE TO VAULT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        } else if (selectedCategory == 1) {
            // Silver Order View
            Text("Silver Bullion Trading Desk", color = DiamondPlatinum, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    viewModel.executeBuySilver(
                        productType = ProductType.CAST_BAR,
                        grossGrams = 1000.0,
                        purity = Purity.PURITY_999,
                        vaultLocation = "Durban Maritime Freight Depot"
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = DiamondPlatinum, contentColor = Color.Black)
            ) {
                Text("BUY 1kg SILVER CAST BAR")
            }
        } else {
            // Diamonds View
            Text("South African Diamond Exchange", color = DiamondAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))
            Text("Browse certified stones or rough diamond parcels in the Merchant Terminal or Vault tab.", fontSize = 12.sp, color = TextMuted)
        }
    }
}

@Composable
fun BreakdownRow(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = if (isBold) IvoryText else TextMuted, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontSize = 11.sp, color = if (isBold) GoldPrimary else IvoryText, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
fun CustomerPortfolioScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val goldBars by viewModel.repository.goldBars.collectAsState()
    val silverBars by viewModel.repository.silverBars.collectAsState()
    val diamonds by viewModel.repository.diamonds.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("MY ALLOCATED PHYSICAL ASSETS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        item {
            Text("GOLD BARS (${goldBars.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight)
        }

        items(goldBars) { bar ->
            GoldPassportCard(bar = bar, selectedCurrency = currency)
        }

        item {
            Text("POLISHED DIAMONDS (${diamonds.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DiamondAccent)
        }

        items(diamonds) { diamond ->
            DiamondPassportCard(diamond = diamond, selectedCurrency = currency)
        }
    }
}

@Composable
fun CustomerVaultPassportsScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val goldBars by viewModel.repository.goldBars.collectAsState()
    val diamonds by viewModel.repository.diamonds.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("DIGITAL ASSET PASSPORTS & PROVENANCE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        items(goldBars) { bar ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("GOLD BAR PASSPORT", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                        Text("SERIAL: ${bar.serialNumber}", fontSize = 10.sp, color = GoldLight)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Custody History & Provenance Chain:", fontSize = 10.sp, color = TextMuted)
                    bar.history.forEach { item ->
                        Text("• $item", fontSize = 11.sp, color = IvoryText)
                    }
                }
            }
        }
    }
}
