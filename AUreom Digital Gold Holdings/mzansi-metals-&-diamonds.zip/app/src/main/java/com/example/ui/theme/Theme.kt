package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MzansiDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = DiamondPlatinum,
    onSecondary = Color.Black,
    secondaryContainer = SurfaceVariantDark,
    onSecondaryContainer = DiamondPlatinum,
    tertiary = DiamondAccent,
    onTertiary = Color.Black,
    background = CharcoalDark,
    onBackground = IvoryText,
    surface = SurfaceDark,
    onSurface = IvoryText,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextMuted,
    outline = BorderDark,
    error = MzansiBurgundyLight,
    onError = Color.White
)

@Composable
fun MzansiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MzansiDarkColorScheme,
        typography = Typography,
        content = content
    )
}
