package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.pricing.PricingEngine
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MzansiViewModel
import java.math.BigDecimal

@Composable
fun MerchantTerminalView(viewModel: MzansiViewModel) {
    val currentTab by viewModel.terminalTab.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalDark)
    ) {
        // Terminal Tab Bar
        ScrollableTabRow(
            selectedTabIndex = currentTab,
            containerColor = SurfaceDark,
            contentColor = GoldPrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = currentTab == 0, onClick = { viewModel.setTerminalTab(0) }, text = { Text("MARKET", fontSize = 11.sp) })
            Tab(selected = currentTab == 1, onClick = { viewModel.setTerminalTab(1) }, text = { Text("RFQ DESK", fontSize = 11.sp) })
            Tab(selected = currentTab == 2, onClick = { viewModel.setTerminalTab(2) }, text = { Text("DIAMOND TENDER", fontSize = 11.sp) })
            Tab(selected = currentTab == 3, onClick = { viewModel.setTerminalTab(3) }, text = { Text("ORDER BOOK", fontSize = 11.sp) })
            Tab(selected = currentTab == 4, onClick = { viewModel.setTerminalTab(4) }, text = { Text("COMPLIANCE", fontSize = 11.sp) })
            Tab(selected = currentTab == 5, onClick = { viewModel.setTerminalTab(5) }, text = { Text("LEDGER & RECON", fontSize = 11.sp) })
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            when (currentTab) {
                0 -> TerminalMarketScreen(currency)
                1 -> TerminalRfqScreen(viewModel, currency)
                2 -> TerminalDiamondTenderScreen(viewModel, currency)
                3 -> TerminalOrderBookScreen(viewModel)
                4 -> TerminalComplianceScreen(viewModel)
                5 -> TerminalLedgerReconScreen(viewModel)
            }
        }
    }
}

@Composable
fun TerminalMarketScreen(currency: CurrencyCode) {
    val spotGoldG = PricingEngine.getGoldSpotZarPerGram()
    val spotSilverKg = PricingEngine.getSilverSpotZarPerKg()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("INSTITUTIONAL COMMODITY MARKET FEED", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("XAU/ZAR SPOT", fontSize = 12.sp, color = TextMuted)
                    Text("R ${spotGoldG.toPlainString()} / gram", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Refiner Benchmark Spread: 1.2% • Vault Fee: R 450/bar", fontSize = 10.sp, color = IvoryText)
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("XAG/ZAR SPOT", fontSize = 12.sp, color = TextMuted)
                    Text("R ${spotSilverKg.toPlainString()} / kg", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DiamondPlatinum)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Industrial Physical Silver Premium: 4.5%", fontSize = 10.sp, color = IvoryText)
                }
            }
        }
    }
}

@Composable
fun TerminalRfqScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val rfqs by viewModel.repository.rfqs.collectAsState()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("INSTITUTIONAL REQUEST FOR QUOTE (RFQ) DESK", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        items(rfqs) { rfq ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(rfq.rfqId, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight, fontFamily = FontFamily.Monospace)
                        ComplianceBadge(text = rfq.status)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Client: ${rfq.customerName}", fontSize = 11.sp, color = IvoryText)
                    Text("Asset: ${rfq.quantitySpec} (${rfq.purityOrQualitySpec})", fontSize = 11.sp, color = GoldPrimary)
                    Text("Location: ${rfq.settlementLocation}", fontSize = 11.sp, color = TextMuted)

                    rfq.quote?.let { q ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = BorderDark)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Dealer Quote: R ${q.priceZar} (Spread: ${q.spreadPercent}%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MzansiGreenLight)
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalDiamondTenderScreen(viewModel: MzansiViewModel, currency: CurrencyCode) {
    val tenders by viewModel.repository.tenders.collectAsState()
    var bidAmountText by remember { mutableStateOf("29800000.00") }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("KIMBERLEY DIAMOND EXCHANGE TENDER PLATFORM", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DiamondAccent)
        }

        items(tenders) { tender ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, DiamondDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(tender.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = IvoryText)
                        ComplianceBadge(text = tender.status.name)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Parcel: ${tender.parcel.parcelId} (${tender.parcel.totalCarat} ct / ${tender.parcel.numberOfStones} stones)", fontSize = 12.sp, color = DiamondAccent)
                    Text("Size Distribution: ${tender.parcel.sizeDistribution}", fontSize = 11.sp, color = TextMuted)
                    Text("Rough Type: ${tender.parcel.roughType.label} • Mine: ${tender.parcel.sourceMine}", fontSize = 11.sp, color = TextMuted)

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BorderDark)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailPair("Opening Price", "R ${tender.openingPriceZar}")
                        DetailPair("Current High Bid", "R ${tender.currentHighBidZar}")
                        DetailPair("Bidders", "${tender.biddersCount}")
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Bidding History Log:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldLight)

                    tender.bids.forEach { bid ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("• ${bid.bidderName} (${bid.timestamp})", fontSize = 10.sp, color = TextMuted)
                            Text("R ${bid.amountZar}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (bid.isWinning) MzansiGreenLight else IvoryText)
                        }
                    }

                    if (tender.status == TenderStatus.TENDER_OPEN) {
                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedTextField(
                            value = bidAmountText,
                            onValueChange = { bidAmountText = it },
                            label = { Text("Higher Bid Amount (ZAR)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DiamondAccent)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val amt = BigDecimal(bidAmountText)
                                    viewModel.submitTenderBid(tender.tenderId, amt)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DiamondAccent, contentColor = Color.Black),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("SUBMIT HIGHER BID")
                            }

                            Button(
                                onClick = { viewModel.awardTender(tender.tenderId) },
                                colors = ButtonDefaults.buttonColors(containerColor = MzansiGreen, contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("CLOSE & AWARD TENDER")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalOrderBookScreen(viewModel: MzansiViewModel) {
    val orders by viewModel.repository.orders.collectAsState()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("INSTITUTIONAL ORDER BOOK & EXECUTIONS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        items(orders) { ord ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${ord.side.name} ${ord.assetCategory.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ord.side == OrderSide.BUY) MzansiGreenLight else MzansiBurgundyLight)
                        Text(ord.status.name, fontSize = 10.sp, color = GoldLight)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(ord.assetDescription, fontSize = 11.sp, color = IvoryText)
                    Text("Total: R ${ord.totalZar} • Vault: ${ord.vaultLocation}", fontSize = 10.sp, color = TextMuted)
                }
            }
        }
    }
}

@Composable
fun TerminalComplianceScreen(viewModel: MzansiViewModel) {
    val cust by viewModel.repository.customer.collectAsState()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("SOUTH AFRICAN SADPMR & FIC COMPLIANCE MODULE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("REGULATED MERCHANT PROFILE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Entity Name: ${cust.name}", fontSize = 11.sp, color = IvoryText)
                    Text("Customer Type: ${cust.type.name}", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ComplianceBadge(text = if (cust.ficKycCleared) "FIC KYC CLEARED" else "KYC PENDING")
                        ComplianceBadge(text = if (cust.sourceOfFundsVerified) "SOURCE OF FUNDS VERIFIED" else "UNVERIFIED")
                    }
                }
            }
        }

        item {
            Text("ACTIVE SADPMR LICENCES & PERMITS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        }

        items(cust.licences) { lic ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(lic.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    Text("Licence Ref: ${lic.licenceId}", fontSize = 10.sp, color = IvoryText, fontFamily = FontFamily.Monospace)
                    Text("Jurisdiction: ${lic.jurisdiction}", fontSize = 10.sp, color = TextMuted)
                    Text("Scope: ${lic.scope}", fontSize = 10.sp, color = TextMuted)
                    Text("Validity: ${lic.issueDate} to ${lic.expiryDate}", fontSize = 10.sp, color = MzansiGreenLight)
                }
            }
        }
    }
}

@Composable
fun TerminalLedgerReconScreen(viewModel: MzansiViewModel) {
    val ledgerAccounts by viewModel.repository.ledgerAccounts.collectAsState()
    val ledgerEntries by viewModel.repository.ledgerEntries.collectAsState()
    val recon by viewModel.repository.lastReconciliation.collectAsState()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DOUBLE-ENTRY LEDGER & RECONCILIATION ENGINE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                Button(
                    onClick = { viewModel.runReconciliation() },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black)
                ) {
                    Text("RUN RECON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        recon?.let { r ->
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(1.dp, if (r.status.contains("BALANCED")) MzansiGreen else MzansiBurgundy),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("LAST RECONCILIATION RUN: ${r.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (r.status.contains("BALANCED")) MzansiGreenLight else MzansiBurgundyLight)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Physical Gold: ${r.physicalGoldKg} kg vs Ledger: ${r.ledgerGoldKg} kg (Drift: ${r.goldDriftKg} kg)", fontSize = 11.sp, color = IvoryText)
                        Text("Physical Silver: ${r.physicalSilverKg} kg vs Ledger: ${r.ledgerSilverKg} kg (Drift: ${r.silverDriftKg} kg)", fontSize = 11.sp, color = IvoryText)
                        Text("Physical Diamonds: ${r.physicalDiamondCt} ct vs Ledger: ${r.ledgerDiamondCt} ct (Drift: ${r.diamondDriftCt} ct)", fontSize = 11.sp, color = IvoryText)
                    }
                }
            }
        }

        item {
            Text("LEDGER ACCOUNTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        }

        items(ledgerAccounts) { acc ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(acc.name, fontSize = 11.sp, color = IvoryText)
                Text("${acc.balance.toPlainString()} ${acc.assetUnit}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
            }
        }

        item {
            Text("AUDIT JOURNAL ENTRIES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        }

        items(ledgerEntries) { entry ->
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(entry.entryId, fontSize = 10.sp, color = GoldLight, fontFamily = FontFamily.Monospace)
                        Text(entry.timestamp, fontSize = 9.sp, color = TextMuted)
                    }
                    Text(entry.description, fontSize = 11.sp, color = IvoryText)
                    Text("Debit: ${entry.debitAccountId} | Credit: ${entry.creditAccountId} | Amount: ${entry.amount} ${entry.unit}", fontSize = 10.sp, color = TextMuted)
                }
            }
        }
    }
}
