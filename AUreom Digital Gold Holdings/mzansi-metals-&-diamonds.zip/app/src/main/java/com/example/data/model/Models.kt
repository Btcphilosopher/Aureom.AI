package com.example.data.model

import java.math.BigDecimal

enum class CurrencyCode(val symbol: String, val displayName: String) {
    ZAR("R", "South African Rand"),
    USD("$", "US Dollar"),
    EUR("€", "Euro"),
    GBP("£", "British Pound"),
    CHF("CHF", "Swiss Franc"),
    AED("AED", "UAE Dirham"),
    SGD("S$", "Singapore Dollar"),
    HKD("HK$", "Hong Kong Dollar"),
    CNY("¥", "Chinese Yuan"),
    CNH("¥", "Offshore Yuan"),
    JPY("¥", "Japanese Yen"),
    AUD("A$", "Australian Dollar"),
    INR("₹", "Indian Rupee")
}

enum class MetalType {
    GOLD, SILVER
}

enum class Purity(val code: String, val multiplier: Double) {
    PURITY_24K("24K (999.9)", 0.9999),
    PURITY_9999("999.9", 0.9999),
    PURITY_999("999", 0.9990),
    PURITY_995("995", 0.9950),
    PURITY_916("916 (22K)", 0.9160)
}

enum class ProductType(val label: String) {
    CAST_BAR("Cast Bar"),
    MINTED_BAR("Minted Bar"),
    INVESTMENT_COIN("Investment Coin"),
    BULLION_ROUND("Bullion Round"),
    INDUSTRIAL_GRAIN("Industrial Grain")
}

enum class AllocationStatus {
    ALLOCATED, UNALLOCATED
}

enum class CustodyStatus {
    VAULT_SECURED, IN_TRANSIT, DELIVERED, ON_TENDER, PENDING_ASSAY
}

data class GoldBar(
    val barId: String,
    val serialNumber: String,
    val refiner: String,
    val brand: String,
    val purity: Purity,
    val productType: ProductType,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val manufactureDate: String,
    val assayReference: String,
    val currentOwner: String,
    val currentVault: String,
    val allocationStatus: AllocationStatus,
    val custodyStatus: CustodyStatus,
    val encumbranceStatus: String = "UNENCUMBERED",
    val inspectionStatus: String = "VERIFIED",
    val valuationZar: BigDecimal,
    val history: List<String>
)

data class SilverBar(
    val barId: String,
    val serialNumber: String,
    val refiner: String,
    val purity: Purity,
    val productType: ProductType,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val manufactureDate: String,
    val assayReference: String,
    val currentOwner: String,
    val currentVault: String,
    val allocationStatus: AllocationStatus,
    val custodyStatus: CustodyStatus,
    val valuationZar: BigDecimal,
    val history: List<String>
)

data class MetalAccount(
    val goldAllocatedOz: Double,
    val goldUnallocatedOz: Double,
    val silverAllocatedKg: Double,
    val silverUnallocatedKg: Double
) {
    val totalGoldOz: Double get() = goldAllocatedOz + goldUnallocatedOz
    val totalGoldKg: Double get() = totalGoldOz * 0.0311035
    val totalSilverKg: Double get() = silverAllocatedKg + silverUnallocatedKg
}

// DIAMONDS
enum class DiamondType {
    POLISHED, ROUGH
}

enum class Shape(val displayName: String) {
    ROUND_BRILLIANT("Round Brilliant"),
    EMERALD("Emerald"),
    PRINCESS("Princess"),
    OVAL("Oval"),
    CUSHION("Cushion"),
    PEAR("Pear"),
    RADIANT("Radiant"),
    HEART("Heart"),
    MARQUISE("Marquise")
}

enum class Clarity {
    FL, IF, VVS1, VVS2, VS1, VS2, SI1, SI2
}

enum class Color {
    D, E, F, G, H, I, J, FANCY_YELLOW
}

enum class CutGrade {
    EXCELLENT, VERY_GOOD, GOOD
}

enum class RoughType(val label: String) {
    SAWABLE("Sawable Rough"),
    MAKEABLE("Makeable Rough"),
    CLIVAGE("Clivage Rough"),
    REJECTIONS("Industrial Rejections")
}

data class DiamondCertificate(
    val certificateId: String,
    val certificateNumber: String,
    val lab: String, // e.g., "Mzansi Gem Laboratory"
    val issueDate: String,
    val stoneId: String,
    val carat: Double,
    val colour: Color,
    val clarity: Clarity,
    val cut: CutGrade,
    val polish: CutGrade,
    val symmetry: CutGrade,
    val fluorescence: String,
    val dimensions: String,
    val laserInscription: String,
    val securityReference: String,
    val verificationStatus: String = "VERIFIED_AUTHENTIC"
)

data class Diamond(
    val stoneId: String,
    val parcelId: String? = null,
    val type: DiamondType = DiamondType.POLISHED,
    val caratWeight: Double,
    val shape: Shape,
    val colour: Color,
    val clarity: Clarity,
    val cut: CutGrade,
    val polish: CutGrade,
    val symmetry: CutGrade,
    val fluorescence: String,
    val dimensions: String,
    val certificate: DiamondCertificate,
    val originMine: String,
    val provenance: List<String>,
    val country: String = "South Africa",
    val treatment: String = "None (Natural)",
    val gradingDate: String,
    val currentOwner: String,
    val custody: CustodyStatus,
    val locationVault: String,
    val askingPriceZar: BigDecimal,
    val indicativeValuationZar: BigDecimal
)

data class DiamondParcel(
    val parcelId: String,
    val title: String,
    val numberOfStones: Int,
    val totalCarat: Double,
    val averageSizeCt: Double,
    val sizeDistribution: String,
    val roughType: RoughType,
    val sourceMine: String,
    val producer: String,
    val country: String = "South Africa",
    val mineReference: String,
    val valuationZar: BigDecimal,
    val tenderStatus: TenderStatus,
    val licenseStatus: String = "SADPMR_APPROVED",
    val certificateStatus: String = "KIMBERLEY_PROCESS_CERTIFIED (ZA-2026-0048)",
    val exportStatus: String = "EXPORT_ELIGIBLE",
    val custody: CustodyStatus
)

enum class TenderStatus {
    READY_FOR_TENDER, TENDER_OPEN, AWARDED_SETTLED
}

data class Bid(
    val bidId: String,
    val tenderId: String,
    val bidderName: String,
    val bidderType: String,
    val amountZar: BigDecimal,
    val timestamp: String,
    val isWinning: Boolean = false
)

data class Tender(
    val tenderId: String,
    val parcel: DiamondParcel,
    val title: String,
    val openingPriceZar: BigDecimal,
    val currentHighBidZar: BigDecimal,
    val biddersCount: Int,
    val closingTime: String,
    val status: TenderStatus,
    val winningBidder: String? = null,
    val winningAmountZar: BigDecimal? = null,
    val bids: List<Bid>
)

// INSTITUTIONAL RFQ & ORDERS
enum class AssetCategory {
    GOLD, SILVER, POLISHED_DIAMONDS, ROUGH_PARCELS
}

data class Quote(
    val quoteId: String,
    val rfqId: String,
    val dealerName: String,
    val priceZar: BigDecimal,
    val spreadPercent: Double,
    val validitySeconds: Int,
    val timestamp: String
)

data class Rfq(
    val rfqId: String,
    val customerName: String,
    val assetCategory: AssetCategory,
    val quantitySpec: String,
    val purityOrQualitySpec: String,
    val currency: CurrencyCode,
    val settlementLocation: String,
    val deliveryPreference: String,
    val status: String,
    val quote: Quote? = null
)

enum class OrderSide {
    BUY, SELL
}

enum class OrderStatus {
    NEW, VALIDATED, QUOTED, ACCEPTED, EXECUTED, ALLOCATED, SETTLED, DELIVERED
}

data class Order(
    val orderId: String,
    val side: OrderSide,
    val assetCategory: AssetCategory,
    val assetDescription: String,
    val quantity: Double,
    val unitPriceZar: BigDecimal,
    val totalZar: BigDecimal,
    val vaultLocation: String,
    val status: OrderStatus,
    val timestamp: String,
    val idempotencyKey: String
)

// VAULT & FACILITIES
enum class SACity(val label: String, val role: String) {
    JOHANNESBURG("Johannesburg", "Commercial HQ & Bullion Vault"),
    KIMBERLEY("Kimberley", "Diamond Centre & Tender Hub"),
    CAPE_TOWN("Cape Town", "Private Wealth & Maritime Trade"),
    DURBAN("Durban", "Port & Freight Logistics"),
    PRETORIA("Pretoria", "SADPMR & Institutional Interface"),
    OR_TAMBO("OR Tambo International", "Secured Air Logistics")
}

data class FacilityNode(
    val id: String,
    val city: SACity,
    val name: String,
    val roleDescription: String,
    val goldVaultKg: Double,
    val silverVaultKg: Double,
    val diamondVaultCarats: Double,
    val securityLevel: String = "Tier-1 High Security Vault",
    val isOperational: Boolean = true
)

// COMPLIANCE & LICENCES
enum class CustomerType {
    PRIVATE_CLIENT, JEWELLER, BULLION_DEALER, DIAMOND_DEALER, INSTITUTION, REFINER, MANUFACTURER
}

data class Licence(
    val licenceId: String,
    val holderName: String,
    val type: String, // e.g. "SADPMR Diamond Dealer Licence", "Precious Metals Refining Certificate"
    val jurisdiction: String = "South Africa (SADPMR)",
    val issueDate: String,
    val expiryDate: String,
    val status: String = "ACTIVE_VERIFIED",
    val scope: String
)

data class CustomerProfile(
    val id: String,
    val name: String,
    val type: CustomerType,
    val country: String = "South Africa",
    val licences: List<Licence>,
    val ficKycCleared: Boolean = true,
    val sourceOfFundsVerified: Boolean = true,
    val zarCashBalance: BigDecimal,
    val usdCashBalance: BigDecimal
)

// LEDGER & AUDIT
data class LedgerAccount(
    val accountId: String,
    val name: String,
    val assetUnit: String, // "ZAR", "GOLD_G", "SILVER_KG", "DIAMOND_CT"
    var balance: BigDecimal
)

data class LedgerEntry(
    val entryId: String,
    val transactionId: String,
    val debitAccountId: String,
    val creditAccountId: String,
    val amount: BigDecimal,
    val unit: String,
    val timestamp: String,
    val description: String
)

data class AuditEvent(
    val eventId: String,
    val eventType: String, // "GoldPurchased", "BarAllocated", "TenderAwarded", etc.
    val payloadSummary: String,
    val timestamp: String,
    val actor: String
)

data class ReconciliationRun(
    val runId: String,
    val timestamp: String,
    val physicalGoldKg: Double,
    val ledgerGoldKg: Double,
    val goldDriftKg: Double,
    val physicalSilverKg: Double,
    val ledgerSilverKg: Double,
    val silverDriftKg: Double,
    val physicalDiamondCt: Double,
    val ledgerDiamondCt: Double,
    val diamondDriftCt: Double,
    val status: String,
    val exceptions: List<String>
)

// DIGITAL PASSPORTS
data class GoldPassport(
    val bar: GoldBar,
    val refinerCertification: String,
    val assayCode: String,
    val vaultFacility: String,
    val custodyChain: List<String>
)

data class SilverPassport(
    val bar: SilverBar,
    val refinerCertification: String,
    val assayCode: String,
    val vaultFacility: String,
    val custodyChain: List<String>
)

data class DiamondPassport(
    val diamond: Diamond,
    val certificate: DiamondCertificate,
    val kimberleyProcessCert: String,
    val mineSource: String,
    val custodyChain: List<String>
)
