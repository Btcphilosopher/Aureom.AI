package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mzansi Metals & Diamonds Palette
val CharcoalDark = Color(0xFF0F1014)
val SurfaceDark = Color(0xFF16181E)
val SurfaceVariantDark = Color(0xFF20232C)
val BorderDark = Color(0xFF2C303D)

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFF997A15)

val DiamondPlatinum = Color(0xFFE2ECEF)
val DiamondAccent = Color(0xFF80D8FF)
val DiamondDark = Color(0xFF455A64)

val IvoryText = Color(0xFFF5F2EB)
val TextMuted = Color(0xFFA0A8B8)

val MzansiGreen = Color(0xFF2E7D32)
val MzansiGreenLight = Color(0xFF66BB6A)
val MzansiBurgundy = Color(0xFF8E2424)
val MzansiBurgundyLight = Color(0xFFEF5350)
