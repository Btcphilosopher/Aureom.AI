package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ComplianceBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.MzansiViewModel

@Composable
fun DemoWalkthroughSimulatorScreen(viewModel: MzansiViewModel) {
    val demoStatus by viewModel.demoStatus.collectAsState()
    val demoStep by viewModel.demoStep.collectAsState()
    val isRunning by viewModel.isDemoRunning.collectAsState()
    val auditEvents by viewModel.repository.auditEvents.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("MZANSI END-TO-END DEMONSTRATION SUITE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Simulate the complete 5-stage trade execution workflow: Gold Purchase, Silver Allocation, Certified Diamond Passport, Gold Sellback, and Kimberley Diamond Tender Auction.", fontSize = 11.sp, color = TextMuted)
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AUTOMATED DEMO CONTROLLER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                        ComplianceBadge(text = if (isRunning) "EXECUTING..." else "READY")
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(demoStatus, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = IvoryText)

                    Spacer(modifier = Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = demoStep / 5f,
                        modifier = Modifier.fillMaxWidth(),
                        color = GoldPrimary,
                        trackColor = SurfaceVariantDark
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.triggerDemoWalkthrough() },
                        enabled = !isRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TRIGGER END-TO-END WALKTHROUGH", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        item {
            Text("SCENARIO CUJ EXECUTION STEPS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IvoryText)
        }

        item {
            DemoStepCard(
                stepNum = 1,
                title = "Customer Buys 100g 999.9 Gold Cast Bar",
                desc = "Allocates bar to Johannesburg Vault, generates serial ZA-AU-9999-XXXX and creates Gold Passport.",
                isCompleted = demoStep >= 1
            )
        }

        item {
            DemoStepCard(
                stepNum = 2,
                title = "Customer Buys 1kg Fine Silver Bar",
                desc = "Allocates silver to Durban Maritime Freight Depot, updates double-entry metal accounts.",
                isCompleted = demoStep >= 2
            )
        }

        item {
            DemoStepCard(
                stepNum = 3,
                title = "Customer Acquires 2.14ct Diamond",
                desc = "Verifies Mzansi Gem Lab Certificate, allocates stone, creates Diamond Passport with origin provenance.",
                isCompleted = demoStep >= 3
            )
        }

        item {
            DemoStepCard(
                stepNum = 4,
                title = "Customer Sells 50g Gold Back to Dealer",
                desc = "Calculates refiner quote, executes buyback settlement, credits ZAR cash proceeds.",
                isCompleted = demoStep >= 4
            )
        }

        item {
            DemoStepCard(
                stepNum = 5,
                title = "Institutional Kimberley Diamond Tender",
                desc = "Opens 4,812ct rough parcel tender, simulates 12 bids, awards winning bid, applies Kimberley Process export seal.",
                isCompleted = demoStep >= 5
            )
        }

        item {
            Text("LIVE DEMO AUDIT JOURNAL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
        }

        items(auditEvents.take(10)) { ev ->
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(ev.eventType, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldLight)
                    Text(ev.payloadSummary, fontSize = 10.sp, color = IvoryText)
                }
            }
        }
    }
}

@Composable
fun DemoStepCard(stepNum: Int, title: String, desc: String, isCompleted: Boolean) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, if (isCompleted) MzansiGreen else BorderDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.PlayArrow,
                contentDescription = "Step",
                tint = if (isCompleted) MzansiGreenLight else TextMuted,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("Step $stepNum: $title", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isCompleted) MzansiGreenLight else IvoryText)
                Text(desc, fontSize = 10.sp, color = TextMuted)
            }
        }
    }
}
