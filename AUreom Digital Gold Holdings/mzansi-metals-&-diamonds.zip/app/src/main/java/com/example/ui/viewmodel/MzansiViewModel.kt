package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.pricing.PricingEngine
import com.example.data.repository.MzansiRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.math.BigDecimal

enum class AppViewMode {
    CUSTOMER_MOBILE,
    INSTITUTIONAL_TERMINAL,
    GEOGRAPHIC_MAP,
    DEMO_SIMULATOR
}

class MzansiViewModel : ViewModel() {

    val repository = MzansiRepository()

    // Active App Mode
    private val _viewMode = MutableStateFlow(AppViewMode.CUSTOMER_MOBILE)
    val viewMode: StateFlow<AppViewMode> = _viewMode.asStateFlow()

    // Selected Currency
    private val _selectedCurrency = MutableStateFlow(CurrencyCode.ZAR)
    val selectedCurrency: StateFlow<CurrencyCode> = _selectedCurrency.asStateFlow()

    // Customer App Bottom Tab
    private val _customerTab = MutableStateFlow(0) // 0: Home, 1: Market, 2: Buy/Sell, 3: Portfolio, 4: Vault & Passports
    val customerTab: StateFlow<Int> = _customerTab.asStateFlow()

    // Terminal Sub-Tab
    private val _terminalTab = MutableStateFlow(0) // 0: Market, 1: RFQ, 2: Tenders, 3: Order Book, 4: Compliance, 5: Ledger & Recon
    val terminalTab: StateFlow<Int> = _terminalTab.asStateFlow()

    // Demo Progress State
    private val _demoStatus = MutableStateFlow("Ready to run end-to-end demonstration.")
    val demoStatus: StateFlow<String> = _demoStatus.asStateFlow()

    private val _demoStep = MutableStateFlow(0)
    val demoStep: StateFlow<Int> = _demoStep.asStateFlow()

    private val _isDemoRunning = MutableStateFlow(false)
    val isDemoRunning: StateFlow<Boolean> = _isDemoRunning.asStateFlow()

    // Feedback SnackBar/Message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        // Start background ticker for live market updates
        viewModelScope.launch {
            while (true) {
                delay(4000)
                PricingEngine.updateMarketTick()
            }
        }
    }

    fun setViewMode(mode: AppViewMode) {
        _viewMode.value = mode
    }

    fun setSelectedCurrency(currency: CurrencyCode) {
        _selectedCurrency.value = currency
    }

    fun setCustomerTab(index: Int) {
        _customerTab.value = index
    }

    fun setTerminalTab(index: Int) {
        _terminalTab.value = index
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun executeBuyGold(
        productType: ProductType,
        grossGrams: Double,
        purity: Purity,
        vaultLocation: String
    ) {
        val key = "TX-${System.currentTimeMillis()}"
        val result = repository.buyGold(productType, grossGrams, purity, vaultLocation, key)
        result.onSuccess { bar ->
            _userMessage.value = "SUCCESS: Allocated Gold Bar ${bar.serialNumber} (${grossGrams}g) to $vaultLocation"
        }.onFailure { err ->
            _userMessage.value = "ERROR: ${err.message}"
        }
    }

    fun executeSellGold(barId: String) {
        val key = "TX-SELL-${System.currentTimeMillis()}"
        val result = repository.sellGold(barId, key)
        result.onSuccess { payout ->
            _userMessage.value = "SUCCESS: Sold Gold Bar. Received R $payout in proceeds."
        }.onFailure { err ->
            _userMessage.value = "ERROR: ${err.message}"
        }
    }

    fun executeBuySilver(
        productType: ProductType,
        grossGrams: Double,
        purity: Purity,
        vaultLocation: String
    ) {
        val key = "TX-AG-${System.currentTimeMillis()}"
        val result = repository.buySilver(productType, grossGrams, purity, vaultLocation, key)
        result.onSuccess { bar ->
            _userMessage.value = "SUCCESS: Allocated Silver Bar ${bar.serialNumber} (${grossGrams}g) to $vaultLocation"
        }.onFailure { err ->
            _userMessage.value = "ERROR: ${err.message}"
        }
    }

    fun submitTenderBid(tenderId: String, amountZar: BigDecimal) {
        val result = repository.submitTenderBid(tenderId, amountZar, repository.customer.value.name)
        result.onSuccess {
            _userMessage.value = "SUCCESS: Bid of R $amountZar submitted on Tender $tenderId"
        }.onFailure { err ->
            _userMessage.value = "ERROR: ${err.message}"
        }
    }

    fun awardTender(tenderId: String) {
        val result = repository.awardTender(tenderId)
        result.onSuccess {
            _userMessage.value = "SUCCESS: Tender $tenderId awarded & settled. Kimberley Process Export Certificate issued."
        }.onFailure { err ->
            _userMessage.value = "ERROR: ${err.message}"
        }
    }

    fun runReconciliation() {
        val run = repository.runReconciliation()
        _userMessage.value = "RECONCILIATION RUN: ${run.status}. Gold Drift: ${run.goldDriftKg}kg, Silver Drift: ${run.silverDriftKg}kg, Diamond Drift: ${run.diamondDriftCt}ct"
    }

    fun triggerDemoWalkthrough() {
        viewModelScope.launch {
            _isDemoRunning.value = true
            repository.runEndToEndWalkthrough { statusMsg, stepNum ->
                _demoStatus.value = statusMsg
                _demoStep.value = stepNum
            }
            _isDemoRunning.value = false
        }
    }
}
