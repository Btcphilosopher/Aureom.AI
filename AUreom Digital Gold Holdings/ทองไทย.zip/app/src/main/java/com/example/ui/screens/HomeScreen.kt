package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ThaiGoldMockEngine
import com.example.model.MetalType
import kotlinx.coroutines.delay
import com.example.ui.theme.BrushedGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SoftChampagne
import com.example.ui.theme.ThaiGreen
import com.example.ui.theme.ThaiRed
import com.example.ui.theme.Charcoal
import com.example.util.ThaiFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToTrade: (Boolean) -> Unit, // True for Buy, False for Sell
    onNavigateToPortfolio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val prices by ThaiGoldMockEngine.currentPrices.collectAsStateWithLifecycle()
    val cashBalance by ThaiGoldMockEngine.cashBalance.collectAsStateWithLifecycle()
    val gold965Baht by ThaiGoldMockEngine.gold965BahtBalance.collectAsStateWithLifecycle()
    val gold9999g by ThaiGoldMockEngine.gold9999GramBalance.collectAsStateWithLifecycle()
    val silverGrams by ThaiGoldMockEngine.silverGramBalance.collectAsStateWithLifecycle()
    val orders by ThaiGoldMockEngine.orders.collectAsStateWithLifecycle()
    val isReconciled by ThaiGoldMockEngine.isSystemReconciled.collectAsStateWithLifecycle()

    // Dynamic price change flash effect
    var flashColor by remember { mutableStateOf(Color.Transparent) }
    LaunchedEffect(prices.timestamp) {
        flashColor = if (prices.bar965Change > 0) ThaiGreen.copy(alpha = 0.15f) else if (prices.bar965Change < 0) ThaiRed.copy(alpha = 0.15f) else Color.Transparent
        delay(1200)
        flashColor = Color.Transparent
    }

    // Calculations
    val gold965Value = gold965Baht * prices.bar965Buy
    val gold9999Value = gold9999g * prices.gold9999BuyPerGram
    val silverValue = silverGrams * prices.silverBuyPerGram
    val totalPortfolioValue = cashBalance + gold965Value + gold9999Value + silverValue

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Luxury Welcome Banner
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ห้างทองทองไทย",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepBurgundy,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Text(
                        text = "THAI GOLD & SILVER • แพลตฟอร์มพรีเมียม",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = Color.Gray
                        )
                    )
                }

                // Reconciliation Status Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isReconciled) ThaiGreen.copy(alpha = 0.1f) else ThaiRed.copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageName = if (isReconciled) Icons.Default.VerifiedUser else Icons.Default.Warning,
                        contentDescription = "Status",
                        tint = if (isReconciled) ThaiGreen else ThaiRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isReconciled) "ปลอดภัย 100%" else "ตรวจพบข้อผิดพลาด",
                        color = if (isReconciled) ThaiGreen else ThaiRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live Market rates container
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("today_gold_prices_card"),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = Brush.linearGradient(listOf(BrushedGold, DeepBurgundy))),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(flashColor)
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(ThaiGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ราคาทองวันนี้",
                                    fontWeight = FontWeight.Bold,
                                    color = DeepBurgundy,
                                    fontSize = 16.sp
                                )
                            }

                            Text(
                                text = "ประกาศครั้งที่ ${prices.announcementNo} • ${ThaiFormatter.formatThaiTime()}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }

                        Divider(color = SoftChampagne)

                        // 96.5% Gold Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ทองคำแท่ง 96.5%",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    val isPositive = prices.bar965Change >= 0
                                    Icon(
                                        imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                        contentDescription = "Price Change Indicator",
                                        tint = if (isPositive) ThaiGreen else ThaiRed,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${if (isPositive) "+" else ""}${ThaiFormatter.formatCurrency(prices.bar965Change)}",
                                        color = if (isPositive) ThaiGreen else ThaiRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("รับซื้อ (บาท)", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = ThaiFormatter.formatCurrency(prices.bar965Buy),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = ThaiRed
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ขายออก (บาท)", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = ThaiFormatter.formatCurrency(prices.bar965Sell),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = DeepBurgundy
                                    )
                                }
                            }
                        }

                        Divider(color = SoftChampagne.copy(alpha = 0.5f))

                        // 96.5% Gold Ornament
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ทองรูปพรรณ 96.5%",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "ค่ากำเหน็จเริ่มต้น ฿350",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ฐานรับซื้อ (บาท)", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = ThaiFormatter.formatCurrency(prices.ornament965Buy),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = ThaiRed
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ขายออก (บาท)", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = ThaiFormatter.formatCurrency(prices.ornament965Sell),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = DeepBurgundy
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick buying/selling triggers
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onNavigateToTrade(true) },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("quick_buy_gold_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy)
                ) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = "Buy Icon")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ซื้อทองวันนี้", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                }

                Button(
                    onClick = { onNavigateToTrade(false) },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("quick_sell_gold_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SoftChampagne),
                    border = ButtonDefaults.outlinedButtonBorder().copy(width = 1.dp, brush = Brush.linearGradient(listOf(BrushedGold, DeepBurgundy)))
                ) {
                    Icon(Icons.Default.Sell, contentDescription = "Sell Icon", tint = DeepBurgundy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ขายคืนทอง", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DeepBurgundy)
                }
            }
        }

        // Customer Portfolio Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToPortfolio() }
                    .testTag("my_portfolio_summary_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Charcoal)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "มูลค่าพอร์ตโดยประมาณ",
                            color = SoftChampagne,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ดูประวัติทองคำ", color = PremiumGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = "View", tint = PremiumGold, modifier = Modifier.size(16.dp))
                        }
                    }

                    Text(
                        text = "฿${ThaiFormatter.formatDecimal(totalPortfolioValue)}",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = PremiumGold,
                            letterSpacing = 0.5.sp
                        )
                    )

                    Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ทองในครอบครอง", fontSize = 11.sp, color = Color.LightGray)
                            Text(
                                text = ThaiFormatter.formatGoldWeightBaht(gold965Baht),
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                        Column {
                            Text("ทองคำสวิส 99.99%", fontSize = 11.sp, color = Color.LightGray)
                            Text(
                                text = "${ThaiFormatter.formatDecimal(gold9999g)} g",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("เงินสดคงเหลือ", fontSize = 11.sp, color = Color.LightGray)
                            Text(
                                text = ThaiFormatter.formatCurrency(cashBalance),
                                fontWeight = FontWeight.Bold,
                                color = PremiumGold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Recent Activity Logs Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "รายการธุรกรรมล่าสุด",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepBurgundy
                    )
                )

                Text(
                    text = "ประวัติทั้งหมด",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateToPortfolio() }
                )
            }
        }

        if (orders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftChampagne.copy(alpha = 0.3f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ยังไม่มีรายการธุรกรรมในระบบ\nเริ่มออมทองของคุณได้ทันทีวันนี้",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        } else {
            items(orders.take(3)) { order ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val isBuy = order.totalAmount > 0
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(if (isBuy) DeepBurgundy.copy(alpha = 0.1f) else ThaiGreen.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isBuy) Icons.Default.ShoppingCart else Icons.Default.Paid,
                                    contentDescription = "Tx Type",
                                    tint = if (isBuy) DeepBurgundy else ThaiGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = order.productName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = when (order.deliveryMethod) {
                                        com.example.model.DeliveryMethod.VAULT_SECURE -> "ฝากเก็บตู้นิรภัย Vault TH-001"
                                        com.example.model.DeliveryMethod.STORE_PICKUP -> "รับทองที่สาขา"
                                        com.example.model.DeliveryMethod.HOME_DELIVERY -> "จัดส่งถึงบ้านผู้รับ"
                                    },
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val isBuy = order.totalAmount > 0
                            Text(
                                text = "${if (isBuy) "-" else "+"}${ThaiFormatter.formatCurrency(Math.abs(order.totalAmount))}",
                                fontWeight = FontWeight.Bold,
                                color = if (isBuy) DeepBurgundy else ThaiGreen,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (order.metalType == MetalType.GOLD_965) "${order.weightInBaht} บาท" else "${order.weightInGrams} กรัม",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun Icon(imageName: androidx.compose.ui.graphics.vector.ImageVector, contentDescription: String, tint: Color, modifier: Modifier) {
    Icon(imageVector = imageName, contentDescription = contentDescription, tint = tint, modifier = modifier)
}
