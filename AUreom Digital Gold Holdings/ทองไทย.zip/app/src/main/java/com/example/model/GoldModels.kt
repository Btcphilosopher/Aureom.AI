package com.example.model

import java.util.UUID

// Product classifications
enum class MetalType { GOLD_965, GOLD_9999, SILVER_999 }
enum class ProductType { BAR, ORNAMENT }

// Purity Percentage helpers
fun MetalType.purityPercent(): Double = when (this) {
    MetalType.GOLD_965 -> 96.5
    MetalType.GOLD_9999 -> 99.99
    MetalType.SILVER_999 -> 99.90
}

data class Product(
    val id: String,
    val name: String,
    val metalType: MetalType,
    val productType: ProductType,
    val weightInBaht: Double,
    val weightInGrams: Double,
    val manufacturer: String = "สมาคมค้าทองคำแห่งประเทศไทย",
    val premiumFee: Double, // ค่าบล็อก / ค่ากำเหน็จ
    val availableInventory: Int = 120,
    val imageUrl: String = ""
)

data class LivePrices(
    val timestamp: Long,
    val announcementNo: Int,
    // Gold 96.5% Bar
    val bar965Buy: Double,
    val bar965Sell: Double,
    val bar965Change: Double,
    // Gold 96.5% Ornament
    val ornament965Buy: Double,
    val ornament965Sell: Double,
    val ornament965Change: Double,
    // Gold 99.99% per gram
    val gold9999BuyPerGram: Double,
    val gold9999SellPerGram: Double,
    // Silver 99.9% per gram
    val silverBuyPerGram: Double,
    val silverSellPerGram: Double,
    // Global Spot
    val goldSpotUsd: Double,
    val silverSpotUsd: Double,
    val usdToThb: Double,
    val cnyToThb: Double,
    val sgdToThb: Double
)

enum class OrderStatus {
    PENDING, CONFIRMED, COMPLETED, CANCELLED
}

enum class DeliveryMethod {
    VAULT_SECURE, // ฝากเก็บห้องนิรภัย
    STORE_PICKUP, // รับที่สาขา
    HOME_DELIVERY // จัดส่งถึงบ้าน
}

data class GoldOrder(
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val productName: String,
    val metalType: MetalType,
    val productType: ProductType,
    val weightInBaht: Double,
    val weightInGrams: Double,
    val unitPrice: Double,
    val premiumFee: Double,
    val shippingFee: Double,
    val totalAmount: Double,
    val deliveryMethod: DeliveryMethod,
    val paymentMethod: String = "ธนาคารไทยพานิชย์ (SCB)",
    val timestamp: Long = System.currentTimeMillis(),
    val status: OrderStatus = OrderStatus.CONFIRMED,
    val allocatedBarSerial: String? = null
)

// Double-Entry Ledger models
data class LedgerEntry(
    val entryId: String = UUID.randomUUID().toString(),
    val accountId: String,
    val asset: String, // "THB", "GOLD_965_BAR", "GOLD_965_ORN", "GOLD_9999_BAR", "SILVER_BAR"
    val quantity: Double,
    val unit: String, // "THB", "BAHT_GOLD", "GRAM"
    val value: Double, // cash value
    val currency: String = "THB",
    val timestamp: Long = System.currentTimeMillis(),
    val eventId: String,
    val reference: String
)

// Replayability / Event Sourcing
data class SystemEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val name: String, // e.g., "PriceUpdated", "GoldPurchased", "VaultDepositCompleted"
    val payload: String,
    val timestamp: Long = System.currentTimeMillis()
)

// Digital Metal Passport (Tokenized Allocated Ownership)
data class MetalPassport(
    val id: String = UUID.randomUUID().toString(),
    val serialNumber: String,
    val metalType: MetalType,
    val productType: ProductType,
    val weightGrams: Double,
    val weightBaht: Double,
    val purity: Double,
    val manufacturer: String,
    val manufactureDate: String,
    val assayMethod: String = "XRF (X-ray Fluorescence)",
    val assayConfidence: Double = 99.98,
    val vaultLocation: String = "Bangkok Secure Vault - TH-001",
    val ownerId: String,
    val allocatedDate: String,
    val auditStatus: String = "ตรวจสอบแล้ว 100% (Audited)"
)

// Price alert setup
data class PriceAlert(
    val id: String = UUID.randomUUID().toString(),
    val targetPrice: Double,
    val triggerOnIncrease: Boolean, // True if trigger when price >= target, False if <=
    val isTriggered: Boolean = false,
    val label: String
)

// Branch / Store locations
data class ThaiBranch(
    val id: String,
    val name: String,
    val address: String,
    val openHours: String = "09:30 - 18:00 น.",
    val services: List<String> = listOf("ซื้อทอง", "ขายคืน", "รับฝากทอง", "รับสลักชื่อ"),
    val latitude: Double,
    val longitude: Double
)

// Branch Pickups
enum class PickupStatus {
    PENDING_CONFIRM, READY_FOR_PICKUP, COMPLETED, CANCELLED
}

data class PickupOrder(
    val id: String = UUID.randomUUID().toString(),
    val branchName: String,
    val productName: String,
    val weightText: String,
    val pickupCode: String,
    val status: PickupStatus = PickupStatus.PENDING_CONFIRM,
    val timestamp: Long = System.currentTimeMillis()
)

// Deliveries
enum class DeliveryStatus {
    ORDERED, PREPARING, QUALITY_CHECK, PACKED, SHIPPED, IN_TRANSIT, DELIVERED
}

data class GoldDelivery(
    val id: String = UUID.randomUUID().toString(),
    val trackingNo: String,
    val productName: String,
    val address: String,
    val status: DeliveryStatus = DeliveryStatus.ORDERED,
    val updatedAt: Long = System.currentTimeMillis()
)

// Custom gold evaluations / assay
data class AssayReport(
    val id: String = UUID.randomUUID().toString(),
    val itemDescription: String,
    val weightGrams: Double,
    val testedPurityPercent: Double,
    val verifiedMetal: String = "ทองคำ (GOLD)",
    val testMethod: String, // "XRF Analysis", "Specific Gravity", "Fire Assay"
    val estimatedValue: Double,
    val testConfidence: Double,
    val status: String = "ประเมินเสร็จสิ้น",
    val timestamp: Long = System.currentTimeMillis()
)
