package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Thai Gold Palette
val DeepBurgundy = Color(0xFF5C1315)      // Primary dark red / burgundy
val DarkBurgundy = Color(0xFF3B0B0C)      // Deeper shadow red
val BrushedGold = Color(0xFFC5A059)       // Champagne Gold accent
val PremiumGold = Color(0xFFD4AF37)       // Rich gold accent
val WarmIvory = Color(0xFFFAF8F5)         // Main background (warm white)
val SoftChampagne = Color(0xFFF3EDE2)     // Card background / container
val Charcoal = Color(0xFF1E1E1E)          // Deep dark for text and solid panels
val GoldAccent = Color(0xFFFFD700)        // Gold highlight

val ThaiGreen = Color(0xFF1B4A2F)         // Positive changes
val ThaiRed = Color(0xFF8B1E1E)           // Negative changes

// Material 3 mappings
val Primary = DeepBurgundy
val Secondary = BrushedGold
val Background = WarmIvory
val Surface = Color.White
val OnBackground = Charcoal
val OnPrimary = Color.White
val OnSurface = Charcoal
