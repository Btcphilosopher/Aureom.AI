package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SoftChampagne

enum class MainScreen {
    HOME, MARKET, TRADE, PORTFOLIO, ACCOUNT
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    var currentScreen by remember { mutableStateOf(MainScreen.HOME) }
    var tradeScreenInitialIsBuy by remember { mutableStateOf(true) }

    // Inter-screen navigation shortcuts
    val navigateToTrade: (Boolean) -> Unit = { isBuy ->
        tradeScreenInitialIsBuy = isBuy
        currentScreen = MainScreen.TRADE
    }

    val navigateToPortfolio: () -> Unit = {
        currentScreen = MainScreen.PORTFOLIO
    }

    // Standard Android Back Button behavior integration
    if (currentScreen != MainScreen.HOME) {
        BackHandler {
            currentScreen = MainScreen.HOME
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepBurgundy)
                    .statusBarsPadding()
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ทองไทย",
                    color = PremiumGold,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "THAI GOLD & SILVER",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = DeepBurgundy,
                contentColor = PremiumGold,
                modifier = Modifier
                    .navigationBarsPadding()
                    .border(0.5.dp, PremiumGold.copy(alpha = 0.3f))
            ) {
                // Screen 1: Home
                NavigationBarItem(
                    selected = currentScreen == MainScreen.HOME,
                    onClick = { currentScreen = MainScreen.HOME },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == MainScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "หน้าหลัก",
                            tint = if (currentScreen == MainScreen.HOME) DeepBurgundy else PremiumGold
                        )
                    },
                    label = { Text("หน้าหลัก", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = PremiumGold
                    ),
                    modifier = Modifier.testTag("nav_home")
                )

                // Screen 2: Prices
                NavigationBarItem(
                    selected = currentScreen == MainScreen.MARKET,
                    onClick = { currentScreen = MainScreen.MARKET },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == MainScreen.MARKET) Icons.Filled.TrendingUp else Icons.Outlined.TrendingUp,
                            contentDescription = "ราคา",
                            tint = if (currentScreen == MainScreen.MARKET) DeepBurgundy else PremiumGold
                        )
                    },
                    label = { Text("ราคา", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = PremiumGold
                    ),
                    modifier = Modifier.testTag("nav_market")
                )

                // Screen 3: Trade
                NavigationBarItem(
                    selected = currentScreen == MainScreen.TRADE,
                    onClick = { 
                        tradeScreenInitialIsBuy = true
                        currentScreen = MainScreen.TRADE 
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == MainScreen.TRADE) Icons.Filled.SwapHoriz else Icons.Outlined.SwapHoriz,
                            contentDescription = "ซื้อขาย",
                            tint = if (currentScreen == MainScreen.TRADE) DeepBurgundy else PremiumGold
                        )
                    },
                    label = { Text("ซื้อขาย", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = PremiumGold
                    ),
                    modifier = Modifier.testTag("nav_trade")
                )

                // Screen 4: Portfolio
                NavigationBarItem(
                    selected = currentScreen == MainScreen.PORTFOLIO,
                    onClick = { currentScreen = MainScreen.PORTFOLIO },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == MainScreen.PORTFOLIO) Icons.Filled.Lock else Icons.Outlined.Lock,
                            contentDescription = "ทองของฉัน",
                            tint = if (currentScreen == MainScreen.PORTFOLIO) DeepBurgundy else PremiumGold
                        )
                    },
                    label = { Text("ทองของฉัน", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = PremiumGold
                    ),
                    modifier = Modifier.testTag("nav_portfolio")
                )

                // Screen 5: Account
                NavigationBarItem(
                    selected = currentScreen == MainScreen.ACCOUNT,
                    onClick = { currentScreen = MainScreen.ACCOUNT },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == MainScreen.ACCOUNT) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle,
                            contentDescription = "บัญชี",
                            tint = if (currentScreen == MainScreen.ACCOUNT) DeepBurgundy else PremiumGold
                        )
                    },
                    label = { Text("บัญชี", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = PremiumGold
                    ),
                    modifier = Modifier.testTag("nav_account")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                MainScreen.HOME -> HomeScreen(
                    onNavigateToTrade = navigateToTrade,
                    onNavigateToPortfolio = navigateToPortfolio
                )
                MainScreen.MARKET -> MarketScreen()
                MainScreen.TRADE -> TradeScreen(
                    initialModeIsBuy = tradeScreenInitialIsBuy
                )
                MainScreen.PORTFOLIO -> PortfolioScreen()
                MainScreen.ACCOUNT -> AccountScreen()
            }
        }
    }
}
