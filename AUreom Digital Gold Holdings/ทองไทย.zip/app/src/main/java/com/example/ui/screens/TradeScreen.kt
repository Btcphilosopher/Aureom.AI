package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ThaiGoldMockEngine
import com.example.model.*
import com.example.ui.theme.*
import com.example.util.ThaiFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeScreen(
    initialModeIsBuy: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prices by ThaiGoldMockEngine.currentPrices.collectAsStateWithLifecycle()
    val cashBalance by ThaiGoldMockEngine.cashBalance.collectAsStateWithLifecycle()
    val gold965Baht by ThaiGoldMockEngine.gold965BahtBalance.collectAsStateWithLifecycle()
    val gold9999g by ThaiGoldMockEngine.gold9999GramBalance.collectAsStateWithLifecycle()
    val allocatedBars by ThaiGoldMockEngine.allocatedBars.collectAsStateWithLifecycle()

    var isBuyMode by remember { mutableStateOf(initialModeIsBuy) }
    var selectedMetalType by remember { mutableStateOf(MetalType.GOLD_965) }

    // Buy Dialog state
    var showBuyDialog by remember { mutableStateOf(false) }
    var selectedProductForBuy by remember { mutableStateOf<Product?>(null) }
    var buyByCashAmount by remember { mutableStateOf(false) }
    var buyCashInput by remember { mutableStateOf("") }
    var buyWeightBahtInput by remember { mutableStateOf(1.0) }
    var selectedDeliveryMethod by remember { mutableStateOf(DeliveryMethod.VAULT_SECURE) }
    var selectedBranchForPickup by remember { mutableStateOf(ThaiGoldMockEngine.branches[0]) }
    var homeAddressInput by remember { mutableStateOf("") }

    // Sell Mode tab
    var showAssayTab by remember { mutableStateOf(false) }

    // Assay form state
    var assayCategory by remember { mutableStateOf("สร้อยคอ") }
    var assayWeightInput by remember { mutableStateOf("") }
    var assayMethod by remember { mutableStateOf("XRF") }
    var currentAssayResult by remember { mutableStateOf<AssayReport?>(null) }

    // Portfolio Sell state
    var showSellDialog by remember { mutableStateOf(false) }
    var sellWeightBahtInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Mode Selector: Buy (ซื้อทอง) vs Sell (ขายทอง)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepBurgundy)
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            TabRow(
                selectedTabIndex = if (isBuyMode) 0 else 1,
                containerColor = DeepBurgundy,
                contentColor = PremiumGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[if (isBuyMode) 0 else 1]),
                        color = PremiumGold
                    )
                },
                modifier = Modifier.width(300.dp)
            ) {
                Tab(
                    selected = isBuyMode,
                    onClick = { isBuyMode = true },
                    modifier = Modifier.testTag("buy_tab")
                ) {
                    Text("ซื้อทองคำ", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(12.dp))
                }
                Tab(
                    selected = !isBuyMode,
                    onClick = { isBuyMode = false },
                    modifier = Modifier.testTag("sell_tab")
                ) {
                    Text("ขายทองคืน", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(12.dp))
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            if (isBuyMode) {
                // Metal Type Filter Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            MetalType.GOLD_965 to "ทอง 96.5%",
                            MetalType.GOLD_9999 to "ทอง 99.99%",
                            MetalType.SILVER_999 to "เงิน 99.9%"
                        ).forEach { (type, label) ->
                            val isSelected = selectedMetalType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) DeepBurgundy else SoftChampagne)
                                    .clickable { selectedMetalType = type }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else DeepBurgundy
                                )
                            }
                        }
                    }
                }

                // Header message based on choice
                item {
                    Text(
                        text = when (selectedMetalType) {
                            MetalType.GOLD_965 -> "ทองคำแท่งและเครื่องประดับยอดนิยม มาตรฐานสมาคม"
                            MetalType.GOLD_9999 -> "ทองคำแท่งนำเข้าเกรดสวิสและออสเตรเลีย ความบริสุทธิ์สูง"
                            MetalType.SILVER_999 -> "เงินแท่งบริสุทธิ์เพื่อการสะสมและการออมระยะยาว"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                // Product items list
                val products = when (selectedMetalType) {
                    MetalType.GOLD_965 -> ThaiGoldMockEngine.products965Bar + ThaiGoldMockEngine.products965Ornament
                    MetalType.GOLD_9999 -> ThaiGoldMockEngine.products9999Gold
                    MetalType.SILVER_999 -> ThaiGoldMockEngine.productsSilver
                }

                items(products) { product ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedProductForBuy = product
                                buyWeightBahtInput = product.weightInBaht
                                selectedDeliveryMethod = DeliveryMethod.VAULT_SECURE
                                showBuyDialog = true
                            }
                            .testTag("product_card_${product.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Metal Visual Card Placeholder
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        Brush.linearGradient(
                                            colors = if (product.metalType == MetalType.SILVER_999) {
                                                listOf(Color(0xFFE0E0E0), Color(0xFFF5F5F5))
                                            } else {
                                                listOf(PremiumGold, BrushedGold)
                                            }
                                        )
                                    )
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (product.metalType == MetalType.SILVER_999) "AG 99.9" else "AU ${if (product.metalType == MetalType.GOLD_965) "96.5" else "99.9"}",
                                    color = if (product.metalType == MetalType.SILVER_999) Charcoal else DeepBurgundy,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = product.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "น้ำหนัก: ${if (product.metalType == MetalType.GOLD_965) "${product.weightInBaht} บาท" else "${product.weightInGrams} กรัม"}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "ผู้ผลิต: ${product.manufacturer}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                val rate = when (product.metalType) {
                                    MetalType.GOLD_965 -> if (product.productType == ProductType.BAR) prices.bar965Sell else prices.ornament965Sell
                                    MetalType.GOLD_9999 -> prices.gold9999SellPerGram
                                    MetalType.SILVER_999 -> prices.silverSellPerGram
                                }
                                val quantityFactor = if (product.metalType == MetalType.GOLD_965) product.weightInBaht else product.weightInGrams
                                val baseCost = quantityFactor * rate
                                val totalEstimated = baseCost + product.premiumFee

                                Text(
                                    text = ThaiFormatter.formatCurrency(totalEstimated),
                                    fontWeight = FontWeight.Bold,
                                    color = DeepBurgundy,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "รวมค่าบล็อก ฿${ThaiFormatter.formatDecimal(product.premiumFee)}",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            } else {
                // SELL MODE Tab Selector: Portal Assets vs Jewelry Appraisal
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAssayTab = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!showAssayTab) DeepBurgundy else SoftChampagne,
                                contentColor = if (!showAssayTab) Color.White else DeepBurgundy
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ขายพอร์ต/ทองฝากเก็บ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showAssayTab = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showAssayTab) DeepBurgundy else SoftChampagne,
                                contentColor = if (showAssayTab) Color.White else DeepBurgundy
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).testTag("jewelry_assay_button")
                        ) {
                            Text("ประเมินทองรูปพรรณ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (!showAssayTab) {
                    // Sell from portfolio/vault screen
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("ทองคำแท่ง 96.5% ในห้องนิรภัยที่ขายได้", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("จำนวนทั้งหมดของคุณ", fontSize = 11.sp, color = Color.Gray)
                                        Text("${gold965Baht} บาททองคำ", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DeepBurgundy)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("มูลค่ารับซื้อคืนปัจจุบัน", fontSize = 11.sp, color = Color.Gray)
                                        Text("฿${ThaiFormatter.formatDecimal(gold965Baht * prices.bar965Buy)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ThaiGreen)
                                    }
                                }

                                Button(
                                    onClick = { showSellDialog = true },
                                    enabled = gold965Baht > 0,
                                    modifier = Modifier.fillMaxWidth().testTag("sell_portfolio_trigger_button"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy)
                                ) {
                                    Text("ขายคืนทองคำแท่งเข้าร้าน", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // List of allocated bar assets that can be sold back individually
                    item {
                        Text("ใบรับรองทองคำจริง (Metal Passports) ที่สามารถขายคืนได้", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DeepBurgundy)
                    }

                    if (allocatedBars.isEmpty()) {
                        item {
                            Text("ไม่มีทองคำแท่งแบบ allocated ในพอร์ตสำหรับการขายคืนรายชิ้น", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(8.dp))
                        }
                    } else {
                        items(allocatedBars) { bar ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("ซีเรียล: ${bar.serialNumber}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("น้ำหนัก: ${bar.weightBaht} บาท (${bar.weightGrams}g) • Purity: ${bar.purity}%", fontSize = 11.sp, color = Color.Gray)
                                    }

                                    Button(
                                        onClick = {
                                            val sellRate = if (bar.metalType == MetalType.GOLD_965) prices.bar965Buy else prices.gold9999BuyPerGram
                                            val result = ThaiGoldMockEngine.sellProduct(
                                                metalType = bar.metalType,
                                                productType = bar.productType,
                                                weightInBaht = bar.weightBaht,
                                                weightInGrams = bar.weightGrams,
                                                sellRatePerUnit = sellRate,
                                                associatedPassportId = bar.id
                                            )
                                            if (result.isSuccess) {
                                                Toast.makeText(context, "ขายคืนแท่งทองซีเรียล ${bar.serialNumber} เรียบร้อย!", Toast.LENGTH_LONG).show()
                                            }
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SoftChampagne, contentColor = DeepBurgundy),
                                        modifier = Modifier.testTag("sell_bar_button_${bar.serialNumber}")
                                    ) {
                                        Text("ขายคืนด่วน", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // JEWELRY DIGITAL ASSAY SCREEN
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("เครื่องประดับทองเก่า ชำรุด หรือต่างร้าน ตรวจวัดด้วยมาตรฐานแล็บ", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("สร้อยคอ", "แหวน", "กำไล", "ต่างหู", "เศษทอง").forEach { category ->
                                        val isSelected = assayCategory == category
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (isSelected) DeepBurgundy else SoftChampagne)
                                                .clickable { assayCategory = category }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(category, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else DeepBurgundy)
                                        }
                                    }
                                }

                                // Weight input
                                OutlinedTextField(
                                    value = assayWeightInput,
                                    onValueChange = { assayWeightInput = it },
                                    label = { Text("น้ำหนักเป็นกรัม (เช่น 15.2)") },
                                    modifier = Modifier.fillMaxWidth().testTag("assay_weight_input"),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )

                                // Assay Method
                                Text("เทคโนโลยีการประเมินวิเคราะห์", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    listOf("XRF" to "XRF สเปกโทรสโกปี (99.98%)", "Specific Gravity" to "ชั่งลอยน้ำถ่วงจำเพาะ (99.5%)").forEach { (method, desc) ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { assayMethod = method }) {
                                            RadioButton(selected = assayMethod == method, onClick = { assayMethod = method })
                                            Text(desc, fontSize = 12.sp)
                                        }
                                    }
                                }

                                Button(
                                    onClick = {
                                        val wt = assayWeightInput.toDoubleOrNull()
                                        if (wt != null && wt > 0) {
                                            currentAssayResult = ThaiGoldMockEngine.submitAssayEvaluation(
                                                description = "$assayCategory ทองคำสำหรับตรวจสอบ",
                                                weight = wt,
                                                method = assayMethod
                                            )
                                        } else {
                                            Toast.makeText(context, "กรุณาระบุน้ำหนักทองที่ถูกต้อง", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("start_assay_button"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy)
                                ) {
                                    Icon(Icons.Default.QueryStats, contentDescription = "Scan")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("เริ่มสแกนตรวจสอบเปอร์เซ็นต์ทอง", fontWeight = FontWeight.Bold)
                                }

                                // Results proposals
                                AnimatedVisibility(visible = currentAssayResult != null) {
                                    val report = currentAssayResult
                                    if (report != null) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(SoftChampagne)
                                                .padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("ผลวิเคราะห์:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(report.status, color = ThaiGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                            Text("เครื่องมือ: ${report.testMethod}", fontSize = 11.sp, color = Charcoal)
                                            Text("น้ำหนักรวม: ${report.weightGrams} กรัม", fontSize = 11.sp, color = Charcoal)
                                            Text("เปอร์เซ็นต์ทองที่วัดได้: ${report.testedPurityPercent}%", fontSize = 11.sp, color = Charcoal, fontWeight = FontWeight.Bold)
                                            Text("ความแม่นยำทางนิวเคลียร์: ${report.testConfidence}%", fontSize = 11.sp, color = Charcoal)

                                            Divider(color = Color.LightGray.copy(alpha = 0.5f))

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Column {
                                                    Text("ราคาเสนอรับซื้อคืนสุทธิ", fontSize = 11.sp, color = Color.Gray)
                                                    Text("฿${ThaiFormatter.formatDecimal(report.estimatedValue)}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = DeepBurgundy)
                                                }

                                                Button(
                                                    onClick = {
                                                        val res = ThaiGoldMockEngine.sellProduct(
                                                            metalType = MetalType.GOLD_965,
                                                            productType = ProductType.ORNAMENT,
                                                            weightInBaht = report.weightGrams / ThaiFormatter.GRAMS_PER_BAHT_BAR,
                                                            weightInGrams = report.weightGrams,
                                                            sellRatePerUnit = report.estimatedValue / (report.weightGrams / ThaiFormatter.GRAMS_PER_BAHT_BAR)
                                                        )
                                                        if (res.isSuccess) {
                                                            Toast.makeText(context, "โอนเงินเข้าบัญชีคุณเรียบร้อย ฿${ThaiFormatter.formatDecimal(report.estimatedValue)}!", Toast.LENGTH_LONG).show()
                                                            currentAssayResult = null
                                                            assayWeightInput = ""
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = ThaiGreen),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.testTag("confirm_sell_assay_button")
                                                ) {
                                                    Text("ยืนยันขายทองคำแท้")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }

    // Interactive Buy Modal Sheet/Dialog
    if (showBuyDialog && selectedProductForBuy != null) {
        val product = selectedProductForBuy!!
        val is965 = product.metalType == MetalType.GOLD_965

        AlertDialog(
            onDismissRequest = { showBuyDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        val rate = when (product.metalType) {
                            MetalType.GOLD_965 -> if (product.productType == ProductType.BAR) prices.bar965Sell else prices.ornament965Sell
                            MetalType.GOLD_9999 -> prices.gold9999SellPerGram
                            MetalType.SILVER_999 -> prices.silverSellPerGram
                        }

                        val wtBaht: Double
                        val wtGrams: Double
                        val finalCost: Double

                        if (buyByCashAmount) {
                            val cash = buyCashInput.toDoubleOrNull() ?: 0.0
                            if (cash <= 0.0) {
                                Toast.makeText(context, "ระบุจำนวนเงินที่ต้องการซื้อ", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            finalCost = cash
                            if (product.metalType == MetalType.GOLD_965) {
                                wtBaht = (cash - product.premiumFee) / rate
                                wtGrams = wtBaht * ThaiFormatter.GRAMS_PER_BAHT_BAR
                            } else {
                                wtGrams = (cash - product.premiumFee) / rate
                                wtBaht = wtGrams / ThaiFormatter.GRAMS_PER_BAHT_BAR
                            }
                        } else {
                            wtBaht = buyWeightBahtInput
                            wtGrams = if (is965) buyWeightBahtInput * ThaiFormatter.GRAMS_PER_BAHT_BAR else product.weightInGrams
                            finalCost = (if (is965) wtBaht else wtGrams) * rate + product.premiumFee + (if (selectedDeliveryMethod == DeliveryMethod.HOME_DELIVERY) 150.0 else 0.0)
                        }

                        val res = ThaiGoldMockEngine.buyProduct(
                            product = product,
                            inputWeightBaht = wtBaht,
                            inputWeightGrams = wtGrams,
                            totalCost = finalCost,
                            deliveryMethod = selectedDeliveryMethod,
                            shippingAddress = homeAddressInput,
                            branchId = selectedBranchForPickup.id
                        )

                        if (res.isSuccess) {
                            Toast.makeText(context, "ซื้อสำเร็จและทำบัญชีเรียบร้อย!", Toast.LENGTH_LONG).show()
                            showBuyDialog = false
                        } else {
                            Toast.makeText(context, "เงินทดสอบของคุณไม่เพียงพอ!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                    modifier = Modifier.testTag("execute_buy_confirm_button")
                ) {
                    Text("ยืนยันออมทองจริง")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBuyDialog = false }) {
                    Text("ยกเลิก")
                }
            },
            title = {
                Text("ซื้อและจัดสรร: ${product.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DeepBurgundy)
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Purchase Method Toggles: Weight vs Cash Budget
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!buyByCashAmount) DeepBurgundy else SoftChampagne)
                                .clickable { buyByCashAmount = false }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("ซื้อตามน้ำหนัก", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (!buyByCashAmount) Color.White else DeepBurgundy)
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                        .background(if (buyByCashAmount) DeepBurgundy else SoftChampagne)
                                        .clickable { buyByCashAmount = true }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("ซื้อด้วยจำนวนเงิน (฿)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (buyByCashAmount) Color.White else DeepBurgundy)
                                }
                            }

                            if (buyByCashAmount) {
                                OutlinedTextField(
                                    value = buyCashInput,
                                    onValueChange = { buyCashInput = it },
                                    label = { Text("ระบุจำนวนเงินบาท เช่น 10000") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth().testTag("buy_cash_input_field")
                                )
                            } else {
                                if (is965) {
                                    // Preset weights selector
                                    Text("เลือกน้ำหนักทองคำแท้", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf(1.0 to "1 บาท", 2.0 to "2 บาท", 5.0 to "5 บาท", 10.0 to "10 บาท").forEach { (wt, desc) ->
                                            val isSelected = buyWeightBahtInput == wt
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isSelected) BrushedGold else SoftChampagne)
                                                    .clickable { buyWeightBahtInput = wt }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(desc, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else DeepBurgundy)
                                            }
                                        }
                                    }
                                } else {
                                    Text("น้ำหนักสินค้าตามมาตรฐานสากล: ${product.weightInGrams} กรัม", fontSize = 12.sp, color = Color.Gray)
                                }
                            }

                            Divider(color = Color.LightGray.copy(alpha = 0.5f))

                            // Delivery/Vault Selection
                            Text("วิธีการรับทองคำแท้", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(
                                    DeliveryMethod.VAULT_SECURE to "ฝากในตู้นิรภัยความปลอดภัยสูง กรุงเทพฯ (ฟรี)",
                                    DeliveryMethod.STORE_PICKUP to "จองรับทองจริงที่ห้างทองสาขาใกล้บ้าน",
                                    DeliveryMethod.HOME_DELIVERY to "จัดส่งแบบประกันภัยถึงหน้าบ้านคุณ (+฿150)"
                                ).forEach { (method, desc) ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { selectedDeliveryMethod = method }
                                    ) {
                                        RadioButton(selected = selectedDeliveryMethod == method, onClick = { selectedDeliveryMethod = method })
                                        Text(desc, fontSize = 12.sp)
                                    }
                                }
                            }

                            // Sub forms for delivery branch/address
                            if (selectedDeliveryMethod == DeliveryMethod.STORE_PICKUP) {
                                Text("เลือกสาขาที่จะไปรับทอง", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                ThaiGoldMockEngine.branches.forEach { br ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { selectedBranchForPickup = br }
                                    ) {
                                        RadioButton(selected = selectedBranchForPickup.id == br.id, onClick = { selectedBranchForPickup = br })
                                        Text(br.name, fontSize = 11.sp)
                                    }
                                }
                            } else if (selectedDeliveryMethod == DeliveryMethod.HOME_DELIVERY) {
                                OutlinedTextField(
                                    value = homeAddressInput,
                                    onValueChange = { homeAddressInput = it },
                                    placeholder = { Text("ระบุที่อยู่จัดส่งพัสดุและรหัสไปรษณีย์") },
                                    modifier = Modifier.fillMaxWidth(),
                                    maxLines = 2
                                )
                            }

                            Divider(color = Color.LightGray.copy(alpha = 0.5f))

                            // Fee transparent pricing breakdown
                            val rate = when (product.metalType) {
                                MetalType.GOLD_965 -> if (product.productType == ProductType.BAR) prices.bar965Sell else prices.ornament965Sell
                                MetalType.GOLD_9999 -> prices.gold9999SellPerGram
                                MetalType.SILVER_999 -> prices.silverSellPerGram
                            }

                            val calculatedWeightText: String
                            val calculatedCost: Double

                            if (buyByCashAmount) {
                                val cash = buyCashInput.toDoubleOrNull() ?: 0.0
                                calculatedCost = cash
                                if (product.metalType == MetalType.GOLD_965) {
                                    val finalWt = (cash - product.premiumFee) / rate
                                    calculatedWeightText = "ทองที่จะได้รับประมาณ ${ThaiFormatter.formatDecimal(finalWt)} บาท (~${ThaiFormatter.formatDecimal(finalWt * ThaiFormatter.GRAMS_PER_BAHT_BAR)} กรัม)"
                                } else {
                                    val finalWt = (cash - product.premiumFee) / rate
                                    calculatedWeightText = "ทองที่จะได้รับประมาณ ${ThaiFormatter.formatDecimal(finalWt)} กรัม"
                                }
                            } else {
                                val qty = if (is965) buyWeightBahtInput else product.weightInGrams
                                val baseCost = qty * rate
                                val shipFee = if (selectedDeliveryMethod == DeliveryMethod.HOME_DELIVERY) 150.0 else 0.0
                                calculatedCost = baseCost + product.premiumFee + shipFee
                                calculatedWeightText = "น้ำหนักรวม: ${if (is965) "$buyWeightBahtInput บาท" else "${product.weightInGrams} กรัม"}"
                            }

                            Text(calculatedWeightText, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepBurgundy)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ค่าบล็อก / ค่ากำเหน็จ:", fontSize = 11.sp, color = Color.Gray)
                                Text("฿${ThaiFormatter.formatDecimal(product.premiumFee)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("เงินสดคงเหลือทดสอบ:", fontSize = 11.sp, color = Color.Gray)
                                Text("฿${ThaiFormatter.formatDecimal(cashBalance)}", fontSize = 11.sp, color = PremiumGold, fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SoftChampagne)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("ยอดสุทธิที่ต้องชำระ:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DeepBurgundy)
                                Text("฿${ThaiFormatter.formatDecimal(calculatedCost)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DeepBurgundy)
                            }
                        }
                    }
                )
            }

            // Interactive Portfolio Sell Dialog
            if (showSellDialog) {
                AlertDialog(
                    onDismissRequest = { showSellDialog = false },
                    confirmButton = {
                        Button(
                            onClick = {
                                val wt = sellWeightBahtInput.toDoubleOrNull() ?: 0.0
                                if (wt <= 0.0 || wt > gold965Baht) {
                                    Toast.makeText(context, "ระบุน้ำหนักทองที่ถูกต้องสำหรับการขายคืน", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                val result = ThaiGoldMockEngine.sellProduct(
                                    metalType = MetalType.GOLD_965,
                                    productType = ProductType.BAR,
                                    weightInBaht = wt,
                                    weightInGrams = wt * ThaiFormatter.GRAMS_PER_BAHT_BAR,
                                    sellRatePerUnit = prices.bar965Buy
                                )

                                if (result.isSuccess) {
                                    Toast.makeText(context, "ขายคืนทองคำสำเร็จ ยอดเงินโอนเข้า ฿${ThaiFormatter.formatDecimal(wt * prices.bar965Buy)}", Toast.LENGTH_LONG).show()
                                    showSellDialog = false
                                    sellWeightBahtInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                            modifier = Modifier.testTag("execute_sell_confirm_button")
                        ) {
                            Text("ขายทองคำเข้าร้าน")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showSellDialog = false }) {
                            Text("ยกเลิก")
                        }
                    },
                    title = {
                        Text("ขายคืนทองคำแท่ง 96.5% เข้าพอร์ต", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DeepBurgundy)
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("ระบุจำนวนบาททองคำที่คุณต้องการขายคืนร้าน ทองคำของคุณจะถูกหักออกจากบัญชีฝากเก็บทันที", fontSize = 12.sp, color = Color.Gray)

                            OutlinedTextField(
                                value = sellWeightBahtInput,
                                onValueChange = { sellWeightBahtInput = it },
                                label = { Text("น้ำหนักที่ต้องการขายคืน (บาท)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth().testTag("sell_weight_field")
                            )

                            val wt = sellWeightBahtInput.toDoubleOrNull() ?: 0.0
                            val estimatedPayout = wt * prices.bar965Buy

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ทองคำของคุณทั้งหมด:", fontSize = 12.sp, color = Color.Gray)
                                Text("$gold965Baht บาท", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ราคารับซื้อสมาคมคืนนี้:", fontSize = 12.sp, color = Color.Gray)
                                Text("฿${ThaiFormatter.formatDecimal(prices.bar965Buy)}/บาท", fontSize = 12.sp, color = ThaiRed, fontWeight = FontWeight.Bold)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SoftChampagne)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("ยอดรับโอนเงินสุทธิ์:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DeepBurgundy)
                                Text("฿${ThaiFormatter.formatDecimal(estimatedPayout)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ThaiGreen)
                            }
                        }
                    }
                )
            }
        }
