package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ThaiGoldMockEngine
import com.example.model.PriceAlert
import com.example.ui.theme.BrushedGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.SoftChampagne
import com.example.ui.theme.ThaiGreen
import com.example.ui.theme.ThaiRed
import com.example.util.ThaiFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketScreen(
    modifier: Modifier = Modifier
) {
    val prices by ThaiGoldMockEngine.currentPrices.collectAsStateWithLifecycle()
    val priceHistory by ThaiGoldMockEngine.priceHistory.collectAsStateWithLifecycle()
    val alerts by ThaiGoldMockEngine.priceAlerts.collectAsStateWithLifecycle()

    var selectedChartRange by remember { mutableStateOf("7D") } // "1D", "7D", "1M", "1Y"
    var selectedChartAsset by remember { mutableStateOf("GOLD_THB") } // "GOLD_THB", "GOLD_USD", "SILVER_THB", "GOLD_SILVER_RATIO"

    var inputAlertPrice by remember { mutableStateOf("") }
    var inputAlertOnIncrease by remember { mutableStateOf(true) } // True: Above, False: Below

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Ticker Header
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ข้อมูลราคาทองและเงิน",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepBurgundy
                        )
                    )
                    Text(
                        text = "ตลาดทองสมาคมไทย & Spot Real-time",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                // Announcement indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepBurgundy.copy(alpha = 0.08f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ครั้งที่ ${prices.announcementNo}",
                        color = DeepBurgundy,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Live Ticker horizontal row
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SoftChampagne.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Spot ทอง", fontSize = 11.sp, color = Color.Gray)
                        Text("$${ThaiFormatter.formatDecimal(prices.goldSpotUsd)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    VerticalDivider(color = Color.LightGray.copy(alpha = 0.5f), modifier = Modifier.height(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("USD/THB", fontSize = 11.sp, color = Color.Gray)
                        Text("${ThaiFormatter.formatDecimal(prices.usdToThb)} ฿", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    VerticalDivider(color = Color.LightGray.copy(alpha = 0.5f), modifier = Modifier.height(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Spot เงิน", fontSize = 11.sp, color = Color.Gray)
                        Text("$${ThaiFormatter.formatDecimal(prices.silverSpotUsd)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Beautiful Interactive Path Chart Canvas
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("market_chart_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Chart Config Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            val assetLabel = when (selectedChartAsset) {
                                "GOLD_THB" -> "ทองแท่ง 96.5% THB"
                                "GOLD_USD" -> "Gold Spot USD"
                                "SILVER_THB" -> "เงินแท่ง 99.9% THB"
                                else -> "Gold/Silver Ratio (XAU/XAG)"
                            }
                            Text(text = assetLabel, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DeepBurgundy)
                            Text(text = "แนวโน้มช่วง $selectedChartRange", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }

                        // Chart Asset Toggles
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("GOLD_THB", "GOLD_USD", "SILVER_THB").forEach { asset ->
                                val label = when (asset) {
                                    "GOLD_THB" -> "ทองไทย"
                                    "GOLD_USD" -> "Spot"
                                    else -> "เงิน"
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedChartAsset == asset) DeepBurgundy else SoftChampagne)
                                        .clickable { selectedChartAsset = asset }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        color = if (selectedChartAsset == asset) Color.White else DeepBurgundy,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Custom Chart Path Drawing on Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val width = size.width
                            val height = size.height

                            // Draw horizontal guidelines
                            val linesCount = 4
                            for (i in 0 until linesCount) {
                                val y = height * (i.toFloat() / (linesCount - 1))
                                drawLine(
                                    color = Color.LightGray.copy(alpha = 0.3f),
                                    start = Offset(0f, y),
                                    end = Offset(width, y),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }

                            // Generate smooth path based on fake chart vectors
                            val points = when (selectedChartAsset) {
                                "GOLD_THB" -> listOf(0.2f, 0.35f, 0.3f, 0.45f, 0.6f, 0.55f, 0.8f, 0.75f, 0.9f)
                                "GOLD_USD" -> listOf(0.4f, 0.38f, 0.5f, 0.48f, 0.55f, 0.62f, 0.7f, 0.65f, 0.85f)
                                else -> listOf(0.1f, 0.15f, 0.22f, 0.2f, 0.35f, 0.45f, 0.4f, 0.55f, 0.6f)
                            }

                            val path = Path()
                            val xStep = width / (points.size - 1)

                            points.forEachIndexed { index, rawY ->
                                val px = index * xStep
                                val py = height - (rawY * height * 0.8f) - (height * 0.1f)
                                if (index == 0) {
                                    path.moveTo(px, py)
                                } else {
                                    path.lineTo(px, py)
                                }
                            }

                            drawPath(
                                path = path,
                                color = DeepBurgundy,
                                style = Stroke(width = 2.dp.toPx())
                            )

                            // Add a linear fade gradient beneath chart path
                            val fillPath = Path().apply {
                                addPath(path)
                                lineTo(width, height)
                                lineTo(0f, height)
                                close()
                            }
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(DeepBurgundy.copy(alpha = 0.2f), Color.Transparent)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Range selection row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        listOf("1D", "7D", "1M", "3M", "1Y").forEach { range ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selectedChartRange == range) BrushedGold.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { selectedChartRange = range }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = range,
                                    color = if (selectedChartRange == range) DeepBurgundy else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Expanded Rate Table
        item {
            Text(
                text = "ตารางอ้างอิงราคาต่าง ๆ",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = DeepBurgundy
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    RateRow(label = "ทองคำ 99.99% (แท่งนอก / Swiss)", buyPrice = "${ThaiFormatter.formatCurrency(prices.gold9999BuyPerGram)}/g", sellPrice = "${ThaiFormatter.formatCurrency(prices.gold9999SellPerGram)}/g")
                    Divider(color = SoftChampagne.copy(alpha = 0.5f))
                    RateRow(label = "เงินแท่ง 99.9% (Silver Bullion)", buyPrice = "${ThaiFormatter.formatCurrency(prices.silverBuyPerGram)}/g", sellPrice = "${ThaiFormatter.formatCurrency(prices.silverSellPerGram)}/g")
                    Divider(color = SoftChampagne.copy(alpha = 0.5f))
                    RateRow(label = "CNY/THB (หยวนจีน)", buyPrice = "${ThaiFormatter.formatDecimal(prices.cnyToThb)} ฿", sellPrice = "-")
                    Divider(color = SoftChampagne.copy(alpha = 0.5f))
                    RateRow(label = "SGD/THB (ดอลลาร์สิงคโปร์)", buyPrice = "${ThaiFormatter.formatDecimal(prices.sgdToThb)} ฿", sellPrice = "-")
                }
            }
        }

        // Live Price Alert Panel
        item {
            Text(
                text = "ตั้งค่าแจ้งเตือนราคาทอง",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = DeepBurgundy
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = inputAlertPrice,
                            onValueChange = { inputAlertPrice = it },
                            placeholder = { Text("ระบุราคา เช่น 43500") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("price_alert_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Button(
                            onClick = {
                                val price = inputAlertPrice.toDoubleOrNull()
                                if (price != null) {
                                    val direction = if (inputAlertOnIncrease) "สูงกว่า" else "ต่ำกว่า"
                                    ThaiGoldMockEngine.addPriceAlert(
                                        price = price,
                                        onIncrease = inputAlertOnIncrease,
                                        label = "ทองแท่ง 96.5% $direction ฿${ThaiFormatter.formatDecimal(price)}"
                                    )
                                    inputAlertPrice = ""
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                            modifier = Modifier.testTag("price_alert_save_button")
                        ) {
                            Text("บันทึก")
                        }
                    }

                    // On Increase / On Decrease Selectors
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = inputAlertOnIncrease,
                                onClick = { inputAlertOnIncrease = true }
                            )
                            Text("สูงกว่าหรือเท่ากับ", fontSize = 13.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = !inputAlertOnIncrease,
                                onClick = { inputAlertOnIncrease = false }
                            )
                            Text("ต่ำกว่าหรือเท่ากับ", fontSize = 13.sp)
                        }
                    }

                    // Existing Alerts List
                    if (alerts.isNotEmpty()) {
                        Divider(color = SoftChampagne)
                        Text("รายการแจ้งเตือนของคุณ", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                        alerts.forEach { alert ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (alert.isTriggered) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                        contentDescription = "Alert",
                                        tint = if (alert.isTriggered) ThaiGreen else BrushedGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = alert.label,
                                        fontSize = 13.sp,
                                        color = if (alert.isTriggered) ThaiGreen else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (alert.isTriggered) FontWeight.Bold else FontWeight.Normal
                                    )
                                }

                                IconButton(onClick = { ThaiGoldMockEngine.removePriceAlert(alert.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove Alert", tint = ThaiRed, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Snapshot History Log
        item {
            Text(
                text = "ประวัติการปรับเปลี่ยนราคาวันนี้",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = DeepBurgundy
            )
        }

        items(priceHistory.reversed().take(5)) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ประกาศครั้งที่ ${item.announcementNo}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                        Text(
                            text = "เวลาประกาศ ${sdf.format(item.timestamp)} น.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ซื้อเข้า 96.5%", fontSize = 10.sp, color = Color.Gray)
                            Text(ThaiFormatter.formatCurrency(item.bar965Buy), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ThaiRed)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ขายออก 96.5%", fontSize = 10.sp, color = Color.Gray)
                            Text(ThaiFormatter.formatCurrency(item.bar965Sell), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepBurgundy)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun RateRow(label: String, buyPrice: String, sellPrice: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(horizontalAlignment = Alignment.End) {
                Text("รับซื้อ", fontSize = 10.sp, color = Color.Gray)
                Text(buyPrice, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ThaiRed)
            }
            if (sellPrice != "-") {
                Column(horizontalAlignment = Alignment.End) {
                    Text("ขายออก", fontSize = 10.sp, color = Color.Gray)
                    Text(sellPrice, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepBurgundy)
                }
            }
        }
    }
}
