package com.example.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object ThaiFormatter {

    private val currencyFormat = DecimalFormat("฿#,##0")
    private val decimalFormat = DecimalFormat("#,##0.00")
    private val precisionWeightFormat = DecimalFormat("#,##0.0000")
    private val gramFormat = DecimalFormat("#,##0.00 กรัม")

    /**
     * Formats an amount to Thai Baht currency (e.g. ฿65,950).
     */
    fun formatCurrency(amount: Double): String {
        return currencyFormat.format(amount)
    }

    /**
     * Formats an amount with standard decimal points (e.g. 10,000.50).
     */
    fun formatDecimal(value: Double): String {
        return decimalFormat.format(value)
    }

    /**
     * Formats gold weight in Baht units with customizable accuracy (e.g. 1.25 บาท).
     */
    fun formatGoldWeightBaht(weightBaht: Double): String {
        return "${decimalFormat.format(weightBaht)} บาท"
    }

    /**
     * Formats gold weight in grams (e.g. 15.244 กรัม).
     */
    fun formatWeightGrams(weightGrams: Double): String {
        return "${precisionWeightFormat.format(weightGrams)} กรัม"
    }

    /**
     * Formats date to Thai Buddhist calendar format (e.g. 6 ตุลาคม 2569).
     */
    fun formatThaiDate(calendar: Calendar = Calendar.getInstance()): String {
        val thaiYear = calendar.get(Calendar.YEAR) + 543
        val monthNames = arrayOf(
            "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
            "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
        )
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = monthNames[calendar.get(Calendar.MONTH)]
        return "$day $month $thaiYear"
    }

    /**
     * Formats time to Thai style (e.g. เวลา 09:02 น.).
     */
    fun formatThaiTime(calendar: Calendar = Calendar.getInstance()): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.US)
        return "เวลา ${sdf.format(calendar.time)} น."
    }

    /**
     * Standard Thai Gold Weight conversion.
     * 1 Baht of Gold Bar = 15.244 grams
     */
    const val GRAMS_PER_BAHT_BAR = 15.244

    fun bahtToGrams(baht: Double): Double {
        return baht * GRAMS_PER_BAHT_BAR
    }

    fun gramsToBaht(grams: Double): Double {
        return grams / GRAMS_PER_BAHT_BAR
    }
}
