package com.example.engine

import com.example.model.*
import com.example.util.ThaiFormatter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.UUID

object ThaiGoldMockEngine {

    private val scope = CoroutineScope(Dispatchers.Default)

    // Current Market state
    private val _currentPrices = MutableStateFlow(
        LivePrices(
            timestamp = System.currentTimeMillis(),
            announcementNo = 1,
            bar965Buy = 43200.0,
            bar965Sell = 43300.0,
            bar965Change = 0.0,
            ornament965Buy = 42422.0,
            ornament965Sell = 43800.0,
            ornament965Change = 0.0,
            gold9999BuyPerGram = 2850.0,
            gold9999SellPerGram = 2860.0,
            silverBuyPerGram = 35.50,
            silverSellPerGram = 36.80,
            goldSpotUsd = 2650.40,
            silverSpotUsd = 31.85,
            usdToThb = 33.12,
            cnyToThb = 4.67,
            sgdToThb = 24.55
        )
    )
    val currentPrices: StateFlow<LivePrices> = _currentPrices.asStateFlow()

    // Price History (for charts)
    private val _priceHistory = MutableStateFlow<List<LivePrices>>(emptyList())
    val priceHistory: StateFlow<List<LivePrices>> = _priceHistory.asStateFlow()

    // Products Data
    val products965Bar = listOf(
        Product("p_b1", "ทองคำแท่ง 96.5% 1 บาท", MetalType.GOLD_965, ProductType.BAR, 1.0, 15.244, premiumFee = 150.0),
        Product("p_b2", "ทองคำแท่ง 96.5% 2 บาท", MetalType.GOLD_965, ProductType.BAR, 2.0, 30.488, premiumFee = 250.0),
        Product("p_b5", "ทองคำแท่ง 96.5% 5 บาท", MetalType.GOLD_965, ProductType.BAR, 5.0, 76.22, premiumFee = 350.0),
        Product("p_b10", "ทองคำแท่ง 96.5% 10 บาท", MetalType.GOLD_965, ProductType.BAR, 10.0, 152.44, premiumFee = 500.0),
        Product("p_b20", "ทองคำแท่ง 96.5% 20 บาท", MetalType.GOLD_965, ProductType.BAR, 20.0, 304.88, premiumFee = 800.0),
        Product("p_b50", "ทองคำแท่ง 96.5% 50 บาท", MetalType.GOLD_965, ProductType.BAR, 50.0, 762.20, premiumFee = 1500.0),
        Product("p_b05s", "ทองคำแท่ง 96.5% 2 สลึง", MetalType.GOLD_965, ProductType.BAR, 0.5, 7.622, premiumFee = 120.0),
        Product("p_b01s", "ทองคำแท่ง 96.5% 1 สลึง", MetalType.GOLD_965, ProductType.BAR, 0.25, 3.811, premiumFee = 100.0)
    )

    val products965Ornament = listOf(
        Product("p_o1", "สร้อยคอทองคำลายมังกร 1 บาท", MetalType.GOLD_965, ProductType.ORNAMENT, 1.0, 15.244, premiumFee = 1200.0),
        Product("p_o2", "สร้อยข้อมือเลสทองคำ 2 บาท", MetalType.GOLD_965, ProductType.ORNAMENT, 2.0, 30.488, premiumFee = 2200.0),
        Product("p_o3", "แหวนทองคำหัวโปร่งสลักลาย 1 สลึง", MetalType.GOLD_965, ProductType.ORNAMENT, 0.25, 3.811, premiumFee = 650.0),
        Product("p_o4", "ต่างหูทองคำระย้าโบราณ 2 สลึง", MetalType.GOLD_965, ProductType.ORNAMENT, 0.5, 7.622, premiumFee = 950.0),
        Product("p_o5", "จี้ทองคำท้าวมหาพรหม 0.5 บาท", MetalType.GOLD_965, ProductType.ORNAMENT, 0.5, 7.622, premiumFee = 800.0)
    )

    val products9999Gold = listOf(
        Product("p_g9_1g", "แผ่นทองสวิส Valcambi 99.99% 1 กรัม", MetalType.GOLD_9999, ProductType.BAR, 0.0655, 1.0, "Valcambi Swiss", 180.0),
        Product("p_g9_5g", "ทองแท่งสวิส Metalor 99.99% 5 กรัม", MetalType.GOLD_9999, ProductType.BAR, 0.3279, 5.0, "Metalor Swiss", 350.0),
        Product("p_g9_10g", "ทองแท่งสวิส Heraeus 99.99% 10 กรัม", MetalType.GOLD_9999, ProductType.BAR, 0.6559, 10.0, "Heraeus Germany", 500.0),
        Product("p_g9_20g", "ทองแท่งออสเตรเลีย Perth Mint 99.99% 20 กรัม", MetalType.GOLD_9999, ProductType.BAR, 1.3119, 20.0, "Perth Mint Australia", 800.0),
        Product("p_g9_50g", "ทองแท่งสวิS PAMP 99.99% 50 กรัม", MetalType.GOLD_9999, ProductType.BAR, 3.2799, 50.0, "PAMP Suisse", 1200.0),
        Product("p_g9_1oz", "เหรียญกษาปณ์ทองคำฝรั่งเซฮอลล์ 99.99% 1 oz", MetalType.GOLD_9999, ProductType.BAR, 2.040, 31.1035, "Royal Canadian Mint", 900.0)
    )

    val productsSilver = listOf(
        Product("p_s_100g", "แผ่นเงินแท้ 99.9% 100 กรัม", MetalType.SILVER_999, ProductType.BAR, 0.0, 100.0, "Thai Silver Refinery", 250.0),
        Product("p_s_1kg", "แท่งเงินแท้ 99.9% 1 กิโลกรัม", MetalType.SILVER_999, ProductType.BAR, 0.0, 1000.0, "Thai Silver Refinery", 1200.0),
        Product("p_s_5kg", "แท่งเงินแท้ 99.9% 5 กิโลกรัม", MetalType.SILVER_999, ProductType.BAR, 0.0, 5000.0, "Thai Silver Refinery", 3500.0)
    )

    // User accounts balances
    private val _cashBalance = MutableStateFlow(250000.0) // Starting with ฿250,000 for realistic demo
    val cashBalance: StateFlow<Double> = _cashBalance.asStateFlow()

    private val _gold965BahtBalance = MutableStateFlow(3.75) // Current held gold 96.5% in Baht
    val gold965BahtBalance: StateFlow<Double> = _gold965BahtBalance.asStateFlow()

    private val _gold9999GramBalance = MutableStateFlow(12.5) // Current held gold 99.99% in grams
    val gold9999GramBalance: StateFlow<Double> = _gold9999GramBalance.asStateFlow()

    private val _silverGramBalance = MutableStateFlow(1200.0) // Current held silver in grams (1.2 kg)
    val silverGramBalance: StateFlow<Double> = _silverGramBalance.asStateFlow()

    // Double-entry Ledger entries
    private val _ledgerEntries = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerEntries: StateFlow<List<LedgerEntry>> = _ledgerEntries.asStateFlow()

    // System Events (for replayability)
    private val _events = MutableStateFlow<List<SystemEvent>>(emptyList())
    val events: StateFlow<List<SystemEvent>> = _events.asStateFlow()

    // Allocated Metal Passports (certificates)
    private val _allocatedBars = MutableStateFlow<List<MetalPassport>>(emptyList())
    val allocatedBars: StateFlow<List<MetalPassport>> = _allocatedBars.asStateFlow()

    // Orders History
    private val _orders = MutableStateFlow<List<GoldOrder>>(emptyList())
    val orders: StateFlow<List<GoldOrder>> = _orders.asStateFlow()

    // Price alerts setup
    private val _priceAlerts = MutableStateFlow<List<PriceAlert>>(
        listOf(
            PriceAlert(targetPrice = 45000.0, triggerOnIncrease = true, label = "ทองแท่ง 96.5% ถึง ฿45,000"),
            PriceAlert(targetPrice = 42000.0, triggerOnIncrease = false, label = "ทองแท่ง 96.5% ต่ำกว่า ฿42,000")
        )
    )
    val priceAlerts: StateFlow<List<PriceAlert>> = _priceAlerts.asStateFlow()

    // Branches
    val branches = listOf(
        ThaiBranch("b_yr", "ห้างทองทองไทย สาขาเยาวราช (สำนักงานใหญ่)", "ถนนเยาวราช แขวงสัมพันธวงศ์ เขตสัมพันธวงศ์ กรุงเทพฯ", latitude = 13.7412, longitude = 100.5083),
        ThaiBranch("b_cm", "ห้างทองทองไทย สาขาเชียงใหม่ (นิมมาน)", "ถนนนิมมานเหมินท์ ต.สุเทพ อ.เมือง เชียงใหม่", latitude = 18.7996, longitude = 98.9687),
        ThaiBranch("b_pk", "ห้างทองทองไทย สาขาภูเก็ต (เมืองเก่า)", "ถนนถลาง ต.ตลาดใหญ่ อ.เมือง ภูเก็ต", latitude = 7.8841, longitude = 98.3894),
        ThaiBranch("b_kk", "ห้างทองทองไทย สาขาขอนแก่น (เซ็นทรัล)", "ถนนศรีจันทร์ ต.ในเมือง อ.เมือง ขอนแก่น", latitude = 16.4322, longitude = 102.8256),
        ThaiBranch("b_cr", "ห้างทองทองไทย สาขาชลบุรี (บางแสน)", "ถนนลงหาดบางแสน ต.แสนสุข อ.เมือง ชลบุรี", latitude = 13.2902, longitude = 100.9161)
    )

    // Branch Pickup Orders
    private val _pickupOrders = MutableStateFlow<List<PickupOrder>>(emptyList())
    val pickupOrders: StateFlow<List<PickupOrder>> = _pickupOrders.asStateFlow()

    // Shipments
    private val _deliveries = MutableStateFlow<List<GoldDelivery>>(emptyList())
    val deliveries: StateFlow<List<GoldDelivery>> = _deliveries.asStateFlow()

    // Assays
    private val _assays = MutableStateFlow<List<AssayReport>>(emptyList())
    val assays: StateFlow<List<AssayReport>> = _assays.asStateFlow()

    // Vault Stats (Bangkok Central Vaults)
    val totalPhysicalAllocatedGoldGrams = MutableStateFlow(428510.24)
    val totalPhysicalUnallocatedGoldGrams = MutableStateFlow(124800.56)
    val isSystemReconciled = MutableStateFlow(true)
    val systemScaleUsersCount = 1248912 // 1.2M Simulated Users
    val systemScaleGoldBarsCount = 485124 // 485K Gold bars allocated

    init {
        // Build initial price history
        generateInitialPriceHistory()

        // Generate mock active metal passports for starting balance
        setupInitialMetalPassports()

        // Continuous Live Price Ticker Fluctuation Loop
        scope.launch {
            while (true) {
                delay(6000) // update prices every 6 seconds
                fluctuatePrices()
            }
        }
    }

    private fun generateInitialPriceHistory() {
        val base = _currentPrices.value
        val history = mutableListOf<LivePrices>()
        var calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -10)
        for (i in 1..10) {
            val announcementNo = (1..3).random()
            val changeVal = (-3..4).random() * 50.0 // standard thai gold adjustment step
            val item = base.copy(
                timestamp = calendar.timeInMillis,
                announcementNo = announcementNo,
                bar965Buy = base.bar965Buy + changeVal - 100.0,
                bar965Sell = base.bar965Sell + changeVal - 100.0,
                bar965Change = changeVal,
                ornament965Buy = base.ornament965Buy + changeVal - 100.0,
                ornament965Sell = base.ornament965Sell + changeVal - 100.0,
                ornament965Change = changeVal
            )
            history.add(item)
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        _priceHistory.value = history
    }

    private fun setupInitialMetalPassports() {
        // Starting 3.75 Baht in user portfolio (96.5% gold bar)
        // Let's allocate 2 Baht bar (30.488g) and 1.75 Baht in other items
        val passport1 = MetalPassport(
            serialNumber = "TH-G965-004281",
            metalType = MetalType.GOLD_965,
            productType = ProductType.BAR,
            weightBaht = 2.0,
            weightGrams = 30.488,
            purity = 96.5,
            manufacturer = "สมาคมค้าทองคำแห่งประเทศไทย",
            manufactureDate = "15 พฤษภาคม 2569",
            ownerId = "me_user_001",
            allocatedDate = "17 พฤษภาคม 2569"
        )
        val passport2 = MetalPassport(
            serialNumber = "TH-G965-004282",
            metalType = MetalType.GOLD_965,
            productType = ProductType.BAR,
            weightBaht = 1.0,
            weightGrams = 15.244,
            purity = 96.5,
            manufacturer = "สมาคมค้าทองคำแห่งประเทศไทย",
            manufactureDate = "10 มิถุนายน 2569",
            ownerId = "me_user_001",
            allocatedDate = "12 มิถุนายน 2569"
        )
        val passport3 = MetalPassport(
            serialNumber = "TH-G999-009144",
            metalType = MetalType.GOLD_9999,
            productType = ProductType.BAR,
            weightBaht = 0.6559,
            weightGrams = 10.0,
            purity = 99.99,
            manufacturer = "PAMP Suisse",
            manufactureDate = "04 มกราคม 2569",
            ownerId = "me_user_001",
            allocatedDate = "15 กุมภาพันธ์ 2569"
        )
        _allocatedBars.value = listOf(passport1, passport2, passport3)
    }

    private fun fluctuatePrices() {
        val current = _currentPrices.value
        // Thai Gold Board updates in standard 50 THB ticks (e.g. +50, -100, +150, 0)
        val changePossibilities = listOf(-100.0, -50.0, 0.0, 50.0, 100.0, 150.0)
        val change = changePossibilities.random()

        if (change != 0.0) {
            val nextBar965Buy = current.bar965Buy + change
            val nextBar965Sell = current.bar965Sell + change
            val nextOrnamentBuy = current.ornament965Buy + change
            val nextOrnamentSell = current.ornament965Sell + change

            val spotChange = (-2..2).random() * 0.50
            val usdChange = (-5..5).random() * 0.01

            val updated = current.copy(
                timestamp = System.currentTimeMillis(),
                announcementNo = current.announcementNo + 1,
                bar965Buy = nextBar965Buy,
                bar965Sell = nextBar965Sell,
                bar965Change = change,
                ornament965Buy = nextOrnamentBuy,
                ornament965Sell = nextOrnamentSell,
                ornament965Change = change,
                goldSpotUsd = current.goldSpotUsd + spotChange,
                usdToThb = current.usdToThb + usdChange
            )

            _currentPrices.value = updated

            // Append to price history, keeping max 30 items
            val history = _priceHistory.value.toMutableList()
            history.add(updated)
            if (history.size > 30) history.removeAt(0)
            _priceHistory.value = history

            // Record price change event
            recordEvent("PriceUpdated", "สมาคมค้าทองคำปรับราคารอบที่ ${updated.announcementNo} การเปลี่ยนแปลง $change บาท")

            // Scan and trigger price alerts
            checkPriceAlerts(nextBar965Sell)
        }
    }

    private fun checkPriceAlerts(currentPrice: Double) {
        val alerts = _priceAlerts.value
        val updatedAlerts = alerts.map { alert ->
            if (!alert.isTriggered) {
                val isTriggered = if (alert.triggerOnIncrease) {
                    currentPrice >= alert.targetPrice
                } else {
                    currentPrice <= alert.targetPrice
                }
                if (isTriggered) {
                    recordEvent("PriceAlertTriggered", "แจ้งเตือน: ${alert.label} (ราคาปัจจุบันคือ ฿${ThaiFormatter.formatDecimal(currentPrice)})")
                    alert.copy(isTriggered = true)
                } else {
                    alert
                }
            } else {
                alert
            }
        }
        _priceAlerts.value = updatedAlerts
    }

    fun addPriceAlert(price: Double, onIncrease: Boolean, label: String) {
        val newAlert = PriceAlert(
            targetPrice = price,
            triggerOnIncrease = onIncrease,
            label = label
        )
        _priceAlerts.update { it + newAlert }
        recordEvent("PriceAlertCreated", "สร้างการแจ้งเตือนราคาที่ ฿${ThaiFormatter.formatDecimal(price)}")
    }

    fun removePriceAlert(alertId: String) {
        _priceAlerts.update { it.filterNot { a -> a.id == alertId } }
    }

    private fun recordEvent(name: String, payload: String) {
        val newEvent = SystemEvent(name = name, payload = payload)
        _events.update { listOf(newEvent) + it } // prepends
    }

    /**
     * Executes a buying order.
     * Implements full Double-Entry Accounting ledger entries.
     */
    @Synchronized
    fun buyProduct(
        product: Product,
        inputWeightBaht: Double,
        inputWeightGrams: Double,
        totalCost: Double,
        deliveryMethod: DeliveryMethod,
        shippingAddress: String = "",
        branchId: String = ""
    ): Result<GoldOrder> {
        if (_cashBalance.value < totalCost) {
            return Result.failure(Exception("INSUFFICIENT_BALANCE"))
        }

        val eventId = UUID.randomUUID().toString()

        // 1. Deduct cash balance
        _cashBalance.update { it - totalCost }

        // 2. Add appropriate assets based on weight & metal type
        var allocatedSerial: String? = null
        val serialId = (400000..999999).random()

        when (product.metalType) {
            MetalType.GOLD_965 -> {
                _gold965BahtBalance.update { it + inputWeightBaht }
                allocatedSerial = "TH-G965-$serialId"

                // Create allocated MetalPassport if choosing VAULT SECURE
                if (deliveryMethod == DeliveryMethod.VAULT_SECURE) {
                    val passport = MetalPassport(
                        serialNumber = allocatedSerial,
                        metalType = MetalType.GOLD_965,
                        productType = product.productType,
                        weightBaht = inputWeightBaht,
                        weightGrams = inputWeightGrams,
                        purity = 96.5,
                        manufacturer = product.manufacturer,
                        manufactureDate = "05 ตุลาคม 2569",
                        ownerId = "me_user_001",
                        allocatedDate = ThaiFormatter.formatThaiDate()
                    )
                    _allocatedBars.update { it + passport }
                    totalPhysicalAllocatedGoldGrams.update { it + inputWeightGrams }
                } else {
                    totalPhysicalUnallocatedGoldGrams.update { it + inputWeightGrams }
                }
            }
            MetalType.GOLD_9999 -> {
                _gold9999GramBalance.update { it + inputWeightGrams }
                allocatedSerial = "TH-G999-$serialId"

                if (deliveryMethod == DeliveryMethod.VAULT_SECURE) {
                    val passport = MetalPassport(
                        serialNumber = allocatedSerial,
                        metalType = MetalType.GOLD_9999,
                        productType = product.productType,
                        weightBaht = inputWeightBaht,
                        weightGrams = inputWeightGrams,
                        purity = 99.99,
                        manufacturer = product.manufacturer,
                        manufactureDate = "28 กันยายน 2569",
                        ownerId = "me_user_001",
                        allocatedDate = ThaiFormatter.formatThaiDate()
                    )
                    _allocatedBars.update { it + passport }
                    totalPhysicalAllocatedGoldGrams.update { it + inputWeightGrams }
                } else {
                    totalPhysicalUnallocatedGoldGrams.update { it + inputWeightGrams }
                }
            }
            MetalType.SILVER_999 -> {
                _silverGramBalance.update { it + inputWeightGrams }
            }
        }

        // 3. Create double-entry ledger bookings:
        // Cash Account (Credit - totalCost)
        // Asset Account (Debit - productCost)
        // Fee Account (Debit - premiumFee + shippingFee)
        val creditCash = LedgerEntry(
            accountId = "ACC-CASH-USER01",
            asset = "THB",
            quantity = -totalCost,
            unit = "THB",
            value = -totalCost,
            eventId = eventId,
            reference = "ซื้อทอง ${product.name}"
        )
        val debitAsset = LedgerEntry(
            accountId = "ACC-METAL-USER01",
            asset = product.metalType.name,
            quantity = if (product.metalType == MetalType.GOLD_965) inputWeightBaht else inputWeightGrams,
            unit = if (product.metalType == MetalType.GOLD_965) "BAHT_GOLD" else "GRAM",
            value = totalCost - product.premiumFee,
            eventId = eventId,
            reference = "ซื้อทองเข้าพอร์ต ${product.name}"
        )
        val debitFee = LedgerEntry(
            accountId = "ACC-FEES-SYSTEM",
            asset = "THB",
            quantity = product.premiumFee,
            unit = "THB",
            value = product.premiumFee,
            eventId = eventId,
            reference = "ค่าพรีเมียม/กำเหน็จสำหรับคำสั่งซื้อ"
        )

        _ledgerEntries.update { it + listOf(creditCash, debitAsset, debitFee) }

        // 4. Create actual order
        val order = GoldOrder(
            productId = product.id,
            productName = product.name,
            metalType = product.metalType,
            productType = product.productType,
            weightInBaht = inputWeightBaht,
            weightInGrams = inputWeightGrams,
            unitPrice = totalCost - product.premiumFee,
            premiumFee = product.premiumFee,
            shippingFee = if (deliveryMethod == DeliveryMethod.HOME_DELIVERY) 150.0 else 0.0,
            totalAmount = totalCost,
            deliveryMethod = deliveryMethod,
            allocatedBarSerial = allocatedSerial
        )

        _orders.update { listOf(order) + it }

        // Log compliance events
        recordEvent("OrderCreated", "สร้างคำสั่งซื้อทองหมายเลข ${order.id}")
        recordEvent("GoldPurchased", "ลูกค้าซื้อทองสำเร็จ: ${product.name} ยอดสุทธิ ฿${ThaiFormatter.formatDecimal(totalCost)}")

        if (deliveryMethod == DeliveryMethod.VAULT_SECURE) {
            recordEvent("GoldAllocated", "จัดสรรทองจริงหมายเลข $allocatedSerial เข้า Vault TH-001")
            recordEvent("VaultDepositCompleted", "ทองคำแท่งถูกบันทึกในบัญชีฝากเก็บห้องนิรภัยเรียบร้อย")
        } else if (deliveryMethod == DeliveryMethod.STORE_PICKUP) {
            val branch = branches.firstOrNull { it.id == branchId } ?: branches[0]
            val pickup = PickupOrder(
                branchName = branch.name,
                productName = product.name,
                weightText = if (product.metalType == MetalType.GOLD_965) "${inputWeightBaht} บาท" else "${inputWeightGrams} กรัม",
                pickupCode = "TX-${(1000..9999).random()}",
                status = PickupStatus.READY_FOR_PICKUP
            )
            _pickupOrders.update { listOf(pickup) + it }
            recordEvent("BranchPickupCreated", "กรุณานำรหัส ${pickup.pickupCode} ไปรับที่ ${branch.name}")
        } else if (deliveryMethod == DeliveryMethod.HOME_DELIVERY) {
            val delivery = GoldDelivery(
                trackingNo = "TH-GOLD-${(100000..999999).random()}",
                productName = product.name,
                address = shippingAddress,
                status = DeliveryStatus.PREPARING
            )
            _deliveries.update { listOf(delivery) + it }
            recordEvent("DeliveryCreated", "สร้างข้อมูลจัดส่งสำเร็จ หมายเลขพัสดุ ${delivery.trackingNo}")
        }

        // Perform instant ledger audit to verify balance matching
        reconcileSystemLedger()

        return Result.success(order)
    }

    /**
     * Executes selling of assets back to the store.
     * Fully updates double-entry ledgers and checks compliance rules.
     */
    @Synchronized
    fun sellProduct(
        metalType: MetalType,
        productType: ProductType,
        weightInBaht: Double,
        weightInGrams: Double,
        sellRatePerUnit: Double,
        associatedPassportId: String? = null
    ): Result<Double> {
        // Validate asset availability
        val isGold965 = metalType == MetalType.GOLD_965
        val isGold9999 = metalType == MetalType.GOLD_9999

        if (isGold965 && _gold965BahtBalance.value < weightInBaht) {
            return Result.failure(Exception("INSUFFICIENT_BALANCE"))
        }
        if (isGold9999 && _gold9999GramBalance.value < weightInGrams) {
            return Result.failure(Exception("INSUFFICIENT_BALANCE"))
        }
        if (metalType == MetalType.SILVER_999 && _silverGramBalance.value < weightInGrams) {
            return Result.failure(Exception("INSUFFICIENT_BALANCE"))
        }

        val eventId = UUID.randomUUID().toString()
        val cashPayout = if (isGold965) {
            weightInBaht * sellRatePerUnit
        } else {
            weightInGrams * sellRatePerUnit
        }

        // 1. Deduct Held Metals
        if (isGold965) {
            _gold965BahtBalance.update { it - weightInBaht }
            if (associatedPassportId != null) {
                _allocatedBars.update { it.filterNot { bar -> bar.id == associatedPassportId } }
                totalPhysicalAllocatedGoldGrams.update { it - weightInGrams }
            } else {
                totalPhysicalUnallocatedGoldGrams.update { it - weightInGrams }
            }
        } else if (isGold9999) {
            _gold9999GramBalance.update { it - weightInGrams }
            if (associatedPassportId != null) {
                _allocatedBars.update { it.filterNot { bar -> bar.id == associatedPassportId } }
                totalPhysicalAllocatedGoldGrams.update { it - weightInGrams }
            } else {
                totalPhysicalUnallocatedGoldGrams.update { it - weightInGrams }
            }
        } else {
            _silverGramBalance.update { it - weightInGrams }
        }

        // 2. Add cash balance
        _cashBalance.update { it + cashPayout }

        // 3. Ledger Bookings
        // Cash Account (Debit + cashPayout)
        // Asset Account (Credit - quantity sold)
        val debitCash = LedgerEntry(
            accountId = "ACC-CASH-USER01",
            asset = "THB",
            quantity = cashPayout,
            unit = "THB",
            value = cashPayout,
            eventId = eventId,
            reference = "ขายคืนทองคำ ${if (isGold965) "$weightInBaht บาท" else "$weightInGrams กรัม"}"
        )
        val creditAsset = LedgerEntry(
            accountId = "ACC-METAL-USER01",
            asset = metalType.name,
            quantity = if (isGold965) -weightInBaht else -weightInGrams,
            unit = if (isGold965) "BAHT_GOLD" else "GRAM",
            value = -cashPayout,
            eventId = eventId,
            reference = "ขายคืนทองออกจากพอร์ต"
        )

        _ledgerEntries.update { it + listOf(debitCash, creditAsset) }

        // Create virtual sell trade
        val order = GoldOrder(
            productId = "sell_tx",
            productName = "ขายคืนทอง ${if (isGold965) "96.5%" else "99.99%"}",
            metalType = metalType,
            productType = productType,
            weightInBaht = weightInBaht,
            weightInGrams = weightInGrams,
            unitPrice = cashPayout,
            premiumFee = 0.0,
            shippingFee = 0.0,
            totalAmount = -cashPayout, // negative demonstrates sell outflows
            deliveryMethod = DeliveryMethod.VAULT_SECURE,
            status = OrderStatus.COMPLETED
        )
        _orders.update { listOf(order) + it }

        recordEvent("GoldSold", "ลูกค้าขายทองคำคืนสำเร็จ: ยอดรับสุทธิ ฿${ThaiFormatter.formatDecimal(cashPayout)}")
        recordEvent("SettlementCompleted", "ระบบทำการ Settlement และโอนเงินเข้าบัญชีเรียบร้อย")

        reconcileSystemLedger()

        return Result.success(cashPayout)
    }

    /**
     * Physical Metal vs Vault Inventory vs Ledger Audit Check
     * Validates that allocated customer gold sum strictly matches Vault capacity
     */
    fun reconcileSystemLedger(): Boolean {
        // Simple audit rule check
        // Check if Sum of Gold Passport weights matches total allocated physical inventory
        val passportSum = _allocatedBars.value.sumOf { it.weightGrams }
        val difference = Math.abs(totalPhysicalAllocatedGoldGrams.value - (428464.508 + passportSum)) // base plus user passport additions
        
        // Ensure no leakage
        val isConsistent = difference < 0.001
        isSystemReconciled.value = isConsistent
        
        if (!isConsistent) {
            recordEvent("ReconciliationFailure", "RECONCILIATION EXCEPTION: ความคลาดเคลื่อนทองคำระหว่างสมุดบัญชีกับคลังสินค้านิรภัย!")
        } else {
            recordEvent("ReconciliationCompleted", "ตรวจสอบระบบเรียบร้อย (Reconciliation Success): ยอดจองพอร์ตสมบูรณ์ตรงกับคลังทองคำกายภาพ")
        }
        return isConsistent
    }

    /**
     * Submits an old piece of jewelry to the digital assay inspection.
     * Evaluates purity, fine weight, and produces standard report.
     */
    fun submitAssayEvaluation(
        description: String,
        weight: Double,
        method: String
    ): AssayReport {
        val randomPurityPercent = when (method) {
            "XRF" -> listOf(96.5, 96.62, 90.5, 80.2, 99.99).random()
            "Specific Gravity" -> listOf(96.3, 96.5, 90.0, 78.5).random()
            else -> 96.5
        }

        val baseGoldRatePerGram = _currentPrices.value.bar965Buy / ThaiFormatter.GRAMS_PER_BAHT_BAR
        val rawValue = weight * (randomPurityPercent / 100.0) * baseGoldRatePerGram
        val feeDeduction = rawValue * 0.05 // 5% assay manual check & processing margin
        val finalEstimate = rawValue - feeDeduction

        val report = AssayReport(
            itemDescription = description,
            weightGrams = weight,
            testedPurityPercent = randomPurityPercent,
            testMethod = when (method) {
                "XRF" -> "XRF (X-ray Fluorescence Spectrometry)"
                "Specific Gravity" -> "Specific Gravity Hydrostatic Method"
                else -> "Fire Assay Pyrometry Standard"
            },
            estimatedValue = finalEstimate,
            testConfidence = if (method == "XRF") 99.98 else 99.50
        )

        _assays.update { listOf(report) + it }
        recordEvent("AssayCreated", "สร้างรายงานตรวจสอบประเมินทองคำ ${report.itemDescription} เสร็จสิ้น")
        return report
    }

    /**
     * Simulated admin action: updates and moves shipment package.
     */
    fun progressShipment(deliveryId: String) {
        _deliveries.update { list ->
            list.map { delivery ->
                if (delivery.id == deliveryId) {
                    val nextStatus = when (delivery.status) {
                        DeliveryStatus.ORDERED -> DeliveryStatus.PREPARING
                        DeliveryStatus.PREPARING -> DeliveryStatus.QUALITY_CHECK
                        DeliveryStatus.QUALITY_CHECK -> DeliveryStatus.PACKED
                        DeliveryStatus.PACKED -> DeliveryStatus.SHIPPED
                        DeliveryStatus.SHIPPED -> DeliveryStatus.IN_TRANSIT
                        DeliveryStatus.IN_TRANSIT -> DeliveryStatus.DELIVERED
                        DeliveryStatus.DELIVERED -> DeliveryStatus.DELIVERED
                    }
                    recordEvent("DeliveryUpdated", "พัสดุจัดส่ง ${delivery.trackingNo} เปลี่ยนสถานะเป็น ${nextStatus.name}")
                    delivery.copy(status = nextStatus, updatedAt = System.currentTimeMillis())
                } else {
                    delivery
                }
            }
        }
    }

    fun addMockFunds(amount: Double) {
        _cashBalance.update { it + amount }
        recordEvent("FundsDeposited", "เติมเงินทดสอบเข้าบัญชีสำเร็จ จำนวน ฿${ThaiFormatter.formatDecimal(amount)}")
    }
}
