package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ThaiGoldMockEngine
import com.example.model.DeliveryStatus
import com.example.model.PickupStatus
import com.example.ui.theme.*
import com.example.util.ThaiFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cashBalance by ThaiGoldMockEngine.cashBalance.collectAsStateWithLifecycle()
    val pickupOrders by ThaiGoldMockEngine.pickupOrders.collectAsStateWithLifecycle()
    val deliveries by ThaiGoldMockEngine.deliveries.collectAsStateWithLifecycle()
    val ledgerEntries by ThaiGoldMockEngine.ledgerEntries.collectAsStateWithLifecycle()
    val systemEvents by ThaiGoldMockEngine.events.collectAsStateWithLifecycle()

    var activeSubTab by remember { mutableStateOf("FUNDS") } // "FUNDS", "PICKUPS", "DELIVERIES", "LEDGER", "EVENTS"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Account Page Header
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ศูนย์จัดการและตรวจสอบระบบ",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepBurgundy
                        )
                    )
                    Text(
                        text = "จัดการเงินทดสอบ ตรวจสอบรายการสาขา และตรวจสอบ Ledger โปร่งใส",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin",
                    tint = PremiumGold,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        // Horizontal Segment Toggles for Audit Sections
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SoftChampagne.copy(alpha = 0.5f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "FUNDS" to "ฝากเงิน",
                    "PICKUPS" to "รับสาขา",
                    "DELIVERIES" to "จัดส่ง",
                    "LEDGER" to "Ledger",
                    "EVENTS" to "Event Log"
                ).forEach { (tab, label) ->
                    val isSelected = activeSubTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DeepBurgundy else Color.Transparent)
                            .clickable { activeSubTab = tab }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else DeepBurgundy,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Tab Content 1: Top-up Funds Simulation
        if (activeSubTab == "FUNDS") {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("เติมเงินทดลองเข้าระบบ", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DeepBurgundy)
                        Text("บัญชีของคุณมีเงินสำหรับใช้จำลองการออมทองและสั่งซื้อสินค้าได้ทันที", fontSize = 12.sp, color = Color.Gray)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SoftChampagne)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ยอดเงินสดของคุณปัจจุบัน", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("฿${ThaiFormatter.formatDecimal(cashBalance)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DeepBurgundy)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(10000.0, 50000.0, 100000.0).forEach { amount ->
                                Button(
                                    onClick = {
                                        ThaiGoldMockEngine.addMockFunds(amount)
                                        Toast.makeText(context, "ฝากเงินจำลองเรียบร้อย +฿${ThaiFormatter.formatDecimal(amount)}", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                                    modifier = Modifier.weight(1f).testTag("topup_button_${amount.toInt()}"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("+${amount.toInt() / 1000}k", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Tab Content 2: Branch Pickups QR Verification
        if (activeSubTab == "PICKUPS") {
            if (pickupOrders.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SoftChampagne.copy(alpha = 0.2f))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("ไม่มีรายการจองรับทองที่สาขา\nเมื่อคุณสั่งซื้อสินค้าแบบ 'รับที่สาขา' รหัส QR รับทองจะปรากฏที่นี่", textAlign = TextAlign.Center, color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(pickupOrders) { order ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = order.branchName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Badge(
                                    containerColor = if (order.status == PickupStatus.READY_FOR_PICKUP) ThaiGreen.copy(alpha = 0.1f) else Color.LightGray
                                ) {
                                    Text(
                                        text = if (order.status == PickupStatus.READY_FOR_PICKUP) "พร้อมรับทองจริง" else "ยืนยันแล้ว",
                                        color = if (order.status == PickupStatus.READY_FOR_PICKUP) ThaiGreen else Charcoal,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text("สินค้าจอง: ${order.productName} (${order.weightText})", fontSize = 12.sp, color = Charcoal)

                            Divider(color = SoftChampagne)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("แสดงบัตรประจำตัวทองคำและรหัสรับของแก่ช่างทองสาขา", fontSize = 10.sp, color = Color.Gray)
                                    Text("รหัสเบิกทอง: ${order.pickupCode}", fontWeight = FontWeight.Bold, color = DeepBurgundy, fontSize = 14.sp)
                                }

                                // Pickup QR Mock
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = "QR Code",
                                    tint = Charcoal,
                                    modifier = Modifier.size(48.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tab Content 3: Home Deliveries Tracker & Transit Simulator
        if (activeSubTab == "DELIVERIES") {
            if (deliveries.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SoftChampagne.copy(alpha = 0.2f))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("ไม่มีประวัติจัดส่งแบบพัสดุ\nเมื่อคุณซื้อและเลือก 'จัดส่งถึงบ้าน' รายการจัดส่งประกันภัยจะอัปเดตที่นี่", textAlign = TextAlign.Center, color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(deliveries) { delivery ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("เลขพัสดุรับประกัน: ${delivery.trackingNo}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = when (delivery.status) {
                                        DeliveryStatus.ORDERED -> "สั่งซื้อเสร็จสิ้น"
                                        DeliveryStatus.PREPARING -> "เตรียมทองแท่ง"
                                        DeliveryStatus.QUALITY_CHECK -> "ตรวจสัญญาลักษณ์ความบริสุทธิ์"
                                        DeliveryStatus.PACKED -> "แพ็คกล่องพัสดุนิรภัย"
                                        DeliveryStatus.SHIPPED -> "นำจ่ายให้บริษัทขนส่ง"
                                        DeliveryStatus.IN_TRANSIT -> "อยู่ระหว่างนำจ่าย"
                                        DeliveryStatus.DELIVERED -> "ลงลายมือชื่อรับมอบสำเร็จ"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    color = DeepBurgundy,
                                    fontSize = 12.sp
                                )
                            }

                            Text("พัสดุภายใน: ${delivery.productName}", fontSize = 12.sp)
                            Text("ที่อยู่ผู้รับ: ${delivery.address}", fontSize = 11.sp, color = Color.Gray)

                            Divider(color = SoftChampagne)

                            // Simulated Transit Progress Trigger
                            Button(
                                onClick = {
                                    ThaiGoldMockEngine.progressShipment(delivery.id)
                                    Toast.makeText(context, "อัปเดตขั้นตอนจัดส่งพัสดุจำลองเรียบร้อย!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SoftChampagne, contentColor = DeepBurgundy),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("simulate_transit_button_${delivery.trackingNo}")
                            ) {
                                Icon(Icons.Default.LocalShipping, contentDescription = "Deliver", tint = DeepBurgundy)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("จำลองอัปเดตขั้นตอนการขนส่ง (Admin Tool)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Tab Content 4: Immutable Double-Entry Ledger Book Explorer
        if (activeSubTab == "LEDGER") {
            item {
                Text(
                    text = "AUTHORITATIVE DOUBLE-ENTRY LEDGER",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            if (ledgerEntries.isEmpty()) {
                item {
                    Text("ไม่มีรายการ Ledger ในพอร์ทดิจิทัลเริ่มต้น", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
            } else {
                items(ledgerEntries.reversed()) { entry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.reference, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("บัญชีอ้างอิง: ${entry.accountId}", fontSize = 10.sp, color = Color.Gray)
                                Text("รหัสตรวจสอบ: ${entry.entryId.take(8).uppercase()}", fontSize = 9.sp, color = Color.LightGray)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                val isPositive = entry.quantity >= 0
                                Text(
                                    text = "${if (isPositive) "+" else ""}${ThaiFormatter.formatDecimal(entry.quantity)} ${entry.unit}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPositive) ThaiGreen else ThaiRed,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "มูลค่า: ${ThaiFormatter.formatCurrency(Math.abs(entry.value))}",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tab Content 5: Real-time Replay Event Store View
        if (activeSubTab == "EVENTS") {
            item {
                Text(
                    text = "REPLAYABLE BLOCKCHAIN-STYLE EVENT LOG",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            if (systemEvents.isEmpty()) {
                item {
                    Text("ไม่มีประวัติเหตุการณ์เกิดขึ้น", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
            } else {
                items(systemEvents) { event ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Charcoal)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = event.name,
                                    fontWeight = FontWeight.Bold,
                                    color = PremiumGold,
                                    fontSize = 11.sp
                                )
                                val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                                Text(
                                    text = sdf.format(event.timestamp),
                                    color = Color.LightGray,
                                    fontSize = 9.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = event.payload,
                                color = Color.White,
                                fontSize = 11.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(48.dp)) }
    }
}
