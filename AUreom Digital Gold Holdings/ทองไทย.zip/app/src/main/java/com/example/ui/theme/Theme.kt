package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = PremiumGold,
  secondary = BrushedGold,
  tertiary = DeepBurgundy,
  background = Charcoal,
  surface = Color(0xFF2C2424),
  onBackground = WarmIvory,
  onSurface = WarmIvory,
  onPrimary = Charcoal
)

private val LightColorScheme = lightColorScheme(
  primary = DeepBurgundy,
  secondary = BrushedGold,
  tertiary = PremiumGold,
  background = WarmIvory,
  surface = Color.White,
  onBackground = Charcoal,
  onSurface = Charcoal,
  onPrimary = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color to lock in the luxury brand identity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
