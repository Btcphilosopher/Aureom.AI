package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ThaiGoldMockEngine
import com.example.model.MetalPassport
import com.example.model.MetalType
import com.example.ui.theme.*
import com.example.util.ThaiFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfolioScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prices by ThaiGoldMockEngine.currentPrices.collectAsStateWithLifecycle()
    val cashBalance by ThaiGoldMockEngine.cashBalance.collectAsStateWithLifecycle()
    val gold965Baht by ThaiGoldMockEngine.gold965BahtBalance.collectAsStateWithLifecycle()
    val gold9999g by ThaiGoldMockEngine.gold9999GramBalance.collectAsStateWithLifecycle()
    val silverGrams by ThaiGoldMockEngine.silverGramBalance.collectAsStateWithLifecycle()
    val allocatedBars by ThaiGoldMockEngine.allocatedBars.collectAsStateWithLifecycle()
    val isReconciled by ThaiGoldMockEngine.isSystemReconciled.collectAsStateWithLifecycle()

    var selectedPassportForDetails by remember { mutableStateOf<MetalPassport?>(null) }
    var isAuditingByClient by remember { mutableStateOf(false) }

    // Calculations
    val gold965Value = gold965Baht * prices.bar965Buy
    val gold9999Value = gold9999g * prices.gold9999BuyPerGram
    val silverValue = silverGrams * prices.silverBuyPerGram
    val totalAssetValue = cashBalance + gold965Value + gold9999Value + silverValue

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Portfolio Header
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ห้องนิรภัยดิจิทัลของคุณ",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepBurgundy
                        )
                    )
                    Text(
                        text = "ทองคำจัดสรรแท้ 100% ตรวจสอบความถูกต้องกายภาพได้",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Shield",
                    tint = PremiumGold,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Vault holdings breakdown card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Charcoal)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("รวมมูลค่าทรัพย์สินออมทองทั้งหมด", color = SoftChampagne, fontSize = 12.sp)
                    Text(
                        text = "฿${ThaiFormatter.formatDecimal(totalAssetValue)}",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = PremiumGold,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                    // Allocated asset items list
                    HoldingRow(label = "ทองคำแท่ง 96.5% อ้างอิงสมาคม", amount = "${gold965Baht} บาท", value = "฿${ThaiFormatter.formatDecimal(gold965Value)}")
                    HoldingRow(label = "ทองคำสวิส 99.99% เกรดการลงทุน", amount = "${ThaiFormatter.formatDecimal(gold9999g)} กรัม", value = "฿${ThaiFormatter.formatDecimal(gold9999Value)}")
                    HoldingRow(label = "เงินแท่งบริสุทธิ์ 99.9% สะสม", amount = "${ThaiFormatter.formatDecimal(silverGrams / 1000.0)} กก.", value = "฿${ThaiFormatter.formatDecimal(silverValue)}")
                    HoldingRow(label = "เงินสดฝากถอนทดสอบระบบ", amount = "THB", value = "฿${ThaiFormatter.formatDecimal(cashBalance)}")
                }
            }
        }

        // Live Audit Checker Trigger Button
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isReconciled) ThaiGreen.copy(alpha = 0.5f) else ThaiRed.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(containerColor = if (isReconciled) ThaiGreen.copy(alpha = 0.05f) else ThaiRed.copy(alpha = 0.05f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isReconciled) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = "Status",
                            tint = if (isReconciled) ThaiGreen else ThaiRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isReconciled) "ตรวจสอบบัญชีทองคำตรงคลังกายภาพ" else "ตรวจพบบัญชีทองคลาดเคลื่อนคลังกายภาพ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isReconciled) ThaiGreen else ThaiRed
                            )
                            Text(
                                text = "ระบบสแกนสมาธิสมุดบัญชีทองคำ TH-VAULT-CHECK01",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Button(
                        onClick = {
                            isAuditingByClient = true
                            ThaiGoldMockEngine.reconcileSystemLedger()
                            Toast.makeText(context, "สแกนสมุดบัญชีและตรวจจำนวนคลังเรียบร้อย!", Toast.LENGTH_SHORT).show()
                            isAuditingByClient = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("ledger_reconcile_audit_button")
                    ) {
                        Text("เริ่มตรวจสอบ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Physical Allocated items: Metal Passports list
        item {
            Text(
                text = "ทองคำแท่งแบบระบุชิ้น (Allocated Gold)",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = DeepBurgundy
                )
            )
        }

        if (allocatedBars.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftChampagne.copy(alpha = 0.2f))
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ไม่มีทองคำจัดสรรในห้องนิรภัยดิจิทัล\nเริ่มซื้อทองคำแท่งและเลือกฝากเก็บตู้นิรภัยเพื่อรับใบรับรองสลักสิทธิ์", textAlign = TextAlign.Center, color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(allocatedBars) { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPassportForDetails = bar }
                        .testTag("allocated_bar_card_${bar.serialNumber}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Brush.linearGradient(listOf(PremiumGold, BrushedGold))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = "Premium Gold", tint = DeepBurgundy, modifier = Modifier.size(20.dp))
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = bar.serialNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "น้ำหนัก: ${if (bar.metalType == MetalType.GOLD_965) "${bar.weightBaht} บาท" else "${bar.weightGrams} กรัม"}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "ผู้ผลิต: ${bar.manufacturer}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ดูใบรับรอง",
                                color = DeepBurgundy,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.ChevronRight, contentDescription = "Arrow", tint = DeepBurgundy, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(32.dp)) }
    }

    // Metal Passport Certificate Detail Sheet
    if (selectedPassportForDetails != null) {
        val bar = selectedPassportForDetails!!

        AlertDialog(
            onDismissRequest = { selectedPassportForDetails = null },
            confirmButton = {
                Button(
                    onClick = { selectedPassportForDetails = null },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy)
                ) {
                    Text("ตกลง / ปิดหน้านี้")
                }
            },
            title = {
                Text(
                    text = "ใบรับรองทองคำจัดสรรดิจิทัล (Metal Passport)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = DeepBurgundy,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Simulated QR verification drawn with Canvas grid
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Canvas(modifier = Modifier.size(90.dp).border(1.dp, Color.LightGray)) {
                                val sizePx = size.width
                                val gridSize = 9
                                val cellPx = sizePx / gridSize

                                for (row in 0 until gridSize) {
                                    for (col in 0 until gridSize) {
                                        // Draw simulated QR matrix squares
                                        val isBlock = (row in 0..2 && col in 0..2) ||
                                                (row in 0..2 && col in 6..8) ||
                                                (row in 6..8 && col in 0..2) ||
                                                ((row + col) % 3 == 0 && (row > 2 && col > 2))

                                        if (isBlock) {
                                            drawRect(
                                                color = Charcoal,
                                                topLeft = Offset(col * cellPx, row * cellPx),
                                                size = Size(cellPx, cellPx)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "รหัสตรวจสิทธิสิทธิ์: ${bar.id.take(12).uppercase()}",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Divider(color = Color.LightGray.copy(alpha = 0.5f))

                    CertificateDetailRow(label = "หมายเลขซีเรียลทองคำ:", value = bar.serialNumber, isBold = true)
                    CertificateDetailRow(label = "ความบริสุทธิ์ทองคำแท้:", value = "${bar.purity}% (มาตรฐานทอง)")
                    CertificateDetailRow(label = "น้ำหนักทองคำแท้:", value = "${bar.weightBaht} บาท (~${bar.weightGrams} กรัม)")
                    CertificateDetailRow(label = "แหล่งผลิตทองอ้างอิง:", value = bar.manufacturer)
                    CertificateDetailRow(label = "วันที่ช่างทองไทยผลิตสำเร็จ:", value = bar.manufactureDate)
                    CertificateDetailRow(label = "วิธีการตรวจความสมบูรณ์:", value = bar.assayMethod)
                    CertificateDetailRow(label = "ระดับความมั่นใจแล็บตรวจ:", value = "${bar.assayConfidence}%")
                    CertificateDetailRow(label = "สถานที่จัดเก็บตู้นิรภัย:", value = bar.vaultLocation)
                    CertificateDetailRow(label = "ผู้ถือกรรมสิทธิ์ถือครอง:", value = "คุณโสมสิริ (บัญชีทดสอบ)")
                    CertificateDetailRow(label = "วันที่จัดสรรเข้าระบบ:", value = bar.allocatedDate)
                    CertificateDetailRow(label = "สถานะการตรวจสอบบัญชีล่าสุด:", value = bar.auditStatus, valueColor = ThaiGreen)
                }
            }
        )
    }
}

@Composable
fun HoldingRow(label: String, amount: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = label, fontSize = 12.sp, color = Color.LightGray)
            Text(text = amount, fontSize = 11.sp, color = Color.Gray)
        }
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PremiumGold)
    }
}

@Composable
fun CertificateDetailRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Charcoal
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = Color.Gray)
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = valueColor,
            textAlign = TextAlign.End
        )
    }
}

@Composable
fun BorderStroke(width: androidx.compose.ui.unit.Dp, color: Color): androidx.compose.foundation.BorderStroke {
    return androidx.compose.foundation.BorderStroke(width, color)
}
