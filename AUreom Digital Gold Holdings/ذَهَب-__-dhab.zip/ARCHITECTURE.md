# ذَهَب // DHAB
### منصة الذهب والفضة العربية للتداول والتجارة والخزائن والتسوية
**Arabic-First Digital Precious Metals Market & Clearing Infrastructure**

---

## 1. ARCHITECTURE OVERVIEW

DHAB is designed from first principles as an API-first, RTL-native precious metals trading, merchant, bullion, custody, vault, and settlement clearing platform tailored specifically for the GCC (Riyadh, Dubai, Doha, Kuwait, Muscat, Manama) and broader MENA markets.

The application strictly separates **physical metal ownership (allocated inventory)** from **financial market exposure**, ensuring that physical bars are treated as individually serialized, unique physical assets held in secure regional custody warehouses, while trading actions execute via a deterministic double-entry accounting ledger.

```
                  +-----------------------------------+
                  |        بوابة التداول والعملاء       |
                  |     DHAB RTL Jetpack Compose      |
                  +-----------------+-----------------+
                                    |
                    [API Calls / WebSockets / Command Bar]
                                    v
                  +-----------------+-----------------+
                  |       مكتب الخدمات المالية        |
                  |     DhabService (Core State)      |
                  +--------+-----------------+--------+
                           |                 |
                           v                 v
           +---------------+-------+ +-------+---------------+
           |     دفتر الأستاذ النقدي   | |    دفتر المعادن العيني    |
           | Double-Entry Cash Ledger| | Double-Entry Metal Ledger|
           |         (SAR)         | |       (Grams XAU)     |
           +-----------------------+ +-----------------------+
                                    |
                                    v
                  +-----------------+-----------------+
                  |      الخزينة والتوأم الرقمي       |
                  |   Vault Digital Twin Custody      |
                  +-----------------+-----------------+
                                    |
                    [Allocated Serialized Bar Inventory]
                                    v
                     - SAU-AU-00001842 (999.9 24K)
                     - SAU-AG-00003021 (999.0 Silver)
```

---

## 2. RTL-FIRST ARABIC UI & NAVIGATION (`RTL_ARCHITECTURE.md`)

Unlike Western platforms fitted with an Arabic skin, DHAB is built with **Arabic information architecture** at its core:
*   **Bidirectional Support**: Mixed language strings (such as `XAU/SAR` or `RFQ-9042`) use Unicode bidi-isolation tags to prevent reading layout distortions.
*   **Dynamic Mirroring**: Bottom navigation bar icons, sliders, input forms, and level-2 depth imbalance indicators automatically flip alignments based on the selected language state (`LocalLayoutDirection provides LayoutDirection.Rtl`).
*   **High-End Typography**: Styles rely on clean Material 3 font scaling (`sp`) matching Noto Sans Arabic and IBM Plex Sans Arabic weighting for an authoritative, premium financial feeling instead of stereotyped calligraphy.

---

## 3. PRECIOUS METALS & PURITY ENGINE (`METAL_MODEL.md`)

The purity calculator operates with strict deterministic precision:
*   **Conversion Metrics**:
    *   $1 \text{ Troy Ounce (oz)} = 31.1034768 \text{ Grams (g)}$
    *   $1 \text{ Tola} = 11.6638 \text{ Grams (g)}$
    *   $1 \text{ Mithqal} = 4.25 \text{ Grams (g)}$
*   **Karat Breakdown**:
    *   **24K** = $99.99\%$ purity factor.
    *   **22K** = $91.67\%$ purity factor.
    *   **21K** = $87.50\%$ purity factor.
    *   **18K** = $75.00\%$ purity factor.
*   **Mathematical Model**:
    $$\text{Fine Metal Weight} = \text{Gross Weight} \times \text{Purity Factor}$$
    $$\text{Metal Value (SAR)} = \text{Fine Metal Weight} \times \text{Spot Price per Gram}$$

---

## 4. VAULT DIGITAL TWIN & CUSTODY (`VAULT.md`)

Each bullion bar exists as an independent, uniquely serialized object rather than a generic credit balance:
*   **State Parameters**: Bar ID (`SAU-AU-00001842`), Serial Number, Gross Weight, Fine Weight, Purity, Refiner, Custodian, and status (`متاح`, `مخصص`, `محجوز`, `قيد النقل`, `تم التسليم`).
*   **Book-entry transfers (نقل الملكية بالقيد الدفتري)**: When client A sells allocated gold to client B, the physical bar remains stationary in the secure regional locker (e.g. `خزينة الرياض 02`), and only the electronic twin ownership ledger changes, appending to an immutable audit trail.

---

## 5. DOUBLE-ENTRY ACCOUNTING LEDGER (`LEDGER.md`)

Every transaction strictly reconciles across independent general ledgers to preserve absolute accounting invariants:
*   **Cash Ledger (دفتر النقد)**: Tracks liquid fiat currencies (SAR, AED, QAR, USD) using a debit-credit double-entry ledger.
*   **Metal Ledger (دفتر المعادن)**: Separately tracks physical precious metals (XAU, XAG) in grams.
*   **Reconciliation Invariant**:
    $$\sum \text{Cash Debits} = \sum \text{Cash Credits}$$
    $$\sum \text{Metal Debits} = \sum \text{Metal Credits}$$

---

## 6. SAUDI ZAKAT & ZATCA TAX ADAPTER (`ZAKAT.md` / `TAX.md`)

*   **Zakat Calculator (حاسبة الزكاة)**: Built under Saudi ZATCA *Zakaty* guidelines. If the portfolio assets (Gold weight $\ge 85\text{g}$ of 24K equivalent, or Silver $\ge 595\text{g}$) meet the Nisab, a $2.5\%$ zakat estimation is computed on the total zakat base.
*   **Tax Engine (الامتثال الضريبي)**: Strictly distinguishes investment metals from retail items.
    *   **Investment Bullion (99%+ purity)**: Zero-rated VAT under Saudi executive regulations.
    *   **Jewellery / المشغولات**: Standard $15\%$ VAT applied to both the metal base and the making fee (المصنعية).
*   **Electronic Invoicing (الفاتورة الإلكترونية)**: Generates ZATCA XML-structured invoices including Seller Name, Buyer Name, Saudi VAT Registration numbers, breakdown of metal value, fabrication making fees, tax rates, and a secure Base64 cryptographic QR payload.

---

## 7. RISK & HEDGING ENGINE (`RISK.md`)

*   **Value-at-Risk (VaR)**: Real-time Daily $95\%$ VaR is calculated using covariance matrices of GCC currency fluctuations paired with global gold and silver daily volatility models.
*   **Hedging Simulator**: Calculates net exposure and automatically suggests hedging futures (AU-F1, AU-F2) to retail merchants to mitigate physical inventory exposure risks.

---

## 8. ذَهَب AI ASSISTANT & COMMAND BAR (`SIMULATION.md`)

*   **Gemini 3.5 Integration**: Direct REST API connection to `gemini-3.5-flash` model. Uses a secure system instruction to enforce Riyadh/Dubai private banking tone and financial accuracy.
*   **Arabic Command Engine**: Parses plain text commands (such as "شراء 100 غرام ذهب" or "محفظتي") and seamlessly converts them into structured OTC execution requests inside the terminal repository.
*   **Synthetics Warning**: All prices, counterparties, and transactions are synthetic simulations, preserving maximum safety for demonstrations while matching real integration architectures.
