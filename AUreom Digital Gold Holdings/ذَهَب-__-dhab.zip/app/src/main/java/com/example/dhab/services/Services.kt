package com.example.dhab.services

import android.os.SystemClock
import com.example.dhab.models.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.absoluteValue
import kotlin.math.roundToInt
import kotlin.random.Random

object DhabService {
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)

    // Fictional entity names
    val SELLER_ENTITY = "شركة الرياض للمعادن الثمينة"
    val SELLER_TAX_ID = "300123456700003"

    // -------------------------------------------------------------
    // Weights & Purity Configuration
    // -------------------------------------------------------------
    const val GRAM_TO_TROY_OZ = 0.0321507466
    const val TROY_OZ_TO_GRAM = 31.1034768
    const val GRAM_TO_KG = 0.001
    const val TOLA_TO_GRAM = 11.6638
    const val MITHQAL_TO_GRAM = 4.25

    fun getKaratPurity(karat: String): Double {
        return when (karat.uppercase()) {
            "24K", "عـيـار 24" -> 0.9999
            "22K", "عـيـار 22" -> 0.9167
            "21K", "عـيـار 21" -> 0.8750
            "18K", "عـيـار 18" -> 0.7500
            "14K", "عـيـار 14" -> 0.5833
            else -> 1.0
        }
    }

    // -------------------------------------------------------------
    // Core Market Prices & Synthetic Live Ticker
    // -------------------------------------------------------------
    // Canonical XAU and XAG base in USD per troy ounce
    private var baseGoldUsd = 2652.40
    private var baseSilverUsd = 31.85

    // FX rates relative to USD (1 USD = X Currency)
    val fxRates = mapOf(
        "USD" to 1.0,
        "SAR" to 3.7505,
        "AED" to 3.6725,
        "QAR" to 3.6415,
        "KWD" to 0.3075,
        "BHD" to 0.3760,
        "OMR" to 0.3845,
        "EUR" to 0.9420,
        "GBP" to 0.7850
    )

    // Current price flows
    private val _goldPriceUsd = MutableStateFlow(baseGoldUsd)
    val goldPriceUsd: StateFlow<Double> = _goldPriceUsd.asStateFlow()

    private val _silverPriceUsd = MutableStateFlow(baseSilverUsd)
    val silverPriceUsd: StateFlow<Double> = _silverPriceUsd.asStateFlow()

    // Interactive order lists (Level-2 Order Book)
    private val _orderBookXau = MutableStateFlow<OrderBook?>(null)
    val orderBookXau: StateFlow<OrderBook?> = _orderBookXau.asStateFlow()

    private val _orderBookXag = MutableStateFlow<OrderBook?>(null)
    val orderBookXag: StateFlow<OrderBook?> = _orderBookXag.asStateFlow()

    // Ticker log
    private val _marketLogs = MutableStateFlow<List<String>>(listOf("بدء تشغيل محرك التسعير الفوري لذهب // DHAB"))
    val marketLogs: StateFlow<List<String>> = _marketLogs.asStateFlow()

    // -------------------------------------------------------------
    // User Portfolio & General Ledgers
    // -------------------------------------------------------------
    private val _cashBalanceSar = MutableStateFlow(480000.0) // Initial client balance
    val cashBalanceSar: StateFlow<Double> = _cashBalanceSar.asStateFlow()

    private val _allocatedGoldGrams = MutableStateFlow(1250.0)
    val allocatedGoldGrams: StateFlow<Double> = _allocatedGoldGrams.asStateFlow()

    private val _allocatedSilverGrams = MutableStateFlow(25000.0)
    val allocatedSilverGrams: StateFlow<Double> = _allocatedSilverGrams.asStateFlow()

    private val _dealerPnlSar = MutableStateFlow(128500.0) // Fictional dealer desk state
    val dealerPnlSar: StateFlow<Double> = _dealerPnlSar.asStateFlow()

    private val _dealerHedgePositionGrams = MutableStateFlow(-5000.0) // Dealer is short to offset retail buys
    val dealerHedgePositionGrams: StateFlow<Double> = _dealerHedgePositionGrams.asStateFlow()

    // Ledgers list
    private val _cashLedger = MutableStateFlow<List<CashLedgerEntry>>(emptyList())
    val cashLedger: StateFlow<List<CashLedgerEntry>> = _cashLedger.asStateFlow()

    private val _metalLedger = MutableStateFlow<List<MetalLedgerEntry>>(emptyList())
    val metalLedger: StateFlow<List<MetalLedgerEntry>> = _metalLedger.asStateFlow()

    // -------------------------------------------------------------
    // Physical Vault Inventory (Digital Twin)
    // -------------------------------------------------------------
    private val _vaultBars = MutableStateFlow<List<MetalBar>>(emptyList())
    val vaultBars: StateFlow<List<MetalBar>> = _vaultBars.asStateFlow()

    // -------------------------------------------------------------
    // RFQs & Orders
    // -------------------------------------------------------------
    private val _activeRfq = MutableStateFlow<RfqQuote?>(null)
    val activeRfq: StateFlow<RfqQuote?> = _activeRfq.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    // -------------------------------------------------------------
    // Invoices & Zakat & Scrap
    // -------------------------------------------------------------
    private val _invoices = MutableStateFlow<List<ElectronicInvoice>>(emptyList())
    val invoices: StateFlow<List<ElectronicInvoice>> = _invoices.asStateFlow()

    private val _zakatCalculations = MutableStateFlow<List<ZakatCalculation>>(emptyList())
    val zakatCalculations: StateFlow<List<ZakatCalculation>> = _zakatCalculations.asStateFlow()

    private val _scrapAssessments = MutableStateFlow<List<ScrapAssessment>>(emptyList())
    val scrapAssessments: StateFlow<List<ScrapAssessment>> = _scrapAssessments.asStateFlow()

    // Audit trailing
    private val _auditTrail = MutableStateFlow<List<String>>(emptyList())
    val auditTrail: StateFlow<List<String>> = _auditTrail.asStateFlow()

    init {
        logAudit("تأسيس النظام", "نجاح إعداد محركات التسعير والتخزين ذَهَب")
        generateInitialVault()
        startLiveSimulation()
    }

    private fun logAudit(action: String, details: String) {
        val stamp = dateFormat.format(Date())
        val logLine = "[$stamp] $action -> $details"
        _auditTrail.update { (listOf(logLine) + it).take(100) }
    }

    // -------------------------------------------------------------
    // Synthetic Vault Initial Generator
    // -------------------------------------------------------------
    private fun generateInitialVault() {
        val initialBars = listOf(
            MetalBar(
                id = "SAU-AU-00001842",
                serialNumber = "AU842999",
                metal = MetalType.GOLD,
                grossWeight = 1000.0,
                fineWeight = 999.9,
                purity = 0.9999,
                refiner = "مصفاة الرياض الدولية المعيارية",
                manufactureDate = "2025-02-12",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة الرياض 02",
                status = BarStatus.ALLOCATED,
                ownerName = "أحمد العتيبي"
            ),
            MetalBar(
                id = "SAU-AU-00001843",
                serialNumber = "AU843999",
                metal = MetalType.GOLD,
                grossWeight = 250.0,
                fineWeight = 249.97,
                purity = 0.9999,
                refiner = "مصفاة مكة الإسلامية للسبائك",
                manufactureDate = "2025-05-20",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة الرياض 02",
                status = BarStatus.ALLOCATED,
                ownerName = "أحمد العتيبي"
            ),
            MetalBar(
                id = "SAU-AU-00001844",
                serialNumber = "AU844999",
                metal = MetalType.GOLD,
                grossWeight = 1000.0,
                fineWeight = 999.9,
                purity = 0.9999,
                refiner = "مصفاة الرياض الدولية المعيارية",
                manufactureDate = "2025-03-01",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة الرياض 02",
                status = BarStatus.AVAILABLE,
                ownerName = "مكتب تداول ذَهَب"
            ),
            MetalBar(
                id = "SAU-AU-00001845",
                serialNumber = "AU845916",
                metal = MetalType.GOLD,
                grossWeight = 500.0,
                fineWeight = 458.35,
                purity = 0.9167, // 22K
                refiner = "مصفاة دبي للمعادن الثمينة",
                manufactureDate = "2024-11-10",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة جدة 01",
                status = BarStatus.AVAILABLE,
                ownerName = "مكتب تداول ذَهَب"
            ),
            MetalBar(
                id = "SAU-AG-00003021",
                serialNumber = "AG021999",
                metal = MetalType.SILVER,
                grossWeight = 15000.0,
                fineWeight = 14998.5,
                purity = 0.9990,
                refiner = "المصفاة الوطنية للفضة بدبي",
                manufactureDate = "2025-01-15",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة الرياض 02",
                status = BarStatus.ALLOCATED,
                ownerName = "أحمد العتيبي"
            ),
            MetalBar(
                id = "SAU-AG-00003022",
                serialNumber = "AG022999",
                metal = MetalType.SILVER,
                grossWeight = 10000.0,
                fineWeight = 9999.0,
                purity = 0.9990,
                refiner = "المصفاة الوطنية للفضة بدبي",
                manufactureDate = "2025-01-18",
                custodian = "خزائن الخليج الأمنية",
                vaultLocation = "خزينة الرياض 02",
                status = BarStatus.ALLOCATED,
                ownerName = "أحمد العتيبي"
            ),
            MetalBar(
                id = "SAU-AG-00003023",
                serialNumber = "AG023999",
                metal = MetalType.SILVER,
                grossWeight = 31103.4,
                fineWeight = 31103.4,
                purity = 0.9999,
                refiner = "دار الصك العربية الموحدة",
                manufactureDate = "2025-04-05",
                custodian = "مستودعات الشحن الدولية الآمنة",
                vaultLocation = "خزينة دبي الدبلوماسية",
                status = BarStatus.AVAILABLE,
                ownerName = "مكتب تداول ذَهَب"
            )
        )
        _vaultBars.value = initialBars
    }

    // -------------------------------------------------------------
    // Live Ticker Thread Simulation (Simulating Markets)
    // -------------------------------------------------------------
    private fun startLiveSimulation() {
        scope.launch {
            while (true) {
                delay(4000) // Updates every 4 seconds
                val goldChange = Random.nextDouble(-1.2, 1.5)
                val silverChange = Random.nextDouble(-0.15, 0.22)

                baseGoldUsd += goldChange
                baseSilverUsd += silverChange

                _goldPriceUsd.value = baseGoldUsd
                _silverPriceUsd.value = baseSilverUsd

                // Log price update
                val goldSar = getPriceInCurrency(MetalType.GOLD, "SAR")
                val logText = "تحديث فوري: الذهب ${String.format(Locale.ENGLISH, "%.2f", baseGoldUsd)} USD (${String.format(Locale.ENGLISH, "%.1f", goldSar)} ريال) | الفضة ${String.format(Locale.ENGLISH, "%.2f", baseSilverUsd)} USD"
                _marketLogs.update { (listOf(logText) + it).take(15) }

                // Regenerate Order Books relative to current tick
                generateOrderBooks()
            }
        }
    }

    // Get current metal price per gram in currency
    fun getPriceInCurrency(metal: MetalType, currency: String): Double {
        val pricePerOz = if (metal == MetalType.GOLD) _goldPriceUsd.value else _silverPriceUsd.value
        val fxRate = fxRates[currency] ?: 1.0
        val pricePerGram = (pricePerOz / TROY_OZ_TO_GRAM) * fxRate
        return pricePerGram
    }

    // Level-2 order book simulation generator
    private fun generateOrderBooks() {
        val xauMid = getPriceInCurrency(MetalType.GOLD, "SAR")
        val xagMid = getPriceInCurrency(MetalType.SILVER, "SAR")

        _orderBookXau.value = createSyntheticBook(MetalType.GOLD, "SAR", xauMid)
        _orderBookXag.value = createSyntheticBook(MetalType.SILVER, "SAR", xagMid)
    }

    private fun createSyntheticBook(metal: MetalType, currency: String, mid: Double): OrderBook {
        val spread = mid * 0.0008 // 0.08% spread
        val bidBase = mid - (spread / 2)
        val askBase = mid + (spread / 2)

        val bids = List(4) { i ->
            val step = mid * 0.0005 * (i + 1)
            OrderBookItem(
                price = (bidBase - step),
                quantity = (250 + Random.nextInt(100, 1500) - i * 150).toDouble(),
                orderCount = Random.nextInt(2, 12)
            )
        }

        val asks = List(4) { i ->
            val step = mid * 0.0005 * (i + 1)
            OrderBookItem(
                price = (askBase + step),
                quantity = (200 + Random.nextInt(100, 1400) - i * 100).toDouble(),
                orderCount = Random.nextInt(2, 10)
            )
        }

        val totalBidDepth = bids.sumOf { it.quantity }
        val totalAskDepth = asks.sumOf { it.quantity }
        val imbalance = (totalBidDepth - totalAskDepth) / (totalBidDepth + totalAskDepth)

        return OrderBook(
            metal = metal,
            currency = currency,
            midPrice = mid,
            bids = bids,
            asks = asks,
            spread = spread,
            depth = totalBidDepth + totalAskDepth,
            imbalance = imbalance
        )
    }

    // -------------------------------------------------------------
    // RFQ Generation (valid for 15s)
    // -------------------------------------------------------------
    fun requestQuote(clientName: String, metal: MetalType, qtyGrams: Double, side: OrderSide, currency: String): RfqQuote {
        val spotPrice = getPriceInCurrency(metal, currency)
        val spreadPct = 0.0012 // 0.12% premium
        val spread = spotPrice * spreadPct
        val fabricationFee = if (metal == MetalType.GOLD) 5.5 else 0.45 // Fabrication fee per gram

        val finalMetalBaseValue = spotPrice * qtyGrams
        val finalFabricationValue = fabricationFee * qtyGrams

        // Tax logic: Saudi ZATCA defines qualifying investment gold (purity 99%+ and tradable in markets) as zero-rated 'Z'.
        // Jewelry or non-qualifying metals standard 15% VAT 'S'.
        // Here we assume standard investment bullion 999.9.
        val isInvestmentGold = (metal == MetalType.GOLD) // zero-rated standard
        val taxRate = if (isInvestmentGold) 0.0 else 0.15
        val taxAmount = (finalMetalBaseValue + finalFabricationValue) * taxRate

        val unitPrice = spotPrice + (if (side == OrderSide.BUY) spread else -spread)
        val subTotal = (unitPrice + fabricationFee) * qtyGrams
        val finalPrice = subTotal + taxAmount

        val quote = RfqQuote(
            rfqId = "RFQ-" + Random.nextInt(100000, 999999),
            clientName = clientName,
            metal = metal,
            quantityGrams = qtyGrams,
            side = side,
            currency = currency,
            spotPrice = spotPrice,
            spread = spread,
            fabricationFee = fabricationFee,
            taxRate = taxRate,
            taxAmount = taxAmount,
            bidPrice = spotPrice + spread + fabricationFee,
            askPrice = spotPrice - spread,
            finalPrice = finalPrice,
            expiryTimestamp = SystemClock.elapsedRealtime() + 15000 // 15 seconds from now
        )

        _activeRfq.value = quote
        logAudit("طلب تسعير", "RFQ جديد ${quote.rfqId} للمعادن: ${metal.arabicName} بقيمة ${String.format("%.2f", finalPrice)} ${currency}")
        return quote
    }

    // -------------------------------------------------------------
    // Order Execution & Double-Entry Ledger Posting
    // -------------------------------------------------------------
    fun executeOrder(rfq: RfqQuote): Boolean {
        // Double-check expiration
        if (SystemClock.elapsedRealtime() > rfq.expiryTimestamp) {
            logAudit("تنفيذ الفشل", "فشل تنفيذ عرض السعر ${rfq.rfqId} بسب انتهاء صلاحية العرض")
            _activeRfq.value = null
            return false
        }

        val timestamp = dateFormat.format(Date())
        val transactionValue = rfq.finalPrice

        if (rfq.side == OrderSide.BUY) {
            // Client is buying from Dealer
            if (_cashBalanceSar.value < transactionValue) {
                logAudit("تنفيذ الفشل", "فشل تنفيذ أمر الشراء ${rfq.rfqId}: عدم كفاية الرصيد النقدي")
                return false
            }

            // Post Cash double entry
            val cashDebit = "مكتب تداول ذَهَب (نقد)"
            val cashCredit = "حساب العميل (أحمد العتيبي)"
            postCashEntry(timestamp, cashDebit, cashCredit, transactionValue, rfq.currency, "شراء ذهب استثماري عبر RFQ", rfq.rfqId)

            // Post Metal double entry (from Dealer inventory to Client)
            val metalDebit = "حساب العميل (أحمد العتيبي)"
            val metalCredit = "مكتب تداول ذَهَب (مخزون المعادن)"
            postMetalEntry(timestamp, metalDebit, metalCredit, rfq.quantityGrams, rfq.metal, "شراء ذهب استثماري عبر RFQ", rfq.rfqId)

            // Adjust Client state
            _cashBalanceSar.value -= transactionValue
            if (rfq.metal == MetalType.GOLD) {
                _allocatedGoldGrams.value += rfq.quantityGrams
            } else {
                _allocatedSilverGrams.value += rfq.quantityGrams
            }

            // Update Dealer desk state
            _dealerPnlSar.value += rfq.spread * rfq.quantityGrams // Spread capture
            _dealerHedgePositionGrams.value -= rfq.quantityGrams // Dealer short exposure increase

            // Allocate specific physical bar in the Vault Twin
            allocatePhysicalBarToClient(rfq.metal, rfq.quantityGrams, "أحمد العتيبي")

            // Generate Electronic Invoice ZATCA Style
            generateInvoice(rfq, timestamp)

        } else {
            // Client is selling metal to Dealer
            val clientMetalBal = if (rfq.metal == MetalType.GOLD) _allocatedGoldGrams.value else _allocatedSilverGrams.value
            if (clientMetalBal < rfq.quantityGrams) {
                logAudit("تنفيذ الفشل", "فشل تنفيذ أمر البيع ${rfq.rfqId}: عدم كفاية رصيد المعادن المخصصة")
                return false
            }

            // Post Cash double entry (from Dealer to Client)
            val cashDebit = "حساب العميل (أحمد العتيبي)"
            val cashCredit = "مكتب تداول ذَهَب (نقد)"
            postCashEntry(timestamp, cashDebit, cashCredit, transactionValue, rfq.currency, "بيع ذهب استثماري عبر RFQ", rfq.rfqId)

            // Post Metal double entry (from Client to Dealer)
            val metalDebit = "مكتب تداول ذَهَب (مخزون المعادن)"
            val metalCredit = "حساب العميل (أحمد العتيبي)"
            postMetalEntry(timestamp, metalDebit, metalCredit, rfq.quantityGrams, rfq.metal, "بيع ذهب استثماري عبر RFQ", rfq.rfqId)

            // Adjust Client state
            _cashBalanceSar.value += transactionValue
            if (rfq.metal == MetalType.GOLD) {
                _allocatedGoldGrams.value -= rfq.quantityGrams
            } else {
                _allocatedSilverGrams.value -= rfq.quantityGrams
            }

            // Update Dealer desk state
            _dealerPnlSar.value += rfq.spread * rfq.quantityGrams
            _dealerHedgePositionGrams.value += rfq.quantityGrams // hedge exposure reduction

            // De-allocate specific physical bar in Vault Twin
            deallocatePhysicalBarFromClient(rfq.metal, rfq.quantityGrams, "أحمد العتيبي")
        }

        // Add to standard orders log
        val order = Order(
            orderId = rfq.rfqId,
            accountId = "ACC-9042",
            metal = rfq.metal,
            side = rfq.side,
            type = OrderType.RFQ,
            quantity = rfq.quantityGrams,
            price = rfq.finalPrice / rfq.quantityGrams,
            currency = rfq.currency,
            timestamp = timestamp,
            status = OrderStatus.EXECUTED,
            executionPrice = rfq.finalPrice / rfq.quantityGrams,
            fee = rfq.fabricationFee * rfq.quantityGrams
        )

        _orders.update { listOf(order) + it }
        _activeRfq.value = null

        logAudit("تسوية ودفتر القيد", "تمت التسوية بنجاح للأمر ${rfq.rfqId}. توازن النقد والمعادن.")
        return true
    }

    private fun postCashEntry(ts: String, deb: String, cred: String, amt: Double, cur: String, desc: String, ref: String) {
        val entry = CashLedgerEntry(timestamp = ts, debitAccount = deb, creditAccount = cred, amount = amt, currency = cur, description = desc, referenceId = ref)
        _cashLedger.update { listOf(entry) + it }
    }

    private fun postMetalEntry(ts: String, deb: String, cred: String, qty: Double, met: MetalType, desc: String, ref: String) {
        val entry = MetalLedgerEntry(timestamp = ts, debitOwner = deb, creditOwner = cred, quantityGrams = qty, metal = met, description = desc, referenceId = ref)
        _metalLedger.update { listOf(entry) + it }
    }

    // Allocate physical bars to client from general vault twin
    private fun allocatePhysicalBarToClient(metal: MetalType, grams: Double, clientName: String) {
        val bars = _vaultBars.value.toMutableList()
        var remainingGrams = grams

        for (i in bars.indices) {
            val bar = bars[i]
            if (bar.metal == metal && bar.status == BarStatus.AVAILABLE && remainingGrams > 0) {
                if (bar.fineWeight <= remainingGrams + 0.1) {
                    // Fully allocate this bar
                    bars[i] = bar.copy(
                        status = BarStatus.ALLOCATED,
                        ownerName = clientName,
                        movementHistory = bar.movementHistory + MovementEvent(
                            timestamp = dateFormat.format(Date()),
                            fromLocation = bar.vaultLocation,
                            toLocation = bar.vaultLocation,
                            description = "تخصيص كامل للعميل $clientName بموجب تسوية صفقة التداول",
                            operatorName = "أمين الخزينة الرئيسي"
                        )
                    )
                    remainingGrams -= bar.fineWeight
                } else {
                    // Partially allocate (split simulation or book-entry registry update)
                    bars[i] = bar.copy(
                        status = BarStatus.ALLOCATED,
                        ownerName = clientName,
                        fineWeight = grams, // Simply allocate portion requested
                        grossWeight = grams,
                        movementHistory = bar.movementHistory + MovementEvent(
                            timestamp = dateFormat.format(Date()),
                            fromLocation = bar.vaultLocation,
                            toLocation = bar.vaultLocation,
                            description = "تخصيص جزء دفتري للعميل $clientName بقيمة $grams غرام",
                            operatorName = "أمين الخزينة الرئيسي"
                        )
                    )
                    remainingGrams = 0.0
                }
            }
        }
        _vaultBars.value = bars
    }

    private fun deallocatePhysicalBarFromClient(metal: MetalType, grams: Double, clientName: String) {
        val bars = _vaultBars.value.toMutableList()
        var remainingGrams = grams

        for (i in bars.indices) {
            val bar = bars[i]
            if (bar.metal == metal && bar.status == BarStatus.ALLOCATED && bar.ownerName == clientName && remainingGrams > 0) {
                if (bar.fineWeight <= remainingGrams + 0.1) {
                    bars[i] = bar.copy(
                        status = BarStatus.AVAILABLE,
                        ownerName = "مكتب تداول ذَهَب",
                        movementHistory = bar.movementHistory + MovementEvent(
                            timestamp = dateFormat.format(Date()),
                            fromLocation = bar.vaultLocation,
                            toLocation = bar.vaultLocation,
                            description = "فك التخصيص وإرجاع للمخزون العام بسبب تسييل البيع",
                            operatorName = "أمين الخزينة الرئيسي"
                        )
                    )
                    remainingGrams -= bar.fineWeight
                }
            }
        }
        _vaultBars.value = bars
    }

    // -------------------------------------------------------------
    // ZATCA Electronic Invoice Generator
    // -------------------------------------------------------------
    private fun generateInvoice(rfq: RfqQuote, timestamp: String) {
        val invId = "ZAT-2026-" + Random.nextInt(10000, 99999)
        val metalVal = rfq.spotPrice * rfq.quantityGrams
        val fabricationVal = rfq.fabricationFee * rfq.quantityGrams
        val isInvGold = (rfq.metal == MetalType.GOLD)
        val taxCatCode = if (isInvGold) "Z" else "S" // Z = Zero-rated, S = Standard (15% VAT)

        // Simulated ZATCA compliant Base64 QR payload (merchant, tax number, timestamp, total, tax)
        val qrPayload = "AQpESEFCIEdPTEQDAjE1BAl6YXRjYTExMTIFMjAyNi0xMC0wNVQxMToxMjowMFoHMTU3NTEuMjU="

        val invoice = ElectronicInvoice(
            invoiceId = invId,
            sellerName = SELLER_ENTITY,
            sellerTaxId = SELLER_TAX_ID,
            buyerName = rfq.clientName,
            buyerTaxId = "310098452100003",
            issueDate = timestamp,
            metal = rfq.metal,
            grossWeight = rfq.quantityGrams,
            purity = if (rfq.metal == MetalType.GOLD) "999.9 (24K)" else "999.0 (فضة ناعمة)",
            netWeight = rfq.quantityGrams,
            unitPrice = rfq.spotPrice,
            metalValue = metalVal,
            makingFee = fabricationVal,
            taxCategoryCode = taxCatCode,
            taxRate = rfq.taxRate,
            taxAmount = rfq.taxAmount,
            grandTotal = rfq.finalPrice,
            currency = rfq.currency,
            qrCodePayload = qrPayload
        )

        _invoices.update { listOf(invoice) + it }
        logAudit("إنشاء فاتورة إلكترونية", "فاتورة $invId متوافقة مع متطلبات ZATCA")
    }

    // -------------------------------------------------------------
    // Zakat Engine
    // -------------------------------------------------------------
    fun calculateZakat(gold24g: Double, silverGrams: Double, cashSar: Double, tradeSar: Double): ZakatCalculation {
        val goldPriceSar = getPriceInCurrency(MetalType.GOLD, "SAR")
        val silverPriceSar = getPriceInCurrency(MetalType.SILVER, "SAR")

        val goldVal = gold24g * goldPriceSar
        val silverVal = silverGrams * silverPriceSar

        // Zakat Nisab calculations:
        // Gold Nisab: 85 grams of pure gold (24K)
        // Silver Nisab: 595 grams of pure silver
        val goldNisabMet = gold24g >= 85.0
        val silverNisabMet = silverGrams >= 595.0

        val totalAssetsSar = goldVal + silverVal + cashSar + tradeSar

        // Zakat rate is 2.5% of the qualifying assets
        val zakatBase = totalAssetsSar
        val zakatAmount = if (goldNisabMet || silverNisabMet || (cashSar + tradeSar >= 85 * goldPriceSar)) {
            zakatBase * 0.025
        } else {
            0.0
        }

        val calc = ZakatCalculation(
            calculationDate = dateFormat.format(Date()),
            goldWeight24K = gold24g,
            silverWeight = silverGrams,
            cashBalanceSar = cashSar,
            tradeInventorySar = tradeSar,
            goldValuationSar = goldVal,
            silverValuationSar = silverVal,
            calculatedBaseSar = zakatBase,
            calculatedAmountSar = zakatAmount
        )

        return calc
    }

    fun saveZakatCalculation(calc: ZakatCalculation) {
        _zakatCalculations.update { listOf(calc) + it }
        logAudit("حساب الزكاة", "تم حفظ احتساب الزكاة التقديري بقيمة: ${String.format("%.2f", calc.calculatedAmountSar)} ريال")
    }

    // -------------------------------------------------------------
    // Scrap/Old Gold Assessment Engine
    // -------------------------------------------------------------
    fun assessScrapGold(weight: Double, karat: Int, stonesWeight: Double, refiningFee: Double): ScrapAssessment {
        val ticketId = "SCR-" + Random.nextInt(1000, 9999)
        val karatCode = "${karat}K"
        val purityFactor = when (karat) {
            24 -> 0.9999
            22 -> 0.9167
            21 -> 0.8750
            18 -> 0.7500
            14 -> 0.5833
            else -> 0.75
        }

        val netFineExpected = (weight - stonesWeight) * purityFactor
        val fineGoldPriceSar = getPriceInCurrency(MetalType.GOLD, "SAR")
        val baseValue = netFineExpected * fineGoldPriceSar
        val finalValue = baseValue - refiningFee

        val assessment = ScrapAssessment(
            ticketId = ticketId,
            receivedDate = dateFormat.format(Date()),
            weightGrams = weight,
            declaredKarat = karat,
            estimatedPurity = purityFactor,
            xrfPurityResult = purityFactor + Random.nextDouble(-0.002, 0.002), // synthetic spectrograph scan
            fireAssayResult = purityFactor + Random.nextDouble(-0.0005, 0.0005), // accurate laboratory result
            stonesWeightDeduction = stonesWeight,
            netFineGoldExpected = netFineExpected,
            refiningFeeSar = refiningFee,
            currentFinePriceSar = fineGoldPriceSar,
            finalValueSar = finalValue,
            status = "فحص ومعايرة"
        )

        _scrapAssessments.update { listOf(assessment) + it }
        logAudit("فحص ذهب مستعمل", "تم إعداد تقرير المعايرة $ticketId لعيار $karatKarat بوزن $weight غرام")
        return assessment
    }

    private val karatKarat: String
        get() = "21"

    // -------------------------------------------------------------
    // Risk Engine, Hedging, and Futures Simulation
    // -------------------------------------------------------------
    fun calculatePortfolioRisk(): Map<String, Any> {
        val goldGramPrice = getPriceInCurrency(MetalType.GOLD, "SAR")
        val silverGramPrice = getPriceInCurrency(MetalType.SILVER, "SAR")

        val gValue = _allocatedGoldGrams.value * goldGramPrice
        val sValue = _allocatedSilverGrams.value * silverGramPrice
        val cash = _cashBalanceSar.value
        val total = gValue + sValue + cash

        // Value-at-Risk (VaR) 95% Confidence, 1-day simulation
        // Assumed standard historical daily volatility: Gold 1.2%, Silver 2.1%
        val goldDailyVol = 0.012
        val silverDailyVol = 0.021
        val zScore = 1.645 // 95% confidence

        val goldVaRSar = gValue * goldDailyVol * zScore
        val silverVaRSar = sValue * silverDailyVol * zScore

        // Simple portfolio VaR with 0.35 correlation assumption
        val portVaR = kotlin.math.sqrt(
            goldVaRSar * goldVaRSar +
            silverVaRSar * silverVaRSar +
            2 * 0.35 * goldVaRSar * silverVaRSar
        )

        // Stress losses scenarios
        val goldDrop10 = gValue * 0.10
        val silverDrop20 = sValue * 0.20
        val totalStressScenario = goldDrop10 + silverDrop20

        return mapOf(
            "total_value" to total,
            "gold_value" to gValue,
            "silver_value" to sValue,
            "var_value" to portVaR,
            "var_pct" to (portVaR / total) * 100,
            "stress_loss_10pct" to totalStressScenario,
            "hedge_ratio" to (if (gValue == 0.0) 0.0 else (_dealerHedgePositionGrams.value.absoluteValue / _allocatedGoldGrams.value) * 100)
        )
    }

    // -------------------------------------------------------------
    // Physical Ownership Transfer (Book-entry transfer)
    // -------------------------------------------------------------
    fun transferBarOwnership(barId: String, newOwner: String): Boolean {
        val bars = _vaultBars.value.toMutableList()
        val index = bars.indexOfFirst { it.id == barId }
        if (index == -1) return false

        val bar = bars[index]
        if (bar.status != BarStatus.ALLOCATED) return false

        val previousOwner = bar.ownerName
        bars[index] = bar.copy(
            ownerName = newOwner,
            movementHistory = bar.movementHistory + MovementEvent(
                timestamp = dateFormat.format(Date()),
                fromLocation = bar.vaultLocation,
                toLocation = bar.vaultLocation,
                description = "نقل ملكية بالقيد الدفتري من العميل $previousOwner إلى العميل $newOwner",
                operatorName = "مسؤول تسويات المقاصة"
            )
        )

        _vaultBars.value = bars
        logAudit("نقل ملكية سبيكة", "تم تحويل ملكية السبيكة ${bar.id} دفترياً من $previousOwner إلى $newOwner")
        return true
    }

    // Direct Level-1 Order execution simulation for testing
    fun executeInstantOrder(metal: MetalType, side: OrderSide, grams: Double, pricePerGram: Double): Boolean {
        val timestamp = dateFormat.format(Date())
        val orderId = "ORD-" + Random.nextInt(10000, 99999)
        val value = grams * pricePerGram
        val fee = value * 0.0015 // 0.15% fee

        if (side == OrderSide.BUY) {
            if (_cashBalanceSar.value < value + fee) return false
            _cashBalanceSar.value -= (value + fee)
            if (metal == MetalType.GOLD) _allocatedGoldGrams.value += grams else _allocatedSilverGrams.value += grams
            postCashEntry(timestamp, "مكتب تداول ذَهَب", "أحمد العتيبي", value, "SAR", "شراء فوري للمعدن", orderId)
            postMetalEntry(timestamp, "أحمد العتيبي", "مكتب تداول ذَهَب", grams, metal, "تسليم فوري للمعدن", orderId)
        } else {
            val balance = if (metal == MetalType.GOLD) _allocatedGoldGrams.value else _allocatedSilverGrams.value
            if (balance < grams) return false
            _cashBalanceSar.value += (value - fee)
            if (metal == MetalType.GOLD) _allocatedGoldGrams.value -= grams else _allocatedSilverGrams.value -= grams
            postCashEntry(timestamp, "أحمد العتيبي", "مكتب تداول ذَهَب", value, "SAR", "بيع فوري للمعدن", orderId)
            postMetalEntry(timestamp, "مكتب تداول ذَهَب", "أحمد العتيبي", grams, metal, "استرداد فوري للمعدن", orderId)
        }

        _orders.update {
            listOf(
                Order(
                    orderId = orderId,
                    accountId = "ACC-9042",
                    metal = metal,
                    side = side,
                    type = OrderType.MARKET,
                    quantity = grams,
                    price = pricePerGram,
                    currency = "SAR",
                    timestamp = timestamp,
                    status = OrderStatus.EXECUTED,
                    executionPrice = pricePerGram,
                    fee = fee
                )
            ) + it
        }

        logAudit("تداول فوري", "تنفيذ قيد فوري ناجح للأمر $orderId لـ $grams غرام")
        return true
    }
}
