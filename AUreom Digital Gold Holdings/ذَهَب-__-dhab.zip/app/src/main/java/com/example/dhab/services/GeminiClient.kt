package com.example.dhab.services

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig
import com.example.dhab.models.MetalType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

// --- Moshi-Compatible Gemini API Data Classes ---

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

// --- Retrofit API Interface ---
interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// --- Gemini Service Client ---
object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    private val api: GeminiApi = retrofit.create(GeminiApi::class.java)

    private const val SYSTEM_INSTRUCTION = """
أنت "ذَهَب AI" - الخبير المالي والمستشار الرقمي الفوري لمنصة ذَهَب للذهب والفضة في الخليج العربي والشرق الأوسط.
تتحدث باللغة العربية الفصحى الفاخرة بأسلوب مالي واثق ومحترف، مثل مستشار في بنك استثماري مرموق بالرياض أو دبي.
مهامك هي:
1. الإجابة عن الأسئلة المتعلقة بأسواق الذهب والفضة، الفروقات بين الذهب الاستثماري والمجوهرات، والزكاة والضرائب.
2. المساعدة في حسابات نقاء الذهب والفضة (مثلاً عيار 21 يحتوي على 87.5% ذهب خالص).
3. تقديم شروحات حول الخزائن المخصصة (Allocated Vaulting) وغير المخصصة وعمليات التسوية.
4. تفسير الأوامر وتنفيذها بشكل افتراضي وتوضيح المخاطر المالية.
الرجاء إبقاء الإجابات مركزة، غنية بالمعلومات المالية، سريعة القراءة وتجنب العبارات الطنانة أو الصياغات الطفولية.
عندما يسألك المستخدم عن أسعار حالية أو محفظة، استند إلى الأرقام السائدة في المنصة واعرضها له باحترافية.
    """

    suspend fun askGemini(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "YOUR_GEMINI_API_KEY") {
            // Return high-quality local synthetic AI helper when API key isn't provided yet
            delay(1000)
            return@withContext getLocalAiResponse(prompt)
        }

        val request = GeminiRequest(
            contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt)))),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = SYSTEM_INSTRUCTION)))
        )

        try {
            val response = api.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "عذراً، لم أتمكن من صياغة الإجابة حالياً. يرجى المحاولة مرة أخرى."
        } catch (e: Exception) {
            // Graceful fallback to local AI response with warning
            val local = getLocalAiResponse(prompt)
            "⚠️ (تنبيه: محاكاة محلية بسبب تعذر الاتصال بالمخدم)\n\n$local"
        }
    }

    // High quality financial engine parser for local offline AI
    private fun getLocalAiResponse(prompt: String): String {
        val lowerPrompt = prompt.lowercase()
        return when {
            lowerPrompt.contains("سعر الذهب") || lowerPrompt.contains("سعر اليوم") || lowerPrompt.contains("الذهب الآن") -> {
                val goldSar = DhabService.getPriceInCurrency(MetalType.GOLD, "SAR")
                "السعر الفوري للذهب الحالي في الأسواق العربية يبلغ ${String.format("%.2f", goldSar)} ريال سعودي للغرام عيار 24 (XAU/SAR). الأسواق العالمية تشهد استقراراً نسبياً مع ترقب قرارات الفيدرالي والطلب الخليجي المتزايد."
            }
            lowerPrompt.contains("زكاة") || lowerPrompt.contains("الزكاة") || lowerPrompt.contains("احسب زكاتي") -> {
                "أهلاً بك. لحساب الزكاة على المعادن الثمينة، يبلغ حد النصاب الشرعي للذهب 85 غراماً من الذهب الخالص (عيار 24)، ونصاب الفضة هو 595 غراماً. إذا بلغت مدخراتك النصاب وحال عليها الحول، تجب الزكاة بنسبة 2.5% من القيمة الإجمالية. يمكنك استخدام حاسبة الزكاة المتوفرة في المنصة لحساب القيمة بدقة متناهية."
            }
            lowerPrompt.contains("عيار 21") || lowerPrompt.contains("نقاء") || lowerPrompt.contains("احسب") -> {
                "الذهب عيار 21 قيراط تبلغ نسبة نقائه 87.5% (أو 875 جزءاً في الألف) من الذهب الخالص، والـ 12.5% المتبقية هي معادن أخرى كالنحاس والفضة لزيادة صلابته. لحساب غرامات الذهب الصافي في قطعة عيار 21، اضرب الوزن الإجمالي في 0.875."
            }
            lowerPrompt.contains("خزينة") || lowerPrompt.contains("تخزين") || lowerPrompt.contains("مخصص") || lowerPrompt.contains("الخزائن") -> {
                "في منصة ذَهَب، نعتمد على 'التخزين المخصص والمعزول' (Allocated Bullion Custody). هذا يعني أنك تملك سبائك عينية مسجلة بأرقام تسلسلية فريدة ومحددة في خزائن الرياض وجدة ودبي، وليست مجرد رصيد دفتري عام غير مخصص. الملكية مسجلة دفترياً وقانونياً باسمك مباشرة ويمكنك طلب استلامها الفعلي في أي وقت."
            }
            lowerPrompt.contains("مخاطر") || lowerPrompt.contains("محفظتي") || lowerPrompt.contains("تقلب") -> {
                val risk = DhabService.calculatePortfolioRisk()
                val total = risk["total_value"] as Double
                val varVal = risk["var_value"] as Double
                val varPct = risk["var_pct"] as Double
                "بناءً على محفظتك الحالية البالغة ${String.format("%,.0f", total)} ريال، يبلغ مقياس القيمة المعرضة للمخاطر (VaR) ليوم واحد وبمستوى ثقة 95% حوالي ${String.format("%,.2f", varVal)} ريال (${String.format("%.2f", varPct)}%). نوصي بالتحوط باستخدام عقود الذهب المستقبلية المتاحة لتغطية أي تقلبات سعرية حادة."
            }
            lowerPrompt.contains("شراء") || lowerPrompt.contains("بيع") || lowerPrompt.contains("نفذ") -> {
                "لتنفيذ عمليات الشراء والبيع بشكل مباشر، يرجى الانتقال إلى 'مكتب التداول' المدمج في المنصة لطلب عرض سعر (RFQ) حي وتنفيذه خلال 15 ثانية لضمان أفضل تسعير فوري ومطابقة دفاتر القيد دبل-إنتري."
            }
            else -> {
                "مرحباً بك في منصة ذَهَب // DHAB للخدمات المالية والمعادن الثمينة. أنا هنا لمساعدتك في استكشاف شاشات التداول، وحساب الزكاة والضرائب الاستثمارية، ومتابعة السبائك المخصصة في الخزائن الرقمية. كيف يمكنني خدمتك اليوم في أسواق الذهب والفضة؟"
            }
        }
    }
}
