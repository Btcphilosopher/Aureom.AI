package com.example.dhab.ui

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dhab.models.*
import com.example.dhab.services.DhabService
import com.example.dhab.services.GeminiClient
import com.example.ui.theme.*
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sin

enum class DhabTab(val arabicName: String, val englishName: String, val icon: ImageVector) {
    HOME("الرئيسية", "Dashboard", Icons.Default.Dashboard),
    MARKETS("الأسواق", "Markets", Icons.Default.TrendingUp),
    TRADE("التداول", "Trading", Icons.Default.SwapHoriz),
    VAULT("الخزينة", "Vault", Icons.Default.AccountBalance),
    MERCHANT("التاجر", "Merchant", Icons.Default.Storefront),
    ZAKAT("الزكاة والذكاء", "Zakat & AI", Icons.Default.Calculate)
}

@Composable
fun DhabApp() {
    var isArabic by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(DhabTab.HOME) }
    var isAiPanelOpen by remember { mutableStateOf(false) }

    // Observe flows from state manager
    val goldPriceUsd by DhabService.goldPriceUsd.collectAsState()
    val silverPriceUsd by DhabService.silverPriceUsd.collectAsState()
    val cashBalanceSar by DhabService.cashBalanceSar.collectAsState()
    val allocatedGoldGrams by DhabService.allocatedGoldGrams.collectAsState()
    val allocatedSilverGrams by DhabService.allocatedSilverGrams.collectAsState()
    val marketLogs by DhabService.marketLogs.collectAsState()

    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    // Force RTL or LTR composition based on language state
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            topBar = {
                DhabTopAppBar(
                    isArabic = isArabic,
                    onLangToggle = { isArabic = !isArabic },
                    cashSar = cashBalanceSar,
                    goldGrams = allocatedGoldGrams
                )
            },
            bottomBar = {
                DhabBottomBar(
                    isArabic = isArabic,
                    currentTab = currentTab,
                    onTabSelect = { currentTab = it }
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { isAiPanelOpen = !isAiPanelOpen },
                    containerColor = DhabGold,
                    contentColor = Color.Black,
                    modifier = Modifier.testTag("ai_assistant_fab")
                ) {
                    Icon(
                        imageVector = if (isAiPanelOpen) Icons.Default.Close else Icons.Default.SmartToy,
                        contentDescription = "ذَهَب AI"
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Background artistic gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            val brush = Brush.radialGradient(
                                colors = listOf(DhabGold.copy(alpha = 0.04f), Color.Transparent),
                                center = Offset(size.width * 0.5f, size.height * 0.2f),
                                radius = size.width * 0.8f
                            )
                            drawRect(brush)
                        }
                )

                // Tab Routing
                when (currentTab) {
                    DhabTab.HOME -> HomeScreen(isArabic = isArabic, goldPrice = goldPriceUsd, silverPrice = silverPriceUsd, logs = marketLogs)
                    DhabTab.MARKETS -> MarketsScreen(isArabic = isArabic, goldPrice = goldPriceUsd, silverPrice = silverPriceUsd)
                    DhabTab.TRADE -> TradingScreen(isArabic = isArabic)
                    DhabTab.VAULT -> VaultScreen(isArabic = isArabic)
                    DhabTab.MERCHANT -> MerchantScreen(isArabic = isArabic)
                    DhabTab.ZAKAT -> ZakatScreen(isArabic = isArabic)
                }

                // Floating AI Assistant Bottom Panel
                AnimatedVisibility(
                    visible = isAiPanelOpen,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(0.6f)
                        .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, DhabGold.copy(alpha = 0.3f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                ) {
                    AiAssistantPanel(isArabic = isArabic, onClose = { isAiPanelOpen = false })
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Core Custom App Bar Components
// -------------------------------------------------------------
@Composable
fun DhabTopAppBar(isArabic: Boolean, onLangToggle: () -> Unit, cashSar: Double, goldGrams: Double) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title and Descriptor
                Column {
                    Text(
                        text = if (isArabic) "ذَهَب // DHAB" else "DHAB // GOLD",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Text(
                        text = if (isArabic) "منصة المعادن والخدمات المالية المخصصة" else "Precious Metals & Custody Terminal",
                        fontSize = 11.sp,
                        color = DhabSand
                    )
                }

                // Interactive Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Synthetic Status Tag
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(DhabDarkGreen.copy(alpha = 0.2f))
                            .border(0.5.dp, DhabDarkGreen, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isArabic) "بيانات تجريبية" else "SYNTHETIC",
                            fontSize = 9.sp,
                            color = Color.Green,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Language Switcher
                    Button(
                        onClick = onLangToggle,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("lang_toggle_button")
                    ) {
                        Text(
                            text = if (isArabic) "English" else "العربية",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = DhabStone.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(6.dp))

            // Quick Client Wealth Summary Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = "Wallet",
                        tint = DhabGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isArabic) "النقد: ${String.format(Locale.ENGLISH, "%,.2f", cashSar)} ريال" else "Cash: ${String.format(Locale.ENGLISH, "%,.2f", cashSar)} SAR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = "Gold Balance",
                        tint = DhabGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isArabic) "الذهب المخصص: ${String.format(Locale.ENGLISH, "%,.2f", goldGrams)} غ" else "Allocated Gold: ${String.format(Locale.ENGLISH, "%,.2f", goldGrams)} g",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun DhabBottomBar(isArabic: Boolean, currentTab: DhabTab, onTabSelect: (DhabTab) -> Unit) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        DhabTab.values().forEach { tab ->
            val label = if (isArabic) tab.arabicName else tab.englishName
            NavigationBarItem(
                selected = currentTab == tab,
                onClick = { onTabSelect(tab) },
                icon = { Icon(imageVector = tab.icon, contentDescription = label) },
                label = { Text(text = label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = DhabGold,
                    indicatorColor = DhabGold,
                    unselectedIconColor = DhabSand,
                    unselectedTextColor = DhabSand
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}

// -------------------------------------------------------------
// 1. HOME / DASHBOARD SCREEN
// -------------------------------------------------------------
@Composable
fun HomeScreen(isArabic: Boolean, goldPrice: Double, silverPrice: Double, logs: List<String>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Premium Card with custom design
        item {
            WelcomeBanner(isArabic = isArabic)
        }

        // Realtime Bulletins & Quotes
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DhabQuoteCard(
                    title = if (isArabic) "الذهب الفوري (XAU/SAR)" else "Gold Spot (XAU/SAR)",
                    price = DhabService.getPriceInCurrency(MetalType.GOLD, "SAR"),
                    change = 1.24,
                    unit = if (isArabic) "ريال / غرام" else "SAR / g",
                    modifier = Modifier.weight(1f)
                )

                DhabQuoteCard(
                    title = if (isArabic) "الفضة الفورية (XAG/SAR)" else "Silver Spot (XAG/SAR)",
                    price = DhabService.getPriceInCurrency(MetalType.SILVER, "SAR"),
                    change = 2.18,
                    unit = if (isArabic) "ريال / غرام" else "SAR / g",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Live Market Interactive Canvas Chart
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) "رسم بياني: الذهب مقابل الريال (توليد صوري مالي)" else "XAU/SAR Synthetic Real-Time Chart",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Timeline,
                            contentDescription = "Chart Icon",
                            tint = DhabGold
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    // Draw synthetic elegant wave chart representing Gulf metals market activity
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .border(0.5.dp, DhabStone.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val path = Path()
                            val points = 25
                            val width = size.width
                            val height = size.height

                            val step = width / (points - 1)
                            for (i in 0 until points) {
                                val x = i * step
                                val y = (height / 2) + sin(i.toDouble() * 0.4) * 40.0 + (sin(i.toDouble() * 0.9) * 15.0)
                                if (i == 0) {
                                    path.moveTo(x, y.toFloat())
                                } else {
                                    path.lineTo(x, y.toFloat())
                                }
                            }

                            drawPath(
                                path = path,
                                color = DhabGold,
                                style = Stroke(width = 3.dp.toPx())
                            )

                            // Under-shadow fill
                            val fillPath = Path().apply {
                                addPath(path)
                                lineTo(width, height)
                                lineTo(0f, height)
                                close()
                            }
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(DhabGold.copy(alpha = 0.25f), Color.Transparent)
                                )
                            )
                        }

                        Text(
                            text = "ذَهَب // Live Feed Engine",
                            fontSize = 10.sp,
                            color = DhabGold.copy(alpha = 0.6f),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                        )
                    }
                }
            }
        }

        // Live Market Update Bulletins (Ticks Logger)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "سجل التداولات والأسعار الفورية" else "Live Market Ticker Feed",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    logs.take(5).forEach { log ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(DhabDarkGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = log, fontSize = 11.sp, color = DhabGold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WelcomeBanner(isArabic: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DhabDeepNavy),
        border = BorderStroke(1.dp, DhabGold.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Text(
                text = if (isArabic) "ذَهَب // منصة أسواق الذهب والفضة العربية" else "DHAB // Arab Gold & Silver Markets",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DhabGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isArabic) "بوابة التداولات الفورية والسبائك المخصصة والمعزولة في الخزائن الأمنية الإقليمية بالرياض وجدة ودبي." else "Gateway to physical allocated bullion vaulting, spot execution and liquidity in the Arabian Gulf.",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.8f),
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = "Shield", tint = DhabGold, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isArabic) "مؤمن بالكامل" else "Fully Insured", fontSize = 10.sp, color = DhabGold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = "Verified", tint = DhabGold, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isArabic) "مطابقة مقاصة ثنائية" else "Double-Entry Ledger", fontSize = 10.sp, color = DhabGold)
                }
            }
        }
    }
}

@Composable
fun DhabQuoteCard(title: String, price: Double, change: Double, unit: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 10.sp, color = DhabSand, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = String.format(Locale.ENGLISH, "%,.2f", price),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DhabGold
            )
            Text(text = unit, fontSize = 9.sp, color = DhabSand)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ArrowUpward,
                    contentDescription = "Upward",
                    tint = Color.Green,
                    modifier = Modifier.size(10.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(text = "+$change%", fontSize = 10.sp, color = Color.Green, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -------------------------------------------------------------
// 2. MARKETS SCREEN (FX matrix, Orderbook Level-2, Crosses)
// -------------------------------------------------------------
@Composable
fun MarketsScreen(isArabic: Boolean, goldPrice: Double, silverPrice: Double) {
    val xauBook by DhabService.orderBookXau.collectAsState()
    val xagBook by DhabService.orderBookXag.collectAsState()

    var selectedMetalTab by remember { mutableStateOf(MetalType.GOLD) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selector tab
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { selectedMetalTab = MetalType.GOLD },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("market_gold_tab"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetalTab == MetalType.GOLD) DhabGold else Color.Transparent,
                        contentColor = if (selectedMetalTab == MetalType.GOLD) Color.Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text(text = if (isArabic) "أسواق الذهب الموحدة" else "Gold Market Desk")
                }
                Button(
                    onClick = { selectedMetalTab = MetalType.SILVER },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("market_silver_tab"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetalTab == MetalType.SILVER) DhabGold else Color.Transparent,
                        contentColor = if (selectedMetalTab == MetalType.SILVER) Color.Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text(text = if (isArabic) "أسواق الفضة الموحدة" else "Silver Market Desk")
                }
            }
        }

        // L2 Order Book Render
        item {
            val book = if (selectedMetalTab == MetalType.GOLD) xauBook else xagBook
            if (book != null) {
                L2OrderBookView(isArabic = isArabic, book = book)
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = DhabGold)
                }
            }
        }

        // FX & Precious Metals Cross-Rate Matrix
        item {
            FXMetalMatrixView(isArabic = isArabic, selectedMetalTab)
        }

        // Digital Gold Indicators (XAUT, BTC/XAU, USDT/XAUT)
        item {
            DigitalAssetsIndicatorView(isArabic = isArabic)
        }
    }
}

@Composable
fun L2OrderBookView(isArabic: Boolean, book: OrderBook) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isArabic) "دفتر العروض والطلبات (Level 2)" else "Level-2 Order Book",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DhabGold
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Asymmetrical bids/asks tables
            Row(modifier = Modifier.fillMaxWidth()) {
                // Bid Side (Buy Requests)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isArabic) "طلبات الشراء (Bids)" else "Bids (Buy)",
                        color = DhabDarkGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    book.bids.forEach { bid ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = String.format(Locale.ENGLISH, "%,.2f", bid.price), color = DhabDarkGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "${bid.quantity.toInt()} oz", fontSize = 11.sp, color = DhabSand)
                        }
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Ask Side (Sell Offers)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isArabic) "عروض البيع (Asks)" else "Asks (Sell)",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    book.asks.forEach { ask ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = String.format(Locale.ENGLISH, "%,.2f", ask.price), color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "${ask.quantity.toInt()} oz", fontSize = 11.sp, color = DhabSand)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = DhabStone.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(6.dp))

            // Spread & Imbalance diagnostics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isArabic) "الفارق (Spread): ${String.format(Locale.ENGLISH, "%.4f", book.spread)} ريال" else "Spread: ${String.format(Locale.ENGLISH, "%.4f", book.spread)} SAR",
                    fontSize = 10.sp,
                    color = DhabSand
                )
                Text(
                    text = if (isArabic) "انحياز الطلب (Imbalance): ${String.format(Locale.ENGLISH, "%.1f%%", book.imbalance * 100)}" else "Imbalance: ${String.format(Locale.ENGLISH, "%.1f%%", book.imbalance * 100)}",
                    fontSize = 10.sp,
                    color = DhabSand
                )
            }
        }
    }
}

@Composable
fun FXMetalMatrixView(isArabic: Boolean, metal: MetalType) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isArabic) "مصفوفة العملات والمعادن الثنائية" else "FX & Metals Cross-Rate Matrix",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DhabGold
            )
            Spacer(modifier = Modifier.height(10.dp))

            val priceUsd = if (metal == MetalType.GOLD) DhabService.goldPriceUsd.value else DhabService.silverPriceUsd.value

            val rows = listOf("SAR", "AED", "QAR", "KWD")
            rows.forEach { cur ->
                val rate = DhabService.fxRates[cur] ?: 1.0
                val metalPriceGram = (priceUsd / DhabService.TROY_OZ_TO_GRAM) * rate

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .border(0.5.dp, DhabStone.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "${metal.code}/$cur", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = if (isArabic) "مباشر غرام" else "Direct gram rate", fontSize = 9.sp, color = DhabSand)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${String.format(Locale.ENGLISH, "%,.3f", metalPriceGram)} $cur",
                            fontWeight = FontWeight.Bold,
                            color = DhabGold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (isArabic) "عكسي: ${String.format(Locale.ENGLISH, "%,.6f", 1.0 / metalPriceGram)} غ/$cur" else "Inv: ${String.format(Locale.ENGLISH, "%,.6f", 1.0 / metalPriceGram)} g/$cur",
                            fontSize = 9.sp,
                            color = DhabSand
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalAssetsIndicatorView(isArabic: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isArabic) "مؤشرات الأصول والذهب الرقمي" else "Digital Gold Indicators & Arbitrage",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DhabGold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // XAUT
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "XAUT / USD", fontSize = 10.sp, color = DhabSand, fontWeight = FontWeight.Bold)
                        Text(text = String.format(Locale.ENGLISH, "$%,.2f", DhabService.goldPriceUsd.value + 0.15), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "الذهب الرقمي المشفر", fontSize = 9.sp, color = DhabSand)
                    }
                }

                // BTC/XAU
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "BTC / XAU", fontSize = 10.sp, color = DhabSand, fontWeight = FontWeight.Bold)
                        val btcOz = 64000.0 / DhabService.goldPriceUsd.value
                        Text(text = String.format(Locale.ENGLISH, "%.2f oz", btcOz), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "البيتكوين مقابل أونصة ذهب", fontSize = 9.sp, color = DhabSand)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. TRADING SCREEN (RFQ desk, Execution logs, Ledgers)
// -------------------------------------------------------------
@Composable
fun TradingScreen(isArabic: Boolean) {
    var quantityInput by remember { mutableStateOf("100") }
    var selectedMetal by remember { mutableStateOf(MetalType.GOLD) }
    var selectedSide by remember { mutableStateOf(OrderSide.BUY) }

    val activeRfq by DhabService.activeRfq.collectAsState()
    val orders by DhabService.orders.collectAsState()
    val cashLedger by DhabService.cashLedger.collectAsState()
    val metalLedger by DhabService.metalLedger.collectAsState()

    var rfqTimer by remember { mutableStateOf(15) }

    // Tick down simulated RFQ quote expiration in real time
    LaunchedEffect(activeRfq) {
        if (activeRfq != null) {
            rfqTimer = 15
            while (rfqTimer > 0) {
                delay(1000)
                rfqTimer--
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // RFQ Desk card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabGold.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "مكتب التداول الفوري لدار المقاصة (RFQ)" else "OTC RFQ Dealer Desk",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Metal selector
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { selectedMetal = MetalType.GOLD },
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMetal == MetalType.GOLD) DhabGold else MaterialTheme.colorScheme.background,
                                contentColor = if (selectedMetal == MetalType.GOLD) Color.Black else MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text(text = if (isArabic) "ذهب" else "Gold")
                        }

                        Button(
                            onClick = { selectedMetal = MetalType.SILVER },
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMetal == MetalType.SILVER) DhabGold else MaterialTheme.colorScheme.background,
                                contentColor = if (selectedMetal == MetalType.SILVER) Color.Black else MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text(text = if (isArabic) "فضة" else "Silver")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Side selector
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { selectedSide = OrderSide.BUY },
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == OrderSide.BUY) DhabDarkGreen else MaterialTheme.colorScheme.background,
                                contentColor = Color.White
                            )
                        ) {
                            Text(text = if (isArabic) "طلب شراء من الخزينة" else "Request BUY")
                        }

                        Button(
                            onClick = { selectedSide = OrderSide.SELL },
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == OrderSide.SELL) Color.Red else MaterialTheme.colorScheme.background,
                                contentColor = Color.White
                            )
                        ) {
                            Text(text = if (isArabic) "طلب بيع للمكتب" else "Request SELL")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quantity Input
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = { quantityInput = it },
                        label = { Text(text = if (isArabic) "الكمية المطلوبة بالغرام" else "Quantity in Grams") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rfq_quantity_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DhabGold,
                            unfocusedBorderColor = DhabStone
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // RFQ Actions
                    Button(
                        onClick = {
                            val qty = quantityInput.toDoubleOrNull() ?: 100.0
                            DhabService.requestQuote("أحمد العتيبي", selectedMetal, qty, selectedSide, "SAR")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("request_rfq_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
                    ) {
                        Text(text = if (isArabic) "طلب تسعير مقاصة فوري" else "Get Execution Quote", fontWeight = FontWeight.Bold)
                    }

                    // Render Active RFQ Quote with countdown
                    val rfq = activeRfq
                    if (rfq != null) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
                            border = BorderStroke(1.dp, DhabGold)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "معرّف السعر: ${rfq.rfqId}", fontWeight = FontWeight.Bold, color = DhabGold, fontSize = 11.sp)
                                    Text(
                                        text = if (isArabic) "الصلاحية: $rfqTimer ثانية" else "Expires in: $rfqTimer s",
                                        fontWeight = FontWeight.Bold,
                                        color = if (rfqTimer > 5) Color.Green else Color.Red,
                                        fontSize = 11.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = if (isArabic) "السعر الصافي المقترح: ${String.format(Locale.ENGLISH, "%,.2f", rfq.finalPrice)} ريال" else "Proposed Final Value: ${String.format(Locale.ENGLISH, "%,.2f", rfq.finalPrice)} SAR",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = DhabGold
                                )
                                Text(
                                    text = if (isArabic) "شامل المصنعية (${rfq.fabricationFee} ر/غ) والضريبة" else "Incl fabrication fee (${rfq.fabricationFee} SAR/g) and ZATCA tax rules",
                                    fontSize = 10.sp,
                                    color = DhabSand
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Button(
                                        onClick = { DhabService.executeOrder(rfq) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("execute_rfq_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = DhabDarkGreen, contentColor = Color.White)
                                    ) {
                                        Text(text = if (isArabic) "قبول وتنفيذ الصفقة" else "Accept & Execute")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ledger Audit and Reconciliation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "مطابقة دفتر القيد الثنائي (Double-Entry Reconciler)" else "Immutable Double-Entry Ledger Logs",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isArabic) "يتم تدقيق مطابقة حسابات النقد والمعادن بشكل مستقل لضمان ميزان القيد الصفري." else "Both ledgers balance out symmetrically to zero to ensure complete custody safety.",
                        fontSize = 10.sp,
                        color = DhabSand
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = if (isArabic) "أحدث قيود دفتر النقد" else "Recent Cash Ledger", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DhabGold)
                    if (cashLedger.isEmpty()) {
                        Text(text = if (isArabic) "لا توجد قيود نقدية حالية" else "No recent cash entries", fontSize = 11.sp, color = DhabSand, modifier = Modifier.padding(vertical = 4.dp))
                    } else {
                        cashLedger.take(3).forEach { entry ->
                            Text(
                                text = "• [${entry.timestamp}] مدين: ${entry.debitAccount} | دائن: ${entry.creditAccount} | قيمة: ${String.format(Locale.ENGLISH, "%,.1f", entry.amount)} ر",
                                fontSize = 10.sp,
                                color = DhabSand,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = if (isArabic) "أحدث قيود دفتر المعادن" else "Recent Metals Ledger", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DhabGold)
                    if (metalLedger.isEmpty()) {
                        Text(text = if (isArabic) "لا توجد قيود معادن حالية" else "No recent metal entries", fontSize = 11.sp, color = DhabSand, modifier = Modifier.padding(vertical = 4.dp))
                    } else {
                        metalLedger.take(3).forEach { entry ->
                            Text(
                                text = "• [${entry.timestamp}] مدين: ${entry.debitOwner} | دائن: ${entry.creditOwner} | وزن: ${entry.quantityGrams} غ (${entry.metal.arabicName})",
                                fontSize = 10.sp,
                                color = DhabSand,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. VAULT DIGITAL TWIN SCREEN (Serialized bars, barcode twin)
// -------------------------------------------------------------
@Composable
fun VaultScreen(isArabic: Boolean) {
    val bars by DhabService.vaultBars.collectAsState()
    var scanInput by remember { mutableStateOf("") }
    var scannedBar by remember { mutableStateOf<MetalBar?>(null) }

    var transferBarId by remember { mutableStateOf("") }
    var transferNewOwner by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Vault Twin Summary card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DhabDeepNavy),
                border = BorderStroke(1.dp, DhabGold.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "مؤشرات خزائن الخليج الأمنية الرقمية" else "Regional Security Vault Digital Twin",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val allocatedG = bars.filter { it.status == BarStatus.ALLOCATED }.sumOf { it.fineWeight }
                    val availableG = bars.filter { it.status == BarStatus.AVAILABLE }.sumOf { it.fineWeight }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = if (isArabic) "إجمالي الذهب المخصص دفترياً" else "Total Allocated fine gold", fontSize = 10.sp, color = DhabSand)
                            Text(text = "${String.format(Locale.ENGLISH, "%,.1f", allocatedG)} غرام", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DhabGold)
                        }
                        Column {
                            Text(text = if (isArabic) "الذهب المتاح للتداول" else "Available general pool", fontSize = 10.sp, color = DhabSand)
                            Text(text = "${String.format(Locale.ENGLISH, "%,.1f", availableG)} غرام", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // Serialized Bar manual lookup twin
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "مستكشف ومعاير السبائك المخصصة" else "Serialized Bullion Cert Lookup",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = scanInput,
                        onValueChange = { scanInput = it },
                        label = { Text(text = if (isArabic) "أدخل معرّف السبيكة (مثال: SAU-AU-00001842)" else "Enter Bar ID (e.g. SAU-AU-00001842)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bar_lookup_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DhabGold,
                            unfocusedBorderColor = DhabStone
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            scannedBar = bars.find { it.id.trim().equals(scanInput.trim(), ignoreCase = true) }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("lookup_bar_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
                    ) {
                        Text(text = if (isArabic) "البحث والتحقق من الشهادة" else "Verify & Inspect Bar", fontWeight = FontWeight.Bold)
                    }

                    val bar = scannedBar
                    if (bar != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "شهادة السبيكة المعرّفة: ${bar.id}", fontWeight = FontWeight.Bold, color = DhabGold, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "المعدن: ${bar.metal.arabicName} | الوزن الصافي: ${bar.fineWeight} غ", fontSize = 11.sp)
                                Text(text = "النقاء الفني: ${bar.purity} | المصفاة: ${bar.refiner}", fontSize = 11.sp)
                                Text(text = "الموقع الأمني: ${bar.vaultLocation} | المالك دفترياً: ${bar.ownerName}", fontSize = 11.sp)
                                Text(text = "الحالة القانونية: ${bar.status.arabicName}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DhabGold)
                            }
                        }
                    }
                }
            }
        }

        // Book-entry transfer mechanism (Client A -> Client B)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "نقل ملكية السبيكة دفترياً" else "Book-Entry Bullion Ownership Transfer",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = transferBarId,
                        onValueChange = { transferBarId = it },
                        label = { Text(text = if (isArabic) "معرّف السبيكة المطلوب نقل ملكيتها" else "Bar ID to Transfer") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transfer_bar_id_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold, unfocusedBorderColor = DhabStone)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = transferNewOwner,
                        onValueChange = { transferNewOwner = it },
                        label = { Text(text = if (isArabic) "اسم المستلم الجديد" else "New Owner Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transfer_owner_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold, unfocusedBorderColor = DhabStone)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (DhabService.transferBarOwnership(transferBarId, transferNewOwner)) {
                                transferBarId = ""
                                transferNewOwner = ""
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transfer_submit_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
                    ) {
                        Text(text = if (isArabic) "تقييد نقل الملكية فوراً" else "Process Book-Entry Transfer", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Render entire list of vault bars
        item {
            Text(text = if (isArabic) "مخزون السبائك الكامل في الخزينة" else "Full Vault Bar Inventory Ledger", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DhabGold)
        }

        items(bars) { bar ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = bar.id, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DhabGold)
                        Text(text = "${bar.metal.arabicName} | ${bar.fineWeight} غرام | نقاء ${bar.purity}", fontSize = 11.sp, color = DhabSand)
                        Text(text = "موقع: ${bar.vaultLocation} | مالك: ${bar.ownerName}", fontSize = 10.sp, color = DhabSand)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (bar.status == BarStatus.ALLOCATED) DhabDarkGreen.copy(alpha = 0.15f) else DhabGold.copy(alpha = 0.15f))
                            .border(0.5.dp, if (bar.status == BarStatus.ALLOCATED) DhabDarkGreen else DhabGold, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = bar.status.arabicName, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 5. MERCHANT SCREEN (Jewelry mode, e-invoicing adapter, scrap)
// -------------------------------------------------------------
@Composable
fun MerchantScreen(isArabic: Boolean) {
    var jewelryWeight by remember { mutableStateOf("50") }
    var selectedKarat by remember { mutableStateOf("21K") }
    var makingFeeInput by remember { mutableStateOf("1500") } // Manufacturing fee / مصنعية
    var packagingFeeInput by remember { mutableStateOf("250") }

    var calculatedTotal by remember { mutableStateOf(0.0) }
    var generatedInvoice by remember { mutableStateOf<ElectronicInvoice?>(null) }

    val invoices by DhabService.invoices.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Merchant Calculator Panel (tablet style)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "حاسبة تاجر مجوهرات الصاغة والذهب" else "Jewelry Retail Merchant Calculator",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = jewelryWeight,
                        onValueChange = { jewelryWeight = it },
                        label = { Text(text = if (isArabic) "الوزن الإجمالي للمشغولات (غرام)" else "Total Jewelry Weight (grams)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("jewelry_weight_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Karat Selector Dropdown mockup
                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("24K", "22K", "21K", "18K").forEach { karat ->
                            Button(
                                onClick = { selectedKarat = karat },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 2.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedKarat == karat) DhabGold else MaterialTheme.colorScheme.background,
                                    contentColor = if (selectedKarat == karat) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Text(text = karat, fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = makingFeeInput,
                        onValueChange = { makingFeeInput = it },
                        label = { Text(text = if (isArabic) "قيمة المصنعية الإجمالية (ريال)" else "Making Fabrication Fee (SAR)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("making_fee_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val w = jewelryWeight.toDoubleOrNull() ?: 0.0
                            val making = makingFeeInput.toDoubleOrNull() ?: 0.0
                            val packaging = packagingFeeInput.toDoubleOrNull() ?: 0.0

                            val goldFactor = DhabService.getKaratPurity(selectedKarat)
                            val goldGramPrice = DhabService.getPriceInCurrency(MetalType.GOLD, "SAR")

                            // Metal value
                            val metalValue = (w * goldFactor) * goldGramPrice
                            val beforeTax = metalValue + making + packaging
                            // Jewelry standard 15% VAT
                            val vat = beforeTax * 0.15
                            calculatedTotal = beforeTax + vat

                            // Trigger simulated invoice representation
                            generatedInvoice = ElectronicInvoice(
                                invoiceId = "ZAT-RET-" + Random.nextInt(10000, 99999),
                                sellerName = "صاغة نجد التقليدية",
                                sellerTaxId = "300889944111223",
                                buyerName = "عميل نقدي",
                                buyerTaxId = null,
                                issueDate = "2026-10-05 11:20:00",
                                metal = MetalType.GOLD,
                                grossWeight = w,
                                purity = selectedKarat,
                                netWeight = w * goldFactor,
                                unitPrice = goldGramPrice,
                                metalValue = metalValue,
                                makingFee = making,
                                taxCategoryCode = "S", // Standard retail jewellry
                                taxRate = 0.15,
                                taxAmount = vat,
                                grandTotal = calculatedTotal,
                                currency = "SAR",
                                qrCodePayload = "AQpESEFCIEdPTEQDAjE1BAl6YXRjYTExMTIFMjAyNi0xMC0wNVQxMToxMjowMFoHMTU3NTEuMjU="
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("calculate_jewelry_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
                    ) {
                        Text(text = if (isArabic) "حساب السعر وإصدار فاتورة" else "Calculate & Generate Invoice", fontWeight = FontWeight.Bold)
                    }

                    // Render temporary retail invoice
                    val inv = generatedInvoice
                    if (inv != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "فاتورة إلكترونية ضريبية مبسطة", fontWeight = FontWeight.Bold, color = DhabGold)
                                Text(text = "رقم الفاتورة: ${inv.invoiceId}", fontSize = 10.sp, color = DhabSand)
                                Text(text = "البائع: ${inv.sellerName} | الرقم الضريبي: ${inv.sellerTaxId}", fontSize = 10.sp)
                                Divider(modifier = Modifier.padding(vertical = 6.dp))
                                Text(text = "وزن الذهب عيار $selectedKarat: ${inv.grossWeight} غرام", fontSize = 11.sp)
                                Text(text = "القيمة المعدنية: ${String.format(Locale.ENGLISH, "%,.2f", inv.metalValue)} ريال", fontSize = 11.sp)
                                Text(text = "المصنعية والتغليف: ${String.format(Locale.ENGLISH, "%,.2f", inv.makingFee)} ريال", fontSize = 11.sp)
                                Text(text = "ضريبة القيمة المضافة (15%): ${String.format(Locale.ENGLISH, "%,.2f", inv.taxAmount)} ريال", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "الإجمالي الضريبي: ${String.format(Locale.ENGLISH, "%,.2f", inv.grandTotal)} ريال",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = DhabGold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Scrap buy workflow
        item {
            OldGoldScrapWorkflowView(isArabic = isArabic)
        }

        // Historical ZATCA invoice list
        item {
            Text(text = if (isArabic) "أرشيف الفواتير المعتمدة (ZATCA History)" else "ZATCA Historical Invoices", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DhabGold)
        }

        if (invoices.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (isArabic) "لا توجد فواتير تجارية سابقة" else "No matching sales records", color = DhabSand)
                }
            }
        } else {
            items(invoices) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = item.invoiceId, fontWeight = FontWeight.Bold, color = DhabGold)
                            Text(text = item.issueDate, fontSize = 9.sp, color = DhabSand)
                        }
                        Text(text = "المشتري: ${item.buyerName}", fontSize = 11.sp)
                        Text(text = "المعدن: ${item.metal.arabicName} | صافي: ${item.netWeight} غ | الإجمالي: ${String.format(Locale.ENGLISH, "%,.2f", item.grandTotal)} ر.س", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun OldGoldScrapWorkflowView(isArabic: Boolean) {
    var scrapWeight by remember { mutableStateOf("120") }
    var scrapKarat by remember { mutableStateOf("18") }
    var scrapStonesDeduction by remember { mutableStateOf("5") }

    var assessmentResult by remember { mutableStateOf<ScrapAssessment?>(null) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isArabic) "استلام ومعايرة الذهب المستعمل (الكشّاف)" else "Scrap Gold Purchasing Hub",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DhabGold
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = scrapWeight,
                onValueChange = { scrapWeight = it },
                label = { Text(text = if (isArabic) "وزن الذهب الكلي المقبوض (غرام)" else "Raw Scrap Weight") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = scrapKarat,
                onValueChange = { scrapKarat = it },
                label = { Text(text = if (isArabic) "العيار المعلن (مثال: 21, 18)" else "Estimated Karat") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = scrapStonesDeduction,
                onValueChange = { scrapStonesDeduction = it },
                label = { Text(text = if (isArabic) "خصم وزن فصوص وأحجار التغليف (غرام)" else "Stones & Packaging Deduction") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val w = scrapWeight.toDoubleOrNull() ?: 120.0
                    val k = scrapKarat.toIntOrNull() ?: 18
                    val s = scrapStonesDeduction.toDoubleOrNull() ?: 5.0
                    assessmentResult = DhabService.assessScrapGold(w, k, s, 350.0) // 350 SAR refining fee
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
            ) {
                Text(text = if (isArabic) "تحليل العينات عبر مطياف XRF وإصدار تقدير" else "Trigger XRF Assay Spectrogram", fontWeight = FontWeight.Bold)
            }

            val res = assessmentResult
            if (res != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "تقرير الفحص المخبري والتقديري: ${res.ticketId}", fontWeight = FontWeight.Bold, color = DhabGold)
                        Text(text = "تأكيد فحص مطياف الأشعة (XRF): ${String.format(Locale.ENGLISH, "%.2f%%", res.xrfPurityResult?.times(100))}", fontSize = 11.sp, color = DhabDarkGreen, fontWeight = FontWeight.Bold)
                        Text(text = "الذهب الصافي المقدر: ${String.format(Locale.ENGLISH, "%.3f غرام خالص", res.netFineGoldExpected)}", fontSize = 11.sp)
                        Text(text = "رسوم التكرير والتصفية: ${res.refiningFeeSar} ريال", fontSize = 11.sp)
                        Text(
                            text = "القيمة الصافية المقترحة للشراء: ${String.format(Locale.ENGLISH, "%,.2f ريال", res.finalValueSar)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = DhabGold
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 6. ZAKAT SCREEN (ZATCA criteria, Nisab calculations)
// -------------------------------------------------------------
@Composable
fun ZakatScreen(isArabic: Boolean) {
    var gold24Input by remember { mutableStateOf("200") }
    var silverInput by remember { mutableStateOf("0") }
    var cashInput by remember { mutableStateOf("50000") }
    var tradeInput by remember { mutableStateOf("0") }

    var calculationResult by remember { mutableStateOf<ZakatCalculation?>(null) }
    val history by DhabService.zakatCalculations.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Calculator Hub
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, DhabStone.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "حاسبة زكاة المعادن والنقد الاستثماري" else "Gold, Silver & Wealth Zakat Calculator",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DhabGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic) "متوافقة مع منهجية زكاتي للهيئة العامة للزكاة والضريبة والجمارك (ZATCA)" else "Calculated under ZATCA guidelines for financial wealth.",
                        fontSize = 10.sp,
                        color = DhabSand
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = gold24Input,
                        onValueChange = { gold24Input = it },
                        label = { Text(text = if (isArabic) "الذهب الخالص عيار 24 (غرام)" else "24K Gold (grams)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = silverInput,
                        onValueChange = { silverInput = it },
                        label = { Text(text = if (isArabic) "الفضة الخالصة (غرام)" else "Pure Silver (grams)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = cashInput,
                        onValueChange = { cashInput = it },
                        label = { Text(text = if (isArabic) "السيولة النقدية والودائع (ريال)" else "Cash & Liquid Deposits (SAR)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DhabGold)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val g = gold24Input.toDoubleOrNull() ?: 0.0
                            val s = silverInput.toDoubleOrNull() ?: 0.0
                            val cash = cashInput.toDoubleOrNull() ?: 0.0
                            val trade = tradeInput.toDoubleOrNull() ?: 0.0
                            calculationResult = DhabService.calculateZakat(g, s, cash, trade)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("zakat_calculate_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DhabGold, contentColor = Color.Black)
                    ) {
                        Text(text = if (isArabic) "تقدير احتساب الزكاة" else "Perform Zakat Assessment", fontWeight = FontWeight.Bold)
                    }

                    val res = calculationResult
                    if (res != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = if (isArabic) "ملخص احتساب وعاء الزكاة" else "Zakat Assessment Base Summary", fontWeight = FontWeight.Bold, color = DhabGold)
                                Text(text = if (isArabic) "تقييم وعاء الأصول بالريال: ${String.format(Locale.ENGLISH, "%,.2f", res.calculatedBaseSar)} ريال" else "Valued Base Assets: ${String.format(Locale.ENGLISH, "%,.2f", res.calculatedBaseSar)} SAR", fontSize = 11.sp)
                                Text(text = if (isArabic) "مبلغ الزكاة التقديري المستحق (2.5%):" else "Estimated Due (2.5%):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${String.format(Locale.ENGLISH, "%,.2f", res.calculatedAmountSar)} ريال سعودي",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = DhabGold
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { DhabService.saveZakatCalculation(res) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("zakat_save_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = DhabDarkGreen)
                                ) {
                                    Text(text = if (isArabic) "حفظ الحسبة بالأرشيف" else "Archive Calculation Result")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Calculation history list
        item {
            Text(text = if (isArabic) "الأرشيف التاريخي للحسبات" else "Archived Zakat Reports", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DhabGold)
        }

        if (history.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (isArabic) "لا توجد حسبات محفوظة حالياً" else "No saved archived records", color = DhabSand)
                }
            }
        } else {
            items(history) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = item.calculationDate, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(text = if (isArabic) "منهجية الزكاة" else "ZATCA Method", fontSize = 9.sp, color = DhabSand)
                        }
                        Text(text = "وعاء الزكاة المقدر: ${String.format(Locale.ENGLISH, "%,.0f", item.calculatedBaseSar)} ر.س", fontSize = 11.sp)
                        Text(text = "مبلغ الزكاة المدفوع: ${String.format(Locale.ENGLISH, "%,.2f", item.calculatedAmountSar)} ر.س", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DhabGold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 7. FLOAT AI CHAT PANEL AND COMMAND ENGINE
// -------------------------------------------------------------
@Composable
fun AiAssistantPanel(isArabic: Boolean, onClose: () -> Unit) {
    var aiInput by remember { mutableStateOf("") }
    val chatHistory = remember { mutableStateListOf<Pair<String, Boolean>>() } // Boolean: true = User, false = AI
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }

    // Start prompt on first launch if empty
    LaunchedEffect(Unit) {
        if (chatHistory.isEmpty()) {
            chatHistory.add(Pair(if (isArabic) "مرحباً بك! أنا ذَهَب AI خبير المعادن الثمينة المساعد. كيف يمكنني إفادتك في أسعار التداول الفورية، نقاء الذهب عيار 21، تفاصيل الخزائن، أو حساب زكاة مدخراتك اليوم؟" else "Welcome! I am DHAB AI assistant. Ask me anything about gold spot prices, 21K purity engine, regional storage custody or Zakat.", false))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Chat Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.SmartToy, contentDescription = "AI Icon", tint = DhabGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "مساعد ذَهَب الذكي (Gemini 3.5)" else "DHAB Gemini Assistant",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DhabGold
                )
            }
            IconButton(onClick = onClose) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close Panel")
            }
        }

        Divider(color = DhabStone.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

        // History Log
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chatHistory) { (msg, isUser) ->
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) DhabGold.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background
                        ),
                        border = BorderStroke(0.5.dp, if (isUser) DhabGold else DhabStone.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUser) (if (isArabic) "أنت" else "You") else "ذَهَب AI",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = DhabGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = msg, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Box(modifier = Modifier.padding(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = DhabGold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Command Bar / Typing area
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = aiInput,
                onValueChange = { aiInput = it },
                placeholder = { Text(text = if (isArabic) "اسأل ذَهَب أو أدخل أمر تداول..." else "Ask or write a command...", fontSize = 11.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_input_text_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DhabGold,
                    unfocusedBorderColor = DhabStone
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    val prompt = aiInput.trim()
                    if (prompt.isNotEmpty()) {
                        chatHistory.add(Pair(prompt, true))
                        aiInput = ""
                        isLoading = true

                        // Check for smart local command triggers prior to calling Gemini
                        coroutineScope.launch {
                            val resp = GeminiClient.askGemini(prompt)

                            // Apply virtual actions based on AI commands if matched
                            if (prompt.contains("شراء") || prompt.contains("شرا")) {
                                DhabService.executeInstantOrder(MetalType.GOLD, OrderSide.BUY, 10.0, DhabService.getPriceInCurrency(MetalType.GOLD, "SAR"))
                            } else if (prompt.contains("بيع") || prompt.contains("بي")) {
                                DhabService.executeInstantOrder(MetalType.GOLD, OrderSide.SELL, 5.0, DhabService.getPriceInCurrency(MetalType.GOLD, "SAR"))
                            }

                            chatHistory.add(Pair(resp, false))
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier
                    .testTag("ai_send_button")
                    .background(DhabGold, CircleShape)
                    .size(48.dp)
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
            }
        }
    }
}
