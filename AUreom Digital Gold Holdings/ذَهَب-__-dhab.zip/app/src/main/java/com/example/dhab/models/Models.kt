package com.example.dhab.models

import java.util.UUID

// Core Asset Definition
enum class MetalType(val code: String, val arabicName: String) {
    GOLD("XAU", "ذهب"),
    SILVER("XAG", "فضة")
}

// Allocated Physical Bullion
data class MetalBar(
    val id: String,          // SAU-AU-00001842
    val serialNumber: String,
    val metal: MetalType,
    val grossWeight: Double, // in grams
    val fineWeight: Double,  // in grams
    val purity: Double,      // 999.9 or 999.0 or 21K, etc.
    val refiner: String,     // مصفاة جدة الوطنية, مصنع الرياض التجريبي
    val manufactureDate: String,
    val custodian: String,   // خزائن الخليج الأمنية
    val vaultLocation: String,// الرياض 02, دبي 01
    val status: BarStatus,
    val ownerName: String,
    val movementHistory: List<MovementEvent> = emptyList()
)

enum class BarStatus(val arabicName: String) {
    AVAILABLE("متاح"),
    ALLOCATED("مخصص"),
    RESERVED("محجوز"),
    TRANSIT("قيد النقل"),
    UNDER_ASSAY("قيد الفحص"),
    DELIVERED("تم التسليم")
}

data class MovementEvent(
    val timestamp: String,
    val fromLocation: String,
    val toLocation: String,
    val description: String,
    val operatorName: String
)

// Level-2 Order Book Structures
data class OrderBookItem(
    val price: Double,
    val quantity: Double, // in Troy Ounces for markets, or grams
    val orderCount: Int
)

data class OrderBook(
    val metal: MetalType,
    val currency: String,
    val midPrice: Double,
    val asks: List<OrderBookItem>, // Sell offers (sorted ascending)
    val bids: List<OrderBookItem>, // Buy offers (sorted descending)
    val spread: Double,
    val depth: Double,
    val imbalance: Double
)

// Order Management System (OMS)
enum class OrderType(val arabicName: String) {
    MARKET("أمر سوق"),
    LIMIT("أمر محدد"),
    STOP("أمر إيقاف"),
    STOP_LIMIT("أمر إيقاف محدد"),
    IOC("فوري أو إلغاء"),
    FOK("تنفيذ كامل أو إلغاء"),
    DAY("صالح لليوم"),
    GTC("صالح حتى الإلغاء"),
    RFQ("طلب تفاوضي")
}

enum class OrderSide(val arabicName: String) {
    BUY("شراء"),
    SELL("بيع")
}

enum class OrderStatus(val arabicName: String) {
    PENDING("قيد الانتظار"),
    EXECUTED("تم التنفيذ"),
    PARTIALLY_EXECUTED("منفذ جزئياً"),
    CANCELLED("ملغى"),
    FAILED("فشل")
}

data class Order(
    val orderId: String,
    val accountId: String,
    val metal: MetalType,
    val side: OrderSide,
    val type: OrderType,
    val quantity: Double, // grams
    val price: Double?,   // null for market
    val currency: String, // SAR, USD
    val timestamp: String,
    val status: OrderStatus,
    val executionPrice: Double? = null,
    val fee: Double = 0.0
)

// Request For Quote (RFQ)
data class RfqQuote(
    val rfqId: String,
    val clientName: String,
    val metal: MetalType,
    val quantityGrams: Double,
    val side: OrderSide,
    val currency: String,
    val spotPrice: Double,
    val spread: Double,
    val fabricationFee: Double,
    val taxRate: Double,
    val taxAmount: Double,
    val bidPrice: Double, // Customer Buy Price
    val askPrice: Double, // Customer Sell Price
    val finalPrice: Double, // Price according to Side
    val expiryTimestamp: Long, // Epoch millis
    val isExpired: Boolean = false
)

// Double-Entry Ledgers (Cash & Metal MUST balance independently)
data class CashLedgerEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val debitAccount: String,
    val creditAccount: String,
    val amount: Double,
    val currency: String, // SAR, AED, USD
    val description: String,
    val referenceId: String
)

data class MetalLedgerEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val debitOwner: String,
    val creditOwner: String,
    val quantityGrams: Double,
    val metal: MetalType,
    val description: String,
    val referenceId: String
)

// Electronic Invoice (ZATCA style compliant)
data class ElectronicInvoice(
    val invoiceId: String,       // ZAT-2026-XXXXX
    val sellerName: String,      // شركة الرياض للمعادن الثمينة
    val sellerTaxId: String,     // 300123456700003
    val buyerName: String,
    val buyerTaxId: String?,
    val issueDate: String,
    val metal: MetalType,
    val grossWeight: Double,
    val purity: String,
    val netWeight: Double,
    val unitPrice: Double,
    val metalValue: Double,
    val makingFee: Double,
    val taxCategoryCode: String, // 'S' for standard, 'Z' for zero-rated qualifying gold
    val taxRate: Double,
    val taxAmount: Double,
    val grandTotal: Double,
    val currency: String,
    val qrCodePayload: String    // Fictional Base64 ZATCA QR
)

// Zakat Calculation History
data class ZakatCalculation(
    val id: String = UUID.randomUUID().toString(),
    val calculationDate: String,
    val goldWeight24K: Double,
    val silverWeight: Double,
    val cashBalanceSar: Double,
    val tradeInventorySar: Double,
    val goldValuationSar: Double,
    val silverValuationSar: Double,
    val calculatedBaseSar: Double,
    val calculatedAmountSar: Double,
    val methodology: String = "الهيئة العامة للزكاة والضريبة والجمارك (ZATCA)"
)

// Scrap Gold / Old Gold Assessment
data class ScrapAssessment(
    val ticketId: String,
    val receivedDate: String,
    val weightGrams: Double,
    val declaredKarat: Int,
    val estimatedPurity: Double, // e.g. 0.875 for 21K
    val xrfPurityResult: Double?, // XRF spectrometer scan
    val fireAssayResult: Double?, // Lab result
    val stonesWeightDeduction: Double,
    val netFineGoldExpected: Double,
    val refiningFeeSar: Double,
    val currentFinePriceSar: Double,
    val finalValueSar: Double,
    val status: String // "استلام", "فحص", "تسعير", "مكتمل"
)
