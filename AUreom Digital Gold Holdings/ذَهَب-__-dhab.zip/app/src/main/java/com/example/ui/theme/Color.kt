package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium DHAB Palette (Gulf Wealth & Precious Metals)
val DhabGold = Color(0xFFC5A880) // Restrained Gold
val DhabBrightGold = Color(0xFFD4AF37) // Bright bullion gold
val DhabCharcoal = Color(0xFF1A1A1A) // Deep charcoal
val DhabNearBlack = Color(0xFF121212) // Near black background
val DhabWarmIvory = Color(0xFFFAF7F2) // Premium background Light Mode
val DhabStone = Color(0xFFE6E1D8) // Premium border / card outline
val DhabSand = Color(0xFFC4BDB0) // Secondary text in dark mode
val DhabDarkGreen = Color(0xFF1E4620) // Saudi green for profit/success indicators
val DhabDeepNavy = Color(0xFF112233) // Financial terminal contrast

// Legacy Theme Colors re-mapped to avoid build breakage
val Purple80 = DhabGold
val PurpleGrey80 = DhabSand
val Pink80 = DhabBrightGold

val Purple40 = DhabCharcoal
val PurpleGrey40 = DhabStone
val Pink40 = DhabDarkGreen
