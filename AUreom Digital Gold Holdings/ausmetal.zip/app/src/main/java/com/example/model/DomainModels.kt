package com.example.model

import java.math.BigDecimal
import java.util.UUID

enum class AssetType { BAR, COIN }
enum class MetalType { GOLD, SILVER }
enum class AllocationStatus { ALLOCATED, UNALLOCATED }
enum class CustodyStatus { IN_VAULT, IN_TRANSIT, DELIVERED, COLLECTED, UNDER_ASSAY }

data class Product(
    val productId: String,
    val name: String,
    val assetType: AssetType,
    val metal: MetalType,
    val brand: String,
    val refiner: String,
    val purity: Double, // e.g. 999.9 or 999
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val unit: String, // "g", "kg", "oz"
    val premiumPercent: Double,
    val availability: String, // "IN_STOCK", "LOW_STOCK", "PRE_ORDER"
    val warehouse: String,
    val vaultEligible: Boolean = true,
    val deliveryEligible: Boolean = true,
    val collectionEligible: Boolean = true,
    val buybackEligible: Boolean = true,
    val description: String = ""
)

interface PhysicalBar {
    val barId: String
    val serialNumber: String
    val refiner: String
    val brand: String
    val purity: Double
    val grossWeightGrams: Double
    val fineWeightGrams: Double
    val manufactureDate: String
    val assayReference: String
    val owner: String
    val vault: String
    val allocationStatus: AllocationStatus
    val custodyStatus: CustodyStatus
    val valuationAud: Double
    val createdAt: String
    val updatedAt: String
}

data class GoldBar(
    override val barId: String = UUID.randomUUID().toString(),
    override val serialNumber: String,
    override val refiner: String,
    override val brand: String,
    override val purity: Double, // 999.9, etc.
    override val grossWeightGrams: Double,
    override val fineWeightGrams: Double,
    override val manufactureDate: String,
    override val assayReference: String,
    override val owner: String, // "CUSTOMER_DEMO" or "DEALER_INVENTORY"
    override val vault: String, // "Perth Vault", "Sydney Vault", etc.
    override val allocationStatus: AllocationStatus,
    override val custodyStatus: CustodyStatus,
    override val valuationAud: Double,
    override val createdAt: String,
    override val updatedAt: String
) : PhysicalBar

data class SilverBar(
    override val barId: String = UUID.randomUUID().toString(),
    override val serialNumber: String,
    override val refiner: String,
    override val brand: String,
    override val purity: Double, // 999, etc.
    override val grossWeightGrams: Double,
    override val fineWeightGrams: Double,
    override val manufactureDate: String,
    override val assayReference: String,
    override val owner: String,
    override val vault: String,
    override val allocationStatus: AllocationStatus,
    override val custodyStatus: CustodyStatus,
    override val valuationAud: Double,
    override val createdAt: String,
    override val updatedAt: String,
    val isIndustrialSize: Boolean = false // Larger wholesale bars like 5kg, 15kg, 100oz
) : PhysicalBar

data class MetalAccount(
    val metal: MetalType,
    val totalOunces: Double,
    val allocatedOunces: Double,
    val unallocatedOunces: Double,
    val averageAcquisitionPriceAud: Double,
    val currentIndicativeValueAud: Double
)

enum class OrderType { MARKET, LIMIT, RFQ, NEGOTIATED, PHYSICAL_PURCHASE, PHYSICAL_SALE, VAULT_TRANSFER, DELIVERY, COLLECTION }
enum class OrderStatus { NEW, VALIDATING, QUOTED, ACCEPTED, EXECUTED, ALLOCATED, SETTLED, READY, DELIVERED, CANCELLED, FAILED }

data class Order(
    val orderId: String = UUID.randomUUID().toString(),
    val orderType: OrderType,
    val side: String, // "BUY" or "SELL"
    val product: Product?,
    val barId: String? = null, // Specific serialized bar if allocated
    val metalType: MetalType,
    val quantity: Int,
    val totalWeightGrams: Double,
    val totalOunces: Double,
    val unitPriceAud: Double,
    val premiumAud: Double,
    val storageAud: Double,
    val deliveryAud: Double,
    val totalAud: Double,
    val status: OrderStatus,
    val deliveryType: String, // "VAULT", "SECURE_DELIVERY", "CLICK_AND_COLLECT"
    val pickupBranch: String? = null,
    val paymentStatus: String, // "PENDING", "SETTLED", "FAILED"
    val timestamp: String,
    val idempotencyKey: String = UUID.randomUUID().toString()
)

data class RFQ(
    val rfqId: String = UUID.randomUUID().toString(),
    val metal: MetalType,
    val quantityKg: Double,
    val purity: Double,
    val currency: String, // "AUD", "USD", etc.
    val settlementLocation: String, // "Perth", "Sydney", "Melbourne"
    val deliveryType: String, // "Vault", "Domestic"
    val bidAud: Double,
    val offerAud: Double,
    val premiumAud: Double,
    val spreadAud: Double,
    val validitySeconds: Int,
    val settlementTerms: String, // "T+0", "T+1"
    val status: String, // "PENDING", "QUOTED", "ACCEPTED", "EXPIRED"
    val timestamp: String
)

data class AssessmentRequest(
    val requestId: String = UUID.randomUUID().toString(),
    val itemType: String, // "gold jewellery", "nugget", "old bullion", "coin"
    val declaredWeightGrams: Double,
    val estimatedPurity: Double,
    val photoUrlPlaceholder: String = "ic_gold_jewellery",
    val customerDeclaration: String,
    val status: String, // "SUBMITTED", "IN_TRANSIT", "ASSAYING", "OFFERED", "ACCEPTED", "DECLINED"
    val finalOfferAud: Double = 0.0,
    val assayResultId: String? = null,
    val timestamp: String
)

data class MetalAssay(
    val assayId: String = UUID.randomUUID().toString(),
    val grossWeightGrams: Double,
    val purity: Double,
    val fineWeightGrams: Double,
    val method: String, // "XRF", "Fire Assay", "Density", "Manual Inspection", "Refiner Certificate"
    val operator: String,
    val timestamp: String,
    val confidenceScore: Double, // e.g. 0.99
    val resultSummary: String
)

data class VaultTwin(
    val name: String, // "Perth Secure Vault", "Sydney Secure Vault", etc.
    val location: String, // "Perth", "Sydney", etc.
    val capacityTonnes: Double,
    val occupiedWeightTonnes: Double,
    val goldInventoryTonnes: Double,
    val silverInventoryTonnes: Double,
    val customerAllocatedTonnes: Double,
    val customerUnallocatedTonnes: Double,
    val barCount: Int,
    val movementsCount: Int,
    val insuranceStatus: String, // "FULLY_INSURED_LLOYDS", "OPERATIONAL"
    val inspectionStatus: String, // "AUDITED_DELOITTE_2026", "COMPLIANT"
    val status: String // "OPERATIONAL", "MAINTENANCE"
)

data class MetalPassport(
    val serialNumber: String,
    val refiner: String,
    val metal: MetalType,
    val purity: Double,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val assayReference: String,
    val owner: String,
    val vault: String,
    val allocationDate: String,
    val movementHistory: List<String>,
    val currentStatus: String,
    val qrVerificationUrl: String
)

data class LedgerEntry(
    val entryId: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val eventType: String, // "PriceUpdated", "GoldPurchased", etc.
    val debitAccount: String,
    val creditAccount: String,
    val amount: BigDecimal,
    val asset: String, // "AUD", "USD", "XAU_OZ", "XAG_OZ"
    val narration: String,
    val auditHash: String
)

data class ComplianceCase(
    val caseId: String = UUID.randomUUID().toString(),
    val customerName: String,
    val customerType: String,
    val riskScore: Int, // 0 to 100
    val triggerReason: String,
    val transactionsSummary: String,
    val status: String, // "OPEN", "INVESTIGATING", "APPROVED", "REPORTED_AUSTRAC"
    val analyst: String,
    val createdAt: String,
    val resolutionNote: String? = null
)

data class MarketPrice(
    val symbol: String, // XAU/AUD, XAU/USD, XAG/AUD, XAG/USD, AUD/USD, etc.
    val assetClass: String, // "GOLD", "SILVER", "FX"
    val bid: Double,
    val ask: Double,
    val spread: Double,
    val change: Double,
    val changePercentage: Double,
    val timestamp: String,
    val provider: String,
    val marketStatus: String = "ACTIVE"
)

data class TaxRuleVersion(
    val ruleVersion: String,
    val effectiveFrom: String,
    val effectiveTo: String,
    val jurisdiction: String, // "Commonwealth of Australia"
    val gstRateBullionPercent: Double = 0.0, // Bullion is GST-free if gold >= 99.5%, silver >= 99.9%
    val gstRateStandardPercent: Double = 10.0, // Standard GST is 10% on freight/freight services/taxable products
    val description: String
)
