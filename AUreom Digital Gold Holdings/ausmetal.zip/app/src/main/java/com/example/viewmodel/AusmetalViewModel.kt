package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.service.MerchantService
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AusmetalUiState(
    // Market Price State
    val marketPrices: List<MarketPrice> = emptyList(),
    val marketStatus: String = "ACTIVE",
    val selectedCurrency: String = "AUD",
    val currencyRates: Map<String, Double> = mapOf(
        "AUD" to 1.0, "USD" to 0.65, "EUR" to 0.59, "GBP" to 0.49,
        "NZD" to 1.08, "SGD" to 0.88, "HKD" to 5.08, "CNY" to 4.72,
        "JPY" to 96.50, "CHF" to 0.58
    ),

    // Products State
    val products: List<Product> = emptyList(),

    // Customer Profile & Compliance State
    val customerName: String = "Harrison Vance",
    val customerTier: String = "VERIFIED", // Personal, Verified, Professional, Business, Institution, Trust, Super Fund
    val isKycApproved: Boolean = true,
    val sourceOfFunds: String = "Wealth from Mineral Exploration",
    val expectedAnnualVolume: String = "$100k - $500k AUD",
    val complianceCases: List<ComplianceCase> = emptyList(),

    // Customer Portfolio & Asset State
    val cashBalanceAud: Double = 8420.0,
    val goldAllocatedOz: Double = 8.0,
    val goldUnallocatedOz: Double = 4.481,
    val silverAllocatedOz: Double = 200.0,
    val silverUnallocatedOz: Double = 45.20,
    val avgGoldAcquisitionPriceOz: Double = 4812.0,
    val avgSilverAcquisitionPriceOz: Double = 52.50,
    val allocatedGoldBars: List<GoldBar> = emptyList(),
    val allocatedSilverBars: List<SilverBar> = emptyList(),

    // Vault Digital Twin State
    val vaults: List<VaultTwin> = emptyList(),
    val physicalGoldOuncesInVault: Double = 250000.0, // Institutional Pool Cover
    val physicalSilverOuncesInVault: Double = 1200000.0,

    // Operations and Trading
    val orders: List<Order> = emptyList(),
    val rfqs: List<RFQ> = emptyList(),
    val doubleEntryLedger: List<LedgerEntry> = emptyList(),
    val goldJewelleryRequests: List<AssessmentRequest> = emptyList(),

    // Demonstration Scenario Step Walkthrough
    val demoStep: Int = 0,
    val demoLogs: List<String> = emptyList(),
    val lastGeneratedDocument: String? = null,
    val docType: String? = null,

    // API & Observability Log Simulation
    val restApiLogs: List<String> = emptyList(),
    val wsConsoleLogs: List<String> = emptyList(),

    // Scenario Lab
    val activeScenario: String = "Normal Market Conditions",
    val systemReconciliationStatus: String = "SYSTEM_RECONCILED"
)

class AusmetalViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(AusmetalUiState())
    val uiState: StateFlow<AusmetalUiState> = _uiState.asStateFlow()

    private val ledger = MerchantService.DoubleEntryLedger()
    private var priceSimJob: Job? = null

    init {
        // Seed initial data
        seedInitialData()
        // Start live ticker simulation
        startPriceSimulation()
    }

    private fun seedInitialData() {
        // Create initial products
        val goldProducts = listOf(
            Product("G-BAR-100G", "100g 999.9 Gold Investment Bar", AssetType.BAR, MetalType.GOLD, "Ausmetal", "Synthetic Australian Refinery", 999.9, 100.0, 100.0, "g", 1.8, "IN_STOCK", "Perth Warehouse"),
            Product("G-BAR-1KG", "1kg 999.9 Gold Bullion Bar", AssetType.BAR, MetalType.GOLD, "Ausmetal", "Synthetic Australian Refinery", 999.9, 1000.0, 1000.0, "kg", 1.2, "IN_STOCK", "Sydney Warehouse"),
            Product("G-COIN-1OZ", "1oz Gold Kangaroo Bullion Coin", AssetType.COIN, MetalType.GOLD, "Ausmetal", "Synthetic Minting Facility", 999.9, 31.103, 31.103, "oz", 3.5, "IN_STOCK", "Melbourne Warehouse"),
            Product("S-BAR-1KG", "1kg 999.0 Silver Bullion Bar", AssetType.BAR, MetalType.SILVER, "Ausmetal", "Synthetic Australian Refinery", 999.0, 1000.0, 1000.0, "kg", 4.2, "IN_STOCK", "Perth Warehouse"),
            Product("S-BAR-5KG", "5kg Industrial Silver Bullion Bar", AssetType.BAR, MetalType.SILVER, "Ausmetal", "Synthetic Industrial Refinery", 999.0, 5000.0, 5000.0, "kg", 3.5, "IN_STOCK", "Sydney Warehouse"),
            Product("S-COIN-1OZ", "1oz Silver Koala Bullion Coin", AssetType.COIN, MetalType.SILVER, "Ausmetal", "Synthetic Minting Facility", 999.9, 31.103, 31.103, "oz", 6.0, "LOW_STOCK", "Adelaide Warehouse")
        )

        // Initial Allocated Bars for Customer Demo
        val initialGoldBars = listOf(
            GoldBar(
                barId = "AU-BAR-000421",
                serialNumber = "AU-000421",
                refiner = "Synthetic Australian Refinery",
                brand = "AUSMETAL PREMIUM",
                purity = 999.9,
                grossWeightGrams = 100.0,
                fineWeightGrams = 100.0,
                manufactureDate = "2026-03-12",
                assayReference = "ASSAY-44281",
                owner = "CUSTOMER_DEMO",
                vault = "Perth Secure Vault",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.IN_VAULT,
                valuationAud = 17420.0,
                createdAt = "2026-04-01 10:00:00",
                updatedAt = "2026-04-01 10:00:00"
            ),
            GoldBar(
                barId = "AU-BAR-000552",
                serialNumber = "AU-000552",
                refiner = "Synthetic Australian Refinery",
                brand = "AUSMETAL SECURE",
                purity = 999.9,
                grossWeightGrams = 148.6,
                fineWeightGrams = 148.6,
                manufactureDate = "2026-05-20",
                assayReference = "ASSAY-44912",
                owner = "CUSTOMER_DEMO",
                vault = "Perth Secure Vault",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.IN_VAULT,
                valuationAud = 25880.0,
                createdAt = "2026-05-25 11:30:00",
                updatedAt = "2026-05-25 11:30:00"
            )
        )

        val initialSilverBars = listOf(
            SilverBar(
                barId = "AG-BAR-110291",
                serialNumber = "AG-110291",
                refiner = "Synthetic Industrial Refinery",
                brand = "AUSMETAL BULK",
                purity = 999.0,
                grossWeightGrams = 1000.0, // 1kg
                fineWeightGrams = 999.0,
                manufactureDate = "2026-01-15",
                assayReference = "ASSAY-SILVER-99",
                owner = "CUSTOMER_DEMO",
                vault = "Sydney Secure Vault",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.IN_VAULT,
                valuationAud = 2180.0,
                createdAt = "2026-02-01 09:15:00",
                updatedAt = "2026-02-01 09:15:00"
            ),
            SilverBar(
                barId = "AG-BAR-220455",
                serialNumber = "AG-220455",
                refiner = "Synthetic Industrial Refinery",
                brand = "AUSMETAL BULK",
                purity = 999.0,
                grossWeightGrams = 5220.0, // 5.22kg
                fineWeightGrams = 5214.78,
                manufactureDate = "2026-02-18",
                assayReference = "ASSAY-SILVER-102",
                owner = "CUSTOMER_DEMO",
                vault = "Sydney Secure Vault",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.IN_VAULT,
                valuationAud = 11380.0,
                createdAt = "2026-03-05 14:22:00",
                updatedAt = "2026-03-05 14:22:00",
                isIndustrialSize = true
            )
        )

        // 5 Fictional Private Vaults across major Australian cities
        val initialVaults = listOf(
            VaultTwin("Perth Secure Vault", "Perth", 100.0, 91.2, 18.42, 72.8, 7.84, 8.76, 12450, 41200, "FULLY_INSURED_LLOYDS", "AUDITED_DELOITTE_2026", "OPERATIONAL"),
            VaultTwin("Sydney Secure Vault", "Sydney", 150.0, 110.5, 34.12, 76.38, 12.15, 14.20, 18900, 56300, "FULLY_INSURED_LLOYDS", "AUDITED_DELOITTE_2026", "OPERATIONAL"),
            VaultTwin("Melbourne Private Vault", "Melbourne", 80.0, 48.3, 14.80, 33.50, 5.40, 6.22, 9400, 29100, "FULLY_INSURED_LLOYDS", "AUDITED_DELOITTE_2026", "OPERATIONAL"),
            VaultTwin("Brisbane Bullion Depository", "Brisbane", 50.0, 22.1, 4.10, 18.00, 2.10, 3.50, 4200, 12800, "FULLY_INSURED_LLOYDS", "AUDITED_EY_2026", "OPERATIONAL"),
            VaultTwin("Adelaide Vault Facility", "Adelaide", 40.0, 15.4, 3.20, 12.20, 1.80, 2.40, 2900, 8400, "FULLY_INSURED_LLOYDS", "AUDITED_EY_2026", "OPERATIONAL")
        )

        val initialPrices = listOf(
            MarketPrice("XAU/AUD", "GOLD", 5395.12, 5420.80, 25.68, 38.60, 0.72, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAU/USD", "GOLD", 3506.82, 3523.52, 16.70, 25.10, 0.72, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAU/EUR", "GOLD", 3185.20, 3200.35, 15.15, 22.85, 0.72, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAU/GBP", "GOLD", 2645.10, 2657.70, 12.60, 18.95, 0.72, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAG/AUD", "SILVER", 67.54, 68.42, 0.88, 0.89, 1.31, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAG/USD", "SILVER", 43.90, 44.47, 0.57, 0.58, 1.31, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("XAG/EUR", "SILVER", 39.87, 40.39, 0.52, 0.52, 1.31, "2026-10-06 09:30:00", "Synthetic Reserve Broker"),
            MarketPrice("AUD/USD", "FX", 0.6500, 0.6505, 0.0005, 0.0032, 0.49, "2026-10-06 09:30:00", "Reserve Bank Simulator"),
            MarketPrice("AUD/GBP", "FX", 0.4900, 0.4903, 0.0003, 0.0011, 0.22, "2026-10-06 09:30:00", "Reserve Bank Simulator"),
            MarketPrice("AUD/EUR", "FX", 0.5900, 0.5904, 0.0004, -0.0005, -0.08, "2026-10-06 09:30:00", "Reserve Bank Simulator"),
            MarketPrice("AUD/JPY", "FX", 96.50, 96.55, 0.0500, 0.8200, 0.85, "2026-10-06 09:30:00", "Reserve Bank Simulator"),
            MarketPrice("AUD/CNY", "FX", 4.720, 4.724, 0.0040, 0.0120, 0.25, "2026-10-06 09:30:00", "Reserve Bank Simulator")
        )

        // Seed some historical ledger entries for double entry integrity
        ledger.postTransaction("CAPITAL_INFLOW", "DEALER_RESERVE", "CUSTOMER_CASH", 50000.0, "AUD", "Initial cash deposit seed")
        ledger.postTransaction("ASSET_MINT", "DEALER_VAULT", "DEALER_INVENTORY", 1000.0, "XAU_OZ", "Initial bulk gold reserve minting")
        ledger.postTransaction("ASSET_MINT", "DEALER_VAULT", "DEALER_INVENTORY", 5000.0, "XAG_OZ", "Initial bulk silver reserve minting")

        // Purchase entry for existing gold/silver holdings
        ledger.postTransaction("GOLD_PURCHASE", "DEALER_INVENTORY", "CUSTOMER_GOLD_ALLOCATED", 8.0, "XAU_OZ", "Customer allocation of 8oz gold bars")
        ledger.postTransaction("GOLD_PURCHASE", "DEALER_INVENTORY", "CUSTOMER_GOLD_UNALLOCATED", 4.481, "XAU_OZ", "Customer unallocated gold pool")
        ledger.postTransaction("SILVER_PURCHASE", "DEALER_INVENTORY", "CUSTOMER_SILVER_ALLOCATED", 200.0, "XAG_OZ", "Customer allocation of 200oz silver bars")
        ledger.postTransaction("SILVER_PURCHASE", "DEALER_INVENTORY", "CUSTOMER_SILVER_UNALLOCATED", 45.20, "XAG_OZ", "Customer unallocated silver pool")

        _uiState.value = AusmetalUiState(
            marketPrices = initialPrices,
            products = goldProducts,
            allocatedGoldBars = initialGoldBars,
            allocatedSilverBars = initialSilverBars,
            vaults = initialVaults,
            doubleEntryLedger = ledger.getEntries()
        )
    }

    private fun startPriceSimulation() {
        priceSimJob = viewModelScope.launch {
            while (true) {
                delay(8000) // update prices every 8s
                tickMarketPrices()
            }
        }
    }

    private fun tickMarketPrices() {
        val rand = Random()
        val changeFactor = 1.0 + (rand.nextDouble() - 0.48) * 0.002 // slight upward drift on average

        val updatedPrices = _uiState.value.marketPrices.map { price ->
            val changeVal = (price.ask * (changeFactor - 1.0))
            val newAsk = price.ask + changeVal
            val newBid = price.bid + (changeVal * 0.99)
            val newSpread = Math.max(0.01, newAsk - newBid)
            val percentage = (changeFactor - 1.0) * 100.0

            price.copy(
                bid = Math.round(newBid * 100.0) / 100.0,
                ask = Math.round(newAsk * 100.0) / 100.0,
                spread = Math.round(newSpread * 100.0) / 100.0,
                change = Math.round(changeVal * 100.0) / 100.0,
                changePercentage = Math.round(percentage * 100.0) / 100.0,
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )
        }

        // Add WebSocket and REST simulation logs
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val wsLog = "WS [prices] Broadcast: XAU/AUD: $${"%,.2f".format(updatedPrices[0].ask)} oz | XAG/AUD: $${"%,.2f".format(updatedPrices[4].ask)} oz | AUD/USD: ${"%.4f".format(updatedPrices[7].ask)}"
        val restLog = "REST API: GET /api/v1/prices - Status 200 OK - Response in 4.2ms"

        val updatedWs = (_uiState.value.wsConsoleLogs + wsLog).takeLast(30)
        val updatedRest = (_uiState.value.restApiLogs + restLog).takeLast(30)

        _uiState.value = _uiState.value.copy(
            marketPrices = updatedPrices,
            wsConsoleLogs = updatedWs,
            restApiLogs = updatedRest
        )

        // Run double-entry balance check and reconciliation
        reconcileSystems()
    }

    fun selectCurrency(currency: String) {
        if (_uiState.value.currencyRates.containsKey(currency)) {
            _uiState.value = _uiState.value.copy(selectedCurrency = currency)
        }
    }

    // 6. SCENARIO LABORATORY
    fun runScenario(scenarioName: String) {
        val rand = Random()
        val currentPrices = _uiState.value.marketPrices
        val updatedPrices = currentPrices.map { price ->
            val multiplier = when (scenarioName) {
                "Gold +10%" -> if (price.assetClass == "GOLD") 1.10 else 1.0
                "Gold -10%" -> if (price.assetClass == "GOLD") 0.90 else 1.0
                "Silver +25%" -> if (price.assetClass == "SILVER") 1.25 else 1.0
                "Silver -25%" -> if (price.assetClass == "SILVER") 0.75 else 1.0
                "AUD strengthens" -> if (price.symbol == "AUD/USD") 1.08 else if (price.assetClass != "FX") 0.94 else 1.0
                "AUD weakens" -> if (price.symbol == "AUD/USD") 0.92 else if (price.assetClass != "FX") 1.06 else 1.0
                "Dealer liquidity shock" -> {
                    // Spread widens heavily
                    return@map price.copy(
                        spread = price.spread * 4.0,
                        ask = price.ask + price.spread * 1.5,
                        bid = price.bid - price.spread * 1.5,
                        timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                    )
                }
                else -> 1.0
            }

            val newAsk = price.ask * multiplier
            val newBid = price.bid * multiplier
            val newSpread = Math.max(0.01, newAsk - newBid)
            price.copy(
                bid = Math.round(newBid * 100.0) / 100.0,
                ask = Math.round(newAsk * 100.0) / 100.0,
                spread = Math.round(newSpread * 100.0) / 100.0,
                changePercentage = if (multiplier != 1.0) (multiplier - 1.0) * 100.0 else price.changePercentage,
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )
        }

        // Recalculate vault twin values & customer allocations
        val logMsg = "SCENARIO TRIGGERED: [$scenarioName] executed at system level. Recalculating portfolio analytics..."
        _uiState.value = _uiState.value.copy(
            marketPrices = updatedPrices,
            activeScenario = scenarioName,
            restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/compliance/scenarios - Status 200 - Triggered $scenarioName").takeLast(30),
            demoLogs = _uiState.value.demoLogs + logMsg
        )
        reconcileSystems()
    }

    // 7. INSTITUTIONAL RFQ ENGINE
    fun submitRfq(metalType: MetalType, quantityKg: Double, purity: Double, currency: String, deliveryType: String) {
        val spotPrice = getSpotPriceAud(metalType)
        // 1kg = 32.1507 troy ounces
        val ouncesPerKg = 32.1507466
        val rawMetalValue = spotPrice * ouncesPerKg * quantityKg

        val premiumPercent = if (quantityKg >= 100.0) 0.005 else 0.012 // scale efficiency
        val premiumVal = rawMetalValue * premiumPercent
        val spreadVal = rawMetalValue * 0.003 // narrow institutional spread

        val offerVal = rawMetalValue + premiumVal + (spreadVal / 2)
        val bidVal = rawMetalValue - (spreadVal / 2)

        val newRfq = RFQ(
            rfqId = "RFQ-" + UUID.randomUUID().toString().take(6).uppercase(),
            metal = metalType,
            quantityKg = quantityKg,
            purity = purity,
            currency = currency,
            settlementLocation = if (metalType == MetalType.GOLD) "Perth" else "Sydney",
            deliveryType = deliveryType,
            bidAud = Math.round(bidVal * 100.0) / 100.0,
            offerAud = Math.round(offerVal * 100.0) / 100.0,
            premiumAud = Math.round(premiumVal * 100.0) / 100.0,
            spreadAud = Math.round(spreadVal * 100.0) / 100.0,
            validitySeconds = 30,
            settlementTerms = "T+1",
            status = "QUOTED",
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        )

        _uiState.value = _uiState.value.copy(
            rfqs = listOf(newRfq) + _uiState.value.rfqs,
            restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/rfq - Quoted RFQ ${newRfq.rfqId}").takeLast(30)
        )
    }

    fun acceptRfq(rfqId: String) {
        val activeRfqs = _uiState.value.rfqs.map {
            if (it.rfqId == rfqId && it.status == "QUOTED") {
                // Post in ledger & deduct/add cash and metal
                val ozBought = it.quantityKg * 32.1507466
                val totalCost = it.offerAud

                if (_uiState.value.cashBalanceAud >= totalCost) {
                    ledger.postTransaction("RFQ_ACCEPTED", "CUSTOMER_CASH", "DEALER_INVENTORY", totalCost, "AUD", "Institutional RFQ ${it.rfqId} purchase")
                    
                    val metalAccountName = if (it.metal == MetalType.GOLD) "CUSTOMER_GOLD_UNALLOCATED" else "CUSTOMER_SILVER_UNALLOCATED"
                    ledger.postTransaction("RFQ_METAL_DELIVERED", "DEALER_INVENTORY", metalAccountName, ozBought, if (it.metal == MetalType.GOLD) "XAU_OZ" else "XAG_OZ", "Institutional RFQ ${it.rfqId} metal allocation")

                    _uiState.value = _uiState.value.copy(
                        cashBalanceAud = _uiState.value.cashBalanceAud - totalCost,
                        goldUnallocatedOz = if (it.metal == MetalType.GOLD) _uiState.value.goldUnallocatedOz + ozBought else _uiState.value.goldUnallocatedOz,
                        silverUnallocatedOz = if (it.metal == MetalType.SILVER) _uiState.value.silverUnallocatedOz + ozBought else _uiState.value.silverUnallocatedOz,
                        restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/orders - Generated from RFQ $rfqId - Executed").takeLast(30)
                    )
                    it.copy(status = "ACCEPTED")
                } else {
                    it.copy(status = "FAILED_INSUFFICIENT_FUNDS")
                }
            } else {
                it
            }
        }
        _uiState.value = _uiState.value.copy(rfqs = activeRfqs, doubleEntryLedger = ledger.getEntries())
        reconcileSystems()
    }

    // 8. BUYBullion WORKFLOW
    fun executePurchase(product: Product, quantity: Int, deliveryType: String, pickupBranch: String?) {
        val spotPrice = getSpotPriceAud(product.metal)
        
        // Calculate raw components
        val audUsdRate = _uiState.value.marketPrices.firstOrNull { it.symbol == "AUD/USD" }?.ask ?: 0.65
        val spotPriceUsd = spotPrice * audUsdRate

        val isStorage = deliveryType == "VAULT"
        val isDelivery = deliveryType == "SECURE_DELIVERY"

        val pricingDetails = MerchantService.PricingEngine.calculateCustomerPrice(
            product = product,
            spotPriceUsdPerOz = spotPriceUsd,
            audUsdRate = audUsdRate,
            quantity = quantity,
            isStorageChosen = isStorage,
            isDeliveryChosen = isDelivery
        )

        val subtotal = pricingDetails["subtotal_aud"] ?: 0.0
        val deliveryFee = pricingDetails["delivery_aud"] ?: 0.0
        val storageFee = pricingDetails["storage_aud"] ?: 0.0
        val totalWithoutTax = subtotal + deliveryFee + storageFee

        // Tax details
        val taxDetails = MerchantService.TaxEngine.calculateTax(product, subtotal, deliveryFee)
        val totalTax = taxDetails["total_gst"] as? Double ?: 0.0
        val grandTotal = totalWithoutTax + totalTax

        if (_uiState.value.cashBalanceAud >= grandTotal) {
            val totalWeightGrams = product.grossWeightGrams * quantity
            val totalOunces = totalWeightGrams / 31.1034768

            // Process Synthetic Payment
            val payRef = "PAY-" + UUID.randomUUID().toString().take(6).uppercase()
            val payRes = MerchantService.PaymentAdapters.processPayment("PayID", grandTotal, payRef)

            // Evaluate Compliance AML/KYC
            val amlCase = MerchantService.ComplianceEngine.evaluateTransactionForAml(
                customerName = _uiState.value.customerName,
                customerType = "PERSONAL",
                amountAud = grandTotal,
                metalType = product.metal,
                quantity = totalOunces,
                paymentMethod = "PayID",
                deliveryType = deliveryType
            )

            // Double Entry Ledgers
            ledger.postTransaction("METAL_BUY_CASH", "CUSTOMER_CASH", "DEALER_REVENUE", grandTotal - totalTax, "AUD", "Purchase of ${product.name} x$quantity")
            if (totalTax > 0.0) {
                ledger.postTransaction("TAX_GST_POST", "CUSTOMER_CASH", "ATO_GST_COLLECTED", totalTax, "AUD", "GST on non-bullion / freight for ${product.name}")
            }

            // Metal Leg Posting
            val metalAccountDest = if (isStorage) {
                if (product.metal == MetalType.GOLD) "CUSTOMER_GOLD_ALLOCATED" else "CUSTOMER_SILVER_ALLOCATED"
            } else {
                "CUSTOMER_METALS_DISPATCHED"
            }
            ledger.postTransaction("METAL_BUY_METAL", "DEALER_VAULT", metalAccountDest, totalOunces, if (product.metal == MetalType.GOLD) "XAU_OZ" else "XAG_OZ", "Metal transfer for ${product.name}")

            // Allocate a physical bar if it's stored in vault
            var allocatedGoldBar: GoldBar? = null
            var allocatedSilverBar: SilverBar? = null

            if (isStorage) {
                if (product.metal == MetalType.GOLD) {
                    allocatedGoldBar = GoldBar(
                        serialNumber = "AU-00" + (400 + _uiState.value.allocatedGoldBars.size + 1),
                        refiner = product.refiner,
                        brand = product.brand,
                        purity = product.purity,
                        grossWeightGrams = product.grossWeightGrams * quantity,
                        fineWeightGrams = product.fineWeightGrams * quantity,
                        manufactureDate = "2026-09-01",
                        assayReference = "ASSAY-" + (40000 + _uiState.value.allocatedGoldBars.size + 1),
                        owner = "CUSTOMER_DEMO",
                        vault = "Perth Secure Vault",
                        allocationStatus = AllocationStatus.ALLOCATED,
                        custodyStatus = CustodyStatus.IN_VAULT,
                        valuationAud = grandTotal,
                        createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
                        updatedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                    )
                } else {
                    allocatedSilverBar = SilverBar(
                        serialNumber = "AG-11" + (200 + _uiState.value.allocatedSilverBars.size + 1),
                        refiner = product.refiner,
                        brand = product.brand,
                        purity = product.purity,
                        grossWeightGrams = product.grossWeightGrams * quantity,
                        fineWeightGrams = product.fineWeightGrams * quantity,
                        manufactureDate = "2026-09-01",
                        assayReference = "ASSAY-SILVER-" + (200 + _uiState.value.allocatedSilverBars.size + 1),
                        owner = "CUSTOMER_DEMO",
                        vault = "Sydney Secure Vault",
                        allocationStatus = AllocationStatus.ALLOCATED,
                        custodyStatus = CustodyStatus.IN_VAULT,
                        valuationAud = grandTotal,
                        createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
                        updatedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                    )
                }
            }

            // Create Order
            val newOrder = Order(
                orderType = OrderType.PHYSICAL_PURCHASE,
                side = "BUY",
                product = product,
                barId = allocatedGoldBar?.barId ?: allocatedSilverBar?.barId,
                metalType = product.metal,
                quantity = quantity,
                totalWeightGrams = totalWeightGrams,
                totalOunces = totalOunces,
                unitPriceAud = spotPrice * totalOunces,
                premiumAud = pricingDetails["product_premium_aud"] ?: 0.0,
                storageAud = storageFee,
                deliveryAud = deliveryFee,
                totalAud = grandTotal,
                status = if (isStorage) OrderStatus.ALLOCATED else OrderStatus.ACCEPTED,
                deliveryType = deliveryType,
                pickupBranch = pickupBranch,
                paymentStatus = "SETTLED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )

            // Update UI State
            _uiState.value = _uiState.value.copy(
                cashBalanceAud = _uiState.value.cashBalanceAud - grandTotal,
                orders = listOf(newOrder) + _uiState.value.orders,
                complianceCases = if (amlCase != null) _uiState.value.complianceCases + amlCase else _uiState.value.complianceCases,
                allocatedGoldBars = if (allocatedGoldBar != null) _uiState.value.allocatedGoldBars + allocatedGoldBar else _uiState.value.allocatedGoldBars,
                allocatedSilverBars = if (allocatedSilverBar != null) _uiState.value.allocatedSilverBars + allocatedSilverBar else _uiState.value.allocatedSilverBars,
                goldUnallocatedOz = if (!isStorage && product.metal == MetalType.GOLD) _uiState.value.goldUnallocatedOz else if (isStorage && product.metal == MetalType.GOLD) _uiState.value.goldUnallocatedOz else _uiState.value.goldUnallocatedOz,
                doubleEntryLedger = ledger.getEntries(),
                restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/buy - Status 201 Created - Order ${newOrder.orderId} processed").takeLast(30)
            )

            // Auto Generate Document Confirmation
            generateDocument(newOrder, "PURCHASE_CONFIRMATION")
        } else {
            // Insufficient balance
            _uiState.value = _uiState.value.copy(
                demoLogs = _uiState.value.demoLogs + "ORDER FAILED: Insufficient AUD cash balance to purchase ${product.name}."
            )
        }
        reconcileSystems()
    }

    // 9. SELL Bullion WORKFLOW
    fun executeSellBar(barId: String, metalType: MetalType) {
        val spotPrice = getSpotPriceAud(metalType)
        val barValuation: Double
        val ounces: Double
        val serial: String

        if (metalType == MetalType.GOLD) {
            val bar = _uiState.value.allocatedGoldBars.firstOrNull { it.barId == barId } ?: return
            ounces = bar.grossWeightGrams / 31.1034768
            serial = bar.serialNumber
            barValuation = ounces * spotPrice * 0.985 // dealer bid discount
        } else {
            val bar = _uiState.value.allocatedSilverBars.firstOrNull { it.barId == barId } ?: return
            ounces = bar.grossWeightGrams / 31.1034768
            serial = bar.serialNumber
            barValuation = ounces * spotPrice * 0.96 // dealer silver bid discount
        }

        // Ledger post
        ledger.postTransaction("METAL_SELL_CASH", "DEALER_RESERVE", "CUSTOMER_CASH", barValuation, "AUD", "Purchase-back of bar $serial")
        ledger.postTransaction("METAL_SELL_METAL", "CUSTOMER_GOLD_ALLOCATED", "DEALER_VAULT", ounces, if (metalType == MetalType.GOLD) "XAU_OZ" else "XAG_OZ", "Release of allocated bar $serial to dealer inventory")

        val newOrder = Order(
            orderType = OrderType.PHYSICAL_SALE,
            side = "SELL",
            product = null,
            barId = barId,
            metalType = metalType,
            quantity = 1,
            totalWeightGrams = ounces * 31.1034,
            totalOunces = ounces,
            unitPriceAud = spotPrice,
            premiumAud = 0.0,
            storageAud = 0.0,
            deliveryAud = 0.0,
            totalAud = barValuation,
            status = OrderStatus.SETTLED,
            deliveryType = "VAULT",
            paymentStatus = "SETTLED",
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        )

        _uiState.value = _uiState.value.copy(
            cashBalanceAud = _uiState.value.cashBalanceAud + barValuation,
            orders = listOf(newOrder) + _uiState.value.orders,
            allocatedGoldBars = if (metalType == MetalType.GOLD) _uiState.value.allocatedGoldBars.filter { it.barId != barId } else _uiState.value.allocatedGoldBars,
            allocatedSilverBars = if (metalType == MetalType.SILVER) _uiState.value.allocatedSilverBars.filter { it.barId != barId } else _uiState.value.allocatedSilverBars,
            doubleEntryLedger = ledger.getEntries(),
            restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/sell - Status 200 OK - Sold allocated bar $serial for $${"%,.2f".format(barValuation)}").takeLast(30)
        )

        generateDocument(newOrder, "SALES_CONFIRMATION")
        reconcileSystems()
    }

    // Sell unallocated metal
    fun executeSellUnallocated(metalType: MetalType, ouncesToSell: Double) {
        val spotPrice = getSpotPriceAud(metalType)
        val currentUnallocated = if (metalType == MetalType.GOLD) _uiState.value.goldUnallocatedOz else _uiState.value.silverUnallocatedOz

        if (currentUnallocated >= ouncesToSell) {
            val dealerDiscount = if (metalType == MetalType.GOLD) 0.99 else 0.97 // wholesale unallocated spreads
            val proceeds = ouncesToSell * spotPrice * dealerDiscount

            ledger.postTransaction("METAL_SELL_CASH", "DEALER_RESERVE", "CUSTOMER_CASH", proceeds, "AUD", "Sell back of $ouncesToSell oz unallocated ${metalType.name}")
            val metalAcct = if (metalType == MetalType.GOLD) "CUSTOMER_GOLD_UNALLOCATED" else "CUSTOMER_SILVER_UNALLOCATED"
            ledger.postTransaction("METAL_SELL_METAL", metalAcct, "DEALER_VAULT", ouncesToSell, if (metalType == MetalType.GOLD) "XAU_OZ" else "XAG_OZ", "Unallocated pool reduction")

            val newOrder = Order(
                orderType = OrderType.PHYSICAL_SALE,
                side = "SELL",
                product = null,
                metalType = metalType,
                quantity = 1,
                totalWeightGrams = ouncesToSell * 31.1034,
                totalOunces = ouncesToSell,
                unitPriceAud = spotPrice,
                premiumAud = 0.0,
                storageAud = 0.0,
                deliveryAud = 0.0,
                totalAud = proceeds,
                status = OrderStatus.SETTLED,
                deliveryType = "UNALLOCATED_POOL",
                paymentStatus = "SETTLED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )

            _uiState.value = _uiState.value.copy(
                cashBalanceAud = _uiState.value.cashBalanceAud + proceeds,
                goldUnallocatedOz = if (metalType == MetalType.GOLD) _uiState.value.goldUnallocatedOz - ouncesToSell else _uiState.value.goldUnallocatedOz,
                silverUnallocatedOz = if (metalType == MetalType.SILVER) _uiState.value.silverUnallocatedOz - ouncesToSell else _uiState.value.silverUnallocatedOz,
                orders = listOf(newOrder) + _uiState.value.orders,
                doubleEntryLedger = ledger.getEntries(),
                restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/sell - Sold unallocated ${ouncesToSell}oz ${metalType.name}").takeLast(30)
            )

            generateDocument(newOrder, "SALES_CONFIRMATION")
        }
        reconcileSystems()
    }

    // 10. GOLD JEWELLERY BUYBACK
    fun submitJewelleryAssessment(itemType: String, weight: Double, purity: Double, declaration: String) {
        val spotPrice = getSpotPriceAud(MetalType.GOLD)
        val gramsPerOz = 31.1034
        val rawValue = (spotPrice / gramsPerOz) * weight * (purity / 100.0)
        // Scrap fee discount
        val estimateOffer = rawValue * 0.88 // 12% scrap processing charge

        val newRequest = AssessmentRequest(
            itemType = itemType,
            declaredWeightGrams = weight,
            estimatedPurity = purity,
            customerDeclaration = declaration,
            status = "OFFERED",
            finalOfferAud = Math.round(estimateOffer * 100.0) / 100.0,
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        )

        _uiState.value = _uiState.value.copy(
            goldJewelleryRequests = listOf(newRequest) + _uiState.value.goldJewelleryRequests,
            restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/assay/requests - Created request ${newRequest.requestId}").takeLast(30)
        )
    }

    fun acceptJewelleryOffer(requestId: String) {
        val updatedRequests = _uiState.value.goldJewelleryRequests.map { req ->
            if (req.requestId == requestId && req.status == "OFFERED") {
                // Post payment
                ledger.postTransaction("JEWELLERY_BUYBACK_CASH", "DEALER_RESERVE", "CUSTOMER_CASH", req.finalOfferAud, "AUD", "Jewellery buyback scrap ${req.requestId}")
                
                // Add metal to dealer vault scrap inventory via Assay certification
                val goldOunces = (req.declaredWeightGrams * (req.estimatedPurity / 100.0)) / 31.1034
                ledger.postTransaction("JEWELLERY_ASSAY_METAL", "DEALER_RESERVE", "DEALER_VAULT", goldOunces, "XAU_OZ", "Assay certified jewellery scrap conversion")

                val assayCert = MetalAssay(
                    grossWeightGrams = req.declaredWeightGrams,
                    purity = req.estimatedPurity,
                    fineWeightGrams = req.declaredWeightGrams * (req.estimatedPurity / 100.0),
                    method = "XRF Spectrometry & Density Assay",
                    operator = "Dr. Helen Rostova (Chief Assayer)",
                    timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
                    confidenceScore = 0.985,
                    resultSummary = "Verified ${req.itemType} scrap. Confirmed fine weight ${"%.3f".format(req.declaredWeightGrams * (req.estimatedPurity / 100.0))}g Gold."
                )

                _uiState.value = _uiState.value.copy(
                    cashBalanceAud = _uiState.value.cashBalanceAud + req.finalOfferAud,
                    restApiLogs = (_uiState.value.restApiLogs + "POST /api/v1/assay/execute - Signed certificate ${assayCert.assayId}").takeLast(30)
                )

                req.copy(status = "ACCEPTED", assayResultId = assayCert.assayId)
            } else {
                req
            }
        }
        _uiState.value = _uiState.value.copy(
            goldJewelleryRequests = updatedRequests,
            doubleEntryLedger = ledger.getEntries()
        )
        reconcileSystems()
    }

    // RECONCILIATION RUNNER
    fun runManualReconciliation() {
        reconcileSystems()
        _uiState.value = _uiState.value.copy(
            demoLogs = _uiState.value.demoLogs + "MANUAL RECONCILIATION TRACE: Physical Vault Cover verified against active Customer Allocated and Pool balances. Ledgers perfectly balanced."
        )
    }

    private fun reconcileSystems() {
        val totalCustomerGoldOz = _uiState.value.goldAllocatedOz + _uiState.value.goldUnallocatedOz
        val totalCustomerSilverOz = _uiState.value.silverAllocatedOz + _uiState.value.silverUnallocatedOz

        // Ensure physical vault cover covers everything
        val physicalGoldCover = totalCustomerGoldOz + 40000.0 // Add solid buffer representing dealer's own bulk reserves
        val physicalSilverCover = totalCustomerSilverOz + 150000.0

        val reconRes = ledger.runReconciliation(
            physicalGoldOunces = physicalGoldCover,
            physicalSilverOunces = physicalSilverCover,
            customerGoldAllocated = _uiState.value.goldAllocatedOz,
            customerGoldUnallocated = _uiState.value.goldUnallocatedOz,
            customerSilverAllocated = _uiState.value.silverAllocatedOz,
            customerSilverUnallocated = _uiState.value.silverUnallocatedOz,
            cashBalanceAud = _uiState.value.cashBalanceAud
        )

        val status = reconRes["status"] as String
        _uiState.value = _uiState.value.copy(
            systemReconciliationStatus = status,
            physicalGoldOuncesInVault = physicalGoldCover,
            physicalSilverOuncesInVault = physicalSilverCover,
            restApiLogs = (_uiState.value.restApiLogs + "GET /api/v1/reconciliation - Status 200 - $status").takeLast(30)
        )
    }

    private fun getSpotPriceAud(metalType: MetalType): Double {
        val symbol = if (metalType == MetalType.GOLD) "XAU/AUD" else "XAG/AUD"
        return _uiState.value.marketPrices.firstOrNull { it.symbol == symbol }?.ask ?: if (metalType == MetalType.GOLD) 5420.80 else 68.42
    }

    // 11. DOCUMENT GENERATION
    fun generateDocument(order: Order, type: String) {
        val documentContent = buildString {
            appendLine("=========================================")
            appendLine("           AUSMETAL PLATFORM DOCUMENT")
            appendLine("       AUSTRALIAN GOLD & SILVER MERCHANT")
            appendLine("=========================================")
            appendLine("Document Type: $type")
            appendLine("Reference Code: DOC-${UUID.randomUUID().toString().take(8).uppercase()}")
            appendLine("Timestamp: ${order.timestamp}")
            appendLine("Transaction ID: ${order.orderId}")
            appendLine("Client Name: ${_uiState.value.customerName}")
            appendLine("Client Tier: ${_uiState.value.customerTier}")
            appendLine("-----------------------------------------")
            appendLine("Side: ${order.side}")
            appendLine("Metal Type: ${order.metalType.name}")
            appendLine("Order Type: ${order.orderType.name}")
            appendLine("Delivery Selection: ${order.deliveryType}")
            if (order.pickupBranch != null) {
                appendLine("Branch Collection Site: ${order.pickupBranch}")
            }
            appendLine("-----------------------------------------")
            if (order.product != null) {
                appendLine("Product Selected: ${order.product.name}")
                appendLine("Unit Weight: ${order.product.grossWeightGrams}g")
                appendLine("Product Purity: ${order.product.purity}% fine")
            }
            appendLine("Total Weight Fine: ${"%.4f".format(order.totalWeightGrams)}g (${"%.3f".format(order.totalOunces)} troy oz)")
            appendLine("Spot Reference (AUD/oz): $${"%,.2f".format(order.unitPriceAud / if (order.totalOunces == 0.0) 1.0 else order.totalOunces)}")
            appendLine("Dealer Premium/Fees: $${"%,.2f".format(order.premiumAud)}")
            appendLine("Storage & Custody: $${"%,.2f".format(order.storageAud)}")
            appendLine("Delivery Services: $${"%,.2f".format(order.deliveryAud)}")
            appendLine("-----------------------------------------")
            appendLine("TOTAL AMOUNT RECEIVED: AUD $${"%,.2f".format(order.totalAud)}")
            appendLine("Payment Status: ${order.paymentStatus}")
            appendLine("-----------------------------------------")
            appendLine("STATUS: APPROVED & PHYSICALLY BACKED")
            appendLine("=========================================")
            appendLine("           SIMULATION — NOT TAX ADVICE")
            appendLine("=========================================")
        }

        _uiState.value = _uiState.value.copy(
            lastGeneratedDocument = documentContent,
            docType = type
        )
    }

    fun dismissDocument() {
        _uiState.value = _uiState.value.copy(lastGeneratedDocument = null, docType = null)
    }

    // 12. STEP-BY-STEP DEMONSTRATION WALKTHROUGH
    fun advanceDemoWalkthrough() {
        val currentStep = _uiState.value.demoStep
        val nextStep = currentStep + 1

        val (logMsg, stateUpdate) = when (nextStep) {
            1 -> {
                "Step 1/10: Harrison Vance initiates synthetic AML verification. System evaluates CDD data and flags clean history. Onboarding approved as VERIFIED customer." to { state: AusmetalUiState ->
                    state.copy(customerTier = "VERIFIED", isKycApproved = true, demoStep = nextStep)
                }
            }
            2 -> {
                "Step 2/10: Viewing Live Market Rates. Gold is trading at $${"%,.2f".format(getSpotPriceAud(MetalType.GOLD))} AUD/oz. Silver is $${"%,.2f".format(getSpotPriceAud(MetalType.SILVER))} AUD/oz." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            3 -> {
                "Step 3/10: Initiating purchase of 100g 999.9 Gold Investment Bar. System calculates subtotal, 0.0% GST rate (qualified bullion), and storage quotes." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            4 -> {
                val gProd = _uiState.value.products.firstOrNull { it.productId == "G-BAR-100G" }
                if (gProd != null) {
                    executePurchase(gProd, 1, "VAULT", null)
                }
                "Step 4/10: Purchase submitted! Cash of $17,420 AUD deducted via PayID simulation. Solid Gold Bar AU-00423 allocated instantly inside Perth Secure Vault. Digital Metal Passport generated." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            5 -> {
                val sProd = _uiState.value.products.firstOrNull { it.productId == "S-BAR-1KG" }
                if (sProd != null) {
                    executePurchase(sProd, 1, "VAULT", null)
                }
                "Step 5/10: Purchased 1kg Silver Bullion Bar. Cash deducted. Silver bar AG-11203 allocated and stored safely in Sydney Secure Vault." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            6 -> {
                "Step 6/10: Viewing Vault Inventory Digital Twin. Both Perth and Sydney Vault metrics updated with Harrison's newly allocated physical bars. High-resolution status shows OPERATIONAL." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            7 -> {
                // Simulating market price spike scenario
                runScenario("Gold +10%")
                "Step 7/10: SCENARIO LAB TRACE - Gold Spot spikes +10%. Watch the portfolio valuation automatically recompute in real-time. Unrealized gains rise." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            8 -> {
                "Step 8/10: Initiating a buyback order. Harrison chooses to sell the 100g Gold Bar back to the dealer. System quotes synthetic bid with narrow premium." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            9 -> {
                val lastBar = _uiState.value.allocatedGoldBars.lastOrNull()
                if (lastBar != null) {
                    executeSellBar(lastBar.barId, MetalType.GOLD)
                }
                "Step 9/10: Sell execution successful! Solid gold bar released back to merchant pool. Harrison receives immediate cash settlement. AUD cash account increases." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            10 -> {
                "Step 10/10: Walkthrough Complete! Reviewed complete audit trail, double-entry ledgers, and transaction certificates. System has fully reconciled physical vs ledger balances." to { state: AusmetalUiState ->
                    state.copy(demoStep = nextStep)
                }
            }
            else -> {
                // Reset walkthrough
                seedInitialData()
                "Demonstration Walkthrough Reset. Starting fresh simulation." to { state: AusmetalUiState ->
                    state.copy(demoStep = 0)
                }
            }
        }

        _uiState.value = stateUpdate(_uiState.value).copy(
            demoLogs = _uiState.value.demoLogs + logMsg
        )
    }

    override fun onCleared() {
        priceSimJob?.cancel()
        super.onCleared()
    }
}
