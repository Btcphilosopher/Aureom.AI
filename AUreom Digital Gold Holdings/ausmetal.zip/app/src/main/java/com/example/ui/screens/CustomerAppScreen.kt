package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.AusmetalViewModel
import com.example.service.MerchantService
import java.util.*

@Composable
fun CustomerAppScreen(
    viewModel: AusmetalViewModel,
    onDealerTerminalToggle: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = GraphiteCard,
                tonalElevation = 8.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                val items = listOf("Home", "Market", "Buy/Sell", "Vaults", "Account")
                val icons = listOf(Icons.Default.Home, Icons.Default.TrendingUp, Icons.Default.ShoppingCart, Icons.Default.Lock, Icons.Default.Person)
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icons[index], contentDescription = item, modifier = Modifier.size(24.dp)) },
                        label = { Text(item, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BlackText,
                            selectedTextColor = AustralianGoldBright,
                            indicatorColor = AustralianGold,
                            unselectedIconColor = SlateText,
                            unselectedTextColor = SlateText
                        )
                    )
                }
            }
        },
        containerColor = CharcoalDark
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(CharcoalDark, Color(0xFF13171B))
                    )
                )
        ) {
            when (selectedTab) {
                0 -> HomeScreen(viewModel, state, onDealerTerminalToggle, onNavigateToBuy = { selectedTab = 2 }, onNavigateToVault = { selectedTab = 3 })
                1 -> MarketScreen(viewModel, state, onBuyProduct = { selectedTab = 2 })
                2 -> BuySellScreen(viewModel, state)
                3 -> VaultsScreen(viewModel, state)
                4 -> AccountScreen(viewModel, state, onDealerTerminalToggle)
            }

            // Interactive Walkthrough banner hovering on screen
            WalkthroughBanner(viewModel, state, modifier = Modifier.align(Alignment.TopCenter))

            // Global Document Viewer Modal
            state.lastGeneratedDocument?.let { doc ->
                DocumentModal(doc = doc, docType = state.docType ?: "DOCUMENT", onDismiss = { viewModel.dismissDocument() })
            }
        }
    }
}

@Composable
fun WalkthroughBanner(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
            .border(1.dp, AustralianGold.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = GraphiteMedium.copy(alpha = 0.95f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(AustralianGold)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DEMONSTRATION WALKTHROUGH (Step ${state.demoStep}/10)",
                        color = AustralianGoldBright,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = if (state.demoStep == 10) "COMPLETE" else "ACTIVE",
                    color = if (state.demoStep == 10) GreenSuccess else AustralianGoldBright,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(
                            if (state.demoStep == 10) GreenSuccess.copy(alpha = 0.2f) else AustralianGold.copy(alpha = 0.2f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = state.demoLogs.lastOrNull() ?: "Welcome to AUSMETAL. Click 'Next Step' to begin the verified private merchant scenario walkthrough.",
                color = WhiteText,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.End,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.demoStep > 0) {
                    TextButton(
                        onClick = { viewModel.advanceDemoWalkthrough() },
                        colors = ButtonDefaults.textButtonColors(contentColor = SlateText),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Reset Scenario", fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Button(
                    onClick = { viewModel.advanceDemoWalkthrough() },
                    colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("walkthrough_next_btn")
                ) {
                    Text(
                        text = if (state.demoStep == 10) "Restart Demo" else "Next Step",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: AusmetalViewModel,
    state: com.example.viewmodel.AusmetalUiState,
    onDealerTerminalToggle: () -> Unit,
    onNavigateToBuy: () -> Unit,
    onNavigateToVault: () -> Unit
) {
    val scrollState = rememberScrollState()
    
    val goldRate = state.marketPrices.firstOrNull { it.symbol == "XAU/AUD" }?.ask ?: 5420.80
    val silverRate = state.marketPrices.firstOrNull { it.symbol == "XAG/AUD" }?.ask ?: 68.42
    val goldChange = state.marketPrices.firstOrNull { it.symbol == "XAU/AUD" }?.changePercentage ?: 0.72
    val silverChange = state.marketPrices.firstOrNull { it.symbol == "XAG/AUD" }?.changePercentage ?: 1.31

    val goldValuation = (state.goldAllocatedOz + state.goldUnallocatedOz) * goldRate
    val silverValuation = (state.silverAllocatedOz + state.silverUnallocatedOz) * silverRate
    val totalPortfolioVal = goldValuation + silverValuation + state.cashBalanceAud

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(130.dp)) // Offset for Walkthrough banner

        // Brand Header Area
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "AUSMETAL",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = WhiteText,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "AUSTRALIAN GOLD & SILVER MERCHANT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = AustralianGold,
                    letterSpacing = 1.sp
                )
            }
            IconButton(
                onClick = onDealerTerminalToggle,
                modifier = Modifier
                    .border(1.dp, AustralianGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .background(GraphiteMedium, RoundedCornerShape(8.dp))
                    .size(40.dp)
            ) {
                Icon(
                    Icons.Default.Terminal,
                    contentDescription = "Dealer Terminal",
                    tint = AustralianGoldBright
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Core promise section - 4 Questions Answered instantly
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PRIVATE WEALTH CUSTODY SUMMARY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateText,
                    letterSpacing = 1.2.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Core answers
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("My Gold Value", fontSize = 11.sp, color = SlateText)
                        Text("$${"%,.2f".format(goldValuation)}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("My Silver Value", fontSize = 11.sp, color = SlateText)
                        Text("$${"%,.2f".format(silverValuation)}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Vault Location", fontSize = 11.sp, color = SlateText)
                        Text("Perth & Sydney", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Liquid Capital (AUD)", fontSize = 11.sp, color = SlateText)
                        Text("$${"%,.2f".format(state.cashBalanceAud)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = GreenSuccess)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large Total Portfolio Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteMedium),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "TOTAL PORTFOLIO INDICATIVE VALUATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateText,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "AUD $${"%,.2f".format(totalPortfolioVal)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = AustralianGoldBright
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(GreenSuccess.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.TrendingUp, "up", tint = GreenSuccess, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+2.84%", color = GreenSuccess, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                // Visual weight division bars
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))) {
                    val goldPct = if (totalPortfolioVal == 0.0) 0.33f else (goldValuation / totalPortfolioVal).toFloat()
                    val silverPct = if (totalPortfolioVal == 0.0) 0.33f else (silverValuation / totalPortfolioVal).toFloat()
                    val cashPct = if (totalPortfolioVal == 0.0) 0.34f else (state.cashBalanceAud / totalPortfolioVal).toFloat()

                    Box(modifier = Modifier
                        .weight(Math.max(0.01f, goldPct))
                        .fillMaxHeight()
                        .background(AustralianGold))
                    Box(modifier = Modifier
                        .weight(Math.max(0.01f, silverPct))
                        .fillMaxHeight()
                        .background(Color.White))
                    Box(modifier = Modifier
                        .weight(Math.max(0.01f, cashPct))
                        .fillMaxHeight()
                        .background(GreenSuccess))
                }

                Spacer(modifier = Modifier.height(12.dp))
                // Color Legend
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LegendItem("Gold (${"%.1f".format(state.goldAllocatedOz + state.goldUnallocatedOz)} oz)", AustralianGold)
                    LegendItem("Silver (${"%.1f".format(state.silverAllocatedOz + state.silverUnallocatedOz)} oz)", Color.White)
                    LegendItem("Cash (AUD)", GreenSuccess)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Spot Ticker Quick widget
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToBuy() },
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("GOLD SPOT", fontSize = 11.sp, color = SlateText, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (goldChange >= 0) "+${"%.2f".format(goldChange)}%" else "${"%.2f".format(goldChange)}%",
                            color = if (goldChange >= 0) GreenSuccess else RedAlert,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("$${"%,.2f".format(goldRate)}", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = AustralianGoldBright)
                    Text("AUD / oz", fontSize = 10.sp, color = SlateText)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToBuy() },
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SILVER SPOT", fontSize = 11.sp, color = SlateText, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (silverChange >= 0) "+${"%.2f".format(silverChange)}%" else "${"%.2f".format(silverChange)}%",
                            color = if (silverChange >= 0) GreenSuccess else RedAlert,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("$${"%,.2f".format(silverRate)}", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = WhiteText)
                    Text("AUD / oz", fontSize = 10.sp, color = SlateText)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Primary Action Buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onNavigateToBuy,
                colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("buy_gold_shortcut_btn"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Add, "Buy")
                Spacer(modifier = Modifier.width(6.dp))
                Text("BUY GOLD / SILVER", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Button(
                onClick = onNavigateToVault,
                colors = ButtonDefaults.buttonColors(containerColor = GraphiteMedium, contentColor = WhiteText),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .border(1.dp, BorderColor, RoundedCornerShape(10.dp)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Security, "Vault")
                Spacer(modifier = Modifier.width(6.dp))
                Text("CUSTODY VAULT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Vault Holdings Breakdown
        Text(
            text = "YOUR PHYSICAL METALS IN SAFE VAULT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SlateText,
            letterSpacing = 1.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Stored items summary card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Allocated Bullion Bars", fontSize = 13.sp, color = WhiteText)
                        Text("${state.allocatedGoldBars.size} Gold Bars | ${state.allocatedSilverBars.size} Silver Bars", fontSize = 11.sp, color = SlateText)
                    }
                    Text(
                        text = "FULLY PHYSICALLY ALLOCATED",
                        color = GreenSuccess,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(GreenSuccess.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = BorderColor)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Unallocated Pooled Metal", fontSize = 13.sp, color = WhiteText)
                        Text("${"%.3f".format(state.goldUnallocatedOz)}oz Gold Pool | ${"%.2f".format(state.silverUnallocatedOz)}oz Silver Pool", fontSize = 11.sp, color = SlateText)
                    }
                    Text(
                        text = "UNALLOCATED POOL COVERS",
                        color = AustralianGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(AustralianGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = SlateText, fontSize = 11.sp)
    }
}

@Composable
fun MarketScreen(
    viewModel: AusmetalViewModel,
    state: com.example.viewmodel.AusmetalUiState,
    onBuyProduct: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf("METALS") } // METALS, FX

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(130.dp))

        Text(
            text = "LIVE AUSTRALIAN METAL DESK",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = WhiteText
        )
        Text(
            text = "Real-time synthetic dealer reference rates",
            fontSize = 11.sp,
            color = SlateText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Categories Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteCard, RoundedCornerShape(8.dp))
                .padding(4.dp)
        ) {
            listOf("METALS", "FX").forEach { cat ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selectedCategory == cat) AustralianGold else Color.Transparent)
                        .clickable { selectedCategory = cat }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cat,
                        color = if (selectedCategory == cat) BlackText else SlateText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Rates Table
        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            val filteredPrices = state.marketPrices.filter {
                if (selectedCategory == "METALS") it.assetClass != "FX" else it.assetClass == "FX"
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ASSET / PAIR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, modifier = Modifier.weight(1.5f))
                        Text("BID", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text("ASK / VALUE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                        Text("SPREAD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, modifier = Modifier.weight(0.8f), textAlign = TextAlign.End)
                    }
                    HorizontalDivider(color = BorderColor)
                }

                items(filteredPrices) { price ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onBuyProduct() }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(price.symbol, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                            Text(
                                text = if (price.changePercentage >= 0) "+${"%.2f".format(price.changePercentage)}%" else "${"%.2f".format(price.changePercentage)}%",
                                color = if (price.changePercentage >= 0) GreenSuccess else RedAlert,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = if (price.assetClass == "FX") "%.4f".format(price.bid) else "$${"%,.2f".format(price.bid)}",
                            fontSize = 13.sp,
                            color = SlateText,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )

                        Text(
                            text = if (price.assetClass == "FX") "%.4f".format(price.ask) else "$${"%,.2f".format(price.ask)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (price.changePercentage >= 0) AustralianGoldBright else WhiteText,
                            modifier = Modifier.weight(1.2f),
                            textAlign = TextAlign.End
                        )

                        Text(
                            text = if (price.assetClass == "FX") "%.4f".format(price.spread) else "$${"%,.2f".format(price.spread)}",
                            fontSize = 11.sp,
                            color = SlateText,
                            modifier = Modifier.weight(0.8f),
                            textAlign = TextAlign.End
                        )
                    }
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
fun BuySellScreen(
    viewModel: AusmetalViewModel,
    state: com.example.viewmodel.AusmetalUiState
) {
    var selectedMetal by remember { mutableStateOf(MetalType.GOLD) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var quantity by remember { mutableStateOf(1) }
    var deliveryType by remember { mutableStateOf("VAULT") } // VAULT, SECURE_DELIVERY

    // Automatically pick first product matching metal if none chosen
    val filteredProducts = state.products.filter { it.metal == selectedMetal }
    if (selectedProduct == null || selectedProduct?.metal != selectedMetal) {
        selectedProduct = filteredProducts.firstOrNull()
    }

    val spotPrice = state.marketPrices.firstOrNull { it.symbol == (if (selectedMetal == MetalType.GOLD) "XAU/AUD" else "XAG/AUD") }?.ask ?: 5420.80
    val audUsdRate = state.marketPrices.firstOrNull { it.symbol == "AUD/USD" }?.ask ?: 0.65
    val spotPriceUsd = spotPrice * audUsdRate

    val pricingDetails = selectedProduct?.let { prod ->
        MerchantService.PricingEngine.calculateCustomerPrice(
            product = prod,
            spotPriceUsdPerOz = spotPriceUsd,
            audUsdRate = audUsdRate,
            quantity = quantity,
            isStorageChosen = deliveryType == "VAULT",
            isDeliveryChosen = deliveryType == "SECURE_DELIVERY"
        )
    }

    val subtotal = pricingDetails?.get("subtotal_aud") ?: 0.0
    val fabricationFee = pricingDetails?.get("fabrication_premium_aud") ?: 0.0
    val productPremium = pricingDetails?.get("product_premium_aud") ?: 0.0
    val storageFee = pricingDetails?.get("storage_aud") ?: 0.0
    val deliveryFee = pricingDetails?.get("delivery_aud") ?: 0.0
    val totalWithoutTax = subtotal + storageFee + deliveryFee

    val taxResult = selectedProduct?.let { prod ->
        MerchantService.TaxEngine.calculateTax(prod, subtotal, deliveryFee)
    }
    val gstAmount = taxResult?.get("total_gst") as? Double ?: 0.0
    val grandTotal = totalWithoutTax + gstAmount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(130.dp))

        Text(
            text = "PRECIOUS METALS TRANSACTION PORTAL",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = WhiteText
        )
        Text(
            text = "Invest in allocated bullion or manage unallocated pools",
            fontSize = 11.sp,
            color = SlateText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Metal Selector Tabs
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { selectedMetal = MetalType.GOLD },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedMetal == MetalType.GOLD) AustralianGold else GraphiteCard,
                    contentColor = if (selectedMetal == MetalType.GOLD) BlackText else SlateText
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("GOLD BULLION", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { selectedMetal = MetalType.SILVER },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedMetal == MetalType.SILVER) AustralianGold else GraphiteCard,
                    contentColor = if (selectedMetal == MetalType.SILVER) BlackText else SlateText
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("SILVER BULLION", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Product Picker Card
        Text("SELECT PHYSICAL BULLION PRODUCT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText)
        Spacer(modifier = Modifier.height(6.dp))
        filteredProducts.forEach { product ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { selectedProduct = product }
                    .border(
                        1.dp,
                        if (selectedProduct?.productId == product.productId) AustralianGold else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                        Text("Refiner: ${product.refiner} | Gross: ${product.grossWeightGrams}g | Purity: ${product.purity}%", fontSize = 11.sp, color = SlateText)
                    }
                    Text(
                        text = product.availability,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (product.availability == "IN_STOCK") GreenSuccess else AustralianGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quantity Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ORDER QUANTITY", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WhiteText)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { if (quantity > 1) quantity-- },
                    modifier = Modifier
                        .size(36.dp)
                        .background(GraphiteMedium, CircleShape)
                ) {
                    Icon(Icons.Default.Remove, "minus", tint = WhiteText)
                }
                Text(quantity.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = WhiteText, modifier = Modifier.padding(horizontal = 16.dp))
                IconButton(
                    onClick = { quantity++ },
                    modifier = Modifier
                        .size(36.dp)
                        .background(GraphiteMedium, CircleShape)
                ) {
                    Icon(Icons.Default.Add, "plus", tint = WhiteText)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Custody & Delivery Selection
        Text("FLEXIBLE STORAGE & DELIVERIES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText)
        Spacer(modifier = Modifier.height(6.dp))
        Row {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { deliveryType = "VAULT" }
                    .border(
                        1.dp,
                        if (deliveryType == "VAULT") AustralianGold else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, "vault", tint = AustralianGoldBright, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Vault Custody", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = WhiteText)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Store allocated bar in private wealth facility.", fontSize = 11.sp, color = SlateText)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { deliveryType = "SECURE_DELIVERY" }
                    .border(
                        1.dp,
                        if (deliveryType == "SECURE_DELIVERY") AustralianGold else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalShipping, "shipping", tint = AustralianGoldBright, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Secure Courier", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = WhiteText)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Physical delivery to verified address.", fontSize = 11.sp, color = SlateText)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Settlement pricing breakdown details
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteMedium)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("ORDER VALUATION & SETTLEMENT SUMMARY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Spot Metal Value (Ref)", fontSize = 13.sp, color = SlateText)
                    Text("$${"%,.2f".format(spotPrice * ((selectedProduct?.fineWeightGrams ?: 0.0) / 31.1034) * quantity)}", fontSize = 13.sp, color = WhiteText)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Dealer premium & fabrication markup", fontSize = 13.sp, color = SlateText)
                    Text("$${"%,.2f".format(fabricationFee + productPremium)}", fontSize = 13.sp, color = WhiteText)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Vault Storage Custody Quote", fontSize = 13.sp, color = SlateText)
                    Text("$${"%,.2f".format(storageFee)}", fontSize = 13.sp, color = WhiteText)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Delivery & Insured Logistics", fontSize = 13.sp, color = SlateText)
                    Text("$${"%,.2f".format(deliveryFee)}", fontSize = 13.sp, color = WhiteText)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("GST (Qualified Bullion: GST-free)", fontSize = 13.sp, color = SlateText)
                    Text("$${"%,.2f".format(gstAmount)}", fontSize = 13.sp, color = if (gstAmount == 0.0) GreenSuccess else AustralianGoldBright)
                }
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = BorderColor)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("GRAND TOTAL (AUD)", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                    Text("$${"%,.2f".format(grandTotal)}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = AustralianGoldBright)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Execute Buy button
        Button(
            onClick = {
                selectedProduct?.let { prod ->
                    viewModel.executePurchase(prod, quantity, deliveryType, null)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("execute_buy_button"),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("SECURELY EXECUTE ACQUISITION", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        // Sell Allocated metal section
        Spacer(modifier = Modifier.height(24.dp))
        Text("LIQUIDATE PHYSICAL ASSETS (BUYBACK)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(8.dp))

        val currentBars = if (selectedMetal == MetalType.GOLD) state.allocatedGoldBars else state.allocatedSilverBars
        if (currentBars.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Text(
                    text = "No allocated ${selectedMetal.name.lowercase()} bars available in vault to liquidate currently.",
                    fontSize = 12.sp,
                    color = SlateText,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            currentBars.forEach { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = GraphiteCard)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Bar: ${bar.serialNumber} [${bar.grossWeightGrams}g ${bar.purity}%]", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                            Text("Stored in: ${bar.vault} | Fine: ${bar.fineWeightGrams}g", fontSize = 11.sp, color = SlateText)
                        }
                        Button(
                            onClick = { viewModel.executeSellBar(bar.barId, selectedMetal) },
                            colors = ButtonDefaults.buttonColors(containerColor = RedAlert, contentColor = WhiteText),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("sell_bar_${bar.serialNumber}")
                        ) {
                            Text("SELL BACK", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun VaultsScreen(
    viewModel: AusmetalViewModel,
    state: com.example.viewmodel.AusmetalUiState
) {
    var selectedVaultIndex by remember { mutableStateOf(0) }
    val activeVault = state.vaults.getOrNull(selectedVaultIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(130.dp))

        Text(
            text = "AUSTRALIAN CUSTODY VAULT DIGITAL TWINS",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = WhiteText
        )
        Text(
            text = "Private wealth secure operations & real-time telemetry",
            fontSize = 11.sp,
            color = SlateText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Australian Map Canvas Layout
        Text(
            text = "GEOGRAPHIC CUSTODY DEPOT MATRIX",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SlateText,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Draw custom simplified vector outline of Australia
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.15f, size.height * 0.40f)
                        quadraticTo(size.width * 0.35f, size.height * 0.15f, size.width * 0.50f, size.height * 0.20f)
                        quadraticTo(size.width * 0.65f, size.height * 0.10f, size.width * 0.75f, size.height * 0.25f)
                        quadraticTo(size.width * 0.85f, size.height * 0.20f, size.width * 0.90f, size.height * 0.45f)
                        quadraticTo(size.width * 0.92f, size.height * 0.60f, size.width * 0.82f, size.height * 0.78f)
                        quadraticTo(size.width * 0.75f, size.height * 0.82f, size.width * 0.65f, size.height * 0.80f)
                        quadraticTo(size.width * 0.55f, size.height * 0.85f, size.width * 0.45f, size.height * 0.80f)
                        quadraticTo(size.width * 0.25f, size.height * 0.82f, size.width * 0.18f, size.height * 0.65f)
                        close()
                    }
                    drawPath(
                        path = path,
                        color = BorderColor,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    )

                    // Draw dots for operating cities
                    val cities = listOf(
                        "Perth" to Offset(size.width * 0.22f, size.height * 0.68f),
                        "Sydney" to Offset(size.width * 0.80f, size.height * 0.68f),
                        "Melbourne" to Offset(size.width * 0.74f, size.height * 0.76f),
                        "Brisbane" to Offset(size.width * 0.84f, size.height * 0.52f),
                        "Adelaide" to Offset(size.width * 0.62f, size.height * 0.72f),
                        "Darwin" to Offset(size.width * 0.48f, size.height * 0.28f),
                        "Hobart" to Offset(size.width * 0.75f, size.height * 0.88f)
                    )

                    cities.forEach { (name, pos) ->
                        drawCircle(
                            color = if (name == "Perth" || name == "Sydney" || name == "Melbourne" || name == "Brisbane" || name == "Adelaide") AustralianGold else SlateText,
                            radius = 6.dp.toPx(),
                            center = pos
                        )
                    }
                }

                // Overlay Labels
                Text(
                    text = "PERTH VAULT",
                    color = AustralianGoldBright,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 24.dp, top = 40.dp)
                )

                Text(
                    text = "SYDNEY VAULT",
                    color = AustralianGoldBright,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp, top = 30.dp)
                )

                Text(
                    text = "SYNTHETIC DEMONSTRATION FACILITY",
                    color = SlateText,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Vault Selector Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.vaults.forEachIndexed { idx, vault ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedVaultIndex == idx) AustralianGold else GraphiteCard)
                        .clickable { selectedVaultIndex = idx }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = vault.name,
                        color = if (selectedVaultIndex == idx) BlackText else WhiteText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Vault Digital Twin Telemetry
        activeVault?.let { vault ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard),
                border = BorderStroke(1.dp, BorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = vault.name.uppercase(),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AustralianGoldBright
                        )
                        Text(
                            text = vault.status,
                            color = GreenSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(GreenSuccess.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        VaultStatBox(title = "Capacity", value = "${vault.capacityTonnes}t", modifier = Modifier.weight(1f))
                        VaultStatBox(title = "Occupied", value = "${vault.occupiedWeightTonnes}t (${"%.1f".format((vault.occupiedWeightTonnes/vault.capacityTonnes)*100)}%)", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        VaultStatBox(title = "Gold Pool", value = "${"%.2f".format(state.physicalGoldOuncesInVault)} oz", modifier = Modifier.weight(1f))
                        VaultStatBox(title = "Silver Pool", value = "${"%.2f".format(state.physicalSilverOuncesInVault)} oz", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    HorizontalDivider(color = BorderColor)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("COMPLIANCE & INSURANCE AUDITS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Lloyd's Insurance", fontSize = 12.sp, color = WhiteText)
                        Text("FULLY INSURED", color = GreenSuccess, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Physical Audit Cycle", fontSize = 12.sp, color = WhiteText)
                        Text("COMPLIANT (DELOITTE 2026)", color = AustralianGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Metal Passports Section
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "YOUR METAL PASSPORTS & PROVENANCE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SlateText,
            letterSpacing = 1.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        val allMyBars = state.allocatedGoldBars + state.allocatedSilverBars
        if (allMyBars.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                Text(
                    text = "No physical bars allocated currently. Acquire gold or silver with storage selection to allocate bars.",
                    fontSize = 12.sp,
                    color = SlateText,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            allMyBars.forEach { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = GraphiteCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "SERIAL: ${bar.serialNumber}",
                                fontWeight = FontWeight.ExtraBold,
                                color = AustralianGoldBright,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "ALLOCATED",
                                color = GreenSuccess,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .background(GreenSuccess.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Refiner: ${bar.refiner}", fontSize = 12.sp, color = WhiteText)
                        Text("Assay Cert: ${bar.assayReference} | Purity: ${bar.purity}% fine", fontSize = 12.sp, color = SlateText)
                        Text("Vault Facility: ${bar.vault}", fontSize = 12.sp, color = SlateText)
                        Spacer(modifier = Modifier.height(10.dp))

                        // QR validation illustration mockup
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GraphiteMedium, RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.White, RoundedCornerShape(4.dp))
                                    .padding(4.dp)
                            ) {
                                // Mini QR abstraction using simple shapes
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawRect(Color.Black, size = size / 2.5f)
                                    drawRect(Color.Black, topLeft = Offset(size.width * 0.6f, 0f), size = size / 2.5f)
                                    drawRect(Color.Black, topLeft = Offset(0f, size.height * 0.6f), size = size / 2.5f)
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Provenance Secure Pass", fontSize = 11.sp, color = WhiteText, fontWeight = FontWeight.Bold)
                                Text("Tap to view audit-trail verification online", fontSize = 9.sp, color = SlateText)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun VaultStatBox(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = GraphiteMedium)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontSize = 11.sp, color = SlateText)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = WhiteText)
        }
    }
}

@Composable
fun AccountScreen(
    viewModel: AusmetalViewModel,
    state: com.example.viewmodel.AusmetalUiState,
    onDealerTerminalToggle: () -> Unit
) {
    var jewelleryItem by remember { mutableStateOf("Gold Jewellery") }
    var jewelleryWeightGrams by remember { mutableStateOf("50") }
    var jewelleryPurityPercent by remember { mutableStateOf("75") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(130.dp))

        Text(
            text = "VERIFIED ACCOUNT & PRIVATE COMPLIANCE",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = WhiteText
        )
        Text(
            text = "Onboarding, AUSTRAC compliance, and scrap jewellery buyback",
            fontSize = 11.sp,
            color = SlateText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // AML KYC Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(state.customerName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                        Text("Private Account Tier: ${state.customerTier}", fontSize = 12.sp, color = SlateText)
                    }
                    Text(
                        text = "APPROVED",
                        color = GreenSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(GreenSuccess.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = BorderColor)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Expected Annual Activity: ${state.expectedAnnualVolume}", fontSize = 12.sp, color = WhiteText)
                Text("Registered Source of Funds: ${state.sourceOfFunds}", fontSize = 12.sp, color = SlateText)
                Text("AUSTRAC Compliance Check: Fully Verified", fontSize = 12.sp, color = SlateText)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Gold Jewellery scrap buyback module
        Text("GOLD JEWELLERY / SCRAP BUYBACK", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateText, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("SUBMIT SCRAP FOR ASSAY ASSESSMENT", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                Text("Disclaimer: online evaluations cannot replace a physical XRF spectrometer or fire assay.", fontSize = 11.sp, color = AustralianGold)
                
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = jewelleryItem,
                    onValueChange = { jewelleryItem = it },
                    label = { Text("Item Description (e.g. 18k necklace)", color = SlateText) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText,
                        focusedBorderColor = AustralianGold,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row {
                    OutlinedTextField(
                        value = jewelleryWeightGrams,
                        onValueChange = { jewelleryWeightGrams = it },
                        label = { Text("Weight (g)", color = SlateText) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText,
                            focusedBorderColor = AustralianGold,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = jewelleryPurityPercent,
                        onValueChange = { jewelleryPurityPercent = it },
                        label = { Text("Est Purity %", color = SlateText) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText,
                            focusedBorderColor = AustralianGold,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val wt = jewelleryWeightGrams.toDoubleOrNull() ?: 50.0
                        val pur = jewelleryPurityPercent.toDoubleOrNull() ?: 75.0
                        viewModel.submitJewelleryAssessment(jewelleryItem, wt, pur, "Harrison declares items legally owned & free from encumbrance.")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("SUBMIT FOR SCRAP METALS BUYBACK", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active buyback requests
        if (state.goldJewelleryRequests.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            state.goldJewelleryRequests.forEach { req ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = GraphiteMedium)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(req.itemType.uppercase(), fontWeight = FontWeight.Bold, color = WhiteText, fontSize = 13.sp)
                            Text(
                                text = req.status,
                                color = if (req.status == "ACCEPTED") GreenSuccess else AustralianGoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text("Weight: ${req.declaredWeightGrams}g | Purity: ${req.estimatedPurity}% | Offer: AUD $${"%,.2f".format(req.finalOfferAud)}", fontSize = 11.sp, color = SlateText)
                        if (req.status == "OFFERED") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { viewModel.acceptJewelleryOffer(req.requestId) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess, contentColor = WhiteText),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ACCEPT SCRAP OFFER", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Open developer terminal toggle
        Button(
            onClick = onDealerTerminalToggle,
            colors = ButtonDefaults.buttonColors(containerColor = GraphiteMedium, contentColor = AustralianGoldBright),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, AustralianGold)
        ) {
            Icon(Icons.Default.Terminal, "Pro")
            Spacer(modifier = Modifier.width(8.dp))
            Text("SWITCH TO DEALER TERMINAL console", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun DocumentModal(doc: String, docType: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText)
            ) {
                Text("PRINT / DOWNLOAD PDF", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Text(docType.replace("_", " "), color = AustralianGoldBright, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .verticalScroll(rememberScrollState())
                    .background(BlackText, RoundedCornerShape(6.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = doc,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = WhiteText
                )
            }
        },
        containerColor = GraphiteMedium,
        shape = RoundedCornerShape(12.dp)
    )
}
