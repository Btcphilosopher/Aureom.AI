package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Australian Precious Metals - Refined Luxury & Industrial Palette
val CharcoalDark = Color(0xFF101214)
val GraphiteCard = Color(0xFF1A1D20)
val GraphiteMedium = Color(0xFF24282D)
val WarmWhite = Color(0xFFFAF8F5)
val EucalyptusGreen = Color(0xFF2D5A27)
val EucalyptusLight = Color(0xFFE2EFE0)
val AustralianGold = Color(0xFFC5A028)
val AustralianGoldBright = Color(0xFFE5C158)
val DeepNavy = Color(0xFF152238)
val SandstoneMuted = Color(0xFFB59A7C)
val RedAlert = Color(0xFFB3261E)
val GreenSuccess = Color(0xFF1A7A3E)
val SlateText = Color(0xFF8E959E)
val BorderColor = Color(0xFF2A2E33)
val WhiteText = Color(0xFFFFFFFF)
val BlackText = Color(0xFF0F1113)
val LightGrayBg = Color(0xFFF5F3F0)
val SoftGoldBg = Color(0xFFF9F5EB)

