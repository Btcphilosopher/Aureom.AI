package com.example.service

import com.example.model.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class MerchantService {

    // 1. AUSTRALIAN TAX ADAPTER
    object TaxEngine {
        private val currentRule = TaxRuleVersion(
            ruleVersion = "GST-ATO-2026-V3",
            effectiveFrom = "2026-01-01",
            effectiveTo = "2026-12-31",
            jurisdiction = "Commonwealth of Australia",
            gstRateBullionPercent = 0.0,
            gstRateStandardPercent = 10.0,
            description = "ATO Bullion Ruling: Precious metal is GST-free if Gold >= 99.5%, Silver >= 99.9%"
        )

        fun calculateTax(
            product: Product,
            subtotalAud: Double,
            deliveryFeeAud: Double,
            isBusinessClient: Boolean = false,
            isExport: Boolean = false
        ): Map<String, Any> {
            val isBullionGstFree = if (product.metal == MetalType.GOLD) {
                product.purity >= 99.5
            } else {
                product.purity >= 99.9
            }

            val productGstRate = if (isExport) {
                0.0 // Exports are GST-free
            } else if (isBullionGstFree) {
                0.0 // Investment grade bullion is GST-free
            } else {
                currentRule.gstRateStandardPercent / 100.0
            }

            // Freight is generally GST-free if it is an international delivery or part of GST-free bullion delivery
            val freightGstRate = if (isExport || isBullionGstFree) {
                0.0
            } else {
                currentRule.gstRateStandardPercent / 100.0
            }

            val productGst = subtotalAud * productGstRate
            val freightGst = deliveryFeeAud * freightGstRate
            val totalGst = productGst + freightGst
            val totalAud = subtotalAud + deliveryFeeAud + totalGst

            return mapOf(
                "rule_version" to currentRule.ruleVersion,
                "is_bullion_gst_free" to isBullionGstFree,
                "product_gst" to productGst,
                "freight_gst" to freightGst,
                "total_gst" to totalGst,
                "total_aud" to totalAud,
                "purity_reconciliation" to "GST applied based on purity: ${product.purity}%",
                "disclaimer" to "SIMULATION — NOT TAX ADVICE"
            )
        }
    }

    // 2. AUSTRALIAN PRICING ENGINE
    object PricingEngine {
        fun calculateCustomerPrice(
            product: Product,
            spotPriceUsdPerOz: Double,
            audUsdRate: Double,
            quantity: Int,
            isStorageChosen: Boolean,
            isDeliveryChosen: Boolean
        ): Map<String, Double> {
            // Spot Price in AUD per Ounce
            val spotPriceAudPerOz = spotPriceUsdPerOz / audUsdRate
            // 1 Troy Ounce = 31.1034768 grams
            val gramsPerOz = 31.1034768
            val spotPriceAudPerGram = spotPriceAudPerOz / gramsPerOz

            // Raw metal value based on fine weight
            val rawMetalValueAud = spotPriceAudPerGram * product.fineWeightGrams * quantity

            // Fabrication Premium (depends on size, smaller bars have higher premiums)
            val fabricationPremiumPerGram = when {
                product.grossWeightGrams <= 5.0 -> 12.50
                product.grossWeightGrams <= 20.0 -> 8.00
                product.grossWeightGrams <= 50.0 -> 4.50
                product.grossWeightGrams <= 100.0 -> 3.20
                product.grossWeightGrams <= 500.0 -> 1.80
                else -> 1.00 // Large 1kg+ bars
            }
            val totalFabricationPremiumAud = fabricationPremiumPerGram * product.grossWeightGrams * quantity

            // Product Premium & Dealer Premium (Markup percent)
            val productPremiumPercent = product.premiumPercent / 100.0
            val productPremiumAud = rawMetalValueAud * productPremiumPercent

            // Subtotal before logistics
            val subtotalAud = rawMetalValueAud + totalFabricationPremiumAud + productPremiumAud

            // Storage fee (if chosen, calculated synthetically)
            val storageAud = if (isStorageChosen) {
                // Synthetically 0.25% per annum, min $35 for demo purposes
                val annualRate = 0.0025
                val calculatedStorage = subtotalAud * (annualRate / 12.0) // 1 month indicative
                if (calculatedStorage < 35.0) 35.0 else calculatedStorage
            } else {
                0.0
            }

            // Delivery and insurance
            val deliveryAud = if (isDeliveryChosen) {
                val flatFee = 45.0
                // Insurance is 0.15% of metal value
                val insuranceFee = subtotalAud * 0.0015
                flatFee + insuranceFee
            } else {
                0.0
            }

            val totalCustomerAud = subtotalAud + storageAud + deliveryAud

            return mapOf(
                "spot_price_aud_oz" to spotPriceAudPerOz,
                "raw_metal_value_aud" to rawMetalValueAud,
                "fabrication_premium_aud" to totalFabricationPremiumAud,
                "product_premium_aud" to productPremiumAud,
                "subtotal_aud" to subtotalAud,
                "storage_aud" to storageAud,
                "delivery_aud" to deliveryAud,
                "total_aud" to totalCustomerAud
            )
        }
    }

    // 3. DOUBLE-ENTRY LEDGER ENGINE
    class DoubleEntryLedger {
        private val entries = mutableListOf<LedgerEntry>()

        fun postTransaction(
            eventType: String,
            debitAccount: String,
            creditAccount: String,
            amount: Double,
            asset: String,
            narration: String
        ): LedgerEntry {
            val amountDecimal = BigDecimal(amount).setScale(8, RoundingMode.HALF_UP)
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            
            // Event Sourcing - Generate hash for audit-trail verification
            val rawDataForHash = "$timestamp|$eventType|$debitAccount|$creditAccount|$amountDecimal|$asset|$narration"
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(rawDataForHash.toByteArray())
            val auditHash = hashBytes.joinToString("") { "%02x".format(it) }

            val entry = LedgerEntry(
                entryId = UUID.randomUUID().toString(),
                timestamp = timestamp,
                eventType = eventType,
                debitAccount = debitAccount,
                creditAccount = creditAccount,
                amount = amountDecimal,
                asset = asset,
                narration = narration,
                auditHash = auditHash
            )
            entries.add(entry)
            return entry
        }

        fun getEntries(): List<LedgerEntry> = entries.toList()

        fun getAccountBalance(accountName: String, asset: String): BigDecimal {
            var balance = BigDecimal.ZERO
            for (entry in entries) {
                if (entry.asset == asset) {
                    if (entry.debitAccount == accountName) {
                        balance = balance.add(entry.amount)
                    }
                    if (entry.creditAccount == accountName) {
                        balance = balance.subtract(entry.amount)
                    }
                }
            }
            return balance
        }

        // PHYSICAL INVENTORY vs LEDGER RECONCILIATION
        fun runReconciliation(
            physicalGoldOunces: Double,
            physicalSilverOunces: Double,
            customerGoldAllocated: Double,
            customerGoldUnallocated: Double,
            customerSilverAllocated: Double,
            customerSilverUnallocated: Double,
            cashBalanceAud: Double
        ): Map<String, Any> {
            val ledgerGoldOunces = getAccountBalance("DEALER_VAULT", "XAU_OZ").toDouble()
            val ledgerSilverOunces = getAccountBalance("DEALER_VAULT", "XAG_OZ").toDouble()
            val ledgerCashAud = getAccountBalance("CUSTOMER_CASH", "AUD").toDouble()

            // Sum of what customers own
            val totalCustomerGold = customerGoldAllocated + customerGoldUnallocated
            val totalCustomerSilver = customerSilverAllocated + customerSilverUnallocated

            // Physical in Vault should cover customer allocated and unallocated pooled metal
            val goldMismatch = physicalGoldOunces - totalCustomerGold
            val silverMismatch = physicalSilverOunces - totalCustomerSilver

            val anomalies = mutableListOf<String>()
            if (Math.abs(goldMismatch) > 0.0001) {
                anomalies.add("RECONCILIATION EXCEPTION: Physical Gold ($physicalGoldOunces oz) does not match Customer Ownership ($totalCustomerGold oz) by $goldMismatch oz!")
            }
            if (Math.abs(silverMismatch) > 0.0001) {
                anomalies.add("RECONCILIATION EXCEPTION: Physical Silver ($physicalSilverOunces oz) does not match Customer Ownership ($totalCustomerSilver oz) by $silverMismatch oz!")
            }

            return mapOf(
                "timestamp" to SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
                "status" to if (anomalies.isEmpty()) "RECONCILED_SUCCESS" else "MISMATCH_ALERT",
                "gold_mismatch_oz" to goldMismatch,
                "silver_mismatch_oz" to silverMismatch,
                "physical_gold_oz" to physicalGoldOunces,
                "customer_gold_oz" to totalCustomerGold,
                "physical_silver_oz" to physicalSilverOunces,
                "customer_silver_oz" to totalCustomerSilver,
                "anomalies" to anomalies
            )
        }
    }

    // 4. SYNTHETIC PAYMENT ADAPTERS
    object PaymentAdapters {
        fun processPayment(
            provider: String, // "PayID", "BPAY", "BankTransfer", "CreditCard"
            amountAud: Double,
            referenceCode: String
        ): Map<String, Any> {
            val isSuccess = when (provider) {
                "CreditCard" -> true // Simulated instant charge
                "PayID" -> true // Fast synthetic transfer
                else -> true // Bank details / BPAY processing
            }
            
            val txId = "TX-" + UUID.randomUUID().toString().take(8).uppercase()
            return mapOf(
                "provider" to provider,
                "transaction_id" to txId,
                "amount_aud" to amountAud,
                "reference" to referenceCode,
                "status" to if (isSuccess) "SETTLED" else "FAILED",
                "timestamp" to SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )
        }
    }

    // 5. AML / KYC ENGINE & COMPLIANCE
    object ComplianceEngine {
        fun evaluateTransactionForAml(
            customerName: String,
            customerType: String,
            amountAud: Double,
            metalType: MetalType,
            quantity: Double,
            paymentMethod: String,
            deliveryType: String
        ): ComplianceCase? {
            // AUSTRAC specifically identifies buying/selling bullion as a designated service.
            // Alert triggers:
            val triggers = mutableListOf<String>()
            var riskScore = 15 // base risk score

            // Cash threshold reporting limit in Australia is $10,000 AUD
            if (amountAud >= 10000.0) {
                triggers.add("Threshold Transaction Flag: Amount exceeds $10,000 AUD limit ($${"%,.2f".format(amountAud)})")
                riskScore += 25
            }

            // High risk triggers
            if (paymentMethod == "Cash" || amountAud > 100000.0) {
                triggers.add("High-value transaction: Elevated volume risk profile")
                riskScore += 35
            }

            if (deliveryType == "SECURE_DELIVERY" && amountAud > 50000.0) {
                triggers.add("Physical Out-Of-Vault Delivery of high metal volume ($quantity units)")
                riskScore += 20
            }

            if (riskScore >= 40) {
                return ComplianceCase(
                    caseId = "AML-CASE-" + UUID.randomUUID().toString().take(6).uppercase(),
                    customerName = customerName,
                    customerType = customerType,
                    riskScore = riskScore,
                    triggerReason = triggers.joinToString(" AND "),
                    transactionsSummary = "Transaction of $quantity ${metalType.name} worth $${"%,.2f".format(amountAud)} via $paymentMethod for $deliveryType",
                    status = "OPEN",
                    analyst = "AUSTRAC Compliance System",
                    createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
                    resolutionNote = if (riskScore > 70) "FLAGGED FOR EXTREME SCRUTINY: AUSTRAC suspicious matter report (SMR) generated automatically." else "Auto-generated alert: Standard Compliance validation required."
                )
            }
            return null
        }
    }
}
