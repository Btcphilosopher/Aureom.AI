package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = AustralianGold,
    secondary = SandstoneMuted,
    tertiary = EucalyptusGreen,
    background = CharcoalDark,
    surface = GraphiteCard,
    onPrimary = BlackText,
    onSecondary = WhiteText,
    onBackground = WhiteText,
    onSurface = WhiteText
  )

private val LightColorScheme =
  lightColorScheme(
    primary = AustralianGold,
    secondary = DeepNavy,
    tertiary = EucalyptusGreen,
    background = WarmWhite,
    surface = WhiteText,
    onPrimary = BlackText,
    onSecondary = WhiteText,
    onBackground = BlackText,
    onSurface = BlackText
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is disabled by default to show brand identity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
