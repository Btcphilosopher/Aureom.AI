package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.AusmetalViewModel

@Composable
fun DealerTerminalScreen(
    viewModel: AusmetalViewModel,
    onBackToClientApp: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf("MARKET") } // MARKET, ORDERS, RFQ, LEDGER, RISK, COMPLIANCE

    val tabs = listOf("MARKET", "ORDERS", "RFQ", "LEDGER", "RISK", "COMPLIANCE")

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalDark)
                    .border(1.dp, BorderColor)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(AustralianGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AUSMETAL PRO-DEALER TERMINAL v3.5",
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            color = AustralianGoldBright,
                            letterSpacing = 1.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = state.systemReconciliationStatus,
                            color = if (state.systemReconciliationStatus == "RECONCILED_SUCCESS") GreenSuccess else AustralianGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .border(1.dp, if (state.systemReconciliationStatus == "RECONCILED_SUCCESS") GreenSuccess else AustralianGold, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = onBackToClientApp,
                            modifier = Modifier
                                .background(GraphiteMedium, RoundedCornerShape(6.dp))
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = WhiteText)
                        }
                    }
                }
            }
        },
        bottomBar = {
            ScrollableTabRow(
                selectedTabIndex = tabs.indexOf(selectedTab),
                containerColor = CharcoalDark,
                contentColor = AustralianGoldBright,
                edgePadding = 12.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                tabs.forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                tab,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }
            }
        },
        containerColor = CharcoalDark
    ) { paddingValues ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Main Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF0C0E10))
                    .padding(12.dp)
            ) {
                when (selectedTab) {
                    "MARKET" -> TerminalMarketTab(viewModel, state)
                    "ORDERS" -> TerminalOrdersTab(viewModel, state)
                    "RFQ" -> TerminalRfqTab(viewModel, state)
                    "LEDGER" -> TerminalLedgerTab(viewModel, state)
                    "RISK" -> TerminalRiskTab(viewModel, state)
                    "COMPLIANCE" -> TerminalComplianceTab(viewModel, state)
                }
            }

            // Right Console Panel (Simulated API Log Stream and Scenario Lab)
            Column(
                modifier = Modifier
                    .width(180.dp)
                    .fillMaxHeight()
                    .border(1.dp, BorderColor)
                    .background(GraphiteCard)
                    .padding(8.dp)
            ) {
                Text(
                    text = "SCENARIO LAB",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SlateText,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                
                val scenarios = listOf(
                    "Gold +10%", "Gold -10%",
                    "Silver +25%", "Silver -25%",
                    "AUD strengthens", "AUD weakens",
                    "Dealer liquidity shock"
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.height(200.dp)
                ) {
                    items(scenarios) { sc ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (state.activeScenario == sc) AustralianGold else GraphiteMedium)
                                .clickable { viewModel.runScenario(sc) }
                                .padding(6.dp)
                        ) {
                            Text(
                                text = sc,
                                color = if (state.activeScenario == sc) BlackText else WhiteText,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = BorderColor)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "API / WS STREAM",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SlateText,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Streaming Websocket logs mock
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black, RoundedCornerShape(4.dp))
                        .padding(4.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        reverseLayout = true
                    ) {
                        items(state.wsConsoleLogs.reversed()) { log ->
                            Text(
                                text = log,
                                color = Color.Green,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.runManualReconciliation() },
                    colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Text("RECONCILE LEDGER", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TerminalMarketTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    Column {
        Text("DEALER LIQUIDITY PRICING FEED", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxSize(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            LazyColumn(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("SYMBOL", color = SlateText, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("BID", color = SlateText, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text("ASK", color = SlateText, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text("CHANGE", color = SlateText, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    }
                }

                items(state.marketPrices) { price ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(price.symbol, color = WhiteText, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(text = "$${"%,.2f".format(price.bid)}", color = SlateText, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text(text = "$${"%,.2f".format(price.ask)}", color = AustralianGold, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text(
                            text = "${if (price.changePercentage >= 0) "+" else ""}${"%.2f".format(price.changePercentage)}%",
                            color = if (price.changePercentage >= 0) GreenSuccess else RedAlert,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
fun TerminalOrdersTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    Column {
        Text("CLIENT PHYSICAL ORDER BOARD", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        if (state.orders.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matching physical orders logged in session.", color = SlateText, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        } else {
            Card(
                modifier = Modifier.fillMaxSize(),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                LazyColumn(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.orders) { order ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("ID: ${order.orderId.take(8).uppercase()}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = WhiteText, fontWeight = FontWeight.Bold)
                                Text("${order.side} | ${order.metalType} | Oz: ${"%.3f".format(order.totalOunces)} | Delivery: ${order.deliveryType}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("AUD $${"%,.2f".format(order.totalAud)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = AustralianGold)
                                Text(order.status.name, color = GreenSuccess, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                        HorizontalDivider(color = BorderColor)
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalRfqTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    var quantityInput by remember { mutableStateOf("10.0") }
    var metalTypeInput by remember { mutableStateOf(MetalType.GOLD) }

    Column {
        Text("INSTITUTIONAL REQUEST-FOR-QUOTE DESK", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("INITIATE SYNTHETIC INSTITUTIONAL BULK RFQ", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = { quantityInput = it },
                        label = { Text("Bulk Quantity (kg)", color = SlateText, fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WhiteText, unfocusedTextColor = WhiteText, focusedBorderColor = AustralianGold, unfocusedBorderColor = BorderColor),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { metalTypeInput = if (metalTypeInput == MetalType.GOLD) MetalType.SILVER else MetalType.GOLD },
                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteMedium, contentColor = WhiteText),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(metalTypeInput.name, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val qty = quantityInput.toDoubleOrNull() ?: 10.0
                            viewModel.submitRfq(metalTypeInput, qty, 999.9, "AUD", "Vault")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AustralianGold, contentColor = BlackText),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("submit_rfq_btn")
                    ) {
                        Text("POST RFQ", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Open RFQ quotes
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.rfqs) { rfq ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GraphiteMedium)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("ID: ${rfq.rfqId}", color = WhiteText, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text(rfq.status, color = if (rfq.status == "ACCEPTED") GreenSuccess else AustralianGoldBright, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                        Text("Metal: ${rfq.metal} | Qty: ${rfq.quantityKg} kg | Purity: ${rfq.purity}% | Settlement: ${rfq.settlementTerms}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                        Text("Offer Ask: AUD $${"%,.2f".format(rfq.offerAud)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = AustralianGoldBright, fontWeight = FontWeight.Bold)

                        if (rfq.status == "QUOTED") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { viewModel.acceptRfq(rfq.rfqId) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess, contentColor = WhiteText),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth().height(36.dp).testTag("accept_rfq_${rfq.rfqId}")
                            ) {
                                Text("ACCEPT & SETTLE QUOTE", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalLedgerTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    Column {
        Text("DOUBLE-ENTRY IMMUTABLE GENERAL LEDGER", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxSize(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            LazyColumn(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.doubleEntryLedger) { entry ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(entry.eventType, color = AustralianGoldBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(entry.timestamp, color = SlateText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("DR: ${entry.debitAccount} | CR: ${entry.creditAccount}", fontSize = 10.sp, color = WhiteText, fontFamily = FontFamily.Monospace)
                            Text("${entry.amount} ${entry.asset}", fontSize = 11.sp, color = if (entry.asset == "AUD") GreenSuccess else Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Text("Narration: ${entry.narration}", fontSize = 10.sp, color = SlateText, fontFamily = FontFamily.Monospace)
                        Text("SHA256 Hash: ${entry.auditHash.take(24)}...", fontSize = 8.sp, color = SlateText, fontFamily = FontFamily.Monospace)
                        HorizontalDivider(color = BorderColor.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalRiskTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    Column {
        Text("RISK EXPOSURE ENGINE & PRICING PARAMETERS", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxSize(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("REAL-TIME CONCENTRATION RISK METRICS", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    RiskCard(title = "Gold Position", value = "${"%.3f".format(state.goldAllocatedOz + state.goldUnallocatedOz)} oz", riskStatus = "OPTIMAL", modifier = Modifier.weight(1f))
                    RiskCard(title = "Silver Position", value = "${"%.2f".format(state.silverAllocatedOz + state.silverUnallocatedOz)} oz", riskStatus = "OPTIMAL", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    RiskCard(title = "FX Exposure (USD)", value = "$${"%,.2f".format((state.goldAllocatedOz + state.goldUnallocatedOz) * 3523.0)} USD", riskStatus = "HEDGED", modifier = Modifier.weight(1f))
                    RiskCard(title = "Cash Reserves", value = "$${"%,.2f".format(state.cashBalanceAud)} AUD", riskStatus = "STABLE", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = BorderColor)
                Spacer(modifier = Modifier.height(16.dp))

                Text("RECONCILIATION INTEGRITY SCORE", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(GreenSuccess, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Physical Bar Allocation matches double-entry ledger database 100%. Mismatch factor is 0.00%.", color = WhiteText, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun RiskCard(title: String, value: String, riskStatus: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = GraphiteMedium)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(title, fontSize = 10.sp, color = SlateText, fontFamily = FontFamily.Monospace)
                Text(riskStatus, fontSize = 10.sp, color = GreenSuccess, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WhiteText, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun TerminalComplianceTab(viewModel: AusmetalViewModel, state: com.example.viewmodel.AusmetalUiState) {
    Column {
        Text("AUSTRAC COMPLIANCE & AML CASE CENTRE", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AustralianGoldBright, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))

        if (state.complianceCases.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No designated service AML/CTF alerts generated. System fully verified.", color = GreenSuccess, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        } else {
            Card(
                modifier = Modifier.fillMaxSize(),
                colors = CardDefaults.cardColors(containerColor = GraphiteCard)
            ) {
                LazyColumn(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.complianceCases) { case ->
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("ID: ${case.caseId}", color = RedAlert, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("Risk Score: ${case.riskScore}/100", color = if (case.riskScore > 60) RedAlert else AustralianGold, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                            }
                            Text("Customer: ${case.customerName} | Class: ${case.customerType}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = WhiteText)
                            Text("Trigger: ${case.triggerReason}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AustralianGoldBright)
                            Text("Summary: ${case.transactionsSummary}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                            case.resolutionNote?.let { note ->
                                Text("AUSTRAC SMR Action: $note", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = SlateText)
                            }
                            HorizontalDivider(color = BorderColor)
                        }
                    }
                }
            }
        }
    }
}
