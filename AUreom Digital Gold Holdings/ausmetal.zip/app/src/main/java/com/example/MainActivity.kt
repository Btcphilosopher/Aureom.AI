package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.CustomerAppScreen
import com.example.ui.screens.DealerTerminalScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AusmetalViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        var isDealerMode by remember { mutableStateOf(false) }
        val viewmodel: AusmetalViewModel = viewModel()

        if (isDealerMode) {
          DealerTerminalScreen(
            viewModel = viewmodel,
            onBackToClientApp = { isDealerMode = false }
          )
        } else {
          CustomerAppScreen(
            viewModel = viewmodel,
            onDealerTerminalToggle = { isDealerMode = true }
          )
        }
      }
    }
  }
}

