package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import java.util.Locale
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.data.repository.AureoRepository
import com.example.ui.theme.*

// --- MAIN COMPOSE APP ENTRY CONTAINER ---
@Composable
fun AureoAppContainer(viewModel: AureoViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Handle system back button press with our back navigation stack
    BackHandler(enabled = currentScreen != AureoScreen.Dashboard) {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = { AureoTopBar(viewModel) },
        bottomBar = { AureoBottomNavigation(viewModel) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { screen ->
                // Apply mobile responsive width limits
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 600.dp)
                        .align(Alignment.Center)
                ) {
                    when (screen) {
                        is AureoScreen.Dashboard -> DashboardScreen(viewModel)
                        is AureoScreen.GoldDetail -> GoldDetailScreen(viewModel)
                        is AureoScreen.SilverDetail -> SilverDetailScreen(viewModel)
                        is AureoScreen.BarPassport -> BarPassportScreen(viewModel, screen.barId)
                        is AureoScreen.VaultTwin -> VaultTwinScreen(viewModel)
                        is AureoScreen.BuyMetal -> BuyMetalScreen(viewModel)
                        is AureoScreen.SellMetal -> SellMetalScreen(viewModel)
                        is AureoScreen.Compliance -> ComplianceScreen(viewModel)
                        is AureoScreen.ComproOro -> ComproOroScreen(viewModel)
                        is AureoScreen.FamilyOffice -> FamilyOfficeScreen(viewModel)
                        is AureoScreen.Documents -> DocumentsScreen(viewModel)
                        is AureoScreen.AiAssistant -> AiAssistantScreen(viewModel)
                    }
                }
            }
        }
    }
}

// --- TOP LUXURY BRANDING BAR ---
@Composable
fun AureoTopBar(viewModel: AureoViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isLight = MaterialTheme.colorScheme.background == WarmParchment

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isLight) WarmParchment else DeepCharcoal)
            .statusBarsPadding()
            .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (currentScreen != AureoScreen.Dashboard) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier
                    .size(40.dp)
                    .testTag("top_bar_back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Torna indietro",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        } else {
            // Elegant brand crest icon
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        brush = Brush.radialGradient(listOf(BrushedGold, Bronze)),
                        shape = RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "A",
                    color = DeepCharcoal,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "AUREO ITALIA",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                color = MaterialTheme.colorScheme.primary,
                fontFamily = FontFamily.Serif
            )
            Text(
                text = "PRIVATE WEALTH & SECURE VAULT",
                fontSize = 8.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 1.5.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        // Italian Segment Badge
        Box(
            modifier = Modifier
                .border(
                    BorderStroke(1.dp, MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = "PRIVATE",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

// --- FLOATING / BOTTOM NAVIGATION PILL ---
@Composable
fun AureoBottomNavigation(viewModel: AureoViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isLight = MaterialTheme.colorScheme.background == WarmParchment

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isLight) OffWhite else WarmCharcoal)
            .navigationBarsPadding()
            .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val navItems = listOf(
            Triple(AureoScreen.Dashboard, Icons.Default.Home, "HOME"),
            Triple(AureoScreen.GoldDetail, Icons.Default.Star, "ORO"),
            Triple(AureoScreen.SilverDetail, Icons.Default.Circle, "ARGENTO"),
            Triple(AureoScreen.VaultTwin, Icons.Default.Lock, "CUSTODIA"),
            Triple(AureoScreen.AiAssistant, Icons.Default.Forum, "AUREO AI")
        )

        navItems.forEach { (targetScreen, icon, label) ->
            val isActive = currentScreen::class == targetScreen::class

            Column(
                modifier = Modifier
                    .testTag("nav_item_${label.lowercase()}")
                    .clickable { viewModel.navigateTo(targetScreen) }
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

// --- SCREEN 1: CLIENT PRIVATE PORTFOLIO DASHBOARD ---
@Composable
fun DashboardScreen(viewModel: AureoViewModel) {
    val account by viewModel.currentAccount.collectAsState()
    val goldValuation by viewModel.goldTotalValuation.collectAsState()
    val silverValuation by viewModel.silverTotalValuation.collectAsState()
    val totalValuation by viewModel.portfolioTotalValuation.collectAsState()
    val activeBars by viewModel.bars.collectAsState()
    val currentClient by viewModel.currentClient.collectAsState()

    val repo = AureoRepository
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Welcome Private Greeting
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "BUONGIORNO",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = currentClient?.name?.uppercase(Locale.ITALIAN) ?: "FAMIGLIA BIANCHI",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            // Status Indicator
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(SuccessGreen, shape = RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "RETE CUSTODIA SICURA",
                    fontSize = 9.sp,
                    color = SuccessGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Total Wealth Portfolio Panel (Luxury Private Banking Statement Style)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "IL TUO PATRIMONIO IN METALLI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "€ ${repo.currencyFormat.format(totalValuation)}",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("total_wealth_text")
                )
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(12.dp))

                // Gold Weight Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(BrushedGold, shape = RoundedCornerShape(2.dp)))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "ORO FISICO", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${repo.weightFormat.format((account?.goldAllocatedOz ?: 0.0) + (account?.goldUnallocatedOz ?: 0.0))} oz",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "€ ${repo.currencyFormat.format(goldValuation)}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Silver Weight Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(Color(0xFFB0C4DE), shape = RoundedCornerShape(2.dp)))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "ARGENTO FISICO", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${repo.weightFormat.format((account?.silverAllocatedKg ?: 0.0) + (account?.silverUnallocatedKg ?: 0.0))} kg",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "€ ${repo.currencyFormat.format(silverValuation)}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Account Cash Ledger Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(Espresso, shape = RoundedCornerShape(2.dp)))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "LIQUIDITÀ DISPONIBILE", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "€ ${repo.currencyFormat.format(account?.cashBalanceEur ?: 0.0)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Primary Operational Action Rows
        Text(
            text = "OPERATIVITÀ FISICA",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { viewModel.navigateTo(AureoScreen.BuyMetal) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dashboard_buy_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "ACQUISTA ORO", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { viewModel.navigateTo(AureoScreen.SellMetal) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("dashboard_sell_button")
            ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "LIQUIDA METALLO", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Grid Menu of Premium Digital Operational Systems Modules
        Text(
            text = "SISTEMA OPERATIVO DI CUSTODIA",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MenuGridItem(
                    title = "REGISTRO OAM & COMPLIANCE",
                    desc = "KYC, Screening Sanzioni, AML",
                    icon = Icons.Default.VerifiedUser,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AureoScreen.Compliance) }
                )
                MenuGridItem(
                    title = "FAMILY OFFICE CONSOLE",
                    desc = "Holding, Trust, Aggregazione",
                    icon = Icons.Default.BusinessCenter,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AureoScreen.FamilyOffice) }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MenuGridItem(
                    title = "ORO USATO (COINTEG)",
                    desc = "Valutazione e saggio gioielleria",
                    icon = Icons.Default.LocalActivity,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AureoScreen.ComproOro) }
                )
                MenuGridItem(
                    title = "DIGITAL TWIN CAVEAU",
                    desc = "Spazio, Occupazione, Audit",
                    icon = Icons.Default.QrCodeScanner,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AureoScreen.VaultTwin) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Your Allocated bars quick selection row
        Text(
            text = "I TUOI LINGOTTI FISICI (ALLOCAZIONE MILANO)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        val allocatedBars = activeBars.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.status == CustodyStatus.ALLOCATED }
        allocatedBars.forEach { bar ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(8.dp))
                    .clickable { viewModel.navigateTo(AureoScreen.BarPassport(bar.id)) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    brush = Brush.linearGradient(
                                        if (bar.metal == MetalType.GOLD) listOf(BrushedGold, Bronze) else listOf(Color(0xFFE2E2E2), Color(0xFF909090))
                                    ),
                                    shape = RoundedCornerShape(6.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (bar.metal == MetalType.GOLD) Icons.Default.Square else Icons.Default.Circle,
                                contentDescription = null,
                                tint = if (bar.metal == MetalType.GOLD) WarmCharcoal else DeepCharcoal,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = bar.serialNumber,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Raffineria: ${bar.manufacturer}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${bar.fineWeightOzOrKg} ${if (bar.metal == MetalType.GOLD) "oz" else "kg"}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "€ ${repo.currencyFormat.format(bar.valuationEur)}",
                            fontSize = 11.sp,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Disclaimer Fiscale (Italian Rule Compliant)
        Text(
            text = "I rendiconti, le valutazioni e le transazioni qui fornite fanno parte del framework operativo di simulazione di Aureo Italia. CALCOLO INFORMATIVO — NON COSTITUISCE CONSULENZA FISCALE.",
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        )
    }
}

@Composable
fun MenuGridItem(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)), shape = RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .height(100.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = desc,
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// --- SCREEN 2: GOLD DETAIL SCREEN ---
@Composable
fun GoldDetailScreen(viewModel: AureoViewModel) {
    val account by viewModel.currentAccount.collectAsState()
    val activeBars by viewModel.bars.collectAsState()
    val ledger by viewModel.goldLedger.collectAsState()
    val goldValuation by viewModel.goldTotalValuation.collectAsState()

    val repo = AureoRepository
    val goldBars = activeBars.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.metal == MetalType.GOLD && it.status == CustodyStatus.ALLOCATED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "ORO INVESTIMENTO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Rendimento e Allocazione Gold",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Gold Balance Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "VALORE COMPLESSIVO ORO FISICO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "€ ${repo.currencyFormat.format(goldValuation)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(text = "Peso Totale", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format((account?.goldAllocatedOz ?: 0.0) + (account?.goldUnallocatedOz ?: 0.0))} oz", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Quota Allocata", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format(account?.goldAllocatedOz ?: 0.0)} oz", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(text = "Prezzo Spot XAU/EUR", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "€ ${repo.currencyFormat.format(repo.marketData.getGoldSpotPriceEur())} / oz", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Quota Pool (Non Allocato)", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format(account?.goldUnallocatedOz ?: 0.0)} oz", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Subtitle: Lingotti Fisici Allocati
        item {
            Text(
                text = "LINGOTTI REGISTRATI IN CAVEAU MILANO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        if (goldBars.isEmpty()) {
            item {
                Text(
                    text = "Nessun lingotto oro allocato in questo compartimento.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(goldBars) { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(8.dp))
                        .clickable { viewModel.navigateTo(AureoScreen.BarPassport(bar.id)) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        brush = Brush.linearGradient(listOf(BrushedGold, Bronze)),
                                        shape = RoundedCornerShape(6.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Square, contentDescription = null, tint = WarmCharcoal, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = bar.serialNumber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Titolo: ${bar.fineness} - Certificato", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "${bar.fineWeightOzOrKg} oz", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "€ ${repo.currencyFormat.format(bar.valuationEur)}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Subtitle: Storico Transazioni
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "LEDGER STORICO TRANSAZIONI ORO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(ledger.reversed()) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = entry.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(text = entry.reference, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = entry.timestamp, fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f))
                }
                Text(
                    text = "${if (entry.deltaOz > 0) "+" else ""}${repo.weightFormat.format(entry.deltaOz)} oz",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (entry.deltaOz > 0) SuccessGreen else ErrorRed
                )
            }
        }
    }
}

// --- SCREEN 3: SILVER DETAIL SCREEN ---
@Composable
fun SilverDetailScreen(viewModel: AureoViewModel) {
    val account by viewModel.currentAccount.collectAsState()
    val activeBars by viewModel.bars.collectAsState()
    val ledger by viewModel.silverLedger.collectAsState()
    val silverValuation by viewModel.silverTotalValuation.collectAsState()

    val repo = AureoRepository
    val silverBars = activeBars.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.metal == MetalType.SILVER && it.status == CustodyStatus.ALLOCATED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "ARGENTO FISICO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Rendimento e Allocazione Silver",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Silver Balance Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "VALORE COMPLESSIVO ARGENTO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "€ ${repo.currencyFormat.format(silverValuation)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(text = "Peso Totale", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format((account?.silverAllocatedKg ?: 0.0) + (account?.silverUnallocatedKg ?: 0.0))} kg", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Quota Allocata", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format(account?.silverAllocatedKg ?: 0.0)} kg", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF708090))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(text = "Prezzo Spot XAG/EUR", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "€ ${repo.currencyFormat.format(repo.marketData.getSilverSpotPriceEur())} / kg", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Quota Pool (Non Allocato)", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(text = "${repo.weightFormat.format(account?.silverUnallocatedKg ?: 0.0)} kg", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Nota Fiscale: L'argento da investimento è soggetto ad IVA italiana ordinaria del 22% al momento dell'acquisto fisico.",
                        fontSize = 10.sp,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Subtitle: Lingotti Fisici Allocati
        item {
            Text(
                text = "LINGOTTI REGISTRATI IN CAVEAU MILANO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        if (silverBars.isEmpty()) {
            item {
                Text(
                    text = "Nessun lingotto argento allocato in questo compartimento.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(silverBars) { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(8.dp))
                        .clickable { viewModel.navigateTo(AureoScreen.BarPassport(bar.id)) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        brush = Brush.linearGradient(listOf(Color(0xFFE2E2E2), Color(0xFF909090))),
                                        shape = RoundedCornerShape(6.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Circle, contentDescription = null, tint = DeepCharcoal, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = bar.serialNumber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Raffineria: ${bar.manufacturer}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "${bar.fineWeightOzOrKg} kg", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "€ ${repo.currencyFormat.format(bar.valuationEur)}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Subtitle: Storico Transazioni
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "LEDGER STORICO TRANSAZIONI ARGENTO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(ledger.reversed()) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = entry.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(text = entry.reference, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = entry.timestamp, fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f))
                }
                Text(
                    text = "${if (entry.deltaKg > 0) "+" else ""}${repo.weightFormat.format(entry.deltaKg)} kg",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (entry.deltaKg > 0) SuccessGreen else ErrorRed
                )
            }
        }
    }
}

// --- SCREEN 4: BAR PASSPORT SCREEN (PASSAPORTO DEL LINGOTTO) ---
@Composable
fun BarPassportScreen(viewModel: AureoViewModel, barId: String) {
    val barsList by viewModel.bars.collectAsState()
    val eventsList by viewModel.passportEvents.collectAsState()
    val compartmentsList by viewModel.compartments.collectAsState()

    val mfaInput by viewModel.mfaInputCode.collectAsState()
    val moveSuccess by viewModel.moveSuccessState.collectAsState()

    val repo = AureoRepository
    val bar = barsList.firstOrNull { it.id == barId } ?: return
    val barEvents = eventsList.filter { it.barId == barId }

    val isGold = bar.metal == MetalType.GOLD

    var showMoveConsole by remember { mutableStateOf(false) }
    var selectedTargetCompartment by remember { mutableStateOf("COMP-MI-2") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "PASSAPORTO DEL LINGOTTO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Certificazione di Provenienza & Audit",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Luxurious Physical Bar Graphic
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(
                        brush = Brush.linearGradient(
                            if (isGold) listOf(DeepCharcoal, Espresso) else listOf(WarmCharcoal, Espresso)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        BorderStroke(
                            2.dp,
                            brush = Brush.linearGradient(
                                if (isGold) listOf(BrushedGold, Bronze) else listOf(Color(0xFFE2E2E2), Color(0xFF909090))
                            )
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(
                                text = if (isGold) "LINGOTTO ORO FINE" else "LINGOTTO ARGENTO FINE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp,
                                color = if (isGold) LightGold else Color.LightGray
                            )
                            Text(
                                text = bar.serialNumber,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                color = Color.White
                            )
                        }
                        Text(
                            text = if (isGold) "999.9 ORO" else "999.0 ARGENTO",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isGold) BrushedGold else Color.LightGray,
                            modifier = Modifier
                                .border(
                                    BorderStroke(1.dp, if (isGold) BrushedGold else Color.LightGray),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Column {
                            Text(text = "RAFFINERIA", fontSize = 8.sp, color = Color.Gray)
                            Text(text = bar.manufacturer, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PESO FINE", fontSize = 8.sp, color = Color.Gray)
                            Text(text = "${bar.fineWeightOzOrKg} ${if (isGold) "oz" else "kg"}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (isGold) BrushedGold else Color.White)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Details Block
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Rendimento e Dettagli Proprietà", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailRow(label = "Certificato ID", value = bar.certificateId)
                    DetailRow(label = "Finitura Titolo", value = "${bar.fineness} Purity")
                    DetailRow(label = "Struttura Custode", value = bar.vaultId)
                    DetailRow(label = "Scompartimento", value = bar.compartmentId)
                    DetailRow(label = "Stato Custodia", value = bar.status.name)
                    DetailRow(label = "Valutazione Corrente", value = "€ ${repo.currencyFormat.format(bar.valuationEur)}")
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Interactive Audit and Relocation Console
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MOVIMENTAZIONE DI SICUREZZA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Sposta Scompartimento blindato",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (!showMoveConsole) {
                        Button(
                            onClick = { showMoveConsole = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "AVVIA TRASFERIMENTO DI COMPARTIMENTO", fontSize = 12.sp)
                        }
                    } else {
                        Text(text = "Seleziona Scompartimento Destinazione:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            compartmentsList.forEach { comp ->
                                val isSelected = selectedTargetCompartment == comp.id
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(
                                            BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) BrushedGold else Color.Gray),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .clickable { selectedTargetCompartment = comp.id }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = comp.compartmentName, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Inserisci Codice MFA Dispositivo Privato (Digita '1918' per autorizzare):",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        OutlinedTextField(
                            value = mfaInput,
                            onValueChange = { viewModel.setMfaCode(it) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            placeholder = { Text(text = "MFA Security Code") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("mfa_input_field"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { showMoveConsole = false },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = "ANNULLA", fontSize = 12.sp)
                            }
                            Button(
                                onClick = {
                                    viewModel.executeMoveCompartment(bar.id, selectedTargetCompartment)
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("mfa_confirm_move_button")
                            ) {
                                Text(text = "CONFERMA TRASFERIMENTO", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        moveSuccess?.let { msg ->
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = msg,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (msg.startsWith("SUCCESSO")) SuccessGreen else ErrorRed,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Provenance Timeline track
        item {
            Text(
                text = "TRACCIABILITÀ CRITTOGRAFICA DI PROVENIENZA",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        items(barEvents) { ev ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                    .padding(14.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(BrushedGold, shape = RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = ev.eventType,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Operatore: ${ev.actor}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = "Luogo: ${ev.location}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = "Documento Rif: ${ev.documentReference}", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f))
                    Text(
                        text = "Hash Audit: ${ev.cryptographicHash}",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                    )
                }

                Text(
                    text = ev.timestamp.split(" ")[0],
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

// --- SCREEN 5: VAULT DIGITAL TWIN SCREEN ---
@Composable
fun VaultTwinScreen(viewModel: AureoViewModel) {
    val facilityList by viewModel.vaults.collectAsState()
    val isReconciling by viewModel.isReconciling.collectAsState()
    val reconLogs by viewModel.reconciliationLog.collectAsState()
    val status by viewModel.reconciliationStatus.collectAsState()

    val repo = AureoRepository
    val milanoVault = facilityList.firstOrNull { it.id == "VAULT-MI-01" } ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "DIGITAL TWIN DELLA CASSAFORTE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Struttura Interna Milano 01",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Fictional Blueprint Diagram Placeholder (M3 Styled Canvas Drawing)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(DeepCharcoal, shape = RoundedCornerShape(10.dp))
                .border(BorderStroke(1.dp, BrushedGold), shape = RoundedCornerShape(10.dp))
                .padding(16.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Drawing an elegant architectural vector line map of security zones
                val w = size.width
                val h = size.height

                // Draw outline grid
                drawRect(color = Color.DarkGray, size = size, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                drawLine(color = Color.DarkGray, start = androidx.compose.ui.geometry.Offset(w * 0.3f, 0f), end = androidx.compose.ui.geometry.Offset(w * 0.3f, h))
                drawLine(color = Color.DarkGray, start = androidx.compose.ui.geometry.Offset(0f, h * 0.5f), end = androidx.compose.ui.geometry.Offset(w, h * 0.5f))

                // Highlight high security zone
                drawRect(
                    color = BrushedGold.copy(alpha = 0.15f),
                    size = androidx.compose.ui.geometry.Size(w * 0.3f, h * 0.5f)
                )
            }

            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "CUSTODIA MILANO 01 - BLUEPRINT", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = BrushedGold)
                    Text(text = "RETE PROTETTA", fontSize = 8.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = "Caveau A: Zona Alta Sicurezza", fontSize = 9.sp, color = Color.White)
                        Text(text = "Caveau B: Custodia Generale", fontSize = 9.sp, color = Color.White)
                        Text(text = "Forziere S-24: Oro Fisico Allocato", fontSize = 9.sp, color = BrushedGold)
                    }
                }

                Text(
                    text = "AUREO CRYPTO AUDIT TRACK RECONCILIATION ENABLED",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Capacity and Live Occupancy Stats
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SPECIFICHE CAVEAU & OCCUPAZIONE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(12.dp))

                DetailRow(label = "Capacità Totale", value = "${repo.currencyFormat.format(milanoVault.capacityKg)} kg")
                DetailRow(label = "Spazio Occupato Oro", value = "${repo.currencyFormat.format(milanoVault.occupiedGoldKg)} kg")
                DetailRow(label = "Spazio Occupato Argento", value = "${repo.currencyFormat.format(milanoVault.occupiedSilverKg)} kg")
                DetailRow(label = "Livello Sicurezza", value = milanoVault.securityLevel)
                DetailRow(label = "Presidio Fisico H24", value = "Esercito Privato Battistolli")

                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "Carico Percentuale Capacità:", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                LinearProgressIndicator(
                    progress = 0.63f,
                    color = BrushedGold,
                    trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Daily Audit Reconciliation Console Block
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AUDITING REGISTRI FISICI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "Riconciliazione Metalli",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(
                                if (status == "RECONCILIED_TODAY") SuccessGreen else WarningOrange,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (status == "RECONCILIED_TODAY") "RICONCILIATO" else "AUDITING",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Esegui il confronto automatico tra l'allocazione fisica effettiva nei cassetti blindati, i ledger di carico/scarico d'acquisto e il registro di cassa generale.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.runAuditReconciliation() },
                    enabled = !isReconciling,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("run_audit_reconciliation_button")
                ) {
                    if (isReconciling) {
                        CircularProgressIndicator(color = DeepCharcoal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "ELABORAZIONE CONFRONTO...", fontSize = 12.sp)
                    } else {
                        Icon(imageVector = Icons.Default.QrCode, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "AVVIA RICONCILIAZIONE CON CAVEAU", fontSize = 12.sp)
                    }
                }

                if (reconLogs.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal, shape = RoundedCornerShape(6.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            reconLogs.forEach { log ->
                                Text(
                                    text = log,
                                    color = Color(0xFF39FF14), // Terminal Green
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 6: BUY METAL SCREEN (RFQ WORKFLOW) ---
@Composable
fun BuyMetalScreen(viewModel: AureoViewModel) {
    val productsList by viewModel.products.collectAsState()
    val selectedProduct by viewModel.purchaseSelectedProduct.collectAsState()
    val quantity by viewModel.purchaseQuantity.collectAsState()
    val quote by viewModel.activeQuote.collectAsState()
    val isLoadingQuote by viewModel.isRequestingQuote.collectAsState()
    val successOrder by viewModel.purchaseSuccessOrder.collectAsState()
    val account by viewModel.currentAccount.collectAsState()

    val repo = AureoRepository
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "PRIMARIO BULLION DEALING",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Acquisto Lingotti Fisici",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (successOrder == null) {
            // STEP 1: SELECT BULLION CATALOG PRODUCT
            Text(
                text = "1. SELEZIONA PRODOTTO DA CATALOGO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            productsList.forEach { prod ->
                val isSelected = selectedProduct?.id == prod.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(
                            BorderStroke(
                                if (isSelected) 2.dp else 1.dp,
                                if (isSelected) BrushedGold else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.selectPurchaseProduct(prod) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${prod.metal.name}: ${prod.brand}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Spec: ${prod.fineWeightGram} g / ${prod.fineness} Purity (${prod.manufacturer})",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        // Premium Tag
                        Box(
                            modifier = Modifier
                                .background(Espresso, shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Premio +${(prod.defaultPremiumPercent * 100).coerceAtLeast(0.1)}%",
                                fontSize = 9.sp,
                                color = WarmParchment,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // STEP 2: QUANTITY INPUT
            selectedProduct?.let { prod ->
                Text(
                    text = "2. SPECIFICA QUANTITÀ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = { viewModel.setPurchaseQuantity(quantity - 1) },
                        modifier = Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Diminuisci")
                    }

                    Text(
                        text = "$quantity pezzi",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    IconButton(
                        onClick = { viewModel.setPurchaseQuantity(quantity + 1) },
                        modifier = Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Aumenta")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // STEP 3: QUOTE ENQUIRY (RFQ IN TEMPO REALE)
                Button(
                    onClick = { viewModel.requestQuote() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("request_rfq_button")
                ) {
                    if (isLoadingQuote) {
                        CircularProgressIndicator(color = DeepCharcoal, modifier = Modifier.size(18.dp))
                    } else {
                        Text(text = "RICHIEDI QUOTAZIONE IN TEMPO REALE (RFQ)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // STEP 4: QUOTE CONFIRMATION LAYOVER
            quote?.let { q ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, BrushedGold), shape = RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "QUOTAZIONE BLOCATA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
                            Text(text = "Rif: ${q.id}", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        DetailRow(label = "Prezzo Spot Metallo", value = "€ ${repo.currencyFormat.format(q.spotPricePerUnit)}")
                        DetailRow(label = "Spesa di Conio / Premium", value = "€ ${repo.currencyFormat.format(q.physicalPremiumEur)}")
                        DetailRow(label = "IVA italiana applicabile", value = "€ ${repo.currencyFormat.format(q.taxVatEur)}")
                        DetailRow(label = "Costo Totale", value = "€ ${repo.currencyFormat.format(q.totalCostEur)}")
                        DetailRow(label = "Spesa di Custodia Caveau", value = "Spazio Milano ${q.storageFeeAnnualPercent * 100}% Annui")

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Scadenza offerta: ${q.validUntilTimestamp}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            fontStyle = FontStyle.Italic
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Trigger confirm with cash ledger
                        Button(
                            onClick = { viewModel.confirmPurchase("Private Wealth Cash Ledger") },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("confirm_purchase_gold_button")
                        ) {
                            Text(text = "ACCETTA ED ALLOCA FISICAMENTE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

        } else {
            // SUCCESS PURCHASE DISPLAY
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(2.dp, SuccessGreen), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "ACQUISTO COMPLETATO CON SUCCESSO",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Il vostro ordine ${successOrder?.id} è stato regolato sul Conto Metalli.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "È stato prelevato un lingotto specifico dai forzieri di cassa con numero seriale unico ed associato irrevocabilmente alla Famiglia Bianchi.",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.selectPurchaseProduct(productsList.first()) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "NUOVO ACQUISTO", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { viewModel.navigateTo(AureoScreen.Dashboard) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "TORNA ALLA HOME", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 7: SELL METAL SCREEN (LIQUIDATION FLOW) ---
@Composable
fun SellMetalScreen(viewModel: AureoViewModel) {
    val barsList by viewModel.bars.collectAsState()
    val selectedBarId by viewModel.saleSelectedBarId.collectAsState()
    val successMsg by viewModel.saleSuccessMessage.collectAsState()

    val repo = AureoRepository
    val allocatedBars = barsList.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.status == CustodyStatus.ALLOCATED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "BROKER LIQUIDAZIONE METALLI",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Disinvestimento e Cessione",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (successMsg == null) {
            Text(
                text = "SELEZIONA IL LINGOTTO FISICO DA DISINVESTIRE:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (allocatedBars.isEmpty()) {
                Text(text = "Non disponete attualmente di lingotti fisici allocati per il disinvestimento.", fontSize = 13.sp, color = Color.Gray)
            } else {
                allocatedBars.forEach { bar ->
                    val isSelected = selectedBarId == bar.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(
                                BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) BrushedGold else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.selectSaleBar(bar.id) },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = bar.serialNumber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Raffineria: ${bar.manufacturer} / ${bar.fineWeightOzOrKg} ${if (bar.metal == MetalType.GOLD) "oz" else "kg"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Text(text = "€ ${repo.currencyFormat.format(bar.valuationEur)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                selectedBarId?.let { barId ->
                    val bar = allocatedBars.first { it.id == barId }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, BrushedGold), shape = RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "PROPOSTA DI LIQUIDAZIONE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.height(8.dp))

                            val currentSpot = if (bar.metal == MetalType.GOLD) repo.marketData.getGoldSpotPriceEur() else repo.marketData.getSilverSpotPriceEur()
                            val baseVal = bar.fineWeightOzOrKg * currentSpot
                            val finalOffer = baseVal * 0.995 // 0.5% broker charge

                            DetailRow(label = "Valutazione base metallo", value = "€ ${repo.currencyFormat.format(baseVal)}")
                            DetailRow(label = "Commissione Deal (0,5%)", value = "€ ${repo.currencyFormat.format(baseVal * 0.005)}")
                            DetailRow(label = "Importo di Liquidazione", value = "€ ${repo.currencyFormat.format(finalOffer)}")

                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = { viewModel.executeSale() },
                                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("confirm_sell_metal_button")
                            ) {
                                Text(text = "VENDI E ACCREDITA CONTANTI", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, SuccessGreen), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "DISINVESTIMENTO COMPLETATO", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = successMsg ?: "", fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.navigateTo(AureoScreen.Dashboard) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "TORNA ALLA DASHBOARD", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// --- SCREEN 8: ITALIAN COMPLIANCE & OAM FRAMEWORK SCREEN ---
@Composable
fun ComplianceScreen(viewModel: AureoViewModel) {
    val cases by viewModel.complianceCases.collectAsState()
    val repo = AureoRepository

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "REGISTRO OPERATORI COMPLIANCE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Architettura Antiriciclaggio OAM",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Italian OPO framework notice block
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, BorderGold), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Riferimento Vigilanza OAM", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Aureo Italia opera in piena aderenza al quadro legislativo italiano coordinato dall'Organismo degli Agenti e dei Mediatori (OAM), incaricato del registro degli Operatori Professionali in Oro (OPO) ai sensi del D.Lgs. 92/2017.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Risk score dashboard widget
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "PUNTEGGIO DI RISCHIO AML (BIANCHI)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Punteggio: 15 / 100", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                            Text(text = "Fascia: Rischio Molto Basso", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Box(
                            modifier = Modifier
                                .background(SuccessGreen.copy(alpha = 0.1f), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(text = "KYV VERIFIED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // List of compliance events
        item {
            Text(
                text = "REGISTRO EVENTI DI VERIFICA CRITTOGRAFICA",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(cases) { c ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = c.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Box(
                            modifier = Modifier
                                .background(SuccessGreen, shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = c.status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = c.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Protocollo OAM: ${c.verificationReference}",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

// --- SCREEN 9: COMPRO ORO ("ORO USATO" SEPARATED MODULE) ---
@Composable
fun ComproOroScreen(viewModel: AureoViewModel) {
    val basket by viewModel.comproOroIntakeBasket.collectAsState()
    val currentOffer by viewModel.currentActiveUsedGoldOffer.collectAsState()
    val receiptState by viewModel.comproOroReceiptState.collectAsState()

    // Inputs
    val desc by viewModel.usedGoldItemDescription.collectAsState()
    val weight by viewModel.usedGoldGrossWeight.collectAsState()
    val fineness by viewModel.usedGoldFineness.collectAsState()

    val sellerName by viewModel.comproOroSellerName.collectAsState()
    val sellerTaxCode by viewModel.comproOroSellerTaxCode.collectAsState()
    val sellerDocId by viewModel.comproOroSellerDocId.collectAsState()

    val repo = AureoRepository
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // High visibility compliance partition banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, ErrorRed), shape = RoundedCornerShape(6.dp)),
            colors = CardDefaults.cardColors(containerColor = ErrorRed.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SEPARAZIONE LEGALE IMPORTANTE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ErrorRed
                )
                Text(
                    text = "La compravendita di oro usato da recupero (gioielleria dismessa, rottami d'oro) è normata separatamente dalla vendita di lingotti d'investimento. Questo pannello gestisce l'intake di gioielli destinati a fusione e affinazione.",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "MODULO PROFESSIONAL ORO USATO",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Accettazione & Saggio Gioielleria",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (receiptState == null) {
            // STEP 1: ITEM INTAKE INPUTS
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "1. INSERIMENTO OGGETTO USATO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = desc,
                        onValueChange = { viewModel.setUsedGoldInputs(it, weight, fineness) },
                        label = { Text("Descrizione oggetto (es. Collana 18k)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = weight,
                            onValueChange = { viewModel.setUsedGoldInputs(desc, it, fineness) },
                            label = { Text("Peso Lordo (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = fineness,
                            onValueChange = { viewModel.setUsedGoldInputs(desc, weight, it) },
                            label = { Text("Caratura/Titolo (es. 750)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.evaluateUsedGold() },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "ESEGUI SAGGIO E CALCOLA OFFERTA", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // STEP 2: ACTIVE ESTIMATED OFFER LAYOVER
            currentOffer?.let { offer ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, BrushedGold), shape = RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "RAPPORTO DI STIMA & SAGGIATURA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(8.dp))

                        DetailRow(label = "Peso fine calcolato", value = "${repo.weightFormat.format(offer.fineWeightGram)} g")
                        DetailRow(label = "Prezzo Spot di Riferimento", value = "€ ${repo.currencyFormat.format(offer.spotPriceGram)} / g")
                        DetailRow(label = "Margine di Recupero (8%)", value = "€ ${repo.currencyFormat.format(offer.calculatedValueEur - offer.finalOfferEur)}")
                        DetailRow(label = "OFFERTA DI LIQUIDAZIONE NETTA", value = "€ ${repo.currencyFormat.format(offer.finalOfferEur)}")

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.addItemToComproOroBasket() },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "AGGIUNGI AL REGISTRO DI RITIRO", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // STEP 3: BASKET LIST
            if (basket.isNotEmpty()) {
                Text(text = "OGGETTI PRONTI PER IL RITIRO FISICO:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                basket.forEach { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = item.description, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Carato: ${item.fineness} - Peso: ${item.grossWeightGram} g", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Text(text = "€ ${repo.currencyFormat.format(item.finalOfferEur)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // STEP 4: SELLER MANDATORY REGISTRATION FORM
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "REGISTRO OBBLIGATORIO IDENTIFICAZIONE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = sellerName,
                            onValueChange = { viewModel.setComproOroSeller(it, sellerTaxCode, sellerDocId) },
                            label = { Text("Nome Completo Venditore") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = sellerTaxCode,
                            onValueChange = { viewModel.setComproOroSeller(sellerName, it, sellerDocId) },
                            label = { Text("Codice Fiscale") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = sellerDocId,
                            onValueChange = { viewModel.setComproOroSeller(sellerName, sellerTaxCode, it) },
                            label = { Text("Numero Carta d'Identità / Documento") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { viewModel.executeComproOroPurchase() },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "REGISTRA ED EMETTI RICEVUTA DI PAGAMENTO", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }

        } else {
            // TRANSACTION RECEIPT COMPLETED DISPLAY
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(2.dp, SuccessGreen), shape = RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "RICEVUTA REGISTRATA NEL REGISTRO COMPRO ORO", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SuccessGreen, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailRow(label = "Codice Transazione", value = receiptState?.id ?: "")
                    DetailRow(label = "Protocollo Questura", value = receiptState?.registrationReceiptNumber ?: "")
                    DetailRow(label = "Venditore", value = receiptState?.customerName ?: "")
                    DetailRow(label = "Codice Fiscale", value = receiptState?.customerCodiceFiscale ?: "")
                    DetailRow(label = "Importo Pagato cash/trsf", value = "€ ${repo.currencyFormat.format(receiptState?.totalPaidEur ?: 0.0)}")

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { viewModel.clearComproOroBasket() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "COMPLETA E TORNA AL PANNELLO", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// --- SCREEN 10: FAMILY OFFICE CONSOLE SCREEN ---
@Composable
fun FamilyOfficeScreen(viewModel: AureoViewModel) {
    val currentRole by viewModel.familyOfficeRole.collectAsState()
    val entitiesList by viewModel.entities.collectAsState()
    val account by viewModel.currentAccount.collectAsState()

    val repo = AureoRepository
    val currentGoldSpot = repo.marketData.getGoldSpotPriceEur()
    val currentSilverSpot = repo.marketData.getSilverSpotPriceEur()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "CONSOLIDATED FAMILY OFFICE GATEWAY",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Portafoglio Aggregato Bianchi",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Role Selector Row
        Text(text = "Ruolo di Accesso Console:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val roles = listOf("Family Advisor", "Accountant", "Auditor")
            roles.forEach { role ->
                val isSelected = currentRole == role
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(
                            BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) BrushedGold else Color.Gray),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { viewModel.setFamilyOfficeRole(role) }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = role, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSelected) BrushedGold else MaterialTheme.colorScheme.primary)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Consolidated Entities Overview
        Text(text = "SOGGETTI ED ENTITÀ PATRIMONIALI:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Spacer(modifier = Modifier.height(8.dp))

        entitiesList.forEach { ent ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = ent.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Box(
                            modifier = Modifier
                                .background(Espresso, shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = ent.role, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = WarmParchment)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // Fraction of simulated balance
                    val fraction = when (ent.id) {
                        "ENT-1" -> 0.60
                        "ENT-2" -> 0.25
                        else -> 0.15
                    }

                    val baseGold = ((account?.goldAllocatedOz ?: 0.0) + (account?.goldUnallocatedOz ?: 0.0)) * fraction
                    val baseSilver = ((account?.silverAllocatedKg ?: 0.0) + (account?.silverUnallocatedKg ?: 0.0)) * fraction
                    val cashVal = (account?.cashBalanceEur ?: 0.0) * fraction

                    val totalVal = (baseGold * currentGoldSpot) + (baseSilver * currentSilverSpot) + cashVal

                    DetailRow(label = "Allocazione Oro", value = "${repo.weightFormat.format(baseGold)} oz")
                    DetailRow(label = "Allocazione Argento", value = "${repo.weightFormat.format(baseSilver)} kg")
                    DetailRow(label = "Cash Reserve", value = "€ ${repo.currencyFormat.format(cashVal)}")
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Valore Consolidato Entità", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = "€ ${repo.currencyFormat.format(totalVal)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrushedGold)
                    }
                }
            }
        }
    }
}

// --- SCREEN 11: DOCUMENTS VIEW SCREEN ---
@Composable
fun DocumentsScreen(viewModel: AureoViewModel) {
    val selectedDoc by viewModel.selectedDocument.collectAsState()
    val docList by viewModel.documents.collectAsState()

    val repo = AureoRepository

    if (selectedDoc == null) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item {
                Text(
                    text = "ARCHIVIO RENDICONTI UFFICIALI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Rapporti di Proprietà & Custodia",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            items(docList.value) { doc ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), shape = RoundedCornerShape(8.dp))
                        .clickable { viewModel.viewDocument(doc) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = doc.documentNumber, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                            Text(text = doc.date, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = doc.description, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = doc.documentType, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(text = "Valore Rif: € ${repo.currencyFormat.format(doc.valueEur)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }
            }
        }
    } else {
        // FULL SCREEN PDF-STYLE LUXURY DOCUMENT REPRESENTATION
        val doc = selectedDoc ?: return
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.closeDocument() }, modifier = Modifier.size(40.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Chiudi")
                }
                Text(
                    text = doc.documentType,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bank paper effect card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(2.dp, BrushedGold), shape = RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = WarmParchment)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    // Header bank address
                    Text(
                        text = "AUREO ITALIA S.P.A.\nUfficio d'Allocazione e Custodia Metalli Rari\nVia Monte Napoleone 12, Milano\nCapitale Sociale € 10.000.000 I.V.\nReg. Impr. OAM n. OPO-2026-904",
                        fontSize = 9.sp,
                        color = Color.DarkGray,
                        lineHeight = 13.sp,
                        fontFamily = FontFamily.Serif
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                    Divider(color = Color.DarkGray, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "DOCUMENTO UFFICIALE DI PROPRIETÀ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Espresso,
                        letterSpacing = 1.5.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    DetailRowPlain(label = "Protocollo Certificato", value = doc.documentNumber)
                    DetailRowPlain(label = "Data di emissione", value = doc.date)
                    DetailRowPlain(label = "Intestatario Custodia", value = doc.clientName)
                    DetailRowPlain(label = "Identificativo Soggetto", value = doc.clientId)
                    DetailRowPlain(label = "Riferimento Transazione", value = doc.referenceId)

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "RILIEVO E CERTIFICAZIONE DELLA CONSISTENZA:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Espresso)
                    Spacer(modifier = Modifier.height(8.dp))

                    doc.contentMeta.forEach { (key, valString) ->
                        DetailRowPlain(label = key, value = valString)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = Color.DarkGray.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "VALORE DI BILANCIO REGISTRATO", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Espresso)
                        Text(text = "€ ${repo.currencyFormat.format(doc.valueEur)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Espresso)
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Signature stamped graphic
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "AUREO ITALIA S.P.A.\nUfficio Sigilli di Cassa", fontSize = 9.sp, color = Color.Gray)
                        }
                        Box(
                            modifier = Modifier
                                .border(BorderStroke(1.5.dp, Burgundy), shape = RoundedCornerShape(4.dp))
                                .padding(6.dp)
                        ) {
                            Text(
                                text = "AUREO MILANO\nVALIDO",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Burgundy,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { viewModel.closeDocument() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "CHIUDI DOCUMENTO", fontSize = 12.sp)
            }
        }
    }
}

// --- SCREEN 12: AUREO AI ASSISTANT PORTAL ---
@Composable
fun AiAssistantScreen(viewModel: AureoViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val isLoading by viewModel.isChatLoading.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val lazyListState = rememberLazyListState()

    // Scroll to latest message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "AUREO AI WEALTH ASSISTANT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = "Consulto Privato Intelligente",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Pre-configured typical private wealth prompts for rapid selection
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val suggestions = listOf(
                "Quanto oro possiedo?",
                "Quali lingotti ho a Milano?",
                "Quanto ho pagato di custodia?",
                "Tasse e plusvalenze sul mio oro"
            )
            suggestions.forEach { sug ->
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp))
                        .clickable { viewModel.sendChatMessage(sug) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = sug, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chat Conversation Stream
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(width = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), shape = RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isAi = msg.sender == "AUREO_AI"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End
                ) {
                    Card(
                        modifier = Modifier.widthIn(max = 280.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isAi) MaterialTheme.colorScheme.surfaceVariant else BrushedGold
                        ),
                        shape = RoundedCornerShape(
                            topStart = 10.dp,
                            topEnd = 10.dp,
                            bottomStart = if (isAi) 0.dp else 10.dp,
                            bottomEnd = if (isAi) 10.dp else 0.dp
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isAi) "AUREO AI" else "FAMIGLIA BIANCHI",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAi) MaterialTheme.colorScheme.secondary else DeepCharcoal
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.text,
                                fontSize = 13.sp,
                                color = if (isAi) MaterialTheme.colorScheme.onSurface else DeepCharcoal,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        CircularProgressIndicator(color = BrushedGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Aureo AI sta elaborando...", fontSize = 11.sp, fontStyle = FontStyle.Italic)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Message Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Esegui consulto patrimoniale...", fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_text_field"),
                singleLine = true
            )

            IconButton(
                onClick = {
                    viewModel.sendChatMessage(textInput)
                    textInput = ""
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(24.dp))
                    .testTag("chat_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Invia", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

// --- UTILITY VIEW COMPOSABLES ---
@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun DetailRowPlain(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = Color.DarkGray)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Espresso)
    }
}
