package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrushedGold,
    onPrimary = DeepCharcoal,
    secondary = MutedGold,
    onSecondary = WarmParchment,
    tertiary = LightGold,
    background = DeepCharcoal,
    onBackground = WarmParchment,
    surface = WarmCharcoal,
    onSurface = WarmParchment,
    surfaceVariant = DarkCard,
    onSurfaceVariant = OffWhite,
    outline = MutedGold,
    error = ErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = Espresso,
    onPrimary = WarmParchment,
    secondary = MutedGold,
    onSecondary = WarmCharcoal,
    tertiary = Burgundy,
    background = WarmParchment,
    onBackground = Espresso,
    surface = OffWhite,
    onSurface = Espresso,
    surfaceVariant = IvoryCard,
    onSurfaceVariant = WarmCharcoal,
    outline = BorderGold,
    error = ErrorRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Force our custom luxury brand theme for maximum branding impact
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
