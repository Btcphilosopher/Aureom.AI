package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureo Italia Luxury Palette
val WarmParchment = Color(0xFFFBF9F4)
val OffWhite = Color(0xFFF5F2EB)
val DeepCharcoal = Color(0xFF121212)
val WarmCharcoal = Color(0xFF1C1917)
val Espresso = Color(0xFF2C2421)

val MutedGold = Color(0xFFC5A059)
val LightGold = Color(0xFFE2C48D)
val BrushedGold = Color(0xFFD4AF37)
val Bronze = Color(0xFF8C6F4D)
val DarkBronze = Color(0xFF59452F)

val Burgundy = Color(0xFF5F2D3D)
val DarkOlive = Color(0xFF3C3F2D)

// Card & Surface Colors
val IvoryCard = Color(0xFFF4ECE1)
val DarkCard = Color(0xFF26211E)
val BorderGold = Color(0xFFD6C8B5)

val SuccessGreen = Color(0xFF344E41)
val ErrorRed = Color(0xFF7B2635)
val WarningOrange = Color(0xFFB07A3E)
