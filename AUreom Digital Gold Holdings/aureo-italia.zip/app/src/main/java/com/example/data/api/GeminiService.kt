package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.repository.AureoRepository
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat

// --- MOSHI COMPATIBLE REQUEST / RESPONSE CLASSES ---
@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiConfig(
    @Json(name = "temperature") val temperature: Double? = 0.2,
    @Json(name = "maxOutputTokens") val maxOutputTokens: Int? = 1000
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null
)

// --- RETROFIT INTERFACE ---
interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// --- CLIENT CLIENT CONFIG ---
object GeminiRetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }
}

// --- HIGH FIDELITY ASSISTANT SERVICE ---
object AureoAiService {

    suspend fun askAssistant(userQuery: String): String = withContext(Dispatchers.IO) {
        // 1. Gather current live application state
        val repo = AureoRepository
        val accounts = repo.accounts.value
        val bianchiAcc = accounts.firstOrNull { it.clientId == repo.CLIENT_BIANCHI_ID }

        val goldAllocated = bianchiAcc?.goldAllocatedOz ?: 0.0
        val goldUnallocated = bianchiAcc?.goldUnallocatedOz ?: 0.0
        val goldTotal = goldAllocated + goldUnallocated

        val silverAllocated = bianchiAcc?.silverAllocatedKg ?: 0.0
        val silverUnallocated = bianchiAcc?.silverUnallocatedKg ?: 0.0
        val silverTotal = silverAllocated + silverUnallocated

        val cash = bianchiAcc?.cashBalanceEur ?: 0.0

        val goldSpot = repo.marketData.getGoldSpotPriceEur()
        val silverSpot = repo.marketData.getSilverSpotPriceEur()

        val totalValue = (goldTotal * goldSpot) + (silverTotal * silverSpot)

        val activeBars = repo.bars.value.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.status == com.example.data.models.CustodyStatus.ALLOCATED }

        // Compile details of physical bars
        val barsSummary = activeBars.joinToString("\n") { bar ->
            "- LINGOTTO ${bar.metal.name}: Peso: ${bar.fineWeightOzOrKg} ${if (bar.metal == com.example.data.models.MetalType.GOLD) "oz" else "kg"}, Purezza: ${bar.fineness}, Seriale: ${bar.serialNumber}, Raffineria: ${bar.manufacturer}, Posizione: ${bar.vaultId} (Compartimento: ${bar.compartmentId}), Certificato: ${bar.certificateId}, Valutazione Attuale: € ${repo.currencyFormat.format(bar.valuationEur)}"
        }

        // Compliances
        val cases = repo.complianceCases.value.joinToString("\n") { "- Caso AML: ${it.type}, Stato: ${it.status}, Punteggio Rischio: ${it.score}" }

        // Assemble strict system constraints instruction
        val systemInstruction = """
            Sei 'AUREO AI', l'assistente di private banking d'élite di AUREO ITALIA per la gestione di metalli preziosi fisici.
            Rispondi esclusivamente in lingua italiana con tono estremamente professionale, sobrio ed elegante, tipico della finanza privata milanese.
            Hai accesso unicamente ai seguenti dati reali certificati della sessione del cliente 'Famiglia Bianchi':
            
            --- PATRIMONIO ATTUALE ---
            - ORO FISICO TOTALE: ${repo.weightFormat.format(goldTotal)} oz
              * ALLOCATO: ${repo.weightFormat.format(goldAllocated)} oz
              * IN POOL (NON ALLOCATO): ${repo.weightFormat.format(goldUnallocated)} oz
              * VALORE ORO SPOT: € ${repo.currencyFormat.format(goldSpot)} / oz
            - ARGENTO FISICO TOTALE: ${repo.weightFormat.format(silverTotal)} kg
              * ALLOCATO: ${repo.weightFormat.format(silverAllocated)} kg
              * IN POOL (NON ALLOCATO): ${repo.weightFormat.format(silverUnallocated)} kg
              * VALORE ARGENTO SPOT: € ${repo.currencyFormat.format(silverSpot)} / kg
            - LIQUIDITÀ CONTO METALLI: € ${repo.currencyFormat.format(cash)}
            - VALUTAZIONE COMPLESSIVA PORTAFOGLIO METALLI: € ${repo.currencyFormat.format(totalValue)}
            
            --- DETTAGLIO LINGOTTI REALI IN CUSTODIA (DIGITAL TWIN) ---
            $barsSummary
            
            --- STATO COMPLIANCE E KYC (OAM REGISTRATION) ---
            $cases
            - Registrazione OAM (Operatore Professionale Oro): ${if (repo.clients.value.firstOrNull()?.isProfessionalOperator == true) "SÌ, Numero Registro: OPO-2026-904" else "NO"}
            
            --- REGOLE FISCALI APPLICABILI IN ITALIA ---
            1. Oro da Investimento: Esente IVA ai sensi della Legge 7/2000. Plusvalenze tassate al 26% (Imposta Sostitutiva). Se il costo di carico d'acquisto non è documentabile, la tassazione si applica su una plusvalenza forfettaria pari al 25% del valore di cessione totale (Regola Fiscale Italiana!).
            2. Argento Fisico: Assoggettato ad IVA ordinaria al 22% al momento dell'acquisto in Italia.
            
            --- VINCOLI MANDATORI DI RISPOSTA ---
            1. NON inventare mai per nessuna ragione lingotti, saldi, transazioni, prezzi o regole fiscali al di fuori di quelli indicati.
            2. Fornisci riferimenti precisi a codici seriali, numeri di documento o di cassaforte quando rispondi alle domande dei clienti.
            3. Includi sempre la dicitura: "CALCOLO INFORMATIVO — NON COSTITUISCE CONSULENZA FISCALE" qualora vengano citati aspetti legati alle tasse o plusvalenze.
            4. Se la domanda riguarda informazioni non disponibili in questa scheda di dati (es. storici di costo di anni passati non specificati), indica educatamente che non è presente nel rendiconto d'archivio corrente.
        """.trimIndent()

        // 2. Perform direct REST request
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("AureoAiService", "API Key is placeholder or missing. Utilizing high-fidelity local parser.")
            return@withContext fallbackAnswer(userQuery, goldTotal, goldAllocated, goldUnallocated, silverTotal, silverAllocated, silverUnallocated, totalValue, activeBars, cash)
        }

        val request = GeminiRequest(
            contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = userQuery)))),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemInstruction)))
        )

        try {
            val response = GeminiRetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "Gentile Cliente, la richiesta è stata elaborata con successo, ma non è stato possibile generare una risposta testuale. La preghiamo di riprovare."
        } catch (e: Exception) {
            Log.e("AureoAiService", "Network call failed, using fallback.", e)
            fallbackAnswer(userQuery, goldTotal, goldAllocated, goldUnallocated, silverTotal, silverAllocated, silverUnallocated, totalValue, activeBars, cash)
        }
    }

    // --- INTEGRAL MOCK ASSISTANT FOR COMPREHENSIVE OFFLINE OPERATION ---
    private fun fallbackAnswer(
        query: String,
        goldTotal: Double,
        goldAllocated: Double,
        goldUnallocated: Double,
        silverTotal: Double,
        silverAllocated: Double,
        silverUnallocated: Double,
        totalValue: Double,
        bars: List<com.example.data.models.BullionBar>,
        cash: Double
    ): String {
        val q = query.lowercase(Locale.ITALIAN)
        val formattedValue = AureoRepository.currencyFormat.format(totalValue)
        val formattedGold = AureoRepository.weightFormat.format(goldTotal)
        val formattedSilver = AureoRepository.weightFormat.format(silverTotal)
        val formattedCash = AureoRepository.currencyFormat.format(cash)

        return when {
            q.contains("quanto oro") || q.contains("saldo oro") || q.contains("possiedo oro") -> {
                """
                    Gentile Famiglia Bianchi,
                    
                    Attualmente il vostro portafoglio Aureo Italia vanta un totale di **$formattedGold oz** di Oro Fisico da Investimento.
                    
                    Questo saldo è così suddiviso nei nostri registri:
                    - **Oro Fisico Allocato**: ${AureoRepository.weightFormat.format(goldAllocated)} oz (suddiviso in lingotti con numeri seriali specifici nel caveau).
                    - **Oro Fisico Non Allocato (Pool Liquido)**: ${AureoRepository.weightFormat.format(goldUnallocated)} oz (immediatamente convertibile o disponibile per l'allocazione).
                    
                    Il controvalore di mercato spot del vostro oro è pari a circa **€ ${AureoRepository.currencyFormat.format(goldTotal * AureoRepository.marketData.getGoldSpotPriceEur())}** (basato sulla quotazione spot odierna di € ${AureoRepository.currencyFormat.format(AureoRepository.marketData.getGoldSpotPriceEur())} / oz).
                    
                    Tutti i lingotti allocati risiedono in sicurezza presso il *Milano Vault Excellentia 01*, protetti da polizze assicurative full-risk.
                """.trimIndent()
            }
            q.contains("quanto argento") || q.contains("saldo argento") || q.contains("valore argento") -> {
                """
                    Gentile Famiglia Bianchi,
                    
                    Il vostro portafoglio include un quantitativo di **$formattedSilver kg** di Argento Fisico.
                    
                    La ripartizione della custodia è la seguente:
                    - **Argento Allocato**: ${AureoRepository.weightFormat.format(silverAllocated)} kg (lingotti fisici custoditi in sicurezza).
                    - **Argento Non Allocato (Pool Liquido)**: ${AureoRepository.weightFormat.format(silverUnallocated)} kg.
                    
                    La valorizzazione corrente dell'argento, basata sullo spot di € ${AureoRepository.currencyFormat.format(AureoRepository.marketData.getSilverSpotPriceEur())} / kg, è pari a **€ ${AureoRepository.currencyFormat.format(silverTotal * AureoRepository.marketData.getSilverSpotPriceEur())}**.
                """.trimIndent()
            }
            q.contains("milano") || q.contains("custoditi a milano") || q.contains("quali lingotti") -> {
                val milanoBars = bars.filter { it.vaultId == "VAULT-MI-01" }
                val barsList = milanoBars.joinToString("\n") { bar ->
                    "- **Lingotto ${bar.metal}**: Seriale **${bar.serialNumber}**, Peso: ${bar.fineWeightOzOrKg} ${if (bar.metal == com.example.data.models.MetalType.GOLD) "oz" else "kg"}, Compartimento **${bar.compartmentId}**, Valutazione: € ${AureoRepository.currencyFormat.format(bar.valuationEur)}"
                }
                """
                    Gentile Cliente,
                    
                    Presso la nostra struttura blindata **Milano Vault Excellentia 01** risultano attualmente allocati e custoditi i seguenti lingotti di vostra esclusiva proprietà:
                    
                    $barsList
                    
                    Questi lingotti sono associati ai rispettivi Certificati di Allocazione emessi in forma ufficiale ed opponibili a terzi.
                """.trimIndent()
            }
            q.contains("cento") || q.contains("100 grammi") || q.contains("100g") -> {
                val gold100g = bars.filter { it.productId == "PROD-AU-100G" }
                if (gold100g.isEmpty()) {
                    "Gentile Cliente, non risultano attualmente in custodia lingotti di Oro da 100 grammi a vostro nome nei registri di allocazione."
                } else {
                    val barsList = gold100g.joinToString("\n") { bar ->
                        "- **Seriale**: ${bar.serialNumber}, Raffineria: ${bar.manufacturer}, Caveau: ${bar.vaultId}, Certificato: ${bar.certificateId}, Valore: € ${AureoRepository.currencyFormat.format(bar.valuationEur)}"
                    }
                    """
                        Gentile Cliente,
                        
                        Risultano allocati a vostro nome i seguenti lingotti da 100 grammi di Oro Fisico 999.9:
                        
                        $barsList
                        
                        Ciascun lingotto possiede un passaporto di provenienza tracciabile.
                    """.trimIndent()
                }
            }
            q.contains("custodia") || q.contains("pagato") || q.contains("spese") -> {
                """
                    Gentile Famiglia Bianchi,
                    
                    Le spese di custodia addebitate per la gestione del caveau, vigilanza armata H24 e assicurazione globale a copertura totale (Lloyd's Syndicate) per il corrente anno ammontano a:
                    
                    - Spese complessive liquidate: **€ 1.250,00** (Addebitate in data 01/07/2026 sul Conto Metalli, con riferimento documento *RECON-REP-2026-10*).
                    
                    La commissione annua concordata è pari allo **0,25%** del valore medio custodito per l'oro e dello **0,45%** per l'argento, calcolata pro-rata temporis su base giornaliera e liquidata trimestralmente in via posticipata.
                """.trimIndent()
            }
            q.contains("tasse") || q.contains("fiscale") || q.contains("annuale") || q.contains("report") -> {
                """
                    Gentile Famiglia Bianchi,
                    
                    In merito alla fiscalità applicabile al vostro patrimonio in metalli preziosi in Italia, vi confermiamo quanto segue:
                    
                    1. **Oro da Investimento (Legge 7/2000)**: L'acquisto dei lingotti d'oro a vostro nome è esente IVA. Le plusvalenze realizzate in caso di vendita sono soggette ad imposta sostitutiva del **26%**. 
                       *Riferimento Codice Fiscale*: BNCFMG52L21F205K.
                       *Nota cruciale*: Poiché disponete dei documenti d'acquisto completi (es. *CONF-ACQ-2026-0048*), la plusvalenza verrà calcolata esattamente sulla differenza reale tra costo d'acquisto e ricavo di cessione. Se la documentazione di carico fosse stata smarrita, la normativa italiana prevede l'applicazione dell'aliquota del 26% su una plusvalenza forfettaria pari al 25% del ricavo totale di vendita.
                    
                    2. **Argento**: L'argento non costituisce "oro da investimento" ed è quindi soggetto ad aliquota IVA ordinaria del **22%** inclusa nel prezzo d'acquisto.
                    
                    Il vostro rendiconto patrimoniale annuale Q3 è pronto per essere scaricato nella sezione **Documenti**.
                    
                    *CALCOLO INFORMATIVO — NON COSTITUISCE CONSULENZA FISCALE*
                """.trimIndent()
            }
            else -> {
                """
                    Gentile Famiglia Bianchi,
                    
                    Aureo AI è al vostro servizio. Potete pormi domande dettagliate sul vostro patrimonio in metalli rari, la dislocazione fisica dei vostri lingotti nei caveau di Milano o Zurigo, le vostre transazioni antiriciclaggio e la fiscalità forfettaria italiana.
                    
                    - **Patrimonio Totale**: € $formattedValue
                    - **Oro Fisico**: $formattedGold oz (Allocato: ${AureoRepository.weightFormat.format(goldAllocated)} oz)
                    - **Argento Fisico**: $formattedSilver kg (Allocato: ${AureoRepository.weightFormat.format(silverAllocated)} kg)
                    - **Liquidità Conto**: € $formattedCash
                    
                    *Come posso aiutarvi ad amministrare il vostro patrimonio oggi?*
                """.trimIndent()
            }
        }
    }
}
