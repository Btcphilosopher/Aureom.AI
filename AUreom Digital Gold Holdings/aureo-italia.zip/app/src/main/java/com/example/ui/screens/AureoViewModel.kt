package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.AureoAiService
import com.example.data.models.*
import com.example.data.repository.AureoRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import java.text.SimpleDateFormat

// --- MAIN NAVIGATION SCREEN STATE ---
sealed interface AureoScreen {
    object Dashboard : AureoScreen
    object GoldDetail : AureoScreen
    object SilverDetail : AureoScreen
    data class BarPassport(val barId: String) : AureoScreen
    object VaultTwin : AureoScreen
    object BuyMetal : AureoScreen
    object SellMetal : AureoScreen
    object Compliance : AureoScreen
    object ComproOro : AureoScreen
    object FamilyOffice : AureoScreen
    object Documents : AureoScreen
    object AiAssistant : AureoScreen
}

data class ChatMessage(
    val sender: String, // "USER" or "AUREO_AI"
    val text: String,
    val timestamp: String
)

class AureoViewModel : ViewModel() {

    private val repo = AureoRepository

    // Navigation state
    private val _currentScreen = MutableStateFlow<AureoScreen>(AureoScreen.Dashboard)
    val currentScreen: StateFlow<AureoScreen> = _currentScreen.asStateFlow()

    private val screenHistory = Stack<AureoScreen>()

    fun navigateTo(screen: AureoScreen) {
        screenHistory.push(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (!screenHistory.isEmpty()) {
            _currentScreen.value = screenHistory.pop()
            return true
        }
        return false
    }

    // --- REPOSITORY MIRROR FLOWS ---
    val clients = repo.clients
    val entities = repo.entities
    val accounts = repo.accounts
    val products = repo.products
    val bars = repo.bars
    val passportEvents = repo.passportEvents
    val vaults = repo.vaults
    val compartments = repo.compartments
    val orders = repo.orders
    val quotes = repo.quotes
    val goldLedger = repo.goldLedger
    val silverLedger = repo.silverLedger
    val cashLedger = repo.cashLedger
    val documents = repo.documents
    val complianceCases = repo.complianceCases
    val usedGoldTransactions = repo.usedGoldTransactions
    val reconciliationStatus = repo.reconciliationStatus

    // --- SELECTED CLIENT & ACCOUNT COMPUTATIONS ---
    val currentAccount = accounts.map { list ->
        list.firstOrNull { it.clientId == repo.CLIENT_BIANCHI_ID }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentClient = clients.map { list ->
        list.firstOrNull { it.id == repo.CLIENT_BIANCHI_ID }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Gold Portfolio Computations
    val goldAllocatedValuation = combine(bars, repo.marketData.getGoldSpotPriceEur().let { flowOf(it) }) { barList, spot ->
        barList.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.metal == MetalType.GOLD && it.status == CustodyStatus.ALLOCATED }
            .sumOf { it.valuationEur }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val goldUnallocatedValuation = combine(currentAccount, repo.marketData.getGoldSpotPriceEur().let { flowOf(it) }) { acc, spot ->
        val unallocatedOz = acc?.goldUnallocatedOz ?: 0.0
        unallocatedOz * spot
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val goldTotalValuation = combine(goldAllocatedValuation, goldUnallocatedValuation) { allocated, unallocated ->
        allocated + unallocated
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Silver Portfolio Computations
    val silverAllocatedValuation = combine(bars, repo.marketData.getSilverSpotPriceEur().let { flowOf(it) }) { barList, spot ->
        barList.filter { it.currentOwnerId == repo.CLIENT_BIANCHI_ID && it.metal == MetalType.SILVER && it.status == CustodyStatus.ALLOCATED }
            .sumOf { it.valuationEur }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val silverUnallocatedValuation = combine(currentAccount, repo.marketData.getSilverSpotPriceEur().let { flowOf(it) }) { acc, spot ->
        val unallocatedKg = acc?.silverUnallocatedKg ?: 0.0
        unallocatedKg * spot
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val silverTotalValuation = combine(silverAllocatedValuation, silverUnallocatedValuation) { allocated, unallocated ->
        allocated + unallocated
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Overall Total Valuation
    val portfolioTotalValuation = combine(goldTotalValuation, silverTotalValuation, currentAccount) { gold, silver, acc ->
        gold + silver + (acc?.cashBalanceEur ?: 0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // --- PURCHASE FLOW STATE ---
    private val _purchaseSelectedProduct = MutableStateFlow<BullionProduct?>(null)
    val purchaseSelectedProduct = _purchaseSelectedProduct.asStateFlow()

    private val _purchaseQuantity = MutableStateFlow(1)
    val purchaseQuantity = _purchaseQuantity.asStateFlow()

    private val _activeQuote = MutableStateFlow<QuoteResponse?>(null)
    val activeQuote = _activeQuote.asStateFlow()

    private val _isRequestingQuote = MutableStateFlow(false)
    val isRequestingQuote = _isRequestingQuote.asStateFlow()

    private val _purchaseSuccessOrder = MutableStateFlow<MetalOrder?>(null)
    val purchaseSuccessOrder = _purchaseSuccessOrder.asStateFlow()

    fun selectPurchaseProduct(product: BullionProduct) {
        _purchaseSelectedProduct.value = product
        _purchaseQuantity.value = 1
        _activeQuote.value = null
        _purchaseSuccessOrder.value = null
    }

    fun setPurchaseQuantity(quantity: Int) {
        _purchaseQuantity.value = quantity.coerceAtLeast(1)
        _activeQuote.value = null
    }

    fun requestQuote() {
        val prod = _purchaseSelectedProduct.value ?: return
        viewModelScope.launch {
            _isRequestingQuote.value = true
            _activeQuote.value = null
            // Simulate networking delay
            kotlinx.coroutines.delay(1000)
            try {
                _activeQuote.value = repo.requestRfq(prod.id, _purchaseQuantity.value)
            } catch (e: Exception) {
                // handle error
            } finally {
                _isRequestingQuote.value = false
            }
        }
    }

    fun confirmPurchase(paymentMethod: String) {
        val quote = _activeQuote.value ?: return
        viewModelScope.launch {
            try {
                val order = repo.confirmPurchase(quote.id, paymentMethod)
                _purchaseSuccessOrder.value = order
                _activeQuote.value = null
            } catch (e: Exception) {
                // handle failure
                _purchaseSuccessOrder.value = null
            }
        }
    }

    // --- LIQUIDATION / SALE FLOW STATE ---
    private val _saleSelectedBarId = MutableStateFlow<String?>(null)
    val saleSelectedBarId = _saleSelectedBarId.asStateFlow()

    private val _saleSuccessMessage = MutableStateFlow<String?>(null)
    val saleSuccessMessage = _saleSuccessMessage.asStateFlow()

    fun selectSaleBar(barId: String) {
        _saleSelectedBarId.value = barId
        _saleSuccessMessage.value = null
    }

    fun executeSale() {
        val barId = _saleSelectedBarId.value ?: return
        viewModelScope.launch {
            try {
                val proceeds = repo.sellMetal(barId)
                _saleSuccessMessage.value = "SCONTRINO DI VENDITA EMESSO:\nAccreditati € ${repo.currencyFormat.format(proceeds)} sul vostro Conto Metalli."
                _saleSelectedBarId.value = null
            } catch (e: Exception) {
                _saleSuccessMessage.value = "Errore: ${e.message}"
            }
        }
    }

    // --- MOVE COMPARTMENT STATE ---
    private val _mfaInputCode = MutableStateFlow("")
    val mfaInputCode = _mfaInputCode.asStateFlow()

    private val _moveSuccessState = MutableStateFlow<String?>(null)
    val moveSuccessState = _moveSuccessState.asStateFlow()

    fun setMfaCode(code: String) {
        _mfaInputCode.value = code
        _moveSuccessState.value = null
    }

    fun executeMoveCompartment(barId: String, targetCompartmentId: String) {
        viewModelScope.launch {
            val success = repo.moveCompartment(barId, targetCompartmentId, _mfaInputCode.value)
            if (success) {
                _moveSuccessState.value = "SUCCESSO: Spostamento del lingotto approvato e registrato con protocollo crittografico."
                _mfaInputCode.value = ""
            } else {
                _moveSuccessState.value = "ERRORE: Codice MFA non valido. Autorizzazione di sicurezza respinta."
            }
        }
    }

    // --- PHYSICAL DELIVERY STATE ---
    private val _deliverySelectedBarId = MutableStateFlow<String?>(null)
    val deliverySelectedBarId = _deliverySelectedBarId.asStateFlow()

    private val _deliveryType = MutableStateFlow("Ferrari S.p.A. Assicurato")
    val deliveryType = _deliveryType.asStateFlow()

    private val _deliveryAddress = MutableStateFlow("")
    val deliveryAddress = _deliveryAddress.asStateFlow()

    private val _deliverySuccessState = MutableStateFlow<String?>(null)
    val deliverySuccessState = _deliverySuccessState.asStateFlow()

    fun selectDeliveryBar(barId: String) {
        _deliverySelectedBarId.value = barId
        _deliverySuccessState.value = null
    }

    fun setDeliveryType(type: String) {
        _deliveryType.value = type
    }

    fun setDeliveryAddress(address: String) {
        _deliveryAddress.value = address
    }

    fun executeRequestDelivery() {
        val barId = _deliverySelectedBarId.value ?: return
        if (_deliveryAddress.value.isBlank()) {
            _deliverySuccessState.value = "ERRORE: Inserire un indirizzo di consegna valido."
            return
        }
        viewModelScope.launch {
            try {
                val success = repo.requestDelivery(barId, _deliveryType.value, _deliveryAddress.value)
                if (success) {
                    _deliverySuccessState.value = "RICHIESTA DI RITIRO ACCETTATA:\nIl trasporto scortato è in fase di preparazione. Consultare il documento di carico emesso."
                    _deliverySelectedBarId.value = null
                }
            } catch (e: Exception) {
                _deliverySuccessState.value = "Errore: ${e.message}"
            }
        }
    }

    // --- DAILY RECONCILIATION STATE ---
    private val _reconciliationLog = MutableStateFlow<List<String>>(emptyList())
    val reconciliationLog = _reconciliationLog.asStateFlow()

    private val _isReconciling = MutableStateFlow(false)
    val isReconciling = _isReconciling.asStateFlow()

    fun runAuditReconciliation() {
        viewModelScope.launch {
            _isReconciling.value = true
            _reconciliationLog.value = listOf(
                "REG-START: Avvio riconciliazione giornaliera dei registri fisici...",
                "AUDIT-01: Caricamento inventario di cassa dal caveau 'Milano Excellentia 01'...",
                "AUDIT-02: Calcolo della massa d'oro totale allocata nei comparti..."
            )
            kotlinx.coroutines.delay(1200)

            _reconciliationLog.value = _reconciliationLog.value + listOf(
                "AUDIT-03: Rilevato: ORO ALLOCATO NEI COMPARTI = ${repo.weightFormat.format(repo.bars.value.filter { it.metal == MetalType.GOLD && it.status == CustodyStatus.ALLOCATED }.sumOf { it.fineWeightOzOrKg })} oz",
                "AUDIT-04: Rilevato: ORO REGISTRATO NEL LEDGER CUSTODIA = ${repo.weightFormat.format(repo.accounts.value.first().goldAllocatedOz)} oz",
                "AUDIT-05: Rilevato: ARGENTO ALLOCATO NEI COMPARTI = ${repo.weightFormat.format(repo.bars.value.filter { it.metal == MetalType.SILVER && it.status == CustodyStatus.ALLOCATED }.sumOf { it.fineWeightOzOrKg })} kg",
                "AUDIT-06: Rilevato: ARGENTO REGISTRATO NEL LEDGER CUSTODIA = ${repo.weightFormat.format(repo.accounts.value.first().silverAllocatedKg)} kg"
            )
            kotlinx.coroutines.delay(1000)

            val success = repo.runReconciliation()
            _reconciliationLog.value = _reconciliationLog.value + if (success) {
                listOf(
                    "AUDIT-OK: Corrispondenza fisica al 100%.",
                    "REG-DONE: STATO GENERAL: RICONCILIATO. Nessuna anomalia rilevata."
                )
            } else {
                listOf(
                    "AUDIT-ERR: ERRORE! Discrepanza rilevata tra il conteggio dei vani blindati e il ledger contabile.",
                    "REG-ERR: GENERATO INCIDENTE DI AUDITING DI LIVELLO II."
                )
            }
            _isReconciling.value = false
        }
    }

    // --- COMPRO ORO (USED JEWELLERY) STATE ---
    private val _usedGoldItemDescription = MutableStateFlow("")
    val usedGoldItemDescription = _usedGoldItemDescription.asStateFlow()

    private val _usedGoldGrossWeight = MutableStateFlow("0.0")
    val usedGoldGrossWeight = _usedGoldGrossWeight.asStateFlow()

    private val _usedGoldFineness = MutableStateFlow("750") // Default 18k (750/1000)
    val usedGoldFineness = _usedGoldFineness.asStateFlow()

    private val _currentActiveUsedGoldOffer = MutableStateFlow<UsedGoldItem?>(null)
    val currentActiveUsedGoldOffer = _currentActiveUsedGoldOffer.asStateFlow()

    private val _comproOroIntakeBasket = MutableStateFlow<List<UsedGoldItem>>(emptyList())
    val comproOroIntakeBasket = _comproOroIntakeBasket.asStateFlow()

    private val _comproOroSellerName = MutableStateFlow("")
    val comproOroSellerName = _comproOroSellerName.asStateFlow()

    private val _comproOroSellerTaxCode = MutableStateFlow("")
    val comproOroSellerTaxCode = _comproOroSellerTaxCode.asStateFlow()

    private val _comproOroSellerDocId = MutableStateFlow("")
    val comproOroSellerDocId = _comproOroSellerDocId.asStateFlow()

    private val _comproOroReceiptState = MutableStateFlow<UsedGoldTransaction?>(null)
    val comproOroReceiptState = _comproOroReceiptState.asStateFlow()

    fun setUsedGoldInputs(desc: String, weight: String, fineness: String) {
        _usedGoldItemDescription.value = desc
        _usedGoldGrossWeight.value = weight
        _usedGoldFineness.value = fineness
    }

    fun evaluateUsedGold() {
        val weight = _usedGoldGrossWeight.value.toDoubleOrNull() ?: 0.0
        val fineness = _usedGoldFineness.value.toDoubleOrNull() ?: 0.0
        if (weight <= 0.0 || fineness <= 0.0) return

        val item = repo.evaluateUsedGold(_usedGoldItemDescription.value, weight, fineness)
        _currentActiveUsedGoldOffer.value = item
    }

    fun addItemToComproOroBasket() {
        val item = _currentActiveUsedGoldOffer.value ?: return
        _comproOroIntakeBasket.value = _comproOroIntakeBasket.value + item
        _currentActiveUsedGoldOffer.value = null
        _usedGoldItemDescription.value = ""
        _usedGoldGrossWeight.value = "0.0"
    }

    fun clearComproOroBasket() {
        _comproOroIntakeBasket.value = emptyList()
        _currentActiveUsedGoldOffer.value = null
        _comproOroReceiptState.value = null
    }

    fun setComproOroSeller(name: String, taxCode: String, docId: String) {
        _comproOroSellerName.value = name
        _comproOroSellerTaxCode.value = taxCode
        _comproOroSellerDocId.value = docId
    }

    fun executeComproOroPurchase() {
        val basket = _comproOroIntakeBasket.value
        val name = _comproOroSellerName.value
        val taxCode = _comproOroSellerTaxCode.value
        val docId = _comproOroSellerDocId.value

        if (basket.isEmpty() || name.isBlank() || taxCode.isBlank() || docId.isBlank()) {
            return
        }

        viewModelScope.launch {
            val trans = repo.executeComproOroTransaction(name, taxCode, docId, basket)
            _comproOroReceiptState.value = trans
            _comproOroIntakeBasket.value = emptyList()
            _comproOroSellerName.value = ""
            _comproOroSellerTaxCode.value = ""
            _comproOroSellerDocId.value = ""
        }
    }

    // --- FAMILY OFFICE CONSOLIDATION ROLES ---
    private val _familyOfficeRole = MutableStateFlow("Family Advisor") // "Family Office Manager", "Owner", "Auditor"
    val familyOfficeRole = _familyOfficeRole.asStateFlow()

    fun setFamilyOfficeRole(role: String) {
        _familyOfficeRole.value = role
    }

    // --- DOCUMENT SELECTION STATE ---
    private val _selectedDocument = MutableStateFlow<AureoDocument?>(null)
    val selectedDocument = _selectedDocument.asStateFlow()

    fun viewDocument(doc: AureoDocument) {
        _selectedDocument.value = doc
        navigateTo(AureoScreen.Documents)
    }

    fun closeDocument() {
        _selectedDocument.value = null
        navigateBack()
    }

    // --- AI CHAT SYSTEM STATE ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("AUREO_AI", "Buongiorno Famiglia Bianchi, sono Aureo AI. Posso assistervi nella rendicontazione dei vostri lingotti rari, calcolare le tasse forfettarie e d'imposta sul vostro oro, o illustrarvi la composizione fisica dei comparti blindati di Milano. Cosa desiderate consultare?", SimpleDateFormat("HH:mm", Locale.ITALIAN).format(Date()))
        )
    )
    val chatMessages = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading = _isChatLoading.asStateFlow()

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return

        val userMsg = ChatMessage("USER", text, SimpleDateFormat("HH:mm", Locale.ITALIAN).format(Date()))
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            _isChatLoading.value = true
            // Small typing delay for premium human feel
            kotlinx.coroutines.delay(800)
            val responseText = AureoAiService.askAssistant(text)
            val aiMsg = ChatMessage("AUREO_AI", responseText, SimpleDateFormat("HH:mm", Locale.ITALIAN).format(Date()))
            _chatMessages.value = _chatMessages.value + aiMsg
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage("AUREO_AI", "Rendiconto cancellato. Come posso aiutarvi ad amministrare il vostro patrimonio?", SimpleDateFormat("HH:mm", Locale.ITALIAN).format(Date()))
        )
    }

    // Market ticks periodically
    fun tickPrices() {
        repo.triggerMarketTick()
    }
}
