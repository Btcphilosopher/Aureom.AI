package com.example.data.repository

import com.example.data.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

// --- ABSTRACT OAM COMPLIANCE ADAPTER ---
interface OAMComplianceProvider {
    fun checkOperatorStatus(operatorVat: String): Boolean
    fun validateRequiredInformation(client: Client, taxCode: String): Map<String, Boolean>
    fun submitComplianceEvent(eventId: String, eventData: Map<String, String>): String
    fun retrieveReference(referenceId: String): String
}

class MockOAMProvider : OAMComplianceProvider {
    override fun checkOperatorStatus(operatorVat: String): Boolean {
        // Deterministic check for compliance register
        return operatorVat.startsWith("IT") && operatorVat.length == 13
    }

    override fun validateRequiredInformation(client: Client, taxCode: String): Map<String, Boolean> {
        return mapOf(
            "CODICE_FISCALE_VALID" to (taxCode.length == 16),
            "KYC_DOCUMENT_APPROVED" to (client.kyvStatus == "VERIFIED"),
            "BENEFICIAL_OWNER_KNOWN" to true,
            "SANCTIONS_CLEAR" to (client.riskScore < 70)
        )
    }

    override fun submitComplianceEvent(eventId: String, eventData: Map<String, String>): String {
        val oamProtocol = "OAM-REG-${Random.nextInt(100000, 999999)}"
        return oamProtocol
    }

    override fun retrieveReference(referenceId: String): String {
        return "REG-REF-ITALIA-OAM-2026-$referenceId"
    }
}

// --- GOLD/SILVER MARKET PRICING ENGINE ---
interface MarketDataProvider {
    fun getGoldSpotPriceEur(): Double
    fun getSilverSpotPriceEur(): Double
    fun getExchangeRate(pair: String): Double // "EUR_USD", "EUR_CHF", "EUR_GBP"
}

class SyntheticMarketDataProvider(private val random: Random) : MarketDataProvider {
    private var goldSpot = 2566.45 // EUR per oz (~ 82.50 EUR/gram)
    private var silverSpot = 1050.20 // EUR per kg (~ 1.05 EUR/gram)

    fun tickPrices() {
        // Small random walk to simulate live market tickers
        goldSpot += random.nextDouble(-1.2, 1.5)
        silverSpot += random.nextDouble(-0.8, 1.1)
    }

    override fun getGoldSpotPriceEur(): Double = goldSpot
    override fun getSilverSpotPriceEur(): Double = silverSpot

    override fun getExchangeRate(pair: String): Double {
        return when (pair) {
            "EUR_USD" -> 1.0850 + random.nextDouble(-0.001, 0.001)
            "EUR_CHF" -> 0.9620 + random.nextDouble(-0.0005, 0.0005)
            "EUR_GBP" -> 0.8540 + random.nextDouble(-0.0004, 0.0004)
            else -> 1.0
        }
    }

    // Overloaded to return Double
    fun getExchangeRateVal(pair: String): Double {
        return when (pair) {
            "EUR_USD" -> 1.0852
            "EUR_CHF" -> 0.9615
            "EUR_GBP" -> 0.8542
            else -> 1.0
        }
    }
}

// --- CORE REPOSITORY MANAGEMENT ---
object AureoRepository {
    private val seed = 20261004L
    private val random = Random(seed)

    val oamProvider = MockOAMProvider()
    val marketData = SyntheticMarketDataProvider(random)

    // Formatting utilities
    val currencyFormat = DecimalFormat("###,###,##0.00")
    val weightFormat = DecimalFormat("#,##0.000")
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ITALIAN)

    // --- STATE FLOWS ---
    private val _clients = MutableStateFlow<List<Client>>(emptyList())
    val clients: StateFlow<List<Client>> = _clients.asStateFlow()

    private val _entities = MutableStateFlow<List<ClientEntity>>(emptyList())
    val entities: StateFlow<List<ClientEntity>> = _entities.asStateFlow()

    private val _accounts = MutableStateFlow<List<MetalAccount>>(emptyList())
    val accounts: StateFlow<List<MetalAccount>> = _accounts.asStateFlow()

    private val _products = MutableStateFlow<List<BullionProduct>>(emptyList())
    val products: StateFlow<List<BullionProduct>> = _products.asStateFlow()

    private val _bars = MutableStateFlow<List<BullionBar>>(emptyList())
    val bars: StateFlow<List<BullionBar>> = _bars.asStateFlow()

    private val _passportEvents = MutableStateFlow<List<PassportEvent>>(emptyList())
    val passportEvents: StateFlow<List<PassportEvent>> = _passportEvents.asStateFlow()

    private val _vaults = MutableStateFlow<List<VaultFacility>>(emptyList())
    val vaults: StateFlow<List<VaultFacility>> = _vaults.asStateFlow()

    private val _compartments = MutableStateFlow<List<VaultCompartment>>(emptyList())
    val compartments: StateFlow<List<VaultCompartment>> = _compartments.asStateFlow()

    private val _orders = MutableStateFlow<List<MetalOrder>>(emptyList())
    val orders: StateFlow<List<MetalOrder>> = _orders.asStateFlow()

    private val _quotes = MutableStateFlow<List<QuoteResponse>>(emptyList())
    val quotes: StateFlow<List<QuoteResponse>> = _quotes.asStateFlow()

    private val _goldLedger = MutableStateFlow<List<GoldLedgerEntry>>(emptyList())
    val goldLedger: StateFlow<List<GoldLedgerEntry>> = _goldLedger.asStateFlow()

    private val _silverLedger = MutableStateFlow<List<SilverLedgerEntry>>(emptyList())
    val silverLedger: StateFlow<List<SilverLedgerEntry>> = _silverLedger.asStateFlow()

    private val _cashLedger = MutableStateFlow<List<CashLedgerEntry>>(emptyList())
    val cashLedger: StateFlow<List<CashLedgerEntry>> = _cashLedger.asStateFlow()

    private val _documents = MutableStateFlow<List<AureoDocument>>(emptyList())
    val documents: StateFlow<StateFlow<List<AureoDocument>>> = MutableStateFlow(_documents.asStateFlow())

    private val _complianceCases = MutableStateFlow<List<ComplianceCase>>(emptyList())
    val complianceCases: StateFlow<List<ComplianceCase>> = _complianceCases.asStateFlow()

    private val _usedGoldTransactions = MutableStateFlow<List<UsedGoldTransaction>>(emptyList())
    val usedGoldTransactions: StateFlow<List<UsedGoldTransaction>> = _usedGoldTransactions.asStateFlow()

    // Active state indicators
    private val _reconciliationStatus = MutableStateFlow("RECONCILIED_TODAY")
    val reconciliationStatus: StateFlow<String> = _reconciliationStatus.asStateFlow()

    // Constant ids for our demonstration client: FAMIGLIA BIANCHI
    const val CLIENT_BIANCHI_ID = "CLI-BIANCHI-918"

    init {
        seedInitialData()
    }

    fun getDocumentsValue(): List<AureoDocument> = _documents.value

    fun triggerMarketTick() {
        marketData.tickPrices()
        // Force evaluation recalculation of valuations
        recalculateValuations()
    }

    private fun recalculateValuations() {
        val currentGoldPriceOz = marketData.getGoldSpotPriceEur()
        val currentSilverPriceKg = marketData.getSilverSpotPriceEur()

        _bars.value = _bars.value.map { bar ->
            val value = if (bar.metal == MetalType.GOLD) {
                bar.fineWeightOzOrKg * currentGoldPriceOz
            } else {
                bar.fineWeightOzOrKg * currentSilverPriceKg
            }
            bar.copy(valuationEur = value)
        }
    }

    private fun seedInitialData() {
        // 1. Seed Client
        val bianchi = Client(
            id = CLIENT_BIANCHI_ID,
            name = "Famiglia Bianchi",
            segment = "Family Office",
            city = "Milano",
            taxCode = "BNCFMG52L21F205K",
            kyvStatus = "VERIFIED",
            riskScore = 22,
            isProfessionalOperator = true,
            OAMRegistrationNumber = "OPO-2026-904"
        )
        _clients.value = listOf(bianchi)

        // Seed Client Entities
        _entities.value = listOf(
            ClientEntity("ENT-1", CLIENT_BIANCHI_ID, "Bianchi Holding S.r.l.", "Holding Company"),
            ClientEntity("ENT-2", CLIENT_BIANCHI_ID, "Famiglia Bianchi Personal Ledger", "Personal Account"),
            ClientEntity("ENT-3", CLIENT_BIANCHI_ID, "Vetra Immobiliare S.p.A. Treasury", "Trust Vehicle")
        )

        // 2. Seed Vaults
        val milanoVault = VaultFacility(
            id = "VAULT-MI-01",
            name = "Milano Vault Excellentia 01",
            city = "Milano",
            address = "Via Monte Napoleone 12, Milano",
            securityLevel = "Class X VdS Supreme Vault",
            isInternational = false,
            capacityKg = 18000.00,
            occupiedGoldKg = 7821.00,
            occupiedSilverKg = 3600.00,
            securityStatus = "SECURE_ACTIVE",
            inspectionStatus = "RECONCILIED_TODAY"
        )
        val romaVault = VaultFacility(
            id = "VAULT-RO-02",
            name = "Roma Vault Imperiale 02",
            city = "Roma",
            address = "Piazza di Spagna 33, Roma",
            securityLevel = "Class IX VdS Vault",
            isInternational = false,
            capacityKg = 12000.00,
            occupiedGoldKg = 4120.00,
            occupiedSilverKg = 1500.00,
            securityStatus = "SECURE_ACTIVE",
            inspectionStatus = "RECONCILIED_TODAY"
        )
        val zurigoVault = VaultFacility(
            id = "VAULT-ZH-03",
            name = "Zurigo Alpine Safe Custody",
            city = "Zurigo",
            address = "Bahnhofstrasse 45, Zurigo (CH)",
            securityLevel = "Class X VdS Swiss Grade",
            isInternational = true,
            capacityKg = 25000.00,
            occupiedGoldKg = 12400.00,
            occupiedSilverKg = 6100.00,
            securityStatus = "SECURE_ACTIVE",
            inspectionStatus = "RECONCILIED_TODAY"
        )
        _vaults.value = listOf(milanoVault, romaVault, zurigoVault)

        // Seed Vault Compartments
        val compMilano1 = VaultCompartment("COMP-MI-1", "VAULT-MI-01", "Caveau A - Alta Sicurezza", "Cassaforte S-24", "Comparto Gold Private Banking")
        val compMilano2 = VaultCompartment("COMP-MI-2", "VAULT-MI-01", "Caveau B - Custodia Generale", "Vano Armato Silver-03", "Comparto Silver Private")
        val compRoma1 = VaultCompartment("COMP-RO-1", "VAULT-RO-02", "Caveau Romano Central", "Forziere F-12", "Comparto Standard")
        val compZurigo1 = VaultCompartment("COMP-ZH-1", "VAULT-ZH-03", "Alpine Vault Alpha", "Safe-S6", "Comparto Swiss-Customs-Exempt")
        _compartments.value = listOf(compMilano1, compMilano2, compRoma1, compZurigo1)

        // 3. Seed Products
        val productsList = listOf(
            // GOLD
            BullionProduct("PROD-AU-100G", MetalType.GOLD, ProductType.BAR, "Chimet Arezzo S.p.A.", "Chimet Refiner S.r.l.", "Aureo Italia Mint", 100.0, 100.0, 3.215, 999.9, "50 x 30 x 4 mm", true, true, 0.008, true),
            BullionProduct("PROD-AU-1KG", MetalType.GOLD, ProductType.BAR, "Argor-Heraeus", "Argor-Heraeus Chiasso", "Valcambi S.A.", 1000.0, 1000.0, 32.1507, 999.9, "115 x 52 x 9 mm", true, true, 0.005, true),
            BullionProduct("PROD-AU-1OZ", MetalType.GOLD, ProductType.BAR, "Italpreziosi S.p.A.", "Italpreziosi Arezzo", "Italpreziosi", 31.103, 31.103, 1.0, 999.9, "38 x 22 x 2.3 mm", true, true, 0.012, true),
            BullionProduct("PROD-AU-COIN-MARENGO", MetalType.GOLD, ProductType.COIN, "Zecca dello Stato", "Zecca di Roma", "Marengo d'Oro", 6.45, 5.8, 0.186, 900.0, "21 mm Diametro", false, false, 0.045, true), // Marengo d'oro (historical investment gold coin)
            
            // SILVER
            BullionProduct("PROD-AG-1KG", MetalType.SILVER, ProductType.BAR, "Italpreziosi S.p.A.", "Italpreziosi Arezzo", "Italpreziosi", 1000.0, 1000.0, 1.0, 999.0, "115 x 52 x 15 mm", true, true, 0.045, false),
            BullionProduct("PROD-AG-5KG", MetalType.SILVER, ProductType.BAR, "Chimet Arezzo S.p.A.", "Chimet Refiner S.r.l.", "Aureo Italia Mint", 5000.0, 5000.0, 5.0, 999.0, "165 x 72 x 28 mm", true, true, 0.035, false),
            BullionProduct("PROD-AG-100OZ", MetalType.SILVER, ProductType.BAR, "Valcambi S.A.", "Valcambi Chiasso", "Valcambi", 3110.3, 3110.3, 3.1103, 999.0, "150 x 60 x 22 mm", true, true, 0.028, false)
        )
        _products.value = productsList

        // 4. Seed Gold & Silver Accounts for Famiglia Bianchi
        val bianchiAccount = MetalAccount(
            id = "ACC-BIANCHI-901",
            clientId = CLIENT_BIANCHI_ID,
            goldAllocatedOz = 1600.40,
            goldUnallocatedOz = 242.00,
            silverAllocatedKg = 31.20,
            silverUnallocatedKg = 11.60,
            cashBalanceEur = 250000.00
        )
        _accounts.value = listOf(bianchiAccount)

        // 5. Seed Allocated Bars for Famiglia Bianchi
        val currentGoldPriceOz = marketData.getGoldSpotPriceEur()
        val currentSilverPriceKg = marketData.getSilverSpotPriceEur()

        val seededBars = listOf(
            // Famiglia Bianchi Gold Bars (Seeding 1600.40 oz)
            // 15 bars of 1kg (each is 32.1507 oz) = 482.26 oz
            // Plus some 100g and 1oz bars
            BullionBar(
                id = "BAR-AU-2026-004821",
                productId = "PROD-AU-100G",
                metal = MetalType.GOLD,
                serialNumber = "AU-IT-2026-004821",
                manufacturer = "Chimet Arezzo S.p.A.",
                fineness = 999.9,
                fineWeightOzOrKg = 3.215, // 100g
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = "VAULT-MI-01",
                compartmentId = "COMP-MI-1",
                certificateId = "CERT-AU-004821",
                valuationEur = 3.215 * currentGoldPriceOz
            ),
            BullionBar(
                id = "BAR-AU-2026-004822",
                productId = "PROD-AU-1KG",
                metal = MetalType.GOLD,
                serialNumber = "AU-CH-2026-009148",
                manufacturer = "Argor-Heraeus Chiasso",
                fineness = 999.9,
                fineWeightOzOrKg = 32.1507, // 1kg
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = "VAULT-MI-01",
                compartmentId = "COMP-MI-1",
                certificateId = "CERT-AU-004822",
                valuationEur = 32.1507 * currentGoldPriceOz
            ),
            BullionBar(
                id = "BAR-AU-2026-004823",
                productId = "PROD-AU-1KG",
                metal = MetalType.GOLD,
                serialNumber = "AU-CH-2026-009149",
                manufacturer = "Argor-Heraeus Chiasso",
                fineness = 999.9,
                fineWeightOzOrKg = 32.1507, // 1kg
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = "VAULT-MI-01",
                compartmentId = "COMP-MI-1",
                certificateId = "CERT-AU-004823",
                valuationEur = 32.1507 * currentGoldPriceOz
            ),
            // Famiglia Bianchi Silver Bars (Seeding 31.20 kg)
            // 31 bars of 1kg = 31 kg
            BullionBar(
                id = "BAR-AG-2026-000821",
                productId = "PROD-AG-1KG",
                metal = MetalType.SILVER,
                serialNumber = "AG-IT-2026-000821",
                manufacturer = "Italpreziosi S.p.A.",
                fineness = 999.0,
                fineWeightOzOrKg = 1.0, // 1 kg
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = "VAULT-MI-01",
                compartmentId = "COMP-MI-2",
                certificateId = "CERT-AG-000821",
                valuationEur = 1.0 * currentSilverPriceKg
            ),
            BullionBar(
                id = "BAR-AG-2026-000822",
                productId = "PROD-AG-5KG",
                metal = MetalType.SILVER,
                serialNumber = "AG-IT-2026-000822",
                manufacturer = "Chimet Arezzo S.p.A.",
                fineness = 999.0,
                fineWeightOzOrKg = 5.0, // 5 kg
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = "VAULT-MI-01",
                compartmentId = "COMP-MI-2",
                certificateId = "CERT-AG-000822",
                valuationEur = 5.0 * currentSilverPriceKg
            )
        )
        _bars.value = seededBars

        // Seed Passport Events for these bars
        val initialEvents = mutableListOf<PassportEvent>()
        seededBars.forEach { bar ->
            initialEvents.add(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = bar.id,
                    timestamp = "12/03/2026 10:14:00",
                    actor = "Raffineria Fonderia",
                    location = bar.manufacturer,
                    eventType = "PRODUZIONE",
                    previousState = "SILICIO_GREZZO",
                    newState = "LINGOTTO_COLATO",
                    authorizationCode = "AUTH-PROD-${random.nextInt(10000, 99999)}",
                    documentReference = "REF-PROD-${bar.serialNumber}",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )
            initialEvents.add(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = bar.id,
                    timestamp = "12/03/2026 14:30:22",
                    actor = "Saggiatore Autorizzato OAM",
                    location = bar.manufacturer,
                    eventType = "SAGGIATURA",
                    previousState = "LINGOTTO_COLATO",
                    newState = "TITOLO_CERTIFICATO_${bar.fineness}",
                    authorizationCode = "AUTH-SAGG-${random.nextInt(10000, 99999)}",
                    documentReference = "REF-SAGG-${bar.serialNumber}",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )
            initialEvents.add(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = bar.id,
                    timestamp = "13/03/2026 09:00:00",
                    actor = "Ufficio Certificazione Aureo",
                    location = "Aureo Milano HQ",
                    eventType = "CERTIFICAZIONE",
                    previousState = "TITOLO_CERTIFICATO",
                    newState = "GARANTITO_AUREO_EXCELLENTIA",
                    authorizationCode = "AUTH-CERT-${random.nextInt(10000, 99999)}",
                    documentReference = bar.certificateId,
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )
            initialEvents.add(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = bar.id,
                    timestamp = "15/03/2026 16:45:00",
                    actor = "Broker Private Banking",
                    location = "Milano Vault Excellentia 01",
                    eventType = "ACQUISTO",
                    previousState = "INVENTARIO_BANCO",
                    newState = "PROPRIETA_CLIENTE",
                    authorizationCode = "AUTH-ACQ-${random.nextInt(10000, 99999)}",
                    documentReference = "CONF-ACQ-2026-0048",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )
            initialEvents.add(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = bar.id,
                    timestamp = "15/03/2026 17:00:00",
                    actor = "Operatore di Caveau",
                    location = "Milano Vault Excellentia 01",
                    eventType = "CUSTODIA",
                    previousState = "PROPRIETA_CLIENTE",
                    newState = "DEPOSITATO_CAVEAU",
                    authorizationCode = "AUTH-CUST-${random.nextInt(10000, 99999)}",
                    documentReference = "CERT-CUST-${bar.serialNumber}",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )
        }
        _passportEvents.value = initialEvents

        // Seed Compliance Cases
        _complianceCases.value = listOf(
            ComplianceCase(
                id = "COMPL-101",
                clientId = CLIENT_BIANCHI_ID,
                timestamp = "01/01/2026 10:00:00",
                type = "KYC_VERIFICATION",
                description = "Adeguata Verifica ed identificazione titolare effettivo.",
                score = 15,
                status = "APPROVED",
                verificationReference = "OAM-KYC-REF-0012"
            ),
            ComplianceCase(
                id = "COMPL-102",
                clientId = CLIENT_BIANCHI_ID,
                timestamp = "01/01/2026 10:15:00",
                type = "AML_MONITORING",
                description = "Controllo liste sanzioni internazionali, PEP e record antiriciclaggio.",
                score = 12,
                status = "APPROVED",
                verificationReference = "OAM-AML-SCREEN-99"
            ),
            ComplianceCase(
                id = "COMPL-103",
                clientId = CLIENT_BIANCHI_ID,
                timestamp = "15/04/2026 14:00:00",
                type = "SOURCE_OF_FUNDS",
                description = "Verifica origine dei fondi da plusvalenza societaria e rendiconto notarile.",
                score = 10,
                status = "APPROVED",
                verificationReference = "REP-NOT-88421"
            )
        )

        // Seed initial documents
        val doc1 = AureoDocument(
            id = "DOC-901",
            documentNumber = "CONF-ACQ-2026-0048",
            documentType = "CONFERMA_ACQUISTO",
            date = "15/03/2026",
            clientId = CLIENT_BIANCHI_ID,
            clientName = bianchi.name,
            referenceId = "BAR-AU-2026-004821",
            description = "Acquisto Lingotto Oro 100g - Allocazione Milano 01",
            valueEur = 3.215 * currentGoldPriceOz,
            contentMeta = mapOf(
                "Metallo" to "ORO",
                "Peso Fine" to "100.0 g",
                "Purezza" to "999.9",
                "Seriale" to "AU-IT-2026-004821",
                "Deposito" to "Milano Vault Excellentia 01",
                "Stato" to "ALLOCATO"
            )
        )
        val doc2 = AureoDocument(
            id = "DOC-902",
            documentNumber = "CERT-ALLOC-2026-0012",
            documentType = "CERTIFICATO_ALLOCAZIONE",
            date = "15/03/2026",
            clientId = CLIENT_BIANCHI_ID,
            clientName = bianchi.name,
            referenceId = "BAR-AU-2026-004822",
            description = "Certificato di Proprietà Reale e Allocazione Fisica Lingotto Oro 1kg",
            valueEur = 32.1507 * currentGoldPriceOz,
            contentMeta = mapOf(
                "Metallo" to "ORO",
                "Peso Fine" to "1.000,00 g (1 kg)",
                "Purezza" to "999.9",
                "Seriale" to "AU-CH-2026-009148",
                "Raffineria" to "Argor-Heraeus Chiasso",
                "Garante" to "Aureo Italia Professional Gold Operator"
            )
        )
        val doc3 = AureoDocument(
            id = "DOC-903",
            documentNumber = "RECON-REP-2026-10",
            documentType = "ESTRATTO_CONTO",
            date = "01/10/2026",
            clientId = CLIENT_BIANCHI_ID,
            clientName = bianchi.name,
            referenceId = bianchiAccount.id,
            description = "Estratto Conto Metalli Pregiati - Famiglia Bianchi Q3 2026",
            valueEur = (bianchiAccount.goldAllocatedOz + bianchiAccount.goldUnallocatedOz) * currentGoldPriceOz + (bianchiAccount.silverAllocatedKg + bianchiAccount.silverUnallocatedKg) * currentSilverPriceKg,
            contentMeta = mapOf(
                "Saldo Oro Totale" to "1.842,40 oz",
                "Saldo Argento Totale" to "42,80 kg",
                "Frazione Allocata" to "87,5%",
                "Valore di Carico Medio" to "€ 2.450,00 / oz (Oro)",
                "Deposito Custode" to "Aureo Vault Services"
            )
        )
        _documents.value = listOf(doc1, doc2, doc3)

        // Seed Ledgers
        _goldLedger.value = listOf(
            GoldLedgerEntry("GL-1", "15/03/2026 16:45:00", CLIENT_BIANCHI_ID, null, 3.215, "ACQUISTO", "Lingotto AU-IT-2026-004821"),
            GoldLedgerEntry("GL-2", "15/03/2026 16:45:00", CLIENT_BIANCHI_ID, null, 32.1507, "ACQUISTO", "Lingotto AU-CH-2026-009148"),
            GoldLedgerEntry("GL-3", "15/03/2026 16:45:00", CLIENT_BIANCHI_ID, null, 32.1507, "ACQUISTO", "Lingotto AU-CH-2026-009149"),
            GoldLedgerEntry("GL-4", "20/06/2026 11:20:00", CLIENT_BIANCHI_ID, null, 242.00, "DEPOSIT_UNALLOCATED", "Allocazione Pool Liquido Gold")
        )

        _silverLedger.value = listOf(
            SilverLedgerEntry("SL-1", "15/03/2026 17:00:00", CLIENT_BIANCHI_ID, null, 1.0, "ACQUISTO", "Lingotto AG-IT-2026-000821"),
            SilverLedgerEntry("SL-2", "15/03/2026 17:00:00", CLIENT_BIANCHI_ID, null, 5.0, "ACQUISTO", "Lingotto AG-IT-2026-000822"),
            SilverLedgerEntry("SL-3", "20/06/2026 11:30:00", CLIENT_BIANCHI_ID, null, 11.60, "DEPOSIT_UNALLOCATED", "Allocazione Pool Liquido Silver")
        )

        _cashLedger.value = listOf(
            CashLedgerEntry("CL-1", "01/01/2026 09:00:00", CLIENT_BIANCHI_ID, 500000.00, "DEPOSIT", "Bonifico SEPA Credito Intesa Sanpaolo"),
            CashLedgerEntry("CL-2", "15/03/2026 16:45:00", CLIENT_BIANCHI_ID, -195000.00, "PURCHASE", "Acquisto Lingotti Gold & Silver Fisici"),
            CashLedgerEntry("CL-3", "01/07/2026 12:00:00", CLIENT_BIANCHI_ID, -1250.00, "CUSTODY_FEES", "Addebito Spese Trimestrali di Custodia e Assicurazione Caveau")
        )
    }

    // --- WORKFLOW: REQUEST RFQ (PRICE QUOTATION ENGINE) ---
    fun requestRfq(productId: String, quantity: Int): QuoteResponse {
        val product = _products.value.firstOrNull { it.id == productId }
            ?: throw IllegalArgumentException("Prodotto non valido o non disponibile nel catalogo.")

        val spotPrice = if (product.metal == MetalType.GOLD) {
            marketData.getGoldSpotPriceEur()
        } else {
            marketData.getSilverSpotPriceEur()
        }

        val fineWeightValue = product.fineWeightOzOrKg
        val baseMetalValue = fineWeightValue * spotPrice * quantity
        val premiumPercent = product.defaultPremiumPercent
        val physicalPremium = baseMetalValue * premiumPercent

        // Italian Tax Engine
        // Gold: Investment Gold has 0% VAT in Italy.
        // Silver: Investment Silver or Industrial Silver has 22% VAT.
        val taxRate = if (product.metal == MetalType.GOLD && product.isInvestmentGold) 0.0 else 0.22
        val taxVat = (baseMetalValue + physicalPremium) * taxRate

        val totalCost = baseMetalValue + physicalPremium + taxVat

        val validitySec = 45 // 45 seconds pricing lock
        val validUntil = Calendar.getInstance().apply {
            add(Calendar.SECOND, validitySec)
        }.time

        val quote = QuoteResponse(
            id = "QT-${random.nextInt(100000, 999999)}",
            rfqId = "RFQ-${random.nextInt(10000, 99999)}",
            productId = productId,
            quantity = quantity,
            spotPricePerUnit = spotPrice,
            physicalPremiumEur = physicalPremium,
            taxVatEur = taxVat,
            totalCostEur = totalCost,
            validUntilTimestamp = dateFormat.format(validUntil),
            spreadPercent = premiumPercent,
            storageFeeAnnualPercent = if (product.metal == MetalType.GOLD) 0.0025 else 0.0045 // 0.25% Gold, 0.45% Silver
        )

        _quotes.value = _quotes.value + quote
        return quote
    }

    // --- WORKFLOW: CONFIRM PURCHASE (ORDER SETTLEMENT & ALLOCATION) ---
    fun confirmPurchase(quoteId: String, paymentMethod: String): MetalOrder {
        val quote = _quotes.value.firstOrNull { it.id == quoteId }
            ?: throw IllegalArgumentException("Quotazione scaduta o non valida.")

        val product = _products.value.first { it.id == quote.productId }
        val account = _accounts.value.first { it.clientId == CLIENT_BIANCHI_ID }

        if (paymentMethod == "Private Wealth Cash Ledger" && account.cashBalanceEur < quote.totalCostEur) {
            throw IllegalStateException("Saldo contanti insufficiente sul Conto Metalli per completare l'operazione.")
        }

        // 1. Spend Cash
        val newCashBalance = if (paymentMethod == "Private Wealth Cash Ledger") {
            account.cashBalanceEur - quote.totalCostEur
        } else {
            account.cashBalanceEur
        }

        // 2. Add cash ledger log if ledger payment
        if (paymentMethod == "Private Wealth Cash Ledger") {
            _cashLedger.value = _cashLedger.value + CashLedgerEntry(
                id = "CL-${random.nextInt(10000, 99999)}",
                timestamp = dateFormat.format(Date()),
                clientId = CLIENT_BIANCHI_ID,
                deltaEur = -quote.totalCostEur,
                type = "PURCHASE",
                reference = "Acquisto ${product.brand} - Rif Quotazione $quoteId"
            )
        }

        val orderId = "ORD-${random.nextInt(100000, 999999)}"

        // 3. Physical metal allocation logic
        val newAllocatedOz: Double
        val newUnallocatedOz: Double
        val newAllocatedKg: Double
        val newUnallocatedKg: Double

        var newlyAllocatedBar: BullionBar? = null

        val currentSpot = if (product.metal == MetalType.GOLD) marketData.getGoldSpotPriceEur() else marketData.getSilverSpotPriceEur()
        val calculatedValuation = product.fineWeightOzOrKg * currentSpot

        if (product.hasSerial) {
            // ALLOCATE A REAL PHYSICAL BAR WITH PASSPORT LOGS
            val newBarId = "BAR-${product.metal.name}-${random.nextInt(100000, 999999)}"
            val prefix = if (product.metal == MetalType.GOLD) "AU" else "AG"
            val serial = "$prefix-IT-2026-${random.nextInt(100000, 999999)}"
            val certId = "CERT-$prefix-${random.nextInt(100000, 999999)}"

            val targetVault = "VAULT-MI-01" // Milano Excellentia
            val targetCompartment = if (product.metal == MetalType.GOLD) "COMP-MI-1" else "COMP-MI-2"

            newlyAllocatedBar = BullionBar(
                id = newBarId,
                productId = product.id,
                metal = product.metal,
                serialNumber = serial,
                manufacturer = product.manufacturer,
                fineness = product.fineness,
                fineWeightOzOrKg = product.fineWeightOzOrKg,
                currentOwnerId = CLIENT_BIANCHI_ID,
                status = CustodyStatus.ALLOCATED,
                vaultId = targetVault,
                compartmentId = targetCompartment,
                certificateId = certId,
                valuationEur = calculatedValuation
            )

            // Append to physical bars flow
            _bars.value = _bars.value + newlyAllocatedBar

            // Seed complete provenance passport timeline
            val timestampNow = dateFormat.format(Date())
            val productionTime = "04/09/2026 09:30:00"
            val assayTime = "04/09/2026 14:15:00"
            val certTime = "05/09/2026 10:00:00"

            val pEvents = listOf(
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = newBarId,
                    timestamp = productionTime,
                    actor = product.manufacturer,
                    location = "Stabilimento Raffineria Arezzo",
                    eventType = "PRODUZIONE",
                    previousState = "FUSIONE_GREZZA",
                    newState = "LINGOTTO_STAMPATO_TITOLO",
                    authorizationCode = "AUTH-PROD-${random.nextInt(10000, 99999)}",
                    documentReference = "REF-PROD-$serial",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                ),
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = newBarId,
                    timestamp = assayTime,
                    actor = "Saggiatore Ufficiale",
                    location = "Arezzo, Italia",
                    eventType = "SAGGIATURA",
                    previousState = "LINGOTTO_STAMPATO_TITOLO",
                    newState = "SAGGIO_CONFERMATO_${product.fineness}",
                    authorizationCode = "AUTH-SAGG-${random.nextInt(10000, 99999)}",
                    documentReference = "REF-SAGG-$serial",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                ),
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = newBarId,
                    timestamp = certTime,
                    actor = "Ufficio Compliance Aureo",
                    location = "Milano Headquarters",
                    eventType = "CERTIFICAZIONE",
                    previousState = "TITOLO_SAGGIO",
                    newState = "GARANTITO_PROPRIETA_AUREO",
                    authorizationCode = "AUTH-CERT-${random.nextInt(10000, 99999)}",
                    documentReference = certId,
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                ),
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = newBarId,
                    timestamp = timestampNow,
                    actor = "Client Portal Platform",
                    location = "Milano",
                    eventType = "ACQUISTO",
                    previousState = "INVENTARIO_AUREO",
                    newState = "PROPRIETA_PRIVATA_BIANCHI",
                    authorizationCode = "AUTH-ACQ-${random.nextInt(10000, 99999)}",
                    documentReference = orderId,
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                ),
                PassportEvent(
                    id = UUID.randomUUID().toString(),
                    barId = newBarId,
                    timestamp = timestampNow,
                    actor = "Operatore Caveau Milano",
                    location = "Milano Vault Excellentia 01",
                    eventType = "ASSEGNAZIONE",
                    previousState = "PROPRIETA_PRIVATA_BIANCHI",
                    newState = "ALLOCATO_COMPARTIMENTO_$targetCompartment",
                    authorizationCode = "AUTH-ALLOC-${random.nextInt(10000, 99999)}",
                    documentReference = "CERT-ALLOC-$serial",
                    cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
                )
            )

            _passportEvents.value = _passportEvents.value + pEvents

            // Update client's physical ledger balances
            if (product.metal == MetalType.GOLD) {
                newAllocatedOz = account.goldAllocatedOz + product.fineWeightOzOrKg
                newUnallocatedOz = account.goldUnallocatedOz
                newAllocatedKg = account.silverAllocatedKg
                newUnallocatedKg = account.silverUnallocatedKg

                _goldLedger.value = _goldLedger.value + GoldLedgerEntry(
                    id = "GL-${random.nextInt(10000, 99999)}",
                    timestamp = timestampNow,
                    clientId = CLIENT_BIANCHI_ID,
                    orderId = orderId,
                    deltaOz = product.fineWeightOzOrKg,
                    type = "ACQUISTO",
                    reference = "Lingotto Fisico Allocato Seriale: $serial"
                )
            } else {
                newAllocatedOz = account.goldAllocatedOz
                newUnallocatedOz = account.goldUnallocatedOz
                newAllocatedKg = account.silverAllocatedKg + product.fineWeightOzOrKg
                newUnallocatedKg = account.silverUnallocatedKg

                _silverLedger.value = _silverLedger.value + SilverLedgerEntry(
                    id = "SL-${random.nextInt(10000, 99999)}",
                    timestamp = timestampNow,
                    clientId = CLIENT_BIANCHI_ID,
                    orderId = orderId,
                    deltaKg = product.fineWeightOzOrKg,
                    type = "ACQUISTO",
                    reference = "Lingotto Fisico Allocato Seriale: $serial"
                )
            }

            // OAM Compliance Submission
            val oamData = mapOf(
                "CLIENT_ID" to CLIENT_BIANCHI_ID,
                "OPERATION" to "ACQUISTO_METALLO_ALLOCATO",
                "METAL" to product.metal.name,
                "SERIAL" to serial,
                "VALUE" to quote.totalCostEur.toString()
            )
            val oamRef = oamProvider.submitComplianceEvent(orderId, oamData)

            // Save official purchase and allocation document
            val purchaseDoc = AureoDocument(
                id = "DOC-${random.nextInt(10000, 99999)}",
                documentNumber = "CONF-ACQ-2026-${random.nextInt(1000, 9999)}",
                documentType = "CONFERMA_ACQUISTO",
                date = SimpleDateFormat("dd/MM/yyyy", Locale.ITALIAN).format(Date()),
                clientId = CLIENT_BIANCHI_ID,
                clientName = "Famiglia Bianchi",
                referenceId = orderId,
                description = "Conferma Acquisto e Assegnazione Proprietà Oro/Argento Fisico",
                valueEur = quote.totalCostEur,
                contentMeta = mapOf(
                    "Metallo" to product.metal.name,
                    "Oggetto" to "${product.brand} (${product.grossWeightGram} g)",
                    "Seriale" to serial,
                    "Prezzo Spot" to "€ ${currencyFormat.format(quote.spotPricePerUnit)}",
                    "Spese Conio/Premio" to "€ ${currencyFormat.format(quote.physicalPremiumEur)}",
                    "IVA (Imposta Valore Aggiunto)" to "€ ${currencyFormat.format(quote.taxVatEur)}",
                    "Caveau di Custodia" to "Milano Vault Excellentia 01 (Cassaforte S-24)",
                    "Garante OAM" to oamProvider.retrieveReference(oamRef)
                )
            )
            _documents.value = _documents.value + purchaseDoc

        } else {
            // UNALLOCATED POOL POOLED HOLDING SALE
            if (product.metal == MetalType.GOLD) {
                newAllocatedOz = account.goldAllocatedOz
                newUnallocatedOz = account.goldUnallocatedOz + product.fineWeightOzOrKg
                newAllocatedKg = account.silverAllocatedKg
                newUnallocatedKg = account.silverUnallocatedKg

                _goldLedger.value = _goldLedger.value + GoldLedgerEntry(
                    id = "GL-${random.nextInt(10000, 99999)}",
                    timestamp = dateFormat.format(Date()),
                    clientId = CLIENT_BIANCHI_ID,
                    orderId = orderId,
                    deltaOz = product.fineWeightOzOrKg,
                    type = "ACQUISTO_UNALLOCATED",
                    reference = "Quota di Metallo Pool Non Allocato"
                )
            } else {
                newAllocatedOz = account.goldAllocatedOz
                newUnallocatedOz = account.goldUnallocatedOz
                newAllocatedKg = account.silverAllocatedKg
                newUnallocatedKg = account.silverUnallocatedKg + product.fineWeightOzOrKg

                _silverLedger.value = _silverLedger.value + SilverLedgerEntry(
                    id = "SL-${random.nextInt(10000, 99999)}",
                    timestamp = dateFormat.format(Date()),
                    clientId = CLIENT_BIANCHI_ID,
                    orderId = orderId,
                    deltaKg = product.fineWeightOzOrKg,
                    type = "ACQUISTO_UNALLOCATED",
                    reference = "Quota di Metallo Pool Non Allocato"
                )
            }
        }

        // 4. Update core account balances
        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == account.id) {
                acc.copy(
                    goldAllocatedOz = newAllocatedOz,
                    goldUnallocatedOz = newUnallocatedOz,
                    silverAllocatedKg = newAllocatedKg,
                    silverUnallocatedKg = newUnallocatedKg,
                    cashBalanceEur = newCashBalance
                )
            } else acc
        }

        val order = MetalOrder(
            id = orderId,
            clientId = CLIENT_BIANCHI_ID,
            productId = product.id,
            quantity = quote.quantity,
            quoteId = quote.id,
            totalCostEur = quote.totalCostEur,
            metalType = product.metal,
            timestamp = dateFormat.format(Date()),
            status = "SETTLED",
            paymentMethod = paymentMethod
        )

        _orders.value = _orders.value + order

        // Tick values to sync with layout
        recalculateValuations()

        return order
    }

    // --- WORKFLOW: SELL METALLO (BAR-SPECIFIC OR POOLED) ---
    fun sellMetal(barId: String): Double {
        val bar = _bars.value.firstOrNull { it.id == barId && it.currentOwnerId == CLIENT_BIANCHI_ID }
            ?: throw IllegalArgumentException("Lingotto fisico non trovato o non di proprietà del cliente.")

        if (bar.status != CustodyStatus.ALLOCATED) {
            throw IllegalStateException("Il lingotto selezionato non si trova attualmente in custodia e non può essere liquidato.")
        }

        val account = _accounts.value.first { it.clientId == CLIENT_BIANCHI_ID }
        val currentPrice = if (bar.metal == MetalType.GOLD) marketData.getGoldSpotPriceEur() else marketData.getSilverSpotPriceEur()
        
        // Compute sell value: physical market purchase offer (usually spot minus a tiny dealer discount of 0.5%)
        val brokerDiscount = 0.005
        val baseVal = bar.fineWeightOzOrKg * currentPrice
        val finalSellValue = baseVal * (1.0 - brokerDiscount)

        // 1. Credit Cash Balance
        val newCashBalance = account.cashBalanceEur + finalSellValue

        // 2. Remove physical bar (Mark as SOLD / WITHDRAWN)
        _bars.value = _bars.value.map { b ->
            if (b.id == barId) b.copy(status = CustodyStatus.WITHDRAWN) else b
        }

        // 3. Update account balances
        val newAllocatedOz = if (bar.metal == MetalType.GOLD) account.goldAllocatedOz - bar.fineWeightOzOrKg else account.goldAllocatedOz
        val newAllocatedKg = if (bar.metal == MetalType.SILVER) account.silverAllocatedKg - bar.fineWeightOzOrKg else account.silverAllocatedKg

        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == account.id) {
                acc.copy(
                    goldAllocatedOz = newAllocatedOz,
                    silverAllocatedKg = newAllocatedKg,
                    cashBalanceEur = newCashBalance
                )
            } else acc
        }

        val timestampNow = dateFormat.format(Date())

        // 4. Log in cash ledger and metal ledger
        _cashLedger.value = _cashLedger.value + CashLedgerEntry(
            id = "CL-${random.nextInt(10000, 99999)}",
            timestamp = timestampNow,
            clientId = CLIENT_BIANCHI_ID,
            deltaEur = finalSellValue,
            type = "SALE",
            reference = "Liquidazione Lingotto Seriale ${bar.serialNumber}"
        )

        if (bar.metal == MetalType.GOLD) {
            _goldLedger.value = _goldLedger.value + GoldLedgerEntry(
                id = "GL-${random.nextInt(10000, 99999)}",
                timestamp = timestampNow,
                clientId = CLIENT_BIANCHI_ID,
                orderId = null,
                deltaOz = -bar.fineWeightOzOrKg,
                type = "VENDITA",
                reference = "Disinvestimento lingotto ${bar.serialNumber}"
            )
        } else {
            _silverLedger.value = _silverLedger.value + SilverLedgerEntry(
                id = "SL-${random.nextInt(10000, 99999)}",
                timestamp = timestampNow,
                clientId = CLIENT_BIANCHI_ID,
                orderId = null,
                deltaKg = -bar.fineWeightOzOrKg,
                type = "VENDITA",
                reference = "Disinvestimento lingotto ${bar.serialNumber}"
            )
        }

        // 5. Append to passport event timeline
        val pEvent = PassportEvent(
            id = UUID.randomUUID().toString(),
            barId = bar.id,
            timestamp = timestampNow,
            actor = "Broker Liquidità Aureo",
            location = "Milano Desk",
            eventType = "CONSEGNA", // Physical redemption/sell-back
            previousState = "DEPOSITATO_CAVEAU",
            newState = "REQUISITO_BANCO_LIQUIDATO",
            authorizationCode = "AUTH-SALE-${random.nextInt(10000, 99999)}",
            documentReference = "CONF-VEND-${bar.serialNumber}",
            cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
        )
        _passportEvents.value = _passportEvents.value + pEvent

        // 6. Save Sell Document
        val sellDoc = AureoDocument(
            id = "DOC-${random.nextInt(10000, 99999)}",
            documentNumber = "CONF-VEND-2026-${random.nextInt(1000, 9999)}",
            documentType = "CONFERMA_VENDITA",
            date = SimpleDateFormat("dd/MM/yyyy", Locale.ITALIAN).format(Date()),
            clientId = CLIENT_BIANCHI_ID,
            clientName = "Famiglia Bianchi",
            referenceId = bar.id,
            description = "Ricevuta di vendita e liquidazione fisica metallo",
            valueEur = finalSellValue,
            contentMeta = mapOf(
                "Metallo liquidato" to bar.metal.name,
                "Identificativo" to bar.serialNumber,
                "Peso di Colata" to "${bar.fineWeightOzOrKg} ${if (bar.metal == MetalType.GOLD) "oz" else "kg"}",
                "Valore di Mercato Spot" to "€ ${currencyFormat.format(currentPrice)}",
                "Trattenuta di Liquidazione (0,5%)" to "€ ${currencyFormat.format(baseVal * brokerDiscount)}",
                "Totale Accreditato" to "€ ${currencyFormat.format(finalSellValue)}",
                "Metodo di Regolamento" to "Conto Metalli Privato"
            )
        )
        _documents.value = _documents.value + sellDoc

        recalculateValuations()
        return finalSellValue
    }

    // --- WORKFLOW: MOVE PHYSICAL COMPARTMENT (STEP-UP MFA CHALLENGE REQUIRED) ---
    fun moveCompartment(barId: String, targetCompartmentId: String, mfaCode: String): Boolean {
        if (mfaCode != "1918") { // Simulated private wealth MFA code for high-value operations
            return false
        }

        val bar = _bars.value.firstOrNull { it.id == barId }
            ?: throw IllegalArgumentException("Lingotto non trovato.")

        val previousComp = bar.compartmentId

        // Update the bar physical location state
        _bars.value = _bars.value.map { b ->
            if (b.id == barId) b.copy(compartmentId = targetCompartmentId) else b
        }

        val timestampNow = dateFormat.format(Date())

        // Register secure custody transfer event
        val moveEvent = PassportEvent(
            id = UUID.randomUUID().toString(),
            barId = bar.id,
            timestamp = timestampNow,
            actor = "Operatore di Sicurezza Caveau",
            location = "Caveau Milano Excellentia",
            eventType = "TRASFERIMENTO",
            previousState = "ALLOCATO_COMPARTIMENTO_$previousComp",
            newState = "TRASFERITO_COMPARTIMENTO_$targetCompartmentId",
            authorizationCode = "MFA-PRIV-SEC-1918",
            documentReference = "MOVE-CUST-${bar.serialNumber}",
            cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
        )

        _passportEvents.value = _passportEvents.value + moveEvent

        // Register custody document
        val moveDoc = AureoDocument(
            id = "DOC-${random.nextInt(10000, 99999)}",
            documentNumber = "CUST-TRSF-2026-${random.nextInt(1000, 9999)}",
            documentType = "CONSEGNA",
            date = SimpleDateFormat("dd/MM/yyyy", Locale.ITALIAN).format(Date()),
            clientId = CLIENT_BIANCHI_ID,
            clientName = "Famiglia Bianchi",
            referenceId = bar.id,
            description = "Verbale di Movimentazione Interna Metalli Pregiati",
            valueEur = bar.valuationEur,
            contentMeta = mapOf(
                "Identità Lingotto" to bar.serialNumber,
                "Spostamento da" to previousComp,
                "Destinazione" to targetCompartmentId,
                "Autorizzatore" to "MFA Privé Famiglia Bianchi (Codice 1918)",
                "Stato di Conservazione" to "Invariato - Ottimo",
                "Verificatore" to "Aureo Vault Security Command"
            )
        )
        _documents.value = _documents.value + moveDoc

        return true
    }

    // --- WORKFLOW: REQUEST DELIVERY (INSURED COURIER OR SECURE TRANSPORT) ---
    fun requestDelivery(barId: String, deliveryType: String, address: String): Boolean {
        val bar = _bars.value.firstOrNull { it.id == barId && it.currentOwnerId == CLIENT_BIANCHI_ID }
            ?: throw IllegalArgumentException("Lingotto non trovato.")

        if (bar.status != CustodyStatus.ALLOCATED) {
            throw IllegalStateException("Questo lingotto non è disponibile per la consegna fisica.")
        }

        val timestampNow = dateFormat.format(Date())

        // 1. Update bar custody status
        _bars.value = _bars.value.map { b ->
            if (b.id == barId) b.copy(status = CustodyStatus.IN_TRANSIT) else b
        }

        // 2. Reduce allocated gold/silver in the account balance
        val account = _accounts.value.first { it.clientId == CLIENT_BIANCHI_ID }
        val newAllocatedOz = if (bar.metal == MetalType.GOLD) account.goldAllocatedOz - bar.fineWeightOzOrKg else account.goldAllocatedOz
        val newAllocatedKg = if (bar.metal == MetalType.SILVER) account.silverAllocatedKg - bar.fineWeightOzOrKg else account.silverAllocatedKg

        _accounts.value = _accounts.value.map { acc ->
            if (acc.id == account.id) {
                acc.copy(
                    goldAllocatedOz = newAllocatedOz,
                    silverAllocatedKg = newAllocatedKg
                )
            } else acc
        }

        // 3. Register ledgers and passport logs
        if (bar.metal == MetalType.GOLD) {
            _goldLedger.value = _goldLedger.value + GoldLedgerEntry(
                id = "GL-${random.nextInt(10000, 99999)}",
                timestamp = timestampNow,
                clientId = CLIENT_BIANCHI_ID,
                orderId = null,
                deltaOz = -bar.fineWeightOzOrKg,
                type = "PRELIEVO",
                reference = "Richiesta Consegna Seriale ${bar.serialNumber}"
            )
        } else {
            _silverLedger.value = _silverLedger.value + SilverLedgerEntry(
                id = "SL-${random.nextInt(10000, 99999)}",
                timestamp = timestampNow,
                clientId = CLIENT_BIANCHI_ID,
                orderId = null,
                deltaKg = -bar.fineWeightOzOrKg,
                type = "PRELIEVO",
                reference = "Richiesta Consegna Seriale ${bar.serialNumber}"
            )
        }

        val delEvent = PassportEvent(
            id = UUID.randomUUID().toString(),
            barId = bar.id,
            timestamp = timestampNow,
            actor = "Servizio Portavalori Blindati",
            location = "Milano Excellentia Vault",
            eventType = "CONSEGNA",
            previousState = "ALLOCATO_COMPARTIMENTO_${bar.compartmentId}",
            newState = "PRELEVATO_PER_CONSEGNA_FISICA",
            authorizationCode = "DEL-AUTH-${random.nextInt(10000, 99999)}",
            documentReference = "CON-DOC-${bar.serialNumber}",
            cryptographicHash = "SHA256-${random.nextInt(10000000, 99999999)}"
        )
        _passportEvents.value = _passportEvents.value + delEvent

        // 4. Generate delivery document
        val delDoc = AureoDocument(
            id = "DOC-${random.nextInt(10000, 99999)}",
            documentNumber = "CONF-CON-2026-${random.nextInt(1000, 9999)}",
            documentType = "CONSEGNA",
            date = SimpleDateFormat("dd/MM/yyyy", Locale.ITALIAN).format(Date()),
            clientId = CLIENT_BIANCHI_ID,
            clientName = "Famiglia Bianchi",
            referenceId = bar.id,
            description = "Mandato di Consegna e Trasporto Valori Assicurato",
            valueEur = bar.valuationEur,
            contentMeta = mapOf(
                "Lingotto Scortato" to bar.serialNumber,
                "Peso Fine" to "${bar.fineWeightOzOrKg} ${if (bar.metal == MetalType.GOLD) "oz" else "kg"}",
                "Canale Consegna" to deliveryType, // "Insured Courier Ferrari S.p.A.", "Battistolli Blindati", etc.
                "Indirizzo Destinatario" to address,
                "Stato Spedizione" to "IN_TRANSITO_SCORTATO",
                "Assicurazione Polizza" to "Aureo Lloyd's Syndicate Full Cover"
            )
        )
        _documents.value = _documents.value + delDoc

        recalculateValuations()
        return true
    }

    // --- WORKFLOW: RUN DAILY PHYSICAL VS LEDGER RECONCILIATION ---
    fun runReconciliation(): Boolean {
        // Simple audit simulation:
        // We ensure that the sum of fine weights of all ALLOCATED bars in our repository
        // matches precisely the client's allocated gold & silver ledger accounts!
        val client = _accounts.value.first { it.clientId == CLIENT_BIANCHI_ID }
        
        val allocatedGoldBarsWeightOz = _bars.value
            .filter { it.currentOwnerId == CLIENT_BIANCHI_ID && it.metal == MetalType.GOLD && it.status == CustodyStatus.ALLOCATED }
            .sumOf { it.fineWeightOzOrKg }

        val allocatedSilverBarsWeightKg = _bars.value
            .filter { it.currentOwnerId == CLIENT_BIANCHI_ID && it.metal == MetalType.SILVER && it.status == CustodyStatus.ALLOCATED }
            .sumOf { it.fineWeightOzOrKg }

        // Precision round representation (to 3 decimal digits)
        val isGoldReconciled = Math.abs(allocatedGoldBarsWeightOz - client.goldAllocatedOz) < 0.001
        val isSilverReconciled = Math.abs(allocatedSilverBarsWeightKg - client.silverAllocatedKg) < 0.001

        if (isGoldReconciled && isSilverReconciled) {
            _reconciliationStatus.value = "RECONCILIED_TODAY"
            // Also update vault facility statuses
            _vaults.value = _vaults.value.map { v ->
                v.copy(inspectionStatus = "RECONCILIED_TODAY")
            }
            return true
        } else {
            _reconciliationStatus.value = "EXCEPTION_AUDIT"
            _vaults.value = _vaults.value.map { v ->
                if (v.id == "VAULT-MI-01") v.copy(inspectionStatus = "EXCEPTION_AUDIT") else v
            }
            return false
        }
    }

    // --- WORKFLOW: COMPRO ORO (USED GOLD INTAKE MODULE) ---
    fun evaluateUsedGold(itemDescription: String, grossWeight: Double, fineness: Double): UsedGoldItem {
        // Italian "Oro Usato" pricing. We calculate the fine weight.
        // Pure gold is 999.9. For 18k, fineness is 750 (75%).
        val purityDecimal = fineness / 1000.0
        val fineWeight = grossWeight * purityDecimal

        // Let's get the spot price per gram
        val goldSpotOz = marketData.getGoldSpotPriceEur()
        val goldSpotGram = goldSpotOz / 31.1035 // ~82.50 €/g

        val baseMetalValue = fineWeight * goldSpotGram
        val refiningAndBrokerFeePercent = 0.08 // 8% fee for assaying, melting, refining
        val discountFee = baseMetalValue * refiningAndBrokerFeePercent
        val finalOffer = baseMetalValue - discountFee

        return UsedGoldItem(
            id = "USEDAU-${random.nextInt(10000, 99999)}",
            description = itemDescription,
            grossWeightGram = grossWeight,
            fineWeightGram = fineWeight,
            fineness = fineness,
            spotPriceGram = goldSpotGram,
            calculatedValueEur = baseMetalValue,
            refiningFeePercent = refiningAndBrokerFeePercent * 100.0,
            finalOfferEur = finalOffer,
            customerCode = "REG-USATO-${random.nextInt(1000, 9999)}",
            status = "OFFER_MADE"
        )
    }

    fun executeComproOroTransaction(customerName: String, taxCode: String, docNumber: String, items: List<UsedGoldItem>): UsedGoldTransaction {
        val totalOffer = items.sumOf { it.finalOfferEur }
        val receiptNumber = "COMPRO-ORO-2026-${random.nextInt(10000, 99999)}"

        val transaction = UsedGoldTransaction(
            id = "TXU-${random.nextInt(100000, 999999)}",
            timestamp = dateFormat.format(Date()),
            customerName = customerName,
            customerCodiceFiscale = taxCode,
            customerDocNumber = docNumber,
            items = items.map { it.copy(status = "PURCHASED") },
            totalPaidEur = totalOffer,
            registrationReceiptNumber = receiptNumber
        )

        _usedGoldTransactions.value = _usedGoldTransactions.value + transaction

        // Save official Compro Oro intake document
        val intakeDoc = AureoDocument(
            id = "DOC-${random.nextInt(10000, 99999)}",
            documentNumber = receiptNumber,
            documentType = "CONSEGNA",
            date = SimpleDateFormat("dd/MM/yyyy", Locale.ITALIAN).format(Date()),
            clientId = CLIENT_BIANCHI_ID,
            clientName = customerName,
            referenceId = transaction.id,
            description = "Verbale Compro Oro - Registro Pubblica Sicurezza Questura",
            valueEur = totalOffer,
            contentMeta = mapOf(
                "Codice Fiscale" to taxCode,
                "Documento Identità" to docNumber,
                "Pezzi Ritirati" to "${items.size} oggetti d'oro",
                "Peso Totale Lordo" to "${items.sumOf { it.grossWeightGram }} g",
                "Peso Fine Stimato" to "${items.sumOf { it.fineWeightGram }} g",
                "Netto Corrisposto" to "€ ${currencyFormat.format(totalOffer)}",
                "Stato di Registro" to "TRASMESSO_QUESTURA_OAM"
            )
        )
        _documents.value = _documents.value + intakeDoc

        return transaction
    }
}
