package com.example.data.models

import java.util.UUID

// --- CORE METAL CLASSIFICATION ---
enum class MetalType { GOLD, SILVER }

enum class ProductType { BAR, COIN }

enum class CustodyStatus { ALLOCATED, UNALLOCATED, IN_TRANSIT, DELIVERED, WITHDRAWN }

// --- CLIENT & PRIVATE BANKING ENTITIES ---
data class Client(
    val id: String,
    val name: String,
    val segment: String, // "Private", "Family Office", "Corporate", "Bullion Dealer"
    val city: String,
    val taxCode: String, // Codice Fiscale
    val kyvStatus: String, // "VERIFIED", "PENDING", "EXPIRED"
    val riskScore: Int, // 1 to 100 (AML risk)
    val isProfessionalOperator: Boolean, // Registered in OAM framework
    val OAMRegistrationNumber: String? = null
)

data class ClientEntity(
    val id: String,
    val clientId: String,
    val name: String, // e.g. "Bianchi Holding S.r.l.", "Famiglia Bianchi Family Trust"
    val role: String // "Holding Company", "Trust Vehicle", "Personal Account"
)

// --- PRECIOUS METAL PORTFOLIO ACCOUNTS ---
data class MetalAccount(
    val id: String,
    val clientId: String,
    val goldAllocatedOz: Double,
    val goldUnallocatedOz: Double,
    val silverAllocatedKg: Double,
    val silverUnallocatedKg: Double,
    val cashBalanceEur: Double
)

// --- BULLION CATALOGUE PRODUCTS ---
data class BullionProduct(
    val id: String,
    val metal: MetalType,
    val type: ProductType,
    val manufacturer: String,
    val refiner: String,
    val brand: String,
    val grossWeightGram: Double,
    val fineWeightGram: Double,
    val fineWeightOzOrKg: Double, // Fine oz for Gold, Fine kg for Silver (as standard)
    val fineness: Double, // e.g. 999.9
    val dimensions: String, // e.g. "120 x 53 x 8 mm"
    val hasSerial: Boolean,
    val hasCertificate: Boolean,
    val defaultPremiumPercent: Double, // Markup on spot
    val isInvestmentGold: Boolean // Capital gains exemption / no VAT
)

// --- INDIVIDUAL BAR OBJECTS & PASSPORTS ---
data class BullionBar(
    val id: String,
    val productId: String,
    val metal: MetalType,
    val serialNumber: String,
    val manufacturer: String,
    val fineness: Double,
    val fineWeightOzOrKg: Double,
    val currentOwnerId: String,
    val status: CustodyStatus,
    val vaultId: String,
    val compartmentId: String,
    val certificateId: String,
    val valuationEur: Double
)

data class PassportEvent(
    val id: String,
    val barId: String,
    val timestamp: String,
    val actor: String,
    val location: String,
    val eventType: String, // "PRODUZIONE", "SAGGIATURA", "CERTIFICAZIONE", "ACQUISTO", "CUSTODIA", "ASSEGNAZIONE", "TRASFERIMENTO", "CONSEGNA"
    val previousState: String,
    val newState: String,
    val authorizationCode: String,
    val documentReference: String,
    val cryptographicHash: String // Audit trail representation
)

// --- SECURE VAULT NETWORK & DIGITAL TWIN ---
data class VaultFacility(
    val id: String,
    val name: String, // "Milano Vault 01", "Roma Vault 02", etc.
    val city: String,
    val address: String,
    val securityLevel: String, // "Class IX VdS", "Supreme Private Vault"
    val isInternational: Boolean, // Italy vs Switzerland (Zurigo, Ginevra) or London/Singapore
    val capacityKg: Double,
    val occupiedGoldKg: Double,
    val occupiedSilverKg: Double,
    val securityStatus: String, // "SECURE_ACTIVE", "MAINTENANCE"
    val inspectionStatus: String, // "RECONCILIED_TODAY", "AUDITING"
    val capacityPercent: Double = ((occupiedGoldKg + occupiedSilverKg) / capacityKg) * 100.0
)

data class VaultCompartment(
    val id: String,
    val vaultId: String,
    val zoneName: String, // "Caveau A - Zona Alta Sicurezza"
    val compartmentName: String, // "Cassaforte S-24"
    val description: String
)

// --- RFQ & PRICING ENGINE ---
data class RfqRequest(
    val id: String,
    val clientId: String,
    val productId: String,
    val quantity: Int,
    val timestamp: String
)

data class QuoteResponse(
    val id: String,
    val rfqId: String,
    val productId: String,
    val quantity: Int,
    val spotPricePerUnit: Double,
    val physicalPremiumEur: Double,
    val taxVatEur: Double,
    val totalCostEur: Double,
    val validUntilTimestamp: String,
    val spreadPercent: Double,
    val storageFeeAnnualPercent: Double
)

data class MetalOrder(
    val id: String,
    val clientId: String,
    val productId: String,
    val quantity: Int,
    val quoteId: String,
    val totalCostEur: Double,
    val metalType: MetalType,
    val timestamp: String,
    val status: String, // "PENDING_PAYMENT", "PAID", "ALLOCATING", "ALLOCATED", "SETTLED"
    val paymentMethod: String // "Bank Transfer SEPA", "Private Wealth Cash Ledger"
)

// --- LEDGERS ---
data class GoldLedgerEntry(
    val id: String,
    val timestamp: String,
    val clientId: String,
    val orderId: String?,
    val deltaOz: Double,
    val type: String, // "ACQUISTO", "VENDITA", "PRELIEVO", "TRASFERIMENTO"
    val reference: String
)

data class SilverLedgerEntry(
    val id: String,
    val timestamp: String,
    val clientId: String,
    val orderId: String?,
    val deltaKg: Double,
    val type: String,
    val reference: String
)

data class CashLedgerEntry(
    val id: String,
    val timestamp: String,
    val clientId: String,
    val deltaEur: Double,
    val type: String, // "DEPOSIT", "WITHDRAWAL", "PURCHASE", "SALE", "CUSTODY_FEES"
    val reference: String
)

// --- ITALIAN TAX RULES & AUDIT ---
data class ItalianTaxRule(
    val ruleId: String,
    val metalType: MetalType,
    val productType: ProductType,
    val isInvestmentGold: Boolean,
    val vatRatePercent: Double, // 22% for Silver, 0% for Investment Gold in Italy
    val capitalGainsTaxPercent: Double, // 26% on positive gains (Imposta Sostitutiva)
    val defaultCostBasisIfMissingPercent: Double, // 25% of sale price is taxed if cost-basis cannot be documented (Italian Rule!)
    val treatmentDescription: String,
    val documentationRequired: String
)

// --- DOCUMENT CREATION & ARCHIVE ---
data class AureoDocument(
    val id: String,
    val documentNumber: String, // e.g. "CONF-ACQ-2026-00918"
    val documentType: String, // "CONFERMA_ACQUISTO", "CONFERMA_VENDITA", "CERTIFICATO_ALLOCAZIONE", "CERTIFICATO_CUSTODIA", "ESTRATTO_CONTO", "REPORT_ANNUALE", "REPORT_FISCALE", "CONSEGNA"
    val date: String,
    val clientId: String,
    val clientName: String,
    val referenceId: String, // transaction id or bar id
    val description: String,
    val valueEur: Double,
    val contentMeta: Map<String, String> // Metadata key-values (Quantità, Titolo, etc.)
)

// --- COMPLIANCE RECORDS ---
data class ComplianceCase(
    val id: String,
    val clientId: String,
    val timestamp: String,
    val type: String, // "AML_MONITORING", "KYC_VERIFICATION", "SANCTIONS_SCREENING", "SOURCE_OF_FUNDS"
    val description: String,
    val score: Int, // Risk score
    val status: String, // "APPROVED", "PENDING_REVIEW", "FLAGGED"
    val verificationReference: String
)

// --- USED JEWELLERY (COMPRO ORO MODULE) ---
data class UsedGoldItem(
    val id: String,
    val description: String, // e.g. "Bracciale oro 18k", "Collana vintage"
    val grossWeightGram: Double,
    val fineWeightGram: Double,
    val fineness: Double, // e.g. 750 (18k)
    val spotPriceGram: Double,
    val calculatedValueEur: Double,
    val refiningFeePercent: Double,
    val finalOfferEur: Double,
    val customerCode: String,
    val status: String // "INTAKE", "ASSAYED", "OFFER_MADE", "PURCHASED", "SENT_TO_REFINERY"
)

data class UsedGoldTransaction(
    val id: String,
    val timestamp: String,
    val customerName: String,
    val customerCodiceFiscale: String,
    val customerDocNumber: String, // Carta d'identità
    val items: List<UsedGoldItem>,
    val totalPaidEur: Double,
    val registrationReceiptNumber: String // Official register reference (Registro Compro Oro)
)
