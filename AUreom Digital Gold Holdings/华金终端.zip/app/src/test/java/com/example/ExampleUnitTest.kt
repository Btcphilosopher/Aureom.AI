package com.example

import com.example.huagold.domain.model.OptionType
import com.example.huagold.engine.BlackScholesEngine
import com.example.huagold.engine.MarginEngine
import com.example.huagold.engine.UnitConversionEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testTroyOunceConversion() {
    assertEquals(31.1034768, UnitConversionEngine.TROY_OUNCE_TO_GRAMS, 0.0000001)
  }

  @Test
  fun testTheoreticalCnyGoldCalculation() {
    val usdPerOz = 4000.0
    val usdCny = 7.0
    // 4000 * 7 / 31.1034768 = 28000 / 31.1034768 = 900.22089...
    val theoretical = UnitConversionEngine.calculateTheoreticalCnyGoldPerGram(usdPerOz, usdCny)
    assertEquals(900.22, theoretical, 0.05)
  }

  @Test
  fun testBlackScholesPricing() {
    val spot = 900.0
    val strike = 900.0
    val t = 30.0 / 365.0
    val r = 0.02
    val vol = 0.16
    val call = BlackScholesEngine.calculateOptionPrice(OptionType.CALL, spot, strike, t, r, vol)
    val put = BlackScholesEngine.calculateOptionPrice(OptionType.PUT, spot, strike, t, r, vol)
    assertTrue(call > 0.0)
    assertTrue(put > 0.0)
    val greeks = BlackScholesEngine.calculateGreeks(OptionType.CALL, spot, strike, t, r, vol)
    assertTrue(greeks.delta in 0.45..0.60)
  }

  @Test
  fun testMarginEngine() {
    val margins = MarginEngine.getMarginRequirements(928.45, 15821.0, isHighVolEnvironment = false)
    val auTd = margins.first { it.contractSymbol == "Au(T+D)" }
    assertEquals(0.11, auTd.marginRatio, 0.001)
    assertTrue(auTd.marginPerLot > 100000.0)
  }
}
