package com.example.huagold.domain.model

data class OrderBookLevel(
  val level: Int, // 1 to 5
  val price: Double,
  val volume: Long,
  val orderCount: Int,
  val cumulativeVolume: Long
)

data class OrderBook(
  val symbol: String,
  val timestamp: String,
  val bids: List<OrderBookLevel>,
  val asks: List<OrderBookLevel>,
  val lastPrice: Double,
  val dataStatus: DataStatus = DataStatus.SYNTHETIC
) {
  val totalBidVolume: Long get() = bids.sumOf { it.volume }
  val totalAskVolume: Long get() = asks.sumOf { it.volume }
  
  // Imbalance: (Bid - Ask) / (Bid + Ask)
  val imbalanceRatio: Double get() {
    val total = totalBidVolume + totalAskVolume
    return if (total > 0) (totalBidVolume.toDouble() - totalAskVolume.toDouble()) / total.toDouble() else 0.0
  }
}

data class HeatmapCell(
  val timeBucket: String,
  val priceLevel: Double,
  val depthRatio: Float // 0.0 to 1.0 intensity
)
