package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = TerminalBg,
  primaryContainer = GoldMuted,
  onPrimaryContainer = GoldAccent,
  secondary = SilverPrimary,
  onSecondary = TerminalBg,
  secondaryContainer = TerminalSurfaceVariant,
  onSecondaryContainer = SilverLight,
  tertiary = CyanAccent,
  onTertiary = TerminalBg,
  background = TerminalBg,
  onBackground = TextWhite,
  surface = TerminalSurface,
  onSurface = TextWhite,
  surfaceVariant = TerminalSurfaceVariant,
  onSurfaceVariant = TextGray,
  outline = TerminalBorder,
  outlineVariant = TerminalBorderSubtle
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Financial terminal uses fixed high-contrast terminal scheme
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = TerminalColorScheme,
    typography = Typography,
    content = content
  )
}
