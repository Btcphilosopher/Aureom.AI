package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.OptionType
import com.example.huagold.engine.BlackScholesEngine
import com.example.huagold.ui.components.VolSurfaceCanvas
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun OptionsLabScreen(
  repository: MarketRepository
) {
  val optionChain by repository.optionChain.collectAsState()
  val volSurface by repository.volSurface.collectAsState()

  // Interactive BS Calculator State
  var calcSpot by remember { mutableStateOf("928.45") }
  var calcStrike by remember { mutableStateOf("930.0") }
  var calcDays by remember { mutableStateOf("30") }
  var calcVol by remember { mutableStateOf("16.5") }
  var calcRate by remember { mutableStateOf("2.0") }

  val s = calcSpot.toDoubleOrNull() ?: 928.45
  val k = calcStrike.toDoubleOrNull() ?: 930.0
  val t = (calcDays.toDoubleOrNull() ?: 30.0) / 365.0
  val vol = (calcVol.toDoubleOrNull() ?: 16.5) / 100.0
  val r = (calcRate.toDoubleOrNull() ?: 2.0) / 100.0

  val callPrice = BlackScholesEngine.calculateOptionPrice(OptionType.CALL, s, k, t, r, vol)
  val putPrice = BlackScholesEngine.calculateOptionPrice(OptionType.PUT, s, k, t, r, vol)
  val callGreeks = BlackScholesEngine.calculateGreeks(OptionType.CALL, s, k, t, r, vol)
  val putGreeks = BlackScholesEngine.calculateGreeks(OptionType.PUT, s, k, t, r, vol)

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("options_lab_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.BlurOn, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "黄金期权实验室 (GOLD OPTIONS LAB)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .background(Color(0x33A855F7), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text("BLACK-SCHOLES GREEKS", color = PurpleAccent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    // 2. Interactive Black-Scholes Greeks Calculator
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            "BLACK-SCHOLES PRICING ENGINE / 解析定价引擎",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Parameters input row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            OutlinedTextField(
              value = calcSpot,
              onValueChange = { calcSpot = it },
              label = { Text("标的价S", fontSize = 8.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = calcStrike,
              onValueChange = { calcStrike = it },
              label = { Text("行权价K", fontSize = 8.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = calcDays,
              onValueChange = { calcDays = it },
              label = { Text("期限(天)", fontSize = 8.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = calcVol,
              onValueChange = { calcVol = it },
              label = { Text("IV(%)", fontSize = 8.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Results Call vs Put
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Call
            Column(
              modifier = Modifier
                .weight(1f)
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(6.dp)
            ) {
              Text("认购期权 (CALL)", color = QuoteUpRed, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("理论价: ¥${String.format(Locale.US, "%.2f", callPrice)}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
              Text("Delta: ${callGreeks.delta} | Gamma: ${callGreeks.gamma}", color = TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              Text("Theta: ${callGreeks.theta} | Vega: ${callGreeks.vega}", color = TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }

            // Put
            Column(
              modifier = Modifier
                .weight(1f)
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(6.dp)
            ) {
              Text("认沽期权 (PUT)", color = QuoteDownGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("理论价: ¥${String.format(Locale.US, "%.2f", putPrice)}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
              Text("Delta: ${putGreeks.delta} | Gamma: ${putGreeks.gamma}", color = TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              Text("Theta: ${putGreeks.theta} | Vega: ${putGreeks.vega}", color = TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
          }
        }
      }
    }

    // 3. Volatility Surface Matrix & Heatmap
    item {
      VolSurfaceCanvas(volData = volSurface)
    }

    // 4. Option Chain Table
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "OPTION CHAIN / 上金所标准黄金期权链",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "Au2611 序列 (30天到期)",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant)
            .padding(horizontal = 4.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Call权利金", color = QuoteUpRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
          Text("Call Delta", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
          Text("行权价K", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
          Text("Put Delta", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
          Text("Put权利金", color = QuoteDownGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
        }

        val strikes = listOf(900.0, 910.0, 920.0, 930.0, 940.0, 950.0, 960.0)
        strikes.forEach { strike ->
          val call = optionChain.firstOrNull { it.strike == strike && it.optionType == OptionType.CALL }
          val put = optionChain.firstOrNull { it.strike == strike && it.optionType == OptionType.PUT }

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "¥${call?.premium ?: "-"}",
              color = QuoteUpRed,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(65.dp)
            )
            Text(
              "${call?.greeks?.delta ?: "-"}",
              color = TextGray,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(55.dp)
            )
            Text(
              "${strike.toInt()}",
              color = if (strike == 930.0) GoldAccent else TextWhite,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(55.dp)
            )
            Text(
              "${put?.greeks?.delta ?: "-"}",
              color = TextGray,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(55.dp)
            )
            Text(
              "¥${put?.premium ?: "-"}",
              color = QuoteDownGreen,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(65.dp)
            )
          }

          Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
        }
      }
    }
  }
}
