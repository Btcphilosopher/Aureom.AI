package com.example.huagold.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.TermStructureCurve
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun CurveChartCanvas(
  curve: TermStructureCurve?,
  modifier: Modifier = Modifier
) {
  if (curve == null || curve.points.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(180.dp)
        .background(TerminalSurface),
      contentAlignment = Alignment.Center
    ) {
      Text("暂无期限结构数据", color = TextMuted, fontSize = 12.sp)
    }
    return
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          "${if (curve.asset == "GOLD") "黄金" else "白银"}期限结构曲线 (TERM STRUCTURE)",
          color = GoldAccent,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Box(
          modifier = Modifier
            .background(Color(0x2210B981), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text(
            curve.curveType,
            color = StatusLive,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Text(
        "近远月基差: +${String.format(Locale.US, "%.2f", curve.frontMonthSpread)}",
        color = CyanAccent,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(130.dp)
    ) {
      val w = size.width
      val h = size.height
      val n = curve.points.size

      val minP = curve.points.minOf { it.price } * 0.998
      val maxP = curve.points.maxOf { it.price } * 1.002
      val pRange = maxP - minP

      val path = Path()
      val fillPath = Path()
      fillPath.moveTo(0f, h)

      val stepX = w / (n - 1)

      curve.points.forEachIndexed { i, pt ->
        val x = i * stepX
        val y = h - ((pt.price - minP) / pRange).toFloat() * (h * 0.8f) - (h * 0.1f)

        if (i == 0) {
          path.moveTo(x, y)
          fillPath.lineTo(x, y)
        } else {
          path.lineTo(x, y)
          fillPath.lineTo(x, y)
        }
      }

      fillPath.lineTo(w, h)
      fillPath.close()

      // Gradient-like Area Fill
      drawPath(
        fillPath,
        color = if (curve.asset == "GOLD") GoldPrimary.copy(alpha = 0.15f) else SilverPrimary.copy(alpha = 0.15f),
        style = Fill
      )

      // Curve Stroke Line
      drawPath(
        path,
        color = if (curve.asset == "GOLD") GoldPrimary else CyanAccent,
        style = Stroke(width = 2.5f)
      )

      // Curve Data Points
      curve.points.forEachIndexed { i, pt ->
        val x = i * stepX
        val y = h - ((pt.price - minP) / pRange).toFloat() * (h * 0.8f) - (h * 0.1f)

        drawCircle(
          color = TerminalBg,
          radius = 5f,
          center = Offset(x, y)
        )
        drawCircle(
          color = GoldAccent,
          radius = 3.5f,
          center = Offset(x, y)
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Tenor labels
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      curve.points.forEach { pt ->
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            pt.tenor,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            String.format(Locale.US, "%.2f", pt.price),
            color = TextGray,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "${pt.annualizedRate}%/y",
            color = GoldAccent,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
