package com.example.huagold.engine

import com.example.huagold.domain.model.MonteCarloResult
import java.util.Random
import kotlin.math.*

object MonteCarloEngine {

  /**
   * Runs Monte Carlo simulation using Geometric Brownian Motion (GBM)
   * S_t = S_0 * exp((mu - 0.5 * sigma^2)*dt + sigma * sqrt(dt) * Z)
   *
   * @param spotPrice Current asset price (e.g. 928.45 CNY/g)
   * @param annualVolatility Annual volatility (e.g. 0.16)
   * @param annualDrift Expected annual drift rate (e.g. 0.05)
   * @param days Horizon in trading days (e.g. 30 days)
   * @param numPaths Number of simulated paths (e.g. 10,000)
   */
  fun runSimulation(
    spotPrice: Double,
    annualVolatility: Double = 0.165,
    annualDrift: Double = 0.04,
    days: Int = 30,
    numPaths: Int = 10000,
    seed: Long = 42L
  ): MonteCarloResult {
    val random = Random(seed)
    val dt = 1.0 / 250.0 // trading days per year
    val finalPrices = DoubleArray(numPaths)
    
    // Store 5 representative sample trajectories (30 steps each)
    val sampleTrajectories = mutableListOf<List<Double>>()
    val samplesToRecord = 5

    val driftTerm = (annualDrift - 0.5 * annualVolatility * annualVolatility) * dt
    val volSqrtDt = annualVolatility * sqrt(dt)

    for (p in 0 until numPaths) {
      var currentS = spotPrice
      val recordThisPath = p < samplesToRecord
      val trajectory = if (recordThisPath) mutableListOf(spotPrice) else null

      for (day in 1..days) {
        val z = random.nextGaussian()
        currentS *= exp(driftTerm + volSqrtDt * z)
        if (recordThisPath) {
          trajectory?.add(currentS)
        }
      }

      finalPrices[p] = currentS
      if (recordThisPath && trajectory != null) {
        sampleTrajectories.add(trajectory)
      }
    }

    finalPrices.sort()

    val p1Idx = max(0, (numPaths * 0.01).toInt())
    val p5Idx = max(0, (numPaths * 0.05).toInt())
    val p50Idx = (numPaths * 0.50).toInt()
    val p95Idx = min(numPaths - 1, (numPaths * 0.95).toInt())
    val p99Idx = min(numPaths - 1, (numPaths * 0.99).toInt())

    val minPrice = finalPrices.first()
    val maxPrice = finalPrices.last()
    val numBuckets = 20
    val bucketWidth = (maxPrice - minPrice) / numBuckets
    val bucketCounts = IntArray(numBuckets)

    for (price in finalPrices) {
      var b = ((price - minPrice) / bucketWidth).toInt()
      if (b >= numBuckets) b = numBuckets - 1
      if (b < 0) b = 0
      bucketCounts[b]++
    }

    val distribution = mutableListOf<Pair<Double, Int>>()
    for (i in 0 until numBuckets) {
      val bucketCenter = minPrice + (i + 0.5) * bucketWidth
      distribution.add(Pair((bucketCenter * 10).roundToInt() / 10.0, bucketCounts[i]))
    }

    return MonteCarloResult(
      numPaths = numPaths,
      timeHorizonDays = days,
      medianPrice = (finalPrices[p50Idx] * 100).roundToInt() / 100.0,
      percentile5th = (finalPrices[p5Idx] * 100).roundToInt() / 100.0,
      percentile1st = (finalPrices[p1Idx] * 100).roundToInt() / 100.0,
      percentile95th = (finalPrices[p95Idx] * 100).roundToInt() / 100.0,
      percentile99th = (finalPrices[p99Idx] * 100).roundToInt() / 100.0,
      pathDistributionBuckets = distribution,
      simulatedPathsSample = sampleTrajectories
    )
  }
}
