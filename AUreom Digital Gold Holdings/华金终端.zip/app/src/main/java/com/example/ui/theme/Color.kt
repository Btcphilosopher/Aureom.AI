package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Dark Financial Terminal Palette
val TerminalBg = Color(0xFF090D16)
val TerminalSurface = Color(0xFF111726)
val TerminalSurfaceVariant = Color(0xFF192237)
val TerminalBorder = Color(0xFF222F49)
val TerminalBorderSubtle = Color(0xFF182338)

// Accents
val GoldPrimary = Color(0xFFF59E0B)
val GoldAccent = Color(0xFFFBBF24)
val GoldDark = Color(0xFFB45309)
val GoldMuted = Color(0xFF3B2F16)

val SilverPrimary = Color(0xFF94A3B8)
val SilverLight = Color(0xFFCBD5E1)
val SilverDark = Color(0xFF475569)

val CyanAccent = Color(0xFF38BDF8)
val IndigoAccent = Color(0xFF818CF8)
val PurpleAccent = Color(0xFFA855F7)

// Chinese Market Quote Colors: Red for Up, Green for Down
val QuoteUpRed = Color(0xFFEF4444)
val QuoteUpRedBg = Color(0x20EF4444)
val QuoteDownGreen = Color(0xFF10B981)
val QuoteDownGreenBg = Color(0x2010B981)
val QuoteNeutral = Color(0xFF94A3B8)

// Text
val TextWhite = Color(0xFFF8FAFC)
val TextGray = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextDark = Color(0xFF334155)

// Status
val StatusLive = Color(0xFF10B981)
val StatusSynthetic = Color(0xFF38BDF8)
val StatusWarning = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)
