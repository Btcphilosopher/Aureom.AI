package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.engine.MarginEngine
import com.example.huagold.ui.components.MonteCarloCanvas
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun RiskControlScreen(
  repository: MarketRepository
) {
  val riskSnapshot by repository.riskSnapshot.collectAsState()
  val stressResults by repository.stressResults.collectAsState()
  val monteCarloResult by repository.monteCarloResult.collectAsState()
  val marginRequirements by repository.marginRequirements.collectAsState()

  var isHighVolRegime by remember { mutableStateOf(false) }
  var mcHorizonDays by remember { mutableStateOf(30) }
  var mcPaths by remember { mutableStateOf(10000) }

  val dynamicMarginList = remember(isHighVolRegime) {
    MarginEngine.getMarginRequirements(928.45, 15821.0, isHighVolRegime)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("risk_control_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Shield, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "风控驾驶舱与压力测试 (RISK CONTROL & STRESS)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .background(Color(0x2210B981), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text("RISK STATUS: NORMAL", color = StatusLive, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 2. Risk Snapshot Matrix Cockpit
    item {
      riskSnapshot?.let { r ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              "PORTFOLIO RISK METRICS / 投资组合风险指标",
              color = GoldAccent,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Primary Metrics Grid
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              RiskMetricTile("1D 99% VaR", "¥${String.format(Locale.US, "%,.0f", r.var1D99Percent)}", QuoteUpRed, Modifier.weight(1f))
              RiskMetricTile("Expected Shortfall (ES)", "¥${String.format(Locale.US, "%,.0f", r.expectedShortfall99Percent)}", QuoteUpRed, Modifier.weight(1f))
              RiskMetricTile("极值压力损失", "¥${String.format(Locale.US, "%,.0f", r.stressLossEstimated)}", StatusWarning, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              RiskMetricTile("黄金净Delta", "${r.goldDeltaGrams.toInt()} 克", GoldAccent, Modifier.weight(1f))
              RiskMetricTile("白银净Delta", "${(r.silverDeltaGrams / 1000).toInt()} kg", CyanAccent, Modifier.weight(1f))
              RiskMetricTile("汇率敞口(USD/CNY)", "¥${(r.fxExposureCNY / 10000).toInt()}万", TextWhite, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Liquidity & Margin
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(6.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("流动性评级: ${r.liquidityStatus}", color = StatusLive, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("保证金占用率: ${String.format(Locale.US, "%.1f", r.marginUtilizationPercent)}%", color = StatusWarning, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("风控状态: ${r.riskLevel}", color = StatusLive, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
          }
        }
      }
    }

    // 3. Stress Testing Scenarios
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "STRESS TESTING / 宏观极端情景压力测试",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "多因子冲击模拟",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        stressResults.forEach { res ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(3.dp))
              .background(TerminalSurfaceVariant)
              .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
              .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(res.scenarioName, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp)
              Text(
                "黄金损益: ${if (res.goldPnL >= 0) "+" else ""}${String.format(Locale.US, "%,.0f", res.goldPnL)} | 白银损益: ${if (res.silverPnL >= 0) "+" else ""}${String.format(Locale.US, "%,.0f", res.silverPnL)}",
                color = TextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                "${if (res.estimatedPnLLoss >= 0) "+" else ""}${String.format(Locale.US, "%,.0f", res.estimatedPnLLoss)} 元",
                color = if (res.estimatedPnLLoss >= 0) QuoteUpRed else QuoteDownGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                "${String.format(Locale.US, "%.1f", res.lossPercentOfEquity)}% 净值",
                color = TextGray,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
          Spacer(modifier = Modifier.height(3.dp))
        }
      }
    }

    // 4. Monte Carlo Simulation Engine
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "MONTE CARLO ENGINE / 蒙特卡洛多路径",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(10000, 50000).forEach { p ->
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(3.dp))
                  .background(if (mcPaths == p) GoldPrimary else TerminalSurfaceVariant)
                  .clickable {
                    mcPaths = p
                    repository.runCustomMonteCarlo(mcHorizonDays, p, 0.165)
                  }
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text("${p / 1000}k 路径", color = if (mcPaths == p) Color.Black else TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        MonteCarloCanvas(result = monteCarloResult)
      }
    }

    // 5. Versioned SGE Dynamic Margin & Leverage Simulator
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                "SGE DYNAMIC MARGINS / 上金所版本化保证金规则",
                color = GoldAccent,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }

            // High Volatility Toggle
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("高波动机制:", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              Switch(
                checked = isHighVolRegime,
                onCheckedChange = { isHighVolRegime = it },
                colors = SwitchDefaults.colors(checkedThumbColor = GoldPrimary, checkedTrackColor = GoldDark),
                modifier = Modifier.scale(0.7f)
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          dynamicMarginList.forEach { m ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(m.contractSymbol, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(m.contractName, color = TextMuted, fontSize = 8.sp)
              }
              Text("保证金比例: ${(m.marginRatio * 100).toInt()}%", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("单手保证金: ¥${String.format(Locale.US, "%,.0f", m.marginPerLot)}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("涨跌停: ±${m.dailyLimitPercent}%", color = StatusWarning, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            "规则版本: SGE-2026-V3.2 (交易所规则参数化管理，支持波动率自适应上调)",
            color = TextMuted,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}

@Composable
private fun RiskMetricTile(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier
      .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
      .padding(6.dp)
  ) {
    Text(label, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
  }
}

private fun Modifier.scale(scale: Float): Modifier = this
