package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.ChinaPremiumData
import com.example.huagold.domain.model.Quote
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketOverviewScreen(
  repository: MarketRepository,
  onNavigateToTrading: (String) -> Unit,
  onNavigateToCurves: () -> Unit,
  onNavigateToRisk: () -> Unit
) {
  val quotes by repository.quotes.collectAsState()
  val goldPremium by repository.chinaGoldPremium.collectAsState()
  val silverPremium by repository.chinaSilverPremium.collectAsState()
  val goldSilverRatio by repository.goldSilverRatio.collectAsState()
  val newsList by repository.newsList.collectAsState()

  var selectedCategory by remember { mutableStateOf("黄金") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("market_overview_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header Banner & Quick Category Filter
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Dashboard, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "中国贵金属市场总览 (MARKET OVERVIEW)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Text(
          "上金所 · 上期所 · 银行间",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Category filter pills
      LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        val categories = listOf("黄金", "白银", "铂族", "外汇", "基准定价", "全部品种")
        items(categories) { cat ->
          val isSelected = selectedCategory == cat
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (isSelected) GoldMuted else TerminalSurfaceVariant)
              .border(1.dp, if (isSelected) GoldPrimary else TerminalBorderSubtle, RoundedCornerShape(4.dp))
              .clickable { selectedCategory = cat }
              .padding(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text(
              cat,
              color = if (isSelected) GoldAccent else TextGray,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // 2. Core Primary Quote Cards (Horizontal Cards: Au99.99, Ag99.99, USD/CNY, XAU/USD, XAG/USD)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        val auQuote = quotes["Au99.99"]
        val agQuote = quotes["Ag99.99"]
        val usdQuote = quotes["USD/CNY"]

        PrimaryQuoteTile(
          symbol = "Au99.99",
          name = "上海金现货",
          quote = auQuote,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTrading("Au99.99") }
        )

        PrimaryQuoteTile(
          symbol = "Ag99.99",
          name = "上海银现货",
          quote = agQuote,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTrading("Ag99.99") }
        )

        PrimaryQuoteTile(
          symbol = "USD/CNY",
          name = "美元在岸人民币",
          quote = usdQuote,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTrading("USD/CNY") }
        )
      }
    }

    // 3. Cross-Market Basis & China Premium Cockpit
    item {
      ChinaPremiumCockpit(
        goldPremium = goldPremium,
        silverPremium = silverPremium,
        ratio = goldSilverRatio?.currentRatio ?: 58.74,
        onViewCurves = onNavigateToCurves
      )
    }

    // 4. SGE & SHFE Contract Monitor Table (Au99.99, Au(T+D), Au99.95, Au100g, Ag99.99, Ag(T+D), SHGOLD_AM, SHGOLD_PM, etc.)
    item {
      ContractMonitorSection(
        quotes = quotes,
        onSelectContract = { symbol ->
          repository.selectSymbol(symbol)
          onNavigateToTrading(symbol)
        }
      )
    }

    // 5. Macro Pulse & Recent Precious Metals Wire Strip
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          "实时市场快讯 (MARKET WIRE)",
          color = GoldAccent,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "全市场实时推送",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        newsList.take(3).forEach { news ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(3.dp))
              .background(TerminalSurface)
              .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
              .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              news.time,
              color = GoldPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                news.title,
                color = TextWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
              )
              Text(
                news.summary,
                color = TextGray,
                fontSize = 9.sp,
                maxLines = 2
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PrimaryQuoteTile(
  symbol: String,
  name: String,
  quote: Quote?,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  val last = quote?.last ?: 0.0
  val changePct = quote?.changePercent ?: 0.0
  val isUp = changePct >= 0
  val quoteColor = if (isUp) QuoteUpRed else QuoteDownGreen
  val quoteBg = if (isUp) QuoteUpRedBg else QuoteDownGreenBg

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(4.dp))
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .clickable { onClick() }
      .padding(8.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(symbol, color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Box(
          modifier = Modifier
            .background(quoteBg, RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text(
            "${if (isUp) "+" else ""}${String.format(Locale.US, "%.2f", changePct)}%",
            color = quoteColor,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      Text(name, color = TextMuted, fontSize = 9.sp)

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        if (symbol.contains("USD/CNY")) String.format(Locale.US, "%.4f", last)
        else if (symbol.contains("Ag")) String.format(Locale.US, "%.0f", last)
        else String.format(Locale.US, "%.2f", last),
        color = quoteColor,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        fontFamily = FontFamily.Monospace
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("买: ${quote?.bid ?: "-"}", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("卖: ${quote?.ask ?: "-"}", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
      }
    }
  }
}

@Composable
private fun ChinaPremiumCockpit(
  goldPremium: ChinaPremiumData?,
  silverPremium: ChinaPremiumData?,
  ratio: Double,
  onViewCurves: () -> Unit
) {
  Surface(
    color = TerminalSurface,
    shape = RoundedCornerShape(4.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.CompareArrows, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
          Text(
            "中国市场跨市场基差 & 溢价定价模型",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
            .clickable { onViewCurves() }
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text("详细曲线 >", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // 3 KPI columns: China Gold Premium, China Silver Premium, Gold/Silver Ratio
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Gold Premium
        Column(
          modifier = Modifier
            .weight(1f)
            .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
            .padding(6.dp)
        ) {
          Text("国内黄金溢价 (XAU)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          Text(
            "${if ((goldPremium?.premiumAmount ?: 0.0) >= 0) "+" else ""}${goldPremium?.premiumAmount ?: 0.0} 元/克",
            color = QuoteUpRed,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "理论价: ¥${goldPremium?.theoreticalCnyPrice ?: "-"} | Z: ${goldPremium?.zScore ?: "-"}",
            color = TextGray,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        // Silver Premium
        Column(
          modifier = Modifier
            .weight(1f)
            .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
            .padding(6.dp)
        ) {
          Text("国内白银溢价 (XAG)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          Text(
            "${if ((silverPremium?.premiumAmount ?: 0.0) >= 0) "+" else ""}${silverPremium?.premiumAmount ?: 0.0} 元/kg",
            color = CyanAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "理论价: ¥${silverPremium?.theoreticalCnyPrice ?: "-"} | 分位: ${silverPremium?.percentile ?: "-"}%",
            color = TextGray,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        // Gold Silver Ratio
        Column(
          modifier = Modifier
            .weight(1f)
            .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
            .padding(6.dp)
        ) {
          Text("金银比价 (XAU/XAG)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          Text(
            String.format(Locale.US, "%.2f", ratio),
            color = GoldPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "历史中枢: 64.20 | 偏离: -8.5%",
            color = TextGray,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}

@Composable
private fun ContractMonitorSection(
  quotes: Map<String, Quote>,
  onSelectContract: (String) -> Unit
) {
  val contractList = listOf(
    "Au99.99", "Au(T+D)", "Au99.95", "Au100g", "Ag99.99", "Ag(T+D)", "SHGOLD_AM", "SHGOLD_PM", "XAU/USD", "XAG/USD"
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "CONTRACT MONITOR / 合约监视器",
        color = GoldAccent,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )
      Text(
        "点击行打开专属行情与盘口",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Table Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalSurfaceVariant)
        .padding(horizontal = 4.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("合约品种", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
      Text("最新价", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
      Text("涨跌幅", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
      Text("买一 / 卖一", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp))
      Text("成交量(手)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
    }

    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
      contractList.forEach { symbol ->
        val q = quotes[symbol]
        if (q != null) {
          val isUp = q.changePercent >= 0
          val qColor = if (isUp) QuoteUpRed else QuoteDownGreen

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onSelectContract(symbol) }
              .padding(horizontal = 4.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.width(65.dp)) {
              Text(q.symbol, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text(q.market.take(6), color = TextMuted, fontSize = 8.sp)
            }

            Text(
              if (q.symbol.contains("Ag") && !q.symbol.contains("USD")) String.format(Locale.US, "%.0f", q.last)
              else String.format(Locale.US, "%.2f", q.last),
              color = qColor,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(65.dp)
            )

            Text(
              "${if (isUp) "+" else ""}${String.format(Locale.US, "%.2f", q.changePercent)}%",
              color = qColor,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(55.dp)
            )

            Text(
              "${if (q.bid > 0) String.format(Locale.US, "%.1f", q.bid) else "-"}/${if (q.ask > 0) String.format(Locale.US, "%.1f", q.ask) else "-"}",
              color = TextGray,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(75.dp)
            )

            Text(
              "${q.volume}",
              color = TextWhite,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.width(60.dp)
            )
          }

          Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
        }
      }
    }
  }
}
