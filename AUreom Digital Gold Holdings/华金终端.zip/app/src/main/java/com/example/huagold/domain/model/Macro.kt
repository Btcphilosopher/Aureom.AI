package com.example.huagold.domain.model

data class MacroIndicator(
  val name: String,
  val symbol: String,
  val latestValue: Double,
  val unit: String,
  val change1M: Double,
  val goldCorrelation: Double,
  val category: String // "RATE", "CURRENCY", "INFLATION", "INDUSTRY"
)

data class CentralBankReserve(
  val country: String,
  val countryCode: String,
  val goldHoldingsTonnes: Double,
  val monthlyChangeTonnes: Double,
  val shareOfTotalReservesPercent: Double,
  val latestPeriod: String
)

data class ChinaGoldEtf(
  val code: String,
  val name: String,
  val price: Double,
  val nav: Double,
  val premiumDiscountPct: Double,
  val aumBillionCNY: Double,
  val goldHoldingsTonnes: Double,
  val volumeLots: Long
)

data class InventoryData(
  val venue: String,
  val location: String,
  val inventoryTonnes: Double,
  val change1W: Double,
  val metal: String, // "GOLD" or "SILVER"
  val sourceLabel: String // "官方", "供应商", "估算"
)

data class LeaseRateRecord(
  val tenor: String,
  val ratePercent: Double,
  val forwardBasisRate: Double,
  val fundingCostPercent: Double,
  val netCarryCost: Double
)
