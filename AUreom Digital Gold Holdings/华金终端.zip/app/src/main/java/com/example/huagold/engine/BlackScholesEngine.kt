package com.example.huagold.engine

import com.example.huagold.domain.model.Greeks
import com.example.huagold.domain.model.OptionType
import kotlin.math.*

object BlackScholesEngine {

  /**
   * Cumulative distribution function for standard normal distribution
   */
  fun cdf(x: Double): Double {
    val a1 = 0.254829592
    val a2 = -0.284496736
    val a3 = 1.421413741
    val a4 = -1.453152027
    val a5 = 1.061405429
    val p = 0.3275911

    val sign = if (x < 0) -1.0 else 1.0
    val absX = abs(x) / sqrt(2.0)

    val t = 1.0 / (1.0 + p * absX)
    val y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * exp(-absX * absX)

    return 0.5 * (1.0 + sign * y)
  }

  /**
   * Probability density function for standard normal distribution
   */
  fun pdf(x: Double): Double {
    return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
  }

  /**
   * Calculate Black-Scholes option price
   * S: spot price
   * K: strike price
   * T: time to maturity in years (days / 365.0)
   * r: risk-free rate (e.g. 0.02)
   * sigma: volatility (e.g. 0.16 for 16%)
   */
  fun calculateOptionPrice(
    type: OptionType,
    S: Double,
    K: Double,
    T: Double,
    r: Double,
    sigma: Double
  ): Double {
    if (T <= 0 || sigma <= 0) {
      return if (type == OptionType.CALL) max(0.0, S - K) else max(0.0, K - S)
    }

    val d1 = (ln(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrt(T))
    val d2 = d1 - sigma * sqrt(T)

    return if (type == OptionType.CALL) {
      S * cdf(d1) - K * exp(-r * T) * cdf(d2)
    } else {
      K * exp(-r * T) * cdf(-d2) - S * cdf(-d1)
    }
  }

  /**
   * Calculate Greeks
   */
  fun calculateGreeks(
    type: OptionType,
    S: Double,
    K: Double,
    T: Double,
    r: Double,
    sigma: Double
  ): Greeks {
    if (T <= 0.001 || sigma <= 0.001) {
      val delta = if (type == OptionType.CALL) (if (S >= K) 1.0 else 0.0) else (if (S <= K) -1.0 else 0.0)
      return Greeks(delta, 0.0, 0.0, 0.0, 0.0)
    }

    val sqrtT = sqrt(T)
    val d1 = (ln(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrtT)
    val d2 = d1 - sigma * sqrtT

    val pdfD1 = pdf(d1)

    val delta = if (type == OptionType.CALL) cdf(d1) else cdf(d1) - 1.0
    val gamma = pdfD1 / (S * sigma * sqrtT)
    
    // Theta (1 day decay)
    val term1 = -(S * pdfD1 * sigma) / (2 * sqrtT)
    val thetaAnnual = if (type == OptionType.CALL) {
      term1 - r * K * exp(-r * T) * cdf(d2)
    } else {
      term1 + r * K * exp(-r * T) * cdf(-d2)
    }
    val theta = thetaAnnual / 365.0

    // Vega (per 1% vol change)
    val vega = (S * sqrtT * pdfD1) / 100.0

    // Rho (per 1% interest rate change)
    val rhoAnnual = if (type == OptionType.CALL) {
      K * T * exp(-r * T) * cdf(d2)
    } else {
      -K * T * exp(-r * T) * cdf(-d2)
    }
    val rho = rhoAnnual / 100.0

    return Greeks(
      delta = (delta * 1000).roundToInt() / 1000.0,
      gamma = (gamma * 10000).roundToInt() / 10000.0,
      theta = (theta * 100).roundToInt() / 100.0,
      vega = (vega * 100).roundToInt() / 100.0,
      rho = (rho * 100).roundToInt() / 100.0
    )
  }
}
