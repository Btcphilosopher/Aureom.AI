package com.example.huagold.domain.model

data class NewsArticle(
  val id: String,
  val time: String,
  val title: String,
  val summary: String,
  val source: String,
  val category: String, // "中国", "黄金", "白银", "央行", "宏观", "ETF", "光伏工业"
  val impactAsset: String, // "XAU/CNY", "XAG/CNY", "USD/CNY", "MACRO"
  val impactDirection: String, // "BULLISH", "BEARISH", "NEUTRAL"
  val relatedSymbols: List<String>
)
