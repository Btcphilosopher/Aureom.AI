package com.example.huagold.engine

import com.example.huagold.domain.model.OHLCVBar

object VWAPEngine {
  /**
   * Computes Volume Weighted Average Price (VWAP):
   * VWAP = Sum(TypicalPrice * Volume) / Sum(Volume)
   * where TypicalPrice = (High + Low + Close) / 3
   */
  fun calculateVWAP(bars: List<OHLCVBar>): Double {
    if (bars.isEmpty()) return 0.0
    var totalVolume = 0L
    var sumPriceVolume = 0.0

    for (bar in bars) {
      val typicalPrice = (bar.high + bar.low + bar.close) / 3.0
      sumPriceVolume += typicalPrice * bar.volume
      totalVolume += bar.volume
    }

    return if (totalVolume > 0) sumPriceVolume / totalVolume else 0.0
  }

  /**
   * Calculate deviation in basis points (bps) from current price to VWAP
   */
  fun calculateDeviationBps(currentPrice: Double, vwap: Double): Double {
    if (vwap <= 0) return 0.0
    return ((currentPrice - vwap) / vwap) * 10000.0
  }
}
