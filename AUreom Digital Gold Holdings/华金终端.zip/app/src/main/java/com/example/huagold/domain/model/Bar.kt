package com.example.huagold.domain.model

enum class Timeframe(val label: String, val minutes: Int) {
  M1("1分", 1),
  M5("5分", 5),
  M15("15分", 15),
  H1("1小时", 60),
  D1("日线", 1440),
  W1("周线", 10080)
}

data class OHLCVBar(
  val timestamp: Long,
  val timeLabel: String,
  val open: Double,
  val high: Double,
  val low: Double,
  val close: Double,
  val volume: Long,
  val openInterest: Long = 0,
  val vwap: Double = 0.0,
  val ma5: Double? = null,
  val ma20: Double? = null,
  val bbUpper: Double? = null,
  val bbLower: Double? = null,
  val rsi: Double? = null,
  val macd: Double? = null,
  val macdSignal: Double? = null,
  val macdHist: Double? = null
)
