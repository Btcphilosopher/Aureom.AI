package com.example.huagold.engine

import com.example.huagold.domain.model.*
import java.text.SimpleDateFormat
import java.util.*

object OMSEngine {

  private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

  /**
   * Validates and submits a new order into the OMS
   */
  fun submitOrder(
    symbol: String,
    side: OrderSide,
    type: OrderType,
    price: Double,
    quantity: Double,
    venue: Venue = Venue.SGE
  ): OrderItem {
    val now = timeFormat.format(Date())
    val id = "ORD-" + System.currentTimeMillis().toString().takeLast(6)
    return OrderItem(
      orderId = id,
      symbol = symbol,
      side = side,
      type = type,
      price = price,
      quantity = quantity,
      filledQuantity = 0.0,
      status = OrderStatus.ACCEPTED,
      createTime = now,
      updateTime = now,
      venue = venue
    )
  }

  /**
   * Simulates matching engine execution for working orders
   */
  fun simulateMatch(order: OrderItem, currentMarketPrice: Double): Pair<OrderItem, TradeExecution?> {
    val now = timeFormat.format(Date())
    val canExecute = when (order.type) {
      OrderType.MARKET -> true
      OrderType.LIMIT -> {
        if (order.side == OrderSide.BUY) currentMarketPrice <= order.price
        else currentMarketPrice >= order.price
      }
      OrderType.STOP_LOSS -> {
        if (order.side == OrderSide.SELL) currentMarketPrice <= order.price
        else currentMarketPrice >= order.price
      }
      else -> true
    }

    if (!canExecute) {
      return Pair(order.copy(status = OrderStatus.WORKING, updateTime = now), null)
    }

    val executionPrice = if (order.type == OrderType.MARKET) currentMarketPrice else order.price
    val execution = TradeExecution(
      tradeId = "TRD-" + System.currentTimeMillis().toString().takeLast(6),
      orderId = order.orderId,
      symbol = order.symbol,
      side = order.side,
      quantity = order.quantity,
      price = executionPrice,
      timestamp = now,
      fee = executionPrice * order.quantity * 0.0002, // 0.02% fee
      venue = order.venue,
      settlement = SettlementType.PHYSICAL
    )

    val updatedOrder = order.copy(
      filledQuantity = order.quantity,
      status = OrderStatus.FILLED,
      updateTime = now
    )

    return Pair(updatedOrder, execution)
  }
}
