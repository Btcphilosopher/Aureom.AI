package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.*
import com.example.huagold.ui.components.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TradingTerminalScreen(
  repository: MarketRepository,
  onNavigateToPortfolio: () -> Unit
) {
  val quotes by repository.quotes.collectAsState()
  val selectedSymbol by repository.selectedSymbol.collectAsState()
  val selectedTf by repository.selectedTimeframe.collectAsState()
  val candles by repository.candles.collectAsState()
  val orderBook by repository.orderBook.collectAsState()
  val heatmapCells by repository.orderBookHeatmap.collectAsState()
  val recentTrades by repository.recentTrades.collectAsState()
  val blockTrades by repository.blockTrades.collectAsState()

  var selectedIndicator by remember { mutableStateOf(SubChartIndicator.VOL) }
  var orderSide by remember { mutableStateOf(OrderSide.BUY) }
  var orderPriceInput by remember { mutableStateOf("") }
  var orderQtyInput by remember { mutableStateOf("100") }
  var showOrderDialog by remember { mutableStateOf(false) }

  val quote = quotes[selectedSymbol] ?: quotes["Au99.99"]
  val last = quote?.last ?: 928.42
  val changePct = quote?.changePercent ?: 0.0
  val isUp = changePct >= 0
  val quoteColor = if (isUp) QuoteUpRed else QuoteDownGreen

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("trading_terminal_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Symbol Selector Bar & Venue Tag
    item {
      LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        val symbols = listOf("Au99.99", "Au(T+D)", "Ag99.99", "Ag(T+D)", "Au99.95", "Au100g", "XAU/USD", "XAG/USD", "USD/CNY")
        items(symbols) { sym ->
          val isSelected = sym == selectedSymbol
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (isSelected) GoldMuted else TerminalSurfaceVariant)
              .border(1.dp, if (isSelected) GoldPrimary else TerminalBorderSubtle, RoundedCornerShape(4.dp))
              .clickable { repository.selectSymbol(sym) }
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("symbol_tab_$sym")
          ) {
            Text(
              sym,
              color = if (isSelected) GoldAccent else TextGray,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // 2. Instrument Header Stats Card
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                selectedSymbol,
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                quote?.market ?: "上海黄金交易所",
                color = TextMuted,
                fontSize = 10.sp
              )
            }

            // Fast Order Button
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(GoldPrimary)
                .clickable {
                  orderPriceInput = String.format(Locale.US, "%.2f", last)
                  showOrderDialog = true
                }
                .padding(horizontal = 10.dp, vertical = 4.dp)
                .testTag("fast_order_btn")
            ) {
              Text(
                "快速下单",
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Primary Price & Change
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                String.format(Locale.US, "%.2f", last),
                color = quoteColor,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                "${if (isUp) "+" else ""}${String.format(Locale.US, "%.2f", quote?.change ?: 0.0)} (${if (isUp) "+" else ""}${String.format(Locale.US, "%.2f", changePct)}%)",
                color = quoteColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }

            Text(
              quote?.unit ?: "元/克",
              color = TextMuted,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Stats Grid (High, Low, Open, PrevClose, Vol, Turnover, OI, Spread)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
              .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("最高: ${quote?.high ?: "-"}", color = QuoteUpRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("最低: ${quote?.low ?: "-"}", color = QuoteDownGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Column {
              Text("今开: ${quote?.open ?: "-"}", color = TextWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("昨收: ${quote?.prevClose ?: "-"}", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Column {
              Text("成交量: ${quote?.volume ?: "-"}手", color = TextWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("持仓量: ${quote?.openInterest ?: "-"}手", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Column {
              Text("买卖价差: ${String.format(Locale.US, "%.2f", quote?.spread ?: 0.0)}", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text("更新: ${quote?.timestamp ?: "-"}", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
          }
        }
      }
    }

    // 3. Timeframe & Technical Indicator Toggles
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Timeframes
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Timeframe.values().forEach { tf ->
            val isSelected = selectedTf == tf
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isSelected) GoldPrimary else TerminalSurfaceVariant)
                .clickable { repository.setTimeframe(tf) }
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                tf.label,
                color = if (isSelected) Color.Black else TextGray,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        // Sub Chart Indicators
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          SubChartIndicator.values().forEach { ind ->
            val isSelected = selectedIndicator == ind
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isSelected) CyanAccent else TerminalSurfaceVariant)
                .clickable { selectedIndicator = ind }
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                ind.label,
                color = if (isSelected) Color.Black else TextGray,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }
      }
    }

    // 4. Interactive Candlestick Canvas
    item {
      MarketChartCanvas(
        bars = candles,
        selectedIndicator = selectedIndicator
      )
    }

    // 5. Level 2 Order Book View
    item {
      OrderBookView(
        orderBook = orderBook,
        heatmapCells = heatmapCells,
        onPriceSelected = { p ->
          orderPriceInput = String.format(Locale.US, "%.2f", p)
          showOrderDialog = true
        }
      )
    }

    // 6. Time & Sales / Recent Trades & Block Trade Monitor
    item {
      TimeAndSalesView(
        trades = recentTrades,
        blockTrades = blockTrades
      )
    }
  }

  // Fast Order Entry Dialog
  if (showOrderDialog) {
    AlertDialog(
      onDismissRequest = { showOrderDialog = false },
      containerColor = TerminalSurface,
      title = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "模拟下单委托 ($selectedSymbol)",
            color = GoldPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Box(
            modifier = Modifier
              .background(Color(0x3338BDF8), RoundedCornerShape(2.dp))
              .padding(horizontal = 4.dp, vertical = 1.dp)
          ) {
            Text("SYNTHETIC OMS", color = CyanAccent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
          }
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          // Side Selector (Buy vs Sell)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(if (orderSide == OrderSide.BUY) QuoteUpRed else TerminalSurfaceVariant)
                .clickable { orderSide = OrderSide.BUY }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("买入 / 多头", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(if (orderSide == OrderSide.SELL) QuoteDownGreen else TerminalSurfaceVariant)
                .clickable { orderSide = OrderSide.SELL }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("卖出 / 空头", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }

          // Price Field
          OutlinedTextField(
            value = orderPriceInput,
            onValueChange = { orderPriceInput = it },
            label = { Text("委托价格 (元/克或千克)") },
            colors = TextFieldDefaults.colors(
              focusedContainerColor = TerminalSurfaceVariant,
              unfocusedContainerColor = TerminalSurfaceVariant,
              focusedTextColor = TextWhite,
              unfocusedTextColor = TextWhite,
              focusedIndicatorColor = GoldPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          // Quantity Field
          OutlinedTextField(
            value = orderQtyInput,
            onValueChange = { orderQtyInput = it },
            label = { Text("委托数量 (克/手)") },
            colors = TextFieldDefaults.colors(
              focusedContainerColor = TerminalSurfaceVariant,
              unfocusedContainerColor = TerminalSurfaceVariant,
              focusedTextColor = TextWhite,
              unfocusedTextColor = TextWhite,
              focusedIndicatorColor = GoldPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Text(
            "提示：订单将提交至华金模拟撮合引擎 (OMS)，成交后将自动录入不可变交易账本并实时更新投资组合 P&L。",
            color = TextMuted,
            fontSize = 9.sp
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val price = orderPriceInput.toDoubleOrNull() ?: last
            val qty = orderQtyInput.toDoubleOrNull() ?: 100.0
            repository.submitOrder(
              symbol = selectedSymbol,
              side = orderSide,
              type = OrderType.LIMIT,
              price = price,
              quantity = qty
            )
            showOrderDialog = false
            onNavigateToPortfolio()
          },
          colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
        ) {
          Text("确认提交委托", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showOrderDialog = false }) {
          Text("取消", color = TextGray)
        }
      }
    )
  }
}
