package com.example.huagold.domain.model

enum class TradeDirection(val label: String) {
  BUY("主动买"),
  SELL("主动卖"),
  NEUTRAL("中性")
}

data class TradeItem(
  val tradeId: String,
  val symbol: String,
  val time: String,
  val price: Double,
  val volume: Long,
  val direction: TradeDirection,
  val isBlock: Boolean = false
)

data class BlockTrade(
  val id: String,
  val symbol: String,
  val time: String,
  val price: Double,
  val volume: Long,
  val amountWan: Double, // in 万元
  val priceImpactBps: Double,
  val direction: TradeDirection,
  val type: String = "大单成交"
)
