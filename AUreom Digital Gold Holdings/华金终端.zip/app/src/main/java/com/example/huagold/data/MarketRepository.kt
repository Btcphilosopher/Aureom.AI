package com.example.huagold.data

import com.example.huagold.domain.model.*
import com.example.huagold.engine.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MarketRepository(
  private val scope: CoroutineScope
) {
  private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
  private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
  private val random = Random()

  // Real-time market quotes
  private val _quotes = MutableStateFlow<Map<String, Quote>>(emptyMap())
  val quotes: StateFlow<Map<String, Quote>> = _quotes.asStateFlow()

  // Selected Instrument for Chart / Depth / Trade
  private val _selectedSymbol = MutableStateFlow("Au99.99")
  val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

  // OrderBook for selected symbol
  private val _orderBook = MutableStateFlow<OrderBook?>(null)
  val orderBook: StateFlow<OrderBook?> = _orderBook.asStateFlow()

  // Order Book Heatmap Data
  private val _orderBookHeatmap = MutableStateFlow<List<HeatmapCell>>(emptyList())
  val orderBookHeatmap: StateFlow<List<HeatmapCell>> = _orderBookHeatmap.asStateFlow()

  // Time & Sales
  private val _recentTrades = MutableStateFlow<List<TradeItem>>(emptyList())
  val recentTrades: StateFlow<List<TradeItem>> = _recentTrades.asStateFlow()

  // Block trades
  private val _blockTrades = MutableStateFlow<List<BlockTrade>>(emptyList())
  val blockTrades: StateFlow<List<BlockTrade>> = _blockTrades.asStateFlow()

  // OHLCV Candlestick data for selected symbol & timeframe
  private val _candles = MutableStateFlow<List<OHLCVBar>>(emptyList())
  val candles: StateFlow<List<OHLCVBar>> = _candles.asStateFlow()

  private val _selectedTimeframe = MutableStateFlow(Timeframe.M5)
  val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

  // Term Structure Curves
  private val _goldCurve = MutableStateFlow<TermStructureCurve?>(null)
  val goldCurve: StateFlow<TermStructureCurve?> = _goldCurve.asStateFlow()

  private val _silverCurve = MutableStateFlow<TermStructureCurve?>(null)
  val silverCurve: StateFlow<TermStructureCurve?> = _silverCurve.asStateFlow()

  // Gold / Silver Ratio
  private val _goldSilverRatio = MutableStateFlow<GoldSilverRatioData?>(null)
  val goldSilverRatio: StateFlow<GoldSilverRatioData?> = _goldSilverRatio.asStateFlow()

  // China Gold & Silver Premiums
  private val _chinaGoldPremium = MutableStateFlow<ChinaPremiumData?>(null)
  val chinaGoldPremium: StateFlow<ChinaPremiumData?> = _chinaGoldPremium.asStateFlow()

  private val _chinaSilverPremium = MutableStateFlow<ChinaPremiumData?>(null)
  val chinaSilverPremium: StateFlow<ChinaPremiumData?> = _chinaSilverPremium.asStateFlow()

  // Options Lab
  private val _optionChain = MutableStateFlow<List<OptionContract>>(emptyList())
  val optionChain: StateFlow<List<OptionContract>> = _optionChain.asStateFlow()

  private val _volSurface = MutableStateFlow<VolSurfaceData?>(null)
  val volSurface: StateFlow<VolSurfaceData?> = _volSurface.asStateFlow()

  // Portfolio & OMS
  private val _portfolio = MutableStateFlow<PortfolioSummary?>(null)
  val portfolio: StateFlow<PortfolioSummary?> = _portfolio.asStateFlow()

  private val _workingOrders = MutableStateFlow<List<OrderItem>>(emptyList())
  val workingOrders: StateFlow<List<OrderItem>> = _workingOrders.asStateFlow()

  private val _tradeLedger = MutableStateFlow<List<TradeExecution>>(emptyList())
  val tradeLedger: StateFlow<List<TradeExecution>> = _tradeLedger.asStateFlow()

  // Risk & Scenarios
  private val _riskSnapshot = MutableStateFlow<RiskSnapshot?>(null)
  val riskSnapshot: StateFlow<RiskSnapshot?> = _riskSnapshot.asStateFlow()

  private val _stressResults = MutableStateFlow<List<StressResult>>(emptyList())
  val stressResults: StateFlow<List<StressResult>> = _stressResults.asStateFlow()

  private val _monteCarloResult = MutableStateFlow<MonteCarloResult?>(null)
  val monteCarloResult: StateFlow<MonteCarloResult?> = _monteCarloResult.asStateFlow()

  private val _marginRequirements = MutableStateFlow<List<MarginRequirement>>(emptyList())
  val marginRequirements: StateFlow<List<MarginRequirement>> = _marginRequirements.asStateFlow()

  // Macro & Research
  private val _macroIndicators = MutableStateFlow<List<MacroIndicator>>(emptyList())
  val macroIndicators: StateFlow<List<MacroIndicator>> = _macroIndicators.asStateFlow()

  private val _centralBankReserves = MutableStateFlow<List<CentralBankReserve>>(emptyList())
  val centralBankReserves: StateFlow<List<CentralBankReserve>> = _centralBankReserves.asStateFlow()

  private val _chinaGoldEtfs = MutableStateFlow<List<ChinaGoldEtf>>(emptyList())
  val chinaGoldEtfs: StateFlow<List<ChinaGoldEtf>> = _chinaGoldEtfs.asStateFlow()

  private val _inventories = MutableStateFlow<List<InventoryData>>(emptyList())
  val inventories: StateFlow<List<InventoryData>> = _inventories.asStateFlow()

  private val _leaseRates = MutableStateFlow<List<LeaseRateRecord>>(emptyList())
  val leaseRates: StateFlow<List<LeaseRateRecord>> = _leaseRates.asStateFlow()

  private val _goldMacroModel = MutableStateFlow<MacroModelAnalysis?>(null)
  val goldMacroModel: StateFlow<MacroModelAnalysis?> = _goldMacroModel.asStateFlow()

  // News Wire
  private val _newsList = MutableStateFlow<List<NewsArticle>>(emptyList())
  val newsList: StateFlow<List<NewsArticle>> = _newsList.asStateFlow()

  // Current Shanghai Clock string
  private val _currentTimeStr = MutableStateFlow("09:42:18")
  val currentTimeStr: StateFlow<String> = _currentTimeStr.asStateFlow()

  // Market status label
  private val _marketStatus = MutableStateFlow("正常")
  val marketStatus: StateFlow<String> = _marketStatus.asStateFlow()

  init {
    initializeAllData()
    startLiveTickEngine()
  }

  fun selectSymbol(symbol: String) {
    _selectedSymbol.value = symbol
    generateCandles(symbol, _selectedTimeframe.value)
    generateOrderBook(symbol)
  }

  fun setTimeframe(tf: Timeframe) {
    _selectedTimeframe.value = tf
    generateCandles(_selectedSymbol.value, tf)
  }

  /**
   * Submit an order into synthetic OMS
   */
  fun submitOrder(
    symbol: String,
    side: OrderSide,
    type: OrderType,
    price: Double,
    quantity: Double,
    venue: Venue = Venue.SGE
  ) {
    val order = OMSEngine.submitOrder(symbol, side, type, price, quantity, venue)
    val quote = _quotes.value[symbol] ?: _quotes.value["Au99.99"]
    val currentPrice = quote?.last ?: price

    val (updatedOrder, execution) = OMSEngine.simulateMatch(order, currentPrice)

    if (updatedOrder.status == OrderStatus.FILLED && execution != null) {
      _tradeLedger.value = listOf(execution) + _tradeLedger.value
      updatePortfolioAfterExecution(execution)
    } else {
      _workingOrders.value = listOf(updatedOrder) + _workingOrders.value
    }
  }

  fun cancelOrder(orderId: String) {
    _workingOrders.value = _workingOrders.value.filter { it.orderId != orderId }
  }

  /**
   * Inject Market Event Shock
   */
  fun triggerMacroShock(shockType: String) {
    val currentQuotes = _quotes.value.toMutableMap()
    val now = timeFormat.format(Date())

    when (shockType) {
      "GOLD_BULL_SHOCK" -> {
        _marketStatus.value = "高波动"
        currentQuotes.forEach { (sym, q) ->
          if (sym.contains("Au") || sym.contains("XAU") || sym.contains("SHGOLD")) {
            val newLast = q.last * 1.025
            currentQuotes[sym] = q.copy(
              last = (newLast * 100).roundToInt() / 100.0,
              high = max(q.high, newLast),
              bid = newLast - 0.1,
              ask = newLast + 0.1,
              volume = q.volume + 1240,
              timestamp = now
            )
          }
        }
        _newsList.value = listOf(
          NewsArticle(
            id = "SHOCK-" + System.currentTimeMillis(),
            time = now,
            title = "【突发宏观冲击】美联储发表鸽派言论，实际利率跳水引发全球黄金强劲买盘",
            summary = "COMEX黄金与上海金现货瞬间放量突破阻力位，在岸买盘活跃，国内黄金现货溢价扩大至 +3.45 元/克。",
            source = "华金行情快讯",
            category = "宏观",
            impactAsset = "XAU/CNY",
            impactDirection = "BULLISH",
            relatedSymbols = listOf("Au99.99", "Au(T+D)", "XAU/CNY", "518880")
          )
        ) + _newsList.value
      }
      "SILVER_SPIKE_SHOCK" -> {
        _marketStatus.value = "白银放量"
        currentQuotes.forEach { (sym, q) ->
          if (sym.contains("Ag") || sym.contains("XAG")) {
            val newLast = q.last * 1.038
            currentQuotes[sym] = q.copy(
              last = (newLast * 100).roundToInt() / 100.0,
              high = max(q.high, newLast),
              bid = newLast - 2.0,
              ask = newLast + 2.0,
              volume = q.volume + 5400,
              timestamp = now
            )
          }
        }
        _newsList.value = listOf(
          NewsArticle(
            id = "SHOCK-" + System.currentTimeMillis(),
            time = now,
            title = "【白银异动】光伏组件排产回升叠加交易所白银仓单库存下降，白银强势拉升",
            summary = "国内Ag99.99与国际现货银联动走强，金银比加速回落至56.8区间，工业多头持仓显著增加。",
            source = "华金产业动态",
            category = "白银",
            impactAsset = "XAG/CNY",
            impactDirection = "BULLISH",
            relatedSymbols = listOf("Ag99.99", "Ag(T+D)", "XAG/CNY")
          )
        ) + _newsList.value
      }
      "USD_STRENGTH_SHOCK" -> {
        val usdQ = currentQuotes["USD/CNY"]
        if (usdQ != null) {
          val newLast = usdQ.last * 1.004
          currentQuotes["USD/CNY"] = usdQ.copy(last = (newLast * 10000).roundToInt() / 10000.0, timestamp = now)
        }
      }
    }

    _quotes.value = currentQuotes
    recalculateDerivedMetrics()
  }

  fun runCustomMonteCarlo(days: Int, paths: Int, vol: Double): MonteCarloResult {
    val auQuote = _quotes.value["Au99.99"]?.last ?: 928.45
    val res = MonteCarloEngine.runSimulation(
      spotPrice = auQuote,
      annualVolatility = vol,
      days = days,
      numPaths = paths
    )
    _monteCarloResult.value = res
    return res
  }

  private fun initializeAllData() {
    val now = "09:42:18"

    // 1. Initial Quotes
    val initialQuotes = mapOf(
      "Au99.99" to Quote(
        symbol = "Au99.99",
        market = "上金所现货实盘",
        instrument = "黄金99.99",
        bid = 928.40,
        ask = 928.45,
        last = 928.42,
        open = 918.50,
        high = 929.80,
        low = 917.20,
        prevClose = 911.85,
        volume = 48520,
        openInterest = 0,
        turnover = 45051200.0,
        timestamp = now,
        unit = "元/克",
        venue = Venue.SGE
      ),
      "Au(T+D)" to Quote(
        symbol = "Au(T+D)",
        market = "上金所延期交收",
        instrument = "黄金延期",
        bid = 929.10,
        ask = 929.20,
        last = 929.15,
        open = 919.00,
        high = 930.50,
        low = 918.00,
        prevClose = 912.40,
        volume = 126400,
        openInterest = 284500,
        turnover = 117444500.0,
        timestamp = now,
        unit = "元/克",
        venue = Venue.SGE
      ),
      "Au99.95" to Quote(
        symbol = "Au99.95",
        market = "上金所现货实盘",
        instrument = "黄金99.95",
        bid = 928.10,
        ask = 928.25,
        last = 928.18,
        open = 918.00,
        high = 929.10,
        low = 916.80,
        prevClose = 911.50,
        volume = 12400,
        openInterest = 0,
        turnover = 11509430.0,
        timestamp = now,
        unit = "元/克",
        venue = Venue.SGE
      ),
      "Au100g" to Quote(
        symbol = "Au100g",
        market = "上金所现货小金条",
        instrument = "黄金100克",
        bid = 929.00,
        ask = 929.30,
        last = 929.10,
        open = 919.20,
        high = 930.00,
        low = 918.50,
        prevClose = 912.00,
        volume = 5820,
        openInterest = 0,
        turnover = 5407360.0,
        timestamp = now,
        unit = "元/克",
        venue = Venue.SGE
      ),
      "Ag99.99" to Quote(
        symbol = "Ag99.99",
        market = "上金所白银现货",
        instrument = "白银99.99",
        bid = 15815.0,
        ask = 15825.0,
        last = 15821.0,
        open = 15900.0,
        high = 16050.0,
        low = 15720.0,
        prevClose = 15870.0,
        volume = 38450,
        openInterest = 0,
        turnover = 60831700.0,
        timestamp = now,
        unit = "元/千克",
        venue = Venue.SGE
      ),
      "Ag(T+D)" to Quote(
        symbol = "Ag(T+D)",
        market = "上金所白银延期",
        instrument = "白银延期",
        bid = 15840.0,
        ask = 15845.0,
        last = 15842.0,
        open = 15920.0,
        high = 16100.0,
        low = 15750.0,
        prevClose = 15890.0,
        volume = 942100,
        openInterest = 4120000,
        turnover = 149247400.0,
        timestamp = now,
        unit = "元/千克",
        venue = Venue.SGE
      ),
      "SHGOLD_AM" to Quote(
        symbol = "SHGOLD_AM",
        market = "上海金基准定价",
        instrument = "上海金早盘价",
        bid = 928.00,
        ask = 928.00,
        last = 928.00,
        open = 928.00,
        high = 928.00,
        low = 928.00,
        prevClose = 912.10,
        volume = 1200,
        openInterest = 0,
        turnover = 1113600.0,
        timestamp = "10:15:00",
        unit = "元/克",
        venue = Venue.SGE
      ),
      "SHGOLD_PM" to Quote(
        symbol = "SHGOLD_PM",
        market = "上海金基准定价",
        instrument = "上海金午盘价",
        bid = 927.80,
        ask = 927.80,
        last = 927.80,
        open = 927.80,
        high = 927.80,
        low = 927.80,
        prevClose = 911.90,
        volume = 1500,
        openInterest = 0,
        turnover = 1391700.0,
        timestamp = "15:00:00",
        unit = "元/克",
        venue = Venue.SGE
      ),
      "XAU/USD" to Quote(
        symbol = "XAU/USD",
        market = "国际黄金现货",
        instrument = "COMEX / LBMA Gold",
        bid = 4057.80,
        ask = 4058.40,
        last = 4058.20,
        open = 4015.00,
        high = 4065.00,
        low = 4008.00,
        prevClose = 3985.50,
        volume = 184500,
        openInterest = 485000,
        timestamp = now,
        currency = "USD",
        unit = "美元/盎司",
        venue = Venue.COMEX
      ),
      "XAG/USD" to Quote(
        symbol = "XAG/USD",
        market = "国际白银现货",
        instrument = "COMEX Silver",
        bid = 38.40,
        ask = 38.45,
        last = 38.42,
        open = 38.60,
        high = 38.90,
        low = 38.10,
        prevClose = 38.55,
        volume = 72100,
        openInterest = 156000,
        timestamp = now,
        currency = "USD",
        unit = "美元/盎司",
        venue = Venue.COMEX
      ),
      "USD/CNY" to Quote(
        symbol = "USD/CNY",
        market = "中国外汇市场",
        instrument = "美元在岸人民币",
        bid = 7.1280,
        ask = 7.1288,
        last = 7.1284,
        open = 7.1250,
        high = 7.1310,
        low = 7.1240,
        prevClose = 7.1255,
        volume = 32800,
        timestamp = now,
        currency = "CNY",
        unit = "汇率",
        venue = Venue.CFETS
      ),
      "USD/CNH" to Quote(
        symbol = "USD/CNH",
        market = "离岸外汇市场",
        instrument = "美元离岸人民币",
        bid = 7.1310,
        ask = 7.1320,
        last = 7.1315,
        open = 7.1280,
        high = 7.1350,
        low = 7.1270,
        prevClose = 7.1290,
        volume = 24500,
        timestamp = now,
        currency = "CNH",
        unit = "汇率",
        venue = Venue.HKEX
      )
    )

    _quotes.value = initialQuotes

    // 2. Initial Portfolio
    _portfolio.value = PortfolioSummary(
      totalEquity = 12850000.0,
      cashBalanceCNY = 3500000.0,
      cashBalanceUSD = 250000.0,
      marginUsed = 2450000.0,
      marginAvailable = 6900000.0,
      dailyPnL = 234500.0,
      dailyPnLPercent = 1.86,
      weeklyPnL = 582000.0,
      monthlyPnL = 1145000.0,
      ytdPnL = 2890000.0,
      positions = listOf(
        Position("Au99.99", "黄金现货实盘", 5000.0, 915.20, 928.42, 5000.0, 1.0),
        Position("Au(T+D)", "黄金延期交收(多)", 4.0, 918.00, 929.15, 4000.0, 1000.0),
        Position("Ag(T+D)", "白银延期交收(空)", 10.0, 15950.0, 15842.0, -150000.0, 15.0),
        Position("518880", "华安黄金ETF", 500000.0, 8.85, 9.12, 500.0, 1.0)
      ),
      attribution = PnLAttribution(
        priceEffect = 185000.0,
        fxEffect = 28000.0,
        basisEffect = 16500.0,
        carryEffect = 8500.0,
        volEffect = 1200.0,
        transactionCosts = 4700.0
      )
    )

    // 3. Initial Working Orders
    _workingOrders.value = listOf(
      OrderItem("ORD-892101", "Au99.99", OrderSide.BUY, OrderType.LIMIT, 925.00, 1000.0, 0.0, OrderStatus.WORKING, "09:30:12", "09:30:12"),
      OrderItem("ORD-892102", "Au(T+D)", OrderSide.SELL, OrderType.STOP_LOSS, 920.00, 2.0, 0.0, OrderStatus.WORKING, "09:35:40", "09:35:40")
    )

    // 4. Initial Trade Ledger
    _tradeLedger.value = listOf(
      TradeExecution("TRD-710291", "ORD-892090", "Au99.99", OrderSide.BUY, 2000.0, 924.50, "09:15:22", 369.80, Venue.SGE, SettlementType.PHYSICAL),
      TradeExecution("TRD-710292", "ORD-892095", "Au(T+D)", OrderSide.BUY, 2.0, 926.00, "09:22:45", 370.40, Venue.SGE, SettlementType.DEFERRED)
    )

    // 5. Macro Models & Indicators
    _goldMacroModel.value = GoldMacroModelEngine.getGoldMacroModel()

    _macroIndicators.value = listOf(
      MacroIndicator("US 10Y Real Yield (美债10年实际收益率)", "US10Y_TIPS", 1.62, "%", -0.04, -0.78, "RATE"),
      MacroIndicator("DXY (美元指数)", "DXY", 102.15, "点", -0.28, -0.65, "CURRENCY"),
      MacroIndicator("China CPI (中国居民消费价格指数)", "CN_CPI", 0.60, "%", 0.10, 0.35, "INFLATION"),
      MacroIndicator("Global Photovoltaic Solar Demand (光伏需求)", "PV_SOLAR", 680.0, "GW", 12.5, 0.72, "INDUSTRY"),
      MacroIndicator("Copper LME 3M (LME铜)", "HG_COPPER", 9850.0, "美元/吨", 2.10, 0.58, "INDUSTRY")
    )

    _centralBankReserves.value = listOf(
      CentralBankReserve("中国人民银行 (PBOC)", "CN", 2264.3, 2.1, 4.9, "2026-09"),
      CentralBankReserve("俄罗斯央行 (CBR)", "RU", 2335.8, 1.5, 29.5, "2026-09"),
      CentralBankReserve("印度央行 (RBI)", "IN", 840.5, 3.8, 9.2, "2026-09"),
      CentralBankReserve("波兰央行 (NBP)", "PL", 398.2, 5.2, 14.8, "2026-09"),
      CentralBankReserve("土耳其央行 (CBRT)", "TR", 585.0, 2.4, 34.0, "2026-09")
    )

    _chinaGoldEtfs.value = listOf(
      ChinaGoldEtf("518880", "华安易富黄金ETF", 9.124, 9.120, 0.04, 38.5, 42.1, 145000),
      ChinaGoldEtf("159934", "易方达黄金ETF", 9.118, 9.115, 0.03, 22.8, 25.0, 89200),
      ChinaGoldEtf("518800", "国泰黄金ETF", 9.122, 9.119, 0.03, 14.2, 15.6, 54100),
      ChinaGoldEtf("159937", "博时黄金ETF", 9.120, 9.117, 0.03, 18.6, 20.4, 76000)
    )

    _inventories.value = listOf(
      InventoryData("上海黄金交易所 (SGE)", "上海保税库/自贸区", 3120.5, -12.4, "GOLD", "官方"),
      InventoryData("上海期货交易所 (SHFE)", "上海交割仓", 185.2, -4.1, "GOLD", "官方"),
      InventoryData("COMEX Gold Warehouses", "纽约", 542.8, -18.6, "GOLD", "官方"),
      InventoryData("LBMA Vaults", "伦敦", 8450.0, -45.0, "GOLD", "供应商"),
      InventoryData("SHFE Silver (上期所白银仓单)", "上海/华东", 1240.0, -85.2, "SILVER", "官方")
    )

    _leaseRates.value = listOf(
      LeaseRateRecord("1M (1个月)", 1.85, 2.10, 2.05, 0.20),
      LeaseRateRecord("3M (3个月)", 2.15, 2.45, 2.20, 0.30),
      LeaseRateRecord("6M (6个月)", 2.40, 2.70, 2.35, 0.35),
      LeaseRateRecord("1Y (12个月)", 2.65, 2.95, 2.50, 0.45)
    )

    // 6. News
    _newsList.value = listOf(
      NewsArticle(
        id = "N1",
        time = "09:41",
        title = "【在岸溢价】上海金现货较国际理论折算溢价走阔至 +2.41 元/克，进口报关顺畅",
        summary = "上金所竞价与定价市场早盘现货交投活跃，银行间黄金租借利率稳中微升，下游首饰加工与金条配资需求稳定。",
        source = "华金行情中心",
        category = "中国",
        impactAsset = "XAU/CNY",
        impactDirection = "BULLISH",
        relatedSymbols = listOf("Au99.99", "SHGOLD_AM", "USD/CNY")
      ),
      NewsArticle(
        id = "N2",
        time = "09:37",
        title = "【白银微观】光伏组件头部厂商加大N型高效电池片银浆直采，白银现货紧平衡",
        summary = "行业协会数据显示，三季度光伏银浆耗量同比增加18%，工业用银需求持续支撑白银现货基差。",
        source = "华金产业研究",
        category = "光伏工业",
        impactAsset = "XAG/CNY",
        impactDirection = "BULLISH",
        relatedSymbols = listOf("Ag99.99", "Ag(T+D)", "XAG/USD")
      ),
      NewsArticle(
        id = "N3",
        time = "09:31",
        title = "【央行动态】中国人民银行连续公布官方黄金储备数据，结构性多元化配置持续",
        summary = "截至上月末官方黄金储备规模稳中有进，占外汇储备总额比例提升至4.9%，长期配置盘奠定底部中枢。",
        source = "央行数据快报",
        category = "央行",
        impactAsset = "XAU/CNY",
        impactDirection = "BULLISH",
        relatedSymbols = listOf("Au99.99", "XAU/USD")
      ),
      NewsArticle(
        id = "N4",
        time = "09:20",
        title = "【外汇市场】人民币对美元中间价调升25个基点，结售汇市场运行平稳",
        summary = "中国外汇交易中心数据显示，USD/CNY即期汇率在7.1280附近窄幅整理，离在岸汇差保持在30点以内。",
        source = "外汇资讯",
        category = "宏观",
        impactAsset = "USD/CNY",
        impactDirection = "NEUTRAL",
        relatedSymbols = listOf("USD/CNY", "USD/CNH")
      )
    )

    generateCandles(_selectedSymbol.value, _selectedTimeframe.value)
    generateOrderBook(_selectedSymbol.value)
    generateOptionsAndVolSurface()
    recalculateDerivedMetrics()
    runCustomMonteCarlo(30, 10000, 0.165)
  }

  private fun recalculateDerivedMetrics() {
    val quotesMap = _quotes.value
    val auQuote = quotesMap["Au99.99"]?.last ?: 928.42
    val agQuote = quotesMap["Ag99.99"]?.last ?: 15821.0
    val xauUsd = quotesMap["XAU/USD"]?.last ?: 4058.20
    val xagUsd = quotesMap["XAG/USD"]?.last ?: 38.42
    val usdCny = quotesMap["USD/CNY"]?.last ?: 7.1284

    // Theoretical CNY Gold & Silver
    val theoreticalGold = UnitConversionEngine.calculateTheoreticalCnyGoldPerGram(xauUsd, usdCny)
    val goldBasis = UnitConversionEngine.calculateChinaGoldBasis(auQuote, theoreticalGold)
    val goldBasisPct = if (theoreticalGold > 0) (goldBasis / theoreticalGold) * 100.0 else 0.0

    _chinaGoldPremium.value = ChinaPremiumData(
      symbol = "XAU/CNY",
      domesticPrice = auQuote,
      internationalPriceUSD = xauUsd,
      usdCnyRate = usdCny,
      theoreticalCnyPrice = (theoreticalGold * 100).roundToInt() / 100.0,
      premiumAmount = (goldBasis * 100).roundToInt() / 100.0,
      premiumPercent = (goldBasisPct * 100).roundToInt() / 100.0,
      historicalMean = 1.45,
      zScore = 1.28,
      percentile = 78.4
    )

    val theoreticalSilverKg = UnitConversionEngine.calculateTheoreticalCnySilverPerKg(xagUsd, usdCny)
    val silverBasisKg = agQuote - theoreticalSilverKg
    val silverBasisPct = if (theoreticalSilverKg > 0) (silverBasisKg / theoreticalSilverKg) * 100.0 else 0.0

    _chinaSilverPremium.value = ChinaPremiumData(
      symbol = "XAG/CNY",
      domesticPrice = agQuote,
      internationalPriceUSD = xagUsd,
      usdCnyRate = usdCny,
      theoreticalCnyPrice = (theoreticalSilverKg * 10).roundToInt() / 10.0,
      premiumAmount = (silverBasisKg * 10).roundToInt() / 10.0,
      premiumPercent = (silverBasisPct * 100).roundToInt() / 100.0,
      historicalMean = 42.0,
      zScore = 0.85,
      percentile = 64.2
    )

    // Term Structure Curves
    _goldCurve.value = TermStructureCurve(
      asset = "GOLD",
      points = listOf(
        TermPoint("现货", 0, auQuote, 0.0, 0.0),
        TermPoint("1M", 30, auQuote + 0.65, 0.65, 2.10),
        TermPoint("3M", 90, auQuote + 1.85, 1.85, 2.38),
        TermPoint("6M", 180, auQuote + 3.90, 3.90, 2.52),
        TermPoint("12M", 360, auQuote + 8.10, 8.10, 2.61)
      ),
      curveType = "CONTANGO (升水结构)",
      frontMonthSpread = 0.65,
      updateTime = "09:42:18"
    )

    _silverCurve.value = TermStructureCurve(
      asset = "SILVER",
      points = listOf(
        TermPoint("现货", 0, agQuote, 0.0, 0.0),
        TermPoint("1M", 30, agQuote + 35.0, 35.0, 2.65),
        TermPoint("3M", 90, agQuote + 110.0, 110.0, 2.78),
        TermPoint("6M", 180, agQuote + 235.0, 235.0, 2.97),
        TermPoint("12M", 360, agQuote + 490.0, 490.0, 3.10)
      ),
      curveType = "CONTANGO (升水结构)",
      frontMonthSpread = 35.0,
      updateTime = "09:42:18"
    )

    // Gold / Silver Ratio
    val ratioVal = if (xagUsd > 0) xauUsd / xagUsd else 105.0
    _goldSilverRatio.value = GoldSilverRatioData(
      currentRatio = (ratioVal * 100).roundToInt() / 100.0,
      change1D = -0.42,
      change1W = -1.15,
      change1M = -3.20,
      change1Y = -8.50,
      percentile10Y = 58.2,
      zScore = -0.38,
      historyPoints = listOf(
        Pair("2024", 88.5),
        Pair("2025-Q1", 82.3),
        Pair("2025-Q2", 76.4),
        Pair("2025-Q3", 71.2),
        Pair("2025-Q4", 65.8),
        Pair("2026-Q1", 61.5),
        Pair("2026-Q2", 59.4),
        Pair("现在", (ratioVal * 100).roundToInt() / 100.0)
      )
    )

    // Margin Requirements
    _marginRequirements.value = MarginEngine.getMarginRequirements(auQuote, agQuote)

    // Risk Snapshot
    val port = _portfolio.value
    if (port != null) {
      val stressScenarios = listOf(
        StressScenario("黄金重挫 (-5%) & 白银 (-10%)", "全球避险情绪消退，流动性急速收紧", -5.0, -10.0, 0.5, 30.0),
        StressScenario("美元走强 (USD/CNY +2%)", "外部汇率冲击导致跨市场折算变动", 0.0, 0.0, 2.0, 10.0),
        StressScenario("实际利率大幅飙升 (+50bps)", "美联储超预期鹰派加息预期重燃", -3.5, -6.0, 1.2, 50.0),
        StressScenario("光伏工业需求爆发 (白银 +15%)", "白银现货出现结构性逼仓", 2.0, 15.0, -0.2, -10.0)
      )
      val (riskSnap, stressList) = RiskEngine.calculateRiskSnapshot(port, stressScenarios)
      _riskSnapshot.value = riskSnap
      _stressResults.value = stressList
    }
  }

  private fun updatePortfolioAfterExecution(execution: TradeExecution) {
    val port = _portfolio.value ?: return
    val currentPositions = port.positions.toMutableList()
    val existingIndex = currentPositions.indexOfFirst { it.symbol == execution.symbol }

    val sign = if (execution.side == OrderSide.BUY) 1.0 else -1.0
    val deltaQty = execution.quantity * sign

    if (existingIndex >= 0) {
      val existing = currentPositions[existingIndex]
      val newQty = existing.quantity + deltaQty
      if (abs(newQty) < 0.001) {
        currentPositions.removeAt(existingIndex)
      } else {
        val newAvgCost = if (existing.quantity * deltaQty > 0) {
          (existing.avgCost * existing.quantity + execution.price * deltaQty) / newQty
        } else existing.avgCost

        currentPositions[existingIndex] = existing.copy(
          quantity = newQty,
          avgCost = newAvgCost,
          currentPrice = execution.price
        )
      }
    } else {
      currentPositions.add(
        Position(
          symbol = execution.symbol,
          name = execution.symbol,
          quantity = deltaQty,
          avgCost = execution.price,
          currentPrice = execution.price,
          delta = deltaQty
        )
      )
    }

    val cashDeduction = execution.price * execution.quantity + execution.fee
    val newCash = if (execution.side == OrderSide.BUY) port.cashBalanceCNY - cashDeduction else port.cashBalanceCNY + execution.price * execution.quantity - execution.fee

    val newPositionsVal = currentPositions.sumOf { it.marketValue }
    val newEquity = newCash + newPositionsVal + port.cashBalanceUSD * 7.1284

    _portfolio.value = port.copy(
      totalEquity = newEquity,
      cashBalanceCNY = newCash,
      positions = currentPositions
    )

    recalculateDerivedMetrics()
  }

  private fun generateCandles(symbol: String, timeframe: Timeframe) {
    val basePrice = when {
      symbol.contains("Au") || symbol.contains("XAU") -> 928.45
      symbol.contains("Ag") || symbol.contains("XAG") -> 15821.0
      symbol.contains("USD") -> 7.1284
      else -> 9.12
    }

    val numBars = 60
    val bars = mutableListOf<OHLCVBar>()
    var currentPrice = basePrice * (1.0 - 0.015)
    val nowMs = System.currentTimeMillis()
    val stepMs = timeframe.minutes * 60 * 1000L

    for (i in 0 until numBars) {
      val barTime = nowMs - (numBars - i) * stepMs
      val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(barTime))

      val noise = (random.nextGaussian() * (basePrice * 0.0015))
      val open = currentPrice
      val close = currentPrice + noise + (basePrice * 0.0003) // slight upward trend
      val high = max(open, close) + abs(random.nextGaussian() * (basePrice * 0.0008))
      val low = min(open, close) - abs(random.nextGaussian() * (basePrice * 0.0008))
      val vol = (1000 + random.nextInt(4000)).toLong()

      currentPrice = close

      bars.add(
        OHLCVBar(
          timestamp = barTime,
          timeLabel = timeStr,
          open = (open * 100).roundToInt() / 100.0,
          high = (high * 100).roundToInt() / 100.0,
          low = (low * 100).roundToInt() / 100.0,
          close = (close * 100).roundToInt() / 100.0,
          volume = vol,
          openInterest = 280000 + i * 200L
        )
      )
    }

    // Compute MA5, MA20, VWAP, Bollinger, RSI, MACD
    val computedBars = mutableListOf<OHLCVBar>()
    var sumVol = 0L
    var sumPriceVol = 0.0

    for (i in bars.indices) {
      val bar = bars[i]
      val typical = (bar.high + bar.low + bar.close) / 3.0
      sumVol += bar.volume
      sumPriceVol += typical * bar.volume
      val vwap = if (sumVol > 0) sumPriceVol / sumVol else typical

      val ma5 = if (i >= 4) bars.subList(i - 4, i + 1).map { it.close }.average() else null
      val ma20 = if (i >= 19) bars.subList(i - 19, i + 1).map { it.close }.average() else null

      val bbUpper = if (ma20 != null) ma20 * 1.008 else null
      val bbLower = if (ma20 != null) ma20 * 0.992 else null

      val rsi = 50.0 + sin(i * 0.3) * 18.0
      val macd = sin(i * 0.2) * 1.2
      val macdSignal = macd * 0.8
      val macdHist = macd - macdSignal

      computedBars.add(
        bar.copy(
          vwap = (vwap * 100).roundToInt() / 100.0,
          ma5 = ma5?.let { (it * 100).roundToInt() / 100.0 },
          ma20 = ma20?.let { (it * 100).roundToInt() / 100.0 },
          bbUpper = bbUpper?.let { (it * 100).roundToInt() / 100.0 },
          bbLower = bbLower?.let { (it * 100).roundToInt() / 100.0 },
          rsi = (rsi * 10).roundToInt() / 10.0,
          macd = (macd * 100).roundToInt() / 100.0,
          macdSignal = (macdSignal * 100).roundToInt() / 100.0,
          macdHist = (macdHist * 100).roundToInt() / 100.0
        )
      )
    }

    _candles.value = computedBars
  }

  private fun generateOrderBook(symbol: String) {
    val quote = _quotes.value[symbol] ?: _quotes.value["Au99.99"]
    val last = quote?.last ?: 928.45
    val tick = if (symbol.contains("Ag")) 1.0 else 0.05
    val now = timeFormat.format(Date())

    val asks = mutableListOf<OrderBookLevel>()
    val bids = mutableListOf<OrderBookLevel>()

    var cumAsk = 0L
    for (i in 5 downTo 1) {
      val price = last + i * tick
      val vol = (50 + random.nextInt(250)).toLong()
      cumAsk += vol
      asks.add(
        OrderBookLevel(
          level = i,
          price = (price * 100).roundToInt() / 100.0,
          volume = vol,
          orderCount = 3 + random.nextInt(12),
          cumulativeVolume = cumAsk
        )
      )
    }

    var cumBid = 0L
    for (i in 1..5) {
      val price = last - i * tick
      val vol = (60 + random.nextInt(280)).toLong()
      cumBid += vol
      bids.add(
        OrderBookLevel(
          level = i,
          price = (price * 100).roundToInt() / 100.0,
          volume = vol,
          orderCount = 4 + random.nextInt(15),
          cumulativeVolume = cumBid
        )
      )
    }

    _orderBook.value = OrderBook(
      symbol = symbol,
      timestamp = now,
      bids = bids,
      asks = asks,
      lastPrice = last
    )

    // Generate heatmap cells
    val heatmap = mutableListOf<HeatmapCell>()
    val times = listOf("09:30", "09:33", "09:36", "09:39", "09:42")
    for (t in times) {
      for (i in -4..4) {
        val p = last + i * tick
        val intensity = (0.2f + random.nextFloat() * 0.8f).coerceIn(0.1f, 1.0f)
        heatmap.add(HeatmapCell(t, (p * 100).roundToInt() / 100.0, intensity))
      }
    }
    _orderBookHeatmap.value = heatmap

    // Generate recent trades
    val trades = mutableListOf<TradeItem>()
    for (i in 0 until 12) {
      val dir = if (random.nextBoolean()) TradeDirection.BUY else TradeDirection.SELL
      val price = if (dir == TradeDirection.BUY) last + (random.nextInt(3) * 0.05) else last - (random.nextInt(3) * 0.05)
      val vol = (10 + random.nextInt(150)).toLong()
      trades.add(
        TradeItem(
          tradeId = "T-" + (1000 + i),
          symbol = symbol,
          time = "09:42:" + String.format(Locale.US, "%02d", 50 - i * 3),
          price = (price * 100).roundToInt() / 100.0,
          volume = vol,
          direction = dir,
          isBlock = vol > 100
        )
      )
    }
    _recentTrades.value = trades

    // Block trades
    _blockTrades.value = listOf(
      BlockTrade("BLK-101", symbol, "09:41:22", last, 350, 32.49, 1.8, TradeDirection.BUY, "主力大单主动买入"),
      BlockTrade("BLK-102", symbol, "09:38:05", last - 0.2, 500, 46.41, -2.1, TradeDirection.SELL, "机构仓单对冲抛盘"),
      BlockTrade("BLK-103", symbol, "09:32:40", last + 0.1, 420, 38.99, 1.4, TradeDirection.BUY, "ETF申购现货建仓")
    )
  }

  private fun generateOptionsAndVolSurface() {
    val spot = 928.45
    val strikes = listOf(900.0, 910.0, 920.0, 930.0, 940.0, 950.0, 960.0)
    val contracts = mutableListOf<OptionContract>()

    for (k in strikes) {
      val tYears = 30.0 / 365.0
      val iv = 0.16 + abs(k - spot) * 0.0003 // smile
      val callPrice = BlackScholesEngine.calculateOptionPrice(OptionType.CALL, spot, k, tYears, 0.02, iv)
      val putPrice = BlackScholesEngine.calculateOptionPrice(OptionType.PUT, spot, k, tYears, 0.02, iv)
      val callGreeks = BlackScholesEngine.calculateGreeks(OptionType.CALL, spot, k, tYears, 0.02, iv)
      val putGreeks = BlackScholesEngine.calculateGreeks(OptionType.PUT, spot, k, tYears, 0.02, iv)

      contracts.add(
        OptionContract(
          symbol = "Au2611-C-$k",
          underlyingSymbol = "Au99.99",
          optionType = OptionType.CALL,
          strike = k,
          expiryDate = "2026-11-20",
          daysToExpiry = 30,
          premium = (callPrice * 100).roundToInt() / 100.0,
          impliedVol = (iv * 10000).roundToInt() / 100.0,
          greeks = callGreeks,
          volume = (100 + random.nextInt(400)).toLong(),
          openInterest = 1200
        )
      )

      contracts.add(
        OptionContract(
          symbol = "Au2611-P-$k",
          underlyingSymbol = "Au99.99",
          optionType = OptionType.PUT,
          strike = k,
          expiryDate = "2026-11-20",
          daysToExpiry = 30,
          premium = (putPrice * 100).roundToInt() / 100.0,
          impliedVol = (iv * 10000).roundToInt() / 100.0,
          greeks = putGreeks,
          volume = (80 + random.nextInt(350)).toLong(),
          openInterest = 980
        )
      )
    }

    _optionChain.value = contracts

    // Volatility Surface Grid (Strikes x Expiries)
    val expiries = listOf(7, 30, 60, 90, 180, 360)
    val grid = mutableListOf<List<Double>>()

    for (k in strikes) {
      val row = mutableListOf<Double>()
      for (exp in expiries) {
        val moneyness = abs(k - spot) / spot
        val termEffect = sqrt(exp / 365.0) * 0.02
        val ivVal = (0.155 + moneyness * 0.12 + termEffect) * 100.0
        row.add((ivVal * 10).roundToInt() / 10.0)
      }
      grid.add(row)
    }

    _volSurface.value = VolSurfaceData(
      underlying = "Au99.99 (上海金)",
      strikes = strikes,
      expiries = expiries,
      grid = grid,
      realizedVol5D = 14.8,
      realizedVol20D = 16.2,
      realizedVol60D = 15.7,
      realizedVol250D = 17.1
    )
  }

  private fun startLiveTickEngine() {
    scope.launch(Dispatchers.Default) {
      while (isActive) {
        delay(2000L) // 2s live tick update
        val now = timeFormat.format(Date())
        _currentTimeStr.value = now

        val curMap = _quotes.value.toMutableMap()
        val auQ = curMap["Au99.99"]
        if (auQ != null) {
          val drift = (random.nextGaussian() * 0.08)
          val newLast = max(100.0, auQ.last + drift)
          val newHigh = max(auQ.high, newLast)
          val newLow = min(auQ.low, newLast)
          val newBid = newLast - 0.05
          val newAsk = newLast + 0.05
          val newVol = auQ.volume + (10 + random.nextInt(40)).toLong()

          curMap["Au99.99"] = auQ.copy(
            last = (newLast * 100).roundToInt() / 100.0,
            high = (newHigh * 100).roundToInt() / 100.0,
            low = (newLow * 100).roundToInt() / 100.0,
            bid = (newBid * 100).roundToInt() / 100.0,
            ask = (newAsk * 100).roundToInt() / 100.0,
            volume = newVol,
            timestamp = now
          )
        }

        val agQ = curMap["Ag99.99"]
        if (agQ != null) {
          val drift = (random.nextGaussian() * 2.5)
          val newLast = max(100.0, agQ.last + drift)
          curMap["Ag99.99"] = agQ.copy(
            last = (newLast * 10).roundToInt() / 10.0,
            high = max(agQ.high, newLast),
            low = min(agQ.low, newLast),
            bid = newLast - 5.0,
            ask = newLast + 5.0,
            volume = agQ.volume + (50 + random.nextInt(150)).toLong(),
            timestamp = now
          )
        }

        _quotes.value = curMap
        recalculateDerivedMetrics()

        // Also drift selected orderbook
        val selSym = _selectedSymbol.value
        generateOrderBook(selSym)
      }
    }
  }

  fun generateFullDailyReport(): ResearchReport {
    val dateStr = dateFormat.format(Date())
    val quotesMap = _quotes.value
    val auQuote = quotesMap["Au99.99"]?.last ?: 928.42
    val agQuote = quotesMap["Ag99.99"]?.last ?: 15821.0
    val premium = _chinaGoldPremium.value?.premiumAmount ?: 2.41
    val ratio = _goldSilverRatio.value?.currentRatio ?: 58.74

    return ResearchReport(
      reportId = "HUAGOLD-DAILY-" + System.currentTimeMillis().toString().takeLast(6),
      title = "华金贵金属日报 (HUAGOLD DAILY PRECIOUS METALS DISPATCH)",
      date = dateStr,
      executiveSummary = "今日中国贵金属市场整体呈现【在岸现货溢价稳固、白银工业需求偏强、金银比持续收敛】的运行格局。国内Au99.99报价于 ¥${String.format(Locale.US, "%.2f", auQuote)}/克 附近高位震荡，在岸黄金基差录得 +${String.format(Locale.US, "%.2f", premium)} 元/克；白银受光伏TOPCon及HJT排产用银支撑，Ag99.99报 ¥${String.format(Locale.US, "%.0f", agQuote)}/千克，金银比收窄至 ${String.format(Locale.US, "%.2f", ratio)}。",
      goldMarketSection = "【黄金市场分析】\n" +
          "• 上金所早午盘定价稳定，基准价与连续竞价价差平稳，现货交割出库维持高位。\n" +
          "• 期限结构呈温和升水（Contango），12个月远期升水约 +8.10 元/克 (年化约 2.61%)，反映国内资金利率与持仓利息处于均衡区间。\n" +
          "• 银行间黄金租借利率 3M 维持在 2.15%，国内现货实物流动性良好。",
      silverMarketSection = "【白银市场与工业属性】\n" +
          "• 白银受工业周期与绿色新能源需求双重驱动，上期所白银仓单降至近五年低位。\n" +
          "• 光伏行业银浆耗量同比录得双位数增长，白银现货升水结构稳固，跨市场溢价保持健康水平。",
      fxBasisSection = "【汇率与在岸溢价研究】\n" +
          "• 美元兑在岸人民币即期运行于 7.1284，离在岸汇差狭窄。\n" +
          "• 国际黄金折算理论人民币金价与国内实盘现货之间形成约 0.26% 的正溢价，进口套利窗口受批文额度限制呈现结构性抗跌特征。",
      termStructureSection = "【期限结构与基差对冲】\n" +
          "• 远月合约升水温和，期现套利资金滚动成本处于历史 35% 分位数低位，适宜产业客户进行远期采购锁价与库存对冲。",
      volatilitySection = "【期权与隐含波动率】\n" +
          "• 黄金平值期权 30D 隐含波动率 (IV) 约为 16.2%，较20日历史波动率存在适度风险溢价；波动率偏斜（Skew）显示虚值看涨期权认购意愿强于看跌期权。",
      etfFlowSection = "【ETF与资金流向】\n" +
          "• 国内四大黄金ETF近一周呈现净流入态势，合计新增持仓约 3.2 吨；全球央行官方黄金储备结构性增持仍在持续。",
      macroRiskSection = "【宏观情景与风险提示】\n" +
          "• 核心关注：美联储议息会议点阵图指引、非农就业数据与实际利率再定价；\n" +
          "• 风险提示：若美元指数出现阶段性脉冲反弹，需警惕高位获利盘平仓带来的短线脉冲波动。",
      conclusionRecommendation = "【策略观点与配置建议】\n" +
          "• 维持多头底仓配置建议，在岸现货黄金逢回调关注结构性支撑；\n" +
          "• 工业属性支撑下金银比仍有压缩空间，可关注跨品种金银比值套利与基差套保机会。"
    )
  }
}
