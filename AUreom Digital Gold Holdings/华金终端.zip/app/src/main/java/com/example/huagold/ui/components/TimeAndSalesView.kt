package com.example.huagold.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.BlockTrade
import com.example.huagold.domain.model.TradeDirection
import com.example.huagold.domain.model.TradeItem
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TimeAndSalesView(
  trades: List<TradeItem>,
  blockTrades: List<BlockTrade> = emptyList(),
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
      .testTag("time_and_sales_view")
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "TIME & SALES / 逐笔成交明细",
        color = GoldAccent,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )
      Text(
        "最新 ${trades.size} 笔",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Table Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 2.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("时间", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
      Text("价格", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
      Text("数量(手)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(50.dp))
      Text("方向", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(48.dp))
    }

    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
      trades.take(8).forEach { item ->
        val dirColor = when (item.direction) {
          TradeDirection.BUY -> QuoteUpRed
          TradeDirection.SELL -> QuoteDownGreen
          TradeDirection.NEUTRAL -> QuoteNeutral
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(if (item.isBlock) Color(0x1AF59E0B) else Color.Transparent)
            .padding(vertical = 1.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            item.time,
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(55.dp)
          )
          Text(
            String.format(Locale.US, "%.2f", item.price),
            color = dirColor,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(65.dp)
          )
          Text(
            "${item.volume}",
            color = if (item.isBlock) GoldAccent else TextWhite,
            fontWeight = if (item.isBlock) FontWeight.Bold else FontWeight.Normal,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(50.dp)
          )
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(2.dp))
              .background(dirColor.copy(alpha = 0.15f))
              .padding(horizontal = 4.dp, vertical = 1.dp)
          ) {
            Text(
              item.direction.label,
              color = dirColor,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    if (blockTrades.isNotEmpty()) {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        "BLOCK TRADE MONITOR / 大单监控",
        color = CyanAccent,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))

      blockTrades.forEach { blk ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                blk.time,
                color = TextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                blk.type,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
              )
            }
            Text(
              "金额: ¥${String.format(Locale.US, "%.2f", blk.amountWan)}万 (${blk.volume}手) @ ${String.format(Locale.US, "%.2f", blk.price)}",
              color = TextWhite,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace
            )
          }

          Text(
            "冲击: ${if (blk.priceImpactBps >= 0) "+" else ""}${blk.priceImpactBps}bps",
            color = if (blk.priceImpactBps >= 0) QuoteUpRed else QuoteDownGreen,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
