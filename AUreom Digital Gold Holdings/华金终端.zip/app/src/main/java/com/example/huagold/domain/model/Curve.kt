package com.example.huagold.domain.model

data class TermPoint(
  val tenor: String, // e.g. "现货", "1M", "3M", "6M", "12M"
  val days: Int,
  val price: Double,
  val basisToSpot: Double,
  val annualizedRate: Double // %
)

data class TermStructureCurve(
  val asset: String, // "GOLD" or "SILVER"
  val points: List<TermPoint>,
  val curveType: String, // "CONTANGO" or "BACKWARDATION"
  val frontMonthSpread: Double,
  val updateTime: String
)

data class GoldSilverRatioData(
  val currentRatio: Double,
  val change1D: Double,
  val change1W: Double,
  val change1M: Double,
  val change1Y: Double,
  val percentile10Y: Double, // e.g. 78.4%
  val zScore: Double, // e.g. +1.45
  val historyPoints: List<Pair<String, Double>> // Date to Ratio
)

data class ChinaPremiumData(
  val symbol: String, // e.g. "XAU/CNY"
  val domesticPrice: Double, // e.g. 928.45 (CNY/g)
  val internationalPriceUSD: Double, // e.g. 4058.20 (USD/oz)
  val usdCnyRate: Double, // e.g. 7.1284
  val theoreticalCnyPrice: Double, // e.g. 930.01 (CNY/g)
  val premiumAmount: Double, // domestic - theoretical
  val premiumPercent: Double, // %
  val historicalMean: Double,
  val zScore: Double,
  val percentile: Double
)
