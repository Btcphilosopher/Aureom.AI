package com.example.huagold.domain.model

enum class OptionType {
  CALL, PUT
}

data class Greeks(
  val delta: Double,
  val gamma: Double,
  val theta: Double,
  val vega: Double,
  val rho: Double
)

data class OptionContract(
  val symbol: String,
  val underlyingSymbol: String,
  val optionType: OptionType,
  val strike: Double,
  val expiryDate: String,
  val daysToExpiry: Int,
  val premium: Double,
  val impliedVol: Double, // in %
  val greeks: Greeks,
  val volume: Long,
  val openInterest: Long
)

data class VolSurfacePoint(
  val strike: Double,
  val expiryDays: Int,
  val impliedVol: Double
)

data class VolSurfaceData(
  val underlying: String,
  val strikes: List<Double>,
  val expiries: List<Int>, // days e.g. 7, 30, 60, 90, 180, 360
  val grid: List<List<Double>>, // matrix of IVs
  val realizedVol5D: Double,
  val realizedVol20D: Double,
  val realizedVol60D: Double,
  val realizedVol250D: Double
)
