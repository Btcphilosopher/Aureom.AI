package com.example.huagold.engine

import java.math.BigDecimal
import java.math.RoundingMode

object UnitConversionEngine {
  // Constant defined by standard international metric convention: 1 troy ounce = 31.1034768 grams
  const val TROY_OUNCE_TO_GRAMS = 31.1034768
  val TROY_OZ_BIGDECIMAL: BigDecimal = BigDecimal.valueOf(31.1034768)

  /**
   * Calculates theoretical CNY gold price per gram from international USD/oz and USD/CNY exchange rate.
   * Formula: USD/oz * USD/CNY / 31.1034768
   */
  fun calculateTheoreticalCnyGoldPerGram(usdPerOz: Double, usdCnyRate: Double): Double {
    if (usdPerOz <= 0 || usdCnyRate <= 0) return 0.0
    val usdDec = BigDecimal.valueOf(usdPerOz)
    val fxDec = BigDecimal.valueOf(usdCnyRate)
    val theoretical = usdDec.multiply(fxDec).divide(TROY_OZ_BIGDECIMAL, 6, RoundingMode.HALF_UP)
    return theoretical.toDouble()
  }

  /**
   * Calculates theoretical CNY silver price per kilogram from international USD/oz and USD/CNY exchange rate.
   * Formula: (USD/oz * USD/CNY / 31.1034768) * 1000
   */
  fun calculateTheoreticalCnySilverPerKg(usdPerOz: Double, usdCnyRate: Double): Double {
    val perGram = calculateTheoreticalCnyGoldPerGram(usdPerOz, usdCnyRate)
    return perGram * 1000.0
  }

  /**
   * Calculates China Gold Basis Spread (Shanghai Gold - Theoretical CNY Gold)
   */
  fun calculateChinaGoldBasis(shanghaiGoldCnyPerGram: Double, theoreticalCnyPerGram: Double): Double {
    return shanghaiGoldCnyPerGram - theoreticalCnyPerGram
  }

  /**
   * Calculates Gold / Silver Ratio
   */
  fun calculateGoldSilverRatio(goldPrice: Double, silverPrice: Double): Double {
    return if (silverPrice > 0) goldPrice / silverPrice else 0.0
  }
}
