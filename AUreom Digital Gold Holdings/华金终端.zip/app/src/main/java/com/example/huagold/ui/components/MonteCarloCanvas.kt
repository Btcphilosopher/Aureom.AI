package com.example.huagold.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.MonteCarloResult
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.max

@Composable
fun MonteCarloCanvas(
  result: MonteCarloResult?,
  modifier: Modifier = Modifier
) {
  if (result == null || result.pathDistributionBuckets.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(180.dp)
        .background(TerminalSurface),
      contentAlignment = Alignment.Center
    ) {
      Text("暂无蒙特卡洛模拟数据", color = TextMuted, fontSize = 12.sp)
    }
    return
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          "MONTE CARLO SIMULATION (${result.numPaths} 路径)",
          color = GoldAccent,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "期限: ${result.timeHorizonDays}天",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Text(
        "中位数: ¥${String.format(Locale.US, "%.2f", result.medianPrice)}",
        color = CyanAccent,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Key Percentiles Strip
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalSurfaceVariant)
        .padding(horizontal = 6.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("1% 极值下行: ¥${result.percentile1st}", color = QuoteUpRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
      Text("5% VaR: ¥${result.percentile5th}", color = StatusWarning, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("95% 上行: ¥${result.percentile95th}", color = QuoteDownGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("99% 极值上行: ¥${result.percentile99th}", color = StatusLive, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Distribution Histogram Canvas
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
    ) {
      val w = size.width
      val h = size.height

      val buckets = result.pathDistributionBuckets
      if (buckets.isEmpty()) return@Canvas

      val maxCount = max(1, buckets.maxOf { it.second }).toFloat()
      val slotW = w / buckets.size
      val barW = max(2f, slotW * 0.8f)

      buckets.forEachIndexed { i, b ->
        val x = i * slotW
        val barH = (b.second / maxCount) * (h * 0.85f)
        val y = h - barH

        // Color based on percentile range
        val color = when {
          b.first <= result.percentile1st -> QuoteUpRed
          b.first <= result.percentile5th -> StatusWarning
          b.first >= result.percentile95th -> QuoteDownGreen
          else -> GoldPrimary.copy(alpha = 0.75f)
        }

        drawRect(
          color = color,
          topLeft = Offset(x + (slotW - barW) / 2f, y),
          size = Size(barW, barH)
        )
      }

      // Median Line
      val medianIdx = buckets.indexOfFirst { it.first >= result.medianPrice }.coerceAtLeast(0)
      val medX = medianIdx * slotW + slotW / 2f
      drawLine(
        color = TextWhite,
        start = Offset(medX, 0f),
        end = Offset(medX, h),
        strokeWidth = 1.5f
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Bottom Axis
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        "¥${result.pathDistributionBuckets.firstOrNull()?.first ?: ""}",
        color = TextMuted,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
      Text(
        "价格分布 (尾部风险区间标红)",
        color = TextMuted,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
      Text(
        "¥${result.pathDistributionBuckets.lastOrNull()?.first ?: ""}",
        color = TextMuted,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
