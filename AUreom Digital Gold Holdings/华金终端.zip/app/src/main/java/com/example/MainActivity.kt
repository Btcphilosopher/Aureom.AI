package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.huagold.data.MarketRepository
import com.example.huagold.ui.components.CommandBarDialog
import com.example.huagold.ui.components.TerminalTopBar
import com.example.huagold.ui.screens.*
import com.example.ui.theme.*

data class NavigationTabItem(
  val title: String,
  val icon: ImageVector,
  val english: String
)

class MainActivity : ComponentActivity() {

  private lateinit var repository: MarketRepository

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    repository = MarketRepository(lifecycleScope)

    setContent {
      MyApplicationTheme {
        HuagoldTerminalApp(repository = repository)
      }
    }
  }
}

@Composable
fun HuagoldTerminalApp(repository: MarketRepository) {
  var selectedTab by remember { mutableStateOf(0) }
  var showCommandBar by remember { mutableStateOf(false) }

  val timeStr by repository.currentTimeStr.collectAsState()
  val marketStatus by repository.marketStatus.collectAsState()

  // Handle Android hardware/gesture back button: return to Market Overview if on sub-screen
  BackHandler(enabled = selectedTab != 0) {
    selectedTab = 0
  }

  val navTabs = remember {
    listOf(
      NavigationTabItem("市场", Icons.Default.Dashboard, "MARKET"),
      NavigationTabItem("行情", Icons.Default.ShowChart, "QUOTES"),
      NavigationTabItem("交易", Icons.Default.AccountBalanceWallet, "TRADE/OMS"),
      NavigationTabItem("曲线", Icons.Default.AutoGraph, "CURVES"),
      NavigationTabItem("期权", Icons.Default.BlurOn, "OPTIONS"),
      NavigationTabItem("研究", Icons.Default.Science, "RESEARCH"),
      NavigationTabItem("风控", Icons.Default.Shield, "RISK"),
      NavigationTabItem("智能", Icons.Default.Psychology, "AI/NEWS"),
      NavigationTabItem("报告", Icons.Default.Description, "REPORT")
    )
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .windowInsetsPadding(WindowInsets.safeDrawing),
    topBar = {
      TerminalTopBar(
        timeStr = timeStr,
        marketStatus = marketStatus,
        onOpenCommandBar = { showCommandBar = true },
        onTriggerShock = { shockType -> repository.triggerMacroShock(shockType) }
      )
    },
    bottomBar = {
      // Primary Terminal Navigation Bar
      Surface(
        color = TerminalSurface,
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          itemsIndexed(navTabs) { index, tab ->
            val isSelected = selectedTab == index
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(if (isSelected) GoldMuted else TerminalSurfaceVariant)
                .border(
                  1.dp,
                  if (isSelected) GoldPrimary else TerminalBorderSubtle,
                  RoundedCornerShape(4.dp)
                )
                .clickable { selectedTab = index }
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("nav_tab_$index"),
              contentAlignment = Alignment.Center
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  tab.icon,
                  contentDescription = tab.title,
                  tint = if (isSelected) GoldAccent else TextGray,
                  modifier = Modifier.size(13.dp)
                )
                Column {
                  Text(
                    tab.title,
                    color = if (isSelected) GoldAccent else TextWhite,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                  Text(
                    tab.english,
                    color = if (isSelected) GoldPrimary else TextMuted,
                    fontSize = 7.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(TerminalBg)
    ) {
      when (selectedTab) {
        0 -> MarketOverviewScreen(
          repository = repository,
          onNavigateToTrading = { symbol ->
            repository.selectSymbol(symbol)
            selectedTab = 1
          },
          onNavigateToCurves = { selectedTab = 3 },
          onNavigateToRisk = { selectedTab = 6 }
        )
        1 -> TradingTerminalScreen(
          repository = repository,
          onNavigateToPortfolio = { selectedTab = 2 }
        )
        2 -> OmsPortfolioScreen(
          repository = repository,
          onSelectInstrument = { symbol ->
            repository.selectSymbol(symbol)
            selectedTab = 1
          }
        )
        3 -> CurvesBasisRatioScreen(repository = repository)
        4 -> OptionsLabScreen(repository = repository)
        5 -> ResearchMacroScreen(repository = repository)
        6 -> RiskControlScreen(repository = repository)
        7 -> NewsAndAIScreen(repository = repository)
        8 -> ReportScreen(repository = repository)
      }
    }
  }

  // Fast Command Bar Modal
  if (showCommandBar) {
    CommandBarDialog(
      onDismiss = { showCommandBar = false },
      onExecuteCommand = { cmd ->
        cmd.symbolToSelect?.let { repository.selectSymbol(it) }
        cmd.tabIndex?.let { selectedTab = it }
      }
    )
  }
}
