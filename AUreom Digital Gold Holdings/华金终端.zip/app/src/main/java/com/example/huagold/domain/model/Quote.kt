package com.example.huagold.domain.model

data class Quote(
  val symbol: String,
  val market: String,
  val instrument: String,
  val bid: Double,
  val ask: Double,
  val last: Double,
  val open: Double,
  val high: Double,
  val low: Double,
  val prevClose: Double,
  val volume: Long,
  val openInterest: Long = 0,
  val turnover: Double = 0.0,
  val timestamp: String,
  val currency: String = "CNY",
  val unit: String = "元/克",
  val dataStatus: DataStatus = DataStatus.SYNTHETIC,
  val venue: Venue = Venue.SGE
) {
  val change: Double get() = last - prevClose
  val changePercent: Double get() = if (prevClose > 0) ((last - prevClose) / prevClose) * 100.0 else 0.0
  val spread: Double get() = ask - bid
}
