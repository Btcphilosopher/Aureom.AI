package com.example.huagold.engine

import com.example.huagold.domain.model.*
import kotlin.math.abs

object RiskEngine {

  /**
   * Computes risk metrics for the portfolio
   */
  fun calculateRiskSnapshot(
    portfolio: PortfolioSummary,
    stressScenarios: List<StressScenario>
  ): Pair<RiskSnapshot, List<StressResult>> {
    val totalVal = portfolio.totalEquity
    var goldDelta = 0.0
    var silverDelta = 0.0

    for (pos in portfolio.positions) {
      if (pos.symbol.contains("Au") || pos.symbol.contains("XAU") || pos.symbol.contains("Gold")) {
        goldDelta += pos.quantity * pos.contractMultiplier
      } else if (pos.symbol.contains("Ag") || pos.symbol.contains("XAG") || pos.symbol.contains("Silver")) {
        silverDelta += pos.quantity * pos.contractMultiplier
      }
    }

    // 1-Day 99% Parametric VaR approx (Z = 2.33, daily vol = 1.05%)
    val dailyVol = 0.0105
    val var1D = totalVal * 2.33 * dailyVol
    val es99 = var1D * 1.15 // Expected Shortfall
    
    // FX exposure
    val fxExposure = portfolio.cashBalanceUSD * 7.1284

    val stressResults = stressScenarios.map { scenario ->
      val goldPnL = goldDelta * 928.45 * (scenario.goldPriceChangePct / 100.0)
      val silverPnL = silverDelta * 15.82 * (scenario.silverPriceChangePct / 100.0)
      val fxPnL = fxExposure * (scenario.usdCnyChangePct / 100.0)
      val yieldEffect = scenario.realYieldChangeBps * -1200.0 // higher yield hurts gold

      val totalLoss = goldPnL + silverPnL + fxPnL + yieldEffect
      val lossPct = if (totalVal > 0) (abs(totalLoss) / totalVal) * 100.0 else 0.0
      val isMarginCall = totalLoss < -portfolio.marginAvailable

      StressResult(
        scenarioName = scenario.name,
        estimatedPnLLoss = totalLoss,
        lossPercentOfEquity = lossPct,
        goldPnL = goldPnL,
        silverPnL = silverPnL,
        fxPnL = fxPnL,
        marginCallRisk = isMarginCall
      )
    }

    val maxStressLoss = stressResults.maxOfOrNull { abs(it.estimatedPnLLoss) } ?: (var1D * 2.5)

    val snapshot = RiskSnapshot(
      totalPortfolioValue = totalVal,
      goldDeltaGrams = goldDelta,
      silverDeltaGrams = silverDelta,
      fxExposureCNY = fxExposure,
      basisExposureCNY = goldDelta * 1.56,
      var1D99Percent = var1D,
      expectedShortfall99Percent = es99,
      stressLossEstimated = maxStressLoss,
      liquidityStatus = if (portfolio.cashBalanceCNY > totalVal * 0.2) "HIGH" else "MODERATE",
      riskLevel = if (portfolio.marginUsed / maxOf(1.0, portfolio.totalEquity) > 0.6) "ELEVATED" else "NORMAL",
      marginUtilizationPercent = (portfolio.marginUsed / maxOf(1.0, portfolio.totalEquity)) * 100.0,
      timestamp = "2026-10-07 09:42:18"
    )

    return Pair(snapshot, stressResults)
  }
}
