package com.example.huagold.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.OHLCVBar
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

enum class SubChartIndicator(val label: String) {
  VOL("成交量"),
  VWAP_DEV("VWAP偏离"),
  RSI("RSI (14)"),
  MACD("MACD (12,26,9)")
}

@Composable
fun MarketChartCanvas(
  bars: List<OHLCVBar>,
  modifier: Modifier = Modifier,
  selectedIndicator: SubChartIndicator = SubChartIndicator.VOL
) {
  if (bars.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(280.dp)
        .background(TerminalSurface),
      contentAlignment = Alignment.Center
    ) {
      Text("暂无K线数据", color = TextMuted, fontSize = 12.sp)
    }
    return
  }

  var scrubIndex by remember { mutableStateOf<Int?>(null) }

  val activeBar = scrubIndex?.let { if (it in bars.indices) bars[it] else bars.last() } ?: bars.last()

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Top Legend & Scrub Info
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          activeBar.timeLabel,
          color = GoldAccent,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "开: ${String.format(Locale.US, "%.2f", activeBar.open)}",
          color = TextGray,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "高: ${String.format(Locale.US, "%.2f", activeBar.high)}",
          color = QuoteUpRed,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "低: ${String.format(Locale.US, "%.2f", activeBar.low)}",
          color = QuoteDownGreen,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          "收: ${String.format(Locale.US, "%.2f", activeBar.close)}",
          color = if (activeBar.close >= activeBar.open) QuoteUpRed else QuoteDownGreen,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Second legend line: VWAP, MA5, MA20, Vol
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "VWAP: ${String.format(Locale.US, "%.2f", activeBar.vwap)}",
        color = GoldPrimary,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
      activeBar.ma5?.let {
        Text(
          "MA5: ${String.format(Locale.US, "%.2f", it)}",
          color = CyanAccent,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
      activeBar.ma20?.let {
        Text(
          "MA20: ${String.format(Locale.US, "%.2f", it)}",
          color = IndigoAccent,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
      Text(
        "量: ${activeBar.volume}",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Main Canvas: Main Candlestick Chart (Top 70%) and Sub Chart (Bottom 30%)
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(230.dp)
        .pointerInput(bars) {
          detectTapGestures(
            onPress = { offset ->
              val totalBars = bars.size
              val barSlotWidth = size.width / totalBars
              val idx = (offset.x / barSlotWidth).toInt().coerceIn(0, totalBars - 1)
              scrubIndex = idx
            }
          )
        }
        .pointerInput(bars) {
          detectDragGestures(
            onDragStart = { offset ->
              val totalBars = bars.size
              val barSlotWidth = size.width / totalBars
              val idx = (offset.x / barSlotWidth).toInt().coerceIn(0, totalBars - 1)
              scrubIndex = idx
            },
            onDragEnd = { scrubIndex = null },
            onDragCancel = { scrubIndex = null },
            onDrag = { change, _ ->
              val totalBars = bars.size
              val barSlotWidth = size.width / totalBars
              val idx = (change.position.x / barSlotWidth).toInt().coerceIn(0, totalBars - 1)
              scrubIndex = idx
            }
          )
        }
    ) {
      val w = size.width
      val h = size.height
      val mainHeight = h * 0.70f
      val subHeight = h * 0.26f
      val subTop = h * 0.74f

      val n = bars.size
      if (n == 0) return@Canvas

      var minP = bars.minOf { it.low }
      var maxP = bars.maxOf { it.high }
      if (maxP == minP) {
        maxP += 1.0
        minP -= 1.0
      }
      val pRange = maxP - minP

      val maxVol = max(1L, bars.maxOf { it.volume })

      val slotWidth = w / n
      val candleWidth = max(2f, slotWidth * 0.65f)

      // 1. Grid Lines on Main Chart
      val gridLines = 4
      for (g in 0..gridLines) {
        val y = (mainHeight / gridLines) * g
        drawLine(
          color = TerminalBorderSubtle,
          start = Offset(0f, y),
          end = Offset(w, y),
          strokeWidth = 1f
        )
      }
      // Grid line separating main and sub chart
      drawLine(
        color = TerminalBorder,
        start = Offset(0f, subTop),
        end = Offset(w, subTop),
        strokeWidth = 1.5f
      )

      // 2. Plot MA & VWAP paths
      val vwapPath = Path()
      val ma5Path = Path()
      val ma20Path = Path()
      var vwapStarted = false
      var ma5Started = false
      var ma20Started = false

      for (i in 0 until n) {
        val bar = bars[i]
        val centerX = i * slotWidth + slotWidth / 2f
        val vwapY = mainHeight - ((bar.vwap - minP) / pRange).toFloat() * mainHeight

        if (!vwapStarted) {
          vwapPath.moveTo(centerX, vwapY)
          vwapStarted = true
        } else {
          vwapPath.lineTo(centerX, vwapY)
        }

        bar.ma5?.let {
          val ma5Y = mainHeight - ((it - minP) / pRange).toFloat() * mainHeight
          if (!ma5Started) {
            ma5Path.moveTo(centerX, ma5Y)
            ma5Started = true
          } else {
            ma5Path.lineTo(centerX, ma5Y)
          }
        }

        bar.ma20?.let {
          val ma20Y = mainHeight - ((it - minP) / pRange).toFloat() * mainHeight
          if (!ma20Started) {
            ma20Path.moveTo(centerX, ma20Y)
            ma20Started = true
          } else {
            ma20Path.lineTo(centerX, ma20Y)
          }
        }
      }

      // Draw Candlesticks & Sub Chart bars
      for (i in 0 until n) {
        val bar = bars[i]
        val centerX = i * slotWidth + slotWidth / 2f
        val isUp = bar.close >= bar.open
        val candleColor = if (isUp) QuoteUpRed else QuoteDownGreen

        // Y Coordinates
        val highY = mainHeight - ((bar.high - minP) / pRange).toFloat() * mainHeight
        val lowY = mainHeight - ((bar.low - minP) / pRange).toFloat() * mainHeight
        val openY = mainHeight - ((bar.open - minP) / pRange).toFloat() * mainHeight
        val closeY = mainHeight - ((bar.close - minP) / pRange).toFloat() * mainHeight

        val bodyTop = min(openY, closeY)
        val bodyBottom = max(openY, closeY)
        val bodyHeight = max(1.5f, bodyBottom - bodyTop)

        // Wick
        drawLine(
          color = candleColor,
          start = Offset(centerX, highY),
          end = Offset(centerX, lowY),
          strokeWidth = 1.2f
        )

        // Candle Body
        drawRect(
          color = candleColor,
          topLeft = Offset(centerX - candleWidth / 2f, bodyTop),
          size = Size(candleWidth, bodyHeight)
        )

        // Sub Chart Rendering
        when (selectedIndicator) {
          SubChartIndicator.VOL -> {
            val volH = (bar.volume.toFloat() / maxVol.toFloat()) * subHeight
            val volTop = h - volH
            drawRect(
              color = if (isUp) QuoteUpRed.copy(alpha = 0.6f) else QuoteDownGreen.copy(alpha = 0.6f),
              topLeft = Offset(centerX - candleWidth / 2f, volTop),
              size = Size(candleWidth, volH)
            )
          }
          SubChartIndicator.MACD -> {
            val hist = bar.macdHist ?: 0.0
            val midY = subTop + subHeight / 2f
            val histH = (hist / 2.0).toFloat() * (subHeight / 2f)
            val top = if (hist >= 0) midY - histH else midY
            drawRect(
              color = if (hist >= 0) QuoteUpRed else QuoteDownGreen,
              topLeft = Offset(centerX - candleWidth / 2f, top),
              size = Size(candleWidth, kotlin.math.abs(histH))
            )
          }
          SubChartIndicator.RSI -> {
            // Drawn as path later or point
          }
          SubChartIndicator.VWAP_DEV -> {
            val dev = if (bar.vwap > 0) ((bar.close - bar.vwap) / bar.vwap) * 10000.0 else 0.0
            val midY = subTop + subHeight / 2f
            val devH = (dev / 50.0).toFloat() * (subHeight / 2f)
            val top = if (dev >= 0) midY - devH else midY
            drawRect(
              color = if (dev >= 0) GoldPrimary else CyanAccent,
              topLeft = Offset(centerX - candleWidth / 2f, top),
              size = Size(candleWidth, kotlin.math.abs(devH))
            )
          }
        }
      }

      // Draw Lines
      drawPath(vwapPath, color = GoldPrimary, style = Stroke(width = 1.8f))
      drawPath(ma5Path, color = CyanAccent, style = Stroke(width = 1.2f))
      drawPath(ma20Path, color = IndigoAccent, style = Stroke(width = 1.2f))

      // Crosshair if scrubbed
      scrubIndex?.let { sIdx ->
        if (sIdx in bars.indices) {
          val crossX = sIdx * slotWidth + slotWidth / 2f
          val sBar = bars[sIdx]
          val crossY = mainHeight - ((sBar.close - minP) / pRange).toFloat() * mainHeight

          // Vertical cross line
          drawLine(
            color = TextWhite.copy(alpha = 0.8f),
            start = Offset(crossX, 0f),
            end = Offset(crossX, h),
            strokeWidth = 1f
          )

          // Horizontal cross line
          drawLine(
            color = TextWhite.copy(alpha = 0.8f),
            start = Offset(0f, crossY),
            end = Offset(w, crossY),
            strokeWidth = 1f
          )

          // Price Tag circle
          drawCircle(
            color = GoldPrimary,
            radius = 4f,
            center = Offset(crossX, crossY)
          )
        }
      }
    }
  }
}
