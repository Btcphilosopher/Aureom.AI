package com.example.huagold.engine

import com.example.huagold.domain.model.FactorSensitivity
import com.example.huagold.domain.model.MacroModelAnalysis

object GoldMacroModelEngine {

  fun getGoldMacroModel(): MacroModelAnalysis {
    val factors = listOf(
      FactorSensitivity("US 10Y Real Yield (美债实际收益率)", -0.42, -6.84, 0.38, "实际利率与无息贵金属持有成本显著负相关"),
      FactorSensitivity("DXY Index (美元指数)", -0.31, -5.12, 0.24, "美元走强压制全球大宗定价"),
      FactorSensitivity("USD/CNY Rate (美元兑在岸人民币)", 0.28, 4.35, 0.18, "人民币汇率贬值提升国内人民币计价黄金折算溢价"),
      FactorSensitivity("PBOC Gold Purchases (央行净购金)", 0.19, 3.42, 0.11, "官方储备结构多元化提供结构性买盘支撑"),
      FactorSensitivity("China Gold ETF Flow (国内ETF净申购)", 0.15, 2.91, 0.08, "在岸投资与避险资金配置偏好"),
      FactorSensitivity("Geopolitical & Market Volatility (地缘与风险偏好)", 0.12, 2.15, 0.05, "避险溢价与尾部对冲需求")
    )

    return MacroModelAnalysis(
      modelId = "HUAGOLD-MACRO-REGRESSION-V3.7",
      targetAsset = "XAU/CNY",
      factors = factors,
      rSquaredTotal = 0.814,
      currentRegime = "降息周期初段 + 去美元化官方购金 + 在岸溢价扩张",
      keyTakeaway = "当前人民币金价对【实际利率下行】与【人民币汇率汇率因子】敏感度最高，宏观多头动能仍保持在80分位数区间。"
    )
  }

  fun getSilverIndustrialModel(): MacroModelAnalysis {
    val factors = listOf(
      FactorSensitivity("Photovoltaic / Solar Demand (光伏电池银浆需求)", 0.38, 5.92, 0.32, "TopCon/HJT高效电池片单瓦耗银提升"),
      FactorSensitivity("Gold Beta (黄金联动因子)", 0.44, 7.10, 0.39, "贵金属货币属性强协同"),
      FactorSensitivity("Copper / LME Base Metals (铜价/基本金属)", 0.22, 3.80, 0.15, "全球制造业景气与工业周期共振"),
      FactorSensitivity("Electronics & EV Power (新能源车与半导体)", 0.16, 2.65, 0.09, "电气化与功率器件工业消费"),
      FactorSensitivity("USD Index (美元指数)", -0.21, -3.20, 0.11, "宏观计价与流动性折现")
    )

    return MacroModelAnalysis(
      modelId = "HUAGOLD-SILVER-IND-V3.7",
      targetAsset = "XAG/CNY",
      factors = factors,
      rSquaredTotal = 0.789,
      currentRegime = "光伏工业强韧性 + 白银现货流动性紧平衡",
      keyTakeaway = "白银工业属性（光伏与电气化）贡献了近40%的定价方差，金银比受工业修复预期推动存在收敛压力。"
    )
  }
}
