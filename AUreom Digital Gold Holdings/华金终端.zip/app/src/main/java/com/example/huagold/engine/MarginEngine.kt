package com.example.huagold.engine

import com.example.huagold.domain.model.MarginRequirement

object MarginEngine {

  /**
   * Versioned SGE Dynamic Margin Rules (e.g. SGE-2026-V3 rulebook)
   * Calculates contract nominal value and margin requirements for deferral contracts Au(T+D), Ag(T+D), etc.
   */
  fun getMarginRequirements(
    auPrice: Double,
    agPrice: Double,
    isHighVolEnvironment: Boolean = false
  ): List<MarginRequirement> {
    // SGE Au(T+D): 1000 grams/lot
    val auMarginRatio = if (isHighVolEnvironment) 0.14 else 0.11
    val auLotSize = 1000.0
    val auMarginPerLot = auPrice * auLotSize * auMarginRatio

    // SGE Ag(T+D): 15 kg/lot, 1kg = 1000g, so 15,000g per lot, Ag price in 元/千克
    val agMarginRatio = if (isHighVolEnvironment) 0.17 else 0.13
    val agLotSizeKg = 15.0
    val agMarginPerLot = agPrice * agLotSizeKg * agMarginRatio

    // Au99.99 spot (100% full payment for physical spot)
    val spotMarginPerLot = auPrice * 1000.0

    return listOf(
      MarginRequirement(
        contractSymbol = "Au(T+D)",
        contractName = "黄金延期交收",
        currentPrice = auPrice,
        contractSize = auLotSize,
        marginRatio = auMarginRatio,
        marginPerLot = auMarginPerLot,
        dailyLimitPercent = if (isHighVolEnvironment) 12.0 else 9.0,
        volatilityRuleVersion = "SGE-2026-V3.2"
      ),
      MarginRequirement(
        contractSymbol = "Ag(T+D)",
        contractName = "白银延期交收",
        currentPrice = agPrice,
        contractSize = agLotSizeKg,
        marginRatio = agMarginRatio,
        marginPerLot = agMarginPerLot,
        dailyLimitPercent = if (isHighVolEnvironment) 15.0 else 11.0,
        volatilityRuleVersion = "SGE-2026-V3.2"
      ),
      MarginRequirement(
        contractSymbol = "Au99.99",
        contractName = "现货实盘黄金",
        currentPrice = auPrice,
        contractSize = 1000.0,
        marginRatio = 1.0, // 100% full cash
        marginPerLot = spotMarginPerLot,
        dailyLimitPercent = 0.0,
        volatilityRuleVersion = "SGE-SPOT-STANDARD"
      )
    )
  }
}
