package com.example.huagold.domain.model

enum class OrderSide(val label: String) {
  BUY("买入/多"),
  SELL("卖出/空")
}

enum class OrderType(val label: String) {
  LIMIT("限价单"),
  MARKET("市价单"),
  STOP_LOSS("止损单"),
  TAKE_PROFIT("止盈单"),
  ICEBERG("冰山订单(模拟)"),
  TWAP("TWAP算法"),
  VWAP("VWAP算法")
}

enum class OrderStatus(val label: String) {
  NEW("新建"),
  VALIDATED("已校验"),
  ACCEPTED("已接受"),
  WORKING("撮合中"),
  PARTIALLY_FILLED("部分成交"),
  FILLED("全部成交"),
  CANCELLED("已撤销")
}

data class OrderItem(
  val orderId: String,
  val symbol: String,
  val side: OrderSide,
  val type: OrderType,
  val price: Double,
  val quantity: Double,
  val filledQuantity: Double = 0.0,
  val status: OrderStatus = OrderStatus.NEW,
  val createTime: String,
  val updateTime: String,
  val venue: Venue = Venue.SGE
)

data class TradeExecution(
  val tradeId: String,
  val orderId: String,
  val symbol: String,
  val side: OrderSide,
  val quantity: Double,
  val price: Double,
  val timestamp: String,
  val fee: Double,
  val venue: Venue,
  val settlement: SettlementType
)

data class Position(
  val symbol: String,
  val name: String,
  val quantity: Double, // in grams or kg or contracts
  val avgCost: Double,
  val currentPrice: Double,
  val delta: Double,
  val contractMultiplier: Double = 1.0
) {
  val marketValue: Double get() = quantity * currentPrice * contractMultiplier
  val costValue: Double get() = quantity * avgCost * contractMultiplier
  val unrealizedPnL: Double get() = marketValue - costValue
  val returnPercent: Double get() = if (costValue != 0.0) (unrealizedPnL / costValue) * 100.0 else 0.0
}

data class PnLAttribution(
  val priceEffect: Double,
  val fxEffect: Double,
  val basisEffect: Double,
  val carryEffect: Double,
  val volEffect: Double,
  val transactionCosts: Double
) {
  val totalPnL: Double get() = priceEffect + fxEffect + basisEffect + carryEffect + volEffect - transactionCosts
}

data class PortfolioSummary(
  val totalEquity: Double,
  val cashBalanceCNY: Double,
  val cashBalanceUSD: Double,
  val marginUsed: Double,
  val marginAvailable: Double,
  val dailyPnL: Double,
  val dailyPnLPercent: Double,
  val weeklyPnL: Double,
  val monthlyPnL: Double,
  val ytdPnL: Double,
  val positions: List<Position>,
  val attribution: PnLAttribution
)
