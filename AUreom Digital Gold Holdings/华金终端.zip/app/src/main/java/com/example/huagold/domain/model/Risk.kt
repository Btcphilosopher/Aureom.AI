package com.example.huagold.domain.model

data class RiskSnapshot(
  val totalPortfolioValue: Double,
  val goldDeltaGrams: Double,
  val silverDeltaGrams: Double,
  val fxExposureCNY: Double,
  val basisExposureCNY: Double,
  val var1D99Percent: Double, // Value at Risk 1D 99%
  val expectedShortfall99Percent: Double, // ES 99%
  val stressLossEstimated: Double,
  val liquidityStatus: String, // "HIGH", "MODERATE", "LOW"
  val riskLevel: String, // "NORMAL", "ELEVATED", "CRITICAL"
  val marginUtilizationPercent: Double,
  val timestamp: String
)

data class StressScenario(
  val name: String,
  val description: String,
  val goldPriceChangePct: Double,
  val silverPriceChangePct: Double,
  val usdCnyChangePct: Double,
  val realYieldChangeBps: Double
)

data class StressResult(
  val scenarioName: String,
  val estimatedPnLLoss: Double,
  val lossPercentOfEquity: Double,
  val goldPnL: Double,
  val silverPnL: Double,
  val fxPnL: Double,
  val marginCallRisk: Boolean
)

data class MonteCarloResult(
  val numPaths: Int,
  val timeHorizonDays: Int,
  val medianPrice: Double,
  val percentile5th: Double, // 95% downside
  val percentile1st: Double, // 99% tail
  val percentile95th: Double,
  val percentile99th: Double,
  val pathDistributionBuckets: List<Pair<Double, Int>>, // Price Bucket to Frequency
  val simulatedPathsSample: List<List<Double>> // 5 sample trajectories
)

data class MarginRequirement(
  val contractSymbol: String,
  val contractName: String,
  val currentPrice: Double,
  val contractSize: Double,
  val marginRatio: Double, // e.g. 0.12 (12%)
  val marginPerLot: Double,
  val dailyLimitPercent: Double, // e.g. 10%
  val volatilityRuleVersion: String = "SGE-2026-V3"
)
