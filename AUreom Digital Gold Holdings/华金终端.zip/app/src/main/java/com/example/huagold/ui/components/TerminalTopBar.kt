package com.example.huagold.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
  timeStr: String,
  marketStatus: String,
  onOpenCommandBar: () -> Unit,
  onTriggerShock: (String) -> Unit
) {
  Surface(
    color = TerminalSurface,
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, TerminalBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Logo & System Title
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(24.dp)
              .clip(RoundedCornerShape(4.dp))
              .background(GoldPrimary),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "华",
              color = Color.Black,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              fontFamily = FontFamily.Monospace
            )
          }

          Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                "HUAGOLD TERMINAL",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
              )
              Text(
                "华金终端",
                color = GoldAccent,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp
              )
            }
            Text(
              "中国贵金属专业交易研究计算机",
              color = TextMuted,
              fontSize = 9.sp,
              fontFamily = FontFamily.SansSerif
            )
          }
        }

        // Actions & Clock
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Macro Shock Injection Button
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(TerminalSurfaceVariant)
              .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
              .clickable { onTriggerShock("GOLD_BULL_SHOCK") }
              .padding(horizontal = 6.dp, vertical = 4.dp)
              .testTag("shock_trigger_btn"),
            contentAlignment = Alignment.Center
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
              Icon(
                Icons.Default.Bolt,
                contentDescription = "宏观事件冲击模拟",
                tint = GoldPrimary,
                modifier = Modifier.size(12.dp)
              )
              Text(
                "宏观冲击",
                color = TextWhite,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          // Command Bar / Search Trigger
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(TerminalSurfaceVariant)
              .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
              .clickable { onOpenCommandBar() }
              .padding(horizontal = 6.dp, vertical = 4.dp)
              .testTag("command_bar_btn"),
            contentAlignment = Alignment.Center
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
              Icon(
                Icons.Default.Terminal,
                contentDescription = "命令栏",
                tint = CyanAccent,
                modifier = Modifier.size(12.dp)
              )
              Text(
                "命令/搜索",
                color = CyanAccent,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Status Bar: Venue, Clock, Data status
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Venue
          Text(
            "上金所 · 上期所 · COMEX · LBMA",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )

          Text(
            "状态: $marketStatus",
            color = if (marketStatus == "正常") StatusLive else StatusWarning,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Data source badge
          Box(
            modifier = Modifier
              .background(Color(0x3338BDF8), RoundedCornerShape(2.dp))
              .padding(horizontal = 4.dp, vertical = 1.dp)
          ) {
            Text(
              "SYNTHETIC 模拟行情",
              color = CyanAccent,
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold
            )
          }

          // Shanghai Clock
          Text(
            "上海 $timeStr",
            color = TextWhite,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
