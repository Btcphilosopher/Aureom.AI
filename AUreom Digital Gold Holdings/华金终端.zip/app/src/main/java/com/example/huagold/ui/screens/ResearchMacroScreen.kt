package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ResearchMacroScreen(
  repository: MarketRepository
) {
  val macroModel by repository.goldMacroModel.collectAsState()
  val centralBanks by repository.centralBankReserves.collectAsState()
  val goldEtfs by repository.chinaGoldEtfs.collectAsState()
  val inventories by repository.inventories.collectAsState()

  // Python Sandbox Notebook State
  var notebookCode by remember {
    mutableStateOf(
      "from huagold import Market\n\n" +
          "gold = Market('XAU/CNY')\n" +
          "silver = Market('XAG/CNY')\n\n" +
          "ratio = gold / silver\n" +
          "ratio.describe()"
    )
  }

  var notebookOutput by remember {
    mutableStateOf(
      "== HUAGOLD PYTHON NOTEBOOK OUTPUT ==\n" +
          "Asset: XAU/XAG (Gold-Silver Ratio)\n" +
          "Count: 250 trading days\n" +
          "Mean: 64.20 | Std: 4.82\n" +
          "Min: 55.40 | Max: 88.50\n" +
          "Current: 58.74 (Percentile: 28.4%)\n" +
          "Correlation with USD/CNY: +0.34\n" +
          "Regression Beta to US 10Y TIPS: -0.42 (p < 0.001)"
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("research_macro_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Science, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "贵金属宏观计量模型与产业研究 (RESEARCH LAB)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .background(Color(0x3310B981), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text("MODEL V3.7 ACTIVE", color = StatusLive, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    // 2. Gold Macro Factor Regression Model
    item {
      macroModel?.let { model ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                "多元因子回归模型: ${model.modelId} (R² = ${model.rSquaredTotal})",
                color = GoldAccent,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
              Text("因变量: ${model.targetAsset}", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              "当前宏观范式: ${model.currentRegime}",
              color = TextWhite,
              fontSize = 9.sp,
              fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Factor sensitivities table
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant)
                .padding(horizontal = 4.dp, vertical = 3.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("因子名称", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(130.dp))
              Text("Beta回归系数", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(70.dp))
              Text("t-Stat统计量", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
              Text("R²方差贡献", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
            }

            model.factors.forEach { f ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 4.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(f.factorName, color = TextWhite, fontSize = 9.sp, modifier = Modifier.width(130.dp), maxLines = 1)
                Text(
                  "${if (f.beta >= 0) "+" else ""}${f.beta}",
                  color = if (f.beta >= 0) QuoteUpRed else QuoteDownGreen,
                  fontWeight = FontWeight.Bold,
                  fontSize = 9.sp,
                  fontFamily = FontFamily.Monospace,
                  modifier = Modifier.width(70.dp)
                )
                Text("${f.tStat}", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
                Text("${(f.rSquaredContribution * 100).toInt()}%", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
              }
              Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(model.keyTakeaway, color = TextGray, fontSize = 9.sp)
          }
        }
      }
    }

    // 3. Central Bank Gold Reserves
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "CENTRAL BANK GOLD RESERVES / 全球央行官方黄金储备",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "单位: 吨 (Tonnes)",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        centralBanks.forEach { cb ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(cb.country, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Text("${cb.goldHoldingsTonnes} 吨", color = GoldPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("月变动: +${cb.monthlyChangeTonnes} 吨", color = QuoteUpRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("占储备: ${cb.shareOfTotalReservesPercent}%", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          }
          Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
        }
      }
    }

    // 4. China Gold ETFs & Global Inventories
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // ETFs
        Column(
          modifier = Modifier
            .weight(1f)
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
        ) {
          Text("中国黄金ETF追踪", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
          Spacer(modifier = Modifier.height(4.dp))
          goldEtfs.forEach { etf ->
            Column(modifier = Modifier.padding(vertical = 2.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(etf.code, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("¥${etf.price}", color = QuoteUpRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              }
              Text("AUM: ${etf.aumBillionCNY}亿 | 持金: ${etf.goldHoldingsTonnes}吨", color = TextGray, fontSize = 8.sp)
            }
            Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }
        }

        // Inventories
        Column(
          modifier = Modifier
            .weight(1f)
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
        ) {
          Text("全球主要库存 (吨)", color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
          Spacer(modifier = Modifier.height(4.dp))
          inventories.forEach { inv ->
            Column(modifier = Modifier.padding(vertical = 2.dp)) {
              Text(inv.venue.take(12), color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 9.sp)
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${inv.inventoryTonnes} 吨", color = GoldPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("${inv.change1W} 吨", color = if (inv.change1W <= 0) QuoteDownGreen else QuoteUpRed, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              }
            }
            Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }
        }
      }
    }

    // 5. Interactive Python Sandbox Notebook
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(Icons.Default.Terminal, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
              Text(
                "HUAGOLD NOTEBOOK / Python 研究沙箱",
                color = CyanAccent,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }

            Button(
              onClick = {
                notebookOutput = "== RUN EXECUTED @ 09:42:18 ==\n" +
                    "Evaluated script successfully.\n" +
                    "Asset: XAU/CNY vs XAG/CNY Cross Ratio\n" +
                    "Current: 58.74 | 20D SMA: 60.12\n" +
                    "Z-score: -0.38 | Volatility (30D): 18.4%\n" +
                    "Conclusion: Ratio within -1.0σ channel, potential mean-reverting bounce."
              },
              colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              modifier = Modifier.height(26.dp)
            ) {
              Text("▶ 运行", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          OutlinedTextField(
            value = notebookCode,
            onValueChange = { notebookCode = it },
            colors = TextFieldDefaults.colors(
              focusedContainerColor = TerminalSurfaceVariant,
              unfocusedContainerColor = TerminalSurfaceVariant,
              focusedTextColor = TextWhite,
              unfocusedTextColor = TextWhite,
              focusedIndicatorColor = CyanAccent
            ),
            textStyle = androidx.compose.ui.text.TextStyle(
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(6.dp))

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalBg, RoundedCornerShape(3.dp))
              .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
              .padding(8.dp)
          ) {
            Text(
              notebookOutput,
              color = StatusLive,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace,
              lineHeight = 13.sp
            )
          }
        }
      }
    }
  }
}
