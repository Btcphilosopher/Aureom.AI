package com.example.huagold.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.VolSurfaceData
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.max

@Composable
fun VolSurfaceCanvas(
  volData: VolSurfaceData?,
  modifier: Modifier = Modifier
) {
  if (volData == null || volData.grid.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(200.dp)
        .background(TerminalSurface),
      contentAlignment = Alignment.Center
    ) {
      Text("暂无波动率曲面数据", color = TextMuted, fontSize = 12.sp)
    }
    return
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "IMPLIED VOL SURFACE / 隐含波动率曲面",
        color = GoldAccent,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )

      Text(
        "标的: ${volData.underlying}",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Realized Volatility Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalSurfaceVariant)
        .padding(horizontal = 6.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("历史已实现波动率 (HV):", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("5D: ${volData.realizedVol5D}%", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("20D: ${volData.realizedVol20D}%", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("60D: ${volData.realizedVol60D}%", color = TextWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
      Text("250D: ${volData.realizedVol250D}%", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Volatility Matrix Table with Heatmap Background
    Column(modifier = Modifier.fillMaxWidth()) {
      // Table Expiry Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("行权价\\期限", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
        volData.expiries.forEach { exp ->
          Text(
            "${exp}D",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(36.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(3.dp))

      volData.strikes.forEachIndexed { sIdx, strike ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "${strike.toInt()}",
            color = if (strike == 930.0) GoldAccent else TextWhite,
            fontWeight = if (strike == 930.0) FontWeight.Bold else FontWeight.Normal,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(60.dp)
          )

          volData.expiries.indices.forEach { eIdx ->
            val iv = volData.grid.getOrNull(sIdx)?.getOrNull(eIdx) ?: 16.0
            val heatAlpha = ((iv - 14.0) / 10.0).toFloat().coerceIn(0.1f, 0.9f)
            val heatColor = Color(0xFFA855F7).copy(alpha = heatAlpha)

            Box(
              modifier = Modifier
                .width(36.dp)
                .background(heatColor, RoundedCornerShape(2.dp))
                .padding(vertical = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                String.format(Locale.US, "%.1f", iv),
                color = TextWhite,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }
}
