package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.ui.components.CurveChartCanvas
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun CurvesBasisRatioScreen(
  repository: MarketRepository
) {
  val goldCurve by repository.goldCurve.collectAsState()
  val silverCurve by repository.silverCurve.collectAsState()
  val goldSilverRatio by repository.goldSilverRatio.collectAsState()
  val chinaGoldPremium by repository.chinaGoldPremium.collectAsState()
  val chinaSilverPremium by repository.chinaSilverPremium.collectAsState()
  val leaseRates by repository.leaseRates.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("curves_basis_ratio_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.AutoGraph, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "期限结构、基差溢价与金银比 (CURVES & BASIS)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Text(
          "无套利定价与期限分析",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    // 2. Gold Term Structure Curve
    item {
      CurveChartCanvas(curve = goldCurve)
    }

    // 3. Silver Term Structure Curve
    item {
      CurveChartCanvas(curve = silverCurve)
    }

    // 4. Gold / Silver Ratio Analyzer
    item {
      goldSilverRatio?.let { gsr ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.CompareArrows, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                Text(
                  "GOLD / SILVER RATIO (金银比价分析)",
                  color = GoldAccent,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace
                )
              }

              Text(
                "当前比值: ${String.format(Locale.US, "%.2f", gsr.currentRatio)}",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
              )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(6.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("10年历史分位数", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${gsr.percentile10Y}%", color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("Z-score (标准分)", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${if (gsr.zScore >= 0) "+" else ""}${gsr.zScore}", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("近1月变动", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${gsr.change1M}%", color = QuoteDownGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("近1年变动", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${gsr.change1Y}%", color = QuoteDownGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              "历史演变序列: ${gsr.historyPoints.joinToString(" → ") { "${it.first}: ${it.second}" }}",
              color = TextMuted,
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // 5. China Premium Pricing Engine (Mathematical Formulas & Parity)
    item {
      chinaGoldPremium?.let { gp ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              "CHINA GOLD PREMIUM MODEL (中国黄金溢价定价机制)",
              color = GoldAccent,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(8.dp)
            ) {
              Text(
                "理论人民币金价 = (国际金价 $${gp.internationalPriceUSD}/oz × USD/CNY ${gp.usdCnyRate}) ÷ 31.1034768 = ¥${gp.theoreticalCnyPrice}/克\n" +
                    "在岸现货黄金基差 = 上海金 (¥${gp.domesticPrice}/g) - 理论平价 (¥${gp.theoreticalCnyPrice}/g) = ${if (gp.premiumAmount >= 0) "+" else ""}${gp.premiumAmount} 元/克 (${gp.premiumPercent}%)",
                color = TextWhite,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp
              )
            }
          }
        }
      }
    }

    // 6. Gold Lease Rates & Carry Cost Model
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "GOLD LEASE RATES & CARRY (黄金租借利率与展期成本)",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "上金所银行间拆借",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant)
            .padding(horizontal = 4.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("期限", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
          Text("租借年利率(Lease)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
          Text("资金成本(Funding)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
          Text("净展期成本(Net Carry)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
        }

        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          leaseRates.forEach { lr ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(lr.tenor, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
              Text("${lr.ratePercent}%", color = GoldAccent, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
              Text("${lr.fundingCostPercent}%", color = TextGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
              Text("+${lr.netCarryCost}%", color = StatusLive, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(90.dp))
            }
            Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }
        }
      }
    }
  }
}
