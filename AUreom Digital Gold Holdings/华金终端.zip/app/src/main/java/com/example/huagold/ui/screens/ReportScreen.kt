package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.ResearchReport
import com.example.ui.theme.*

@Composable
fun ReportScreen(
  repository: MarketRepository
) {
  var report by remember { mutableStateOf<ResearchReport?>(null) }
  val clipboardManager = LocalClipboardManager.current
  var showCopiedToast by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    if (report == null) {
      report = repository.generateFullDailyReport()
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("report_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Top Action Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Description, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "研究报告生成器 (REPORT GENERATOR)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Button(
            onClick = {
              report = repository.generateFullDailyReport()
            },
            colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceVariant),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("🔄 重新生成", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          }

          Button(
            onClick = {
              report?.let {
                val fullText = "${it.title}\n日期: ${it.date}\n\n${it.executiveSummary}\n\n${it.goldMarketSection}\n\n${it.silverMarketSection}\n\n${it.fxBasisSection}\n\n${it.termStructureSection}\n\n${it.volatilitySection}\n\n${it.etfFlowSection}\n\n${it.macroRiskSection}\n\n${it.conclusionRecommendation}"
                clipboardManager.setText(AnnotatedString(fullText))
                showCopiedToast = true
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text(if (showCopiedToast) "✓ 已复制" else "📋 复制全文", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }

    // 2. Daily Report Document Paper Layout
    item {
      report?.let { rep ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Document Header
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
            ) {
              Text(
                rep.title,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("发布机构: ${rep.author}", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("报告日期: ${rep.date}", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              }
            }

            // Executive Summary
            ReportSectionCard("【核心摘要 / EXECUTIVE SUMMARY】", rep.executiveSummary, GoldAccent)

            // Gold Market
            ReportSectionCard("【黄金市场与现货基差】", rep.goldMarketSection, TextWhite)

            // Silver Market
            ReportSectionCard("【白银市场与光伏工业链】", rep.silverMarketSection, TextWhite)

            // FX Basis
            ReportSectionCard("【汇率折算与跨市场溢价】", rep.fxBasisSection, TextWhite)

            // Term Structure
            ReportSectionCard("【期限结构与套保成本】", rep.termStructureSection, TextWhite)

            // Volatility
            ReportSectionCard("【期权隐含波动率与偏斜】", rep.volatilitySection, TextWhite)

            // ETF Flow
            ReportSectionCard("【ETF资金流与央行储备】", rep.etfFlowSection, TextWhite)

            // Macro Risk
            ReportSectionCard("【宏观情景与尾部风险】", rep.macroRiskSection, QuoteUpRed)

            // Conclusion
            ReportSectionCard("【策略观点与配置建议】", rep.conclusionRecommendation, StatusLive)
          }
        }
      }
    }
  }
}

@Composable
private fun ReportSectionCard(title: String, body: String, titleColor: Color) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
      .padding(8.dp)
  ) {
    Text(
      title,
      color = titleColor,
      fontWeight = FontWeight.Bold,
      fontSize = 10.sp,
      fontFamily = FontFamily.Monospace
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      body,
      color = TextGray,
      fontSize = 9.sp,
      fontFamily = FontFamily.SansSerif,
      lineHeight = 14.sp
    )
  }
}
