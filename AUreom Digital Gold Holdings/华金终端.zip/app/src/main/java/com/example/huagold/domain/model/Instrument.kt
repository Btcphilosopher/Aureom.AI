package com.example.huagold.domain.model

enum class AssetClass(val displayName: String) {
  GOLD("黄金"),
  SILVER("白银"),
  PGM("铂族金属"),
  FX("外汇汇率"),
  MACRO("宏观指标")
}

enum class Venue(val displayName: String, val code: String) {
  SGE("上海黄金交易所", "SGE"),
  SHFE("上海期货交易所", "SHFE"),
  CFETS("中国外汇交易中心", "CFETS"),
  COMEX("纽约商品交易所", "COMEX"),
  LBMA("伦敦金银市场协会", "LBMA"),
  HKEX("香港交易所", "HKEX"),
  PBOC("中国人民银行", "PBOC")
}

enum class SettlementType(val displayName: String) {
  PHYSICAL("实物交割"),
  CASH("现金结算"),
  DEFERRED("延期交收(T+D)"),
  BENCHMARK("基准定价")
}

enum class DataStatus(val label: String, val isSimulated: Boolean) {
  LIVE("实盘行情", false),
  DELAYED("延迟行情", false),
  HISTORICAL("历史行情", false),
  SYNTHETIC("模拟行情", true),
  UNAVAILABLE("数据不可用", false)
}

data class Instrument(
  val instrumentId: String,
  val symbol: String,
  val name: String,
  val assetClass: AssetClass,
  val venue: Venue,
  val currency: String = "CNY",
  val unit: String = "元/克",
  val contractSize: Double = 1.0, // e.g. 1000g for Au(T+D) or 15kg for Ag(T+D)
  val tickSize: Double = 0.01,
  val settlementType: SettlementType = SettlementType.PHYSICAL,
  val tradingHours: String = "09:00-11:30, 13:30-15:30, 20:00-02:30",
  val status: String = "TRADING"
)
