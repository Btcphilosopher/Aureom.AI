package com.example.huagold.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

data class CommandAction(
  val code: String,
  val title: String,
  val category: String,
  val icon: ImageVector,
  val tabIndex: Int? = null,
  val symbolToSelect: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandBarDialog(
  onDismiss: () -> Unit,
  onExecuteCommand: (CommandAction) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }

  val allCommands = remember {
    listOf(
      CommandAction("XAU/CNY", "黄金/在岸人民币 (综合行情与在岸溢价)", "行情", Icons.Default.MonetizationOn, 0, "Au99.99"),
      CommandAction("AU9999", "Au99.99 黄金现货实盘 (上海黄金交易所)", "合约", Icons.Default.ShowChart, 1, "Au99.99"),
      CommandAction("AUTD", "Au(T+D) 黄金延期交收合约", "合约", Icons.Default.Timeline, 1, "Au(T+D)"),
      CommandAction("AGTD", "Ag(T+D) 白银延期交收合约", "合约", Icons.Default.TrendingUp, 1, "Ag(T+D)"),
      CommandAction("SHGOLD", "上海金集中定价基准 (早盘价 / 午盘价)", "基准", Icons.Default.AccountBalance, 0, "SHGOLD_AM"),
      CommandAction("USD/CNY", "中国外汇市场即期汇率 & 离在岸汇差", "外汇", Icons.Default.CurrencyExchange, 0, "USD/CNY"),
      CommandAction("GOLD CURVE", "黄金期限结构曲线 (Contango / Backwardation)", "曲线", Icons.Default.AutoGraph, 3),
      CommandAction("SILVER CURVE", "白银期限结构曲线与远期升贴水", "曲线", Icons.Default.AutoGraph, 3),
      CommandAction("GOLD/SILVER", "金银比价分析 (历史分位数与Z-score)", "比价", Icons.Default.CompareArrows, 3),
      CommandAction("CHINA PREMIUM", "中国在岸黄金白银溢价模型", "溢价", Icons.Default.Insights, 3),
      CommandAction("OPTIONS LAB", "黄金期权实验室 (Black-Scholes & 波动率曲面)", "衍生品", Icons.Default.BlurOn, 4),
      CommandAction("OMS / PORTFOLIO", "模拟订单管理系统 & 投资组合 P&L 归因", "交易", Icons.Default.AccountBalanceWallet, 2),
      CommandAction("RISK CONTROL", "风险驾驶舱 (VaR, ES, 压力测试, 保证金模拟)", "风控", Icons.Default.Shield, 6),
      CommandAction("RESEARCH LAB", "宏观计量模型 & 央行储备 & ETF资金流", "研究", Icons.Default.Science, 5),
      CommandAction("HUAGOLD AI", "华金 AI 贵金属深度研究助手 (数据引用归因)", "智能", Icons.Default.Psychology, 7),
      CommandAction("DAILY REPORT", "一键生成华金贵金属市场日报", "报告", Icons.Default.Description, 8)
    )
  }

  val filteredCommands = remember(searchQuery) {
    if (searchQuery.isBlank()) allCommands
    else allCommands.filter {
      it.code.contains(searchQuery, ignoreCase = true) ||
          it.title.contains(searchQuery, ignoreCase = true) ||
          it.category.contains(searchQuery, ignoreCase = true)
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      color = TerminalSurface,
      shape = RoundedCornerShape(8.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 560.dp)
        .testTag("command_bar_dialog")
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Terminal, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
            Text(
              "COMMAND BAR / 终端指令搜索",
              color = GoldPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
          }

          Text(
            "ESC / 点击外部关闭",
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = {
            Text(
              "输入代码/名称 (如 XAU, AU9999, CURVE, RISK, AI)...",
              color = TextMuted,
              fontSize = 12.sp
            )
          },
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Clear, contentDescription = "清除", tint = TextGray, modifier = Modifier.size(16.dp))
              }
            }
          },
          colors = TextFieldDefaults.colors(
            focusedContainerColor = TerminalSurfaceVariant,
            unfocusedContainerColor = TerminalSurfaceVariant,
            focusedTextColor = TextWhite,
            unfocusedTextColor = TextWhite,
            focusedIndicatorColor = GoldPrimary,
            unfocusedIndicatorColor = TerminalBorder
          ),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("command_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          "匹配结果 (${filteredCommands.size})",
          color = TextMuted,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier.weight(1f, fill = false)
        ) {
          items(filteredCommands) { cmd ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(TerminalSurfaceVariant)
                .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(4.dp))
                .clickable {
                  onExecuteCommand(cmd)
                  onDismiss()
                }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("cmd_item_${cmd.code}"),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(cmd.icon, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                      cmd.code,
                      color = GoldAccent,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      fontFamily = FontFamily.Monospace
                    )
                    Box(
                      modifier = Modifier
                        .background(Color(0x22818CF8), RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                      Text(
                        cmd.category,
                        color = IndigoAccent,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                  }
                  Text(
                    cmd.title,
                    color = TextWhite,
                    fontSize = 11.sp,
                    maxLines = 1
                  )
                }
              }

              Icon(Icons.Default.ArrowForward, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
            }
          }
        }
      }
    }
  }
}
