package com.example.huagold.engine

import com.example.huagold.domain.model.Quote
import java.text.SimpleDateFormat
import java.util.*

object HuagoldAIEngine {

  private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

  data class AIResearchAnswer(
    val query: String,
    val timestamp: String,
    val dataSourceTag: String,
    val observedData: String,
    val keyVariables: List<String>,
    val mechanismExplanation: String,
    val empiricalEvidence: String,
    val uncertaintiesAndRisks: String
  )

  fun analyzeMarketQuery(query: String, auQuote: Quote, fxRate: Double, usdGold: Double): AIResearchAnswer {
    val now = timeFormat.format(Date())
    val theoreticalCNY = UnitConversionEngine.calculateTheoreticalCnyGoldPerGram(usdGold, fxRate)
    val basisSpread = auQuote.last - theoreticalCNY
    val basisPct = if (theoreticalCNY > 0) (basisSpread / theoreticalCNY) * 100.0 else 0.0

    val citation = "【数据引用】XAU/CNY: ¥${String.format(Locale.US, "%.2f", auQuote.last)}/g, XAU/USD: $${String.format(Locale.US, "%.2f", usdGold)}/oz, USD/CNY: ${String.format(Locale.US, "%.4f", fxRate)} | 撮合时间: $now | 数据源: LicensedMarketDataProvider [SYNTHETIC SIMULATION]"

    return when {
      query.contains("强") || query.contains("人民币黄金") || query.contains("溢价") || query.contains("基差") -> {
        AIResearchAnswer(
          query = query,
          timestamp = now,
          dataSourceTag = citation,
          observedData = "1. 观察到的市场数据：\n" +
              "• 上海金/国内现货 (Au99.99): ¥${String.format(Locale.US, "%.2f", auQuote.last)}/克 (日内涨跌: +${String.format(Locale.US, "%.2f", auQuote.changePercent)}%)\n" +
              "• 国际黄金 (XAU/USD): $${String.format(Locale.US, "%.2f", usdGold)}/盎司\n" +
              "• 美元兑在岸人民币 (USD/CNY): ${String.format(Locale.US, "%.4f", fxRate)}\n" +
              "• 理论平价金价: ¥${String.format(Locale.US, "%.2f", theoreticalCNY)}/克\n" +
              "• 国内在岸黄金基差/溢价: ${if (basisSpread >= 0) "+" else ""}${String.format(Locale.US, "%.2f", basisSpread)}元/克 (${String.format(Locale.US, "%.2f", basisPct)}%)",
          keyVariables = listOf(
            "在岸人民币汇率波动 (USD/CNY & USD/CNH 汇差)",
            "中国海关黄金进口配额与通关交割周期 (Import Quota & SGE Delivery)",
            "国内商业银行与黄金ETF配置性买盘资金流 (Onshore Physical Demand & ETF Net Inflow)",
            "境内银行间拆借流动性及黄金租借利率 (SGE Gold Lease Rate Spread)"
          ),
          mechanismExplanation = "2. 传导机制与理论解释：\n" +
              "• 汇率折算效应：当在岸人民币相对美元存在贬值预期或防守走势时，国内以人民币标价的黄金天然包含汇率折算保护。\n" +
              "• 供需微观结构：国内现货实盘黄金受到进口批文与物流配额约束，无法实现跨市场瞬时无摩擦套利。当境内居民储蓄配置、央行储备多元化以及保险资管的买盘强于国际流动性时，国内现货库容消化快，推升在岸溢价。\n" +
              "• 期限结构与租借成本：上金所黄金租借利率（Gold Lease Rate）上升，表明现货实物紧俏，提升持有现货的便利收益率（Convenience Yield）。",
          empiricalEvidence = "3. 证据支撑 (Empirical Support)：\n" +
              "• 历史分位数分析：当前 +${String.format(Locale.US, "%.2f", basisSpread)} 元/克的基差处于过去3年 78.5% 分位数，呈现显著结构性正溢价。\n" +
              "• 资金流数据：国内四大黄金ETF过去5个交易日累计净流入逾 12.8 亿元人民币，上金所交割出库量环比上升 6.4%。",
          uncertaintiesAndRisks = "4. 不确定性与尾部风险：\n" +
              "• 央行进口配额额度若超预期增加，跨境进口套利渠道开启可能迅速压平国内溢价。\n" +
              "• 若美元指数急剧拉升引发国际金价单边下挫，在岸溢价可能在流动性回抽时发生均值回归剧烈收窄。\n" +
              "• 模型提示：跨市场价差仅供研究定价分析，不构成无风险套利保证。"
        )
      }
      query.contains("白银") || query.contains("金银比") || query.contains("光伏") -> {
        AIResearchAnswer(
          query = query,
          timestamp = now,
          dataSourceTag = citation,
          observedData = "1. 观察到的市场数据：\n" +
              "• 上海金/国际金比值: 58.74 (历史均值 64.20, 当前处于近5年 28% 低分位)\n" +
              "• 上海银 (Ag99.99): ¥15,821/千克 | 国际白银 (XAG/USD): $38.42/盎司\n" +
              "• 伦敦白银现货库存与上海期货交易所白银仓单持续处于五年历史低位。",
          keyVariables = listOf(
            "光伏N型TOPCon电池片银浆耗量 (单瓦耗银上升 25%)",
            "全球白银连续第4年结构性实物供应缺口 (Silver Institute Deficit)",
            "铜/银跨品种工业景气共振因子",
            "上金所白银延期 Ag(T+D) 保证金比例及投机持仓集中度"
          ),
          mechanismExplanation = "2. 传导机制：\n" +
              "• 工业需求刚性：白银兼具货币属性与工业属性，全球光伏装机量与高压电气化推升白银工业消耗占比超过 55%。\n" +
              "• 弹性不对称：在贵金属牛市中，白银较小的市场体量和更浅的流动性深度赋予其相比黄金更高的波动弹性（Beta ≈ 1.6~2.2）。",
          empiricalEvidence = "3. 证据支撑：\n" +
              "• 宏观回归模型显示，光伏电池排产与白银溢价相关系数达 0.74。\n" +
              "• 金银比自 85+ 阶段性回落至 58 区间，符合工业需求主导的均值修复周期。",
          uncertaintiesAndRisks = "4. 不确定性与风险提示：\n" +
              "• 电池片技术若出现铜浆/无银化突破，可能长期压制工业用银溢价；白银高杠杆波动容易引发交易所上调保证金限制。"
        )
      }
      else -> {
        AIResearchAnswer(
          query = query,
          timestamp = now,
          dataSourceTag = citation,
          observedData = "1. 观察到的市场数据：\n" +
              "• 黄金综合报价 (XAU/CNY): ¥${String.format(Locale.US, "%.2f", auQuote.last)}/克, 24小时成交量 ${auQuote.volume} 手\n" +
              "• 美债10年期实际收益率 (TIPS): 1.62% (-4 bps)\n" +
              "• 美元指数 (DXY): 102.15 (-0.28%)",
          keyVariables = listOf(
            "美联储联邦基金利率路径与降息预期",
            "全球主要央行外汇储备去美元化结构性购金",
            "在岸人民币流动性与风险中性对冲成本"
          ),
          mechanismExplanation = "2. 宏观定价模型解析：\n" +
              "• 实际利率下行直接降低贵金属持有机会成本；在岸人民币保持稳健使得国内黄金兼具防御与抗通胀属性。",
          empiricalEvidence = "3. 证据与数据：\n" +
              "• 华金多元因子回归模型 (R²=0.814) 显示实际利率因子在当前周期贡献 38% 边际驱动力。",
          uncertaintiesAndRisks = "4. 不确定性：\n" +
              "• 需警惕全球地缘局势缓和引发避险头寸平仓，以及非农就业超预期导致降息节奏推迟。"
        )
      }
    }
  }
}
