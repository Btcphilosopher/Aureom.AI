package com.example.huagold.domain.model

data class FactorSensitivity(
  val factorName: String,
  val beta: Double,
  val tStat: Double,
  val rSquaredContribution: Double,
  val description: String
)

data class MacroModelAnalysis(
  val modelId: String = "GOLD-MACRO-V3.7",
  val targetAsset: String = "XAU/CNY",
  val factors: List<FactorSensitivity>,
  val rSquaredTotal: Double,
  val currentRegime: String,
  val keyTakeaway: String
)

data class ResearchReport(
  val reportId: String,
  val title: String,
  val date: String,
  val author: String = "华金贵金属研究台 (HUAGOLD RESEARCH)",
  val executiveSummary: String,
  val goldMarketSection: String,
  val silverMarketSection: String,
  val fxBasisSection: String,
  val termStructureSection: String,
  val volatilitySection: String,
  val etfFlowSection: String,
  val macroRiskSection: String,
  val conclusionRecommendation: String
)
