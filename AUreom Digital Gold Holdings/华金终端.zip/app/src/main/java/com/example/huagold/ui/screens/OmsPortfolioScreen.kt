package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun OmsPortfolioScreen(
  repository: MarketRepository,
  onSelectInstrument: (String) -> Unit
) {
  val portfolio by repository.portfolio.collectAsState()
  val workingOrders by repository.workingOrders.collectAsState()
  val tradeLedger by repository.tradeLedger.collectAsState()
  val quotes by repository.quotes.collectAsState()

  var newOrderSymbol by remember { mutableStateOf("Au99.99") }
  var newOrderSide by remember { mutableStateOf(OrderSide.BUY) }
  var newOrderType by remember { mutableStateOf(OrderType.LIMIT) }
  var newOrderPrice by remember { mutableStateOf("928.45") }
  var newOrderQty by remember { mutableStateOf("500") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("oms_portfolio_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "OMS 交易与投资组合驾驶舱 (PORTFOLIO & OMS)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .background(Color(0x3338BDF8), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text("SYNTHETIC EXECUTION", color = CyanAccent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    // 2. Portfolio Summary Cockpit
    item {
      portfolio?.let { p ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text("账户总资产 (TOTAL EQUITY)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Bottom
            ) {
              Text(
                "¥${String.format(Locale.US, "%,.2f", p.totalEquity)}",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Monospace
              )

              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("今日盈亏:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(
                  "+¥${String.format(Locale.US, "%,.0f", p.dailyPnL)} (+${p.dailyPnLPercent}%)",
                  color = QuoteUpRed,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Balances & Margin
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                .padding(6.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("人民币可用现金", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("¥${String.format(Locale.US, "%,.0f", p.cashBalanceCNY)}", color = TextWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("美元现金储备", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("$${String.format(Locale.US, "%,.0f", p.cashBalanceUSD)}", color = CyanAccent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("已占用保证金", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("¥${String.format(Locale.US, "%,.0f", p.marginUsed)}", color = StatusWarning, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              }
              Column {
                Text("年内累计P&L", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("+¥${String.format(Locale.US, "%,.0f", p.ytdPnL)}", color = QuoteUpRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              }
            }
          }
        }
      }
    }

    // 3. P&L Attribution Breakdown
    item {
      portfolio?.attribution?.let { attr ->
        Surface(
          color = TerminalSurface,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(
              "P&L ATTRIBUTION / 收益归因拆解",
              color = GoldAccent,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              AttributionPill("价格效应", attr.priceEffect, QuoteUpRed)
              AttributionPill("汇率折算", attr.fxEffect, CyanAccent)
              AttributionPill("基差溢价", attr.basisEffect, GoldAccent)
              AttributionPill("展期Carry", attr.carryEffect, StatusLive)
              AttributionPill("波动率收益", attr.volEffect, IndigoAccent)
            }
          }
        }
      }
    }

    // 4. Current Positions List
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "CURRENT POSITIONS / 当前持仓明细",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "${portfolio?.positions?.size ?: 0} 个标的",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant)
            .padding(horizontal = 4.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("品种", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
          Text("持仓量", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(55.dp))
          Text("均价/现价", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp))
          Text("市值(元)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(65.dp))
          Text("浮动盈亏", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
        }

        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          portfolio?.positions?.forEach { pos ->
            val isProfit = pos.unrealizedPnL >= 0
            val pColor = if (isProfit) QuoteUpRed else QuoteDownGreen

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectInstrument(pos.symbol) }
                .padding(horizontal = 4.dp, vertical = 5.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.width(65.dp)) {
                Text(pos.symbol, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(pos.name.take(5), color = TextMuted, fontSize = 8.sp)
              }

              Text(
                "${pos.quantity}",
                color = if (pos.quantity >= 0) TextWhite else CyanAccent,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.width(55.dp)
              )

              Column(modifier = Modifier.width(75.dp)) {
                Text("${pos.avgCost}", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("${pos.currentPrice}", color = pColor, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              }

              Text(
                String.format(Locale.US, "%,.0f", pos.marketValue),
                color = TextWhite,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.width(65.dp)
              )

              Column(modifier = Modifier.width(60.dp)) {
                Text(
                  "${if (isProfit) "+" else ""}${String.format(Locale.US, "%,.0f", pos.unrealizedPnL)}",
                  color = pColor,
                  fontWeight = FontWeight.Bold,
                  fontSize = 9.sp,
                  fontFamily = FontFamily.Monospace
                )
                Text(
                  "${if (isProfit) "+" else ""}${String.format(Locale.US, "%.2f", pos.returnPercent)}%",
                  color = pColor,
                  fontSize = 8.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }

            Divider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }
        }
      }
    }

    // 5. Order Entry Panel
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          Text(
            "SIMULATED ORDER ENTRY / 模拟订单输入",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            // Symbol
            OutlinedTextField(
              value = newOrderSymbol,
              onValueChange = { newOrderSymbol = it },
              label = { Text("标的代码", fontSize = 9.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            // Price
            OutlinedTextField(
              value = newOrderPrice,
              onValueChange = { newOrderPrice = it },
              label = { Text("委托价格", fontSize = 9.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            // Quantity
            OutlinedTextField(
              value = newOrderQty,
              onValueChange = { newOrderQty = it },
              label = { Text("委托数量", fontSize = 9.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Side & Submit Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                val p = newOrderPrice.toDoubleOrNull() ?: 928.45
                val q = newOrderQty.toDoubleOrNull() ?: 100.0
                repository.submitOrder(newOrderSymbol, OrderSide.BUY, newOrderType, p, q)
              },
              colors = ButtonDefaults.buttonColors(containerColor = QuoteUpRed),
              modifier = Modifier.weight(1f)
            ) {
              Text("买入 / 做多 (BUY)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            Button(
              onClick = {
                val p = newOrderPrice.toDoubleOrNull() ?: 928.45
                val q = newOrderQty.toDoubleOrNull() ?: 100.0
                repository.submitOrder(newOrderSymbol, OrderSide.SELL, newOrderType, p, q)
              },
              colors = ButtonDefaults.buttonColors(containerColor = QuoteDownGreen),
              modifier = Modifier.weight(1f)
            ) {
              Text("卖出 / 做空 (SELL)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }
        }
      }
    }

    // 6. Working Orders & Trade Ledger
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "WORKING ORDERS & TRADE LEDGER / 撮合与交易账本",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            "不可变审计追踪",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (workingOrders.isNotEmpty()) {
          Text("未完成挂单 (${workingOrders.size})", color = CyanAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          workingOrders.forEach { ord ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("${ord.orderId} · ${ord.symbol} · ${ord.side.label} · ¥${ord.price} (${ord.quantity}手)", color = TextWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Button(
                onClick = { repository.cancelOrder(ord.orderId) },
                colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceVariant),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                modifier = Modifier.height(24.dp)
              ) {
                Text("撤单", color = StatusWarning, fontSize = 9.sp)
              }
            }
          }
          Divider(color = TerminalBorderSubtle, modifier = Modifier.padding(vertical = 4.dp))
        }

        Text("历史成交账本 (最新 ${tradeLedger.size} 笔)", color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        tradeLedger.take(5).forEach { trd ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("${trd.timestamp} · ${trd.tradeId}", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("${trd.symbol} · ${trd.side.label}", color = if (trd.side == OrderSide.BUY) QuoteUpRed else QuoteDownGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("¥${trd.price} × ${trd.quantity}", color = TextWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("手续费 ¥${String.format(Locale.US, "%.1f", trd.fee)}", color = TextGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }
  }
}

@Composable
private fun AttributionPill(label: String, value: Double, color: Color) {
  Column(
    modifier = Modifier
      .background(TerminalSurfaceVariant, RoundedCornerShape(2.dp))
      .padding(horizontal = 4.dp, vertical = 2.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(label, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    Text(
      "${if (value >= 0) "+" else ""}¥${(value / 1000).toInt()}k",
      color = color,
      fontWeight = FontWeight.Bold,
      fontSize = 9.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}
