package com.example.huagold.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.domain.model.HeatmapCell
import com.example.huagold.domain.model.OrderBook
import com.example.huagold.domain.model.OrderBookLevel
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

enum class DepthViewMode {
  LADDER, DEPTH_CHART, HEATMAP
}

@Composable
fun OrderBookView(
  orderBook: OrderBook?,
  heatmapCells: List<HeatmapCell> = emptyList(),
  onPriceSelected: (Double) -> Unit = {}
) {
  var viewMode by remember { mutableStateOf(DepthViewMode.LADDER) }

  if (orderBook == null) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(280.dp)
        .background(TerminalSurface),
      contentAlignment = Alignment.Center
    ) {
      Text("暂无盘口数据", color = TextMuted, fontSize = 12.sp)
    }
    return
  }

  val maxCumVol = max(
    orderBook.bids.maxOfOrNull { it.cumulativeVolume } ?: 1L,
    orderBook.asks.maxOfOrNull { it.cumulativeVolume } ?: 1L
  ).toFloat()

  val imbalance = orderBook.imbalanceRatio
  val imbalancePct = (imbalance * 100).toInt()

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
      .testTag("order_book_container")
  ) {
    // Header & Tabs
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text(
          "LEVEL 2 深度盘口",
          color = GoldAccent,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          orderBook.timestamp,
          color = TextMuted,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf(
          DepthViewMode.LADDER to "五档",
          DepthViewMode.DEPTH_CHART to "深度图",
          DepthViewMode.HEATMAP to "热力图"
        ).forEach { (mode, label) ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(3.dp))
              .background(if (viewMode == mode) GoldMuted else TerminalSurfaceVariant)
              .border(
                1.dp,
                if (viewMode == mode) GoldPrimary else TerminalBorderSubtle,
                RoundedCornerShape(3.dp)
              )
              .clickable { viewMode = mode }
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              label,
              color = if (viewMode == mode) GoldPrimary else TextGray,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    when (viewMode) {
      DepthViewMode.LADDER -> {
        // Table Columns Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("档位", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(32.dp))
          Text("买卖价格", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(70.dp))
          Text("申报量(手)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
          Text("订单数", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(40.dp))
          Text("累计深度", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp))
        }

        // Asks (Sell 5 down to Sell 1)
        Column(modifier = Modifier.fillMaxWidth()) {
          orderBook.asks.forEach { level ->
            LadderRow(
              levelLabel = "卖${level.level}",
              level = level,
              isAsk = true,
              maxCumVol = maxCumVol,
              onClick = { onPriceSelected(level.price) }
            )
          }
        }

        // Central Current Price Strip
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
          contentAlignment = Alignment.Center
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "最新成交: ¥${String.format(Locale.US, "%.2f", orderBook.lastPrice)}",
              color = TextWhite,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )

            // Order Book Imbalance Meter
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("盘口失衡:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
              Text(
                "${if (imbalance >= 0) "+" else ""}$imbalancePct%",
                color = if (imbalance >= 0) QuoteUpRed else QuoteDownGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        // Bids (Buy 1 down to Buy 5)
        Column(modifier = Modifier.fillMaxWidth()) {
          orderBook.bids.forEach { level ->
            LadderRow(
              levelLabel = "买${level.level}",
              level = level,
              isAsk = false,
              maxCumVol = maxCumVol,
              onClick = { onPriceSelected(level.price) }
            )
          }
        }
      }

      DepthViewMode.DEPTH_CHART -> {
        // Visual Cumulative Depth Chart
        CumulativeDepthChartCanvas(orderBook)
      }

      DepthViewMode.HEATMAP -> {
        // Order Book Heatmap
        OrderBookHeatmapCanvas(heatmapCells)
      }
    }
  }
}

@Composable
private fun LadderRow(
  levelLabel: String,
  level: OrderBookLevel,
  isAsk: Boolean,
  maxCumVol: Float,
  onClick: () -> Unit
) {
  val depthFraction = (level.cumulativeVolume / maxCumVol).coerceIn(0.05f, 1.0f)
  val barColor = if (isAsk) QuoteDownGreen.copy(alpha = 0.18f) else QuoteUpRed.copy(alpha = 0.18f)
  val textColor = if (isAsk) QuoteDownGreen else QuoteUpRed

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(22.dp)
      .clickable { onClick() }
  ) {
    // Background Depth Fill Bar
    Box(
      modifier = Modifier
        .fillMaxHeight()
        .fillMaxWidth(depthFraction)
        .align(if (isAsk) Alignment.CenterEnd else Alignment.CenterStart)
        .background(barColor)
    )

    // Text Row
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        levelLabel,
        color = TextMuted,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.width(32.dp)
      )
      Text(
        String.format(Locale.US, "%.2f", level.price),
        color = textColor,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.width(70.dp)
      )
      Text(
        "${level.volume}",
        color = TextWhite,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.width(60.dp)
      )
      Text(
        "${level.orderCount}",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.width(40.dp)
      )
      Text(
        "${level.cumulativeVolume}",
        color = TextGray,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.width(60.dp)
      )
    }
  }
}

@Composable
private fun CumulativeDepthChartCanvas(orderBook: OrderBook) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .height(200.dp)
      .padding(top = 8.dp)
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val midX = w / 2f

      val bids = orderBook.bids
      val asks = orderBook.asks
      if (bids.isEmpty() || asks.isEmpty()) return@Canvas

      val maxVol = max(
        bids.last().cumulativeVolume,
        asks.last().cumulativeVolume
      ).toFloat()

      // Bids Path (Green on left)
      val bidPath = Path()
      bidPath.moveTo(midX, h)
      bids.forEachIndexed { idx, b ->
        val x = midX - (idx + 1).toFloat() / bids.size * midX
        val y = h - (b.cumulativeVolume / maxVol) * (h * 0.85f)
        bidPath.lineTo(x, y)
      }
      bidPath.lineTo(0f, h)
      bidPath.close()

      drawPath(bidPath, color = QuoteUpRed.copy(alpha = 0.35f), style = Fill)

      // Asks Path (Red on right)
      val askPath = Path()
      askPath.moveTo(midX, h)
      asks.forEachIndexed { idx, a ->
        val x = midX + (idx + 1).toFloat() / asks.size * midX
        val y = h - (a.cumulativeVolume / maxVol) * (h * 0.85f)
        askPath.lineTo(x, y)
      }
      askPath.lineTo(w, h)
      askPath.close()

      drawPath(askPath, color = QuoteDownGreen.copy(alpha = 0.35f), style = Fill)

      // Center Divider
      drawLine(
        color = GoldPrimary,
        start = Offset(midX, 0f),
        end = Offset(midX, h),
        strokeWidth = 1.5f
      )
    }
  }
}

@Composable
private fun OrderBookHeatmapCanvas(cells: List<HeatmapCell>) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .height(200.dp)
      .padding(top = 8.dp)
  ) {
    Text(
      "订单簿历史挂单深度分布 (时间 × 价格层级)",
      color = TextMuted,
      fontSize = 9.sp,
      fontFamily = FontFamily.Monospace
    )
    Spacer(modifier = Modifier.height(4.dp))
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      if (cells.isEmpty()) return@Canvas

      val times = cells.map { it.timeBucket }.distinct()
      val prices = cells.map { it.priceLevel }.distinct().sortedDescending()

      val numCols = times.size
      val numRows = prices.size
      val colW = w / max(1, numCols)
      val rowH = h / max(1, numRows)

      cells.forEach { cell ->
        val colIdx = times.indexOf(cell.timeBucket)
        val rowIdx = prices.indexOf(cell.priceLevel)
        if (colIdx >= 0 && rowIdx >= 0) {
          val x = colIdx * colW
          val y = rowIdx * rowH
          val alpha = cell.depthRatio.coerceIn(0.1f, 0.95f)
          val color = GoldPrimary.copy(alpha = alpha)

          drawRect(
            color = color,
            topLeft = Offset(x, y),
            size = androidx.compose.ui.geometry.Size(colW - 1f, rowH - 1f)
          )
        }
      }
    }
  }
}
