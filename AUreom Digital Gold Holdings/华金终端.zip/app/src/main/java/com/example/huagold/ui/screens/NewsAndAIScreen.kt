package com.example.huagold.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.huagold.data.MarketRepository
import com.example.huagold.domain.model.NewsArticle
import com.example.huagold.engine.HuagoldAIEngine
import com.example.ui.theme.*

@Composable
fun NewsAndAIScreen(
  repository: MarketRepository
) {
  val newsList by repository.newsList.collectAsState()
  val quotes by repository.quotes.collectAsState()

  var selectedCategory by remember { mutableStateOf("全部") }
  var userPromptInput by remember { mutableStateOf("为什么今天人民币黄金比国际黄金强？") }
  var aiResponse by remember { mutableStateOf<HuagoldAIEngine.AIResearchAnswer?>(null) }
  var isAiAnalyzing by remember { mutableStateOf(false) }

  val auQuote = quotes["Au99.99"] ?: quotes.values.first()
  val fxRate = quotes["USD/CNY"]?.last ?: 7.1284
  val usdGold = quotes["XAU/USD"]?.last ?: 4058.20

  // Initial trigger for default query
  LaunchedEffect(Unit) {
    if (aiResponse == null) {
      aiResponse = HuagoldAIEngine.analyzeMarketQuery(userPromptInput, auQuote, fxRate, usdGold)
    }
  }

  val filteredNews = remember(selectedCategory, newsList) {
    if (selectedCategory == "全部") newsList
    else newsList.filter { it.category == selectedCategory }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp)
      .testTag("news_and_ai_screen"),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Psychology, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
          Text(
            "华金 AI 贵金属研究助手与实时电讯 (AI RESEARCH & WIRE)",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .background(Color(0x3338BDF8), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text("AI 严格严谨归因", color = CyanAccent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    // 2. 华金 AI Assistant Interactive Lab
    item {
      Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                "华金 AI 深度研究工作台",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
              )
            }
            Text("多步逻辑：观察→变量→机制→证据→不确定性", color = TextMuted, fontSize = 8.sp)
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Preset Question Pills
          Text("研究问题预设模版:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          Spacer(modifier = Modifier.height(3.dp))
          val presets = listOf(
            "为什么今天人民币黄金比国际黄金强？",
            "白银工业需求与光伏排产对金银比的影响",
            "美元走势与在岸黄金基差传导机制"
          )
          LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(presets) { p ->
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(3.dp))
                  .background(TerminalSurfaceVariant)
                  .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
                  .clickable {
                    userPromptInput = p
                    aiResponse = HuagoldAIEngine.analyzeMarketQuery(p, auQuote, fxRate, usdGold)
                  }
                  .padding(horizontal = 6.dp, vertical = 3.dp)
              ) {
                Text(p, color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.SansSerif)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Query Input Box
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = userPromptInput,
              onValueChange = { userPromptInput = it },
              placeholder = { Text("输入研究问题，AI 将基于当前合成行情与计量模型进行严格推演...", fontSize = 10.sp) },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = TerminalSurfaceVariant,
                unfocusedContainerColor = TerminalSurfaceVariant,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedIndicatorColor = GoldPrimary
              ),
              modifier = Modifier.weight(1f)
            )

            Button(
              onClick = {
                aiResponse = HuagoldAIEngine.analyzeMarketQuery(userPromptInput, auQuote, fxRate, usdGold)
              },
              colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
              modifier = Modifier.height(48.dp)
            ) {
              Text("研判", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // AI Structured Answer
          aiResponse?.let { ans ->
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBg, RoundedCornerShape(3.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
                .padding(8.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              // Citation Badge
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0x2238BDF8), RoundedCornerShape(2.dp))
                  .padding(4.dp)
              ) {
                Text(
                  ans.dataSourceTag,
                  color = CyanAccent,
                  fontSize = 8.sp,
                  fontFamily = FontFamily.Monospace
                )
              }

              // 1. Observed Data
              Text(
                ans.observedData,
                color = TextWhite,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp
              )

              // 2. Key Variables
              Text(
                "• 核心关联变量: ${ans.keyVariables.joinToString(" | ")}",
                color = GoldAccent,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )

              // 3. Mechanism
              Text(
                ans.mechanismExplanation,
                color = TextGray,
                fontSize = 9.sp,
                fontFamily = FontFamily.SansSerif,
                lineHeight = 14.sp
              )

              // 4. Evidence
              Text(
                ans.empiricalEvidence,
                color = StatusLive,
                fontSize = 9.sp,
                fontFamily = FontFamily.SansSerif,
                lineHeight = 14.sp
              )

              // 5. Uncertainties & Risks
              Text(
                ans.uncertaintiesAndRisks,
                color = QuoteUpRed,
                fontSize = 8.sp,
                fontFamily = FontFamily.SansSerif,
                lineHeight = 13.sp
              )
            }
          }
        }
      }
    }

    // 3. News Wire Categories & List
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurface)
          .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "PRECIOUS METALS NEWS WIRE / 贵金属电讯与研报",
            color = GoldAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )

          Text(
            "共 ${filteredNews.size} 条",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Categories Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          val cats = listOf("全部", "中国", "黄金", "白银", "光伏工业", "央行", "宏观")
          items(cats) { c ->
            val isSel = selectedCategory == c
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isSel) GoldMuted else TerminalSurfaceVariant)
                .border(1.dp, if (isSel) GoldPrimary else TerminalBorderSubtle, RoundedCornerShape(3.dp))
                .clickable { selectedCategory = c }
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(c, color = if (isSel) GoldAccent else TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        filteredNews.forEach { news ->
          NewsItemCard(news = news)
          Spacer(modifier = Modifier.height(4.dp))
        }
      }
    }
  }
}

@Composable
private fun NewsItemCard(news: NewsArticle) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(3.dp))
      .background(TerminalSurfaceVariant)
      .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(news.time, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Box(
          modifier = Modifier
            .background(Color(0x22818CF8), RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text(news.category, color = IndigoAccent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        Text(news.source, color = TextMuted, fontSize = 8.sp)
      }

      Box(
        modifier = Modifier
          .background(
            when (news.impactDirection) {
              "BULLISH" -> QuoteUpRedBg
              "BEARISH" -> QuoteDownGreenBg
              else -> Color(0x2294A3B8)
            },
            RoundedCornerShape(2.dp)
          )
          .padding(horizontal = 4.dp, vertical = 1.dp)
      ) {
        Text(
          "影响: ${news.impactAsset} (${news.impactDirection})",
          color = when (news.impactDirection) {
            "BULLISH" -> QuoteUpRed
            "BEARISH" -> QuoteDownGreen
            else -> TextGray
          },
          fontSize = 8.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      news.title,
      color = TextWhite,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp
    )

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      news.summary,
      color = TextGray,
      fontSize = 9.sp,
      lineHeight = 13.sp
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      "关联标的: ${news.relatedSymbols.joinToString(", ")}",
      color = CyanAccent,
      fontSize = 8.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}
