package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GeumhanApp
import com.example.ui.GeumhanViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Instantiate our centralized state simulator ViewModel
                val geumhanViewModel: GeumhanViewModel = viewModel()
                
                // Launch the premium Korean precious metals platform
                GeumhanApp(viewModel = geumhanViewModel)
            }
        }
    }
}
