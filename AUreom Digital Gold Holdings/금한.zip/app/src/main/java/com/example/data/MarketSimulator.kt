package com.example.data

import kotlin.math.sin
import kotlin.random.Random

object MarketSimulator {
    private val random = Random(42)

    // Baseline international prices
    var usdKrw = 1345.0
    var goldUsdOz = 2580.0
    var silverUsdOz = 31.50
    var platUsdOz = 985.0
    var palUsdOz = 1020.0

    // Dealer pricing params
    const val DEALER_SPREAD_PERCENT = 0.0025 // 0.25% spread
    const val PHYSICAL_PREMIUM_PERCENT = 0.015 // 1.5% premium for physical delivery

    // Generate current prices via triangulation
    fun getCurrentPrices(): List<MetalPrice> {
        val xauMidG = (goldUsdOz * usdKrw) / 31.1034768
        val xagMidG = (silverUsdOz * usdKrw) / 31.1034768
        val xptMidG = (platUsdOz * usdKrw) / 31.1034768
        val xpdMidG = (palUsdOz * usdKrw) / 31.1034768

        return listOf(
            MetalPrice(
                ticker = "XAU/KRW",
                displayName = "금 현물 (KRX형)",
                priceKrw = xauMidG,
                priceUsd = goldUsdOz,
                changePercent = 0.85,
                bid = xauMidG * (1.0 - DEALER_SPREAD_PERCENT),
                ask = xauMidG * (1.0 + DEALER_SPREAD_PERCENT),
                unit = "g",
                purity = "99.99%",
                volume = 125400.0,
                high = xauMidG * 1.012,
                low = xauMidG * 0.991
            ),
            MetalPrice(
                ticker = "XAG/KRW",
                displayName = "은 현물",
                priceKrw = xagMidG,
                priceUsd = silverUsdOz,
                changePercent = -1.24,
                bid = xagMidG * (1.0 - DEALER_SPREAD_PERCENT),
                ask = xagMidG * (1.0 + DEALER_SPREAD_PERCENT),
                unit = "g",
                purity = "99.9%",
                volume = 8425000.0,
                high = xagMidG * 1.025,
                low = xagMidG * 0.978
            ),
            MetalPrice(
                ticker = "XPT/KRW",
                displayName = "플래티넘 현물",
                priceKrw = xptMidG,
                priceUsd = platUsdOz,
                changePercent = 0.12,
                bid = xptMidG * (1.0 - DEALER_SPREAD_PERCENT * 1.5),
                ask = xptMidG * (1.0 + DEALER_SPREAD_PERCENT * 1.5),
                unit = "g",
                purity = "99.9%",
                volume = 32500.0,
                high = xptMidG * 1.008,
                low = xptMidG * 0.995
            ),
            MetalPrice(
                ticker = "XPD/KRW",
                displayName = "팔라듐 현물",
                priceKrw = xpdMidG,
                priceUsd = palUsdOz,
                changePercent = -0.45,
                bid = xpdMidG * (1.0 - DEALER_SPREAD_PERCENT * 2.0),
                ask = xpdMidG * (1.0 + DEALER_SPREAD_PERCENT * 2.0),
                unit = "g",
                purity = "99.9%",
                volume = 11400.0,
                high = xpdMidG * 1.015,
                low = xpdMidG * 0.982
            ),
            MetalPrice(
                ticker = "USD/KRW",
                displayName = "원/달러 환율",
                priceKrw = usdKrw,
                priceUsd = 1.0,
                changePercent = 0.18,
                bid = usdKrw - 0.5,
                ask = usdKrw + 0.5,
                unit = "원",
                purity = "N/A",
                volume = 125000000.0,
                high = usdKrw + 4.5,
                low = usdKrw - 3.2
            )
        )
    }

    // Tick the market with micro-fluctuations (called every few seconds)
    fun tickPrices() {
        usdKrw += (random.nextDouble() - 0.49) * 1.2
        goldUsdOz += (random.nextDouble() - 0.485) * 3.5
        silverUsdOz += (random.nextDouble() - 0.495) * 0.08
        platUsdOz += (random.nextDouble() - 0.50) * 1.5
        palUsdOz += (random.nextDouble() - 0.51) * 2.0

        // Clamp values to stay within realistic parameters
        if (usdKrw < 1200) usdKrw = 1200.0
        if (usdKrw > 1500) usdKrw = 1500.0
        if (goldUsdOz < 1800) goldUsdOz = 1800.0
        if (silverUsdOz < 15) silverUsdOz = 15.0
    }

    // Unit conversion engine (KRW/g -> Don / Kg / Nyang / Oz)
    fun convertUnit(grams: Double, targetUnit: String, midPricePerGram: Double): Map<String, Any> {
        val don = grams / 3.75
        val kg = grams / 1000.0
        val troyOz = grams / 31.1034768
        val nyang = grams / 37.5

        val rawMetalValue = grams * midPricePerGram
        val spreadCost = rawMetalValue * DEALER_SPREAD_PERCENT
        val physicalPremium = rawMetalValue * PHYSICAL_PREMIUM_PERCENT
        val estimatedBuyCost = rawMetalValue + spreadCost + physicalPremium
        val estimatedSellValue = rawMetalValue - spreadCost

        return mapOf(
            "grams" to grams,
            "don" to don,
            "kg" to kg,
            "troyOz" to troyOz,
            "nyang" to nyang,
            "metalValue" to rawMetalValue,
            "dealerSpread" to spreadCost,
            "physicalPremium" to physicalPremium,
            "buyPrice" to estimatedBuyCost,
            "sellPrice" to estimatedSellValue
        )
    }

    // Pure Canvas candlestick / line series synthetic pre-generation
    fun getHistoryPoints(ticker: String, range: String): List<PriceHistoryPoint> {
        val list = mutableListOf<PriceHistoryPoint>()
        val count = when (range) {
            "1D" -> 24
            "1W" -> 35
            "1M" -> 30
            "1Y" -> 50
            else -> 30
        }
        val currentPrice = getCurrentPrices().find { it.ticker == ticker }?.priceKrw ?: 100000.0
        val interval = 3600000L // 1 hour
        val now = System.currentTimeMillis()

        for (i in count downTo 0) {
            val offsetTime = now - i * interval
            val drift = sin(i.toDouble() / 5.0) * (currentPrice * 0.015)
            val noise = (random.nextDouble() - 0.5) * (currentPrice * 0.005)
            list.add(PriceHistoryPoint(offsetTime, currentPrice - drift + noise))
        }
        return list
    }

    // Order Book Depth Generator (10 Levels of bids and asks)
    fun getOrderBook(midPrice: Double): Pair<List<OrderBookItem>, List<OrderBookItem>> {
        val bids = mutableListOf<OrderBookItem>()
        val asks = mutableListOf<OrderBookItem>()

        var bidCum = 0.0
        var askCum = 0.0

        for (i in 1..10) {
            // Asks (above mid price)
            val askPrice = Math.round((midPrice + i * (midPrice * 0.0004)) * 10.0) / 10.0
            val askQty = (15 - i) * (random.nextDouble() * 20.0 + 5.0)
            askCum += askQty
            asks.add(OrderBookItem(askPrice, askQty, askCum))

            // Bids (below mid price)
            val bidPrice = Math.round((midPrice - i * (midPrice * 0.0004)) * 10.0) / 10.0
            val bidQty = (15 - i) * (random.nextDouble() * 20.0 + 5.0)
            bidCum += bidQty
            bids.add(OrderBookItem(bidPrice, bidQty, bidCum))
        }

        return Pair(bids, asks)
    }
}
