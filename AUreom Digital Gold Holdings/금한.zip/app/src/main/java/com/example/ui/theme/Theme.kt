package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GeumhanColorScheme = darkColorScheme(
    primary = GeumhanGold,
    onPrimary = GeumhanBg,
    primaryContainer = GeumhanGoldDark,
    onPrimaryContainer = GeumhanGoldLight,
    secondary = GeumhanSilver,
    onSecondary = GeumhanBg,
    secondaryContainer = GeumhanDivider,
    onSecondaryContainer = GeumhanSilverLight,
    background = GeumhanBg,
    onBackground = GeumhanTextPrimary,
    surface = GeumhanSurface,
    onSurface = GeumhanTextPrimary,
    surfaceVariant = GeumhanCard,
    onSurfaceVariant = GeumhanTextSecondary,
    outline = GeumhanDivider,
    error = PriceDown
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GeumhanColorScheme,
        typography = Typography,
        content = content
    )
}
