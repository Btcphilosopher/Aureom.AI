package com.example.data

// Domain Models for GEUMHAN (금한) Platform

data class MetalPrice(
    val ticker: String,           // e.g., "XAU/KRW", "XAG/KRW", "USD/KRW", "XAU/USD"
    val displayName: String,      // e.g., "금 현물 (KRX형)", "은 현물"
    val priceKrw: Double,         // Price in KRW (usually per gram)
    val priceUsd: Double,         // Price in USD (usually per troy oz)
    val changePercent: Double,     // Daily change %
    val bid: Double,
    val ask: Double,
    val unit: String,             // e.g., "g", "돈", "kg"
    val purity: String,           // e.g., "99.99%", "99.9%"
    val volume: Double,           // Daily synthetic volume
    val high: Double,
    val low: Double
)

data class PriceHistoryPoint(
    val timestamp: Long,
    val price: Double
)

data class OrderBookItem(
    val price: Double,
    val quantity: Double,
    val cumulative: Double
)

data class OrderItem(
    val id: String,
    val ticker: String,           // "XAU/KRW" or "XAG/KRW"
    val side: String,             // "BUY" or "SELL"
    val type: String,             // "LIMIT" or "MARKET"
    val price: Double,            // Order price
    val quantityGrams: Double,    // Size in grams
    val filledGrams: Double,      // Completed fill
    val status: String,           // "OPEN", "PARTIAL", "FILLED", "CANCELLED"
    val timestamp: Long
)

data class LedgerEntry(
    val id: String,
    val timestamp: Long,
    val actionType: String,       // "TRADE_BUY", "TRADE_SELL", "VAULT_WITHDRAW", "SCRAP_BUYBACK", "CASH_DEPOSIT"
    val debitAccount: String,     // e.g., "CASH_ASSET", "GOLD_LEDGER_XAU"
    val creditAccount: String,    // e.g., "CUSTOMER_LIABILITY", "CASH_ASSET"
    val quantity: Double,         // Metal quantity (g) or cash amount (KRW)
    val unit: String,             // "g", "KRW"
    val valuationKrw: Long,       // Value in Korean Won
    val description: String
)

data class GoldBar(
    val id: String,
    val serialNumber: String,
    val refinery: String,         // e.g., "서울불리온", "한강귀금속", "한국정밀금속"
    val purity: Double,           // e.g., 99.99, 18.0 (for jewellery/scrap estimation)
    val purityType: String,       // "24K", "18K", "14K"
    val grossWeightG: Double,     // Physical weight
    val fineWeightG: Double,      // Pure gold content
    val manufactureDate: String,
    val vaultZone: String,        // "Zone A" (Retail), "Zone B" (High Security), etc.
    val rackId: String,           // e.g., "Rack 03"
    val drawerId: String,         // e.g., "Box 14"
    val status: String,           // "VAULTED" (보관중), "TRANSFERRING" (이동중), "RELEASED" (출고완료), "COLLATERAL" (담보설정), "LOCKED" (잠금)
    val owner: String,             // "USER" or "DEALER_A", etc.
    val isLocked: Boolean = false
)

data class RfqRequest(
    val id: String,
    val product: String,          // e.g., "99.99% 골드바 1kg"
    val quantityKg: Double,       // e.g., 25.0
    val totalGrams: Double,
    val targetCity: String,       // e.g., "서울", "부산"
    val expiresAt: Long,          // countdown timestamp
    val status: String,           // "PENDING", "ACCEPTED", "EXPIRED"
    val quotes: List<RfqQuote>,
    val chosenQuoteId: String? = null
)

data class RfqQuote(
    val id: String,
    val dealerName: String,
    val pricePerGram: Double,
    val totalAmountKrw: Long,
    val deliveryDays: Int,
    val confidenceScore: Double
)

data class ScrapAssay(
    val id: String,
    val weightG: Double,
    val inputPurity: String,       // "24K", "18K", "14K", "99.9%"
    val estimatedPurity: Double,  // e.g., 75.32% (calculated from density/XRF)
    val density: Double,          // g/cm^3
    val xrfGoldPercent: Double,   // XRF scanner reading
    val confidence: Double,       // % confidence
    val fineGoldGrams: Double,
    val valuationKrw: Long,       // Cash value payout after fees
    val refiningFeeKrw: Long,
    val timestamp: Long
)

data class JewelryItem(
    val id: String,
    val name: String,
    val purityType: String,       // "24K", "18K", "14K"
    val metalWeightG: Double,
    val designCostKrw: Long,       // 세공비
    val brandPremiumKrw: Long,    // 브랜드 마진
    val taxRate: Double = 0.10,   // VAT 10%
    val description: String
)

data class StressImpact(
    val scenarioName: String,
    val scenarioDesc: String,
    val goldChangePercent: Double,
    val silverChangePercent: Double,
    val fxChangePercent: Double,
    val pnlImpactKrw: Long,
    val portfolioValueAfterKrw: Long
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
