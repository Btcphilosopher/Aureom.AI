package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeumhanApp(viewModel: GeumhanViewModel) {
    var currentTab by remember { mutableStateOf("DASHBOARD") }

    // Collect values from StateFlow
    val prices by viewModel.prices.collectAsStateWithLifecycle()
    val cash by viewModel.cashBalance.collectAsStateWithLifecycle()
    val metals by viewModel.metalBalances.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val activeRfqs by viewModel.activeRfqs.collectAsStateWithLifecycle()
    val bars by viewModel.vaultBars.collectAsStateWithLifecycle()

    val goldGrams = metals["XAU"] ?: 0.0
    val silverGrams = metals["XAG"] ?: 0.0
    val platGrams = metals["XPT"] ?: 0.0
    val palGrams = metals["XPD"] ?: 0.0

    val goldSpot = prices.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
    val silverSpot = prices.find { it.ticker == "XAG/KRW" }?.priceKrw ?: 1250.0
    val platSpot = prices.find { it.ticker == "XPT/KRW" }?.priceKrw ?: 45000.0
    val palSpot = prices.find { it.ticker == "XPD/KRW" }?.priceKrw ?: 40000.0

    val goldValue = goldGrams * goldSpot
    val silverValue = silverGrams * silverSpot
    val platValue = platGrams * platSpot
    val palValue = palGrams * palSpot
    val totalAssetsValue = cash + goldValue + silverValue + platValue + palValue

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Surface(
                            color = GeumhanGold,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "금한",
                                color = GeumhanBg,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "GEUMHAN",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = GeumhanGold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "한국 귀금속 금융·거래 플랫폼",
                                fontSize = 10.sp,
                                color = GeumhanSilver,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GeumhanBg,
                    titleContentColor = GeumhanTextPrimary
                ),
                actions = {
                    Row(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(GeumhanSurface, RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageName = Icons.Default.Wallet,
                            contentDescription = "Wallet",
                            tint = GeumhanGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "₩${String.format("%,d", cash)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeumhanTextPrimary
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = GeumhanBg,
                tonalElevation = 8.dp,
                modifier = Modifier.height(72.dp)
            ) {
                val tabs = listOf(
                    Triple("DASHBOARD", "대시보드", Icons.Default.Dashboard),
                    Triple("TRADE", "HTS 거래", Icons.Default.QueryStats),
                    Triple("VAULT", "디지털 금고", Icons.Default.Domain),
                    Triple("MERCHANT", "상인/RFQ", Icons.Default.Storefront),
                    Triple("RISK", "리스크/분석", Icons.Default.Percent),
                    Triple("AI", "금한 AI", Icons.Default.Psychology)
                )
                tabs.forEach { (tabId, label, icon) ->
                    NavigationBarItem(
                        selected = currentTab == tabId,
                        onClick = { currentTab = tabId },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                modifier = Modifier.size(20.dp),
                                tint = if (currentTab == tabId) GeumhanGold else GeumhanSilver
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 9.sp,
                                fontWeight = if (currentTab == tabId) FontWeight.Bold else FontWeight.Normal,
                                color = if (currentTab == tabId) GeumhanGold else GeumhanSilver
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = GeumhanSurface
                        )
                    )
                }
            }
        },
        containerColor = GeumhanBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            when (currentTab) {
                "DASHBOARD" -> DashboardScreen(
                    prices = prices,
                    cash = cash,
                    goldGrams = goldGrams,
                    silverGrams = silverGrams,
                    goldSpot = goldSpot,
                    silverSpot = silverSpot,
                    totalValue = totalAssetsValue,
                    viewModel = viewModel,
                    onNavigateToTrade = { currentTab = "TRADE" }
                )
                "TRADE" -> TradeExchangeScreen(
                    prices = prices,
                    orders = orders,
                    bids = viewModel.bids.collectAsStateWithLifecycle().value,
                    asks = viewModel.asks.collectAsStateWithLifecycle().value,
                    viewModel = viewModel
                )
                "VAULT" -> VaultDigitalTwinScreen(
                    bars = bars,
                    goldSpot = goldSpot,
                    silverSpot = silverSpot,
                    viewModel = viewModel
                )
                "MERCHANT" -> MerchantTerminalScreen(
                    activeRfqs = activeRfqs,
                    goldSpot = goldSpot,
                    viewModel = viewModel
                )
                "RISK" -> RiskAnalyticsScreen(
                    viewModel = viewModel,
                    totalValue = totalAssetsValue,
                    cash = cash,
                    goldGrams = goldGrams,
                    silverGrams = silverGrams,
                    goldSpot = goldSpot,
                    silverSpot = silverSpot
                )
                "AI" -> GeumhanAiScreen(
                    viewModel = viewModel,
                    goldSpot = goldSpot,
                    silverSpot = silverSpot,
                    goldGrams = goldGrams,
                    silverGrams = silverGrams,
                    cash = cash
                )
            }
        }
    }
}

// Helper Compose Icon function
@Composable
fun Icon(imageName: androidx.compose.ui.graphics.vector.ImageVector, contentDescription: String, tint: Color, modifier: Modifier) {
    androidx.compose.material3.Icon(
        imageVector = imageName,
        contentDescription = contentDescription,
        tint = tint,
        modifier = modifier
    )
}

// 1. DASHBOARD SCREEN
@Composable
fun DashboardScreen(
    prices: List<MetalPrice>,
    cash: Long,
    goldGrams: Double,
    silverGrams: Double,
    goldSpot: Double,
    silverSpot: Double,
    totalValue: Double,
    viewModel: GeumhanViewModel,
    onNavigateToTrade: () -> Unit
) {
    val scrollState = rememberScrollState()
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Portfolio Valuation Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GeumhanDivider),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "순자산 평가 총액",
                        fontSize = 12.sp,
                        color = GeumhanSilver,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "₩${String.format("%,.0f", totalValue)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = GeumhanGold
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "금 보유량", fontSize = 10.sp, color = GeumhanSilver)
                            Text(
                                text = "${String.format("%.2f", goldGrams)} g",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanTextPrimary
                            )
                            Text(
                                text = "(${String.format("%.2f", goldGrams / 3.75)} 돈)",
                                fontSize = 11.sp,
                                color = GeumhanSilver
                            )
                        }
                        Column {
                            Text(text = "은 보유량", fontSize = 10.sp, color = GeumhanSilver)
                            Text(
                                text = "${String.format("%,.1f", silverGrams)} g",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanTextPrimary
                            )
                            Text(
                                text = "(${String.format("%.1f", silverGrams / 3.75)} 돈)",
                                fontSize = 11.sp,
                                color = GeumhanSilver
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "귀금속 평가", fontSize = 10.sp, color = GeumhanSilver)
                            Text(
                                text = "₩${String.format("%,.0f", (goldGrams * goldSpot) + (silverGrams * silverSpot))}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanGoldLight
                            )
                            Text(text = "원화 자산", fontSize = 11.sp, color = GeumhanSilver)
                        }
                    }
                }
            }
        }

        // Real-Time Spot Price Tickers Grid
        item {
            Text(
                text = "실시간 귀금속 현물 가격 (XAU / XAG)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = GeumhanTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        items(prices.take(3)) { metal ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToTrade() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = metal.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (metal.ticker.startsWith("XAU")) GeumhanGoldDark else GeumhanDivider,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = metal.ticker,
                                    color = if (metal.ticker.startsWith("XAU")) GeumhanGoldLight else GeumhanSilverLight,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "순도: ${metal.purity} | 단위: 1${metal.unit}",
                            fontSize = 11.sp,
                            color = GeumhanSilver
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₩${String.format("%,.0f", metal.priceKrw)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = if (metal.changePercent >= 0.0) PriceUp else PriceDown
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (metal.changePercent >= 0.0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = "Trend",
                                tint = if (metal.changePercent >= 0.0) PriceUp else PriceDown,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${if (metal.changePercent >= 0.0) "+" else ""}${metal.changePercent}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (metal.changePercent >= 0.0) PriceUp else PriceDown
                            )
                        }
                    }
                }
            }
        }

        // Live Gram-to-Don Korean Unit Converter Engine
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, GeumhanDivider),
                modifier = Modifier.fillMaxWidth()
            ) {
                var inputGramsStr by remember { mutableStateOf("37.5") }
                val inputGrams = inputGramsStr.toDoubleOrNull() ?: 0.0
                val conv = MarketSimulator.convertUnit(inputGrams, "돈", goldSpot)

                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "한국형 실시간 중량·가치 환산 엔진",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = GeumhanGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "그램(g) 입력을 한국 전통 단위인 '돈'으로 자동 환산하고 스프레드를 정산합니다.",
                        fontSize = 11.sp,
                        color = GeumhanSilver
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = inputGramsStr,
                        onValueChange = { inputGramsStr = it },
                        label = { Text("중량 입력 (g 단위)", color = GeumhanSilver) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GeumhanGold,
                            unfocusedBorderColor = GeumhanDivider,
                            focusedTextColor = GeumhanTextPrimary,
                            unfocusedTextColor = GeumhanTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "한국식 돈 환산", fontSize = 10.sp, color = GeumhanSilver)
                            Text(
                                text = "${String.format("%.2f", conv["don"] as Double)} 돈",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanTextPrimary
                            )
                        }
                        Column {
                            Text(text = "금속 순수 시세 가치", fontSize = 10.sp, color = GeumhanSilver)
                            Text(
                                text = "₩${String.format("%,.0f", conv["metalValue"] as Double)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeumhanTextPrimary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = GeumhanDivider)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "최종 매매 수령액 (스프레드 공제)", fontSize = 10.sp, color = PriceDown)
                            Text(
                                text = "₩${String.format("%,.0f", conv["sellPrice"] as Double)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PriceDown
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "실물 바 인출 결제액 (프리미엄 포함)", fontSize = 10.sp, color = PriceUp)
                            Text(
                                text = "₩${String.format("%,.0f", conv["buyPrice"] as Double)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PriceUp
                            )
                        }
                    }
                }
            }
        }

        // Information disclaimer
        item {
            Text(
                text = "※ 본 시세와 자산 보고서는 '금한' 플랫폼 교육용 합성 시나리오에 의해 실시간 가동 중이며 실제 금융 시장 거래와 무관합니다.",
                fontSize = 10.sp,
                color = GeumhanSilver,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )
        }
    }
}

// 2. EXCHANGE & TRADE SCREEN (HTS)
@Composable
fun TradeExchangeScreen(
    prices: List<MetalPrice>,
    orders: List<OrderItem>,
    bids: List<OrderBookItem>,
    asks: List<OrderBookItem>,
    viewModel: GeumhanViewModel
) {
    var selectedTicker by remember { mutableStateOf("XAU/KRW") }
    val activeMetal = prices.find { it.ticker == selectedTicker } ?: return
    val spotPrice = activeMetal.priceKrw

    // Order inputs
    var orderSide by remember { mutableStateOf("BUY") } // BUY or SELL
    var orderType by remember { mutableStateOf("LIMIT") } // LIMIT or MARKET
    var inputPrice by remember { mutableStateOf(String.format("%.0f", spotPrice)) }
    var inputQuantityG by remember { mutableStateOf("10.0") } // Default 10g

    // Keep input price in sync if spot changes in MARKET order
    LaunchedEffect(spotPrice) {
        if (orderType == "MARKET") {
            inputPrice = String.format("%.0f", spotPrice)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Ticker Selector Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("XAU/KRW" to "금 현물", "XAG/KRW" to "은 현물").forEach { (ticker, label) ->
                    val isSel = selectedTicker == ticker
                    Button(
                        onClick = {
                            selectedTicker = ticker
                            inputPrice = String.format("%.0f", prices.find { it.ticker == ticker }?.priceKrw ?: 100000.0)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSel) GeumhanGold else GeumhanSurface,
                            contentColor = if (isSel) GeumhanBg else GeumhanSilverLight
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "$label ($ticker)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // HTS Layout: Live Order Book + Order Form
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Live Order Book Depth (Left side, takes 45% width)
                Column(
                    modifier = Modifier
                        .weight(0.45f)
                        .background(GeumhanSurface, RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "호가 잔량 (Order Book)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GeumhanSilver,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Asks (Sells, in red)
                    asks.take(5).reversed().forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "₩${String.format("%,.0f", item.price)}",
                                color = PriceDown,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = String.format("%.1f", item.quantity),
                                color = GeumhanSilverLight,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Mid Price Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(GeumhanDivider, RoundedCornerShape(4.dp))
                            .padding(vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "현재가: ₩${String.format("%,.0f", spotPrice)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = if (activeMetal.changePercent >= 0.0) PriceUp else PriceDown
                        )
                    }

                    // Bids (Buys, in green)
                    bids.take(5).forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "₩${String.format("%,.0f", item.price)}",
                                color = PriceUp,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = String.format("%.1f", item.quantity),
                                color = GeumhanSilverLight,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Order Placement Form (Right side, takes 55% width)
                Column(
                    modifier = Modifier
                        .weight(0.55f)
                        .background(GeumhanSurface, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    // Side Switch: BUY / SELL
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("BUY" to "매수", "SELL" to "매도").forEach { (side, label) ->
                            val isSel = orderSide == side
                            val activeColor = if (side == "BUY") PriceUp else PriceDown
                            Button(
                                onClick = { orderSide = side },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) activeColor else GeumhanDivider,
                                    contentColor = GeumhanTextPrimary
                                ),
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp)
                            ) {
                                Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Type Switch: LIMIT / MARKET
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("LIMIT" to "지정가", "MARKET" to "시장가").forEach { (type, label) ->
                            val isSel = orderType == type
                            Button(
                                onClick = {
                                    orderType = type
                                    if (type == "MARKET") {
                                        inputPrice = String.format("%.0f", spotPrice)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) GeumhanGold else GeumhanDivider,
                                    contentColor = if (isSel) GeumhanBg else GeumhanTextPrimary
                                ),
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(30.dp)
                            ) {
                                Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Price Input (disabled in market order)
                    OutlinedTextField(
                        value = inputPrice,
                        onValueChange = { if (orderType == "LIMIT") inputPrice = it },
                        label = { Text("주문 단가 (₩)", color = GeumhanSilver, fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        enabled = orderType == "LIMIT",
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GeumhanGold,
                            unfocusedBorderColor = GeumhanDivider,
                            focusedTextColor = GeumhanTextPrimary,
                            unfocusedTextColor = GeumhanTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("price_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quantity Input
                    OutlinedTextField(
                        value = inputQuantityG,
                        onValueChange = { inputQuantityG = it },
                        label = { Text("주문 수량 (g)", color = GeumhanSilver, fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GeumhanGold,
                            unfocusedBorderColor = GeumhanDivider,
                            focusedTextColor = GeumhanTextPrimary,
                            unfocusedTextColor = GeumhanTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quantity_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Submit Order Button
                    val q = inputQuantityG.toDoubleOrNull() ?: 0.0
                    val p = inputPrice.toDoubleOrNull() ?: 0.0
                    val totalCost = q * p
                    
                    Button(
                        onClick = {
                            viewModel.placeOrder(
                                ticker = selectedTicker,
                                side = orderSide,
                                type = orderType,
                                price = p,
                                quantityG = q
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderSide == "BUY") PriceUp else PriceDown,
                            contentColor = GeumhanTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_order_button")
                    ) {
                        Text(
                            text = "${if (orderSide == "BUY") "즉시 매수" else "즉시 매도"} (₩${String.format("%,.0f", totalCost)})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Matching Engine Status Alert
        item {
            Surface(
                color = GeumhanSurface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, GeumhanGoldDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val infiniteTransition = rememberInfiniteTransition()
                    val pulseAlpha by infiniteTransition.animateFloat(
                        initialValue = 0.3f,
                        targetValue = 1.0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(PriceUp.copy(alpha = pulseAlpha), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "실시간 매칭 엔진 가동중 (가격·시간 우선 연속 경쟁 매매)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeumhanGoldLight
                    )
                }
            }
        }

        // Active Orders & Recent Trade History Title
        item {
            Text(
                text = "내 대기 주문 및 체결 내역",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = GeumhanTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        if (orders.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "접수된 활성 주문이 없습니다.", color = GeumhanSilver, fontSize = 12.sp)
                }
            }
        } else {
            items(orders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = GeumhanCard),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = if (order.side == "BUY") PriceUp.copy(alpha = 0.15f) else PriceDown.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (order.side == "BUY") "매수" else "매도",
                                        color = if (order.side == "BUY") PriceUp else PriceDown,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = order.ticker,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GeumhanTextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "수량: ${order.quantityGrams}g | 가격: ₩${String.format("%,.0f", order.price)}",
                                fontSize = 11.sp,
                                color = GeumhanSilver
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Surface(
                                color = when (order.status) {
                                    "FILLED" -> SafeGreen.copy(alpha = 0.15f)
                                    "OPEN" -> StatusLock.copy(alpha = 0.15f)
                                    else -> GeumhanDivider
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = when (order.status) {
                                        "FILLED" -> "체결완료"
                                        "OPEN" -> "대기중"
                                        "CANCELLED" -> "취소됨"
                                        else -> order.status
                                    },
                                    color = when (order.status) {
                                        "FILLED" -> PriceUp
                                        "OPEN" -> StatusLock
                                        else -> GeumhanSilverLight
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            if (order.status == "OPEN") {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "취소",
                                    fontSize = 11.sp,
                                    color = PriceDown,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable { viewModel.cancelOrder(order.id) }
                                        .padding(4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. VAULT DIGITAL TWIN SCREEN
@Composable
fun VaultDigitalTwinScreen(
    bars: List<GoldBar>,
    goldSpot: Double,
    silverSpot: Double,
    viewModel: GeumhanViewModel
) {
    var selectedZone by remember { mutableStateOf("A구역 (프리미엄 관)") }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Vault Twin Visual Grid Representation Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, GeumhanDivider),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "디지털 트윈 금고 (Vault Digital Twin)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GeumhanGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "서울 금고 구역의 실물 바(Bar) 안치 위치 및 보안 제어 상태를 실시간 매핑합니다.",
                        fontSize = 11.sp,
                        color = GeumhanSilver
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Interactive Vault Map / Grid Drawing with Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(GeumhanBg, RoundedCornerShape(8.dp))
                            .border(1.dp, GeumhanDivider, RoundedCornerShape(8.dp))
                    ) {
                        val cellW = size.width / 4f
                        val cellH = size.height / 2f
                        
                        // Draw Zone slots
                        for (row in 0..1) {
                            for (col in 0..3) {
                                val x = col * cellW
                                val y = row * cellH
                                val isOccupied = (row * 4 + col) < bars.filter { it.status == "VAULTED" || it.status == "COLLATERAL" }.size
                                val hasLock = bars.any { it.isLocked && (it.id.hashCode() % 8) == (row * 4 + col) }

                                drawRect(
                                    color = if (isOccupied) GeumhanGoldDark.copy(alpha = 0.5f) else Color.Transparent,
                                    topLeft = Offset(x + 4, y + 4),
                                    size = androidx.compose.ui.geometry.Size(cellW - 8, cellH - 8)
                                )
                                drawRect(
                                    color = if (isOccupied) GeumhanGold else GeumhanDivider,
                                    topLeft = Offset(x + 4, y + 4),
                                    size = androidx.compose.ui.geometry.Size(cellW - 8, cellH - 8),
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("A구역 (프리미엄 관)", "B구역 (고보안 금고)", "C구역 (실버벌크 관)").forEach { zone ->
                            val isSel = selectedZone == zone
                            Button(
                                onClick = { selectedZone = zone },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) GeumhanGold else GeumhanDivider,
                                    contentColor = if (isSel) GeumhanBg else GeumhanTextPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(28.dp)
                            ) {
                                Text(text = zone.split(" ")[0], fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Physical Bars List
        item {
            Text(
                text = "$selectedZone 내 실물 보관 리스트",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = GeumhanTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        val filteredBars = bars.filter { it.vaultZone == selectedZone }
        if (filteredBars.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "해당 구역 금고에 보관 중인 실물 귀금속이 없습니다.", color = GeumhanSilver, fontSize = 12.sp)
                }
            }
        } else {
            items(filteredBars) { bar ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = GeumhanCard),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (bar.purityType == "999") Icons.Default.Circle else Icons.Default.InvertColors,
                                        contentDescription = "Type",
                                        tint = if (bar.purityType == "999") GeumhanSilver else GeumhanGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${bar.grossWeightG}g 바 (${bar.purityType} Purity)",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GeumhanTextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "일련번호: ${bar.serialNumber}",
                                    fontSize = 11.sp,
                                    color = GeumhanSilver
                                )
                            }

                            // Dynamic status badge
                            Surface(
                                color = when (bar.status) {
                                    "VAULTED" -> SafeGreen.copy(alpha = 0.15f)
                                    "COLLATERAL" -> StatusLock.copy(alpha = 0.15f)
                                    "RELEASED" -> GeumhanDivider
                                    else -> GeumhanDivider
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = when (bar.status) {
                                        "VAULTED" -> "보관중"
                                        "COLLATERAL" -> "담보설정됨"
                                        "RELEASED" -> "인출출고"
                                        else -> bar.status
                                    },
                                    color = when (bar.status) {
                                        "VAULTED" -> PriceUp
                                        "COLLATERAL" -> StatusLock
                                        else -> GeumhanSilverLight
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = GeumhanDivider)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "제조 제련소: ${bar.refinery}", fontSize = 10.sp, color = GeumhanSilver)
                                Text(
                                    text = "위치: ${bar.rackId} > ${bar.drawerId}",
                                    fontSize = 11.sp,
                                    color = GeumhanSilverLight
                                )
                            }

                            // Interactive Lock and Collateral control
                            if (bar.status != "RELEASED") {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // Lock control
                                    IconButton(
                                        onClick = { viewModel.lockUnlockVaultBar(bar.id) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(
                                                if (bar.isLocked) PriceDown.copy(alpha = 0.15f) else GeumhanDivider,
                                                CircleShape
                                            )
                                    ) {
                                        Icon(
                                            imageVector = if (bar.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                            contentDescription = "Lock",
                                            tint = if (bar.isLocked) PriceDown else GeumhanSilver,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }

                                    // Collateral Pledging control
                                    IconButton(
                                        onClick = { viewModel.toggleBarCollateralStatus(bar.id) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(
                                                if (bar.status == "COLLATERAL") StatusLock.copy(alpha = 0.15f) else GeumhanDivider,
                                                CircleShape
                                            )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CreditCard,
                                            contentDescription = "Collateral",
                                            tint = if (bar.status == "COLLATERAL") StatusLock else GeumhanSilver,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. MERCHANT TERMINAL / JEWELLERY & RFQ
@Composable
fun MerchantTerminalScreen(
    activeRfqs: List<RfqRequest>,
    goldSpot: Double,
    viewModel: GeumhanViewModel
) {
    var mode by remember { mutableStateOf("RFQ") } // RFQ or JEWELLERY

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Selector Tab
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("RFQ" to "VIP 대량 RFQ", "JEWELLERY" to "금은방 / 쥬얼리 정련").forEach { (termMode, label) ->
                    val isSel = mode == termMode
                    Button(
                        onClick = { mode = termMode },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSel) GeumhanGold else GeumhanSurface,
                            contentColor = if (isSel) GeumhanBg else GeumhanSilverLight
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        if (mode == "RFQ") {
            // Enterprise Request for Quote panel
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GeumhanDivider)
                ) {
                    var rfqProduct by remember { mutableStateOf("99.99% 골드바 1kg") }
                    var rfqWeightKg by remember { mutableStateOf("10.0") }
                    var rfqCity by remember { mutableStateOf("서울 본부") }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "실시간 VIP / 기업용 귀금속 RFQ 송신 패널",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GeumhanGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "대규모 인수도 계약 체결을 위해 다수 주거래 딜러사들에게 실시간 견적을 일괄 요청합니다.",
                            fontSize = 11.sp,
                            color = GeumhanSilver
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = rfqProduct,
                            onValueChange = { rfqProduct = it },
                            label = { Text("인수 대상 규격", color = GeumhanSilver) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeumhanGold,
                                unfocusedBorderColor = GeumhanDivider,
                                focusedTextColor = GeumhanTextPrimary,
                                unfocusedTextColor = GeumhanTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = rfqWeightKg,
                                onValueChange = { rfqWeightKg = it },
                                label = { Text("중량 (Kg)", color = GeumhanSilver) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GeumhanGold,
                                    unfocusedBorderColor = GeumhanDivider,
                                    focusedTextColor = GeumhanTextPrimary,
                                    unfocusedTextColor = GeumhanTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = rfqCity,
                                onValueChange = { rfqCity = it },
                                label = { Text("인도 목적지", color = GeumhanSilver) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GeumhanGold,
                                    unfocusedBorderColor = GeumhanDivider,
                                    focusedTextColor = GeumhanTextPrimary,
                                    unfocusedTextColor = GeumhanTextPrimary
                                ),
                                modifier = Modifier.weight(1.2f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val w = rfqWeightKg.toDoubleOrNull() ?: 1.0
                                viewModel.requestRfq(rfqProduct, w, rfqCity)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GeumhanGold, contentColor = GeumhanBg),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "딜러 다자간 견적 일괄 요청 (RFQ 송신)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Text(
                    text = "활성 견적 리스트 (30초 유효)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = GeumhanTextPrimary,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            if (activeRfqs.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "송신된 견적 요청이 없습니다.", color = GeumhanSilver, fontSize = 12.sp)
                    }
                }
            } else {
                items(activeRfqs) { rfq ->
                    val now = System.currentTimeMillis()
                    val isExpired = rfq.status == "EXPIRED" || (rfq.status == "PENDING" && rfq.expiresAt <= now)
                    val remainingSecs = if (isExpired) 0L else ((rfq.expiresAt - now) / 1000)

                    Card(
                        colors = CardDefaults.cardColors(containerColor = GeumhanCard),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${rfq.product} [${rfq.quantityKg} Kg]",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GeumhanTextPrimary
                                    )
                                    Text(
                                        text = "인도지: ${rfq.targetCity} | ID: ${rfq.id}",
                                        fontSize = 11.sp,
                                        color = GeumhanSilver
                                    )
                                }
                                Surface(
                                    color = if (rfq.status == "ACCEPTED") SafeGreen.copy(alpha = 0.15f) else if (isExpired) GeumhanDivider else StatusLock.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (rfq.status == "ACCEPTED") "수락완료" else if (isExpired) "기간만료" else "${remainingSecs}초 남음",
                                        color = if (rfq.status == "ACCEPTED") PriceUp else if (isExpired) GeumhanSilver else StatusLock,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            if (rfq.status == "PENDING" && !isExpired) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(text = "딜러 견적 회신 내역:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GeumhanGoldLight)
                                Spacer(modifier = Modifier.height(6.dp))

                                rfq.quotes.forEach { quote ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(GeumhanSurface, RoundedCornerShape(8.dp))
                                            .border(1.dp, GeumhanDivider, RoundedCornerShape(8.dp))
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = quote.dealerName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GeumhanTextPrimary)
                                            Text(text = "단가: ₩${String.format("%,.0f", quote.pricePerGram)} / g | 배송: ${quote.deliveryDays}일 소요", fontSize = 10.sp, color = GeumhanSilver)
                                        }
                                        Button(
                                            onClick = { viewModel.acceptRfqQuote(rfq.id, quote.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = GeumhanGold, contentColor = GeumhanBg),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text(text = "낙찰 수락", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                            } else if (rfq.status == "ACCEPTED") {
                                val acceptedQuote = rfq.quotes.find { it.id == rfq.chosenQuoteId }
                                if (acceptedQuote != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "수락된 파트너사: ${acceptedQuote.dealerName}\n계약 정산액: ₩${String.format("%,d", acceptedQuote.totalAmountKrw)} (VAT 별도)",
                                        fontSize = 11.sp,
                                        color = PriceUp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // RETAIL JEWELLERY JEWELLER MODE & SCRAP GOLD LAB ASSAY
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GeumhanDivider)
                ) {
                    var goldScrapWeight by remember { mutableStateOf("18.75") } // 5 Don
                    var selectedScrapPurity by remember { mutableStateOf("18K") }
                    val assayProgress by viewModel.scrapAssayProgress.collectAsStateWithLifecycle()
                    val currentAssay by viewModel.currentScrapAssay.collectAsStateWithLifecycle()

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "한국형 고금(Scrap Gold) 정련·매입 감정 분석기",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GeumhanGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "고객의 헌 금(반지, 목걸이 등)을 실시간 분석 및 XRF 분광 스펙트럼 스캔을 통해 순도를 정밀 분석해 원가 매입 정산합니다.",
                            fontSize = 11.sp,
                            color = GeumhanSilver
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = goldScrapWeight,
                                onValueChange = { goldScrapWeight = it },
                                label = { Text("고금 중량 (g)", color = GeumhanSilver) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GeumhanGold,
                                    unfocusedBorderColor = GeumhanDivider,
                                    focusedTextColor = GeumhanTextPrimary,
                                    unfocusedTextColor = GeumhanTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            // Purity selection
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "신고 순도", color = GeumhanSilver, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("14K", "18K", "24K").forEach { purity ->
                                        val isSel = selectedScrapPurity == purity
                                        Button(
                                            onClick = { selectedScrapPurity = purity },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSel) GeumhanGold else GeumhanDivider,
                                                contentColor = if (isSel) GeumhanBg else GeumhanTextPrimary
                                            ),
                                            contentPadding = PaddingValues(horizontal = 4.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(30.dp)
                                        ) {
                                            Text(text = purity, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress loader animation for Spectrometer assay
                        if (assayProgress != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "XRF 분광 스펙트럼 센서 정밀 분석중... ${String.format("%.0f", assayProgress!! * 100)}%",
                                    fontSize = 11.sp,
                                    color = GeumhanGoldLight
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { assayProgress!! },
                                    color = GeumhanGold,
                                    trackColor = GeumhanDivider,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    val w = goldScrapWeight.toDoubleOrNull() ?: 10.0
                                    viewModel.startScrapAssay(w, selectedScrapPurity)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GeumhanGold, contentColor = GeumhanBg),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(text = "정밀 함량 성분 분석 스캔 (XRF) 시작", fontWeight = FontWeight.Bold)
                            }
                        }

                        // Display Assay results
                        if (currentAssay != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Surface(
                                color = GeumhanBg,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, GeumhanDivider),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "감정서 영수증 (Assay Report)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GeumhanGold)
                                        Text(text = "ID: ${currentAssay!!.id}", fontSize = 10.sp, color = GeumhanSilver)
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(text = "밀도 검사 결과", fontSize = 9.sp, color = GeumhanSilver)
                                            Text(text = "${String.format("%.2f", currentAssay!!.density)} g/cm³", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GeumhanTextPrimary)
                                        }
                                        Column {
                                            Text(text = "XRF 분석 순도", fontSize = 9.sp, color = GeumhanSilver)
                                            Text(text = "${String.format("%.2f", currentAssay!!.xrfGoldPercent)}% (금소재)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GeumhanTextPrimary)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "신뢰도 지수", fontSize = 9.sp, color = GeumhanSilver)
                                            Text(text = "${String.format("%.1f", currentAssay!!.confidence)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PriceUp)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    HorizontalDivider(color = GeumhanDivider)
                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "추출 순금 중량 (Fine Gold):", fontSize = 12.sp, color = GeumhanSilver)
                                        Text(text = "${String.format("%.3f", currentAssay!!.fineGoldGrams)} g", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GeumhanTextPrimary)
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "환경정련비 수수료 (3.5%):", fontSize = 12.sp, color = GeumhanSilver)
                                        Text(text = "-₩${String.format("%,d", currentAssay!!.refiningFeeKrw)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PriceDown)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "최종 매입 정산금:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GeumhanGoldLight)
                                        Text(text = "₩${String.format("%,d", currentAssay!!.valuationKrw)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = PriceUp)
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { viewModel.acceptScrapPayout() },
                                        colors = ButtonDefaults.buttonColors(containerColor = PriceUp, contentColor = GeumhanBg),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = "정련소 매입 즉시 승인 (현금 예치금 정산)", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. RISK & STRESS TESTING SCREEN
@Composable
fun RiskAnalyticsScreen(
    viewModel: GeumhanViewModel,
    totalValue: Double,
    cash: Long,
    goldGrams: Double,
    silverGrams: Double,
    goldSpot: Double,
    silverSpot: Double
) {
    val complianceFlags by viewModel.complianceFlags.collectAsStateWithLifecycle()
    val selectedScenario by viewModel.selectedStressScenario.collectAsStateWithLifecycle()
    val stressScenarios = viewModel.getStressScenarios()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quantitative stats panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, GeumhanDivider)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "리스크 관리 및 정밀 리스크 통계",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GeumhanGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Value at Risk (VaR 95% 1일)", fontSize = 10.sp, color = GeumhanSilver)
                            Text(text = "₩${String.format("%,.0f", totalValue * 0.024)} (2.4%)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PriceDown)
                        }
                        Column {
                            Text(text = "Expected Shortfall (ES)", fontSize = 10.sp, color = GeumhanSilver)
                            Text(text = "₩${String.format("%,.0f", totalValue * 0.038)} (3.8%)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PriceDown)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "포트폴리오 변동성", fontSize = 10.sp, color = GeumhanSilver)
                            Text(text = "12.8% (연율화)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GeumhanGoldLight)
                        }
                    }
                }
            }
        }

        // Stress Scenario Selector
        item {
            Text(
                text = "인터랙티브 스트레스 시나리오 테스트",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = GeumhanTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        items(stressScenarios) { scenario ->
            val isSelected = selectedScenario == scenario.scenarioName
            Card(
                colors = CardDefaults.cardColors(containerColor = if (isSelected) GeumhanGoldDark.copy(alpha = 0.25f) else GeumhanCard),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isSelected) GeumhanGold else Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isSelected) viewModel.selectStressScenario(null) else viewModel.selectStressScenario(scenario.scenarioName)
                    }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = scenario.scenarioName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeumhanTextPrimary
                        )
                        Icon(
                            imageVector = if (scenario.pnlImpactKrw >= 0L) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                            contentDescription = "Scenario Impact",
                            tint = if (scenario.pnlImpactKrw >= 0L) PriceUp else PriceDown,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = scenario.scenarioDesc, fontSize = 11.sp, color = GeumhanSilver)

                    if (isSelected) {
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = GeumhanDivider)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "예상 포트폴리오 자산 변화", fontSize = 10.sp, color = GeumhanSilver)
                                Text(
                                    text = "₩${String.format("%,d", totalValue.toLong())}  ➔  ₩${String.format("%,d", scenario.portfolioValueAfterKrw)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GeumhanTextPrimary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "예상 손실액 (P&L Impact)", fontSize = 10.sp, color = GeumhanSilver)
                                Text(
                                    text = "${if (scenario.pnlImpactKrw >= 0) "+" else ""}₩${String.format("%,d", scenario.pnlImpactKrw)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (scenario.pnlImpactKrw >= 0) PriceUp else PriceDown
                                )
                            }
                        }
                    }
                }
            }
        }

        // Compliance & Tax audit Section
        item {
            Text(
                text = "내부 컴플라이언스 및 준법 검증 내역",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = GeumhanTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GeumhanSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GeumhanDivider)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "자금세탁방지 위험 지수 (AML Score)", fontSize = 10.sp, color = GeumhanSilver)
                            Text(text = "18 / 100 (양호)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PriceUp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "실명인증(KYC) 상태", fontSize = 10.sp, color = GeumhanSilver)
                            Text(text = "인증완료 (1등급)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PriceUp)
                        }
                    }

                    if (complianceFlags.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = GeumhanDivider)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "실시간 감사 플래그 경고:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PriceDown)
                        Spacer(modifier = Modifier.height(6.dp))
                        complianceFlags.forEach { flag ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = "Alert", tint = PriceDown, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = flag, fontSize = 11.sp, color = GeumhanSilverLight)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. GEUMHAN AI CHAT SCREEN
@Composable
fun GeumhanAiScreen(
    viewModel: GeumhanViewModel,
    goldSpot: Double,
    silverSpot: Double,
    goldGrams: Double,
    silverGrams: Double,
    cash: Long
) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val loading by viewModel.chatLoading.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf("") }

    val listState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Suggested Questions Quick Bar
        val suggestedQuestions = listOf(
            "내 보유 금은 몇 돈이고 원화로 얼마야?",
            "오늘 금 가격이 왜 올랐어?",
            "금 10돈을 팔면 얼마야?",
            "금과 은의 비율이 어떻게 변했어?"
        )

        // Chat logs List
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(listState)
        ) {
            Text(
                text = "금한 AI 금융 전담 비서",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = GeumhanGold
            )
            Text(
                text = "금고 원장 및 실시간 환율 엔진에 연동된 스마트 금융 안내를 제공합니다.",
                fontSize = 11.sp,
                color = GeumhanSilver
            )
            Spacer(modifier = Modifier.height(14.dp))

            messages.forEach { msg ->
                val alignSide = if (msg.isUser) Alignment.End else Alignment.Start
                val cardColor = if (msg.isUser) GeumhanGoldDark.copy(alpha = 0.2f) else GeumhanSurface

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = alignSide
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                            .background(cardColor, RoundedCornerShape(12.dp))
                            .border(1.dp, if (msg.isUser) GeumhanGold else GeumhanDivider, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            fontSize = 12.sp,
                            color = GeumhanTextPrimary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            if (loading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    CircularProgressIndicator(color = GeumhanGold, modifier = Modifier.size(24.dp))
                }
            }
        }

        Column {
            // Suggestion quick selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                suggestedQuestions.forEach { query ->
                    Surface(
                        color = GeumhanCard,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, GeumhanDivider),
                        modifier = Modifier
                            .clickable { viewModel.sendChatMessage(query) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = query, fontSize = 10.sp, color = GeumhanGoldLight)
                    }
                }
            }

            // Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GeumhanSurface, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = { Text("금한 AI에게 질문하기...", color = GeumhanSilver, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = GeumhanTextPrimary,
                        unfocusedTextColor = GeumhanTextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input")
                )

                IconButton(
                    onClick = {
                        viewModel.sendChatMessage(inputQuery)
                        inputQuery = ""
                    },
                    modifier = Modifier.testTag("ai_chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = GeumhanGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
