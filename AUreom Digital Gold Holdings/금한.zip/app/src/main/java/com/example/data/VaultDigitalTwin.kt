package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object VaultDigitalTwin {
    private val _bars = MutableStateFlow<List<GoldBar>>(emptyList())
    val bars: StateFlow<List<GoldBar>> = _bars.asStateFlow()

    init {
        // Pre-populate with user's seed bars totaling 125.50g Gold and 2500g Silver
        _bars.value = listOf(
            GoldBar(
                id = "BAR-AU-100",
                serialNumber = "GEUMHAN-AU-9999-0219",
                refinery = "서울불리온 (Seoul Bullion)",
                purity = 99.99,
                purityType = "24K",
                grossWeightG = 100.0,
                fineWeightG = 100.0,
                manufactureDate = "2026-02-14",
                vaultZone = "A구역 (프리미엄 관)",
                rackId = "01선반",
                drawerId = "05번 개인 금고",
                status = "VAULTED",
                owner = "USER",
                isLocked = false
            ),
            GoldBar(
                id = "BAR-AU-10",
                serialNumber = "GEUMHAN-AU-9999-0411",
                refinery = "한강귀금속",
                purity = 99.99,
                purityType = "24K",
                grossWeightG = 10.0,
                fineWeightG = 10.0,
                manufactureDate = "2026-05-18",
                vaultZone = "A구역 (프리미엄 관)",
                rackId = "01선반",
                drawerId = "06번 보관함",
                status = "VAULTED",
                owner = "USER",
                isLocked = true
            ),
            GoldBar(
                id = "BAR-AU-10-B",
                serialNumber = "GEUMHAN-AU-9999-0412",
                refinery = "한강귀금속",
                purity = 99.99,
                purityType = "24K",
                grossWeightG = 10.0,
                fineWeightG = 10.0,
                manufactureDate = "2026-05-18",
                vaultZone = "A구역 (프리미엄 관)",
                rackId = "01선반",
                drawerId = "06번 보관함",
                status = "COLLATERAL", // Collateral status!
                owner = "USER",
                isLocked = false
            ),
            GoldBar(
                id = "BAR-AU-5",
                serialNumber = "GEUMHAN-AU-9999-0912",
                refinery = "한국정밀금속",
                purity = 99.99,
                purityType = "24K",
                grossWeightG = 5.5,
                fineWeightG = 5.5,
                manufactureDate = "2026-08-30",
                vaultZone = "B구역 (고보안 금고)",
                rackId = "03선반",
                drawerId = "12번 보관함",
                status = "VAULTED",
                owner = "USER",
                isLocked = false
            ),
            GoldBar(
                id = "BAR-AG-2500",
                serialNumber = "GEUMHAN-AG-9990-8802",
                refinery = "코리아메탈파트너스",
                purity = 99.90,
                purityType = "999",
                grossWeightG = 2500.0,
                fineWeightG = 2497.5,
                manufactureDate = "2026-01-20",
                vaultZone = "C구역 (실버벌크 관)",
                rackId = "05선반",
                drawerId = "01번 파레트",
                status = "VAULTED",
                owner = "USER",
                isLocked = false
            )
        )
    }

    // Toggle Lock / Unlock
    fun toggleLock(barId: String): Boolean {
        var result = false
        _bars.value = _bars.value.map { bar ->
            if (bar.id == barId) {
                result = true
                bar.copy(isLocked = !bar.isLocked)
            } else bar
        }
        return result
    }

    // Toggle Collateral (담보 설정)
    fun toggleCollateral(barId: String): Boolean {
        var result = false
        _bars.value = _bars.value.map { bar ->
            if (bar.id == barId) {
                result = true
                val newStatus = if (bar.status == "COLLATERAL") "VAULTED" else "COLLATERAL"
                bar.copy(status = newStatus)
            } else bar
        }
        return result
    }

    // Spawn a newly vaulted gold bar upon buying physical gold
    fun depositBar(weightG: Double, refinery: String, purityType: String = "24K"): GoldBar {
        val id = "BAR-AU-${System.currentTimeMillis().toString().takeLast(6)}"
        val serial = "GEUMHAN-AU-9999-${(1000..9999).random()}"
        val newBar = GoldBar(
            id = id,
            serialNumber = serial,
            refinery = refinery,
            purity = if (purityType == "24K") 99.99 else if (purityType == "18K") 75.0 else 58.5,
            purityType = purityType,
            grossWeightG = weightG,
            fineWeightG = weightG * (if (purityType == "24K") 0.9999 else if (purityType == "18K") 0.75 else 0.585),
            manufactureDate = "2026-10-05",
            vaultZone = "A구역 (프리미엄 관)",
            rackId = "02선반",
            drawerId = "08번 보관함",
            status = "VAULTED",
            owner = "USER",
            isLocked = false
        )
        _bars.value = _bars.value + newBar
        return newBar
    }

    // Withdraw physical bar
    fun withdrawBar(barId: String): Boolean {
        val targetBar = _bars.value.find { it.id == barId } ?: return false
        if (targetBar.isLocked || targetBar.status == "COLLATERAL") return false // cannot withdraw locked or collateralized bars
        
        _bars.value = _bars.value.map { bar ->
            if (bar.id == barId) {
                bar.copy(status = "RELEASED") // Released from vault
            } else bar
        }
        return true
    }
}
