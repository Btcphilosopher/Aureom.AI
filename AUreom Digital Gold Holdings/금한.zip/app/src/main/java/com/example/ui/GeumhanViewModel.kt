package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class GeumhanViewModel : ViewModel() {

    // Market Ticker States
    private val _prices = MutableStateFlow<List<MetalPrice>>(emptyList())
    val prices: StateFlow<List<MetalPrice>> = _prices.asStateFlow()

    // Interactive Order Book
    private val _bids = MutableStateFlow<List<OrderBookItem>>(emptyList())
    val bids: StateFlow<List<OrderBookItem>> = _bids.asStateFlow()

    private val _asks = MutableStateFlow<List<OrderBookItem>>(emptyList())
    val asks: StateFlow<List<OrderBookItem>> = _asks.asStateFlow()

    // Trade Orders List
    private val _orders = MutableStateFlow<List<OrderItem>>(emptyList())
    val orders: StateFlow<List<OrderItem>> = _orders.asStateFlow()

    // Real-Time Ledger Cash and Metal balances directly observed from LedgerEngine
    val cashBalance = LedgerEngine.cashBalance
    val metalBalances = LedgerEngine.metalBalances
    val ledgerEntries = LedgerEngine.entries

    // Vault Digital Twin direct observabilities
    val vaultBars = VaultDigitalTwin.bars

    // Active Enterprise RFQs
    private val _activeRfqs = MutableStateFlow<List<RfqRequest>>(emptyList())
    val activeRfqs: StateFlow<List<RfqRequest>> = _activeRfqs.asStateFlow()

    // Scrap Gold & Assay Scanner States
    private val _scrapAssayProgress = MutableStateFlow<Float?>(null) // null means idle, 0.0..1.0 is scanning
    val scrapAssayProgress: StateFlow<Float?> = _scrapAssayProgress.asStateFlow()

    private val _currentScrapAssay = MutableStateFlow<ScrapAssay?>(null)
    val currentScrapAssay: StateFlow<ScrapAssay?> = _currentScrapAssay.asStateFlow()

    // Risk Engine Stress Scenario States
    private val _selectedStressScenario = MutableStateFlow<String?>(null)
    val selectedStressScenario: StateFlow<String?> = _selectedStressScenario.asStateFlow()

    // Compliance Alert Flags
    private val _complianceFlags = MutableStateFlow<List<String>>(emptyList())
    val complianceFlags: StateFlow<List<String>> = _complianceFlags.asStateFlow()

    // AI Assistant Chat Messages
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(id = "INIT", text = "금한 AI 금융 비서에 오신 것을 환영합니다. 오늘 실시간 금 시세 분석 및 자산 포트폴리오 평가, 또는 중량 계산에 대해 질문해 주십시오.", isUser = false)
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _chatLoading = MutableStateFlow(false)
    val chatLoading: StateFlow<Boolean> = _chatLoading.asStateFlow()

    // Core tickers and background jobs
    private var tickerJob: Job? = null
    private var timerJob: Job? = null

    init {
        // Initialize market prices
        _prices.value = MarketSimulator.getCurrentPrices()
        updateOrderBook()

        // Start real-time background market ticker (every 3 seconds)
        tickerJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                MarketSimulator.tickPrices()
                _prices.value = MarketSimulator.getCurrentPrices()
                updateOrderBook()
                simulateMatchingEngine()
            }
        }

        // Start RFQ Countdown timer (ticks every second)
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val now = System.currentTimeMillis()
                _activeRfqs.value = _activeRfqs.value.map { rfq ->
                    if (rfq.status == "PENDING" && rfq.expiresAt <= now) {
                        rfq.copy(status = "EXPIRED")
                    } else rfq
                }
            }
        }
    }

    private fun updateOrderBook() {
        val xauPrice = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
        val (b, a) = MarketSimulator.getOrderBook(xauPrice)
        _bids.value = b
        _asks.value = a
    }

    // SIMULATED MATCHING ENGINE (Continuous Auction - 실시간 경쟁 매매 매칭)
    private fun simulateMatchingEngine() {
        val xauPrice = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
        val xagPrice = _prices.value.find { it.ticker == "XAG/KRW" }?.priceKrw ?: 1250.0

        _orders.value = _orders.value.map { order ->
            if (order.status == "OPEN" || order.status == "PARTIAL") {
                val currentPrice = if (order.ticker == "XAU/KRW") xauPrice else xagPrice
                
                var shouldFill = false
                if (order.side == "BUY" && currentPrice <= order.price) {
                    shouldFill = true
                } else if (order.side == "SELL" && currentPrice >= order.price) {
                    shouldFill = true
                }

                if (shouldFill) {
                    // Execute Transaction
                    val fillGrams = order.quantityGrams
                    val costKrw = (fillGrams * order.price).toLong()
                    val taxVat = (costKrw * 0.10).toLong() // 10% simulated VAT
                    val fee = (costKrw * 0.0015).toLong() // 0.15% simulated transaction fee
                    val finalDeduction = if (order.side == "BUY") costKrw + taxVat + fee else costKrw - fee

                    if (order.side == "BUY") {
                        // Validate Cash
                        if (cashBalance.value >= finalDeduction) {
                            val success = LedgerEngine.recordTransaction(
                                actionType = "TRADE_BUY",
                                debitAccount = "CASH_ASSET_VAULT_KRW",
                                creditAccount = "METAL_ASSET_VAULT_${order.ticker.take(3)}",
                                quantity = fillGrams,
                                unit = order.ticker.take(3),
                                valuationKrw = costKrw,
                                description = "${order.ticker.take(3)} 현물 매수 체결 - 수량: ${String.format("%.2f", fillGrams)}g, 가격: ₩${String.format("%,.0f", order.price)}"
                            )
                            if (success) {
                                // Add to Vault
                                VaultDigitalTwin.depositBar(
                                    weightG = fillGrams,
                                    refinery = "서울불리온 (Seoul Bullion)"
                                )
                                // Trigger audit flag if massive transaction (>10,000,000 KRW)
                                if (finalDeduction > 10000000L) {
                                    addComplianceFlag("대용량 미확인 실물 매수 거래 탐지 - AML 모니터링 감사 대기")
                                }
                                order.copy(filledGrams = fillGrams, status = "FILLED")
                            } else order
                        } else {
                            // Cancel order if not enough funds
                            order.copy(status = "CANCELLED")
                        }
                    } else { // SELL
                        // Validate Metal grams
                        val heldMetal = metalBalances.value[order.ticker.take(3)] ?: 0.0
                        if (heldMetal >= fillGrams) {
                            val success = LedgerEngine.recordTransaction(
                                actionType = "TRADE_SELL",
                                debitAccount = "METAL_ASSET_VAULT_${order.ticker.take(3)}",
                                creditAccount = "CASH_ASSET_VAULT_KRW",
                                quantity = fillGrams,
                                unit = order.ticker.take(3),
                                valuationKrw = costKrw,
                                description = "${order.ticker.take(3)} 현물 매도 체결 - 수량: ${String.format("%.2f", fillGrams)}g, 가격: ₩${String.format("%,.0f", order.price)}"
                            )
                            if (success) {
                                // Withdraw user bar of matching size if possible
                                val matchingBar = vaultBars.value.find { it.grossWeightG <= fillGrams && it.status == "VAULTED" }
                                if (matchingBar != null) {
                                    VaultDigitalTwin.withdrawBar(matchingBar.id)
                                }
                                order.copy(filledGrams = fillGrams, status = "FILLED")
                            } else order
                        } else {
                            order.copy(status = "CANCELLED")
                        }
                    }
                } else order
            } else order
        }
    }

    // Place new limit/market order
    fun placeOrder(ticker: String, side: String, type: String, price: Double, quantityG: Double): Boolean {
        if (quantityG <= 0.0) return false
        
        val costKrw = (quantityG * price).toLong()
        val taxVat = if (side == "BUY") (costKrw * 0.10).toLong() else 0L
        val fee = (costKrw * 0.0015).toLong()
        val finalDeduction = if (side == "BUY") costKrw + taxVat + fee else costKrw - fee

        // Let's write the placeOrder implementation in a fully clean, ordered way.
        val orderId = "ORD-${System.currentTimeMillis()}-${(1000..9999).random()}"
        val newOrder = OrderItem(
            id = orderId,
            ticker = ticker,
            side = side,
            type = type,
            price = price,
            quantityGrams = quantityG,
            filledGrams = 0.0,
            status = if (type == "MARKET") "FILLED" else "OPEN",
            timestamp = System.currentTimeMillis()
        )

        if (type == "MARKET") {
            if (side == "BUY") {
                if (cashBalance.value < finalDeduction) return false
                val success = LedgerEngine.recordTransaction(
                    actionType = "TRADE_BUY",
                    debitAccount = "CASH_ASSET_VAULT_KRW",
                    creditAccount = "METAL_ASSET_VAULT_${ticker.take(3)}",
                    quantity = quantityG,
                    unit = ticker.take(3),
                    valuationKrw = costKrw,
                    description = "$ticker 현물 시장가 매수 체결 - 수량: ${String.format("%.2f", quantityG)}g, 단가: ₩${String.format("%,.0f", price)}"
                )
                if (success) {
                    VaultDigitalTwin.depositBar(quantityG, "서울불리온 (Seoul Bullion)")
                    _orders.value = listOf(newOrder) + _orders.value
                    return true
                }
                return false
            } else { // SELL
                val heldG = metalBalances.value[ticker.take(3)] ?: 0.0
                if (heldG < quantityG) return false
                val success = LedgerEngine.recordTransaction(
                    actionType = "TRADE_SELL",
                    debitAccount = "METAL_ASSET_VAULT_${ticker.take(3)}",
                    creditAccount = "CASH_ASSET_VAULT_KRW",
                    quantity = quantityG,
                    unit = ticker.take(3),
                    valuationKrw = costKrw,
                    description = "$ticker 현물 시장가 매도 체결 - 수량: ${String.format("%.2f", quantityG)}g, 단가: ₩${String.format("%,.0f", price)}"
                )
                if (success) {
                    val matchingBar = vaultBars.value.find { it.grossWeightG <= quantityG && it.status == "VAULTED" }
                    if (matchingBar != null) {
                        VaultDigitalTwin.withdrawBar(matchingBar.id)
                    }
                    _orders.value = listOf(newOrder) + _orders.value
                    return true
                }
                return false
            }
        } else {
            // Limit order: save into the book
            _orders.value = listOf(newOrder) + _orders.value
            return true
        }
    }

    fun cancelOrder(orderId: String) {
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId && order.status == "OPEN") {
                order.copy(status = "CANCELLED")
            } else order
        }
    }

    // ENTERPRISE VIP RFQ REQUEST GENERATOR
    fun requestRfq(product: String, weightKg: Double, city: String) {
        val totalGrams = weightKg * 1000.0
        val midPrice = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
        val rfqId = "RFQ-${System.currentTimeMillis().toString().takeLast(6)}"
        
        // Generate 3 competitive dealer quotes around the mid price
        val quotes = listOf(
            RfqQuote(
                id = "${rfqId}-Q1",
                dealerName = "서울금융금속 (Seoul Financial Metal)",
                pricePerGram = midPrice * 1.0015, // 0.15% over
                totalAmountKrw = (totalGrams * midPrice * 1.0015).toLong(),
                deliveryDays = 1,
                confidenceScore = 98.5
            ),
            RfqQuote(
                id = "${rfqId}-Q2",
                dealerName = "한강귀금속 딜러사업실",
                pricePerGram = midPrice * 1.0008, // 0.08% over
                totalAmountKrw = (totalGrams * midPrice * 1.0008).toLong(),
                deliveryDays = 2,
                confidenceScore = 94.2
            ),
            RfqQuote(
                id = "${rfqId}-Q3",
                dealerName = "대한민국금속거래 파트너즈",
                pricePerGram = midPrice * 1.0022, // 0.22% over
                totalAmountKrw = (totalGrams * midPrice * 1.0022).toLong(),
                deliveryDays = 1,
                confidenceScore = 99.1
            )
        )

        val request = RfqRequest(
            id = rfqId,
            product = product,
            quantityKg = weightKg,
            totalGrams = totalGrams,
            targetCity = city,
            expiresAt = System.currentTimeMillis() + 30000L, // 30 seconds countdown
            status = "PENDING",
            quotes = quotes
        )

        _activeRfqs.value = listOf(request) + _activeRfqs.value
    }

    // Accept RFQ quote and transfer ownership of enterprise metal blocks
    fun acceptRfqQuote(rfqId: String, quoteId: String): Boolean {
        val rfq = _activeRfqs.value.find { it.id == rfqId } ?: return false
        if (rfq.status != "PENDING") return false
        val quote = rfq.quotes.find { it.id == quoteId } ?: return false

        val cost = quote.totalAmountKrw
        val taxVat = (cost * 0.10).toLong() // 10% simulated VAT for physical delivery
        val totalPayment = cost + taxVat

        if (cashBalance.value < totalPayment) return false

        val success = LedgerEngine.recordTransaction(
            actionType = "RFQ_SETTLED",
            debitAccount = "CASH_ASSET_VAULT_KRW",
            creditAccount = "METAL_ASSET_VAULT_XAU",
            quantity = rfq.totalGrams,
            unit = "XAU",
            valuationKrw = cost,
            description = "VIP RFQ 낙찰 계약 정산 완료 - 인수기업: ${quote.dealerName}, 물품: ${rfq.product} ${rfq.quantityKg}kg, 실물 인도 대기"
        )

        if (success) {
            // Deposit enterprise massive bar (e.g. 10kg bar or 1kg bars) to the digital twin vault
            VaultDigitalTwin.depositBar(rfq.totalGrams, quote.dealerName)
            addComplianceFlag("기업형 대규모 실물 인수 계약 (RFQ) 체결 완료 - 관할 세무 감사 자료 발부 완료")

            _activeRfqs.value = _activeRfqs.value.map { r ->
                if (r.id == rfqId) {
                    r.copy(status = "ACCEPTED", chosenQuoteId = quoteId)
                } else r
            }
            return true
        }
        return false
    }

    // CUSTOM SCRAP OLD GOLD ASSAY SPECTROMETER SCANNER
    fun startScrapAssay(weightG: Double, purityType: String) {
        viewModelScope.launch {
            _scrapAssayProgress.value = 0.0f
            _currentScrapAssay.value = null
            
            // Increment loader simulation to represent physical sensors (XRF, density)
            for (i in 1..10) {
                delay(300)
                _scrapAssayProgress.value = i * 0.10f
            }

            // Calculations based on purity selection
            val basePurity = if (purityType == "14K") 58.5 else if (purityType == "18K") 75.0 else 99.9
            val actualPurityOffset = (Math.random() - 0.5) * 0.5 // minor realistic scrap drift
            val estimatedPurityResult = basePurity + actualPurityOffset
            
            val density = if (purityType == "14K") 13.1 else if (purityType == "18K") 15.6 else 19.3
            val xrfReading = estimatedPurityResult + (Math.random() - 0.5) * 0.1
            
            val fineGoldGrams = weightG * (estimatedPurityResult / 100.0)
            val spotXau = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
            
            // Scrap buyback spread: subtract 3.5% refining fee
            val rawValue = fineGoldGrams * spotXau
            val refiningFee = (rawValue * 0.035).toLong()
            val valuation = (rawValue - refiningFee).toLong()

            _currentScrapAssay.value = ScrapAssay(
                id = "ASS-${(10000..99999).random()}",
                weightG = weightG,
                inputPurity = purityType,
                estimatedPurity = estimatedPurityResult,
                density = density + (Math.random() - 0.5) * 0.1,
                xrfGoldPercent = xrfReading,
                confidence = 98.4 + Math.random() * 1.5,
                fineGoldGrams = fineGoldGrams,
                valuationKrw = valuation,
                refiningFeeKrw = refiningFee,
                timestamp = System.currentTimeMillis()
            )
            _scrapAssayProgress.value = null
        }
    }

    // Customer accepts payout of assayed scrap
    fun acceptScrapPayout(): Boolean {
        val assay = _currentScrapAssay.value ?: return false
        
        val success = LedgerEngine.recordTransaction(
            actionType = "SCRAP_BUYBACK",
            debitAccount = "METAL_ASSET_VAULT_XAU", // User hands over scrap gold
            creditAccount = "CASH_ASSET_VAULT_KRW", // Payout cash
            quantity = assay.fineGoldGrams,
            unit = "XAU",
            valuationKrw = assay.valuationKrw,
            description = "오래된 고금(Scrap Gold) ${assay.inputPurity} (${String.format("%.2f", assay.weightG)}g) 정련 매입 정산 완료 - 정련비 공제: ₩${String.format("%,d", assay.refiningFeeKrw)}"
        )

        if (success) {
            _currentScrapAssay.value = null
            return true
        }
        return false
    }

    // PORTFOLIO RISK & STRESS TESTING
    fun selectStressScenario(scenarioName: String?) {
        _selectedStressScenario.value = scenarioName
    }

    fun getStressScenarios(): List<StressImpact> {
        val cash = cashBalance.value
        val goldG = metalBalances.value["XAU"] ?: 0.0
        val silverG = metalBalances.value["XAG"] ?: 0.0
        
        val goldSpot = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
        val silverSpot = _prices.value.find { it.ticker == "XAG/KRW" }?.priceKrw ?: 1250.0

        val currentPortfolioVal = cash + (goldG * goldSpot) + (silverG * silverSpot)

        return listOf(
            StressImpact(
                scenarioName = "글로벌 금 가격 -20% 대폭락",
                scenarioDesc = "금융 완화 정책 조기 긴축에 따른 귀금속 투자 회피 시뮬레이션",
                goldChangePercent = -0.20,
                silverChangePercent = -0.25,
                fxChangePercent = -0.02,
                pnlImpactKrw = ((goldG * goldSpot * -0.20) + (silverG * silverSpot * -0.25)).toLong(),
                portfolioValueAfterKrw = (currentPortfolioVal + ((goldG * goldSpot * -0.20) + (silverG * silverSpot * -0.25))).toLong()
            ),
            StressImpact(
                scenarioName = "원/달러 환율 +10% 폭등 (원화 약세)",
                scenarioDesc = "글로벌 무역 분쟁 격화에 따른 원화 가치 절하 및 환차익 시그널",
                goldChangePercent = 0.05,
                silverChangePercent = 0.03,
                fxChangePercent = 0.10,
                pnlImpactKrw = ((goldG * goldSpot * 0.15) + (silverG * silverSpot * 0.13)).toLong(), // 환율 상승 시 원화 환산 가격 증가
                portfolioValueAfterKrw = (currentPortfolioVal + ((goldG * goldSpot * 0.15) + (silverG * silverSpot * 0.13))).toLong()
            ),
            StressImpact(
                scenarioName = "은 산업수요 급증 (친환경 반도체 호재 +30%)",
                scenarioDesc = "차세대 실리콘 배터리 배선 소재 국산화 폭발에 따른 은 시세 대세 상승",
                goldChangePercent = 0.02,
                silverChangePercent = 0.30,
                fxChangePercent = 0.0,
                pnlImpactKrw = ((goldG * goldSpot * 0.02) + (silverG * silverSpot * 0.30)).toLong(),
                portfolioValueAfterKrw = (currentPortfolioVal + ((goldG * goldSpot * 0.02) + (silverG * silverSpot * 0.30))).toLong()
            ),
            StressImpact(
                scenarioName = "국내 금 현물 프리미엄 폭등 (+15%)",
                scenarioDesc = "실물 귀금속 국내 공급망 품귀 현상에 따른 현물 수령 수수료 할증 마찰",
                goldChangePercent = 0.15,
                silverChangePercent = 0.08,
                fxChangePercent = 0.01,
                pnlImpactKrw = ((goldG * goldSpot * 0.15) + (silverG * silverSpot * 0.08)).toLong(),
                portfolioValueAfterKrw = (currentPortfolioVal + ((goldG * goldSpot * 0.15) + (silverG * silverSpot * 0.08))).toLong()
            )
        )
    }

    // VAULT INTERACTIVE ACTIONS
    fun lockUnlockVaultBar(barId: String) {
        VaultDigitalTwin.toggleLock(barId)
    }

    fun toggleBarCollateralStatus(barId: String) {
        VaultDigitalTwin.toggleCollateral(barId)
    }

    // COMPLIANCE AUDIT FLAGS
    private fun addComplianceFlag(flag: String) {
        _complianceFlags.value = listOf(flag) + _complianceFlags.value
    }

    fun clearComplianceFlags() {
        _complianceFlags.value = emptyList()
    }

    // CHAT ASSISTANT ACTION
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        
        val userMsg = ChatMessage(id = UUID.randomUUID().toString(), text = text, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg
        _chatLoading.value = true

        val goldSpot = _prices.value.find { it.ticker == "XAU/KRW" }?.priceKrw ?: 110000.0
        val silverSpot = _prices.value.find { it.ticker == "XAG/KRW" }?.priceKrw ?: 1250.0
        val goldG = metalBalances.value["XAU"] ?: 0.0
        val silverG = metalBalances.value["XAG"] ?: 0.0
        val cash = cashBalance.value
        val barsCount = vaultBars.value.filter { it.status == "VAULTED" || it.status == "COLLATERAL" }.size

        viewModelScope.launch {
            val response = GeminiService.chatWithGemini(
                userMessage = text,
                currentGoldPrice = goldSpot,
                currentSilverPrice = silverSpot,
                userGoldGrams = goldG,
                userSilverGrams = silverG,
                userCashKrw = cash,
                vaultBarsCount = barsCount
            )
            _chatMessages.value = _chatMessages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                text = response,
                isUser = false
            )
            _chatLoading.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        tickerJob?.cancel()
        timerJob?.cancel()
    }
}
