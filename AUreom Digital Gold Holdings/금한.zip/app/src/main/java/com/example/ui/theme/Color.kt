package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Geumhan Charcoal Theme Palette
val GeumhanBg = Color(0xFF0B0B0D)
val GeumhanSurface = Color(0xFF161619)
val GeumhanCard = Color(0xFF1E1E22)

val GeumhanGold = Color(0xFFD4AF37)
val GeumhanGoldLight = Color(0xFFF3D075)
val GeumhanGoldDark = Color(0xFF997A15)

val GeumhanSilver = Color(0xFF8C939E)
val GeumhanSilverLight = Color(0xFFD5D8DC)

val GeumhanTextPrimary = Color(0xFFF5F5F7)
val GeumhanTextSecondary = Color(0xFF9A9A9E)
val GeumhanDivider = Color(0xFF2C2C32)

// Technical Indicators
val PriceUp = Color(0xFF4CAF50)      // Rising prices
val PriceDown = Color(0xFFF44336)    // Falling prices
val StatusLock = Color(0xFFFF9800)    // Collateral / Lock Status
val SafeGreen = Color(0xFF2E7D32)     // Vault Safe Status
