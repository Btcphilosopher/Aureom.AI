package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    
    // OkHttp Client configured with 60s timeouts as required by gemini-api skill
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // Determine if key is a valid configured key
    private fun isKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY" && !key.contains("PLACEHOLDER")
    }

    suspend fun chatWithGemini(
        userMessage: String,
        currentGoldPrice: Double,
        currentSilverPrice: Double,
        userGoldGrams: Double,
        userSilverGrams: Double,
        userCashKrw: Long,
        vaultBarsCount: Int
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        
        if (!isKeyConfigured()) {
            Log.w(TAG, "Gemini API key is not configured or is placeholder. Using high-fidelity synthetic fallback.")
            return@withContext getSyntheticResponse(
                userMessage,
                currentGoldPrice,
                currentSilverPrice,
                userGoldGrams,
                userSilverGrams,
                userCashKrw,
                vaultBarsCount
            )
        }

        try {
            // Setup System Instruction Context
            val systemPrompt = """
                당신은 대한민국 최고 권위의 귀금속 금융·거래 플랫폼 '금한(GEUMHAN)'의 전문 금융 AI 비서 '금한 AI'입니다.
                사용자는 귀금속 거래소 회원, 딜러, 금은방 점주, 또는 기관 투자자입니다.
                항상 정중하고 신뢰감 있으며 논리적인 한국어 금융 전문가 어조(하십시오체 위주)로 답변하십시오.
                
                [현재 플랫폼 실시간 가상 시장 상태]
                - 실시간 금 시세: ₩${String.format("%,.2f", currentGoldPrice)} / g (1돈 3.75g 환산: ₩${String.format("%,.0f", currentGoldPrice * 3.75)})
                - 실시간 은 시세: ₩${String.format("%,.2f", currentSilverPrice)} / g (1돈 3.75g 환산: ₩${String.format("%,.0f", currentSilverPrice * 3.75)})
                - 금/은 비율: ${String.format("%.2f", currentGoldPrice / currentSilverPrice)}
                
                [현재 질문자의 가상 자산 잔고]
                - 보유 금: ${String.format("%.2f", userGoldGrams)}g (평가금액: ₩${String.format("%,.0f", userGoldGrams * currentGoldPrice)})
                - 보유 은: ${String.format("%.2f", userSilverGrams)}g (평가금액: ₩${String.format("%,.0f", userSilverGrams * currentSilverPrice)})
                - 예치금 현금: ₩${String.format("%,d", userCashKrw)}
                - 디지털 트윈 금고 내 보관 중인 실물 귀금속 바(Bar) 수량: ${vaultBarsCount}개
                
                [답변 지침]
                1. 사용자의 보유 자산과 관련된 질문(예: "내 금은 몇 돈이야?", "팔면 얼마야?")에 대해서는 상기 제공된 실시간 데이터를 바탕으로 3.75g 단위 환산 및 원화 가치를 정확히 수학적으로 계산해서 신속하게 답변해 주십시오.
                2. 시장 상승/하락 원인 분석 질문("오늘 왜 올라?")에 대해서는 금의 '안전 자산 매수세', '인플레이션 헷지', '원달러 환율 변동', '반도체 등 은 산업용 수요 증가' 등 구체적이고 전문적인 거시 경제적 관점에서 가상의 시나리오를 논리적으로 설명해 주십시오.
                3. 귀금속 상점/쥬얼리 세공비 관련 질문이나 정련비 scrap 매입 질문에도 상인의 관점에서 세공마진, 정련스프레드를 고려한 공식과 분석을 친절히 설명하십시오.
                4. 절대 실제 투자 자문이나 법적 책임이 있는 금융 조언이 아니며, 제공되는 시장 데이터는 '금한' 플랫폼 내부의 가상 합성 데이터 시뮬레이션임을 명확히 하십시오.
            """.trimIndent()

            // Construct JSON request using Android native JSONObject
            val requestJson = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().apply {
                        put("text", systemPrompt)
                    }))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().apply {
                        put("text", userMessage)
                    }))
                }))
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "Gemini API error response: $errBody")
                    return@withContext "죄송합니다. API 호출 중 오류가 발생하여 분석 결과를 가져오지 못했습니다. (서버 응답 오류)"
                }

                val responseBody = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBody)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "답변을 작성하지 못했습니다.")
                    }
                }
                return@withContext "답변 형식을 해석할 수 없습니다."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call exception", e)
            return@withContext "네트워크 연결 또는 API 설정 오류로 인해 답변을 가져오지 못했습니다. 로컬 시뮬레이션 답변을 요청해 주십시오."
        }
    }

    // High fidelity semantic mock simulation in case key is missing
    private fun getSyntheticResponse(
        userMessage: String,
        goldPrice: Double,
        silverPrice: Double,
        goldGrams: Double,
        silverGrams: Double,
        cashKrw: Long,
        vaultBarsCount: Int
    ): String {
        val cleanMsg = userMessage.trim()
        val goldValue = goldGrams * goldPrice
        val silverValue = silverGrams * silverPrice
        val totalValue = goldValue + silverValue + cashKrw

        return when {
            cleanMsg.contains("오늘") || cleanMsg.contains("왜") || cleanMsg.contains("올랐") || cleanMsg.contains("상승") || cleanMsg.contains("시세") -> {
                """
                    [금한 AI 전문 거시경제 브리핑 - 시뮬레이션 모드]
                    
                    현재 '금한' 가상 시장에서 금 시세는 1g당 **₩${String.format("%,.0f", goldPrice)}** (1돈 기준 ₩${String.format("%,.0f", goldPrice * 3.75)})에 거래되며 강세를 유지하고 있습니다. 
                    
                    이번 시세 상승의 세 가지 핵심 동인은 다음과 같습니다:
                    1. **안전 자산 수요 집중**: 글로벌 가상 인플레이션 헷지 매수세 유입으로 인해 금에 대한 자금 집중 현상이 강화되었습니다.
                    2. **원/달러 환율 상승 작용**: 원/달러 환율이 현재 **₩${String.format("%,.0f", MarketSimulator.usdKrw)}** 내외에서 등락하며 삼각 통화 결제 상 원화 환산 금 가격을 더욱 밀어 올렸습니다.
                    3. **은(Silver) 산업용 수요 확대**: 첨단 친환경 배터리 및 정밀 전자 회로용 실버 그레인(Silver Grain) 발주가 급증하면서 은 가격 또한 g당 **₩${String.format("%,.0f", silverPrice)}** 선을 돌파하며 동반 상승을 견인하고 있습니다.
                    
                    현재 질문자님의 총 귀금속 평가액은 **₩${String.format("%,.0f", goldValue + silverValue)}**에 달하여 자산 가치가 안정적으로 보전되고 있습니다. 추가적인 포트폴리오 리스크 관리는 '리스크/분석' 패널의 스트레스 시나리오를 참고해 주십시오.
                """.trimIndent()
            }
            cleanMsg.contains("보유") || cleanMsg.contains("내 금") || cleanMsg.contains("얼마") || cleanMsg.contains("돈") -> {
                """
                    [금한 AI 실시간 자산 분석 리포트 - 시뮬레이션 모드]
                    
                    질문자님께서 현재 '금한' 플랫폼에 예탁하신 귀금속 자산 현황을 보고서 형식으로 안내해 드립니다.
                    
                    1. **금(Gold) 보유량**: 
                       - 중량: **${String.format("%.2f", goldGrams)} g**
                       - 한국식 돈 환산: **${String.format("%.2f", goldGrams / 3.75)} 돈**
                       - 실시간 평가액: **₩${String.format("%,.0f", goldValue)}** (99.99% 순도 기준)
                    
                    2. **은(Silver) 보유량**:
                       - 중량: **${String.format("%,.1f", silverGrams)} g** (2.50kg 은괴 형태 보관 중)
                       - 한국식 돈 환산: **${String.format("%.1f", silverGrams / 3.75)} 돈**
                       - 실시간 평가액: **₩${String.format("%,.0f", silverValue)}**
                    
                    3. **현금 예치금 및 디지털 금고**:
                       - 보유 현금: **₩${String.format("%,d", cashKrw)}**
                       - 디지털 트윈 금고 보관품 수량: **${vaultBarsCount}개** (서울 본사 보안 랙에 안치됨)
                    
                    **총 자산 합계**: **₩${String.format("%,.0f", totalValue)}**
                    
                    질문자님의 자산 포트폴리오는 금 비중 **${String.format("%.1f", (goldValue / (goldValue + silverValue + 1.0)) * 100)}%**, 은 비중 **${String.format("%.1f", (silverValue / (goldValue + silverValue + 1.0)) * 100)}%**으로 귀금속 포트폴리오 다각화 지수가 우수하게 관리되고 있습니다.
                """.trimIndent()
            }
            cleanMsg.contains("10돈") || cleanMsg.contains("십돈") -> {
                val tenDonGrams = 37.5
                val tenDonValue = tenDonGrams * goldPrice
                val spreadCost = tenDonValue * MarketSimulator.DEALER_SPREAD_PERCENT
                val finalPay = tenDonValue - spreadCost
                """
                    [금한 AI 계산 마스터 - 10돈(37.50g) 거래 견적]
                    
                    요청하신 **금 10돈(37.50g)**에 대한 실시간 기준 가격 산정 결과는 다음과 같습니다:
                    
                    - **순도**: 24K (99.99%)
                    - **적용 그람수**: 37.50 g
                    - **순수 금속 원가**: ₩${String.format("%,.0f", tenDonValue)} (g당 ₩${String.format("%,.0f", goldPrice)} 기준)
                    - **딜러 스프레드 (0.25%)**: -₩${String.format("%,.0f", spreadCost)}
                    
                    ----------------------------------------
                    - **최종 매입 시 예상 지급액 (고객 수령)**: **₩${String.format("%,.0f", finalPay)}**
                    - **실물 바 인도 시 예상 매수액 (고객 결제)**: **₩${String.format("%,.0f", tenDonValue + spreadCost + (tenDonValue * MarketSimulator.PHYSICAL_PREMIUM_PERCENT))}** (실물 1.5% 프리미엄 포함)
                    
                    해당 견적은 '금한' 실시간 가상 삼각 환율을 적용한 정밀 계산값이며 30초간 유효합니다. 즉시 주문 창에서 거래를 체결하실 수 있습니다.
                """.trimIndent()
            }
            else -> {
                """
                    반갑습니다! 대한민국 최고 권위의 한국형 귀금속 금융·거래 플랫폼 **금한(GEUMHAN)**의 AI 분석 비서입니다.
                    
                    저는 실시간으로 삼각 환율 Triangulation을 추적하는 **금 가격 연동 엔진**, 실물 귀금속의 보관 상태를 추적하는 **디지털 트윈 금고**, 그리고 거래의 이중 원장을 무결하게 기록하는 **Ledger 원장**과 동기화되어 있습니다.
                    
                    다음 내용에 대해 질문해 주시면 전문적으로 즉시 리포팅을 드리겠습니다:
                    - **"오늘 왜 금값이 상승세야?"** (가상 시장 거시 경제 요인 분석)
                    - **"내 보유 금은 몇 돈이고 원화 가치가 얼마야?"** (보유 포트폴리오 자산 가치 정산)
                    - **"금 10돈을 지금 팔면 얼마를 정산받을 수 있어?"** (스프레드 차감 실시간 정산액 계산)
                    - **"금과 은의 실시간 시세 비율이 어떻게 변했어?"** (금/은 비율 교차 차트 분석)
                """.trimIndent()
            }
        }
    }
}
