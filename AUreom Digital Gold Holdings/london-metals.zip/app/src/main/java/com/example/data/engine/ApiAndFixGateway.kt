package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ApiAndFixGateway {

    private val _invocationLogs = MutableStateFlow<List<ApiInvocationLog>>(emptyList())
    val invocationLogs: StateFlow<List<ApiInvocationLog>> = _invocationLogs.asStateFlow()

    private val _fixMessages = MutableStateFlow<List<FixMessageRecord>>(createInitialFixMessages())
    val fixMessages: StateFlow<List<FixMessageRecord>> = _fixMessages.asStateFlow()

    private val _webSocketEvents = MutableStateFlow<List<WebSocketLiveEvent>>(createInitialWsEvents())
    val webSocketEvents: StateFlow<List<WebSocketLiveEvent>> = _webSocketEvents.asStateFlow()

    val availableEndpoints: List<ApiEndpointDefinition> = listOf(
        ApiEndpointDefinition(
            method = "GET",
            path = "/v1/markets",
            title = "Global Market Summary",
            description = "Returns real-time synthetic spot rates, 24h volumes, spreads, and London session statuses.",
            responseSampleJson = """{
  "status": "SUCCESS",
  "session": "LONDON_CORE_OPEN",
  "timestamp": 1791112700000,
  "instruments_count": 24,
  "synthetic": true,
  "disclaimer": "Simulated institutional market data. Not official LME or LBMA exchange prices."
}"""
        ),
        ApiEndpointDefinition(
            method = "GET",
            path = "/v1/quotes/{symbol}",
            title = "Instrument Quote & Depth",
            description = "Fetches Top-of-Book and Level 2 synthetic order book for the given instrument symbol (e.g., XAU/GBP, BTC/XAU).",
            responseSampleJson = """{
  "symbol": "XAU/GBP",
  "bid": 3150.40,
  "ask": 3150.75,
  "mid": 3150.575,
  "spread": 0.35,
  "currency": "GBP",
  "provenance": "SYNTHETIC_LONDON_METALS",
  "derivation": "XAU/USD ÷ GBP/USD"
}"""
        ),
        ApiEndpointDefinition(
            method = "POST",
            path = "/v1/orders",
            title = "Submit Institutional Order (Idempotent)",
            description = "Routes and executes orders with Smart Order Router (SOR), pre-trade margin check, and immutable ledger booking.",
            requestSampleJson = """{
  "instrument": "XAU/GBP",
  "side": "BUY",
  "quantity": 100.00,
  "order_type": "LIMIT",
  "limit_price": 3150.40,
  "currency": "GBP",
  "client_order_id": "CLIENT-ORD-8819",
  "idempotency_key": "IDEM-XAU-20261004-9941"
}""",
            responseSampleJson = """{
  "order_id": "LMX-994102AB",
  "status": "FILLED",
  "filled_qty": 100.00,
  "avg_price": 3150.40,
  "venue": "LONDON_SPOT_OTC",
  "fees_gbp": 44.10,
  "synthetic": true,
  "idempotency_cached": false
}"""
        ),
        ApiEndpointDefinition(
            method = "POST",
            path = "/v1/rfqs",
            title = "Request For Quote (Dealer OTC)",
            description = "Institutional OTC forward RFQ workflow with City Bullion Partners / Thames Metals dealer desk.",
            requestSampleJson = """{
  "instrument": "XAU/GBP",
  "side": "BUY",
  "quantity": 250.00,
  "maturity_days": 30,
  "currency": "GBP"
}""",
            responseSampleJson = """{
  "rfq_id": "RFQ-LDN-8842",
  "spot_ref": 3150.40,
  "forward_points": 10.35,
  "forward_quote": 3160.75,
  "valid_seconds": 30,
  "status": "QUOTED"
}"""
        ),
        ApiEndpointDefinition(
            method = "GET",
            path = "/v1/vaults/london-04",
            title = "London Vault 04 Digital Twin",
            description = "Queries real-time bar allocation, chamber capacity, and book-entry ownership state.",
            responseSampleJson = """{
  "vault_id": "LONDON-VAULT-04",
  "total_bars": 400000,
  "allocated_bars": 284500,
  "unallocated_bars": 105200,
  "fineness": 999.9,
  "reconciliation_status": "PASS"
}"""
        ),
        ApiEndpointDefinition(
            method = "POST",
            path = "/v1/allocations/book-entry-transfer",
            title = "Book-Entry Title Transfer",
            description = "Transfers legal title of specific allocated 400oz gold bars between City accounts without moving physical metal.",
            requestSampleJson = """{
  "bar_id": "LDN-AU-00048271",
  "from_entity": "Thames Metals Ltd",
  "to_entity": "City Bullion Partners",
  "settlement_ref": "SETTLE-LDN-8841"
}""",
            responseSampleJson = """{
  "transfer_id": "BET-99182AB",
  "status": "TRANSFERRED",
  "bar_id": "LDN-AU-00048271",
  "vault": "London Vault 04 [Chamber Alpha-03]",
  "signature_hash": "0x9f88c3a018bc449e"
}"""
        ),
        ApiEndpointDefinition(
            method = "GET",
            path = "/v1/risk/portfolio",
            title = "Portfolio Risk & Margin Metrics",
            description = "Calculates multi-asset VaR (99%), CVaR, 4-tier margin status, and cross-asset haircuts.",
            responseSampleJson = """{
  "nav_gbp": 24819440.00,
  "var_99_1d_gbp": 842000.00,
  "cvar_99_gbp": 1290000.00,
  "margin_utilisation_pct": 63.4,
  "margin_tier": "NORMAL"
}"""
        ),
        ApiEndpointDefinition(
            method = "POST",
            path = "/v1/scenarios/stress-test",
            title = "Cross-Asset Stress Simulation",
            description = "Applies simultaneous shocks across Spot Metals, FX Cable, Crypto and Volatility surfaces.",
            requestSampleJson = """{
  "gold_shock_pct": -15.0,
  "silver_shock_pct": -25.0,
  "btc_shock_pct": -35.0,
  "gbp_usd_shock_pct": -8.0,
  "vol_shock_pct": 60.0
}""",
            responseSampleJson = """{
  "scenario_id": "SCEN-01",
  "simulated_pnl_loss_gbp": -3680000.00,
  "new_margin_requirement_gbp": 12740000.00,
  "margin_deficit_gbp": -970000.00,
  "margin_call_triggered": true
}"""
        )
    )

    fun invokeEndpoint(
        endpoint: ApiEndpointDefinition,
        customRequestBody: String?,
        idempotencyKey: String?
    ): ApiInvocationLog {
        val start = System.currentTimeMillis()
        val latency = (8..35).random().toLong()

        val responseBody = when (endpoint.path) {
            "/v1/markets" -> """{
  "status": "SUCCESS",
  "session": "LONDON_CORE_OPEN",
  "timestamp": ${System.currentTimeMillis()},
  "market_regime": "RISK_OFF",
  "active_feed": "SYNTHETIC_LONDON_METALS_V3",
  "venues": ["LONDON_SPOT_OTC", "LME_ELECTRONIC", "FX_INTERBANK", "DIGITAL_METALS"],
  "synthetic": true
}"""
            "/v1/orders" -> """{
  "order_id": "LMX-${UUID.randomUUID().toString().take(8).uppercase()}",
  "status": "FILLED",
  "executed_qty": 100.00,
  "avg_fill_price": 3150.40,
  "currency": "GBP",
  "settlement_convention": "PHYSICAL_ALLOCATED_LONDON",
  "venue": "LONDON_SPOT_OTC",
  "idempotency_key": "${idempotencyKey ?: UUID.randomUUID().toString()}",
  "timestamp": ${System.currentTimeMillis()},
  "synthetic": true
}"""
            "/v1/rfqs" -> """{
  "rfq_id": "RFQ-LDN-${(1000..9999).random()}",
  "dealer": "City Bullion Partners / Thames Metals LP",
  "instrument": "XAU/GBP",
  "side": "BUY",
  "quantity": 250.00,
  "spot_reference": 3150.40,
  "forward_points": 10.35,
  "forward_outright": 3160.75,
  "maturity_days": 30,
  "valid_until": ${System.currentTimeMillis() + 30000},
  "status": "QUOTED"
}"""
            else -> endpoint.responseSampleJson
        }

        val log = ApiInvocationLog(
            invocationId = "INV-" + UUID.randomUUID().toString().take(8).uppercase(),
            timestamp = start,
            method = endpoint.method,
            path = endpoint.path,
            idempotencyKey = idempotencyKey,
            statusCode = 200,
            latencyMs = latency,
            requestBody = customRequestBody ?: endpoint.requestSampleJson,
            responseBody = responseBody
        )

        _invocationLogs.value = listOf(log) + _invocationLogs.value.take(20)

        // Broadcast to WebSocket feed as well
        broadcastWsEvent(
            eventType = "API_REQUEST_COMPLETED",
            channel = "terminal.audit",
            payloadJson = """{"endpoint": "${endpoint.path}", "status": 200, "latency_ms": $latency}"""
        )

        return log
    }

    fun broadcastWsEvent(eventType: String, channel: String, payloadJson: String) {
        val event = WebSocketLiveEvent(
            eventType = eventType,
            channel = channel,
            timestamp = System.currentTimeMillis(),
            payloadJson = payloadJson
        )
        _webSocketEvents.value = listOf(event) + _webSocketEvents.value.take(25)
    }

    private fun createInitialWsEvents(): List<WebSocketLiveEvent> {
        val now = System.currentTimeMillis()
        return listOf(
            WebSocketLiveEvent(
                eventType = "QUOTE_UPDATED",
                channel = "market.xau_gbp",
                timestamp = now - 2000,
                payloadJson = """{"symbol": "XAU/GBP", "bid": 3150.40, "ask": 3150.75, "mid": 3150.575, "spread": 0.35}"""
            ),
            WebSocketLiveEvent(
                eventType = "TRADE_EXECUTED",
                channel = "execution.otc_gold",
                timestamp = now - 5000,
                payloadJson = """{"trade_id": "TRD-8821", "symbol": "XAU/GBP", "qty": 250.0, "price": 3150.40, "buyer": "City Bullion Partners"}"""
            ),
            WebSocketLiveEvent(
                eventType = "VAULT_ALLOCATION_UPDATED",
                channel = "vault.london_04",
                timestamp = now - 8000,
                payloadJson = """{"bar_id": "LDN-AU-00048271", "owner": "City Bullion Partners", "chamber": "Chamber Alpha-03", "status": "ALLOCATED"}"""
            )
        )
    }

    private fun createInitialFixMessages(): List<FixMessageRecord> {
        val now = System.currentTimeMillis()
        return listOf(
            FixMessageRecord(
                msgType = "D (NewOrderSingle)",
                seqNum = 101,
                senderCompId = "CITY_BULLION_TRADING",
                targetCompId = "LMX_LONDON_ENGINE",
                rawFixString = "8=FIX.4.4\u00019=142\u000135=D\u000149=CITY_BULLION\u000156=LMX_MATCH\u000134=101\u000152=${now - 30000}\u000111=ORD-8819\u000155=XAU/GBP\u000154=1\u000138=100.00\u000140=2\u000144=3150.40\u000110=114\u0001",
                parsedDescription = "NewOrderSingle: BUY 100 XAU/GBP Limit @ £3,150.40",
                timestamp = now - 30000
            ),
            FixMessageRecord(
                msgType = "8 (ExecutionReport)",
                seqNum = 102,
                senderCompId = "LMX_LONDON_ENGINE",
                targetCompId = "CITY_BULLION_TRADING",
                rawFixString = "8=FIX.4.4\u00019=168\u000135=8\u000149=LMX_MATCH\u000156=CITY_BULLION\u000134=102\u000152=${now - 29000}\u000111=ORD-8819\u000137=LMX-88190\u000117=EXEC-991\u0001150=2\u000139=2\u000155=XAU/GBP\u000154=1\u000138=100.00\u000131=3150.40\u000132=100.00\u000110=098\u0001",
                parsedDescription = "ExecutionReport (FILLED): Order LMX-88190 fully executed @ £3,150.40",
                timestamp = now - 29000
            )
        )
    }
}
