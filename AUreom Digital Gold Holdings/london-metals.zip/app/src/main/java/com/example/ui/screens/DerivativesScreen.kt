package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderSide
import com.example.data.model.RfqStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun DerivativesScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val futures by viewModel.repository.futuresContracts.collectAsState()
    val options by viewModel.repository.optionsContracts.collectAsState()
    val rfqs by viewModel.repository.rfqHistory.collectAsState()
    val swaps by viewModel.repository.metalSwaps.collectAsState()
    val perp by viewModel.repository.perpMarket.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Futures, 1: Options, 2: OTC RFQ, 3: Swaps, 4: BTC/XAU Perp

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Sub-tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                listOf("Futures", "Options", "OTC RFQ", "Swaps", "BTC/XAU Perp").forEachIndexed { idx, title ->
                    val isSel = activeSubTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) BullionGold else Color.Transparent, RoundedCornerShape(4.dp))
                            .clickable { activeSubTab = idx }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            title,
                            fontFamily = TerminalMonospace,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 9.sp,
                            color = if (isSel) Color(0xFF0F141C) else TextSecondary
                        )
                    }
                }
            }
        }

        when (activeSubTab) {
            0 -> {
                // Futures Terminal
                item {
                    Text(
                        text = "LONDON PROMPT-DATE FORWARD CURVE (CONTANGO/BACKWARDATION)",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                }

                items(futures) { fut ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = fut.contractId,
                                        fontFamily = TerminalMonospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "[${fut.prompt.code} - ${fut.promptDateFormatted}]",
                                        fontFamily = TerminalMonospace,
                                        fontSize = 10.sp,
                                        color = BullionGoldMuted
                                    )
                                }
                                Text(
                                    text = "${fut.underlyingMetal} | Size: ${fut.contractSizeOzOrTonnes.toInt()} ${fut.sizeUnit}",
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "Basis vs Spot: +£${String.format("%.2f", fut.basisVsSpot)} | Implied Rate: ${String.format("%.2f", fut.impliedFinancingAnnualizedPct)}% p.a.",
                                    fontFamily = TerminalMonospace,
                                    fontSize = 9.sp,
                                    color = SteelBlue
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "£${String.format("%.2f", fut.lastPrice)}",
                                    fontFamily = TerminalMonospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "OI: ${String.format("%,d", fut.openInterest)}",
                                    fontFamily = TerminalMonospace,
                                    fontSize = 9.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
            1 -> {
                // Options Terminal
                item {
                    Text(
                        text = "METALS OPTIONS // VOLATILITY SURFACE & GREEKS",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                }

                items(options) { opt ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = opt.contractId,
                                        fontFamily = TerminalMonospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (opt.optionType == com.example.data.model.OptionType.CALL) MarketBidGreen else MarketAskRed
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Strike: £${String.format("%.0f", opt.strike)} (${opt.expiryDate})",
                                        fontFamily = TerminalMonospace,
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                                Text(
                                    text = "Premium: £${String.format("%.2f", opt.premiumGbp)}",
                                    fontFamily = TerminalMonospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = BullionGoldMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Greeks Grid
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                                    .padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Δ ${String.format("%.2f", opt.greeks.delta)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextPrimary)
                                Text("Γ ${String.format("%.3f", opt.greeks.gamma)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextPrimary)
                                Text("Θ ${String.format("%.2f", opt.greeks.theta)}/d", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextPrimary)
                                Text("V ${String.format("%.1f", opt.greeks.vega)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextPrimary)
                                Text("IV ${String.format("%.1f", opt.impliedVolatilityPct)}%", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = SteelBlue)
                            }
                        }
                    }
                }
            }
            2 -> {
                // OTC Forward RFQ
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "INSTITUTIONAL OTC FORWARD RFQ ENGINE",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = BullionGold
                            )
                            Text(
                                text = "Workflow: RFQ → QUOTE → NEGOTIATE → ACCEPT → CONFIRM → SETTLE",
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 9.5.sp,
                                color = TextMuted
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    viewModel.repository.requestDealerRfq("XAU/GBP", OrderSide.BUY, 250.0, 30, "GBP")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("REQUEST 30-DAY OTC FORWARD (250 XAU/GBP)", fontFamily = TerminalMonospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                items(rfqs) { rfq ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${rfq.rfqId} // ${rfq.side} ${rfq.quantity.toInt()} ${rfq.instrumentSymbol}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
                                Text(rfq.status.name, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = if (rfq.status == RfqStatus.ACCEPTED) BritishRacingGreenBright else BullionGold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Dealer: ${rfq.dealerName} | Maturity: ${rfq.maturityDays} Days", fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = TextSecondary)
                            Text("Spot: £${String.format("%.2f", rfq.quotedSpot)} + Fwd Pts: ${String.format("%.2f", rfq.forwardPoints)} = Quoted: £${String.format("%.2f", rfq.quotedForwardPrice)}", fontFamily = TerminalMonospace, fontSize = 10.sp, color = BullionGoldMuted)

                            if (rfq.status == RfqStatus.QUOTED) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(
                                    onClick = {
                                        viewModel.repository.acceptRfqAndExecute(rfq.rfqId)
                                        viewModel.selectTab(TerminalTab.SETTLEMENT)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth().height(32.dp)
                                ) {
                                    Text("ACCEPT QUOTE & TRIGGER SETTLEMENT", fontFamily = TerminalMonospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF041E0F))
                                }
                            }
                        }
                    }
                }
            }
            3 -> {
                // Metal Swaps & Financing
                item {
                    Text("SYNTHETIC METAL LEASE & CASH/METAL SWAPS", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BullionGold)
                }

                items(swaps) { swap ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(swap.swapId, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
                                Text(swap.status, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = BritishRacingGreenBright)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Notional: ${swap.notionalMetalOz.toInt()} oz ${swap.metalSymbol} (Value: £${String.format("%,.0f", swap.baseValueGbp)})", fontFamily = TerminalMonospace, fontSize = 10.5.sp, color = TextSecondary)
                            Text("Lease Rate: ${swap.metalLeaseRatePct}% | Funding Rate: ${swap.fundingRatePct}% | Maturity: ${swap.maturityDays}D", fontFamily = TerminalMonospace, fontSize = 10.sp, color = SteelBlue)
                            Text("Counterparty: ${swap.counterparty}", fontFamily = FontFamily.SansSerif, fontSize = 9.5.sp, color = TextMuted)
                        }
                    }
                }
            }
            4 -> {
                // BTC/XAU Perpetual Market
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("BTC/XAU PERPETUAL DERIVATIVE", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BullionGold)
                                Text("SIMULATED RISK CONTROLS", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Mark Price: ${String.format("%.3f", perp.markPrice)} XAU / BTC | Index Price: ${String.format("%.3f", perp.indexPrice)} XAU", fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary)
                            Text("8h Funding Rate: +${String.format("%.4f", perp.fundingRate8hPct)}% | Open Interest: ${String.format("%,.0f", perp.openInterestXau)} XAU", fontFamily = TerminalMonospace, fontSize = 10.sp, color = SteelBlue)
                            Text("Max Leverage: ${perp.maxLeverage}x | Maintenance Margin: ${perp.maintenanceMarginPct}%", fontFamily = TerminalMonospace, fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
