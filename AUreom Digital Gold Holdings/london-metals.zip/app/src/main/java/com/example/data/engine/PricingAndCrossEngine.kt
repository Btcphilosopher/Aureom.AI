package com.example.data.engine

import com.example.data.model.*
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.exp

data class DigitalVsPhysicalComparison(
    val productType: String,
    val identifier: String,
    val currentPriceGbp: Double,
    val premiumDiscountVsSpotPct: Double,
    val basisVsCashGbp: Double,
    val annualCustodyBps: Double,
    val financingCostAnnualPct: Double,
    val settlementDelay: String,
    val liquidityRating: String, // "High Tier 1", "Deep OTC", "On-Chain"
    val counterpartyExposure: String,
    val legalInterchangeabilityNote: String
)

data class FxForwardQuote(
    val pair: String,
    val tenorDays: Int,
    val spotRate: Double,
    val forwardPoints: Double,
    val forwardOutright: Double,
    val baseInterestRatePct: Double,
    val quoteInterestRatePct: Double,
    val impliedFundingDiffPct: Double
)

data class CurrencyToGoldForward(
    val instrument: String, // "GBP/XAU-30D"
    val goldSpotUsd: Double,
    val gbpUsdSpot: Double,
    val impliedGoldGbpSpot: Double,
    val gbpInterestRate30dPct: Double, // e.g. 5.25%
    val goldLeaseRate30dPct: Double,   // e.g. 1.10%
    val daysToMaturity: Int,
    val impliedForwardPointsGbp: Double,
    val impliedForwardGoldPriceGbp: Double,
    val formulaBreakdown: String
)

class PricingAndCrossEngine {

    fun calculateTriangulation(
        xauUsd: Double,
        gbpUsd: Double,
        eurUsd: Double,
        btcUsd: Double,
        usdtUsd: Double,
        xautUsd: Double
    ): Map<String, Double> {
        val xauGbp = xauUsd / gbpUsd
        val gbpXau = 1.0 / xauGbp
        val btcXau = btcUsd / xauUsd
        val xauEur = xauUsd / eurUsd
        val usdtXaut = usdtUsd / xautUsd

        return mapOf(
            "XAU/GBP" to xauGbp,
            "GBP/XAU" to gbpXau,
            "BTC/XAU" to btcXau,
            "XAU/EUR" to xauEur,
            "USDT/XAUT" to usdtXaut
        )
    }

    fun calculateFxForward(pair: String, spot: Double, tenorDays: Int): FxForwardQuote {
        val (baseRate, quoteRate) = when (pair) {
            "GBP/USD" -> Pair(0.0500, 0.0525) // BoE 5.00% vs Fed 5.25%
            "EUR/USD" -> Pair(0.0350, 0.0525) // ECB 3.50% vs Fed 5.25%
            "EUR/GBP" -> Pair(0.0350, 0.0500)
            else -> Pair(0.0500, 0.0500)
        }
        val t = tenorDays / 365.0
        val forwardOutright = spot * ((1.0 + quoteRate * t) / (1.0 + baseRate * t))
        val forwardPoints = (forwardOutright - spot) * 10000.0 // pips

        return FxForwardQuote(
            pair = pair,
            tenorDays = tenorDays,
            spotRate = spot,
            forwardPoints = forwardPoints,
            forwardOutright = forwardOutright,
            baseInterestRatePct = baseRate * 100,
            quoteInterestRatePct = quoteRate * 100,
            impliedFundingDiffPct = (quoteRate - baseRate) * 100
        )
    }

    fun calculateCurrencyToGoldForward(
        xauUsd: Double,
        gbpUsd: Double,
        maturityDays: Int = 30
    ): CurrencyToGoldForward {
        val goldSpotGbp = xauUsd / gbpUsd
        val gbpRate = 0.0500
        val goldLeaseRate = 0.0110
        val t = maturityDays / 365.0

        // Forward Price = Spot * exp((r_gbp - r_gold_lease) * t)
        val forwardPrice = goldSpotGbp * exp((gbpRate - goldLeaseRate) * t)
        val forwardPoints = forwardPrice - goldSpotGbp

        return CurrencyToGoldForward(
            instrument = "GBP/XAU ${maturityDays}D Forward",
            goldSpotUsd = xauUsd,
            gbpUsdSpot = gbpUsd,
            impliedGoldGbpSpot = goldSpotGbp,
            gbpInterestRate30dPct = gbpRate * 100,
            goldLeaseRate30dPct = goldLeaseRate * 100,
            daysToMaturity = maturityDays,
            impliedForwardPointsGbp = forwardPoints,
            impliedForwardGoldPriceGbp = forwardPrice,
            formulaBreakdown = "Spot (£${String.format("%.2f", goldSpotGbp)}) × exp[(GBP 5.0% - Gold Lease 1.1%) × ${maturityDays}/365] = £${String.format("%.2f", forwardPrice)}"
        )
    }

    fun getDigitalVsPhysicalComparisons(
        xauSpotGbp: Double,
        xautPriceGbp: Double,
        goldFuturesGbp: Double
    ): List<DigitalVsPhysicalComparison> {
        val xautPremPct = ((xautPriceGbp - xauSpotGbp) / xauSpotGbp) * 100.0
        val futBasis = goldFuturesGbp - xauSpotGbp

        return listOf(
            DigitalVsPhysicalComparison(
                productType = "London Spot Bullion",
                identifier = "XAU/GBP Spot (Loco London)",
                currentPriceGbp = xauSpotGbp,
                premiumDiscountVsSpotPct = 0.00,
                basisVsCashGbp = 0.00,
                annualCustodyBps = 10.0,
                financingCostAnnualPct = 5.20,
                settlementDelay = "T+2 London Working Days",
                liquidityRating = "Tier 1 Interbank Bullion Desk",
                counterpartyExposure = "LBMA Clearing Member Bilateral",
                legalInterchangeabilityNote = "Standard interbank unallocated / clearable bullion"
            ),
            DigitalVsPhysicalComparison(
                productType = "Allocated Physical Bar",
                identifier = "London Vault 04 (400oz Bar Title)",
                currentPriceGbp = xauSpotGbp * 1.0025, // +25 bps physical fabrication/bar premium
                premiumDiscountVsSpotPct = +0.25,
                basisVsCashGbp = xauSpotGbp * 0.0025,
                annualCustodyBps = 18.0,
                financingCostAnnualPct = 5.50,
                settlementDelay = "Book-Entry Instant / Physical 5D",
                liquidityRating = "Deep Institutional Custody",
                counterpartyExposure = "Direct Bailment / Custodian Segregated",
                legalInterchangeabilityNote = "Direct legal ownership of specific numbered bar serials"
            ),
            DigitalVsPhysicalComparison(
                productType = "Digital Synthetic Gold Token",
                identifier = "XAUT/GBP (Tether Gold Abstraction)",
                currentPriceGbp = xautPriceGbp,
                premiumDiscountVsSpotPct = xautPremPct,
                basisVsCashGbp = xautPriceGbp - xauSpotGbp,
                annualCustodyBps = 0.0, // embedded in token
                financingCostAnnualPct = 4.80,
                settlementDelay = "On-Chain Instant (< 12 sec)",
                liquidityRating = "24/7 Digital Metals Layer",
                counterpartyExposure = "Issuer Smart Contract / Digital Custody",
                legalInterchangeabilityNote = "Digital asset representation; not legally interchangeable with LBMA allocated bars without formal redemption flow"
            ),
            DigitalVsPhysicalComparison(
                productType = "Exchange Futures Contract",
                identifier = "XAU-F1 (1M Forward Prompt)",
                currentPriceGbp = goldFuturesGbp,
                premiumDiscountVsSpotPct = ((goldFuturesGbp - xauSpotGbp) / xauSpotGbp) * 100.0,
                basisVsCashGbp = futBasis,
                annualCustodyBps = 0.0,
                financingCostAnnualPct = 5.15,
                settlementDelay = "Prompt Expiry Delivery",
                liquidityRating = "High Screen Electronic",
                counterpartyExposure = "Central Counterparty Clearing House (CCP)",
                legalInterchangeabilityNote = "Exchange derivative contract with CCP margin rules"
            )
        )
    }

    fun scanTriangularArbitrage(
        xauUsd: Double,
        gbpUsd: Double,
        observedXauGbp: Double,
        btcUsd: Double,
        observedBtcXau: Double
    ): List<TriangularArbitrageOpportunity> {
        val impliedXauGbp = xauUsd / gbpUsd
        val discXauGbp = observedXauGbp - impliedXauGbp
        val feeEst = 0.45 // estimated 1.5 bps fee
        val netArb = kotlin.math.abs(discXauGbp) - feeEst

        val impliedBtcXau = btcUsd / xauUsd
        val discBtcXau = observedBtcXau - impliedBtcXau

        return listOf(
            TriangularArbitrageOpportunity(
                id = "ARB-XAU-GBP-001",
                leg1 = "XAU/USD ($" + String.format("%.2f", xauUsd) + ")",
                leg2 = "GBP/USD (" + String.format("%.4f", gbpUsd) + ")",
                leg3 = "XAU/GBP (£" + String.format("%.2f", observedXauGbp) + ")",
                observedPrice = observedXauGbp,
                impliedPrice = impliedXauGbp,
                theoreticalSpreadGbp = discXauGbp,
                estimatedFeesGbp = feeEst,
                netArbitrageGbp = netArb,
                isActionableAfterLatency = netArb > 0.10,
                explanation = "Implied XAU/GBP ($" + String.format("%.2f", xauUsd) + " ÷ " + String.format("%.4f", gbpUsd) + " = £" + String.format("%.2f", impliedXauGbp) + ") vs Observed £" + String.format("%.2f", observedXauGbp) + ". Net dislocation: £" + String.format("%.2f", discXauGbp)
            ),
            TriangularArbitrageOpportunity(
                id = "ARB-BTC-XAU-002",
                leg1 = "BTC/USD ($" + String.format("%.2f", btcUsd) + ")",
                leg2 = "XAU/USD ($" + String.format("%.2f", xauUsd) + ")",
                leg3 = "BTC/XAU (" + String.format("%.3f", observedBtcXau) + " oz)",
                observedPrice = observedBtcXau,
                impliedPrice = impliedBtcXau,
                theoreticalSpreadGbp = discBtcXau * observedXauGbp,
                estimatedFeesGbp = 1.20,
                netArbitrageGbp = (discBtcXau * observedXauGbp) - 1.20,
                isActionableAfterLatency = false,
                explanation = "BTC/USD to Gold Triangulation parity within standard 4bps digital-asset fee band."
            )
        )
    }
}
