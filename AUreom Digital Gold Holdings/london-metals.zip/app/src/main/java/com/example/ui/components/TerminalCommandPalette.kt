package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalCommandPalette(
    commandInput: String,
    onCommandChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    feedback: String?,
    modifier: Modifier = Modifier
) {
    val quickShortcuts = listOf(
        "BUY 100 XAU/GBP",
        "SELL 50 XAG/USD",
        "SHOW VAULT",
        "STRESS GOLD -15%",
        "CREATE RFQ",
        "RECONCILE"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBackground, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LMX:/>",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = BullionGold
            )
            Spacer(modifier = Modifier.width(6.dp))
            BasicTextField(
                value = commandInput,
                onValueChange = onCommandChange,
                textStyle = TextStyle(
                    fontFamily = TerminalMonospace,
                    fontSize = 12.sp,
                    color = TextPrimary
                ),
                cursorBrush = SolidColor(BullionGold),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onExecute(commandInput) }),
                modifier = Modifier
                    .weight(1f)
                    .testTag("command_input"),
                decorationBox = { innerTextField ->
                    if (commandInput.isEmpty()) {
                        Text(
                            text = "Enter terminal command (e.g. BUY 100 XAU/GBP, SHOW VAULT, STRESS GOLD -15%)...",
                            fontFamily = TerminalMonospace,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    innerTextField()
                }
            )
            IconButton(
                onClick = { onExecute(commandInput) },
                modifier = Modifier
                    .size(28.dp)
                    .testTag("command_execute_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Execute Command",
                    tint = BullionGold,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Quick suggestions scroll
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "SUGGESTIONS:",
                fontFamily = TerminalMonospace,
                fontSize = 9.sp,
                color = TextMuted,
                modifier = Modifier.align(Alignment.CenterVertically)
            )
            for (cmd in quickShortcuts) {
                SuggestionChip(
                    onClick = { onExecute(cmd) },
                    label = {
                        Text(cmd, fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextSecondary)
                    },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = TerminalSurfaceVariant
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        borderColor = TerminalBorder,
                        enabled = true
                    ),
                    modifier = Modifier.height(24.dp)
                )
            }
        }

        feedback?.let { fb ->
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF132A1C), shape = RoundedCornerShape(3.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = fb,
                    fontFamily = TerminalMonospace,
                    fontSize = 10.sp,
                    color = BritishRacingGreenBright
                )
            }
        }
    }
}
