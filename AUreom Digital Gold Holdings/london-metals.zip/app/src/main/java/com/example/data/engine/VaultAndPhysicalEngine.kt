package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class VaultAndPhysicalEngine {

    private val _vaultTwin = MutableStateFlow(createInitialVaultState())
    val vaultTwin: StateFlow<VaultDigitalTwin> = _vaultTwin.asStateFlow()

    private val _reconciliationReport = MutableStateFlow(createInitialReconciliationReport())
    val reconciliationReport: StateFlow<PhysicalMetalReconciliationReport> = _reconciliationReport.asStateFlow()

    fun transferBookEntryOwnership(
        barId: String,
        fromEntity: String,
        toEntity: String,
        settlementRef: String
    ): BookEntryTransfer? {
        val current = _vaultTwin.value
        val barIndex = current.sampleAllocatedBars.indexOfFirst { it.barId == barId }
        if (barIndex == -1) return null

        val targetBar = current.sampleAllocatedBars[barIndex]
        val updatedBar = targetBar.copy(
            currentOwner = toEntity,
            allocationStatus = AllocationStatus.ALLOCATED
        )

        val updatedBars = current.sampleAllocatedBars.toMutableList().apply {
            set(barIndex, updatedBar)
        }

        val transfer = BookEntryTransfer(
            transferId = "BET-" + UUID.randomUUID().toString().take(8).uppercase(),
            barId = barId,
            fromEntity = fromEntity,
            toEntity = toEntity,
            vaultLocation = targetBar.locationVault + " [" + targetBar.chamber + " / " + targetBar.pallet + "]",
            fineOzTransferred = targetBar.fineWeightOz,
            timestamp = System.currentTimeMillis(),
            settlementRef = settlementRef,
            signatureHash = "0x" + UUID.randomUUID().toString().replace("-", "").take(16),
            reconciliationVerified = true
        )

        _vaultTwin.value = current.copy(
            sampleAllocatedBars = updatedBars,
            recentTransfers = listOf(transfer) + current.recentTransfers.take(15)
        )

        runPhysicalReconciliation()
        return transfer
    }

    fun allocateBarForExecution(
        ownerEntity: String,
        metalType: String = "XAU",
        fineOz: Double = 400.0,
        settlementRef: String
    ): Pair<VaultBar, BookEntryTransfer> {
        val current = _vaultTwin.value
        val unallocatedBar = current.sampleAllocatedBars.firstOrNull { it.allocationStatus == AllocationStatus.UNALLOCATED }
            ?: current.sampleAllocatedBars.first()

        val allocatedBar = unallocatedBar.copy(
            currentOwner = ownerEntity,
            allocationStatus = AllocationStatus.ALLOCATED,
            fineWeightOz = fineOz
        )

        val updatedBars = current.sampleAllocatedBars.toMutableList().apply {
            val idx = indexOfFirst { it.barId == unallocatedBar.barId }
            if (idx != -1) set(idx, allocatedBar)
        }

        val transfer = BookEntryTransfer(
            transferId = "BET-" + UUID.randomUUID().toString().take(8).uppercase(),
            barId = allocatedBar.barId,
            fromEntity = "LMX Principal Pool (Unallocated)",
            toEntity = ownerEntity,
            vaultLocation = allocatedBar.locationVault + " [" + allocatedBar.chamber + "]",
            fineOzTransferred = fineOz,
            timestamp = System.currentTimeMillis(),
            settlementRef = settlementRef,
            signatureHash = "0x" + UUID.randomUUID().toString().replace("-", "").take(16),
            reconciliationVerified = true
        )

        _vaultTwin.value = current.copy(
            sampleAllocatedBars = updatedBars,
            allocatedBarsCount = current.allocatedBarsCount + 1,
            unallocatedBarsCount = current.unallocatedBarsCount - 1,
            recentTransfers = listOf(transfer) + current.recentTransfers.take(15)
        )

        runPhysicalReconciliation()
        return Pair(allocatedBar, transfer)
    }

    fun runPhysicalReconciliation(): PhysicalMetalReconciliationReport {
        val bars = _vaultTwin.value.sampleAllocatedBars
        val allocatedBars = bars.filter { it.currentOwner == "City Bullion Partners" && it.allocationStatus == AllocationStatus.ALLOCATED }
        val totalAllocatedOz = allocatedBars.sumOf { it.fineWeightOz }

        val report = PhysicalMetalReconciliationReport(
            timestamp = System.currentTimeMillis(),
            accountId = "ACC-LDN-01994 (City Bullion Partners)",
            clientMetalBalanceOz = totalAllocatedOz,
            barInventoryOz = totalAllocatedOz,
            vaultLocationVerified = true,
            ownershipRecordVerified = true,
            quadLedgerBalanced = true,
            statusPass = true,
            detectedBreaks = emptyList()
        )
        _reconciliationReport.value = report
        return report
    }

    private fun createInitialReconciliationReport(): PhysicalMetalReconciliationReport {
        return PhysicalMetalReconciliationReport(
            timestamp = System.currentTimeMillis(),
            accountId = "ACC-LDN-01994 (City Bullion Partners)",
            clientMetalBalanceOz = 2920.0,
            barInventoryOz = 2920.0,
            vaultLocationVerified = true,
            ownershipRecordVerified = true,
            quadLedgerBalanced = true,
            statusPass = true,
            detectedBreaks = emptyList()
        )
    }

    private fun createInitialVaultState(): VaultDigitalTwin {
        val sampleBars = listOf(
            VaultBar(
                barId = "LDN-AU-00048271",
                serialNumber = "SN-2024-88492",
                metalType = "XAU",
                refiner = "The Royal Mint (Llantrisant, UK)",
                grossWeightKg = 12.41,
                fineWeightOz = 400.00,
                fineness = 999.9,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Alpha-03",
                pallet = "Pallet-14B",
                currentOwner = "City Bullion Partners",
                allocationStatus = AllocationStatus.ALLOCATED,
                certificateNumber = "CERT-RM-9948201"
            ),
            VaultBar(
                barId = "LDN-AU-00048272",
                serialNumber = "SN-2024-88493",
                metalType = "XAU",
                refiner = "Valcambi Suisse (Balerna, CH)",
                grossWeightKg = 12.44,
                fineWeightOz = 400.00,
                fineness = 999.9,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Alpha-03",
                pallet = "Pallet-14B",
                currentOwner = "City Bullion Partners",
                allocationStatus = AllocationStatus.ALLOCATED,
                certificateNumber = "CERT-VAL-110293"
            ),
            VaultBar(
                barId = "LDN-AU-00048273",
                serialNumber = "SN-2023-77102",
                metalType = "XAU",
                refiner = "Rand Refinery (Germiston, ZA)",
                grossWeightKg = 12.42,
                fineWeightOz = 400.00,
                fineness = 999.9,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Alpha-04",
                pallet = "Pallet-09A",
                currentOwner = "Thames Metals Ltd",
                allocationStatus = AllocationStatus.ALLOCATED,
                certificateNumber = "CERT-RND-882910"
            ),
            VaultBar(
                barId = "LDN-AU-00048274",
                serialNumber = "SN-2025-01048",
                metalType = "XAU",
                refiner = "Metalor Technologies (Neuchâtel, CH)",
                grossWeightKg = 12.45,
                fineWeightOz = 400.00,
                fineness = 999.9,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Beta-01",
                pallet = "Pallet-03C",
                currentOwner = "Cannon Street Commodities",
                allocationStatus = AllocationStatus.ALLOCATED,
                certificateNumber = "CERT-MET-554918"
            ),
            VaultBar(
                barId = "LDN-AU-00048275",
                serialNumber = "SN-2025-01049",
                metalType = "XAU",
                refiner = "PAMP Suisse (Castel San Pietro, CH)",
                grossWeightKg = 12.43,
                fineWeightOz = 400.00,
                fineness = 999.9,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Beta-02",
                pallet = "Pallet-11A",
                currentOwner = "LMX Principal Liquidity Pool",
                allocationStatus = AllocationStatus.UNALLOCATED,
                certificateNumber = "CERT-PAMP-339481"
            ),
            VaultBar(
                barId = "LDN-AG-00091840",
                serialNumber = "SN-2024-AG-491",
                metalType = "XAG",
                refiner = "The Royal Mint (UK)",
                grossWeightKg = 31.10,
                fineWeightOz = 1000.00,
                fineness = 999.0,
                locationVault = "London Vault 04 (Bank of England Depository Sub-Level 2)",
                chamber = "Chamber Gamma-01 (Silver Deep Depository)",
                pallet = "Pallet-AG-02",
                currentOwner = "City Bullion Partners",
                allocationStatus = AllocationStatus.ALLOCATED,
                certificateNumber = "CERT-RM-AG-8839"
            )
        )

        val chambers = listOf(
            VaultChamber("CHAMBER-A1", "Chamber Alpha-01 (High-Density Gold)", 80000, 78400, 62000, 16400, "Class 4 Physical Hardened"),
            VaultChamber("CHAMBER-A2", "Chamber Alpha-02 (LBMA Good Delivery)", 90000, 89100, 71500, 17600, "Class 4 Monitored Biometric"),
            VaultChamber("CHAMBER-A3", "Chamber Alpha-03 (Allocated Institution Pods)", 100000, 96500, 84000, 12500, "Class 4 Dual Custodian"),
            VaultChamber("CHAMBER-B1", "Chamber Beta-01 (Interbank Reserve Depot)", 80000, 76000, 48000, 28000, "Class 4 Automated Palletized"),
            VaultChamber("CHAMBER-G1", "Chamber Gamma-01 (Silver Bullion Depository)", 50000, 48000, 19000, 29000, "Class 4 Reinforced Floor")
        )

        val initialTransfers = listOf(
            BookEntryTransfer(
                transferId = "BET-INIT-001",
                barId = "LDN-AU-00048271",
                fromEntity = "Westminster Bullion Markets",
                toEntity = "City Bullion Partners",
                vaultLocation = "London Vault 04 [Chamber Alpha-03 / Pallet-14B]",
                fineOzTransferred = 400.0,
                timestamp = System.currentTimeMillis() - 86400000,
                settlementRef = "SETTLE-LDN-8841",
                signatureHash = "0x9f88c3a018bc449e",
                reconciliationVerified = true
            )
        )

        return VaultDigitalTwin(
            totalBars = 400000,
            totalFineOz = 160000000.0,
            totalValuationGbp = 504000000000.0,
            allocatedBarsCount = 284500,
            unallocatedBarsCount = 105200,
            inTransitCount = 8200,
            underInspectionCount = 2100,
            sampleAllocatedBars = sampleBars,
            chambers = chambers,
            recentTransfers = initialTransfers
        )
    }
}
