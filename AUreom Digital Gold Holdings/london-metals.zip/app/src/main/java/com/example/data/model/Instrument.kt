package com.example.data.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class AssetCategory(val label: String) {
    SPOT_METALS("Spot Precious Metals"),
    INDUSTRIAL_LME("LME Industrial Metals"),
    BULLION_OTC("London Bullion OTC"),
    DERIVATIVE_FUTURES("Metals Futures"),
    DERIVATIVE_OPTIONS("Metals Options"),
    FX_CROSS("FX / Metals Cross"),
    DIGITAL_ASSET("Digital Asset / Synthetic Metals")
}

enum class SettlementConvention(val label: String) {
    CASH_USD("Cash USD (T+2)"),
    CASH_GBP("Cash GBP (T+2)"),
    PHYSICAL_ALLOCATED_LONDON("London Vault Allocated (T+2)"),
    BOOK_ENTRY_TRANSFER("BoE / London Vault Book Entry"),
    DIGITAL_TOKEN("Smart Contract / Token Settlement"),
    ON_CHAIN_USDT("Tether Collateral Settlement")
}

enum class QuoteType(val label: String) {
    DIRECT("Direct Spot"),
    INVERTED("Inverted Rate"),
    SYNTHETIC("Synthetic Cross"),
    TRIANGULATED("Triangulated Cross")
}

enum class MarketVenue(val code: String, val fullName: String) {
    LONDON_SPOT_OTC("LDN-OTC", "London Bullion OTC Market"),
    LME_ELECTRONIC("LME-ELEC", "LME Electronic Select (Synthetic Ref)"),
    OTC_LONDON_DEALER("LDN-DEALER", "London Principal Dealing Desk"),
    FX_INTERBANK("LDN-FX", "London Interbank FX Desk"),
    DIGITAL_METALS("LDN-DIGITAL", "Digital Asset Metals Execution Layer")
}

data class InstrumentDefinition(
    val id: String,
    val symbol: String,
    val name: String,
    val baseAsset: String,
    val quoteAsset: String,
    val category: AssetCategory,
    val venue: MarketVenue,
    val tickSize: Double,
    val minQuantity: Double,
    val unit: String,
    val settlementConvention: SettlementConvention,
    val quoteType: QuoteType = QuoteType.DIRECT,
    val triangulatedFormula: String? = null
)

data class QuoteData(
    val symbol: String,
    val instrumentId: String,
    val bid: Double,
    val ask: Double,
    val mid: Double,
    val last: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val closePrev: Double,
    val change: Double,
    val changePercent: Double,
    val spread: Double,
    val volume: Double,
    val volatilityBps: Double,
    val timestamp: Long,
    val quoteType: QuoteType = QuoteType.DIRECT,
    val provenanceSource: String = "SYNTHETIC_LONDON_METALS",
    val isSimulated: Boolean = true
) {
    fun formattedBid(decimals: Int = 2): String = String.format("%.${decimals}f", bid)
    fun formattedAsk(decimals: Int = 2): String = String.format("%.${decimals}f", ask)
    fun formattedLast(decimals: Int = 2): String = String.format("%.${decimals}f", last)
    fun formattedSpread(decimals: Int = 2): String = String.format("%.${decimals}f", spread)
}

data class OrderBookLevel(
    val price: Double,
    val quantity: Double,
    val ordersCount: Int,
    val accumulated: Double = 0.0
)

data class OrderBookData(
    val symbol: String,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val midPrice: Double,
    val spread: Double,
    val depthImbalance: Double, // -1.0 (all ask) to +1.0 (all bid)
    val vwapBid: Double,
    val vwapAsk: Double,
    val timestamp: Long
)
