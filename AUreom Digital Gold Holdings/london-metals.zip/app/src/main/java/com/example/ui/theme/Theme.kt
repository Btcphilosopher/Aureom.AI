package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalDarkColorScheme = darkColorScheme(
    primary = BullionGold,
    onPrimary = Color(0xFF0F141C),
    primaryContainer = Color(0xFF2A2210),
    onPrimaryContainer = BullionGoldMuted,
    secondary = BritishRacingGreenBright,
    onSecondary = Color(0xFF041E0F),
    secondaryContainer = BritishRacingGreen,
    onSecondaryContainer = Color(0xFFDCFCE7),
    tertiary = SteelBlue,
    onTertiary = Color(0xFF0F172A),
    tertiaryContainer = LondonNavy,
    onTertiaryContainer = Color(0xFFDBEAFE),
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderLight,
    error = MarketAskRed,
    onError = Color.White
)

@Composable
fun LondonMetalsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Alias for compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LondonMetalsTheme(content = content)
}
