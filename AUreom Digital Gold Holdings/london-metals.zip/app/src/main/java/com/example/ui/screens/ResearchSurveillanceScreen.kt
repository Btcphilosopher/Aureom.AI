package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketRegime
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun ResearchSurveillanceScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val quotes by viewModel.repository.marketEngine.quotes.collectAsState()
    val regime by viewModel.repository.surveillanceEngine.currentRegime.collectAsState()
    val alerts by viewModel.repository.surveillanceEngine.surveillanceAlerts.collectAsState()
    val pricingEngine = viewModel.repository.pricingEngine

    val xauUsd = quotes["XAU/USD"]?.last ?: 4200.00
    val gbpUsd = quotes["GBP/USD"]?.last ?: 1.3340
    val xauGbp = quotes["XAU/GBP"]?.last ?: 3150.40
    val btcUsd = quotes["BTC/USD"]?.last ?: 64800.0
    val btcXau = quotes["BTC/XAU"]?.last ?: 15.42

    val arbOpportunities = remember(xauUsd, gbpUsd, xauGbp, btcUsd, btcXau) {
        pricingEngine.scanTriangularArbitrage(xauUsd, gbpUsd, xauGbp, btcUsd, btcXau)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Market Regime Engine Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MARKET REGIME ENGINE // QUANTITATIVE CLASSIFIER",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = BullionGold
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF281810), RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = regime.label,
                                fontFamily = TerminalMonospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = regime.description,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Volatility Profile: ${regime.volatilityProfile}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.sp,
                        color = SteelBlue
                    )
                }
            }
        }

        // Arbitrage Research Lab
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ARBITRAGE RESEARCH LAB // TRIANGULAR PRICING DISLOCATIONS",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Continuous scanning of implied crosses (Leg 1 / Leg 2) vs Observed direct execution feeds, factoring fees, slippage, and latency.",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        items(arbOpportunities) { arb ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(arb.id, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
                        Box(
                            modifier = Modifier
                                .background(
                                    if (arb.isActionableAfterLatency) Color(0xFF132A1C) else TerminalBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (arb.isActionableAfterLatency) "ACTIONABLE DISLOCATION" else "WITHIN FEE BAND",
                                fontFamily = TerminalMonospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (arb.isActionableAfterLatency) BritishRacingGreenBright else TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Legs: ${arb.leg1} ↔ ${arb.leg2} ↔ ${arb.leg3}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.5.sp,
                        color = BullionGoldMuted
                    )
                    Text(
                        text = arb.explanation,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Market Abuse Surveillance Alerts
        item {
            Text(
                text = "MARKET ABUSE SURVEILLANCE // INTEGRITY MONITOR",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(alerts) { alert ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${alert.category.title} [${alert.category.code}]",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (alert.severity == "HIGH") MarketAskRed else StatusWarning
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    if (alert.severity == "HIGH") Color(0xFF381414) else Color(0xFF281C08),
                                    RoundedCornerShape(3.dp)
                                )
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SEV: ${alert.severity}",
                                fontFamily = TerminalMonospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (alert.severity == "HIGH") MarketAskRed else StatusWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "Target: ${alert.instrumentSymbol} | Flagged: ${alert.flaggedEntity}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = alert.evidenceDetails,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "Recommended: ${alert.recommendedAction}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.sp,
                        color = SteelBlue
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
