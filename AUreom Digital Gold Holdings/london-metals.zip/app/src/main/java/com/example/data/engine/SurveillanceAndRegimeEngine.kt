package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SurveillanceAndRegimeEngine {

    private val _currentRegime = MutableStateFlow(MarketRegime.RISK_OFF)
    val currentRegime: StateFlow<MarketRegime> = _currentRegime.asStateFlow()

    private val _surveillanceAlerts = MutableStateFlow<List<SurveillanceAlert>>(createInitialAlerts())
    val surveillanceAlerts: StateFlow<List<SurveillanceAlert>> = _surveillanceAlerts.asStateFlow()

    fun updateRegime(regime: MarketRegime) {
        _currentRegime.value = regime
    }

    fun addSurveillanceAlert(alert: SurveillanceAlert) {
        _surveillanceAlerts.value = listOf(alert) + _surveillanceAlerts.value.take(20)
    }

    private fun createInitialAlerts(): List<SurveillanceAlert> {
        val now = System.currentTimeMillis()
        return listOf(
            SurveillanceAlert(
                alertId = "SURV-ALERT-001",
                timestamp = now - 1800000,
                category = SurveillanceCategory.SPOOFING,
                instrumentSymbol = "XAU/GBP",
                severity = "HIGH",
                flaggedEntity = "Anonymous Prop Desk 14B (Bilateral DMA)",
                evidenceDetails = "Rapid placement of 500 oz bids at £3,150.80 cancelled within 85ms before sell fill execution.",
                recommendedAction = "Issue pre-trade throttle and alert Compliance Officer."
            ),
            SurveillanceAlert(
                alertId = "SURV-ALERT-002",
                timestamp = now - 3600000,
                category = SurveillanceCategory.PRICING_DISLOCATION,
                instrumentSymbol = "BTC/XAU vs XAU/USD",
                severity = "MEDIUM",
                flaggedEntity = "Cross-Venue Synthetic Feed",
                evidenceDetails = "Dislocation > 12 bps detected between London physical gold fix and synthetic tokenized asset.",
                recommendedAction = "Engage liquidity provider hedging arbitrage bridge."
            ),
            SurveillanceAlert(
                alertId = "SURV-ALERT-003",
                timestamp = now - 7200000,
                category = SurveillanceCategory.LAYERING,
                instrumentSymbol = "XAG/USD",
                severity = "LOW",
                flaggedEntity = "Thames Metals Market Maker Pool",
                evidenceDetails = "Multiple sequential bids stacked across 4 ticks with symmetric cancellation ratio (94%).",
                recommendedAction = "Logged to MiFID II / UK MAR Trade Surveillance Archive."
            )
        )
    }
}
