package com.example.data.model

enum class MarketRegime(val label: String, val description: String, val volatilityProfile: String) {
    RISK_ON("RISK ON", "Equities & Industrial metals bid; Bullion steady; FX carry favored", "Normal (12-16% annualized)"),
    RISK_OFF("RISK OFF", "Heavy flight to London physical gold & USD liquidity; Industrial metals down", "Elevated (22-28% annualized)"),
    INFLATION_EXPANSION("INFLATION EXPANSION", "Broad commodity rally; Silver & Copper outperforming Gold", "Moderate-High (18-24%)"),
    USD_STRENGTH("USD STRENGTH", "Strong USD pressuring spot metals in USD terms; XAU/GBP stable", "Moderate (15-18%)"),
    USD_WEAKNESS("USD WEAKNESS", "Broad dollar selling; Sharp rally across Bullion and FX crosses", "Moderate (14-19%)"),
    METALS_SHORTAGE("METALS SHORTAGE / BACKWARDATION", "Severe spot/cash tightness; London prompt dates in backwardation", "High Spot Vol (32%+)"),
    LIQUIDITY_STRESS("LIQUIDITY STRESS", "Widening interbank bid-ask spreads; Collateral haircuts active", "Spike (35%+)")
}

enum class SurveillanceCategory(val code: String, val title: String) {
    SPOOFING("SPOOF-01", "Order Book Spoofing / Phantom Depth"),
    LAYERING("LAYER-02", "Multi-Tier Layering on Bid/Ask"),
    WASH_TRADING("WASH-03", "Self-Matching / Wash Execution Pattern"),
    ABNORMAL_CANCEL("CNCL-04", "Abnormal High-Frequency Order Cancellation"),
    PRICING_DISLOCATION("DISLOC-05", "Cross-Market Triangular Pricing Dislocation")
}

data class SurveillanceAlert(
    val alertId: String,
    val timestamp: Long,
    val category: SurveillanceCategory,
    val instrumentSymbol: String,
    val severity: String, // "LOW", "MEDIUM", "HIGH", "CRITICAL"
    val flaggedEntity: String,
    val evidenceDetails: String,
    val recommendedAction: String
)

data class TriangularArbitrageOpportunity(
    val id: String,
    val leg1: String, // "XAU/USD"
    val leg2: String, // "GBP/USD"
    val leg3: String, // "XAU/GBP"
    val observedPrice: Double,
    val impliedPrice: Double,
    val theoreticalSpreadGbp: Double,
    val estimatedFeesGbp: Double,
    val netArbitrageGbp: Double,
    val isActionableAfterLatency: Boolean,
    val explanation: String
)

data class MarketSessionClock(
    val city: String,
    val timezoneCode: String,
    val currentLocalTime: String,
    val sessionName: String,
    val isOpen: Boolean,
    val volumeWeightPct: Int
)
