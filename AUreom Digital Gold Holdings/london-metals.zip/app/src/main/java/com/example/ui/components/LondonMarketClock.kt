package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketSessionClock
import com.example.ui.theme.*

@Composable
fun LondonMarketClockView(
    clocks: List<MarketSessionClock>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant, shape = RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LONDON MARKET CLOCK // LIQUIDITY SESSIONS",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BullionGold
            )
            Text(
                text = "UTC REFERENCE",
                fontFamily = TerminalMonospace,
                fontSize = 10.sp,
                color = TextMuted
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(clocks) { clock ->
                Box(
                    modifier = Modifier
                        .background(
                            if (clock.isOpen) Color(0xFF132A1C) else TerminalSurface,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .background(
                                        if (clock.isOpen) BritishRacingGreenBright else TextMuted,
                                        shape = androidx.compose.foundation.shape.CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = clock.city,
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = if (clock.isOpen) TextPrimary else TextSecondary
                            )
                        }
                        Text(
                            text = clock.currentLocalTime,
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = if (clock.isOpen) BullionGoldMuted else TextMuted
                        )
                        Text(
                            text = clock.timezoneCode,
                            fontFamily = TerminalMonospace,
                            fontSize = 8.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}
