package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// London Metals Terminal Palette
val TerminalBackground = Color(0xFF090C10)
val TerminalSurface = Color(0xFF0F141C)
val TerminalSurfaceVariant = Color(0xFF161E2A)
val TerminalSurfaceHover = Color(0xFF1D2635)
val TerminalBorder = Color(0xFF263345)
val TerminalBorderLight = Color(0xFF37465D)

// Accents
val BullionGold = Color(0xFFD4AF37)
val BullionGoldDark = Color(0xFF997A1E)
val BullionGoldMuted = Color(0xFFE5C158)
val BritishRacingGreen = Color(0xFF1A5632)
val BritishRacingGreenBright = Color(0xFF22C55E)
val SteelBlue = Color(0xFF60A5FA)
val LondonNavy = Color(0xFF1E293B)

// Market & Risk states
val MarketBidGreen = Color(0xFF10B981)
val MarketAskRed = Color(0xFFEF4444)
val StatusNormal = Color(0xFF10B981)
val StatusWatch = Color(0xFF38BDF8)
val StatusWarning = Color(0xFFF59E0B)
val StatusBreach = Color(0xFFDC2626)

// Text
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextGold = Color(0xFFF6D860)
