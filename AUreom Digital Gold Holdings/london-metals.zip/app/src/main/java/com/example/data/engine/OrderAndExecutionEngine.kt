package com.example.data.engine

import com.example.data.model.*
import java.util.UUID

class OrderAndExecutionEngine {

    private val idempotencyCache = mutableMapOf<String, OrderRecord>()

    fun evaluateSmartOrderRouting(
        symbol: String,
        side: OrderSide,
        quantity: Double,
        urgency: String = "NORMAL"
    ): RoutingDecision {
        return when {
            symbol.startsWith("BTC") || symbol.startsWith("USDT") || symbol.startsWith("XAUT") -> {
                RoutingDecision(
                    recommendedVenue = MarketVenue.DIGITAL_METALS,
                    venueMixExplanation = "100% Digital Execution Layer: Lowest latency (< 15ms), On-chain & Synthetic token depth.",
                    estimatedSlippageBps = 4.2,
                    liquidityScore = 9.4,
                    feeRateBps = 2.5,
                    latencyMs = 12
                )
            }
            symbol.contains("GBP") && quantity > 200.0 -> {
                RoutingDecision(
                    recommendedVenue = MarketVenue.LONDON_SPOT_OTC,
                    venueMixExplanation = "75% London Bullion OTC Dealer + 25% Screen Limit: Minimizes market impact on 200+ oz block.",
                    estimatedSlippageBps = 1.8,
                    liquidityScore = 9.8,
                    feeRateBps = 1.2,
                    latencyMs = 28
                )
            }
            symbol.startsWith("XCU") || symbol.startsWith("XAL") || symbol.startsWith("XNI") -> {
                RoutingDecision(
                    recommendedVenue = MarketVenue.LME_ELECTRONIC,
                    venueMixExplanation = "100% LME Electronic Select (Synthetic Reference): Standard prompt clearing & warranted settlement.",
                    estimatedSlippageBps = 3.1,
                    liquidityScore = 9.1,
                    feeRateBps = 1.5,
                    latencyMs = 18
                )
            }
            else -> {
                RoutingDecision(
                    recommendedVenue = MarketVenue.LONDON_SPOT_OTC,
                    venueMixExplanation = "London OTC Principal Liquidity Pool with direct allocation settlement.",
                    estimatedSlippageBps = 2.0,
                    liquidityScore = 9.6,
                    feeRateBps = 1.4,
                    latencyMs = 22
                )
            }
        }
    }

    fun executeOrder(
        request: OrderRequest,
        currentMidPrice: Double
    ): Pair<OrderRecord, ExecutionReport?> {
        // Idempotency check
        idempotencyCache[request.idempotencyKey]?.let { cached ->
            return Pair(cached, null)
        }

        val orderId = "LMX-" + UUID.randomUUID().toString().take(8).uppercase()
        val routing = evaluateSmartOrderRouting(request.instrumentSymbol, request.side, request.quantity)
        
        val executionPrice = when (request.orderType) {
            OrderType.LIMIT -> request.price ?: currentMidPrice
            OrderType.MARKET, OrderType.IOC, OrderType.FOK -> {
                val slippageMult = if (request.side == OrderSide.BUY) (1.0 + routing.estimatedSlippageBps / 10000.0) else (1.0 - routing.estimatedSlippageBps / 10000.0)
                currentMidPrice * slippageMult
            }
            OrderType.TWAP, OrderType.VWAP -> currentMidPrice * (1.0 + (if (request.side == OrderSide.BUY) 0.0003 else -0.0003))
            else -> currentMidPrice
        }

        val fees = (request.quantity * executionPrice) * (routing.feeRateBps / 10000.0)
        val now = System.currentTimeMillis()

        val eventTrail = listOf(
            "[$now] ORDER_CREATED (Client Order: ${request.clientOrderId})",
            "[$now] PRE_TRADE_RISK_CHECK_PASSED (Margin & Collateral Validated)",
            "[$now] SMART_ROUTER_DIRECTED (Venue: ${routing.recommendedVenue.fullName})",
            "[$now] ORDER_FILLED (Executed @ ${String.format("%.2f", executionPrice)} ${request.currency})"
        )

        val record = OrderRecord(
            orderId = orderId,
            clientOrderId = request.clientOrderId,
            clientId = request.clientId,
            accountId = request.accountId,
            symbol = request.instrumentSymbol,
            side = request.side,
            orderType = request.orderType,
            quantity = request.quantity,
            filledQuantity = request.quantity,
            price = request.price ?: executionPrice,
            avgFillPrice = executionPrice,
            currency = request.currency,
            venue = routing.recommendedVenue,
            status = OrderStatus.FILLED,
            timestamp = now,
            lastUpdate = now,
            fees = fees,
            slippageBps = routing.estimatedSlippageBps,
            routing = routing,
            idempotencyKey = request.idempotencyKey,
            eventTrail = eventTrail
        )

        val report = ExecutionReport(
            executionId = "EXEC-" + UUID.randomUUID().toString().take(8).uppercase(),
            orderId = orderId,
            symbol = request.instrumentSymbol,
            side = request.side,
            executedQty = request.quantity,
            executedPrice = executionPrice,
            notional = request.quantity * executionPrice,
            currency = request.currency,
            venue = routing.recommendedVenue,
            timestamp = now
        )

        idempotencyCache[request.idempotencyKey] = record
        return Pair(record, report)
    }

    fun generateFixExecutionReport(order: OrderRecord, exec: ExecutionReport): FixMessageRecord {
        val fixSide = if (order.side == OrderSide.BUY) "1" else "2"
        val fixOrdType = when (order.orderType) {
            OrderType.MARKET -> "1"
            OrderType.LIMIT -> "2"
            OrderType.STOP -> "3"
            else -> "2"
        }
        val rawFix = "8=FIX.4.4\u00019=168\u000135=8\u000149=LMX_MATCH\u000156=${order.clientId}\u000134=104\u000152=${order.timestamp}\u000111=${order.clientOrderId}\u000137=${order.orderId}\u000117=${exec.executionId}\u0001150=2\u000139=2\u000155=${order.symbol}\u000154=$fixSide\u000138=${order.quantity}\u000140=$fixOrdType\u000131=${String.format("%.2f", exec.executedPrice)}\u000132=${exec.executedQty}\u0001151=0\u000114=${exec.executedQty}\u00016=${String.format("%.2f", exec.executedPrice)}\u000110=092\u0001"

        return FixMessageRecord(
            msgType = "8 (ExecutionReport - FILLED)",
            seqNum = 104,
            senderCompId = "LMX_LONDON_ENGINE",
            targetCompId = order.clientId,
            rawFixString = rawFix,
            parsedDescription = "FIX 4.4 ExecutionReport: Order ${order.orderId} filled for ${order.quantity} ${order.symbol} @ ${String.format("%.2f", exec.executedPrice)} ${order.currency}",
            timestamp = System.currentTimeMillis()
        )
    }
}
