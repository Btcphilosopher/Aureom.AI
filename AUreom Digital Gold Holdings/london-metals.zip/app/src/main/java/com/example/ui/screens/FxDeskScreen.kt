package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun FxDeskScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val quotes by viewModel.repository.marketEngine.quotes.collectAsState()
    val pricingEngine = viewModel.repository.pricingEngine

    val xauUsd = quotes["XAU/USD"]?.last ?: 4200.00
    val gbpUsd = quotes["GBP/USD"]?.last ?: 1.3340
    val eurUsd = quotes["EUR/USD"]?.last ?: 1.0920
    val usdJpy = quotes["USD/JPY"]?.last ?: 148.50
    val btcUsd = quotes["BTC/USD"]?.last ?: 64800.0

    val currencyToGoldForward = remember(xauUsd, gbpUsd) {
        pricingEngine.calculateCurrencyToGoldForward(xauUsd, gbpUsd, 30)
    }

    val fxForwardGbp = remember(gbpUsd) {
        pricingEngine.calculateFxForward("GBP/USD", gbpUsd, 30)
    }

    val fxForwardEur = remember(eurUsd) {
        pricingEngine.calculateFxForward("EUR/USD", eurUsd, 30)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "INSTITUTIONAL FX & CROSS-ASSET PRICING DESK",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BullionGold
                    )
                    Text(
                        text = "Cross-Asset Engine: FX (Cable, Fiber, Ninja) ↔ Spot Bullion (XAU, XAG) ↔ Digital Crosses",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Live Triangulation Engine Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "TRIANGULATION ENGINE // FX → METAL → CRYPTO",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = SteelBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    TriangulationRow(
                        target = "GBP/XAU (Inverted)",
                        formula = "1 ÷ (XAU/USD ÷ GBP/USD)",
                        result = String.format("%.6f", 1.0 / (xauUsd / gbpUsd)) + " oz/£",
                        status = "INVERTED"
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    TriangulationRow(
                        target = "XAU/GBP (London Benchmark)",
                        formula = "XAU/USD ($${String.format("%.2f", xauUsd)}) ÷ GBP/USD (${String.format("%.4f", gbpUsd)})",
                        result = "£" + String.format("%.2f", xauUsd / gbpUsd),
                        status = "TRIANGULATED"
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    TriangulationRow(
                        target = "BTC/XAU (Gold-Priced Crypto)",
                        formula = "BTC/USD ($${String.format("%,.0f", btcUsd)}) ÷ XAU/USD ($${String.format("%.2f", xauUsd)})",
                        result = String.format("%.3f", btcUsd / xauUsd) + " oz",
                        status = "TRIANGULATED"
                    )
                }
            }
        }

        // Currency-to-Gold Forward Calculator
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CURRENCY-TO-GOLD FORWARD ENGINE // GBP/XAU 30D",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currencyToGoldForward.formulaBreakdown,
                        fontFamily = TerminalMonospace,
                        fontSize = 10.sp,
                        color = BullionGoldMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Spot Ref: £${String.format("%.2f", currencyToGoldForward.impliedGoldGbpSpot)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextSecondary)
                        Text("Forward Points: +£${String.format("%.2f", currencyToGoldForward.impliedForwardPointsGbp)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = BritishRacingGreenBright)
                        Text("Forward Outright: £${String.format("%.2f", currencyToGoldForward.impliedForwardGoldPriceGbp)}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = TextPrimary)
                    }
                }
            }
        }

        // FX Forwards & Forward Points Table
        item {
            Text(
                text = "INSTITUTIONAL FX FORWARDS & POINTS",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    FxForwardItem(quote = fxForwardGbp)
                    Divider(color = TerminalBorder, modifier = Modifier.padding(vertical = 6.dp))
                    FxForwardItem(quote = fxForwardEur)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TriangulationRow(target: String, formula: String, result: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1.5f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(target, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = TextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Box(modifier = Modifier.background(TerminalBorder, RoundedCornerShape(2.dp)).padding(horizontal = 3.dp, vertical = 1.dp)) {
                    Text(status, fontFamily = TerminalMonospace, fontSize = 7.5.sp, color = BullionGoldMuted)
                }
            }
            Text(formula, fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted)
        }
        Text(result, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BullionGold)
    }
}

@Composable
fun FxForwardItem(quote: com.example.data.engine.FxForwardQuote) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("${quote.pair} (${quote.tenorDays}D Forward)", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
            Text("Spot: ${String.format("%.4f", quote.spotRate)} | Points: ${String.format("%.1f", quote.forwardPoints)} pips", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextSecondary)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("Outright: ${String.format("%.4f", quote.forwardOutright)}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = TextPrimary)
            Text("Funding Diff: ${String.format("%.2f", quote.impliedFundingDiffPct)}%", fontFamily = TerminalMonospace, fontSize = 9.sp, color = SteelBlue)
        }
    }
}
