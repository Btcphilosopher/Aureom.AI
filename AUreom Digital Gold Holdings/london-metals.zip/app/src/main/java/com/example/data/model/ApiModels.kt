package com.example.data.model

data class ApiEndpointDefinition(
    val method: String, // "GET" or "POST"
    val path: String,   // "/v1/quotes/{symbol}"
    val title: String,
    val description: String,
    val requestSampleJson: String? = null,
    val responseSampleJson: String
)

data class ApiInvocationLog(
    val invocationId: String,
    val timestamp: Long,
    val method: String,
    val path: String,
    val idempotencyKey: String?,
    val statusCode: Int,
    val latencyMs: Long,
    val requestBody: String?,
    val responseBody: String
)

data class FinancialError(
    val code: String, // "INSUFFICIENT_MARGIN", "INVALID_INSTRUMENT", "PRICE_STALE", etc.
    val message: String,
    val correlationId: String,
    val timestamp: Long,
    val remediationHint: String
)

data class FixMessageRecord(
    val msgType: String, // "D (NewOrderSingle)", "8 (ExecutionReport)", "F (OrderCancelRequest)", "W (MarketDataSnapshot)"
    val seqNum: Long,
    val senderCompId: String,
    val targetCompId: String,
    val rawFixString: String,
    val parsedDescription: String,
    val timestamp: Long
)

data class WebSocketLiveEvent(
    val eventType: String, // "QUOTE_UPDATED", "TRADE_EXECUTED", "ORDER_FILLED", "RISK_UPDATED", "VAULT_UPDATED"
    val channel: String,
    val timestamp: Long,
    val payloadJson: String
)
