package com.example.data.repository

import com.example.data.engine.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class TerminalRepository(
    val marketEngine: MarketDataEngine = MarketDataEngine(),
    val pricingEngine: PricingAndCrossEngine = PricingAndCrossEngine(),
    val orderEngine: OrderAndExecutionEngine = OrderAndExecutionEngine(),
    val vaultEngine: VaultAndPhysicalEngine = VaultAndPhysicalEngine(),
    val settlementEngine: SettlementAndLedgerEngine = SettlementAndLedgerEngine(),
    val riskEngine: RiskAndMarginEngine = RiskAndMarginEngine(),
    val surveillanceEngine: SurveillanceAndRegimeEngine = SurveillanceAndRegimeEngine(),
    val apiGateway: ApiAndFixGateway = ApiAndFixGateway()
) {
    private val repoScope = CoroutineScope(Dispatchers.Default)

    // Orders & Executions
    private val _orders = MutableStateFlow<List<OrderRecord>>(createInitialOrders())
    val orders: StateFlow<List<OrderRecord>> = _orders.asStateFlow()

    private val _executions = MutableStateFlow<List<ExecutionReport>>(createInitialExecutions())
    val executions: StateFlow<List<ExecutionReport>> = _executions.asStateFlow()

    // Derivatives
    private val _futuresContracts = MutableStateFlow<List<FuturesContract>>(createInitialFutures())
    val futuresContracts: StateFlow<List<FuturesContract>> = _futuresContracts.asStateFlow()

    private val _optionsContracts = MutableStateFlow<List<OptionContract>>(createInitialOptions())
    val optionsContracts: StateFlow<List<OptionContract>> = _optionsContracts.asStateFlow()

    private val _rfqHistory = MutableStateFlow<List<RfqRecord>>(createInitialRfqs())
    val rfqHistory: StateFlow<List<RfqRecord>> = _rfqHistory.asStateFlow()

    private val _metalSwaps = MutableStateFlow<List<MetalSwapContract>>(createInitialSwaps())
    val metalSwaps: StateFlow<List<MetalSwapContract>> = _metalSwaps.asStateFlow()

    private val _perpMarket = MutableStateFlow(
        PerpetualMarket(
            symbol = "BTC/XAU-PERP",
            baseAsset = "BTC",
            quoteAsset = "XAU",
            indexPrice = 15.42,
            markPrice = 15.44,
            fundingRate8hPct = 0.0125,
            openInterestXau = 4850.0,
            maxLeverage = 20,
            maintenanceMarginPct = 5.0,
            liquidationPriceEstimate = 12.35
        )
    )
    val perpMarket: StateFlow<PerpetualMarket> = _perpMarket.asStateFlow()

    init {
        // Continuous market ticker simulation loop
        repoScope.launch {
            while (true) {
                delay(2000)
                marketEngine.stepSimulationTick()
                
                val currentQuotes = marketEngine.quotes.value
                val goldGbp = currentQuotes["XAU/GBP"]?.last ?: 3150.40
                val silverGbp = currentQuotes["XAG/GBP"]?.last ?: 39.80
                val btcGbp = (currentQuotes["BTC/USD"]?.last ?: 64800.0) / (currentQuotes["GBP/USD"]?.last ?: 1.3340)

                riskEngine.recalculateRisk(goldGbp, silverGbp, btcGbp)
            }
        }
    }

    // Trading Actions
    fun submitOrder(request: OrderRequest): Pair<OrderRecord, ExecutionReport?> {
        val currentQuote = marketEngine.quotes.value[request.instrumentSymbol]
        val mid = currentQuote?.mid ?: (request.price ?: 3150.0)

        val (order, report) = orderEngine.executeOrder(request, mid)
        _orders.value = listOf(order) + _orders.value.take(30)

        report?.let { exec ->
            _executions.value = listOf(exec) + _executions.value.take(30)

            // Convert to FIX message and record in gateway
            val fixRecord = orderEngine.generateFixExecutionReport(order, exec)
            apiGateway.broadcastWsEvent(
                eventType = "TRADE_EXECUTED",
                channel = "trades.${request.instrumentSymbol.lowercase().replace("/", "_")}",
                payloadJson = """{"trade_id": "${exec.executionId}", "order_id": "${order.orderId}", "symbol": "${order.symbol}", "qty": ${exec.executedQty}, "price": ${exec.executedPrice}}"""
            )

            // Auto-settle trade in quad-ledger & physical vault if allocated
            val settle = settlementEngine.processSettlementForTrade(
                tradeId = exec.executionId,
                symbol = order.symbol,
                side = order.side,
                quantity = exec.executedQty,
                price = exec.executedPrice,
                currency = order.currency
            )

            if (order.symbol.contains("XAU") && order.side == OrderSide.BUY) {
                vaultEngine.allocateBarForExecution(
                    ownerEntity = "City Bullion Partners",
                    metalType = "XAU",
                    fineOz = exec.executedQty,
                    settlementRef = settle.settlementId
                )
            }
        }

        return Pair(order, report)
    }

    // RFQ Workflow
    fun requestDealerRfq(
        instrument: String,
        side: OrderSide,
        quantity: Double,
        maturityDays: Int,
        currency: String = "GBP"
    ): RfqRecord {
        val rfqId = "RFQ-LDN-" + (1000..9999).random()
        val quote = marketEngine.quotes.value[instrument]
        val spot = quote?.mid ?: 3150.40
        val fwd = pricingEngine.calculateCurrencyToGoldForward(
            xauUsd = marketEngine.quotes.value["XAU/USD"]?.mid ?: 4200.0,
            gbpUsd = marketEngine.quotes.value["GBP/USD"]?.mid ?: 1.3340,
            maturityDays = maturityDays
        )

        val record = RfqRecord(
            rfqId = rfqId,
            clientId = "City Bullion Partners",
            instrumentSymbol = instrument,
            side = side,
            quantity = quantity,
            maturityDays = maturityDays,
            currency = currency,
            dealerName = "Cannon Street Commodities / Thames Metals LP",
            quotedSpot = spot,
            forwardPoints = fwd.impliedForwardPointsGbp,
            quotedForwardPrice = fwd.impliedForwardGoldPriceGbp,
            requiredMarginPct = 8.5,
            validUntilTimestamp = System.currentTimeMillis() + 45000,
            status = RfqStatus.QUOTED
        )

        _rfqHistory.value = listOf(record) + _rfqHistory.value
        return record
    }

    fun acceptRfqAndExecute(rfqId: String): SettlementCase? {
        val current = _rfqHistory.value
        val target = current.firstOrNull { it.rfqId == rfqId } ?: return null

        val updated = target.copy(
            status = RfqStatus.ACCEPTED,
            executedTradeId = "TRD-RFQ-" + (1000..9999).random()
        )
        _rfqHistory.value = current.map { if (it.rfqId == rfqId) updated else it }

        // Execute full lifecycle
        val settle = settlementEngine.processSettlementForTrade(
            tradeId = updated.executedTradeId!!,
            symbol = target.instrumentSymbol,
            side = target.side,
            quantity = target.quantity,
            price = target.quotedForwardPrice,
            currency = target.currency
        )

        vaultEngine.allocateBarForExecution(
            ownerEntity = "City Bullion Partners",
            metalType = "XAU",
            fineOz = target.quantity,
            settlementRef = settle.settlementId
        )

        return settle
    }

    // Guided Demonstrations
    fun executeGuidedTrade1Demo(): String {
        val rfq = requestDealerRfq("XAU/GBP", OrderSide.BUY, 250.0, 30, "GBP")
        acceptRfqAndExecute(rfq.rfqId)
        return "TRADE 1 DEMO COMPLETED: City Bullion Partners bought 250 XAU/GBP @ £${String.format("%.2f", rfq.quotedForwardPrice)}. Cash debited, gold bar allocated in London Vault 04, quad-ledger balanced, 5-point physical reconciliation PASSED."
    }

    fun executeHedgeDemo(): String {
        // Dealer buys 500 XAU and hedges with futures & FX
        val goldMid = marketEngine.quotes.value["XAU/GBP"]?.mid ?: 3150.40
        return "HEDGE SIMULATION: Client bought 500 oz XAU spot (£1.575M). Dealer hedged with 5x XAU-F1 Futures (Delta: -500 oz) + Cable FX Short \$2.1M GBP/USD. Net Gold Delta: 0.0 oz; Net FX Delta: £0.00; Residual Basis: 1.8 bps."
    }

    private fun createInitialOrders(): List<OrderRecord> {
        val now = System.currentTimeMillis()
        val routing = orderEngine.evaluateSmartOrderRouting("XAU/GBP", OrderSide.BUY, 100.0)
        return listOf(
            OrderRecord(
                orderId = "LMX-000001842",
                clientOrderId = "CLI-ORD-9912",
                clientId = "City Bullion Partners",
                accountId = "ACC-LDN-01994",
                symbol = "XAU/GBP",
                side = OrderSide.BUY,
                orderType = OrderType.LIMIT,
                quantity = 100.0,
                filledQuantity = 100.0,
                price = 3150.00,
                avgFillPrice = 3150.40,
                currency = "GBP",
                venue = MarketVenue.LONDON_SPOT_OTC,
                status = OrderStatus.FILLED,
                timestamp = now - 180000,
                lastUpdate = now - 175000,
                fees = 37.80,
                slippageBps = 1.2,
                routing = routing,
                idempotencyKey = "IDEM-XAU-20261004-9912",
                eventTrail = listOf("ORDER_CREATED", "PRE_TRADE_MARGIN_PASS", "ROUTED_OTC_LONDON", "ORDER_FILLED")
            )
        )
    }

    private fun createInitialExecutions(): List<ExecutionReport> {
        val now = System.currentTimeMillis()
        return listOf(
            ExecutionReport(
                executionId = "EXEC-88194",
                orderId = "LMX-000001842",
                symbol = "XAU/GBP",
                side = OrderSide.BUY,
                executedQty = 100.0,
                executedPrice = 3150.40,
                notional = 315040.0,
                currency = "GBP",
                venue = MarketVenue.LONDON_SPOT_OTC,
                timestamp = now - 175000,
                counterparty = "Thames Metals Ltd",
                settlementStatus = "SETTLED_AND_ALLOCATED"
            )
        )
    }

    private fun createInitialFutures(): List<FuturesContract> {
        return listOf(
            FuturesContract("XAU-F1", "XAU (Gold)", PromptDate.PROMPT_1M, "Nov 2026", 100.0, "Fine Troy Oz", 0.10, 3162.80, 3162.40, 3163.20, 48200, 14200, 12.40, 4.85, 30),
            FuturesContract("XAU-F2", "XAU (Gold)", PromptDate.PROMPT_2M, "Dec 2026", 100.0, "Fine Troy Oz", 0.10, 3175.50, 3175.00, 3176.00, 39400, 9800, 25.10, 4.90, 60),
            FuturesContract("XAU-F3", "XAU (Gold)", PromptDate.PROMPT_3M, "Jan 2027", 100.0, "Fine Troy Oz", 0.10, 3188.90, 3188.30, 3189.50, 89100, 28400, 38.50, 4.95, 90),
            FuturesContract("XAU-F4", "XAU (Gold)", PromptDate.PROMPT_6M, "Apr 2027", 100.0, "Fine Troy Oz", 0.10, 3228.40, 3227.50, 3229.30, 24500, 6200, 78.00, 5.05, 180),
            
            FuturesContract("XAG-F1", "XAG (Silver)", PromptDate.PROMPT_1M, "Nov 2026", 5000.0, "Fine Troy Oz", 0.005, 39.95, 39.92, 39.98, 34000, 11200, 0.15, 5.10, 30),
            FuturesContract("XAG-F2", "XAG (Silver)", PromptDate.PROMPT_3M, "Jan 2027", 5000.0, "Fine Troy Oz", 0.005, 40.35, 40.31, 40.39, 41200, 15400, 0.55, 5.25, 90),

            FuturesContract("CU-3M", "Copper Grade A", PromptDate.PROMPT_3M, "Jan 2027", 25.0, "Metric Tonnes", 0.50, 9890.00, 9888.00, 9892.00, 114000, 42000, 50.00, 3.80, 90),
            FuturesContract("ALU-3M", "Primary Aluminium", PromptDate.PROMPT_3M, "Jan 2027", 25.0, "Metric Tonnes", 0.50, 2640.00, 2638.50, 2641.50, 98000, 31000, 20.00, 3.40, 90),
            FuturesContract("NI-3M", "Primary Nickel", PromptDate.PROMPT_3M, "Jan 2027", 6.0, "Metric Tonnes", 1.00, 16920.00, 16910.00, 16930.00, 32000, 8400, 120.00, 4.20, 90),
            FuturesContract("ZN-3M", "Zinc Special High Grade", PromptDate.PROMPT_3M, "Jan 2027", 25.0, "Metric Tonnes", 0.50, 2995.00, 2993.50, 2996.50, 41000, 12800, 15.00, 3.60, 90),
            FuturesContract("PB-3M", "Standard Lead", PromptDate.PROMPT_3M, "Jan 2027", 25.0, "Metric Tonnes", 0.50, 2155.00, 2154.00, 2156.00, 28000, 7100, 15.00, 3.50, 90),
            FuturesContract("SN-3M", "Refined Tin", PromptDate.PROMPT_3M, "Jan 2027", 5.0, "Metric Tonnes", 5.00, 31980.00, 31950.00, 32010.00, 14200, 3800, 180.00, 4.50, 90)
        )
    }

    private fun createInitialOptions(): List<OptionContract> {
        return listOf(
            OptionContract("OPT-XAU-3150-C", "XAU (Gold)", OptionType.CALL, 3150.0, 30, "Nov 2026", 3150.40, 48.20, 16.4, Greeks(0.52, 0.004, -0.75, 14.2, 0.12), 100.01, 14200),
            OptionContract("OPT-XAU-3150-P", "XAU (Gold)", OptionType.PUT, 3150.0, 30, "Nov 2026", 3150.40, 46.80, 16.4, Greeks(-0.48, 0.004, -0.72, 14.2, -0.11), 100.01, 12800),
            OptionContract("OPT-XAU-3200-C", "XAU (Gold)", OptionType.CALL, 3200.0, 30, "Nov 2026", 3150.40, 26.40, 17.1, Greeks(0.35, 0.005, -0.68, 12.8, 0.08), 98.45, 19400),
            OptionContract("OPT-XAU-3100-P", "XAU (Gold)", OptionType.PUT, 3100.0, 30, "Nov 2026", 3150.40, 24.90, 17.0, Greeks(-0.32, 0.005, -0.65, 12.5, -0.07), 101.62, 16500)
        )
    }

    private fun createInitialRfqs(): List<RfqRecord> {
        val now = System.currentTimeMillis()
        return listOf(
            RfqRecord(
                rfqId = "RFQ-LDN-8841",
                clientId = "City Bullion Partners",
                instrumentSymbol = "XAU/GBP",
                side = OrderSide.BUY,
                quantity = 250.0,
                maturityDays = 30,
                currency = "GBP",
                dealerName = "Westminster Bullion Markets",
                quotedSpot = 3150.40,
                forwardPoints = 10.35,
                quotedForwardPrice = 3160.75,
                requiredMarginPct = 8.5,
                validUntilTimestamp = now - 3600000,
                status = RfqStatus.ACCEPTED,
                executedTradeId = "TRD-8821"
            )
        )
    }

    private fun createInitialSwaps(): List<MetalSwapContract> {
        return listOf(
            MetalSwapContract(
                swapId = "SWAP-XAU-001",
                metalSymbol = "XAU",
                notionalMetalOz = 1000.0,
                baseValueGbp = 3150400.0,
                maturityDays = 90,
                metalLeaseRatePct = 1.15,
                fundingRatePct = 5.25,
                collateralHeldGbp = 3450000.0,
                counterparty = "Fleet Street Refining / Royal Exchange Metals",
                status = "ACTIVE_ACCRUING"
            )
        )
    }
}
