package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun DemonstrationsScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    var outputMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "GUIDED CUJ DEMONSTRATION ENGINE",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Execute the end-to-end London market mechanisms: Bilateral OTC Gold RFQ, Vault Allocation, Cross-Asset Triangulation, Dealer Hedging, and Portfolio Stress Shocks.",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        outputMessage?.let { out ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF132A1C)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "DEMONSTRATION OUTPUT:",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = BritishRacingGreenBright
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = out,
                            fontFamily = TerminalMonospace,
                            fontSize = 10.5.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Demo 1: Full Trade Lifecycle (Trade 1)
        item {
            DemoCard(
                title = "DEMO 1: LONDON OTC GOLD RFQ → VAULT ALLOCATION",
                description = "City Bullion Partners requests 250 XAU/GBP 30D forward. Dealer quotes spot + forward points. Acceptance triggers instant GBP cash debit, specific 400oz gold bar allocation in London Vault 04, quad-ledger entries, and 5-point reconciliation.",
                buttonText = "EXECUTE TRADE 1 (250 XAU/GBP LIFECYCLE)",
                onClick = {
                    val res = viewModel.repository.executeGuidedTrade1Demo()
                    outputMessage = res
                    viewModel.selectTab(TerminalTab.SETTLEMENT)
                }
            )
        }

        // Demo 2: Cross-Asset Triangulation
        item {
            DemoCard(
                title = "DEMO 2: CROSS-ASSET TRIANGULATION (FX ↔ METAL ↔ CRYPTO)",
                description = "Demonstrates how BTC/USD ($64,800) and XAU/USD ($4,200) derive BTC/XAU (15.42 Fine Troy Ounces/BTC), and USDT/USD and XAUT/USD derive USDT/XAUT with exact direct vs inverse notation.",
                buttonText = "RUN CROSS-ASSET TRIANGULATION SCAN",
                onClick = {
                    val quotes = viewModel.repository.marketEngine.quotes.value
                    val xauUsd = quotes["XAU/USD"]?.last ?: 4200.0
                    val btcUsd = quotes["BTC/USD"]?.last ?: 64800.0
                    val btcXau = btcUsd / xauUsd
                    outputMessage = "TRIANGULATION RESULT: BTC/USD ($${String.format("%,.0f", btcUsd)}) ÷ XAU/USD ($${String.format("%.2f", xauUsd)}) = BTC/XAU is ${String.format("%.3f", btcXau)} Fine Troy Oz of Gold per BTC. Inverted XAU/BTC = ${String.format("%.6f", 1.0 / btcXau)} BTC/oz."
                    viewModel.selectTab(TerminalTab.FX_DESK)
                }
            )
        }

        // Demo 3: Dealer Futures & FX Hedge
        item {
            DemoCard(
                title = "DEMO 3: DEALER FUTURES & FX HEDGING ENGINE",
                description = "Client purchases 500 XAU spot. Dealer hedging engine automatically calculates Gold Delta (+500 oz) and FX Delta (\$2.1M), executing 5x XAU-F1 short futures contracts and Cable short to eliminate directional risk.",
                buttonText = "EXECUTE DEALER 500 XAU HEDGE SIMULATION",
                onClick = {
                    val res = viewModel.repository.executeHedgeDemo()
                    outputMessage = res
                    viewModel.selectTab(TerminalTab.DERIVATIVES)
                }
            )
        }

        // Demo 4: Cross-Asset Stress Testing
        item {
            DemoCard(
                title = "DEMO 4: CROSS-ASSET LIQUIDITY STRESS SHOCK",
                description = "Simulates severe liquidity shock: Gold -15%, Silver -25%, BTC -35%, GBP/USD -8%, Volatility +60%. Evaluates portfolio P&L loss, margin requirement escalation from £9.8M to £12.74M, and collateral deficit.",
                buttonText = "TRIGGER MACRO STRESS SHOCK",
                onClick = {
                    val shock = viewModel.repository.riskEngine.evaluateCustomStressTest(-15.0, -25.0, -35.0, -8.0, 60.0)
                    outputMessage = "STRESS SHOCK APPLIED: Simulated P&L loss is -£${String.format("%,.0f", kotlin.math.abs(shock.simulatedPnlImpactGbp))}. Initial margin required increases to £${String.format("%,.0f", shock.simulatedMarginRequirementGbp)}. Margin Call Triggered."
                    viewModel.selectTab(TerminalTab.PORTFOLIO)
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DemoCard(
    title: String,
    description: String,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BullionGold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontFamily = FontFamily.SansSerif,
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(buttonText, fontFamily = TerminalMonospace, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
