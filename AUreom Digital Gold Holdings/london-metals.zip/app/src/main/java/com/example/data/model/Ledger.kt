package com.example.data.model

import java.math.BigDecimal

enum class LedgerCategory(val displayName: String) {
    CASH_GBP("Cash Ledger (GBP)"),
    CASH_USD("Cash Ledger (USD)"),
    CASH_EUR("Cash Ledger (EUR)"),
    CASH_USDT("Cash / Stablecoin Ledger (USDT)"),
    METAL_XAU("Physical Metal Ledger (XAU Fine Oz)"),
    METAL_XAG("Physical Metal Ledger (XAG Fine Oz)"),
    METAL_XPT("Physical Metal Ledger (XPT Fine Oz)"),
    DIGITAL_XAUT("Digital Asset Gold Ledger (XAUT Tokens)")
}

data class LedgerEntry(
    val entryId: String,
    val sequenceNumber: Long,
    val timestamp: Long,
    val category: LedgerCategory,
    val debitAccount: String,
    val creditAccount: String,
    val amount: BigDecimal,
    val unit: String,
    val referenceTransactionId: String,
    val eventType: String, // "TRADE_FILL", "SETTLEMENT", "ALLOCATION", "BOOK_ENTRY_TRANSFER"
    val hashSignature: String
)

data class InstitutionalAccountBalance(
    val accountId: String,
    val accountName: String,
    val cashGbp: BigDecimal,
    val cashUsd: BigDecimal,
    val cashEur: BigDecimal,
    val cashUsdt: BigDecimal,
    val metalXauOz: BigDecimal,
    val metalXagOz: BigDecimal,
    val metalXptOz: BigDecimal,
    val digitalXaut: BigDecimal,
    val allocatedBarIds: List<String>
)

data class ReconciliationBreak(
    val component: String,
    val expected: String,
    val actual: String,
    val discrepancy: String,
    val timestamp: Long
)

data class PhysicalMetalReconciliationReport(
    val timestamp: Long,
    val accountId: String,
    val clientMetalBalanceOz: Double,
    val barInventoryOz: Double,
    val vaultLocationVerified: Boolean,
    val ownershipRecordVerified: Boolean,
    val quadLedgerBalanced: Boolean,
    val statusPass: Boolean,
    val detectedBreaks: List<ReconciliationBreak> = emptyList()
)
