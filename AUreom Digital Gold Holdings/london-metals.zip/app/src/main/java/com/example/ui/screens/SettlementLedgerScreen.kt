package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderSide
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun SettlementLedgerScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val settlements by viewModel.repository.settlementEngine.activeSettlements.collectAsState()
    val ledgerEntries by viewModel.repository.settlementEngine.ledgerHistory.collectAsState()
    val balance by viewModel.repository.settlementEngine.accountBalance.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Account Balance Sheet (Quad-Ledger Balances)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "QUAD-LEDGER BALANCE SHEET (DECIMAL PRECISION)",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = BullionGold
                        )
                        Text(
                            text = balance.accountId,
                            fontFamily = TerminalMonospace,
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BalanceBox("Cash GBP", "£" + String.format("%,.2f", balance.cashGbp.toDouble()), TextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        BalanceBox("Gold XAU", String.format("%,.4f", balance.metalXauOz.toDouble()) + " oz", BullionGoldMuted, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BalanceBox("Silver XAG", String.format("%,.2f", balance.metalXagOz.toDouble()) + " oz", SteelBlue, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        BalanceBox("Digital XAUT", String.format("%,.4f", balance.digitalXaut.toDouble()) + " XAUT", BritishRacingGreenBright, Modifier.weight(1f))
                    }
                }
            }
        }

        // 7-Stage Settlement Lifecycle Visualizer
        item {
            Text(
                text = "7-STAGE SETTLEMENT PIPELINE LIFECYCLE",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(settlements) { st ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${st.settlementId} // ${st.side} ${st.quantity.toInt()} ${st.symbol}",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = if (st.side == OrderSide.BUY) MarketBidGreen else MarketAskRed
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF132A1C), RoundedCornerShape(3.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = st.status,
                                fontFamily = TerminalMonospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRacingGreenBright
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Pipeline Stages Horizontal Flow
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        st.stages.forEach { stage ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 1.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .background(BritishRacingGreenBright, androidx.compose.foundation.shape.CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(stage.stageName, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = TextPrimary)
                                }
                                Text(stage.description, fontFamily = FontFamily.SansSerif, fontSize = 8.5.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }

        // Immutable Double-Entry Quad-Ledger Journal
        item {
            Text(
                text = "IMMUTABLE AUDITED DOUBLE-ENTRY JOURNAL",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(ledgerEntries.take(12)) { entry ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${entry.entryId} // ${entry.category.displayName}",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = BullionGoldMuted
                        )
                        Text(
                            text = "${entry.amount} ${entry.unit}",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = "Debit: ${entry.debitAccount} → Credit: ${entry.creditAccount}",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "Audit Signature: ${entry.hashSignature} | Event: ${entry.eventType}",
                        fontFamily = TerminalMonospace,
                        fontSize = 8.sp,
                        color = TextMuted
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun BalanceBox(title: String, amount: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, fontFamily = TerminalMonospace, fontSize = 8.sp, color = TextMuted)
            Text(amount, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = color)
        }
    }
}
