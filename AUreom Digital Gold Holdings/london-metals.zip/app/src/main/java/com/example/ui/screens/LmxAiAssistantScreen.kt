package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun LmxAiAssistantScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.aiMessages.collectAsState()
    val inputText by viewModel.aiInputText.collectAsState()

    val suggestedPrompts = listOf(
        "What is current synthetic XAU/GBP price?",
        "Show the gold forward curve contango",
        "Why is BTC/XAU falling?",
        "Calculate my gold exposure in GBP",
        "Stress silver down 20%",
        "Show all allocated bars in Vault 04"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp)
    ) {
        // AI Header Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "LMX AI // QUANTITATIVE MARKET COPILOT",
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = BullionGold
                )
                Text(
                    text = "Connected directly to live local pricing, vault ledger, risk parameters, and order book state.",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 9.5.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Prompt Suggestions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (p in suggestedPrompts) {
                SuggestionChip(
                    onClick = { viewModel.sendAiPrompt(p) },
                    label = {
                        Text(p, fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextPrimary)
                    },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = TerminalSurface
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        borderColor = TerminalBorder,
                        enabled = true
                    ),
                    modifier = Modifier.height(26.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Chat Conversation Stream
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.isUser
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) Color(0xFF1D2838) else TerminalSurface
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth(0.92f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isUser) "DEALING DESK OPERATOR" else "LMX MARKET COPILOT",
                                    fontFamily = TerminalMonospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.5.sp,
                                    color = if (isUser) SteelBlue else BullionGoldMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.text,
                                fontFamily = if (isUser) FontFamily.SansSerif else TerminalMonospace,
                                fontSize = 11.sp,
                                color = TextPrimary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Input Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(6.dp))
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { viewModel.updateAiInput(it) },
                placeholder = { Text("Ask quantitative market questions...", fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextMuted) },
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                )
            )
            IconButton(
                onClick = { viewModel.sendAiPrompt(inputText) },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("send_ai_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send Prompt",
                    tint = BullionGold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
