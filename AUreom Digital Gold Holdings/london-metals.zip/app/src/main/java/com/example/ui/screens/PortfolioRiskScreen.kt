package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarginTier
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun PortfolioRiskScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val riskSummary by viewModel.repository.riskEngine.portfolioRisk.collectAsState()
    val customStressResult by viewModel.customStressResult.collectAsState()

    val goldShock by viewModel.stressGoldShock.collectAsState()
    val silverShock by viewModel.stressSilverShock.collectAsState()
    val btcShock by viewModel.stressBtcShock.collectAsState()
    val volShock by viewModel.stressVolShock.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Executive NAV Summary Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PORTFOLIO EXECUTIVE COMMAND CENTRE",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = BullionGold
                        )
                        Text(
                            text = "BASE: GBP",
                            fontFamily = TerminalMonospace,
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "£${String.format("%,.0f", riskSummary.totalNavGbp)}",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Asset Allocation Bar Breakdown
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        NavBreakdownChip("Gold (37.1%)", "£9.2M", BullionGoldMuted, Modifier.weight(1f))
                        NavBreakdownChip("Silver (15.3%)", "£3.8M", SteelBlue, Modifier.weight(1f))
                        NavBreakdownChip("FX (16.5%)", "£4.1M", TextSecondary, Modifier.weight(1f))
                        NavBreakdownChip("Digital (11.3%)", "£2.8M", BritishRacingGreenBright, Modifier.weight(1f))
                    }
                }
            }
        }

        // 4-Tier Margin Utilisation Monitor
        item {
            val margin = riskSummary.marginProfile
            val tierColor = when (margin.tier) {
                MarginTier.NORMAL -> BritishRacingGreenBright
                MarginTier.WATCH -> SteelBlue
                MarginTier.WARNING -> StatusWarning
                MarginTier.BREACH -> StatusBreach
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MARGIN UTILISATION & COLLATERAL",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .background(tierColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "TIER: ${margin.tier.label} (${String.format("%.1f", margin.marginUtilisationPct)}%)",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = tierColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (margin.marginUtilisationPct / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = tierColor,
                        trackColor = TerminalBorder,
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Initial Margin: £${String.format("%,.0f", margin.initialMarginRequiredGbp)}", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextSecondary)
                        Text("Maint Margin: £${String.format("%,.0f", margin.maintenanceMarginGbp)}", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextSecondary)
                        Text("Collateral: £${String.format("%,.0f", margin.totalCollateralPostHaircutGbp)}", fontFamily = TerminalMonospace, fontSize = 9.sp, color = BullionGoldMuted)
                    }
                }
            }
        }

        // Multi-Asset P&L Decomposition
        item {
            val pnl = riskSummary.pnlDecomposition
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "MULTI-ASSET P&L ATTRIBUTION DECOMPOSITION",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Spot Metals P&L: +£${String.format("%,.0f", pnl.spotPnlGbp)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = MarketBidGreen)
                        Text("Futures P&L: +£${String.format("%,.0f", pnl.futuresPnlGbp)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = MarketBidGreen)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Physical Custody: +£${String.format("%,.0f", pnl.physicalPnlGbp)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = MarketBidGreen)
                        Text("Digital Assets: +£${String.format("%,.0f", pnl.digitalPnlGbp)}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = MarketBidGreen)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Financing Costs: -£${String.format("%,.0f", kotlin.math.abs(pnl.financingCostGbp))}", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = MarketAskRed)
                        Text("Net Realised + Unrealised: +£${String.format("%,.0f", pnl.netTotalPnlGbp)}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 9.5.sp, color = BullionGold)
                    }
                }
            }
        }

        // Interactive Cross-Asset Stress Testing Lab
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CROSS-ASSET STRESS TESTING LAB",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Apply simultaneous macroeconomic scenario shocks across Gold, Silver, BTC & Volatility surfaces.",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = goldShock,
                            onValueChange = { viewModel.updateStressInput("gold", it) },
                            label = { Text("Gold %", fontFamily = TerminalMonospace, fontSize = 9.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = silverShock,
                            onValueChange = { viewModel.updateStressInput("silver", it) },
                            label = { Text("Silver %", fontFamily = TerminalMonospace, fontSize = 9.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = btcShock,
                            onValueChange = { viewModel.updateStressInput("btc", it) },
                            label = { Text("BTC %", fontFamily = TerminalMonospace, fontSize = 9.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = volShock,
                            onValueChange = { viewModel.updateStressInput("vol", it) },
                            label = { Text("Vol +%", fontFamily = TerminalMonospace, fontSize = 9.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.runCustomStressSimulation() },
                        colors = ButtonDefaults.buttonColors(containerColor = MarketAskRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SIMULATE SCENARIO SHOCK (STRESS TEST)", fontFamily = TerminalMonospace, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    customStressResult?.let { res ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TerminalSurface, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("SIMULATION RESULT:", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = MarketAskRed)
                                Text("Projected P&L Loss: -£${String.format("%,.0f", kotlin.math.abs(res.simulatedPnlImpactGbp))}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MarketAskRed)
                                Text("New Initial Margin Required: £${String.format("%,.0f", res.simulatedMarginRequirementGbp)}", fontFamily = TerminalMonospace, fontSize = 10.sp, color = TextSecondary)
                                Text("Risk Contribution: Gold ${String.format("%.1f", res.riskContributionGoldPct)}% | BTC ${String.format("%.1f", res.riskContributionBtcPct)}%", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = SteelBlue)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun NavBreakdownChip(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(label, fontFamily = TerminalMonospace, fontSize = 8.sp, color = TextMuted)
            Text(value, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = color)
        }
    }
}
