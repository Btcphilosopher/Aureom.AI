package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalStatusStrip(
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalBackground)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusBadge("REST API", "200 OK", BritishRacingGreenBright)
            StatusBadge("WS", "12ms", BritishRacingGreenBright)
            StatusBadge("SOR", "ONLINE", SteelBlue)
            StatusBadge("LEDGER", "BALANCED", BullionGold)
            StatusBadge("VAULT 04", "RECONCILED", BritishRacingGreenBright)
        }
        Text(
            text = "LMX // v3.7 INSTITUTIONAL",
            fontFamily = TerminalMonospace,
            fontSize = 9.sp,
            color = TextMuted
        )
    }
}

@Composable
private fun StatusBadge(title: String, status: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(4.dp)
                .background(color, shape = androidx.compose.foundation.shape.CircleShape)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = "$title:",
            fontFamily = TerminalMonospace,
            fontSize = 8.5.sp,
            color = TextMuted
        )
        Spacer(modifier = Modifier.width(2.dp))
        Text(
            text = status,
            fontFamily = TerminalMonospace,
            fontWeight = FontWeight.Bold,
            fontSize = 8.5.sp,
            color = color
        )
    }
}
