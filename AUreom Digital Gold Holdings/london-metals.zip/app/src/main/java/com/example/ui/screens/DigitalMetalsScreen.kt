package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun DigitalMetalsScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val quotes by viewModel.repository.marketEngine.quotes.collectAsState()
    val pricingEngine = viewModel.repository.pricingEngine

    val xauSpotGbp = quotes["XAU/GBP"]?.last ?: 3150.40
    val xautGbp = quotes["XAUT/GBP"]?.last ?: 3152.90
    val futGbp = 3162.80

    val comparisons = remember(xauSpotGbp, xautGbp) {
        pricingEngine.getDigitalVsPhysicalComparisons(xauSpotGbp, xautGbp, futGbp)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Disclaimer & Architecture Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "DIGITAL METALS & TOKENISED ASSET LAYER",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Architecture Notice: The platform models digital assets (XAUT, USDT, BTC) as synthetic execution & settlement abstractions. Physical allocated bars remain legally segregated bailment objects.",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Digital vs Physical Comparison Engine
        item {
            Text(
                text = "DIGITAL VS PHYSICAL GOLD COMPARISON ENGINE",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(comparisons) { comp ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = comp.productType,
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = BullionGoldMuted
                        )
                        Text(
                            text = "£${String.format("%.2f", comp.currentPriceGbp)}",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = comp.identifier,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = "Premium/Discount: ${if (comp.premiumDiscountVsSpotPct >= 0) "+" else ""}${String.format("%.2f", comp.premiumDiscountVsSpotPct)}%",
                            fontFamily = TerminalMonospace,
                            fontSize = 9.5.sp,
                            color = if (comp.premiumDiscountVsSpotPct >= 0) MarketBidGreen else MarketAskRed
                        )
                        Text(
                            text = "Custody: ${String.format("%.1f", comp.annualCustodyBps)} bps/yr",
                            fontFamily = TerminalMonospace,
                            fontSize = 9.5.sp,
                            color = TextMuted
                        )
                        Text(
                            text = "Settlement: ${comp.settlementDelay}",
                            fontFamily = TerminalMonospace,
                            fontSize = 9.5.sp,
                            color = SteelBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Counterparty: ${comp.counterpartyExposure}",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "Legal Status: ${comp.legalInterchangeabilityNote}",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Digital Metals Live Quotes
        item {
            Text(
                text = "SYNTHETIC DIGITAL METALS RATES",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    val xautUsd = quotes["XAUT/USD"]?.last ?: 4203.40
                    val btcXau = quotes["BTC/XAU"]?.last ?: 15.42
                    val usdtXaut = quotes["USDT/XAUT"]?.last ?: 0.000238

                    Text("XAUT/USD (Tether Gold): $${String.format("%.2f", xautUsd)} (Spread: $0.50)", fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("BTC/XAU (Bitcoin in Gold): ${String.format("%.3f", btcXau)} Fine Troy Ounces per BTC", fontFamily = TerminalMonospace, fontSize = 11.sp, color = BullionGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("USDT/XAUT (Stablecoin in Gold): ${String.format("%.6f", usdtXaut)} XAUT per USDT", fontFamily = TerminalMonospace, fontSize = 11.sp, color = TextPrimary)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
