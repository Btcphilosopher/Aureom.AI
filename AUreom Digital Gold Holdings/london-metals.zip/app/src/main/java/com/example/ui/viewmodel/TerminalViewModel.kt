package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.engine.*
import com.example.data.model.*
import com.example.data.repository.TerminalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class TerminalTab(val title: String, val shortcutKey: String) {
    MARKETS("Markets", "G"),
    TRADE("Trade", "O"),
    DERIVATIVES("Derivatives", "D"),
    FX_DESK("FX Desk", "F"),
    DIGITAL("Digital", "C"),
    VAULT("Vault", "V"),
    PORTFOLIO("Portfolio & Risk", "P"),
    SETTLEMENT("Settlement", "S"),
    RESEARCH("Research & Surv", "R"),
    API("API & FIX", "A"),
    LMX_AI("LMX AI", "I"),
    DEMOS("Demos", "X")
}

data class AiMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long,
    val structuredDataNote: String? = null
)

class TerminalViewModel(
    val repository: TerminalRepository = TerminalRepository()
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(TerminalTab.MARKETS)
    val selectedTab: StateFlow<TerminalTab> = _selectedTab.asStateFlow()

    private val _commandInput = MutableStateFlow("")
    val commandInput: StateFlow<String> = _commandInput.asStateFlow()

    private val _commandFeedback = MutableStateFlow<String?>(null)
    val commandFeedback: StateFlow<String?> = _commandFeedback.asStateFlow()

    // Trade screen form state
    private val _selectedTradeSymbol = MutableStateFlow("XAU/GBP")
    val selectedTradeSymbol: StateFlow<String> = _selectedTradeSymbol.asStateFlow()

    private val _tradeSide = MutableStateFlow(OrderSide.BUY)
    val tradeSide: StateFlow<OrderSide> = _tradeSide.asStateFlow()

    private val _tradeOrderType = MutableStateFlow(OrderType.LIMIT)
    val tradeOrderType: StateFlow<OrderType> = _tradeOrderType.asStateFlow()

    private val _tradeQuantity = MutableStateFlow("100.00")
    val tradeQuantity: StateFlow<String> = _tradeQuantity.asStateFlow()

    private val _tradePrice = MutableStateFlow("3150.40")
    val tradePrice: StateFlow<String> = _tradePrice.asStateFlow()

    private val _tradeCurrency = MutableStateFlow("GBP")
    val tradeCurrency: StateFlow<String> = _tradeCurrency.asStateFlow()

    private val _tradeNotification = MutableStateFlow<String?>(null)
    val tradeNotification: StateFlow<String?> = _tradeNotification.asStateFlow()

    // Stress testing custom input state
    private val _stressGoldShock = MutableStateFlow("-15")
    val stressGoldShock: StateFlow<String> = _stressGoldShock.asStateFlow()

    private val _stressSilverShock = MutableStateFlow("-25")
    val stressSilverShock: StateFlow<String> = _stressSilverShock.asStateFlow()

    private val _stressBtcShock = MutableStateFlow("-35")
    val stressBtcShock: StateFlow<String> = _stressBtcShock.asStateFlow()

    private val _stressGbpShock = MutableStateFlow("-8")
    val stressGbpShock: StateFlow<String> = _stressGbpShock.asStateFlow()

    private val _stressVolShock = MutableStateFlow("60")
    val stressVolShock: StateFlow<String> = _stressVolShock.asStateFlow()

    private val _customStressResult = MutableStateFlow<StressShockScenario?>(null)
    val customStressResult: StateFlow<StressShockScenario?> = _customStressResult.asStateFlow()

    // Book-entry transfer form state
    private val _selectedBarToTransfer = MutableStateFlow("LDN-AU-00048271")
    val selectedBarToTransfer: StateFlow<String> = _selectedBarToTransfer.asStateFlow()

    private val _transferToEntity = MutableStateFlow("Thames Metals Ltd")
    val transferToEntity: StateFlow<String> = _transferToEntity.asStateFlow()

    // API Console State
    private val _selectedApiEndpoint = MutableStateFlow(repository.apiGateway.availableEndpoints[0])
    val selectedApiEndpoint: StateFlow<ApiEndpointDefinition> = _selectedApiEndpoint.asStateFlow()

    private val _customApiRequest = MutableStateFlow<String>("")
    val customApiRequest: StateFlow<String> = _customApiRequest.asStateFlow()

    private val _apiIdempotencyKey = MutableStateFlow("IDEM-LMX-" + UUID.randomUUID().toString().take(8))
    val apiIdempotencyKey: StateFlow<String> = _apiIdempotencyKey.asStateFlow()

    private val _latestApiLog = MutableStateFlow<ApiInvocationLog?>(null)
    val latestApiLog: StateFlow<ApiInvocationLog?> = _latestApiLog.asStateFlow()

    // AI Assistant Messages
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(createInitialAiMessages())
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _aiInputText = MutableStateFlow("")
    val aiInputText: StateFlow<String> = _aiInputText.asStateFlow()

    init {
        // Sync default trade price when quotes update
        viewModelScope.launch {
            repository.marketEngine.quotes.collect { quotes ->
                val q = quotes[_selectedTradeSymbol.value]
                if (q != null && _tradePrice.value.isEmpty()) {
                    _tradePrice.value = String.format("%.2f", q.mid)
                }
            }
        }
    }

    fun selectTab(tab: TerminalTab) {
        _selectedTab.value = tab
    }

    fun updateCommandInput(input: String) {
        _commandInput.value = input
    }

    fun executeCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        when {
            trimmed.startsWith("BUY", ignoreCase = true) || trimmed.startsWith("SELL", ignoreCase = true) -> {
                val parts = trimmed.split(" ")
                val side = if (parts[0].equals("BUY", true)) OrderSide.BUY else OrderSide.SELL
                val qty = parts.getOrNull(1)?.toDoubleOrNull() ?: 50.0
                val sym = parts.getOrNull(2)?.uppercase() ?: "XAU/GBP"

                val quote = repository.marketEngine.quotes.value[sym]
                val mid = quote?.mid ?: 3150.40

                val req = OrderRequest(
                    clientOrderId = "CMD-" + UUID.randomUUID().toString().take(6),
                    instrumentSymbol = sym,
                    side = side,
                    orderType = OrderType.MARKET,
                    quantity = qty,
                    currency = if (sym.contains("USD")) "USD" else "GBP",
                    idempotencyKey = "IDEM-CMD-" + UUID.randomUUID()
                )
                val (order, _) = repository.submitOrder(req)
                _commandFeedback.value = "COMMAND EXECUTED: ${order.side} ${order.quantity} ${order.symbol} @ £${String.format("%.2f", order.avgFillPrice)} (Order: ${order.orderId})"
                _selectedTab.value = TerminalTab.TRADE
            }
            trimmed.contains("VAULT", ignoreCase = true) -> {
                _selectedTab.value = TerminalTab.VAULT
                _commandFeedback.value = "NAVIGATED TO: London Vault 04 Digital Twin"
            }
            trimmed.contains("RISK", ignoreCase = true) || trimmed.contains("MARGIN", ignoreCase = true) -> {
                _selectedTab.value = TerminalTab.PORTFOLIO
                _commandFeedback.value = "NAVIGATED TO: Portfolio Risk & Margins"
            }
            trimmed.contains("STRESS", ignoreCase = true) -> {
                val shock = repository.riskEngine.evaluateCustomStressTest(-15.0, -25.0, -35.0, -8.0, 60.0)
                _customStressResult.value = shock
                _selectedTab.value = TerminalTab.PORTFOLIO
                _commandFeedback.value = "STRESS SHOCK APPLIED: Simulated P&L Impact £${String.format("%,.0f", shock.simulatedPnlImpactGbp)}"
            }
            trimmed.contains("BTC", ignoreCase = true) || trimmed.contains("DIGITAL", ignoreCase = true) -> {
                _selectedTab.value = TerminalTab.DIGITAL
                _commandFeedback.value = "NAVIGATED TO: Digital Asset Metals Terminal"
            }
            trimmed.contains("RFQ", ignoreCase = true) -> {
                val rfq = repository.requestDealerRfq("XAU/GBP", OrderSide.BUY, 250.0, 30)
                _selectedTab.value = TerminalTab.DERIVATIVES
                _commandFeedback.value = "OTC RFQ CREATED: 250 XAU/GBP 30D @ £${String.format("%.2f", rfq.quotedForwardPrice)}"
            }
            trimmed.contains("RECONCILE", ignoreCase = true) -> {
                val rep = repository.vaultEngine.runPhysicalReconciliation()
                _selectedTab.value = TerminalTab.VAULT
                _commandFeedback.value = "5-POINT RECONCILIATION COMPLETED: STATUS PASS (2,920.0 oz verified)"
            }
            else -> {
                _commandFeedback.value = "RECOGNISED COMMAND. Type BUY 100 XAU/GBP, SHOW VAULT, STRESS GOLD -15%, or CREATE RFQ"
            }
        }
        _commandInput.value = ""
    }

    fun submitTradeOrder() {
        val qty = _tradeQuantity.value.toDoubleOrNull() ?: 100.0
        val price = _tradePrice.value.toDoubleOrNull()
        val sym = _selectedTradeSymbol.value

        val req = OrderRequest(
            clientOrderId = "UI-ORD-" + UUID.randomUUID().toString().take(6).uppercase(),
            instrumentSymbol = sym,
            side = _tradeSide.value,
            orderType = _tradeOrderType.value,
            quantity = qty,
            price = price,
            currency = _tradeCurrency.value,
            idempotencyKey = "IDEM-" + UUID.randomUUID().toString().take(12)
        )

        val (order, _) = repository.submitOrder(req)
        _tradeNotification.value = "Order ${order.orderId} executed! ${order.side} ${order.quantity} ${order.symbol} @ £${String.format("%.2f", order.avgFillPrice)}"
    }

    fun selectTradeSymbol(symbol: String) {
        _selectedTradeSymbol.value = symbol
        val q = repository.marketEngine.quotes.value[symbol]
        if (q != null) {
            _tradePrice.value = String.format("%.2f", q.mid)
        }
    }

    fun setTradeSide(side: OrderSide) {
        _tradeSide.value = side
    }

    fun setTradeOrderType(type: OrderType) {
        _tradeOrderType.value = type
    }

    fun updateTradeQuantity(qty: String) {
        _tradeQuantity.value = qty
    }

    fun updateTradePrice(price: String) {
        _tradePrice.value = price
    }

    fun executeBookEntryTransfer() {
        val barId = _selectedBarToTransfer.value
        val to = _transferToEntity.value
        val transfer = repository.vaultEngine.transferBookEntryOwnership(
            barId = barId,
            fromEntity = "City Bullion Partners",
            toEntity = to,
            settlementRef = "SETTLE-BET-" + UUID.randomUUID().toString().take(6)
        )
        if (transfer != null) {
            _commandFeedback.value = "TITLE TRANSFERRED: Bar $barId is now owned by $to in London Vault 04"
        }
    }

    fun runCustomStressSimulation() {
        val gShock = _stressGoldShock.value.toDoubleOrNull() ?: -15.0
        val sShock = _stressSilverShock.value.toDoubleOrNull() ?: -25.0
        val bShock = _stressBtcShock.value.toDoubleOrNull() ?: -35.0
        val fxShock = _stressGbpShock.value.toDoubleOrNull() ?: -8.0
        val vShock = _stressVolShock.value.toDoubleOrNull() ?: 60.0

        val res = repository.riskEngine.evaluateCustomStressTest(gShock, sShock, bShock, fxShock, vShock)
        _customStressResult.value = res
    }

    fun updateStressInput(field: String, value: String) {
        when (field) {
            "gold" -> _stressGoldShock.value = value
            "silver" -> _stressSilverShock.value = value
            "btc" -> _stressBtcShock.value = value
            "gbp" -> _stressGbpShock.value = value
            "vol" -> _stressVolShock.value = value
        }
    }

    fun selectApiEndpoint(ep: ApiEndpointDefinition) {
        _selectedApiEndpoint.value = ep
        _customApiRequest.value = ep.requestSampleJson ?: ""
    }

    fun updateCustomApiRequest(req: String) {
        _customApiRequest.value = req
    }

    fun executeApiCall() {
        val ep = _selectedApiEndpoint.value
        val log = repository.apiGateway.invokeEndpoint(
            endpoint = ep,
            customRequestBody = _customApiRequest.value.ifEmpty { null },
            idempotencyKey = _apiIdempotencyKey.value
        )
        _latestApiLog.value = log
        _apiIdempotencyKey.value = "IDEM-LMX-" + UUID.randomUUID().toString().take(8)
    }

    fun updateAiInput(text: String) {
        _aiInputText.value = text
    }

    fun sendAiPrompt(prompt: String) {
        val p = prompt.trim()
        if (p.isEmpty()) return

        val userMsg = AiMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = p,
            timestamp = System.currentTimeMillis()
        )

        val quotes = repository.marketEngine.quotes.value
        val xauGbp = quotes["XAU/GBP"]?.last ?: 3150.40
        val xauUsd = quotes["XAU/USD"]?.last ?: 4200.00
        val btcXau = quotes["BTC/XAU"]?.last ?: 15.42
        val risk = repository.riskEngine.portfolioRisk.value

        val responseText = when {
            p.contains("price", ignoreCase = true) || p.contains("XAU/GBP", ignoreCase = true) -> {
                "The current synthetic London benchmark price for XAU/GBP is £${String.format("%.2f", xauGbp)} (derived via XAU/USD $${String.format("%.2f", xauUsd)} ÷ GBP/USD 1.3340). Bid/Ask spread is £0.35/oz with settlement convention PHYSICAL_ALLOCATED_LONDON."
            }
            p.contains("forward curve", ignoreCase = true) || p.contains("curve", ignoreCase = true) -> {
                "Gold Forward Curve is currently in Contango: 1M (XAU-F1) is £3,162.80 (+£12.40 basis), 3M (XAU-F3) is £3,188.90 (+£38.50 basis), and 6M (XAU-F4) is £3,228.40 (+£78.00 basis). Implied annualised financing differential is 4.90% based on Sterling SONIA vs Gold lease rate (1.10%)."
            }
            p.contains("BTC/XAU", ignoreCase = true) || p.contains("falling", ignoreCase = true) || p.contains("bitcoin", ignoreCase = true) -> {
                "BTC/XAU is trading at ${String.format("%.3f", btcXau)} Fine Troy Ounces of gold per Bitcoin. The ratio reflects relative strength in physical bullion relative to digital crypto assets amid Risk-Off sentiment."
            }
            p.contains("exposure", ignoreCase = true) || p.contains("nav", ignoreCase = true) -> {
                "Your institutional Portfolio NAV is £24,819,440. Gold physical & spot allocation stands at £9,200,000 (37.1% of NAV), Silver at £3,800,000 (15.3%), and FX Cash & Collateral at £4,100,000. Margin utilisation is 63.4% (NORMAL tier)."
            }
            p.contains("stress", ignoreCase = true) -> {
                "Under a -15% Gold, -25% Silver, -35% BTC, +60% Volatility scenario shock, portfolio loss is estimated at -£3,680,000. Required initial margin increases from £9.8M to £12.74M, creating a potential collateral deficit of -£970,000 requiring pre-hedging."
            }
            p.contains("vault", ignoreCase = true) || p.contains("unsettled", ignoreCase = true) -> {
                "London Vault 04 holds 400,000 synthetic bars (284,500 allocated, 105,200 unallocated pool). All 2,920.0 oz of allocated gold for City Bullion Partners are reconciled to specific numbered bar serials (e.g., LDN-AU-00048271) with 0 reconciliation breaks."
            }
            else -> {
                "LMX Market Engine analysis: Active regime is ${repository.surveillanceEngine.currentRegime.value.label}. All quad-ledgers (GBP, USD, XAU, XAUT) are balanced. Cross-asset triangulation is verified within 1.2 bps tolerance."
            }
        }

        val aiMsg = AiMessage(
            id = UUID.randomUUID().toString(),
            isUser = false,
            text = responseText,
            timestamp = System.currentTimeMillis() + 100
        )

        _aiMessages.value = _aiMessages.value + listOf(userMsg, aiMsg)
        _aiInputText.value = ""
    }

    private fun createInitialAiMessages(): List<AiMessage> {
        val now = System.currentTimeMillis()
        return listOf(
            AiMessage(
                id = "AI-001",
                isUser = false,
                text = "LMX Market Copilot initialized. Connected to real-time synthetic London metals, derivatives, FX triangulation, and London Vault 04 digital twin. How may I assist your dealing desk?",
                timestamp = now - 60000
            )
        )
    }
}
