package com.example.data.model

import java.math.BigDecimal

enum class OrderSide {
    BUY, SELL
}

enum class OrderType(val displayName: String) {
    MARKET("Market"),
    LIMIT("Limit"),
    STOP("Stop Loss"),
    STOP_LIMIT("Stop Limit"),
    IOC("Immediate Or Cancel"),
    FOK("Fill Or Kill"),
    GTC("Good 'Til Cancelled"),
    DAY("Day Order"),
    RFQ("Request For Quote (Dealer)"),
    TWAP("Time-Weighted Avg Price"),
    VWAP("Volume-Weighted Avg Price"),
    ICEBERG("Synthetic Iceberg")
}

enum class OrderStatus(val label: String) {
    NEW("New (Unvalidated)"),
    VALIDATED("Pre-Trade Validated"),
    ROUTED("Routed to Venue"),
    PARTIALLY_FILLED("Partially Filled"),
    FILLED("Executed & Filled"),
    REJECTED("Risk / Venue Rejected"),
    CANCELLED("Cancelled by Desk"),
    SETTLED("Settled in Vault / Ledger")
}

data class OrderRequest(
    val clientOrderId: String,
    val clientId: String = "CP-8842-CITY-BULLION",
    val accountId: String = "ACC-LDN-01994",
    val instrumentSymbol: String,
    val side: OrderSide,
    val orderType: OrderType,
    val quantity: Double,
    val price: Double? = null,
    val stopPrice: Double? = null,
    val currency: String = "GBP",
    val venuePreference: MarketVenue = MarketVenue.LONDON_SPOT_OTC,
    val maxSlippageBps: Double = 15.0,
    val idempotencyKey: String,
    val icebergVisibleQty: Double? = null
)

data class RoutingDecision(
    val recommendedVenue: MarketVenue,
    val venueMixExplanation: String,
    val estimatedSlippageBps: Double,
    val liquidityScore: Double,
    val feeRateBps: Double,
    val latencyMs: Int
)

data class OrderRecord(
    val orderId: String,
    val clientOrderId: String,
    val clientId: String,
    val accountId: String,
    val symbol: String,
    val side: OrderSide,
    val orderType: OrderType,
    val quantity: Double,
    val filledQuantity: Double,
    val price: Double,
    val avgFillPrice: Double,
    val currency: String,
    val venue: MarketVenue,
    val status: OrderStatus,
    val timestamp: Long,
    val lastUpdate: Long,
    val fees: Double,
    val slippageBps: Double,
    val routing: RoutingDecision,
    val idempotencyKey: String,
    val eventTrail: List<String> = emptyList()
)

data class ExecutionReport(
    val executionId: String,
    val orderId: String,
    val symbol: String,
    val side: OrderSide,
    val executedQty: Double,
    val executedPrice: Double,
    val notional: Double,
    val currency: String,
    val venue: MarketVenue,
    val timestamp: Long,
    val counterparty: String = "City Bullion Partners / Thames Metals LP",
    val settlementStatus: String = "PENDING_ALLOCATION"
)
