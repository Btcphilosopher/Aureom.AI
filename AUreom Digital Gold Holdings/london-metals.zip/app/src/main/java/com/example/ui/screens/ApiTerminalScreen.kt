package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun ApiTerminalScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val endpoints = viewModel.repository.apiGateway.availableEndpoints
    val selectedEndpoint by viewModel.selectedApiEndpoint.collectAsState()
    val customRequest by viewModel.customApiRequest.collectAsState()
    val idempotencyKey by viewModel.apiIdempotencyKey.collectAsState()
    val latestLog by viewModel.latestApiLog.collectAsState()
    val wsEvents by viewModel.repository.apiGateway.webSocketEvents.collectAsState()
    val fixMessages by viewModel.repository.apiGateway.fixMessages.collectAsState()

    var activeApiTab by remember { mutableStateOf(0) } // 0: REST API Console, 1: WebSocket Stream, 2: FIX Gateway

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // API Sub Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("REST API Console", "WebSocket Feed", "FIX 4.4 Adapter").forEachIndexed { idx, title ->
                    val isSel = activeApiTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) BullionGold else Color.Transparent, RoundedCornerShape(4.dp))
                            .clickable { activeApiTab = idx }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            title,
                            fontFamily = TerminalMonospace,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp,
                            color = if (isSel) Color(0xFF0F141C) else TextSecondary
                        )
                    }
                }
            }
        }

        when (activeApiTab) {
            0 -> {
                // Interactive REST API Console
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "THE API IS THE PRODUCT // INTERACTIVE CONSOLE",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = BullionGold
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Execute live API calls against local deterministic market engine. Full Idempotency-Key support.",
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 9.5.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                // Endpoint Selector Buttons
                item {
                    Text("SELECT ENDPOINT:", fontFamily = TerminalMonospace, fontSize = 10.sp, color = TextMuted)
                }

                items(endpoints) { ep ->
                    val isSelected = selectedEndpoint.path == ep.path
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF1D2838) else TerminalSurface),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectApiEndpoint(ep) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(if (ep.method == "GET") SteelBlue else BritishRacingGreenBright, RoundedCornerShape(2.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(ep.method, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color(0xFF0F141C))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(ep.path, fontFamily = TerminalMonospace, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = TextPrimary)
                            }
                            Text(ep.title, fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }

                // Selected Endpoint Invocation Sandbox
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "${selectedEndpoint.method} ${selectedEndpoint.path}",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = BullionGold
                            )
                            Text(
                                text = selectedEndpoint.description,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 10.sp,
                                color = TextSecondary
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("Idempotency-Key Header: $idempotencyKey", fontFamily = TerminalMonospace, fontSize = 9.sp, color = SteelBlue)

                            if (selectedEndpoint.method == "POST") {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = customRequest,
                                    onValueChange = { viewModel.updateCustomApiRequest(it) },
                                    label = { Text("Request Body (JSON)", fontFamily = TerminalMonospace, fontSize = 9.sp) },
                                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 10.sp, color = TextPrimary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp)
                                        .testTag("api_request_json_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = { viewModel.executeApiCall() },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(36.dp)
                                    .testTag("execute_api_btn")
                            ) {
                                Text("SEND API REQUEST // EXECUTE", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF041E0F))
                            }
                        }
                    }
                }

                // Response Inspector
                latestLog?.let { log ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D141E)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("HTTP ${log.statusCode} OK (Latency: ${log.latencyMs}ms)", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BritishRacingGreenBright)
                                    Text(log.invocationId, fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Response JSON Payload:", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextMuted)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(TerminalBackground, RoundedCornerShape(4.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = log.responseBody,
                                        fontFamily = TerminalMonospace,
                                        fontSize = 10.sp,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Live WebSocket Events
                item {
                    Text("WEBSOCKET LIVE STREAM // /ws/market, /ws/executions, /ws/vault", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BullionGold)
                }

                items(wsEvents) { ev ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(ev.eventType, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = BritishRacingGreenBright)
                                Text("Channel: ${ev.channel}", fontFamily = TerminalMonospace, fontSize = 9.sp, color = SteelBlue)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(ev.payloadJson, fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = TextSecondary)
                        }
                    }
                }
            }
            2 -> {
                // FIX 4.4 Gateway
                item {
                    Text("FIX 4.4 / 5.0 FINANCIAL PROTOCOL ADAPTER STREAM", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BullionGold)
                }

                items(fixMessages) { fix ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("MsgType: ${fix.msgType}", fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = BullionGoldMuted)
                                Text("Seq: ${fix.seqNum}", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(fix.parsedDescription, fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = TextPrimary)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Raw Tag String: ${fix.rawFixString.take(80)}...", fontFamily = TerminalMonospace, fontSize = 8.5.sp, color = TextMuted)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
