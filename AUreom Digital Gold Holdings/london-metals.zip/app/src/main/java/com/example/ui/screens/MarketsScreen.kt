package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssetCategory
import com.example.data.model.QuoteData
import com.example.ui.components.LondonMarketClockView
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun MarketsScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val quotes by viewModel.repository.marketEngine.quotes.collectAsState()
    val clocks = remember { viewModel.repository.marketEngine.getLondonMarketClocks() }
    var selectedCategory by remember { mutableStateOf(AssetCategory.SPOT_METALS) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Market Session Clocks
        item {
            LondonMarketClockView(clocks = clocks)
        }

        // Dedicated Gold FX Matrix Card
        item {
            GoldFxMatrixCard(quotes = quotes, onSelectSymbol = { sym ->
                viewModel.selectTradeSymbol(sym)
                viewModel.selectTab(TerminalTab.TRADE)
            })
        }

        // Category Filter Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    AssetCategory.SPOT_METALS to "Spot Metals",
                    AssetCategory.INDUSTRIAL_LME to "LME Industrial",
                    AssetCategory.FX_CROSS to "FX Crosses",
                    AssetCategory.DIGITAL_ASSET to "Digital Metals"
                ).forEach { (cat, label) ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isSelected) BullionGold else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { selectedCategory = cat }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontFamily = TerminalMonospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp,
                            color = if (isSelected) Color(0xFF0F141C) else TextSecondary
                        )
                    }
                }
            }
        }

        // Filtered Instruments List
        val filteredInstruments = viewModel.repository.marketEngine.instrumentsList.filter { it.category == selectedCategory }
        items(filteredInstruments) { inst ->
            val quote = quotes[inst.symbol]
            InstrumentQuoteCard(
                instrument = inst,
                quote = quote,
                onTradeClick = {
                    viewModel.selectTradeSymbol(inst.symbol)
                    viewModel.selectTab(TerminalTab.TRADE)
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun GoldFxMatrixCard(
    quotes: Map<String, QuoteData>,
    onSelectSymbol: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GOLD FX MATRIX // MULTI-CURRENCY BENCHMARKS",
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BullionGold
                )
                Text(
                    text = "CANONICAL DIRECTION",
                    fontFamily = TerminalMonospace,
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            val goldPairs = listOf(
                Triple("XAU/USD", "$", quotes["XAU/USD"]?.last ?: 4200.0),
                Triple("XAU/GBP", "£", quotes["XAU/GBP"]?.last ?: 3150.40),
                Triple("GBP/XAU", " oz", quotes["GBP/XAU"]?.last ?: 0.000317),
                Triple("XAU/EUR", "€", quotes["XAU/EUR"]?.last ?: 3845.0),
                Triple("XAU/JPY", "¥", quotes["XAU/JPY"]?.last ?: 623000.0),
                Triple("XAU/CHF", "CHF ", quotes["XAU/CHF"]?.last ?: 3630.0)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                goldPairs.take(3).forEach { (sym, prefix, price) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(TerminalSurface, RoundedCornerShape(4.dp))
                            .clickable { onSelectSymbol(sym) }
                            .padding(6.dp)
                    ) {
                        Column {
                            Text(sym, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = BullionGoldMuted)
                            Text(
                                if (sym == "GBP/XAU") String.format("%.6f", price) + prefix else prefix + String.format(if (price > 10000) "%,.0f" else "%,.2f", price),
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                goldPairs.drop(3).forEach { (sym, prefix, price) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(TerminalSurface, RoundedCornerShape(4.dp))
                            .clickable { onSelectSymbol(sym) }
                            .padding(6.dp)
                    ) {
                        Column {
                            Text(sym, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = BullionGoldMuted)
                            Text(
                                prefix + String.format(if (price > 10000) "%,.0f" else "%,.2f", price),
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstrumentQuoteCard(
    instrument: com.example.data.model.InstrumentDefinition,
    quote: QuoteData?,
    onTradeClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("instrument_card_${instrument.symbol.replace("/", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = instrument.symbol,
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(TerminalSurfaceVariant, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = instrument.venue.code,
                            fontFamily = TerminalMonospace,
                            fontSize = 8.sp,
                            color = BullionGoldMuted
                        )
                    }
                }
                Text(
                    text = instrument.name,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                if (instrument.triangulatedFormula != null) {
                    Text(
                        text = "Formula: ${instrument.triangulatedFormula}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.sp,
                        color = SteelBlue
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                Text(
                    text = quote?.formattedLast(if (instrument.symbol == "GBP/XAU" || instrument.symbol == "USDT/XAUT") 6 else if (instrument.symbol.contains("USD") && !instrument.symbol.contains("BTC") && !instrument.symbol.contains("XAU") && !instrument.symbol.contains("XCU")) 4 else 2) ?: "--",
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                val isPos = (quote?.change ?: 0.0) >= 0
                Text(
                    text = (if (isPos) "+" else "") + String.format("%.2f", quote?.changePercent ?: 0.0) + "%",
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp,
                    color = if (isPos) MarketBidGreen else MarketAskRed
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onTradeClick,
                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("TRADE", fontFamily = TerminalMonospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
