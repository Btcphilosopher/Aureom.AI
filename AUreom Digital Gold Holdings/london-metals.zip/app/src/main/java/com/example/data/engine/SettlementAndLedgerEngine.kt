package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class SettlementPipelineStage(
    val stageName: String,
    val description: String,
    val isComplete: Boolean,
    val timestamp: Long,
    val referenceId: String
)

data class SettlementCase(
    val settlementId: String,
    val tradeId: String,
    val symbol: String,
    val side: OrderSide,
    val quantity: Double,
    val price: Double,
    val totalNotionalGbp: Double,
    val buyerAccount: String,
    val sellerAccount: String,
    val status: String, // "CONFIRMED", "CLEARED", "FUNDED", "ALLOCATED", "SETTLED_AND_RECONCILED", "FAILED_RETRYING"
    val timestamp: Long,
    val stages: List<SettlementPipelineStage>,
    val retryCount: Int = 0
)

class SettlementAndLedgerEngine {

    private var sequenceCounter = 1000L

    private val _accountBalance = MutableStateFlow(
        InstitutionalAccountBalance(
            accountId = "ACC-LDN-01994",
            accountName = "City Bullion Partners (Prime Commodities Account)",
            cashGbp = BigDecimal("14250800.00"),
            cashUsd = BigDecimal("8450000.00"),
            cashEur = BigDecimal("3920000.00"),
            cashUsdt = BigDecimal("2450000.00"),
            metalXauOz = BigDecimal("2920.0000"),
            metalXagOz = BigDecimal("95400.0000"),
            metalXptOz = BigDecimal("840.0000"),
            digitalXaut = BigDecimal("890.0000"),
            allocatedBarIds = listOf("LDN-AU-00048271", "LDN-AU-00048272", "LDN-AG-00091840")
        )
    )
    val accountBalance: StateFlow<InstitutionalAccountBalance> = _accountBalance.asStateFlow()

    private val _ledgerHistory = MutableStateFlow<List<LedgerEntry>>(createInitialLedgerEntries())
    val ledgerHistory: StateFlow<List<LedgerEntry>> = _ledgerHistory.asStateFlow()

    private val _activeSettlements = MutableStateFlow<List<SettlementCase>>(createInitialSettlements())
    val activeSettlements: StateFlow<List<SettlementCase>> = _activeSettlements.asStateFlow()

    fun processSettlementForTrade(
        tradeId: String,
        symbol: String,
        side: OrderSide,
        quantity: Double,
        price: Double,
        currency: String = "GBP"
    ): SettlementCase {
        val settlementId = "SETTLE-LDN-" + UUID.randomUUID().toString().take(6).uppercase()
        val notional = quantity * price
        val notionalBd = BigDecimal(notional.toString()).setScale(2, RoundingMode.HALF_UP)
        val qtyBd = BigDecimal(quantity.toString()).setScale(4, RoundingMode.HALF_UP)
        val now = System.currentTimeMillis()

        val currentBal = _accountBalance.value
        val entries = _ledgerHistory.value.toMutableList()

        if (side == OrderSide.BUY) {
            // Cash Debit, Metal Credit
            val newCashGbp = currentBal.cashGbp.subtract(notionalBd)
            val newGoldOz = currentBal.metalXauOz.add(qtyBd)

            _accountBalance.value = currentBal.copy(
                cashGbp = newCashGbp,
                metalXauOz = newGoldOz
            )

            // Immutable double-entry ledger entries
            sequenceCounter++
            val cashEntry = LedgerEntry(
                entryId = "LEDG-CASH-" + sequenceCounter,
                sequenceNumber = sequenceCounter,
                timestamp = now,
                category = LedgerCategory.CASH_GBP,
                debitAccount = "ACC-LDN-01994 (City Bullion Partners)",
                creditAccount = "LMX Central Clearing Liquidity Pool",
                amount = notionalBd,
                unit = "GBP",
                referenceTransactionId = tradeId,
                eventType = "TRADE_SETTLEMENT_PAYMENT",
                hashSignature = "0x" + UUID.randomUUID().toString().replace("-", "").take(16)
            )

            sequenceCounter++
            val metalEntry = LedgerEntry(
                entryId = "LEDG-METAL-" + sequenceCounter,
                sequenceNumber = sequenceCounter,
                timestamp = now,
                category = LedgerCategory.METAL_XAU,
                debitAccount = "LMX Depository Vault Pool",
                creditAccount = "ACC-LDN-01994 (City Bullion Partners)",
                amount = qtyBd,
                unit = "XAU Fine Oz",
                referenceTransactionId = tradeId,
                eventType = "PHYSICAL_ALLOCATION_CREDIT",
                hashSignature = "0x" + UUID.randomUUID().toString().replace("-", "").take(16)
            )

            entries.add(0, cashEntry)
            entries.add(0, metalEntry)
        } else {
            // Sell: Cash Credit, Metal Debit
            val newCashGbp = currentBal.cashGbp.add(notionalBd)
            val newGoldOz = currentBal.metalXauOz.subtract(qtyBd)

            _accountBalance.value = currentBal.copy(
                cashGbp = newCashGbp,
                metalXauOz = newGoldOz
            )

            sequenceCounter++
            val cashEntry = LedgerEntry(
                entryId = "LEDG-CASH-" + sequenceCounter,
                sequenceNumber = sequenceCounter,
                timestamp = now,
                category = LedgerCategory.CASH_GBP,
                debitAccount = "LMX Central Clearing Liquidity Pool",
                creditAccount = "ACC-LDN-01994 (City Bullion Partners)",
                amount = notionalBd,
                unit = "GBP",
                referenceTransactionId = tradeId,
                eventType = "TRADE_PROCEEDS_CREDIT",
                hashSignature = "0x" + UUID.randomUUID().toString().replace("-", "").take(16)
            )

            sequenceCounter++
            val metalEntry = LedgerEntry(
                entryId = "LEDG-METAL-" + sequenceCounter,
                sequenceNumber = sequenceCounter,
                timestamp = now,
                category = LedgerCategory.METAL_XAU,
                debitAccount = "ACC-LDN-01994 (City Bullion Partners)",
                creditAccount = "LMX Depository Vault Pool",
                amount = qtyBd,
                unit = "XAU Fine Oz",
                referenceTransactionId = tradeId,
                eventType = "PHYSICAL_METAL_DELIVERY",
                hashSignature = "0x" + UUID.randomUUID().toString().replace("-", "").take(16)
            )

            entries.add(0, cashEntry)
            entries.add(0, metalEntry)
        }

        _ledgerHistory.value = entries

        val stages = listOf(
            SettlementPipelineStage("1. TRADE", "Bilateral / Screen Execution Captured", true, now - 1500, tradeId),
            SettlementPipelineStage("2. CONFIRM", "Electronic Affirmation & FIX Confirm Sent", true, now - 1200, "CONF-" + tradeId),
            SettlementPipelineStage("3. CLEAR", "CCP / Bilateral Novation & Risk Check", true, now - 900, "CLR-LDN"),
            SettlementPipelineStage("4. FUND", "RTGS / Cash Ledger Movement Verified", true, now - 600, "FUND-GBP"),
            SettlementPipelineStage("5. ALLOCATE", "Vault Bar Assigned (Bank of England Vault 04)", true, now - 300, "LDN-AU-00048271"),
            SettlementPipelineStage("6. SETTLE", "Title Transferred via Book Entry (Immutable)", true, now, settlementId),
            SettlementPipelineStage("7. RECONCILE", "Quad-Ledger Balanced (0.00 Discrepancy)", true, now, "REC-PASS")
        )

        val settlementCase = SettlementCase(
            settlementId = settlementId,
            tradeId = tradeId,
            symbol = symbol,
            side = side,
            quantity = quantity,
            price = price,
            totalNotionalGbp = notional,
            buyerAccount = if (side == OrderSide.BUY) "ACC-LDN-01994 (City Bullion Partners)" else "Thames Metals Ltd",
            sellerAccount = if (side == OrderSide.BUY) "Thames Metals Ltd" else "ACC-LDN-01994 (City Bullion Partners)",
            status = "SETTLED_AND_RECONCILED",
            timestamp = now,
            stages = stages
        )

        _activeSettlements.value = listOf(settlementCase) + _activeSettlements.value.take(15)
        return settlementCase
    }

    private fun createInitialSettlements(): List<SettlementCase> {
        val now = System.currentTimeMillis()
        val stages = listOf(
            SettlementPipelineStage("1. TRADE", "Bilateral OTC London RFQ Executed", true, now - 3600000, "TRD-8821"),
            SettlementPipelineStage("2. CONFIRM", "Electronic Affirmation Received", true, now - 3500000, "CONF-8821"),
            SettlementPipelineStage("3. CLEAR", "Clearing Validation Completed", true, now - 3400000, "CLR-019"),
            SettlementPipelineStage("4. FUND", "GBP Cash Wire Transferred", true, now - 3300000, "FUND-019"),
            SettlementPipelineStage("5. ALLOCATE", "Specific Bar Assigned (LDN-AU-00048271)", true, now - 3200000, "LDN-AU-00048271"),
            SettlementPipelineStage("6. SETTLE", "Book-Entry Title Transferred", true, now - 3100000, "SETTLE-LDN-8841"),
            SettlementPipelineStage("7. RECONCILE", "5-Point Reconciliation PASS", true, now - 3000000, "REC-PASS")
        )

        return listOf(
            SettlementCase(
                settlementId = "SETTLE-LDN-8841",
                tradeId = "TRD-8821",
                symbol = "XAU/GBP",
                side = OrderSide.BUY,
                quantity = 250.0,
                price = 3150.40,
                totalNotionalGbp = 787600.0,
                buyerAccount = "ACC-LDN-01994 (City Bullion Partners)",
                sellerAccount = "Westminster Bullion Markets",
                status = "SETTLED_AND_RECONCILED",
                timestamp = now - 3100000,
                stages = stages
            )
        )
    }

    private fun createInitialLedgerEntries(): List<LedgerEntry> {
        val now = System.currentTimeMillis()
        return listOf(
            LedgerEntry(
                entryId = "LEDG-INIT-001",
                sequenceNumber = 1001,
                timestamp = now - 3600000,
                category = LedgerCategory.CASH_GBP,
                debitAccount = "ACC-LDN-01994 (City Bullion Partners)",
                creditAccount = "Westminster Bullion Markets",
                amount = BigDecimal("787600.00"),
                unit = "GBP",
                referenceTransactionId = "TRD-8821",
                eventType = "TRADE_SETTLEMENT_PAYMENT",
                hashSignature = "0x8fa400192bc7e41b"
            ),
            LedgerEntry(
                entryId = "LEDG-INIT-002",
                sequenceNumber = 1002,
                timestamp = now - 3600000,
                category = LedgerCategory.METAL_XAU,
                debitAccount = "Westminster Bullion Markets (London Vault 04)",
                creditAccount = "ACC-LDN-01994 (City Bullion Partners)",
                amount = BigDecimal("250.0000"),
                unit = "XAU Fine Oz",
                referenceTransactionId = "TRD-8821",
                eventType = "PHYSICAL_ALLOCATION_CREDIT",
                hashSignature = "0x39a11ef091a6c429"
            ),
            LedgerEntry(
                entryId = "LEDG-INIT-003",
                sequenceNumber = 1003,
                timestamp = now - 7200000,
                category = LedgerCategory.DIGITAL_XAUT,
                debitAccount = "Digital Metals Depository",
                creditAccount = "ACC-LDN-01994 (City Bullion Partners)",
                amount = BigDecimal("150.0000"),
                unit = "XAUT",
                referenceTransactionId = "TRD-7704",
                eventType = "TOKEN_ISSUANCE_CREDIT",
                hashSignature = "0x55b18ca039df8812"
            )
        )
    }
}
