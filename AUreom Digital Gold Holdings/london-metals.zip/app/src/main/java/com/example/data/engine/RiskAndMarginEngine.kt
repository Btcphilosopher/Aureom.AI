package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RiskAndMarginEngine {

    private val _portfolioRisk = MutableStateFlow(createInitialPortfolioRisk())
    val portfolioRisk: StateFlow<PortfolioRiskSummary> = _portfolioRisk.asStateFlow()

    fun recalculateRisk(
        goldPriceGbp: Double,
        silverPriceGbp: Double,
        btcPriceGbp: Double,
        activeOrdersNotional: Double = 0.0
    ): PortfolioRiskSummary {
        val baseGoldOz = 2920.0
        val baseSilverOz = 95400.0
        val baseBtc = 48.0
        val baseUsdt = 2450000.0

        val goldGross = baseGoldOz * goldPriceGbp
        val silverGross = baseSilverOz * silverPriceGbp
        val btcGross = baseBtc * btcPriceGbp
        val usdtGross = baseUsdt * 0.75 // ~£1.84m in GBP

        // Haircuts: Gold 8%, Silver 15%, BTC 35%, USDT 5%
        val goldCollateral = goldGross * (1.0 - 0.08)
        val silverCollateral = silverGross * (1.0 - 0.15)
        val btcCollateral = btcGross * (1.0 - 0.35)
        val usdtCollateral = usdtGross * (1.0 - 0.05)
        val cashGbp = 14250800.0 // 0% haircut on home currency

        val totalCollateralPostHaircut = cashGbp + goldCollateral + silverCollateral + btcCollateral + usdtCollateral

        val initialMarginReq = 9800000.0 + (activeOrdersNotional * 0.10)
        val maintMarginReq = initialMarginReq * 0.75
        val varMargin = 420000.0

        val marginUtilisationPct = (initialMarginReq / totalCollateralPostHaircut) * 100.0
        val tier = when {
            marginUtilisationPct >= 95.0 -> MarginTier.BREACH
            marginUtilisationPct >= 85.0 -> MarginTier.WARNING
            marginUtilisationPct >= 70.0 -> MarginTier.WATCH
            else -> MarginTier.NORMAL
        }

        val marginProfile = MarginProfile(
            initialMarginRequiredGbp = initialMarginReq,
            variationMarginGbp = varMargin,
            maintenanceMarginGbp = maintMarginReq,
            totalCollateralPostHaircutGbp = totalCollateralPostHaircut,
            freeMarginGbp = totalCollateralPostHaircut - initialMarginReq,
            marginUtilisationPct = marginUtilisationPct,
            tier = tier,
            liquidationThresholdGbp = maintMarginReq * 1.10
        )

        val totalNav = cashGbp + goldGross + silverGross + btcGross + usdtGross + 3200000.0 + 1700000.0
        val dailyVaR99 = totalNav * 0.034
        val cVaR99 = dailyVaR99 * 1.52

        val pnl = PnLDecomposition(
            spotPnlGbp = 482900.0,
            futuresPnlGbp = 124500.0,
            optionsPnlGbp = -38400.0,
            fxPnlGbp = 89200.0,
            physicalPnlGbp = 310000.0,
            digitalPnlGbp = 194000.0,
            hedgingPnlGbp = -82000.0,
            financingCostGbp = -24500.0,
            feesPaidGbp = -14200.0,
            vaultingCostGbp = -8900.0,
            totalRealizedPnlGbp = 345000.0,
            totalUnrealizedPnlGbp = 687600.0,
            netTotalPnlGbp = 1032600.0
        )

        val updated = _portfolioRisk.value.copy(
            totalNavGbp = totalNav,
            goldAssetGbp = goldGross,
            silverAssetGbp = silverGross,
            dailyVaR99Gbp = dailyVaR99,
            cVaR99Gbp = cVaR99,
            marginProfile = marginProfile,
            pnlDecomposition = pnl
        )

        _portfolioRisk.value = updated
        return updated
    }

    fun evaluateCustomStressTest(
        goldShockPct: Double,
        silverShockPct: Double,
        btcShockPct: Double,
        gbpUsdShockPct: Double,
        volShockPct: Double
    ): StressShockScenario {
        val current = _portfolioRisk.value
        val goldLoss = current.goldAssetGbp * (goldShockPct / 100.0)
        val silverLoss = current.silverAssetGbp * (silverShockPct / 100.0)
        val btcLoss = current.digitalAssetGbp * (btcShockPct / 100.0)
        val fxLoss = current.fxAssetGbp * (gbpUsdShockPct / 100.0)
        val volImpact = current.optionsAssetGbp * (volShockPct / 100.0) * 0.4

        val totalLoss = goldLoss + silverLoss + btcLoss + fxLoss + volImpact
        val simulatedMarginReq = current.marginProfile.initialMarginRequiredGbp * (1.0 + (volShockPct / 200.0))
        val newCollateral = current.marginProfile.totalCollateralPostHaircutGbp + totalLoss
        val deficit = newCollateral - simulatedMarginReq

        return StressShockScenario(
            scenarioId = "STRESS-CUSTOM-" + System.currentTimeMillis().toString().takeLast(4),
            name = "Interactive Scenario Shock",
            description = "Custom macro shock evaluation across Bullion, Crypto & FX",
            goldShockPct = goldShockPct,
            silverShockPct = silverShockPct,
            btcShockPct = btcShockPct,
            gbpUsdShockPct = gbpUsdShockPct,
            volShockPct = volShockPct,
            simulatedPnlImpactGbp = totalLoss,
            simulatedMarginRequirementGbp = simulatedMarginReq,
            marginDeficitSurplusGbp = deficit,
            riskContributionGoldPct = if (totalLoss != 0.0) (goldLoss / totalLoss) * 100 else 0.0,
            riskContributionBtcPct = if (totalLoss != 0.0) (btcLoss / totalLoss) * 100 else 0.0,
            riskContributionFxPct = if (totalLoss != 0.0) (fxLoss / totalLoss) * 100 else 0.0
        )
    }

    private fun createInitialPortfolioRisk(): PortfolioRiskSummary {
        val marginProfile = MarginProfile(
            initialMarginRequiredGbp = 9800000.0,
            variationMarginGbp = 420000.0,
            maintenanceMarginGbp = 7350000.0,
            totalCollateralPostHaircutGbp = 15450000.0,
            freeMarginGbp = 5650000.0,
            marginUtilisationPct = 63.4,
            tier = MarginTier.NORMAL,
            liquidationThresholdGbp = 8085000.0
        )

        val pnl = PnLDecomposition(
            spotPnlGbp = 482900.0,
            futuresPnlGbp = 124500.0,
            optionsPnlGbp = -38400.0,
            fxPnlGbp = 89200.0,
            physicalPnlGbp = 310000.0,
            digitalPnlGbp = 194000.0,
            hedgingPnlGbp = -82000.0,
            financingCostGbp = -24500.0,
            feesPaidGbp = -14200.0,
            vaultingCostGbp = -8900.0,
            totalRealizedPnlGbp = 345000.0,
            totalUnrealizedPnlGbp = 687600.0,
            netTotalPnlGbp = 1032600.0
        )

        val scenarios = listOf(
            StressShockScenario(
                scenarioId = "SCEN-01",
                name = "Severe Cross-Asset Liquidity Shock",
                description = "Gold -15%, Silver -25%, BTC -35%, GBP/USD -8%, Vol +60%",
                goldShockPct = -15.0,
                silverShockPct = -25.0,
                btcShockPct = -35.0,
                gbpUsdShockPct = -8.0,
                volShockPct = 60.0,
                simulatedPnlImpactGbp = -3680000.0,
                simulatedMarginRequirementGbp = 12740000.0,
                marginDeficitSurplusGbp = -970000.0,
                riskContributionGoldPct = 37.5,
                riskContributionBtcPct = 26.8,
                riskContributionFxPct = 8.9
            ),
            StressShockScenario(
                scenarioId = "SCEN-02",
                name = "UK Sterling Crisis & Sovereign Volatility",
                description = "GBP/USD -12%, UK Rates +200bps, Gold/GBP +18%",
                goldShockPct = 18.0,
                silverShockPct = 10.0,
                btcShockPct = 5.0,
                gbpUsdShockPct = -12.0,
                volShockPct = 40.0,
                simulatedPnlImpactGbp = 1450000.0,
                simulatedMarginRequirementGbp = 10800000.0,
                marginDeficitSurplusGbp = 6100000.0,
                riskContributionGoldPct = 65.0,
                riskContributionBtcPct = 10.0,
                riskContributionFxPct = -25.0
            )
        )

        return PortfolioRiskSummary(
            totalNavGbp = 24819440.0,
            goldAssetGbp = 9200000.0,
            silverAssetGbp = 3800000.0,
            fxAssetGbp = 4100000.0,
            futuresAssetGbp = 3200000.0,
            optionsAssetGbp = 1700000.0,
            digitalAssetGbp = 2819440.0,
            dailyVaR99Gbp = 842000.0,
            cVaR99Gbp = 1290000.0,
            sharpeRatio = 2.14,
            marginProfile = marginProfile,
            pnlDecomposition = pnl,
            activeScenarios = scenarios
        )
    }
}
