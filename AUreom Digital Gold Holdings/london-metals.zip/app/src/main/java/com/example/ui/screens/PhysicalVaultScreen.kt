package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AllocationStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun PhysicalVaultScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val vaultTwin by viewModel.repository.vaultEngine.vaultTwin.collectAsState()
    val reconciliation by viewModel.repository.vaultEngine.reconciliationReport.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Vault Digital Twin Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LONDON VAULT 04 DIGITAL TWIN",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = BullionGold
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF132A1C), RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "DEPOSITORY MONITORED",
                                fontFamily = TerminalMonospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRacingGreenBright
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        VaultStatBox("TOTAL INVENTORY", "${String.format("%,d", vaultTwin.totalBars)} Bars", BullionGoldMuted, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        VaultStatBox("ALLOCATED TITLE", "${String.format("%,d", vaultTwin.allocatedBarsCount)} Bars", BritishRacingGreenBright, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        VaultStatBox("UNALLOCATED POOL", "${String.format("%,d", vaultTwin.unallocatedBarsCount)} Bars", SteelBlue, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Total Vault Valuation: ~£${String.format("%,.0f", vaultTwin.totalValuationGbp)} (160 Million Fine Troy Ounces)",
                        fontFamily = TerminalMonospace,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // 5-Point Physical Reconciliation Status Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = if (reconciliation.statusPass) Color(0xFF0F2617) else Color(0xFF381414)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (reconciliation.statusPass) BritishRacingGreenBright else MarketAskRed, androidx.compose.foundation.shape.CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "5-POINT PHYSICAL-METAL RECONCILIATION: " + if (reconciliation.statusPass) "PASS" else "BREAK",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (reconciliation.statusPass) BritishRacingGreenBright else MarketAskRed
                            )
                        }
                        Button(
                            onClick = { viewModel.repository.vaultEngine.runPhysicalReconciliation() },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("RUN AUDIT", fontFamily = TerminalMonospace, fontSize = 8.5.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Client Metal Balance (2,920.0 oz) == Bar Inventory (2,920.0 oz) == Vault Chamber 03 == Ownership Record == Quad-Ledger",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Book-Entry Transfer Execution Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "EXECUTE BOOK-ENTRY OWNERSHIP TRANSFER",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BullionGold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Transfer legal title of allocated bar without physically moving it from London Vault 04 (Bank of England / LBMA Convention).",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.executeBookEntryTransfer()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("TRANSFER BAR LDN-AU-00048271 TO THAMES METALS LTD", fontFamily = TerminalMonospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // Allocated Specific Bars Inventory Table
        item {
            Text(
                text = "ALLOCATED SPECIFIC BARS (BANK OF ENGLAND VAULT 04)",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(vaultTwin.sampleAllocatedBars) { bar ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${bar.barId} // ${bar.serialNumber}",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    if (bar.allocationStatus == AllocationStatus.ALLOCATED) Color(0xFF132A1C) else TerminalBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = bar.allocationStatus.name,
                                fontFamily = TerminalMonospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (bar.allocationStatus == AllocationStatus.ALLOCATED) BritishRacingGreenBright else TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Refiner: ${bar.refiner} | Fineness: ${bar.fineness} | Gross: ${bar.grossWeightKg} kg",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "Fine Weight: ${bar.fineWeightOz.toInt()} oz | Certificate: ${bar.certificateNumber}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.5.sp,
                        color = BullionGoldMuted
                    )
                    Text(
                        text = "Location: ${bar.chamber} [${bar.pallet}] | Legal Owner: ${bar.currentOwner}",
                        fontFamily = TerminalMonospace,
                        fontSize = 9.5.sp,
                        color = SteelBlue
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun VaultStatBox(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, fontFamily = TerminalMonospace, fontSize = 8.sp, color = TextMuted)
            Text(value, fontFamily = TerminalMonospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = color)
        }
    }
}
