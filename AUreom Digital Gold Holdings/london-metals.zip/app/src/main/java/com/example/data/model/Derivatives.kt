package com.example.data.model

enum class PromptDate(val code: String, val displayName: String, val daysToPrompt: Int) {
    CASH("CASH", "Cash (Today)", 0),
    TOM("TOM", "Tomorrow (T+1)", 1),
    SPOT("SPOT", "Spot (T+2)", 2),
    PROMPT_1M("1M", "1 Month Prompt", 30),
    PROMPT_2M("2M", "2 Month Prompt", 60),
    PROMPT_3M("3M", "3 Month Benchmark (3M LME Standard)", 90),
    PROMPT_6M("6M", "6 Month Prompt", 180),
    PROMPT_12M("12M", "12 Month Prompt", 365)
}

data class FuturesContract(
    val contractId: String,
    val underlyingMetal: String,
    val prompt: PromptDate,
    val promptDateFormatted: String,
    val contractSizeOzOrTonnes: Double,
    val sizeUnit: String, // "Fine Troy Oz" or "Metric Tonnes"
    val tickSize: Double,
    val lastPrice: Double,
    val bid: Double,
    val ask: Double,
    val openInterest: Long,
    val volume24h: Long,
    val basisVsSpot: Double,
    val impliedFinancingAnnualizedPct: Double,
    val daysToExpiry: Int,
    val isPhysicalDelivery: Boolean = true
)

enum class OptionType {
    CALL, PUT
}

data class Greeks(
    val delta: Double,
    val gamma: Double,
    val theta: Double,
    val vega: Double,
    val rho: Double
)

data class OptionContract(
    val contractId: String,
    val underlyingMetal: String,
    val optionType: OptionType,
    val strike: Double,
    val expiryDays: Int,
    val expiryDate: String,
    val spotRef: Double,
    val premiumGbp: Double,
    val impliedVolatilityPct: Double,
    val greeks: Greeks,
    val moneynessPct: Double,
    val openInterest: Int
)

data class VolatilitySurfacePoint(
    val expiryLabel: String,
    val strikeDelta: String, // "90% OTM", "ATM", "110% ITM"
    val strikePrice: Double,
    val impliedVol: Double
)

data class RfqRequest(
    val rfqId: String,
    val clientId: String,
    val instrumentSymbol: String,
    val side: OrderSide,
    val quantity: Double,
    val unit: String,
    val maturityDays: Int,
    val currency: String,
    val preferredDealer: String = "Cannon Street Commodities / City Bullion Partners"
)

enum class RfqStatus {
    REQUESTED, QUOTED, NEGOTIATING, ACCEPTED, REJECTED, EXPIRED, SETTLED
}

data class RfqRecord(
    val rfqId: String,
    val clientId: String,
    val instrumentSymbol: String,
    val side: OrderSide,
    val quantity: Double,
    val maturityDays: Int,
    val currency: String,
    val dealerName: String,
    val quotedSpot: Double,
    val forwardPoints: Double,
    val quotedForwardPrice: Double,
    val requiredMarginPct: Double,
    val validUntilTimestamp: Long,
    val status: RfqStatus,
    val executedTradeId: String? = null
)

data class MetalSwapContract(
    val swapId: String,
    val metalSymbol: String,
    val notionalMetalOz: Double,
    val baseValueGbp: Double,
    val maturityDays: Int,
    val metalLeaseRatePct: Double,
    val fundingRatePct: Double,
    val collateralHeldGbp: Double,
    val counterparty: String,
    val status: String = "ACTIVE_ACCRUING"
)

data class PerpetualMarket(
    val symbol: String, // "BTC/XAU-PERP"
    val baseAsset: String,
    val quoteAsset: String,
    val indexPrice: Double,
    val markPrice: Double,
    val fundingRate8hPct: Double,
    val openInterestXau: Double,
    val maxLeverage: Int = 20,
    val maintenanceMarginPct: Double = 5.0,
    val liquidationPriceEstimate: Double
)
