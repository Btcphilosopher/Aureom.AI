package com.example.data.model

enum class AllocationStatus {
    ALLOCATED,
    UNALLOCATED,
    IN_TRANSIT,
    UNDER_INSPECTION,
    LOCKED_FOR_SETTLEMENT
}

data class VaultBar(
    val barId: String,               // e.g. "LDN-AU-00048271"
    val serialNumber: String,        // e.g. "SN-2024-88492"
    val metalType: String,           // "XAU" (Gold) or "XAG" (Silver)
    val refiner: String,             // e.g. "Royal Mint / Valcambi Suisse / Rand Refinery"
    val grossWeightKg: Double,       // e.g. 12.41 kg (standard London Good Delivery bar)
    val fineWeightOz: Double,        // e.g. 400.00 oz
    val fineness: Double,            // e.g. 999.9
    val locationVault: String,       // "London Vault 04 (Bank of England Sub-Depository)"
    val chamber: String,             // "Chamber Alpha-03"
    val pallet: String,              // "Pallet-14B"
    val currentOwner: String,        // "City Bullion Partners"
    val custodian: String = "LMX Custody Depository Ltd",
    val allocationStatus: AllocationStatus,
    val certificateNumber: String,
    val lastWeighedDate: String = "2026-08-15",
    val assayVerified: Boolean = true
)

data class VaultChamber(
    val chamberId: String,
    val name: String,
    val capacityBars: Int,
    val currentBarsCount: Int,
    val allocatedCount: Int,
    val unallocatedCount: Int,
    val securityLevel: String, // "Class 4 Institutional / Monitored"
    val temperatureCelsius: Double = 19.4,
    val relativeHumidityPct: Double = 42.0
)

data class BookEntryTransfer(
    val transferId: String,
    val barId: String,
    val fromEntity: String,
    val toEntity: String,
    val vaultLocation: String,
    val fineOzTransferred: Double,
    val timestamp: Long,
    val settlementRef: String,
    val signatureHash: String,
    val reconciliationVerified: Boolean = true
)

data class VaultDigitalTwin(
    val totalBars: Int = 400000,
    val totalFineOz: Double = 160000000.0, // 160M fine oz
    val totalValuationGbp: Double = 504000000000.0, // ~£504B
    val allocatedBarsCount: Int = 284500,
    val unallocatedBarsCount: Int = 105200,
    val inTransitCount: Int = 8200,
    val underInspectionCount: Int = 2100,
    val sampleAllocatedBars: List<VaultBar>,
    val chambers: List<VaultChamber>,
    val recentTransfers: List<BookEntryTransfer>
)
