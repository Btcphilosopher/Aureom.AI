package com.example.data.model

enum class MarginTier(val label: String, val thresholdDesc: String) {
    NORMAL("NORMAL", "< 70% Margin Utilisation (Safe Operating Zone)"),
    WATCH("WATCH", "70% - 85% Utilisation (Heightened Volatility Monitoring)"),
    WARNING("WARNING", "85% - 95% Utilisation (Pre-Margin Call Alert Issued)"),
    BREACH("BREACH", ">= 95% Utilisation (Immediate Liquidation Protocol Active)")
}

data class CollateralAsset(
    val assetSymbol: String,
    val name: String,
    val quantity: Double,
    val unit: String,
    val marketPriceGbp: Double,
    val grossValueGbp: Double,
    val haircutPct: Double, // Gold 8%, Silver 15%, BTC 35%, XAUT 20%, USDT 5%
    val postHaircutCollateralGbp: Double
)

data class MarginProfile(
    val initialMarginRequiredGbp: Double,
    val variationMarginGbp: Double,
    val maintenanceMarginGbp: Double,
    val totalCollateralPostHaircutGbp: Double,
    val freeMarginGbp: Double,
    val marginUtilisationPct: Double,
    val tier: MarginTier,
    val liquidationThresholdGbp: Double
)

data class PnLDecomposition(
    val spotPnlGbp: Double,
    val futuresPnlGbp: Double,
    val optionsPnlGbp: Double,
    val fxPnlGbp: Double,
    val physicalPnlGbp: Double,
    val digitalPnlGbp: Double,
    val hedgingPnlGbp: Double,
    val financingCostGbp: Double,
    val feesPaidGbp: Double,
    val vaultingCostGbp: Double,
    val totalRealizedPnlGbp: Double,
    val totalUnrealizedPnlGbp: Double,
    val netTotalPnlGbp: Double
)

data class StressShockScenario(
    val scenarioId: String,
    val name: String,
    val description: String,
    val goldShockPct: Double,
    val silverShockPct: Double,
    val btcShockPct: Double,
    val gbpUsdShockPct: Double,
    val volShockPct: Double,
    val simulatedPnlImpactGbp: Double,
    val simulatedMarginRequirementGbp: Double,
    val marginDeficitSurplusGbp: Double,
    val riskContributionGoldPct: Double,
    val riskContributionBtcPct: Double,
    val riskContributionFxPct: Double
)

data class PortfolioRiskSummary(
    val totalNavGbp: Double = 24819440.0, // £24,819,440
    val goldAssetGbp: Double = 9200000.0,  // £9.2m
    val silverAssetGbp: Double = 3800000.0,// £3.8m
    val fxAssetGbp: Double = 4100000.0,    // £4.1m
    val futuresAssetGbp: Double = 3200000.0,// £3.2m
    val optionsAssetGbp: Double = 1700000.0,// £1.7m
    val digitalAssetGbp: Double = 2819440.0,// £2.82m
    val dailyVaR99Gbp: Double = 842000.0,  // 99% 1-day VaR
    val cVaR99Gbp: Double = 1290000.0,     // Conditional VaR / Expected Shortfall
    val sharpeRatio: Double = 2.14,
    val marginProfile: MarginProfile,
    val pnlDecomposition: PnLDecomposition,
    val activeScenarios: List<StressShockScenario>
)
