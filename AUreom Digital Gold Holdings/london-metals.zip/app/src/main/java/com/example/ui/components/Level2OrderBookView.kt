package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderBookData
import com.example.ui.theme.*

@Composable
fun Level2OrderBookView(
    book: OrderBookData?,
    modifier: Modifier = Modifier
) {
    if (book == null) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(TerminalSurfaceVariant, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading Depth Book...", color = TextMuted, fontFamily = TerminalMonospace)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurfaceVariant, shape = RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LEVEL 2 SYNTHETIC ORDER BOOK // ${book.symbol}",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BullionGold
            )
            Text(
                text = "Spread: £${String.format("%.2f", book.spread)}",
                fontFamily = TerminalMonospace,
                fontSize = 10.sp,
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Headers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("BID QTY", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1f))
            Text("BID PRICE", fontFamily = TerminalMonospace, fontSize = 9.sp, color = MarketBidGreen, modifier = Modifier.weight(1f))
            Text("ASK PRICE", fontFamily = TerminalMonospace, fontSize = 9.sp, color = MarketAskRed, modifier = Modifier.weight(1f))
            Text("ASK QTY", fontFamily = TerminalMonospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 5 Levels
        val rowsCount = minOf(book.bids.size, book.asks.size, 5)
        for (i in 0 until rowsCount) {
            val bid = book.bids[i]
            val ask = book.asks[i]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bid Qty
                Text(
                    text = "${bid.quantity.toInt()} oz",
                    fontFamily = TerminalMonospace,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    modifier = Modifier.weight(1f)
                )
                // Bid Price
                Text(
                    text = String.format("%.2f", bid.price),
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp,
                    color = MarketBidGreen,
                    modifier = Modifier.weight(1f)
                )
                // Ask Price
                Text(
                    text = String.format("%.2f", ask.price),
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp,
                    color = MarketAskRed,
                    modifier = Modifier.weight(1f)
                )
                // Ask Qty
                Text(
                    text = "${ask.quantity.toInt()} oz",
                    fontFamily = TerminalMonospace,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Mid Price & Imbalance Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MID: £${String.format("%.2f", book.midPrice)}",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )
            Text(
                text = "VWAP: £${String.format("%.2f", (book.vwapBid + book.vwapAsk) / 2)}",
                fontFamily = TerminalMonospace,
                fontSize = 10.sp,
                color = BullionGoldMuted
            )
            val imbText = if (book.depthImbalance >= 0) "+${String.format("%.1f", book.depthImbalance * 100)}% BID" else "${String.format("%.1f", book.depthImbalance * 100)}% ASK"
            Text(
                text = "Imbalance: $imbText",
                fontFamily = TerminalMonospace,
                fontSize = 9.sp,
                color = if (book.depthImbalance >= 0) MarketBidGreen else MarketAskRed
            )
        }
    }
}
