package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlobalMarketBar
import com.example.ui.components.TerminalCommandPalette
import com.example.ui.components.TerminalStatusStrip
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LondonMetalsTheme {
                LondonMetalsTerminalApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LondonMetalsTerminalApp(viewModel: TerminalViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val quotes by viewModel.repository.marketEngine.quotes.collectAsState()
    val commandInput by viewModel.commandInput.collectAsState()
    val commandFeedback by viewModel.commandFeedback.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = TerminalBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column {
                GlobalMarketBar(quotes = quotes)
                TerminalTabBar(
                    selectedTab = selectedTab,
                    onSelectTab = { viewModel.selectTab(it) }
                )
                TerminalCommandPalette(
                    commandInput = commandInput,
                    onCommandChange = { viewModel.updateCommandInput(it) },
                    onExecute = { viewModel.executeCommand(it) },
                    feedback = commandFeedback
                )
            }
        },
        bottomBar = {
            TerminalStatusStrip()
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                TerminalTab.MARKETS -> MarketsScreen(viewModel = viewModel)
                TerminalTab.TRADE -> TradeScreen(viewModel = viewModel)
                TerminalTab.DERIVATIVES -> DerivativesScreen(viewModel = viewModel)
                TerminalTab.FX_DESK -> FxDeskScreen(viewModel = viewModel)
                TerminalTab.DIGITAL -> DigitalMetalsScreen(viewModel = viewModel)
                TerminalTab.VAULT -> PhysicalVaultScreen(viewModel = viewModel)
                TerminalTab.PORTFOLIO -> PortfolioRiskScreen(viewModel = viewModel)
                TerminalTab.SETTLEMENT -> SettlementLedgerScreen(viewModel = viewModel)
                TerminalTab.RESEARCH -> ResearchSurveillanceScreen(viewModel = viewModel)
                TerminalTab.API -> ApiTerminalScreen(viewModel = viewModel)
                TerminalTab.LMX_AI -> LmxAiAssistantScreen(viewModel = viewModel)
                TerminalTab.DEMOS -> DemonstrationsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TerminalTabBar(
    selectedTab: TerminalTab,
    onSelectTab: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .horizontalScroll(scrollState)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TerminalTab.values().forEach { tab ->
            val isSelected = selectedTab == tab
            FilterChip(
                selected = isSelected,
                onClick = { onSelectTab(tab) },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = tab.title,
                            fontFamily = TerminalMonospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.5.sp,
                            color = if (isSelected) Color(0xFF0F141C) else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) Color(0xFF1E2838) else TerminalSurfaceVariant,
                                    shape = RoundedCornerShape(2.dp)
                                )
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = tab.shortcutKey,
                                fontFamily = TerminalMonospace,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BullionGold else TextMuted
                            )
                        }
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BullionGold,
                    containerColor = TerminalSurfaceVariant
                ),
                border = FilterChipDefaults.filterChipBorder(
                    borderColor = if (isSelected) BullionGold else TerminalBorder,
                    enabled = true,
                    selected = isSelected
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("tab_${tab.name.lowercase()}")
            )
        }
    }
}
