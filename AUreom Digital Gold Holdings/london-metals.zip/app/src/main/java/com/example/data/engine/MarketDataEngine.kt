package com.example.data.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.cos

class MarketDataEngine {

    private val _quotes = MutableStateFlow<Map<String, QuoteData>>(emptyMap())
    val quotes: StateFlow<Map<String, QuoteData>> = _quotes.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, OrderBookData>>(emptyMap())
    val orderBooks: StateFlow<Map<String, OrderBookData>> = _orderBooks.asStateFlow()

    private var tickIndex = 0

    val instrumentsList: List<InstrumentDefinition> = listOf(
        // Spot Precious Metals
        InstrumentDefinition("INS-XAU-USD", "XAU/USD", "Spot Gold / USD", "XAU", "USD", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.01, 1.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON),
        InstrumentDefinition("INS-XAU-GBP", "XAU/GBP", "Spot Gold / GBP (London Benchmark)", "XAU", "GBP", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.01, 1.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.TRIANGULATED, "XAU/USD ÷ GBP/USD"),
        InstrumentDefinition("INS-GBP-XAU", "GBP/XAU", "British Pound in Gold Ounces", "GBP", "XAU", AssetCategory.FX_CROSS, MarketVenue.LONDON_SPOT_OTC, 0.000001, 1000.0, "GBP", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.INVERTED, "1 ÷ XAU/GBP"),
        InstrumentDefinition("INS-XAU-EUR", "XAU/EUR", "Spot Gold / EUR", "XAU", "EUR", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.01, 1.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.TRIANGULATED, "XAU/USD ÷ EUR/USD"),
        InstrumentDefinition("INS-XAU-JPY", "XAU/JPY", "Spot Gold / JPY", "XAU", "JPY", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 10.0, 1.0, "Fine Troy Oz", SettlementConvention.CASH_USD, QuoteType.TRIANGULATED, "XAU/USD × USD/JPY"),
        InstrumentDefinition("INS-XAU-CHF", "XAU/CHF", "Spot Gold / Swiss Franc", "XAU", "CHF", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.05, 1.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.TRIANGULATED, "XAU/USD ÷ USD/CHF"),
        
        InstrumentDefinition("INS-XAG-USD", "XAG/USD", "Spot Silver / USD", "XAG", "USD", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.005, 50.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON),
        InstrumentDefinition("INS-XAG-GBP", "XAG/GBP", "Spot Silver / GBP", "XAG", "GBP", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.005, 50.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.TRIANGULATED, "XAG/USD ÷ GBP/USD"),
        InstrumentDefinition("INS-XAG-EUR", "XAG/EUR", "Spot Silver / EUR", "XAG", "EUR", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.005, 50.0, "Fine Troy Oz", SettlementConvention.PHYSICAL_ALLOCATED_LONDON, QuoteType.TRIANGULATED, "XAG/USD ÷ EUR/USD"),
        
        InstrumentDefinition("INS-XPT-USD", "XPT/USD", "Spot Platinum / USD", "XPT", "USD", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.1, 5.0, "Fine Troy Oz", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XPD-USD", "XPD/USD", "Spot Palladium / USD", "XPD", "USD", AssetCategory.SPOT_METALS, MarketVenue.LONDON_SPOT_OTC, 0.1, 5.0, "Fine Troy Oz", SettlementConvention.CASH_USD),

        // LME Industrial Metals
        InstrumentDefinition("INS-XCU-USD", "XCU/USD", "Copper Grade A Cash (Synthetic Ref)", "XCU", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 0.5, 25.0, "Metric Tonnes", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XAL-USD", "XAL/USD", "Primary Aluminium Cash (Synthetic Ref)", "XAL", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 0.5, 25.0, "Metric Tonnes", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XNI-USD", "XNI/USD", "Nickel Cash Reference", "XNI", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 1.0, 6.0, "Metric Tonnes", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XZN-USD", "XZN/USD", "Special High Grade Zinc", "XZN", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 0.5, 25.0, "Metric Tonnes", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XPB-USD", "XPB/USD", "Standard Lead Cash", "XPB", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 0.5, 25.0, "Metric Tonnes", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-XSN-USD", "XSN/USD", "Refined Tin Cash", "XSN", "USD", AssetCategory.INDUSTRIAL_LME, MarketVenue.LME_ELECTRONIC, 5.0, 5.0, "Metric Tonnes", SettlementConvention.CASH_USD),

        // Institutional FX
        InstrumentDefinition("INS-GBP-USD", "GBP/USD", "British Pound / US Dollar Cable", "GBP", "USD", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.0001, 100000.0, "GBP", SettlementConvention.CASH_GBP),
        InstrumentDefinition("INS-EUR-USD", "EUR/USD", "Euro / US Dollar", "EUR", "USD", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.0001, 100000.0, "EUR", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-EUR-GBP", "EUR/GBP", "Euro / British Pound", "EUR", "GBP", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.0001, 100000.0, "EUR", SettlementConvention.CASH_GBP),
        InstrumentDefinition("INS-USD-JPY", "USD/JPY", "US Dollar / Japanese Yen", "USD", "JPY", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.01, 100000.0, "USD", SettlementConvention.CASH_USD),
        InstrumentDefinition("INS-GBP-JPY", "GBP/JPY", "British Pound / Japanese Yen", "GBP", "JPY", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.01, 100000.0, "GBP", SettlementConvention.CASH_GBP),
        InstrumentDefinition("INS-USD-CHF", "USD/CHF", "US Dollar / Swiss Franc", "USD", "CHF", AssetCategory.FX_CROSS, MarketVenue.FX_INTERBANK, 0.0001, 100000.0, "USD", SettlementConvention.CASH_USD),

        // Digital Asset Metals
        InstrumentDefinition("INS-BTC-USD", "BTC/USD", "Bitcoin / USD Index", "BTC", "USD", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.1, 0.01, "BTC", SettlementConvention.DIGITAL_TOKEN),
        InstrumentDefinition("INS-BTC-XAU", "BTC/XAU", "Bitcoin Priced in Fine Gold Oz", "BTC", "XAU", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.001, 0.01, "BTC", SettlementConvention.DIGITAL_TOKEN, QuoteType.TRIANGULATED, "BTC/USD ÷ XAU/USD"),
        InstrumentDefinition("INS-BTC-XAG", "BTC/XAG", "Bitcoin Priced in Fine Silver Oz", "BTC", "XAG", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.01, 0.01, "BTC", SettlementConvention.DIGITAL_TOKEN, QuoteType.TRIANGULATED, "BTC/USD ÷ XAG/USD"),
        InstrumentDefinition("INS-USDT-USD", "USDT/USD", "Tether USD Reference", "USDT", "USD", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.0001, 1000.0, "USDT", SettlementConvention.ON_CHAIN_USDT),
        InstrumentDefinition("INS-XAUT-USD", "XAUT/USD", "Tether Gold / USD Index", "XAUT", "USD", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.01, 0.1, "XAUT", SettlementConvention.DIGITAL_TOKEN),
        InstrumentDefinition("INS-XAUT-GBP", "XAUT/GBP", "Tether Gold / GBP", "XAUT", "GBP", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.01, 0.1, "XAUT", SettlementConvention.DIGITAL_TOKEN, QuoteType.TRIANGULATED, "XAUT/USD ÷ GBP/USD"),
        InstrumentDefinition("INS-USDT-XAUT", "USDT/XAUT", "USDT Priced in Tokenized Gold", "USDT", "XAUT", AssetCategory.DIGITAL_ASSET, MarketVenue.DIGITAL_METALS, 0.000001, 1000.0, "USDT", SettlementConvention.DIGITAL_TOKEN, QuoteType.INVERTED, "USDT/USD ÷ XAUT/USD")
    )

    init {
        generateInitialMarketSnapshot()
    }

    fun stepSimulationTick() {
        tickIndex++
        val now = System.currentTimeMillis()
        val current = _quotes.value.toMutableMap()

        // Base synthetic drift
        val xauUsdBase = 4200.00 + 12.0 * sin(tickIndex * 0.1) + 4.0 * cos(tickIndex * 0.04)
        val gbpUsdBase = 1.3340 + 0.0015 * cos(tickIndex * 0.08)
        val eurUsdBase = 1.0920 + 0.0012 * sin(tickIndex * 0.07)
        val usdJpyBase = 148.50 + 0.35 * sin(tickIndex * 0.05)
        val usdChfBase = 0.8650 + 0.0010 * cos(tickIndex * 0.06)
        val xagUsdBase = 39.80 + 0.35 * sin(tickIndex * 0.12)
        val btcUsdBase = 64800.0 + 350.0 * sin(tickIndex * 0.09)
        val xautUsdBase = xauUsdBase * (1.0 + 0.0008 * sin(tickIndex * 0.15)) // slight digital premium/discount

        fun updateQuote(sym: String, baseMid: Double, halfSpread: Double, vol: Double, quoteType: QuoteType = QuoteType.DIRECT) {
            val prev = current[sym]?.last ?: baseMid
            val mid = baseMid
            val bid = mid - halfSpread
            val ask = mid + halfSpread
            val change = mid - (current[sym]?.open ?: (mid * 0.992))
            val changePct = (change / (current[sym]?.open ?: (mid * 0.992))) * 100.0

            current[sym] = QuoteData(
                symbol = sym,
                instrumentId = "INS-" + sym.replace("/", "-"),
                bid = bid,
                ask = ask,
                mid = mid,
                last = mid,
                open = current[sym]?.open ?: (mid * 0.992),
                high = maxOf(current[sym]?.high ?: mid, ask),
                low = minOf(current[sym]?.low ?: mid, bid),
                closePrev = current[sym]?.closePrev ?: (mid * 0.988),
                change = change,
                changePercent = changePct,
                spread = ask - bid,
                volume = (current[sym]?.volume ?: 14000.0) + (10.0 + (tickIndex % 5) * 4.0),
                volatilityBps = vol,
                timestamp = now,
                quoteType = quoteType
            )
        }

        // 1. Core Underlyings
        updateQuote("XAU/USD", xauUsdBase, 0.40, 14.5)
        updateQuote("GBP/USD", gbpUsdBase, 0.0002, 8.2)
        updateQuote("EUR/USD", eurUsdBase, 0.0002, 7.5)
        updateQuote("USD/JPY", usdJpyBase, 0.02, 9.8)
        updateQuote("USD/CHF", usdChfBase, 0.0002, 7.1)
        updateQuote("XAG/USD", xagUsdBase, 0.02, 22.0)
        updateQuote("XPT/USD", 985.0 + 5.0 * sin(tickIndex * 0.08), 1.20, 18.0)
        updateQuote("XPD/USD", 1020.0 + 8.0 * cos(tickIndex * 0.07), 1.80, 24.0)

        // Industrial LME
        updateQuote("XCU/USD", 9840.0 + 30.0 * sin(tickIndex * 0.06), 2.0, 16.0)
        updateQuote("XAL/USD", 2620.0 + 12.0 * cos(tickIndex * 0.05), 1.0, 14.0)
        updateQuote("XNI/USD", 16800.0 + 80.0 * sin(tickIndex * 0.04), 10.0, 26.0)
        updateQuote("XZN/USD", 2980.0 + 15.0 * cos(tickIndex * 0.07), 1.5, 17.5)
        updateQuote("XPB/USD", 2140.0 + 8.0 * sin(tickIndex * 0.05), 1.0, 13.0)
        updateQuote("XSN/USD", 31800.0 + 120.0 * cos(tickIndex * 0.03), 25.0, 28.0)

        // 2. Cross Rates & Triangulations
        val xauGbp = xauUsdBase / gbpUsdBase
        val gbpXau = 1.0 / xauGbp
        val xauEur = xauUsdBase / eurUsdBase
        val xauJpy = xauUsdBase * usdJpyBase
        val xauChf = xauUsdBase / usdChfBase
        val xagGbp = xagUsdBase / gbpUsdBase
        val xagEur = xagUsdBase / eurUsdBase
        val eurGbp = eurUsdBase / gbpUsdBase
        val gbpJpy = gbpUsdBase * usdJpyBase

        updateQuote("XAU/GBP", xauGbp, 0.35, 13.8, QuoteType.TRIANGULATED)
        updateQuote("GBP/XAU", gbpXau, 0.0000005, 13.8, QuoteType.INVERTED)
        updateQuote("XAU/EUR", xauEur, 0.45, 14.0, QuoteType.TRIANGULATED)
        updateQuote("XAU/JPY", xauJpy, 80.0, 18.0, QuoteType.TRIANGULATED)
        updateQuote("XAU/CHF", xauChf, 0.50, 13.0, QuoteType.TRIANGULATED)
        updateQuote("XAG/GBP", xagGbp, 0.02, 21.0, QuoteType.TRIANGULATED)
        updateQuote("XAG/EUR", xagEur, 0.025, 21.5, QuoteType.TRIANGULATED)
        updateQuote("EUR/GBP", eurGbp, 0.0002, 7.8, QuoteType.TRIANGULATED)
        updateQuote("GBP/JPY", gbpJpy, 0.03, 11.2, QuoteType.TRIANGULATED)

        // 3. Digital Asset Metals Crosses
        val btcXau = btcUsdBase / xauUsdBase
        val btcXag = btcUsdBase / xagUsdBase
        val xautGbp = xautUsdBase / gbpUsdBase
        val usdtXaut = 1.0 / xautUsdBase

        updateQuote("BTC/USD", btcUsdBase, 15.0, 38.0)
        updateQuote("BTC/XAU", btcXau, 0.008, 36.5, QuoteType.TRIANGULATED)
        updateQuote("BTC/XAG", btcXag, 0.5, 42.0, QuoteType.TRIANGULATED)
        updateQuote("USDT/USD", 1.0001, 0.0001, 1.2)
        updateQuote("XAUT/USD", xautUsdBase, 0.50, 15.0)
        updateQuote("XAUT/GBP", xautGbp, 0.40, 14.5, QuoteType.TRIANGULATED)
        updateQuote("USDT/XAUT", usdtXaut, 0.0000002, 15.0, QuoteType.INVERTED)

        _quotes.value = current
        updateOrderBooks(current)
    }

    private fun updateOrderBooks(quotesMap: Map<String, QuoteData>) {
        val books = mutableMapOf<String, OrderBookData>()
        val symbols = listOf("XAU/USD", "XAU/GBP", "XAG/USD", "GBP/USD", "BTC/XAU", "XAUT/USD", "XCU/USD")

        for (sym in symbols) {
            val q = quotesMap[sym] ?: continue
            val mid = q.mid
            val tick = when (sym) {
                "XAU/USD", "XAU/GBP" -> 0.10
                "XAG/USD" -> 0.01
                "GBP/USD" -> 0.0001
                "BTC/XAU" -> 0.005
                "XCU/USD" -> 1.0
                else -> 0.10
            }

            val bids = listOf(
                OrderBookLevel(mid - tick * 1, 350.0, 12, 350.0),
                OrderBookLevel(mid - tick * 2, 220.0, 8, 570.0),
                OrderBookLevel(mid - tick * 3, 180.0, 6, 750.0),
                OrderBookLevel(mid - tick * 4, 450.0, 15, 1200.0),
                OrderBookLevel(mid - tick * 5, 600.0, 22, 1800.0)
            )

            val asks = listOf(
                OrderBookLevel(mid + tick * 1, 400.0, 14, 400.0),
                OrderBookLevel(mid + tick * 2, 250.0, 9, 650.0),
                OrderBookLevel(mid + tick * 3, 100.0, 4, 750.0),
                OrderBookLevel(mid + tick * 4, 380.0, 11, 1130.0),
                OrderBookLevel(mid + tick * 5, 520.0, 18, 1650.0)
            )

            val totalBidQty = bids.sumOf { it.quantity }
            val totalAskQty = asks.sumOf { it.quantity }
            val imbalance = (totalBidQty - totalAskQty) / (totalBidQty + totalAskQty)

            books[sym] = OrderBookData(
                symbol = sym,
                bids = bids,
                asks = asks,
                midPrice = mid,
                spread = q.spread,
                depthImbalance = imbalance,
                vwapBid = bids.sumOf { it.price * it.quantity } / totalBidQty,
                vwapAsk = asks.sumOf { it.price * it.quantity } / totalAskQty,
                timestamp = System.currentTimeMillis()
            )
        }
        _orderBooks.value = books
    }

    private fun generateInitialMarketSnapshot() {
        stepSimulationTick()
    }

    fun getLondonMarketClocks(): List<MarketSessionClock> {
        val nowUtc = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.UK)
        
        fun formatCity(tz: String): String {
            val cal = Calendar.getInstance(TimeZone.getTimeZone(tz))
            return sdf.format(cal.time)
        }

        val utcHour = nowUtc.get(Calendar.HOUR_OF_DAY)

        return listOf(
            MarketSessionClock("LONDON", "GMT/BST", formatCity("Europe/London"), "London Core Bullion & LME", utcHour in 8..17, 45),
            MarketSessionClock("NEW YORK", "EST/EDT", formatCity("America/New_York"), "COMEX & US Interbank FX", utcHour in 13..21, 35),
            MarketSessionClock("SINGAPORE", "SGT", formatCity("Asia/Singapore"), "Asia Bullion & Offshore FX", utcHour in 0..9, 12),
            MarketSessionClock("TOKYO", "JST", formatCity("Asia/Tokyo"), "TOCOM & East Asia", utcHour in 0..8, 8),
            MarketSessionClock("HONG KONG", "HKT", formatCity("Asia/Hong_Kong"), "HK Bullion & Gold Vaults", utcHour in 1..9, 10),
            MarketSessionClock("UTC", "UTC", formatCity("UTC"), "Global Benchmark Time", true, 100)
        )
    }
}
