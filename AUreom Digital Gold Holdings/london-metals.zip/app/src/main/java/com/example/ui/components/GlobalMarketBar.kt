package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuoteData
import com.example.ui.theme.*

@Composable
fun GlobalMarketBar(
    quotes: Map<String, QuoteData>,
    modifier: Modifier = Modifier
) {
    val keySymbols = listOf("XAU/USD", "XAU/GBP", "XAG/USD", "XCU/USD", "GBP/USD", "EUR/GBP", "BTC/USD", "BTC/XAU", "XAUT/USD", "USDT/XAUT")
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
    ) {
        // Upper Status Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(BritishRacingGreenBright, shape = androidx.compose.foundation.shape.CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LONDON METALS // LMX TERMINAL",
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BullionGold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ONE TERMINAL. EVERY METAL. EVERY MARKET.",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Box(
                modifier = Modifier
                    .background(Color(0xFF261E10), shape = androidx.compose.foundation.shape.RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "SIMULATED MARKET (DEMO)",
                    fontFamily = TerminalMonospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = BullionGoldMuted
                )
            }
        }

        // Horizontal Ticker Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (sym in keySymbols) {
                val q = quotes[sym]
                if (q != null) {
                    MarketStripItem(quote = q)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(TerminalBorder)
        )
    }
}

@Composable
private fun MarketStripItem(quote: QuoteData) {
    val isPositive = quote.change >= 0
    val changeColor = if (isPositive) MarketBidGreen else MarketAskRed
    val sign = if (isPositive) "+" else ""

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.testTag("ticker_${quote.symbol.replace("/", "_")}")
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = quote.symbol,
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = quote.formattedLast(if (quote.symbol.contains("USD") && !quote.symbol.contains("BTC") && !quote.symbol.contains("XCU") && !quote.symbol.contains("XAU")) 4 else 2),
                    fontFamily = TerminalMonospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$sign${String.format("%.2f", quote.changePercent)}%",
                    fontFamily = TerminalMonospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    color = changeColor
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sprd ${quote.formattedSpread(2)}",
                    fontFamily = TerminalMonospace,
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .width(1.dp)
                .height(18.dp)
                .background(TerminalBorderLight)
        )
    }
}
