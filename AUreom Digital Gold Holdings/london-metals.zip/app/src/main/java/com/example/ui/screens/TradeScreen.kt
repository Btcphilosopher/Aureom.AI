package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderSide
import com.example.data.model.OrderType
import com.example.ui.components.Level2OrderBookView
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun TradeScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSymbol by viewModel.selectedTradeSymbol.collectAsState()
    val side by viewModel.tradeSide.collectAsState()
    val orderType by viewModel.tradeOrderType.collectAsState()
    val quantity by viewModel.tradeQuantity.collectAsState()
    val price by viewModel.tradePrice.collectAsState()
    val currency by viewModel.tradeCurrency.collectAsState()
    val notification by viewModel.tradeNotification.collectAsState()

    val books by viewModel.repository.marketEngine.orderBooks.collectAsState()
    val orders by viewModel.repository.orders.collectAsState()
    val executions by viewModel.repository.executions.collectAsState()

    val currentBook = books[selectedSymbol] ?: books["XAU/GBP"]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Notification Banner
        notification?.let { note ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14301D)),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = note,
                        fontFamily = TerminalMonospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BritishRacingGreenBright,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }

        // Level 2 Orderbook View
        item {
            Level2OrderBookView(book = currentBook)
        }

        // OMS Order Entry Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ORDER MANAGEMENT SYSTEM // $selectedSymbol",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = BullionGold
                        )
                        Text(
                            text = "ACCOUNT: ACC-LDN-01994",
                            fontFamily = TerminalMonospace,
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Side Selector (BUY / SELL)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (side == OrderSide.BUY) BritishRacingGreenBright else TerminalSurface,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { viewModel.setTradeSide(OrderSide.BUY) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "BUY / BID",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (side == OrderSide.BUY) Color(0xFF041E0F) else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (side == OrderSide.SELL) MarketAskRed else TerminalSurface,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { viewModel.setTradeSide(OrderSide.SELL) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "SELL / OFFER",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (side == OrderSide.SELL) Color.White else TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Order Type Chips
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            OrderType.LIMIT to "Limit",
                            OrderType.MARKET to "Market",
                            OrderType.STOP to "Stop",
                            OrderType.TWAP to "TWAP",
                            OrderType.VWAP to "VWAP",
                            OrderType.ICEBERG to "Iceberg"
                        ).forEach { (type, label) ->
                            val isSelected = orderType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isSelected) BullionGold else TerminalSurface,
                                        RoundedCornerShape(3.dp)
                                    )
                                    .clickable { viewModel.setTradeOrderType(type) }
                                    .padding(vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    fontFamily = TerminalMonospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 9.sp,
                                    color = if (isSelected) Color(0xFF0F141C) else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quantity and Price Inputs
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { viewModel.updateTradeQuantity(it) },
                            label = { Text("Quantity (Oz/T)", fontFamily = TerminalMonospace, fontSize = 10.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 12.sp, color = TextPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("trade_quantity_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BullionGold,
                                unfocusedBorderColor = TerminalBorder
                            )
                        )

                        OutlinedTextField(
                            value = price,
                            onValueChange = { viewModel.updateTradePrice(it) },
                            label = { Text("Price ($currency)", fontFamily = TerminalMonospace, fontSize = 10.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TerminalMonospace, fontSize = 12.sp, color = TextPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("trade_price_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BullionGold,
                                unfocusedBorderColor = TerminalBorder
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Submit Order Button
                    Button(
                        onClick = { viewModel.submitTradeOrder() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) BritishRacingGreenBright else MarketAskRed
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("submit_order_btn")
                    ) {
                        Text(
                            text = "EXECUTE INSTITUTIONAL ${side.name} // $quantity $selectedSymbol",
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (side == OrderSide.BUY) Color(0xFF041E0F) else Color.White
                        )
                    }
                }
            }
        }

        // Smart Order Router (SOR) Analysis Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "SMART ORDER ROUTER (SOR) // OPTIMISATION",
                        fontFamily = TerminalMonospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = SteelBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Optimising Price + Liquidity + Fees + Latency + Settlement Convention.",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Recommended Venue: London OTC Pool", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = BullionGoldMuted)
                        Text("Est. Slippage: 1.8 bps | Latency: 22ms", fontFamily = TerminalMonospace, fontSize = 9.5.sp, color = BritishRacingGreenBright)
                    }
                }
            }
        }

        // Orders Audit Trail & Execution Reports
        item {
            Text(
                text = "RECENT ORDERS & AUDIT TRAIL",
                fontFamily = TerminalMonospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(orders.take(8)) { ord ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${ord.side} ${ord.quantity} ${ord.symbol}",
                                fontFamily = TerminalMonospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (ord.side == OrderSide.BUY) MarketBidGreen else MarketAskRed
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "@ £${String.format("%.2f", ord.avgFillPrice)}",
                                fontFamily = TerminalMonospace,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = ord.status.name,
                            fontFamily = TerminalMonospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = BritishRacingGreenBright
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Order ID: ${ord.orderId} | Venue: ${ord.venue.code}",
                            fontFamily = TerminalMonospace,
                            fontSize = 8.5.sp,
                            color = TextMuted
                        )
                        Text(
                            text = "Idempotency: ${ord.idempotencyKey.take(16)}...",
                            fontFamily = TerminalMonospace,
                            fontSize = 8.5.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
