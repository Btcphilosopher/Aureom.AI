package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun TransitionDashboardScreen(
    contracts: List<LegacyContract>,
    onBulkRemediate: (Currency, TransitionStatus, TransitionStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    var showBulkDialog by remember { mutableStateOf(false) }

    // Maturity Wall Items (2026, 2027, 2028, 2029, 2030, 2031+)
    val maturityWallItems = remember(contracts) {
        val years = listOf(2026, 2027, 2028, 2029, 2030, 2031)
        years.map { yr ->
            val matching = if (yr == 2031) contracts.filter { it.maturityYear >= 2031 } else contracts.filter { it.maturityYear == yr }
            val notionalBn = matching.sumOf { it.notional } / 1_000_000_000.0
            BarChartItem(
                label = if (yr == 2031) "2031+" else yr.toString(),
                value = notionalBn,
                color = if (yr <= 2027) BritishAmber else YieldBlue,
                subText = "${matching.size} contracts"
            )
        }
    }

    // Breakdown by Currency
    val currencyBreakdown = remember(contracts) {
        Currency.values().map { c ->
            val matching = contracts.filter { it.currency == c }
            val sumBn = matching.sumOf { it.notional } / 1_000_000_000.0
            BarChartItem(
                label = c.name,
                value = sumBn,
                color = when (c) {
                    Currency.USD -> LondonGold
                    Currency.GBP -> SterlingGreen
                    Currency.EUR -> YieldBlue
                    Currency.CHF -> PurpleQuant
                    Currency.JPY -> RiskCrimson
                }
            )
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("transition_dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIBOR TRANSITION CONTROL ROOM",
                        style = MaterialTheme.typography.titleLarge,
                        color = LondonGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Maturity Wall Analysis & Multi-Asset Remediation Workflow",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted
                    )
                }

                Button(
                    onClick = { showBulkDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SterlingGreenDark),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(34.dp).testTag("bulk_remediate_button")
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Bulk Remediate", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // LIBOR Maturity Wall Bar Chart
        item {
            CanvasBarChart(
                title = "LIBOR Maturity Wall Exposure (£bn Notional by Year)",
                items = maturityWallItems,
                unitLabel = "Exposure (£bn)"
            )
        }

        // Currency Distribution Bar Chart
        item {
            CanvasBarChart(
                title = "Exposure by Currency Universe",
                items = currencyBreakdown,
                unitLabel = "Notional (£bn)"
            )
        }

        // Priority Flags List
        item {
            Text(
                text = "HIGH PRIORITY CONTRACTS REQUIRING REMEDIATION",
                style = MaterialTheme.typography.labelMedium,
                color = LondonGold
            )
        }

        val highRiskContracts = contracts.filter { it.riskFlag || it.transitionStatus == TransitionStatus.PENDING_REVIEW || it.transitionStatus == TransitionStatus.ACTIVE_DISPUTE }
        items(highRiskContracts.take(8)) { c ->
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, RiskCrimson, RoundedCornerShape(6.dp))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(c.contractId, style = MaterialTheme.typography.titleSmall, color = LondonGold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusBadge(text = c.transitionStatus.label, color = RiskCrimson)
                        }
                        Text(c.counterparty, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Maturity: ${c.maturityYear} • Notional: ${c.currency.code} ${String.format("%,.1f", c.notional/1_000_000)}M", style = MaterialTheme.typography.bodySmall, color = CityTextMuted, fontSize = 10.sp)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Status Flag", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                        Text("ACTION REQUIRED", style = MaterialTheme.typography.labelSmall, color = RiskCrimson, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showBulkDialog) {
        var selectedCurr by remember { mutableStateOf(Currency.USD) }
        AlertDialog(
            onDismissRequest = { showBulkDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        onBulkRemediate(selectedCurr, TransitionStatus.FALLBACK_DEFINED, TransitionStatus.REMEDIATED_RFR)
                        showBulkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SterlingGreenDark)
                ) {
                    Text("Execute Bulk Conversion", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkDialog = false }) {
                    Text("Cancel", color = CityTextMuted)
                }
            },
            title = { Text("Bulk Contract Remediation", color = LondonGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Converts all eligible 'Fallback Defined' contracts for the selected currency to 'Remediated to RFR' using the official ISDA 2020 5-year median spread adjustment.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Select Target Currency:", style = MaterialTheme.typography.labelSmall, color = LondonGold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Currency.values().forEach { c ->
                            FilterChip(
                                selected = selectedCurr == c,
                                onClick = { selectedCurr = c },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }
            },
            containerColor = CityNavySurface
        )
    }
}
