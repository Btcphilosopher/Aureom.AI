package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.ScenarioEngine
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun PortfoliosScreen(
    portfolios: List<Portfolio>,
    contracts: List<LegacyContract>,
    modifier: Modifier = Modifier
) {
    var selectedPortfolio by remember { mutableStateOf(portfolios.firstOrNull() ?: generateDefaultPortfolio()) }
    var selectedScenario by remember { mutableStateOf(ScenarioType.IMMEDIATE_RFR_CONVERSION) }

    val scenarioResult = remember(selectedPortfolio, selectedScenario) {
        ScenarioEngine.runScenario(selectedPortfolio, contracts, selectedScenario)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("portfolios_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "PORTFOLIO RISK & SCENARIO LAB",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "DV01 Sensitivity, Value Transfer Stress Testing & Scenario Shocks",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Portfolio Selector Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                portfolios.forEach { p ->
                    val isSel = p.id == selectedPortfolio.id
                    Surface(
                        color = if (isSel) CityNavyCardHover else CityNavyCard,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, if (isSel) LondonGold else CityBorder, RoundedCornerShape(6.dp))
                            .clickable { selectedPortfolio = p }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = p.name.take(18),
                                style = MaterialTheme.typography.titleSmall,
                                color = if (isSel) LondonGold else CityTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${p.currency.symbol}${String.format("%,.0f", p.totalNotional / 1_000_000)}M Notional",
                                style = MaterialTheme.typography.labelSmall,
                                color = SterlingGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Active Portfolio Summary Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FinancialMetricCard(
                    label = "Portfolio Net PV",
                    value = "${selectedPortfolio.currency.symbol}${String.format("%,.1f", selectedPortfolio.netPv / 1_000_000)}M",
                    subValue = "${selectedPortfolio.contractCount} Active Contracts",
                    badgeText = "MARK TO MARKET",
                    badgeColor = SterlingGreen,
                    accentColor = LondonGold,
                    modifier = Modifier.weight(1f)
                )
                FinancialMetricCard(
                    label = "Total DV01 Risk",
                    value = "${selectedPortfolio.currency.symbol}${String.format("%,.0f", selectedPortfolio.totalDv01)}",
                    subValue = "Duration: ${selectedPortfolio.weightedDurationYears} Yrs",
                    badgeText = "DV01",
                    badgeColor = YieldBlue,
                    accentColor = YieldBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Scenario Selector
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TRANSITION SCENARIO STRESS ENGINE",
                        style = MaterialTheme.typography.labelMedium,
                        color = LondonGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    ScenarioType.values().forEach { st ->
                        val isSel = st == selectedScenario
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) CityNavyDark else Color.Transparent)
                                .clickable { selectedScenario = st }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSel,
                                onClick = { selectedScenario = st },
                                colors = RadioButtonDefaults.colors(selectedColor = LondonGold)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = st.label,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isSel) LondonGold else CityTextPrimary
                                )
                                Text(
                                    text = st.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CityTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Scenario Results Card
        item {
            Surface(
                color = CityNavySurface,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, if (scenarioResult.pvDelta >= 0) SterlingGreen else RiskCrimson, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STRESSED SCENARIO IMPACT",
                            style = MaterialTheme.typography.titleMedium,
                            color = LondonGold
                        )
                        StatusBadge(
                            text = "RISK: ${scenarioResult.transitionRiskScore}",
                            color = when (scenarioResult.transitionRiskScore) {
                                "LOW" -> SterlingGreen
                                "MODERATE" -> YieldBlue
                                "ELEVATED" -> BritishAmber
                                else -> RiskCrimson
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Stressed Portfolio PV:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = "${selectedPortfolio.currency.symbol}${String.format("%,.1f", scenarioResult.stressedPv / 1_000_000)}M",
                                style = MaterialTheme.typography.headlineSmall,
                                color = CityTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Net PV Delta:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = (if (scenarioResult.pvDelta >= 0) "+" else "") +
                                    "${selectedPortfolio.currency.symbol}${String.format("%,.2f", scenarioResult.pvDelta / 1_000_000)}M (${String.format("%.2f", scenarioResult.pvDeltaPercent)}%)",
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (scenarioResult.pvDelta >= 0) SterlingGreen else RiskCrimson,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier.fillMaxWidth().background(CityNavyDark, RoundedCornerShape(4.dp)).padding(8.dp)
                    ) {
                        Text(
                            text = scenarioResult.quantitativeCommentary,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

fun generateDefaultPortfolio(): Portfolio {
    return Portfolio(
        id = "PORT-LON-001",
        name = "City Rates Desk Legacy Book",
        desk = "Fixed Income & Multi-Asset Derivatives",
        currency = Currency.GBP,
        contractCount = 12,
        totalNotional = 240_000_000.0,
        netPv = 238_500_000.0,
        totalDv01 = 98_400.0,
        weightedDurationYears = 4.2,
        remediatedCount = 7,
        fallbackDefinedCount = 3,
        pendingReviewCount = 1,
        activeDisputeCount = 1,
        contractIds = emptyList()
    )
}
