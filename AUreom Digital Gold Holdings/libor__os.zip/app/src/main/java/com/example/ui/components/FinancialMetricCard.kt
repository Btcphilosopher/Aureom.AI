package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun FinancialMetricCard(
    label: String,
    value: String,
    subValue: String? = null,
    badgeText: String? = null,
    badgeColor: Color = LondonGold,
    accentColor: Color = YieldBlue,
    testTag: String = "metric_card",
    modifier: Modifier = Modifier
) {
    Surface(
        color = CityNavyCard,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
            .border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = CityTextSecondary,
                    fontSize = 10.sp
                )
                if (badgeText != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(badgeColor.copy(alpha = 0.15f))
                            .border(0.5.dp, badgeColor, RoundedCornerShape(3.dp))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeColor,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                color = accentColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (subValue != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subValue,
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun StatusBadge(
    text: String,
    color: Color = SterlingGreen,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.15f))
            .border(0.5.dp, color, RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun LegalWarningBanner(
    title: String = "REGULATORY & LEGAL BOUNDARY NOTICE",
    message: String = "LIBOR//OS is financial technology and analytical software. It does not provide legal advice, regulatory advice, investment advice or binding contractual interpretation. Document scanner diagnoses potential clauses only — human legal review required.",
    modifier: Modifier = Modifier
) {
    Surface(
        color = CityNavyDark,
        shape = RoundedCornerShape(4.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, LondonGoldMuted.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .testTag("legal_warning_banner")
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(BritishAmber, RoundedCornerShape(4.dp))
                    .padding(top = 4.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun FooterBanner(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CityNavyDark)
            .border(1.dp, CityBorder)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "LIBOR IS GONE. THE CONTRACTS ARE NOT.",
            style = MaterialTheme.typography.labelMedium,
            color = LondonGold,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = "LIBOR//OS — Understand the legacy. Model the transition. Reproduce the calculation.",
            style = MaterialTheme.typography.bodySmall,
            color = CityTextMuted,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "Aldgate Benchmark Systems Ltd • City of London EC2 • Licensed Data & Synthetic Fallback Engine",
            style = MaterialTheme.typography.labelSmall,
            color = CityBorderLight,
            fontSize = 9.sp
        )
    }
}
