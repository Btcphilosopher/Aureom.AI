package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class ChartSeries(
    val name: String,
    val color: Color,
    val dataPoints: List<Pair<String, Double>> // (Label, Value)
)

@Composable
fun CanvasLineChart(
    title: String,
    seriesList: List<ChartSeries>,
    yAxisSuffix: String = "%",
    modifier: Modifier = Modifier
) {
    Surface(
        color = CityNavyCard,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CityBorder, RoundedCornerShape(6.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = LondonGold
                )

                Row {
                    seriesList.forEach { s ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(s.color, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = s.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = CityTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val allValues = seriesList.flatMap { it.dataPoints.map { p -> p.second } }
            val minVal = (allValues.minOrNull() ?: 0.0).coerceAtLeast(-1.0)
            val maxVal = (allValues.maxOrNull() ?: 6.0).coerceAtLeast(minVal + 0.5)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val paddingBottom = 20f
                    val paddingTop = 10f
                    val chartHeight = h - paddingBottom - paddingTop

                    // Draw 4 horizontal grid lines
                    val gridSteps = 4
                    for (i in 0..gridSteps) {
                        val y = paddingTop + (chartHeight * i / gridSteps)
                        drawLine(
                            color = CityBorder.copy(alpha = 0.6f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Draw each series
                    seriesList.forEach { series ->
                        if (series.dataPoints.size > 1) {
                            val path = Path()
                            val stepX = w / (series.dataPoints.size - 1).coerceAtLeast(1)

                            series.dataPoints.forEachIndexed { idx, (_, value) ->
                                val normY = (value - minVal) / (maxVal - minVal).coerceAtLeast(0.001)
                                val x = idx * stepX
                                val y = (paddingTop + chartHeight * (1.0 - normY)).toFloat()

                                if (idx == 0) {
                                    path.moveTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                }

                                drawCircle(
                                    color = series.color,
                                    radius = 3.5f,
                                    center = Offset(x, y)
                                )
                            }

                            drawPath(
                                path = path,
                                color = series.color,
                                style = Stroke(width = 2.5f)
                            )
                        }
                    }
                }
            }

            // X-Axis labels
            val firstSeries = seriesList.firstOrNull()?.dataPoints ?: emptyList()
            if (firstSeries.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val step = (firstSeries.size / 5).coerceAtLeast(1)
                    firstSeries.filterIndexed { index, _ -> index % step == 0 || index == firstSeries.size - 1 }.forEach {
                        Text(
                            text = it.first,
                            style = MaterialTheme.typography.labelSmall,
                            color = CityTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

data class BarChartItem(
    val label: String,
    val value: Double,
    val color: Color = YieldBlue,
    val subText: String = ""
)

@Composable
fun CanvasBarChart(
    title: String,
    items: List<BarChartItem>,
    unitLabel: String = "£bn Notional",
    modifier: Modifier = Modifier
) {
    Surface(
        color = CityNavyCard,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CityBorder, RoundedCornerShape(6.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = LondonGold
                )
                Text(
                    text = unitLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = CityTextMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val maxVal = (items.maxOfOrNull { it.value } ?: 100.0).coerceAtLeast(1.0)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val barCount = items.size
                    val totalSpacing = w * 0.25f
                    val barWidth = (w - totalSpacing) / barCount.coerceAtLeast(1)
                    val spacing = totalSpacing / (barCount + 1).coerceAtLeast(1)

                    // Baseline
                    drawLine(
                        color = CityBorder,
                        start = Offset(0f, h - 2f),
                        end = Offset(w, h - 2f),
                        strokeWidth = 1.5f
                    )

                    items.forEachIndexed { index, item ->
                        val barHeight = (item.value / maxVal * (h - 10f)).toFloat()
                        val x = spacing + index * (barWidth + spacing)
                        val y = h - barHeight - 2f

                        drawRect(
                            color = item.color,
                            topLeft = Offset(x, y),
                            size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                        )
                    }
                }
            }

            // Labels row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                items.forEach { item ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = CityTextPrimary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%.1f", item.value),
                            style = MaterialTheme.typography.labelSmall,
                            color = item.color,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
