package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.CompoundingEngine
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun RfrCompoundingScreen(
    rfrRates: List<RiskFreeRate>,
    modifier: Modifier = Modifier
) {
    var selectedRfr by remember { mutableStateOf(rfrRates.firstOrNull { it.code == "SONIA" } ?: rfrRates.first()) }
    var compoundingMethod by remember { mutableStateOf(CompoundingMethod.COMPOUNDED_ARREARS) }
    var observationConvention by remember { mutableStateOf(ObservationConvention.OBSERVATION_SHIFT) }
    var lookbackDays by remember { mutableStateOf(5) }
    var lockoutDays by remember { mutableStateOf(0) }
    var marginBps by remember { mutableStateOf(150.0) }
    var notionalMillions by remember { mutableStateOf(10.0) }

    val dayCount = if (selectedRfr.currency == Currency.GBP) DayCountConvention.ACT_365F else DayCountConvention.ACT_360

    // Compute live compounding results
    val compoundingResult = remember(
        selectedRfr,
        compoundingMethod,
        observationConvention,
        lookbackDays,
        lockoutDays,
        marginBps,
        notionalMillions
    ) {
        CompoundingEngine.calculateCompoundedRate(
            baseObservations = emptyList(), // Generates realistic 90-day window
            notional = notionalMillions * 1_000_000.0,
            marginBps = marginBps,
            compoundingMethod = compoundingMethod,
            observationConvention = observationConvention,
            lookbackDays = lookbackDays,
            lockoutDays = lockoutDays,
            dayCount = dayCount
        )
    }

    val chartSeries = remember(compoundingResult) {
        listOf(
            ChartSeries(
                name = "Compounded Cumulative Rate",
                color = SterlingGreen,
                dataPoints = compoundingResult.dailyObservations.take(15).map { Pair(it.date, it.cumulativeRate) }
            ),
            ChartSeries(
                name = "Daily Fixing",
                color = YieldBlue,
                dataPoints = compoundingResult.dailyObservations.take(15).map { Pair(it.date, it.ratePercent) }
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("rfr_compounding_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Title
        item {
            Column {
                Text(
                    text = "RISK-FREE RATE & COMPOUNDING ENGINE",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ISDA 2020 / Sterling RFR Working Group Daily Compounding Calculator",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // RFR Selector Cards
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(rfrRates) { rfr ->
                    val isSelected = rfr.code == selectedRfr.code
                    Surface(
                        color = if (isSelected) CityNavyCardHover else CityNavyCard,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .width(130.dp)
                            .border(1.dp, if (isSelected) LondonGold else CityBorder, RoundedCornerShape(6.dp))
                            .clickable { selectedRfr = rfr }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = rfr.code,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isSelected) LondonGold else CityTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = rfr.currency.code,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextMuted,
                                    fontSize = 9.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = String.format("%.4f%%", rfr.currentRate),
                                style = MaterialTheme.typography.titleLarge,
                                color = SterlingGreen,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (rfr.isSecured) "Secured Repo" else "Unsecured",
                                style = MaterialTheme.typography.labelSmall,
                                color = CityTextMuted,
                                fontSize = 8.sp
                            )
                        }
                    }
                }
            }
        }

        // Selected RFR Profile Details
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "${selectedRfr.benchmarkName} (${selectedRfr.code})",
                        style = MaterialTheme.typography.titleMedium,
                        color = LondonGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Administrator: ${selectedRfr.administrator} • Pub Time: ${selectedRfr.publicationTime} • Day Count: ${dayCount.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Methodology: ${selectedRfr.methodology}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Compounding Controls
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "COMPOUNDING PARAMETERS",
                        style = MaterialTheme.typography.labelMedium,
                        color = LondonGold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Compounding Method Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            CompoundingMethod.COMPOUNDED_ARREARS,
                            CompoundingMethod.COMPOUNDED_ADVANCE,
                            CompoundingMethod.WEIGHTED_AVERAGE
                        ).forEach { method ->
                            val isSel = method == compoundingMethod
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) YieldBlue else CityNavyDark)
                                    .border(0.5.dp, if (isSel) YieldBlue else CityBorder, RoundedCornerShape(4.dp))
                                    .clickable { compoundingMethod = method }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = method.label.replace("Compounded ", ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) CityNavyDark else CityTextPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Convention & Lookback controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Lookback (Days): $lookbackDays BD", style = MaterialTheme.typography.labelSmall, color = CityTextMuted)
                            Slider(
                                value = lookbackDays.toFloat(),
                                onValueChange = { lookbackDays = it.toInt() },
                                valueRange = 0f..10f,
                                steps = 9,
                                colors = SliderDefaults.colors(thumbColor = LondonGold, activeTrackColor = LondonGold)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Margin (Spread): ${marginBps.toInt()} bps", style = MaterialTheme.typography.labelSmall, color = CityTextMuted)
                            Slider(
                                value = marginBps.toFloat(),
                                onValueChange = { marginBps = it.toDouble() },
                                valueRange = 0f..500f,
                                steps = 20,
                                colors = SliderDefaults.colors(thumbColor = YieldBlue, activeTrackColor = YieldBlue)
                            )
                        }
                    }
                }
            }
        }

        // Live Calculated Results Summary Card
        item {
            Surface(
                color = CityNavySurface,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, SterlingGreen, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CALCULATED COMPOUNDED COUPON",
                            style = MaterialTheme.typography.titleMedium,
                            color = SterlingGreen
                        )
                        StatusBadge(
                            text = "${compoundingResult.totalPeriodDays} DAYS ACCRUAL",
                            color = SterlingGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Base Compounded Rate:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = String.format("%.4f%%", compoundingResult.compoundedRatePercent),
                                style = MaterialTheme.typography.headlineSmall,
                                color = YieldBlue,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("All-In Rate (+ Margin):", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = String.format("%.4f%%", compoundingResult.allInRatePercent),
                                style = MaterialTheme.typography.headlineSmall,
                                color = LondonGold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Period Interest Payable (£${notionalMillions.toInt()}M Notional):",
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextSecondary
                        )
                        Text(
                            text = "${selectedRfr.currency.symbol}${String.format("%,.2f", compoundingResult.totalInterestAmount)}",
                            style = MaterialTheme.typography.titleMedium,
                            color = SterlingGreen,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Formula explanation box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CityNavyDark, RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        Text(
                            text = compoundingResult.formulaExplanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Compounding Trajectory Canvas Chart
        item {
            CanvasLineChart(
                title = "Daily Fixing vs Cumulative Compounded Trajectory",
                seriesList = chartSeries
            )
        }
    }
}
