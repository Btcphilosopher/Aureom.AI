package com.example.engine

import com.example.data.model.*
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

object CurveEngine {

    /**
     * Constructs Yield Curves for RFR and Legacy LIBOR across standard tenors.
     */
    fun buildStandardCurve(
        currency: Currency,
        benchmark: String,
        baseShortRate: Double = when (currency) {
            Currency.GBP -> 4.75
            Currency.USD -> 4.50
            Currency.EUR -> 3.25
            Currency.CHF -> 1.00
            Currency.JPY -> 0.25
        },
        slopeBpsPerYear: Double = -12.0 // Inverted/flat curve regime
    ): YieldCurve {
        val tenorDefs = listOf(
            Triple("1M", 30, 0.0),
            Triple("3M", 90, 0.05),
            Triple("6M", 180, 0.08),
            Triple("1Y", 365, -0.05),
            Triple("2Y", 730, -0.25),
            Triple("3Y", 1095, -0.40),
            Triple("5Y", 1825, -0.55),
            Triple("7Y", 2555, -0.60),
            Triple("10Y", 3650, -0.65),
            Triple("15Y", 5475, -0.60),
            Triple("20Y", 7300, -0.55),
            Triple("30Y", 10950, -0.50)
        )

        val points = mutableListOf<YieldCurvePoint>()
        var prevDf = 1.0
        var prevT = 0.0

        tenorDefs.forEach { (label, days, humpAdj) ->
            val tYears = days / 365.25
            val zeroRate = (baseShortRate + humpAdj + (tYears * (slopeBpsPerYear / 100.0))).coerceAtLeast(0.05)
            val discountFactor = exp(- (zeroRate / 100.0) * tYears)

            // Forward rate from previous tenor point
            val forwardRate = if (tYears > prevT) {
                (ln(prevDf / discountFactor) / (tYears - prevT)) * 100.0
            } else {
                zeroRate
            }

            points.add(
                YieldCurvePoint(
                    tenorLabel = label,
                    tenorDays = days,
                    zeroRatePercent = zeroRate,
                    discountFactor = discountFactor,
                    forwardRatePercent = forwardRate,
                    curveType = if (benchmark.contains("LIBOR")) "LEGACY_PROJECTION" else "OIS_DISCOUNT"
                )
            )

            prevDf = discountFactor
            prevT = tYears
        }

        return YieldCurve(
            curveId = "CRV-${currency.name}-$benchmark",
            curveName = "${currency.name} $benchmark Benchmark Curve",
            currency = currency,
            benchmark = benchmark,
            asOfDate = "2026-10-01",
            points = points
        )
    }

    /**
     * Interpolates discount factor for an arbitrary fractional time in years t.
     */
    fun interpolateDiscountFactor(curve: YieldCurve, tYears: Double): Double {
        if (tYears <= 0.0) return 1.0
        val points = curve.points
        if (points.isEmpty()) return 1.0

        val days = tYears * 365.25
        if (days <= points.first().tenorDays) {
            val r = points.first().zeroRatePercent / 100.0
            return exp(-r * tYears)
        }
        if (days >= points.last().tenorDays) {
            val r = points.last().zeroRatePercent / 100.0
            return exp(-r * tYears)
        }

        for (i in 0 until points.size - 1) {
            val p1 = points[i]
            val p2 = points[i + 1]
            if (days >= p1.tenorDays && days <= p2.tenorDays) {
                val weight = (days - p1.tenorDays).toDouble() / (p2.tenorDays - p1.tenorDays)
                // Log-linear discount factor interpolation
                val lnDf1 = ln(p1.discountFactor)
                val lnDf2 = ln(p2.discountFactor)
                val interpolatedLnDf = lnDf1 + weight * (lnDf2 - lnDf1)
                return exp(interpolatedLnDf)
            }
        }
        return exp(-0.04 * tYears)
    }
}
