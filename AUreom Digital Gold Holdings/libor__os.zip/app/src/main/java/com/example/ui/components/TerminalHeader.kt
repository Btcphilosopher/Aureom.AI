package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    onRunDemo: () -> Unit,
    isDemoRunning: Boolean = false,
    modifier: Modifier = Modifier
) {
    var showRoleDropdown by remember { mutableStateOf(false) }

    Surface(
        color = CityNavyMedium,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CityBorder)
            .testTag("terminal_header")
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            // Top institutional branding row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(LondonGold.copy(alpha = 0.15f))
                            .border(1.dp, LondonGold, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "£//",
                            color = LondonGold,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "LIBOR//OS",
                                style = MaterialTheme.typography.titleLarge,
                                color = LondonGold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(CityNavyCard, RoundedCornerShape(4.dp))
                                    .border(0.5.dp, CityBorderLight, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "CITY OF LONDON EC2",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextSecondary
                                )
                            }
                        }
                        Text(
                            text = "Aldgate Benchmark Systems Ltd • Benchmark Transition Platform",
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextMuted
                        )
                    }
                }

                // Action buttons: Demo runner & Role Switcher
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onRunDemo,
                        enabled = !isDemoRunning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDemoRunning) CityNavyCard else SterlingGreenDark,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("run_demo_button")
                    ) {
                        if (isDemoRunning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = LondonGold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RUNNING DEMO...", style = MaterialTheme.typography.labelSmall)
                        } else {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("libor-os demo", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Role selector
                    Box {
                        Surface(
                            color = CityNavyCard,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .border(1.dp, CityBorder, RoundedCornerShape(4.dp))
                                .clickable { showRoleDropdown = true }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("role_selector_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(currentRole.badgeColor), RoundedCornerShape(2.dp))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = currentRole.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Select Role",
                                    tint = CityTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showRoleDropdown,
                            onDismissRequest = { showRoleDropdown = false },
                            modifier = Modifier.background(CityNavySurface)
                        ) {
                            UserRole.values().forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(Color(role.badgeColor), RoundedCornerShape(2.dp))
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = role.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = CityTextPrimary
                                                )
                                                Text(
                                                    text = "Role: ${role.name}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = CityTextMuted
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        onRoleSelected(role)
                                        showRoleDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sub-status line: Regulatory Permanence Notice
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CityNavyDark, RoundedCornerShape(3.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(RiskCrimson, RoundedCornerShape(3.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "REGULATORY STATUS: ALL 35 LIBOR SETTINGS PERMANENTLY CEASED (FCA/IBA). FINAL SYNTHETIC USD CEASED 30 SEP 2024.",
                    style = MaterialTheme.typography.labelSmall,
                    color = LondonGold,
                    fontSize = 10.sp
                )
            }
        }
    }
}
