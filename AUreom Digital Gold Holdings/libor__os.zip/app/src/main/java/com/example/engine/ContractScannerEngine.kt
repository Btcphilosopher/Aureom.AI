package com.example.engine

import com.example.data.model.*

object ContractScannerEngine {

    /**
     * Diagnostic NLP parser for legacy credit agreements, ISDA confirmations, and FRN prospectuses.
     * Enforces strict regulatory compliance: never gives final legal conclusions; outputs confidence and candidate interpretations.
     */
    fun scanDocumentText(text: String): List<ScannedClauseResult> {
        val results = mutableListOf<ScannedClauseResult>()
        val lower = text.lowercase()

        // 1. Benchmark Detection
        if (lower.contains("libor") || lower.contains("london interbank offered rate") || lower.contains("screen rate")) {
            val tenorCandidate = when {
                lower.contains("3 month") || lower.contains("3-month") || lower.contains("three month") -> "3M"
                lower.contains("6 month") || lower.contains("6-month") || lower.contains("six month") -> "6M"
                lower.contains("1 month") || lower.contains("1-month") || lower.contains("one month") -> "1M"
                lower.contains("12 month") || lower.contains("1-year") -> "12M"
                else -> "Unspecified Tenor"
            }
            val currencyCandidate = when {
                lower.contains("dollar") || lower.contains("usd") || lower.contains("$") -> "USD"
                lower.contains("sterling") || lower.contains("gbp") || lower.contains("pound") || lower.contains("£") -> "GBP"
                lower.contains("euro") || lower.contains("eur") || lower.contains("€") -> "EUR"
                lower.contains("franc") || lower.contains("chf") -> "CHF"
                lower.contains("yen") || lower.contains("jpy") || lower.contains("¥") -> "JPY"
                else -> "USD (Default Inference)"
            }

            results.add(
                ScannedClauseResult(
                    clauseType = "Benchmark Definition Clause",
                    detectedText = extractMatchingSnippet(text, listOf("LIBOR", "London Interbank", "Screen Rate")),
                    confidenceScore = 96.8,
                    candidateInterpretation = "References $currencyCandidate LIBOR ($tenorCandidate). Permanent cessation occurred 30 June 2023 / Synthetic 30 Sept 2024.",
                    humanReviewRequired = false,
                    matchedKeywords = listOf("LIBOR", currencyCandidate, tenorCandidate, "Screen Rate"),
                    governingLawCandidate = GoverningLaw.ENGLISH_LAW,
                    fallbackCandidate = "Statutory / RFR Replacement"
                )
            )
        }

        // 2. Fallback Language Analysis
        val isdaProtocol = lower.contains("isda 2020 ibor") || lower.contains("fallback protocol") || lower.contains("ibor fallbacks supplement")
        val arrcLanguage = lower.contains("arrc") || lower.contains("benchmark replacement") || lower.contains("sofr waterfall")
        val pollingRefBanks = lower.contains("reference banks") || lower.contains("cost of funds") || lower.contains("poll principal london offices")
        val agentDiscretion = lower.contains("administrative agent") || lower.contains("sole discretion") || lower.contains("replacement benchmark")

        when {
            isdaProtocol -> {
                results.add(
                    ScannedClauseResult(
                        clauseType = "Fallback Mechanism — ISDA Protocol Adherence",
                        detectedText = extractMatchingSnippet(text, listOf("ISDA 2020", "IBOR Fallbacks", "Protocol")),
                        confidenceScore = 94.2,
                        candidateInterpretation = "Contract language incorporates ISDA 2020 IBOR Fallbacks Protocol. Maps to Compounded RFR in Arrears + 5-yr Historical Median Spread Adjustment.",
                        humanReviewRequired = false,
                        matchedKeywords = listOf("ISDA 2020", "IBOR Fallbacks", "Protocol"),
                        governingLawCandidate = GoverningLaw.ENGLISH_LAW,
                        fallbackCandidate = "ISDA Compounded RFR + 5-Yr Median Spread"
                    )
                )
            }
            arrcLanguage -> {
                results.add(
                    ScannedClauseResult(
                        clauseType = "Fallback Mechanism — ARRC Hardwired Waterfall",
                        detectedText = extractMatchingSnippet(text, listOf("Benchmark Replacement", "ARRC", "SOFR Waterfall")),
                        confidenceScore = 91.5,
                        candidateInterpretation = "Hardwired ARRC fallback detected. Steps: Step 1 (Term SOFR + ARRC Spread), Step 2 (Compounded Daily SOFR + Spread), Step 3 (Agent/Borrower Selection).",
                        humanReviewRequired = false,
                        matchedKeywords = listOf("Benchmark Replacement", "Waterfall", "ARRC"),
                        governingLawCandidate = GoverningLaw.NEW_YORK_LAW,
                        fallbackCandidate = "Term SOFR / Daily Compounded SOFR"
                    )
                )
            }
            pollingRefBanks -> {
                results.add(
                    ScannedClauseResult(
                        clauseType = "Legacy Fallback — Polling / Cost of Funds (TOUGH LEGACY)",
                        detectedText = extractMatchingSnippet(text, listOf("reference banks", "cost of funds", "poll")),
                        confidenceScore = 88.0,
                        candidateInterpretation = "CRITICAL ALERT: Legacy Reference Bank Polling / Cost of Funds clause detected. Banks no longer quote LIBOR polling. Risk of conversion to fixed rate or lender-specific cost of funds. Requires active bilateral amendment.",
                        humanReviewRequired = true,
                        matchedKeywords = listOf("Reference Banks", "Cost of Funds", "Polling"),
                        governingLawCandidate = GoverningLaw.ENGLISH_LAW,
                        fallbackCandidate = "Tough Legacy — Legislative / Bilateral Remediation Required"
                    )
                )
            }
            agentDiscretion -> {
                results.add(
                    ScannedClauseResult(
                        clauseType = "Fallback Mechanism — Agent Discretionary Replacement",
                        detectedText = extractMatchingSnippet(text, listOf("administrative agent", "sole discretion", "replacement")),
                        confidenceScore = 79.4,
                        candidateInterpretation = "Administrative Agent empowered to select successor benchmark with borrower consultation. Notice and consent timeline verification required.",
                        humanReviewRequired = true,
                        matchedKeywords = listOf("Administrative Agent", "Discretion", "Replacement"),
                        governingLawCandidate = GoverningLaw.NEW_YORK_LAW,
                        fallbackCandidate = "Discretionary Agent RFR Selection"
                    )
                )
            }
            else -> {
                results.add(
                    ScannedClauseResult(
                        clauseType = "Fallback Clause — Undefined / Missing",
                        detectedText = "No explicit robust benchmark fallback clause identified in provided excerpt.",
                        confidenceScore = 65.0,
                        candidateInterpretation = "No clear fallback provision found. Potential Tough Legacy contract. Subject to statutory safe harbors (e.g. US LIBOR Act / UK Critical Benchmarks Act).",
                        humanReviewRequired = true,
                        matchedKeywords = emptyList(),
                        governingLawCandidate = GoverningLaw.OTHER,
                        fallbackCandidate = "Statutory Override / Bilateral Consent"
                    )
                )
            }
        }

        // 3. Governing Law Detection
        val lawCandidate = when {
            lower.contains("laws of the state of new york") || lower.contains("new york law") -> Pair(GoverningLaw.NEW_YORK_LAW, 95.0)
            lower.contains("laws of england") || lower.contains("english law") || lower.contains("england and wales") -> Pair(GoverningLaw.ENGLISH_LAW, 97.0)
            lower.contains("swiss law") || lower.contains("laws of switzerland") -> Pair(GoverningLaw.SWISS_LAW, 93.0)
            lower.contains("laws of japan") || lower.contains("japanese law") -> Pair(GoverningLaw.JAPANESE_LAW, 90.0)
            lower.contains("laws of germany") || lower.contains("german law") -> Pair(GoverningLaw.GERMAN_LAW, 92.0)
            else -> Pair(GoverningLaw.OTHER, 50.0)
        }

        results.add(
            ScannedClauseResult(
                clauseType = "Governing Law & Jurisdiction",
                detectedText = extractMatchingSnippet(text, listOf("governed by", "jurisdiction", "laws of")),
                confidenceScore = lawCandidate.second,
                candidateInterpretation = "Governed by ${lawCandidate.first.label} (${lawCandidate.first.jurisdiction}). Determines applicability of statutory safe harbor legislation (US LIBOR Act vs UK Financial Services Act 2021).",
                humanReviewRequired = lawCandidate.second < 80.0,
                matchedKeywords = listOf(lawCandidate.first.label, "Jurisdiction"),
                governingLawCandidate = lawCandidate.first,
                fallbackCandidate = "Statutory Framework: ${lawCandidate.first.label}"
            )
        )

        return results
    }

    private fun extractMatchingSnippet(text: String, keywords: List<String>): String {
        for (kw in keywords) {
            val idx = text.indexOf(kw, ignoreCase = true)
            if (idx >= 0) {
                val start = (idx - 60).coerceAtLeast(0)
                val end = (idx + kw.length + 100).coerceAtMost(text.length)
                return "..." + text.substring(start, end).replace("\n", " ").trim() + "..."
            }
        }
        return text.take(150) + "..."
    }
}
