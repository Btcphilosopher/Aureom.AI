package com.example.engine

import com.example.data.model.*
import kotlin.math.abs

object ScenarioEngine {

    /**
     * Executes stress tests and transition scenarios against a portfolio of legacy contracts.
     */
    fun runScenario(portfolio: Portfolio, contracts: List<LegacyContract>, scenarioType: ScenarioType): ScenarioImpactResult {
        val basePv = portfolio.netPv
        val baseDv01 = portfolio.totalDv01

        var stressedPv = basePv
        var stressedDv01 = baseDv01
        var riskLevel = "LOW"
        var commentary = ""

        when (scenarioType) {
            ScenarioType.IMMEDIATE_RFR_CONVERSION -> {
                // Immediate clean conversion reduces basis risk and eliminates litigation leakage
                stressedPv = basePv * 1.0015
                stressedDv01 = baseDv01 * 0.98
                riskLevel = "LOW"
                commentary = "Immediate execution of standard ISDA/ARRC fallback conversion locks in 5-yr median spread, eliminating operational tracking friction and reducing legal dispute reserve by 95%."
            }
            ScenarioType.CONTRACTUAL_FALLBACK -> {
                // Contractual fallbacks may have custom spreads or timing differences
                val reviewRatio = (portfolio.pendingReviewCount.toDouble() / portfolio.contractCount.coerceAtLeast(1))
                val drag = reviewRatio * 0.008
                stressedPv = basePv * (1.0 - drag)
                stressedDv01 = baseDv01 * 1.02
                riskLevel = if (reviewRatio > 0.15) "ELEVATED" else "MODERATE"
                commentary = "Applying strict contractual terms reveals spread dispersion across legacy bilateral facilities. ${portfolio.pendingReviewCount} contracts require manual amendment confirmation."
            }
            ScenarioType.DELAYED_REMEDIATION -> {
                // 12-month delay increases carry slippage and legal dispute overhead
                stressedPv = basePv * 0.982 // -1.8% value erosion
                stressedDv01 = baseDv01 * 1.08
                riskLevel = "CRITICAL"
                commentary = "12-month delay in remediation results in £${String.format("%.2f", abs(basePv * 0.018) / 1_000_000)}M basis slippage, increased dealer bid-ask friction, and high litigation exposure under non-representative synthetic LIBOR expiration."
            }
            ScenarioType.SPREAD_SHOCK_PLUS_10BP -> {
                // +10 bps spread adjustment on floating rate assets increases asset PV
                val delta = (portfolio.totalNotional * 0.0010 * portfolio.weightedDurationYears * 0.5)
                stressedPv = basePv + delta
                stressedDv01 = baseDv01 * 1.01
                riskLevel = "MODERATE"
                commentary = "+10 bps basis widening increases asset present value by £${String.format("%.2f", delta / 1_000_000)}M, but creates counterparty refinancing friction on corporate credit lines."
            }
            ScenarioType.SPREAD_SHOCK_MINUS_10BP -> {
                val delta = (portfolio.totalNotional * 0.0010 * portfolio.weightedDurationYears * 0.5)
                stressedPv = basePv - delta
                stressedDv01 = baseDv01 * 0.99
                riskLevel = "MODERATE"
                commentary = "-10 bps basis compression leads to £${String.format("%.2f", delta / 1_000_000)}M mark-to-market reduction across legacy loan asset books."
            }
            ScenarioType.CURVE_PARALLEL_PLUS_100BP -> {
                // +100 bps parallel curve shift: PV changes by approx -DV01 * 100
                val delta = baseDv01 * 100.0
                stressedPv = basePv - delta
                stressedDv01 = baseDv01 * 0.95
                riskLevel = "ELEVATED"
                commentary = "+100 bps discount rate rise causes £${String.format("%.2f", delta / 1_000_000)}M net present value reduction across the portfolio due to duration discounting."
            }
            ScenarioType.CURVE_TWIST_STEEPENER -> {
                val delta = baseDv01 * 35.0
                stressedPv = basePv - delta
                stressedDv01 = baseDv01 * 1.06
                riskLevel = "MODERATE"
                commentary = "2s10s curve steepening (+50 bps) impacts long-dated amortising facilities maturing post-2030."
            }
        }

        val pvDelta = stressedPv - basePv
        val pvDeltaPercent = if (basePv != 0.0) (pvDelta / basePv) * 100.0 else 0.0

        return ScenarioImpactResult(
            scenarioType = scenarioType,
            name = scenarioType.label,
            portfolioId = portfolio.id,
            basePv = basePv,
            stressedPv = stressedPv,
            pvDelta = pvDelta,
            pvDeltaPercent = pvDeltaPercent,
            baseDv01 = baseDv01,
            stressedDv01 = stressedDv01,
            transitionRiskScore = riskLevel,
            quantitativeCommentary = commentary
        )
    }
}
