package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ResearchLabScreen(
    researchStudies: List<ResearchStudy>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Quantitative Studies, 1: Backtesting Replay
    var replayYear by remember { mutableStateOf("2023 (USD Pre-Cessation)") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("research_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "QUANTITATIVE RESEARCH & BACKTESTING LAB",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Aldgate Quantitative Finance Working Papers & Transition Backtesting Engine",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Sub Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CityNavyCard,
                contentColor = LondonGold,
                modifier = Modifier.border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("RESEARCH STUDIES", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("TRANSITION REPLAY (2018-2024)", style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        if (selectedTab == 0) {
            items(researchStudies) { study ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = study.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = LondonGold
                            )
                            StatusBadge(text = study.studyId, color = YieldBlue)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Author: ${study.author} • Date: ${study.date} • Focus: ${study.benchmarkFocus}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextMuted,
                            fontSize = 10.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = study.abstractText,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextSecondary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Key Empirical Findings:", style = MaterialTheme.typography.labelSmall, color = LondonGold)
                        study.keyFindings.forEach { finding ->
                            Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                Text("• ", color = LondonGold)
                                Text(finding, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary, fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Python code snippet block
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CityNavyDark, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "# Reproducible Research Script (libor-os quant python)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = study.codeSnippet,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SterlingGreen,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Replay Backtesting
            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "HISTORICAL REGIME REPLAY SELECTOR",
                            style = MaterialTheme.typography.labelMedium,
                            color = LondonGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        listOf(
                            "2018 (Pre-Transition Baseline)",
                            "2021 (ISDA Protocol & GBP/JPY/CHF Cessation)",
                            "2023 (USD Panel Cessation / Synthetic USD Active)",
                            "2024 (Permanent Cessation of Final Synthetic Settings)"
                        ).forEach { yearLabel ->
                            val isSel = yearLabel == replayYear
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) CityNavyDark else Color.Transparent)
                                    .clickable { replayYear = yearLabel }
                                    .padding(vertical = 6.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSel,
                                    onClick = { replayYear = yearLabel },
                                    colors = RadioButtonDefaults.colors(selectedColor = LondonGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = yearLabel,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isSel) LondonGold else CityTextPrimary
                                )
                            }
                        }
                    }
                }
            }

            item {
                Surface(
                    color = CityNavySurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, SterlingGreen, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "HISTORICAL BACKTESTING REPLAY: $replayYear",
                            style = MaterialTheme.typography.titleMedium,
                            color = SterlingGreen
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when {
                                replayYear.contains("2018") -> "Pre-transition period: LIBOR fixings active with normal interbank credit spreads (USD 3M @ ~2.80%). Full panel submissions active."
                                replayYear.contains("2021") -> "Milestone 1: 31 December 2021. All GBP, EUR, CHF, and JPY panel settings permanently ceased. UK markets smoothly switched 98% of sterling swaps to SONIA."
                                replayYear.contains("2023") -> "Milestone 2: 30 June 2023. Final USD panel submissions ended. FCA permitted synthetic 1M, 3M, 6M USD LIBOR for legacy use only."
                                else -> "Final Milestone: 30 September 2024. All 35 LIBOR settings permanently ceased. Zero synthetic publications remain. All contracts operate under statutory safe harbors or transitioned RFRs."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextPrimary
                        )
                    }
                }
            }
        }
    }
}
