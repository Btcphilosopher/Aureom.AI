package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun FallbackEngineScreen(
    fallbackRules: List<FallbackRule>,
    spreadAdjustments: List<SpreadAdjustment>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Fallback Rules, 1: Spread Adjustment Table

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("fallback_engine_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "FALLBACK & SPREAD ADJUSTMENT ENGINE",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ISDA 2020 Protocol, ARRC Waterfall & Statutory Remediation Registry",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Sub Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CityNavyCard,
                contentColor = LondonGold,
                modifier = Modifier.border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("FALLBACK RULES & PROTOCOLS", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("OFFICIAL SPREAD REGISTRY", style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        if (selectedTab == 0) {
            // Fallback Rules list
            items(fallbackRules) { rule ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (rule.requiresReview) RiskCrimson else CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rule.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = LondonGold
                            )
                            StatusBadge(
                                text = if (rule.requiresReview) "REVIEW REQUIRED" else "PROTOCOL STANDARD",
                                color = if (rule.requiresReview) RiskCrimson else SterlingGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Source Benchmark:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text(rule.sourceBenchmark, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Fallback Target RFR:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text(rule.fallbackBenchmark, style = MaterialTheme.typography.bodySmall, color = SterlingGreen, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Spread Adjustment:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text("${String.format("%.3f", rule.spreadAdjustmentBps)} bps", style = MaterialTheme.typography.bodySmall, color = YieldBlue, fontFamily = FontFamily.Monospace)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Governing Law:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text(rule.governingLaw, style = MaterialTheme.typography.bodySmall, color = CityTextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CityNavyDark, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Contractual Snippet: \"${rule.contractualLanguageSnippet}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = CityTextSecondary,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        } else {
            // Official Spread Adjustment Registry Table
            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CityNavySurface)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("BENCHMARK", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.4f))
                            Text("TENOR", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(0.8f))
                            Text("5-YR SPREAD", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                            Text("SOURCE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.4f))
                        }

                        Divider(color = CityBorder, thickness = 0.5.dp)

                        spreadAdjustments.forEach { sa ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sa.sourceBenchmark,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CityTextPrimary,
                                    modifier = Modifier.weight(1.4f)
                                )
                                Text(
                                    text = sa.tenor.code,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = YieldBlue,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(0.8f)
                                )
                                Text(
                                    text = String.format("%.3f bps", sa.valueBps),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LondonGold,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1.2f)
                                )
                                Text(
                                    text = sa.source.take(18),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextMuted,
                                    fontSize = 9.sp,
                                    modifier = Modifier.weight(1.4f)
                                )
                            }
                            Divider(color = CityBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}
