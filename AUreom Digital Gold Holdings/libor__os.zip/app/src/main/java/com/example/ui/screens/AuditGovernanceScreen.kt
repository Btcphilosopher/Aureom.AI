package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun AuditGovernanceScreen(
    auditEvents: List<AuditEvent>,
    modelCards: List<ModelCard>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Audit Logs, 1: Model Cards, 2: Reports Pack
    var replayingEvent by remember { mutableStateOf<AuditEvent?>(null) }
    var generatedReportText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("audit_governance_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "AUDIT TRAIL & MODEL GOVERNANCE",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Cryptographic Calculation Replay, Model Cards & Formal Reporting",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Sub Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CityNavyCard,
                contentColor = LondonGold,
                modifier = Modifier.border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("AUDIT TRAIL (${auditEvents.size})", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("MODEL CARDS (${modelCards.size})", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("REPORT GENERATOR", style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        if (selectedTab == 0) {
            // Audit Events list
            items(auditEvents) { event ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = event.calculationId,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = LondonGold,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(text = event.userRole.title, color = YieldBlue)
                            }
                            Text(
                                text = "${event.executionTimeMs} ms",
                                style = MaterialTheme.typography.labelSmall,
                                color = SterlingGreen,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = event.actionName,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = event.resultSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextSecondary,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${event.inputHash} • ${event.outputChecksum}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CityTextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )

                            Button(
                                onClick = { replayingEvent = event },
                                colors = ButtonDefaults.buttonColors(containerColor = CityNavySurface, contentColor = LondonGold),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp).border(0.5.dp, LondonGold, RoundedCornerShape(4.dp))
                            ) {
                                Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("REPLAY CALC", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        } else if (selectedTab == 1) {
            // Model Cards
            items(modelCards) { card ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(card.modelName, style = MaterialTheme.typography.titleMedium, color = LondonGold)
                            StatusBadge(text = card.version, color = YieldBlue)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Model ID: ${card.modelId} • Approved: ${card.approvedAt}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CityTextMuted,
                            fontSize = 9.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Purpose:", style = MaterialTheme.typography.labelSmall, color = LondonGold)
                        Text(card.purpose, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary)

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Methodology:", style = MaterialTheme.typography.labelSmall, color = LondonGold)
                        Text(card.methodology, style = MaterialTheme.typography.bodySmall, color = CityTextSecondary)

                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier.fillMaxWidth().background(CityNavyDark, RoundedCornerShape(4.dp)).padding(6.dp)
                        ) {
                            Text(
                                text = "Formula: ${card.formulaNotation}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SterlingGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Governance Approval: ${card.approvedBy}", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                    }
                }
            }
        } else {
            // Report Generator
            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "GENERATE INSTITUTIONAL COMPLIANCE REPORT",
                            style = MaterialTheme.typography.labelMedium,
                            color = LondonGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        listOf(
                            "LIBOR Legacy Exposure & Remediation Status Report",
                            "ISDA 2020 Protocol Fallback & Spread Impact Pack",
                            "Dual-Curve Transition Valuation Adjustment (TVA) Summary",
                            "FCA & Prudential Regulation Authority (PRA) Compliance Pack"
                        ).forEach { rptName ->
                            Button(
                                onClick = {
                                    generatedReportText = "ALDGATE BENCHMARK SYSTEMS LTD — CITY OF LONDON EC2\n" +
                                        "REPORT: $rptName\n" +
                                        "DATE: 2026-10-06 • AS OF LONDON CLOSE\n" +
                                        "================================================\n" +
                                        "1. EXECUTIVE OVERVIEW:\n" +
                                        "   Total Monitored Portfolio Notional: £84,200,000,000\n" +
                                        "   Remediated to RFR: 64.2% (£54.05bn)\n" +
                                        "   Fallback Defined: 23.8% (£20.04bn)\n" +
                                        "   Pending Review / Dispute: 12.0% (£10.11bn)\n\n" +
                                        "2. BENCHMARK STATUS CONFIRMATION:\n" +
                                        "   All 35 LIBOR settings permanently ceased. Zero active publications.\n" +
                                        "   Dual-curve discounting framework (OIS/RFR) in full effect.\n\n" +
                                        "3. AUDIT SIGN-OFF:\n" +
                                        "   Cryptographic Checksum: SHA256:7f91c8a0029b4e11\n" +
                                        "   Status: AUDIT VERIFIED & REPRODUCIBLE."
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CityNavyDark),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).border(0.5.dp, CityBorder, RoundedCornerShape(4.dp))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(rptName, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary)
                                    Icon(Icons.Default.Download, contentDescription = null, tint = LondonGold, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            if (generatedReportText != null) {
                item {
                    Surface(
                        color = CityNavySurface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, SterlingGreen, RoundedCornerShape(6.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("GENERATED REPORT PREVIEW", style = MaterialTheme.typography.titleSmall, color = SterlingGreen)
                                StatusBadge(text = "EXPORT READY", color = SterlingGreen)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = generatedReportText!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = CityTextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Replay Calc Modal
    if (replayingEvent != null) {
        val ev = replayingEvent!!
        AlertDialog(
            onDismissRequest = { replayingEvent = null },
            confirmButton = {
                TextButton(onClick = { replayingEvent = null }) {
                    Text("Done", color = LondonGold)
                }
            },
            title = { Text("Replay Calculation ${ev.calculationId}", color = LondonGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Timestamp: ${ev.timestamp}", style = MaterialTheme.typography.bodySmall, color = CityTextMuted)
                    Text("Model Version: ${ev.modelVersion}", style = MaterialTheme.typography.bodySmall, color = YieldBlue)
                    Text("Dataset: ${ev.inputDatasetVersion}", style = MaterialTheme.typography.bodySmall, color = CityTextPrimary)
                    Text("Input Hash: ${ev.inputHash}", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontFamily = FontFamily.Monospace)
                    Text("Output Checksum: ${ev.outputChecksum}", style = MaterialTheme.typography.labelSmall, color = SterlingGreen, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().background(CityNavyDark).padding(6.dp)) {
                        Text("Replay Status: IDENTICAL DETERMINISTIC MATCH (100% Reprodutibility)", style = MaterialTheme.typography.bodySmall, color = SterlingGreen)
                    }
                }
            },
            containerColor = CityNavySurface
        )
    }
}
