package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = LondonGold,
    onPrimary = CityNavyDark,
    primaryContainer = CityNavyCard,
    onPrimaryContainer = LondonGold,
    secondary = YieldBlue,
    onSecondary = CityNavyDark,
    secondaryContainer = CityNavyCardHover,
    onSecondaryContainer = YieldBlue,
    tertiary = SterlingGreen,
    onTertiary = CityNavyDark,
    background = CityNavyDark,
    onBackground = CityTextPrimary,
    surface = CityNavySurface,
    onSurface = CityTextPrimary,
    surfaceVariant = CityNavyCard,
    onSurfaceVariant = CityTextSecondary,
    outline = CityBorder,
    outlineVariant = CityBorderLight,
    error = RiskCrimson,
    onError = CityNavyDark,
    errorContainer = RiskCrimsonDark,
    onErrorContainer = CityTextPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = CityLightSurface,
    primaryContainer = CityLightCard,
    onPrimaryContainer = CityLightTextPrimary,
    secondary = YieldBlueDark,
    onSecondary = CityLightSurface,
    tertiary = SterlingGreenDark,
    onTertiary = CityLightSurface,
    background = CityLightBackground,
    onBackground = CityLightTextPrimary,
    surface = CityLightSurface,
    onSurface = CityLightTextPrimary,
    surfaceVariant = CityLightCard,
    onSurfaceVariant = CityLightTextSecondary,
    outline = CityLightBorder,
    outlineVariant = CityLightBorder,
    error = RiskCrimson,
    onError = CityLightSurface
)

@Composable
fun LiborOsTheme(
    darkTheme: Boolean = true, // Default to Institutional Dark Terminal theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
