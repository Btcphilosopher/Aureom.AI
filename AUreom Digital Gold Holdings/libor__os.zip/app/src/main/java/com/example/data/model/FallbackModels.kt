package com.example.data.model

enum class FallbackFramework(val title: String, val issuingBody: String) {
    ISDA_PROTOCOL_2020("ISDA 2020 IBOR Fallbacks Protocol", "International Swaps and Derivatives Association"),
    ARRC_HARDWIRED("ARRC Hardwired Fallback Language", "Alternative Reference Rates Committee (US Fed)"),
    STERLING_RFR_STATUTORY("UK Sterling RFR WG Statutory Transition", "Bank of England / Working Group on Sterling RFRs"),
    EU_BMR_STATUTORY("EU BMR Statutory Replacement (Art. 23b)", "European Commission / ESMA"),
    SWISS_NWG_RECOMMENDATION("Swiss NWG SARON Recommendations", "National Working Group on Swiss Franc Reference Rates"),
    BESPOKE_CONTRACTUAL("Bespoke Bilateral Contractual Amendment", "Contracting Parties")
}

enum class FallbackTrigger(val title: String, val isPreCessation: Boolean) {
    PERMANENT_CESSATION("Permanent Cessation of Benchmark", false),
    NON_REPRESENTATIVENESS("Pre-Cessation Statement of Non-Representativeness", true),
    STATUTORY_OVERRIDE("Statutory Regulatory Designator Trigger", false),
    CONTRACT_AMENDMENT("Mutual Agreement & Consent", false)
}

enum class SpreadAdjustmentMethod(val title: String, val defaultSource: String) {
    HISTORICAL_MEDIAN_5YR("5-Year Historical Median Spread (Bloomberg/ISDA Official)", "ISDA / Bloomberg Calculation Agent (30 Sep 2024 Final)"),
    STATUTORY_SYNTHETIC("Statutory Synthetic Spread (FCA Designated)", "FCA Article 23D Benchmarks Regulation"),
    CONTRACTUAL_AGREED("Contractually Agreed Basis", "Executed Amendment Annex"),
    USER_OVERRIDE("User-Defined Modeling Override", "Aldgate Quantitative Lab")
}

data class SpreadAdjustment(
    val id: String,
    val sourceBenchmark: String,
    val fallbackBenchmark: String,
    val tenor: Tenor,
    val currency: Currency,
    val methodology: SpreadAdjustmentMethod,
    val effectiveDate: String,
    val valueBps: Double,
    val source: String,
    val version: String,
    val approvedDate: String,
    val provenanceHash: String
)

data class FallbackRule(
    val ruleId: String,
    val title: String,
    val sourceBenchmark: String,
    val fallbackBenchmark: String,
    val tenor: Tenor,
    val trigger: FallbackTrigger,
    val spreadAdjustmentBps: Double,
    val spreadMethodology: SpreadAdjustmentMethod,
    val observationMethod: String,
    val effectiveDate: String,
    val contractualLanguageSnippet: String,
    val governingLaw: String,
    val framework: FallbackFramework,
    val requiresReview: Boolean = false
)
