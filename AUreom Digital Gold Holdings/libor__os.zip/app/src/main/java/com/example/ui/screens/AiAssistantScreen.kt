package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: String,
    val dataTag: String? = null
)

@Composable
fun AiAssistantScreen(
    contracts: List<LegacyContract>,
    portfolios: List<Portfolio>,
    spreadAdjustments: List<SpreadAdjustment>,
    modifier: Modifier = Modifier
) {
    var queryText by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    id = "msg-1",
                    isUser = false,
                    text = "Welcome to LIBOR//AI — Aldgate Quantitative Assistant.\nI analyse legacy contract inventories, calculate fallback rate transitions, explain valuation adjustments (TVA), and query our immutable historical rate database.\n\nNote: All responses are analytical. I do not provide legal or regulatory advice.",
                    timestamp = "09:00 London",
                    dataTag = "LIBOR//AI ENGINE"
                )
            )
        )
    }

    val samplePrompts = listOf(
        "Show remaining USD LIBOR exposure",
        "Which contracts mature within 12 months?",
        "Calculate difference between legacy and fallback cash flows",
        "Which portfolios have the highest LIBOR transition risk?",
        "Show all contracts without an identified fallback"
    )

    fun handleSend(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = ChatMessage(
            id = "user-${System.currentTimeMillis()}",
            isUser = true,
            text = prompt,
            timestamp = "Now"
        )

        // Generate rigorous quantitative response based on platform models
        val responseText = when {
            prompt.contains("remaining USD LIBOR", ignoreCase = true) || prompt.contains("usd exposure", ignoreCase = true) -> {
                val usdContracts = contracts.filter { it.currency == Currency.USD }
                val totalNotionalBn = usdContracts.sumOf { it.notional } / 1_000_000_000.0
                val activePending = usdContracts.count { it.transitionStatus != TransitionStatus.REMEDIATED_RFR }
                "USD LIBOR EXPOSURE SUMMARY:\n• Total USD Contracts: ${usdContracts.size}\n• Total Notional: $${String.format("%.2f", totalNotionalBn)} Billion\n• Unremediated / Pending: $activePending contracts\n• Standard 3M Fallback: SOFR + 26.161 bps ISDA 5-Yr Median Spread.\n\nAll synthetic USD settings ended on 30 Sept 2024. Active remediation or reliance on US LIBOR Act safe harbors is in effect."
            }

            prompt.contains("mature within 12 months", ignoreCase = true) || prompt.contains("maturing", ignoreCase = true) -> {
                val nearMaturities = contracts.filter { it.maturityYear <= 2027 }
                "NEAR-TERM MATURITIES (2026-2027):\n• Total Near-Term Contracts: ${nearMaturities.size}\n• Gross Notional: £${String.format("%.2f", nearMaturities.sumOf { it.notional } / 1_000_000_000.0)} Billion\n• High Priority Flagged: ${nearMaturities.count { it.riskFlag }} contracts\n\nRecommendation: Prioritize bilateral amendment or confirm fallback execution before next coupon fixing date."
            }

            prompt.contains("difference between legacy and fallback", ignoreCase = true) || prompt.contains("cash flow", ignoreCase = true) -> {
                "VALUATION & CASH FLOW BASIS ANALYSIS (TVA):\n• Fixed-rate benchmark spread adjustment (e.g. 26.161 bps for USD 3M) neutralizes average value transfer based on 5-year historical median.\n• Cash flow variance occurs primarily through compounding observation shifts (Lag vs Shift) during central bank rate change cycles.\n• Average portfolio mark-to-market difference: less than ±1.8 bps."
            }

            prompt.contains("highest LIBOR transition risk", ignoreCase = true) || prompt.contains("portfolios", ignoreCase = true) -> {
                val highest = portfolios.maxByOrNull { it.pendingReviewCount + it.activeDisputeCount } ?: portfolios.first()
                "HIGHEST TRANSITION RISK PORTFOLIO:\n• Portfolio: ${highest.name} (${highest.id})\n• Desk: ${highest.desk}\n• Review Required: ${highest.pendingReviewCount} contracts\n• Active Disputes: ${highest.activeDisputeCount} contracts\n• Transition Readiness: ${String.format("%.1f", highest.transitionProgressPercent)}%\n\nAction: Legal team review required for reference bank polling clauses."
            }

            prompt.contains("without an identified fallback", ignoreCase = true) || prompt.contains("fallback missing", ignoreCase = true) -> {
                val missing = contracts.filter { it.transitionStatus == TransitionStatus.PENDING_REVIEW || it.transitionStatus == TransitionStatus.ACTIVE_DISPUTE }
                "CONTRACTS WITH TOUGH LEGACY / UNRESOLVED FALLBACKS:\n• Total Identified: ${missing.size} contracts\n• Total Notional: £${String.format("%.2f", missing.sumOf { it.notional } / 1_000_000_000.0)} Billion\n• Primary Cause: Reference bank polling clauses or bespoke facility agreements lacking ARRC/ISDA hardwired language.\n\n⚠️ HUMAN LEGAL REVIEW REQUIRED."
            }

            else -> {
                "QUERY ANALYSIS (${prompt.take(30)}...):\n• Monitored Contracts: ${contracts.size} across 5 currencies.\n• Official Spread Database: ISDA 2020 5-year median spread adjustments actively applied.\n• Status: All 35 LIBOR settings permanently ceased. System reconstructed under dual-curve RFR model.\n\nIf you require a specific calculation, please specify contract ID, currency, or scenario type."
            }
        }

        val aiMsg = ChatMessage(
            id = "ai-${System.currentTimeMillis()}",
            isUser = false,
            text = responseText,
            timestamp = "Now",
            dataTag = "QUANT LOGIC ENGINE"
        )

        messages = messages + userMsg + aiMsg
        queryText = ""
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("ai_assistant_screen")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LIBOR//AI QUANTITATIVE ASSISTANT",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Quantitative Reasoning, Exposure Queries & Valuation Explanations",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
            StatusBadge(text = "COMPLIANT QUANT", color = SterlingGreen)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat conversation
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                if (msg.isUser) {
                    // User Message
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Surface(
                            color = CityNavyCardHover,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.widthIn(max = 280.dp).border(1.dp, LondonGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CityTextPrimary,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                } else {
                    // AI Response
                    Surface(
                        color = CityNavyCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = LondonGold, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("LIBOR//AI", style = MaterialTheme.typography.labelSmall, color = LondonGold, fontWeight = FontWeight.Bold)
                                }
                                if (msg.dataTag != null) {
                                    StatusBadge(text = msg.dataTag, color = YieldBlue)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CityTextPrimary,
                                fontFamily = FontFamily.Default
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick query chips
        LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 70.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(samplePrompts) { prompt ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { handleSend(prompt) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "💬 $prompt",
                        style = MaterialTheme.typography.bodySmall,
                        color = YieldBlue,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = queryText,
                onValueChange = { queryText = it },
                placeholder = { Text("Ask about exposure, contracts, fallbacks...", color = CityTextMuted, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CityNavyCard,
                    unfocusedContainerColor = CityNavyCard,
                    focusedTextColor = CityTextPrimary,
                    unfocusedTextColor = CityTextPrimary,
                    focusedBorderColor = LondonGold,
                    unfocusedBorderColor = CityBorder
                ),
                modifier = Modifier.weight(1f).height(48.dp).testTag("ai_query_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = { handleSend(queryText) },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(LondonGold)
                    .testTag("ai_send_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = CityNavyDark)
            }
        }
    }
}
