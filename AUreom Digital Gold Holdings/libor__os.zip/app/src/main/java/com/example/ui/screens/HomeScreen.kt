package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    contracts: List<LegacyContract>,
    portfolios: List<Portfolio>,
    isDemoRunning: Boolean,
    demoProgress: Float,
    demoLogs: List<String>,
    onNavigateTab: (Int) -> Unit,
    onRunDemo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalNotionalBn = contracts.sumOf { it.notional } / 1_000_000_000.0
    val totalContractsCount = contracts.size
    val remediatedCount = contracts.count { it.transitionStatus == TransitionStatus.REMEDIATED_RFR }
    val fallbackDefinedCount = contracts.count { it.transitionStatus == TransitionStatus.FALLBACK_DEFINED }
    val pendingReviewCount = contracts.count { it.transitionStatus == TransitionStatus.PENDING_REVIEW }
    val activeDisputeCount = contracts.count { it.transitionStatus == TransitionStatus.ACTIVE_DISPUTE }
    val syntheticTransitionedCount = contracts.count { it.transitionStatus == TransitionStatus.SYNTHETIC_TRANSITIONED }

    val usdCount = contracts.count { it.currency == Currency.USD }
    val gbpCount = contracts.count { it.currency == Currency.GBP }
    val eurCount = contracts.count { it.currency == Currency.EUR }
    val otherCount = contracts.count { it.currency == Currency.CHF || it.currency == Currency.JPY }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Card with City of London branding
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CityBorder, RoundedCornerShape(8.dp))
            ) {
                Column {
                    // Optional City of London Hero Image
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                    ) {
                        Image(
                            painter = painterResource(id = com.example.R.drawable.london_city_hero_1791289572337),
                            contentDescription = "City of London Financial District",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        // Gradient overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, CityNavyCard)
                                    )
                                )
                        )
                        Box(
                            modifier = Modifier
                                .padding(10.dp)
                                .align(Alignment.BottomStart)
                        ) {
                            StatusBadge(text = "SYNTHETIC DEMO PLATFORM", color = LondonGold)
                        }
                    }

                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "LIBOR//OS CONTROL ROOM",
                            style = MaterialTheme.typography.headlineMedium,
                            color = LondonGold,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "City of London quantitative benchmark transition, legacy contract remediation, and multi-curve valuation intelligence engine.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CityTextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LegalWarningBanner()
                    }
                }
            }
        }

        // Demo Progress Banner if running
        if (isDemoRunning || demoLogs.isNotEmpty()) {
            item {
                Surface(
                    color = CityNavySurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LondonGold, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = null,
                                    tint = LondonGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "DEMONSTRATION PIPELINE: libor-os demo",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = LondonGold
                                )
                            }
                            Text(
                                text = "${(demoProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = LondonGold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { demoProgress },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = LondonGold,
                            trackColor = CityNavyCard
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Terminal Log Output
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CityNavyDark, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            demoLogs.takeLast(4).forEach { logLine ->
                                Text(
                                    text = logLine,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SterlingGreen,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Primary Metric Cards Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "Legacy Contracts",
                        value = "12,480",
                        subValue = "Active Monitored Inventory",
                        badgeText = "SYNTHETIC",
                        badgeColor = YieldBlue,
                        accentColor = LondonGold,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "Gross Exposure",
                        value = "£84.2B",
                        subValue = "5 Currencies (USD/GBP/EUR+)",
                        badgeText = "NOTIONAL",
                        badgeColor = SterlingGreen,
                        accentColor = YieldBlue,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "USD LIBOR Legacy",
                        value = "6,742",
                        subValue = "$52.8B Exposure",
                        badgeText = "CEASED",
                        badgeColor = RiskCrimson,
                        accentColor = CityTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "GBP LIBOR Legacy",
                        value = "3,918",
                        subValue = "£24.1B Exposure",
                        badgeText = "CEASED",
                        badgeColor = RiskCrimson,
                        accentColor = CityTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Transition Status Progress Bar
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PORTFOLIO REMEDIATION PROGRESS",
                            style = MaterialTheme.typography.titleMedium,
                            color = LondonGold
                        )
                        StatusBadge(
                            text = "88.0% PROTECTED",
                            color = SterlingGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Multi-segment progress bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                    ) {
                        Box(modifier = Modifier.weight(64.2f).fillMaxHeight().background(SterlingGreen))
                        Box(modifier = Modifier.weight(23.8f).fillMaxHeight().background(YieldBlue))
                        Box(modifier = Modifier.weight(8.5f).fillMaxHeight().background(BritishAmber))
                        Box(modifier = Modifier.weight(3.5f).fillMaxHeight().background(RiskCrimson))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(SterlingGreen, RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("RFR Remediated (64.2%)", style = MaterialTheme.typography.labelSmall, color = CityTextSecondary, fontSize = 9.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(YieldBlue, RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Fallback Defined (23.8%)", style = MaterialTheme.typography.labelSmall, color = CityTextSecondary, fontSize = 9.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(BritishAmber, RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Review Required (8.5%)", style = MaterialTheme.typography.labelSmall, color = CityTextSecondary, fontSize = 9.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(RiskCrimson, RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dispute (3.5%)", style = MaterialTheme.typography.labelSmall, color = CityTextSecondary, fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        // Quick Navigation Launchpad
        item {
            Text(
                text = "QUANTITATIVE WORKSTATIONS",
                style = MaterialTheme.typography.labelMedium,
                color = LondonGold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickNavButton(
                        title = "LIBOR History",
                        subtitle = "Fixings, Archive, IBA Status",
                        icon = Icons.Default.Timeline,
                        accentColor = YieldBlue,
                        onClick = { onNavigateTab(1) },
                        modifier = Modifier.weight(1f)
                    )
                    QuickNavButton(
                        title = "RFR Engine",
                        subtitle = "SONIA/SOFR Compounding",
                        icon = Icons.Default.Calculate,
                        accentColor = SterlingGreen,
                        onClick = { onNavigateTab(2) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickNavButton(
                        title = "Contract Scanner",
                        subtitle = "NLP Clause Diagnostics",
                        icon = Icons.Default.DocumentScanner,
                        accentColor = BritishAmber,
                        onClick = { onNavigateTab(5) },
                        modifier = Modifier.weight(1f)
                    )
                    QuickNavButton(
                        title = "Valuation & TVA",
                        subtitle = "Dual-Curve Loan & Swap PV",
                        icon = Icons.Default.ShowChart,
                        accentColor = LondonGold,
                        onClick = { onNavigateTab(7) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Footer Principle
        item {
            FooterBanner(modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun QuickNavButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CityNavyCard,
        shape = RoundedCornerShape(6.dp),
        onClick = onClick,
        modifier = modifier
            .border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            .testTag("nav_btn_${title.lowercase().replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = CityTextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}
