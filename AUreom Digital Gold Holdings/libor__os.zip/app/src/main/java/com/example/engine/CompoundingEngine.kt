package com.example.engine

import com.example.data.model.*
import java.text.DecimalFormat
import kotlin.math.*

object CompoundingEngine {

    /**
     * Standard ISDA 2020 / Sterling RFR Working Group Daily RFR Compounding in Arrears
     * Formula:
     *   Factor = Product_{i=1}^{d_b} [ 1 + (r_i * n_i) / DayCountBasis ]
     *   CompoundedRate = [ Factor - 1 ] * (DayCountBasis / totalDays)
     */
    fun calculateCompoundedRate(
        baseObservations: List<Pair<String, Double>>, // (Date, Daily Rate in %)
        notional: Double = 10_000_000.0,
        marginBps: Double = 150.0, // 1.50%
        compoundingMethod: CompoundingMethod = CompoundingMethod.COMPOUNDED_ARREARS,
        observationConvention: ObservationConvention = ObservationConvention.OBSERVATION_SHIFT,
        lookbackDays: Int = 5,
        lockoutDays: Int = 0,
        dayCount: DayCountConvention = DayCountConvention.ACT_365F,
        startDate: String = "2026-07-01",
        endDate: String = "2026-10-01"
    ): CompoundingResult {
        val basis = dayCount.annualDays
        val dailyList = mutableListOf<DailyRfrObservation>()

        val rawList = if (baseObservations.isEmpty()) {
            generateSyntheticDailyFixings(startDate, 90, 4.85)
        } else {
            baseObservations
        }

        var cumulativeProduct = 1.0
        var totalWeightedRateSum = 0.0
        var totalDays = 0

        // Handle lockout: freeze rate for last N days
        val effectiveRates = rawList.mapIndexed { index, pair ->
            val rate = if (lockoutDays > 0 && index >= rawList.size - lockoutDays && rawList.isNotEmpty()) {
                val freezeIndex = (rawList.size - lockoutDays - 1).coerceAtLeast(0)
                rawList[freezeIndex].second
            } else {
                pair.second
            }
            Pair(pair.first, rate)
        }

        effectiveRates.forEachIndexed { index, (date, ratePercent) ->
            // Determine day weight (e.g. Friday gets 3 days over weekend)
            val weight = if (index % 5 == 4) 3 else 1
            val dailyRateDecimal = (ratePercent / 100.0)

            when (compoundingMethod) {
                CompoundingMethod.COMPOUNDED_ARREARS, CompoundingMethod.COMPOUNDED_ADVANCE -> {
                    val singleDayFactor = 1.0 + (dailyRateDecimal * weight / basis)
                    cumulativeProduct *= singleDayFactor
                }
                CompoundingMethod.WEIGHTED_AVERAGE, CompoundingMethod.SIMPLE_RATE -> {
                    totalWeightedRateSum += (ratePercent * weight)
                }
            }

            totalDays += weight
            val currentCompoundedAnnual = if (compoundingMethod == CompoundingMethod.COMPOUNDED_ARREARS || compoundingMethod == CompoundingMethod.COMPOUNDED_ADVANCE) {
                ((cumulativeProduct - 1.0) * (basis / totalDays)) * 100.0
            } else {
                totalWeightedRateSum / totalDays
            }

            dailyList.add(
                DailyRfrObservation(
                    date = date,
                    ratePercent = ratePercent,
                    weightDays = weight,
                    compoundingFactor = cumulativeProduct,
                    cumulativeRate = currentCompoundedAnnual
                )
            )
        }

        val finalAnnualCompoundedPercent = if (compoundingMethod == CompoundingMethod.COMPOUNDED_ARREARS || compoundingMethod == CompoundingMethod.COMPOUNDED_ADVANCE) {
            ((cumulativeProduct - 1.0) * (basis / totalDays.coerceAtLeast(1))) * 100.0
        } else {
            totalWeightedRateSum / totalDays.coerceAtLeast(1)
        }

        val allInRatePercent = finalAnnualCompoundedPercent + (marginBps / 100.0)
        val interestFraction = totalDays / basis
        val totalInterestAmount = notional * (allInRatePercent / 100.0) * interestFraction

        val formulaText = when (compoundingMethod) {
            CompoundingMethod.COMPOUNDED_ARREARS ->
                "Compounded in Arrears: [ ∏_{i=1}^{$totalDays} (1 + (r_i × n_i)/${basis.toInt()}) - 1 ] × (${basis.toInt()}/$totalDays) + ${marginBps}bps"
            CompoundingMethod.WEIGHTED_AVERAGE ->
                "Weighted Average: [ ∑ (r_i × n_i) / $totalDays ] + ${marginBps}bps"
            CompoundingMethod.COMPOUNDED_ADVANCE ->
                "Compounded in Advance (Historical window): Lag $lookbackDays BD + ${marginBps}bps"
            CompoundingMethod.SIMPLE_RATE ->
                "Simple Spot Fix + ${marginBps}bps"
        }

        return CompoundingResult(
            startDate = startDate,
            endDate = endDate,
            compoundingMethod = compoundingMethod,
            observationConvention = observationConvention,
            lookbackDays = lookbackDays,
            lockoutDays = lockoutDays,
            dayCount = dayCount,
            notional = notional,
            marginBps = marginBps,
            compoundedRatePercent = finalAnnualCompoundedPercent,
            allInRatePercent = allInRatePercent,
            totalInterestAmount = totalInterestAmount,
            observationCount = effectiveRates.size,
            totalPeriodDays = totalDays,
            dailyObservations = dailyList,
            formulaExplanation = formulaText
        )
    }

    fun generateSyntheticDailyFixings(startDate: String, days: Int, baseRate: Double): List<Pair<String, Double>> {
        val list = mutableListOf<Pair<String, Double>>()
        var curRate = baseRate
        for (i in 0 until days) {
            val drift = (sin(i * 0.15) * 0.04) + ((i % 7 - 3) * 0.008)
            curRate = (curRate + drift).coerceIn(0.01, 8.5)
            val dayStr = String.format("D+%02d", i + 1)
            list.add(Pair(dayStr, curRate))
        }
        return list
    }
}
