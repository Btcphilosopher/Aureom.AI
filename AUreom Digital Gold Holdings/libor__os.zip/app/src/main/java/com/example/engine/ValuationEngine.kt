package com.example.engine

import com.example.data.model.*
import kotlin.math.*

object ValuationEngine {

    /**
     * Prices a Floating Rate Loan under both Legacy LIBOR and Transitioned RFR + Spread Adjustment.
     * Computes Transition Valuation Adjustment (TVA), DV01, Duration, and Cash Flow Schedule.
     */
    fun valueFloatingRateLoan(
        contract: LegacyContract,
        discountCurve: YieldCurve = CurveEngine.buildStandardCurve(contract.currency, "RFR_OIS")
    ): LoanValuationResult {
        val frequencyMonths = when (contract.paymentFrequency) {
            "Monthly" -> 1
            "Quarterly" -> 3
            "Semi-Annual" -> 6
            "Annual" -> 12
            else -> 3
        }

        val totalYears = (contract.maturityYear - 2026).coerceIn(1, 15)
        val totalPeriods = (totalYears * 12) / frequencyMonths
        val dtYears = frequencyMonths / 12.0

        val officialSpreadBps = SpreadEngine.getOfficialSpreadBps(contract.currency, contract.tenor)
        val baseRfrRate = when (contract.currency) {
            Currency.GBP -> 4.80
            Currency.USD -> 4.55
            Currency.EUR -> 3.30
            Currency.CHF -> 1.10
            Currency.JPY -> 0.35
        }

        val cashFlows = mutableListOf<CashFlowItem>()
        var remainingPrincipal = contract.notional
        val principalPaymentPerPeriod = when (contract.amortisationType) {
            AmortisationType.LINEAR -> contract.notional / totalPeriods
            AmortisationType.BULLET -> 0.0
            else -> 0.0
        }

        var totalLegacyPv = 0.0
        var totalTransitionPv = 0.0
        var weightedTimeSum = 0.0
        var totalInterestLegacy = 0.0
        var totalInterestTransition = 0.0

        for (p in 1..totalPeriods) {
            val tYears = p * dtYears
            val df = CurveEngine.interpolateDiscountFactor(discountCurve, tYears)

            val currentPrincipalAtStart = remainingPrincipal
            val principalPaidThisPeriod = if (p == totalPeriods && contract.amortisationType == AmortisationType.BULLET) {
                contract.notional
            } else {
                principalPaymentPerPeriod
            }

            // Legacy LIBOR rate projection (assumes higher credit risk premium)
            val legacyBenchmarkRate = baseRfrRate + (officialSpreadBps / 100.0)
            val legacyAllInRate = legacyBenchmarkRate + (contract.contractualMarginBps / 100.0)
            val legacyInterest = currentPrincipalAtStart * (legacyAllInRate / 100.0) * dtYears

            // Transitioned RFR Rate (RFR + Contract Margin + Fallback Spread Adjustment)
            val transitionAllInRate = baseRfrRate + ((contract.contractualMarginBps + officialSpreadBps) / 100.0)
            val transitionInterest = currentPrincipalAtStart * (transitionAllInRate / 100.0) * dtYears

            totalInterestLegacy += legacyInterest
            totalInterestTransition += transitionInterest

            val legacyTotalCf = principalPaidThisPeriod + legacyInterest
            val transitionTotalCf = principalPaidThisPeriod + transitionInterest

            val discountedLegacyCf = legacyTotalCf * df
            val discountedTransitionCf = transitionTotalCf * df

            totalLegacyPv += discountedLegacyCf
            totalTransitionPv += discountedTransitionCf
            weightedTimeSum += (tYears * discountedTransitionCf)

            remainingPrincipal = (remainingPrincipal - principalPaidThisPeriod).coerceAtLeast(0.0)

            val startYear = 2026 + ((p - 1) * frequencyMonths) / 12
            val endYear = 2026 + (p * frequencyMonths) / 12
            val paymentDate = String.format("%04d-%02d-15", endYear, ((p * frequencyMonths) % 12).let { if (it == 0) 12 else it })

            cashFlows.add(
                CashFlowItem(
                    periodIndex = p,
                    startDate = String.format("%04d-%02d-15", startYear, (((p - 1) * frequencyMonths) % 12).let { if (it == 0) 12 else it }),
                    endDate = paymentDate,
                    paymentDate = paymentDate,
                    accrualFraction = dtYears,
                    baseBenchmarkRatePercent = baseRfrRate,
                    spreadBps = contract.contractualMarginBps + officialSpreadBps,
                    allInRatePercent = transitionAllInRate,
                    notionalAmount = currentPrincipalAtStart,
                    principalPayment = principalPaidThisPeriod,
                    interestPayment = transitionInterest,
                    totalCashFlow = transitionTotalCf,
                    discountFactor = df,
                    discountedCashFlow = discountedTransitionCf,
                    isLegacyLibor = false
                )
            )
        }

        val durationYears = if (totalTransitionPv > 0) weightedTimeSum / totalTransitionPv else dtYears
        // DV01: Dollar value of 1 basis point change (Duration * PV * 0.0001)
        val dv01 = totalTransitionPv * durationYears * 0.0001
        val pvDifference = totalTransitionPv - totalLegacyPv
        val pvDiffPercent = if (totalLegacyPv != 0.0) (pvDifference / totalLegacyPv) * 100.0 else 0.0

        return LoanValuationResult(
            contractId = contract.contractId,
            currency = contract.currency,
            initialNotional = contract.notional,
            legacyPv = totalLegacyPv,
            transitionPv = totalTransitionPv,
            pvDifference = pvDifference,
            pvDifferencePercent = pvDiffPercent,
            parRatePercent = baseRfrRate + (officialSpreadBps / 100.0) + (contract.contractualMarginBps / 100.0),
            durationYears = durationYears,
            dv01 = dv01,
            totalInterestLegacy = totalInterestLegacy,
            totalInterestTransition = totalInterestTransition,
            cashFlowSchedule = cashFlows
        )
    }

    /**
     * Prices an Interest Rate Swap (IRS) Fixed vs Floating.
     */
    fun valueInterestRateSwap(
        swapId: String,
        currency: Currency,
        notional: Double = 50_000_000.0,
        fixedRatePercent: Double = 4.25,
        floatingBenchmark: String = "USD SOFR Compounded 3M",
        fallbackSpreadBps: Double = 26.161,
        tenorYears: Int = 5,
        discountCurve: YieldCurve = CurveEngine.buildStandardCurve(currency, "OIS_DISCOUNT")
    ): SwapValuationResult {
        val periods = tenorYears * 2 // Semi-annual fixed
        val dtYears = 0.5

        val fixedFlows = mutableListOf<CashFlowItem>()
        val floatingFlows = mutableListOf<CashFlowItem>()

        var fixedPv = 0.0
        var floatingPv = 0.0
        var weightedTimeSum = 0.0

        val baseFloatingRate = when (currency) {
            Currency.USD -> 4.50
            Currency.GBP -> 4.75
            Currency.EUR -> 3.25
            Currency.CHF -> 1.05
            Currency.JPY -> 0.30
        }

        for (p in 1..periods) {
            val tYears = p * dtYears
            val df = CurveEngine.interpolateDiscountFactor(discountCurve, tYears)

            val fixedInterest = notional * (fixedRatePercent / 100.0) * dtYears
            val discountedFixed = fixedInterest * df
            fixedPv += discountedFixed

            val floatingAllIn = baseFloatingRate + (fallbackSpreadBps / 100.0)
            val floatingInterest = notional * (floatingAllIn / 100.0) * dtYears
            val discountedFloating = floatingInterest * df
            floatingPv += discountedFloating

            weightedTimeSum += tYears * discountedFloating

            val payDate = String.format("2026-%02d-20", ((p * 6) % 12).let { if (it == 0) 12 else it })

            fixedFlows.add(
                CashFlowItem(
                    periodIndex = p,
                    startDate = "T0",
                    endDate = payDate,
                    paymentDate = payDate,
                    accrualFraction = dtYears,
                    baseBenchmarkRatePercent = fixedRatePercent,
                    spreadBps = 0.0,
                    allInRatePercent = fixedRatePercent,
                    notionalAmount = notional,
                    principalPayment = 0.0,
                    interestPayment = fixedInterest,
                    totalCashFlow = fixedInterest,
                    discountFactor = df,
                    discountedCashFlow = discountedFixed,
                    isLegacyLibor = false
                )
            )

            floatingFlows.add(
                CashFlowItem(
                    periodIndex = p,
                    startDate = "T0",
                    endDate = payDate,
                    paymentDate = payDate,
                    accrualFraction = dtYears,
                    baseBenchmarkRatePercent = baseFloatingRate,
                    spreadBps = fallbackSpreadBps,
                    allInRatePercent = floatingAllIn,
                    notionalAmount = notional,
                    principalPayment = 0.0,
                    interestPayment = floatingInterest,
                    totalCashFlow = floatingInterest,
                    discountFactor = df,
                    discountedCashFlow = discountedFloating,
                    isLegacyLibor = false
                )
            )
        }

        val netPv = floatingPv - fixedPv
        val annuity = (1..periods).sumOf { p -> dtYears * CurveEngine.interpolateDiscountFactor(discountCurve, p * dtYears) }
        val parSwapRate = if (annuity > 0) (floatingPv / (notional * annuity)) * 100.0 else fixedRatePercent
        val durationYears = if (floatingPv > 0) weightedTimeSum / floatingPv else dtYears
        val dv01 = notional * annuity * 0.0001
        val pv01 = annuity * 0.0001 * 10000

        return SwapValuationResult(
            swapId = swapId,
            fixedLegPv = fixedPv,
            floatingLegPv = floatingPv,
            netPv = netPv,
            parSwapRate = parSwapRate,
            dv01 = dv01,
            pv01 = pv01,
            durationYears = durationYears,
            transitionValuationAdjustment = (fallbackSpreadBps / 10000.0) * notional * annuity,
            fixedCashFlows = fixedFlows,
            floatingCashFlows = floatingFlows
        )
    }
}
