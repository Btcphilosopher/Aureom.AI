package com.example.data.model

enum class DayCountConvention(val label: String, val annualDays: Double) {
    ACT_360("Actual/360 (USD/EUR/CHF/JPY)", 360.0),
    ACT_365F("Actual/365 Fixed (GBP/SONIA)", 365.0),
    ACT_365("Actual/Actual", 365.25),
    THIRTY_360("30/360 Bond Basis", 360.0)
}

enum class BusinessDayConvention(val label: String) {
    MODIFIED_FOLLOWING("Modified Following"),
    FOLLOWING("Following"),
    PRECEDING("Preceding")
}

enum class CompoundingMethod(val label: String, val description: String) {
    COMPOUNDED_ARREARS("Compounded in Arrears", "Standard ISDA/Sterling RFR daily geometric compounding over observation period"),
    COMPOUNDED_ADVANCE("Compounded in Advance", "Known rate prior to period start using historical observation window"),
    WEIGHTED_AVERAGE("Weighted Daily Average", "Simple arithmetic weighted daily interest"),
    SIMPLE_RATE("Simple Interest", "Single terminal spot rate application")
}

enum class ObservationConvention(val label: String, val description: String) {
    LOOKBACK_WITHOUT_SHIFT("Lookback (Lag / Observation Period unchanged)", "Weights based on interest period days"),
    OBSERVATION_SHIFT("Observation Shift", "Weights based on observation period days (ARRC / ISDA 2020)"),
    LOCKOUT("Lockout (Rate Repeat)", "Fixing freezes N days prior to period end")
}

data class RiskFreeRate(
    val currency: Currency,
    val benchmarkName: String,
    val code: String,
    val administrator: String,
    val methodology: String,
    val currentRate: Double,
    val historicalAverage: Double,
    val publicationTime: String,
    val isSecured: Boolean,
    val targetVolumeBn: Double
)

data class DailyRfrObservation(
    val date: String,
    val ratePercent: Double,
    val weightDays: Int,
    val compoundingFactor: Double,
    val cumulativeRate: Double
)

data class CompoundingResult(
    val startDate: String,
    val endDate: String,
    val compoundingMethod: CompoundingMethod,
    val observationConvention: ObservationConvention,
    val lookbackDays: Int,
    val lockoutDays: Int,
    val dayCount: DayCountConvention,
    val notional: Double,
    val marginBps: Double,
    val compoundedRatePercent: Double,
    val allInRatePercent: Double,
    val totalInterestAmount: Double,
    val observationCount: Int,
    val totalPeriodDays: Int,
    val dailyObservations: List<DailyRfrObservation>,
    val formulaExplanation: String
)
