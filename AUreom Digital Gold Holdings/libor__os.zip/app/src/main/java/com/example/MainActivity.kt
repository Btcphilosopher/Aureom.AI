package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.LiborOsRepository
import com.example.ui.components.TerminalHeader
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val repository = LiborOsRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LiborOsTheme(darkTheme = true) {
                LiborOsMainApp(repository = repository)
            }
        }
    }
}

data class NavTabItem(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun LiborOsMainApp(
    repository: LiborOsRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTabIndex by remember { mutableStateOf(0) }

    val userRole by repository.currentUserRole.collectAsStateWithLifecycle()
    val benchmarks by repository.benchmarks.collectAsStateWithLifecycle()
    val rfrRates by repository.rfrRates.collectAsStateWithLifecycle()
    val spreadAdjustments by repository.spreadAdjustments.collectAsStateWithLifecycle()
    val fallbackRules by repository.fallbackRules.collectAsStateWithLifecycle()
    val contracts by repository.contracts.collectAsStateWithLifecycle()
    val portfolios by repository.portfolios.collectAsStateWithLifecycle()
    val auditEvents by repository.auditEvents.collectAsStateWithLifecycle()
    val modelCards by repository.modelCards.collectAsStateWithLifecycle()
    val researchStudies by repository.researchStudies.collectAsStateWithLifecycle()
    val isDemoRunning by repository.demoRunning.collectAsStateWithLifecycle()
    val demoProgress by repository.demoProgress.collectAsStateWithLifecycle()
    val demoLogs by repository.demoLog.collectAsStateWithLifecycle()

    val tabs = listOf(
        NavTabItem("HOME", Icons.Default.Dashboard),
        NavTabItem("LIBOR", Icons.Default.Timeline),
        NavTabItem("RFR", Icons.Default.Calculate),
        NavTabItem("COMPARE", Icons.Default.CompareArrows),
        NavTabItem("FALLBACK", Icons.Default.Rule),
        NavTabItem("CONTRACTS", Icons.Default.Description),
        NavTabItem("TRANSITION", Icons.Default.Transform),
        NavTabItem("VALUATION", Icons.Default.ShowChart),
        NavTabItem("CURVES", Icons.Default.StackedLineChart),
        NavTabItem("PORTFOLIOS", Icons.Default.PieChart),
        NavTabItem("RESEARCH", Icons.Default.Science),
        NavTabItem("LIBOR//AI", Icons.Default.AutoAwesome),
        NavTabItem("AUDIT", Icons.Default.VerifiedUser)
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(CityNavyDark)
            .testTag("libor_os_main_screen"),
        topBar = {
            TerminalHeader(
                currentRole = userRole,
                onRoleSelected = { repository.setUserRole(it) },
                isDemoRunning = isDemoRunning,
                onRunDemo = {
                    coroutineScope.launch {
                        repository.runFullDemonstrationPipeline { step, progress -> }
                    }
                }
            )
        },
        bottomBar = {
            // Horizontal scrollable institutional tab bar
            Surface(
                color = CityNavyMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CityBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEachIndexed { index, tab ->
                        val isSelected = selectedTabIndex == index
                        Surface(
                            color = if (isSelected) LondonGold else CityNavyCard,
                            shape = RoundedCornerShape(4.dp),
                            onClick = { selectedTabIndex = index },
                            modifier = Modifier
                                .border(
                                    0.5.dp,
                                    if (isSelected) LondonGold else CityBorder,
                                    RoundedCornerShape(4.dp)
                                )
                                .testTag("tab_${tab.title.lowercase().replace("//", "_")}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) CityNavyDark else CityTextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = tab.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) CityNavyDark else CityTextPrimary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CityNavyDark)
        ) {
            when (selectedTabIndex) {
                0 -> HomeScreen(
                    contracts = contracts,
                    portfolios = portfolios,
                    isDemoRunning = isDemoRunning,
                    demoProgress = demoProgress,
                    demoLogs = demoLogs,
                    onNavigateTab = { selectedTabIndex = it },
                    onRunDemo = {
                        coroutineScope.launch {
                            repository.runFullDemonstrationPipeline { _, _ -> }
                        }
                    }
                )
                1 -> BenchmarksScreen(benchmarks = benchmarks)
                2 -> RfrCompoundingScreen(rfrRates = rfrRates)
                3 -> ComparisonLabScreen()
                4 -> FallbackEngineScreen(fallbackRules = fallbackRules, spreadAdjustments = spreadAdjustments)
                5 -> ContractsScreen(
                    contracts = contracts,
                    onUpdateStatus = { id, st, notes -> repository.updateContractStatus(id, st, notes) },
                    onAddContract = { repository.addContract(it) }
                )
                6 -> TransitionDashboardScreen(
                    contracts = contracts,
                    onBulkRemediate = { curr, fromSt, toSt -> repository.bulkRemediateCategory(curr, fromSt, toSt) }
                )
                7 -> ValuationScreen(contracts = contracts)
                8 -> CurveLabScreen()
                9 -> PortfoliosScreen(portfolios = portfolios, contracts = contracts)
                10 -> ResearchLabScreen(researchStudies = researchStudies)
                11 -> AiAssistantScreen(
                    contracts = contracts,
                    portfolios = portfolios,
                    spreadAdjustments = spreadAdjustments
                )
                12 -> AuditGovernanceScreen(auditEvents = auditEvents, modelCards = modelCards)
            }
        }
    }
}
