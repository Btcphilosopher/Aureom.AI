package com.example.data.model

data class CashFlowItem(
    val periodIndex: Int,
    val startDate: String,
    val endDate: String,
    val paymentDate: String,
    val accrualFraction: Double,
    val baseBenchmarkRatePercent: Double,
    val spreadBps: Double,
    val allInRatePercent: Double,
    val notionalAmount: Double,
    val principalPayment: Double,
    val interestPayment: Double,
    val totalCashFlow: Double,
    val discountFactor: Double,
    val discountedCashFlow: Double,
    val isLegacyLibor: Boolean
)

data class LoanValuationResult(
    val contractId: String,
    val currency: Currency,
    val initialNotional: Double,
    val legacyPv: Double,
    val transitionPv: Double,
    val pvDifference: Double, // Transition Valuation Adjustment (TVA)
    val pvDifferencePercent: Double,
    val parRatePercent: Double,
    val durationYears: Double,
    val dv01: Double, // Dollar value of 01 (PV change per 1bp interest rate shift)
    val totalInterestLegacy: Double,
    val totalInterestTransition: Double,
    val cashFlowSchedule: List<CashFlowItem>
)

enum class SwapLegType { FIXED, FLOATING }

data class SwapLeg(
    val legType: SwapLegType,
    val rateOrBenchmark: String,
    val spreadBps: Double,
    val notional: Double,
    val paymentFrequencyMonths: Int,
    val dayCount: DayCountConvention
)

data class SwapValuationResult(
    val swapId: String,
    val fixedLegPv: Double,
    val floatingLegPv: Double,
    val netPv: Double,
    val parSwapRate: Double,
    val dv01: Double,
    val pv01: Double,
    val durationYears: Double,
    val transitionValuationAdjustment: Double,
    val fixedCashFlows: List<CashFlowItem>,
    val floatingCashFlows: List<CashFlowItem>
)

data class YieldCurvePoint(
    val tenorLabel: String,
    val tenorDays: Int,
    val zeroRatePercent: Double,
    val discountFactor: Double,
    val forwardRatePercent: Double,
    val curveType: String
)

data class YieldCurve(
    val curveId: String,
    val curveName: String,
    val currency: Currency,
    val benchmark: String,
    val asOfDate: String,
    val points: List<YieldCurvePoint>,
    val interpolationMethod: String = "Monotone Cubic Spline / Log-Linear Discount"
)
