package com.example.data.model

enum class ContractType(val label: String, val category: String) {
    LOAN("Syndicated & Bi-lateral Loan", "Cash"),
    MORTGAGE("Commercial Mortgage", "Real Estate"),
    BOND("Floating Rate Note (FRN)", "Securities"),
    INTEREST_RATE_SWAP("Interest Rate Swap (IRS)", "Derivatives"),
    CROSS_CURRENCY_SWAP("Cross-Currency Basis Swap (XCS)", "Derivatives"),
    CREDIT_FACILITY("Revolving Credit Facility (RCF)", "Cash"),
    STRUCTURED_NOTE("Structured Floating Note", "Structured"),
    SECURITISATION("Securitisation / RMBS / CLO", "Structured"),
    LEASE("Equipment & Asset Lease", "Commercial"),
    CORPORATE_FACILITY("Corporate Liquidity Facility", "Treasury")
}

enum class TransitionStatus(val label: String, val badgeColorHex: Long) {
    REMEDIATED_RFR("Remediated to RFR", 0xFF10B981),
    FALLBACK_DEFINED("Fallback Defined (Robust)", 0xFF38BDF8),
    PENDING_REVIEW("Review Required (Tough Legacy)", 0xFFF59E0B),
    ACTIVE_DISPUTE("Bespoke / Active Negotiation", 0xFFEF4444),
    SYNTHETIC_TRANSITIONED("Synthetic LIBOR Terminated", 0xFFA855F7)
}

enum class GoverningLaw(val label: String, val jurisdiction: String) {
    ENGLISH_LAW("English Law", "United Kingdom (Courts of England & Wales)"),
    NEW_YORK_LAW("New York Law", "United States (Federal / NY State)"),
    SWISS_LAW("Swiss Law", "Switzerland (Zurich Commercial Court)"),
    JAPANESE_LAW("Japanese Law", "Japan (Tokyo District Court)"),
    GERMAN_LAW("German Law", "Germany (BGB / Frankfurt)"),
    OTHER("Other Jurisdictional Law", "International / Custom")
}

enum class AmortisationType(val label: String) {
    BULLET("Bullet (Principal at Maturity)"),
    LINEAR("Linear Equal Principal Amortisation"),
    ANNUITY("Equal Payment Annuity"),
    CUSTOM("Custom Sinking Schedule")
}

data class LegacyContract(
    val contractId: String,
    val counterparty: String,
    val contractType: ContractType,
    val currency: Currency,
    val notional: Double,
    val benchmark: String,
    val tenor: Tenor,
    val contractualMarginBps: Double,
    val startDate: String,
    val maturityDate: String,
    val maturityYear: Int,
    val paymentFrequency: String, // e.g. "Quarterly", "Semi-Annual"
    val dayCount: DayCountConvention,
    val amortisationType: AmortisationType = AmortisationType.BULLET,
    val fallbackClauseSummary: String,
    val fallbackRuleId: String,
    val governingLaw: GoverningLaw,
    val transitionStatus: TransitionStatus,
    val estimatedLegacyPv: Double,
    val estimatedTransitionPv: Double,
    val riskFlag: Boolean = false,
    val notes: String = ""
)

data class ScannedClauseResult(
    val clauseType: String,
    val detectedText: String,
    val confidenceScore: Double,
    val candidateInterpretation: String,
    val humanReviewRequired: Boolean,
    val matchedKeywords: List<String>,
    val governingLawCandidate: GoverningLaw,
    val fallbackCandidate: String,
    val disclaimer: String = "LIBOR//OS provides analytical diagnostics only. Does NOT constitute legal advice or formal contractual interpretation."
)
