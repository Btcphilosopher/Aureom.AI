package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.SpreadEngine
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ComparisonLabScreen(modifier: Modifier = Modifier) {
    var selectedPair by remember { mutableStateOf("USD: LIBOR 3M vs SOFR") }

    val comparisonData = remember(selectedPair) {
        when (selectedPair) {
            "GBP: LIBOR 3M vs SONIA" -> ComparisonPairData(
                currency = Currency.GBP,
                legacyBenchmark = "GBP LIBOR 3M",
                rfrBenchmark = "SONIA (Compounded 3M)",
                legacyFinalRate = 5.2210,
                rfrCurrentRate = 4.7500,
                isda5YrMedianSpreadBps = 11.930,
                structuralDifference = "LIBOR included term bank credit premium; SONIA is an unsecured overnight rate requiring backward-looking compounding.",
                historicalBasisVol = 4.8,
                correlation = 0.94
            )
            "JPY: LIBOR 3M vs TONA" -> ComparisonPairData(
                currency = Currency.JPY,
                legacyBenchmark = "JPY LIBOR 3M",
                rfrBenchmark = "TONA (Compounded 3M)",
                legacyFinalRate = -0.0780,
                rfrCurrentRate = 0.2500,
                isda5YrMedianSpreadBps = 0.800,
                structuralDifference = "JPY LIBOR London panel ceased 2021; TONA uncollateralized overnight call rate now dominates JGB and JPY swap markets.",
                historicalBasisVol = 1.2,
                correlation = 0.98
            )
            else -> ComparisonPairData( // USD
                currency = Currency.USD,
                legacyBenchmark = "USD LIBOR 3M",
                rfrBenchmark = "SOFR (Compounded 3M)",
                legacyFinalRate = 5.5891,
                rfrCurrentRate = 4.5200,
                isda5YrMedianSpreadBps = 26.161,
                structuralDifference = "USD LIBOR was an uncollateralized interbank term rate with embedded bank credit risk. SOFR is a nearly risk-free overnight secured repo rate backed by US Treasuries.",
                historicalBasisVol = 7.4,
                correlation = 0.91
            )
        }
    }

    val chartSeries = remember(comparisonData) {
        val ptsLegacy = (1..12).map { i ->
            val v = comparisonData.legacyFinalRate - ((12 - i) * 0.08)
            Pair("M-$i", v)
        }
        val ptsRfr = (1..12).map { i ->
            val v = (comparisonData.rfrCurrentRate - ((12 - i) * 0.06))
            Pair("M-$i", v)
        }
        val ptsSpread = (1..12).map { i ->
            Pair("M-$i", (comparisonData.isda5YrMedianSpreadBps / 100.0) + 4.0)
        }

        listOf(
            ChartSeries(name = comparisonData.legacyBenchmark, color = LondonGold, dataPoints = ptsLegacy),
            ChartSeries(name = comparisonData.rfrBenchmark, color = SterlingGreen, dataPoints = ptsRfr)
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("comparison_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "BENCHMARK COMPARISON LAB",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "LIBOR vs Risk-Free Rate Methodological & Historical Spread Analytics",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Pair Selector
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("USD: LIBOR 3M vs SOFR", "GBP: LIBOR 3M vs SONIA", "JPY: LIBOR 3M vs TONA").forEach { pairName ->
                        val isSel = pairName == selectedPair
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) LondonGold else Color.Transparent)
                                .clickable { selectedPair = pairName }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pairName.take(12),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSel) CityNavyDark else CityTextPrimary,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Analytical Metrics Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FinancialMetricCard(
                    label = "ISDA 5-Yr Median Spread",
                    value = String.format("%.3f bps", comparisonData.isda5YrMedianSpreadBps),
                    subValue = "Bloomberg Official 5-Yr",
                    badgeText = "OFFICIAL",
                    badgeColor = SterlingGreen,
                    accentColor = LondonGold,
                    modifier = Modifier.weight(1f)
                )
                FinancialMetricCard(
                    label = "Historical Basis Vol",
                    value = String.format("%.1f bps", comparisonData.historicalBasisVol),
                    subValue = "Annualized Standard Deviation",
                    badgeText = "RISK",
                    badgeColor = BritishAmber,
                    accentColor = YieldBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Chart Comparison
        item {
            CanvasLineChart(
                title = "${comparisonData.legacyBenchmark} vs ${comparisonData.rfrBenchmark}",
                seriesList = chartSeries
            )
        }

        // Methodological Difference Matrix
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "METHODOLOGICAL & STRUCTURAL COMPARISON",
                        style = MaterialTheme.typography.titleMedium,
                        color = LondonGold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ComparisonRow("Credit Risk Premium", "Embedded (Interbank borrowing)", "None (O/N Risk-Free or Repo)")
                    ComparisonRow("Term Structure", "Forward-looking 1M/3M/6M/12M", "Overnight compounded in arrears")
                    ComparisonRow("Underlying Volume", "Thin / Expert Judgement", "Robust (e.g. $1.8T/day in SOFR)")
                    ComparisonRow("Administrator", "ICE Benchmark Admin (IBA)", "Central Banks (Fed / BoE / ECB / BOJ)")
                    ComparisonRow("Regulatory Status", "Permanently Ceased", "Mandatory Global Standard")

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CityNavyDark, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = comparisonData.structuralDifference,
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ComparisonRow(attribute: String, legacyVal: String, rfrVal: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(attribute, style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
        Text(legacyVal, style = MaterialTheme.typography.bodySmall, color = LondonGold, modifier = Modifier.weight(1.4f), fontSize = 11.sp)
        Text(rfrVal, style = MaterialTheme.typography.bodySmall, color = SterlingGreen, modifier = Modifier.weight(1.4f), fontSize = 11.sp)
    }
    Divider(color = CityBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
}

data class ComparisonPairData(
    val currency: Currency,
    val legacyBenchmark: String,
    val rfrBenchmark: String,
    val legacyFinalRate: Double,
    val rfrCurrentRate: Double,
    val isda5YrMedianSpreadBps: Double,
    val structuralDifference: String,
    val historicalBasisVol: Double,
    val correlation: Double
)
