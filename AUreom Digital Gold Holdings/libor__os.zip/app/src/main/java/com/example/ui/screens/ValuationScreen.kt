package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.ValuationEngine
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun ValuationScreen(
    contracts: List<LegacyContract>,
    modifier: Modifier = Modifier
) {
    var valuationType by remember { mutableStateOf(0) } // 0: Floating Loan, 1: Interest Rate Swap
    var selectedContract by remember { mutableStateOf(contracts.firstOrNull() ?: generateDefaultLoan()) }

    // Swap parameters
    var swapNotionalM by remember { mutableStateOf(50.0) }
    var swapFixedRate by remember { mutableStateOf(4.25) }
    var swapTenorYears by remember { mutableStateOf(5) }

    val loanValuation = remember(selectedContract) {
        ValuationEngine.valueFloatingRateLoan(selectedContract)
    }

    val swapValuation = remember(swapNotionalM, swapFixedRate, swapTenorYears) {
        ValuationEngine.valueInterestRateSwap(
            swapId = "IRS-USD-DEMO-01",
            currency = Currency.USD,
            notional = swapNotionalM * 1_000_000.0,
            fixedRatePercent = swapFixedRate,
            tenorYears = swapTenorYears
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("valuation_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "VALUATION & TRANSITION ADJUSTMENT (TVA)",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Dual-Curve Pricing, DV01 Risk & Cash Flow Schedule Reconstruction",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Sub Tabs
        item {
            TabRow(
                selectedTabIndex = valuationType,
                containerColor = CityNavyCard,
                contentColor = LondonGold,
                modifier = Modifier.border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = valuationType == 0,
                    onClick = { valuationType = 0 },
                    text = { Text("FLOATING-RATE LOAN VALUATION", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = valuationType == 1,
                    onClick = { valuationType = 1 },
                    text = { Text("INTEREST RATE SWAP (IRS)", style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        if (valuationType == 0) {
            // Loan Valuation
            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("SELECT CONTRACT TO REVALUE:", style = MaterialTheme.typography.labelSmall, color = LondonGold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedContract.contractId} (${selectedContract.counterparty})",
                                style = MaterialTheme.typography.titleSmall,
                                color = CityTextPrimary
                            )
                            StatusBadge(text = selectedContract.currency.code, color = YieldBlue)
                        }
                    }
                }
            }

            // Results Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "Legacy LIBOR PV",
                        value = "${selectedContract.currency.symbol}${String.format("%,.0f", loanValuation.legacyPv)}",
                        subValue = "Discounted OIS",
                        badgeText = "LEGACY",
                        badgeColor = LondonGold,
                        accentColor = LondonGold,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "Transition RFR PV",
                        value = "${selectedContract.currency.symbol}${String.format("%,.0f", loanValuation.transitionPv)}",
                        subValue = "RFR + 5-Yr Spread",
                        badgeText = "RFR",
                        badgeColor = SterlingGreen,
                        accentColor = SterlingGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "Transition Value Adj (TVA)",
                        value = "${selectedContract.currency.symbol}${String.format("%,.0f", loanValuation.pvDifference)}",
                        subValue = "${String.format("%.3f", loanValuation.pvDifferencePercent)}% Value Shift",
                        badgeText = if (abs(loanValuation.pvDifferencePercent) < 0.1) "MINIMAL BASIS" else "BASIS SHIFT",
                        badgeColor = YieldBlue,
                        accentColor = if (loanValuation.pvDifference >= 0) SterlingGreen else RiskCrimson,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "DV01 Sensitivity",
                        value = "${selectedContract.currency.symbol}${String.format("%,.0f", loanValuation.dv01)}",
                        subValue = "Duration: ${String.format("%.2f", loanValuation.durationYears)} Yrs",
                        badgeText = "RISK",
                        badgeColor = BritishAmber,
                        accentColor = YieldBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Cash Flow Table
            item {
                Text(
                    text = "PROJECTED CASH FLOW SCHEDULE",
                    style = MaterialTheme.typography.labelMedium,
                    color = LondonGold
                )
            }

            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CityNavySurface)
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("PAY DATE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1f))
                            Text("ALL-IN RATE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1f))
                            Text("COUPON", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                            Text("DISCOUNTED", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                        }
                        Divider(color = CityBorder, thickness = 0.5.dp)

                        loanValuation.cashFlowSchedule.take(6).forEach { cf ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(cf.paymentDate, style = MaterialTheme.typography.bodySmall, color = CityTextPrimary, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text(String.format("%.3f%%", cf.allInRatePercent), style = MaterialTheme.typography.bodySmall, color = LondonGold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("${selectedContract.currency.symbol}${String.format("%,.0f", cf.interestPayment)}", style = MaterialTheme.typography.bodySmall, color = SterlingGreen, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                Text("${selectedContract.currency.symbol}${String.format("%,.0f", cf.discountedCashFlow)}", style = MaterialTheme.typography.bodySmall, color = CityTextSecondary, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            }
                            Divider(color = CityBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                        }
                    }
                }
            }
        } else {
            // Swap Valuation
            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("INTEREST RATE SWAP PARAMETERS", style = MaterialTheme.typography.labelMedium, color = LondonGold)
                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Notional: $${swapNotionalM.toInt()}M USD", style = MaterialTheme.typography.bodySmall, color = CityTextMuted)
                        Slider(
                            value = swapNotionalM.toFloat(),
                            onValueChange = { swapNotionalM = it.toDouble() },
                            valueRange = 10f..250f,
                            colors = SliderDefaults.colors(thumbColor = LondonGold, activeTrackColor = LondonGold)
                        )

                        Text("Fixed Coupon Rate: ${String.format("%.2f", swapFixedRate)}%", style = MaterialTheme.typography.bodySmall, color = CityTextMuted)
                        Slider(
                            value = swapFixedRate.toFloat(),
                            onValueChange = { swapFixedRate = it.toDouble() },
                            valueRange = 2f..7f,
                            colors = SliderDefaults.colors(thumbColor = YieldBlue, activeTrackColor = YieldBlue)
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "Swap Net PV",
                        value = "$${String.format("%,.0f", swapValuation.netPv)}",
                        subValue = "Floating PV - Fixed PV",
                        badgeText = "MARK TO MARKET",
                        badgeColor = SterlingGreen,
                        accentColor = if (swapValuation.netPv >= 0) SterlingGreen else RiskCrimson,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "Par Swap Rate",
                        value = String.format("%.3f%%", swapValuation.parSwapRate),
                        subValue = "Fair Fixed Equilibrium",
                        badgeText = "PAR RATE",
                        badgeColor = LondonGold,
                        accentColor = LondonGold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FinancialMetricCard(
                        label = "Swap DV01 Risk",
                        value = "$${String.format("%,.0f", swapValuation.dv01)}",
                        subValue = "PV change per 1 bp shift",
                        badgeText = "DV01",
                        badgeColor = BritishAmber,
                        accentColor = YieldBlue,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        label = "Transition TVA Value",
                        value = "$${String.format("%,.0f", swapValuation.transitionValuationAdjustment)}",
                        subValue = "26.161 bp Spread MTM",
                        badgeText = "TVA",
                        badgeColor = PurpleQuant,
                        accentColor = CityTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

fun generateDefaultLoan(): LegacyContract {
    return LegacyContract(
        contractId = "LGC-USD-1001",
        counterparty = "Barclays Corporate Banking",
        contractType = ContractType.LOAN,
        currency = Currency.USD,
        notional = 50_000_000.0,
        benchmark = "USD LIBOR 3M",
        tenor = Tenor.M3,
        contractualMarginBps = 175.0,
        startDate = "2019-06-15",
        maturityDate = "2028-06-15",
        maturityYear = 2028,
        paymentFrequency = "Quarterly",
        dayCount = DayCountConvention.ACT_360,
        fallbackClauseSummary = "ISDA 2020 protocol with 26.161 bps median spread.",
        fallbackRuleId = "FBR-ISDA-USD",
        governingLaw = GoverningLaw.NEW_YORK_LAW,
        transitionStatus = TransitionStatus.FALLBACK_DEFINED,
        estimatedLegacyPv = 49_800_000.0,
        estimatedTransitionPv = 49_920_000.0
    )
}
