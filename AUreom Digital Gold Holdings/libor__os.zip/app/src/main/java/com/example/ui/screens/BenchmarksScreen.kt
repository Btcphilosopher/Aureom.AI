package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun BenchmarksScreen(
    benchmarks: List<BenchmarkSetting>,
    modifier: Modifier = Modifier
) {
    var selectedCurrency by remember { mutableStateOf(Currency.USD) }
    var selectedTenor by remember { mutableStateOf(Tenor.M3) }
    var activeProvider by remember { mutableStateOf(DataProviderType.SYNTHETIC_DEMO) }

    val currentBenchmark = benchmarks.find { it.currency == selectedCurrency && it.tenor == selectedTenor }
        ?: benchmarks.firstOrNull() ?: BenchmarkSetting(
            benchmarkId = "USD-LIBOR-3M",
            benchmarkName = "USD LIBOR 3M",
            currency = Currency.USD,
            tenor = Tenor.M3,
            effectiveDate = "1986-01-01",
            cessationDate = "2023-06-30 (Synthetic Ceased 2024-09-30)",
            status = BenchmarkStatus.PERMANENTLY_CEASED,
            administrator = "ICE Benchmark Administration (IBA)",
            methodology = "Waterfall Panel Submissions",
            source = "IBA Historical Archive",
            licence = "Aldgate Licence #UK-2026",
            isRepresentative = false,
            finalFixingRate = 5.58914,
            description = "Final published synthetic rate ceased 30 September 2024."
        )

    // Generate historical fixings timeseries
    val historicalFixings = remember(selectedCurrency, selectedTenor) {
        generateHistoricalFixings(selectedCurrency, selectedTenor)
    }

    val chartSeries = remember(historicalFixings) {
        listOf(
            ChartSeries(
                name = "${selectedCurrency.name} LIBOR ${selectedTenor.code}",
                color = LondonGold,
                dataPoints = historicalFixings.takeLast(16).map { Pair(it.date.takeLast(5), it.fixingRate) }
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("benchmarks_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Title & Provider selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HISTORICAL LIBOR TERMINAL",
                        style = MaterialTheme.typography.titleLarge,
                        color = LondonGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Archival Benchmark Database & Data Provenance Registry",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted
                    )
                }

                StatusBadge(text = activeProvider.badge, color = YieldBlue)
            }
        }

        // Currency Selector Tabs
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Currency.values().forEach { curr ->
                        val isSelected = curr == selectedCurrency
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) LondonGold else Color.Transparent)
                                .clickable { selectedCurrency = curr }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = curr.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) CityNavyDark else CityTextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Tenor Selector Row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(listOf(Tenor.ON, Tenor.W1, Tenor.M1, Tenor.M2, Tenor.M3, Tenor.M6, Tenor.M12)) { t ->
                    val isSelected = t == selectedTenor
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) YieldBlue else CityNavyCard)
                            .border(1.dp, if (isSelected) YieldBlue else CityBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedTenor = t }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = t.code,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) CityNavyDark else CityTextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Benchmark Profile Card
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentBenchmark.benchmarkName,
                            style = MaterialTheme.typography.titleMedium,
                            color = LondonGold
                        )
                        StatusBadge(
                            text = "PERMANENTLY CEASED",
                            color = RiskCrimson
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Final Published Rate:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = String.format("%.5f%%", currentBenchmark.finalFixingRate),
                                style = MaterialTheme.typography.titleLarge,
                                color = LondonGold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cessation Date:", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                            Text(
                                text = currentBenchmark.cessationDate.take(10),
                                style = MaterialTheme.typography.titleSmall,
                                color = CityTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Administrator: ${currentBenchmark.administrator} • ${currentBenchmark.licence}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Historical Fixing Chart
        item {
            CanvasLineChart(
                title = "${selectedCurrency.name} LIBOR ${selectedTenor.code} Historical Fixings",
                seriesList = chartSeries
            )
        }

        // Fixings Data Table
        item {
            Text(
                text = "HISTORICAL FIXING OBSERVATIONS (LAST 10 FIXINGS)",
                style = MaterialTheme.typography.labelMedium,
                color = LondonGold
            )
        }

        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CityNavySurface)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("DATE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                        Text("FIXING", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                        Text("CHANGE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1f))
                        Text("STATUS", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                    }

                    Divider(color = CityBorder, thickness = 0.5.dp)

                    historicalFixings.takeLast(10).reversed().forEach { fix ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = fix.date,
                                style = MaterialTheme.typography.bodySmall,
                                color = CityTextPrimary,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = String.format("%.5f%%", fix.fixingRate),
                                style = MaterialTheme.typography.bodySmall,
                                color = LondonGold,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = (if (fix.changeBps >= 0) "+" else "") + String.format("%.2f bp", fix.changeBps),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (fix.changeBps >= 0) SterlingGreen else RiskCrimson,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = fix.publicationStatus,
                                style = MaterialTheme.typography.labelSmall,
                                color = CityTextMuted,
                                fontSize = 9.sp,
                                modifier = Modifier.weight(1.2f)
                            )
                        }
                        Divider(color = CityBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                    }
                }
            }
        }

        // Data Provenance & Licence
        item {
            Surface(
                color = CityNavyDark,
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(4.dp))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "DATA PROVENANCE & ARCHIVE LICENCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = YieldBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Provider: ICE Benchmark Administration (Historical Archive) • Licence: Aldgate Fintech #UK-IBA-2026-884 • Transformation: Immutable Parquet Ingestion • SHA256 Hash: 9f84b1820ac34981e1948",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

fun generateHistoricalFixings(currency: Currency, tenor: Tenor): List<FixingObservation> {
    val list = mutableListOf<FixingObservation>()
    val baseRate = when (currency) {
        Currency.USD -> 5.45
        Currency.GBP -> 5.15
        Currency.EUR -> 3.85
        Currency.CHF -> 1.45
        Currency.JPY -> 0.08
    }

    var current = baseRate
    var prev = current

    for (i in 1..24) {
        val dateStr = String.format("2024-09-%02d", (i % 30) + 1)
        val delta = (sin(i.toDouble() * 0.8) * 0.015) + ((i % 5 - 2) * 0.004)
        current = (current + delta).coerceAtLeast(0.01)
        val changeBps = (current - prev) * 100.0
        val pctChange = if (prev > 0) ((current - prev) / prev) * 100.0 else 0.0

        list.add(
            FixingObservation(
                id = "FIX-${currency.name}-${tenor.code}-$i",
                benchmarkId = "${currency.name}-LIBOR-${tenor.code}",
                date = dateStr,
                fixingRate = current,
                previousRate = prev,
                changeBps = changeBps,
                percentChange = pctChange,
                source = "IBA Archival Feed",
                isSynthetic = true
            )
        )
        prev = current
    }

    return list
}
