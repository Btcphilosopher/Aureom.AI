package com.example.data.model

enum class Currency(val symbol: String, val code: String, val defaultCalendar: String) {
    GBP("£", "GBP", "UK London (Bank of England)"),
    USD("$", "USD", "US New York (SIFMA/Fed)"),
    EUR("€", "EUR", "Eurozone (TARGET2)"),
    CHF("CHF ", "CHF", "Switzerland (SIX/SNB)"),
    JPY("¥", "JPY", "Japan Tokyo (BOJ)")
}

enum class Tenor(val code: String, val label: String, val approxDays: Int, val months: Int) {
    ON("ON", "Overnight", 1, 0),
    SN("SN", "Spot Next", 2, 0),
    W1("1W", "1 Week", 7, 0),
    M1("1M", "1 Month", 30, 1),
    M2("2M", "2 Months", 60, 2),
    M3("3M", "3 Months", 90, 3),
    M6("6M", "6 Months", 180, 6),
    M12("12M", "12 Months / 1 Year", 365, 12)
}

enum class BenchmarkStatus(val label: String, val isCeased: Boolean) {
    PERMANENTLY_CEASED("Permanently Ceased (FCA/IBA)", true),
    SYNTHETIC_CEASED("Synthetic Expired (30 Sep 2024)", true),
    ACTIVE_RFR("Active Alternative RFR", false),
    HISTORICAL_ARCHIVE("Historical Archive Only", true)
}

enum class DataProviderType(val displayName: String, val badge: String) {
    LICENSED_IBA("ICE Benchmark Administration (Licensed)", "LICENSED"),
    SYNTHETIC_DEMO("Aldgate Synthetic Demo Provider", "SYNTHETIC"),
    HISTORICAL_CSV("Historical CSV Ingestion", "INGESTED"),
    INTERNAL_RESEARCH("Aldgate Quantitative Research", "RESEARCH")
}

data class BenchmarkSetting(
    val benchmarkId: String,
    val benchmarkName: String,
    val currency: Currency,
    val tenor: Tenor,
    val effectiveDate: String,
    val cessationDate: String,
    val status: BenchmarkStatus,
    val administrator: String,
    val methodology: String,
    val source: String,
    val licence: String,
    val isRepresentative: Boolean,
    val finalFixingRate: Double,
    val description: String
)

data class FixingObservation(
    val id: String,
    val benchmarkId: String,
    val date: String,
    val fixingRate: Double,
    val previousRate: Double,
    val changeBps: Double,
    val percentChange: Double,
    val source: String,
    val isSynthetic: Boolean = true,
    val publicationStatus: String = "FINAL_PUBLISHED",
    val timestamp: Long = System.currentTimeMillis()
)

data class DataProvenance(
    val source: String,
    val provider: String,
    val timestamp: Long,
    val publicationDate: String,
    val benchmarkId: String,
    val methodologyVersion: String,
    val licenceId: String,
    val transformation: String,
    val hashSignature: String
)
