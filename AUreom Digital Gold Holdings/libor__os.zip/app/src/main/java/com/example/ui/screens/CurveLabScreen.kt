package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.CurveEngine
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun CurveLabScreen(modifier: Modifier = Modifier) {
    var selectedCurrency by remember { mutableStateOf(Currency.USD) }
    var curveType by remember { mutableStateOf("OIS_DISCOUNT") } // OIS_DISCOUNT vs LEGACY_PROJECTION

    val curve = remember(selectedCurrency, curveType) {
        val bmName = if (curveType == "OIS_DISCOUNT") {
            when (selectedCurrency) {
                Currency.USD -> "SOFR OIS"
                Currency.GBP -> "SONIA OIS"
                Currency.EUR -> "€STR OIS"
                Currency.CHF -> "SARON OIS"
                Currency.JPY -> "TONA OIS"
            }
        } else {
            "${selectedCurrency.name} LIBOR Projection"
        }
        CurveEngine.buildStandardCurve(selectedCurrency, bmName)
    }

    val chartSeries = remember(curve) {
        listOf(
            ChartSeries(
                name = "Zero Rate (%)",
                color = LondonGold,
                dataPoints = curve.points.map { Pair(it.tenorLabel, it.zeroRatePercent) }
            ),
            ChartSeries(
                name = "Forward Rate (%)",
                color = YieldBlue,
                dataPoints = curve.points.map { Pair(it.tenorLabel, it.forwardRatePercent) }
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("curve_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "MULTI-CURVE LABORATORY",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Dual-Curve Framework: OIS Discounting vs Forward Projection Curves",
                    style = MaterialTheme.typography.bodySmall,
                    color = CityTextMuted
                )
            }
        }

        // Currency Selector
        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Currency.values().forEach { c ->
                        val isSel = c == selectedCurrency
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) LondonGold else Color.Transparent)
                                .clickable { selectedCurrency = c }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = c.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSel) CityNavyDark else CityTextPrimary,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Curve Type Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Pair("OIS_DISCOUNT", "RFR / OIS Discount Curve"),
                    Pair("LEGACY_PROJECTION", "Legacy LIBOR Projection Curve")
                ).forEach { (typeKey, label) ->
                    val isSel = typeKey == curveType
                    Surface(
                        color = if (isSel) CityNavyCardHover else CityNavyCard,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, if (isSel) YieldBlue else CityBorder, RoundedCornerShape(4.dp))
                            .clickable { curveType = typeKey }
                            .padding(vertical = 8.dp, horizontal = 6.dp)
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSel) YieldBlue else CityTextPrimary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Curve Chart
        item {
            CanvasLineChart(
                title = "${curve.curveName} Term Structure",
                seriesList = chartSeries
            )
        }

        // Curve Points Table
        item {
            Text(
                text = "CURVE DISPERSION & DISCOUNT FACTORS",
                style = MaterialTheme.typography.labelMedium,
                color = LondonGold
            )
        }

        item {
            Surface(
                color = CityNavyCard,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CityNavySurface)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("TENOR", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(0.8f))
                        Text("DAYS", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(0.8f))
                        Text("ZERO RATE", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                        Text("FORWARD", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1.2f))
                        Text("DF", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, modifier = Modifier.weight(1f))
                    }
                    Divider(color = CityBorder, thickness = 0.5.dp)

                    curve.points.forEach { pt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pt.tenorLabel, style = MaterialTheme.typography.bodySmall, color = LondonGold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                            Text("${pt.tenorDays}", style = MaterialTheme.typography.bodySmall, color = CityTextMuted, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                            Text(String.format("%.4f%%", pt.zeroRatePercent), style = MaterialTheme.typography.bodySmall, color = CityTextPrimary, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(String.format("%.4f%%", pt.forwardRatePercent), style = MaterialTheme.typography.bodySmall, color = YieldBlue, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(String.format("%.5f", pt.discountFactor), style = MaterialTheme.typography.bodySmall, color = SterlingGreen, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }
                        Divider(color = CityBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}
