package com.example.data.model

enum class UserRole(val title: String, val badgeColor: Long) {
    QUANT("Quantitative Research", 0xFFA855F7),
    TRADER("Rates Desk Trader", 0xFF38BDF8),
    RISK_MANAGER("Risk Management Officer", 0xFFEF4444),
    TREASURER("Corporate Treasurer", 0xFFF59E0B),
    OPERATIONS("Derivatives Operations", 0xFF10B981),
    LEGAL_REVIEWER("Legal & Contract Remediation", 0xFFEAB308),
    AUDITOR("Independent Valuation Auditor", 0xFF94A3B8),
    ADMIN("System Administrator", 0xFF64748B)
}

data class Portfolio(
    val id: String,
    val name: String,
    val desk: String,
    val currency: Currency,
    val contractCount: Int,
    val totalNotional: Double,
    val netPv: Double,
    val totalDv01: Double,
    val weightedDurationYears: Double,
    val remediatedCount: Int,
    val fallbackDefinedCount: Int,
    val pendingReviewCount: Int,
    val activeDisputeCount: Int,
    val contractIds: List<String>
) {
    val transitionProgressPercent: Double
        get() = if (contractCount == 0) 0.0 else ((remediatedCount + fallbackDefinedCount).toDouble() / contractCount) * 100.0
}

enum class ScenarioType(val label: String, val description: String) {
    IMMEDIATE_RFR_CONVERSION("Scenario A: Immediate RFR Conversion", "Converts all active legacy contracts immediately to compounded RFR with ISDA 5-yr median spread"),
    CONTRACTUAL_FALLBACK("Scenario B: Strict Contractual Fallback", "Applies strict per-document clause fallback provisions and individual spread terms"),
    DELAYED_REMEDIATION("Scenario C: Delayed Remediation", "Models 12-month delay with synthetic rate basis leakage and higher operational dispute costs"),
    SPREAD_SHOCK_PLUS_10BP("Scenario D: Spread Shock (+10 bps)", "Stress tests fixed-income portfolios against a 10 bps widening in RFR-LIBOR historical basis"),
    SPREAD_SHOCK_MINUS_10BP("Scenario D2: Spread Shock (-10 bps)", "Stress tests fixed-income portfolios against a 10 bps tightening in basis spread"),
    CURVE_PARALLEL_PLUS_100BP("Scenario E: Yield Curve Parallel Shock (+100 bps)", "Applies +100 bps parallel upward shift across all OIS and projection discount curves"),
    CURVE_TWIST_STEEPENER("Scenario F: Curve Twist (2s10s Steepener)", "Applies 50 bps steepening between 2Y and 10Y tenors")
}

data class ScenarioImpactResult(
    val scenarioType: ScenarioType,
    val name: String,
    val portfolioId: String,
    val basePv: Double,
    val stressedPv: Double,
    val pvDelta: Double,
    val pvDeltaPercent: Double,
    val baseDv01: Double,
    val stressedDv01: Double,
    val transitionRiskScore: String, // "LOW", "MODERATE", "ELEVATED", "CRITICAL"
    val quantitativeCommentary: String
)

data class AuditEvent(
    val calculationId: String,
    val timestamp: String,
    val userRole: UserRole,
    val actionName: String,
    val inputDatasetVersion: String,
    val modelVersion: String,
    val executionTimeMs: Long,
    val inputHash: String,
    val outputChecksum: String,
    val resultSummary: String,
    val replayable: Boolean = true
)

data class ModelCard(
    val modelId: String,
    val modelName: String,
    val version: String,
    val purpose: String,
    val methodology: String,
    val assumptions: List<String>,
    val limitations: List<String>,
    val validationStatus: String,
    val approvedBy: String,
    val approvedAt: String,
    val formulaNotation: String
)

data class ResearchStudy(
    val studyId: String,
    val title: String,
    val author: String,
    val date: String,
    val benchmarkFocus: String,
    val abstractText: String,
    val keyFindings: List<String>,
    val datasetRef: String,
    val codeSnippet: String
)
