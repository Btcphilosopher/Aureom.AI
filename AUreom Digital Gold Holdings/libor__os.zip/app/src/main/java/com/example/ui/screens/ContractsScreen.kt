package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.ContractScannerEngine
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ContractsScreen(
    contracts: List<LegacyContract>,
    onUpdateStatus: (String, TransitionStatus, String) -> Unit,
    onAddContract: (LegacyContract) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: Inventory, 1: NLP Scanner
    var searchQuery by remember { mutableStateOf("") }
    var selectedCurrencyFilter by remember { mutableStateOf<Currency?>(null) }
    var selectedStatusFilter by remember { mutableStateOf<TransitionStatus?>(null) }
    var inspectingContract by remember { mutableStateOf<LegacyContract?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    // Scanner state
    var sampleDocText by remember {
        mutableStateOf(
            "CREDIT AGREEMENT dated as of March 15, 2019 among BARCLAYS CORPORATE, as Administrative Agent, and the Lenders party hereto.\n" +
            "SECTION 1.01. Defined Terms. \"LIBOR\" means the London Interbank Offered Rate for 3-Month US Dollars as administered by the ICE Benchmark Administration.\n" +
            "SECTION 2.14. Benchmark Replacement. If the Administrative Agent determines that USD LIBOR has ceased or is non-representative, the benchmark replacement shall be CME Term SOFR plus the ARRC recommended spread adjustment (26.161 bps).\n" +
            "SECTION 9.09. Governing Law. This Agreement shall be governed by, and construed in accordance with, the laws of the State of New York."
        )
    }
    var scanResults by remember { mutableStateOf<List<ScannedClauseResult>>(emptyList()) }

    val filteredContracts = remember(contracts, searchQuery, selectedCurrencyFilter, selectedStatusFilter) {
        contracts.filter { c ->
            val matchesQuery = searchQuery.isBlank() ||
                c.contractId.contains(searchQuery, ignoreCase = true) ||
                c.counterparty.contains(searchQuery, ignoreCase = true) ||
                c.benchmark.contains(searchQuery, ignoreCase = true)
            val matchesCurr = selectedCurrencyFilter == null || c.currency == selectedCurrencyFilter
            val matchesStatus = selectedStatusFilter == null || c.transitionStatus == selectedStatusFilter
            matchesQuery && matchesCurr && matchesStatus
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("contracts_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Title & Header actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LEGACY CONTRACT REPOSITORY & SCANNER",
                        style = MaterialTheme.typography.titleLarge,
                        color = LondonGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${contracts.size} Active Contracts Monitored • Multi-Currency Inventory",
                        style = MaterialTheme.typography.bodySmall,
                        color = CityTextMuted
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = LondonGoldMuted, contentColor = Color.White),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("add_contract_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Contract", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Sub Tabs (Inventory vs Scanner)
        item {
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = CityNavyCard,
                contentColor = LondonGold,
                modifier = Modifier.border(1.dp, CityBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = { Text("CONTRACT INVENTORY (${filteredContracts.size})", style = MaterialTheme.typography.labelSmall) }
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = {
                        activeSubTab = 1
                        if (scanResults.isEmpty()) {
                            scanResults = ContractScannerEngine.scanDocumentText(sampleDocText)
                        }
                    },
                    text = { Text("NLP CLAUSE SCANNER", style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        if (activeSubTab == 0) {
            // Search Bar & Filter Chips
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by ID, Counterparty, or Benchmark...", color = CityTextMuted, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = LondonGold) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = CityTextMuted)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LondonGold,
                        unfocusedBorderColor = CityBorder,
                        focusedContainerColor = CityNavyCard,
                        unfocusedContainerColor = CityNavyCard,
                        focusedTextColor = CityTextPrimary,
                        unfocusedTextColor = CityTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("contract_search_input")
                )
            }

            // Currency & Status Filters Row
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterChip(
                            selected = selectedCurrencyFilter == null,
                            onClick = { selectedCurrencyFilter = null },
                            label = { Text("ALL CURRENCIES", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    items(Currency.values()) { curr ->
                        FilterChip(
                            selected = selectedCurrencyFilter == curr,
                            onClick = { selectedCurrencyFilter = if (selectedCurrencyFilter == curr) null else curr },
                            label = { Text(curr.name, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Contracts List
            items(filteredContracts) { contract ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (contract.riskFlag) RiskCrimson else CityBorder, RoundedCornerShape(6.dp))
                        .clickable { inspectingContract = contract }
                        .testTag("contract_item_${contract.contractId}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = contract.contractId,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = LondonGold,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = contract.contractType.label.take(20),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CityTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                            StatusBadge(
                                text = contract.transitionStatus.label.take(18),
                                color = Color(contract.transitionStatus.badgeColorHex)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = contract.counterparty,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CityTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Notional", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text(
                                    text = "${contract.currency.symbol}${String.format("%,.1f", contract.notional / 1_000_000)}M",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = SterlingGreen,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text("Legacy Benchmark", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text(contract.benchmark, style = MaterialTheme.typography.bodySmall, color = YieldBlue)
                            }
                            Column {
                                Text("Maturity", style = MaterialTheme.typography.labelSmall, color = CityTextMuted, fontSize = 9.sp)
                                Text("${contract.maturityYear}", style = MaterialTheme.typography.bodySmall, color = CityTextPrimary, fontFamily = FontFamily.Monospace)
                            }
                        }

                        if (contract.riskFlag) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(RiskCrimson.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .border(0.5.dp, RiskCrimson, RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text(
                                    text = "ACTION REQUIRED: ${contract.fallbackClauseSummary}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = RiskCrimson,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // NLP Scanner View
            item {
                LegalWarningBanner()
            }

            item {
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, CityBorder, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "DOCUMENT CLAUSE TEXT INPUT",
                            style = MaterialTheme.typography.labelMedium,
                            color = LondonGold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = sampleDocText,
                            onValueChange = { sampleDocText = it },
                            modifier = Modifier.fillMaxWidth().height(140.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CityNavyDark,
                                unfocusedContainerColor = CityNavyDark,
                                focusedTextColor = CityTextPrimary,
                                unfocusedTextColor = CityTextPrimary,
                                focusedBorderColor = LondonGold,
                                unfocusedBorderColor = CityBorder
                            ),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { scanResults = ContractScannerEngine.scanDocumentText(sampleDocText) },
                            colors = ButtonDefaults.buttonColors(containerColor = SterlingGreenDark),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        ) {
                            Icon(Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DIAGNOSE & EXTRACT CLAUSES", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Scanner Diagnostics Results
            items(scanResults) { res ->
                Surface(
                    color = CityNavyCard,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (res.humanReviewRequired) BritishAmber else SterlingGreen, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(res.clauseType, style = MaterialTheme.typography.titleMedium, color = LondonGold)
                            StatusBadge(
                                text = "CONFIDENCE: ${res.confidenceScore.toInt()}%",
                                color = if (res.confidenceScore >= 90) SterlingGreen else BritishAmber
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Candidate Interpretation: ${res.candidateInterpretation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CityTextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Box(
                            modifier = Modifier.fillMaxWidth().background(CityNavyDark, RoundedCornerShape(4.dp)).padding(6.dp)
                        ) {
                            Text(
                                text = "Extracted Snippet: \"${res.detectedText}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = CityTextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        if (res.humanReviewRequired) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "⚠️ HUMAN LEGAL REVIEW REQUIRED — Ambiguous language or reference bank fallback detected.",
                                style = MaterialTheme.typography.labelSmall,
                                color = BritishAmber,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Inspect Contract Modal Dialog
    if (inspectingContract != null) {
        val c = inspectingContract!!
        AlertDialog(
            onDismissRequest = { inspectingContract = null },
            confirmButton = {
                TextButton(onClick = { inspectingContract = null }) {
                    Text("Close", color = LondonGold)
                }
            },
            title = {
                Text(
                    text = "${c.contractId} Details",
                    style = MaterialTheme.typography.titleLarge,
                    color = LondonGold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Counterparty: ${c.counterparty}", style = MaterialTheme.typography.bodyMedium, color = CityTextPrimary)
                    Text("Notional: ${c.currency.code} ${String.format("%,.0f", c.notional)}", style = MaterialTheme.typography.bodySmall, color = SterlingGreen)
                    Text("Margin: ${c.contractualMarginBps} bps", style = MaterialTheme.typography.bodySmall, color = YieldBlue)
                    Text("Governing Law: ${c.governingLaw.label}", style = MaterialTheme.typography.bodySmall, color = CityTextSecondary)
                    Text("Fallback Summary: ${c.fallbackClauseSummary}", style = MaterialTheme.typography.bodySmall, color = CityTextMuted)

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Update Transition Status:", style = MaterialTheme.typography.labelSmall, color = LondonGold)

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                onUpdateStatus(c.contractId, TransitionStatus.REMEDIATED_RFR, "Remediated via ISDA Protocol")
                                inspectingContract = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SterlingGreenDark),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("Remediate to RFR", style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = {
                                onUpdateStatus(c.contractId, TransitionStatus.ACTIVE_DISPUTE, "Marked for Legal Review")
                                inspectingContract = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RiskCrimsonDark),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("Flag Dispute", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            },
            containerColor = CityNavySurface
        )
    }

    // Add Contract Dialog
    if (showAddDialog) {
        var cpName by remember { mutableStateOf("NatWest Markets plc") }
        var curr by remember { mutableStateOf(Currency.GBP) }
        var notionalStr by remember { mutableStateOf("25000000") }
        var marginStr by remember { mutableStateOf("175") }
        var matYearStr by remember { mutableStateOf("2029") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        val not = notionalStr.toDoubleOrNull() ?: 10_000_000.0
                        val mrg = marginStr.toDoubleOrNull() ?: 150.0
                        val yr = matYearStr.toIntOrNull() ?: 2029
                        val newC = LegacyContract(
                            contractId = "LGC-${curr.name}-${(1000..9999).random()}",
                            counterparty = cpName,
                            contractType = ContractType.LOAN,
                            currency = curr,
                            notional = not,
                            benchmark = "${curr.name} LIBOR 3M",
                            tenor = Tenor.M3,
                            contractualMarginBps = mrg,
                            startDate = "2020-03-15",
                            maturityDate = "$yr-03-15",
                            maturityYear = yr,
                            paymentFrequency = "Quarterly",
                            dayCount = if (curr == Currency.GBP) DayCountConvention.ACT_365F else DayCountConvention.ACT_360,
                            fallbackClauseSummary = "Incorporates ISDA 2020 fallback protocol.",
                            fallbackRuleId = "FBR-ISDA-USD",
                            governingLaw = GoverningLaw.ENGLISH_LAW,
                            transitionStatus = TransitionStatus.FALLBACK_DEFINED,
                            estimatedLegacyPv = not * 0.99,
                            estimatedTransitionPv = not * 0.995
                        )
                        onAddContract(newC)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LondonGold)
                ) {
                    Text("Save Contract", color = CityNavyDark)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = CityTextMuted)
                }
            },
            title = { Text("Add Legacy Contract", color = LondonGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = cpName,
                        onValueChange = { cpName = it },
                        label = { Text("Counterparty") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notionalStr,
                        onValueChange = { notionalStr = it },
                        label = { Text("Notional Amount") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = marginStr,
                        onValueChange = { marginStr = it },
                        label = { Text("Margin (bps)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = matYearStr,
                        onValueChange = { matYearStr = it },
                        label = { Text("Maturity Year") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = CityNavySurface
        )
    }
}
