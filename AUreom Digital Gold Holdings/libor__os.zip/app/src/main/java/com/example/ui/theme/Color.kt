package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// City of London Institutional Quantitative Palette
val CityNavyDark = Color(0xFF070D18)
val CityNavyMedium = Color(0xFF0B1320)
val CityNavySurface = Color(0xFF101B2D)
val CityNavyCard = Color(0xFF16233B)
val CityNavyCardHover = Color(0xFF1D2E4D)
val CityBorder = Color(0xFF263859)
val CityBorderLight = Color(0xFF3B5075)

val CityTextPrimary = Color(0xFFF1F5F9)
val CityTextSecondary = Color(0xFF94A3B8)
val CityTextMuted = Color(0xFF64748B)

// Accents & Signals
val LondonGold = Color(0xFFEAB308)
val LondonGoldMuted = Color(0xFFB45309)
val BritishAmber = Color(0xFFF59E0B)
val SterlingGreen = Color(0xFF10B981)
val SterlingGreenDark = Color(0xFF047857)
val YieldBlue = Color(0xFF38BDF8)
val YieldBlueDark = Color(0xFF0284C7)
val RoyalBlue = Color(0xFF2563EB)
val RiskCrimson = Color(0xFFEF4444)
val RiskCrimsonDark = Color(0xFF991B1B)
val PurpleQuant = Color(0xFFA855F7)

// Light theme fallback palette (institutional cream / light slate)
val CityLightBackground = Color(0xFFF8FAFC)
val CityLightSurface = Color(0xFFFFFFFF)
val CityLightCard = Color(0xFFF1F5F9)
val CityLightBorder = Color(0xFFCBD5E1)
val CityLightTextPrimary = Color(0xFF0F172A)
val CityLightTextSecondary = Color(0xFF475569)
