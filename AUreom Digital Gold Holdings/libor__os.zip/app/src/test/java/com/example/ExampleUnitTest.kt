package com.example

import com.example.data.model.*
import com.example.engine.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCompoundingEngine_inArrears() {
        val result = CompoundingEngine.calculateCompoundedRate(
            baseObservations = listOf(
                Pair("D+01", 4.75),
                Pair("D+02", 4.80),
                Pair("D+03", 4.85),
                Pair("D+04", 4.80),
                Pair("D+05", 4.75)
            ),
            notional = 10_000_000.0,
            marginBps = 150.0,
            compoundingMethod = CompoundingMethod.COMPOUNDED_ARREARS,
            dayCount = DayCountConvention.ACT_365F
        )

        assertTrue("Compounded rate must be positive", result.compoundedRatePercent > 4.0)
        assertTrue("All-in rate must include margin", result.allInRatePercent > result.compoundedRatePercent)
        assertTrue("Total interest must be positive", result.totalInterestAmount > 0.0)
        assertEquals("Observation count matches", 5, result.observationCount)
    }

    @Test
    fun testSpreadEngine_isdaOfficialSpreads() {
        val usd3m = SpreadEngine.getOfficialSpreadBps(Currency.USD, Tenor.M3)
        assertEquals("USD 3M ISDA spread should equal 26.161 bps", 26.161, usd3m, 0.001)

        val gbp3m = SpreadEngine.getOfficialSpreadBps(Currency.GBP, Tenor.M3)
        assertEquals("GBP 3M ISDA spread should equal 11.930 bps", 11.930, gbp3m, 0.001)

        val jpy3m = SpreadEngine.getOfficialSpreadBps(Currency.JPY, Tenor.M3)
        assertEquals("JPY 3M ISDA spread should equal 0.800 bps", 0.800, jpy3m, 0.001)
    }

    @Test
    fun testCurveEngine_discountFactors() {
        val curve = CurveEngine.buildStandardCurve(Currency.USD, "SOFR_OIS", baseShortRate = 4.50)
        assertTrue("Curve points must be populated", curve.points.isNotEmpty())

        curve.points.forEach { pt ->
            assertTrue("Discount factor must be less than 1.0", pt.discountFactor < 1.0)
            assertTrue("Discount factor must be positive", pt.discountFactor > 0.0)
            assertTrue("Zero rate must be positive", pt.zeroRatePercent > 0.0)
        }
    }

    @Test
    fun testValuationEngine_floatingLoanPricing() {
        val contract = LegacyContract(
            contractId = "TEST-USD-01",
            counterparty = "Test Bank NA",
            contractType = ContractType.LOAN,
            currency = Currency.USD,
            notional = 10_000_000.0,
            benchmark = "USD LIBOR 3M",
            tenor = Tenor.M3,
            contractualMarginBps = 150.0,
            startDate = "2020-01-01",
            maturityDate = "2028-01-01",
            maturityYear = 2028,
            paymentFrequency = "Quarterly",
            dayCount = DayCountConvention.ACT_360,
            fallbackClauseSummary = "ISDA 2020 fallback",
            fallbackRuleId = "FBR-ISDA-USD",
            governingLaw = GoverningLaw.NEW_YORK_LAW,
            transitionStatus = TransitionStatus.FALLBACK_DEFINED,
            estimatedLegacyPv = 9_900_000.0,
            estimatedTransitionPv = 9_950_000.0
        )

        val valResult = ValuationEngine.valueFloatingRateLoan(contract)
        assertTrue("Transition PV must be positive", valResult.transitionPv > 0.0)
        assertTrue("Cash flow schedule must have entries", valResult.cashFlowSchedule.isNotEmpty())
        assertTrue("DV01 must be positive", valResult.dv01 > 0.0)
    }

    @Test
    fun testContractScannerEngine_nlpDiagnostics() {
        val sampleText = "The loan shall bear interest referencing 3-Month USD LIBOR. Upon benchmark cessation, fallback shall be ARRC recommended SOFR. Governed by New York law."
        val results = ContractScannerEngine.scanDocumentText(sampleText)

        assertTrue("Should detect clauses", results.isNotEmpty())
        val bmClause = results.find { it.clauseType.contains("Benchmark") }
        assertNotNull("Should detect benchmark clause", bmClause)
        assertTrue("Confidence score should be high", bmClause!!.confidenceScore > 90.0)
    }
}
