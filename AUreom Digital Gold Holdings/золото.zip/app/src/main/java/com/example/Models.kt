package com.example

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Date
import java.util.UUID

enum class MetalType(val code: String, val ruName: String, val enName: String, val defaultPurity: Double) {
    GOLD("GLD", "Золото", "Gold", 999.9),
    SILVER("SLV", "Серебро", "Silver", 999.0),
    PLATINUM("PLT", "Платина", "Platinum", 999.5),
    PALLADIUM("PLD", "Палладий", "Palladium", 999.5)
}

enum class InstrumentType {
    SPOT, SWAP, FUTURES, PHYSICAL, OTC, REF_PRICES
}

data class MarketTick(
    val metal: MetalType,
    val type: InstrumentType,
    val bid: BigDecimal,
    val ask: BigDecimal,
    val last: BigDecimal,
    val spread: BigDecimal,
    val volume: Double,
    val openInterest: Int,
    val high: BigDecimal,
    val low: BigDecimal,
    val prevClose: BigDecimal,
    val timestamp: Long
) {
    val changePercent: BigDecimal
        get() = if (prevClose.compareTo(BigDecimal.ZERO) == 0) {
            BigDecimal.ZERO
        } else {
            last.subtract(prevClose)
                .multiply(BigDecimal("100"))
                .divide(prevClose, 2, RoundingMode.HALF_UP)
        }
}

data class ReferencePrice(
    val metal: MetalType,
    val priceRubPerGram: BigDecimal,
    val effectiveDate: String, // e.g. "2026-10-04"
    val isSimulation: Boolean = true
)

data class FXRate(
    val pair: String, // e.g., "USD/RUB"
    val rate: BigDecimal,
    val prevRate: BigDecimal,
    val high: BigDecimal,
    val low: BigDecimal,
    val timestamp: Long
) {
    val changePercent: BigDecimal
        get() = if (prevRate.compareTo(BigDecimal.ZERO) == 0) {
            BigDecimal.ZERO
        } else {
            rate.subtract(prevRate)
                .multiply(BigDecimal("100"))
                .divide(prevRate, 2, RoundingMode.HALF_UP)
        }
}

enum class RfqStatus(val labelRu: String) {
    PENDING("ОЖИДАЕТ КОТИРОВКУ"),
    QUOTED("ПРЕДЛОЖЕНА КОТИРОВКА"),
    ACCEPTED("ПОДТВЕРЖДЕНО"),
    REJECTED("ОТКЛОНЕНО"),
    EXPIRED("ИСТЕКЛО")
}

data class RFQ(
    val id: String = "RFQ-RU-2026-${UUID.randomUUID().toString().take(6).uppercase()}",
    val metal: MetalType,
    val productType: String, // e.g., "Investment Bar", "Recycled Scrap"
    val purity: Double,
    val quantityGrams: BigDecimal,
    val targetPricePerGram: BigDecimal? = null,
    val premiumPerGram: BigDecimal = BigDecimal.ZERO,
    val discountPerGram: BigDecimal = BigDecimal.ZERO,
    val deliveryLocation: String,
    val deliveryDate: String,
    val settlementTerms: String, // e.g. "T+0", "T+1"
    val clientName: String,
    val status: RfqStatus = RfqStatus.PENDING,
    val quotedPricePerGram: BigDecimal? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val totalValue: BigDecimal
        get() {
            val basePrice = quotedPricePerGram ?: BigDecimal.ZERO
            val finalPrice = basePrice.add(premiumPerGram).subtract(discountPerGram)
            return finalPrice.multiply(quantityGrams).setScale(2, RoundingMode.HALF_UP)
        }
}

enum class TradeDirection {
    BUY, SELL
}

data class Trade(
    val id: String = "TR-RU-${UUID.randomUUID().toString().take(8).uppercase()}",
    val rfqId: String?,
    val metal: MetalType,
    val instrumentType: InstrumentType,
    val direction: TradeDirection,
    val quantityGrams: BigDecimal,
    val pricePerGram: BigDecimal,
    val totalValue: BigDecimal,
    val clientName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isHedge: Boolean = false,
    val status: String = "Рассчитано" // "Не рассчитано", "В процессе", "Рассчитано"
)

enum class BarStatus(val labelRu: String) {
    AVAILABLE("СВОБОДЕН"),
    RESERVED("ЗАРЕЗЕРВИРОВАН"),
    IN_TRANSIT("В ПУТИ"),
    REFINING("НА АФФИНАЖЕ"),
    ASSAY("НА АНАЛИЗЕ")
}

data class BullionBar(
    val serialNumber: String,
    val metal: MetalType,
    val purity: Double, // e.g., 999.9
    val grossWeightGrams: BigDecimal,
    val fineWeightGrams: BigDecimal,
    val refiner: String,
    val productionDate: String,
    val certificateNumber: String,
    val vaultLocation: String,
    val owner: String,
    val status: BarStatus,
    val simulatedValue: BigDecimal = BigDecimal.ZERO
)

enum class AssayStep(val labelRu: String) {
    RECEIVING("ПРИЁМ"),
    SAMPLING("ОТБОР ОБРАЗЦА"),
    ANALYSIS("АНАЛИЗ"),
    CONFIRMATION("ПОДТВЕРЖДЕНИЕ"),
    CERTIFICATION("СЕРТИФИКАЦИЯ"),
    FINISHED("НА СКЛАДЕ")
}

enum class AssayMethod(val code: String, val labelRu: String) {
    XRF("XRF", "Рентгенофлуоресцентный анализ"),
    FIRE_ASSAY("FIRE", "Купелирование (пробирный анализ)"),
    DENSITY("DENSE", "Гидростатическое взвешивание"),
    CHEMICAL("CHEM", "Химический анализ")
}

data class AssayRecord(
    val id: String = "ASSAY-${UUID.randomUUID().toString().take(6).uppercase()}",
    val clientName: String,
    val metal: MetalType,
    val sampleWeightGrams: BigDecimal,
    val declaredPurity: Double,
    val currentStep: AssayStep = AssayStep.RECEIVING,
    val methodUsed: AssayMethod = AssayMethod.XRF,
    val measuredPurity: Double? = null,
    val certifiedBy: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class RefineryBatch(
    val batchId: String = "REF-BATCH-${UUID.randomUUID().toString().take(6).uppercase()}",
    val inputWeight: BigDecimal,
    val inputPurity: Double,
    val inputFineWeight: BigDecimal,
    val outputWeight: BigDecimal = BigDecimal.ZERO,
    val outputPurity: Double = 999.9,
    val outputFineWeight: BigDecimal = BigDecimal.ZERO,
    val recoveryRate: BigDecimal = BigDecimal.ZERO, // Percentage e.g. 99.8
    val processLoss: BigDecimal = BigDecimal.ZERO,
    val status: String = "В процессе", // "Приемка", "Аффинаж", "Контроль", "Выпуск", "Завершено"
    val timestamp: Long = System.currentTimeMillis()
)

data class WarehouseReceipt(
    val receiptId: String,
    val warehouseName: String,
    val ownerName: String,
    val metal: MetalType,
    val serialNumbers: List<String>,
    val totalFineWeightGrams: BigDecimal,
    val issueDate: String,
    val isCancelled: Boolean = false
)

data class InvoicingDocument(
    val docId: String,
    val type: String, // "Коммерческое предложение", "Счёт", "Акт приема-передачи", "Складское свидетельство"
    val recipient: String,
    val metal: MetalType,
    val grams: BigDecimal,
    val rubAmount: BigDecimal,
    val date: String,
    val status: String
)

data class RiskMetrics(
    val metal: MetalType,
    val netExposureGrams: BigDecimal,
    val grossExposureGrams: BigDecimal,
    val exposureRub: BigDecimal,
    val limitRub: BigDecimal,
    val utilizationPercent: BigDecimal,
    val statusLabel: String, // "НОРМА", "ВЫСОКАЯ НАГРУЗКА", "ЛИМИТ ИСПАНУТ"
    val hedgeRatio: BigDecimal // e.g. 85.0 %
)

data class DoubleEntryLedgerRow(
    val id: String = UUID.randomUUID().toString().take(8),
    val account: String, // e.g. "Касса АО СеверМеталл", "Дебиторы"
    val isDebit: Boolean,
    val amount: BigDecimal,
    val currency: String = "RUB",
    val reference: String,
    val timestamp: Long = System.currentTimeMillis()
)
