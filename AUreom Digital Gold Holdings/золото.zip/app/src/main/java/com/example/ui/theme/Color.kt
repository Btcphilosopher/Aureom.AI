package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Dark Palette
val GraphiteBg = Color(0xFF121212)      // Main deep background
val SlateSurface = Color(0xFF1E1E1E)     // Card / sheet surface
val SurfaceLight = Color(0xFF2B2B2B)     // Hover / highlighted surface

val RestrainedGold = Color(0xFFD4AF37)   // Primary gold, used with restraint
val SoftGold = Color(0xFFE5C158)         // Lighter gold accent

val BrushedSilver = Color(0xFFB0B5BC)    // Secondary steel / silver
val SlateNavy = Color(0xFF374151)        // Tertiary navy-gray
val DeepBurgundy = Color(0xFF8B1E2B)     // Alert / Risk state (highly stylized)
val DarkGreen = Color(0xFF1E4620)        // Success / Profit state
val LightGreen = Color(0xFF4CAF50)       // Gains
val LightRed = Color(0xFFE57373)         // Loss

val WarmWhite = Color(0xFFF5F4F0)        // Primary text
val MutedGrey = Color(0xFF9E9E9E)        // Secondary text / labels
val SteelBorder = Color(0xFF333333)      // Divider / border lines
