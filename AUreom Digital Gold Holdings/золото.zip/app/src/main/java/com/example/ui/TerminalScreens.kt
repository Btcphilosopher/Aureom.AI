package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.*
import com.example.ui.theme.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*

// Helper translation map for quick localization without massive resource files
object Loc {
    private val ru = mapOf(
        "app_title" to "ЗОЛОТО",
        "tagline" to "МЕТАЛЛ. РЫНОК. СТОИМОСТЬ.",
        "simulated_data" to "СИМУЛИРОВАННЫЕ ДАННЫЕ",
        "market" to "Рынок",
        "dealer" to "Дилер",
        "flow" to "Аффинаж & Скупка",
        "vault" to "Хранилище",
        "risk" to "Риски & P&L",
        "ai" to "ЗОЛОТО AI",
        "gold" to "Золото",
        "silver" to "Серебро",
        "platinum" to "Платина",
        "palladium" to "Палладий",
        "bid" to "Покупка",
        "ask" to "Продажа",
        "spread" to "Спред",
        "volume" to "Объём",
        "time" to "Время",
        "prev_close" to "Пред. закр.",
        "min" to "Минимум",
        "max" to "Максимум",
        "ref_price" to "Учётная цена ЦБ РФ",
        "moex_adapter" to "АДАПТЕР МОСКОВСКОЙ БИРЖИ",
        "futures" to "Фьючерсы",
        "spot" to "Спот",
        "swap" to "Своп",
        "physical" to "Физический металл",
        "otc" to "OTC",
        "indices" to "ИНДЕКСЫ ЦВЕТНЫХ МЕТАЛЛОВ",
        "check_trade" to "ПРОВЕРИТЬ СДЕЛКУ",
        "confirm" to "ПОДТВЕРДИТЬ СДЕЛКУ",
        "rfq_title" to "ЗАПРОС КОТИРОВКИ (RFQ)",
        "purity" to "Проба",
        "weight" to "Вес",
        "client" to "Клиент",
        "status" to "Статус",
        "total" to "Итоговая стоимость",
        "exposure" to "Экспозиция",
        "limits" to "Лимиты",
        "ledger" to "Торговая книга / Проводки",
        "scan" to "Сканировать Слиток",
        "recycle" to "Скупка лома",
        "refinery" to "Аффинаж",
        "assay_lab" to "Лаборатория пробирного анализа",
        "balance_invariant" to "Материальный баланс металлов",
        "stress_test" to "Сценарный анализ & Стресс-тест",
        "api_terminal" to "Разработчикам: API / CLI",
        "reconciled" to "Дебет = Кредит: Подтверждено",
        "not_reconciled" to "Несбалансированные проводки!",
        "vault_receipts" to "Складские свидетельства (Варранты)",
        "scan_bar_prompt" to "Введите серийный номер слитка для детальной проверки provenance:"
    )

    private val en = mapOf(
        "app_title" to "ZOLOTO",
        "tagline" to "METAL. MARKET. VALUE.",
        "simulated_data" to "SIMULATED DATA",
        "market" to "Market",
        "dealer" to "Dealer Terminal",
        "flow" to "Refining & Scrap",
        "vault" to "Vault",
        "risk" to "Risk & P&L",
        "ai" to "ZOLOTO AI",
        "gold" to "Gold",
        "silver" to "Silver",
        "platinum" to "Platinum",
        "palladium" to "Palladium",
        "bid" to "Bid",
        "ask" to "Ask",
        "spread" to "Spread",
        "volume" to "Volume",
        "time" to "Time",
        "prev_close" to "Prev Close",
        "min" to "Low",
        "max" to "High",
        "ref_price" to "CBR Reference Price",
        "moex_adapter" to "MOSCOW EXCHANGE ADAPTER",
        "futures" to "Futures",
        "spot" to "Spot",
        "swap" to "Swap",
        "physical" to "Physical Metal",
        "otc" to "OTC",
        "indices" to "PRECIOUS METALS INDICES",
        "check_trade" to "CHECK TRADE",
        "confirm" to "CONFIRM TRADE",
        "rfq_title" to "REQUEST FOR QUOTE (RFQ)",
        "purity" to "Purity",
        "weight" to "Weight",
        "client" to "Counterparty",
        "status" to "Status",
        "total" to "Total Value",
        "exposure" to "Exposure",
        "limits" to "Limits",
        "ledger" to "Double-Entry Ledger",
        "scan" to "Scan Bullion Bar",
        "recycle" to "Scrap Buyback",
        "refinery" to "Refinery Facility",
        "assay_lab" to "Assay & Laboratory",
        "balance_invariant" to "Material Balance Verification",
        "stress_test" to "Scenario Lab & Stress Test",
        "api_terminal" to "Developer API & CLI Terminal",
        "reconciled" to "Debits = Credits: Reconciled",
        "not_reconciled" to "Ledger imbalance detected!",
        "vault_receipts" to "Warehouse Receipts & Warrants",
        "scan_bar_prompt" to "Enter bar serial number to verify full digital provenance:"
    )

    fun t(key: String, lang: LanguageSetting): String {
        return if (lang == LanguageSetting.RU) ru[key] ?: key else en[key] ?: key
    }
}

// ---------------------------------------------------------------------
// Reusable Component: Custom Technical Sparkline / Price Chart
// ---------------------------------------------------------------------
@Composable
fun SimulatedSparkline(
    points: List<Float>,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (points.size < 2) return@Canvas
        val width = size.width
        val height = size.height
        val minVal = points.minOrNull() ?: 0f
        val maxVal = points.maxOrNull() ?: 1f
        val range = if (maxVal == minVal) 1f else maxVal - minVal

        val path = Path()
        val stepX = width / (points.size - 1)

        points.forEachIndexed { i, value ->
            val x = i * stepX
            val y = height - ((value - minVal) / range) * height
            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        val color = if (isPositive) LightGreen else LightRed
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

// ---------------------------------------------------------------------
// Common Decorative Layout: Section Header
// ---------------------------------------------------------------------
@Composable
fun SectionHeader(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = RestrainedGold,
            letterSpacing = 1.5.sp
        )
        if (subtitle != null) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MutedGrey
            )
        }
        Divider(
            color = SteelBorder,
            thickness = 1.dp,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
        )
    }
}

// ---------------------------------------------------------------------
// Workspace 1: РЫНОК (Market overview, CBR rates, Index tracker)
// ---------------------------------------------------------------------
@Composable
fun MarketTerminalScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val ticksMap by vm.ticks.collectAsState()
    val refPrices by vm.referencePrices.collectAsState()
    val fxList by vm.fxRates.collectAsState()
    val session by vm.marketSession.collectAsState()
    val moscowClock by vm.moscowTime.collectAsState()
    val selectedMetal by vm.selectedMetal.collectAsState()

    var activeInstrumentTab by remember { mutableStateOf(InstrumentType.SPOT) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper session info band
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (session.contains("Закрыто")) LightRed else LightGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${Loc.t("moex_adapter", lang)}: $session",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = moscowClock,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = RestrainedGold,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Metal Select Quick Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetalType.values().forEach { metal ->
                    val activeTick = ticksMap[metal]?.firstOrNull { it.type == InstrumentType.SPOT }
                    val refPrice = refPrices.firstOrNull { it.metal == metal }?.priceRubPerGram ?: BigDecimal.ZERO
                    val isSelected = selectedMetal == metal

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { vm.selectMetal(metal) }
                            .testTag("metal_card_${metal.code.lowercase()}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) SurfaceLight else SlateSurface
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) RestrainedGold else SteelBorder
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = metal.ruName.uppercase(),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) RestrainedGold else WarmWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "₽${String.format("%,.2f", refPrice.toDouble())}",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val change = activeTick?.changePercent ?: BigDecimal.ZERO
                            val isPos = change >= BigDecimal.ZERO
                            Text(
                                text = (if (isPos) "+" else "") + "$change%",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isPos) LightGreen else LightRed,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Central Bank and FX Curves
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // CBR Reference Prices Table
                Card(
                    modifier = Modifier.weight(1.2f),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = Loc.t("ref_price", lang).uppercase(),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = RestrainedGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        refPrices.forEach { ref ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ref.metal.ruName, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "₽${String.format("%,.2f", ref.priceRubPerGram.toDouble())} / г",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ЦБ РФ • ${Loc.t("simulated_data", lang)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedGrey,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                    }
                }

                // FX Desk Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "ВАЛЮТНЫЙ ДЕСК (FX)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = BrushedSilver
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        fxList.forEach { fx ->
                            val isPos = fx.changePercent >= BigDecimal.ZERO
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(fx.pair, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "₽${fx.rate}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = (if (isPos) "+" else "") + "${fx.changePercent}%",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isPos) LightGreen else LightRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Instrument Tabs
        item {
            SectionHeader(
                title = "${selectedMetal.ruName}: Торговые инструменты",
                subtitle = "Котировки в реальном времени на Московской бирже"
            )
        }

        item {
            ScrollableTabRow(
                selectedTabIndex = InstrumentType.values().indexOf(activeInstrumentTab),
                containerColor = Color.Transparent,
                contentColor = RestrainedGold,
                edgePadding = 0.dp
            ) {
                InstrumentType.values().forEach { inst ->
                    val tabLabel = when (inst) {
                        InstrumentType.SPOT -> Loc.t("spot", lang)
                        InstrumentType.SWAP -> Loc.t("swap", lang)
                        InstrumentType.FUTURES -> Loc.t("futures", lang)
                        InstrumentType.PHYSICAL -> Loc.t("physical", lang)
                        InstrumentType.OTC -> Loc.t("otc", lang)
                        InstrumentType.REF_PRICES -> "ЦБ РФ"
                    }
                    Tab(
                        selected = activeInstrumentTab == inst,
                        onClick = { activeInstrumentTab = inst },
                        text = { Text(tabLabel) }
                    )
                }
            }
        }

        // Interactive quotes grid/rows
        item {
            val tick = ticksMap[selectedMetal]?.firstOrNull { it.type == activeInstrumentTab }
            if (tick != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "${selectedMetal.ruName.uppercase()} ${tick.type.name}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Код: ${selectedMetal.code}-${tick.type.name}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedGrey
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "₽${String.format("%,.2f", tick.last.toDouble())}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = RestrainedGold,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                val chg = tick.changePercent
                                val isPos = chg >= BigDecimal.ZERO
                                Text(
                                    text = (if (isPos) "+" else "") + "$chg% за сегодня",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isPos) LightGreen else LightRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Bid / Ask Split Action View
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                border = BorderStroke(1.dp, SteelBorder)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(Loc.t("bid", lang), style = MaterialTheme.typography.labelSmall, color = MutedGrey)
                                    Text(
                                        text = "₽${String.format("%,.2f", tick.bid.toDouble())}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = LightGreen
                                    )
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                border = BorderStroke(1.dp, SteelBorder)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(Loc.t("ask", lang), style = MaterialTheme.typography.labelSmall, color = MutedGrey)
                                    Text(
                                        text = "₽${String.format("%,.2f", tick.ask.toDouble())}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = LightRed
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // High, Low, Volume table
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(Loc.t("spread", lang), style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                                Text("₽${tick.spread}", style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text(Loc.t("min", lang), style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                                Text("₽${String.format("%,.2f", tick.low.toDouble())}", style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(Loc.t("max", lang), style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                                Text("₽${String.format("%,.2f", tick.high.toDouble())}", style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(Loc.t("volume", lang), style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                                Text(String.format("%,.1f кг", tick.volume), style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Technical Sparkline Chart representation
                        Text(
                            text = "ДИНАМИКА ТОРГОВЫХ СЕССИЙ (СИНТЕТИКА)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedGrey,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        // Mock 10 points for sparkline
                        val sparkPoints = remember(tick.last) {
                            List(15) { i -> tick.last.toFloat() * (1f + (Math.sin(i.toDouble()) * 0.005f).toFloat()) }
                        }
                        SimulatedSparkline(
                            points = sparkPoints,
                            isPositive = tick.changePercent >= BigDecimal.ZERO,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                        )
                    }
                }
            }
        }

        // MOEX Deliverable Futures Details
        item {
            SectionHeader(
                title = "ФЬЮЧЕРСНЫЕ КОНТРАКТЫ (MOEX GLD/SLV)",
                subtitle = "Спецификации поставочных контрактов на золото и серебро"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Gold Future specification
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("ФЬЮЧЕРС НА ЗОЛОТО", fontWeight = FontWeight.Bold, color = RestrainedGold)
                            Text("GLD-12.26", fontFamily = FontFamily.Monospace, color = MutedGrey)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Базовый актив: Золото аффинированное", style = MaterialTheme.typography.bodySmall)
                        Text("Размер лота: 10 г", style = MaterialTheme.typography.bodySmall)
                        Text("Валюта котирования: Рубль РФ (RUB)", style = MaterialTheme.typography.bodySmall)
                        Text("Исполнение: Физическая поставка", style = MaterialTheme.typography.bodySmall, color = LightGreen, fontWeight = FontWeight.Bold)
                    }
                }

                // Silver Future specification
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("ФЬЮЧЕРС НА СЕРЕБРО", fontWeight = FontWeight.Bold, color = BrushedSilver)
                            Text("SLV-12.26", fontFamily = FontFamily.Monospace, color = MutedGrey)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Базовый актив: Серебро аффинированное", style = MaterialTheme.typography.bodySmall)
                        Text("Размер лота: 100 г", style = MaterialTheme.typography.bodySmall)
                        Text("Валюта котирования: Рубль РФ (RUB)", style = MaterialTheme.typography.bodySmall)
                        Text("Исполнение: Физическая поставка", style = MaterialTheme.typography.bodySmall, color = LightGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Index Indicators
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = Loc.t("indices", lang),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = RestrainedGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        listOf("RUGOLD" to "11,143.31", "RUSILVER" to "163.51", "RUPLAT" to "4,636.32", "RUPALLAD" to "3,204.64").forEach { (idx, value) ->
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(idx, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                Text(
                                    "₽$value",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RestrainedGold
                                )
                                Text("+0.84%", fontSize = 10.sp, color = LightGreen)
                            }
                        }
                    }
                }
            }
        }

        // Manual simulator ticking controls
        item {
            Button(
                onClick = { vm.manualTick() },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tick_simulation_button"),
                colors = ButtonDefaults.buttonColors(containerColor = SlateNavy)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Tick")
                Spacer(modifier = Modifier.width(8.dp))
                Text("ПРИНУДИТЕЛЬНО ОБНОВИТЬ ЦЕНЫ (СИМУЛЯЦИЯ TICK)")
            }
        }
    }
}

// ---------------------------------------------------------------------
// Workspace 2: ДИЛЕРСКИЙ ТЕРМИНАЛ & RFQ
// ---------------------------------------------------------------------
@Composable
fun DealerTerminalScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val ticksMap by vm.ticks.collectAsState()
    val rfqsList by vm.rfqs.collectAsState()
    val selectedMetal by vm.selectedMetal.collectAsState()

    // Form inputs
    var rfqClient by remember { mutableStateOf("АО «СеверМеталл»") }
    var rfqProduct by remember { mutableStateOf("Инвестиционные слитки 999.9") }
    var rfqWeight by remember { mutableStateOf("1000.00") }
    var rfqLocation by remember { mutableStateOf("Московское хранилище") }

    // Selected RFQ for confirmation
    var selectedRfqForAction by remember { mutableStateOf<RFQ?>(null) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: RFQ input and Quotes Selector (60%)
        Column(
            modifier = Modifier
                .weight(1.3f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("rfq_title", lang),
                subtitle = "Запрос расчетной котировки с учетом логистики и пробы"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Metal selection
                    Text("Выберите металл:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetalType.values().forEach { metal ->
                            val isSel = selectedMetal == metal
                            Button(
                                onClick = { vm.selectMetal(metal) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) RestrainedGold else SlateNavy,
                                    contentColor = if (isSel) GraphiteBg else WarmWhite
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(metal.ruName)
                            }
                        }
                    }

                    // Client Counterparty input
                    OutlinedTextField(
                        value = rfqClient,
                        onValueChange = { rfqClient = it },
                        label = { Text("Контрагент / Клиент") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Product type selection
                    OutlinedTextField(
                        value = rfqProduct,
                        onValueChange = { rfqProduct = it },
                        label = { Text("Форма продукта (Слитки, Лом, Гранулы)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Weight input
                    OutlinedTextField(
                        value = rfqWeight,
                        onValueChange = { rfqWeight = it },
                        label = { Text("Вес брутто (граммов)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Location input
                    OutlinedTextField(
                        value = rfqLocation,
                        onValueChange = { rfqLocation = it },
                        label = { Text("Место физической поставки") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Action: Submit RFQ
                    Button(
                        onClick = {
                            val w = rfqWeight.toDoubleOrNull() ?: 1000.0
                            vm.createNewRFQ(
                                metal = selectedMetal,
                                product = rfqProduct,
                                purity = selectedMetal.defaultPurity,
                                weightGrams = w,
                                deliveryLocation = rfqLocation,
                                deliveryDate = "2026-10-06",
                                settlement = "T+0",
                                client = rfqClient
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RestrainedGold, contentColor = GraphiteBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .testTag("submit_rfq_button")
                    ) {
                        Text("ОТПРАВИТЬ ЗАПРОС КОТИРОВКИ (RFQ)")
                    }
                }
            }

            // Quotes Simulator Center View
            SectionHeader(
                title = "АКТИВНЫЕ ЗАПРОСЫ В ТОРГОВОЙ ОЧЕРЕДИ",
                subtitle = "Ожидают подтверждения дилера или автоматического квотирования"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (rfqsList.isEmpty()) {
                        Text("Очередь RFQ пуста.", modifier = Modifier.padding(8.dp), color = MutedGrey)
                    } else {
                        rfqsList.forEach { rfq ->
                            val isSelected = selectedRfqForAction?.id == rfq.id
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { selectedRfqForAction = rfq },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) SurfaceLight else SlateSurface
                                ),
                                border = BorderStroke(1.dp, if (isSelected) RestrainedGold else SteelBorder)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(rfq.id, fontWeight = FontWeight.Bold, color = RestrainedGold)
                                        Text("${rfq.clientName} • ${rfq.metal.ruName} ${rfq.quantityGrams}г", style = MaterialTheme.typography.bodySmall)
                                        Text("Продукт: ${rfq.productType}", style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        val statusColor = when (rfq.status) {
                                            RfqStatus.PENDING -> BrushedSilver
                                            RfqStatus.QUOTED -> SoftGold
                                            RfqStatus.ACCEPTED -> LightGreen
                                            RfqStatus.REJECTED -> LightRed
                                            RfqStatus.EXPIRED -> MutedGrey
                                        }
                                        Text(
                                            text = rfq.status.labelRu,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold
                                        )

                                        if (rfq.quotedPricePerGram != null) {
                                            Text(
                                                text = "₽${rfq.quotedPricePerGram}/г",
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Risk / Position & Quick Confirmation (40%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = "РИСК И КВОТИРОВАНИЕ ДИЛЕРА",
                subtitle = "Резюме по выбранной операции"
            )

            // Dynamic pricing calculator box
            AnimatedVisibility(visible = selectedRfqForAction != null) {
                selectedRfqForAction?.let { rfq ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SlateSurface),
                        border = BorderStroke(1.dp, RestrainedGold)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "СПЕЦИФИКАЦИЯ СДЕЛКИ: ${rfq.id}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = RestrainedGold
                            )

                            Divider(color = SteelBorder)

                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Металл:")
                                Text(rfq.metal.ruName, fontWeight = FontWeight.Bold)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Количество:")
                                Text("${rfq.quantityGrams} г", fontFamily = FontFamily.Monospace)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Адрес склада:")
                                Text(rfq.deliveryLocation, maxLines = 1)
                            }

                            if (rfq.status == RfqStatus.PENDING) {
                                // Quote button to generate price
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { vm.updateRfqStatus(rfq.id, RfqStatus.QUOTED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(Loc.t("check_trade", lang))
                                }
                            } else if (rfq.status == RfqStatus.QUOTED) {
                                // Display final valuation formula
                                Divider(color = SteelBorder)
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Базовая цена ЦБ:")
                                    val cb = ticksMap[rfq.metal]?.firstOrNull { it.type == InstrumentType.REF_PRICES }?.last ?: BigDecimal("5000")
                                    Text("₽$cb / г", fontFamily = FontFamily.Monospace)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Премия дилера (+):")
                                    Text("₽${rfq.premiumPerGram} / г", fontFamily = FontFamily.Monospace, color = LightGreen)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Итоговый курс:")
                                    Text("₽${rfq.quotedPricePerGram} / г", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = RestrainedGold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(Loc.t("total", lang), fontWeight = FontWeight.Bold)
                                    Text("₽${String.format("%,.2f", rfq.totalValue.toDouble())}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = RestrainedGold)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // CONFIRM button
                                Button(
                                    onClick = {
                                        vm.confirmRfqTrade(rfq.id)
                                        selectedRfqForAction = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = LightGreen, contentColor = Color.White),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("confirm_trade_button")
                                ) {
                                    Text(Loc.t("confirm", lang))
                                }
                            } else {
                                Text(
                                    text = "Сделка по запросу ${rfq.status.labelRu}.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = LightGreen,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // Quick Exposure & Risk Dashboard in Dealer room
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "ЭКСПОЗИЦИЯ И ЛИМИТЫ РИСКА",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = RestrainedGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    MetalType.values().forEach { m ->
                        val risk = vm.getRiskMetrics(m)
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(m.ruName, fontWeight = FontWeight.SemiBold)
                                Text("${risk.utilizationPercent}%", fontWeight = FontWeight.Bold, color = if (risk.statusLabel != "НОРМА") LightRed else LightGreen)
                            }
                            LinearProgressIndicator(
                                progress = (risk.utilizationPercent.toFloat() / 100f).coerceIn(0f, 1f),
                                color = if (risk.statusLabel != "НОРМА") LightRed else RestrainedGold,
                                trackColor = SurfaceLight,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// Workspace 3: АФФИНАЖ, СКУПКА & ПРОБА (Refining & Recycling)
// ---------------------------------------------------------------------
@Composable
fun ProductionScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val assaysList by vm.assays.collectAsState()
    val batchesList by vm.refineryBatches.collectAsState()

    // Recycling form inputs
    var buybackDesc by remember { mutableStateOf("Цепочка золотая поврежденная") }
    var buybackGross by remember { mutableStateOf("38.40") }
    var buybackPurity by remember { mutableStateOf("585.0") } // Russian standard gold proby

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Refining facility & Material balance (50%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("refinery", lang),
                subtitle = "Цикл выплавки инвестиционных слитков из сырья"
            )

            // Refinery facility twin
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("АКТИВНЫЕ ПАРТИИ АФФИНАЖА", fontWeight = FontWeight.Bold, color = RestrainedGold)
                    Divider(color = SteelBorder)

                    if (batchesList.isEmpty()) {
                        Text("Плавильная печь не загружена.", color = MutedGrey)
                    } else {
                        batchesList.forEach { batch ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(batch.batchId, fontWeight = FontWeight.Bold)
                                        Text(
                                            batch.status,
                                            color = if (batch.status == "Завершен") LightGreen else RestrainedGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Сырьё: ${batch.inputWeight} г (${batch.inputPurity} проба)", style = MaterialTheme.typography.bodySmall)
                                    Text("Выход: ${batch.outputWeight} г (${batch.outputPurity} проба)", style = MaterialTheme.typography.bodySmall)
                                    Text("Потери при плавке: ${batch.processLoss} г чистого золота", style = MaterialTheme.typography.bodySmall, color = LightRed)

                                    if (batch.status != "Завершен") {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { vm.completeRefiningBatch(batch.batchId) },
                                            colors = ButtonDefaults.buttonColors(containerColor = RestrainedGold, contentColor = GraphiteBg),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("ВЫПУСТИТЬ СЛИТОК 999.9")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { vm.submitRefiningBatch(15000.0, 585.0, MetalType.GOLD) },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ЗАГРУЗИТЬ НОВУЮ ПАРТИЮ ДЛЯ ОЧИСТКИ")
                    }
                }
            }

            // Material Balance Verification Invariant
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = Loc.t("balance_invariant", lang).uppercase(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = LightGreen
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ВХОДНОЙ МЕТАЛЛ + ПОСТУПЛЕНИЯ − ВЫХОД − ПОТЕРИ = ОСТАТОК",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Материальный баланс по всем счетам хранения и плавления сведен со 100% точностью. Неучтенных потерь в аффинажном цехе не зафиксировано.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedGrey
                    )
                }
            }
        }

        // Right Column: Scrap Buyback Calculator & Assay Lab (50%)
        Column(
            modifier = Modifier
                .weight(1.1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("recycle", lang),
                subtitle = "Оценка и приемка ювелирного лома от населения и предприятий"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = buybackDesc,
                        onValueChange = { buybackDesc = it },
                        label = { Text("Описание ювелирного изделия") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = buybackGross,
                        onValueChange = { buybackGross = it },
                        label = { Text("Общая масса (граммов)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = buybackPurity,
                        onValueChange = { buybackPurity = it },
                        label = { Text("Ожидаемая проба (например, 585 или 925)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val gw = buybackGross.toDoubleOrNull() ?: 38.4
                            val pr = buybackPurity.toDoubleOrNull() ?: 585.0
                            vm.submitRecycleBuyback(MetalType.GOLD, buybackDesc, gw, pr)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RestrainedGold, contentColor = GraphiteBg),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("РАССЧИТАТЬ СТОИМОСТЬ СКУПКИ")
                    }
                }
            }

            // Lab Assay tracker
            SectionHeader(
                title = Loc.t("assay_lab", lang),
                subtitle = "Анализ пробы методами XRF (рентген) и купелирования"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (assaysList.isEmpty()) {
                        Text("Нет активных проб на анализе.", color = MutedGrey)
                    } else {
                        assaysList.forEach { assay ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(assay.id, fontWeight = FontWeight.Bold, color = RestrainedGold)
                                        Text(assay.currentStep.labelRu, fontWeight = FontWeight.Bold, color = SoftGold)
                                    }
                                    Text("Клиент: ${assay.clientName}", style = MaterialTheme.typography.bodySmall)
                                    Text("Металл: ${assay.metal.ruName} ${assay.sampleWeightGrams} г", style = MaterialTheme.typography.bodySmall)
                                    Text("Заявленная проба: ${assay.declaredPurity}", style = MaterialTheme.typography.bodySmall)
                                    assay.measuredPurity?.let {
                                        Text("Измеренная проба: $it (Метод: ${assay.methodUsed.labelRu})", style = MaterialTheme.typography.bodySmall, color = LightGreen, fontWeight = FontWeight.Bold)
                                    }
                                    assay.certifiedBy?.let {
                                        Text("Сертификат подписан: $it", style = MaterialTheme.typography.bodySmall, color = BrushedSilver)
                                    }

                                    if (assay.currentStep != AssayStep.FINISHED) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { vm.advanceAssay(assay.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("ПРОДВИНУТЬ НА СЛЕДУЮЩИЙ ШАГ")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { vm.submitLabAssay("Ювелирный Магазин «Аметист»", MetalType.GOLD, 120.50, 585.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ОТПРАВИТЬ НОВЫЙ ОБРАЗЕЦ НА ЭКСПЕРТИЗУ")
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// Workspace 4: ХРАНИЛИЩЕ & СКАНЕР (Vault & Provenance twin)
// ---------------------------------------------------------------------
@Composable
fun VaultScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val barsList by vm.bars.collectAsState()
    val scannedBar by vm.scannedBar.collectAsState()
    val receiptsList by vm.receipts.collectAsState()

    var manualSerialInput by remember { mutableStateOf("") }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Vault digital twin visualization (55%)
        Column(
            modifier = Modifier
                .weight(1.2f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = "ЦИФРОВОЙ ДВОЙНИК ХРАНИЛИЩА (VAULT TWIN)",
                subtitle = "Интерактивная визуализация стеллажей хранения слитков"
            )

            // 3D representation mockup using clean, technical 2D grid
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "СЕКЦИЯ А-3 • МОСКОВСКОЕ ЦЕНТРАЛЬНОЕ ХРАНИЛИЩЕ",
                        style = MaterialTheme.typography.labelMedium,
                        color = RestrainedGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Grid of shelves
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (row in 0..3) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                for (col in 0..5) {
                                    val idx = row * 6 + col
                                    val bar = barsList.getOrNull(idx)

                                    val cellColor = when {
                                        bar == null -> SlateSurface
                                        bar.status == BarStatus.RESERVED -> DeepBurgundy
                                        bar.metal == MetalType.GOLD -> DarkGreen
                                        else -> SlateNavy
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(cellColor)
                                            .border(1.dp, SteelBorder)
                                            .clickable {
                                                if (bar != null) {
                                                    vm.setScannedBar(bar)
                                                    manualSerialInput = bar.serialNumber
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (bar != null) {
                                            Text(
                                                text = bar.metal.code,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (bar.metal == MetalType.GOLD) SoftGold else BrushedSilver
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(DarkGreen))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Свободное Золото", fontSize = 10.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(SlateNavy))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Свободные металлы", fontSize = 10.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(DeepBurgundy))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Зарезервировано", fontSize = 10.sp)
                        }
                    }
                }
            }

            // Warehouse receipts list
            SectionHeader(
                title = Loc.t("vault_receipts", lang),
                subtitle = "Официальные варранты под залог физического металла"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    receiptsList.forEach { rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(rec.receiptId, fontWeight = FontWeight.Bold, color = RestrainedGold)
                                Text("Держатель: ${rec.ownerName}", style = MaterialTheme.typography.bodySmall)
                                Text("Обеспечение: ${rec.serialNumbers.joinToString(", ")}", style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                            }
                            Text(
                                text = "${rec.totalFineWeightGrams} г чистого ${rec.metal.code}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Right Column: Scanner / Provenance Digital Twin (45%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("scan", lang),
                subtitle = "Мгновенное сканирование QR/Штрихкода на слитке"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = Loc.t("scan_bar_prompt", lang),
                        style = MaterialTheme.typography.bodyMedium
                    )

                    OutlinedTextField(
                        value = manualSerialInput,
                        onValueChange = { manualSerialInput = it },
                        label = { Text("Серийный номер слитка") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val match = barsList.firstOrNull { it.serialNumber.equals(manualSerialInput, ignoreCase = true) }
                            if (match != null) {
                                vm.setScannedBar(match)
                            } else {
                                vm.setScannedBar(null)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ЗАПРОСИТЬ DIGITAL TWIN")
                    }

                    // Display scanned bar provenance
                    scannedBar?.let { bar ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                            border = BorderStroke(1.dp, RestrainedGold),
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "ПАСПОРТ СЛИТКА (DIGITAL THREAD)",
                                    fontWeight = FontWeight.Bold,
                                    color = RestrainedGold,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Divider(color = SteelBorder)

                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Слиток:")
                                    Text(bar.serialNumber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Металл:")
                                    Text(bar.metal.ruName, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Проба металла:")
                                    Text("${bar.purity}", fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Вес брутто:")
                                    Text("${bar.grossWeightGrams} г", fontFamily = FontFamily.Monospace)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Масса нетто (чистый):")
                                    Text("${bar.fineWeightGrams} г", fontFamily = FontFamily.Monospace, color = RestrainedGold, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Аффинажер:")
                                    Text(bar.refiner)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Сертификат:")
                                    Text(bar.certificateNumber, fontFamily = FontFamily.Monospace)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Текущая локация:")
                                    Text(bar.vaultLocation)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Владелец:")
                                    Text(bar.owner)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Статус актива:")
                                    Text(bar.status.labelRu, fontWeight = FontWeight.Bold, color = if (bar.status == BarStatus.AVAILABLE) LightGreen else DeepBurgundy)
                                }

                                Divider(color = SteelBorder)
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Рыночная оценка:", fontWeight = FontWeight.Bold)
                                    Text("₽${String.format("%,.2f", bar.simulatedValue.toDouble())}", fontWeight = FontWeight.Bold, color = SoftGold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    } ?: run {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .border(BorderStroke(1.dp, SteelBorder), RoundedCornerShape(4.dp))
                                .background(SurfaceLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Слиток не сканирован. Выберите серийный номер из ячеек хранилища слева.",
                                color = MutedGrey,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// Workspace 5: РИСКИ, СЦЕНАРИИ & P&L (Risk & Analytics)
// ---------------------------------------------------------------------
@Composable
fun RiskAnalyticsScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val ledgerList by vm.ledger.collectAsState()
    val stressResult by vm.stressResult.collectAsState()
    val loading by vm.aiLoading.collectAsState()

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Stress Testing Lab (50%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("stress_test", lang),
                subtitle = "Стресс-тестирование залогового портфеля на экстремальные шоки"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("ВЫБЕРИТЕ СТРЕСС-СЦЕНАРИЙ ДЛЯ СИМУЛЯЦИИ:", fontWeight = FontWeight.Bold, color = RestrainedGold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { vm.runStressTest("GOLD_SHOCK") },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Шок Металлов")
                        }
                        Button(
                            onClick = { vm.runStressTest("RUB_DEVALUATION") },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Девальвация")
                        }
                        Button(
                            onClick = { vm.runStressTest("LIQUIDITY_SHOCK") },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateNavy),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Ликвидность")
                        }
                    }

                    if (loading) {
                        CircularProgressIndicator(color = RestrainedGold, modifier = Modifier.align(Alignment.CenterHorizontally))
                    }

                    stressResult?.let { res ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                            border = BorderStroke(1.dp, RestrainedGold),
                            modifier = Modifier.padding(top = 12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(res.title, fontWeight = FontWeight.Bold, color = RestrainedGold, modifier = Modifier.weight(1f))
                                    Text(
                                        res.status,
                                        fontWeight = FontWeight.Bold,
                                        color = if (res.status.contains("КРИТИЧЕСКИЙ")) LightRed else LightGreen
                                    )
                                }
                                Divider(color = SteelBorder)
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Расчетные убытки:")
                                    Text("₽${String.format("%,.2f", res.lossRub.toDouble())}", fontFamily = FontFamily.Monospace, color = LightRed, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Доступный капитал:")
                                    Text("₽${String.format("%,.2f", res.capitalRemaining.toDouble())}", fontFamily = FontFamily.Monospace, color = LightGreen, fontWeight = FontWeight.Bold)
                                }
                                Text(res.description, style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                            }
                        }
                    }
                }
            }

            // Balanced Double-Entry verification invariant
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val balanced = PreciousMetalsRepository.verifyLedgerDebitsEqualsCredits()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(if (balanced) LightGreen else LightRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (balanced) Loc.t("reconciled", lang) else Loc.t("not_reconciled", lang),
                            fontWeight = FontWeight.Bold,
                            color = if (balanced) LightGreen else LightRed
                        )
                    }
                }
            }
        }

        // Right Column: Double-Entry Ledger (50%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = Loc.t("ledger", lang),
                subtitle = "Аудируемый журнал бухгалтерских проводок"
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    ledgerList.forEach { row ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(row.account, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = (if (row.isDebit) "Дт " else "Кт ") + "₽${String.format("%,.2f", row.amount.toDouble())}",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (row.isDebit) LightGreen else SoftGold
                                    )
                                }
                                Text("Назначение: ${row.reference}", style = MaterialTheme.typography.bodySmall, color = MutedGrey)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
// Workspace 6: ЗОЛОТО AI (Intelligent structured assistant)
// ---------------------------------------------------------------------
@Composable
fun AiAssistantScreen(vm: PreciousMetalsViewModel) {
    val lang by vm.language.collectAsState()
    val chatHistory by vm.chatHistory.collectAsState()
    val loading by vm.aiLoading.collectAsState()

    var userInputText by remember { mutableStateOf("") }

    val presetQueries = listOf(
        "Сколько золота сейчас на складе Москвы?",
        "Покажи текущую позицию по серебру.",
        "Какой сегодня P&L?",
        "Какие клиенты приближаются к кредитному лимиту?",
        "Какова стоимость запасов платины?",
        "Покажи изменение золота за 30 дней.",
        "Какая доля позиции захеджирована?"
    )

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Chat box (65%)
        Column(
            modifier = Modifier.weight(1.5f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionHeader(
                title = "ЗОЛОТО AI АССИСТЕНТ",
                subtitle = "Интеллектуальный поиск по структурированному закрытому реестру драгметаллов"
            )

            // Chat log
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SteelBorder)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    val scrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(scrollState),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        chatHistory.forEach { (sender, text) ->
                            val isUser = sender == "user"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isUser) SurfaceLight else SlateNavy
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isUser) RestrainedGold else SteelBorder
                                    ),
                                    modifier = Modifier.widthIn(max = 400.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = if (isUser) "ВЫ" else "ЗОЛОТО AI",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isUser) RestrainedGold else SoftGold
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = text, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                        if (loading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = RestrainedGold)
                            }
                        }
                    }
                }
            }

            // Input field
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = userInputText,
                    onValueChange = { userInputText = it },
                    placeholder = { Text("Введите финансовый или складской запрос...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_input_field")
                )

                Button(
                    onClick = {
                        vm.askAi(userInputText)
                        userInputText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RestrainedGold, contentColor = GraphiteBg),
                    modifier = Modifier.testTag("send_ai_button")
                ) {
                    Text("ЗАПРОС")
                }
            }
        }

        // Right Column: Presets & Clear chat (35%)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionHeader(
                title = "РЕКОМЕНДУЕМЫЕ ЗАПРОСЫ",
                subtitle = "Нажмите для быстрого извлечения аналитики"
            )

            presetQueries.forEach { query ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.askAi(query) },
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SteelBorder)
                ) {
                    Text(
                        text = query,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { vm.clearChat() },
                colors = ButtonDefaults.buttonColors(containerColor = DeepBurgundy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ОЧИСТИТЬ ИСТОРИЮ ЧАТА")
            }
        }
    }
}
