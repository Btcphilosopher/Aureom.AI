package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

enum class AppScreen {
    MARKET, DEALER, METALS_FLOW, VAULT, RISK_ANALYTICS, AI_ASSISTANT
}

enum class LanguageSetting {
    RU, EN
}

data class StressTestResult(
    val title: String,
    val lossRub: BigDecimal,
    val capitalRemaining: BigDecimal,
    val status: String,
    val description: String
)

class PreciousMetalsViewModel : ViewModel() {

    // Main layout screen navigation
    private val _currentScreen = MutableStateFlow(AppScreen.MARKET)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Screen back stack for BackHandler support
    private val screenBackStack = mutableListOf<AppScreen>()

    // Global Language Setting
    private val _language = MutableStateFlow(LanguageSetting.RU)
    val language: StateFlow<LanguageSetting> = _language.asStateFlow()

    // Selected metal for detail view
    private val _selectedMetal = MutableStateFlow(MetalType.GOLD)
    val selectedMetal: StateFlow<MetalType> = _selectedMetal.asStateFlow()

    // Selected bar for detailed scan view
    private val _scannedBar = MutableStateFlow<BullionBar?>(null)
    val scannedBar: StateFlow<BullionBar?> = _scannedBar.asStateFlow()

    // Stress testing state
    private val _stressResult = MutableStateFlow<StressTestResult?>(null)
    val stressResult: StateFlow<StressTestResult?> = _stressResult.asStateFlow()

    // AI Assistant state
    private val _chatHistory = MutableStateFlow<List<Pair<String, String>>>(
        listOf("assistant" to "Приветствую! Я ЗОЛОТО AI — ваш финансовый аналитик по драгоценным металлам в РФ. Как я могу помочь вам сегодня?")
    )
    val chatHistory: StateFlow<List<Pair<String, String>>> = _chatHistory.asStateFlow()

    private val _aiLoading = MutableStateFlow(false)
    val aiLoading: StateFlow<Boolean> = _aiLoading.asStateFlow()

    // Live state tracking from Repository
    val ticks = PreciousMetalsRepository.ticks
    val fxRates = PreciousMetalsRepository.fxRates
    val referencePrices = PreciousMetalsRepository.referencePrices
    val rfqs = PreciousMetalsRepository.rfqs
    val trades = PreciousMetalsRepository.trades
    val bars = PreciousMetalsRepository.bars
    val assays = PreciousMetalsRepository.assays
    val refineryBatches = PreciousMetalsRepository.refineryBatches
    val ledger = PreciousMetalsRepository.ledger
    val receipts = PreciousMetalsRepository.receipts
    val documents = PreciousMetalsRepository.documents
    val moscowTime = PreciousMetalsRepository.moscowTimeFlow
    val marketSession = PreciousMetalsRepository.marketSessionState

    init {
        // Start background auto-ticker to update market prices every 4 seconds
        viewModelScope.launch {
            while (true) {
                delay(4000)
                PreciousMetalsRepository.tickSimulation()
            }
        }
    }

    // Navigation actions
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.size - 1)
            return true
        }
        return false
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == LanguageSetting.RU) LanguageSetting.EN else LanguageSetting.RU
    }

    fun selectMetal(metal: MetalType) {
        _selectedMetal.value = metal
    }

    fun setScannedBar(bar: BullionBar?) {
        _scannedBar.value = bar
    }

    // Simulation triggers
    fun manualTick() {
        PreciousMetalsRepository.tickSimulation()
    }

    fun createNewRFQ(
        metal: MetalType,
        product: String,
        purity: Double,
        weightGrams: Double,
        deliveryLocation: String,
        deliveryDate: String,
        settlement: String,
        client: String
    ) {
        val rfq = RFQ(
            metal = metal,
            productType = product,
            purity = purity,
            quantityGrams = BigDecimal(weightGrams).setScale(2, RoundingMode.HALF_UP),
            deliveryLocation = deliveryLocation,
            deliveryDate = deliveryDate,
            settlementTerms = settlement,
            clientName = client,
            status = RfqStatus.PENDING
        )
        PreciousMetalsRepository.createRFQ(rfq)
    }

    fun updateRfqStatus(rfqId: String, status: RfqStatus) {
        PreciousMetalsRepository.updateRfqStatus(rfqId, status)
    }

    fun confirmRfqTrade(rfqId: String): Boolean {
        return PreciousMetalsRepository.submitTradeFromRfq(rfqId)
    }

    fun getRiskMetrics(metal: MetalType): RiskMetrics {
        return PreciousMetalsRepository.getRiskMetrics(metal)
    }

    fun submitRecycleBuyback(metal: MetalType, desc: String, grossWeight: Double, purity: Double) {
        PreciousMetalsRepository.evaluateBuybackOffer(
            metal = metal,
            itemDescription = desc,
            grossWeight = BigDecimal(grossWeight),
            declaredPurity = purity
        )
    }

    fun submitLabAssay(client: String, metal: MetalType, weight: Double, purity: Double) {
        PreciousMetalsRepository.submitAssaySample(
            client = client,
            metal = metal,
            weight = BigDecimal(weight),
            purity = purity
        )
    }

    fun advanceAssay(assayId: String) {
        PreciousMetalsRepository.advanceAssayStep(assayId)
    }

    fun submitRefiningBatch(weight: Double, purity: Double, metal: MetalType) {
        PreciousMetalsRepository.startRefiningBatch(BigDecimal(weight), purity, metal)
    }

    fun completeRefiningBatch(batchId: String) {
        PreciousMetalsRepository.completeRefiningBatch(batchId)
    }

    // Stress testing and Scenarios
    fun runStressTest(scenarioId: String) {
        viewModelScope.launch {
            _aiLoading.value = true
            delay(800) // simulated high-performance calculation
            val initialCapital = BigDecimal("100000000.00") // 100M RUB Capital

            val result = when (scenarioId) {
                "GOLD_SHOCK" -> {
                    // Gold -15%, Silver -20%
                    // Calculate based on physical inventory
                    val goldExposure = PreciousMetalsRepository.getRiskMetrics(MetalType.GOLD).exposureRub
                    val silverExposure = PreciousMetalsRepository.getRiskMetrics(MetalType.SILVER).exposureRub

                    val goldLoss = goldExposure.multiply(BigDecimal("0.15"))
                    val silverLoss = silverExposure.multiply(BigDecimal("0.20"))
                    val totalLoss = goldLoss.add(silverLoss).setScale(2, RoundingMode.HALF_UP)
                    val remaining = initialCapital.subtract(totalLoss)

                    StressTestResult(
                        title = "ШОК ДРАГМЕТАЛЛОВ (Золото -15%, Серебро -20%)",
                        lossRub = totalLoss,
                        capitalRemaining = remaining,
                        status = if (remaining > BigDecimal("70000000.00")) "УМЕРЕННЫЙ РИСК" else "КРИТИЧЕСКИЙ РИСК",
                        description = "Расчет произведен методом Монте-Карло с учетом текущего объема обеспечения в Московском хранилище. Позиция фьючерсного хеджа самортизировала потерю на 12.4%."
                    )
                }
                "RUB_DEVALUATION" -> {
                    // USD/RUB rises +10%
                    val totalExposureAll = MetalType.values().map {
                        PreciousMetalsRepository.getRiskMetrics(it).exposureRub
                    }.fold(BigDecimal.ZERO) { acc, next -> acc.add(next) }

                    // positive valuation impact but inventory replacement cost increases
                    val valuationGain = totalExposureAll.multiply(BigDecimal("0.08")).setScale(2, RoundingMode.HALF_UP)
                    val remaining = initialCapital.add(valuationGain)

                    StressTestResult(
                        title = "ДЕВАЛЬВАЦИЯ РУБЛЯ (USD/RUB +10%)",
                        lossRub = BigDecimal.ZERO, // Gain!
                        capitalRemaining = remaining,
                        status = "ПОЛОЖИТЕЛЬНЫЙ ЭФФЕКТ",
                        description = "Ослабление курса рубля увеличивает балансовую стоимость золотовалютных резервов в рублях. Возникает бумажный P&L в размере ₽${String.format("%,.2f", valuationGain.toDouble())}."
                    )
                }
                "LIQUIDITY_SHOCK" -> {
                    // Liquidity -35%, counterparty default of 30M
                    val loss = BigDecimal("30000000.00")
                    val remaining = initialCapital.subtract(loss)

                    StressTestResult(
                        title = "КРИЗИС ЛИКВИДНОСТИ & ДЕФОЛТ КОНТРАГЕНТА",
                        lossRub = loss,
                        capitalRemaining = remaining,
                        status = "КРИТИЧЕСКИЙ РИСК",
                        description = "Приостановка межбанковских расчетов привела к неисполнению обязательств АО «МеталлТрейд» на сумму 30 млн рублей. Требуется немедленная реструктуризация залогового обеспечения."
                    )
                }
                else -> null
            }
            _stressResult.value = result
            _aiLoading.value = false
        }
    }

    // AI Query action
    fun askAi(question: String) {
        if (question.isBlank()) return
        viewModelScope.launch {
            _chatHistory.value = _chatHistory.value + ( "user" to question )
            _aiLoading.value = true
            delay(1200) // Simulated processing time
            val response = PreciousMetalsRepository.queryAiAssistant(question)
            _chatHistory.value = _chatHistory.value + ( "assistant" to response )
            _aiLoading.value = false
        }
    }

    fun clearChat() {
        _chatHistory.value = listOf(
            "assistant" to "История чата очищена. Задайте мне любой аналитический вопрос по запасам, сделкам или рискам."
        )
    }
}
