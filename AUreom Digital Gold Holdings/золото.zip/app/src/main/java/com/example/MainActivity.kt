package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: PreciousMetalsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(vm: PreciousMetalsViewModel) {
    val currentScreen by vm.currentScreen.collectAsState()
    val lang by vm.language.collectAsState()
    val moscowTime by vm.moscowTime.collectAsState()
    val session by vm.marketSession.collectAsState()

    // Handle system back press
    BackHandler {
        vm.navigateBack()
    }

    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Embedded luxury monogram custom app icon from asset
                        Image(
                            painter = painterResource(id = R.drawable.img_app_icon_1791112003493),
                            contentDescription = "Zoloto Monogram Logo",
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, RestrainedGold, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Column {
                            Text(
                                text = Loc.t("app_title", lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = RestrainedGold,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = Loc.t("tagline", lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedGrey,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                },
                actions = {
                    // System session indicator pill
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SlateSurface),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (session.contains("Закрыто")) LightRed else LightGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = moscowTime.take(5) + " МСК",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarmWhite
                            )
                        }
                    }

                    // Language switcher button
                    TextButton(onClick = { vm.toggleLanguage() }) {
                        Text(
                            text = if (lang == LanguageSetting.RU) "ENGLISH" else "РУССКИЙ",
                            color = RestrainedGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GraphiteBg,
                    titleContentColor = WarmWhite
                )
            )
        },
        bottomBar = {
            if (!isTablet) {
                // Bottom Navigation for normal devices
                NavigationBar(
                    containerColor = GraphiteBg,
                    contentColor = RestrainedGold
                ) {
                    listOf(
                        Triple(AppScreen.MARKET, Icons.Default.TrendingUp, Loc.t("market", lang)),
                        Triple(AppScreen.DEALER, Icons.Default.CurrencyExchange, Loc.t("dealer", lang)),
                        Triple(AppScreen.METALS_FLOW, Icons.Default.Factory, "Производство"),
                        Triple(AppScreen.VAULT, Icons.Default.Lock, Loc.t("vault", lang)),
                        Triple(AppScreen.RISK_ANALYTICS, Icons.Default.Analytics, "Аналитика"),
                        Triple(AppScreen.AI_ASSISTANT, Icons.Default.Psychology, "AI")
                    ).forEach { (screen, icon, label) ->
                        val selected = currentScreen == screen
                        NavigationBarItem(
                            selected = selected,
                            onClick = { vm.navigateTo(screen) },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = GraphiteBg,
                                selectedTextColor = RestrainedGold,
                                indicatorColor = RestrainedGold,
                                unselectedIconColor = MutedGrey,
                                unselectedTextColor = MutedGrey
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GraphiteBg)
        ) {
            // Left sidebar for tablets / large screens
            if (isTablet) {
                NavigationRail(
                    containerColor = GraphiteBg,
                    header = {
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                ) {
                    listOf(
                        Triple(AppScreen.MARKET, Icons.Default.TrendingUp, Loc.t("market", lang)),
                        Triple(AppScreen.DEALER, Icons.Default.CurrencyExchange, Loc.t("dealer", lang)),
                        Triple(AppScreen.METALS_FLOW, Icons.Default.Factory, "Производство"),
                        Triple(AppScreen.VAULT, Icons.Default.Lock, Loc.t("vault", lang)),
                        Triple(AppScreen.RISK_ANALYTICS, Icons.Default.Analytics, "Риск / P&L"),
                        Triple(AppScreen.AI_ASSISTANT, Icons.Default.Psychology, "AI")
                    ).forEach { (screen, icon, label) ->
                        val selected = currentScreen == screen
                        NavigationRailItem(
                            selected = selected,
                            onClick = { vm.navigateTo(screen) },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = GraphiteBg,
                                selectedTextColor = RestrainedGold,
                                indicatorColor = RestrainedGold,
                                unselectedIconColor = MutedGrey,
                                unselectedTextColor = MutedGrey
                            ),
                            modifier = Modifier.testTag("rail_item_${screen.name.lowercase()}")
                        )
                    }
                }
            }

            // Primary screen workspace routing container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(GraphiteBg)
            ) {
                when (currentScreen) {
                    AppScreen.MARKET -> MarketTerminalScreen(vm)
                    AppScreen.DEALER -> DealerTerminalScreen(vm)
                    AppScreen.METALS_FLOW -> ProductionScreen(vm)
                    AppScreen.VAULT -> VaultScreen(vm)
                    AppScreen.RISK_ANALYTICS -> RiskAnalyticsScreen(vm)
                    AppScreen.AI_ASSISTANT -> AiAssistantScreen(vm)
                }
            }
        }
    }
}
