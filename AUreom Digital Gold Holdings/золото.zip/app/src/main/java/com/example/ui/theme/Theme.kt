package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CustomDarkColorScheme = darkColorScheme(
    primary = RestrainedGold,
    secondary = BrushedSilver,
    tertiary = SlateNavy,
    background = GraphiteBg,
    surface = SlateSurface,
    onPrimary = GraphiteBg,
    onSecondary = GraphiteBg,
    onTertiary = WarmWhite,
    onBackground = WarmWhite,
    onSurface = WarmWhite,
    surfaceVariant = SurfaceLight,
    onSurfaceVariant = MutedGrey,
    outline = SteelBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark terminal mode by default
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve our tailored branding
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CustomDarkColorScheme,
        typography = Typography,
        content = content
    )
}
