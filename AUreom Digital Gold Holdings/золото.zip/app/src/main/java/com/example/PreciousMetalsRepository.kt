package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

object PreciousMetalsRepository {
    private val random = Random(42) // Seed for deterministic reproducibility
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    // -------------------------------------------------------------
    // Reactive States
    // -------------------------------------------------------------
    private val _ticks = MutableStateFlow<Map<MetalType, List<MarketTick>>>(emptyMap())
    val ticks: StateFlow<Map<MetalType, List<MarketTick>>> = _ticks.asStateFlow()

    private val _fxRates = MutableStateFlow<List<FXRate>>(emptyList())
    val fxRates: StateFlow<List<FXRate>> = _fxRates.asStateFlow()

    private val _referencePrices = MutableStateFlow<List<ReferencePrice>>(emptyList())
    val referencePrices: StateFlow<List<ReferencePrice>> = _referencePrices.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RFQ>>(emptyList())
    val rfqs: StateFlow<List<RFQ>> = _rfqs.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _bars = MutableStateFlow<List<BullionBar>>(emptyList())
    val bars: StateFlow<List<BullionBar>> = _bars.asStateFlow()

    private val _assays = MutableStateFlow<List<AssayRecord>>(emptyList())
    val assays: StateFlow<List<AssayRecord>> = _assays.asStateFlow()

    private val _refineryBatches = MutableStateFlow<List<RefineryBatch>>(emptyList())
    val refineryBatches: StateFlow<List<RefineryBatch>> = _refineryBatches.asStateFlow()

    private val _ledger = MutableStateFlow<List<DoubleEntryLedgerRow>>(emptyList())
    val ledger: StateFlow<List<DoubleEntryLedgerRow>> = _ledger.asStateFlow()

    private val _receipts = MutableStateFlow<List<WarehouseReceipt>>(emptyList())
    val receipts: StateFlow<List<WarehouseReceipt>> = _receipts.asStateFlow()

    private val _documents = MutableStateFlow<List<InvoicingDocument>>(emptyList())
    val documents: StateFlow<List<InvoicingDocument>> = _documents.asStateFlow()

    // Configuration / Calendar state
    val moscowTimeFlow = MutableStateFlow("09:00:00")
    val marketSessionState = MutableStateFlow("Основная сессия") // "Открытие", "Основная сессия", "Перерыв", "Вечерняя сессия", "Закрыто"

    // Initial constants
    private var initialGoldOpeningMetal = BigDecimal("4000.0") // kg
    private var openingSilver = BigDecimal("28000.0") // kg
    private var openingPlatinum = BigDecimal("800.0") // kg
    private var openingPalladium = BigDecimal("1100.0") // kg

    init {
        resetSimulation()
    }

    fun resetSimulation() {
        // Seed FX Rates
        val initialFx = listOf(
            FXRate("USD/RUB", BigDecimal("92.45"), BigDecimal("91.90"), BigDecimal("92.80"), BigDecimal("91.60"), System.currentTimeMillis()),
            FXRate("CNY/RUB", BigDecimal("12.85"), BigDecimal("12.75"), BigDecimal("12.95"), BigDecimal("12.70"), System.currentTimeMillis()),
            FXRate("EUR/RUB", BigDecimal("100.20"), BigDecimal("99.80"), BigDecimal("100.60"), BigDecimal("99.40"), System.currentTimeMillis())
        )
        _fxRates.value = initialFx

        // Seed Reference Prices (concept of Bank of Russia in RUB / gram)
        // Bank of Russia reference price represents refined metal value conceptually derived from London/MOEX
        val initialRef = listOf(
            ReferencePrice(MetalType.GOLD, BigDecimal("11143.31"), "2026-10-04"),
            ReferencePrice(MetalType.SILVER, BigDecimal("163.51"), "2026-10-04"),
            ReferencePrice(MetalType.PLATINUM, BigDecimal("4636.32"), "2026-10-04"),
            ReferencePrice(MetalType.PALLADIUM, BigDecimal("3204.64"), "2026-10-04")
        )
        _referencePrices.value = initialRef

        // Generate synthetic ticks
        val initialTicks = mutableMapOf<MetalType, List<MarketTick>>()
        MetalType.values().forEach { metal ->
            val refPrice = initialRef.first { it.metal == metal }.priceRubPerGram
            initialTicks[metal] = InstrumentType.values().map { instrument ->
                // Vary price based on instrument type
                val factor = when(instrument) {
                    InstrumentType.SPOT -> BigDecimal("1.00")
                    InstrumentType.SWAP -> BigDecimal("1.0015")
                    InstrumentType.FUTURES -> BigDecimal("1.0120")
                    InstrumentType.PHYSICAL -> BigDecimal("1.0250") // Premium for physical
                    InstrumentType.OTC -> BigDecimal("0.9980")
                    InstrumentType.REF_PRICES -> BigDecimal("1.00")
                }
                val lastPrice = refPrice.multiply(factor).setScale(2, RoundingMode.HALF_UP)
                val spread = lastPrice.multiply(BigDecimal("0.003")).setScale(2, RoundingMode.HALF_UP) // 0.3% spread
                val bid = lastPrice.subtract(spread.divide(BigDecimal("2"), RoundingMode.HALF_UP))
                val ask = lastPrice.add(spread.divide(BigDecimal("2"), RoundingMode.HALF_UP))

                MarketTick(
                    metal = metal,
                    type = instrument,
                    bid = bid,
                    ask = ask,
                    last = lastPrice,
                    spread = spread,
                    volume = random.nextDouble(50000.0, 150000.0),
                    openInterest = random.nextInt(1000, 5000),
                    high = lastPrice.multiply(BigDecimal("1.01")),
                    low = lastPrice.multiply(BigDecimal("0.99")),
                    prevClose = lastPrice.multiply(BigDecimal("0.985")),
                    timestamp = System.currentTimeMillis()
                )
            }
        }
        _ticks.value = initialTicks

        // Seed 25 Vault Bars across synthetic locations
        val locations = listOf("Москва", "Санкт-Петербург", "Екатеринбург", "Новосибирск", "Красноярск", "Владивосток", "Казань", "Нижний Новгород")
        val owners = listOf("АО «СеверМеталл»", "Невская Ювелирная Компания", "АО «СоюзРафинад»", "АО «РосЗолото»", "ООО ЮвелирПром")
        val refiners = listOf("Красцветмет", "Приокский завод цветных металлов", "Новосибирский аффинажный завод", "Екатеринбургский завод ОЦМ")

        val seededBars = mutableListOf<BullionBar>()
        // Let's add first-class Palladium bars too!
        for (i in 1..25) {
            val metal = when (i % 4) {
                0 -> MetalType.GOLD
                1 -> MetalType.SILVER
                2 -> MetalType.PLATINUM
                else -> MetalType.PALLADIUM
            }
            val purity = metal.defaultPurity
            val sizeFactor = when (metal) {
                MetalType.SILVER -> BigDecimal("30") // silver bars are heavy e.g. 30kg
                else -> BigDecimal("1.0") // gold/plat/pall are 1kg
            }
            val grossWeight = BigDecimal(random.nextDouble(995.0, 1005.0) * sizeFactor.toDouble()).setScale(2, RoundingMode.HALF_UP)
            val fineWeight = grossWeight.multiply(BigDecimal(purity / 1000.0)).setScale(2, RoundingMode.HALF_UP)
            val metalCode = metal.code
            val purityCode = (purity * 10).toInt()
            val serial = "RU-$metalCode-$purityCode-${String.format("%08d", 48290 + i)}"

            val lastPrice = _ticks.value[metal]?.firstOrNull { it.type == InstrumentType.PHYSICAL }?.last ?: BigDecimal("5000.0")
            val valEstimate = fineWeight.multiply(lastPrice).setScale(2, RoundingMode.HALF_UP)

            seededBars.add(
                BullionBar(
                    serialNumber = serial,
                    metal = metal,
                    purity = purity,
                    grossWeightGrams = grossWeight,
                    fineWeightGrams = fineWeight,
                    refiner = refiners[i % refiners.size],
                    productionDate = "2026-03-${10 + (i % 15)}",
                    certificateNumber = "CERT-$metalCode-${99000 + i}",
                    vaultLocation = locations[i % locations.size],
                    owner = owners[i % owners.size],
                    status = BarStatus.AVAILABLE,
                    simulatedValue = valEstimate
                )
            )
        }
        _bars.value = seededBars

        // Seed some RFQs
        _rfqs.value = listOf(
            RFQ(
                id = "RFQ-RU-2026-004821",
                metal = MetalType.GOLD,
                productType = "Investment Bars 999.9",
                purity = 999.9,
                quantityGrams = BigDecimal("500.00"),
                deliveryLocation = "Московское хранилище",
                deliveryDate = "2026-10-06",
                settlementTerms = "T+0",
                clientName = "АО «СеверМеталл»",
                status = RfqStatus.PENDING,
                timestamp = System.currentTimeMillis() - 600000
            ),
            RFQ(
                id = "RFQ-RU-2026-004825",
                metal = MetalType.PALLADIUM,
                productType = "Industrial Catalyst Ingot",
                purity = 999.5,
                quantityGrams = BigDecimal("1200.00"),
                deliveryLocation = "Нижний Новгород Хранилище",
                deliveryDate = "2026-10-08",
                settlementTerms = "T+1",
                clientName = "ООО ЮвелирПром",
                status = RfqStatus.QUOTED,
                quotedPricePerGram = BigDecimal("3210.50"),
                timestamp = System.currentTimeMillis() - 300000
            )
        )

        // Seed some history of Trades
        _trades.value = listOf(
            Trade(
                id = "TR-RU-829104",
                rfqId = "RFQ-RU-2026-004711",
                metal = MetalType.GOLD,
                instrumentType = InstrumentType.PHYSICAL,
                direction = TradeDirection.BUY,
                quantityGrams = BigDecimal("1000.0"),
                pricePerGram = BigDecimal("11130.00"),
                totalValue = BigDecimal("11130000.00"),
                clientName = "АО «СеверМеталл»",
                timestamp = System.currentTimeMillis() - 3600000 * 4,
                isHedge = false
            ),
            Trade(
                id = "TR-RU-829105",
                rfqId = "HEDGE-GLD-02",
                metal = MetalType.GOLD,
                instrumentType = InstrumentType.FUTURES,
                direction = TradeDirection.SELL,
                quantityGrams = BigDecimal("1000.0"),
                pricePerGram = BigDecimal("11250.00"),
                totalValue = BigDecimal("11250000.00"),
                clientName = "Московская Биржа (Синтетика)",
                timestamp = System.currentTimeMillis() - 3600000 * 4,
                isHedge = true
            )
        )

        // Seed Assay / Recycling batches
        _assays.value = listOf(
            AssayRecord(
                id = "ASSAY-001482",
                clientName = "Иван Петров (Скупка)",
                metal = MetalType.GOLD,
                sampleWeightGrams = BigDecimal("38.40"),
                declaredPurity = 916.0,
                currentStep = AssayStep.ANALYSIS,
                methodUsed = AssayMethod.XRF,
                measuredPurity = 915.8,
                timestamp = System.currentTimeMillis() - 1200000
            )
        )

        _refineryBatches.value = listOf(
            RefineryBatch(
                batchId = "BATCH-AU-9901",
                inputWeight = BigDecimal("15000.00"), // 15kg scrap
                inputPurity = 585.0, // 58.5% jewellery scrap
                inputFineWeight = BigDecimal("8775.00"),
                outputWeight = BigDecimal("8760.00"),
                outputPurity = 999.9,
                outputFineWeight = BigDecimal("8759.12"),
                recoveryRate = BigDecimal("99.82"),
                processLoss = BigDecimal("15.88"),
                status = "Контроль",
                timestamp = System.currentTimeMillis() - 7200000
            )
        )

        // Seed double-entry ledger rows
        // Sum of Debits must equal credits. Let's seed initial balanced double entries:
        // Cash Account (Debit 50m RUB), Precious Metals Inventory Asset (Debit 20m RUB), Owner's Capital (Credit 70m RUB)
        _ledger.value = listOf(
            DoubleEntryLedgerRow(account = "Касса АО «СеверМеталл»", isDebit = true, amount = BigDecimal("50000000.00"), reference = "Начальный баланс капитала"),
            DoubleEntryLedgerRow(account = "Запасы металлов (Ассет)", isDebit = true, amount = BigDecimal("20000000.00"), reference = "Оценка резервов слитков"),
            DoubleEntryLedgerRow(account = "Уставный Капитал", isDebit = false, amount = BigDecimal("70000000.00"), reference = "Формирование баланса")
        )

        // Seed initial receipts
        _receipts.value = listOf(
            WarehouseReceipt(
                receiptId = "WR-RU-2026-9901",
                warehouseName = "Московское хранилище",
                ownerName = "АО «СеверМеталл»",
                metal = MetalType.GOLD,
                serialNumbers = listOf("RU-GLD-9999-00048291"),
                totalFineWeightGrams = BigDecimal("1000.12"),
                issueDate = "2026-09-15"
            )
        )

        // Seed some beautiful simulated documents
        _documents.value = listOf(
            InvoicingDocument("DOC-2026-004821", "Счёт на оплату", "АО «СеверМеталл»", MetalType.GOLD, BigDecimal("500.0"), BigDecimal("5570000.00"), "2026-10-04", "Оплачен"),
            InvoicingDocument("DOC-2026-004822", "Акт приема-передачи", "АО «СеверМеталл»", MetalType.GOLD, BigDecimal("500.0"), BigDecimal("5570000.00"), "2026-10-04", "Подписан")
        )
    }

    // -------------------------------------------------------------
    // Core Simulator Tick
    // -------------------------------------------------------------
    fun tickSimulation() {
        // Ticks prices
        val currentTicks = _ticks.value.toMutableMap()
        val currentRef = _referencePrices.value.toMutableList()
        val currentFx = _fxRates.value.toMutableList()

        // 1. Tick FX Rates (USD/RUB, CNY/RUB, EUR/RUB)
        val usdIdx = currentFx.indexOfFirst { it.pair == "USD/RUB" }
        if (usdIdx != -1) {
            val oldRate = currentFx[usdIdx].rate
            // Random walk within -0.4% to +0.5%
            val change = oldRate.multiply(BigDecimal(random.nextDouble(-0.004, 0.005))).setScale(2, RoundingMode.HALF_UP)
            val newRate = oldRate.add(change)
            currentFx[usdIdx] = currentFx[usdIdx].copy(
                rate = newRate,
                prevRate = oldRate,
                high = if (newRate > currentFx[usdIdx].high) newRate else currentFx[usdIdx].high,
                low = if (newRate < currentFx[usdIdx].low) newRate else currentFx[usdIdx].low,
                timestamp = System.currentTimeMillis()
            )
        }
        val cnyIdx = currentFx.indexOfFirst { it.pair == "CNY/RUB" }
        if (cnyIdx != -1) {
            val oldRate = currentFx[cnyIdx].rate
            val change = oldRate.multiply(BigDecimal(random.nextDouble(-0.003, 0.004))).setScale(2, RoundingMode.HALF_UP)
            val newRate = oldRate.add(change)
            currentFx[cnyIdx] = currentFx[cnyIdx].copy(rate = newRate, prevRate = oldRate, timestamp = System.currentTimeMillis())
        }
        _fxRates.value = currentFx

        // 2. Tick Metals
        MetalType.values().forEach { metal ->
            val list = currentTicks[metal] ?: emptyList()
            val refIdx = currentRef.indexOfFirst { it.metal == metal }
            var refPrice = if (refIdx != -1) currentRef[refIdx].priceRubPerGram else BigDecimal("5000")

            // Tick international prices which drive domestic prices
            val changePercent = random.nextDouble(-0.006, 0.008) // bias slightly positive
            refPrice = refPrice.multiply(BigDecimal(1.0 + changePercent)).setScale(2, RoundingMode.HALF_UP)
            if (refIdx != -1) {
                currentRef[refIdx] = currentRef[refIdx].copy(priceRubPerGram = refPrice)
            }

            val updatedInstrumentTicks = list.map { tick ->
                val lastPrice = tick.last.multiply(BigDecimal(1.0 + changePercent + random.nextDouble(-0.001, 0.001))).setScale(2, RoundingMode.HALF_UP)
                val spread = lastPrice.multiply(BigDecimal("0.003")).setScale(2, RoundingMode.HALF_UP)
                val bid = lastPrice.subtract(spread.divide(BigDecimal("2"), RoundingMode.HALF_UP))
                val ask = lastPrice.add(spread.divide(BigDecimal("2"), RoundingMode.HALF_UP))

                tick.copy(
                    bid = bid,
                    ask = ask,
                    last = lastPrice,
                    spread = spread,
                    high = if (lastPrice > tick.high) lastPrice else tick.high,
                    low = if (lastPrice < tick.low) lastPrice else tick.low,
                    timestamp = System.currentTimeMillis()
                )
            }
            currentTicks[metal] = updatedInstrumentTicks
        }
        _ticks.value = currentTicks
        _referencePrices.value = currentRef

        // Update estimated value of bars
        val updatedBars = _bars.value.map { bar ->
            val tick = _ticks.value[bar.metal]?.firstOrNull { it.type == InstrumentType.PHYSICAL }
            val price = tick?.last ?: BigDecimal("5000.0")
            bar.copy(simulatedValue = bar.fineWeightGrams.multiply(price).setScale(2, RoundingMode.HALF_UP))
        }
        _bars.value = updatedBars

        // Simulate random RFQ updates or custom timers
        val currentRfqs = _rfqs.value.map { rfq ->
            if (rfq.status == RfqStatus.PENDING && random.nextDouble() < 0.3) {
                // Propose quote!
                val tick = _ticks.value[rfq.metal]?.firstOrNull { it.type == InstrumentType.PHYSICAL }?.last ?: BigDecimal("5000.0")
                // add premium/discount
                val quoted = tick.multiply(BigDecimal(random.nextDouble(0.99, 1.01))).setScale(2, RoundingMode.HALF_UP)
                rfq.copy(
                    status = RfqStatus.QUOTED,
                    quotedPricePerGram = quoted,
                    premiumPerGram = quoted.multiply(BigDecimal("0.01")).setScale(2, RoundingMode.HALF_UP)
                )
            } else {
                rfq
            }
        }
        _rfqs.value = currentRfqs

        // Simulating MOEX session clock shifting slightly
        val moscowHour = (9 + (System.currentTimeMillis() / 60000) % 15).toInt()
        val moscowMin = ((System.currentTimeMillis() / 1000) % 60).toInt()
        moscowTimeFlow.value = String.format("%02d:%02d:00 МСК", moscowHour, moscowMin)
        marketSessionState.value = when {
            moscowHour < 9 -> "Предторговый период"
            moscowHour in 9..18 -> "Основная сессия"
            moscowHour == 19 -> "Расчетный клиринг"
            moscowHour in 20..23 -> "Вечерняя сессия"
            else -> "Рынок закрыт"
        }
    }

    // -------------------------------------------------------------
    // Core API actions
    // -------------------------------------------------------------
    fun createRFQ(rfq: RFQ): RFQ {
        val newList = _rfqs.value + rfq
        _rfqs.value = newList
        return rfq
    }

    fun updateRfqStatus(rfqId: String, newStatus: RfqStatus) {
        _rfqs.value = _rfqs.value.map { rfq ->
            if (rfq.id == rfqId) rfq.copy(status = newStatus) else rfq
        }
    }

    fun submitTradeFromRfq(rfqId: String): Boolean {
        val rfq = _rfqs.value.firstOrNull { it.id == rfqId } ?: return false
        if (rfq.status != RfqStatus.QUOTED) return false

        val price = rfq.quotedPricePerGram ?: return false
        val finalPrice = price.add(rfq.premiumPerGram).subtract(rfq.discountPerGram)
        val totalRub = finalPrice.multiply(rfq.quantityGrams).setScale(2, RoundingMode.HALF_UP)

        // 1. Create completed physical trade
        val trade = Trade(
            rfqId = rfq.id,
            metal = rfq.metal,
            instrumentType = InstrumentType.PHYSICAL,
            direction = TradeDirection.SELL, // client buys from us, so we sell to client
            quantityGrams = rfq.quantityGrams,
            pricePerGram = finalPrice,
            totalValue = totalRub,
            clientName = rfq.clientName,
            isHedge = false
        )
        _trades.value = _trades.value + trade

        // 2. Trigger automatic hedge trade on Moscow Exchange futures (85% hedge)
        val hedgeWeight = rfq.quantityGrams.multiply(BigDecimal("0.85")).setScale(2, RoundingMode.HALF_UP)
        val hedgeFutTick = _ticks.value[rfq.metal]?.firstOrNull { it.type == InstrumentType.FUTURES }
        val futPrice = hedgeFutTick?.last ?: finalPrice
        val hedgeValue = hedgeWeight.multiply(futPrice).setScale(2, RoundingMode.HALF_UP)

        val hedgeTrade = Trade(
            id = "HEDGE-${rfq.metal.code}-${UUID.randomUUID().toString().take(4).uppercase()}",
            rfqId = rfq.id,
            metal = rfq.metal,
            instrumentType = InstrumentType.FUTURES,
            direction = TradeDirection.BUY, // Buy futures to hedge physical sale
            quantityGrams = hedgeWeight,
            pricePerGram = futPrice,
            totalValue = hedgeValue,
            clientName = "Московская Биржа (Синтетика)",
            isHedge = true
        )
        _trades.value = _trades.value + hedgeTrade

        // 3. Double-entry ledger reconciliation:
        // Cash Account (Debit the total trade value)
        // Precious Metals Inventory (Credit the fine weight equivalent in standard pricing)
        // Gain/Loss Spread (Balanced equity)
        val ledgerEntries = listOf(
            DoubleEntryLedgerRow(account = "Касса АО «СеверМеталл»", isDebit = true, amount = totalRub, reference = "Оплата по сделке ${trade.id}"),
            DoubleEntryLedgerRow(account = "Дебиторы / Расчеты с клиентами", isDebit = false, amount = totalRub, reference = "Расчет с ${trade.clientName} по сделке ${trade.id}")
        )
        _ledger.value = _ledger.value + ledgerEntries

        // 4. Physical bar allocation
        // If there is an available bar for this metal with appropriate weight, mark it reserved!
        val barsList = _bars.value.toMutableList()
        val matchIdx = barsList.indexOfFirst { it.metal == rfq.metal && it.status == BarStatus.AVAILABLE && it.fineWeightGrams >= rfq.quantityGrams }
        if (matchIdx != -1) {
            val targetBar = barsList[matchIdx]
            barsList[matchIdx] = targetBar.copy(
                status = BarStatus.RESERVED,
                owner = rfq.clientName
            )
            _bars.value = barsList

            // Also issue warehouse receipt
            val newReceipt = WarehouseReceipt(
                receiptId = "WR-RU-2026-${UUID.randomUUID().toString().take(4).uppercase()}",
                warehouseName = targetBar.vaultLocation + " Хранилище",
                ownerName = rfq.clientName,
                metal = rfq.metal,
                serialNumbers = listOf(targetBar.serialNumber),
                totalFineWeightGrams = targetBar.fineWeightGrams,
                issueDate = "2026-10-04"
            )
            _receipts.value = _receipts.value + newReceipt
        }

        // 5. Generate documents
        val invoiceDoc = InvoicingDocument(
            docId = "INV-2026-${UUID.randomUUID().toString().take(4).uppercase()}",
            type = "Счёт на оплату",
            recipient = rfq.clientName,
            metal = rfq.metal,
            grams = rfq.quantityGrams,
            rubAmount = totalRub,
            date = "2026-10-04",
            status = "Выписан"
        )
        _documents.value = _documents.value + invoiceDoc

        // 6. Update RFQ status
        _rfqs.value = _rfqs.value.map { item ->
            if (item.id == rfq.id) item.copy(status = RfqStatus.ACCEPTED) else item
        }

        return true
    }

    // Physical recycling buyback valuation
    fun evaluateBuybackOffer(metal: MetalType, itemDescription: String, grossWeight: BigDecimal, declaredPurity: Double): RFQ {
        val refPrice = _referencePrices.value.firstOrNull { it.metal == metal }?.priceRubPerGram ?: BigDecimal("5000.0")
        // Purity coefficient e.g. 585 / 1000 = 0.585
        val purityCoeff = BigDecimal(declaredPurity / 1000.0)
        val fineWeight = grossWeight.multiply(purityCoeff).setScale(2, RoundingMode.HALF_UP)

        // Institutional recycling discount (e.g., 5% discount on recycling buyback)
        val recycleDiscountRate = BigDecimal("0.05")
        val discount = refPrice.multiply(recycleDiscountRate).setScale(2, RoundingMode.HALF_UP)
        val offerPricePerGram = refPrice.subtract(discount)

        val totalValue = offerPricePerGram.multiply(fineWeight).setScale(2, RoundingMode.HALF_UP)

        // Create a custom pending buyback RFQ
        val buybackRfq = RFQ(
            id = "RECYCLE-RFQ-${UUID.randomUUID().toString().take(6).uppercase()}",
            metal = metal,
            productType = "Лом: $itemDescription ($declaredPurity проба)",
            purity = declaredPurity,
            quantityGrams = grossWeight,
            targetPricePerGram = offerPricePerGram,
            quotedPricePerGram = offerPricePerGram,
            premiumPerGram = BigDecimal.ZERO,
            discountPerGram = discount,
            deliveryLocation = "Московское хранилище",
            deliveryDate = "2026-10-04",
            settlementTerms = "T+0",
            clientName = "Розничная скупка",
            status = RfqStatus.QUOTED
        )
        _rfqs.value = _rfqs.value + buybackRfq
        return buybackRfq
    }

    fun submitAssaySample(client: String, metal: MetalType, weight: BigDecimal, purity: Double): AssayRecord {
        val record = AssayRecord(
            clientName = client,
            metal = metal,
            sampleWeightGrams = weight,
            declaredPurity = purity,
            currentStep = AssayStep.RECEIVING
        )
        _assays.value = _assays.value + record
        return record
    }

    fun advanceAssayStep(assayId: String) {
        _assays.value = _assays.value.map { record ->
            if (record.id == assayId) {
                val nextStep = when (record.currentStep) {
                    AssayStep.RECEIVING -> AssayStep.SAMPLING
                    AssayStep.SAMPLING -> AssayStep.ANALYSIS
                    AssayStep.ANALYSIS -> AssayStep.CONFIRMATION
                    AssayStep.CONFIRMATION -> AssayStep.CERTIFICATION
                    AssayStep.CERTIFICATION -> AssayStep.FINISHED
                    AssayStep.FINISHED -> AssayStep.FINISHED
                }
                val measured = if (nextStep == AssayStep.ANALYSIS) {
                    record.declaredPurity + (random.nextDouble(-1.5, 0.8))
                } else record.measuredPurity

                val certified = if (nextStep == AssayStep.CERTIFICATION) {
                    "Ведущий лаборант Котов А.В."
                } else record.certifiedBy

                // If finished, add to vault as a physical scrap block
                if (nextStep == AssayStep.FINISHED && record.currentStep != AssayStep.FINISHED) {
                    val finalPurity = measured ?: record.declaredPurity
                    val gross = record.sampleWeightGrams
                    val fine = gross.multiply(BigDecimal(finalPurity / 1000.0)).setScale(2, RoundingMode.HALF_UP)
                    val serial = "RU-${record.metal.code}-SCRAP-${record.id.takeLast(4)}"

                    _bars.value = _bars.value + BullionBar(
                        serialNumber = serial,
                        metal = record.metal,
                        purity = finalPurity,
                        grossWeightGrams = gross,
                        fineWeightGrams = fine,
                        refiner = "АО «СоюзЛаб»",
                        productionDate = "2026-10-04",
                        certificateNumber = "LAB-CERT-${record.id}",
                        vaultLocation = "Москва Хранилище",
                        owner = record.clientName,
                        status = BarStatus.AVAILABLE
                    )
                }

                record.copy(currentStep = nextStep, measuredPurity = measured, certifiedBy = certified)
            } else record
        }
    }

    fun startRefiningBatch(inputWeight: BigDecimal, inputPurity: Double, metal: MetalType) {
        val inputFine = inputWeight.multiply(BigDecimal(inputPurity / 1000.0)).setScale(2, RoundingMode.HALF_UP)
        // Expected recovery is 99.8%
        val expectedFineOutput = inputFine.multiply(BigDecimal("0.9982")).setScale(2, RoundingMode.HALF_UP)
        val expectedGrossOutput = expectedFineOutput.divide(BigDecimal("0.9999"), 2, RoundingMode.HALF_UP)
        val loss = inputFine.subtract(expectedFineOutput).setScale(2, RoundingMode.HALF_UP)

        val batch = RefineryBatch(
            inputWeight = inputWeight,
            inputPurity = inputPurity,
            inputFineWeight = inputFine,
            outputWeight = expectedGrossOutput,
            outputPurity = 999.9,
            outputFineWeight = expectedFineOutput,
            recoveryRate = BigDecimal("99.82"),
            processLoss = loss,
            status = "Аффинаж"
        )
        _refineryBatches.value = _refineryBatches.value + batch
    }

    fun completeRefiningBatch(batchId: String) {
        _refineryBatches.value = _refineryBatches.value.map { batch ->
            if (batch.batchId == batchId) {
                // Generate a real 999.9 refined investment bar from batch!
                val serial = "RU-AU-9999-REFINED-${UUID.randomUUID().toString().take(4).uppercase()}"
                _bars.value = _bars.value + BullionBar(
                    serialNumber = serial,
                    metal = MetalType.GOLD,
                    purity = 999.9,
                    grossWeightGrams = batch.outputWeight,
                    fineWeightGrams = batch.outputFineWeight,
                    refiner = "Красцветмет (Синтетика)",
                    productionDate = "2026-10-04",
                    certificateNumber = "RC-CERT-${batch.batchId}",
                    vaultLocation = "Москва Хранилище",
                    owner = "АО «СоюзРафинад»",
                    status = BarStatus.AVAILABLE
                )
                batch.copy(status = "Завершен")
            } else batch
        }
    }

    // -------------------------------------------------------------
    // Double-Entry Ledger Verification
    // -------------------------------------------------------------
    fun verifyLedgerDebitsEqualsCredits(): Boolean {
        var debitsTotal = BigDecimal.ZERO
        var creditsTotal = BigDecimal.ZERO
        _ledger.value.forEach { row ->
            if (row.isDebit) {
                debitsTotal = debitsTotal.add(row.amount)
            } else {
                creditsTotal = creditsTotal.add(row.amount)
            }
        }
        return debitsTotal.compareTo(creditsTotal) == 0
    }

    // -------------------------------------------------------------
    // Metal Ledger Invariant Verification
    // -------------------------------------------------------------
    fun calculateMetalInventory(metal: MetalType): BigDecimal {
        // Current sum of fine weights of all bars for this metal in our system
        return _bars.value
            .filter { it.metal == metal && it.status != BarStatus.REFINING }
            .map { it.fineWeightGrams }
            .fold(BigDecimal.ZERO) { acc, next -> acc.add(next) }
            .divide(BigDecimal("1000"), 3, RoundingMode.HALF_UP) // return as kg
    }

    // -------------------------------------------------------------
    // Risk Calculation
    // -------------------------------------------------------------
    fun getRiskMetrics(metal: MetalType): RiskMetrics {
        val totalFineWeightKg = calculateMetalInventory(metal)
        val tick = _ticks.value[metal]?.firstOrNull { it.type == InstrumentType.PHYSICAL }?.last ?: BigDecimal("5000")
        val fineWeightGrams = totalFineWeightKg.multiply(BigDecimal("1000"))
        val exposureRub = fineWeightGrams.multiply(tick).setScale(2, RoundingMode.HALF_UP)

        val limitRub = when (metal) {
            MetalType.GOLD -> BigDecimal("90000000.00") // 90M limit
            MetalType.SILVER -> BigDecimal("30000000.00") // 30M limit
            MetalType.PLATINUM -> BigDecimal("25000000.00") // 25M limit
            MetalType.PALLADIUM -> BigDecimal("40000000.00") // 40M limit
        }

        val utilization = exposureRub.multiply(BigDecimal("100"))
            .divide(limitRub, 2, RoundingMode.HALF_UP)

        val status = when {
            utilization >= BigDecimal("95.0") -> "ЛИМИТ ИСЧЕРПАН"
            utilization >= BigDecimal("80.0") -> "ВЫСОКАЯ НАГРУЗКА"
            else -> "НОРМА"
        }

        // Calculate hedge ratio conceptually based on our futures trades
        val physExposure = fineWeightGrams
        val hedgeExposure = _trades.value
            .filter { it.metal == metal && it.isHedge }
            .fold(BigDecimal.ZERO) { acc, t ->
                if (t.direction == TradeDirection.SELL) acc.add(t.quantityGrams) else acc.subtract(t.quantityGrams)
            }

        val ratio = if (physExposure.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ZERO else {
            hedgeExposure.multiply(BigDecimal("100")).divide(physExposure, 1, RoundingMode.HALF_UP).abs()
        }

        return RiskMetrics(
            metal = metal,
            netExposureGrams = physExposure.subtract(hedgeExposure),
            grossExposureGrams = physExposure.add(hedgeExposure),
            exposureRub = exposureRub,
            limitRub = limitRub,
            utilizationPercent = utilization,
            statusLabel = status,
            hedgeRatio = ratio
        )
    }

    // -------------------------------------------------------------
    // AI Intelligent query parser directly executing on state
    // -------------------------------------------------------------
    fun queryAiAssistant(question: String): String {
        val q = question.lowercase(Locale.getDefault()).trim()
        return when {
            q.contains("склад") || q.contains("москв") || q.contains("хранилищ") -> {
                val goldMsc = _bars.value.filter { it.metal == MetalType.GOLD && it.vaultLocation.contains("Москва") }.sumOf { it.fineWeightGrams.toDouble() } / 1000.0
                val silvMsc = _bars.value.filter { it.metal == MetalType.SILVER && it.vaultLocation.contains("Москва") }.sumOf { it.fineWeightGrams.toDouble() } / 1000.0
                val platMsc = _bars.value.filter { it.metal == MetalType.PLATINUM && it.vaultLocation.contains("Москва") }.sumOf { it.fineWeightGrams.toDouble() } / 1000.0
                val pallMsc = _bars.value.filter { it.metal == MetalType.PALLADIUM && it.vaultLocation.contains("Москва") }.sumOf { it.fineWeightGrams.toDouble() } / 1000.0

                "Запасы драгоценных металлов в Московском хранилище:\n" +
                        "• Золото: ${String.format("%.3f", goldMsc)} кг\n" +
                        "• Серебро: ${String.format("%.3f", silvMsc)} кг\n" +
                        "• Платина: ${String.format("%.3f", platMsc)} кг\n" +
                        "• Палладий: ${String.format("%.3f", pallMsc)} кг\n" +
                        "\nДанные получены из реестра Хранилища в реальном времени."
            }
            q.contains("позиц") || q.contains("серебр") -> {
                val silvInv = calculateMetalInventory(MetalType.SILVER)
                val silvVal = _ticks.value[MetalType.SILVER]?.firstOrNull { it.type == InstrumentType.PHYSICAL }?.last ?: BigDecimal("163")
                val totalRubVal = silvInv.multiply(BigDecimal("1000")).multiply(silvVal)
                "Текущие запасы Серебра составляют **${String.format("%.2f", silvInv.toDouble())} кг**.\n" +
                        "Рыночная стоимость оценивается в **₽${String.format("%,.2f", totalRubVal.toDouble())}** при учетной цене ₽$silvVal/г."
            }
            q.contains("p&l") || q.contains("прибыль") || q.contains("убыток") -> {
                // Calculate P&L synthetically from trades
                var totalTradesPnl = BigDecimal("18500000.00")
                _trades.value.filter { !it.isHedge }.forEach { t ->
                    totalTradesPnl = if (t.direction == TradeDirection.SELL) {
                        totalTradesPnl.add(t.totalValue.multiply(BigDecimal("0.02"))) // 2% spread margin
                    } else {
                        totalTradesPnl.add(t.totalValue.multiply(BigDecimal("0.01")))
                    }
                }
                "Сводный финансовый отчет Платформы ЗОЛОТО за сегодня:\n" +
                        "• Операционный P&L: **₽${String.format("%,.2f", totalTradesPnl.toDouble())}**\n" +
                        "• Торговый P&L (Спот/Своп): ₽8,400,000.00\n" +
                        "• Доход от премий (Слитки): ₽2,100,000.00\n" +
                        "• Оценка изменения стоимости запасов: ₽8,000,000.00\n" +
                        "Все балансовые счета проверены. Дебет равен Кредиту."
            }
            q.contains("лимит") || q.contains("кредит") -> {
                val goldRisk = getRiskMetrics(MetalType.GOLD)
                val pallRisk = getRiskMetrics(MetalType.PALLADIUM)
                "Проверка лимитов концентрации рисков:\n" +
                        "• Лимит по Золоту: ₽${String.format("%,.0f", goldRisk.limitRub.toDouble())} " +
                        "(Использовано: ${String.format("%.1f", goldRisk.utilizationPercent.toDouble())}% - ${goldRisk.statusLabel})\n" +
                        "• Лимит по Палладию: ₽${String.format("%,.0f", pallRisk.limitRub.toDouble())} " +
                        "(Использовано: ${String.format("%.1f", pallRisk.utilizationPercent.toDouble())}% - ${pallRisk.statusLabel})\n" +
                        "Действия при ВЫСОКОЙ НАГРУЗКЕ: Выполните хеджирование фьючерсами MOEX или сократите остатки на складе."
            }
            q.contains("платин") || q.contains("стоимость") -> {
                val platInv = calculateMetalInventory(MetalType.PLATINUM)
                val platVal = _ticks.value[MetalType.PLATINUM]?.firstOrNull { it.type == InstrumentType.PHYSICAL }?.last ?: BigDecimal("4636")
                val totalRubVal = platInv.multiply(BigDecimal("1000")).multiply(platVal)
                "Текущие запасы Платины составляют **${String.format("%.2f", platInv.toDouble())} кг**.\n" +
                        "Текущая рыночная стоимость запасов оценивается в **₽${String.format("%,.2f", totalRubVal.toDouble())}**."
            }
            q.contains("изменен") || q.contains("30") || q.contains("золот") -> {
                val goldTick = _ticks.value[MetalType.GOLD]?.firstOrNull { it.type == InstrumentType.SPOT }
                val change = goldTick?.changePercent ?: BigDecimal("2.4")
                "Изменение стоимости Золота за прошедшие 30 дней составляет **+$change%**.\n" +
                        "Текущая котировка Спот на МосБирже: **₽${goldTick?.last ?: "11143"}/г**. Направление тренда: восходящее."
            }
            q.contains("хедж") || q.contains("доля") -> {
                val goldRisk = getRiskMetrics(MetalType.GOLD)
                "Уровень хеджирования портфеля:\n" +
                        "• Золото: захеджировано на **${String.format("%.1f", goldRisk.hedgeRatio.toDouble())}%** позиции физического металла.\n" +
                        "• Хеджирующие инструменты: Deliverable Futures (GLD) на MOEX.\n" +
                        "Целевой диапазон хеджа: 80% - 95%. Текущий статус: сбалансировано."
            }
            else -> {
                "Приветствую! Я ЗОЛОТО AI — ваш финансовый аналитик по драгоценным металлам в Российской Федерации. Я имею прямой доступ к закрытому реестру слитков, сделок, лимитов риска и ведомостей аффинажного завода.\n\n" +
                        "Вы можете задать мне точные вопросы:\n" +
                        "• «Сколько золота сейчас на складе Москвы?»\n" +
                        "• «Покажи текущую позицию по серебру.»\n" +
                        "• «Какой сегодня P&L?»\n" +
                        "• «Какие клиенты приближаются к кредитному лимиту?»\n" +
                        "• «Какова стоимость запасов платины?»\n" +
                        "• «Покажи изменение золота за 30 дней.»"
            }
        }
    }
}
