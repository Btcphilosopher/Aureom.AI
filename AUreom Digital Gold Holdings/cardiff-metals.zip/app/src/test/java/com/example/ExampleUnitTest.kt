package com.example

import com.example.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode

class ExampleUnitTest {

    @Test
    fun `test troy ounce exact conversion factor`() {
        // Section 16: 1 troy oz = 31.1034768 g
        val troyOzFactor = WeightUnit.TROY_OUNCES.gramsFactor
        assertEquals(BigDecimal("31.1034768"), troyOzFactor)

        // Convert 1 troy oz to grams
        val grams = WeightUnit.TROY_OUNCES.toGrams(BigDecimal.ONE)
        assertEquals(BigDecimal("31.1034768"), grams)

        // Convert 100g back to troy oz
        val oz = WeightUnit.TROY_OUNCES.fromGrams(BigDecimal("100.0"))
        // 100 / 31.1034768 = 3.21507466
        assertEquals(BigDecimal("3.21507466"), oz.setScale(8, RoundingMode.HALF_UP))
    }

    @Test
    fun `test purity fine weight formula`() {
        // Section 14: 100 g * 0.9999 = 99.99 g fine gold
        val grossWeight = BigDecimal("100.00")
        val purity = BigDecimal("0.9999")
        val fineWeight = PurityEngine.calculateFineWeight(grossWeight, purity)
        assertEquals(BigDecimal("99.9900"), fineWeight)
    }

    @Test
    fun `test spread engine explicit calculations`() {
        // Section 7: Sell Price > Spot > Buy Price
        val spotPrice = BigDecimal("2000.00") // GBP per Oz
        val quote = SpreadEngine.calculateCustomerPrices(
            metalType = MetalType.GOLD,
            spotGbpPerOz = spotPrice,
            volumeGbp = BigDecimal("1000.00")
        )

        // Buy price should be less than spot
        assertTrue(quote.ourBuyPriceGbpPerOz < spotPrice)
        // Sell price should be greater than spot
        assertTrue(quote.ourSellPriceGbpPerOz > spotPrice)
        // Spread matches difference
        assertEquals(quote.spreadGbp, quote.ourSellPriceGbpPerOz.subtract(quote.ourBuyPriceGbpPerOz))
    }

    @Test
    fun `test HMRC investment gold is VAT exempt`() {
        // Section 41: Qualifying Investment Gold is VAT exempt
        val goldClassification = TaxClassification(
            metalType = MetalType.GOLD,
            typeName = "Bar",
            purity = BigDecimal("0.9999"),
            isPreOwned = false,
            isStoredInVault = false,
            transactionType = "CUSTOMER_BUY"
        )
        val taxResult = TaxEngine.calculateTax(goldClassification, BigDecimal("10000.00"))
        assertEquals("EXEMPT", taxResult.taxTreatment)
        assertEquals(BigDecimal.ZERO.setScale(2), taxResult.vatAmountGbp.setScale(2))
    }

    @Test
    fun `test silver delivery VAT is standard 20 percent`() {
        // Section 42: Physical Silver delivery standard VAT is 20%
        val silverClassification = TaxClassification(
            metalType = MetalType.SILVER,
            typeName = "Bar",
            purity = BigDecimal("0.999"),
            isPreOwned = false,
            isStoredInVault = false,
            transactionType = "CUSTOMER_BUY"
        )
        val taxResult = TaxEngine.calculateTax(silverClassification, BigDecimal("1000.00"))
        assertEquals("STANDARD_20_PERCENT", taxResult.taxTreatment)
        assertEquals(BigDecimal("200.00"), taxResult.vatAmountGbp)
    }

    @Test
    fun `test second hand silver margin scheme`() {
        // Section 43: Margins scheme pre-owned silver (VAT is 20% on the difference, i.e., margin * 1/6)
        val silverMarginClassification = TaxClassification(
            metalType = MetalType.SILVER,
            typeName = "Bar",
            purity = BigDecimal("0.999"),
            isPreOwned = true,
            isStoredInVault = false,
            transactionType = "CUSTOMER_BUY"
        )
        // Buy from customer for £800, resell for £1000. Margin = £200. VAT = 200 * 1/6 = £33.33
        val taxResult = TaxEngine.calculateTax(
            silverMarginClassification,
            netAmountGbp = BigDecimal("1000.00"),
            purchaseCostGbp = BigDecimal("800.00")
        )
        assertEquals("MARGIN_SCHEME", taxResult.taxTreatment)
        assertEquals(BigDecimal("33.33"), taxResult.vatAmountGbp)
    }
}
