package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cardiff Metals Premium Welsh Precious-Metals House Palette
val Charcoal = Color(0xFF121416)
val Graphite = Color(0xFF23272A)
val Slate = Color(0xFF4A525A)
val DeepNavy = Color(0xFF0C1620)
val DarkWelshGreen = Color(0xFF0F2C20)
val WarmWhite = Color(0xFFF9F6F0)
val PureWhite = Color(0xFFFFFFFF)

// Restrained Material Accents
val RestrainedGold = Color(0xFFC59B27)      // Refined metallic bullion gold
val RestrainedSilver = Color(0xFF9EB2C0)    // High-grade bullion silver

// Functional status colors
val EmeraldGreen = Color(0xFF22C55E)
val CrimsonRed = Color(0xFFEF4444)
val AmberOrange = Color(0xFFF59E0B)
val LightIceBlue = Color(0xFFF0F4F8)
