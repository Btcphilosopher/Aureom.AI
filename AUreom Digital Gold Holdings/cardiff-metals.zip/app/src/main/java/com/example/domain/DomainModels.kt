package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID
import java.time.Instant

// --- METAL TYPES ---
enum class MetalType {
    GOLD, SILVER
}

// --- WEIGHT ENGINE ---
enum class WeightUnit(val unitName: String, val gramsFactor: BigDecimal) {
    GRAMS("g", BigDecimal("1.0")),
    KILOGRAMS("kg", BigDecimal("1000.0")),
    TROY_OUNCES("oz t", BigDecimal("31.1034768")), // Explicit canonical conversion
    PENNYWEIGHTS("dwt", BigDecimal("1.55517384")),
    MILLIGRAMS("mg", BigDecimal("0.001"));

    fun toGrams(amount: BigDecimal): BigDecimal {
        return amount.multiply(this.gramsFactor)
    }

    fun fromGrams(grams: BigDecimal): BigDecimal {
        return grams.divide(this.gramsFactor, 8, RoundingMode.HALF_UP)
    }
}

// --- PURITY ENGINE ---
object PurityEngine {
    // Standard supported purities
    val SUPPORTED_PURITIES = listOf(
        BigDecimal("0.9999"), // 999.9 Fine (Bullion)
        BigDecimal("0.999"),  // 999 Fine
        BigDecimal("0.9167"), // 22ct Sovereign/Krugerrand
        BigDecimal("0.750"),  // 18ct Jewellery
        BigDecimal("0.585"),  // 14ct Jewellery
        BigDecimal("0.375")   // 9ct Jewellery
    )

    fun calculateFineWeight(grossWeightGrams: BigDecimal, purity: BigDecimal): BigDecimal {
        return grossWeightGrams.multiply(purity).setScale(4, RoundingMode.HALF_UP)
    }
}

// --- PHYSICAL ASSET OBJECTS ---
data class PhysicalObject(
    val objectId: String = UUID.randomUUID().toString(),
    val metalType: MetalType,
    val typeName: String, // "Bar", "Coin", "Jewellery Scrap", "Silverware"
    val brand: String, // "Valcambi", "PAMP", "Royal Mint", "Heuristics"
    val serialNumber: String?,
    val grossWeightGrams: BigDecimal,
    val purity: BigDecimal,
    val fineWeightGrams: BigDecimal,
    val hallmarkInfo: HallmarkInfo?,
    val purchasePrice: BigDecimal,
    val purchaseDate: Instant = Instant.now(),
    val ownerId: String, // "MERCHANT" or Customer KYC ID
    val status: InventoryStatus = InventoryStatus.MERCHANT_INVENTORY,
    val vaultLocation: String = "CARDIFF_MAIN_VAULT",
    val assayStatus: AssayStatus = AssayStatus.COMPLETED
)

enum class InventoryStatus {
    MERCHANT_INVENTORY,
    CUSTOMER_ALLOCATED,
    IN_TRANSIT,
    SOLD_OUT
}

enum class AssayStatus {
    PENDING, COMPLETED, REJECTED
}

data class HallmarkInfo(
    val sponsorMark: String,
    val finenessMark: String,
    val assayOffice: String, // e.g. "Cardiff", "London", "Birmingham"
    val dateLetter: String?,
    val welshHallmarkMetadata: String? = "Welsh Dragon Hallmark Verified"
)

// --- BRITISH COINS ARCHITECTURE ---
data class BritishCoin(
    val id: String,
    val name: String,
    val year: Int,
    val metalType: MetalType,
    val grossWeightGrams: BigDecimal,
    val purity: BigDecimal,
    val fineWeightGrams: BigDecimal,
    val faceValueGBP: BigDecimal,
    val marketPremiumPercent: BigDecimal,
    val cgtExempt: Boolean = true, // British legal tender is CGT-exempt
    val vatExempt: Boolean // Investment Gold is VAT exempt, Silver is NOT
) {
    companion object {
        fun createSovereign(year: Int): BritishCoin {
            return BritishCoin(
                id = "COIN-SOV-$year",
                name = "Gold Sovereign ($year)",
                year = year,
                metalType = MetalType.GOLD,
                grossWeightGrams = BigDecimal("7.9881"),
                purity = BigDecimal("0.9167"),
                fineWeightGrams = BigDecimal("7.3224"),
                faceValueGBP = BigDecimal("1.00"), // Nominal face value
                marketPremiumPercent = BigDecimal("0.04"), // 4% retail premium
                cgtExempt = true,
                vatExempt = true // Investment gold
            )
        }

        fun createGoldBritannia(year: Int): BritishCoin {
            return BritishCoin(
                id = "COIN-GBR-$year",
                name = "Gold Britannia 1oz ($year)",
                year = year,
                metalType = MetalType.GOLD,
                grossWeightGrams = BigDecimal("31.21"),
                purity = BigDecimal("0.9999"),
                fineWeightGrams = BigDecimal("31.1035"),
                faceValueGBP = BigDecimal("100.00"),
                marketPremiumPercent = BigDecimal("0.025"), // 2.5% premium
                cgtExempt = true,
                vatExempt = true
            )
        }

        fun createSilverBritannia(year: Int): BritishCoin {
            return BritishCoin(
                id = "COIN-SBR-$year",
                name = "Silver Britannia 1oz ($year)",
                year = year,
                metalType = MetalType.SILVER,
                grossWeightGrams = BigDecimal("31.21"),
                purity = BigDecimal("0.999"),
                fineWeightGrams = BigDecimal("31.1035"),
                faceValueGBP = BigDecimal("2.00"),
                marketPremiumPercent = BigDecimal("0.15"), // 15% silver premium due to high physical demand
                cgtExempt = true,
                vatExempt = false // Silver is subject to standard UK VAT rules
            )
        }
    }
}

// --- CARDIFF ASSAY DESK ---
data class AssayResult(
    val assayId: String = "CF-ASSAY-" + (1000..9999).random(),
    val customerName: String,
    val itemName: String,
    val grossWeightGrams: BigDecimal,
    val declaredPurity: BigDecimal,
    val measuredPurity: BigDecimal,
    val fineWeightGrams: BigDecimal,
    val method: AssayMethod,
    val operatorName: String = "D. Jenkins (Chief Assayer)",
    val timestamp: Instant = Instant.now(),
    val confidenceScore: BigDecimal = BigDecimal("0.995"),
    val resultStatus: AssayStatus = AssayStatus.COMPLETED
)

enum class AssayMethod {
    XRF_SPECTROMETRY,
    HYDROSTATIC_DENSITY,
    ACID_TEST_VERIFICATION,
    FIRE_ASSAY_LAB_CERTIFICATE
}

// --- METAL PASSPORT ---
data class MetalPassport(
    val passportId: String,
    val barSerial: String,
    val metalType: MetalType,
    val grossWeight: BigDecimal,
    val purity: BigDecimal,
    val fineWeight: BigDecimal,
    val assayReference: String,
    val ownerName: String,
    val vaultLocation: String = "Cardiff Main Vault",
    val custodyStatus: String = "ALLOCATED",
    val issueDate: Instant = Instant.now()
)

// --- CUSTOMER KYC, COMPLIANCE & PROVENANCE ---
data class CustomerKYC(
    val customerId: String = UUID.randomUUID().toString(),
    val fullName: String,
    val email: String,
    val dateOfBirth: String,
    val address: String,
    val idVerificationStatus: String = "VERIFIED (WELSH IDENTITY SCHEME)",
    val riskRating: String = "LOW", // LOW, MEDIUM, HIGH
    val sourceOfFunds: String = "Corporate Dividend / Private Wealth",
    val transactionLimitGBP: BigDecimal = BigDecimal("50000.00"),
    val complianceFlags: List<String> = emptyList()
)

data class ProvenanceReview(
    val reviewId: String = "PRV-" + (10000..99999).random(),
    val sellerId: String,
    val sourceDeclaration: String, // e.g. "Family inheritance", "Sovereign liquidation"
    val countryOfOrigin: String = "United Kingdom",
    val previousOwner: String = "Self / Family",
    val reasonForSale: String = "Showroom trade-in",
    val riskScore: Int = 12, // out of 100
    val approvedBy: String = "E. Morgan (Compliance Officer)",
    val timestamp: Instant = Instant.now()
)

// --- DOUBLE-ENTRY ACCOUNTING LEDGER ---
data class LedgerEntry(
    val entryId: String = UUID.randomUUID().toString(),
    val transactionId: String,
    val timestamp: Instant = Instant.now(),
    val description: String,
    val debitAccount: LedgerAccount,
    val creditAccount: LedgerAccount,
    val amount: BigDecimal,
    val metalType: MetalType? = null,
    val metalAmountGrams: BigDecimal = BigDecimal.ZERO
)

enum class LedgerAccount {
    CASH_GBP,
    GOLD_INVENTORY,
    SILVER_INVENTORY,
    CUSTOMER_ALLOCATED_GOLD,
    CUSTOMER_ALLOCATED_SILVER,
    MERCHANT_VAULT_RESERVES,
    SALES_REVENUE,
    DEALER_MARGIN,
    STORAGE_FEES,
    TAX_VAT_COLLECTED,
    SETTLEMENT_SUSPENSE
}

// --- EVENT SOURCING LOG ---
sealed class CardiffEvent {
    abstract val eventId: String
    abstract val timestamp: Instant

    data class SpotPriceUpdated(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val goldSpotGbp: BigDecimal,
        val silverSpotGbp: BigDecimal
    ) : CardiffEvent()

    data class QuoteCreated(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val quoteId: String,
        val metalType: MetalType,
        val isSellToUs: Boolean,
        val grossWeightGrams: BigDecimal,
        val purity: BigDecimal,
        val spotRefPriceGbp: BigDecimal,
        val dealerPriceGbp: BigDecimal,
        val expiresAt: Instant
    ) : CardiffEvent()

    data class QuoteExpired(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val quoteId: String
    ) : CardiffEvent()

    data class OrderCreated(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val orderId: String,
        val customerName: String,
        val metalType: MetalType,
        val isCustomerBuying: Boolean, // BUY = true, SELL = false
        val itemDescription: String,
        val weightGrams: BigDecimal,
        val totalCostGbp: BigDecimal,
        val vatPaidGbp: BigDecimal,
        val status: String
    ) : CardiffEvent()

    data class AssetAllocated(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val objectId: String,
        val serialNumber: String,
        val customerName: String
    ) : CardiffEvent()

    data class VaultDeposit(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val metalType: MetalType,
        val weightGrams: BigDecimal,
        val depositor: String
    ) : CardiffEvent()

    data class SettlementCompleted(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val transactionId: String,
        val cashSettledGbp: BigDecimal,
        val metalAllocatedGrams: BigDecimal
    ) : CardiffEvent()

    data class ReconciliationCompleted(
        override val eventId: String = UUID.randomUUID().toString(),
        override val timestamp: Instant = Instant.now(),
        val exceptionFound: Boolean,
        val summaryText: String
    ) : CardiffEvent()
}
