package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

data class AppState(
    val currentTab: NavigationTab = NavigationTab.HOME,
    val currentPrices: SpotPrices = CardiffDatabase.currentPrices,
    val livePriceTicksEnabled: Boolean = true,
    
    // Portfolio holds
    val cashBalance: BigDecimal = CardiffDatabase.cashBalanceGbp,
    val physicalGoldGrams: BigDecimal = CardiffDatabase.physicalGoldGrams,
    val physicalSilverGrams: BigDecimal = CardiffDatabase.physicalSilverGrams,
    val customerPassports: List<MetalPassport> = CardiffDatabase.metalPassports,
    
    // Calculator States
    val calcMetalType: MetalType = MetalType.GOLD,
    val calcWeightGrams: String = "100.0",
    val calcPurity: BigDecimal = BigDecimal("0.9999"),
    val calcActionBuy: Boolean = false, // false = Sell to Us, true = Buy from Us
    val calcIsStoredInVault: Boolean = true,
    val calcResult: CalculationResult? = null,
    
    // Active Quote Expiries (Price Lock)
    val activeQuoteId: String? = null,
    val activeQuote: DealerQuote? = null,
    val activeQuoteTimeLeftSec: Int = 0,
    val activeQuoteMessage: String? = null,
    
    // Assay Desk States
    val assayCustomerName: String = "Welsh Heritage Trust",
    val assayItemName: String = "Vintage 18ct Welsh Dragon Pendant",
    val assayWeightGrams: String = "45.80",
    val assayDeclaredPurity: BigDecimal = BigDecimal("0.750"), // 18ct
    val assaySelectedMethod: AssayMethod = AssayMethod.XRF_SPECTROMETRY,
    val latestAssayResult: AssayResult? = null,
    val assayQueue: List<AssayResult> = CardiffDatabase.assays,

    // Compliance States
    val complianceCases: List<ComplianceCase> = CardiffDatabase.complianceCases,
    val selectedComplianceCase: ComplianceCase? = null,
    val provenanceDeclaration: String = "Showroom Trade-In (Family Estate)",
    val countryOfOrigin: String = "Wales, UK",
    val riskAssessmentPassed: Boolean = false,

    // Ledger & Events logs
    val ledgerEntries: List<LedgerEntry> = CardiffDatabase.doubleEntryLedger,
    val eventsLog: List<CardiffEvent> = CardiffDatabase.eventsLog,
    val orders: List<OrderRecord> = CardiffDatabase.orders,
    val reconciliationRuns: List<ReconciliationRun> = CardiffDatabase.reconciliationRuns,

    // Showroom map location selection
    val selectedFacility: FacilityLocation? = null,
    
    // R-Analytics Simulation Metrics
    val monteCarloForecastDays: Int = 30,
    val simulatedPAndL: BigDecimal = BigDecimal("14250.00")
)

enum class NavigationTab {
    HOME, MARKET, SERVICES, VAULT, AUDIT
}

data class CalculationResult(
    val grossValue: BigDecimal,
    val dealerAdjustment: BigDecimal,
    val finalOffer: BigDecimal,
    val vatAmount: BigDecimal,
    val description: String,
    val taxTreatment: String
)

data class FacilityLocation(
    val name: String,
    val region: String,
    val type: String, // "Showroom", "Security Vault", "Customer Support Center"
    val address: String,
    val status: String = "Operational"
)

class CardiffViewModel : ViewModel() {

    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private var priceTickerJob: Job? = null
    private var quoteCountdownJob: Job? = null

    init {
        startPriceTicker()
        triggerCalculation() // Initialize default calc results
        CardiffDatabase.reconcileBalances() // Run initial audit
        refreshStateFromDatabase()
    }

    private fun startPriceTicker() {
        priceTickerJob?.cancel()
        priceTickerJob = viewModelScope.launch {
            while (true) {
                if (_state.value.livePriceTicksEnabled) {
                    CardiffDatabase.tickPrices()
                    refreshStateFromDatabase()
                }
                delay(4000) // update prices every 4 seconds
            }
        }
    }

    fun toggleLivePriceTicks() {
        _state.update { it.copy(livePriceTicksEnabled = !it.livePriceTicksEnabled) }
    }

    fun selectTab(tab: NavigationTab) {
        _state.update { it.copy(currentTab = tab) }
    }

    fun setCalculatorParams(
        metalType: MetalType? = null,
        weight: String? = null,
        purity: BigDecimal? = null,
        actionBuy: Boolean? = null,
        storedInVault: Boolean? = null
    ) {
        _state.update { s ->
            s.copy(
                calcMetalType = metalType ?: s.calcMetalType,
                calcWeightGrams = weight ?: s.calcWeightGrams,
                calcPurity = purity ?: s.calcPurity,
                calcActionBuy = actionBuy ?: s.calcActionBuy,
                calcIsStoredInVault = storedInVault ?: s.calcIsStoredInVault
            )
        }
        triggerCalculation()
    }

    private fun triggerCalculation() {
        val s = _state.value
        val weightG = s.calcWeightGrams.toBigDecimalOrNull() ?: BigDecimal.ZERO
        if (weightG <= BigDecimal.ZERO) {
            _state.update { it.copy(calcResult = null) }
            return
        }

        val spotPerOz = if (s.calcMetalType == MetalType.GOLD) s.currentPrices.goldGbpPerOz else s.currentPrices.silverGbpPerOz
        val weightOz = weightG.divide(WeightUnit.TROY_OUNCES.gramsFactor, 8, RoundingMode.HALF_UP)
        val grossMetalValue = spotPerOz.multiply(weightOz).setScale(2, RoundingMode.HALF_UP)

        // Run through spread engine to fetch quote parameters
        val quote = SpreadEngine.calculateCustomerPrices(s.calcMetalType, spotPerOz, grossMetalValue)

        val customerPricePerOz = if (s.calcActionBuy) quote.ourSellPriceGbpPerOz else quote.ourBuyPriceGbpPerOz
        val finalMetalValue = customerPricePerOz.multiply(weightOz).setScale(2, RoundingMode.HALF_UP)
        val dealerAdjustment = grossMetalValue.subtract(finalMetalValue).abs()

        // Calculate VAT
        val taxClassification = TaxClassification(
            metalType = s.calcMetalType,
            typeName = if (weightG < BigDecimal("50")) "Coin" else "Bar",
            purity = s.calcPurity,
            isPreOwned = !s.calcActionBuy,
            isStoredInVault = s.calcIsStoredInVault,
            transactionType = if (s.calcActionBuy) "CUSTOMER_BUY" else "CUSTOMER_SELL"
        )
        val taxResult = TaxEngine.calculateTax(taxClassification, finalMetalValue)

        _state.update {
            it.copy(
                calcResult = CalculationResult(
                    grossValue = grossMetalValue,
                    dealerAdjustment = dealerAdjustment,
                    finalOffer = finalMetalValue.add(taxResult.vatAmountGbp),
                    vatAmount = taxResult.vatAmountGbp,
                    description = taxResult.description,
                    taxTreatment = taxResult.taxTreatment
                )
            )
        }
    }

    fun requestPriceLockQuote() {
        val s = _state.value
        val weightG = s.calcWeightGrams.toBigDecimalOrNull() ?: BigDecimal.ZERO
        if (weightG <= BigDecimal.ZERO) return

        try {
            val quoteId = CardiffDatabase.createQuote(s.calcMetalType, !s.calcActionBuy, weightG, s.calcPurity)
            val quote = CardiffDatabase.quotes[quoteId]
            
            _state.update {
                it.copy(
                    activeQuoteId = quoteId,
                    activeQuote = quote,
                    activeQuoteTimeLeftSec = 60,
                    activeQuoteMessage = "Price Lock Secured (Cardiff Bullion Desks). Expires in 60s."
                )
            }
            startQuoteCountdown()
        } catch (e: Exception) {
            _state.update { it.copy(activeQuoteMessage = "Failed to lock price: ${e.message}") }
        }
    }

    private fun startQuoteCountdown() {
        quoteCountdownJob?.cancel()
        quoteCountdownJob = viewModelScope.launch {
            while (_state.value.activeQuoteTimeLeftSec > 0) {
                delay(1000)
                _state.update { s ->
                    val nextTime = s.activeQuoteTimeLeftSec - 1
                    s.copy(
                        activeQuoteTimeLeftSec = nextTime,
                        activeQuoteMessage = if (nextTime == 0) "PRICE EXPIRED: Secure new quote." else s.activeQuoteMessage
                    )
                }
            }
            // Clear active quote upon expiry
            _state.update { it.copy(activeQuoteId = null, activeQuote = null) }
        }
    }

    fun executeLockedTrade() {
        val s = _state.value
        val quoteId = s.activeQuoteId ?: return
        val weightG = s.calcWeightGrams.toBigDecimalOrNull() ?: return
        val customer = CardiffDatabase.customers.first() // Use default Cardiff private client

        viewModelScope.launch {
            try {
                CardiffDatabase.executeOrder(
                    customer = customer,
                    metalType = s.calcMetalType,
                    isCustomerBuying = s.calcActionBuy,
                    grossWeightGrams = weightG,
                    purity = s.calcPurity,
                    quoteId = quoteId,
                    isStoredInVault = s.calcIsStoredInVault
                )
                // Stop countdown and reset active quote on successful settlement
                quoteCountdownJob?.cancel()
                _state.update {
                    it.copy(
                        activeQuoteId = null,
                        activeQuote = null,
                        activeQuoteTimeLeftSec = 0,
                        activeQuoteMessage = "TRADE EXECUTED & SETTLED SUCCESSFULLY in Cardiff Vault."
                    )
                }
                refreshStateFromDatabase()
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        activeQuoteMessage = e.message ?: "Transaction error occurred."
                    )
                }
            }
        }
    }

    // --- ASSAY DESK OPERATIONS ---
    fun setAssayParams(
        name: String? = null,
        itemName: String? = null,
        weight: String? = null,
        purity: BigDecimal? = null,
        method: AssayMethod? = null
    ) {
        _state.update { s ->
            s.copy(
                assayCustomerName = name ?: s.assayCustomerName,
                assayItemName = itemName ?: s.assayItemName,
                assayWeightGrams = weight ?: s.assayWeightGrams,
                assayDeclaredPurity = purity ?: s.assayDeclaredPurity,
                assaySelectedMethod = method ?: s.assaySelectedMethod
            )
        }
    }

    fun runAssayTest() {
        val s = _state.value
        val weightG = s.assayWeightGrams.toBigDecimalOrNull() ?: BigDecimal.ZERO
        if (weightG <= BigDecimal.ZERO) return

        // Simple fluctuation representing chemical variations discovered during spectrometry
        val randomOffset = BigDecimal((-10..10).random().toDouble() / 10000.0)
        val measuredPurity = s.assayDeclaredPurity.add(randomOffset).coerceIn(BigDecimal("0.10"), BigDecimal("0.9999"))
        val fineWeight = weightG.multiply(measuredPurity).setScale(4, RoundingMode.HALF_UP)

        val result = AssayResult(
            customerName = s.assayCustomerName,
            itemName = s.assayItemName,
            grossWeightGrams = weightG,
            declaredPurity = s.assayDeclaredPurity,
            measuredPurity = measuredPurity,
            fineWeightGrams = fineWeight,
            method = s.assaySelectedMethod,
            confidenceScore = BigDecimal("0.995").add(BigDecimal((-5..4).random().toDouble() / 1000.0))
        )

        CardiffDatabase.assays.add(result)
        _state.update {
            it.copy(
                latestAssayResult = result,
                assayQueue = CardiffDatabase.assays.toList()
            )
        }

        CardiffDatabase.emitEvent(
            CardiffEvent.OrderCreated(
                orderId = result.assayId,
                customerName = result.customerName,
                metalType = MetalType.GOLD, // Assumed Gold for cataloging
                isCustomerBuying = false,
                itemDescription = "Physical Assay: ${result.itemName}",
                weightGrams = result.grossWeightGrams,
                totalCostGbp = BigDecimal("150.00"), // Fixed assay lab fee
                vatPaidGbp = BigDecimal("30.00"),
                status = "COMPLETED"
            )
        )
        refreshStateFromDatabase()
    }

    // --- COMPLIANCE MANAGEMENT ---
    fun selectComplianceCase(case: ComplianceCase) {
        _state.update { it.copy(selectedComplianceCase = case) }
    }

    fun updateProvenanceDetails(declaration: String, country: String) {
        _state.update {
            it.copy(
                provenanceDeclaration = declaration,
                countryOfOrigin = country
            )
        }
    }

    fun approveComplianceCase() {
        val currentCase = _state.value.selectedComplianceCase ?: return
        currentCase.status = "VERIFIED_APPROVED"

        // Insert provenance approval audit trail
        val auditTrail = ProvenanceReview(
            sellerId = currentCase.customerId,
            sourceDeclaration = _state.value.provenanceDeclaration,
            countryOfOrigin = _state.value.countryOfOrigin
        )

        CardiffDatabase.emitEvent(
            CardiffEvent.SettlementCompleted(
                transactionId = currentCase.caseId,
                cashSettledGbp = BigDecimal.ZERO,
                metalAllocatedGrams = BigDecimal.ZERO
            )
        )

        _state.update {
            it.copy(
                selectedComplianceCase = null,
                complianceCases = CardiffDatabase.complianceCases.toList()
            )
        }
        refreshStateFromDatabase()
    }

    fun runManualAuditReconciliation() {
        CardiffDatabase.reconcileBalances()
        refreshStateFromDatabase()
    }

    // --- MAP FACILITY SELECTOR ---
    fun selectFacility(facility: FacilityLocation?) {
        _state.update { it.copy(selectedFacility = facility) }
    }

    // --- STATE SYNC ---
    private fun refreshStateFromDatabase() {
        _state.update { s ->
            s.copy(
                currentPrices = CardiffDatabase.currentPrices,
                cashBalance = CardiffDatabase.cashBalanceGbp,
                physicalGoldGrams = CardiffDatabase.physicalGoldGrams,
                physicalSilverGrams = CardiffDatabase.physicalSilverGrams,
                customerPassports = CardiffDatabase.metalPassports.toList(),
                ledgerEntries = CardiffDatabase.doubleEntryLedger.toList(),
                eventsLog = CardiffDatabase.eventsLog.toList(),
                orders = CardiffDatabase.orders.toList(),
                reconciliationRuns = CardiffDatabase.reconciliationRuns.toList(),
                complianceCases = CardiffDatabase.complianceCases.toList()
            )
        }
        triggerCalculation() // update calculator values based on ticked price
    }
}
