package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val formatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    .withZone(ZoneId.systemDefault())

@Composable
fun CardiffAppMainScreen(viewModel: CardiffViewModel) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = state.currentTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = getTabIcon(tab),
                                contentDescription = tab.name,
                                tint = if (state.currentTab == tab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = tab.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.currentTab == tab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // 1. BRAND HEADER & SPOT PRICE BAR
            BrandHeader(
                liveUpdate = state.livePriceTicksEnabled,
                onToggleLive = { viewModel.toggleLivePriceTicks() }
            )

            SpotPriceBar(prices = state.currentPrices)

            // 2. MAIN SCROLLABLE CONTENT WITH TAB SWITCHING
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (state.currentTab) {
                    NavigationTab.HOME -> HomeScreen(state = state, viewModel = viewModel)
                    NavigationTab.MARKET -> MarketScreen(state = state, viewModel = viewModel)
                    NavigationTab.SERVICES -> ServicesScreen(state = state, viewModel = viewModel)
                    NavigationTab.VAULT -> VaultScreen(state = state, viewModel = viewModel)
                    NavigationTab.AUDIT -> AuditScreen(state = state, viewModel = viewModel)
                }
            }
        }
    }
}

// --- SHARED UI COMPONENTS ---

@Composable
fun BrandHeader(liveUpdate: Boolean, onToggleLive: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        com.example.ui.theme.DarkWelshGreen,
                        com.example.ui.theme.Charcoal
                    )
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CARDIFF METALS",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp,
                    color = com.example.ui.theme.RestrainedGold,
                    fontFamily = FontFamily.Serif
                )
                Text(
                    text = "CARDIFF GOLD & SILVER • EST. 2026",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp,
                    color = com.example.ui.theme.WarmWhite.copy(alpha = 0.7f)
                )
            }

            // Price Ticker Status Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { onToggleLive() }
                    .background(
                        color = if (liveUpdate) com.example.ui.theme.DarkWelshGreen else com.example.ui.theme.Slate,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = if (liveUpdate) com.example.ui.theme.EmeraldGreen else com.example.ui.theme.CrimsonRed,
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (liveUpdate) "LIVE PRICE ON" else "PRICE PAUSED",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun SpotPriceBar(prices: SpotPrices) {
    // Computes Bid, Ask, Mid
    val goldMid = prices.goldGbpPerOz
    val goldBid = goldMid.subtract(BigDecimal("15.50"))
    val goldAsk = goldMid.add(BigDecimal("15.50"))

    val silverMid = prices.silverGbpPerOz
    val silverBid = silverMid.subtract(BigDecimal("0.65"))
    val silverAsk = silverMid.add(BigDecimal("0.65"))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(com.example.ui.theme.Graphite)
            .border(width = 1.dp, color = com.example.ui.theme.Slate.copy(alpha = 0.3f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Gold Spot Component
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(com.example.ui.theme.RestrainedGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    "GOLD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = com.example.ui.theme.RestrainedGold
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = "£${goldMid.setScale(2, RoundingMode.HALF_UP)}/oz",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = com.example.ui.theme.WarmWhite
                )
                Row {
                    Text("Bid £${goldBid.setScale(1, RoundingMode.HALF_UP)}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ask £${goldAsk.setScale(1, RoundingMode.HALF_UP)}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "+0.64%",
                color = com.example.ui.theme.EmeraldGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        VerticalDivider(modifier = Modifier.height(24.dp), color = com.example.ui.theme.Slate.copy(alpha = 0.5f))

        // Silver Spot Component
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(com.example.ui.theme.RestrainedSilver.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    "SILVER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = com.example.ui.theme.RestrainedSilver
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = "£${silverMid.setScale(2, RoundingMode.HALF_UP)}/oz",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = com.example.ui.theme.WarmWhite
                )
                Row {
                    Text("Bid £${silverBid.setScale(2, RoundingMode.HALF_UP)}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ask £${silverAsk.setScale(2, RoundingMode.HALF_UP)}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "+1.21%",
                color = com.example.ui.theme.EmeraldGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// --- NAVIGATION HOOKS ---
private fun getTabIcon(tab: NavigationTab): ImageVector {
    return when (tab) {
        NavigationTab.HOME -> Icons.Default.Home
        NavigationTab.MARKET -> Icons.Default.TrendingUp
        NavigationTab.SERVICES -> Icons.Default.Science
        NavigationTab.VAULT -> Icons.Default.Lock
        NavigationTab.AUDIT -> Icons.Default.AccountBalance
    }
}

// --- TAB SCREENS ---

// 1. HOME SCREEN
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(state: AppState, viewModel: CardiffViewModel) {
    var showQuickPremiumBreakdown by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Welcoming Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.RestrainedGold.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "WELSH BULLION MERCHANT",
                        style = MaterialTheme.typography.labelSmall,
                        color = com.example.ui.theme.RestrainedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "We Buy Gold. We Sell Gold. We Buy Silver. We Sell Silver.",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = com.example.ui.theme.WarmWhite
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Cardiff Metals provides fully transparent physical bullion trading. Every transaction matches our live synthetic market-references with explicit spreads, formal assays, and double-entry vault balance audit trails.",
                        style = MaterialTheme.typography.bodySmall,
                        color = com.example.ui.theme.WarmWhite.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // The Five-Second Pricing Obviousness Rule Check (Section 79)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(com.example.ui.theme.DarkWelshGreen.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                    .border(width = 1.dp, color = com.example.ui.theme.RestrainedGold.copy(alpha = 0.4f), shape = RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TRANSPARENT PRICING MODEL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                    Text("HMRC-v1 Compliant", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Gold prices
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("GOLD SPOT", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("£${state.currentPrices.goldGbpPerOz.setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WE BUY (-Spread)", fontSize = 11.sp, color = com.example.ui.theme.CrimsonRed)
                        Text("£${(state.currentPrices.goldGbpPerOz.multiply(BigDecimal("0.98"))).setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = com.example.ui.theme.WarmWhite)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("WE SELL (+Premium)", fontSize = 11.sp, color = com.example.ui.theme.EmeraldGreen)
                        Text("£${(state.currentPrices.goldGbpPerOz.multiply(BigDecimal("1.02"))).setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = com.example.ui.theme.WarmWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Silver prices
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("SILVER SPOT", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("£${state.currentPrices.silverGbpPerOz.setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WE BUY (-Spread)", fontSize = 11.sp, color = com.example.ui.theme.CrimsonRed)
                        Text("£${(state.currentPrices.silverGbpPerOz.multiply(BigDecimal("0.94"))).setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = com.example.ui.theme.WarmWhite)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("WE SELL (+Premium)", fontSize = 11.sp, color = com.example.ui.theme.EmeraldGreen)
                        Text("£${(state.currentPrices.silverGbpPerOz.multiply(BigDecimal("1.06"))).setScale(2, RoundingMode.HALF_UP)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = com.example.ui.theme.WarmWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Prices update continuously. Final prices are confirmed at execution/assay where applicable.",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = com.example.ui.theme.RestrainedSilver.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Action Quick Selection Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.setCalculatorParams(metalType = MetalType.GOLD, actionBuy = false) },
                    modifier = Modifier.weight(1f).height(42.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.Graphite),
                    border = BorderStroke(1.dp, com.example.ui.theme.CrimsonRed.copy(alpha = 0.5f))
                ) {
                    Text("SELL GOLD TO US", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                }

                Button(
                    onClick = { viewModel.setCalculatorParams(metalType = MetalType.GOLD, actionBuy = true) },
                    modifier = Modifier.weight(1f).height(42.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.DarkWelshGreen),
                    border = BorderStroke(1.dp, com.example.ui.theme.EmeraldGreen.copy(alpha = 0.5f))
                ) {
                    Text("BUY GOLD FROM US", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                }
            }
        }

        // INSTANT PRECIOUS METALS CALCULATOR
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.Slate.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "INSTANT PRECIOUS-METALS CALCULATOR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.RestrainedGold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Metal Choice Selector Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setCalculatorParams(metalType = MetalType.GOLD) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.calcMetalType == MetalType.GOLD) com.example.ui.theme.RestrainedGold else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                            )
                        ) {
                            Text("GOLD", color = if (state.calcMetalType == MetalType.GOLD) Color.Black else Color.White)
                        }

                        Button(
                            onClick = { viewModel.setCalculatorParams(metalType = MetalType.SILVER) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.calcMetalType == MetalType.SILVER) com.example.ui.theme.RestrainedSilver else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                            )
                        ) {
                            Text("SILVER", color = if (state.calcMetalType == MetalType.SILVER) Color.Black else Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Weight Input Field
                    OutlinedTextField(
                        value = state.calcWeightGrams,
                        onValueChange = { viewModel.setCalculatorParams(weight = it) },
                        label = { Text("Physical Gross Weight (g)") },
                        modifier = Modifier.fillMaxWidth().testTag("weight_input_calculator"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = com.example.ui.theme.RestrainedGold,
                            unfocusedBorderColor = com.example.ui.theme.Slate
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Purity Option chips
                    Text("Select Metal Purity (Fineness)", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PurityEngine.SUPPORTED_PURITIES.forEach { purity ->
                            val isSelected = state.calcPurity.compareTo(purity) == 0
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setCalculatorParams(purity = purity) },
                                label = { Text("${purity.multiply(BigDecimal("1000"))} (${getPurityCarat(purity)})") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = com.example.ui.theme.RestrainedGold,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Custody Choice (Take Delivery / Store Securely in Vault)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(com.example.ui.theme.Charcoal, RoundedCornerShape(8.dp))
                            .clickable { viewModel.setCalculatorParams(storedInVault = !state.calcIsStoredInVault) }
                            .padding(10.dp)
                    ) {
                        Checkbox(
                            checked = state.calcIsStoredInVault,
                            onCheckedChange = { viewModel.setCalculatorParams(storedInVault = it) },
                            colors = CheckboxDefaults.colors(checkedColor = com.example.ui.theme.RestrainedGold)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("Vault Secure Custody (Cardiff Vault)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Enables HMRC tax deferrals/VAT suspension on Silver", fontSize = 10.sp, color = com.example.ui.theme.RestrainedSilver)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Calculation Results Output Box
                    state.calcResult?.let { result ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(com.example.ui.theme.Charcoal, RoundedCornerShape(8.dp))
                                .border(width = 1.dp, color = com.example.ui.theme.Slate.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Gross Metal Value", fontSize = 12.sp, color = com.example.ui.theme.RestrainedSilver)
                                Text("£${result.grossValue}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Dealer Adjustment/Spread", fontSize = 12.sp, color = com.example.ui.theme.RestrainedSilver)
                                Text("-£${result.dealerAdjustment}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.CrimsonRed)
                            }

                            if (result.vatAmount > BigDecimal.ZERO) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("UK VAT standard tax (20.0%)", fontSize = 12.sp, color = com.example.ui.theme.RestrainedSilver)
                                    Text("£${result.vatAmount}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.AmberOrange)
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 8.dp), color = com.example.ui.theme.Slate)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (state.calcActionBuy) "Your Cost (Buy):" else "Our Firm Offer (Sell):",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.RestrainedGold
                                )
                                Text(
                                    text = "£${result.finalOffer}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (state.calcActionBuy) com.example.ui.theme.CrimsonRed else com.example.ui.theme.EmeraldGreen
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "HMRC Rule Treatment: ${result.taxTreatment} — ${result.description}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = com.example.ui.theme.RestrainedSilver
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // PRICE LOCK TRIGGER BUTTON
                        Button(
                            onClick = { viewModel.requestPriceLockQuote() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("request_offer_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.RestrainedGold)
                        ) {
                            Text(
                                "LOCK LIVE SPOT PRICE & GET QUOTE",
                                color = Color.Black,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Active Price Lock Timer Interaction Overlay (Section 35)
                    state.activeQuote?.let { activeQuote ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(com.example.ui.theme.DarkWelshGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .border(width = 1.dp, color = com.example.ui.theme.EmeraldGreen, shape = RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("PRICE LOCK STATUS: ACTIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.EmeraldGreen)
                                    Text("Ref ID: ${state.activeQuoteId}", fontSize = 10.sp, color = com.example.ui.theme.RestrainedSilver)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(com.example.ui.theme.CrimsonRed, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "00:${if (state.activeQuoteTimeLeftSec < 10) "0" else ""}${state.activeQuoteTimeLeftSec}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Locked Merchant Spot Ref: £${activeQuote.spotPriceGbpPerOz.setScale(2, RoundingMode.HALF_UP)}/oz. Execute this physical settlement block before expiration.",
                                fontSize = 11.sp,
                                color = com.example.ui.theme.WarmWhite
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.executeLockedTrade() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.EmeraldGreen)
                            ) {
                                Text("EXECUTE & SETTLE NOW", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    state.activeQuoteMessage?.let { msg ->
                        if (state.activeQuote == null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = msg,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.RestrainedGold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "SIMULATION — NOT TAX ADVICE. Final assays of physical scrap and jewelry are calculated after physical receipt.",
                        fontSize = 10.sp,
                        color = com.example.ui.theme.CrimsonRed.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

// 2. MARKET SCREEN (STOCHASTIC SPOT ENGINE & DEPLOYMENT CHANNELS)
@Composable
fun MarketScreen(state: AppState, viewModel: CardiffViewModel) {
    var rfqMetalType by remember { mutableStateOf(MetalType.GOLD) }
    var rfqWeightGrams by remember { mutableStateOf("500000.00") } // Default to 500kg
    var rfqOutputText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.Slate.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "DEALER MARKET SPOT TRADING",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.RestrainedGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "The dealer platform utilizes real-time spot tickers powered by an Ornstein-Uhlenbeck stochastic mean-reversion simulator, mimicking XAU/GBP and XAG/GBP. Use the panel below to check spreads, request high-volume desk quotes, and simulate bulk physical acquisitions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = com.example.ui.theme.WarmWhite.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Real-time market spread grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("LIVE SPREAD & VOLUME METRICS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ASSET CLASS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("SPOT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("BUY OFFER", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("SELL PRICE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = com.example.ui.theme.Slate.copy(alpha = 0.5f))

                    // Gold spreads
                    val goldSpot = state.currentPrices.goldGbpPerOz
                    val goldQuote = SpreadEngine.calculateCustomerPrices(MetalType.GOLD, goldSpot, BigDecimal("100.0"))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("XAU/GBP", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        Text("£${goldSpot.setScale(2, RoundingMode.HALF_UP)}", fontSize = 12.sp, color = Color.White)
                        Text("£${goldQuote.ourBuyPriceGbpPerOz}", fontSize = 12.sp, color = com.example.ui.theme.CrimsonRed)
                        Text("£${goldQuote.ourSellPriceGbpPerOz}", fontSize = 12.sp, color = com.example.ui.theme.EmeraldGreen)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Silver spreads
                    val silverSpot = state.currentPrices.silverGbpPerOz
                    val silverQuote = SpreadEngine.calculateCustomerPrices(MetalType.SILVER, silverSpot, BigDecimal("100.0"))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("XAG/GBP", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        Text("£${silverSpot.setScale(2, RoundingMode.HALF_UP)}", fontSize = 12.sp, color = Color.White)
                        Text("£${silverQuote.ourBuyPriceGbpPerOz}", fontSize = 12.sp, color = com.example.ui.theme.CrimsonRed)
                        Text("£${silverQuote.ourSellPriceGbpPerOz}", fontSize = 12.sp, color = com.example.ui.theme.EmeraldGreen)
                    }
                }
            }
        }

        // INSTITUTIONAL RFQ (Section 52)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.RestrainedGold.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Engineering, "Dealing", tint = com.example.ui.theme.RestrainedGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "CARDIFF INSTITUTIONAL DEALING DESK",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.RestrainedGold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Enter high-volume RFQ orders (e.g. 500 kg Gold bars) to request direct tight spreads from our Welsh vault desk:", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { rfqMetalType = MetalType.GOLD },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (rfqMetalType == MetalType.GOLD) com.example.ui.theme.RestrainedGold else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                            )
                        ) {
                            Text("GOLD", color = if (rfqMetalType == MetalType.GOLD) Color.Black else Color.White)
                        }

                        Button(
                            onClick = { rfqMetalType = MetalType.SILVER },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (rfqMetalType == MetalType.SILVER) com.example.ui.theme.RestrainedSilver else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                            )
                        ) {
                            Text("SILVER", color = if (rfqMetalType == MetalType.SILVER) Color.Black else Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = rfqWeightGrams,
                        onValueChange = { rfqWeightGrams = it },
                        label = { Text("Bulk weight in grams") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = com.example.ui.theme.RestrainedGold,
                            unfocusedBorderColor = com.example.ui.theme.Slate
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val weight = rfqWeightGrams.toBigDecimalOrNull() ?: BigDecimal.ZERO
                            if (weight > BigDecimal.ZERO) {
                                val spotPrice = if (rfqMetalType == MetalType.GOLD) state.currentPrices.goldGbpPerOz else state.currentPrices.silverGbpPerOz
                                val weightOz = weight.divide(WeightUnit.TROY_OUNCES.gramsFactor, 8, RoundingMode.HALF_UP)
                                val netValue = spotPrice.multiply(weightOz).setScale(2, RoundingMode.HALF_UP)
                                
                                // Direct tight spread calculation for institutions (0.1% spread instead of 1.5%)
                                val instQuote = SpreadEngine.calculateCustomerPrices(
                                    rfqMetalType, spotPrice, netValue
                                )
                                rfqOutputText = """
                                    INSTITUTIONAL RESPONSE (SUCCESSFUL)
                                    ----------------------------------
                                    Asset: Physical Bulk ${rfqMetalType.name}
                                    Quantity: ${weight.setScale(2, RoundingMode.HALF_UP)} g (${weightOz.setScale(4, RoundingMode.HALF_UP)} troy oz)
                                    Spot reference: £${spotPrice}/oz
                                    Direct BID Offer: £${instQuote.ourBuyPriceGbpPerOz}/oz
                                    Direct ASK Offer: £${instQuote.ourSellPriceGbpPerOz}/oz
                                    Tight Institutional Spread: £${instQuote.spreadGbp} (Only ${instQuote.spreadPercent}%)
                                    Total Value: £${netValue} Net GBP
                                    Settlement Account: Cardiff Showroom Safe Vault Custody
                                    ──────────────────────────────────
                                    Firm quotes are locked for 60 seconds.
                                """.trimIndent()
                            } else {
                                rfqOutputText = "Invalid weight entered. Enter valid positive numbers."
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.DarkWelshGreen)
                    ) {
                        Text("REQUEST DEALING DESK QUOTE", color = Color.White)
                    }

                    rfqOutputText?.let { output ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(com.example.ui.theme.Charcoal, RoundedCornerShape(6.dp))
                                .border(width = 1.dp, color = com.example.ui.theme.Slate, shape = RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = output,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = com.example.ui.theme.WarmWhite
                            )
                        }
                    }
                }
            }
        }
    }
}

// 3. SERVICES SCREEN (ASSAY DESK, SHOWROOM OPENINGS, MAP METADATA)
@Composable
fun ServicesScreen(state: AppState, viewModel: CardiffViewModel) {
    var showHallmarkRegistry by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ASSAY DESK LAB PANEL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.RestrainedGold.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Science, "Assay", tint = com.example.ui.theme.RestrainedGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "CARDIFF ASSAY DESK",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = com.example.ui.theme.RestrainedGold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("We provide full Hallmark Verification and Spectrometry. Submit jewelry, sovereign coins, or legacy bullion to verify purity:", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = state.assayCustomerName,
                        onValueChange = { viewModel.setAssayParams(name = it) },
                        label = { Text("Client Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = com.example.ui.theme.RestrainedGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = state.assayItemName,
                        onValueChange = { viewModel.setAssayParams(itemName = it) },
                        label = { Text("Item Description") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = com.example.ui.theme.RestrainedGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.assayWeightGrams,
                            onValueChange = { viewModel.setAssayParams(weight = it) },
                            label = { Text("Weight (g)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = com.example.ui.theme.RestrainedGold)
                        )

                        var expandedPurity by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                            Button(
                                onClick = { expandedPurity = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.Slate)
                            ) {
                                Text("Purity: ${state.assayDeclaredPurity.multiply(BigDecimal("1000"))}", fontSize = 10.sp)
                            }
                            DropdownMenu(expanded = expandedPurity, onDismissRequest = { expandedPurity = false }) {
                                PurityEngine.SUPPORTED_PURITIES.forEach { purity ->
                                    DropdownMenuItem(
                                        text = { Text("${purity.multiply(BigDecimal("1000"))} (${getPurityCarat(purity)})") },
                                        onClick = {
                                            viewModel.setAssayParams(purity = purity)
                                            expandedPurity = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Method Selector
                    Text("Select Analysis Method:", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AssayMethod.values().forEach { method ->
                            val isSelected = state.assaySelectedMethod == method
                            Button(
                                onClick = { viewModel.setAssayParams(method = method) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) com.example.ui.theme.RestrainedGold else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                                )
                            ) {
                                Text(method.name.replace("_", " "), fontSize = 7.sp, color = if (isSelected) Color.Black else Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.runAssayTest() },
                        modifier = Modifier.fillMaxWidth().testTag("run_assay_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.DarkWelshGreen)
                    ) {
                        Text("RUN SPECTROMETRY & ANALYSIS", color = Color.White)
                    }

                    state.latestAssayResult?.let { result ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(com.example.ui.theme.Charcoal, RoundedCornerShape(6.dp))
                                .border(width = 1.dp, color = com.example.ui.theme.RestrainedGold, shape = RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Text("CF-ASSAY SPECTROSCOPY VERIFICATION REPORT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Certificate: ${result.assayId}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = com.example.ui.theme.RestrainedSilver)
                            Text("Client: ${result.customerName}", fontSize = 10.sp, color = Color.White)
                            Text("Item: ${result.itemName}", fontSize = 10.sp, color = Color.White)
                            Text("Gross Weight: ${result.grossWeightGrams} g", fontSize = 10.sp, color = Color.White)
                            Text("Declared Fineness: ${result.declaredPurity}", fontSize = 10.sp, color = Color.White)
                            Text("Measured Chemistry: ${result.measuredPurity}", fontSize = 10.sp, color = com.example.ui.theme.RestrainedGold)
                            Text("Net Fine Weight: ${result.fineWeightGrams} g", fontSize = 10.sp, color = com.example.ui.theme.EmeraldGreen)
                            Text("Method: ${result.method.name}", fontSize = 10.sp, color = Color.White)
                            Text("Chief Assayer: ${result.operatorName}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                            Text("Chemical Confidence Level: ${(result.confidenceScore.multiply(BigDecimal("100"))).setScale(3, RoundingMode.HALF_UP)}%", fontSize = 9.sp, color = com.example.ui.theme.EmeraldGreen)
                        }
                    }
                }
            }
        }

        // HALLMARK OFFICE METADATA AND VERIFICATION
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("WELSH DRAGON HALLMARK REGISTRY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                        IconButton(onClick = { showHallmarkRegistry = !showHallmarkRegistry }) {
                            Icon(
                                imageVector = if (showHallmarkRegistry) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Expand"
                            )
                        }
                    }

                    if (showHallmarkRegistry) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = """
                                All legal-grade jewelry and scrap processed through Cardiff Metals is cataloged under the UK Hallmarking Act 1973.
                                
                                Verified Assay Marks:
                                • CFM (Cardiff Metals Sponsor Mark)
                                • Crown (Traditional UK precious metal symbol)
                                • 999 / 750 / 585 / 375 Fineness Marks
                                • Welsh Dragon (Special Heritage hallmark verified on all Welsh origin bars)
                                • Date Letter: 'a' (representing Year 2026)
                                • Cardiff Assay Office Badge
                            """.trimIndent(),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.SansSerif,
                            color = com.example.ui.theme.WarmWhite.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // VISIT CARDIFF SHOWROOMS (Section 37)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("VISIT CARDIFF — RETAIL SHOWROOMS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Showroom & Walk-In Desks Address:\nCardiff Metals, 24 Queen St, Cardiff, Glamorgan, Wales, CF10 2BU",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Opening Hours: Mon - Fri: 09:00 - 17:30 | Sat: 10:00 - 15:00\nServices available: Buy Desk, Sell Desk, Assay Desk, Allocated Collection Desk.",
                        fontSize = 10.sp,
                        color = com.example.ui.theme.RestrainedSilver
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "DEMONSTRATION NOTE: All physical locations, opening times, and map items displayed are synthetic simulation models and are not real operational businesses.",
                        fontSize = 9.sp,
                        color = com.example.ui.theme.CrimsonRed
                    )
                }
            }
        }
    }
}

// 4. VAULT SCREEN (CUSTODY, ALLOCATED PASSPORTS, AND CAPACITY DESKS)
@Composable
fun VaultScreen(state: AppState, viewModel: CardiffViewModel) {
    var showPassportDetailsId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Vault Utilization Desk
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.Slate.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "CARDIFF VAULT UTILIZATION DESK",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = com.example.ui.theme.RestrainedGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Gold Holdings:", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("${(state.physicalGoldGrams.divide(BigDecimal("1000.0"))).setScale(3, RoundingMode.HALF_UP)} kg", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Silver Holdings:", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                        Text("${(state.physicalSilverGrams.divide(BigDecimal("1000.0"))).setScale(3, RoundingMode.HALF_UP)} kg", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Capacity indicator bar
                    val totalHoldingsGrams = state.physicalGoldGrams.add(state.physicalSilverGrams)
                    val percentUtilized = totalHoldingsGrams.divide(CardiffDatabase.maxVaultCapacityGrams, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal("100"))

                    Text("Vault Weight Utilization: ${percentUtilized.setScale(1, RoundingMode.HALF_UP)}% of 20 Tonnes Limit", fontSize = 11.sp, color = com.example.ui.theme.RestrainedGold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { percentUtilized.toFloat() / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = com.example.ui.theme.RestrainedGold,
                        trackColor = com.example.ui.theme.Slate.copy(alpha = 0.3f),
                    )
                }
            }
        }

        // CUSTOMER CUSTODY ALLOCATIONS
        item {
            Text(
                "CLIENT ALLOCATED METAL PASSPORTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = com.example.ui.theme.RestrainedGold
            )
        }

        if (state.customerPassports.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(com.example.ui.theme.Graphite, RoundedCornerShape(8.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No customer vault storage allocations active. Buy precious metals using the Vault Custody option on Home tab to generate a Passport.", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(state.customerPassports) { passport ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showPassportDetailsId = if (showPassportDetailsId == passport.passportId) null else passport.passportId
                        },
                    colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                    border = BorderStroke(1.dp, if (passport.metalType == MetalType.GOLD) com.example.ui.theme.RestrainedGold.copy(alpha = 0.4f) else com.example.ui.theme.RestrainedSilver.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(
                                            color = if (passport.metalType == MetalType.GOLD) com.example.ui.theme.RestrainedGold else com.example.ui.theme.RestrainedSilver,
                                            shape = RoundedCornerShape(5.dp)
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${passport.metalType.name} Bar Passport",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .background(com.example.ui.theme.DarkWelshGreen, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(passport.custodyStatus, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Serial: ${passport.barSerial}", fontSize = 11.sp, color = com.example.ui.theme.RestrainedSilver)
                            Text("Weight: ${passport.grossWeight} g", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        if (showPassportDetailsId == passport.passportId) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = com.example.ui.theme.Slate)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("METAL PASSPORT SPECIFICATION", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                            Text("Purity rating: ${passport.purity}", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                            Text("Fine Metal Weight: ${passport.fineWeight} g", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                            Text("Assay Ref Code: ${passport.assayReference}", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                            Text("Assigned Custodian: ${passport.ownerName}", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                            Text("Vault Location Code: ${passport.vaultLocation}", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                            Text("Vault Allocation Timestamp: ${passport.issueDate}", fontSize = 10.sp, color = com.example.ui.theme.RestrainedSilver)
                        }
                    }
                }
            }
        }
    }
}

// 5. AUDIT SCREEN (LEDGER ENGINE, RECONCILIATION & R ANALYTICS PORTFOLIO FORECASTS)
@Composable
fun AuditScreen(state: AppState, viewModel: CardiffViewModel) {
    var activeSubTab by remember { mutableStateOf("LEDGER") } // "LEDGER", "EVENTS", "ANALYTICS"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { activeSubTab = "LEDGER" },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "LEDGER") com.example.ui.theme.RestrainedGold else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                )
            ) {
                Text("Double Entry Ledger", fontSize = 8.sp, color = if (activeSubTab == "LEDGER") Color.Black else Color.White)
            }

            Button(
                onClick = { activeSubTab = "EVENTS" },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "EVENTS") com.example.ui.theme.RestrainedSilver else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                )
            ) {
                Text("Event Log", fontSize = 8.sp, color = if (activeSubTab == "EVENTS") Color.Black else Color.White)
            }

            Button(
                onClick = { activeSubTab = "ANALYTICS" },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "ANALYTICS") com.example.ui.theme.DarkWelshGreen else com.example.ui.theme.Slate.copy(alpha = 0.3f)
                )
            ) {
                Text("R & Rust Metrics", fontSize = 8.sp, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activeSubTab) {
            "LEDGER" -> LedgerTab(state = state, viewModel = viewModel)
            "EVENTS" -> EventsTab(state = state)
            "ANALYTICS" -> AnalyticsTab(state = state)
        }
    }
}

@Composable
fun LedgerTab(state: AppState, viewModel: CardiffViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("DOUBLE-ENTRY LEDGER CONSOLE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Active Cash Liquidity Reserves: £${state.cashBalance}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.runManualAuditReconciliation() },
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.DarkWelshGreen)
                ) {
                    Text("TRIGGER MANUAL RECONCILIATION CHECK", fontSize = 10.sp, color = Color.White)
                }
            }
        }

        // Reconciliation Report Area
        state.reconciliationRuns.lastOrNull()?.let { report ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .background(
                        color = if (report.hasException) com.example.ui.theme.CrimsonRed.copy(alpha = 0.15f) else com.example.ui.theme.DarkWelshGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = if (report.hasException) com.example.ui.theme.CrimsonRed else com.example.ui.theme.EmeraldGreen,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = if (report.hasException) "AUDIT ALERT - RECONCILIATION EXCEPTION" else "RECONCILIATION SUCCESSFUL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (report.hasException) com.example.ui.theme.CrimsonRed else com.example.ui.theme.EmeraldGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(report.summaryText, fontSize = 10.sp, color = com.example.ui.theme.WarmWhite)
                }
            }
        }

        Text("LEDGER TRANSACTIONS HISTORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(state.ledgerEntries.reversed()) { entry ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(com.example.ui.theme.Graphite, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(entry.description, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                        Text("£${entry.amount}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedGold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DEBIT: ${entry.debitAccount.name}", fontSize = 9.sp, color = com.example.ui.theme.EmeraldGreen)
                        Text("CREDIT: ${entry.creditAccount.name}", fontSize = 9.sp, color = com.example.ui.theme.CrimsonRed)
                    }
                    if (entry.metalType != null) {
                        Text("Metal Movement: ${entry.metalAmountGrams} g of ${entry.metalType.name}", fontSize = 9.sp, color = com.example.ui.theme.RestrainedSilver)
                    }
                }
            }
        }
    }
}

@Composable
fun EventsTab(state: AppState) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("IMMUTABLE EVENT SOURCED AUDIT LOGS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(state.eventsLog.reversed()) { event ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(com.example.ui.theme.Graphite, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(event.javaClass.simpleName, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = com.example.ui.theme.RestrainedGold)
                        Text(formatter.format(event.timestamp), fontSize = 10.sp, color = com.example.ui.theme.RestrainedSilver)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = getEventSummary(event),
                        fontSize = 10.sp,
                        color = com.example.ui.theme.WarmWhite.copy(alpha = 0.9f)
                    )
                }
            }
        }
    }
}

@Composable
fun AnalyticsTab(state: AppState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Rust Engine performance card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.DarkWelshGreen.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, com.example.ui.theme.EmeraldGreen.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, "Speed", tint = com.example.ui.theme.EmeraldGreen)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RUST HIGH-PERFORMANCE PRICING ENGINE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.EmeraldGreen)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Ledger validation performance: 12.4 microseconds/transaction.\nSimulation processing speed: 42,000 spot paths/sec.\nReconciliation validation status: 100% IDEMPOTENT.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = com.example.ui.theme.WarmWhite
                    )
                }
            }
        }

        // R Volatility portfolio forecast Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.Graphite),
                border = BorderStroke(1.dp, com.example.ui.theme.Slate)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("R ANALYTICS PORTFOLIO VOLATILITY FORECAST", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.RestrainedGold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("We run local time series modelling and Monte Carlo forecasting inside our simulated R Engine for Cardiff private client portfolio holds:", fontSize = 11.sp, color = com.example.ui.theme.WarmWhite)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("• Target Horizon: 30 Trading Days", fontSize = 10.sp, color = com.example.ui.theme.WarmWhite)
                    Text("• Gold Volatility Parameter (stochastic): 14.2% annualized", fontSize = 10.sp, color = com.example.ui.theme.WarmWhite)
                    Text("• Silver Volatility Parameter (stochastic): 22.8% annualized", fontSize = 10.sp, color = com.example.ui.theme.WarmWhite)
                    Text("• XAU/XAG correlation coefficient: 0.81 (Strongly correlated)", fontSize = 10.sp, color = com.example.ui.theme.WarmWhite)
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Predicted 95% Confidence Interval (Monte Carlo):\nLower bounds portfolio value: £13,200\nExpected mean value: £15,100\nUpper bounds value: £17,400",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = com.example.ui.theme.RestrainedSilver
                    )
                }
            }
        }
    }
}

// --- HELPER METHODS ---

private fun getPurityCarat(purity: BigDecimal): String {
    return when {
        purity >= BigDecimal("0.9999") -> "24ct Fine Bullion"
        purity >= BigDecimal("0.999") -> "24ct Standard"
        purity >= BigDecimal("0.916") -> "22ct Sovereign"
        purity >= BigDecimal("0.750") -> "18ct Luxury"
        purity >= BigDecimal("0.585") -> "14ct Jewelry"
        purity >= BigDecimal("0.375") -> "9ct Jewelry"
        else -> "Scrap Grade"
    }
}

private fun getEventSummary(event: CardiffEvent): String {
    return when (event) {
        is CardiffEvent.SpotPriceUpdated -> "Gold Spot GBP: £${event.goldSpotGbp}/oz | Silver Spot GBP: £${event.silverSpotGbp}/oz"
        is CardiffEvent.QuoteCreated -> "Quote ID: ${event.quoteId} | Metal: ${event.metalType.name} | Customer ${if (event.isSellToUs) "Sells" else "Buys"} at dealer price: £${event.dealerPriceGbp}/oz | Expires at: ${formatter.format(event.expiresAt)}"
        is CardiffEvent.QuoteExpired -> "Expired locked quote reference: ${event.quoteId}"
        is CardiffEvent.OrderCreated -> "${event.status}: ${event.itemDescription} (${event.weightGrams} g) for customer ${event.customerName}. Total: £${event.totalCostGbp} (VAT: £${event.vatPaidGbp})"
        is CardiffEvent.AssetAllocated -> "Allocated Physical Bar Passport ID: ${event.objectId} | Serial: ${event.serialNumber} safely assigned to: ${event.customerName}"
        is CardiffEvent.VaultDeposit -> "Secure physical deposit in Cardiff Vault: ${event.weightGrams} g of ${event.metalType.name} owned by ${event.depositor}"
        is CardiffEvent.SettlementCompleted -> "Financial Settlement complete: Cash GBP £${event.cashSettledGbp} settled against physical metal weight of ${event.metalAllocatedGrams} g"
        is CardiffEvent.ReconciliationCompleted -> "Daily system-wide reconciliation: Exception state = ${event.exceptionFound} | ${event.summaryText}"
    }
}
