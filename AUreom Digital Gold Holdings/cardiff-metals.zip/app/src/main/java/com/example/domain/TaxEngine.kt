package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

// --- HMRC TAX ENGINE ---
data class TaxRuleVersion(
    val versionId: String = "HMRC-VAT-2026-v2.1",
    val jurisdiction: String = "United Kingdom (HMRC)",
    val effectiveDate: String = "2026-04-06",
    val sourceReference: String = "HMRC Notice 701/21 (Gold) & Notice 718 (Margin Schemes)"
)

data class TaxClassification(
    val metalType: MetalType,
    val typeName: String,         // "Bar", "Coin", "Jewellery Scrap", "Silverware"
    val purity: BigDecimal,
    val isPreOwned: Boolean,
    val isStoredInVault: Boolean,  // Vault storage can defer / suspend VAT in qualifying regimes
    val transactionType: String    // "CUSTOMER_BUY" (Sales) or "CUSTOMER_SELL" (Purchase)
)

data class TaxResult(
    val ruleVersion: TaxRuleVersion = TaxRuleVersion(),
    val ratePercent: BigDecimal,
    val vatAmountGbp: BigDecimal,
    val isVatDeferredOrSuspended: Boolean,
    val description: String,
    val taxTreatment: String // "EXEMPT", "STANDARD_20_PERCENT", "MARGIN_SCHEME", "SUSPENDED"
)

object TaxEngine {

    fun calculateTax(
        classification: TaxClassification,
        netAmountGbp: BigDecimal,
        purchaseCostGbp: BigDecimal = BigDecimal.ZERO // Required for Second-Hand Silver margin calculations
    ): TaxResult {
        // Warning placeholder is rendered in the UI: "SIMULATION — NOT TAX ADVICE"

        // 1. Check if CUSTOMER SELLS to us (purchase by merchant)
        // Usually, when a consumer sells to a registered business, no VAT is charged by the customer to the business,
        // unless they are a VAT-registered business themselves. Under HMRC rules for second-hand purchases, the dealer uses the margin scheme later.
        if (classification.transactionType == "CUSTOMER_SELL") {
            return TaxResult(
                ratePercent = BigDecimal.ZERO,
                vatAmountGbp = BigDecimal.ZERO,
                isVatDeferredOrSuspended = false,
                description = "Purchase by dealer. Customer does not charge VAT on private metal liquidation.",
                taxTreatment = "EXEMPT"
            )
        }

        // 2. CUSTOMER BUYS from us (Sales)
        when (classification.metalType) {
            MetalType.GOLD -> {
                // HMRC Notice 701/21: Investment Gold is VAT exempt.
                // Gold Bars: purity >= 995
                // Gold Coins: purity >= 900, minted after 1800, legal tender list.
                val isQualifyingGold = if (classification.typeName == "Coin") {
                    classification.purity >= BigDecimal("0.900")
                } else {
                    classification.purity >= BigDecimal("0.995")
                }

                return if (isQualifyingGold) {
                    TaxResult(
                        ratePercent = BigDecimal.ZERO,
                        vatAmountGbp = BigDecimal.ZERO,
                        isVatDeferredOrSuspended = false,
                        description = "Qualifying Investment Gold under HMRC Notice 701/21.",
                        taxTreatment = "EXEMPT"
                    )
                } else {
                    // Non-investment gold (e.g., jewellery scrap, low-purity industrial gold) carries standard VAT (20%)
                    val taxRate = BigDecimal("20.0")
                    val vatAmount = netAmountGbp.multiply(BigDecimal("0.20")).setScale(2, RoundingMode.HALF_UP)
                    TaxResult(
                        ratePercent = taxRate,
                        vatAmountGbp = vatAmount,
                        isVatDeferredOrSuspended = false,
                        description = "Non-investment gold subject to standard UK VAT rate (20%).",
                        taxTreatment = "STANDARD_20_PERCENT"
                    )
                }
            }

            MetalType.SILVER -> {
                // Silver is subject to standard UK VAT (20%) on sales unless structured under Storage or Margin schemes
                if (classification.isStoredInVault) {
                    // Storing within a bonded / customs vault suspensions regime defers standard VAT until physical extraction
                    return TaxResult(
                        ratePercent = BigDecimal.ZERO,
                        vatAmountGbp = BigDecimal.ZERO,
                        isVatDeferredOrSuspended = true,
                        description = "Silver held securely in Cardiff Vault under VAT suspension regime. VAT deferred until delivery.",
                        taxTreatment = "SUSPENDED"
                    )
                }

                if (classification.isPreOwned) {
                    // Second-Hand Silver Margin Scheme (Notice 718):
                    // VAT is 20% on the difference between purchase and selling price.
                    // Effectively: (Selling Price - Buying Price) * 1/6 (the VAT fraction for 20% margin VAT)
                    val margin = netAmountGbp.subtract(purchaseCostGbp)
                    return if (margin > BigDecimal.ZERO) {
                        val vatAmount = margin.multiply(BigDecimal("0.166667")).setScale(2, RoundingMode.HALF_UP)
                        TaxResult(
                            ratePercent = BigDecimal("20.0"), // 20% applied to margin
                            vatAmountGbp = vatAmount,
                            isVatDeferredOrSuspended = false,
                            description = "HMRC Second-Hand Silver Margin Scheme (VAT calculated on dealer margin, not total cost).",
                            taxTreatment = "MARGIN_SCHEME"
                        )
                    } else {
                        TaxResult(
                            ratePercent = BigDecimal.ZERO,
                            vatAmountGbp = BigDecimal.ZERO,
                            isVatDeferredOrSuspended = false,
                            description = "HMRC Second-Hand Silver Margin Scheme (Zero margin, zero tax).",
                            taxTreatment = "MARGIN_SCHEME"
                        )
                    }
                }

                // Standard Physical Delivery of Brand-New Silver (Bars or Coins)
                val taxRate = BigDecimal("20.0")
                val vatAmount = netAmountGbp.multiply(BigDecimal("0.20")).setScale(2, RoundingMode.HALF_UP)
                return TaxResult(
                    ratePercent = taxRate,
                    vatAmountGbp = vatAmount,
                    isVatDeferredOrSuspended = false,
                    description = "Standard UK physical delivery VAT (20%) for non-exempt silver.",
                    taxTreatment = "STANDARD_20_PERCENT"
                )
            }
        }
    }
}
