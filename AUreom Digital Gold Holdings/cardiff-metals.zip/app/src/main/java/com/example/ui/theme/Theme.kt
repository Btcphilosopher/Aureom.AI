package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = RestrainedGold,
    onPrimary = Charcoal,
    secondary = RestrainedSilver,
    onSecondary = Charcoal,
    tertiary = DarkWelshGreen,
    onTertiary = WarmWhite,
    background = Charcoal,
    onBackground = WarmWhite,
    surface = Graphite,
    onSurface = WarmWhite,
    surfaceVariant = Slate,
    onSurfaceVariant = WarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = DarkWelshGreen,
    onPrimary = WarmWhite,
    secondary = RestrainedGold,
    onSecondary = Charcoal,
    tertiary = RestrainedSilver,
    onTertiary = Charcoal,
    background = WarmWhite,
    onBackground = Charcoal,
    surface = PureWhite,
    onSurface = Charcoal,
    surfaceVariant = LightIceBlue,
    onSurfaceVariant = Charcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable Android 12+ dynamic wallpaper colors to enforce our strict luxury brand identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
