package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Random

// --- SPOT PRICE ENGINE ---
data class FXRates(
    val gbpUsd: BigDecimal, // e.g. 1.3050
    val gbpEur: BigDecimal  // e.g. 1.1820
)

data class SpotPrices(
    val goldUsdPerOz: BigDecimal,    // e.g. 2650.00
    val silverUsdPerOz: BigDecimal,  // e.g. 32.50
    val fxRates: FXRates,
    val timestamp: Long = System.currentTimeMillis()
) {
    // Derived GBP spot values using BigDecimal
    val goldGbpPerOz: BigDecimal
        get() = goldUsdPerOz.divide(fxRates.gbpUsd, 4, RoundingMode.HALF_UP)

    val silverGbpPerOz: BigDecimal
        get() = silverUsdPerOz.divide(fxRates.gbpUsd, 4, RoundingMode.HALF_UP)

    // Spot per gram calculations for convenience
    val goldGbpPerGram: BigDecimal
        get() = goldGbpPerOz.divide(WeightUnit.TROY_OUNCES.gramsFactor, 4, RoundingMode.HALF_UP)

    val silverGbpPerGram: BigDecimal
        get() = silverGbpPerOz.divide(WeightUnit.TROY_OUNCES.gramsFactor, 4, RoundingMode.HALF_UP)
}

// --- SPREAD ENGINE ---
object SpreadEngine {
    // Spreads are configurable and represent premium merchant settings
    data class SpreadConfig(
        val goldBaseSpreadPercent: BigDecimal = BigDecimal("0.015"), // 1.5% base spread
        val silverBaseSpreadPercent: BigDecimal = BigDecimal("0.050"), // 5.0% base spread for physical logistics
        val goldProductAdjustmentPercent: BigDecimal = BigDecimal("0.005"), // 0.5% product variation
        val silverProductAdjustmentPercent: BigDecimal = BigDecimal("0.020") // 2.0% silver logistics premium
    )

    fun calculateCustomerPrices(
        metalType: MetalType,
        spotGbpPerOz: BigDecimal,
        volumeGbp: BigDecimal,
        config: SpreadConfig = SpreadConfig()
    ): DealerQuote {
        val baseSpreadPercent = if (metalType == MetalType.GOLD) config.goldBaseSpreadPercent else config.silverBaseSpreadPercent
        val productAdjPercent = if (metalType == MetalType.GOLD) config.goldProductAdjustmentPercent else config.silverProductAdjustmentPercent

        // Volume discount: Larger transactions receive tighter spreads
        val volumeDiscountFactor = when {
            volumeGbp >= BigDecimal("100000.00") -> BigDecimal("0.40") // 60% spread reduction for RFQ
            volumeGbp >= BigDecimal("25000.00") -> BigDecimal("0.60")  // 40% spread reduction
            volumeGbp >= BigDecimal("5000.00") -> BigDecimal("0.80")   // 20% spread reduction
            else -> BigDecimal("1.00")                                  // Retail standard spread
        }

        val finalSpreadPercent = baseSpreadPercent.multiply(volumeDiscountFactor)

        // Calculate adjustments
        val dealerMarginPerOz = spotGbpPerOz.multiply(finalSpreadPercent).setScale(4, RoundingMode.HALF_UP)
        val productPremiumPerOz = spotGbpPerOz.multiply(productAdjPercent).setScale(4, RoundingMode.HALF_UP)

        // BUY FROM US (Customer Buys / We Sell): Spot + Spread Margin + Product Premium
        val ourSellPricePerOz = spotGbpPerOz.add(dealerMarginPerOz).add(productPremiumPerOz)
            .setScale(2, RoundingMode.HALF_UP)

        // SELL TO US (Customer Sells / We Buy): Spot - Spread Margin - Product Premium
        val ourBuyPricePerOz = spotGbpPerOz.subtract(dealerMarginPerOz).subtract(productPremiumPerOz)
            .setScale(2, RoundingMode.HALF_UP)

        val finalSpreadGbp = ourSellPricePerOz.subtract(ourBuyPricePerOz)
        val finalSpreadPercentOfSpot = finalSpreadGbp.divide(spotGbpPerOz, 4, RoundingMode.HALF_UP)
            .multiply(BigDecimal("100"))

        return DealerQuote(
            metalType = metalType,
            spotPriceGbpPerOz = spotGbpPerOz,
            ourBuyPriceGbpPerOz = ourBuyPricePerOz,
            ourSellPriceGbpPerOz = ourSellPricePerOz,
            spreadGbp = finalSpreadGbp,
            spreadPercent = finalSpreadPercentOfSpot,
            volumeDiscountApplied = volumeDiscountFactor < BigDecimal.ONE
        )
    }
}

data class DealerQuote(
    val metalType: MetalType,
    val spotPriceGbpPerOz: BigDecimal,
    val ourBuyPriceGbpPerOz: BigDecimal, // WHAT WE PAY THE CUSTOMER
    val ourSellPriceGbpPerOz: BigDecimal, // WHAT WE CHARGE THE CUSTOMER
    val spreadGbp: BigDecimal,
    val spreadPercent: BigDecimal,
    val volumeDiscountApplied: Boolean
)

// --- SPOT TRADING SIMULATOR (Stochastic Volatility / Mean-Reverting Generator) ---
class SpotPriceSimulator(seed: Long = 42) {
    private val random = Random(seed)

    // Base market references (XAU/USD and XAG/USD)
    private var goldUsd = 2650.00
    private var silverUsd = 32.40
    private var gbpUsd = 1.3050
    private var gbpEur = 1.1820

    // Stochastics parameters
    private val goldMean = 2650.00
    private val silverMean = 32.40
    private val gbpUsdMean = 1.3050

    private val speedOfReversion = 0.05 // Mean-reversion strength
    private val goldVol = 8.50          // High volatility for gold
    private val silverVol = 0.35        // Higher relative volatility for silver
    private val fxVol = 0.0020          // Low volatility for currency

    fun nextPrices(): SpotPrices {
        // Ornstein-Uhlenbeck (mean reverting) stochastic process + random walk
        val goldShock = random.nextGaussian()
        goldUsd = goldUsd + speedOfReversion * (goldMean - goldUsd) + goldVol * goldShock
        if (goldUsd < 1000.0) goldUsd = 1000.0 // Floor safety

        val silverShock = random.nextGaussian()
        silverUsd = silverUsd + speedOfReversion * (silverMean - silverUsd) + silverVol * silverShock
        if (silverUsd < 5.0) silverUsd = 5.0 // Floor safety

        val fxShock = random.nextGaussian()
        gbpUsd = gbpUsd + speedOfReversion * (gbpUsdMean - gbpUsd) + fxVol * fxShock
        if (gbpUsd < 0.8) gbpUsd = 0.8
        if (gbpUsd > 2.0) gbpUsd = 2.0

        return SpotPrices(
            goldUsdPerOz = BigDecimal(goldUsd).setScale(2, RoundingMode.HALF_UP),
            silverUsdPerOz = BigDecimal(silverUsd).setScale(2, RoundingMode.HALF_UP),
            fxRates = FXRates(
                gbpUsd = BigDecimal(gbpUsd).setScale(4, RoundingMode.HALF_UP),
                gbpEur = BigDecimal(gbpEur).setScale(4, RoundingMode.HALF_UP)
            )
        )
    }
}
