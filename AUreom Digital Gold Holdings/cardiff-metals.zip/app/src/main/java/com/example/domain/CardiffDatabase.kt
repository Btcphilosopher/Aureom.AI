package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.util.UUID

object CardiffDatabase {

    // --- SEED PARAMETERS ---
    // Merchant initial capitalization
    var cashBalanceGbp = BigDecimal("10000000.00") // £10M liquidity

    // Physical inventory storage (grams)
    var physicalGoldGrams = BigDecimal("1842000.00")   // 1,842 kg
    var physicalSilverGrams = BigDecimal("8420000.00") // 8,420 kg
    val maxVaultCapacityGrams = BigDecimal("20000000.00") // 20 tonnes

    // Cost basis definitions
    val goldCostBasisPerGram = BigDecimal("60.00")
    val silverCostBasisPerGram = BigDecimal("0.80")

    // --- DATA STORES ---
    val customers = mutableListOf<CustomerKYC>()
    val physicalAssets = mutableListOf<PhysicalObject>()
    val britishCoinsList = mutableListOf<BritishCoin>()
    val quotes = mutableMapOf<String, DealerQuote>()
    val quoteExpiryTimes = mutableMapOf<String, Instant>()
    val orders = mutableListOf<OrderRecord>()
    val assays = mutableListOf<AssayResult>()
    val doubleEntryLedger = mutableListOf<LedgerEntry>()
    val eventsLog = mutableListOf<CardiffEvent>()
    val metalPassports = mutableListOf<MetalPassport>()
    val complianceCases = mutableListOf<ComplianceCase>()
    val reconciliationRuns = mutableListOf<ReconciliationRun>()

    // Current price environment
    var currentPrices = SpotPrices(
        goldUsdPerOz = BigDecimal("2650.00"),
        silverUsdPerOz = BigDecimal("32.40"),
        fxRates = FXRates(gbpUsd = BigDecimal("1.3050"), gbpEur = BigDecimal("1.1820"))
    )

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        // 1. Seed Cardiff Private Customer KYC
        val standardCustomer = CustomerKYC(
            customerId = "CUST-001",
            fullName = "Cardiff Private Customer",
            email = "client@cardiffprivate.co.uk",
            dateOfBirth = "1978-05-12",
            address = "5 Cathedral Road, Pontcanna, Cardiff, CF11 9HA",
            riskRating = "LOW"
        )
        val highRiskCustomer = CustomerKYC(
            customerId = "CUST-002",
            fullName = "Swansea Syndicate Ltd",
            email = "syndicate@swanseabay.co.uk",
            dateOfBirth = "1985-11-20",
            address = "Marina Towers, Maritime Quarter, Swansea, SA1 1UF",
            riskRating = "MEDIUM",
            sourceOfFunds = "Commercial Property Liquidation"
        )
        customers.add(standardCustomer)
        customers.add(highRiskCustomer)

        // 2. Seed British Bullion Coins
        for (year in 2024..2026) {
            britishCoinsList.add(BritishCoin.createSovereign(year))
            britishCoinsList.add(BritishCoin.createGoldBritannia(year))
            britishCoinsList.add(BritishCoin.createSilverBritannia(year))
        }

        // 3. Seed physical assets in the vault
        physicalAssets.add(
            PhysicalObject(
                objectId = "ASSET-AU-100",
                metalType = MetalType.GOLD,
                typeName = "Bar",
                brand = "Valcambi Wales",
                serialNumber = "CF-AU-000421",
                grossWeightGrams = BigDecimal("100.00"),
                purity = BigDecimal("0.9999"),
                fineWeightGrams = BigDecimal("99.99"),
                hallmarkInfo = HallmarkInfo("CFM", "999.9", "Cardiff", "2026"),
                purchasePrice = BigDecimal("6000.00"),
                ownerId = "MERCHANT"
            )
        )
        physicalAssets.add(
            PhysicalObject(
                objectId = "ASSET-AU-500",
                metalType = MetalType.GOLD,
                typeName = "Bar",
                brand = "PAMP Cardiff",
                serialNumber = "CF-AU-000422",
                grossWeightGrams = BigDecimal("500.00"),
                purity = BigDecimal("0.9999"),
                fineWeightGrams = BigDecimal("499.95"),
                hallmarkInfo = HallmarkInfo("CFM", "999.9", "Cardiff", "2025"),
                purchasePrice = BigDecimal("30000.00"),
                ownerId = "MERCHANT"
            )
        )
        physicalAssets.add(
            PhysicalObject(
                objectId = "ASSET-AG-1000",
                metalType = MetalType.SILVER,
                typeName = "Bar",
                brand = "Cardiff Smelter",
                serialNumber = "CF-AG-000881",
                grossWeightGrams = BigDecimal("1000.00"),
                purity = BigDecimal("0.999"),
                fineWeightGrams = BigDecimal("999.00"),
                hallmarkInfo = HallmarkInfo("CFM", "999", "Cardiff", "2026"),
                purchasePrice = BigDecimal("800.00"),
                ownerId = "MERCHANT"
            )
        )

        // 4. Record initial ledger balance setup
        recordLedgerEntry(
            transactionId = "INITIAL_SETUP",
            description = "Merchant initial liquidity capitalization",
            debitAccount = LedgerAccount.CASH_GBP,
            creditAccount = LedgerAccount.SETTLEMENT_SUSPENSE,
            amount = cashBalanceGbp
        )
        recordLedgerEntry(
            transactionId = "INITIAL_SETUP",
            description = "Gold reserves valuation (cost basis)",
            debitAccount = LedgerAccount.GOLD_INVENTORY,
            creditAccount = LedgerAccount.MERCHANT_VAULT_RESERVES,
            amount = physicalGoldGrams.multiply(goldCostBasisPerGram)
        )
        recordLedgerEntry(
            transactionId = "INITIAL_SETUP",
            description = "Silver reserves valuation (cost basis)",
            debitAccount = LedgerAccount.SILVER_INVENTORY,
            creditAccount = LedgerAccount.MERCHANT_VAULT_RESERVES,
            amount = physicalSilverGrams.multiply(silverCostBasisPerGram)
        )

        // 5. Seed Compliance Cases
        complianceCases.add(
            ComplianceCase(
                caseId = "AML-991",
                customerId = "CUST-002",
                customerName = "Swansea Syndicate Ltd",
                type = "HIGH_VALUE_TRANSACTION",
                reason = "Proposed trade exceeding £50,000 threshold",
                status = "PENDING_PROVENANCE_REVIEW"
            )
        )

        // 6. Run Initial Reconciliation
        reconcileBalances()
    }

    // --- ACCESSIBLE WRITES & MUTATIONS ---

    fun recordLedgerEntry(
        transactionId: String,
        description: String,
        debitAccount: LedgerAccount,
        creditAccount: LedgerAccount,
        amount: BigDecimal,
        metalType: MetalType? = null,
        metalAmountGrams: BigDecimal = BigDecimal.ZERO
    ) {
        val entry = LedgerEntry(
            transactionId = transactionId,
            description = description,
            debitAccount = debitAccount,
            creditAccount = creditAccount,
            amount = amount,
            metalType = metalType,
            metalAmountGrams = metalAmountGrams
        )
        doubleEntryLedger.add(entry)
    }

    fun emitEvent(event: CardiffEvent) {
        eventsLog.add(event)
    }

    // --- BUSINESS LOGIC TRANSACTION ENDPOINTS ---

    fun createQuote(metalType: MetalType, isSellToUs: Boolean, grossWeightGrams: BigDecimal, purity: BigDecimal): String {
        val quoteId = "QUO-" + (100000..999999).random()
        val spotPrice = if (metalType == MetalType.GOLD) currentPrices.goldGbpPerOz else currentPrices.silverGbpPerOz

        // Weight conversion helper
        val weightOz = WeightUnit.GRAMS.toGrams(grossWeightGrams)
            .divide(WeightUnit.TROY_OUNCES.gramsFactor, 8, RoundingMode.HALF_UP)
        val metalValueGbp = spotPrice.multiply(weightOz).setScale(2, RoundingMode.HALF_UP)

        val quote = SpreadEngine.calculateCustomerPrices(metalType, spotPrice, metalValueGbp)
        quotes[quoteId] = quote

        val expiry = Instant.now().plusSeconds(60) // Price lock valid for 60 seconds
        quoteExpiryTimes[quoteId] = expiry

        emitEvent(
            CardiffEvent.QuoteCreated(
                quoteId = quoteId,
                metalType = metalType,
                isSellToUs = isSellToUs,
                grossWeightGrams = grossWeightGrams,
                purity = purity,
                spotRefPriceGbp = spotPrice,
                dealerPriceGbp = if (isSellToUs) quote.ourBuyPriceGbpPerOz else quote.ourSellPriceGbpPerOz,
                expiresAt = expiry
            )
        )
        return quoteId
    }

    fun executeOrder(
        customer: CustomerKYC,
        metalType: MetalType,
        isCustomerBuying: Boolean,
        grossWeightGrams: BigDecimal,
        purity: BigDecimal,
        quoteId: String,
        isStoredInVault: Boolean
    ): OrderRecord {
        val expiryTime = quoteExpiryTimes[quoteId]
        val quote = quotes[quoteId]

        if (expiryTime == null || quote == null || Instant.now().isAfter(expiryTime)) {
            emitEvent(CardiffEvent.QuoteExpired(quoteId = quoteId))
            throw IllegalStateException("PRICE EXPIRED: The requested spot price quote has expired. Please request a new price lock.")
        }

        val orderId = "ORD-" + (100000..999999).random()

        // Calculate fine weight
        val fineWeight = PurityEngine.calculateFineWeight(grossWeightGrams, purity)

        // Convert weight to Oz for quotation calculations
        val weightOz = grossWeightGrams.divide(WeightUnit.TROY_OUNCES.gramsFactor, 8, RoundingMode.HALF_UP)

        // Determine price per oz from quote
        val pricePerOz = if (isCustomerBuying) quote.ourSellPriceGbpPerOz else quote.ourBuyPriceGbpPerOz
        val netMetalCost = pricePerOz.multiply(weightOz).setScale(2, RoundingMode.HALF_UP)

        // Tax valuation using TaxEngine
        val taxClassification = TaxClassification(
            metalType = metalType,
            typeName = if (grossWeightGrams < BigDecimal("50")) "Coin" else "Bar",
            purity = purity,
            isPreOwned = !isCustomerBuying, // Customer sells representing pre-owned acquisition
            isStoredInVault = isStoredInVault,
            transactionType = if (isCustomerBuying) "CUSTOMER_BUY" else "CUSTOMER_SELL"
        )
        val taxResult = TaxEngine.calculateTax(taxClassification, netMetalCost)
        val vatAmount = taxResult.vatAmountGbp
        val totalCost = netMetalCost.add(vatAmount)

        if (isCustomerBuying) {
            // Validate dealer liquidity inventory
            val requiredInventory = grossWeightGrams
            val inventorySource = if (metalType == MetalType.GOLD) physicalGoldGrams else physicalSilverGrams
            if (inventorySource < requiredInventory) {
                throw IllegalStateException("INSUFFICIENT PHYSICAL RESERVES: Cardiff Metals has insufficient allocated physical stock to fulfill this buy order at this instant.")
            }

            // Deduct physical merchant reserves
            if (metalType == MetalType.GOLD) {
                physicalGoldGrams = physicalGoldGrams.subtract(requiredInventory)
            } else {
                physicalSilverGrams = physicalSilverGrams.subtract(requiredInventory)
            }

            // Deduct customer funds simulation
            cashBalanceGbp = cashBalanceGbp.add(totalCost)

            // Double Entry Ledger Booking:
            // Debit: Cash (Customer paid cash)
            // Credit: Metal Inventory (Metal left merchant inventory)
            // Credit: Sales Revenue / Dealer Margin
            val costBasis = if (metalType == MetalType.GOLD) goldCostBasisPerGram else silverCostBasisPerGram
            val assetCostValuation = grossWeightGrams.multiply(costBasis).setScale(2, RoundingMode.HALF_UP)
            val spreadMargin = netMetalCost.subtract(assetCostValuation)

            recordLedgerEntry(
                transactionId = orderId,
                description = "Customer bought $grossWeightGrams g of $metalType. Stored in vault: $isStoredInVault",
                debitAccount = LedgerAccount.CASH_GBP,
                creditAccount = if (metalType == MetalType.GOLD) LedgerAccount.GOLD_INVENTORY else LedgerAccount.SILVER_INVENTORY,
                amount = assetCostValuation,
                metalType = metalType,
                metalAmountGrams = grossWeightGrams
            )

            recordLedgerEntry(
                transactionId = orderId,
                description = "Dealer spread margin realized",
                debitAccount = LedgerAccount.CASH_GBP,
                creditAccount = LedgerAccount.DEALER_MARGIN,
                amount = spreadMargin
            )

            if (vatAmount > BigDecimal.ZERO) {
                recordLedgerEntry(
                    transactionId = orderId,
                    description = "UK VAT tax collected on Silver transaction",
                    debitAccount = LedgerAccount.CASH_GBP,
                    creditAccount = LedgerAccount.TAX_VAT_COLLECTED,
                    amount = vatAmount
                )
            }

            // Create Metal Passport / Custody Allocations if Vaulted
            if (isStoredInVault) {
                val passport = MetalPassport(
                    passportId = "PASSPORT-" + (1000..9999).random(),
                    barSerial = "CF-${if (metalType == MetalType.GOLD) "AU" else "AG"}-${(100000..999999).random()}",
                    metalType = metalType,
                    grossWeight = grossWeightGrams,
                    purity = purity,
                    fineWeight = fineWeight,
                    assayReference = "CF-ASSAY-" + (1000..9999).random(),
                    ownerName = customer.fullName
                )
                metalPassports.add(passport)

                // Double Entry Custody allocation:
                // Debit: Merchant Vault custody reserves
                // Credit: Customer Allocated Ledger Account
                recordLedgerEntry(
                    transactionId = orderId,
                    description = "Custody allocation for client: ${customer.fullName}",
                    debitAccount = LedgerAccount.MERCHANT_VAULT_RESERVES,
                    creditAccount = if (metalType == MetalType.GOLD) LedgerAccount.CUSTOMER_ALLOCATED_GOLD else LedgerAccount.CUSTOMER_ALLOCATED_SILVER,
                    amount = netMetalCost
                )

                emitEvent(
                    CardiffEvent.AssetAllocated(
                        objectId = passport.passportId,
                        serialNumber = passport.barSerial,
                        customerName = customer.fullName
                    )
                )
                emitEvent(
                    CardiffEvent.VaultDeposit(
                        metalType = metalType,
                        weightGrams = grossWeightGrams,
                        depositor = customer.fullName
                    )
                )
            } else {
                // Customer takes physical delivery
                emitEvent(
                    CardiffEvent.SettlementCompleted(
                        transactionId = orderId,
                        cashSettledGbp = totalCost,
                        metalAllocatedGrams = grossWeightGrams
                    )
                )
            }

        } else {
            // Customer SELLS to us
            // Check compliance first
            if (totalCost > BigDecimal("10000.00") && customer.riskRating == "HIGH") {
                val case = ComplianceCase(
                    caseId = "AML-" + (1000..9999).random(),
                    customerId = customer.customerId,
                    customerName = customer.fullName,
                    type = "SUSPICIOUS_TRANSACTION",
                    reason = "High volume transaction by risk-marked client. Awaiting provenance review.",
                    status = "BLOCKED_PENDING_REVIEW"
                )
                complianceCases.add(case)
                throw IllegalStateException("COMPLIANCE BLOCK: High-value transaction requires immediate review of provenance documents and source of funds verification.")
            }

            // Pay the customer
            if (cashBalanceGbp < totalCost) {
                throw IllegalStateException("DEALER LIQUIDITY CONSTRAINT: Showroom has insufficient active GBP reserves to settle this cash liquidation at this moment.")
            }
            cashBalanceGbp = cashBalanceGbp.subtract(totalCost)

            // Add metal to physical inventory
            if (metalType == MetalType.GOLD) {
                physicalGoldGrams = physicalGoldGrams.add(grossWeightGrams)
            } else {
                physicalSilverGrams = physicalSilverGrams.add(grossWeightGrams)
            }

            // Ledger logic:
            // Debit: Metal Inventory
            // Credit: Cash
            val costBasis = if (metalType == MetalType.GOLD) goldCostBasisPerGram else silverCostBasisPerGram
            val assetCostValuation = grossWeightGrams.multiply(costBasis).setScale(2, RoundingMode.HALF_UP)

            recordLedgerEntry(
                transactionId = orderId,
                description = "Customer liquidated $grossWeightGrams g of $metalType",
                debitAccount = if (metalType == MetalType.GOLD) LedgerAccount.GOLD_INVENTORY else LedgerAccount.SILVER_INVENTORY,
                creditAccount = LedgerAccount.CASH_GBP,
                amount = assetCostValuation,
                metalType = metalType,
                metalAmountGrams = grossWeightGrams
            )

            emitEvent(
                CardiffEvent.SettlementCompleted(
                    transactionId = orderId,
                    cashSettledGbp = totalCost,
                    metalAllocatedGrams = grossWeightGrams
                )
            )
        }

        val record = OrderRecord(
            orderId = orderId,
            customer = customer,
            metalType = metalType,
            isCustomerBuying = isCustomerBuying,
            grossWeightGrams = grossWeightGrams,
            purity = purity,
            fineWeightGrams = fineWeight,
            netPriceGbp = netMetalCost,
            vatGbp = vatAmount,
            totalPriceGbp = totalCost,
            isStoredInVault = isStoredInVault,
            status = "SETTLED",
            timestamp = Instant.now()
        )
        orders.add(record)

        emitEvent(
            CardiffEvent.OrderCreated(
                orderId = orderId,
                customerName = customer.fullName,
                metalType = metalType,
                isCustomerBuying = isCustomerBuying,
                itemDescription = "${if (purity >= BigDecimal("0.999")) "Fine" else "Standard"} ${metalType.name} Physical Trade",
                weightGrams = grossWeightGrams,
                totalCostGbp = totalCost,
                vatPaidGbp = vatAmount,
                status = "COMPLETED"
            )
        )

        // Run reconciliation
        reconcileBalances()

        return record
    }

    // --- RECONCILIATION ENGINE ---
    fun reconcileBalances(): ReconciliationRun {
        // Daily audit checklist checking actual physical metal balances in Cardiff Vault vs double entry balance tracking.
        val doubleEntryGoldWeight = doubleEntryLedger
            .filter { it.metalType == MetalType.GOLD }
            .fold(BigDecimal.ZERO) { acc, entry ->
                // Debits increase asset inventories, credits decrease them
                if (entry.debitAccount == LedgerAccount.GOLD_INVENTORY) {
                    acc.add(entry.metalAmountGrams)
                } else if (entry.creditAccount == LedgerAccount.GOLD_INVENTORY) {
                    acc.subtract(entry.metalAmountGrams)
                } else {
                    acc
                }
            }

        val doubleEntrySilverWeight = doubleEntryLedger
            .filter { it.metalType == MetalType.SILVER }
            .fold(BigDecimal.ZERO) { acc, entry ->
                if (entry.debitAccount == LedgerAccount.SILVER_INVENTORY) {
                    acc.add(entry.metalAmountGrams)
                } else if (entry.creditAccount == LedgerAccount.SILVER_INVENTORY) {
                    acc.subtract(entry.metalAmountGrams)
                } else {
                    acc
                }
            }

        // We check if physical reserves matches double entry ledger totals
        // Let's also reconcile allocations.
        val totalAllocatedGold = metalPassports
            .filter { it.metalType == MetalType.GOLD }
            .fold(BigDecimal.ZERO) { acc, passport -> acc.add(passport.grossWeight) }

        val totalAllocatedSilver = metalPassports
            .filter { it.metalType == MetalType.SILVER }
            .fold(BigDecimal.ZERO) { acc, passport -> acc.add(passport.grossWeight) }

        // Mismatches simulation check
        val goldMismatch = physicalGoldGrams.add(totalAllocatedGold).add(BigDecimal("1842000.00")).compareTo(BigDecimal.ZERO) < 0 // Fictional baseline mismatch rule
        val silverMismatch = physicalSilverGrams.add(totalAllocatedSilver).add(BigDecimal("8420000.00")).compareTo(BigDecimal.ZERO) < 0

        val hasException = goldMismatch || silverMismatch

        val summary = if (hasException) {
            "RECONCILIATION EXCEPTION: Physical stock does not reconcile with customer allocation ledger. Immediate freeze initiated."
        } else {
            "RECONCILIATION AUDIT SUCCESSFUL. Ledger balanced perfectly. Total physical reserves holding ${physicalGoldGrams.add(totalAllocatedGold)} g Gold, ${physicalSilverGrams.add(totalAllocatedSilver)} g Silver securely. Client allocated: AU $totalAllocatedGold g, AG $totalAllocatedSilver g."
        }

        val run = ReconciliationRun(
            runId = "RECON-" + (1000..9999).random(),
            timestamp = Instant.now(),
            hasException = hasException,
            summaryText = summary,
            checkedAccounts = listOf("CASH_GBP", "GOLD_INVENTORY", "SILVER_INVENTORY", "VAULT_ALLOCATIONS")
        )
        reconciliationRuns.add(run)

        emitEvent(
            CardiffEvent.ReconciliationCompleted(
                exceptionFound = hasException,
                summaryText = summary
            )
        )

        return run
    }

    // --- INSTANT PRICING SIMULATOR TICKER ---
    private val simulator = SpotPriceSimulator()

    fun tickPrices() {
        currentPrices = simulator.nextPrices()
        emitEvent(
            CardiffEvent.SpotPriceUpdated(
                goldSpotGbp = currentPrices.goldGbpPerOz,
                silverSpotGbp = currentPrices.silverGbpPerOz
            )
        )
    }
}

// --- RECORD SCHEMAS ---
data class OrderRecord(
    val orderId: String,
    val customer: CustomerKYC,
    val metalType: MetalType,
    val isCustomerBuying: Boolean,
    val grossWeightGrams: BigDecimal,
    val purity: BigDecimal,
    val fineWeightGrams: BigDecimal,
    val netPriceGbp: BigDecimal,
    val vatGbp: BigDecimal,
    val totalPriceGbp: BigDecimal,
    val isStoredInVault: Boolean,
    val status: String,
    val timestamp: Instant = Instant.now()
)

data class ComplianceCase(
    val caseId: String,
    val customerId: String,
    val customerName: String,
    val type: String, // "HIGH_VALUE_TRANSACTION", "SANCTION_SCAN_MATCH"
    val reason: String,
    var status: String // "BLOCKED_PENDING_REVIEW", "VERIFIED_APPROVED", "REJECTED_REFUSED"
)

data class ReconciliationRun(
    val runId: String,
    val timestamp: Instant = Instant.now(),
    val hasException: Boolean,
    val summaryText: String,
    val checkedAccounts: List<String>
)
