package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.KinkaScreen
import com.example.viewmodel.KinkaViewModel

@Composable
fun KinkaMainScreen(viewModel: KinkaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Handle system back gesture
    BackHandler(enabled = currentScreen != KinkaScreen.MARKET_OVERVIEW) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MatteBlack,
        bottomBar = {
            KinkaBottomNavigation(
                currentScreen = currentScreen,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MatteBlack)
        ) {
            // High-Prestige Japanese Header
            KinkaAppHeader(viewModel = viewModel)

            Divider(color = GridLineColor, thickness = 1.dp)

            // Dynamic Screen Switching
            Box(modifier = Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "screenTransition"
                ) { screen ->
                    when (screen) {
                        KinkaScreen.MARKET_OVERVIEW -> MarketOverviewScreen(viewModel)
                        KinkaScreen.GOLD_TERMINAL -> MetalTerminalScreen(viewModel, MetalType.GOLD)
                        KinkaScreen.SILVER_TERMINAL -> MetalTerminalScreen(viewModel, MetalType.SILVER)
                        KinkaScreen.PLATINUM_TERMINAL -> MetalTerminalScreen(viewModel, MetalType.PLATINUM)
                        KinkaScreen.DEALER_DESK -> DealerDeskScreen(viewModel)
                        KinkaScreen.INVENTORY_VAULT -> InventoryVaultScreen(viewModel)
                        KinkaScreen.ASSAY_RECYCLING -> AssayRecyclingScreen(viewModel)
                        KinkaScreen.LEDGERS_AUDIT -> LedgersAuditScreen(viewModel)
                        KinkaScreen.STRESS_LAB -> StressLabScreen(viewModel)
                        KinkaScreen.AI_ASSISTANT -> AiAssistantScreen(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun KinkaAppHeader(viewModel: KinkaViewModel) {
    val session by viewModel.currentSession.collectAsState()
    val usdJpy by viewModel.usdJpy.collectAsState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Charcoal)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JapaneseSeal()
                Column {
                    Text(
                        text = "金華",
                        color = WarmWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "KINKA PRECIOUS METALS",
                        color = MutedGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = MonoFont
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "貴金属を、精密に。 | JAPANESE PRECISION",
                color = OffWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
            SessionIndicator(currentSession = session, usdJpy = usdJpy)
        }
    }
}

@Composable
fun KinkaBottomNavigation(currentScreen: KinkaScreen, onNavigate: (KinkaScreen) -> Unit) {
    // Custom Navigation Row respecting system navigation bars padding
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Charcoal)
            .border(1.dp, BorderColor, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
            .navigationBarsPadding()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val navItems = listOf(
            NavigationItem(KinkaScreen.MARKET_OVERVIEW, "市場概況", Icons.Default.Dashboard, Icons.Outlined.Dashboard, "nav_market_overview"),
            NavigationItem(KinkaScreen.DEALER_DESK, "取引デスク", Icons.Default.AddBusiness, Icons.Outlined.AddBusiness, "nav_dealer_desk"),
            NavigationItem(KinkaScreen.INVENTORY_VAULT, "在庫・保管", Icons.Default.Warehouse, Icons.Outlined.Warehouse, "nav_inventory_vault"),
            NavigationItem(KinkaScreen.ASSAY_RECYCLING, "検査・買取", Icons.Default.Analytics, Icons.Outlined.Analytics, "nav_assay_recycling"),
            NavigationItem(KinkaScreen.AI_ASSISTANT, "KINKA AI", Icons.Default.SmartToy, Icons.Outlined.SmartToy, "nav_ai_assistant")
        )

        navItems.forEach { item ->
            val isSelected = currentScreen == item.screen
            IconButton(
                onClick = { onNavigate(item.screen) },
                modifier = Modifier
                    .weight(1f)
                    .testTag(item.testTag)
                    .size(52.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label,
                        tint = if (isSelected) MutedGold else BrushedMetal,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.label,
                        color = if (isSelected) MutedGold else BrushedMetal,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

data class NavigationItem(
    val screen: KinkaScreen,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

// ======================== SCREEN 1: MARKET OVERVIEW ========================
@Composable
fun MarketOverviewScreen(viewModel: KinkaViewModel) {
    val goldVal by viewModel.goldRef.collectAsState()
    val silverVal by viewModel.silverRef.collectAsState()
    val platinumVal by viewModel.platinumRef.collectAsState()

    // Pre-calculated mock trends for visual sparklines
    val goldTrend = remember { listOf(2642.0, 2645.0, 2648.0, 2641.0, 2649.0, 2650.0) }
    val silverTrend = remember { listOf(32.4, 32.1, 32.5, 32.3, 32.2, 32.1) }
    val platinumTrend = remember { listOf(980.0, 982.0, 985.0, 981.0, 984.0, 985.0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "【市場概況】 REALTIME SIMULATED MARKETS",
                    color = MutedGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = MonoFont
                )
                Text(
                    text = "シミュレーション市場データ | SYNTHETIC DATA ONLY",
                    color = BrushedMetal,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }

        // Active Metal Price Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Gold Card
                Box(modifier = Modifier.weight(1f).clickable { viewModel.navigateTo(KinkaScreen.GOLD_TERMINAL) }) {
                    KinkaCard(title = "GOLD | 金価格", subTag = "+0.42%", borderCol = BorderColor) {
                        Text(
                            text = "¥${String.format("%,.0f", goldVal)} / g",
                            color = WarmWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MonoFont
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Sparkline(data = goldTrend, modifier = Modifier.fillMaxWidth().height(40.dp), lineColor = ForestGreen)
                    }
                }

                // Platinum Card
                Box(modifier = Modifier.weight(1f).clickable { viewModel.navigateTo(KinkaScreen.PLATINUM_TERMINAL) }) {
                    KinkaCard(title = "PLATINUM | プラチナ", subTag = "+0.12%", borderCol = BorderColor) {
                        Text(
                            text = "¥${String.format("%,.0f", platinumVal)} / g",
                            color = WarmWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MonoFont
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Sparkline(data = platinumTrend, modifier = Modifier.fillMaxWidth().height(40.dp), lineColor = ForestGreen)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Silver Card
                Box(modifier = Modifier.weight(1f).clickable { viewModel.navigateTo(KinkaScreen.SILVER_TERMINAL) }) {
                    KinkaCard(title = "SILVER | 銀価格", subTag = "-0.18%", borderCol = BorderColor) {
                        Text(
                            text = "¥${String.format("%,.1f", silverVal)} / g",
                            color = WarmWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MonoFont
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Sparkline(data = silverTrend, modifier = Modifier.fillMaxWidth().height(40.dp), lineColor = Vermilion)
                    }
                }

                // Quick Link Card to Double-Entry General Ledger
                Box(modifier = Modifier.weight(1f).clickable { viewModel.navigateTo(KinkaScreen.LEDGERS_AUDIT) }) {
                    KinkaCard(title = "元帳 & 会計監査", subTag = "DEBITS=CREDITS", borderCol = MutedGold) {
                        Text(
                            text = "二重仕訳元帳",
                            color = MutedGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "円・メタル純分 リアルタイム監査システム。全仕訳明細の一括監査ログ。",
                            color = BrushedMetal,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Quick Action Hub (金を売る, 金を買う, 貴金属を査定, etc)
        item {
            KinkaCard(title = "クイック業務ハブ | QUICK ACTIONS") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(KinkaScreen.DEALER_DESK) },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).padding(end = 4.dp).testTag("buy_gold_action")
                    ) {
                        Icon(Icons.Default.TrendingUp, "Buy", tint = WarmWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ゴールド買付", fontSize = 11.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.navigateTo(KinkaScreen.DEALER_DESK) },
                        colors = ButtonDefaults.buttonColors(containerColor = Vermilion),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp).testTag("sell_gold_action")
                    ) {
                        Icon(Icons.Default.TrendingDown, "Sell", tint = WarmWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ゴールド売却", fontSize = 11.sp, color = WarmWhite, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.navigateTo(KinkaScreen.ASSAY_RECYCLING) },
                        colors = ButtonDefaults.buttonColors(containerColor = SoftCharcoal),
                        shape = RoundedCornerShape(2.dp),
                        border = BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.weight(1.3f).padding(start = 4.dp).testTag("recycle_assess_action")
                    ) {
                        Icon(Icons.Default.QueryStats, "Recycle", tint = MutedGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("貴金属買取査定", fontSize = 11.sp, color = MutedGold, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Navigation list for supplementary screens
        item {
            KinkaCard(title = "補助分析・ラボ | LABS & ANALYTICS") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(KinkaScreen.STRESS_LAB) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmWhite),
                        shape = RoundedCornerShape(2.dp),
                        border = BorderStroke(1.dp, BorderColor)
                    ) {
                        Text("ストレステスト", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(KinkaScreen.LEDGERS_AUDIT) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmWhite),
                        shape = RoundedCornerShape(2.dp),
                        border = BorderStroke(1.dp, BorderColor)
                    ) {
                        Text("二重元帳監査", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 2: METAL TERMINALS ========================
@Composable
fun MetalTerminalScreen(viewModel: KinkaViewModel, metalType: MetalType) {
    val bars by viewModel.physicalBars.collectAsState()
    val matchingBars = bars.filter { it.metalType == metalType }
    val refPrice = when (metalType) {
        MetalType.GOLD -> viewModel.goldRef.collectAsState().value
        MetalType.SILVER -> viewModel.silverRef.collectAsState().value
        MetalType.PLATINUM -> viewModel.platinumRef.collectAsState().value
        MetalType.PALLADIUM -> viewModel.palladiumRef.collectAsState().value
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${metalType.displayName}ターミナル | ${metalType.name} DASHBOARD",
                    color = MutedGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = { viewModel.navigateTo(KinkaScreen.MARKET_OVERVIEW) },
                    colors = ButtonDefaults.buttonColors(containerColor = SoftCharcoal),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("市場概況へ", fontSize = 11.sp, color = WarmWhite)
                }
            }
        }

        // Metal Reference Price
        item {
            KinkaCard(title = "${metalType.displayName} 国内店頭参考価格") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "¥${String.format("%,.1f", refPrice)} / g",
                            color = WarmWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MonoFont
                        )
                        Text(
                            text = "金華基準フェアバリュー値 (Purity 99.9% 換算)",
                            color = BrushedMetal,
                            fontSize = 11.sp
                        )
                    }
                    JapaneseSeal()
                }
            }
        }

        // Simulated Inventory Specific List
        item {
            KinkaCard(title = "割当可能 ${metalType.displayName}地金一覧 (保管庫)") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (matchingBars.isEmpty()) {
                        Text("割当可能な地金はございません。", color = BrushedMetal, fontSize = 12.sp)
                    } else {
                        matchingBars.take(5).forEach { bar ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                    .background(SoftCharcoal)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = bar.serialNumber,
                                        color = WarmWhite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = MonoFont
                                    )
                                    Text(
                                        text = "品位: ${bar.purity} | 量: ${bar.grossWeight}g | 純分: ${String.format("%.2f", bar.fineWeight)}g",
                                        color = BrushedMetal,
                                        fontSize = 11.sp
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = bar.location.kanjiName,
                                        color = MutedGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = bar.status.displayName,
                                        color = if (bar.status == PhysicalStatus.UNASSIGNED) ForestGreen else MutedGold,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 3: DEALER DESK & RFQ ========================
@Composable
fun DealerDeskScreen(viewModel: KinkaViewModel) {
    val activeRfq by viewModel.activeRfq.collectAsState()
    val rfqTimer by viewModel.activeRfqTimeRemaining.collectAsState()

    var clientName by remember { mutableStateOf("東日本貴金属株式会社") }
    var selectedMetal by remember { mutableStateOf(MetalType.GOLD) }
    var selectedProduct by remember { mutableStateOf(ProductType.BULLION_BAR) }
    var purity by remember { mutableStateOf("0.9999") }
    var quantityGrams by remember { mutableStateOf("500") }
    var deliveryLocation by remember { mutableStateOf(VaultLocation.TOKYO) }
    var paymentTerms by remember { mutableStateOf("銀行振込 (T/T)") }

    val focusManager = LocalFocusManager.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "貴金属取引デスク & 見積作成 | DEALER DESK",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            KinkaCard(title = "見積依頼作成 (RFQ submission)") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Client Selector
                    OutlinedTextField(
                        value = clientName,
                        onValueChange = { clientName = it },
                        label = { Text("顧客事業者名 (Client)", color = BrushedMetal) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmWhite,
                            unfocusedTextColor = WarmWhite,
                            focusedBorderColor = MutedGold,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("client_name_field")
                    )

                    // Metal & Product selection
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("貴金属区分", color = BrushedMetal, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                            Row {
                                MetalType.values().forEach { metal ->
                                    val isSelected = selectedMetal == metal
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .border(1.dp, if (isSelected) MutedGold else BorderColor, RoundedCornerShape(2.dp))
                                            .background(if (isSelected) MutedGold.copy(alpha = 0.15f) else Color.Transparent)
                                            .clickable { selectedMetal = metal }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(metal.displayName, color = if (isSelected) MutedGold else OffWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = purity,
                            onValueChange = { purity = it },
                            label = { Text("品位 (Purity)", color = BrushedMetal) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmWhite,
                                unfocusedTextColor = WarmWhite,
                                focusedBorderColor = MutedGold,
                                unfocusedBorderColor = BorderColor
                            ),
                            modifier = Modifier.weight(1f).testTag("purity_field")
                        )

                        OutlinedTextField(
                            value = quantityGrams,
                            onValueChange = { quantityGrams = it },
                            label = { Text("数量（グラム）", color = BrushedMetal) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmWhite,
                                unfocusedTextColor = WarmWhite,
                                focusedBorderColor = MutedGold,
                                unfocusedBorderColor = BorderColor
                            ),
                            modifier = Modifier.weight(1f).testTag("quantity_field")
                        )
                    }

                    // Vault location
                    Column {
                        Text("受渡場所（保管庫）", color = BrushedMetal, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(VaultLocation.TOKYO, VaultLocation.OSAKA, VaultLocation.NAGOYA).forEach { loc ->
                                val isSelected = deliveryLocation == loc
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(1.dp, if (isSelected) MutedGold else BorderColor, RoundedCornerShape(2.dp))
                                        .background(if (isSelected) MutedGold.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable { deliveryLocation = loc }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(loc.kanjiName.take(2), color = if (isSelected) MutedGold else OffWhite, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Submit button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            val qty = quantityGrams.toDoubleOrNull() ?: 500.0
                            val pur = purity.toDoubleOrNull() ?: 0.9999
                            viewModel.submitRfq(
                                clientName = clientName,
                                metalType = selectedMetal,
                                productType = selectedProduct,
                                purity = pur,
                                quantityGrams = qty,
                                deliveryLocation = deliveryLocation,
                                paymentTerms = paymentTerms
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("submit_rfq_button")
                    ) {
                        Text("見積を依頼する (RFQ送信)", color = MatteBlack, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Active RFQ Quote Presentation Desk
        item {
            activeRfq?.let { rfq ->
                KinkaCard(
                    title = "現在算出された見積書 (Active Fair Quote)",
                    subTag = rfq.rfqId,
                    borderCol = if (rfq.isExpired) Vermilion else if (rfq.isAccepted) ForestGreen else MutedGold
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("品目 / 区分:", color = BrushedMetal, fontSize = 12.sp)
                            Text("${rfq.metalType.displayName} ${rfq.purity} (${rfq.productType.displayName})", color = WarmWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("引合量 / 単価:", color = BrushedMetal, fontSize = 12.sp)
                            Text("${rfq.quantityGrams}g @ ¥${String.format("%,.1f", rfq.askPricePerGram)} / g", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }

                        // Detailed Pricing breakdown chain (Benchmark, premiums, FX)
                        Divider(color = GridLineColor)
                        Text("【計算内訳チェーン】", color = MutedGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("国際スポット / FX:", color = BrushedMetal, fontSize = 11.sp)
                            Text("$${rfq.benchmarkSpotPriceJpy} USD/oz | ¥${rfq.fxRateUsdJpy}", color = OffWhite, fontSize = 11.sp, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("プレミアム調整費:", color = BrushedMetal, fontSize = 11.sp)
                            Text("+¥${rfq.computedPremiumJpy} / g", color = OffWhite, fontSize = 11.sp, fontFamily = MonoFont)
                        }
                        Divider(color = GridLineColor)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("決済条件 / 受渡場所:", color = BrushedMetal, fontSize = 12.sp)
                            Text("${rfq.paymentTerms} / ${rfq.deliveryLocation.kanjiName}", color = WarmWhite, fontSize = 12.sp)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SoftCharcoal)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("総御見積額 (Total Amount)", color = MutedGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("¥${String.format("%,.0f", rfq.totalAmountJpy)} 円", color = WarmWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                if (rfq.isAccepted) {
                                    Text("取引完了", color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                } else if (rfq.isExpired) {
                                    Text("有効期限切れ", color = Vermilion, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                } else {
                                    Text("見積有効期限: ${rfqTimer}秒", color = Vermilion, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = MonoFont)
                                }
                            }
                        }

                        // Confirm Buttons
                        if (!rfq.isAccepted && !rfq.isExpired) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.confirmActiveTrade("BUY") },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.weight(1f).height(42.dp).testTag("accept_buy_quote_button")
                                ) {
                                    Text("買付確定", color = WarmWhite, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { viewModel.confirmActiveTrade("SELL") },
                                    colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.weight(1f).height(42.dp).testTag("accept_sell_quote_button")
                                ) {
                                    Text("売却確定", color = MatteBlack, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 4: INVENTORY, VAULT & RECEIPTS ========================
@Composable
fun InventoryVaultScreen(viewModel: KinkaViewModel) {
    val bars by viewModel.physicalBars.collectAsState()
    val receipts by viewModel.warehouseReceipts.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Inventory/Vaults, 1: Warehouse Receipts

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "保管管理 & 倉荷証券デスク | INVENTORY",
                    color = MutedGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Tab selection
        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                TabButton(text = "保管金庫・地金在庫", isSelected = selectedTab == 0, modifier = Modifier.weight(1f)) { selectedTab = 0 }
                TabButton(text = "倉荷証券 (Warehouse Receipts)", isSelected = selectedTab == 1, modifier = Modifier.weight(1f)) { selectedTab = 1 }
            }
        }

        if (selectedTab == 0) {
            // Summary holdings of Gold, Silver, Platinum
            item {
                KinkaCard(title = "保管庫総資材サマリー (Total Holdings)") {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        HoldingsSummaryItem("GOLD", "${String.format("%.2f", bars.filter { it.metalType == MetalType.GOLD }.sumOf { it.fineWeight } / 1000.0)} kg")
                        HoldingsSummaryItem("SILVER", "${String.format("%.2f", bars.filter { it.metalType == MetalType.SILVER }.sumOf { it.fineWeight } / 1000.0)} kg")
                        HoldingsSummaryItem("PLATINUM", "${String.format("%.2f", bars.filter { it.metalType == MetalType.PLATINUM }.sumOf { it.fineWeight } / 1000.0)} kg")
                    }
                }
            }

            // List of actual serialized bars in different city vaults
            item {
                KinkaCard(title = "実物保管地金台帳 (Vault Ledger)") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        bars.take(15).forEach { bar ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                    .background(SoftCharcoal)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(if (bar.status == PhysicalStatus.ALLOCATED) MutedGold else ForestGreen)
                                    )
                                    Column {
                                        Text(bar.serialNumber, color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${bar.metalType.displayName} ${bar.purity} | ${bar.grossWeight}g | ${bar.manufacturer}",
                                            color = BrushedMetal,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(bar.location.kanjiName, color = WarmWhite, fontSize = 11.sp)
                                    Text(
                                        text = bar.status.displayName,
                                        color = if (bar.status == PhysicalStatus.ALLOCATED) MutedGold else ForestGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Warehouse Receipts list
            item {
                KinkaCard(title = "OSE適格倉荷証券一覧") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (receipts.isEmpty()) {
                            Text("現在、発行された倉荷証券はございません。", color = BrushedMetal, fontSize = 12.sp)
                        } else {
                            receipts.forEach { wr ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                        .background(SoftCharcoal)
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(wr.receiptId, color = MutedGold, fontSize = 12.sp, fontFamily = MonoFont, fontWeight = FontWeight.Bold)
                                        Text("適格証券", color = ForestGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("預入倉庫: ${wr.warehouseName}", color = OffWhite, fontSize = 11.sp)
                                    Text("寄託者: ${wr.owner}", color = OffWhite, fontSize = 11.sp)
                                    Text("預入地金: ${wr.metalType.displayName} | 重量: ${wr.grossWeight}g", color = BrushedMetal, fontSize = 11.sp)
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("発行日: ${wr.issueDate.take(10)}", color = BrushedMetal, fontSize = 10.sp)
                                        Text("シリアル: ${wr.barSerialNumbers.joinToString()}", color = MutedGold, fontSize = 10.sp, fontFamily = MonoFont)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabButton(text: String, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .border(1.dp, if (isSelected) MutedGold else BorderColor, RoundedCornerShape(2.dp))
            .background(if (isSelected) MutedGold.copy(alpha = 0.15f) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = if (isSelected) MutedGold else OffWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HoldingsSummaryItem(label: String, valStr: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = BrushedMetal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(valStr, color = WarmWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
    }
}

// ======================== SCREEN 5: ASSAY & RECYCLING ========================
@Composable
fun AssayRecyclingScreen(viewModel: KinkaViewModel) {
    val recyclingRecords by viewModel.recyclingRecords.collectAsState()
    val assays by viewModel.assayRecords.collectAsState()
    val twinState by viewModel.twinState.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Buyback & Assay, 1: Recycling Digital Twin

    // Recycling input states
    var customerName by remember { mutableStateOf("山田様") }
    var article by remember { mutableStateOf("K18 金製ブレスレット") }
    var weightInput by remember { mutableStateOf("38.4") }
    var selectedKarat by remember { mutableStateOf("18K") }
    var purityVal by remember { mutableStateOf(0.75) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "貴金属買取査定・品位分析 & リサイクルツイン | RECYCLING",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                TabButton(text = "買取・査定・品位検査", isSelected = activeTab == 0, modifier = Modifier.weight(1f)) { activeTab = 0 }
                TabButton(text = "リサイクル・ツイン", isSelected = activeTab == 1, modifier = Modifier.weight(1f)) { activeTab = 1 }
            }
        }

        if (activeTab == 0) {
            // Recycling form
            item {
                KinkaCard(title = "店舗貴金属買取査定 (Old Gold Buyback Calculator)") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("お客様名 (Customer)", color = BrushedMetal) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmWhite,
                                unfocusedTextColor = WarmWhite,
                                focusedBorderColor = MutedGold,
                                unfocusedBorderColor = BorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = article,
                                onValueChange = { article = it },
                                label = { Text("品名 (Article)", color = BrushedMetal) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = WarmWhite,
                                    unfocusedTextColor = WarmWhite,
                                    focusedBorderColor = MutedGold,
                                    unfocusedBorderColor = BorderColor
                                ),
                                modifier = Modifier.weight(1.5f)
                            )

                            OutlinedTextField(
                                value = weightInput,
                                onValueChange = { weightInput = it },
                                label = { Text("重量 (g)", color = BrushedMetal) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = WarmWhite,
                                    unfocusedTextColor = WarmWhite,
                                    focusedBorderColor = MutedGold,
                                    unfocusedBorderColor = BorderColor
                                ),
                                modifier = Modifier.weight(0.8f).testTag("recycle_weight_input")
                            )
                        }

                        // Karat Selector
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("24K" to 0.999, "18K" to 0.75, "14K" to 0.585, "PT950" to 0.95).forEach { (karat, pur) ->
                                val isSelected = selectedKarat == karat
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(1.dp, if (isSelected) MutedGold else BorderColor, RoundedCornerShape(2.dp))
                                        .background(if (isSelected) MutedGold.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable {
                                            selectedKarat = karat
                                            purityVal = pur
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(karat, color = if (isSelected) MutedGold else OffWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val w = weightInput.toDoubleOrNull() ?: 38.4
                                viewModel.assessRecycle(customerName, article, w, selectedKarat, purityVal)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("assess_recycle_button")
                        ) {
                            Text("査定を実行する", color = MatteBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Display result if present
            item {
                val quote by viewModel.activeRecyclingQuote.collectAsState()
                quote?.let { q ->
                    KinkaCard(title = "査定・買取明細書 (Buyback Receipt)", borderCol = ForestGreen) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("山田様 買取査定結果", color = WarmWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("品名:", color = BrushedMetal, fontSize = 12.sp)
                                Text(q.articleDescription, color = WarmWhite, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("総重量 / 品位:", color = BrushedMetal, fontSize = 12.sp)
                                Text("${q.grossWeight}g / ${q.purityKarat} (純分率: ${q.purityDecimal})", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("純金分重量 (Fine Gold):", color = BrushedMetal, fontSize = 12.sp)
                                Text("${String.format("%.2f", q.fineWeightGrams)} g", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("基準参考価格 / g:", color = BrushedMetal, fontSize = 12.sp)
                                Text("¥${String.format("%,.1f", q.benchmarkReferencePriceJpy)}", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("精錬手数料・各種控除:", color = BrushedMetal, fontSize = 12.sp)
                                Text("-¥${String.format("%,.0f", q.handlingDeductionJpy)}", color = Vermilion, fontSize = 12.sp, fontFamily = MonoFont)
                            }
                            Divider(color = GridLineColor)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SoftCharcoal)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("お客様お支払金額", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("¥${String.format("%,.0f", q.customerPayoutJpy)} 円", color = WarmWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
                            }
                        }
                    }
                }
            }

            // Quality Assays List
            item {
                KinkaCard(title = "品位検査ワークフロー管理 (Assay Queue)") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        assays.forEach { assay ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                    .background(SoftCharcoal)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(assay.sampleId, color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont, fontWeight = FontWeight.Bold)
                                    Text("declared: ${assay.declaredPurity} | measured: ${String.format("%.4f", assay.measuredPurity)}", color = BrushedMetal, fontSize = 11.sp)
                                }
                                Button(
                                    onClick = { viewModel.processAssay(assay.sampleId) },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (assay.status == AssayStep.INVENTORIED) ForestGreen else MutedGold),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(assay.status.displayName, color = MatteBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Recycling Digital Twin Material Flow simulation
            item {
                KinkaCard(title = "リサイクル デジタル・ツイン (Recycling Twin Simulator)") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "10kgの混合スクラップを電解融解分離し、99.99%純分の金・銀・プラチナを回収するデジタルフローです。",
                            color = OffWhite,
                            fontSize = 11.sp
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SoftCharcoal)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("現在のプロセス段階:", color = BrushedMetal, fontSize = 11.sp)
                                Text(
                                    text = twinState.currentStage,
                                    color = if (twinState.isRunning) MutedGold else ForestGreen,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                LinearProgressIndicator(
                                    progress = { twinState.progress },
                                    modifier = Modifier.fillMaxWidth().height(4.dp),
                                    color = MutedGold,
                                    trackColor = BorderColor,
                                )
                            }
                        }

                        // Start twin simulation
                        if (!twinState.isRunning) {
                            Button(
                                onClick = { viewModel.startRecyclingTwinSimulation(10000.0) }, // 10kg
                                colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth().testTag("start_twin_sim_button")
                            ) {
                                Text("デジタルツインを起動する", color = MatteBlack, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Yield breakdown
                        if (twinState.progress == 1.0f) {
                            Divider(color = GridLineColor)
                            Text("【回収成果物内訳】", color = ForestGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("回収純金量 (Fine Gold):", color = BrushedMetal, fontSize = 11.sp)
                                Text("${String.format("%.2f", twinState.recoveredGoldGrams)} g", color = WarmWhite, fontSize = 11.sp, fontFamily = MonoFont)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("回収純銀量 (Fine Silver):", color = BrushedMetal, fontSize = 11.sp)
                                Text("${String.format("%.2f", twinState.recoveredSilverGrams)} g", color = WarmWhite, fontSize = 11.sp, fontFamily = MonoFont)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("回収純プラチナ量 (Fine Platinum):", color = BrushedMetal, fontSize = 11.sp)
                                Text("${String.format("%.2f", twinState.recoveredPlatinumGrams)} g", color = WarmWhite, fontSize = 11.sp, fontFamily = MonoFont)
                            }
                            Divider(color = GridLineColor)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("回収資産価値概算:", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("¥${String.format("%,.0f", twinState.recoveryValueJpy)} 円", color = WarmWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
                            }
                            Text("※金華地金台帳(Vault Ledger)に『品位認証完了地金』として自動で登録されました。", color = BrushedMetal, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 6: LEDGERS & FINANCIAL AUDIT ========================
@Composable
fun LedgersAuditScreen(viewModel: KinkaViewModel) {
    val financialEntries by viewModel.financialLedger.collectAsState()
    val metalEntries by viewModel.metalLedger.collectAsState()

    var activeLedgerType by remember { mutableStateOf(0) } // 0: Financial, 1: Metal

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "ダブルエントリー元帳 & 会計監査 | DOUBLE ENTRY LEDGER",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                TabButton(text = "純分円建て財務元帳", isSelected = activeLedgerType == 0, modifier = Modifier.weight(1f)) { activeLedgerType = 0 }
                TabButton(text = "純分重量メタル元帳", isSelected = activeLedgerType == 1, modifier = Modifier.weight(1f)) { activeLedgerType = 1 }
            }
        }

        if (activeLedgerType == 0) {
            // Real Financial double-entry ledger checking
            val debits = financialEntries.filter { it.isDebit }.sumOf { it.amountJpy }
            val credits = financialEntries.filter { !it.isDebit }.sumOf { it.amountJpy }
            val isBalanced = debits == credits

            item {
                KinkaCard(
                    title = "財務仕訳バランス監査 (Trial Balance)",
                    borderCol = if (isBalanced) ForestGreen else Vermilion
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("借方合計 (Total Debits):", color = BrushedMetal, fontSize = 12.sp)
                            Text("¥${String.format("%,d", debits)} 円", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("貸方合計 (Total Credits):", color = BrushedMetal, fontSize = 12.sp)
                            Text("¥${String.format("%,d", credits)} 円", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Divider(color = GridLineColor)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("監査整合ステータス:", color = MutedGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (isBalanced) "貸借一致 (INVARIANT OK)" else "不一致",
                                color = if (isBalanced) ForestGreen else Vermilion,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Ledger entries list
            item {
                KinkaCard(title = "仕訳明細台帳 (General Ledger)") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        financialEntries.forEach { entry ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                    .background(SoftCharcoal)
                                    .padding(8.dp)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(entry.accountName, color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = if (entry.isDebit) "借 (DR)" else "貸 (CR)",
                                        color = if (entry.isDebit) MutedGold else BrushedMetal,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text("概要: ${entry.description}", color = OffWhite, fontSize = 11.sp)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("額: ¥${String.format("%,d", entry.amountJpy)}", color = MutedGold, fontSize = 11.sp, fontFamily = MonoFont)
                                    Text("取引先: ${entry.counterparty}", color = BrushedMetal, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Metal Ledger
            item {
                KinkaCard(title = "純分重量監査 (Metal Mass Balance Audit)") {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "金属台帳不変条件: 総重量 × 品位 ＝ 純分重量 (GROSS WEIGHT × PURITY ＝ FINE METAL WEIGHT)",
                            color = OffWhite,
                            fontSize = 11.sp
                        )
                        Divider(color = GridLineColor)
                        metalEntries.take(10).forEach { entry ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GridLineColor, RoundedCornerShape(2.dp))
                                    .background(SoftCharcoal)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${entry.metalType.displayName} ${entry.direction}",
                                        color = if (entry.direction == "IN") ForestGreen else Vermilion,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text("純分重量: ${entry.fineWeightGrams}g | 粗重量: ${entry.grossWeightGrams}g", color = BrushedMetal, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(entry.owner, color = WarmWhite, fontSize = 10.sp)
                                    Text(entry.location.kanjiName, color = MutedGold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 7: STRESS TEST & SCENARIO LAB ========================
@Composable
fun StressLabScreen(viewModel: KinkaViewModel) {
    val activeResult by viewModel.activeScenarioResult.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "リスク検証・ストレステスト・ラボ | RISK LAB",
                color = MutedGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Available Scenarios Selector
        item {
            KinkaCard(title = "検証シナリオ選択 (Select Scenario)") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "GOLD_SPIKE" to "ゴールド急騰シナリオ (Gold Spike +5% & JPY -2%)",
                        "CRASH" to "急激な相場暴落 & 流動性危機 (Crash -12% & JPY +5%)",
                        "JPY_APPRECIATION" to "急激な円高シナリオ (JPY Appreciation -4% & Gold -2%)"
                    ).forEach { (scenario, displayName) ->
                        Button(
                            onClick = { viewModel.selectScenario(scenario) },
                            colors = ButtonDefaults.buttonColors(containerColor = SoftCharcoal),
                            shape = RoundedCornerShape(2.dp),
                            border = BorderStroke(1.dp, BorderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(displayName, color = WarmWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Stress Results presentation
        item {
            activeResult?.let { res ->
                KinkaCard(
                    title = "シナリオ検証結果分析 (Stress Test Result)",
                    subTag = res.scenarioName,
                    borderCol = if (res.alertLevel == "CRITICAL") Vermilion else if (res.alertLevel == "WARNING") MutedGold else ForestGreen
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("価格・為替変動率:", color = BrushedMetal, fontSize = 12.sp)
                            Text("金: ${res.priceChangePercent * 100}% | 為替: ${res.fxChangePercent * 100}%", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("自己資本への損益影響額 (PnL Impact):", color = BrushedMetal, fontSize = 12.sp)
                            Text(
                                text = "¥${String.format("%,.0f", res.pnlImpactJpy)} 円",
                                color = if (res.pnlImpactJpy >= 0) ForestGreen else Vermilion,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = MonoFont
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("検証後保有地金総評価額:", color = BrushedMetal, fontSize = 12.sp)
                            Text("¥${String.format("%,.0f", res.endingPortfolioValueJpy)} 円", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("残存自己資本総額:", color = BrushedMetal, fontSize = 12.sp)
                            Text("¥${String.format("%,.0f", res.remainingCapitalJpy)} 円", color = WarmWhite, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("流動性比率 (Liquidity Ratio):", color = BrushedMetal, fontSize = 12.sp)
                            Text("${res.liquidityRatio * 100}%", color = if (res.liquidityRatio < 0.7) Vermilion else ForestGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFont)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ヘッジ有効性割合 (Hedge Effectiveness):", color = BrushedMetal, fontSize = 12.sp)
                            Text("${res.hedgeEffectivenessPercent}%", color = ForestGreen, fontSize = 12.sp, fontFamily = MonoFont)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (res.alertLevel == "CRITICAL") Vermilion.copy(alpha = 0.15f) else SoftCharcoal)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("リスク管理警告レベル:", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = res.alertLevel,
                                color = if (res.alertLevel == "CRITICAL") Vermilion else if (res.alertLevel == "WARNING") MutedGold else ForestGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ======================== SCREEN 8: KINKA AI ASSISTANT ========================
@Composable
fun AiAssistantScreen(viewModel: KinkaViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "金華 AI アシスタント | KINKA COGNITIVE ENGINE",
            color = MutedGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Suggestion questions chips
        Text("推奨される問い合わせの例 (タップして入力):", color = BrushedMetal, fontSize = 10.sp, modifier = Modifier.padding(bottom = 4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "現在の金在庫はいくらですか？",
                "今日の損益はいくらですか？",
                "最大の金ポジションを持つ顧客は？",
                "東京保管庫の金は何kgありますか？"
            ).forEach { sug ->
                Box(
                    modifier = Modifier
                        .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                        .background(SoftCharcoal)
                        .clickable { textInput = sug }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(sug, color = OffWhite, fontSize = 11.sp)
                }
            }
        }

        // Chat list area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, BorderColor, RoundedCornerShape(2.dp))
                .background(Charcoal)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(message = msg)
            }

            if (isAiLoading) {
                item {
                    Text("金華AI 思考中...", color = MutedGold, fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("AIに質問...", color = BrushedMetal, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = WarmWhite,
                    unfocusedTextColor = WarmWhite,
                    focusedBorderColor = MutedGold,
                    unfocusedBorderColor = BorderColor
                ),
                modifier = Modifier.weight(1f).testTag("ai_input_field")
            )

            Button(
                onClick = {
                    if (textInput.isNotBlank()) {
                        focusManager.clearFocus()
                        viewModel.sendAiMessage(textInput)
                        textInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MutedGold),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.height(52.dp).testTag("ai_send_button")
            ) {
                Icon(Icons.Default.Send, "Send", tint = MatteBlack)
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val alignment = if (message.isUser) Alignment.End else Alignment.Start
    val bubbleColor = if (message.isUser) MutedGold.copy(alpha = 0.15f) else SoftCharcoal
    val textColor = if (message.isUser) MutedGold else OffWhite

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Box(
            modifier = Modifier
                .border(1.dp, if (message.isUser) MutedGold else BorderColor, RoundedCornerShape(4.dp))
                .background(bubbleColor)
                .padding(10.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                text = message.text,
                color = textColor,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
        Text(
            text = message.timestamp,
            color = BrushedMetal,
            fontSize = 8.sp,
            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
        )
    }
}
