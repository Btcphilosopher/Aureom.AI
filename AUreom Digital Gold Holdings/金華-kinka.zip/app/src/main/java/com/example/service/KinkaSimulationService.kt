package com.example.service

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*

object KinkaSimulationService {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.JAPAN)

    // Current Market Status Flow
    private val _goldSpot = MutableStateFlow(2650.0) // USD/oz
    private val _silverSpot = MutableStateFlow(32.2) // USD/oz
    private val _platinumSpot = MutableStateFlow(985.0) // USD/oz
    private val _palladiumSpot = MutableStateFlow(1050.0) // USD/oz
    private val _usdJpy = MutableStateFlow(148.50) // JPY/USD

    // Calculated Domestic Reference Prices (円/g)
    private val _goldRef = MutableStateFlow(12650.0)
    private val _silverRef = MutableStateFlow(154.0)
    private val _platinumRef = MutableStateFlow(4700.0)
    private val _palladiumRef = MutableStateFlow(5010.0)

    val goldRef: StateFlow<Double> = _goldRef.asStateFlow()
    val silverRef: StateFlow<Double> = _silverRef.asStateFlow()
    val platinumRef: StateFlow<Double> = _platinumRef.asStateFlow()
    val palladiumRef: StateFlow<Double> = _palladiumRef.asStateFlow()
    val usdJpy: StateFlow<Double> = _usdJpy.asStateFlow()

    // Interactive State lists
    private val _physicalBars = MutableStateFlow<List<PhysicalBar>>(emptyList())
    val physicalBars: StateFlow<List<PhysicalBar>> = _physicalBars.asStateFlow()

    private val _warehouseReceipts = MutableStateFlow<List<WarehouseReceipt>>(emptyList())
    val warehouseReceipts: StateFlow<List<WarehouseReceipt>> = _warehouseReceipts.asStateFlow()

    private val _rfqs = MutableStateFlow<List<Rfq>>(emptyList())
    val rfqs: StateFlow<List<Rfq>> = _rfqs.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _recyclingRecords = MutableStateFlow<List<RecyclingRecord>>(emptyList())
    val recyclingRecords: StateFlow<List<RecyclingRecord>> = _recyclingRecords.asStateFlow()

    private val _assayRecords = MutableStateFlow<List<AssayRecord>>(emptyList())
    val assayRecords: StateFlow<List<AssayRecord>> = _assayRecords.asStateFlow()

    private val _financialLedger = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val financialLedger: StateFlow<List<LedgerEntry>> = _financialLedger.asStateFlow()

    private val _metalLedger = MutableStateFlow<List<MetalLedgerEntry>>(emptyList())
    val metalLedger: StateFlow<List<MetalLedgerEntry>> = _metalLedger.asStateFlow()

    // Market session definitions
    private val _currentSession = MutableStateFlow("後場 (東京セッション)")
    val currentSession: StateFlow<String> = _currentSession.asStateFlow()

    init {
        // Generate preloaded rich synthetic database
        generatePreloadedData()
    }

    // Precise JPY Pricing Engine using Decimal Arithmetic
    // Converts USD/oz Spot to JPY/g with custom parameters
    fun calculatePrice(
        metalType: MetalType,
        purity: Double,
        weightGrams: Double,
        clientTierDiscountPercent: Double = 0.0
    ): Map<String, Any> {
        val spotUsd = when (metalType) {
            MetalType.GOLD -> _goldSpot.value
            MetalType.SILVER -> _silverSpot.value
            MetalType.PLATINUM -> _platinumSpot.value
            MetalType.PALLADIUM -> _palladiumSpot.value
        }
        val fx = _usdJpy.value

        // Troy ounce to gram constant
        val gramsPerOz = BigDecimal("31.1034768")

        // 1. Calculate base international price per gram in JPY
        val spotUsdBD = BigDecimal(spotUsd.toString())
        val fxBD = BigDecimal(fx.toString())
        val baseJpyPerGram = spotUsdBD.multiply(fxBD).divide(gramsPerOz, 4, RoundingMode.HALF_UP)

        // 2. Domestic Premium (Refinery & Liquidity factor)
        val domesticPremiumJpy = when (metalType) {
            MetalType.GOLD -> BigDecimal("120.0") // ¥120 premium per gram
            MetalType.SILVER -> BigDecimal("2.5")  // ¥2.5 premium per gram
            MetalType.PLATINUM -> BigDecimal("45.0") // ¥45 premium per gram
            MetalType.PALLADIUM -> BigDecimal("60.0")
        }

        // 3. Product Fabrication/Handling Premium (e.g. bar size premium)
        val productPremiumJpy = BigDecimal("15.0")

        // 4. Spread Bid/Ask adjustments
        val spreadPercent = when (metalType) {
            MetalType.GOLD -> BigDecimal("0.003") // 0.3% spread
            MetalType.SILVER -> BigDecimal("0.015") // 1.5% spread
            MetalType.PLATINUM -> BigDecimal("0.008") // 0.8% spread
            MetalType.PALLADIUM -> BigDecimal("0.012")
        }

        val fairPricePerGram = baseJpyPerGram.add(domesticPremiumJpy).add(productPremiumJpy)
        val spreadHalf = fairPricePerGram.multiply(spreadPercent).divide(BigDecimal("2"), 4, RoundingMode.HALF_UP)

        var askPrice = fairPricePerGram.add(spreadHalf)
        var bidPrice = fairPricePerGram.subtract(spreadHalf)

        // Adjust for purity
        val purityMultiplier = BigDecimal(purity.toString())
        askPrice = askPrice.multiply(purityMultiplier)
        bidPrice = bidPrice.multiply(purityMultiplier)

        // Fees
        val commissionFeePercent = BigDecimal("0.001") // 0.1% processing fee
        val askFee = askPrice.multiply(commissionFeePercent)
        val bidFee = bidPrice.multiply(commissionFeePercent)

        // Final Quotes (Ask for customer buying, Bid for customer selling)
        val finalAskPrice = askPrice.add(askFee).multiply(BigDecimal(1.0 - clientTierDiscountPercent).setScale(4, RoundingMode.HALF_UP))
        val finalBidPrice = bidPrice.subtract(bidFee)

        val totalAmount = finalAskPrice.multiply(BigDecimal(weightGrams.toString()))

        return mapOf(
            "benchmarkSpot" to spotUsd,
            "fxRate" to fx,
            "baseJpyPerGram" to baseJpyPerGram.toDouble(),
            "domesticPremium" to domesticPremiumJpy.toDouble(),
            "productPremium" to productPremiumJpy.toDouble(),
            "purityMultiplier" to purityMultiplier.toDouble(),
            "bidPrice" to finalBidPrice.setScale(2, RoundingMode.HALF_UP).toDouble(),
            "askPrice" to finalAskPrice.setScale(2, RoundingMode.HALF_UP).toDouble(),
            "totalAmount" to totalAmount.setScale(0, RoundingMode.HALF_UP).toLong()
        )
    }

    // Dynamic market ticker generator
    fun triggerMarketTick() {
        val random = Random()
        val percentGold = (random.nextDouble() * 0.4 - 0.2) / 100.0 // +/- 0.2%
        val percentSilver = (random.nextDouble() * 1.0 - 0.5) / 100.0 // +/- 0.5%
        val percentPlatinum = (random.nextDouble() * 0.6 - 0.3) / 100.0 // +/- 0.3%
        val percentUsdJpy = (random.nextDouble() * 0.3 - 0.15) / 100.0 // +/- 0.15%

        _goldSpot.value = _goldSpot.value * (1.0 + percentGold)
        _silverSpot.value = _silverSpot.value * (1.0 + percentSilver)
        _platinumSpot.value = _platinumSpot.value * (1.0 + percentPlatinum)
        _usdJpy.value = _usdJpy.value * (1.0 + percentUsdJpy)

        // Recalculate refs
        _goldRef.value = calculatePrice(MetalType.GOLD, 1.0, 1.0)["askPrice"] as Double
        _silverRef.value = calculatePrice(MetalType.SILVER, 1.0, 1.0)["askPrice"] as Double
        _platinumRef.value = calculatePrice(MetalType.PLATINUM, 1.0, 1.0)["askPrice"] as Double
        _palladiumRef.value = calculatePrice(MetalType.PALLADIUM, 1.0, 1.0)["askPrice"] as Double

        // Ticker random session shift
        if (random.nextInt(100) < 5) {
            val sessions = listOf("前場 (東京セッション)", "後場 (東京セッション)", "夜間取引 (JPX OSE)", "取引終了 (清算処理)")
            _currentSession.value = sessions[random.nextInt(sessions.size)]
        }
    }

    // Submit a Request for Quote (RFQ)
    fun submitRfq(
        clientName: String,
        metalType: MetalType,
        productType: ProductType,
        purity: Double,
        quantityGrams: Double,
        deliveryLocation: VaultLocation,
        paymentTerms: String
    ): Rfq {
        val calc = calculatePrice(metalType, purity, quantityGrams)
        val rfq = Rfq(
            clientName = clientName,
            metalType = metalType,
            productType = productType,
            purity = purity,
            quantityGrams = quantityGrams,
            deliveryLocation = deliveryLocation,
            paymentTerms = paymentTerms,
            benchmarkSpotPriceJpy = calc["baseJpyPerGram"] as Double,
            fxRateUsdJpy = calc["fxRate"] as Double,
            computedPremiumJpy = calc["domesticPremium"] as Double,
            computedFeeJpy = (calc["askPrice"] as Double) * 0.001,
            bidPricePerGram = calc["bidPrice"] as Double,
            askPricePerGram = calc["askPrice"] as Double,
            totalAmountJpy = (calc["totalAmount"] as Long).toDouble(),
            timestamp = dateFormat.format(Date())
        )
        val updated = _rfqs.value.toMutableList()
        updated.add(0, rfq)
        _rfqs.value = updated
        return rfq
    }

    // Confirm a Trade and update Vault & Ledgers (Double-Entry Core Invariants)
    fun confirmTrade(rfqId: String, buySell: String): Trade? {
        val activeRfqs = _rfqs.value.toMutableList()
        val index = activeRfqs.indexOfFirst { it.rfqId == rfqId }
        if (index == -1) return null

        val rfq = activeRfqs[index]
        if (rfq.isAccepted || rfq.isExpired) return null

        // Mark RFQ accepted
        activeRfqs[index] = rfq.copy(isAccepted = true)
        _rfqs.value = activeRfqs

        // Allocate physical bars from Vault if SELL (we deliver metal to customer) or BUY (we receive and register metal)
        val allocatedBars = mutableListOf<PhysicalBar>()
        val barSerials = mutableListOf<String>()

        if (buySell == "SELL") { // Customer is buying from us, we allocate bars to them
            val availableBars = _physicalBars.value.filter {
                it.metalType == rfq.metalType &&
                it.purity >= rfq.purity &&
                it.status == PhysicalStatus.UNASSIGNED
            }.sortedBy { it.fineWeight }

            var remainingWeight = rfq.quantityGrams
            val updatedBars = _physicalBars.value.toMutableList()

            for (bar in availableBars) {
                if (remainingWeight <= 0) break
                val barIdx = updatedBars.indexOfFirst { it.serialNumber == bar.serialNumber }
                if (barIdx != -1) {
                    val updatedBar = updatedBars[barIdx].copy(
                        status = PhysicalStatus.ALLOCATED,
                        owner = rfq.clientName
                    )
                    updatedBars[barIdx] = updatedBar
                    allocatedBars.add(updatedBar)
                    barSerials.add(updatedBar.serialNumber)
                    remainingWeight -= updatedBar.grossWeight
                }
            }
            _physicalBars.value = updatedBars
        } else { // Customer is selling to us, we accept and register new bars into vault
            val barCount = Math.ceil(rfq.quantityGrams / 1000.0).toInt().coerceAtLeast(1)
            val updatedBars = _physicalBars.value.toMutableList()
            for (i in 1..barCount) {
                val weight = if (i == barCount) rfq.quantityGrams % 1000.0 else 1000.0
                val grossW = if (weight == 0.0) 1000.0 else weight
                val newBar = PhysicalBar(
                    serialNumber = "JP-${rfq.metalType.code}-${(9999..99999).random()}-${(100000..999999).random()}",
                    metalType = rfq.metalType,
                    purity = rfq.purity,
                    grossWeight = grossW,
                    fineWeight = grossW * rfq.purity,
                    manufacturer = "金華精錬 (KINKA REFINERY)",
                    location = rfq.deliveryLocation,
                    owner = "金華コモディティズ (KINKA Commodities)",
                    status = PhysicalStatus.UNASSIGNED,
                    certificateId = "CERT-AU-${(10000..99999).random()}",
                    productionDate = dateFormat.format(Date())
                )
                updatedBars.add(0, newBar)
                allocatedBars.add(newBar)
                barSerials.add(newBar.serialNumber)
            }
            _physicalBars.value = updatedBars
        }

        // Create OSE Warehouse Receipt Concept if client requested Vault Delivery
        if (rfq.productType == ProductType.BULLION_BAR) {
            val wrId = "WR-OSE-2026-${(10000..99999).random()}"
            val newWr = WarehouseReceipt(
                receiptId = wrId,
                warehouseName = "東京大和倉庫 (Tokyo Yamato Warehouse)",
                metalType = rfq.metalType,
                grossWeight = rfq.quantityGrams,
                fineWeight = rfq.quantityGrams * rfq.purity,
                barSerialNumbers = barSerials,
                owner = if (buySell == "SELL") rfq.clientName else "金華コモディティズ (KINKA Commodities)",
                issueDate = dateFormat.format(Date()),
                cancellationDate = null
            )
            val updatedWrs = _warehouseReceipts.value.toMutableList()
            updatedWrs.add(0, newWr)
            _warehouseReceipts.value = updatedWrs
        }

        // Create confirmed Trade object
        val trade = Trade(
            rfqId = rfq.rfqId,
            metalType = rfq.metalType,
            productType = rfq.productType,
            quantityGrams = rfq.quantityGrams,
            pricePerGram = if (buySell == "SELL") rfq.askPricePerGram else rfq.bidPricePerGram,
            premiumJpy = rfq.computedPremiumJpy,
            totalAmountJpy = rfq.totalAmountJpy,
            clientName = rfq.clientName,
            action = buySell,
            settlementDate = rfq.timestamp.take(10), // Same day settlement
            deliveryLocation = rfq.deliveryLocation,
            isSettled = true,
            isDelivered = true,
            allocatedBarSerials = barSerials,
            timestamp = dateFormat.format(Date())
        )

        val updatedTrades = _trades.value.toMutableList()
        updatedTrades.add(0, trade)
        _trades.value = updatedTrades

        // ------------------ DOUBLE-ENTRY ACCOUNTING LEDGERS ------------------
        // Invariant: TOTAL DEBITS = TOTAL CREDITS
        val updatedLedger = _financialLedger.value.toMutableList()
        val totalLongJpy = rfq.totalAmountJpy.toLong()

        if (buySell == "SELL") { // We sell to customer. We receive Money (Debit CASH/AR), We reduce metal inventory value (Credit SALES)
            updatedLedger.add(LedgerEntry(
                accountName = "現金口座 (KINKA Main Cash Account)",
                isDebit = true,
                amountJpy = totalLongJpy,
                referenceId = trade.tradeId,
                counterparty = rfq.clientName,
                description = "貴金属売却代金受入 (${rfq.metalType.displayName} ${rfq.quantityGrams}g)",
                timestamp = trade.timestamp
            ))
            updatedLedger.add(LedgerEntry(
                accountName = "売上高 (Gold/Precious Metal Sales Revenue)",
                isDebit = false,
                amountJpy = totalLongJpy,
                referenceId = trade.tradeId,
                counterparty = rfq.clientName,
                description = "貴金属売却売上勘定 (${rfq.metalType.displayName})",
                timestamp = trade.timestamp
            ))
        } else { // We buy from customer. We reduce money (Credit CASH), We increase metal inventory value (Debit PURCHASE)
            updatedLedger.add(LedgerEntry(
                accountName = "仕入高 (Precious Metal Purchase Costs)",
                isDebit = true,
                amountJpy = totalLongJpy,
                referenceId = trade.tradeId,
                counterparty = rfq.clientName,
                description = "貴金属仕入勘定 (${rfq.metalType.displayName} ${rfq.quantityGrams}g)",
                timestamp = trade.timestamp
            ))
            updatedLedger.add(LedgerEntry(
                accountName = "現金口座 (KINKA Main Cash Account)",
                isDebit = false,
                amountJpy = totalLongJpy,
                referenceId = trade.tradeId,
                counterparty = rfq.clientName,
                description = "貴金属買付代金支払",
                timestamp = trade.timestamp
            ))
        }
        _financialLedger.value = updatedLedger

        // ------------------ METAL ACCOUNTING LEDGER ------------------
        // Invariant: OPENING METAL + RECEIPTS - DELIVERIES = CLOSING METAL
        val updatedMetalLedger = _metalLedger.value.toMutableList()
        updatedMetalLedger.add(MetalLedgerEntry(
            metalType = rfq.metalType,
            grossWeightGrams = rfq.quantityGrams,
            fineWeightGrams = rfq.quantityGrams * rfq.purity,
            direction = if (buySell == "SELL") "OUT" else "IN",
            referenceId = trade.tradeId,
            location = rfq.deliveryLocation,
            owner = rfq.clientName,
            status = if (rfq.productType == ProductType.BULLION_BAR) "ALLOCATED" else "UNALLOCATED",
            timestamp = trade.timestamp
        ))
        _metalLedger.value = updatedMetalLedger

        return trade
    }

    // Submit a Recycling Buyback assessment (査定・買取明細)
    fun addRecyclingRecord(
        customerName: String,
        article: String,
        weight: Double,
        karat: String,
        purity: Double
    ): RecyclingRecord {
        val calc = calculatePrice(MetalType.GOLD, purity, weight)
        val finalPayout = (calc["totalAmount"] as Long) * 0.92 // Deduct refining fee margin
        val record = RecyclingRecord(
            customerName = customerName,
            articleDescription = article,
            grossWeight = weight,
            purityKarat = karat,
            purityDecimal = purity,
            fineWeightGrams = weight * purity,
            benchmarkReferencePriceJpy = calc["baseJpyPerGram"] as Double,
            handlingDeductionJpy = (calc["askPrice"] as Double) * 0.08,
            customerPayoutJpy = finalPayout.toDouble(),
            status = "査定完了",
            date = dateFormat.format(Date())
        )
        val updated = _recyclingRecords.value.toMutableList()
        updated.add(0, record)
        _recyclingRecords.value = updated
        return record
    }

    // Process step-by-step assay flow
    fun addAssayRecord(
        metalType: MetalType,
        grossWeight: Double,
        declaredPurity: Double,
        assayer: String
    ): AssayRecord {
        val record = AssayRecord(
            metalType = metalType,
            declaredPurity = declaredPurity,
            measuredPurity = declaredPurity + (Random().nextDouble() * 0.0002 - 0.0001), // Minor variation
            grossWeight = grossWeight,
            assayMethod = "カップレーション法 (火試金試験)",
            laboratory = "東京中央貴金属分析ラボ",
            assayerName = assayer,
            status = AssayStep.RECEIVED,
            certificateUrl = "CERT-ASY-${(1000..9999).random()}",
            date = dateFormat.format(Date())
        )
        val updated = _assayRecords.value.toMutableList()
        updated.add(0, record)
        _assayRecords.value = updated
        return record
    }

    fun advanceAssayRecord(sampleId: String): AssayRecord? {
        val updated = _assayRecords.value.toMutableList()
        val index = updated.indexOfFirst { it.sampleId == sampleId }
        if (index == -1) return null

        val record = updated[index]
        val nextStep = when (record.status) {
            AssayStep.RECEIVED -> AssayStep.SAMPLING
            AssayStep.SAMPLING -> AssayStep.TESTING
            AssayStep.TESTING -> AssayStep.VERIFIED
            AssayStep.VERIFIED -> AssayStep.CERTIFIED
            AssayStep.CERTIFIED -> {
                // Once certified, auto-register as pure physical bars in inventory
                val updatedBars = _physicalBars.value.toMutableList()
                val newBar = PhysicalBar(
                    serialNumber = "JP-${record.metalType.code}-${(9999..99999).random()}-REC",
                    metalType = record.metalType,
                    purity = record.measuredPurity,
                    grossWeight = record.grossWeight,
                    fineWeight = record.grossWeight * record.measuredPurity,
                    manufacturer = "金華精錬 (KINKA REFINERY)",
                    location = VaultLocation.TOKYO,
                    owner = "金華コモディティズ (KINKA Commodities)",
                    status = PhysicalStatus.UNASSIGNED,
                    certificateId = record.certificateUrl ?: "CERT-REC",
                    productionDate = dateFormat.format(Date())
                )
                updatedBars.add(0, newBar)
                _physicalBars.value = updatedBars
                AssayStep.INVENTORIED
            }
            AssayStep.INVENTORIED -> AssayStep.INVENTORIED
        }

        val nextRecord = record.copy(status = nextStep)
        updated[index] = nextRecord
        _assayRecords.value = updated
        return nextRecord
    }

    // Runs Scenario Stress calculations and returns details
    fun executeScenarioAnalysis(scenarioType: String): ScenarioResult {
        val goldChg: Double
        val fxChg: Double
        val alert: String

        when (scenarioType) {
            "GOLD_SPIKE" -> {
                goldChg = 0.05
                fxChg = 0.02
                alert = "WARNING"
            }
            "CRASH" -> {
                goldChg = -0.12
                fxChg = 0.05
                alert = "CRITICAL"
            }
            "JPY_APPRECIATION" -> {
                goldChg = -0.02
                fxChg = -0.04
                alert = "WARNING"
            }
            else -> {
                goldChg = 0.0
                fxChg = 0.0
                alert = "NORMAL"
            }
        }

        // Calculate total inventory value in JPY
        var totalInvVal = 0.0
        for (bar in _physicalBars.value) {
            val spot = when (bar.metalType) {
                MetalType.GOLD -> _goldSpot.value
                MetalType.SILVER -> _silverSpot.value
                MetalType.PLATINUM -> _platinumSpot.value
                MetalType.PALLADIUM -> _palladiumSpot.value
            }
            val pricePerGramJpy = (spot * _usdJpy.value) / 31.1034768
            totalInvVal += bar.fineWeight * pricePerGramJpy
        }

        // Apply price changes
        val spotFactor = 1.0 + goldChg
        val fxFactor = 1.0 + fxChg
        val newInvVal = totalInvVal * spotFactor * fxFactor
        val pnlImpact = newInvVal - totalInvVal

        // Base statistics
        val endingVal = newInvVal
        val capital = 15000000000L // ¥15,000,000,000 baseline
        val finalCapital = (capital + pnlImpact).toLong()
        val liquidityRatio = if (alert == "CRITICAL") 0.65 else 0.91
        val hedgeEffectiveness = if (goldChg == 0.0) 100.0 else 94.2

        return ScenarioResult(
            scenarioName = scenarioType,
            priceChangePercent = goldChg,
            fxChangePercent = fxChg,
            pnlImpactJpy = pnlImpact,
            endingPortfolioValueJpy = endingVal,
            remainingCapitalJpy = finalCapital.toDouble(),
            liquidityRatio = liquidityRatio,
            hedgeEffectivenessPercent = hedgeEffectiveness,
            alertLevel = alert
        )
    }

    // Helper to generate full realistic synthetic database on initial start
    private fun generatePreloadedData() {
        val random = Random()

        // 1. Preload Physical Serialized Bars inside different Vaults
        val preloadedBars = mutableListOf<PhysicalBar>()
        val locations = VaultLocation.values()

        // Add 25 highly detailed physical Gold Bars (1kg and 500g, pure gold)
        for (i in 1..15) {
            val loc = locations[i % locations.size]
            val purity = if (i % 3 == 0) 0.9999 else 0.999
            val gross = if (i % 2 == 0) 1000.0 else 500.0
            preloadedBars.add(PhysicalBar(
                serialNumber = "JP-AU-9999-0004${8200 + i}",
                metalType = MetalType.GOLD,
                purity = purity,
                grossWeight = gross,
                fineWeight = gross * purity,
                manufacturer = if (i % 2 == 0) "田中貴金属 (Tanaka Precious Metals)" else "金華精錬 (KINKA REFINERY)",
                location = loc,
                owner = if (i % 4 == 0) "東日本貴金属株式会社" else "大阪宝飾株式会社",
                status = if (i % 5 == 0) PhysicalStatus.ALLOCATED else PhysicalStatus.UNASSIGNED,
                certificateId = "CERT-AU-${20300 + i}",
                productionDate = "2026-05-${10 + i}"
            ))
        }

        // Add 10 Silver Bars (15kg and 30kg)
        for (i in 1..10) {
            val loc = locations[i % locations.size]
            val gross = if (i % 2 == 0) 30000.0 else 15000.0
            preloadedBars.add(PhysicalBar(
                serialNumber = "JP-AG-9990-0002${1400 + i}",
                metalType = MetalType.SILVER,
                purity = 0.999,
                grossWeight = gross,
                fineWeight = gross * 0.999,
                manufacturer = "三菱マテリアル (Mitsubishi Materials)",
                location = loc,
                owner = "大和貴金属商事 (Yamato Precious Metals)",
                status = PhysicalStatus.UNASSIGNED,
                certificateId = "CERT-AG-${41200 + i}",
                productionDate = "2026-06-${5 + i}"
            ))
        }

        // Add 8 Platinum Bars
        for (i in 1..8) {
            val loc = locations[i % locations.size]
            preloadedBars.add(PhysicalBar(
                serialNumber = "JP-PT-9995-0001${7500 + i}",
                metalType = MetalType.PLATINUM,
                purity = 0.9995,
                grossWeight = 1000.0,
                fineWeight = 1000.0 * 0.9995,
                manufacturer = "金華精錬 (KINKA REFINERY)",
                location = loc,
                owner = "金華コモディティズ (KINKA Commodities)",
                status = PhysicalStatus.UNASSIGNED,
                certificateId = "CERT-PT-${51300 + i}",
                productionDate = "2026-07-22"
            ))
        }

        _physicalBars.value = preloadedBars

        // 2. Preload Warehouse Receipts
        _warehouseReceipts.value = listOf(
            WarehouseReceipt(
                receiptId = "WR-OSE-2026-0048",
                warehouseName = "東京大和倉庫 (Tokyo Yamato Warehouse)",
                metalType = MetalType.GOLD,
                grossWeight = 5000.0,
                fineWeight = 4999.5,
                barSerialNumbers = listOf("JP-AU-9999-00048201", "JP-AU-9999-00048202", "JP-AU-9999-00048203"),
                owner = "東日本貴金属株式会社",
                issueDate = "2026-09-01 10:00:00",
                cancellationDate = null
            ),
            WarehouseReceipt(
                receiptId = "WR-OSE-2026-0049",
                warehouseName = "大阪阪神商品倉庫 (Osaka Hanshin Commodity Warehouse)",
                metalType = MetalType.SILVER,
                grossWeight = 30000.0,
                fineWeight = 29970.0,
                barSerialNumbers = listOf("JP-AG-9990-00021401"),
                owner = "大和貴金属商事 (Yamato Precious Metals)",
                issueDate = "2026-09-12 11:30:00",
                cancellationDate = null
            )
        )

        // 3. Preload RFQs
        _rfqs.value = listOf(
            Rfq(
                rfqId = "RFQ-JP-2026-004821",
                clientName = "東日本貴金属株式会社",
                metalType = MetalType.GOLD,
                productType = ProductType.BULLION_BAR,
                purity = 0.9999,
                quantityGrams = 500.0,
                deliveryLocation = VaultLocation.TOKYO,
                paymentTerms = "銀行振込 (T/T)",
                benchmarkSpotPriceJpy = 12645.2,
                fxRateUsdJpy = 148.50,
                computedPremiumJpy = 120.0,
                computedFeeJpy = 15.0,
                bidPricePerGram = 12750.0,
                askPricePerGram = 12780.0,
                totalAmountJpy = 6390000.0,
                isAccepted = true,
                timestamp = "2026-10-05 09:12:00"
            ),
            Rfq(
                rfqId = "RFQ-JP-2026-004822",
                clientName = "大阪宝飾株式会社",
                metalType = MetalType.PLATINUM,
                productType = ProductType.JEWELRY_ITEM,
                purity = 0.9995,
                quantityGrams = 200.0,
                deliveryLocation = VaultLocation.OSAKA,
                paymentTerms = "翌月末一括支払",
                benchmarkSpotPriceJpy = 4710.0,
                fxRateUsdJpy = 148.50,
                computedPremiumJpy = 45.0,
                computedFeeJpy = 10.0,
                bidPricePerGram = 4755.0,
                askPricePerGram = 4765.0,
                totalAmountJpy = 953000.0,
                isAccepted = false,
                timestamp = "2026-10-05 09:14:00"
            )
        )

        // 4. Preload Trades
        _trades.value = listOf(
            Trade(
                tradeId = "TRD-JP-AU48210",
                rfqId = "RFQ-JP-2026-004821",
                metalType = MetalType.GOLD,
                productType = ProductType.BULLION_BAR,
                quantityGrams = 500.0,
                pricePerGram = 12780.0,
                premiumJpy = 120.0,
                totalAmountJpy = 6390000.0,
                clientName = "東日本貴金属株式会社",
                action = "SELL",
                settlementDate = "2026-10-05",
                deliveryLocation = VaultLocation.TOKYO,
                isSettled = true,
                isDelivered = true,
                allocatedBarSerials = listOf("JP-AU-9999-00048201"),
                timestamp = "2026-10-05 09:12:30"
            )
        )

        // 5. Preload Recycling Buybacks
        _recyclingRecords.value = listOf(
            RecyclingRecord(
                recordId = "REC-JP-0041",
                customerName = "山田様 (Yamada-sama)",
                articleDescription = "Gold 18K solid bracelet",
                grossWeight = 38.40,
                purityKarat = "18K",
                purityDecimal = 0.750,
                fineWeightGrams = 28.80,
                benchmarkReferencePriceJpy = 12645.2,
                handlingDeductionJpy = 820.0,
                customerPayoutJpy = 340500.0,
                status = "買取済",
                date = "2026-10-05 08:30:00"
            )
        )

        // 6. Preload Quality Assays
        _assayRecords.value = listOf(
            AssayRecord(
                sampleId = "ASY-JP-9014",
                metalType = MetalType.GOLD,
                declaredPurity = 0.9999,
                measuredPurity = 0.9999,
                grossWeight = 1000.22,
                assayMethod = "カップレーション法 (火試金試験)",
                laboratory = "東京中央貴金属分析ラボ",
                assayerName = "佐藤 明 (Sato Akira)",
                status = AssayStep.VERIFIED,
                certificateUrl = "CERT-AU-9014",
                date = "2026-10-05 07:15:00"
            )
        )

        // 7. Preload Financial Accounting Ledgers (Perfectly balanced debits and credits!)
        _financialLedger.value = listOf(
            // Initial capital injection (¥15B)
            LedgerEntry(
                entryId = "LED-FI-INIT01",
                accountName = "現金口座 (KINKA Main Cash Account)",
                isDebit = true,
                amountJpy = 15000000000L,
                referenceId = "SYS-CAPITAL",
                counterparty = "金華金融ホールディングス",
                description = "自己資本金払込 (Initial Capitalization)",
                timestamp = "2026-01-01 09:00:00"
            ),
            LedgerEntry(
                entryId = "LED-FI-INIT02",
                accountName = "自己資本 (Shareholders Equity)",
                isDebit = false,
                amountJpy = 15000000000L,
                referenceId = "SYS-CAPITAL",
                counterparty = "金華金融ホールディングス",
                description = "自己資本金払込 (Initial Capitalization)",
                timestamp = "2026-01-01 09:00:00"
            ),
            // Preload entry for the trade of gold
            LedgerEntry(
                entryId = "LED-FI-TRD01",
                accountName = "現金口座 (KINKA Main Cash Account)",
                isDebit = true,
                amountJpy = 6390000L,
                referenceId = "TRD-JP-AU48210",
                counterparty = "東日本貴金属株式会社",
                description = "貴金属売却代金受入",
                timestamp = "2026-10-05 09:12:30"
            ),
            LedgerEntry(
                entryId = "LED-FI-TRD02",
                accountName = "売上高 (Gold/Precious Metal Sales Revenue)",
                isDebit = false,
                amountJpy = 6390000L,
                referenceId = "TRD-JP-AU48210",
                counterparty = "東日本貴金属株式会社",
                description = "貴金属売却売上勘定",
                timestamp = "2026-10-05 09:12:30"
            )
        )

        // 8. Preload Metal Balances Ledger (Weight IN/OUT)
        _metalLedger.value = listOf(
            MetalLedgerEntry(
                metalType = MetalType.GOLD,
                grossWeightGrams = 500.0,
                fineWeightGrams = 499.95,
                direction = "OUT",
                referenceId = "TRD-JP-AU48210",
                location = VaultLocation.TOKYO,
                owner = "東日本貴金属株式会社",
                status = "ALLOCATED",
                timestamp = "2026-10-05 09:12:30"
            )
        )
    }
}
