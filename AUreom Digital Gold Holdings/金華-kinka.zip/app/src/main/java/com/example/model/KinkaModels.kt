package com.example.model

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

// Supported Metals
enum class MetalType(val displayName: String, val code: String) {
    GOLD("金", "AU"),
    SILVER("銀", "AG"),
    PLATINUM("プラチナ", "PT"),
    PALLADIUM("パラジウム", "PD")
}

// Product categories for the catalog
enum class ProductType(val displayName: String) {
    BULLION_BAR("地金バー"),
    COIN("地金コイン"),
    RECYCLED_SCRAP("回収スクラップ"),
    JEWELRY_ITEM("宝飾品"),
    INDUSTRIAL_METAL("工業用メタル"),
    EXCHANGE_CONTRACT("取引所先物契約")
}

// Vault locations (Cities)
enum class VaultLocation(val kanjiName: String, val englishName: String) {
    TOKYO("東京保管庫", "Tokyo Vault"),
    OSAKA("大阪保管庫", "Osaka Vault"),
    NAGOYA("名古屋保管庫", "Nagoya Vault"),
    YOKOHAMA("横浜保管庫", "Yokohama Vault"),
    KOBE("神戸保管庫", "Kobe Vault"),
    FUKUOKA("福岡保管庫", "Fukuoka Vault"),
    SAPPORO("札幌保管庫", "Sapporo Vault")
}

// Physical status of precious metals
enum class PhysicalStatus(val displayName: String) {
    UNASSIGNED("未割当"),
    ALLOCATED("割当済"),
    AWAITING_DELIVERY("出庫待ち"),
    IN_TRANSIT("輸送中"),
    ARRIVED("到着"),
    ASSAYED("検品済"),
    DELIVERED("受渡完了")
}

// Data class representing a serialized bullion bar
data class PhysicalBar(
    val serialNumber: String,
    val metalType: MetalType,
    val purity: Double,        // e.g. 0.9999
    val grossWeight: Double,   // in grams
    val fineWeight: Double,    // fine weight = grossWeight * purity
    val manufacturer: String,  // e.g. "田中貴金属", "金華精錬"
    val location: VaultLocation,
    val owner: String,         // e.g. "東日本貴金属株式会社"
    val status: PhysicalStatus,
    val certificateId: String,
    val productionDate: String
)

// Warehouse Receipts (倉荷証券)
data class WarehouseReceipt(
    val receiptId: String,
    val warehouseName: String,
    val metalType: MetalType,
    val grossWeight: Double,
    val fineWeight: Double,
    val barSerialNumbers: List<String>,
    val owner: String,
    val issueDate: String,
    val cancellationDate: String?,
    val isCancelled: Boolean = false
)

// Quote Request (RFQ - 見積依頼)
data class Rfq(
    val rfqId: String = "RFQ-JP-2026-${(100000..999999).random()}",
    val clientName: String,
    val metalType: MetalType,
    val productType: ProductType,
    val purity: Double,
    val quantityGrams: Double,
    val deliveryLocation: VaultLocation,
    val paymentTerms: String, // e.g. "銀行振込 (T/T)"
    val expirationSeconds: Int = 30,
    val benchmarkSpotPriceJpy: Double, // Benchmark price per gram
    val fxRateUsdJpy: Double,
    val computedPremiumJpy: Double,   // Premium per gram
    val computedFeeJpy: Double,       // Processing fee per gram
    val bidPricePerGram: Double,      // Calculated bid price
    val askPricePerGram: Double,      // Calculated ask price
    val totalAmountJpy: Double,
    val isAccepted: Boolean = false,
    val isExpired: Boolean = false,
    val timestamp: String
)

// Confirmed Precious Metal Trade
data class Trade(
    val tradeId: String = "TRD-JP-${UUID.randomUUID().toString().take(8).uppercase()}",
    val rfqId: String?,
    val metalType: MetalType,
    val productType: ProductType,
    val quantityGrams: Double,
    val pricePerGram: Double,
    val premiumJpy: Double,
    val totalAmountJpy: Double,
    val clientName: String,
    val action: String, // "BUY" (買付) or "SELL" (売却)
    val settlementDate: String,
    val deliveryLocation: VaultLocation,
    val isSettled: Boolean = false,
    val isDelivered: Boolean = false,
    val allocatedBarSerials: List<String> = emptyList(),
    val timestamp: String
)

// Recycling buyback tickets (貴金属買取査定)
data class RecyclingRecord(
    val recordId: String = "REC-JP-${(1000..9999).random()}",
    val customerName: String,
    val articleDescription: String, // e.g. "Gold Bracelet"
    val grossWeight: Double,
    val purityKarat: String,        // e.g. "18K", "24K", "PT950", "916"
    val purityDecimal: Double,      // e.g. 0.750, 0.999
    val fineWeightGrams: Double,
    val benchmarkReferencePriceJpy: Double,
    val handlingDeductionJpy: Double, // Deduction fee per gram
    val customerPayoutJpy: Double,
    val status: String,             // "査定完了", "買取済", "精錬中"
    val date: String
)

// Assay Quality/Verification State Machine (品位検査)
enum class AssayStep(val displayName: String) {
    RECEIVED("受入"),
    SAMPLING("サンプリング"),
    TESTING("品位検査中"),
    VERIFIED("検査確認済"),
    CERTIFIED("品位認証完了"),
    INVENTORIED("在庫登録済")
}

data class AssayRecord(
    val sampleId: String = "ASY-JP-${(100000..999999).random()}",
    val metalType: MetalType,
    val declaredPurity: Double,
    val measuredPurity: Double,
    val grossWeight: Double,
    val assayMethod: String,        // e.g. "XRF (蛍光X線分析)", "カップレーション法 (火試金)"
    val laboratory: String,         // e.g. "東京プレシャス分析所"
    val assayerName: String,
    val status: AssayStep,
    val certificateUrl: String?,
    val date: String
)

// Double-Entry Financial Accounting Ledger Entry (純分円建て)
data class LedgerEntry(
    val entryId: String = "LED-FI-${UUID.randomUUID().toString().take(12).uppercase()}",
    val accountName: String,        // e.g. "現金", "売掛金", "金地金売上", "ヘッジ損益"
    val isDebit: Boolean,           // Debit (借方) vs Credit (貸方)
    val amountJpy: Long,            // Explicit long integer to ensure absolute precision
    val referenceId: String,        // Trade ID or Payment ID
    val counterparty: String,
    val description: String,
    val timestamp: String
)

// Metal Weight Balance Ledger Entry (純分重量グラム建て)
data class MetalLedgerEntry(
    val entryId: String = "LED-MT-${UUID.randomUUID().toString().take(12).uppercase()}",
    val metalType: MetalType,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val direction: String,          // "IN" (入庫) or "OUT" (出庫)
    val referenceId: String,        // Trade ID, Recycled Record, or Delivery ID
    val location: VaultLocation,
    val owner: String,
    val status: String,             // "ALLOCATED", "UNALLOCATED"
    val timestamp: String
)

// Scenario stress analysis state
data class ScenarioResult(
    val scenarioName: String,
    val priceChangePercent: Double,
    val fxChangePercent: Double,
    val pnlImpactJpy: Double,
    val endingPortfolioValueJpy: Double,
    val remainingCapitalJpy: Double,
    val liquidityRatio: Double,
    val hedgeEffectivenessPercent: Double,
    val alertLevel: String          // "NORMAL", "WARNING", "CRITICAL"
)
