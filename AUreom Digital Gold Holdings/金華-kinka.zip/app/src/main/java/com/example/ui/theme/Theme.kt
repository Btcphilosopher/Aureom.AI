package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val KinkaColorScheme = darkColorScheme(
    primary = MutedGold,
    onPrimary = MatteBlack,
    secondary = OffWhite,
    onSecondary = Charcoal,
    tertiary = BrushedMetal,
    background = MatteBlack,
    onBackground = WarmWhite,
    surface = Charcoal,
    onSurface = WarmWhite,
    surfaceVariant = SoftCharcoal,
    onSurfaceVariant = OffWhite,
    outline = BorderColor,
    error = Vermilion,
    onError = WarmWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KinkaColorScheme,
        typography = Typography,
        content = content
    )
}
