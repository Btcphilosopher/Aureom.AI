package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.service.KinkaAiService
import com.example.service.KinkaSimulationService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class KinkaScreen {
    MARKET_OVERVIEW,
    GOLD_TERMINAL,
    SILVER_TERMINAL,
    PLATINUM_TERMINAL,
    DEALER_DESK,
    INVENTORY_VAULT,
    ASSAY_RECYCLING,
    LEDGERS_AUDIT,
    STRESS_LAB,
    AI_ASSISTANT
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: String
)

data class RecyclingTwinState(
    val isRunning: Boolean = false,
    val progress: Float = 0.0f,
    val currentStage: String = "未開始",
    val recoveredGoldGrams: Double = 0.0,
    val recoveredSilverGrams: Double = 0.0,
    val recoveredPlatinumGrams: Double = 0.0,
    val recoveryValueJpy: Double = 0.0
)

class KinkaViewModel : ViewModel() {

    // Custom Screen/Navigation Stack
    private val _currentScreen = MutableStateFlow(KinkaScreen.MARKET_OVERVIEW)
    val currentScreen: StateFlow<KinkaScreen> = _currentScreen.asStateFlow()

    private val screenHistory = mutableListOf<KinkaScreen>()

    // Expose Simulation service states
    val goldRef = KinkaSimulationService.goldRef
    val silverRef = KinkaSimulationService.silverRef
    val platinumRef = KinkaSimulationService.platinumRef
    val palladiumRef = KinkaSimulationService.palladiumRef
    val usdJpy = KinkaSimulationService.usdJpy
    val physicalBars = KinkaSimulationService.physicalBars
    val warehouseReceipts = KinkaSimulationService.warehouseReceipts
    val rfqs = KinkaSimulationService.rfqs
    val trades = KinkaSimulationService.trades
    val recyclingRecords = KinkaSimulationService.recyclingRecords
    val assayRecords = KinkaSimulationService.assayRecords
    val financialLedger = KinkaSimulationService.financialLedger
    val metalLedger = KinkaSimulationService.metalLedger
    val currentSession = KinkaSimulationService.currentSession

    // Active RFQ in the dealer terminal
    private val _activeRfq = MutableStateFlow<Rfq?>(null)
    val activeRfq: StateFlow<Rfq?> = _activeRfq.asStateFlow()

    private val _activeRfqTimeRemaining = MutableStateFlow(30)
    val activeRfqTimeRemaining: StateFlow<Int> = _activeRfqTimeRemaining.asStateFlow()

    private var rfqTimerJob: Job? = null

    // Recycling Quick Assessment input state
    private val _activeRecyclingQuote = MutableStateFlow<RecyclingRecord?>(null)
    val activeRecyclingQuote: StateFlow<RecyclingRecord?> = _activeRecyclingQuote.asStateFlow()

    // Recycling Twin (Material-Flow Simulator) State
    private val _twinState = MutableStateFlow(RecyclingTwinState())
    val twinState: StateFlow<RecyclingTwinState> = _twinState.asStateFlow()

    // Stress testing active state
    private val _activeScenarioResult = MutableStateFlow<ScenarioResult?>(null)
    val activeScenarioResult: StateFlow<ScenarioResult?> = _activeScenarioResult.asStateFlow()

    // Chat Log state for Kinka AI
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private var marketTickerJob: Job? = null

    init {
        // Start simulated live market updates (ticks)
        startMarketTicker()

        // Welcome chat message
        _chatMessages.value = listOf(
            ChatMessage(
                text = "金華 KINKA AIアシスタントへようこそ。金華プラットフォーム内のリアルタイム在庫量、お客様のポジション、損益、リスク限界値など何でもお尋ねください。丁寧にお答えいたします。",
                isUser = false,
                timestamp = "09:00:00"
            )
        )
    }

    private fun startMarketTicker() {
        marketTickerJob = viewModelScope.launch {
            while (true) {
                delay(3000) // Ticks every 3 seconds to feel very alive!
                KinkaSimulationService.triggerMarketTick()
            }
        }
    }

    // Custom Type-Safe Navigation methods with Back Stack
    fun navigateTo(screen: KinkaScreen) {
        if (_currentScreen.value != screen) {
            screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenHistory.isNotEmpty()) {
            _currentScreen.value = screenHistory.removeAt(screenHistory.size - 1)
            true
        } else {
            false
        }
    }

    // Dealer Desk Actions
    fun submitRfq(
        clientName: String,
        metalType: MetalType,
        productType: ProductType,
        purity: Double,
        quantityGrams: Double,
        deliveryLocation: VaultLocation,
        paymentTerms: String
    ) {
        rfqTimerJob?.cancel()
        val rfq = KinkaSimulationService.submitRfq(
            clientName, metalType, productType, purity, quantityGrams, deliveryLocation, paymentTerms
        )
        _activeRfq.value = rfq
        _activeRfqTimeRemaining.value = 30

        // Countdown timer for Quote validity
        rfqTimerJob = viewModelScope.launch {
            while (_activeRfqTimeRemaining.value > 0) {
                delay(1000)
                _activeRfqTimeRemaining.value -= 1
            }
            // Mark RFQ expired
            _activeRfq.value = _activeRfq.value?.copy(isExpired = true)
        }
    }

    fun confirmActiveTrade(buySell: String) {
        val rfq = _activeRfq.value ?: return
        if (rfq.isAccepted || rfq.isExpired) return

        rfqTimerJob?.cancel()
        val trade = KinkaSimulationService.confirmTrade(rfq.rfqId, buySell)
        if (trade != null) {
            _activeRfq.value = _activeRfq.value?.copy(isAccepted = true)
        }
    }

    // Recycling Quick Payout Assessment
    fun assessRecycle(
        customerName: String,
        article: String,
        weight: Double,
        karat: String,
        purity: Double
    ) {
        val record = KinkaSimulationService.addRecyclingRecord(customerName, article, weight, karat, purity)
        _activeRecyclingQuote.value = record
    }

    // Digital Recycling Twin Material-Flow animation
    fun startRecyclingTwinSimulation(inputWeightGrams: Double) {
        if (_twinState.value.isRunning) return

        viewModelScope.launch {
            _twinState.value = RecyclingTwinState(isRunning = true, currentStage = "収集・分別中...", progress = 0.1f)
            delay(1500)

            _twinState.value = _twinState.value.copy(currentStage = "成分・品位検査 (XRF)", progress = 0.35f)
            delay(1500)

            _twinState.value = _twinState.value.copy(currentStage = "精製溶解・電解プロセス...", progress = 0.65f)
            delay(1800)

            // Simulate high quality yields
            // Mixed jewelry yields: Gold 70%, Silver 20%, Platinum 8%, and 2% refining loss
            val goldYield = inputWeightGrams * 0.70
            val silverYield = inputWeightGrams * 0.20
            val platinumYield = inputWeightGrams * 0.08

            val goldValue = goldYield * KinkaSimulationService.goldRef.value
            val silverValue = silverYield * KinkaSimulationService.silverRef.value
            val platinumValue = platinumYield * KinkaSimulationService.platinumRef.value
            val totalValue = goldValue + silverValue + platinumValue

            _twinState.value = _twinState.value.copy(
                currentStage = "純分回収・インゴット鋳造完了",
                progress = 1.0f,
                recoveredGoldGrams = goldYield,
                recoveredSilverGrams = silverYield,
                recoveredPlatinumGrams = platinumYield,
                recoveryValueJpy = totalValue
            )

            // Register recovered metal as a new physical bar inside Tokyo Vault automatically
            KinkaSimulationService.addAssayRecord(
                MetalType.GOLD,
                goldYield,
                0.9999,
                "リサイクル回収ロボット (Digital Twin)"
            )

            delay(1500)
            _twinState.value = _twinState.value.copy(isRunning = false)
        }
    }

    // Advanced Assay process step
    fun processAssay(sampleId: String) {
        KinkaSimulationService.advanceAssayRecord(sampleId)
    }

    // Create a manual Assay
    fun submitAssay(metalType: MetalType, weight: Double, purity: Double, assayer: String) {
        KinkaSimulationService.addAssayRecord(metalType, weight, purity, assayer)
    }

    // Scenario Stress lab trigger
    fun selectScenario(scenarioType: String) {
        val result = KinkaSimulationService.executeScenarioAnalysis(scenarioType)
        _activeScenarioResult.value = result
    }

    // Send chat question to Kinka AI
    fun sendAiMessage(messageText: String) {
        if (messageText.isBlank()) return

        val sdf = SimpleDateFormat("HH:mm:ss", Locale.JAPAN)
        val timestamp = sdf.format(Date())

        // Append user chat
        val currentMessages = _chatMessages.value.toMutableList()
        currentMessages.add(ChatMessage(text = messageText, isUser = true, timestamp = timestamp))
        _chatMessages.value = currentMessages

        _isAiLoading.value = true

        viewModelScope.launch {
            val reply = KinkaAiService.queryKinkaAi(messageText)
            val aiTimestamp = sdf.format(Date())

            val updatedMessages = _chatMessages.value.toMutableList()
            updatedMessages.add(ChatMessage(text = reply, isUser = false, timestamp = aiTimestamp))
            _chatMessages.value = updatedMessages

            _isAiLoading.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        marketTickerJob?.cancel()
        rfqTimerJob?.cancel()
    }
}
