package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KINKA Premium Japanese Financial Color Palette
val MatteBlack = Color(0xFF0C0C0C)
val Charcoal = Color(0xFF161616)
val SoftCharcoal = Color(0xFF222222)
val BrushedMetal = Color(0xFF8A8F93)

val WarmWhite = Color(0xFFFAF6EE)
val OffWhite = Color(0xFFE6E1D8)
val MutedGold = Color(0xFFC5A02B)
val BrightGold = Color(0xFFD4AF37)

val Vermilion = Color(0xFFC04028) //朱色 (Down status, stress, alerts)
val Indigo = Color(0xFF1E2F40)    //藍色 (Secondary elements, stable)
val ForestGreen = Color(0xFF285038) //常盤色 (Up status, profits, verified)
val SubtleBronze = Color(0xFF8C6239)

val BorderColor = Color(0xFF2C2A24) // Soft dark-gold border
val GridLineColor = Color(0xFF1A1A1A)
