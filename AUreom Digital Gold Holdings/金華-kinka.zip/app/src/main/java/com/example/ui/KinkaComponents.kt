package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// Style variables
val MonoFont = FontFamily.Monospace

// Custom elegant vermilion seal
@Composable
fun JapaneseSeal(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(36.dp)
            .border(2.dp, Vermilion, RoundedCornerShape(2.dp))
            .background(Vermilion.copy(alpha = 0.05f))
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "金",
                color = Vermilion,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 11.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "華",
                color = Vermilion,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// Sparkline graph painted with high precision on Canvas
@Composable
fun Sparkline(
    data: List<Double>,
    modifier: Modifier = Modifier,
    lineColor: Color = ForestGreen,
    fillColor: Color = ForestGreen.copy(alpha = 0.05f)
) {
    if (data.size < 2) return

    Canvas(modifier = modifier) {
        val minVal = data.minOrNull() ?: 0.0
        val maxVal = data.maxOrNull() ?: 1.0
        val range = (maxVal - minVal).coerceAtLeast(0.0001)

        val width = size.width
        val height = size.height

        val points = data.mapIndexed { index, value ->
            val x = (index.toFloat() / (data.size - 1)) * width
            val y = height - (((value - minVal) / range).toFloat() * height)
            Offset(x, y)
        }

        val strokePath = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 1 until points.size) {
                lineTo(points[i].x, points[i].y)
            }
        }

        // Fill under path
        val fillPath = Path().apply {
            addPath(strokePath)
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(fillColor, Color.Transparent)
            )
        )

        drawPath(
            path = strokePath,
            color = lineColor,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

// High prestige card container
@Composable
fun KinkaCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    subTag: String? = null,
    borderCol: Color = BorderColor,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .border(1.dp, borderCol, RoundedCornerShape(4.dp))
            .background(Charcoal)
            .padding(14.dp)
    ) {
        if (title != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = WarmWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif
                )
                if (subTag != null) {
                    Text(
                        text = subTag,
                        color = MutedGold,
                        fontSize = 11.sp,
                        fontFamily = MonoFont,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(GridLineColor)
                    .padding(bottom = 10.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
        content()
    }
}

// Live Session indicator
@Composable
fun SessionIndicator(currentSession: String, usdJpy: Double) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteSpec(),
        label = "pulseAlpha"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .background(SoftCharcoal, RoundedCornerShape(2.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = Icons.Default.FiberManualRecord,
            contentDescription = "Active Ticker",
            tint = ForestGreen.copy(alpha = alpha),
            modifier = Modifier.size(10.dp)
        )
        Text(
            text = "セッション: $currentSession",
            color = OffWhite,
            fontSize = 11.sp,
            fontFamily = FontFamily.SansSerif
        )
        Text(
            text = "|",
            color = BorderColor,
            fontSize = 11.sp
        )
        Text(
            text = "USD/JPY: ¥${String.format("%.2f", usdJpy)}",
            color = MutedGold,
            fontSize = 11.sp,
            fontFamily = MonoFont
        )
    }
}

private fun infiniteSpec() = infiniteRepeatable<Float>(
    animation = tween(1200, easing = LinearEasing),
    repeatMode = RepeatMode.Reverse
)
