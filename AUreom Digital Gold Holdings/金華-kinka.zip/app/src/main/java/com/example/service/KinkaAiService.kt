package com.example.service

import com.example.BuildConfig
import com.example.model.MetalType
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Moshi Data Models for Gemini ---
@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate> = emptyList()
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content
)

// Retrofit API Service for direct REST calls to Gemini
interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object KinkaAiService {

    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    // Handles user prompt with rule-based premium fallback and real state injection
    suspend fun queryKinkaAi(prompt: String): String {
        val cleanPrompt = prompt.trim()

        // 1. Fetch current live states from the Simulation repository
        val bars = KinkaSimulationService.physicalBars.value
        val trades = KinkaSimulationService.trades.value
        val ledger = KinkaSimulationService.financialLedger.value

        val totalGoldKg = bars.filter { it.metalType == MetalType.GOLD }.sumOf { it.fineWeight } / 1000.0
        val totalSilverKg = bars.filter { it.metalType == MetalType.SILVER }.sumOf { it.fineWeight } / 1000.0
        val totalPlatinumKg = bars.filter { it.metalType == MetalType.PLATINUM }.sumOf { it.fineWeight } / 1000.0

        val tokyoGoldKg = bars.filter { it.metalType == MetalType.GOLD && it.location == com.example.model.VaultLocation.TOKYO }.sumOf { it.fineWeight } / 1000.0

        // Find client with largest position
        val positionMap = bars.filter { it.owner != "金華コモディティズ (KINKA Commodities)" }.groupBy { it.owner }
        val maxOwner = positionMap.maxByOrNull { entry -> entry.value.sumOf { it.fineWeight } }?.key ?: "該当なし"

        // Today's total JPY turnover
        val todayPnl = ledger.filter { it.accountName.contains("売上") || it.accountName.contains("利益") }.sumOf { it.amountJpy }

        // --- RULE-BASED JAPANESE FINANCIAL EXPERT RESPONSE SYSTEM (Bulletproof offline fallbacks) ---
        if (cleanPrompt.contains("現在の金在庫") || cleanPrompt.contains("金在庫はいくら") || cleanPrompt.contains("金は全部で何キロ")) {
            return """
                【金華 AI アシスタント - 倉庫管理デスク】
                お問合せありがとうございます。現在、金華のグローバル保管金庫システムに登録されている【純金地金】の合計在庫量は以下の通りでございます：
                
                ■ 総保有重量（純分）： ${String.format("%.2f", totalGoldKg)} kg
                ■ 時価評価額： 約 ¥${String.format("%,d", (totalGoldKg * 1000.0 * KinkaSimulationService.goldRef.value).toLong())} 円
                
                詳細な割り当て、または各都市保管庫の状況は「保管管理」画面よりご確認いただけます。
            """.trimIndent()
        }

        if (cleanPrompt.contains("東京保管庫") && cleanPrompt.contains("金")) {
            return """
                【金華 AI アシスタント - 保管分析】
                東京保管庫（Tokyo Vault）に配備されている【純金】の状況についてご報告いたします：
                
                ■ 東京保管庫 純金総重量（純分）： ${String.format("%.2f", tokyoGoldKg)} kg
                ■ 状態： すべてセキュリティ認証を完了したJIS/JMA適格ロッド（田中貴金属・金華精錬製造）で構成されています。
            """.trimIndent()
        }

        if (cleanPrompt.contains("最大の金ポジション") || cleanPrompt.contains("最大のポジション") || cleanPrompt.contains("大口の顧客")) {
            return """
                【金華 AI アシスタント - リスク・顧客管理】
                金地金（ゴールド）のポートフォリオポジション最大保有顧客を特定いたしました：
                
                ■ 筆頭保有社： 『$maxOwner』様
                ■ ポジション合計： ${String.format("%.2f", positionMap[maxOwner]?.sumOf { it.fineWeight }?.div(1000.0) ?: 0.0)} kg
                
                信用枠（Credit Limit）およびリスク管理データに基づき、現在のポジションは正常な担保比率内に収まっております。
            """.trimIndent()
        }

        if (cleanPrompt.contains("今日の損益") || cleanPrompt.contains("本日の損益") || cleanPrompt.contains("今日の利益")) {
            return """
                【金華 AI アシスタント - 財務経理デスク】
                本日（2026年10月5日）の取引損益・収益状況をダブルエントリー元帳システムよりリアルタイム抽出いたしました：
                
                ■ 本日の確定損益・売上高： ¥${String.format("%,d", todayPnl)} 円
                ■ 勘定科目： 貴金属売却売上およびスプレッド・プレミアム手数料の合算値です。
                
                より詳細な仕訳明細は「損益（P&L）」および「ダブルエントリー元帳」画面をご参照ください。
            """.trimIndent()
        }

        if (cleanPrompt.contains("銀の在庫") || cleanPrompt.contains("銀の評価額")) {
            return """
                【金華 AI アシスタント - 銀在庫評価】
                現在、各金庫に保管されている【純銀地金（Silver 999.9/999）】の評価概況でございます：
                
                ■ 総保有重量（純分）： ${String.format("%.2f", totalSilverKg)} kg
                ■ 現在時価： ¥${String.format("%.2f", KinkaSimulationService.silverRef.value)} / g
                ■ 総評価額： 約 ¥${String.format("%,d", (totalSilverKg * 1000.0 * KinkaSimulationService.silverRef.value).toLong())} 円
            """.trimIndent()
        }

        if (cleanPrompt.contains("金価格を分析") || cleanPrompt.contains("過去30日間の金価格")) {
            return """
                【金華 AI アシスタント - 市場分析レポート】
                直近の貴金属市況ならびに金の相場展開を解説いたします：
                
                現在、金価格は【1gあたり ¥${String.format("%,.0f", KinkaSimulationService.goldRef.value)}】を軸に高位保ち合いとなっております。米国金利の動向や為替（USD/JPY = ${String.format("%.2f", KinkaSimulationService.usdJpy.value)}円）のボラティリティ上昇を受け、東京・大坂市場では現物需要が極めて旺盛です。
                
                テクニカル的には、堅調なインフレ懸念を背景に、長期的には強気トレンド（Bull market）を維持しております。
            """.trimIndent()
        }

        if (cleanPrompt.contains("信用限度額を超えそう") || cleanPrompt.contains("リスク限度額") || cleanPrompt.contains("限度額")) {
            return """
                【金華 AI アシスタント - リスク統括部】
                リスク管理リミット状況をお知らせいたします：
                
                現在、顧客である「東日本貴金属株式会社」様がゴールド集中取引の上限に近づいており、利用率は【93.6%】に達しております（注意警告レベル）。
                リスクデスクにて、ヘッジ比率の引き上げまたはマージン追加要請の準備を開始することを推奨いたします。
            """.trimIndent()
        }

        // --- GEMINI DIRECT REST CALL ---
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        if (apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val systemInstruction = "あなたは高級日本貴金属商社『金華 KINKA』の金融AIアシスタントです。日本の金融用語（相場、品位、受渡、元帳等）を使い、丁寧、簡潔かつ品格のある日本語で答えてください。"
                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = "【システム状態インジェクション】現在の金在庫: ${totalGoldKg}kg, 銀在庫: ${totalSilverKg}kg, プラチナ: ${totalPlatinumKg}kg, JPY/USD: ${KinkaSimulationService.usdJpy.value}. 質問: $cleanPrompt")))
                    ),
                    systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
                )
                val response = apiService.generateContent(apiKey, request)
                val reply = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (reply != null) {
                    return "【金華 AI - Gemini 3.5 リアルタイム生成】\n$reply"
                }
            } catch (e: Exception) {
                return "【金華 AI - 通信エラー】\nGemini APIとの通信中にエラーが発生しました（${e.message}）。恐れ入りますが、ローカルのインテリジェンスエンジンで回答いたします：\n\n現在、金華の保管金庫に収納されている総地金量は金 ${String.format("%.2f", totalGoldKg)} kg、プラチナ ${String.format("%.2f", totalPlatinumKg)} kg でございます。"
            }
        }

        // Generic beautiful Japanese precious metal merchant fallback response
        return """
            【金華 AI アシスタント - インテリジェント窓口】
            「$cleanPrompt」について承りました。金華プラットフォームでは、市場概況、見積依頼（RFQ）、保管庫（Vault）の地金割当、およびダブルエントリー勘定元帳の自動監査情報を瞬時に検索可能です。
            
            ※Gemini APIキー（Secretsパネル）が構成されていないため、ローカルのエキスパートシステムにより応答しています。
            【現在市況データ】
            ■ 金価格: ¥${String.format("%,.2f", KinkaSimulationService.goldRef.value)} / g
            ■ プラチナ価格: ¥${String.format("%,.2f", KinkaSimulationService.platinumRef.value)} / g
            ■ ドル円: ¥${String.format("%.2f", KinkaSimulationService.usdJpy.value)}
        """.trimIndent()
    }
}
