package com.example.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.TimelineEvent
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    private val moshi = Moshi.Builder().build()
    private val timelineListType = Types.newParameterizedType(List::class.java, TimelineEvent::class.java)
    private val adapter = moshi.adapter<List<TimelineEvent>>(timelineListType)

    @TypeConverter
    fun fromTimelineList(value: List<TimelineEvent>?): String {
        return value?.let { adapter.toJson(it) } ?: "[]"
    }

    @TypeConverter
    fun toTimelineList(value: String?): List<TimelineEvent> {
        if (value.isNullOrEmpty()) return emptyList()
        return try {
            adapter.fromJson(value) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}

@Database(
    entities = [
        BarEntity::class,
        VaultEntity::class,
        OrderEntity::class,
        TransactionEntity::class,
        ReconciliationEntity::class,
        ComplianceCaseEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun preciousMetalDao(): PreciousMetalDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aurum_france_database"
                )
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Seed data in background thread
                CoroutineScope(Dispatchers.IO).launch {
                    val database = INSTANCE ?: return@launch
                    val dao = database.preciousMetalDao()

                    // 1. Seed Vaults (Digital Twin Network)
                    val initialVaults = listOf(
                        VaultEntity(
                            id = "FR-PARIS-01",
                            name = "Paris Vault 01 (Fort d'Ivry)",
                            jurisdictionCode = "FR",
                            city = "Paris",
                            capacityKg = 10000.00,
                            occupiedKg = 7821.70,
                            secureZone = "Zone Haute-Sécurité Alpha",
                            room = "Salle des Coffres Royale",
                            compartmentCount = 150,
                            allocatedMetalKg = 5200.0,
                            unallocatedMetalKg = 2621.70,
                            pendingMovementsCount = 2,
                            insuranceCompany = "AXA Art & Precious Metals",
                            lastInspectionDate = System.currentTimeMillis() - 86400000 * 2 // 2 days ago
                        ),
                        VaultEntity(
                            id = "CH-GENEVE-01",
                            name = "Geneva SafeDepot (Freeport)",
                            jurisdictionCode = "CH",
                            city = "Genève",
                            capacityKg = 15000.00,
                            occupiedKg = 11200.50,
                            secureZone = "Zone d'Or Fortifié",
                            room = "Salle Cervin (Sous Douane)",
                            compartmentCount = 200,
                            allocatedMetalKg = 8000.0,
                            unallocatedMetalKg = 3200.50,
                            pendingMovementsCount = 0,
                            insuranceCompany = "Lloyd's of London (Bullion Policy)",
                            lastInspectionDate = System.currentTimeMillis() - 86400000 * 5 // 5 days ago
                        ),
                        VaultEntity(
                            id = "BE-BRU-01",
                            name = "Bruxelles Garde Nationale",
                            jurisdictionCode = "BE",
                            city = "Bruxelles",
                            capacityKg = 8000.00,
                            occupiedKg = 3200.20,
                            secureZone = "Zone Léopold Royale",
                            room = "Salle de l'Europe",
                            compartmentCount = 100,
                            allocatedMetalKg = 2000.0,
                            unallocatedMetalKg = 1200.20,
                            pendingMovementsCount = 1,
                            insuranceCompany = "Allianz Global Corporate & Specialty",
                            lastInspectionDate = System.currentTimeMillis() - 86400000 * 1 // 1 day ago
                        ),
                        VaultEntity(
                            id = "CA-MON-01",
                            name = "Montréal Forté (Viger)",
                            jurisdictionCode = "CA",
                            city = "Montréal",
                            capacityKg = 12000.00,
                            occupiedKg = 6800.80,
                            secureZone = "Zone Laurentides",
                            room = "Salle du Saint-Laurent",
                            compartmentCount = 120,
                            allocatedMetalKg = 4500.0,
                            unallocatedMetalKg = 2300.80,
                            pendingMovementsCount = 3,
                            insuranceCompany = "Chubb Canada Bullion Insurance",
                            lastInspectionDate = System.currentTimeMillis() - 86400000 * 3
                        ),
                        VaultEntity(
                            id = "AFR-ABID-01",
                            name = "Abidjan Coffres d'Or",
                            jurisdictionCode = "AFR",
                            city = "Abidjan",
                            capacityKg = 5000.00,
                            occupiedKg = 1200.00,
                            secureZone = "Zone Ebrié Sécurisée",
                            room = "Salle de la Lagune",
                            compartmentCount = 50,
                            allocatedMetalKg = 800.0,
                            unallocatedMetalKg = 400.00,
                            pendingMovementsCount = 0,
                            insuranceCompany = "Saham Assurance",
                            lastInspectionDate = System.currentTimeMillis() - 86400000 * 12
                        )
                    )
                    dao.insertVaults(initialVaults)

                    // 2. Seed Gold and Silver bars owned by the Famille Delorme (CLIENT-DELORME)
                    // We seed exactly 1,600.40 oz of allocated gold across multiple bars
                    // And 31.2 kg of allocated silver across multiple bars.
                    
                    val pampTimeline = """[
                      {"timestamp": 1774353600000, "eventType": "PRODUCTION", "location": "Castel San Pietro, Suisse", "actor": "Pamp SA Refining", "previousState": "N/A", "newState": "MÉTAL_FIN", "documentRef": "CERT-PAMP-9999", "authorizationSign": "SIG-PAMP-CH"},
                      {"timestamp": 1774440000000, "eventType": "ASSAYAGE", "location": "Castel San Pietro, Suisse", "actor": "Assay Office", "previousState": "MÉTAL_FIN", "newState": "ESSAYÉ_ET_SCELLÉ", "documentRef": "ASSAY-PAMP-9999", "authorizationSign": "SIG-ASSAY-CH"},
                      {"timestamp": 1774526400000, "eventType": "CERTIFICATION", "location": "Genève, Suisse", "actor": "SGS Certifiers", "previousState": "ESSAYÉ_ET_SCELLÉ", "newState": "CERTIFIÉ_LBMA", "documentRef": "CERT-LBMA-PAMP", "authorizationSign": "SIG-SGS-LBMA"},
                      {"timestamp": 1774612800000, "eventType": "ALLOCATION", "location": "Genève, Suisse", "actor": "Aurum France Private Banking", "previousState": "RÉSERVE_GÉNÉRALE", "newState": "ALLOUÉ_PATRIMOINE", "documentRef": "DOC-ALLOC-DELORME-01", "authorizationSign": "SIG-AURUM-PARIS"}
                    ]"""

                    val metalorTimeline = """[
                      {"timestamp": 1773000000000, "eventType": "PRODUCTION", "location": "Neuchâtel, Suisse", "actor": "Metalor Technologies", "previousState": "N/A", "newState": "LINGOT_COULÉ", "documentRef": "CERT-MET-1120", "authorizationSign": "SIG-MET-CH"},
                      {"timestamp": 1773100000000, "eventType": "ALLOCATION", "location": "Neuchâtel, Suisse", "actor": "Aurum Suisse Operations", "previousState": "STOCKE_MINE", "newState": "ALLOUÉ_PATRIMOINE", "documentRef": "DOC-ALLOC-DELORME-02", "authorizationSign": "SIG-AURUM-GENEVE"}
                    ]"""

                    val simpleTimeline = """[
                      {"timestamp": 1771000000000, "eventType": "PRODUCTION", "location": "Valenza, Italie", "actor": "Valcambi EU Refiners", "previousState": "N/A", "newState": "CERTIFIÉ_FIN", "documentRef": "CERT-VAL-4821", "authorizationSign": "SIG-VAL-IT"},
                      {"timestamp": 1771100000000, "eventType": "ALLOCATION", "location": "Paris, France", "actor": "Aurum France Compliance", "previousState": "GARDE_GÉNÉRALE", "newState": "ALLOUÉ_PROPRIÉTÉ", "documentRef": "DOC-ALLOC-DELORME-03", "authorizationSign": "SIG-AURUM-PARIS"}
                    ]"""

                    val initialBars = listOf(
                        // Gold Bars (Allocated total = 1,600.40 oz)
                        // Bar 1: Large 1,000 oz Institutional Bar in Geneva
                        BarEntity(
                            serialNumber = "AU-INST-1000Z-001",
                            metal = "OR",
                            productId = "au-1kg", // Map to catalogue
                            refiner = "LBMA Refiner Royal",
                            grossWeight = 1003.10,
                            fineWeight = 1000.00,
                            weightUnit = "oz",
                            fineness = "999,9",
                            status = "CONSERVATION",
                            vaultId = "CH-GENEVE-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-1000-01",
                            assayDate = 1774526400000,
                            compartment = "Compte Privé Suisse A10",
                            currentPriceEUR = 3125000.00, // Simulated valuation
                            timelineJson = pampTimeline
                        ),
                        // Bar 2: 100 oz Gold Bar in Paris Vault
                        BarEntity(
                            serialNumber = "AU-FR-100OZ-4821",
                            metal = "OR",
                            productId = "au-100g",
                            refiner = "Pamp Suisse",
                            grossWeight = 100.12,
                            fineWeight = 100.00,
                            weightUnit = "oz",
                            fineness = "999,9",
                            status = "CONSERVATION",
                            vaultId = "FR-PARIS-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-4821",
                            assayDate = 1773000000000,
                            compartment = "Compartiment Privé Delorme C01",
                            currentPriceEUR = 312500.00,
                            timelineJson = metalorTimeline
                        ),
                        // Bar 3: 100 oz Gold Bar in Montréal Vault
                        BarEntity(
                            serialNumber = "AU-CA-100OZ-003",
                            metal = "OR",
                            productId = "au-100g",
                            refiner = "C. Hafner",
                            grossWeight = 100.08,
                            fineWeight = 100.00,
                            weightUnit = "oz",
                            fineness = "999,9",
                            status = "CONSERVATION",
                            vaultId = "CA-MON-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-0492",
                            assayDate = 1771000000000,
                            currentPriceEUR = 312500.00,
                            compartment = "Compartiment Canadien 12",
                            timelineJson = simpleTimeline
                        ),
                        // Bar 4: 100 oz Gold Bar in Bruxelles Vault
                        BarEntity(
                            serialNumber = "AU-BE-100OZ-004",
                            metal = "OR",
                            productId = "au-100g",
                            refiner = "Heraeus Germany",
                            grossWeight = 100.05,
                            fineWeight = 100.00,
                            weightUnit = "oz",
                            fineness = "999,9",
                            status = "CONSERVATION",
                            vaultId = "BE-BRU-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-0881",
                            assayDate = 1771000000000,
                            currentPriceEUR = 312500.00,
                            compartment = "Compartiment Belge Royal 02",
                            timelineJson = simpleTimeline
                        ),
                        // Bar 5: 100 oz Gold Bar in Paris Vault (Making 400 oz smaller bars + 1,000 oz Swiss bar)
                        BarEntity(
                            serialNumber = "AU-FR-100OZ-4822",
                            metal = "OR",
                            productId = "au-100g",
                            refiner = "Valcambi Suisse",
                            grossWeight = 100.10,
                            fineWeight = 100.00,
                            weightUnit = "oz",
                            fineness = "999,9",
                            status = "CONSERVATION",
                            vaultId = "FR-PARIS-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-4822",
                            assayDate = 1773000000000,
                            currentPriceEUR = 312500.00,
                            compartment = "Compartiment Privé Delorme C01",
                            timelineJson = metalorTimeline
                        ),
                        // Bar 6: Custom 200 Napoleon Gold Coins batch (representing 100.40 oz) in Paris Vault
                        BarEntity(
                            serialNumber = "AU-FR-COINS-9912",
                            metal = "OR",
                            productId = "au-1oz",
                            refiner = "Monnaie de Paris",
                            grossWeight = 100.40,
                            fineWeight = 100.40,
                            weightUnit = "oz",
                            fineness = "900,0",
                            status = "CONSERVATION",
                            vaultId = "FR-PARIS-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AU-NAP-99",
                            assayDate = 1771000000000,
                            currentPriceEUR = 313750.00,
                            compartment = "Coffret Sécurisé Napoléon D05",
                            timelineJson = simpleTimeline
                        ),

                        // Silver Bars (Allocated total = 31.20 kg)
                        // Bar S1: 15 kg Silver Bar in Paris Vault
                        BarEntity(
                            serialNumber = "AG-FR-15KG-001",
                            metal = "ARGENT",
                            productId = "ag-5kg", // Large format
                            refiner = "Metalor France",
                            grossWeight = 15.01,
                            fineWeight = 15.00,
                            weightUnit = "kg",
                            fineness = "999,0",
                            status = "CONSERVATION",
                            vaultId = "FR-PARIS-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AG-15K-01",
                            assayDate = 1773000000000,
                            currentPriceEUR = 12000.00,
                            compartment = "Compartiment Argent Base B02",
                            timelineJson = simpleTimeline
                        ),
                        // Bar S2: 15 kg Silver Bar in Geneva Freeport (Swiss VAT-free zones)
                        BarEntity(
                            serialNumber = "AG-CH-15KG-002",
                            metal = "ARGENT",
                            productId = "ag-5kg",
                            refiner = "Umicore Switzerland",
                            grossWeight = 15.02,
                            fineWeight = 15.00,
                            weightUnit = "kg",
                            fineness = "999,0",
                            status = "CONSERVATION",
                            vaultId = "CH-GENEVE-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AG-15K-02",
                            assayDate = 1774526400000,
                            currentPriceEUR = 12000.00,
                            compartment = "Coffre Franc Sous Douane CH4",
                            timelineJson = pampTimeline
                        ),
                        // Bar S3: 1.2 kg Silver coin/lingot pack in Bruxelles
                        BarEntity(
                            serialNumber = "AG-BE-1.2KG-003",
                            metal = "ARGENT",
                            productId = "ag-1kg",
                            refiner = "Pamp Suisse",
                            grossWeight = 1.20,
                            fineWeight = 1.20,
                            weightUnit = "kg",
                            fineness = "999,0",
                            status = "CONSERVATION",
                            vaultId = "BE-BRU-01",
                            ownerId = "CLIENT-DELORME",
                            certificateNo = "CERT-AG-1K-03",
                            assayDate = 1771000000000,
                            currentPriceEUR = 960.00,
                            compartment = "Compartiment Belge Royal 02",
                            timelineJson = simpleTimeline
                        )
                    )
                    dao.insertBars(initialBars)

                    // 3. Seed some general Transactions to populate history beautifully
                    val transactions = listOf(
                        TransactionEntity(
                            timestamp = System.currentTimeMillis() - 86400000 * 30, // 30 days ago
                            type = "ACHAT",
                            metal = "OR",
                            amount = 100.00,
                            unit = "oz",
                            valueEUR = 312500.00,
                            status = "COMPLÉTÉ",
                            serialNumber = "AU-FR-100OZ-4822",
                            sourceVaultId = "PROVENANCE-RAFFINEUR",
                            destVaultId = "FR-PARIS-01",
                            details = "Achat direct d'or d'investissement alloué - Devis accepté.",
                            auditHash = "HASH-9921-AF12-CD48"
                        ),
                        TransactionEntity(
                            timestamp = System.currentTimeMillis() - 86400000 * 15, // 15 days ago
                            type = "TRANSFERT",
                            metal = "ARGENT",
                            amount = 15.00,
                            unit = "kg",
                            valueEUR = 12000.00,
                            status = "COMPLÉTÉ",
                            serialNumber = "AG-CH-15KG-002",
                            sourceVaultId = "FR-PARIS-01",
                            destVaultId = "CH-GENEVE-01",
                            details = "Transfert physique de garde de Paris à Genève sous douane (Exempté de TVA).",
                            auditHash = "HASH-1289-CH88-99AF"
                        ),
                        TransactionEntity(
                            timestamp = System.currentTimeMillis() - 86400000 * 5, // 5 days ago
                            type = "ACHAT",
                            metal = "ARGENT",
                            amount = 1.20,
                            unit = "kg",
                            valueEUR = 960.00,
                            status = "COMPLÉTÉ",
                            serialNumber = "AG-BE-1.2KG-003",
                            sourceVaultId = "PROVENANCE-RAFFINEUR",
                            destVaultId = "BE-BRU-01",
                            details = "Achat d'argent d'investissement alloué.",
                            auditHash = "HASH-BE-9912-FF92"
                        )
                    )
                    for (tx in transactions) {
                        dao.insertTransaction(tx)
                    }

                    // 4. Seed compliance cases
                    val initialCompliance = listOf(
                        ComplianceCaseEntity(
                            timestamp = System.currentTimeMillis() - 86400000 * 45,
                            clientName = "FAMILLE DELORME",
                            jurisdictionCode = "FR",
                            riskScore = 0.08, // Very safe
                            status = "APPROUVÉ",
                            checksPassedJson = "[\"KYC_OK\", \"LCB_FT_ACPR_OK\", \"SANCTIONS_CLEAR\", \"SOURCE_OF_FUNDS_VALIDATED\"]",
                            notes = "Dossier validé par le Secrétariat Général. Client Patrimonial classifié - Origine des fonds: Cession immobilière notariée en France."
                        ),
                        ComplianceCaseEntity(
                            timestamp = System.currentTimeMillis() - 86400000 * 2,
                            clientName = "DEMANDE RFQ G-2026",
                            jurisdictionCode = "CH",
                            riskScore = 0.15,
                            status = "LCB_FT_VÉRIFIÉ",
                            checksPassedJson = "[\"KYC_OK\", \"OBA_FINMA_VÉRIFIÉ\"]",
                            notes = "Vérification automatisée effectuée pour le devis d'achat d'or physique."
                        )
                    )
                    for (cc in initialCompliance) {
                        dao.insertComplianceCase(cc)
                    }

                    // 5. Seed initial Reconciliation logs
                    val initialReconciliations = listOf(
                        ReconciliationEntity(
                            date = System.currentTimeMillis() - 86400000 * 2,
                            vaultId = "FR-PARIS-01",
                            expectedWeightKg = 7821.700,
                            registeredWeightKg = 7821.700,
                            physicalWeightKg = 7821.700,
                            status = "RÉCONCILIÉ",
                            inspectorName = "Jérôme Berthier (Commissaire aux Métaux)",
                            notes = "Réconciliation complète effectuée avec succès. Toutes les barres de lingot d'or et d'argent correspondent exactement à la masse physique constatée."
                        ),
                        ReconciliationEntity(
                            date = System.currentTimeMillis() - 86400000 * 5,
                            vaultId = "CH-GENEVE-01",
                            expectedWeightKg = 11200.500,
                            registeredWeightKg = 11200.500,
                            physicalWeightKg = 11200.500,
                            status = "RÉCONCILIÉ",
                            inspectorName = "Marc-Antoine de Saussure (Auditeur Suisse)",
                            notes = "Audit annuel et réconciliation bi-mensuelle. Scellés de sécurité inspectés et intacts."
                        )
                    )
                    for (rec in initialReconciliations) {
                        dao.insertReconciliation(rec)
                    }
                }
            }
        }
    }
}
