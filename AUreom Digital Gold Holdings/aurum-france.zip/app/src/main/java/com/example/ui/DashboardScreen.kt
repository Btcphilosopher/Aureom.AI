package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BarEntity
import com.example.data.TransactionEntity
import com.example.model.Jurisdiction
import com.example.model.Metal
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MutedFrenchBlue
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    viewModel: PreciousMetalViewModel,
    onNavigateToBuy: () -> Unit,
    onNavigateToMetals: () -> Unit,
    onNavigateToVaults: () -> Unit
) {
    val bars by viewModel.bars.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val goldSpot by viewModel.goldSpotPrice.collectAsState()
    val silverSpot by viewModel.silverSpotPrice.collectAsState()

    val activeBars = bars.filter { it.status == "CONSERVATION" }

    // Calculate totals
    val goldWeightOz = activeBars.filter { it.metal == "OR" }.sumOf { it.fineWeight } + 242.0 // Seeded unallocated
    val silverWeightKg = activeBars.filter { it.metal == "ARGENT" }.sumOf { it.fineWeight } + 11.6 // Seeded unallocated

    val goldValuationEUR = goldWeightOz * goldSpot
    val silverValuationEUR = (silverWeightKg / 0.0311035) * silverSpot // Convert kg to oz for spot valuation
    val totalValuationEUR = goldValuationEUR + silverValuationEUR

    val forex = viewModel.getForexRate()
    val totalValuationConverted = totalValuationEUR * forex
    val goldValuationConverted = goldValuationEUR * forex
    val silverValuationConverted = silverValuationEUR * forex

    val currencySymbol = when(currency) {
        "EUR" -> "€"
        "USD" -> "$"
        "CHF" -> "CHF"
        "CAD" -> "CA$"
        "MAD" -> "MAD"
        "XOF" -> "F.CFA"
        "XAF" -> "F.CFA"
        else -> "€"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp)
    ) {
        // 1. Editorial Private Bank Brand
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "A U R U M   F R A N C E",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    letterSpacing = 5.sp
                )
                Text(
                    text = "MAISON DE GARDE ET DE PATRIMOINE HAUTE-SÉCURITÉ",
                    style = MaterialTheme.typography.bodySmall,
                    color = ChampagneGold,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Divider(
                    color = ChampagneGold.copy(alpha = 0.3f),
                    modifier = Modifier
                        .width(120.dp)
                        .padding(top = 12.dp, bottom = 8.dp),
                    thickness = 1.dp
                )
            }
        }

        // Welcome banner
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BONJOUR,",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Famille Delorme",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                
                // Currency Selector Chip
                Box {
                    var expanded by remember { mutableStateOf(false) }
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, ChampagneGold.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                            .clickable { expanded = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currency,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Devise",
                            tint = ChampagneGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                    ) {
                        listOf("EUR", "USD", "CHF", "CAD", "MAD", "XOF").forEach { curr ->
                            DropdownMenuItem(
                                text = { Text(curr, fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.selectCurrency(curr)
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 2. CONSOLIDATED VALUE CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("consolidated_wealth_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "VALEUR TOTALE ESTIMÉE DU PATRIMOINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "$currencySymbol ${"%,.2f".format(totalValuationConverted)}",
                        style = MaterialTheme.typography.headlineLarge.copy(fontSize = 32.sp),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Régime d'allocation nominative intégrale • 100% Physique",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Divider(
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )

                    // Multi-Ledger Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ChampagneGold))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "MON OR ALLOUÉ", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                            }
                            Text(
                                text = "${"%,.3f".format(goldWeightOz)} oz",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "$currencySymbol ${"%,.2f".format(goldValuationConverted)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MutedFrenchBlue))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "MON ARGENT ALLOUÉ", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                            }
                            Text(
                                text = "${"%,.3f".format(silverWeightKg)} kg",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "$currencySymbol ${"%,.2f".format(silverValuationConverted)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedFrenchBlue,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // 3. QUICK ACTIONS ROW
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onNavigateToBuy,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("quick_buy_button")
                ) {
                    Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Acheter", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onNavigateToMetals,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("quick_portfolio_button")
                ) {
                    Icon(imageVector = Icons.Default.Category, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Mes Lingots", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // 4. REGIONAL JURISDICTIONS SPLIT
        item {
            Text(
                text = "RÉPARTITION PAR JURIDICTION",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            val regionalBars = activeBars.groupBy { it.vaultId }
            val jurisdictions = listOf(
                "FR-PARIS-01" to ("Paris, France" to Jurisdiction.FRANCE),
                "CH-GENEVE-01" to ("Genève, Suisse" to Jurisdiction.SUISSE),
                "BE-BRU-01" to ("Bruxelles, Belgique" to Jurisdiction.BELGIQUE),
                "CA-MON-01" to ("Montréal, Canada" to Jurisdiction.CANADA)
            )

            jurisdictions.forEach { (vaultId, detail) ->
                val (city, jur) = detail
                val barsInVault = regionalBars[vaultId] ?: emptyList()
                val goldInVaultOz = barsInVault.filter { it.metal == "OR" }.sumOf { it.fineWeight } + (if (vaultId == "FR-PARIS-01") 242.0 else 0.0)
                val silverInVaultKg = barsInVault.filter { it.metal == "ARGENT" }.sumOf { it.fineWeight } + (if (vaultId == "FR-PARIS-01") 11.6 else 0.0)

                val valuationEUR = (goldInVaultOz * goldSpot) + ((silverInVaultKg / 0.0311035) * silverSpot)
                val valuationConv = valuationEUR * forex

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onNavigateToVaults() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Domain,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = city, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${barsInVault.size} Lingots • ${"%,.1f".format(goldInVaultOz)} oz Or • ${"%,.1f".format(silverInVaultKg)} kg Ag",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "$currencySymbol ${"%,.2f".format(valuationConv)}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = jur.amlRegime,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 9.sp,
                                color = ChampagneGold,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // 5. LEDGER / RECONSTRUCTABLE EVENTS TIMELINE
        item {
            Text(
                text = "REGISTRE DE PROPRIÉTÉ - DERNIÈRES OPÉRATIONS",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "Aucune opération enregistrée dans le registre.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                )
            }
        } else {
            items(transactions.take(5)) { tx ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val icon = when (tx.type) {
                                    "ACHAT" -> Icons.Default.TrendingUp
                                    "VENTE" -> Icons.Default.Sell
                                    "TRANSFERT" -> Icons.Default.SwapHoriz
                                    "LIVRAISON" -> Icons.Default.LocalShipping
                                    else -> Icons.Default.Info
                                }
                                val iconColor = when (tx.type) {
                                    "ACHAT" -> Color(0xFF2E7D32)
                                    "VENTE" -> Color(0xFFC62828)
                                    "TRANSFERT" -> ChampagneGold
                                    "LIVRAISON" -> MutedFrenchBlue
                                    else -> Color.Gray
                                }
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tx.type,
                                    tint = iconColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = tx.type,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = iconColor
                                )
                            }
                            Text(
                                text = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.FRANCE).format(Date(tx.timestamp)),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${tx.amount} ${tx.unit} de ${tx.metal} • Mouvement de ${tx.sourceVaultId} vers ${tx.destVaultId}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = tx.details,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Registre d'audit cryptographique : ${tx.auditHash}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 8.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
