package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "precious_metal_bars")
data class BarEntity(
    @PrimaryKey val serialNumber: String,
    val metal: String, // OR, ARGENT
    val productId: String, // au-100g, etc.
    val refiner: String,
    val grossWeight: Double,
    val fineWeight: Double,
    val weightUnit: String, // g, oz, kg
    val fineness: String, // 999,9
    val status: String, // ALLOCÉ, CONSERVATION, EN_TRANSFERT, LIVRÉ
    val vaultId: String, // PARIS-01, GENEVE-01, etc.
    val ownerId: String, // CLIENT-DELORME, etc.
    val certificateNo: String,
    val assayDate: Long,
    val compartment: String,
    val currentPriceEUR: Double,
    val timelineJson: String, // JSON serialization of List<TimelineEvent>
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "vaults")
data class VaultEntity(
    @PrimaryKey val id: String,
    val name: String,
    val jurisdictionCode: String, // FR, CH, BE, etc.
    val city: String,
    val capacityKg: Double,
    val occupiedKg: Double,
    val secureZone: String,
    val room: String,
    val compartmentCount: Int,
    val allocatedMetalKg: Double,
    val unallocatedMetalKg: Double,
    val pendingMovementsCount: Int,
    val insuranceCompany: String,
    val lastInspectionDate: Long
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientName: String,
    val metal: String,
    val productId: String,
    val productName: String,
    val weight: Double,
    val weightUnit: String,
    val quantity: Int,
    val baseMetalPriceEUR: Double,
    val premiumPriceEUR: Double,
    val totalPriceEUR: Double,
    val currency: String,
    val targetVaultId: String,
    val status: String, // RFQ, QUOTED, ACCEPTED, ALLOCATED, DELIVERED, REJECTED
    val quoteExpirationTime: Long,
    val rfvCode: String, // RFQ unique tracking reference
    val createdTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val type: String, // ACHAT, VENTE, TRANSFERT, LIVRAISON, FRAIS
    val metal: String, // OR, ARGENT
    val amount: Double,
    val unit: String,
    val valueEUR: Double,
    val status: String, // COMPLÉTÉ, EN_ATTENTE, REJETÉ
    val serialNumber: String, // Reference bar if applicable
    val sourceVaultId: String,
    val destVaultId: String,
    val details: String,
    val auditHash: String // Audit cryptographic simulation string
)

@Entity(tableName = "reconciliations")
data class ReconciliationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val vaultId: String,
    val expectedWeightKg: Double,
    val registeredWeightKg: Double,
    val physicalWeightKg: Double,
    val status: String, // RÉCONCILIÉ, EXCEPTION, EN_INVESTIGATION
    val inspectorName: String,
    val notes: String
)

@Entity(tableName = "compliance_cases")
data class ComplianceCaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val clientName: String,
    val jurisdictionCode: String,
    val riskScore: Double, // 0.0 to 1.0
    val status: String, // CAPTURE, LCB_FT_VÉRIFIÉ, APPROUVÉ, SURVEILLANCE_TRACFIN
    val checksPassedJson: String, // KYC, LCB-FT, Sanctions list checks
    val notes: String
)
