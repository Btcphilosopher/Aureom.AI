package com.example.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OrderEntity
import com.example.model.BullionCatalog
import com.example.model.Jurisdiction
import com.example.model.Metal
import com.example.model.ProductSpecification
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DarkBurgundy
import com.example.ui.theme.MutedFrenchBlue

@Composable
fun AchatScreen(viewModel: PreciousMetalViewModel) {
    val currency by viewModel.selectedCurrency.collectAsState()
    val activeQuote by viewModel.activeQuote.collectAsState()
    val quoteTimer by viewModel.quoteTimerSeconds.collectAsState()
    val vaults by viewModel.vaults.collectAsState()

    var selectedMetal by remember { mutableStateOf(Metal.OR) }
    var selectedProduct by remember { mutableStateOf<ProductSpecification>(BullionCatalog.goldProducts.last()) } // Default to 1kg gold bar
    var quantity by remember { mutableStateOf(1) }
    var selectedVaultId by remember { mutableStateOf("FR-PARIS-01") }

    var allocationSuccess by remember { mutableStateOf(false) }

    val currencySymbol = when(currency) {
        "EUR" -> "€"
        "USD" -> "$"
        "CHF" -> "CHF"
        "CAD" -> "CA$"
        "MAD" -> "MAD"
        "XOF" -> "F.CFA"
        "XAF" -> "F.CFA"
        else -> "€"
    }

    // Automatically synchronize selected product lists when metal tab changes
    LaunchedEffect(selectedMetal) {
        selectedProduct = if (selectedMetal == Metal.OR) {
            BullionCatalog.goldProducts.last()
        } else {
            BullionCatalog.silverProducts.first()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("achat_screen")
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp)
    ) {
        item {
            Text(
                text = "TERMINAL DE COTATION ACHAT PHYS-BULLION (RFQ)",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Calcul d'allocation physique fine nominative et calcul de prime en temps-réel",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (allocationSuccess) {
            // Success view
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp)
                        .testTag("allocation_success_panel"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, Color(0xFF2E7D32))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "ALLOCATION PHYSIQUE REUSSIE",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Le dossier de conformité LCB-FT a été validé électroniquement. Vos lingots ont été scellés, frappés de leur numéro de série unique, et affectés nominalement dans votre compartiment de coffre-fort de destination.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "L'OR EST PHYSIQUE • LA GARDE EST TRAÇABLE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ChampagneGold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { allocationSuccess = false },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("Retour au terminal de cotation", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else if (activeQuote != null) {
            // Quotation review view
            item {
                val vault = vaults.firstOrNull { it.id == activeQuote!!.targetVaultId }
                val jur = Jurisdiction.values().firstOrNull { it.code == vault?.jurisdictionCode } ?: Jurisdiction.FRANCE
                val taxEstimate = viewModel.estimateTaxForProduct(selectedProduct, "ACHAT")

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quotation_review_panel"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DEVIS ALLOUÉ IMMUTABLE",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                            Box(
                                modifier = Modifier
                                    .background(DarkBurgundy.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Expire dans ${quoteTimer}s",
                                    color = Color(0xFFC62828),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Divider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(vertical = 12.dp))

                        // Product specifications
                        Text(
                            text = "${activeQuote!!.quantity}x ${activeQuote!!.productName}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Lieu d'allocation cible : ${vault?.name ?: activeQuote!!.targetVaultId}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedFrenchBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Pricing breakdowns
                        Text(
                            text = "DÉTAIL DES COMPOSANTES DE LA PRIME",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        DetailPricingRow("Valeur métal de base (Spot)", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * (1 - selectedProduct.defaultPremiumPercent / 100.0) * quantity)}")
                        DetailPricingRow("Frais de fabrication & fonderie", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * (selectedProduct.defaultPremiumPercent / 100.0 * 0.40) * quantity)}")
                        DetailPricingRow("Prime de raffineur agréé", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * (selectedProduct.defaultPremiumPercent / 100.0 * 0.25) * quantity)}")
                        DetailPricingRow("Marge de courtage d'investissement", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * (selectedProduct.defaultPremiumPercent / 100.0 * 0.20) * quantity)}")
                        DetailPricingRow("Logistique & transport sécurisé", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * (selectedProduct.defaultPremiumPercent / 100.0 * 0.15) * quantity)}")
                        
                        Divider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(vertical = 10.dp))
                        
                        DetailPricingRow("Sous-total Net (Hors Taxe)", "$currencySymbol ${"%,.2f".format(taxEstimate.productPrice * quantity)}")
                        DetailPricingRow("Taxation locale (${"%,.1f".format(taxEstimate.taxRate)}%)", "$currencySymbol ${"%,.2f".format(taxEstimate.taxAmount * quantity)}")

                        Divider(color = ChampagneGold.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PRIX TOTAL NET DE L'ALLOCATION",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "$currencySymbol ${"%,.2f".format(taxEstimate.totalWithTax * quantity)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = ChampagneGold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Tax breakdown note
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MutedFrenchBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Régime Fiscal de Juridiction : ${jur.displayName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = taxEstimate.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Audit trace : ${taxEstimate.trace}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Accept / Cancel actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.cancelActiveQuote() },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Rejeter")
                            }

                            Button(
                                onClick = {
                                    viewModel.acceptQuote { success ->
                                        if (success) {
                                            allocationSuccess = true
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1.5f).height(48.dp).testTag("accept_quote_confirm_btn"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold)
                            ) {
                                Text("Accepter l'Allocation", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        } else {
            // Configuration Form View
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        // Metal Select Tabs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                                .padding(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selectedMetal == Metal.OR) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { selectedMetal = Metal.OR }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "OR PHYSIQUE (XAU)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (selectedMetal == Metal.OR) Color.White else Color.Gray
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selectedMetal == Metal.ARGENT) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { selectedMetal = Metal.ARGENT }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "ARGENT PHYSIQUE (XAG)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (selectedMetal == Metal.ARGENT) Color.White else Color.Gray
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        // Product Selection Dropdown
                        Text("1. Sélectionner l'unité d'investissement", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))

                        val products = if (selectedMetal == Metal.OR) BullionCatalog.goldProducts else BullionCatalog.silverProducts
                        var expanded by remember { mutableStateOf(false) }

                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable { expanded = true }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(selectedProduct.name, fontWeight = FontWeight.Bold)
                                    Text("${selectedProduct.manufacturer} • Pureté ${selectedProduct.fineness}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = ChampagneGold)
                            }

                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                            ) {
                                products.forEach { prod ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(prod.name, fontWeight = FontWeight.Bold)
                                                Text("${prod.manufacturer} • Prime +${prod.defaultPremiumPercent}%", fontSize = 11.sp, color = Color.Gray)
                                            }
                                        },
                                        onClick = {
                                            selectedProduct = prod
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        // Quantity Selector
                        Text("2. Quantité physique", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            IconButton(onClick = { if (quantity > 1) quantity-- }) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Diminuer", tint = ChampagneGold)
                            }
                            Text(
                                text = quantity.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(32.dp),
                                textAlign = TextAlign.Center
                            )
                            IconButton(onClick = { quantity++ }) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Augmenter", tint = ChampagneGold)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        // Target Vault Selector
                        Text("3. Sélectionner le coffre-fort de garde", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))

                        var vaultExpanded by remember { mutableStateOf(false) }
                        val currentVault = vaults.firstOrNull { it.id == selectedVaultId }

                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable { vaultExpanded = true }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(currentVault?.name ?: selectedVaultId, fontWeight = FontWeight.Bold)
                                    Text("Lieu de conservation : ${currentVault?.city ?: ""}", style = MaterialTheme.typography.bodySmall, color = MutedFrenchBlue)
                                }
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = ChampagneGold)
                            }

                            DropdownMenu(
                                expanded = vaultExpanded,
                                onDismissRequest = { vaultExpanded = false },
                                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                            ) {
                                vaults.forEach { v ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(v.name, fontWeight = FontWeight.Bold)
                                                Text("Juridiction: ${v.jurisdictionCode} • Assureur: ${v.insuranceCompany}", fontSize = 11.sp, color = Color.Gray)
                                            }
                                        },
                                        onClick = {
                                            selectedVaultId = v.id
                                            vaultExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // RFQ calculation trigger
                        Button(
                            onClick = {
                                viewModel.requestRFQ(selectedProduct.id, quantity, selectedVaultId)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("request_rfq_calc_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Calculer la Cotation (RFQ)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailPricingRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}
