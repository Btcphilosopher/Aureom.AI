package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PreciousMetalDao {

    // --- BARS / LINGOTS ---
    @Query("SELECT * FROM precious_metal_bars ORDER BY lastUpdated DESC")
    fun getAllBars(): Flow<List<BarEntity>>

    @Query("SELECT * FROM precious_metal_bars WHERE ownerId = :ownerId")
    fun getBarsByOwner(ownerId: String): Flow<List<BarEntity>>

    @Query("SELECT * FROM precious_metal_bars WHERE vaultId = :vaultId")
    fun getBarsByVault(vaultId: String): Flow<List<BarEntity>>

    @Query("SELECT * FROM precious_metal_bars WHERE serialNumber = :serialNumber LIMIT 1")
    suspend fun getBarBySerialNumber(serialNumber: String): BarEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBar(bar: BarEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBars(bars: List<BarEntity>)

    @Update
    suspend fun updateBar(bar: BarEntity)

    @Delete
    suspend fun deleteBar(bar: BarEntity)


    // --- VAULTS / COFFRES ---
    @Query("SELECT * FROM vaults ORDER BY id ASC")
    fun getAllVaults(): Flow<List<VaultEntity>>

    @Query("SELECT * FROM vaults WHERE id = :id LIMIT 1")
    suspend fun getVaultById(id: String): VaultEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaults(vaults: List<VaultEntity>)

    @Update
    suspend fun updateVault(vault: VaultEntity)


    // --- ORDERS / DEVIS ---
    @Query("SELECT * FROM orders ORDER BY createdTime DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: Long): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)


    // --- TRANSACTIONS ---
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)


    // --- RECONCILIATIONS ---
    @Query("SELECT * FROM reconciliations ORDER BY date DESC")
    fun getAllReconciliations(): Flow<List<ReconciliationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReconciliation(reconciliation: ReconciliationEntity)


    // --- COMPLIANCE ---
    @Query("SELECT * FROM compliance_cases ORDER BY timestamp DESC")
    fun getAllComplianceCases(): Flow<List<ComplianceCaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplianceCase(complianceCase: ComplianceCaseEntity)
}
