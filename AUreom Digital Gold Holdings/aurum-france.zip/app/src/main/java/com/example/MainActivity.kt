package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AchatScreen
import com.example.ui.DashboardScreen
import com.example.ui.MetalsScreen
import com.example.ui.PreciousMetalViewModel
import com.example.ui.ProfilComplianceScreen
import com.example.ui.VaultsScreen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppLayout()
            }
        }
    }
}

@Composable
fun MainAppLayout() {
    val viewModel: PreciousMetalViewModel = viewModel()
    var selectedScreenIndex by remember { mutableStateOf(0) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_nav_bar"),
                tonalElevation = 8.dp
            ) {
                val items = listOf(
                    NavigationItem("Accueil", Icons.Default.Home, "accueil_nav"),
                    NavigationItem("Métaux", Icons.Default.Category, "metaux_nav"),
                    NavigationItem("Coffres", Icons.Default.Business, "coffres_nav"),
                    NavigationItem("Acheter", Icons.Default.AddShoppingCart, "acheter_nav"),
                    NavigationItem("Privé & AI", Icons.Default.SupportAgent, "profil_nav")
                )

                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = selectedScreenIndex == index,
                        onClick = { selectedScreenIndex = index },
                        icon = { Icon(imageVector = item.icon, contentDescription = item.label, modifier = Modifier.size(22.dp)) },
                        label = { Text(text = item.label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag(item.tag),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ChampagneGold,
                            selectedTextColor = ChampagneGold,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedScreenIndex) {
                0 -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToBuy = { selectedScreenIndex = 3 },
                    onNavigateToMetals = { selectedScreenIndex = 1 },
                    onNavigateToVaults = { selectedScreenIndex = 2 }
                )
                1 -> MetalsScreen(viewModel = viewModel)
                2 -> VaultsScreen(viewModel = viewModel)
                3 -> AchatScreen(viewModel = viewModel)
                4 -> ProfilComplianceScreen(viewModel = viewModel)
            }
        }
    }
}

data class NavigationItem(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val tag: String)
