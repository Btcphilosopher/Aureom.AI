package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaultEntity
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MutedFrenchBlue
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun VaultsScreen(viewModel: PreciousMetalViewModel) {
    val vaults by viewModel.vaults.collectAsState()
    val reconciliations by viewModel.reconciliations.collectAsState()

    var auditingVaultId by remember { mutableStateOf<String?>(null) }
    var auditOutputLog by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("vaults_screen")
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp)
    ) {
        // Main Header
        item {
            Text(
                text = "JUMEAU NUMÉRIQUE DES COFFRES (FORT-TWIN)",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Supervision temps-réel de l'infrastructure de garde physique",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Vault Twins List
        items(vaults) { vault ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Title and Jurisdiction
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = vault.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(text = "${vault.city}, Jurisdiction ${vault.jurisdictionCode}", style = MaterialTheme.typography.bodySmall, color = MutedFrenchBlue, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF2E7D32).copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "SÉCURISÉ", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(vertical = 12.dp))

                    // Capacity indicator
                    val occupiedRatio = (vault.occupiedKg / vault.capacityKg).toFloat().coerceIn(0f, 1f)
                    Text(
                        text = "CAPACITÉ D'INVENTAIRE : ${(occupiedRatio * 100).toInt()}% (${"%,.1f".format(vault.occupiedKg)} kg / ${"%,.0f".format(vault.capacityKg)} kg)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { occupiedRatio },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = ChampagneGold,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Allocated / Unallocated Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Métaux Alloués Spécifiques", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("${"%,.1f".format(vault.allocatedMetalKg)} kg", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Column {
                            Text("Métaux Non Alloués (Pooled)", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("${"%,.1f".format(vault.unallocatedMetalKg)} kg", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    // Secure specifications
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "${vault.secureZone} • ${vault.room}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Assurance : ${vault.insuranceCompany} • Compartiments actifs : ${vault.compartmentCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Dernière inspection physique : ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(vault.lastInspectionDate))}",
                            modifier = Modifier.materialLabelStyle(),
                            fontSize = 10.sp,
                            color = MutedFrenchBlue,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Audit trigger
                    Button(
                        onClick = {
                            auditingVaultId = vault.id
                            viewModel.triggerReconciliation(vault.id, "Jérôme Berthier (Commissaire aux Métaux)") { log ->
                                auditOutputLog = log
                                auditingVaultId = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("audit_reconciliation_btn_${vault.id}"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Déclencher audit physique", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Reconciliation Report display
        if (auditOutputLog != null) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    border = BorderStroke(1.dp, Color(0xFF2E7D32).copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = Color(0xFF2E7D32))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("RAPPORT D'AUDIT COFFRE-REGISTRE", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = auditOutputLog!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF1B5E20)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Vérificateur : Jérôme Berthier (Commissaire certifié LBMA)\n" +
                                   "Système d'audit déterministe synchrone • 100% Réconcilié",
                            fontSize = 10.sp,
                            color = Color(0xFF1B5E20).copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Audit History section
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "HISTORIQUE DU REGISTRE DE RÉCONCILIATION",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (reconciliations.isEmpty()) {
            item {
                Text(
                    text = "Aucune réconciliation passée.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        } else {
            items(reconciliations) { rec ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Audit Coffre : ${rec.vaultId}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(
                                text = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(rec.date)),
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Registre : ${rec.registeredWeightKg} kg | Physique compté : ${rec.physicalWeightKg} kg", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text(text = "Inspecteur : ${rec.inspectorName}", fontSize = 11.sp, color = Color.Gray)
                        Text(text = rec.notes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Statut : ${rec.status}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                    }
                }
            }
        }
    }
}

// Extension function for styling
@Composable
fun Modifier.materialLabelStyle() = this.padding(top = 4.dp)
