package com.example.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BarEntity
import com.example.data.VaultEntity
import com.example.model.BullionCatalog
import com.example.model.Metal
import com.example.model.TimelineEvent
import com.example.ui.theme.AntiqueBronze
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MutedFrenchBlue
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MetalsScreen(viewModel: PreciousMetalViewModel) {
    val bars by viewModel.bars.collectAsState()
    val vaults by viewModel.vaults.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val goldSpot by viewModel.goldSpotPrice.collectAsState()
    val silverSpot by viewModel.silverSpotPrice.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0 = Marché Spot, 1 = Mes Lingots Alloués
    var selectedBarForPassport by remember { mutableStateOf<BarEntity?>(null) }

    val currencySymbol = when(currency) {
        "EUR" -> "€"
        "USD" -> "$"
        "CHF" -> "CHF"
        "CAD" -> "CA$"
        "MAD" -> "MAD"
        "XOF" -> "F.CFA"
        "XAF" -> "F.CFA"
        else -> "€"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("metals_screen")
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Upper Navigation Tab
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = ChampagneGold
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0; selectedBarForPassport = null },
                text = { Text("Cours & Tarification", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Mon Portefeuille Alloué", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        if (selectedBarForPassport != null) {
            // Display the beautiful Asset Passport view
            AssetPassportView(
                bar = selectedBarForPassport!!,
                vaults = vaults,
                viewModel = viewModel,
                onBack = { selectedBarForPassport = null }
            )
        } else {
            when (selectedTab) {
                0 -> SpotMarketTab(viewModel, currencySymbol)
                1 -> PortfolioTab(bars.filter { it.status == "CONSERVATION" }, currencySymbol, onSelectBar = { selectedBarForPassport = it })
            }
        }
    }
}

@Composable
fun SpotMarketTab(viewModel: PreciousMetalViewModel, currencySymbol: String) {
    val currency by viewModel.selectedCurrency.collectAsState()
    val goldSpot by viewModel.goldSpotPrice.collectAsState()
    val silverSpot by viewModel.silverSpotPrice.collectAsState()

    val forex = viewModel.getForexRate()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 40.dp)
    ) {
        // Spot Price Cards
        item {
            Text(
                text = "TABLEAU DES COURS EN DIRECT",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Gold Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("OR PHYSIQUE (XAU)", style = MaterialTheme.typography.bodySmall, color = MutedFrenchBlue, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        val conv = viewModel.getSpotConverted(Metal.OR, "oz")
                        Text(
                            text = "$currencySymbol ${"%,.2f".format(conv)} / oz",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Achat (Ask) : ${"%,.2f".format(conv * 1.0015)}", fontSize = 10.sp, color = Color.Gray)
                            Text("Vente (Bid) : ${"%,.2f".format(conv * 0.9985)}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }

                // Silver Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ARGENT PHYSIQUE (XAG)", style = MaterialTheme.typography.bodySmall, color = MutedFrenchBlue, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        val conv = viewModel.getSpotConverted(Metal.ARGENT, "kg")
                        Text(
                            text = "$currencySymbol ${"%,.2f".format(conv)} / kg",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Achat : ${"%,.2f".format(conv * 1.0025)}", fontSize = 10.sp, color = Color.Gray)
                            Text("Vente : ${"%,.2f".format(conv * 0.9975)}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Bullion Catalog List
        item {
            Text(
                text = "BARRES & LINGOTS DE RÉFÉRENCE",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Gold section of catalog
        item {
            Text("Catalogue Or d'Investissement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
        }

        items(BullionCatalog.goldProducts) { prod ->
            val calc = viewModel.estimateTaxForProduct(prod, "ACHAT")
            CatalogProductRow(prod, calc, currencySymbol)
        }

        // Silver section of catalog
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Catalogue Argent d'Investissement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
        }

        items(BullionCatalog.silverProducts) { prod ->
            val calc = viewModel.estimateTaxForProduct(prod, "ACHAT")
            CatalogProductRow(prod, calc, currencySymbol)
        }
    }
}

@Composable
fun CatalogProductRow(
    prod: com.example.model.ProductSpecification,
    calc: CalculatedTaxEstimate,
    currencySymbol: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.3f)) {
                Text(text = prod.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${prod.manufacturer} • Pureté ${prod.fineness} • ${prod.dimensions}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
            Column(
                modifier = Modifier.weight(0.7f),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "$currencySymbol ${"%,.2f".format(calc.productPrice)}",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "+ ${prod.defaultPremiumPercent}% Prime de manufacture",
                    style = MaterialTheme.typography.bodySmall,
                    color = ChampagneGold,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun PortfolioTab(
    bars: List<BarEntity>,
    currencySymbol: String,
    onSelectBar: (BarEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 40.dp)
    ) {
        item {
            Text(
                text = "VOS UNITÉS PHYSIQUES CERTIFIÉES ET ALLOUÉES",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (bars.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Aucun lingot physique alloué.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(bars) { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectBar(bar) },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (bar.metal == "OR") Icons.Default.Toll else Icons.Default.Toll,
                                contentDescription = null,
                                tint = if (bar.metal == "OR") ChampagneGold else MutedFrenchBlue,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Lingot d'${if(bar.metal == "OR") "Or" else "Argent"} ${bar.fineWeight} ${bar.weightUnit}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(ChampagneGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = bar.status,
                                            color = AntiqueBronze,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.sp
                                        )
                                    }
                                }
                                Text(
                                    text = "S/N: ${bar.serialNumber} • ${bar.refiner}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "Garde: ${bar.vaultId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedFrenchBlue,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "$currencySymbol ${"%,.2f".format(bar.currentPriceEUR * (if(currencySymbol != "€") 1.085 else 1.0))}", // Simulated currency adjust
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Passeport ➔",
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AssetPassportView(
    bar: BarEntity,
    vaults: List<VaultEntity>,
    viewModel: PreciousMetalViewModel,
    onBack: () -> Unit
) {
    val currency by viewModel.selectedCurrency.collectAsState()
    val forex = viewModel.getForexRate()

    var showTransferDialog by remember { mutableStateOf(false) }
    var showDeliveryDialog by remember { mutableStateOf(false) }
    var showSellDialog by remember { mutableStateOf(false) }

    val currencySymbol = when(currency) {
        "EUR" -> "€"
        "USD" -> "$"
        "CHF" -> "CHF"
        "CAD" -> "CA$"
        "MAD" -> "MAD"
        "XOF" -> "F.CFA"
        "XAF" -> "F.CFA"
        else -> "€"
    }

    val moshi = Moshi.Builder().build()
    val timelineListType = Types.newParameterizedType(List::class.java, TimelineEvent::class.java)
    val adapter = moshi.adapter<List<TimelineEvent>>(timelineListType)
    val timelineEvents = remember(bar) {
        try {
            adapter.fromJson(bar.timelineJson) ?: emptyList()
        } catch(e: Exception) {
            emptyList()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
    ) {
        // Header back button
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onBack() }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Retour", tint = ChampagneGold)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Retour au portefeuille", style = MaterialTheme.typography.bodyLarge, color = ChampagneGold, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Title and Serial
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "PASSEPORT DE L'UNITÉ PHYSIQUE",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "LINGOT D'${if (bar.metal == "OR") "OR" else "ARGENT"} ${bar.fineWeight} ${bar.weightUnit.uppercase()}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "S/N: ${bar.serialNumber}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Monospace,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Divider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Poids Net", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.6f))
                            Text("${bar.fineWeight} ${bar.weightUnit}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column {
                            Text("Pureté Garantie", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.6f))
                            Text(bar.fineness, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column {
                            Text("Valeur Estimée", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.6f))
                            Text(
                                "$currencySymbol ${"%,.2f".format(bar.currentPriceEUR * forex)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = ChampagneGold
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showTransferDialog = true },
                    modifier = Modifier.weight(1f).height(40.dp).testTag("transfer_custody_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Transférer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showDeliveryDialog = true },
                    modifier = Modifier.weight(1f).height(40.dp).testTag("request_delivery_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MutedFrenchBlue)
                ) {
                    Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Se faire livrer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showSellDialog = true },
                    modifier = Modifier.weight(1f).height(40.dp).testTag("sell_dealer_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) {
                    Icon(imageVector = Icons.Default.Sell, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Revendre", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Details block
        item {
            Text(
                text = "SPÉCIFICATIONS TECHNIQUES D'ALLOCATION",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                DetailRow("Propriétaire enregistré", "FAMILLE DELORME")
                DetailRow("Raffineur d'origine", bar.refiner)
                DetailRow("Certificat d'essai n°", bar.certificateNo)
                DetailRow("Poids brut constaté", "${bar.grossWeight} ${bar.weightUnit}")
                DetailRow("Lieu d'allocation", bar.vaultId)
                DetailRow("Compartiment de garde", bar.compartment)
                DetailRow("Date du dernier audit", SimpleDateFormat("dd MMMM yyyy", Locale.FRANCE).format(Date(bar.lastUpdated)))
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Timeline Provenance Events
        item {
            Text(
                text = "PASSEPORT DE PROVENANCE ET HISTORIQUE DE CONSERVATION",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        items(timelineEvents.reversed()) { event ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(ChampagneGold, RoundedCornerShape(12.dp))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(2.dp)
                            .height(60.dp)
                            .background(Color.LightGray)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = event.eventType,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(event.timestamp)),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    Text(
                        text = "Lieu : ${event.location}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MutedFrenchBlue
                    )
                    Text(
                        text = "Opérateur : ${event.actor}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    Text(
                        text = "Détails : ${event.previousState} ➔ ${event.newState}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "Réf Document : ${event.documentRef} • Signature : ${event.authorizationSign}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 10.sp,
                        color = ChampagneGold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }

    // --- DIALOGS INTERACTION SIMULATION ---

    // 1. Transfer Dialog
    if (showTransferDialog) {
        var selectedDest by remember { mutableStateOf("CH-GENEVE-01") }
        AlertDialog(
            onDismissRequest = { showTransferDialog = false },
            title = { Text("Transférer la garde de l'unité") },
            text = {
                Column {
                    Text("Veuillez sélectionner le coffre-fort de destination sécurisé inter-juridiction. Brink's assurera le transport blindé sécurisé de l'unité.")
                    Spacer(modifier = Modifier.height(12.dp))
                    vaults.filter { it.id != bar.vaultId }.forEach { vault ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDest = vault.id }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedDest == vault.id, onClick = { selectedDest = vault.id })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(vault.name, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.transferCustody(bar.serialNumber, selectedDest) { success ->
                            showTransferDialog = false
                            onBack()
                        }
                    }
                ) {
                    Text("Confirmer le transfert physique")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTransferDialog = false }) { Text("Annuler") }
            }
        )
    }

    // 2. Delivery Dialog
    if (showDeliveryDialog) {
        var address by remember { mutableStateOf("Place Vendôme, 75001 Paris, France") }
        AlertDialog(
            onDismissRequest = { showDeliveryDialog = false },
            title = { Text("Demander une livraison physique assurée") },
            text = {
                Column {
                    Text("L'unité physique sera prélevée du coffre fort ${bar.vaultId}. Un transport blindé hautement sécurisé Loomis ou Brink's effectuera le transfert vers l'adresse indiquée ci-dessous.")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Adresse de destination blindée") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Note fiscale : Une taxe d'importation nationale peut s'appliquer en dehors des zones franches suisses.", color = Color.Red, fontSize = 10.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.requestPhysicalDelivery(bar.serialNumber, address) { success ->
                            showDeliveryDialog = false
                            onBack()
                        }
                    }
                ) {
                    Text("Déclencher la livraison blindée")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeliveryDialog = false }) { Text("Annuler") }
            }
        )
    }

    // 3. Sell Dialog
    if (showSellDialog) {
        val payout = bar.currentPriceEUR * 0.995 // 0.5% margin fee
        AlertDialog(
            onDismissRequest = { showSellDialog = false },
            title = { Text("Revendre l'unité d'or à la maison") },
            text = {
                Column {
                    Text("Vous demandez le rachat du lingot S/N : ${bar.serialNumber} par la Maison d'Or Aurum France.")
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Prix spot : ${"%,.2f".format(bar.currentPriceEUR)} EUR", fontWeight = FontWeight.Bold)
                    Text("Frais de liquidation de la maison : 0.5%", color = Color.Gray)
                    Text("Montant net estimé crédité sur votre compte espèces : ${"%,.2f".format(payout)} EUR", color = ChampagneGold, fontWeight = FontWeight.ExtraBold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.sellPhysicalBar(bar.serialNumber) { success ->
                            showSellDialog = false
                            onBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) {
                    Text("Confirmer la vente", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSellDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}
