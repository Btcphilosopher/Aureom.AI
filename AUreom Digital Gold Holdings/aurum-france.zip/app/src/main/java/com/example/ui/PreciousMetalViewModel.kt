package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PreciousMetalViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = PreciousMetalRepository(database.preciousMetalDao())

    // --- BASE FLOWS FROM DATABASE ---
    val bars = repository.allBars.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val vaults = repository.allVaults.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val orders = repository.allOrders.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val transactions = repository.allTransactions.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val reconciliations = repository.allReconciliations.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val complianceCases = repository.allComplianceCases.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // --- INTERACTIVE UI STATE ---
    private val _selectedCurrency = MutableStateFlow("EUR")
    val selectedCurrency: StateFlow<String> = _selectedCurrency.asStateFlow()

    private val _selectedJurisdiction = MutableStateFlow(Jurisdiction.FRANCE)
    val selectedJurisdiction: StateFlow<Jurisdiction> = _selectedJurisdiction.asStateFlow()

    // Prices (Triggering updates on tick)
    private val _goldSpotPrice = MutableStateFlow(2425.50)
    val goldSpotPrice: StateFlow<Double> = _goldSpotPrice.asStateFlow()

    private val _silverSpotPrice = MutableStateFlow(29.50)
    val silverSpotPrice: StateFlow<Double> = _silverSpotPrice.asStateFlow()

    // RFQ & Active Quote State
    private val _activeQuote = MutableStateFlow<OrderEntity?>(null)
    val activeQuote: StateFlow<OrderEntity?> = _activeQuote.asStateFlow()

    private val _quoteTimerSeconds = MutableStateFlow(0)
    val quoteTimerSeconds: StateFlow<Int> = _quoteTimerSeconds.asStateFlow()

    // AI Chat Messages
    data class ChatMessage(val sender: String, val message: String, val timestamp: Long = System.currentTimeMillis())
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("ai", "Bonjour, je suis l'assistant AURUM AI de la maison Aurum France. Comment puis-je vous renseigner aujourd'hui sur l'état physique de votre patrimoine, l'allocation de vos lingots ou la fiscalité de vos coffres-forts ?")
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    init {
        // Start live spot price ticking
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(12000) // Tick prices every 12 seconds
                repository.tickPrices()
                _goldSpotPrice.value = repository.getSpotPriceEUR(Metal.OR)
                _silverSpotPrice.value = repository.getSpotPriceEUR(Metal.ARGENT)
            }
        }
    }

    fun selectCurrency(currency: String) {
        _selectedCurrency.value = currency
    }

    fun selectJurisdiction(jurisdiction: Jurisdiction) {
        _selectedJurisdiction.value = jurisdiction
    }

    // --- SPOT CONVERSION HELPER ---
    fun getSpotConverted(metal: Metal, unit: String): Double {
        return repository.getSpotConverted(metal, unit, _selectedCurrency.value)
    }

    fun getForexRate(): Double {
        return repository.getForexRate(_selectedCurrency.value)
    }

    // --- REPOSITORY INTERFACES ---

    fun requestRFQ(productId: String, quantity: Int, targetVaultId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val orderId = repository.requestRFQ(
                clientName = "FAMILLE DELORME",
                productId = productId,
                quantity = quantity,
                targetVaultId = targetVaultId
            )
            // Fetch quote and set active
            val order = database.preciousMetalDao().getOrderById(orderId)
            _activeQuote.value = order
            
            // Start 60 second countdown
            _quoteTimerSeconds.value = 60
            while (_quoteTimerSeconds.value > 0 && _activeQuote.value?.status == "QUOTED") {
                delay(1000)
                _quoteTimerSeconds.value -= 1
            }
            if (_quoteTimerSeconds.value == 0 && _activeQuote.value?.status == "QUOTED") {
                // Expired
                _activeQuote.value?.let {
                    database.preciousMetalDao().updateOrder(it.copy(status = "EXPIRÉ"))
                }
                _activeQuote.value = null
            }
        }
    }

    fun acceptQuote(onSuccess: (Boolean) -> Unit) {
        val quote = _activeQuote.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.acceptQuotation(quote.id)
            _activeQuote.value = null
            _quoteTimerSeconds.value = 0
            launch(Dispatchers.Main) {
                onSuccess(success)
            }
        }
    }

    fun cancelActiveQuote() {
        _activeQuote.value = null
        _quoteTimerSeconds.value = 0
    }

    fun transferCustody(serialNumber: String, destVaultId: String, onFinished: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.transferCustody(serialNumber, destVaultId)
            launch(Dispatchers.Main) {
                onFinished(success)
            }
        }
    }

    fun requestPhysicalDelivery(serialNumber: String, destinationAddress: String, onFinished: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.requestPhysicalDelivery(serialNumber, destinationAddress)
            launch(Dispatchers.Main) {
                onFinished(success)
            }
        }
    }

    fun sellPhysicalBar(serialNumber: String, onFinished: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.sellPhysicalBar(serialNumber)
            launch(Dispatchers.Main) {
                onFinished(success)
            }
        }
    }

    fun triggerReconciliation(vaultId: String, inspectorName: String, onFinished: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = repository.triggerReconciliation(vaultId, inspectorName)
            launch(Dispatchers.Main) {
                onFinished("Le coffre-fort ${result.vaultId} a été audité avec succès. Statut: ${result.status}.")
            }
        }
    }

    // --- TAX ESTIMATION FOR DISPLAY ---
    fun estimateTaxForProduct(product: ProductSpecification, transactionType: String): CalculatedTaxEstimate {
        val currentCurrency = _selectedCurrency.value
        val currentJurisdiction = _selectedJurisdiction.value
        
        // Calculate total client product price in selected currency
        val calc = repository.calculateProductPrice(product, currentCurrency, currentJurisdiction.code)
        val taxCalc = repository.calculateTax(
            metal = product.metal,
            productType = if (product.id.contains("coin")) "COIN" else "BAR",
            price = calc.totalClientPrice,
            currency = currentCurrency,
            jurisdictionCode = currentJurisdiction.code,
            transactionType = transactionType
        )

        return CalculatedTaxEstimate(
            productPrice = calc.totalClientPrice,
            taxRate = taxCalc.taxRate,
            taxAmount = taxCalc.taxAmount,
            totalWithTax = calc.totalClientPrice + taxCalc.taxAmount,
            description = taxCalc.treatmentDescription,
            trace = taxCalc.trace
        )
    }

    // --- AI CHAT LOGIC ---
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage("user", text)
        _chatMessages.value = _chatMessages.value + userMsg
        
        _isAiLoading.value = true
        
        viewModelScope.launch(Dispatchers.IO) {
            val response = GeminiClient.askAurumAI(
                userMessage = text,
                currentBars = bars.value,
                vaults = vaults.value,
                transactions = transactions.value,
                goldSpotEUR = _goldSpotPrice.value,
                silverSpotEUR = _silverSpotPrice.value
            )
            launch(Dispatchers.Main) {
                _chatMessages.value = _chatMessages.value + ChatMessage("ai", response)
                _isAiLoading.value = false
            }
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage("ai", "Bonjour, je suis l'assistant AURUM AI de la maison Aurum France. Comment puis-je vous renseigner aujourd'hui sur l'état physique de votre patrimoine, l'allocation de vos lingots ou la fiscalité de vos coffres-forts ?")
        )
    }
}

data class CalculatedTaxEstimate(
    val productPrice: Double,
    val taxRate: Double,
    val taxAmount: Double,
    val totalWithTax: Double,
    val description: String,
    val trace: String
)
