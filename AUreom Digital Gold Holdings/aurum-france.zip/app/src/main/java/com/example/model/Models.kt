package com.example.model

enum class Metal(val code: String, val displayName: String, val defaultUnit: String) {
    OR("XAU", "Or Physique", "oz"),
    ARGENT("XAG", "Argent Physique", "kg")
}

enum class Jurisdiction(
    val code: String,
    val displayName: String,
    val currency: String,
    val taxRegime: String,
    val amlRegime: String,
    val custodyRules: String,
    val deliveryRules: String
) {
    FRANCE("FR", "France (Paris)", "EUR", "TVA Or d'investissement 0%, Taxe métaux précieux 11.5%", "TRACFIN / ACPR", "Garde physique allouée individuelle", "Livraison sécurisée sous 48h ou retrait coffre"),
    SUISSE("CH", "Suisse (Genève / Lausanne)", "CHF", "Zone franche sous douane (TVA 0% Argent)", "OBA-FINMA", "Coffres de haute sécurité certifiés", "Retrait sous douane ou livraison internationale"),
    BELGIQUE("BE", "Belgique (Bruxelles)", "EUR", "Régime d'exemption d'or d'investissement", "CTIF / SPF Economie", "Garde allouée nominative", "Livraison sécurisée par transporteur spécialisé"),
    LUXEMBOURG("LU", "Luxembourg", "EUR", "Cadre fiscal privilégié pour métaux précieux", "CSSF / CRF", "Coffres de banque privée prestigieuse", "Mise à disposition en salle des coffres"),
    CANADA("CA", "Canada (Montréal / Québec)", "CAD", "Taxation fédérale TPS/TVQ métaux d'investissement exemptés", "CANAFE", "Garde souveraine canadienne", "Livraison par transport blindé"),
    AFRIQUE_FRANCOPHONE("AFR", "Afrique Francophone (Abidjan / Casablanca / Dakar)", "XOF", "Tarif extérieur commun UEMOA / Législation nationale", "CENTIF", "Maison de dépôt sécurisée agréée", "Livraison sous douane ou retrait comptoir autorisé")
}

data class ProductSpecification(
    val id: String,
    val metal: Metal,
    val name: String,
    val weightValue: Double,
    val weightUnit: String,
    val fineness: String,
    val manufacturer: String,
    val defaultPremiumPercent: Double,
    val dimensions: String,
    val description: String
)

object BullionCatalog {
    val goldProducts = listOf(
        ProductSpecification("au-1g", Metal.OR, "Lingotin d'Or 1 g", 1.0, "g", "999,9", "Heraeus / Valcambi", 8.5, "15 x 8.5 x 0.5 mm", "Idéal pour débuter l'allocation physique fine."),
        ProductSpecification("au-10g", Metal.OR, "Lingotin d'Or 10 g", 10.0, "g", "999,9", "Metalor Switzerland", 4.2, "22 x 13.5 x 1.2 mm", "Compromis idéal entre liquidité et prime de fabrication."),
        ProductSpecification("au-1oz", Metal.OR, "Lingot d'Or 1 Once (31.1g)", 1.0, "oz", "999,9", "C. Hafner", 2.2, "41 x 24 x 1.8 mm", "L'once d'or d'investissement standardisée internationale."),
        ProductSpecification("au-100g", Metal.OR, "Lingot d'Or 100 g", 100.0, "g", "999,9", "Valcambi Suisse", 1.2, "45 x 26 x 3.0 mm", "Lingot d'or coulé avec certificat de pureté individuel."),
        ProductSpecification("au-1kg", Metal.OR, "Lingot d'Or 1 kg (Standard)", 1.0, "kg", "999,9", "Pamp Suisse", 0.48, "115 x 50 x 8.0 mm", "Maison de métaux précieux classique. Idéal pour grande réserve.")
    )

    val silverProducts = listOf(
        ProductSpecification("ag-1oz", Metal.ARGENT, "Pièce d'Argent 1 Once Philharmonique / Wiener", 1.0, "oz", "999,0", "Münze Österreich", 12.0, "37 x 3.2 mm", "Pièce d'argent d'investissement majeure."),
        ProductSpecification("ag-1kg", Metal.ARGENT, "Lingot d'Argent 1 kg", 1.0, "kg", "999,0", "Umicore EU", 6.5, "115 x 50 x 15 mm", "Format classique pour l'investisseur d'argent d'investissement."),
        ProductSpecification("ag-5kg", Metal.ARGENT, "Lingot d'Argent 5 kg", 5.0, "kg", "999,0", "Sempsa JP", 5.0, "165 x 75 x 35 mm", "Lingot industriel certifié LBMA pour détention de coffre."),
        ProductSpecification("ag-15kg", Metal.ARGENT, "Grande Barre d'Argent 15 kg", 15.0, "kg", "999,0", "Metalor", 4.0, "250 x 100 x 50 mm", "Barre industrielle pour garde de haute capacité.")
    )

    fun getProductById(id: String): ProductSpecification? {
        return (goldProducts + silverProducts).firstOrNull { it.id == id }
    }
}

data class TimelineEvent(
    val timestamp: Long,
    val eventType: String, // PRODUCTION, ASSAYAGE, CERTIFICATION, ENREGISTREMENT, ALLOCATION, TRANSFERT, LIVRAISON
    val location: String,
    val actor: String,
    val previousState: String,
    val newState: String,
    val documentRef: String,
    val authorizationSign: String
)
