package com.example.data

import com.example.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID
import kotlin.random.Random

class PreciousMetalRepository(private val dao: PreciousMetalDao) {

    val allBars: Flow<List<BarEntity>> = dao.getAllBars()
    val allVaults: Flow<List<VaultEntity>> = dao.getAllVaults()
    val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val allReconciliations: Flow<List<ReconciliationEntity>> = dao.getAllReconciliations()
    val allComplianceCases: Flow<List<ComplianceCaseEntity>> = dao.getAllComplianceCases()

    private val moshi = Moshi.Builder().build()
    private val timelineListType = Types.newParameterizedType(List::class.java, TimelineEvent::class.java)
    private val timelineAdapter = moshi.adapter<List<TimelineEvent>>(timelineListType)

    // --- LIVE PRICE ENGINE & MARKET FOREX ---
    // Spot base prices (EUR per ounce)
    private var baseGoldSpotEUR = 2425.50
    private var baseSilverSpotEUR = 29.50

    fun tickPrices() {
        // Organic minute-by-minute slight price fluctuation (0.05% max)
        val goldPct = 1.0 + (Random.nextDouble(-0.0005, 0.0005))
        val silverPct = 1.0 + (Random.nextDouble(-0.0008, 0.0008))
        baseGoldSpotEUR *= goldPct
        baseSilverSpotEUR *= silverPct
    }

    fun getSpotPriceEUR(metal: Metal): Double {
        return when (metal) {
            Metal.OR -> baseGoldSpotEUR
            Metal.ARGENT -> baseSilverSpotEUR
        }
    }

    // Live forex rates from EUR
    fun getForexRate(targetCurrency: String): Double {
        return when (targetCurrency) {
            "EUR" -> 1.0
            "USD" -> 1.085
            "CHF" -> 0.942
            "CAD" -> 1.482
            "MAD" -> 10.95
            "XOF" -> 655.957 // CFA Franc BCEAO (Fixed peg to EUR)
            "XAF" -> 655.957 // CFA Franc BEAC
            else -> 1.0
        }
    }

    // Convert ounce spot to various weight units and currencies
    fun getSpotConverted(metal: Metal, targetUnit: String, targetCurrency: String): Double {
        val spotOunceEUR = getSpotPriceEUR(metal)
        val exchangeRate = getForexRate(targetCurrency)

        // Convert ounce (31.1034768 g) to target unit
        val rawPriceEUR = when (targetUnit) {
            "oz" -> spotOunceEUR
            "g" -> spotOunceEUR / 31.1034768
            "kg" -> (spotOunceEUR / 31.1034768) * 1000.0
            else -> spotOunceEUR
        }
        return rawPriceEUR * exchangeRate
    }

    // --- PHYSICAL PREMIUM ENGINE ---
    data class CalculatedPremium(
        val metalBaseValue: Double,
        val fabricationCost: Double,
        val refinerPremium: Double,
        val dealerMargin: Double,
        val logisticsCost: Double,
        val totalClientPrice: Double,
        val totalPremiumPercent: Double
    )

    fun calculateProductPrice(
        product: ProductSpecification,
        currency: String,
        jurisdictionCode: String
    ): CalculatedPremium {
        val fx = getForexRate(currency)
        // Get base metal spot price in EUR for this product size
        val baseValueEUR = getSpotConverted(product.metal, product.weightUnit, "EUR") * product.weightValue
        
        // Define premium components based on product size (larger = lower premium %)
        val premiumFactor = product.defaultPremiumPercent / 100.0
        val fabPct = premiumFactor * 0.40
        val refinerPct = premiumFactor * 0.25
        val dealerPct = premiumFactor * 0.20
        val logisticsPct = premiumFactor * 0.15

        val fabCost = baseValueEUR * fabPct
        val refinerPrem = baseValueEUR * refinerPct
        val dealerMarg = baseValueEUR * dealerPct
        val logisticsC = baseValueEUR * logisticsPct
        val totalPremiumVal = fabCost + refinerPrem + dealerMarg + logisticsC

        val totalClientEUR = baseValueEUR + totalPremiumVal

        return CalculatedPremium(
            metalBaseValue = baseValueEUR * fx,
            fabricationCost = fabCost * fx,
            refinerPremium = refinerPrem * fx,
            dealerMargin = dealerMarg * fx,
            logisticsCost = logisticsC * fx,
            totalClientPrice = totalClientEUR * fx,
            totalPremiumPercent = product.defaultPremiumPercent
        )
    }

    // --- TAX ENGINE (JURISDICTION SPECIFIC) ---
    data class TaxCalculation(
        val taxRate: Double,
        val taxAmount: Double,
        val treatmentDescription: String,
        val trace: String
    )

    fun calculateTax(
        metal: Metal,
        productType: String, // BAR, COIN
        price: Double,
        currency: String,
        jurisdictionCode: String,
        transactionType: String // ACHAT, VENTE, LIVRAISON
    ): TaxCalculation {
        return when (jurisdictionCode) {
            "FR" -> {
                if (transactionType == "ACHAT") {
                    if (metal == Metal.OR) {
                        TaxCalculation(
                            taxRate = 0.0,
                            taxAmount = 0.0,
                            treatmentDescription = "Exonération de TVA en France pour l'Or d'investissement (Directives européennes).",
                            trace = "FR-TAX-OR-ACHAT: Article 298 sexdecies du CGI - TVA 0%."
                        )
                    } else {
                        TaxCalculation(
                            taxRate = 20.0,
                            taxAmount = price * 0.20,
                            treatmentDescription = "TVA de 20% applicable sur l'argent physique d'investissement en France.",
                            trace = "FR-TAX-AG-ACHAT: Article 256 du CGI - TVA standard 20%."
                        )
                    }
                } else {
                    // VENTE
                    TaxCalculation(
                        taxRate = 11.5,
                        taxAmount = price * 0.115,
                        treatmentDescription = "Taxe forfaitaire française sur les métaux précieux (TMP) de 11,5% ou régime de la plus-value réelle (36.2%).",
                        trace = "FR-TAX-VENTE: Article 150 VI à CGI. Prélèvement TMP libératoire de 11,5% calculé sur le prix de cession brut."
                    )
                }
            }
            "CH" -> {
                // Switzerland
                if (metal == Metal.OR) {
                    TaxCalculation(
                        taxRate = 0.0,
                        taxAmount = 0.0,
                        treatmentDescription = "Exonération totale d'impôts et TVA suisse sur l'or d'investissement.",
                        trace = "CH-TAX-OR: Exonéré sous législation fédérale LTVA."
                    )
                } else {
                    // Silver in Swiss Vaults (Freeport / Zollfreilager VAT Free)
                    TaxCalculation(
                        taxRate = 0.0,
                        taxAmount = 0.0,
                        treatmentDescription = "Exemption de TVA sur l'argent conservé en port franc sous douane (Zollfreilager/Genève).",
                        trace = "CH-TAX-AG-FREEPORT: Port franc de Genève sous douane, TVA 0% tant que le métal y réside."
                    )
                }
            }
            "BE" -> {
                // Belgium
                if (metal == Metal.OR) {
                    TaxCalculation(0.0, 0.0, "Exonération de TVA belge sur l'or d'investissement.", "BE-TAX-OR: Exemption Loi TVA Art 44 bis.")
                } else {
                    TaxCalculation(21.0, price * 0.21, "TVA standard de 21% sur l'argent en Belgique.", "BE-TAX-AG: Article 3 Code TVA belge.")
                }
            }
            "LU" -> {
                // Luxembourg
                if (metal == Metal.OR) {
                    TaxCalculation(0.0, 0.0, "Exonération de TVA luxembourgeoise.", "LU-TAX-OR: Loi TVA Grand-Duché.")
                } else {
                    TaxCalculation(17.0, price * 0.17, "TVA standard de 17% sur l'argent au Luxembourg.", "LU-TAX-AG: TVA de 17%.")
                }
            }
            "CA" -> {
                // Canada
                if (price > 0.0) {
                    TaxCalculation(
                        taxRate = 0.0,
                        taxAmount = 0.0,
                        treatmentDescription = "Métaux précieux d'une pureté minimale (Or >99.5%, Argent >99.0%) qualifiés comme services financiers exonérés de TPS/TVQ au Canada.",
                        trace = "CA-TAX-EXEMPT: Loi sur la taxe d'accise canadienne (LTA), fourniture exonérée."
                    )
                } else {
                    TaxCalculation(0.0, 0.0, "Pas de taxe.", "")
                }
            }
            "AFR" -> {
                // West Africa UEMOA
                if (transactionType == "ACHAT") {
                    TaxCalculation(
                        taxRate = 18.0,
                        taxAmount = price * 0.18,
                        treatmentDescription = "TVA harmonisée de 18% UEMOA applicable sur les importations et livraisons physiques hors zone d'exemption d'État.",
                        trace = "AFR-TAX-UEMOA: Code des Douanes de l'UEMOA - TVA 18%."
                    )
                } else {
                    TaxCalculation(5.0, price * 0.05, "Retenue fiscale nationale sur les transactions de métaux précieux.", "AFR-TAX-VENTE: Impôt sur le revenu des plus-values.")
                }
            }
            else -> TaxCalculation(0.0, 0.0, "Régime d'exemption de taxe territoriale générale.", "GEN-TAX: Exemption standard.")
        }
    }

    // --- REGULATORY COMPLIANCE LCB-FT ---
    fun runComplianceCheck(clientName: String, jurisdiction: Jurisdiction, amountEUR: Double): ComplianceCaseEntity {
        val riskFactor = if (amountEUR > 50000.0) 0.18 else 0.05
        val additionalFactor = if (jurisdiction == Jurisdiction.AFRIQUE_FRANCOPHONE) 0.12 else 0.02
        val finalRisk = riskFactor + additionalFactor

        val checksPassed = mutableListOf("KYC_IDENTITÉ_VÉRIFIÉ", "SANCTIONS_LIST_OFFAC_PASSED")
        if (jurisdiction.amlRegime.contains("TRACFIN")) {
            checksPassed.add("TRACFIN_AML_VÉRIFICATION")
        } else {
            checksPassed.add("LOCAL_AML_REGULATOR_VÉRIFICATION")
        }

        if (amountEUR > 15000.0) {
            checksPassed.add("ORIGINE_DES_FONDS_JUSTIFIÉE")
        }

        val checksJson = moshi.adapter<List<String>>(List::class.java).toJson(checksPassed)

        return ComplianceCaseEntity(
            timestamp = System.currentTimeMillis(),
            clientName = clientName,
            jurisdictionCode = jurisdiction.code,
            riskScore = finalRisk,
            status = if (finalRisk > 0.25) "SURVEILLANCE_TRACFIN" else "APPROUVÉ",
            checksPassedJson = checksJson,
            notes = "Contrôle automatique de conformité Aurum LCB-FT. Montant: ${"%,.2f".format(amountEUR)} EUR. Évaluation du profil de risque: ${if (finalRisk > 0.25) "Élevé - Transmission Tracfin simulée" else "Faible - Prêt pour exécution"}"
        )
    }

    // --- RFQ WORKFLOW (RFQ -> Quote -> Purchase) ---
    suspend fun requestRFQ(
        clientName: String,
        productId: String,
        quantity: Int,
        targetVaultId: String
    ): Long {
        val product = BullionCatalog.getProductById(productId) ?: throw IllegalArgumentException("Produit inconnu")
        val vault = dao.getVaultById(targetVaultId) ?: throw IllegalArgumentException("Coffre inconnu")
        val jurisdiction = Jurisdiction.values().first { it.code == vault.jurisdictionCode }

        // Calculate dynamic pricing
        val calc = calculateProductPrice(product, jurisdiction.currency, jurisdiction.code)
        val singlePrice = calc.totalClientPrice
        val totalPrice = singlePrice * quantity

        val rfvCode = "RFQ-${UUID.randomUUID().toString().take(8).uppercase()}"

        val order = OrderEntity(
            clientName = clientName,
            metal = product.metal.name,
            productId = productId,
            productName = product.name,
            weight = product.weightValue,
            weightUnit = product.weightUnit,
            quantity = quantity,
            baseMetalPriceEUR = calc.metalBaseValue / getForexRate(jurisdiction.currency),
            premiumPriceEUR = (calc.totalClientPrice - calc.metalBaseValue) / getForexRate(jurisdiction.currency),
            totalPriceEUR = totalPrice / getForexRate(jurisdiction.currency),
            currency = jurisdiction.currency,
            targetVaultId = targetVaultId,
            status = "QUOTED", // RFQ immediately returns a Quote for the client
            quoteExpirationTime = System.currentTimeMillis() + 60000, // Valid for 60 seconds
            rfvCode = rfvCode
        )

        val orderId = dao.insertOrder(order)
        return orderId
    }

    suspend fun acceptQuotation(orderId: Long): Boolean {
        val order = dao.getOrderById(orderId) ?: return false
        if (order.status != "QUOTED") return false
        if (System.currentTimeMillis() > order.quoteExpirationTime) {
            dao.updateOrder(order.copy(status = "EXPIRÉ"))
            return false
        }

        // 1. Perform Compliance check in background
        val vault = dao.getVaultById(order.targetVaultId) ?: return false
        val jurisdiction = Jurisdiction.values().first { it.code == vault.jurisdictionCode }
        val compCase = runComplianceCheck(order.clientName, jurisdiction, order.totalPriceEUR)
        dao.insertComplianceCase(compCase)

        if (compCase.status == "SURVEILLANCE_TRACFIN") {
            dao.updateOrder(order.copy(status = "BLOQUÉ_CONFORMITÉ"))
            return false
        }

        // 2. Accept Quote & Perform Physical Bar Allocation!
        val updatedOrder = order.copy(status = "ACCEPTED")
        dao.updateOrder(updatedOrder)

        // Generate and allocate physical bars
        val product = BullionCatalog.getProductById(order.productId) ?: return false
        
        for (i in 1..order.quantity) {
            val serialNo = "AU-${jurisdiction.code}-${System.currentTimeMillis().toString().takeLast(6)}-${Random.nextInt(1000, 9999)}"
            val certNo = "CERT-${UUID.randomUUID().toString().take(6).uppercase()}"
            
            // Build timeline provenance
            val timelineEvents = listOf(
                TimelineEvent(
                    timestamp = System.currentTimeMillis() - 86400000 * 3,
                    eventType = "PRODUCTION",
                    location = product.manufacturer,
                    actor = product.manufacturer,
                    previousState = "N/A",
                    newState = "MÉTAL_FIN_FUSIONNÉ",
                    documentRef = certNo,
                    authorizationSign = "SIG-REFINER-LBMA"
                ),
                TimelineEvent(
                    timestamp = System.currentTimeMillis() - 86400000,
                    eventType = "ASSAYAGE",
                    location = "Laboratoire National d'Essai",
                    actor = "Bureau des Métaux",
                    previousState = "MÉTAL_FIN_FUSIONNÉ",
                    newState = "PURETÉ_ESSAYÉE_${product.fineness}",
                    documentRef = "ASS-TEST-${serialNo}",
                    authorizationSign = "SIG-ASSAYER"
                ),
                TimelineEvent(
                    timestamp = System.currentTimeMillis(),
                    eventType = "ALLOCATION",
                    location = vault.city,
                    actor = "Aurum France Custody Agent",
                    previousState = "RÉSERVE_BULLION_GÉNÉRALE",
                    newState = "ALLOUÉ_PATRIMOINE_NOMINATIF",
                    documentRef = "ALLOC-CERT-${orderId}",
                    authorizationSign = "SIG-CUSTODY-${vault.id}"
                )
            )

            val fineWeight = if (product.weightUnit == "oz") product.weightValue else {
                // If in grams or kg, let's keep units matching
                product.weightValue
            }

            val allocatedBar = BarEntity(
                serialNumber = serialNo,
                metal = order.metal,
                productId = order.productId,
                refiner = product.manufacturer,
                grossWeight = product.weightValue * 1.002, // Gross weight is slightly more than fine weight due to fineness/alloying
                fineWeight = fineWeight,
                weightUnit = product.weightUnit,
                fineness = product.fineness,
                status = "CONSERVATION",
                vaultId = order.targetVaultId,
                ownerId = "CLIENT-DELORME", // Default demo client
                certificateNo = certNo,
                assayDate = System.currentTimeMillis() - 86400000,
                compartment = "Compartiment Privé Delorme C01",
                currentPriceEUR = (order.totalPriceEUR / order.quantity),
                timelineJson = timelineAdapter.toJson(timelineEvents)
            )
            
            dao.insertBar(allocatedBar)

            // Log corresponding ledger Transaction
            val tx = TransactionEntity(
                timestamp = System.currentTimeMillis(),
                type = "ACHAT",
                metal = order.metal,
                amount = fineWeight,
                unit = product.weightUnit,
                valueEUR = order.totalPriceEUR / order.quantity,
                status = "COMPLÉTÉ",
                serialNumber = serialNo,
                sourceVaultId = "MARCHÉ-OR-PHYSIQUE",
                destVaultId = order.targetVaultId,
                details = "Achat alloué individuel du lingot de pureté ${product.fineness}. Réf Ordre: ${order.rfvCode}",
                auditHash = "AUDIT-${UUID.randomUUID().toString().take(12).uppercase()}"
            )
            dao.insertTransaction(tx)
        }

        // 3. Update Vault occupied capacity
        val productWeightKg = if (product.weightUnit == "kg") {
            product.weightValue * order.quantity
        } else if (product.weightUnit == "g") {
            (product.weightValue * order.quantity) / 1000.0
        } else {
            // ounce to kg (1 oz = 0.0311035 kg)
            (product.weightValue * order.quantity) * 0.0311035
        }

        val updatedVault = vault.copy(
            occupiedKg = vault.occupiedKg + productWeightKg,
            allocatedMetalKg = vault.allocatedMetalKg + productWeightKg
        )
        dao.updateVault(updatedVault)

        // Mark order as DELIVERED in the vault storage
        dao.updateOrder(updatedOrder.copy(status = "DELIVERED"))

        return true
    }

    // --- CUSTODY TRANSFER WORKFLOW (Paris -> Genève, etc.) ---
    suspend fun transferCustody(serialNumber: String, destVaultId: String): Boolean {
        val bar = dao.getBarBySerialNumber(serialNumber) ?: return false
        val sourceVault = dao.getVaultById(bar.vaultId) ?: return false
        val destVault = dao.getVaultById(destVaultId) ?: return false
        if (sourceVault.id == destVaultId) return false

        // 1. Perform LCB-FT check for crossing jurisdictions
        val jurisdictionDest = Jurisdiction.values().first { it.code == destVault.jurisdictionCode }
        val barValueEUR = bar.currentPriceEUR
        val compCase = runComplianceCheck(bar.ownerId, jurisdictionDest, barValueEUR)
        dao.insertComplianceCase(compCase)

        if (compCase.status == "SURVEILLANCE_TRACFIN") {
            return false // Suspended due to regional AML review
        }

        // 2. Add Timeline Event to the Bar's Passport
        val currentTimeline = timelineAdapter.fromJson(bar.timelineJson)?.toMutableList() ?: mutableListOf()
        val transferEvent = TimelineEvent(
            timestamp = System.currentTimeMillis(),
            eventType = "TRANSFERT",
            location = "${sourceVault.city} ➔ ${destVault.city}",
            actor = "Aurum Secure Transit (Brink's / Loomis)",
            previousState = "GARDE_CONSERVATION_${sourceVault.id}",
            newState = "GARDE_CONSERVATION_${destVault.id}",
            documentRef = "TRANS-WAYBILL-${UUID.randomUUID().toString().take(6).uppercase()}",
            authorizationSign = "SIG-TRANSIT-SECURE"
        )
        currentTimeline.add(transferEvent)

        // 3. Update Bar's location state
        val updatedBar = bar.copy(
            vaultId = destVaultId,
            timelineJson = timelineAdapter.toJson(currentTimeline),
            lastUpdated = System.currentTimeMillis()
        )
        dao.updateBar(updatedBar)

        // 4. Update Vault capacities (move weights)
        val weightKg = if (bar.weightUnit == "kg") {
            bar.fineWeight
        } else if (bar.weightUnit == "g") {
            bar.fineWeight / 1000.0
        } else {
            bar.fineWeight * 0.0311035
        }

        // Subtract from source vault
        dao.updateVault(sourceVault.copy(
            occupiedKg = (sourceVault.occupiedKg - weightKg).coerceAtLeast(0.0),
            allocatedMetalKg = (sourceVault.allocatedMetalKg - weightKg).coerceAtLeast(0.0)
        ))

        // Add to destination vault
        dao.updateVault(destVault.copy(
            occupiedKg = destVault.occupiedKg + weightKg,
            allocatedMetalKg = destVault.allocatedMetalKg + weightKg
        ))

        // 5. Log General Ledger Transaction
        val tx = TransactionEntity(
            timestamp = System.currentTimeMillis(),
            type = "TRANSFERT",
            metal = bar.metal,
            amount = bar.fineWeight,
            unit = bar.weightUnit,
            valueEUR = bar.currentPriceEUR,
            status = "COMPLÉTÉ",
            serialNumber = bar.serialNumber,
            sourceVaultId = sourceVault.id,
            destVaultId = destVault.id,
            details = "Transfert physique inter-coffres sécurisé de ${sourceVault.city} à ${destVault.city}.",
            auditHash = "AUDIT-TRANS-${UUID.randomUUID().toString().take(8).uppercase()}"
        )
        dao.insertTransaction(tx)

        return true
    }

    // --- SECURE PHYSICAL WITHDRAWAL / DELIVERY ---
    suspend fun requestPhysicalDelivery(serialNumber: String, destinationAddress: String): Boolean {
        val bar = dao.getBarBySerialNumber(serialNumber) ?: return false
        val sourceVault = dao.getVaultById(bar.vaultId) ?: return false

        // Mark bar as LIVRÉ (withdrawn from custody)
        val currentTimeline = timelineAdapter.fromJson(bar.timelineJson)?.toMutableList() ?: mutableListOf()
        val deliveryEvent = TimelineEvent(
            timestamp = System.currentTimeMillis(),
            eventType = "LIVRAISON",
            location = destinationAddress,
            actor = "Securitas Direct / Client handoff",
            previousState = "CONSERVATION_COFFRE",
            newState = "RETIRE_DU_COFFRE_LIVRÉ",
            documentRef = "DELIV-CONF-${UUID.randomUUID().toString().take(6).uppercase()}",
            authorizationSign = "SIG-CLIENT-RECEPTION"
        )
        currentTimeline.add(deliveryEvent)

        val updatedBar = bar.copy(
            status = "LIVRÉ",
            timelineJson = timelineAdapter.toJson(currentTimeline),
            lastUpdated = System.currentTimeMillis()
        )
        // We delete or update the bar status to LIVRÉ so it no longer shows up in vault inventory, but remains in the historical passport!
        dao.updateBar(updatedBar)

        // Update Vault weights
        val weightKg = if (bar.weightUnit == "kg") {
            bar.fineWeight
        } else if (bar.weightUnit == "g") {
            bar.fineWeight / 1000.0
        } else {
            bar.fineWeight * 0.0311035
        }

        dao.updateVault(sourceVault.copy(
            occupiedKg = (sourceVault.occupiedKg - weightKg).coerceAtLeast(0.0),
            allocatedMetalKg = (sourceVault.allocatedMetalKg - weightKg).coerceAtLeast(0.0)
        ))

        // Log transaction
        val tx = TransactionEntity(
            timestamp = System.currentTimeMillis(),
            type = "LIVRAISON",
            metal = bar.metal,
            amount = bar.fineWeight,
            unit = bar.weightUnit,
            valueEUR = bar.currentPriceEUR,
            status = "COMPLÉTÉ",
            serialNumber = bar.serialNumber,
            sourceVaultId = sourceVault.id,
            destVaultId = "DESTINATION-CLIENT-PHYSIQUE",
            details = "Prélèvement physique du coffre et livraison sécurisée à l'adresse indiquée.",
            auditHash = "AUDIT-DELIV-${UUID.randomUUID().toString().take(8).uppercase()}"
        )
        dao.insertTransaction(tx)

        return true
    }

    // --- SECURE PHYSICAL SALE ---
    suspend fun sellPhysicalBar(serialNumber: String): Boolean {
        val bar = dao.getBarBySerialNumber(serialNumber) ?: return false
        val sourceVault = dao.getVaultById(bar.vaultId) ?: return false

        // Mark bar as SOLD
        val currentTimeline = timelineAdapter.fromJson(bar.timelineJson)?.toMutableList() ?: mutableListOf()
        val saleEvent = TimelineEvent(
            timestamp = System.currentTimeMillis(),
            eventType = "VENTE",
            location = "Comptoir Central de Paris",
            actor = "Aurum France Liquidations",
            previousState = "GARDE_CONSERVATION",
            newState = "LIQUIDÉ_VENTE_COMPTOIR",
            documentRef = "SALE-LIQUID-${UUID.randomUUID().toString().take(6).uppercase()}",
            authorizationSign = "SIG-LIQUIDATION-OFFICIER"
        )
        currentTimeline.add(saleEvent)

        val updatedBar = bar.copy(
            status = "VENDU",
            timelineJson = timelineAdapter.toJson(currentTimeline),
            lastUpdated = System.currentTimeMillis()
        )
        dao.updateBar(updatedBar)

        // Update Vault weights
        val weightKg = if (bar.weightUnit == "kg") {
            bar.fineWeight
        } else if (bar.weightUnit == "g") {
            bar.fineWeight / 1000.0
        } else {
            bar.fineWeight * 0.0311035
        }

        dao.updateVault(sourceVault.copy(
            occupiedKg = (sourceVault.occupiedKg - weightKg).coerceAtLeast(0.0),
            allocatedMetalKg = (sourceVault.allocatedMetalKg - weightKg).coerceAtLeast(0.0)
        ))

        // Log Transaction
        val tx = TransactionEntity(
            timestamp = System.currentTimeMillis(),
            type = "VENTE",
            metal = bar.metal,
            amount = bar.fineWeight,
            unit = bar.weightUnit,
            valueEUR = bar.currentPriceEUR,
            status = "COMPLÉTÉ",
            serialNumber = bar.serialNumber,
            sourceVaultId = sourceVault.id,
            destVaultId = "MARCHÉ-LIQUIDATIONS",
            details = "Rachat par la maison de métaux précieux. Plus-values de cession calculées.",
            auditHash = "AUDIT-SALE-${UUID.randomUUID().toString().take(8).uppercase()}"
        )
        dao.insertTransaction(tx)

        return true
    }

    // --- TRIGGER DAILY RECONCILIATION AUDIT ---
    suspend fun triggerReconciliation(vaultId: String, inspectorName: String): ReconciliationEntity {
        val vault = dao.getVaultById(vaultId) ?: throw IllegalArgumentException("Coffre introuvable")

        // Sum physical bars currently in the database for this vault
        val barsInVault = dao.getAllBars().first().filter { it.vaultId == vaultId && it.status == "CONSERVATION" }
        
        var calculatedFineWeightKg = 0.0
        for (bar in barsInVault) {
            val barWeightKg = if (bar.weightUnit == "kg") {
                bar.fineWeight
            } else if (bar.weightUnit == "g") {
                bar.fineWeight / 1000.0
            } else {
                bar.fineWeight * 0.0311035
            }
            calculatedFineWeightKg += barWeightKg
        }

        // Add seeded unallocated pool weight to match registry (simulate exact total)
        val expectedWeight = vault.allocatedMetalKg + vault.unallocatedMetalKg
        // For simulation, let's say physical weighing has 100% precision
        val physicalWeight = expectedWeight

        val rec = ReconciliationEntity(
            date = System.currentTimeMillis(),
            vaultId = vaultId,
            expectedWeightKg = expectedWeight,
            registeredWeightKg = expectedWeight,
            physicalWeightKg = physicalWeight,
            status = "RÉCONCILIÉ",
            inspectorName = inspectorName,
            notes = "Contrôle d'audit physique hebdomadaire. Comptage complet de ${barsInVault.size} lingots physiques alloués spécifiques. Correspondance parfaite avec le registre informatique."
        )
        dao.insertReconciliation(rec)
        return rec
    }
}
