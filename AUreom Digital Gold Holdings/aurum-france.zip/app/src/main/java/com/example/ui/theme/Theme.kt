package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = LightGold,
    onPrimary = DeepNavyPrimary,
    secondary = MutedFrenchBlue,
    onSecondary = IvoryText,
    tertiary = ChampagneGold,
    background = CharcoalBackground,
    onBackground = IvoryText,
    surface = GraphiteSurface,
    onSurface = IvoryText,
    surfaceVariant = Color(0xFF1E2127),
    onSurfaceVariant = WarmGreyText
)

private val LightColorScheme = lightColorScheme(
    primary = DeepNavyPrimary,
    onPrimary = WarmWhiteSurface,
    secondary = MutedFrenchBlue,
    onSecondary = WarmWhiteSurface,
    tertiary = ChampagneGold,
    onTertiary = DeepNavyPrimary,
    background = IvoryBackground,
    onBackground = DeepNavyPrimary,
    surface = WarmWhiteSurface,
    onSurface = DeepNavyPrimary,
    surfaceVariant = Color(0xFFF0EDE7),
    onSurfaceVariant = AntiqueBronze
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We default dynamicColor to false to enforce our prestigious, hand-crafted branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
