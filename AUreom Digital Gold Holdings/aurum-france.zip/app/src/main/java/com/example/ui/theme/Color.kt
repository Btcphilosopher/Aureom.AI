package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette (Ivory, Warm White, Deep Navy, Champagne Gold, Antique Bronze)
val IvoryBackground = Color(0xFFFAF8F5) // Refined warm background
val WarmWhiteSurface = Color(0xFFFFFFFF) // Pristine surface
val DeepNavyPrimary = Color(0xFF0F1E36) // Prestine Parisian blue
val MutedFrenchBlue = Color(0xFF4A607A) // Secondary brand color
val ChampagneGold = Color(0xFFC5A059) // Metallic gold accent (used sparingly)
val AntiqueBronze = Color(0xFF8A7355) // Warm metal secondary
val DarkBurgundy = Color(0xFF42101B) // Accents and alert highlights

// Dark Theme Palette (Charcoal, Graphite, Deep Navy, Champagne Gold)
val CharcoalBackground = Color(0xFF0D0F12) // Rich dark background
val GraphiteSurface = Color(0xFF15181E) // Dark elevation surface
val IvoryText = Color(0xFFF5F2EB) // Warm off-white text
val WarmGreyText = Color(0xFF9EA3AC) // Muted label text
val LightGold = Color(0xFFDFBF82) // Brighter gold for dark readability
val MutedBronze = Color(0xFF6E5D46) // Muted dark metal accent
