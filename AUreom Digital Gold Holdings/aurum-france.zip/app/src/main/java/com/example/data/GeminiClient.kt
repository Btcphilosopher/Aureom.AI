package com.example.data

import com.example.BuildConfig
import com.example.model.Metal
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request / Response Data Classes (Moshi Compatible) ---

data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

data class GeminiGenerationConfig(
    @Json(name = "temperature") val temperature: Float? = 0.2f, // Low temperature for high precision
    @Json(name = "topP") val topP: Float? = 0.95f
)

data class GeminiGenerateRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)

data class GeminiGenerateResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

// --- Retrofit Interface ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiGenerateRequest
    ): GeminiGenerateResponse
}

// --- Singleton Client ---

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    /**
     * Contextual prompt generation using live application state as system instructions.
     */
    suspend fun askAurumAI(
        userMessage: String,
        currentBars: List<BarEntity>,
        vaults: List<VaultEntity>,
        transactions: List<TransactionEntity>,
        goldSpotEUR: Double,
        silverSpotEUR: Double
    ): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "YOUR_GEMINI_API_KEY") {
            return "Note : L'assistant AURUM AI requiert une clé API Gemini configurée dans le panneau Secrets d'AI Studio.\n\n" +
                   "Simulation de réponse locale (Hors-ligne):\n" +
                   "« En tant que conseiller virtuel d'Aurum France, je vois que votre patrimoine s'élève à ${"%,.2f".format(currentBars.sumOf { it.currentPriceEUR })} EUR, " +
                   "réparti sur ${vaults.size} coffres-forts ultra-sécurisés (Paris, Genève, Bruxelles, Montréal). »"
        }

        // Build precise system context based on live DB state
        val barsSummary = currentBars.filter { it.status == "CONSERVATION" }.mapIndexed { i, bar ->
            "- Lingot ${bar.serialNumber}: ${bar.fineWeight} ${bar.weightUnit} de ${bar.metal} (${bar.refiner}, pureté ${bar.fineness}), situé à ${bar.vaultId}. Valeur estimée: ${"%,.2f".format(bar.currentPriceEUR)} EUR. Certificat: ${bar.certificateNo}."
        }.joinToString("\n")

        val vaultsSummary = vaults.map { v ->
            "- Coffre ${v.id} (${v.name} à ${v.city}): Capacité totale de ${v.capacityKg} kg. Métal alloué: ${v.allocatedMetalKg} kg. Métal non-alloué: ${v.unallocatedMetalKg} kg. Assureur: ${v.insuranceCompany}."
        }.joinToString("\n")

        val txSummary = transactions.take(10).map { tx ->
            "- ${tx.type} de ${tx.amount} ${tx.unit} de ${tx.metal} le ${java.text.SimpleDateFormat("dd/MM/yyyy").format(java.util.Date(tx.timestamp))}. Valeur: ${"%,.2f".format(tx.valueEUR)} EUR. Statut: ${tx.status}."
        }.joinToString("\n")

        val systemPrompt = """
            Vous êtes "AURUM AI", l'assistant d'élite de la prestigieuse maison de métaux précieux "AURUM FRANCE".
            Votre rôle est de répondre de manière extrêmement professionnelle, élégante, précise et courtoise aux questions des conseillers et clients de la Famille Delorme.
            Vous vous exprimez dans un français impeccable et soigné d'un banquier privé parisien.
            
            DONNÉES DU PATRIMOINE RÉEL DU CLIENT (Utilisez UNIQUEMENT ces faits. Ne les inventez jamais !) :
            Cours de Référence Spot de l'Or: ${"%,.2f".format(goldSpotEUR)} EUR / oz
            Cours de Référence Spot de l'Argent: ${"%,.2f".format(silverSpotEUR)} EUR / oz
            
            LINGOTS PHYSIQUES ALLOUÉS DU CLIENT EN GARDE :
            $barsSummary
            
            REPRÉSENTATION DU RÉSEAU DE COFFRES (VOS COFFRES-FORTS) :
            $vaultsSummary
            
            HISTORIQUE DES 10 DERNIÈRES OPÉRATIONS :
            $txSummary
            
            CONSIGNES CRITIQUES :
            1. Ne fabriquez jamais de lingots, de balances, de coffres, d'opérations ou d'informations fiscales.
            2. Si le client pose une question en dehors de ces données, répondez poliment que vous n'avez accès qu'aux registres physiques certifiés de sa famille.
            3. Mentionnez toujours les numéros de série des lingots ou les noms des coffres pour prouver l'exactitude physique de l'allocation.
            4. Le métal physique est au centre de notre philosophie: "L'OR EST PHYSIQUE. LA PROPRIÉTÉ EST PRÉCISE. LA GARDE EST TRAÇABLE."
        """.trimIndent()

        val request = GeminiGenerateRequest(
            contents = listOf(
                GeminiContent(parts = listOf(GeminiPart(text = userMessage)))
            ),
            generationConfig = GeminiGenerationConfig(temperature = 0.2f),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
        )

        return try {
            val response = service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "L'assistant AURUM AI n'a pas pu générer de réponse."
        } catch (e: Exception) {
            "Erreur lors de la communication avec l'assistant: ${e.localizedMessage ?: e.message}"
        }
    }
}
