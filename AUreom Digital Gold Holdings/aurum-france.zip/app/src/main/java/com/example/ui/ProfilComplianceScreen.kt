package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Jurisdiction
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MutedFrenchBlue
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfilComplianceScreen(viewModel: PreciousMetalViewModel) {
    val complianceCases by viewModel.complianceCases.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0 = Aurum AI, 1 = Fiscalité & Jurisdictions, 2 = Conformité LCB-FT

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profil_compliance_screen")
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub Tabs
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                SubTabChip(
                    text = "Aurum AI Conseiller",
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 }
                )
            }
            item {
                SubTabChip(
                    text = "Fiscalité & Régions",
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 }
                )
            }
            item {
                SubTabChip(
                    text = "Conformité LCB-FT",
                    selected = activeSubTab == 2,
                    onClick = { activeSubTab = 2 }
                )
            }
        }

        when (activeSubTab) {
            0 -> AurumAiTab(chatMessages, isAiLoading, onSendMessage = { viewModel.sendChatMessage(it) }, onClear = { viewModel.clearChat() })
            1 -> FiscaliteTab(viewModel)
            2 -> ComplianceTab(complianceCases)
        }
    }
}

@Composable
fun SubTabChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) ChampagneGold else Color.White.copy(alpha = 0.12f))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (selected) MaterialTheme.colorScheme.primary else Color.White
        )
    }
}

// --- TAB 1: AURUM AI CHAT ASSISTANT ---
@Composable
fun AurumAiTab(
    messages: List<PreciousMetalViewModel.ChatMessage>,
    isLoading: Boolean,
    onSendMessage: (String) -> Unit,
    onClear: () -> Unit
) {
    var textState by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CONSEILLER PATRIMONIAL INTELLIGENT AURUM AI",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            TextButton(onClick = onClear) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp), tint = ChampagneGold)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Effacer", color = ChampagneGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Chat Bubble Column
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f))
                .padding(8.dp)
        ) {
            val listState = remember { androidx.compose.foundation.lazy.LazyListState() }
            LaunchedEffect(messages.size) {
                if (messages.isNotEmpty()) {
                    listState.animateScrollToItem(messages.size - 1)
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages) { msg ->
                    val isAi = msg.sender == "ai"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End
                    ) {
                        Card(
                            modifier = Modifier
                                .widthIn(max = 280.dp)
                                .testTag(if (isAi) "ai_message_bubble" else "user_message_bubble"),
                            shape = RoundedCornerShape(
                                topStart = 12.dp,
                                topEnd = 12.dp,
                                bottomStart = if (isAi) 2.dp else 12.dp,
                                bottomEnd = if (isAi) 12.dp else 2.dp
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isAi) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primary
                            ),
                            border = if (isAi) BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.3f)) else null
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isAi) "AURUM AI" else "FAMILLE DELORME",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isAi) ChampagneGold else ChampagneGold,
                                    fontSize = 9.sp,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = msg.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isAi) MaterialTheme.colorScheme.onSurface else Color.White
                                )
                            }
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = ChampagneGold,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Recherche certifiée dans les registres physiques...", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textState,
                onValueChange = { textState = it },
                placeholder = { Text("Posez votre question (ex: Quels sont mes lingots à Paris ?)", fontSize = 12.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ChampagneGold,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                ),
                maxLines = 2
            )

            IconButton(
                onClick = {
                    if (textState.isNotBlank()) {
                        onSendMessage(textState)
                        textState = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .size(48.dp)
                    .testTag("chat_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Envoyer", tint = Color.White)
            }
        }
    }
}

// --- TAB 2: FISCALITÉ ET JURIDICTIONS ---
@Composable
fun FiscaliteTab(viewModel: PreciousMetalViewModel) {
    val selectedJurisdiction by viewModel.selectedJurisdiction.collectAsState()

    var dropdownExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "CONSEILLER FISCAL ET RÉGLEMENTAIRE MUTLI-JURIDICTIONS",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Avis consultatif. Ne constitue pas un conseil d'investissement formel.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Red,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Selector
            Text("Sélectionnez une Juridiction Francophone", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Gray)
            Spacer(modifier = Modifier.height(6.dp))

            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, ChampagneGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { dropdownExpanded = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(selectedJurisdiction.displayName, fontWeight = FontWeight.Bold)
                        Text("Devise : ${selectedJurisdiction.currency} • Cadre : ${selectedJurisdiction.amlRegime}", style = MaterialTheme.typography.bodySmall, color = MutedFrenchBlue)
                    }
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = ChampagneGold)
                }

                DropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                ) {
                    Jurisdiction.values().forEach { jur ->
                        DropdownMenuItem(
                            text = { Text(jur.displayName, fontWeight = FontWeight.Bold) },
                            onClick = {
                                viewModel.selectJurisdiction(jur)
                                dropdownExpanded = false
                            }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Display Rules
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "RÉGIME FISCAL TERRITORIAL - ${selectedJurisdiction.displayName.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    DetailFiscalRow("Régime de taxe sur métaux précieux", selectedJurisdiction.taxRegime)
                    DetailFiscalRow("Organisme de contrôle LCB-FT", selectedJurisdiction.amlRegime)
                    DetailFiscalRow("Règles de détention en coffre", selectedJurisdiction.custodyRules)
                    DetailFiscalRow("Règles de prélèvement physique", selectedJurisdiction.deliveryRules)
                }
            }
        }
    }
}

@Composable
fun DetailFiscalRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MutedFrenchBlue)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        Divider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(top = 8.dp))
    }
}

// --- TAB 3: CONFORMITÉ LCB-FT ---
@Composable
fun ComplianceTab(cases: List<com.example.data.ComplianceCaseEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "CADRE DE CONFORMITÉ ET SÉCURITÉ FINANCIÈRE (LCB-FT)",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "La maison Aurum France applique rigoureusement les principes sectoriels de l'ACPR et de TRACFIN concernant le négoce physique de métaux précieux.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        items(cases) { c ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = c.clientName, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Box(
                            modifier = Modifier
                                .background(
                                    if (c.status == "APPROUVÉ") Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFC62828).copy(alpha = 0.15f),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(text = c.status, color = if (c.status == "APPROUVÉ") Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Réf Juridiction : ${c.jurisdictionCode} • Score de Risque : ${"%,.2f".format(c.riskScore * 100)} %", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text(text = c.notes, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp))

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "CONTRÔLES AUTOMATIQUES EFFECTUÉS :", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ChampagneGold)
                    Text(text = c.checksPassedJson, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MutedFrenchBlue)
                }
            }
        }
    }
}
