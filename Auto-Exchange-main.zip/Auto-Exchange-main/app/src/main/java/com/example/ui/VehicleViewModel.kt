package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class VehicleViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AureliaDatabase.getDatabase(application, viewModelScope)
    private val repository = VehicleRepository(database.vehicleDao())

    // 1. Raw flows from DB
    val marketplaceListings: StateFlow<List<VehicleListing>> = repository.marketplaceListings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val garageVehicles: StateFlow<List<VehicleListing>> = repository.garageVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteListings: StateFlow<List<VehicleListing>> = repository.favoriteListings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appointments: StateFlow<List<Appointment>> = repository.appointments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 2. Filter states
    val searchKeyword = MutableStateFlow("")
    val selectedListingType = MutableStateFlow("All") // "All", "C2C", "B2C", "AUCTION", "TRADE_IN"
    val selectedFuelType = MutableStateFlow("All") // "All", "Gasoline", "Electric", "Hybrid"
    val maxPriceBudget = MutableStateFlow(250000.0)

    // Combined filtered listings
    val filteredListings: StateFlow<List<VehicleListing>> = combine(
        marketplaceListings,
        searchKeyword,
        selectedListingType,
        selectedFuelType,
        maxPriceBudget
    ) { listings, keyword, type, fuel, budget ->
        listings.filter { vehicle ->
            val matchesKeyword = keyword.isEmpty() || 
                    vehicle.make.contains(keyword, ignoreCase = true) || 
                    vehicle.model.contains(keyword, ignoreCase = true)
            val matchesType = type == "All" || vehicle.listingType == type
            val matchesFuel = fuel == "All" || vehicle.fuelType.contains(fuel, ignoreCase = true)
            val matchesPrice = if (vehicle.listingType == "AUCTION") {
                vehicle.currentBid <= budget
            } else {
                vehicle.listingPrice <= budget
            }
            matchesKeyword && matchesType && matchesFuel && matchesPrice
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Vehicle for Detail View
    private val _selectedVehicleId = MutableStateFlow<Int?>(null)
    val selectedVehicle: StateFlow<VehicleListing?> = _selectedVehicleId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else marketplaceListings.map { list -> list.find { it.id == id } }
                .combine(garageVehicles.map { list -> list.find { it.id == id } }) { market, garage ->
                    market ?: garage
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Interactive Auction Bids for Selected Vehicle
    val selectedVehicleBids: StateFlow<List<Bid>> = _selectedVehicleId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getBidsForVehicle(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Comparison Basket (Up to 3 vehicles)
    private val _comparisonIds = MutableStateFlow<List<Int>>(emptyList())
    val comparisonList: StateFlow<List<VehicleListing>> = _comparisonIds
        .flatMapLatest { ids ->
            marketplaceListings.map { list ->
                list.filter { it.id in ids }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Transaction detail for selected vehicle if active
    val activeTransaction: StateFlow<Transaction?> = _selectedVehicleId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else transactions.map { list -> list.find { it.vehicleId == id } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // AI Valuation State
    val valuationResult = MutableStateFlow<ValuationResult?>(null)
    val isValuing = MutableStateFlow(false)

    // Notification Feed State
    private val _notifications = MutableStateFlow<List<String>>(
        listOf(
            "Welcome to Aurelia Auto Exchange - Your digital vehicle asset console is fully synced.",
            "Apex Auctions: BMW M4 bidding war is active. Reserve price is nearly reached.",
            "Aurelia Security: All digital title document transfers are cryptographically escrow-backed."
        )
    )
    val notifications: StateFlow<List<String>> = _notifications.asStateFlow()

    fun selectVehicle(id: Int?) {
        _selectedVehicleId.value = id
    }

    fun toggleFavorite(vehicle: VehicleListing) {
        viewModelScope.launch {
            repository.toggleFavorite(vehicle.id, !vehicle.isFavorite)
        }
    }

    // Sell a Vehicle from Garage
    fun createListingFromGarage(vehicle: VehicleListing, price: Double) {
        viewModelScope.launch {
            // Update owned status or create marketplace asset
            val marketListing = vehicle.copy(
                id = 0, // Fresh insert for marketplace
                listingPrice = price,
                listingType = "C2C",
                isInGarage = false,
                sellerName = "Private Owner (You)",
                sellerTrustScore = 100
            )
            repository.insertListing(marketListing)
            addNotification("Listing created: Your ${vehicle.year} ${vehicle.make} is now active on Aurelia Exchange.")
        }
    }

    // Fast Create Custom User Car Listing
    fun createCustomListing(
        make: String,
        model: String,
        year: Int,
        mileage: Int,
        price: Double,
        fuel: String,
        listingType: String,
        description: String
    ) {
        viewModelScope.launch {
            val newListing = VehicleListing(
                make = make,
                model = model,
                year = year,
                mileage = mileage,
                fuelType = fuel,
                ownershipHistory = "1 Private Owner",
                accidentHistory = "No Accidents reported",
                serviceHistory = "Self-documented premium services",
                inspectionStatus = "Aurelia Self-Certified",
                valuationScore = 88,
                listingPrice = price,
                listingType = listingType,
                imageUrl = "custom_car",
                sellerName = "Me (Self-Listed)",
                sellerTrustScore = 95,
                isVerified = false,
                description = description
            )
            repository.insertListing(newListing)
            addNotification("System: Your customized listing for $make $model has been broadcast to Aurelia Elite network.")
        }
    }

    // Live Instant Bid
    fun placeAuctionBid(amount: Double): Boolean {
        val vehicle = selectedVehicle.value ?: return false
        if (vehicle.listingType != "AUCTION") return false

        viewModelScope.launch {
            val success = repository.placeBid(vehicle.id, amount, "You (Secured Bidder)")
            if (success) {
                addNotification("Aurelia Exchange: Bid of $${amount.toInt()} approved on ${vehicle.make} ${vehicle.model}!")
            }
        }
        return true
    }

    // Schedule Tour / Inspection Viewing
    fun scheduleViewing(date: String, time: String, location: String, type: String) {
        val vehicle = selectedVehicle.value ?: return
        viewModelScope.launch {
            repository.bookAppointment(
                vehicleId = vehicle.id,
                vehicleName = "${vehicle.year} ${vehicle.make} ${vehicle.model}",
                date = date,
                time = time,
                location = location,
                type = type
            )
            addNotification("Calendar: $type booked for ${vehicle.make} on $date at $time. Location: $location.")
        }
    }

    fun deleteAppointment(id: Int) {
        viewModelScope.launch {
            repository.deleteAppointment(id)
            addNotification("Calendar: Viewing request slot withdrawn.")
        }
    }

    /**
     * Complete Transaction Flow Engine
     */
    fun initiateSovereignTransfer() {
        val vehicle = selectedVehicle.value ?: return
        viewModelScope.launch {
            val txId = repository.initiateTransaction(
                vehicleId = vehicle.id,
                buyerName = "You (Sovereign Trader)",
                transactionType = when (vehicle.listingType) {
                    "AUCTION" -> "Auction Win"
                    "TRADE_IN" -> "Trade-In"
                    else -> "Buy"
                }
            )
            if (txId != -1L) {
                addNotification("Escrow: Initialized title transfer secure escrow for ${vehicle.make} ${vehicle.model}.")
            }
        }
    }

    fun fundEscrow() {
        val tx = activeTransaction.value ?: return
        viewModelScope.launch {
            val updated = tx.copy(status = "Escrow Funded")
            repository.updateTransaction(updated)
            addNotification("Escrow: Crypto-secured cash asset ($${tx.price.toInt()}) locked securely in Aurelia vault.")
        }
    }

    fun signTransferDocuments() {
        val tx = activeTransaction.value ?: return
        viewModelScope.launch {
            val updated = tx.copy(
                status = "Legal Transfer Pending",
                documentStatus = "Signed & Verified"
            )
            repository.updateTransaction(updated)
            addNotification("Document Engine: Escrow smart contract verified. Digital title deed signed by buyer.")
        }
    }

    fun releaseEscrowAndDeliver() {
        val tx = activeTransaction.value ?: return
        viewModelScope.launch {
            val updated = tx.copy(status = "Completed")
            repository.updateTransaction(updated)
            
            // Re-allocate vehicle to the user's garage!
            repository.getListingById(tx.vehicleId)?.let { listing ->
                repository.updateListing(listing.copy(
                    isInGarage = true,
                    isFavorite = false // remove from marketplace search listings list
                ))
            }
            
            addNotification("Ownership: Title deed transferred successfully! Vehicle is now parked in YOUR DIGITAL GARAGE.")
        }
    }

    // Comparison Engine Control
    fun toggleComparison(id: Int) {
        val current = _comparisonIds.value.toMutableList()
        if (id in current) {
            current.remove(id)
        } else {
            if (current.size < 3) {
                current.add(id)
            } else {
                addNotification("Aurelia Limit: Comparison basket accommodates a maximum of 3 assets side-by-side.")
            }
        }
        _comparisonIds.value = current
    }

    fun clearComparison() {
        _comparisonIds.value = emptyList()
    }

    // AI Valuation Engine Interface
    fun runAiValuation(make: String, model: String, year: Int, mileage: Int, condition: String) {
        viewModelScope.launch {
            isValuing.value = true
            val result = GeminiService.getValuation(make, model, year, mileage, condition)
            valuationResult.value = result
            isValuing.value = false
            addNotification("AI Engine: High-fidelity predictive valuation computed for $year $make $model.")
        }
    }

    fun resetValuation() {
        valuationResult.value = null
    }

    fun addNotification(message: String) {
        val list = _notifications.value.toMutableList()
        list.add(0, message)
        _notifications.value = list.take(15) // Keep last 15 feeds
    }
}
