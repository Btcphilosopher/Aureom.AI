package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aurelia Auto Exchange - Premium High-Contrast Color Palette (Professional Polish Theme)
val CyberBlue = Color(0xFF00E5FF)       // Electric Cyan / Accent Active Line
val DeepBlueDark = Color(0xFF00384D)    // Blue Depth Shadow
val ElectricAmber = Color(0xFFFF9100)   // High-Contrast Alert / Bidding Active Color
val ActiveGreen = Color(0xFF00FF41)     // Connected Status / Approved Transferred Cash Indicator (Vibrant Tech Green)

val MatteBlack = Color(0xFF0B0D0F)      // Top-level unified screen background (#0B0D0F)
val SlateGrayDark = Color(0xFF0B0D0F)   // Header/Bottom Nav premium integrated background (#0B0D0F)
val LightSlateGray = Color(0xFF16191D)  // Bento Box / Card Container / Dialog depth background (#16191D)
val CarbonGray = Color(0xFF1E293B)      // Professional slate borders (#1E293B)

val OffWhiteText = Color(0xFFF1F5F9)    // Core Headers (Slate-100)
val DullSilverText = Color(0xFF94A3B8)  // Subheads and Parameter metrics (Slate-400)
val GoldenYellow = Color(0xFFFDBB2D)    // Level markers
