package com.example.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@Entity(tableName = "vehicle_listings")
data class VehicleListing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val make: String,
    val model: String,
    val year: Int,
    val mileage: Int,
    val fuelType: String,
    val ownershipHistory: String,
    val accidentHistory: String,
    val serviceHistory: String,
    val inspectionStatus: String,
    val valuationScore: Int, // e.g. 95/100
    val listingPrice: Double,
    val listingType: String, // "C2C" (P2P), "B2C" (Dealer), "AUCTION", "TRADE_IN"
    val imageUrl: String, // Used as dynamic canvas identifier like "porsche_911", "tesla_s", etc.
    val isFavorite: Boolean = false,
    val isInGarage: Boolean = false, // Owned by the current user
    val bidsCount: Int = 0,
    val currentBid: Double = 0.0,
    val reservePrice: Double = 0.0,
    val auctionEndTime: Long = 0L, // Timestamp in ms
    val sellerName: String,
    val sellerTrustScore: Int, // e.g. 98%
    val isVerified: Boolean = true,
    val description: String = ""
)

@Entity(tableName = "appointments")
data class Appointment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: Int,
    val vehicleName: String,
    val date: String,
    val time: String,
    val location: String,
    val type: String, // "Inspection", "Test Drive"
    val status: String // "Scheduled", "Completed", "Cancelled"
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: Int,
    val vehicleName: String,
    val price: Double,
    val transactionType: String, // "Buy", "Sell", "Trade-In", "Auction Win"
    val status: String, // "Offer Made", "Escrow Funded", "Legal Transfer Pending", "Completed"
    val documentStatus: String, // "Unsigned", "Pending Counter-Sign", "Signed & Verified"
    val buyerName: String,
    val sellerName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bids")
data class Bid(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: Int,
    val bidderName: String,
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicle_listings WHERE isInGarage = 0")
    fun getMarketplaceListings(): Flow<List<VehicleListing>>

    @Query("SELECT * FROM vehicle_listings WHERE isInGarage = 1")
    fun getGarageVehicles(): Flow<List<VehicleListing>>

    @Query("SELECT * FROM vehicle_listings WHERE isFavorite = 1")
    fun getFavoriteListings(): Flow<List<VehicleListing>>

    @Query("SELECT * FROM vehicle_listings WHERE id = :id")
    suspend fun getListingById(id: Int): VehicleListing?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: VehicleListing): Long

    @Update
    suspend fun updateListing(listing: VehicleListing)

    @Delete
    suspend fun deleteListing(listing: VehicleListing)

    @Query("UPDATE vehicle_listings SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Int, isFavorite: Boolean)

    @Query("UPDATE vehicle_listings SET isInGarage = :isInGarage WHERE id = :id")
    suspend fun updateGarageStatus(id: Int, isInGarage: Boolean)

    // Appointments
    @Query("SELECT * FROM appointments ORDER BY id DESC")
    fun getAllAppointments(): Flow<List<Appointment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: Appointment)

    @Query("DELETE FROM appointments WHERE id = :id")
    suspend fun deleteAppointment(id: Int)

    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction): Long

    @Update
    suspend fun updateTransaction(transaction: Transaction)

    @Query("SELECT * FROM transactions WHERE vehicleId = :vehicleId LIMIT 1")
    suspend fun getTransactionByVehicleId(vehicleId: Int): Transaction?

    // Bids
    @Query("SELECT * FROM bids WHERE vehicleId = :vehicleId ORDER BY amount DESC")
    fun getBidsForVehicle(vehicleId: Int): Flow<List<Bid>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBid(bid: Bid)
}

@Database(entities = [VehicleListing::class, Appointment::class, Transaction::class, Bid::class], version = 1, exportSchema = false)
abstract class AureliaDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao

    companion object {
        @Volatile
        private var INSTANCE: AureliaDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AureliaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AureliaDatabase::class.java,
                    "aurelia_auto_exchange_db"
                )
                    .addCallback(AureliaDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AureliaDatabaseCallback(private val scope: CoroutineScope) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.vehicleDao())
                }
            }
        }

        suspend fun populateDatabase(dao: VehicleDao) {
            val now = System.currentTimeMillis()

            // 1. Porsche 911 GT3 (P2P/C2C listing)
            dao.insertListing(
                VehicleListing(
                    make = "Porsche",
                    model = "911 GT3 (992)",
                    year = 2023,
                    mileage = 4250,
                    fuelType = "Gasoline (High Octane)",
                    ownershipHistory = "Single Owner, Ceramic Coated",
                    accidentHistory = "No Accidents, Original Paint",
                    serviceHistory = "Porsche Zuffenhausen Dealer Serviced",
                    inspectionStatus = "Aurelia Certified - 150 Point Inspected",
                    valuationScore = 98,
                    listingPrice = 224900.0,
                    listingType = "C2C",
                    imageUrl = "porsche_911",
                    sellerName = "Julian Vance (Collector)",
                    sellerTrustScore = 99,
                    isVerified = true,
                    description = "A pristine 992-generation GT3 in Shark Blue. Optional carbon bucket seats, front axle lift, and ceramic brakes. Always stored in a temperature-controlled garage. Transferable extended factory warranty. Experience track precision on the street."
                )
            )

            // 2. Tesla Model S Plaid (Dealer/B2C listing)
            dao.insertListing(
                VehicleListing(
                    make = "Tesla",
                    model = "Model S Plaid",
                    year = 2024,
                    mileage = 1850,
                    fuelType = "Electric (1020 HP)",
                    ownershipHistory = "Corporate Demo Car, Like New",
                    accidentHistory = "No Accidents, Clean Carfax",
                    serviceHistory = "Tesla Service Center Inspections",
                    inspectionStatus = "Certified Pre-Owned by Tesla Partner",
                    valuationScore = 97,
                    listingPrice = 88500.0,
                    listingType = "B2C",
                    imageUrl = "tesla_s",
                    sellerName = "Aurelia Elite Motors",
                    sellerTrustScore = 98,
                    isVerified = true,
                    description = "0-60 MPH in 1.99s. Full Self-Driving (FSD) computer active, Yoke steering wheel, Ultra Red exterior with premium Cream carbon fiber interior. Instant delivery with dealer-backed service plan, financing eligibility verified, and trade-ins welcome."
                )
            )

            // 3. BMW M4 Competition (Auction listing)
            dao.insertListing(
                VehicleListing(
                    make = "BMW",
                    model = "M4 Competition xDrive",
                    year = 2022,
                    mileage = 14200,
                    fuelType = "Gasoline (M TwinPower)",
                    ownershipHistory = "1 Owner, Leased originally",
                    accidentHistory = "No Accidents, Minor Wheel Scrape Fixed",
                    serviceHistory = "BMW M-Division Scheduled Services Only",
                    inspectionStatus = "Aurelia Pre-Auction Inspected",
                    valuationScore = 92,
                    listingPrice = 75000.0,
                    listingType = "AUCTION",
                    imageUrl = "bmw_m4",
                    bidsCount = 14,
                    currentBid = 72400.0,
                    reservePrice = 74000.0,
                    auctionEndTime = now + (1000 * 60 * 60 * 4), // Ends in 4 hours
                    sellerName = "Apex Auctions",
                    sellerTrustScore = 95,
                    isVerified = true,
                    description = "Stunning Isle of Man Green metallic matched with Tartufo Merino leather. Driving Assistance package, M Carbon Exterior Package, and Laserlights. Highly sought-after option build with active bid war. Automated escrow transaction active."
                )
            )

            // 4. Audi RS e-tron GT (Trade-In option)
            dao.insertListing(
                VehicleListing(
                    make = "Audi",
                    model = "RS e-tron GT",
                    year = 2023,
                    mileage = 8100,
                    fuelType = "Electric (Quattro)",
                    ownershipHistory = "Ex-Executive lease, clean record",
                    accidentHistory = "No Accidents, Original Owner",
                    serviceHistory = "Audi Dealership annual service completed",
                    inspectionStatus = "Aurelia Certified Plus",
                    valuationScore = 94,
                    listingPrice = 102000.0,
                    listingType = "TRADE_IN",
                    imageUrl = "audi_rs",
                    sellerName = "Genesis Luxury Group",
                    sellerTrustScore = 96,
                    isVerified = true,
                    description = "Beautiful Kemora Gray metallic over Black fine Nappa leather interior. Carbosilicic brakes, rear steering, and active air suspension. Perfect trade-in asset, qualifies for 1.9% financing, or instant cash trade optimization through Aurelia exchange network."
                )
            )

            // 5. User's own vehicle in Garage (Owned list)
            dao.insertListing(
                VehicleListing(
                    make = "Mercedes-AMG",
                    model = "C63 S Coupe",
                    year = 2021,
                    mileage = 24500,
                    fuelType = "Gasoline (Handcrafted V8)",
                    ownershipHistory = "Current Owner (You)",
                    accidentHistory = "No Accidents, Paint Protection Film applied",
                    serviceHistory = "Mercedes-Benz AMG Certified Services",
                    inspectionStatus = "Aurelia Verified Member Vehicle",
                    valuationScore = 91,
                    listingPrice = 68000.0, // Suggested valuation
                    listingType = "C2C",
                    imageUrl = "mercedes_c63",
                    isFavorite = false,
                    isInGarage = true, // In Garage!
                    sellerName = "Me (You)",
                    sellerTrustScore = 100,
                    isVerified = true,
                    description = "My beloved Obsidian Black AMG C63 S. Biturbo V8 with intoxicating exhaust note. Complete service book, factory carbon trims, luxury cockpit setup. Considering offers, open to trade-in options with Audi RS e-tron GT or Porsche 911."
                )
            )
        }
    }
}
