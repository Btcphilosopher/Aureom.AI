package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.VehicleViewModel
import com.example.ui.components.VehicleCanvas
import com.example.ui.theme.*

enum class Screen {
    MARKETPLACE, GARAGE, VALUATION, TRANSACTIONS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    val context = LocalContext.current
    val viewModel: VehicleViewModel = viewModel()
    
    // Core Navigation state
    var currentScreen by remember { mutableStateOf(Screen.MARKETPLACE) }
    
    val notifications by viewModel.notifications.collectAsState()
    var showNotifDialog by remember { mutableStateOf(false) }
    
    // Selected Vehicle Details Overlay is open when not null
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    
    // Comparison panel toggle
    val comparisonList by viewModel.comparisonList.collectAsState()
    var showComparisonOverlay by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        bottomBar = {
            BottomConsoleBar(
                currentScreen = currentScreen,
                onScreenSelected = { currentScreen = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MatteBlack)
        ) {
            // Screen contents
            Column(modifier = Modifier.fillMaxSize()) {
                // Precision Header
                AppDashboardHeader(
                    currentScreen = currentScreen,
                    notificationCount = notifications.size,
                    comparisonCount = comparisonList.size,
                    onNotificationClick = { showNotifDialog = true },
                    onComparisonClick = { if (comparisonList.isNotEmpty()) showComparisonOverlay = true }
                )

                Box(modifier = Modifier.weight(1f)) {
                    when (currentScreen) {
                        Screen.MARKETPLACE -> MarketplaceTabScreen(viewModel = viewModel)
                        Screen.GARAGE -> GarageTabScreen(viewModel = viewModel)
                        Screen.VALUATION -> ValuationTabScreen(viewModel = viewModel)
                        Screen.TRANSACTIONS -> TransactionsTabScreen(viewModel = viewModel)
                    }
                }
            }

            // Interactive vehicle details overlay
            selectedVehicle?.let { vehicle ->
                VehicleDetailsOverlay(
                    vehicle = vehicle,
                    viewModel = viewModel,
                    onDismiss = { viewModel.selectVehicle(null) }
                )
            }

            // Notifications Feed Dialog overlay
            if (showNotifDialog) {
                NotificationFeedOverlay(
                    notifications = notifications,
                    onDismiss = { showNotifDialog = false }
                )
            }

            // Comparison Board Overlay
            if (showComparisonOverlay && comparisonList.isNotEmpty()) {
                ComparisonBoardOverlay(
                    comparisonList = comparisonList,
                    viewModel = viewModel,
                    onDismiss = { showComparisonOverlay = false }
                )
            }
        }
    }
}

// ==========================================
// CORE SHELL STRUCTS & VIEWS
// ==========================================

@Composable
fun AppDashboardHeader(
    currentScreen: Screen,
    notificationCount: Int,
    comparisonCount: Int,
    onNotificationClick: () -> Unit,
    onComparisonClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SlateGrayDark)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .border(
                border = BorderStroke(1.dp, CarbonGray),
                shape = RoundedCornerShape(0.dp)
            ),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "AURELIA AUTO EXCHANGE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00E5FF),
                letterSpacing = 2.sp
            )
            Text(
                text = when (currentScreen) {
                    Screen.MARKETPLACE -> "SOVEREIGN VEHICLE TRANSIT EXCHANGE"
                    Screen.GARAGE -> "USER MULTI-ASSET GARAGE CABINET"
                    Screen.VALUATION -> "AI PREDICTIVE VALUATION DEPRECIATION COMPUTER"
                    Screen.TRANSACTIONS -> "ESCROW COMPLIANCE TRANSACTION LEDGER"
                },
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFADB5C4),
                letterSpacing = 1.sp
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Comparison Basket trigger
            if (comparisonCount > 0) {
                Box(
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFFF9100).copy(alpha = 0.15f))
                        .border(BorderStroke(1.dp, Color(0xFFFF9100)), RoundedCornerShape(4.dp))
                        .clickable { onComparisonClick() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Compare Basket",
                            tint = Color(0xFFFF9100),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "COMPARE ($comparisonCount)",
                            color = Color(0xFFFF9100),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Notification glow pill
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(LightSlateGray)
                    .border(BorderStroke(1.dp, CarbonGray), CircleShape)
                    .clickable { onNotificationClick() }
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Alert Board",
                    tint = if (notificationCount > 0) Color(0xFF00E5FF) else Color.White,
                    modifier = Modifier.size(18.dp)
                )
                if (notificationCount > 0) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color.Red)
                            .align(Alignment.TopEnd)
                    )
                }
            }
        }
    }
}

@Composable
fun BottomConsoleBar(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SlateGrayDark)
            .border(BorderStroke(1.dp, CarbonGray))
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ConsoleBarItem(
            screen = Screen.MARKETPLACE,
            label = "EXCHANGE",
            icon = Icons.Default.Search,
            selected = currentScreen == Screen.MARKETPLACE,
            onClick = { onScreenSelected(Screen.MARKETPLACE) }
        )
        ConsoleBarItem(
            screen = Screen.GARAGE,
            label = "GARAGE",
            icon = Icons.Default.Home,
            selected = currentScreen == Screen.GARAGE,
            onClick = { onScreenSelected(Screen.GARAGE) }
        )
        ConsoleBarItem(
            screen = Screen.VALUATION,
            label = "VALUATION",
            icon = Icons.Default.Info,
            selected = currentScreen == Screen.VALUATION,
            onClick = { onScreenSelected(Screen.VALUATION) }
        )
        ConsoleBarItem(
            screen = Screen.TRANSACTIONS,
            label = "ESCROW",
            icon = Icons.Default.CheckCircle,
            selected = currentScreen == Screen.TRANSACTIONS,
            onClick = { onScreenSelected(Screen.TRANSACTIONS) }
        )
    }
}

@Composable
fun RowScope.ConsoleBarItem(
    screen: Screen,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .weight(1f)
            .testTag("nav_tab_${screen.name.lowercase()}")
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) Color(0xFF00E5FF) else Color(0xFFADB5C4),
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color(0xFF00E5FF) else Color(0xFFADB5C4),
            letterSpacing = 1.sp
        )
    }
}

// ==========================================
// 1. EXCHANGE (MARKETPLACE) TAB VIEW
// ==========================================

@Composable
fun MarketplaceTabScreen(viewModel: VehicleViewModel) {
    val searchKey by viewModel.searchKeyword.collectAsState()
    val selectedType by viewModel.selectedListingType.collectAsState()
    val selectedFuel by viewModel.selectedFuelType.collectAsState()
    val budgetCap by viewModel.maxPriceBudget.collectAsState()
    val listings by viewModel.filteredListings.collectAsState()
    val favoritedList by viewModel.favoriteListings.collectAsState()
    val comparisonList by viewModel.comparisonList.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Quick Search Bar + Filters Action Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchKey,
                onValueChange = { viewModel.searchKeyword.value = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("search_input"),
                placeholder = { Text("Search make or model (e.g. Porsche, BMW)...", color = DullSilverText, fontSize = 12.sp) },
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                leadingIcon = { Icon(Icons.Default.Search, "Search Icon", tint = CyberBlue) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberBlue,
                    unfocusedBorderColor = CarbonGray,
                    focusedContainerColor = LightSlateGray,
                    unfocusedContainerColor = LightSlateGray
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            
            Spacer(modifier = Modifier.width(10.dp))

            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LightSlateGray)
                    .border(BorderStroke(1.dp, if (selectedType != "All") CyberBlue else CarbonGray), RoundedCornerShape(12.dp))
                    .clickable { showFilterSheet = !showFilterSheet }
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build, // Engineering Filter Cog Symbol
                    contentDescription = "Show Filter Drawer",
                    tint = if (selectedType != "All" || selectedFuel != "All" || budgetCap < 250000) Color(0xFF00E5FF) else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Active Quick Filter Ribbons
        if (showFilterSheet) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1116))
                    .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text("EXCHANGE PIPELINE SELECTOR", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val exchangeTypes = listOf("All", "C2C", "B2C", "AUCTION", "TRADE_IN")
                    items(exchangeTypes) { type ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (selectedType == type) Color(0xFF00E5FF).copy(alpha = 0.15f) else Color(0xFF161920))
                                .border(BorderStroke(1.dp, if (selectedType == type) Color(0xFF00E5FF) else Color(0xFF232732)), RoundedCornerShape(4.dp))
                                .clickable { viewModel.selectedListingType.value = type }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = when (type) {
                                    "All" -> "ALL INVENTORY"
                                    "C2C" -> "P2P SALES"
                                    "B2C" -> "DEALERS"
                                    "AUCTION" -> "LIVE AUCTION"
                                    "TRADE_IN" -> "TRADE-IN EXCH"
                                    else -> type
                                },
                                color = if (selectedType == type) Color(0xFF00E5FF) else Color(0xFFADB5C4),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                
                Text("FUEL & MOTOR SYSTEMS", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val fluids = listOf("All", "Gasoline", "Electric", "Hybrid")
                    fluids.forEach { f ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (selectedFuel == f) Color(0xFF00E5FF).copy(alpha = 0.15f) else Color(0xFF161920))
                                .border(BorderStroke(1.dp, if (selectedFuel == f) Color(0xFF00E5FF) else Color(0xFF232732)), RoundedCornerShape(4.dp))
                                .clickable { viewModel.selectedFuelType.value = f }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = f.uppercase(),
                                color = if (selectedFuel == f) Color(0xFF00E5FF) else Color(0xFFADB5C4),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("MAX PRICE INDEX BUDGET BOUNDS", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                    Text("$${budgetCap.toInt()}", color = Color(0xFFFF9100), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = budgetCap.toFloat(),
                    onValueChange = { viewModel.maxPriceBudget.value = it.toDouble() },
                    valueRange = 20000f..250000f,
                    steps = 23,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFFF9100),
                        activeTrackColor = Color(0xFFFF9100),
                        inactiveTrackColor = Color(0xFF232732)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Total count label
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${listings.size} ASSETS LIVE ON EXCHANGE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFADB5C4),
                letterSpacing = 1.sp
            )
            
            if (listings.isEmpty()) {
                Text("Clear filters", color = Color(0xFF00E5FF), fontSize = 10.sp, modifier = Modifier.clickable {
                    viewModel.searchKeyword.value = ""
                    viewModel.selectedListingType.value = "All"
                    viewModel.selectedFuelType.value = "All"
                    viewModel.maxPriceBudget.value = 250000.0
                })
            }
        }

        // Listings Stream
        if (listings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1116))
                    .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Empty",
                        tint = Color(0xFF232732),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("NO ASSETS MATCH CURRENT PARAMETERS", color = Color(0xFFADB5C4), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Recalibrate search keyword or adjust maximum MSRP envelope constraints.", color = Color(0xFFADB5C4).copy(alpha = 0.6f), fontSize = 9.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(listings) { vehicle ->
                    val isFav = favoritedList.any { it.id == vehicle.id }
                    val isInComp = comparisonList.any { it.id == vehicle.id }

                    ListingRowCard(
                        vehicle = vehicle,
                        isFav = isFav,
                        isInComparison = isInComp,
                        onSelect = { viewModel.selectVehicle(vehicle.id) },
                        onToggleFavorite = { viewModel.toggleFavorite(vehicle) },
                        onToggleComparison = { viewModel.toggleComparison(vehicle.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun ListingRowCard(
    vehicle: VehicleListing,
    isFav: Boolean,
    isInComparison: Boolean,
    onSelect: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleComparison: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vehicle_card_${vehicle.id}")
            .clickable { onSelect() }
            .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LightSlateGray)
    ) {
        Column {
            // Silhouette Header drawing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(MatteBlack)
            ) {
                VehicleCanvas(
                    imageUrl = vehicle.imageUrl,
                    modifier = Modifier.fillMaxSize()
                )

                // Category badges
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                when (vehicle.listingType) {
                                    "AUCTION" -> Color(0xFFFF9100).copy(alpha = 0.2f)
                                    "B2C" -> Color(0xFF00E5FF).copy(alpha = 0.2f)
                                    "TRADE_IN" -> Color(0xFFE040FB).copy(alpha = 0.2f)
                                    else -> Color.White.copy(alpha = 0.1f)
                                }
                            )
                            .border(
                                border = BorderStroke(
                                    1.dp,
                                    when (vehicle.listingType) {
                                        "AUCTION" -> Color(0xFFFF9100)
                                        "B2C" -> Color(0xFF00E5FF)
                                        "TRADE_IN" -> Color(0xFFE040FB)
                                        else -> Color(0xFFADB5C4)
                                    }
                                ),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = when (vehicle.listingType) {
                                "AUCTION" -> "LIVE AUCTION BIDS"
                                "B2C" -> "PARTNER DEALER"
                                "TRADE_IN" -> "TRADE-IN LISTING"
                                else -> "P2P CASH SPREAD"
                            },
                            color = when (vehicle.listingType) {
                                "AUCTION" -> Color(0xFFFF9100)
                                "B2C" -> Color(0xFF00E5FF)
                                "TRADE_IN" -> Color(0xFFE040FB)
                                else -> Color.White
                            },
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Trust Score Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(LightSlateGray)
                            .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "TRUST VALUE: ${vehicle.sellerTrustScore}%",
                            color = if (vehicle.sellerTrustScore > 95) ActiveGreen else ElectricAmber,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Specs context
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${vehicle.year} ${vehicle.make.uppercase()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Text(
                            text = vehicle.model,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        if (vehicle.listingType == "AUCTION") {
                            Text("CURRENT BID", color = ElectricAmber, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text("$${vehicle.currentBid.toInt()}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("${vehicle.bidsCount} bid increments", color = DullSilverText, fontSize = 8.sp)
                        } else {
                            Text("LISTING PRICE", color = DullSilverText, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text("$${vehicle.listingPrice.toInt()}", color = CyberBlue, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("No Escrow Tax", color = ActiveGreen, fontSize = 8.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                // Specs dashboard parameters
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SpecColumn(label = "MILEAGE", value = "${vehicle.mileage} mi")
                    SpecColumn(label = "MOTOR TYPE", value = vehicle.fuelType.split(" ").first())
                    SpecColumn(label = "VEHICLE SCORE", value = "${vehicle.valuationScore}/100")
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = Color(0xFF232732), thickness = 0.8.dp)
                Spacer(modifier = Modifier.height(10.dp))

                // Action controls at bottom row of the card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Seller: ${vehicle.sellerName}",
                        color = Color(0xFFADB5C4),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Row {
                        // Compare basket toggle
                        IconToggleButton(
                            checked = isInComparison,
                            onCheckedChange = { onToggleComparison() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Add to Comparison",
                                tint = if (isInComparison) Color(0xFFFF9100) else Color(0xFFADB5C4),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Add to favorites
                        IconToggleButton(
                            checked = isFav,
                            onCheckedChange = { onToggleFavorite() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Default.Star else Icons.Default.Star,
                                contentDescription = "Favorite",
                                tint = if (isFav) Color.Red else Color(0xFFADB5C4),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF00E5FF))
                                .clickable { onSelect() }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("EXAMINE", color = Color(0xFF07080A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpecColumn(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 8.sp, color = Color(0xFFADB5C4), fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

// ==========================================
// 2. USER GARAGE TAB VIEW
// ==========================================

@Composable
fun GarageTabScreen(viewModel: VehicleViewModel) {
    val garageList by viewModel.garageVehicles.collectAsState()
    val favoritedList by viewModel.favoriteListings.collectAsState()
    
    // Quick Add new P2P listing form logic
    var isCreatingListing by remember { mutableStateOf(false) }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var yearStr by remember { mutableStateOf("") }
    var mileageStr by remember { mutableStateOf("") }
    var priceStr by remember { mutableStateOf("") }
    var fuelType by remember { mutableStateOf("Gasoline") }
    var listingType by remember { mutableStateOf("C2C") }
    var description by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Quick Toggle sell car interface
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MANAGED GARAGE ASSETS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00E5FF),
                letterSpacing = 1.sp
            )

            Button(
                onClick = { isCreatingListing = !isCreatingListing },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCreatingListing) Color.Red else Color(0xFF00E5FF)
                )
            ) {
                Text(
                    text = if (isCreatingListing) "CANCEL FORM" else "SELL A VEHICLE C2C",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF07080A)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Create Custom Listing Drawer Form
        if (isCreatingListing) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp)),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1116))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PUBLISH TO AURELIA INDEX", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = make,
                        onValueChange = { make = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Make (e.g. Porsche)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Model (e.g. 911 Coupe)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = yearStr,
                            onValueChange = { yearStr = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("Year (2025)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )
                        OutlinedTextField(
                            value = mileageStr,
                            onValueChange = { mileageStr = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("Mileage (mi)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = priceStr,
                            onValueChange = { priceStr = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("MSRP Price ($)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )
                        
                        // Select type tag dropdown replacement
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FLUID SELECT", color = Color(0xFFADB5C4), fontSize = 8.sp)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                val fluidsList = listOf("Gas", "Electric", "Hybrid")
                                fluidsList.forEach { f ->
                                    val isSel = fuelType.startsWith(f)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSel) Color(0xFFFF9100).copy(alpha = 0.2f) else Color(0xFF161920))
                                            .border(BorderStroke(1.dp, if (isSel) Color(0xFFFF9100) else Color(0xFF232732)))
                                            .clickable { fuelType = if (f=="Gas") "Gasoline" else f }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(f, color = if (isSel) Color(0xFFFF9100) else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Details & Maintenance History") },
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val yearVal = yearStr.toIntOrNull() ?: 2023
                            val mileageVal = mileageStr.toIntOrNull() ?: 5000
                            val priceVal = priceStr.toDoubleOrNull() ?: 45000.0

                            if (make.isEmpty() || model.isEmpty()) {
                                return@Button
                            }

                            viewModel.createCustomListing(
                                make = make,
                                model = model,
                                year = yearVal,
                                mileage = mileageVal,
                                price = priceVal,
                                fuel = fuelType,
                                listingType = listingType,
                                description = description
                            )
                            // reset
                            make = ""
                            model = ""
                            yearStr = ""
                            mileageStr = ""
                            priceStr = ""
                            description = ""
                            isCreatingListing = false
                        },
                        modifier = Modifier.fillMaxWidth().testTag("publish_listing_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("BROADCAST ASSET LIVE", color = Color(0xFF07080A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // List User Owned Vehicles inside the Garage
        if (garageList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1116))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("GARAGE PORTFOLIO IS EMPTY", color = Color(0xFFADB5C4), fontSize = 11.sp)
            }
        } else {
            garageList.forEach { myCar ->
                GarageCarPanel(car = myCar, viewModel = viewModel)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Watchlist (Favorites) Section
        Text(
            text = "SAVED & WATCHED VEHICLES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (favoritedList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1116))
                    .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Star, "Star", tint = Color(0xFF232732), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("NO ACTIVE SAVED WATCHES", color = Color(0xFFADB5C4), fontSize = 10.sp)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                favoritedList.forEach { watchedCar ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F1116))
                            .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                            .clickable { viewModel.selectVehicle(watchedCar.id) }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.size(60.dp).clip(RoundedCornerShape(4.dp)).background(Color.Black)) {
                                VehicleCanvas(imageUrl = watchedCar.imageUrl, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("${watchedCar.year} ${watchedCar.make}", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(watchedCar.model, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("${watchedCar.mileage} miles | ${watchedCar.listingType}", color = Color(0xFFADB5C4), fontSize = 9.sp)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "$${(if (watchedCar.listingType == "AUCTION") watchedCar.currentBid else watchedCar.listingPrice).toInt()}",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Text(
                                text = "RMV UNCHECKED",
                                color = Color(0xFFFF9100),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        // Quick set valuation parameters and select Valuation Screen
                                        viewModel.runAiValuation(
                                            make = watchedCar.make,
                                            model = watchedCar.model,
                                            year = watchedCar.year,
                                            mileage = watchedCar.mileage,
                                            condition = "Good"
                                        )
                                    }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GarageCarPanel(car: VehicleListing, viewModel: VehicleViewModel) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LightSlateGray)
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth().height(100.dp).background(MatteBlack)) {
                VehicleCanvas(imageUrl = car.imageUrl, modifier = Modifier.fillMaxSize())
                Box(
                    modifier = Modifier
                        .padding(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(ActiveGreen.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, ActiveGreen), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text("OWNED & REGISTERED", color = ActiveGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                Text("${car.year} ${car.make}", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(car.model, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Mileage: ${car.mileage} mi | Blockchain Title: SECURE_AVF_${car.id}AX7", color = Color(0xFFADB5C4), fontSize = 9.sp)

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = Color(0xFF232732))
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("MAPPED REALIZED VALUE", color = Color(0xFFADB5C4), fontSize = 8.sp)
                        Text("$${car.listingPrice.toInt()}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Row {
                        Button(
                            onClick = {
                                viewModel.createListingFromGarage(car, car.listingPrice * 1.05)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("LIST FOR SALE C2C", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. AI VALUATION ENGINE TAB VIEW
// ==========================================

@Composable
fun ValuationTabScreen(viewModel: VehicleViewModel) {
    var valMake by remember { mutableStateOf("Porsche") }
    var valModel by remember { mutableStateOf("911 GT3 (992)") }
    var valYear by remember { mutableStateOf("2023") }
    var valMileage by remember { mutableStateOf("4500") }
    var valCondition by remember { mutableStateOf("Excellent") }

    val valuationResult by viewModel.valuationResult.collectAsState()
    val isValuing by viewModel.isValuing.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "AI REAL-TIME ASSET APPRAISER",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Form Inputs
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = LightSlateGray)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("VEHICLE STATE METRICS", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = valMake,
                        onValueChange = { valMake = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Brand/Make") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue, unfocusedBorderColor = CarbonGray,
                            focusedContainerColor = MatteBlack, unfocusedContainerColor = MatteBlack
                        )
                    )
                    OutlinedTextField(
                        value = valModel,
                        onValueChange = { valModel = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Model Class") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue, unfocusedBorderColor = CarbonGray,
                            focusedContainerColor = MatteBlack, unfocusedContainerColor = MatteBlack
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = valYear,
                        onValueChange = { valYear = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Year (Mfd.)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue, unfocusedBorderColor = CarbonGray,
                            focusedContainerColor = MatteBlack, unfocusedContainerColor = MatteBlack
                        )
                    )
                    OutlinedTextField(
                        value = valMileage,
                        onValueChange = { valMileage = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Active Mileage") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue, unfocusedBorderColor = CarbonGray,
                            focusedContainerColor = MatteBlack, unfocusedContainerColor = MatteBlack
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("REPORTED STRUCTURAL CONDITION", color = Color(0xFFADB5C4), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val conditions = listOf("Excellent", "Good", "Fair")
                    conditions.forEach { cond ->
                        val selected = valCondition == cond
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (selected) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF161920))
                                .border(BorderStroke(1.dp, if (selected) Color(0xFF00E5FF) else Color(0xFF232732)), RoundedCornerShape(4.dp))
                                .clickable { valCondition = cond }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cond.uppercase(), color = if (selected) Color(0xFF00E5FF) else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val yrVal = valYear.toIntOrNull() ?: 2023
                        val milVal = valMileage.toIntOrNull() ?: 5000
                        viewModel.runAiValuation(
                            make = valMake,
                            model = valModel,
                            year = yrVal,
                            mileage = milVal,
                            condition = valCondition
                        )
                    },
                    modifier = Modifier.fillMaxWidth().testTag("valuation_run_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    if (isValuing) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("COMPUTING BLOCKCHAIN SPREADS...", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("CALCULATE FAIR MARKET INDEX", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Appraisal Output Presentation
        valuationResult?.let { result ->
            Text(
                text = "VALUATION DEED OUTPUT",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF9100),
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, Color(0xFFFF9100)), RoundedCornerShape(8.dp)),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1116))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("FAIR QUANTIFIED LIQUID VALUE", color = Color(0xFFADB5C4), fontSize = 9.sp)
                            Text("$${result.estimatedValue.toInt()}", color = Color(0xFF00E5FF), fontSize = 24.sp, fontWeight = FontWeight.Black)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (result.isFromAi) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f))
                                .border(BorderStroke(1.dp, if (result.isFromAi) Color(0xFF00E5FF) else Color(0xFF232732)), RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (result.isFromAi) "SECURE AI MATRIX" else "LOCAL INDEX ALGO",
                                color = if (result.isFromAi) Color(0xFF00E5FF) else Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = Color(0xFF232732))
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("PRIVATE TRADING ESTIMATE", color = Color(0xFFADB5C4), fontSize = 8.sp)
                            Text(result.privateSaleRange, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("DEALER CERTIF. INVENTORY", color = Color(0xFFADB5C4), fontSize = 8.sp)
                            Text(result.dealerPriceRange, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.weight(0.8f)) {
                            Text("HOT DEMAND", color = Color(0xFFADB5C4), fontSize = 8.sp)
                            Text("${result.marketDemandScore}/10", color = Color(0xFF00E676), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(result.marketDemandDescription, color = Color(0xFFADB5C4), fontSize = 10.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("5-YEAR PREDICTIVE DEPRECIATION CURVE", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Dynamic graph Canvas
                    DepreciationGraph(curvePoints = result.depreciationCurve)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("SOVEREIGN TRADE RECOMMENDATIONS", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    result.smartRecommendations.forEach { rec ->
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                            Text("• ", color = Color(0xFFFF9100), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(rec, color = Color.White, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("AURELIA BLOCKCHAIN ANALYTICAL ANALYSIS", color = Color(0xFFFF9100), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = result.aiCommentary,
                        color = Color(0xFFADB5C4),
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } ?: run {
            // Placeholder empty state
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1116))
                    .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Analysis",
                        tint = Color(0xFF232732),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Valuation Engine Idle.", color = Color(0xFFADB5C4), fontSize = 11.sp)
                    Text("Input your vehicle specs above and tap core appraiser trigger for multi-agent predictive analysis.", color = Color(0xFFADB5C4).copy(alpha = 0.5f), fontSize = 9.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun DepreciationGraph(curvePoints: List<DepreciationPoint>) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .background(Color.Black)
            .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(4.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            val w = size.width
            val h = size.height

            // Calculate min/max range of curves
            val values = curvePoints.map { it.value }
            val maxValue = values.maxOrNull() ?: 100000.0
            val minValue = values.minOrNull() ?: 10000.0
            val valueDiff = (maxValue - minValue).coerceAtLeast(1.0)

            // Draw clean vertical grid stripes
            val stepsCount = curvePoints.size
            for (i in 0 until stepsCount) {
                val gridX = w * (i.toFloat() / (stepsCount - 1))
                drawLine(
                    color = Color.White.copy(alpha = 0.08f),
                    start = Offset(gridX, 0f),
                    end = Offset(gridX, h),
                    strokeWidth = 1f
                )
            }

            // Map points to canvas coordinates
            val points = curvePoints.mapIndexed { index, dpValue ->
                val pxX = w * (index.toFloat() / (stepsCount - 1))
                // inverted since Y coordinate goes downwards in Android draw behind context
                val ratio = (dpValue.value - minValue) / valueDiff
                val pxY = h - (h * ratio.toFloat() * 0.8f) - (h * 0.1f)
                Offset(pxX, pxY)
            }

            // Draw graph shading area below curve
            val shadePath = Path().apply {
                moveTo(0f, h)
                points.forEachIndexed { idx, p ->
                    if (idx == 0) lineTo(p.x, p.y) else lineTo(p.x, p.y)
                }
                lineTo(w, h)
                close()
            }
            drawPath(
                path = shadePath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.18f), Color.Transparent)
                )
            )

            // Draw path lines
            val path = Path().apply {
                points.forEachIndexed { idx, p ->
                    if (idx == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
            }
            drawPath(
                path = path,
                color = Color(0xFF00E5FF),
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )

            // Draw points dots and numeric prices labels
            points.forEachIndexed { idx, p ->
                drawCircle(color = Color.White, radius = 5f, center = p)
                drawCircle(color = Color(0xFF00E5FF), radius = 10f, center = p, style = Stroke(width = 2f))
            }
        }

        // Horizontal bottom label row overlay outside drawing
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 2.dp, start = 12.dp, end = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            curvePoints.forEach { pt ->
                Text(
                    text = "${pt.year}\n$${pt.value.toInt() / 1000}k",
                    color = Color(0xFFADB5C4),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// ==========================================
// 4. TRANSACTIONS & BOOKINGS LEDGER
// ==========================================

@Composable
fun TransactionsTabScreen(viewModel: VehicleViewModel) {
    val transactionList by viewModel.transactions.collectAsState()
    val appointmentList by viewModel.appointments.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Appoint Booking Calendar requests
        Text(
            text = "VERIFICATION & INSPECTION BOOKINGS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = CyberBlue,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (appointmentList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LightSlateGray)
                    .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("NO VIEWINGS SCHEDULED IN CALENDAR", color = DullSilverText, fontSize = 10.sp)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                appointmentList.forEach { appt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(LightSlateGray)
                            .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberBlue.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(appt.type.uppercase(), color = CyberBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(appt.vehicleName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("When: ${appt.date} at ${appt.time}", color = DullSilverText, fontSize = 10.sp)
                            Text("Spot: ${appt.location}", color = DullSilverText, fontSize = 9.sp)
                        }

                        Button(
                            onClick = { viewModel.deleteAppointment(appt.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("CANCEL", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Sovereign Transaction list
        Text(
            text = "SOVEREIGN ESCROW CODES TRANSIT",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = ElectricAmber,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (transactionList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LightSlateGray)
                    .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, "Security ledger", tint = CarbonGray, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("LEDGER CLEAR: NO OUTSTANDING TRANSITS", color = DullSilverText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                transactionList.forEach { tx ->
                    EscrowTransactionLedgerCard(tx = tx, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun EscrowTransactionLedgerCard(tx: Transaction, viewModel: VehicleViewModel) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("escrow_card_${tx.id}")
            .border(BorderStroke(1.dp, CarbonGray), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LightSlateGray)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ESCROW CONTRACT TRANSACTION ID: AX_LE_${tx.id}", color = ElectricAmber, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(tx.vehicleName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Transfer Type: ${tx.transactionType} pipeline", color = DullSilverText, fontSize = 10.sp)
                }

                Text(
                    text = "$${tx.price.toInt()}",
                    color = CyberBlue,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = CarbonGray)
            Spacer(modifier = Modifier.height(12.dp))

            // Transaction Pipeline graphic
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val step = when (tx.status) {
                    "Offer Made" -> 1
                    "Escrow Funded" -> 2
                    "Legal Transfer Pending" -> 3
                    "Completed" -> 4
                    else -> 1
                }

                LifecycleStep(label = "OFFER", active = step >= 1, done = step > 1)
                LifecycleArrow(done = step > 1)
                LifecycleStep(label = "ESCROW", active = step >= 2, done = step > 2)
                LifecycleArrow(done = step > 2)
                LifecycleStep(label = "TITLE SIGN", active = step >= 3, done = step > 3)
                LifecycleArrow(done = step > 3)
                LifecycleStep(label = "COMPLETED", active = step >= 4, done = step > 4)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action trigger based on dynamic status
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        when (tx.status) {
                            "Offer Made" -> Color(0xFFFF9100)
                            "Escrow Funded" -> Color(0xFF00E5FF)
                            "Legal Transfer Pending" -> Color(0xFF00E676)
                            else -> Color(0xFF161920)
                        }
                    )
                    .clickable {
                        when (tx.status) {
                            "Offer Made" -> viewModel.fundEscrow()
                            "Escrow Funded" -> viewModel.signTransferDocuments()
                            "Legal Transfer Pending" -> viewModel.releaseEscrowAndDeliver()
                        }
                    }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (tx.status) {
                        "Offer Made" -> "DEPOSIT FUNDS SECURELY TO ESCROW WALLET"
                        "Escrow Funded" -> "SIGN AND VERIFY LEASE/TITLE TRANSLATE CODES (NDA)"
                        "Legal Transfer Pending" -> "RELEASE SECURED CAPITAL & HAND OVER DEED KEYS"
                        else -> "TRANSACTION SETTLED SUCCESSFULLY EN ROUTE"
                    },
                    color = if (tx.status == "Completed") Color(0xFFADB5C4) else Color(0xFF07080A),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun RowScope.LifecycleStep(label: String, active: Boolean, done: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(CircleShape)
                .background(
                    if (done) Color(0xFF00E676)
                    else if (active) Color(0xFF00E5FF)
                    else Color(0xFF232732)
                )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label, 
            fontSize = 8.sp, 
            fontWeight = FontWeight.Bold,
            color = if (active) Color.White else Color(0xFFADB5C4).copy(alpha = 0.5f)
        )
    }
}

@Composable
fun LifecycleArrow(done: Boolean) {
    Icon(
        imageVector = Icons.Default.ArrowForward,
        contentDescription = "Next",
        tint = if (done) Color(0xFF00E676) else Color(0xFF232732),
        modifier = Modifier.size(12.dp)
    )
}

// ==========================================
// DETAILED VIEW OVERLAYS & SHEETS
// ==========================================

@Composable
fun VehicleDetailsOverlay(
    vehicle: VehicleListing,
    viewModel: VehicleViewModel,
    onDismiss: () -> Unit
) {
    val bids by viewModel.selectedVehicleBids.collectAsState()
    val activeTx by viewModel.activeTransaction.collectAsState()
    
    // Sliders & Calculators state
    var interestRate by remember { mutableStateOf(5.5f) }
    var loanTermMonths by remember { mutableStateOf(60f) }
    var bidOfferStr by remember { mutableStateOf("") }
    
    // Viewing inputs
    var apptDate by remember { mutableStateOf("2026-06-25") }
    var apptTime by remember { mutableStateOf("11:30") }
    var apptLoc by remember { mutableStateOf("Aurelia Inspection Hub London") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable { onDismiss() } // Dim dismiss clickable
    ) {
        // Core Sheet Body
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.95f)
                .align(Alignment.BottomCenter)
                .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .clickable(enabled = false) {} /* Prevent close when clicking card body */,
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1116))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header dismiss bar
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF161920))
                            .clickable { onDismiss() }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("BACK EXCH", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "VEHICLE ENCRYPTED DOSSIER",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                // Silhouette drawing banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                ) {
                    VehicleCanvas(imageUrl = vehicle.imageUrl, modifier = Modifier.fillMaxSize())
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Model description text
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${vehicle.year} ${vehicle.make.uppercase()}", color = Color(0xFF00E5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(vehicle.model, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("RESERVE VALUE", color = Color(0xFFADB5C4), fontSize = 8.sp)
                        Text("$${vehicle.listingPrice.toInt()}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Spec rows detail
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF07080A))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SpecColumn(label = "MILEAGE", value = "${vehicle.mileage} miles")
                    SpecColumn(label = "FUEL DYNAMICS", value = vehicle.fuelType)
                    SpecColumn(label = "VALUATION INDEX", value = "${vehicle.valuationScore}/100")
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("REPRESENTATIVE PHYSICAL RECORDS", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HistoryCard(title = "OWNERSHIP RECORD", desc = vehicle.ownershipHistory, modifier = Modifier.weight(1f))
                    HistoryCard(title = "ACCIDENT DEED", desc = vehicle.accidentHistory, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HistoryCard(title = "SERVICE INTERVAL", desc = vehicle.serviceHistory, modifier = Modifier.weight(1f))
                    HistoryCard(title = "INSPECTION LABEL", desc = vehicle.inspectionStatus, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("ASSET DIGITIZED BRIEFING", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = vehicle.description,
                    color = Color(0xFFADB5C4),
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                // AUCTION ENGINE CARD
                if (vehicle.listingType == "AUCTION") {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("LIVE CRYPTO-BIDDING TERMINAL", color = Color(0xFFFF9100), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, Color(0xFFFF9100)), RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF07080A))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("CURRENT HIGHEST BID STATUS", color = Color(0xFFADB5C4), fontSize = 9.sp)
                                    Text("$${vehicle.currentBid.toInt()}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ACTIVE CONTESTANTS", color = Color(0xFFADB5C4), fontSize = 9.sp)
                                    Text("${vehicle.bidsCount} Approved Bids", color = Color(0xFFFF9100), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row {
                                OutlinedTextField(
                                    value = bidOfferStr,
                                    onValueChange = { bidOfferStr = it },
                                    modifier = Modifier.weight(1f).testTag("bid_input_field"),
                                    placeholder = { Text("Enter bid above $${(if (vehicle.bidsCount > 0) vehicle.currentBid else vehicle.listingPrice).toInt()}") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFFF9100), unfocusedBorderColor = Color(0xFF232732)
                                    )
                                )

                                Spacer(modifier = Modifier.width(10.dp))

                                Button(
                                    onClick = {
                                        val bidVal = bidOfferStr.toDoubleOrNull() ?: 0.0
                                        if (viewModel.placeAuctionBid(bidVal)) {
                                            bidOfferStr = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100)),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.align(Alignment.CenterVertically).testTag("place_bid_button")
                                ) {
                                    Text("PLACE BID", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (bids.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("SYSTEM TRANSMIT LOG", color = Color(0xFFADB5C4), fontSize = 8.sp)
                                bids.take(3).forEach { b ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(b.bidderName, color = Color.White, fontSize = 9.sp)
                                        Text("$${b.amount.toInt()}", color = Color(0xFF00E676), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // FINANCING & INSURANCE CALCULATOR
                Spacer(modifier = Modifier.height(24.dp))
                Text("FINANCE & INSTALLMENT CALCULATOR INDEX", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))

                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp)),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF07080A))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        val basePrice = if (vehicle.listingType == "AUCTION") vehicle.currentBid else vehicle.listingPrice
                        
                        // Calculating monthly amortization
                        val principal = basePrice * 0.90
                        val totalInterest = principal * (interestRate / 100.0) * (loanTermMonths / 12.0)
                        val monthlyInstallment = (principal + totalInterest) / loanTermMonths

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ESTIMATED MONTHLY CLEARANCE", color = Color(0xFFADB5C4), fontSize = 9.sp)
                                Text("$${monthlyInstallment.toInt()}/mo", color = Color(0xFF00E5FF), fontSize = 20.sp, fontWeight = FontWeight.Black)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("DOWNPAYMENT REQUIRED (10%)", color = Color(0xFFADB5C4), fontSize = 8.sp)
                                Text("$${(basePrice * 0.1).toInt()}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ANNUAL INTEREST MULTIPLIER (APR)", color = Color(0xFFADB5C4), fontSize = 8.sp, modifier = Modifier.weight(1f))
                            Text("${String.format("%.1f", interestRate)}%", color = Color(0xFFFF9100), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = interestRate,
                            onValueChange = { interestRate = it },
                            valueRange = 1.9f..12.9f,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFFF9100), activeTrackColor = Color(0xFFFF9100))
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("LOAN AMORTIZATION TERM LIMIT", color = Color(0xFFADB5C4), fontSize = 8.sp, modifier = Modifier.weight(1f))
                            Text("${loanTermMonths.toInt()} Months", color = Color(0xFFFF9100), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = loanTermMonths,
                            onValueChange = { loanTermMonths = it },
                            valueRange = 24f..84f,
                            steps = 4,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFFF9100), activeTrackColor = Color(0xFFFF9100))
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Aurelia Elite Insurance rates: Quote $${(basePrice * 0.0015).toInt()}/mo available under compliance codes.",
                            color = Color(0xFF00E676),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // BOOK TEST DRIVE & VIEWING CALENDAR
                Spacer(modifier = Modifier.height(24.dp))
                Text("SCHEDULE DIRECT PHYSICAL VIEWING & TOUR", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))

                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp)),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF07080A))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        OutlinedTextField(
                            value = apptDate,
                            onValueChange = { apptDate = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Viewing Date") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = apptTime,
                            onValueChange = { apptTime = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Viewing Hour Time") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = apptLoc,
                            onValueChange = { apptLoc = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Aurelia Pickup Depot Hub Location") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF), unfocusedBorderColor = Color(0xFF232732)
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    viewModel.scheduleViewing(apptDate, apptTime, apptLoc, "Test Drive")
                                },
                                modifier = Modifier.weight(1f).testTag("book_test_drive_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("BOOK TEST DRIVE", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = {
                                    viewModel.scheduleViewing(apptDate, apptTime, apptLoc, "Inspection")
                                },
                                modifier = Modifier.weight(1f).testTag("book_inspection_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("BOOK INSPECTION", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // INITIATE LEGAL CONVEYANCE ESCROW
                Spacer(modifier = Modifier.height(28.dp))
                Text("SOVEREIGN LEGAL OWNERSHIP ESCROW PIPELINE", color = Color(0xFFFF9100), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))

                ActiveTransactPortal(vehicle = vehicle, activeTx = activeTx, onInitiate = { viewModel.initiateSovereignTransfer() })

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun ActiveTransactPortal(vehicle: VehicleListing, activeTx: Transaction?, onInitiate: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF07080A))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            if (activeTx == null) {
                Text(
                    text = "No active purchase transaction registered for this asset. Initiating purchase locks the dynamic price index into secure escrow vault under block AX.",
                    color = Color(0xFFADB5C4),
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { onInitiate() },
                    modifier = Modifier.fillMaxWidth().testTag("initiate_purchase_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("START SECURED P2P PURCHASE", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Text(
                    text = "ACTIVE CONTRACT RECORD DETECTED: CODE AX_${activeTx.id}",
                    color = Color(0xFF00E676),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Contract price index: $${activeTx.price.toInt()} | Pipeline Status: ${activeTx.status}",
                    color = Color.White,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Verify legal signature counters and fund escrow from Aurelia exchange ledger page.",
                    color = Color(0xFFADB5C4),
                    fontSize = 9.sp
                )
            }
        }
    }
}

@Composable
fun HistoryCard(title: String, desc: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF07080A))
            .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(title, color = Color(0xFFFF9100), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ==========================================
// 5. ASSET NOTIFICATION FEED OVERLAY
// ==========================================

@Composable
fun NotificationFeedOverlay(
    notifications: List<String>,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.8f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.7f)
                .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                .clickable(enabled = false) {},
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1116)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AURELIA EXCHANGE BROADCAST SYSTEM", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { onDismiss() }) {
                        Icon(Icons.Default.Close, "Dismiss", tint = Color.White)
                    }
                }

                Divider(color = Color(0xFF232732))
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    items(notifications) { notif ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF07080A))
                                .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(4.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("⚡", color = Color(0xFFFF9100), modifier = Modifier.padding(end = 8.dp))
                            Text(notif, color = Color.White, fontSize = 11.sp, lineHeight = 16.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. ASSET SIDE-BY-SIDE COMPARISON BOARD OVERLAY
// ==========================================

@Composable
fun ComparisonBoardOverlay(
    comparisonList: List<VehicleListing>,
    viewModel: VehicleViewModel,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.90f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.85f)
                .border(BorderStroke(1.dp, Color(0xFF00E5FF)), RoundedCornerShape(12.dp))
                .clickable(enabled = false) {},
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1116)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Header dismiss
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AURELIA DUAL-SPEC COMPARISON ENGINE", color = Color(0xFF00E5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Analyzing vehicle mechanics side-by-side", color = Color(0xFFADB5C4), fontSize = 8.sp)
                    }

                    Row {
                        Text(
                            text = "CLEAR ALL",
                            color = Color.Red,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { viewModel.clearComparison() }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )

                        IconButton(onClick = { onDismiss() }) {
                            Icon(Icons.Default.Close, "Close", tint = Color.White)
                        }
                    }
                }

                Divider(color = Color(0xFF232732))
                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable side-by-side rows representing parameters
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    comparisonList.forEach { asset ->
                        Column(
                            modifier = Modifier
                                .width(140.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF07080A))
                                .border(BorderStroke(1.dp, Color(0xFF232732)), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().height(60.dp).background(Color.Black)) {
                                VehicleCanvas(imageUrl = asset.imageUrl, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("${asset.year} ${asset.make}", color = Color(0xFF00E5FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(asset.model, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Divider(color = Color(0xFF161920))
                            Spacer(modifier = Modifier.height(8.dp))

                            ComparisonTextCell(label = "LISTING MSRP", value = "$${asset.listingPrice.toInt()}")
                            ComparisonTextCell(label = "MILEAGE", value = "${asset.mileage} mi")
                            ComparisonTextCell(label = "VALUATION INDEX", value = "${asset.valuationScore}/100")
                            ComparisonTextCell(label = "TRUST INDEX", value = "${asset.sellerTrustScore}%")
                            ComparisonTextCell(label = "FUEL SYSTEM", value = asset.fuelType.split(" ").first())
                            ComparisonTextCell(label = "OWNER LOGS", value = asset.ownershipHistory)
                            ComparisonTextCell(label = "ACCIDENT DEED", value = asset.accidentHistory)

                            Spacer(modifier = Modifier.weight(1f))
                            
                            Button(
                                onClick = {
                                    viewModel.toggleComparison(asset.id)
                                },
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                Text("REMOVE", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ComparisonTextCell(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(label, color = Color(0xFFADB5C4), fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
