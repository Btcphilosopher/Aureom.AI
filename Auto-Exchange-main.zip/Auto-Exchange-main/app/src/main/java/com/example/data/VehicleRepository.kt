package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class VehicleRepository(private val dao: VehicleDao) {

    val marketplaceListings: Flow<List<VehicleListing>> = dao.getMarketplaceListings()
    val garageVehicles: Flow<List<VehicleListing>> = dao.getGarageVehicles()
    val favoriteListings: Flow<List<VehicleListing>> = dao.getFavoriteListings()
    val appointments: Flow<List<Appointment>> = dao.getAllAppointments()
    val transactions: Flow<List<Transaction>> = dao.getAllTransactions()

    suspend fun getListingById(id: Int): VehicleListing? {
        return dao.getListingById(id)
    }

    suspend fun toggleFavorite(id: Int, isFavorite: Boolean) {
        dao.updateFavoriteStatus(id, isFavorite)
    }

    suspend fun insertListing(listing: VehicleListing): Long {
        return dao.insertListing(listing)
    }

    suspend fun updateListing(listing: VehicleListing) {
        dao.updateListing(listing)
    }

    suspend fun deleteListing(listing: VehicleListing) {
        dao.deleteListing(listing)
    }

    // Interactive Auction Bidding
    suspend fun placeBid(vehicleId: Int, amount: Double, bidderName: String): Boolean {
        val vehicle = dao.getListingById(vehicleId) ?: return false
        
        // Ensure bid is higher than current bid (or listing price if no bids)
        val minimumBid = if (vehicle.bidsCount > 0) vehicle.currentBid else vehicle.listingPrice
        if (amount <= minimumBid) {
            return false
        }

        // 1. Insert Bid event
        dao.insertBid(Bid(vehicleId = vehicleId, bidderName = bidderName, amount = amount))

        // 2. Update Vehicle listing status
        val updatedVehicle = vehicle.copy(
            bidsCount = vehicle.bidsCount + 1,
            currentBid = amount
        )
        dao.updateListing(updatedVehicle)
        return true
    }

    fun getBidsForVehicle(vehicleId: Int): Flow<List<Bid>> {
        return dao.getBidsForVehicle(vehicleId)
    }

    // Appointment Booking
    suspend fun bookAppointment(vehicleId: Int, vehicleName: String, date: String, time: String, location: String, type: String) {
        val appointment = Appointment(
            vehicleId = vehicleId,
            vehicleName = vehicleName,
            date = date,
            time = time,
            location = location,
            type = type,
            status = "Scheduled"
        )
        dao.insertAppointment(appointment)
    }

    suspend fun deleteAppointment(id: Int) {
        dao.deleteAppointment(id)
    }

    // Transaction Management
    suspend fun initiateTransaction(
        vehicleId: Int,
        buyerName: String,
        transactionType: String // "Buy", "Trade-In", "Auction Win"
    ): Long {
        val vehicle = dao.getListingById(vehicleId) ?: return -1
        
        // Check if there is an existing transaction
        val existing = dao.getTransactionByVehicleId(vehicleId)
        if (existing != null) {
            return existing.id.toLong()
        }

        val price = if (vehicle.listingType == "AUCTION") vehicle.currentBid else vehicle.listingPrice
        
        val transaction = Transaction(
            vehicleId = vehicleId,
            vehicleName = "${vehicle.year} ${vehicle.make} ${vehicle.model}",
            price = price,
            transactionType = transactionType,
            status = "Offer Made",
            documentStatus = "Unsigned",
            buyerName = buyerName,
            sellerName = vehicle.sellerName
        )
        
        return dao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: Transaction) {
        dao.updateTransaction(transaction)
    }

    suspend fun getTransactionByVehicleId(vehicleId: Int): Transaction? {
        return dao.getTransactionByVehicleId(vehicleId)
    }
}
