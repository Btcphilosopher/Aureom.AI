package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AureliaDarkColorScheme = darkColorScheme(
    primary = CyberBlue,
    secondary = ElectricAmber,
    tertiary = ActiveGreen,
    background = MatteBlack,
    surface = SlateGrayDark,
    onPrimary = MatteBlack,
    onSecondary = MatteBlack,
    onBackground = OffWhiteText,
    onSurface = OffWhiteText,
    onSurfaceVariant = DullSilverText
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // We enforce the premium Dark Mode aesthetic for the Aurelia garage concept
    MaterialTheme(
        colorScheme = AureliaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
