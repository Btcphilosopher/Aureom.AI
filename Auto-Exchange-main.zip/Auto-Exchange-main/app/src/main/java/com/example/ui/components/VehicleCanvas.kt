package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun VehicleCanvas(
    imageUrl: String,
    modifier: Modifier = Modifier
) {
    // Choose dynamic glow colors based on the vehicle's design theme ID
    val glowColor = when (imageUrl) {
        "porsche_911" -> Color(0xFF00E5FF)  // Shark Blue
        "tesla_s" -> Color(0xFFE040FB)      // Pulse Magenta
        "bmw_m4" -> Color(0xFF00E676)       // Isle of Man Green
        "audi_rs" -> Color(0xFFFF9100)      // Amber Orange
        "mercedes_c63" -> Color(0xFFE53935) // Cyber Red
        else -> MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = 0.15f), Color.Transparent),
                radius = 450f
            ))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw dashboard grids (Tesla/BMW cockpit background)
            val gridSpacing = 24.dp.toPx()
            val gridPaint = Paint().apply {
                color = Color.White.copy(alpha = 0.03f)
                strokeWidth = 1f
            }
            var x = 0f
            while (x < w) {
                drawLine(
                    color = Color.White.copy(alpha = 0.03f),
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 1f
                )
                x += gridSpacing
            }
            var y = 0f
            while (y < h) {
                drawLine(
                    color = Color.White.copy(alpha = 0.03f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
                y += gridSpacing
            }

            // 2. Draw luxury car profile silhouette
            val path = Path().apply {
                // Ground starting point
                moveTo(w * 0.10f, h * 0.70f)
                
                // Front lip spoiler
                lineTo(w * 0.15f, h * 0.70f)
                
                // Front bumper curve up
                quadraticTo(w * 0.17f, h * 0.65f, w * 0.19f, h * 0.63f)
                
                // Hood slope
                quadraticTo(w * 0.28f, h * 0.50f, w * 0.35f, h * 0.45f)
                
                // Windshield slide
                quadraticTo(w * 0.42f, h * 0.33f, w * 0.48f, h * 0.33f)
                
                // Roof line flat-ish back
                lineTo(w * 0.60f, h * 0.33f)
                
                // Rear fastback slope
                quadraticTo(w * 0.73f, h * 0.42f, w * 0.81f, h * 0.54f)
                
                // Spoiler lip
                quadraticTo(w * 0.86f, h * 0.54f, w * 0.88f, h * 0.56f)
                
                // Rear bumper down
                lineTo(w * 0.87f, h * 0.65f)
                
                // Rear exhaust block
                quadraticTo(w * 0.85f, h * 0.70f, w * 0.82f, h * 0.70f)
                
                // Underbody step towards rear wheel well
                lineTo(w * 0.76f, h * 0.70f)
            }

            // Wheels positions
            val wheelY = h * 0.70f
            val frontWheelCenter = Offset(w * 0.27f, wheelY)
            val rearWheelCenter = Offset(w * 0.68f, wheelY)
            val wheelRadius = h * 0.13f

            // Wheel cutout details
            val cutoutPath = Path().apply {
                addPath(path)
                // We draw the silhouette, skipping the tires
            }

            // Draw shadow base gradient under the silhouette
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(glowColor.copy(alpha = 0.25f), glowColor.copy(alpha = 0.01f)),
                    startY = h * 0.35f,
                    endY = h * 0.70f
                )
            )

            // Draw the car outline stroke
            drawPath(
                path = path,
                color = glowColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw aerodynamic downforce speed trails
            drawLine(
                color = glowColor.copy(alpha = 0.3f),
                start = Offset(w * 0.05f, h * 0.52f),
                end = Offset(w * 0.22f, h * 0.52f),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = glowColor.copy(alpha = 0.4f),
                start = Offset(w * 0.38f, h * 0.36f),
                end = Offset(w * 0.58f, h * 0.36f),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = glowColor.copy(alpha = 0.2f),
                start = Offset(w * 0.78f, h * 0.48f),
                end = Offset(w * 0.93f, h * 0.48f),
                strokeWidth = 1.5.dp.toPx()
            )

            // 3. Draw high-end CNC wheels
            // Outer tires
            drawCircle(color = Color(0xFF090A0C), radius = wheelRadius, center = frontWheelCenter)
            drawCircle(color = Color(0xFF090A0C), radius = wheelRadius, center = rearWheelCenter)

            // Metal alloy tire rim
            drawCircle(
                color = glowColor.copy(alpha = 0.9f),
                radius = wheelRadius * 0.85f,
                center = frontWheelCenter,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = glowColor.copy(alpha = 0.9f),
                radius = wheelRadius * 0.85f,
                center = rearWheelCenter,
                style = Stroke(width = 2.dp.toPx())
            )

            // Rim inner spokes (5-Spoke turbine design)
            for (i in 0 until 5) {
                val angle = (i * 72 * Math.PI / 180.0)
                val spokeX = (wheelRadius * 0.8f * Math.cos(angle)).toFloat()
                val spokeY = (wheelRadius * 0.8f * Math.sin(angle)).toFloat()

                drawLine(
                    color = glowColor.copy(alpha = 0.7f),
                    start = frontWheelCenter,
                    end = Offset(frontWheelCenter.x + spokeX, frontWheelCenter.y + spokeY),
                    strokeWidth = 2.dp.toPx()
                )
                drawLine(
                    color = glowColor.copy(alpha = 0.7f),
                    start = rearWheelCenter,
                    end = Offset(rearWheelCenter.x + spokeX, rearWheelCenter.y + spokeY),
                    strokeWidth = 2.dp.toPx()
                )
            }

            // Wheel axles center pins
            drawCircle(color = Color.White, radius = 4f, center = frontWheelCenter)
            drawCircle(color = Color.White, radius = 4f, center = rearWheelCenter)

            // 4. Draw laser headlights
            drawCircle(color = Color.White, radius = 5f, center = Offset(w * 0.17f, h * 0.62f))
            drawCircle(color = glowColor, radius = 10f, center = Offset(w * 0.17f, h * 0.62f), alpha = 0.5f)

            // 5. Draw LED active brake tail strips
            drawLine(
                color = Color.Red,
                start = Offset(w * 0.83f, h * 0.55f),
                end = Offset(w * 0.85f, h * 0.57f),
                strokeWidth = 3f
            )
        }
    }
}
