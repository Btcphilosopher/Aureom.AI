package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Estimates vehicle value and depreciation trends using Gemini.
     * Falls back to high-fidelity mathematical modeling if API key is not configured or network fails.
     */
    suspend fun getValuation(
        make: String,
        model: String,
        year: Int,
        mileage: Int,
        condition: String // "Excellent", "Good", "Fair", "Needs Work"
    ): ValuationResult = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            System.getenv("GEMINI_API_KEY") ?: ""
        }

        // Calculate stable, high-fidelity localized baseline estimate FIRST
        val baseline = estimateAlgorithmically(make, model, year, mileage, condition)

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey.contains("placeholder", ignoreCase = true)) {
            Log.w(TAG, "Gemini API key is not configured or using default/placeholder key. Relying on baseline mathematical engine.")
            return@withContext baseline
        }

        val prompt = """
            You are the core pricing engine of Aurelia Auto Exchange (a luxury digital stock exchange for vehicles).
            Analyze and calculate a precise pricing and prediction package for:
            Vehicle: $year $make $model
            Mileage: $mileage miles
            Condition: $condition
            
            Provide a complete and highly analytical breakdown of this vehicle's current and future market position as a JSON object with the following structure:
            {
               "estimatedValue": $${baseline.estimatedValue.toInt()} (adjust slightly if needed but keep near this realistic baseline),
               "privateSaleRange": "$${(baseline.estimatedValue * 0.95).toInt()} - $${(baseline.estimatedValue * 1.05).toInt()}",
               "dealerPriceRange": "$${(baseline.estimatedValue * 1.08).toInt()} - $${(baseline.estimatedValue * 1.20).toInt()}",
               "marketDemandScore": 0.0 to 10.0 (e.g. 8.5),
               "marketDemandDescription": "Short text summary of the current market supply and velocity for this vehicle",
               "fiveYearDepreciation": [
                   {"year": "Current", "value": ${baseline.depreciationCurve[0].value}},
                   {"year": "Year 1", "value": ${baseline.depreciationCurve[1].value}},
                   {"year": "Year 2", "value": ${baseline.depreciationCurve[2].value}},
                   {"year": "Year 3", "value": ${baseline.depreciationCurve[3].value}},
                   {"year": "Year 4", "value": ${baseline.depreciationCurve[4].value}},
                   {"year": "Year 5", "value": ${baseline.depreciationCurve[5].value}}
               ],
               "smartRecommendations": [
                  "Recommendation 1 on whether to sell now, trade-in, or hold depending on depreciation curve and condition",
                  "Recommendation 2 based on fuel type or service strategy"
               ],
               "aiCommentary": "A professional, Bloomberg terminal-styled analytical report (90-120 words) analyzing this asset's current valuation index, market liquidity, and trade-in yield."
            }
            Do not include any greeting, explanation or markdown formatting outside the raw JSON object. Provide only valid JSON.
        """.trimIndent()

        try {
            val jsonPayload = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                }
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL/$MODEL:generateContent?key=$apiKey")
                .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: ""
                    Log.e(TAG, "Gemini API returned error code ${response.code}: $err")
                    return@withContext baseline
                }

                val responseStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseStr)
                val textResponse = responseJson
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                // Parse generated content
                val mainJson = JSONObject(textResponse.trim())
                val valEst = mainJson.optDouble("estimatedValue", baseline.estimatedValue)
                val pRange = mainJson.optString("privateSaleRange", baseline.privateSaleRange)
                val dRange = mainJson.optString("dealerPriceRange", baseline.dealerPriceRange)
                val demand = mainJson.optDouble("marketDemandScore", baseline.marketDemandScore)
                val demandDesc = mainJson.optString("marketDemandDescription", baseline.marketDemandDescription)
                val comm = mainJson.optString("aiCommentary", baseline.aiCommentary)

                val recsArray = mainJson.optJSONArray("smartRecommendations")
                val recsList = mutableListOf<String>()
                if (recsArray != null) {
                    for (i in 0 until recsArray.length()) {
                        recsList.add(recsArray.getString(i))
                    }
                } else {
                    recsList.addAll(baseline.smartRecommendations)
                }

                val depArray = mainJson.optJSONArray("fiveYearDepreciation")
                val depList = mutableListOf<DepreciationPoint>()
                if (depArray != null) {
                    for (i in 0 until depArray.length()) {
                        val dObj = depArray.getJSONObject(i)
                        depList.add(
                            DepreciationPoint(
                                year = dObj.getString("year"),
                                value = dObj.getDouble("value")
                            )
                        )
                    }
                } else {
                    depList.addAll(baseline.depreciationCurve)
                }

                ValuationResult(
                    estimatedValue = valEst,
                    privateSaleRange = pRange,
                    dealerPriceRange = dRange,
                    marketDemandScore = demand,
                    marketDemandDescription = demandDesc,
                    depreciationCurve = depList,
                    smartRecommendations = recsList,
                    aiCommentary = comm,
                    isFromAi = true
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error invoking Gemini API: ${e.message}", e)
            baseline
        }
    }

    /**
     * Reliable algorithmic valuation engine representing the core depreciation equations.
     */
    fun estimateAlgorithmically(
        make: String,
        model: String,
        year: Int,
        mileage: Int,
        condition: String
    ): ValuationResult {
        // Base pricing guide
        val baseMsrp = when (make.lowercase()) {
            "porsche" -> if (model.contains("911")) 195000.0 else 110000.0
            "tesla" -> if (model.contains("s")) 85000.0 else 55000.0
            "bmw" -> if (model.contains("m")) 78000.0 else 48000.0
            "audi" -> if (model.contains("rs") || model.contains("e-tron")) 115000.0 else 50000.0
            "mercedes-amg", "mercedes" -> if (model.contains("c63")) 82000.0 else 60000.0
            else -> 45000.0
        }

        val age = (2026 - year).coerceAtLeast(0)

        // Exponential decay algorithm for depreciation
        // Formula: MSRP * (1 - r_age)^age * (1 - r_mileage)^(mileage / 10000)
        val rateAge = 0.09 // 9% per year
        val rateMileage = 0.045 // 4.5% per 10k miles

        var estValue = baseMsrp * Math.pow(1.0 - rateAge, age.toDouble())
        estValue *= Math.pow(1.0 - rateMileage, (mileage.toDouble() / 10000.0))

        // Condition multiplier
        val conditionMult = when (condition.lowercase()) {
            "excellent" -> 1.05
            "good" -> 0.96
            "fair" -> 0.85
            "needs work" -> 0.68
            else -> 1.0
        }
        estValue *= conditionMult
        estValue = estValue.coerceAtLeast(3000.0) // scrap price floor

        // Create depreciation curve
        val currentVal = estValue
        val curvePoints = (0..5).map { y ->
            val futureAge = age + y
            val futureMileage = mileage + (y * 11000) // average 11k miles per year projection
            var futVal = baseMsrp * Math.pow(1.0 - rateAge, futureAge.toDouble())
            futVal *= Math.pow(1.0 - rateMileage, (futureMileage.toDouble() / 10000.0))
            futVal *= conditionMult
            val label = if (y == 0) "Current" else "Year $y"
            DepreciationPoint(label, futVal.coerceAtLeast(1500.0))
        }

        // Generate algorithmic recommendations
        val score = when {
            age <= 1 && mileage < 5000 -> 9.5
            age < 3 && mileage < 30000 -> 8.2
            age < 6 && mileage < 70000 -> 6.5
            else -> 4.8
        }

        val demandDesc = when {
            score >= 9.0 -> "Velocity index is extremely high. High liquidity, buyers are paying a premium."
            score >= 7.5 -> "Strong demand. Normal listing period is less than 9 days."
            score >= 6.0 -> "Moderate demand. Stable pricing with mild seasonality shifts."
            else -> "Market supply is saturated. Lower price to optimize asset turnaround."
        }

        val recommendations = listOf(
            if (score >= 8.0) "Highly resilient asset. Consider listing C2C to capture premium private buyer yields."
            else "Standard depreciation has stabilized. Ideal candidate for instant Aurelia Dealer Trade-In.",
            if (mileage > 40000) "Performing the major service inspection milestone will elevate buyer confidence and increase sales yields by +$1,200."
            else "Extend maintenance logs in Aurelia blockchain. Highly verifiable history increases price bounds.",
            "Suggested private listing strategy: Set starting price at ${((estValue * 1.03) / 100).toInt() * 100} to allow head-room for negotiation."
        )

        val textReport = "The $year $make $model demonstrates a highly predictable depreciation curve. Present valuation indicates a residual asset value of ${(estValue / baseMsrp * 100).toInt()}% of its estimated baseline. Liquid markets indicate low dealer premium spreads, representing high private trading stability. Verified inspections by Aurelia protect transaction yields."

        return ValuationResult(
            estimatedValue = estValue,
            privateSaleRange = "$${(estValue * 0.94).toInt()} - $${(estValue * 1.04).toInt()}",
            dealerPriceRange = "$${(estValue * 1.06).toInt()} - $${(estValue * 1.18).toInt()}",
            marketDemandScore = score,
            marketDemandDescription = demandDesc,
            depreciationCurve = curvePoints,
            smartRecommendations = recommendations,
            aiCommentary = textReport,
            isFromAi = false
        )
    }
}

data class ValuationResult(
    val estimatedValue: Double,
    val privateSaleRange: String,
    val dealerPriceRange: String,
    val marketDemandScore: Double,
    val marketDemandDescription: String,
    val depreciationCurve: List<DepreciationPoint>,
    val smartRecommendations: List<String>,
    val aiCommentary: String,
    val isFromAi: Boolean
)

data class DepreciationPoint(
    val year: String,
    val value: Double
)
