package com.example.api

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Moshi models for Gemini content generation ---

data class Part(
    val text: String? = null
)

data class Content(
    val parts: List<Part>
)

data class GenerateContentRequest(
    val contents: List<Content>
)

data class Candidate(
    val content: Content
)

data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

// --- Retrofit setup ---

interface GeminiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiClient {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: GeminiService = retrofit.create(GeminiService::class.java)

    /**
     * Executes content generation query to Gemini.
     */
    suspend fun evaluateNetworkPerformance(
        apiKey: String,
        activeTransportsSummary: String,
        sovereignModeStatus: Boolean,
        credits: Double,
        recentUptimeSeconds: Long
    ): String {
        val prompt = """
            You are the AURELIA NETWORK CYBERNETIC CO-PILOT. You run within AURELIA CONNECT, the sovereign network orchestration layer of a high-tech digitised civilization.
            
            We are analyzing the user's active connection and sovereign node telemetry.
            
            Active Transports: $activeTransportsSummary
            Sovereign Network Mode: ${if (sovereignModeStatus) "ACTIVE (Maximum security, decentralized routes prioritized)" else "OFF (Mixed paths)"}
            Sovereign Credits: ${String.format("%.2f", credits)} credits
            Contributed Node Uptime: ${recentUptimeSeconds / 3600} hours, ${(recentUptimeSeconds % 3600) / 60} minutes
            
            Based on these parameters, please generate a concise, professional tactful analysis report in the voice of a Sovereign Network Operations Center (NOC) mission analyst. Use technical retro-futuristic terminology (e.g. quantum packets, low-orbit satellite beams, P2P telemetry, mesh routing vector).
            Format the response with exactly three clear cybernetic sections:
            1. [SECURITY THREAT ASSESSMENT & PATH INTEGRITY] - assess the current route configuration security posture.
            2. [MULTI-PATH OPTIMIZATION INSTRUCTIONS] - suggest specific flow allocation updates (e.g. Wi-Fi: 30%, LEO Satellite: 50%, P2P Mesh: 20%).
            3. [SOVEREIGN CONTRIBUTOR METRICS REVIEW] - evaluate their credit earnings, network score, and node health.
            
            Keep the report highly technical, structured, and under 300 words. Avoid generic introductory conversational phrases. Get straight to the analysis.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = prompt)))
            )
        )

        return try {
            val response = service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "CO-PILOT TELEMETRY REPORT FAILED. LINK TIMEOUT."
        } catch (e: Exception) {
            "CO-PILOT CORRELATION EXCEPTION: ${e.localizedMessage ?: "Unknown link vector interrupt."}\nInspect local antenna connection and valid GEMINI_API_KEY."
        }
    }
}
