package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.scale
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.BuildConfig
import com.example.api.GeminiClient
import com.example.data.TransactionRecord
import com.example.ui.theme.*
import com.example.ui.viewmodel.AureliaViewModel
import com.example.ui.viewmodel.GeminiReportState
import com.example.ui.viewmodel.MarketplaceItem
import com.example.ui.viewmodel.NetworkInterfaceInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    AureliaConnectConsole(
                        modifier = Modifier
                            .padding(innerPadding)
                            .fillMaxSize()
                            .background(CyberBlack)
                    )
                }
            }
        }
    }
}

@Composable
fun AureliaConnectConsole(modifier: Modifier = Modifier) {
    val viewModel: AureliaViewModel = viewModel()
    
    // UI state states
    val interfaces by viewModel.interfaces.collectAsState()
    val aggregateSpeed by viewModel.aggregateThroughput.collectAsState()
    val aggregateLat by viewModel.aggregateLatency.collectAsState()
    val aggregateLoss by viewModel.aggregatePacketLoss.collectAsState()
    val eventLog by viewModel.nocEventLog.collectAsState()

    val balance by viewModel.creditsBalance.collectAsState()
    val score by viewModel.reputationScore.collectAsState()
    val uptimeText by viewModel.activeUptimeText.collectAsState()
    val sharedGb by viewModel.totalSharedGb.collectAsState()

    val alwaysOnlineStat by viewModel.alwaysOnline.collectAsState()
    val sovereignStat by viewModel.sovereignMode.collectAsState()
    val edgeModeStat by viewModel.edgeNodeMode.collectAsState()
    val bandwidthSliderStat by viewModel.maxBandwidthLimitGb.collectAsState()
    val batterySliderStat by viewModel.batteryCapPercent.collectAsState()

    val marketplaceLines by viewModel.marketplaceItems.collectAsState()
    val transactions by viewModel.transactionsList.collectAsState()
    val geminiStatus by viewModel.geminiState.collectAsState()

    var activeTab by remember { mutableStateOf("DASHBOARD") } // DASHBOARD, PROOF, MARKET, COPILOT
    var showQuickSellDialog by remember { mutableStateOf(false) }
    var selectedInterfaceDetails by remember { mutableStateOf<NetworkInterfaceInfo?>(null) }

    Column(modifier = modifier) {
        // 1. Mission Header Bar
        NOCHeaderBar(
            speedMbps = aggregateSpeed,
            latencyMs = aggregateLat,
            lossPercent = aggregateLoss,
            uptime = uptimeText
        )

        HorizontalDivider(color = TacticalSlate, thickness = 1.dp)

        // 2. Station Selector Tab Selector
        NOCStationTabs(
            activeTab = activeTab,
            onTabSelected = { activeTab = it }
        )

        HorizontalDivider(color = TacticalSlate, thickness = 1.dp)

        // 3. Central Operational Content Deck
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            when (activeTab) {
                "DASHBOARD" -> DashboardScreen(
                    interfaces = interfaces,
                    alwaysOnline = alwaysOnlineStat,
                    sovereignMode = sovereignStat,
                    eventLog = eventLog,
                    onToggleAlwaysOnline = { viewModel.toggleAlwaysOnline(it) },
                    onToggleSovereign = { viewModel.toggleSovereignMode(it) },
                    onInterfaceClicked = { selectedInterfaceDetails = it }
                )
                "PROOF" -> ProofOfBandwidthScreen(
                    credits = balance,
                    rating = score,
                    uptime = uptimeText,
                    sharedGb = sharedGb,
                    activeEdgeMode = edgeModeStat,
                    maxBandwidth = bandwidthSliderStat,
                    batteryCap = batterySliderStat,
                    transactions = transactions,
                    onEdgeModeChanged = { viewModel.changeEdgeMode(it) },
                    onSlidersUpdated = { bw, bat -> viewModel.updateSliders(bw, bat) },
                    onQuickSellClicked = { showQuickSellDialog = true }
                )
                "MARKET" -> MarketplaceScreen(
                    credits = balance,
                    items = marketplaceLines,
                    onPurchaseLease = { viewModel.purchaseTransitChannel(it) }
                )
                "COPILOT" -> CopilotScreen(
                    interfaces = interfaces,
                    sovereignMode = sovereignStat,
                    credits = balance,
                    uptimeSeconds = viewModel.uptimeSeconds.value,
                    geminiStatus = geminiStatus,
                    onAnalyzeRequest = { key -> viewModel.requestAureliaIntelligenceReport(key) }
                )
            }
        }

        // 4. Interface details popup dialogue if chosen
        selectedInterfaceDetails?.let { info ->
            InterfaceDetailsDialog(
                info = info,
                onDismiss = { selectedInterfaceDetails = null }
            )
        }

        // 5. Quick sell dialogue
        if (showQuickSellDialog) {
            QuickSellDialog(
                onDismiss = { showQuickSellDialog = false },
                onConfirmSell = { desc, gb, credits ->
                    viewModel.listBandwidthForCredits(desc, gb, credits)
                    showQuickSellDialog = false
                }
            )
        }
    }
}

// --- NOC Header Component ---
@Composable
fun NOCHeaderBar(
    speedMbps: Double,
    latencyMs: Int,
    lossPercent: Double,
    uptime: String
) {
    val blinkingAlpha by rememberInfiniteTransition().animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SpaceGrey),
        border = BorderStroke(1.dp, TacticalSlate)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Application Title Core Theme
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(CyberGreen.copy(alpha = blinkingAlpha))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AURELIA CONNECT",
                        color = CyberBrass,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 18.sp,
                        letterSpacing = 1.5.sp
                    )
                }
                
                // Status indicator pill
                Box(
                    modifier = Modifier
                        .border(1.dp, ElectricCyan.copy(alpha = 0.2f), RoundedCornerShape(50))
                        .background(ElectricCyan.copy(alpha = 0.1f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ALWAYS ONLINE",
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // MultiPath aggregations
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HeaderMetricItem(
                    label = "FLOW RATE",
                    value = String.format("%.1f Mbps", speedMbps),
                    color = ElectricCyan
                )
                HeaderMetricItem(
                    label = "COMPOSITE LATENCY",
                    value = "$latencyMs ms",
                    color = CyberGold
                )
                HeaderMetricItem(
                    label = "PACKET INTACTNESS",
                    value = String.format("%.3f%% Loss", lossPercent),
                    color = if (lossPercent > 1.0) CyberRed else CyberGreen
                )
                HeaderMetricItem(
                    label = "AURELIA UPTIME",
                    value = uptime,
                    color = DimWhite
                )
            }
        }
    }
}

@Composable
fun HeaderMetricItem(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            color = GridWhite,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = value,
            color = color,
            fontSize = 15.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- NOC Stations Tab Selectors ---
@Composable
fun NOCStationTabs(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    val tabs = listOf(
        Pair("DASHBOARD", "NOC CORE"),
        Pair("PROOF", "VERIFIABILITY"),
        Pair("MARKET", "MARKETPLACE"),
        Pair("COPILOT", "AI CO-PILOT")
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBlack)
            .padding(vertical = 4.dp, horizontal = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        tabs.forEach { (tabId, subtitle) ->
            val isSelected = activeTab == tabId
            val borderColor = if (isSelected) CyberBrass.copy(alpha = 0.6f) else TacticalSlate.copy(alpha = 0.4f)
            val bgBrush = if (isSelected) {
                Brush.verticalGradient(listOf(CyberBrass.copy(alpha = 0.12f), SpaceGrey))
            } else {
                Brush.verticalGradient(listOf(CyberBlack, CyberBlack))
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bgBrush)
                    .border(1.dp, borderColor, RoundedCornerShape(16.dp))
                    .clickable { onTabSelected(tabId) }
                    .padding(vertical = 10.dp)
                    .testTag("tab_$tabId"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = tabId,
                        color = if (isSelected) ElectricCyan else GridWhite,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = subtitle,
                        color = if (isSelected) CyberBrass else GridWhite.copy(alpha = 0.5f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }
        }
    }
}

// --- station 1: DASHBOARD ---
@Composable
fun DashboardScreen(
    interfaces: List<NetworkInterfaceInfo>,
    alwaysOnline: Boolean,
    sovereignMode: Boolean,
    eventLog: List<String>,
    onToggleAlwaysOnline: (Boolean) -> Unit,
    onToggleSovereign: (Boolean) -> Unit,
    onInterfaceClicked: (NetworkInterfaceInfo) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Live Radar Overlay Plot Animation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    LiveNetworkMapPlot(interfaces = interfaces)
                }
            }
        }

        item {
            // Toggles dashboard
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ToggleCard(
                    title = "Always-Online Core",
                    subtitle = "Proactive backup swap & routing verification",
                    checked = alwaysOnline,
                    onCheckedChange = onToggleAlwaysOnline,
                    accentColor = CyberGreen,
                    modifier = Modifier.weight(1f)
                )
                ToggleCard(
                    title = "Sovereign Mode",
                    subtitle = "Bypass standard ISP; tunnel via orbital P2P Mesh",
                    checked = sovereignMode,
                    onCheckedChange = onToggleSovereign,
                    accentColor = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Multipath interfaces lists
        item {
            Text(
                text = "ACTIVE TRANSPORT MULTIPATH ARRAYS",
                color = CyberBrass,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
            )
        }

        items(interfaces) { info ->
            NetworkInterfaceCard(info = info, onClick = { onInterfaceClicked(info) })
        }

        // Live Alerts Feed Ticker
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(SpaceGrey)
                    .border(1.dp, TacticalSlate, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "NOC COMMAND CENTER LINK AGENT LOGS",
                    color = CyberGold,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Column(
                    modifier = Modifier
                        .height(80.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    eventLog.take(5).forEach { text ->
                        Text(
                            text = text,
                            color = GridWhite,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LiveNetworkMapPlot(interfaces: List<NetworkInterfaceInfo>) {
    val infiniteTransition = rememberInfiniteTransition()
    val radarLineAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val signalPulseSize by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        )
    )

    Canvas(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = size.height * 0.45f

        // Draw compass circle grid
        drawCircle(
            color = GridWhite.copy(alpha = 0.15f),
            radius = maxRadius,
            center = center,
            style = Stroke(width = 1f)
        )
        drawCircle(
            color = GridWhite.copy(alpha = 0.1f),
            radius = maxRadius * 0.6f,
            center = center,
            style = Stroke(width = 1f)
        )
        drawCircle(
            color = GridWhite.copy(alpha = 0.05f),
            radius = maxRadius * 0.3f,
            center = center,
            style = Stroke(width = 15f)
        )

        // Draw cross grid axes
        drawLine(
            color = GridWhite.copy(alpha = 0.15f),
            start = Offset(center.x - maxRadius, center.y),
            end = Offset(center.x + maxRadius, center.y),
            strokeWidth = 1f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
        )
        drawLine(
            color = GridWhite.copy(alpha = 0.15f),
            start = Offset(center.x, center.y - maxRadius),
            end = Offset(center.x, center.y + maxRadius),
            strokeWidth = 1f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
        )

        // Draw active radar sweep beam
        val lineLength = maxRadius
        val angleRad = Math.toRadians(radarLineAngle.toDouble())
        val scanX = center.x + (lineLength * cos(angleRad)).toFloat()
        val scanY = center.y + (lineLength * sin(angleRad)).toFloat()

        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(ElectricCyan.copy(alpha = 0.7f), Color.Transparent),
                start = center,
                end = Offset(scanX, scanY)
            ),
            start = center,
            end = Offset(scanX, scanY),
            strokeWidth = 2f
        )

        // Draw a pulse center node
        drawCircle(
            color = CyberGreen.copy(alpha = 0.2f),
            radius = signalPulseSize,
            center = center,
            style = Stroke(width = 2f)
        )
        drawCircle(
            color = CyberGreen,
            radius = 4.dp.toPx(),
            center = center
        )

        // Draw icons representing connection channels around the grid
        val activeConnected = interfaces.filter { it.isConnected }
        activeConnected.forEachIndexed { idx, item ->
            // Distribute on circular ring
            val segmentAngle = 360f / activeConnected.size * idx
            val segRad = Math.toRadians(segmentAngle.toDouble())
            val positionRadius = maxRadius * (0.5f + (idx % 2) * 0.25f)
            val nodeX = center.x + (positionRadius * cos(segRad)).toFloat()
            val nodeY = center.y + (positionRadius * sin(segRad)).toFloat()

            // Draw line to center indicating multi-path transport flow (QUIC track)
            drawLine(
                color = if (item.type == "SATELLITE") CyberBrass.copy(alpha = 0.4f) else ElectricBlue.copy(alpha = 0.4f),
                start = Offset(nodeX, nodeY),
                end = center,
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 12f), (radarLineAngle * 2) % 20)
            )

            // Draw node dot
            val dotColor = when (item.type) {
                "SATELLITE" -> CyberBrass
                "MESH" -> ElectricCyan
                "FIBER" -> ElectricBlue
                else -> CyberGreen
            }
            drawCircle(
                color = dotColor,
                radius = 5.dp.toPx(),
                center = Offset(nodeX, nodeY)
            )
            drawCircle(
                color = dotColor.copy(alpha = 0.3f),
                radius = 10.dp.toPx(),
                center = Offset(nodeX, nodeY),
                style = Stroke(width = 1f)
            )
        }
    }
}

@Composable
fun ToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SpaceGrey),
        border = BorderStroke(1.dp, if (checked) accentColor.copy(alpha = 0.8f) else TacticalSlate)
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = if (checked) ElectricCyan else DimWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Switch(
                    checked = checked,
                    onCheckedChange = onCheckedChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = accentColor,
                        checkedTrackColor = accentColor.copy(alpha = 0.2f),
                        uncheckedThumbColor = GridWhite,
                        uncheckedTrackColor = TacticalSlate
                    ),
                    modifier = Modifier.scale(0.8f)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                color = GridWhite,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 12.sp
            )
        }
    }
}



@Composable
fun NetworkInterfaceCard(
    info: NetworkInterfaceInfo,
    onClick: () -> Unit
) {
    val stateColor = if (info.isConnected) CyberGreen else GridWhite.copy(alpha = 0.4f)
    val indicatorColor = when (info.type) {
        "FIBER" -> ElectricBlue
        "CELLULAR" -> CyberGold
        "SATELLITE" -> CyberBrass
        "MESH" -> ElectricCyan
        "DECENTRALIZED" -> CyberGreen
        else -> ElectricCyan
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("interface_card_${info.name.replace(" ", "_")}"),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, if (info.isConnected) TacticalSlate else TacticalSlate.copy(alpha = 0.4f)),
        colors = CardDefaults.cardColors(containerColor = SpaceGrey.copy(alpha = if (info.isConnected) 1.0f else 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Signal Dot
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(stateColor)
            )

            // Dynamic Path Label
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = info.name,
                        color = if (info.isConnected) DimWhite else GridWhite.copy(alpha = 0.4f),
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(indicatorColor.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                            .border(0.5.dp, indicatorColor.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = info.type,
                            color = indicatorColor,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                
                // Flow allocation visual bar
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(
                        progress = { (info.flowWeightPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = indicatorColor,
                        trackColor = TacticalSlate
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${info.flowWeightPercent}% ALLOC",
                        color = if (info.isConnected) CyberBrass else GridWhite.copy(alpha = 0.4f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // High precision status metrics
            Column(
                horizontalAlignment = Alignment.End
            ) {
                if (info.isConnected) {
                    Text(
                        text = String.format("%.1f Mbps", info.throughputMbps),
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${info.latencyMs} ms / ${String.format("%.1f%%", info.packetLossPercent)} loss",
                        color = GridWhite,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    Text(
                        text = "STANDBY / OFFLINE",
                        color = GridWhite.copy(alpha = 0.4f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// --- station 2: PROOF OF BANDWIDTH & SUSTENANCE ---
@Composable
fun ProofOfBandwidthScreen(
    credits: Double,
    rating: Double,
    uptime: String,
    sharedGb: Double,
    activeEdgeMode: String,
    maxBandwidth: Int,
    batteryCap: Int,
    transactions: List<TransactionRecord>,
    onEdgeModeChanged: (String) -> Unit,
    onSlidersUpdated: (Int, Int) -> Unit,
    onQuickSellClicked: () -> Unit
) {
    var maxBwInput by remember { mutableStateOf(maxBandwidth) }
    var batteryInput by remember { mutableStateOf(batteryCap) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // High-precision Earnings visual dashboard
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBrass)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ACCUMULATED SOVEREIGN CREDITS BALANCE",
                        color = CyberBlack.copy(alpha = 0.65f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%.4f CR", credits),
                        color = CyberBlack,
                        fontSize = 28.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "NODE REPUTATION", color = CyberBlack.copy(alpha = 0.6f), fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(text = "$rating/100", color = CyberBlack, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "TOTAL DATA SHARED", color = CyberBlack.copy(alpha = 0.6f), fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(text = String.format("%.2f GB", sharedGb), color = CyberBlack, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "VERIFIED UPTIME", color = CyberBlack.copy(alpha = 0.6f), fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(text = uptime, color = CyberBlack, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Edge Node selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EDGE NODE MODE PROMOTION",
                            color = CyberBrass,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Button(
                            onClick = onQuickSellClicked,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberBrass, contentColor = CyberBlack),
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("QUICK TRADE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Participating as a network infrastructure core provider lets you routing traffic or caching data blocks. Contributors earn bandwidth credits directly.",
                        color = GridWhite,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Buttons array
                    val modes = listOf(
                        Pair("OFF", "Bypass"),
                        Pair("RELAY", "Transit"),
                        Pair("CACHE", "Files"),
                        Pair("MESH_NODE", "Mesh Hop"),
                        Pair("SATELLITE_GATEWAY", "LEO Gateway")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        modes.forEach { (modeId, modeLabel) ->
                            val active = activeEdgeMode == modeId
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (active) ElectricCyan.copy(alpha = 0.15f) else TacticalSlate.copy(alpha = 0.2f))
                                    .border(1.dp, if (active) ElectricCyan else TacticalSlate, RoundedCornerShape(12.dp))
                                    .clickable { onEdgeModeChanged(modeId) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = modeId.replace("_", " "),
                                        color = if (active) ElectricCyan else GridWhite,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = modeLabel,
                                        color = if (active) CyberBrass else GridWhite.copy(alpha = 0.5f),
                                        fontSize = 7.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Adjustable Limits Sliders
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "CONTRIBUTION RESOURCE THRESHOLDS",
                        color = CyberBrass,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Limit Slider 1
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bandwidth Limit CAP", color = DimWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("$maxBwInput GB / month", color = ElectricCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = maxBwInput.toFloat(),
                        onValueChange = {
                            maxBwInput = it.toInt()
                            onSlidersUpdated(maxBwInput, batteryInput)
                        },
                        valueRange = 50f..1000f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = TacticalSlate
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Limit Slider 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Battery Save Protection", color = DimWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("Pause below $batteryInput%", color = ElectricCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = batteryInput.toFloat(),
                        onValueChange = {
                            batteryInput = it.toInt()
                            onSlidersUpdated(maxBwInput, batteryInput)
                        },
                        valueRange = 5f..80f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = TacticalSlate
                        )
                    )
                }
            }
        }

        // Transactions log
        item {
            Text(
                text = "HISTORIC DECENTRALIZED SYSTEM TACTICAL LEDGER",
                color = CyberBrass,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
            )
        }

        if (transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("NO TELEMETRY TRANSACTIONS VERIFIED YET.", color = GridWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        } else {
            items(transactions) { tx ->
                TransactionRow(tx = tx)
            }
        }
    }
}

@Composable
fun TransactionRow(tx: TransactionRecord) {
    val txColor = if (tx.type == "SHARE_REWARD" || tx.type == "SALE" || tx.type == "LEASE_OUT") CyberGreen else ElectricCyan
    val prefix = if (tx.type == "SHARE_REWARD" || tx.type == "SALE" || tx.type == "LEASE_OUT") "+" else "-"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TacticalSlate, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = SpaceGrey)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = tx.type,
                    color = txColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${tx.bandwidthGb} GB to ${tx.partner}",
                    color = GridWhite,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$prefix${String.format("%.2f", tx.credits)} CR",
                    color = txColor,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = tx.status,
                    color = if (tx.status == "COMPLETED" || tx.status == "ACTIVE") CyberGreen else CyberGold,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// --- station 3: MARKETPLACE SCREEN ---
@Composable
fun MarketplaceScreen(
    credits: Double,
    items: List<MarketplaceItem>,
    onPurchaseLease: (MarketplaceItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AVAILABLE BUYBACK LIQUIDITY",
                            color = CyberBrass,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = String.format("%.2f credits", credits),
                            color = CyberGold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(CyberGold.copy(alpha = 0.1f), RoundedCornerShape(50))
                            .border(1.dp, CyberGold.copy(alpha = 0.3f), RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "LIQUID DECK ACTIVE",
                            color = CyberGold,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "ORBITAL, BACKHAUL & MESH CHANNELS FOR LEASE",
                color = CyberBrass,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
            )
        }

        items(items) { term ->
            MarketItemRow(
                item = term,
                canAfford = credits >= term.costCredits,
                onPurchase = { onPurchaseLease(term) }
            )
        }
    }
}

@Composable
fun MarketItemRow(
    item: MarketplaceItem,
    canAfford: Boolean,
    onPurchase: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SpaceGrey),
        border = BorderStroke(1.dp, TacticalSlate)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.name,
                            color = DimWhite,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(CyberBrass.copy(alpha = 0.15f), RoundedCornerShape(50))
                                .border(0.5.dp, CyberBrass.copy(alpha = 0.5f), RoundedCornerShape(50))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.type,
                                color = CyberBrass,
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Sign: ${item.providerSignature}",
                        color = GridWhite,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "${item.costCredits} CR",
                    color = CyberGold,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = TacticalSlate.copy(alpha = 0.4f), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column {
                        Text("TRANSIT CAP", color = GridWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("${item.bandwidthGb.toInt()} GB", color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("LATENCY", color = GridWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("${item.latencyMs} ms", color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("QUALITY RATING", color = GridWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("★ ${item.rating}", color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onPurchase,
                    enabled = canAfford,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberBrass,
                        contentColor = CyberBlack,
                        disabledContainerColor = TacticalSlate,
                        disabledContentColor = GridWhite.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(
                        text = if (canAfford) "LEASE CHANNEL" else "LIMIT REACHED",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// --- station 4: COPILOT SCREEN ---
@Composable
fun CopilotScreen(
    interfaces: List<NetworkInterfaceInfo>,
    sovereignMode: Boolean,
    credits: Double,
    uptimeSeconds: Long,
    geminiStatus: GeminiReportState,
    onAnalyzeRequest: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var inputSecretKey by remember { mutableStateOf("") }
    
    // Auto-detect a security set secret key if user has stored it inBuildConfig!
    // If not, we allow user to input a sandbox developer key directly on top screen for prototyping convenience!
    val activeKey = if (BuildConfig.GEMINI_API_KEY.isNotEmpty() && !BuildConfig.GEMINI_API_KEY.contains("MY_GEMINI_API_KEY")) {
        BuildConfig.GEMINI_API_KEY
    } else {
        inputSecretKey
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Text(
                        text = "AURELIA CYBERNETIC CO-PILOT ANALYSIS CORE",
                        color = CyberBrass,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "The AURELIA CO-PILOT utilizes server-side Gemini intelligence models to evaluate path integrity risks, detect quantum packet anomalies, and dynamically design optimized multi-path configurations.",
                        color = GridWhite,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 13.sp
                    )
                }
            }
        }

        // Key configuration
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceGrey),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "GEMINI SECURE API DECK CONSOLE",
                        color = CyberGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "The platform securely detects keys configured in Google AI Studio secrets. Alternatively, paste your temporary API key below to conduct live terminal queries.",
                        color = GridWhite,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 11.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (BuildConfig.GEMINI_API_KEY.isNotEmpty() && !BuildConfig.GEMINI_API_KEY.contains("MY_GEMINI_API_KEY")) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberGreen.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                .border(1.dp, CyberGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "✓ PLATFORM SECURED KEY INJECTED RECOGNISED",
                                color = CyberGreen,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = inputSecretKey,
                            onValueChange = { inputSecretKey = it },
                            placeholder = { Text("Enter GEMINI_API_KEY", color = GridWhite.copy(alpha = 0.4f), fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                            textStyle = TextStyle(color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("api_key_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = TacticalSlate,
                                focusedContainerColor = CyberBlack,
                                unfocusedContainerColor = CyberBlack
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { onAnalyzeRequest(activeKey) },
                        enabled = activeKey.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricCyan,
                            contentColor = CyberBlack,
                            disabledContainerColor = TacticalSlate,
                            disabledContentColor = GridWhite.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .testTag("analyze_button")
                    ) {
                        Text(
                            text = "SOLICIT CO-PILOT OPTIMIZATION DECISION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Telemetry terminal printout
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBlack),
                border = BorderStroke(1.dp, TacticalSlate)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    when (geminiStatus) {
                        is GeminiReportState.Idle -> {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "⚡ CO-PILOT STANDBY",
                                    color = GridWhite,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Ready to receive telemetry vector query.",
                                    color = GridWhite.copy(alpha = 0.5f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        is GeminiReportState.Loading -> {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ElectricCyan, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "TAPPING GEMINI AI SYNDICATE CONUNDRUM...",
                                    color = CyberGold,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        is GeminiReportState.Success -> {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "AURELIA NOC INTELLIGENCE REPORT [DECRYPTED]",
                                        color = CyberBrass,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        IconButton(
                                            onClick = { clipboardManager.setText(AnnotatedString(geminiStatus.report)) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Copy Report",
                                                tint = ElectricCyan,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = geminiStatus.report,
                                    color = DimWhite,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                        is GeminiReportState.Error -> {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "REPORT INTERRUPT FAILURE",
                                    color = CyberRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = geminiStatus.message,
                                    color = DimWhite,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Detail Dialogups ---

@Composable
fun InterfaceDetailsDialog(
    info: NetworkInterfaceInfo,
    onDismiss: () -> Unit
) {
    val indicatorColor = when (info.type) {
        "FIBER" -> ElectricBlue
        "CELLULAR" -> CyberGold
        "SATELLITE" -> CyberBrass
        "MESH" -> ElectricCyan
        "DECENTRALIZED" -> CyberGreen
        else -> ElectricCyan
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, indicatorColor, RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SpaceGrey)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = info.name.uppercase(),
                            color = CyberBrass,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = CyberRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TacticalSlate, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailItem(label = "HARDWARE CARRIER CLASS", value = info.type)
                    DetailItem(label = "LINK VALID STATE", value = if (info.isConnected) "ONLINE" else "STANDBY OFFLINE")
                    DetailItem(label = "BANDWIDTH STREAM SPEED", value = if (info.isConnected) String.format("%.2f Mbps", info.throughputMbps) else "0.0 Mbps")
                    DetailItem(label = "CHANNEL SIGNAL WEIGHT", value = "${info.signalStrengthDb} dBm")
                    DetailItem(label = "TRANSMISSIVE LIFT TIME", value = "${info.latencyMs} ms")
                    DetailItem(label = "PACKET LOSS DEFLECTION", value = String.format("%.3f%% Loss", info.packetLossPercent))
                    DetailItem(label = "SECURE PROTOCOL WRAPPER", value = "QUIC (Multipath binding AES-GCM)")

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = indicatorColor, contentColor = CyberBlack),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                    ) {
                        Text("DISMISS SECURE DECK UI", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
}

@Composable
fun DetailItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = GridWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = DimWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun QuickSellDialog(
    onDismiss: () -> Unit,
    onConfirmSell: (String, Double, Double) -> Unit
) {
    var shareDesc by remember { mutableStateOf("LOCAL-MESH-RELAY-CACHE") }
    var slideGb by remember { mutableStateOf(20f) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberBrass, RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = SpaceGrey)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = "LIQUID SWAP CONTRIBUTE CORES",
                    color = CyberBrass,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Release your localized storage block cache to peers immediately. You will provide transit to neighbor network nodes and receive credits.",
                    color = GridWhite,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 12.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = shareDesc,
                    onValueChange = { shareDesc = it },
                    label = { Text("Provider Node Signature", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    textStyle = TextStyle(color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = TacticalSlate,
                        focusedContainerColor = CyberBlack,
                        unfocusedContainerColor = CyberBlack
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Capacity shared", color = GridWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("${slideGb.toInt()} GB", color = ElectricCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = slideGb,
                    onValueChange = { slideGb = it },
                    valueRange = 5f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricCyan,
                        activeTrackColor = ElectricCyan,
                        inactiveTrackColor = TacticalSlate
                    )
                )

                val rewardsCredits = slideGb.toDouble() * 0.45
                DetailItem(label = "ESTIMATED SWAP RETURN", value = String.format("%.2f CR", rewardsCredits))

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, CyberRed),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberRed),
                        modifier = Modifier.weight(1f).height(36.dp)
                    ) {
                        Text("CANCEL", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = { onConfirmSell(shareDesc, slideGb.toDouble(), rewardsCredits) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberGreen, contentColor = CyberBlack),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f).height(36.dp)
                    ) {
                        Text("INITIATE SWAP", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
