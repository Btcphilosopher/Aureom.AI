package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- NOC Aerospace color palette ---
val CyberBlack = Color(0xFF050505)      // Dark deep space background
val SpaceGrey = Color(0xFF121212)       // Rich radar tactical grey
val TacticalSlate = Color(0x26D4AF37)   // High-contrast lines & active card tones (15% brass)
val ElectricCyan = Color(0xFF00FFFF)    // Electro-luminescent antenna signals (neon cyan)
val ElectricBlue = Color(0xFF2979FF)    // Network trunk telemetry streams
val CyberBrass = Color(0xFFD4AF37)      // Brass calibration, core dials, & brand accents
val CyberGold = Color(0xFFFFB300)       // Secondary alert, numeric metrics
val CyberGreen = Color(0xFF00E676)      // Connection "ALWAYS ON" success signal
val CyberRed = Color(0xFFFF1744)        // Carrier interrupt drop-out hazard
val DimWhite = Color(0xFFECEFF1)
val GridWhite = Color(0x66B0BEC5)       // Radar compass grids
