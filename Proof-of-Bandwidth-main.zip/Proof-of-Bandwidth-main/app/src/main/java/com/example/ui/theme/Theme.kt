package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    secondary = CyberBrass,
    tertiary = ElectricBlue,
    background = CyberBlack,
    surface = SpaceGrey,
    onPrimary = CyberBlack,
    onSecondary = CyberBlack,
    onBackground = DimWhite,
    onSurface = DimWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force our high-precision tactical dark NOC environment!
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
