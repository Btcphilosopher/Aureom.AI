package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

// --- View Models Data Structures ---

data class NetworkInterfaceInfo(
    val name: String,
    val type: String, // "FIBER", "ETHERNET", "WIFI", "CELLULAR", "SATELLITE", "MESH", "DECENTRALIZED"
    val isConnected: Boolean,
    val throughputMbps: Double,
    val signalStrengthDb: Int,
    val latencyMs: Int,
    val packetLossPercent: Double,
    val flowWeightPercent: Int,
    val coverageQuality: String // "OPTIMAL", "STABLE", "DEGRADED", "OFFLINE"
)

data class MarketplaceItem(
    val id: String,
    val name: String,
    val type: String, // "SATELLITE LEO", "PEER MESH", "FIBRE TRUNK", "CELLULAR RELAY"
    val bandwidthGb: Double,
    val costCredits: Double,
    val rating: Double,
    val latencyMs: Int,
    val providerSignature: String
)

sealed interface GeminiReportState {
    object Idle : GeminiReportState
    object Loading : GeminiReportState
    data class Success(val report: String) : GeminiReportState
    data class Error(val message: String) : GeminiReportState
}

class AureliaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AureliaDatabase.getDatabase(application)
    val repository = AureliaRepository(database)

    // Live list of network interfaces
    private val _interfaces = MutableStateFlow<List<NetworkInterfaceInfo>>(emptyList())
    val interfaces: StateFlow<List<NetworkInterfaceInfo>> = _interfaces.asStateFlow()

    // Aggregate telemetry values
    val aggregateThroughput = MutableStateFlow(384.5)
    val aggregateLatency = MutableStateFlow(12)
    val aggregatePacketLoss = MutableStateFlow(0.04)

    // Alert system for NOC events
    private val _nocEventLog = MutableStateFlow<List<String>>(emptyList())
    val nocEventLog: StateFlow<List<String>> = _nocEventLog.asStateFlow()

    // Sandbox credits balance & reputation
    val creditsBalance = MutableStateFlow(724.85)
    val reputationScore = MutableStateFlow(98.4)
    val uptimeSeconds = MutableStateFlow(412500L)
    val totalSharedGb = MutableStateFlow(1420.45)
    val activeUptimeText = MutableStateFlow("114h 35m 00s")

    // Node state entity from Room
    val databaseNodeState = repository.nodeState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Current toggles
    val alwaysOnline = MutableStateFlow(true)
    val sovereignMode = MutableStateFlow(false)
    val edgeNodeMode = MutableStateFlow("RELAY") // OFF, RELAY, CACHE, MESH_NODE, SATELLITE_GATEWAY
    val maxBandwidthLimitGb = MutableStateFlow(500)
    val batteryCapPercent = MutableStateFlow(20)

    // Marketplace
    private val _marketplaceItems = MutableStateFlow<List<MarketplaceItem>>(emptyList())
    val marketplaceItems: StateFlow<List<MarketplaceItem>> = _marketplaceItems.asStateFlow()

    // Transaction list from Room
    val transactionsList = repository.allTransactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Gemini analytical report state
    private val _geminiState = MutableStateFlow<GeminiReportState>(GeminiReportState.Idle)
    val geminiState: StateFlow<GeminiReportState> = _geminiState.asStateFlow()

    init {
        // Prepare initial static/simulated network interfaces
        resetNetworkInterfaces()
        generateMarketplaceItems()
        addNocEvent("AURELIA CONNECT v4.2 PROVISIONED")
        addNocEvent("Sovereign security model: AES-GCM integrated")
        addNocEvent("Multipath QUIC dispatcher binding completed")

        // Periodically run the engine loop
        viewModelScope.launch(Dispatchers.IO) {
            // Seed database node state if not exists
            repository.nodeState.first()?.let {
                creditsBalance.value = it.currentBalance
                alwaysOnline.value = it.alwaysOnlineEnabled
                sovereignMode.value = it.sovereignModeEnabled
                edgeNodeMode.value = it.edgeMode
                maxBandwidthLimitGb.value = it.maxBandwidthLimitGb
                batteryCapPercent.value = it.batteryCapPercent
                reputationScore.value = it.reputationScore
                uptimeSeconds.value = it.uptimeSeconds
                totalSharedGb.value = it.totalSharedGb
            } ?: run {
                val seedState = NodeState(
                    currentBalance = 724.85,
                    alwaysOnlineEnabled = true,
                    sovereignModeEnabled = false,
                    edgeMode = "RELAY",
                    maxBandwidthLimitGb = 500,
                    batteryCapPercent = 20,
                    reputationScore = 98.4,
                    uptimeSeconds = 412500L,
                    totalSharedGb = 1420.45
                )
                repository.saveNodeState(seedState)
            }

            // Seed some random old transactions if empty
            if (repository.allTransactions.first().isEmpty()) {
                repository.saveTransaction(TransactionRecord(type = "PURCHASE", partner = "LEO-SKYLINE-7", date = System.currentTimeMillis() - 86400000, bandwidthGb = 50.0, credits = 25.0, status = "COMPLETED"))
                repository.saveTransaction(TransactionRecord(type = "SHARE_REWARD", partner = "LOCAL_MESH_RELAY_3", date = System.currentTimeMillis() - 72000000, bandwidthGb = 14.2, credits = 7.10, status = "COMPLETED"))
                repository.saveTransaction(TransactionRecord(type = "LEASE_OUT", partner = "PEER-SUBSCRIBER-99", date = System.currentTimeMillis() - 36000000, bandwidthGb = 100.0, credits = 45.0, status = "ACTIVE"))
            }

            // Start telemetry simulation tick loop
            var tickCount = 0
            while (true) {
                delay(1500)
                tickCount++
                simulateNetworkTelemetry(tickCount)
            }
        }
    }

    private fun addNocEvent(event: String) {
        val currentList = _nocEventLog.value.toMutableList()
        currentList.add(0, "[NOC PROT] $event")
        if (currentList.size > 25) currentList.removeLast()
        _nocEventLog.value = currentList
    }

    private fun resetNetworkInterfaces() {
        _interfaces.value = listOf(
            NetworkInterfaceInfo("Fibre Broadband", "FIBER", true, 250.0, -12, 4, 0.00, 40, "OPTIMAL"),
            NetworkInterfaceInfo("Cellular 5G Core", "CELLULAR", true, 85.0, -82, 14, 0.05, 30, "STABLE"),
            NetworkInterfaceInfo("SATELLITE LEO-7", "SATELLITE", true, 110.0, -94, 25, 0.01, 20, "STABLE"),
            NetworkInterfaceInfo("Sovereign Mesh P2P", "MESH", true, 18.0, -68, 11, 0.12, 10, "STABLE"),
            NetworkInterfaceInfo("Gigabit Ethernet", "ETHERNET", false, 0.0, 0, 999, 100.0, 0, "OFFLINE"),
            NetworkInterfaceInfo("Local Wi-Fi Hub", "WIFI", false, 0.0, 0, 999, 100.0, 0, "OFFLINE")
        )
    }

    private fun generateMarketplaceItems() {
        _marketplaceItems.value = listOf(
            MarketplaceItem("X-1", "AETHER-STAR-LEO", "SATELLITE LEO", 50.0, 20.0, 4.9, 18, "STARSYS_SECURE_98"),
            MarketplaceItem("X-2", "APEX-CELLULAR-RELAY", "CELLULAR RELAY", 100.0, 35.0, 4.7, 12, "APEX_TELE_CORE_04"),
            MarketplaceItem("X-3", "NEIGHBOUR-MESH-6", "PEER MESH", 25.0, 8.0, 4.4, 22, "P2P_MESH_VERIFIABLE"),
            MarketplaceItem("X-4", "PACIFIC-DARK-FIBRE", "FIBRE TRUNK", 300.0, 110.0, 5.0, 2, "PACIFIC_TRANSIT_SIG"),
            MarketplaceItem("X-5", "Sovereign Relay #204", "PEER MESH", 40.0, 15.0, 4.8, 15, "SOV_NODE_REPUTATION_9")
        )
    }

    private suspend fun simulateNetworkTelemetry(tick: Int) {
        // Random slight fluctuations
        val random = Random.Default
        val alwaysOnlineEnabled = alwaysOnline.value
        val edgeActive = edgeNodeMode.value != "OFF"

        // Increment uptime
        uptimeSeconds.value += 1
        val tSeconds = uptimeSeconds.value
        val hrs = tSeconds / 3600
        val mins = (tSeconds % 3600) / 60
        val secs = tSeconds % 60
        activeUptimeText.value = String.format("%dh %dm %02ds", hrs, mins, secs)

        // Increment credits if edge hosting contributes bandwidth
        if (edgeActive) {
            val incrementalCredits = when (edgeNodeMode.value) {
                "RELAY" -> 0.02 + random.nextDouble(0.01)
                "CACHE" -> 0.04 + random.nextDouble(0.01)
                "MESH_NODE" -> 0.03 + random.nextDouble(0.01)
                "SATELLITE_GATEWAY" -> 0.07 + random.nextDouble(0.03)
                else -> 0.0
            }
            creditsBalance.value += incrementalCredits
            val sharedGbInc = 0.05 + random.nextDouble(0.12)
            totalSharedGb.value += sharedGbInc

            // Every 10 ticks, write a small Metric or Reward into database
            if (tick % 10 == 0) {
                repository.saveNodeState(
                    NodeState(
                        id = 1,
                        currentBalance = creditsBalance.value,
                        alwaysOnlineEnabled = alwaysOnline.value,
                        sovereignModeEnabled = sovereignMode.value,
                        edgeMode = edgeNodeMode.value,
                        maxBandwidthLimitGb = maxBandwidthLimitGb.value,
                        batteryCapPercent = batteryCapPercent.value,
                        reputationScore = reputationScore.value,
                        uptimeSeconds = uptimeSeconds.value,
                        totalSharedGb = totalSharedGb.value
                    )
                )
                repository.saveMetric(
                    HistoryMetric(
                        timestamp = System.currentTimeMillis(),
                        networkType = "Mesh Relay",
                        latencyMs = aggregateLatency.value,
                        packetLossPercent = aggregatePacketLoss.value,
                        throughputMbps = aggregateThroughput.value,
                        creditsEarned = incrementalCredits * 10
                    )
                )
            }
        }

        // Simulate network disruption/failover logic for Always-Online validation
        val isDisruptedTick = tick % 16 == 0

        val currentList = _interfaces.value.map { item ->
            var status = item.isConnected
            var throughput = item.throughputMbps
            var sig = item.signalStrengthDb
            var lat = item.latencyMs
            var loss = item.packetLossPercent
            var qual = item.coverageQuality

            if (item.isConnected) {
                // Normal slight drift
                val drift = random.nextDouble(-1.5, 1.5)
                throughput = (throughput + drift).coerceIn(1.0, 1000.0)
                sig = (sig + random.nextInt(-1, 2)).coerceIn(-120, -5)
                lat = (lat + random.nextInt(-1, 2)).coerceIn(1, 400)
                loss = (loss + random.nextDouble(-0.01, 0.01)).coerceIn(0.0, 5.0)

                // Simulate sudden dropping of Fibre BroadBand in a disrupted tick
                if (isDisruptedTick && item.type == "FIBER" && alwaysOnlineEnabled) {
                    status = false
                    throughput = 0.0
                    sig = 0
                    lat = 999
                    loss = 100.0
                    qual = "OFFLINE"
                    addNocEvent("ALERT: FIBRE BACKHAUL CARRIER CARDS DRIPPED LINK!")
                }
            } else {
                // If fiber is dropped, and alwaysOnline is enabled, it should pre-negotiate backup,
                // or after 3 ticks, regain connectivity
                if (item.type == "FIBER" && tick % 16 == 3) {
                    status = true
                    throughput = 245.0
                    sig = -10
                    lat = 5
                    loss = 0.0
                    qual = "OPTIMAL"
                    addNocEvent("RESOLVED: FIBRE CARRIER SYNC RE-ESTABLISHED")
                }
            }

            // Adjust flow weights based on toggles
            var weight = item.flowWeightPercent
            if (sovereignMode.value) {
                // Private/Decentralized routes are prioritized
                if (item.type == "MESH" || item.type == "SATELLITE" || item.type == "DECENTRALIZED") {
                    weight = 35
                } else if (item.isConnected) {
                    weight = 10
                }
            } else {
                // Conventional load balancers
                weight = if (item.type == "FIBER" && status) 40
                else if (item.type == "CELLULAR" && status) 30
                else if (item.type == "SATELLITE" && status) 20
                else if (item.type == "MESH" && status) 10
                else 0
            }

            item.copy(
                isConnected = status,
                throughputMbps = throughput,
                signalStrengthDb = sig,
                latencyMs = lat,
                packetLossPercent = loss,
                flowWeightPercent = weight,
                coverageQuality = qual
            )
        }

        // Adjust for "Always-Online Zero Packet Loss Failover Mode"
        if (isDisruptedTick && alwaysOnlineEnabled) {
            // Instant notification of seamless failover
            addNocEvent("FAILOVER DISPATCHER TRIGGERED: Transformed Cellular (50%) & Satellite (50%)")
            addNocEvent("ALWAYS-ONLINE PROTOCOL SUCCESSFUL: Zero traffic dropped.")
        }

        _interfaces.value = currentList

        // Calculate aggregate statistics
        var totalMbps = 0.0
        var totalWeight = 0
        var weightedLat = 0.0
        var weightedLoss = 0.0

        currentList.forEach { info ->
            if (info.isConnected) {
                totalMbps += info.throughputMbps
                weightedLat += info.latencyMs * info.flowWeightPercent
                weightedLoss += info.packetLossPercent * info.flowWeightPercent
                totalWeight += info.flowWeightPercent
            }
        }

        aggregateThroughput.value = if (totalMbps > 0) totalMbps else 0.0
        aggregateLatency.value = if (totalWeight > 0) (weightedLat / totalWeight).toInt() else 999
        aggregatePacketLoss.value = if (totalWeight > 0) (weightedLoss / totalWeight) else 100.0
    }

    // Interactive controls

    fun toggleAlwaysOnline(enabled: Boolean) {
        alwaysOnline.value = enabled
        addNocEvent(if (enabled) "ALWAYS-ONLINE PRE-NEGOTIATIVE CORE ENFORCED" else "ALWAYS-ONLINE CORE DEACTIVATED (MANUAL FAILOVER REQUIRED)")
        saveCurrentNodeStateToDb()
    }

    fun toggleSovereignMode(enabled: Boolean) {
        sovereignMode.value = enabled
        addNocEvent(if (enabled) "Sovereign Network Active - Bypassing standard ISP, tunneling via mesh and orbital P2P." else "Sovereign routing policy relaxed.")
        saveCurrentNodeStateToDb()
    }

    fun changeEdgeMode(mode: String) {
        edgeNodeMode.value = mode
        addNocEvent("EDGE MODE SWITCHED: Connected as a $mode node. Contributing resources.")
        saveCurrentNodeStateToDb()
    }

    fun updateSliders(maxBandwidth: Int, batteryCap: Int) {
        maxBandwidthLimitGb.value = maxBandwidth
        batteryCapPercent.value = batteryCap
        saveCurrentNodeStateToDb()
    }

    private fun saveCurrentNodeStateToDb() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveNodeState(
                NodeState(
                    id = 1,
                    currentBalance = creditsBalance.value,
                    alwaysOnlineEnabled = alwaysOnline.value,
                    sovereignModeEnabled = sovereignMode.value,
                    edgeMode = edgeNodeMode.value,
                    maxBandwidthLimitGb = maxBandwidthLimitGb.value,
                    batteryCapPercent = batteryCapPercent.value,
                    reputationScore = reputationScore.value,
                    uptimeSeconds = uptimeSeconds.value,
                    totalSharedGb = totalSharedGb.value
                )
            )
        }
    }

    // Marketplace orders

    fun purchaseTransitChannel(item: MarketplaceItem) {
        if (creditsBalance.value >= item.costCredits) {
            creditsBalance.value -= item.costCredits
            addNocEvent("SECURED LEASE CHANNEL: ${item.name} (${item.bandwidthGb} GB leased for ${item.costCredits} credits)")
            
            viewModelScope.launch(Dispatchers.IO) {
                // Record to db
                val record = TransactionRecord(
                    type = "PURCHASE",
                    partner = item.name,
                    date = System.currentTimeMillis(),
                    bandwidthGb = item.bandwidthGb,
                    credits = item.costCredits,
                    status = "ACTIVE"
                )
                repository.saveTransaction(record)
                saveCurrentNodeStateToDb()

                // Inject a dynamic decentralized network interface representing our leased channel!
                val currentList = _interfaces.value.toMutableList()
                currentList.add(
                    NetworkInterfaceInfo(
                        name = "Leased: " + item.name,
                        type = "DECENTRALIZED",
                        isConnected = true,
                        throughputMbps = 150.0,
                        signalStrengthDb = -45,
                        latencyMs = item.latencyMs,
                        packetLossPercent = 0.00,
                        flowWeightPercent = 15,
                        coverageQuality = "OPTIMAL"
                    )
                )
                _interfaces.value = currentList
            }
        } else {
            addNocEvent("ERROR: Insufficient credits to lease channel: ${item.name}")
        }
    }

    fun listBandwidthForCredits(desc: String, gbShared: Double, priceCredits: Double) {
        creditsBalance.value += priceCredits
        addNocEvent("CONTRIBUTOR LIQUIDITY: Listed and sold $gbShared GB of local cached static assets for $priceCredits credits.")

        viewModelScope.launch(Dispatchers.IO) {
            val record = TransactionRecord(
                type = "SALE",
                partner = desc,
                date = System.currentTimeMillis(),
                bandwidthGb = gbShared,
                credits = priceCredits,
                status = "COMPLETED"
            )
            repository.saveTransaction(record)
            saveCurrentNodeStateToDb()
        }
    }

    // Gemini actions

    fun requestAureliaIntelligenceReport(apiKey: String) {
        _geminiState.value = GeminiReportState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Compile summaries
                val summaryBuilder = StringBuilder()
                _interfaces.value.forEach {
                    summaryBuilder.append("[${it.name}: Type=${it.type}, Active=${it.isConnected}, Speed=${String.format("%.1f", it.throughputMbps)} Mbps, Loss=${String.format("%.2f", it.packetLossPercent)}%]\n")
                }

                val report = GeminiClient.evaluateNetworkPerformance(
                    apiKey = apiKey,
                    activeTransportsSummary = summaryBuilder.toString(),
                    sovereignModeStatus = sovereignMode.value,
                    credits = creditsBalance.value,
                    recentUptimeSeconds = uptimeSeconds.value
                )

                _geminiState.value = GeminiReportState.Success(report)
                addNocEvent("AURELIA INTELLIGENCE: Copilot telemetry sync complete.")
            } catch (e: Exception) {
                _geminiState.value = GeminiReportState.Error(e.localizedMessage ?: "Unknown link synchronization exception")
                addNocEvent("AURELIA INTELLIGENCE ERROR: Sync broken.")
            }
        }
    }
}
