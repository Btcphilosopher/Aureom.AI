package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- entities ---

@Entity(tableName = "transactions")
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "PURCHASE", "SALE", "LEASE_IN", "LEASE_OUT"
    val partner: String,
    val date: Long,
    val bandwidthGb: Double,
    val credits: Double,
    val status: String // "COMPLETED", "ACTIVE", "PENDING"
)

@Entity(tableName = "history_metrics")
data class HistoryMetric(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val networkType: String, // "Fibre", "Satellite LEO", "5G", "Wi-Fi 6E", "Mesh Relay"
    val latencyMs: Int,
    val packetLossPercent: Double,
    val throughputMbps: Double,
    val creditsEarned: Double
)

@Entity(tableName = "node_state")
data class NodeState(
    @PrimaryKey val id: Int = 1,
    val currentBalance: Double,
    val alwaysOnlineEnabled: Boolean,
    val sovereignModeEnabled: Boolean,
    val edgeMode: String, // "OFF", "RELAY", "CACHE", "MESH_NODE", "SATELLITE_GATEWAY"
    val maxBandwidthLimitGb: Int,
    val batteryCapPercent: Int,
    val reputationScore: Double,
    val uptimeSeconds: Long,
    val totalSharedGb: Double
)

// --- daos ---

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactions(): Flow<List<TransactionRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionRecord)

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()
}

@Dao
interface MetricDao {
    @Query("SELECT * FROM history_metrics ORDER BY timestamp DESC LIMIT 50")
    fun getRecentMetrics(): Flow<List<HistoryMetric>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMetric(metric: HistoryMetric)

    @Query("DELETE FROM history_metrics")
    suspend fun clearMetrics()
}

@Dao
interface NodeStateDao {
    @Query("SELECT * FROM node_state WHERE id = 1")
    fun getNodeState(): Flow<NodeState?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNodeState(state: NodeState)
}

// --- database ---

@Database(entities = [TransactionRecord::class, HistoryMetric::class, NodeState::class], version = 1, exportSchema = false)
abstract class AureliaDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun metricDao(): MetricDao
    abstract fun nodeStateDao(): NodeStateDao

    companion object {
        @Volatile
        private var INSTANCE: AureliaDatabase? = null

        fun getDatabase(context: Context): AureliaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AureliaDatabase::class.java,
                    "aurelia_connect_db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- repository ---

class AureliaRepository(private val db: AureliaDatabase) {
    val allTransactions: Flow<List<TransactionRecord>> = db.transactionDao().getAllTransactions()
    val recentMetrics: Flow<List<HistoryMetric>> = db.metricDao().getRecentMetrics()
    val nodeState: Flow<NodeState?> = db.nodeStateDao().getNodeState()

    suspend fun saveTransaction(tx: TransactionRecord) = db.transactionDao().insertTransaction(tx)
    suspend fun saveMetric(m: HistoryMetric) = db.metricDao().insertMetric(m)
    suspend fun saveNodeState(state: NodeState) = db.nodeStateDao().insertNodeState(state)

    suspend fun initDefaultStateIfEmpty() {
        // We will call this in ViewModel initialization to insert default seeds
    }
}
