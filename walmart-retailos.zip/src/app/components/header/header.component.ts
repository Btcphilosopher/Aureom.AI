import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../../core/services/retail-state.service';
import { UserRole } from '../../core/models/retail.types';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#041E42] text-white border-b border-slate-700/60 sticky top-0 z-40 shadow-sm">
      <!-- Main Brand & Global Operations Bar -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        <!-- Zone 1: Brand Wordmark -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="w-9 h-9 rounded-lg bg-[#0071DC] flex items-center justify-center font-black text-[#FFC220] shadow-sm text-xl select-none">
            <mat-icon class="text-xl">hub</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-lg font-bold tracking-tight text-white whitespace-nowrap">Walmart RetailOS</span>
              <span class="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">v2.4 Enterprise</span>
            </div>
            <p class="text-[11px] text-slate-400 leading-tight">Multi-Store Inventory, Replenishment & Fulfillment Platform</p>
          </div>
        </div>

        <!-- Zone 2: Facility Context & Quick Stats -->
        <div class="hidden lg:flex items-center gap-6 text-xs text-slate-300">
          <!-- Facility Switcher -->
          <div class="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
            <mat-icon class="text-slate-400 text-sm">storefront</mat-icon>
            <span class="text-slate-400">Store Context:</span>
            <select
              [value]="state.selectedFacilityId()"
              (change)="onFacilityChange($event)"
              class="bg-transparent text-white font-semibold focus:outline-none cursor-pointer pr-1"
            >
              @for (fac of state.facilities(); track fac.id) {
                <option [value]="fac.id" class="bg-slate-900 text-white">
                  {{ fac.code }} — {{ fac.name }}
                </option>
              }
            </select>
          </div>

          <!-- Network Telemetry -->
          <div class="flex items-center gap-4 text-slate-400">
            <div class="flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span class="text-slate-300 font-medium">Network Online</span>
            </div>
            <span class="text-slate-600">|</span>
            <div>
              Short-Dated: <span class="font-mono text-amber-300 font-semibold">{{ state.shortDatedLotsCount() }} lots</span>
            </div>
            <span class="text-slate-600">|</span>
            <div>
              Low Stock: <span class="font-mono text-rose-300 font-semibold">{{ state.lowStockProductsCount() }} SKUs</span>
            </div>
          </div>
        </div>

        <!-- Zone 3: Actions, Persona Switcher & Handheld Launch -->
        <div class="flex items-center gap-2.5 shrink-0">
          <!-- Demo Scenario Trigger -->
          <button
            (click)="demoClick.emit()"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#FFC220] text-[#041E42] hover:bg-yellow-400 transition-colors shadow-sm cursor-pointer whitespace-nowrap"
            title="Launch 11-step end-to-end demonstration workflow"
          >
            <mat-icon class="text-sm">play_circle_filled</mat-icon>
            <span>Demo Scenario</span>
            <span class="bg-[#041E42]/15 text-[#041E42] px-1 py-0.2 rounded text-[10px] font-mono">11-Step</span>
          </button>

          <!-- Handheld Zebra Terminal Toggle -->
          <button
            (click)="state.toggleHandheldMode()"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700 transition-colors cursor-pointer whitespace-nowrap"
            title="Open Associate Zebra Android TC5x Handheld Terminal Simulator"
          >
            <mat-icon class="text-sm text-cyan-400">qr_code_scanner</mat-icon>
            <span>Associate Terminal</span>
          </button>

          <!-- User Role Switcher -->
          <div class="flex items-center gap-1.5 bg-slate-800/90 pl-2.5 pr-2 py-1 rounded-lg border border-slate-700 text-xs">
            <mat-icon class="text-slate-400 text-sm">badge</mat-icon>
            <select
              [value]="state.currentUser().role"
              (change)="onRoleChange($event)"
              class="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer pr-1 text-xs"
              title="Switch user role to test permissions & scope"
            >
              @for (role of availableRoles; track role) {
                <option [value]="role" class="bg-slate-900 text-slate-200">
                  {{ role }}
                </option>
              }
            </select>
          </div>
        </div>
      </div>

      <!-- System Notification Bar (if active) -->
      @if (state.systemNotice(); as notice) {
        <div
          class="border-t text-xs py-1.5 px-4 sm:px-6 lg:px-8 flex items-center justify-between transition-colors"
          [class.bg-emerald-950]="notice.type === 'success'"
          [class.border-emerald-800]="notice.type === 'success'"
          [class.text-emerald-200]="notice.type === 'success'"
          [class.bg-amber-950]="notice.type === 'warning'"
          [class.border-amber-800]="notice.type === 'warning'"
          [class.text-amber-200]="notice.type === 'warning'"
          [class.bg-rose-950]="notice.type === 'error'"
          [class.border-rose-800]="notice.type === 'error'"
          [class.text-rose-200]="notice.type === 'error'"
          [class.bg-blue-950]="notice.type === 'info'"
          [class.border-blue-800]="notice.type === 'info'"
          [class.text-blue-200]="notice.type === 'info'"
        >
          <div class="flex items-center gap-2 max-w-7xl mx-auto w-full">
            <mat-icon class="text-sm">
              @if (notice.type === 'success') { check_circle }
              @else if (notice.type === 'warning') { warning }
              @else if (notice.type === 'error') { error }
              @else { info }
            </mat-icon>
            <span class="font-medium truncate">{{ notice.message }}</span>
            <button
              (click)="state.clearNotice()"
              class="ml-auto text-xs opacity-70 hover:opacity-100 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      }
    </header>
  `
})
export class HeaderComponent {
  readonly state = inject(RetailStateService);
  readonly demoClick = output<void>();

  readonly availableRoles: UserRole[] = [
    'Enterprise Administrator',
    'Regional Manager',
    'Store Manager',
    'Inventory Associate',
    'Buyer',
    'Pricing Analyst',
    'Delivery Dispatcher',
    'Customer Service',
    'Auditor (Read-Only)'
  ];

  onFacilityChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectFacility(val);
  }

  onRoleChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as UserRole;
    this.state.setUserRole(val);
  }
}
