import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../../core/services/retail-state.service';

@Component({
  selector: 'app-scenario-runner',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-6">
      <!-- Header banner -->
      <div class="bg-gradient-to-r from-[#041E42] via-[#0071DC] to-[#041E42] text-white px-5 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs uppercase tracking-wider font-semibold text-yellow-300">Live Demonstration Scenario</span>
            <span class="text-xs font-mono bg-white/20 text-white px-2 py-0.5 rounded">Section 12 Verification</span>
          </div>
          <h2 class="text-lg font-bold text-white mt-0.5">End-to-End Enterprise Retail Lifecycle</h2>
          <p class="text-xs text-blue-100 max-w-2xl mt-0.5">
            Execute the complete vertical slice: dock receiving → ATP ledger → customer order → stock reservation → mobile pick → substitution → dispatch → POD & loyalty → markdown → replenishment → customer return & clawback.
          </p>
        </div>

        <!-- Controls -->
        <div class="flex items-center gap-2 shrink-0">
          <button
            (click)="state.advanceDemoStep()"
            [disabled]="state.activeDemoStepIndex() >= state.demoSteps().length"
            class="flex items-center gap-2 px-4 py-2 bg-[#FFC220] text-[#041E42] hover:bg-yellow-400 font-bold text-xs rounded-lg transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <mat-icon class="text-sm">fast_forward</mat-icon>
            <span>
              @if (state.activeDemoStepIndex() >= state.demoSteps().length) {
                All 11 Steps Complete
              } @else {
                Execute Step {{ state.activeDemoStepIndex() + 1 }} of 11
              }
            </span>
          </button>

          <button
            (click)="runAllRemaining()"
            [disabled]="state.activeDemoStepIndex() >= state.demoSteps().length"
            class="flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg border border-white/20 transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            title="Auto-run remaining steps"
          >
            <mat-icon class="text-sm">play_arrow</mat-icon>
            <span>Run All</span>
          </button>

          <button
            (click)="state.resetDemoScenario()"
            class="flex items-center gap-1.5 px-3 py-2 bg-slate-900/60 hover:bg-slate-900 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors cursor-pointer"
            title="Reset scenario & seed database"
          >
            <mat-icon class="text-sm">restart_alt</mat-icon>
            <span>Reset</span>
          </button>

          <button
            (click)="closeDrawer.emit()"
            class="text-white/60 hover:text-white p-1 rounded-lg ml-2 cursor-pointer"
            title="Close scenario drawer"
          >
            <mat-icon>close</mat-icon>
          </button>
        </div>
      </div>

      <!-- Step Pipeline Tracker -->
      <div class="p-5 bg-slate-50 border-b border-slate-200">
        <div class="flex items-center justify-between mb-3 text-xs text-slate-600 font-medium">
          <span>PROGRESSION PIPELINE</span>
          <span class="font-mono text-slate-700">
            {{ completedCount }} / {{ state.demoSteps().length }} COMPLETED ({{ completionPct }}%)
          </span>
        </div>

        <!-- Progress bar -->
        <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-4">
          <div
            class="bg-gradient-to-r from-[#0071DC] to-emerald-500 h-full transition-all duration-300"
            [style.width.%]="completionPct"
          ></div>
        </div>

        <!-- Horizontal Step Timeline -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
          @for (step of state.demoSteps(); track step.stepNumber; let i = $index) {
            <div
              class="p-2.5 rounded-lg border text-xs transition-all relative flex flex-col justify-between"
              [class.bg-white]="step.status === 'PENDING' && i !== state.activeDemoStepIndex()"
              [class.border-slate-200]="step.status === 'PENDING' && i !== state.activeDemoStepIndex()"
              [class.text-slate-500]="step.status === 'PENDING' && i !== state.activeDemoStepIndex()"
              [class.bg-blue-50]="i === state.activeDemoStepIndex()"
              [class.border-blue-500]="i === state.activeDemoStepIndex()"
              [class.shadow-sm]="i === state.activeDemoStepIndex()"
              [class.bg-emerald-50]="step.status === 'COMPLETED'"
              [class.border-emerald-300]="step.status === 'COMPLETED'"
              [class.text-emerald-950]="step.status === 'COMPLETED'"
            >
              <div>
                <div class="flex items-center justify-between font-mono text-[11px] mb-1">
                  <span class="font-bold">#{{ step.stepNumber }}. {{ step.domain }}</span>
                  @if (step.status === 'COMPLETED') {
                    <mat-icon class="text-emerald-600 text-xs">check_circle</mat-icon>
                  } @else if (i === state.activeDemoStepIndex()) {
                    <span class="w-2 h-2 rounded-full bg-blue-600 animate-ping"></span>
                  }
                </div>
                <div class="font-semibold text-slate-800 line-clamp-1 text-[11.5px]">{{ step.title }}</div>
                <p class="text-[10.5px] text-slate-500 line-clamp-2 mt-0.5 leading-snug">{{ step.description }}</p>
              </div>

              @if (step.resultSummary) {
                <div class="mt-2 pt-1.5 border-t border-emerald-200/60 font-mono text-[10px] text-emerald-800 line-clamp-2">
                  ✓ {{ step.resultSummary }}
                </div>
              }
            </div>
          }
        </div>
      </div>

      <!-- Failure Mode Sandbox Playground -->
      <div class="p-4 bg-white flex flex-wrap items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2 text-slate-700">
          <mat-icon class="text-amber-600 text-base">shield</mat-icon>
          <span class="font-semibold">Resilience & Failure Cases Playground:</span>
          <span class="text-slate-500 hidden sm:inline">Simulate boundary edge-cases specified in Section 12</span>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <button
            (click)="state.triggerFailureScenario('DUPLICATE_MESSAGE')"
            class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 font-medium cursor-pointer transition-colors"
            title="Send duplicate event to test idempotency filter"
          >
            Duplicate Event (Idempotency)
          </button>
          <button
            (click)="state.triggerFailureScenario('PAYMENT_FAILURE')"
            class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 font-medium cursor-pointer transition-colors"
            title="Simulate card decline and automatic inventory unlock"
          >
            Payment Card Decline
          </button>
          <button
            (click)="state.triggerFailureScenario('PARTIAL_RECEIPT')"
            class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 font-medium cursor-pointer transition-colors"
            title="Simulate supplier shortage discrepancy on dock"
          >
            Supplier Shortage Discrepancy
          </button>
          <button
            (click)="state.triggerFailureScenario('NEGATIVE_STOCK')"
            class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 font-medium cursor-pointer transition-colors"
            title="Attempt dispatch exceeding on-hand balance"
          >
            Negative Stock Guard
          </button>
          <button
            (click)="state.triggerFailureScenario('EXPIRED_COUPON')"
            class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 font-medium cursor-pointer transition-colors"
            title="Attempt checkout with expired coupon"
          >
            Expired Coupon Rejection
          </button>
        </div>
      </div>
    </div>
  `
})
export class ScenarioRunnerComponent {
  readonly state = inject(RetailStateService);
  readonly closeDrawer = output<void>();

  get completedCount(): number {
    return this.state.demoSteps().filter(s => s.status === 'COMPLETED').length;
  }

  get completionPct(): number {
    return Math.round((this.completedCount / this.state.demoSteps().length) * 100);
  }

  runAllRemaining(): void {
    const total = this.state.demoSteps().length;
    const interval = setInterval(() => {
      if (this.state.activeDemoStepIndex() < total) {
        this.state.advanceDemoStep();
      } else {
        clearInterval(interval);
      }
    }, 450);
  }
}
