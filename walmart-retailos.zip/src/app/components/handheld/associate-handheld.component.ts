import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../../core/services/retail-state.service';
import { Product } from '../../core/models/retail.types';

type HandheldMode = 'LOOKUP' | 'PICKING' | 'RECEIVING' | 'CYCLE_COUNT' | 'WASTE' | 'PRINTER';

@Component({
  selector: 'app-associate-handheld',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Modal Backdrop -->
    <div class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div class="relative w-full max-w-md bg-slate-900 rounded-[32px] p-3 shadow-2xl border-4 border-slate-700 text-white flex flex-col max-h-[92vh]">
        <!-- Physical Handheld Bumper Top Bar -->
        <div class="flex items-center justify-between px-3 py-1 bg-slate-800 rounded-t-2xl text-[11px] text-slate-300 font-mono">
          <div class="flex items-center gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full" [class.bg-emerald-400]="!state.isAssociateOffline()" [class.bg-amber-400]="state.isAssociateOffline()"></span>
            <span>ZEBRA TC57x</span>
            <span class="text-slate-500">|</span>
            <span class="text-yellow-400">STORE #1042</span>
          </div>

          <!-- Close Modal -->
          <button
            (click)="state.toggleHandheldMode()"
            class="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
            title="Exit Handheld Mode"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <!-- Android Screen Viewport -->
        <div class="bg-slate-950 rounded-2xl flex-1 flex flex-col overflow-hidden border border-slate-800">
          <!-- Android Status Bar -->
          <div class="bg-[#041E42] px-3 py-1 flex items-center justify-between text-[10px] font-mono text-slate-200">
            <span>13:33</span>
            <div class="flex items-center gap-2">
              <!-- Offline mode toggle -->
              <button
                (click)="state.toggleAssociateOffline()"
                class="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold cursor-pointer"
                [class.bg-emerald-700]="!state.isAssociateOffline()"
                [class.bg-amber-600]="state.isAssociateOffline()"
              >
                {{ state.isAssociateOffline() ? 'OFFLINE (QUEUED)' : 'ONLINE' }}
              </button>
              <mat-icon class="text-xs">wifi</mat-icon>
              <span>92%</span>
            </div>
          </div>

          <!-- Associate App Title Bar -->
          <div class="bg-[#0071DC] px-3 py-2 flex items-center justify-between text-white">
            <div class="flex items-center gap-2">
              <mat-icon class="text-yellow-300 text-lg">local_shipping</mat-icon>
              <div>
                <div class="text-xs font-bold leading-none">Associate Workstation</div>
                <div class="text-[10px] text-blue-100">Devon Barnes · Inventory Specialist</div>
              </div>
            </div>

            <!-- Offline Queue Indicator -->
            @if (state.associateOfflineQueue().length > 0) {
              <button
                (click)="state.syncAssociateOfflineQueue()"
                class="bg-amber-400 text-slate-900 px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer animate-pulse"
              >
                Sync ({{ state.associateOfflineQueue().length }})
              </button>
            }
          </div>

          <!-- Handheld Navigation Tabs -->
          <div class="grid grid-cols-6 bg-slate-900 border-b border-slate-800 text-[10px]">
            <button
              (click)="activeMode.set('LOOKUP')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'LOOKUP'"
              [class.bg-slate-800]="activeMode() === 'LOOKUP'"
              [class.text-slate-400]="activeMode() !== 'LOOKUP'"
            >
              <mat-icon class="text-base">search</mat-icon>
              <span>Lookup</span>
            </button>
            <button
              (click)="activeMode.set('PICKING')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'PICKING'"
              [class.bg-slate-800]="activeMode() === 'PICKING'"
              [class.text-slate-400]="activeMode() !== 'PICKING'"
            >
              <mat-icon class="text-base">shopping_basket</mat-icon>
              <span>Pick</span>
            </button>
            <button
              (click)="activeMode.set('RECEIVING')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'RECEIVING'"
              [class.bg-slate-800]="activeMode() === 'RECEIVING'"
              [class.text-slate-400]="activeMode() !== 'RECEIVING'"
            >
              <mat-icon class="text-base">move_to_inbox</mat-icon>
              <span>Receive</span>
            </button>
            <button
              (click)="activeMode.set('CYCLE_COUNT')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'CYCLE_COUNT'"
              [class.bg-slate-800]="activeMode() === 'CYCLE_COUNT'"
              [class.text-slate-400]="activeMode() !== 'CYCLE_COUNT'"
            >
              <mat-icon class="text-base">fact_check</mat-icon>
              <span>Count</span>
            </button>
            <button
              (click)="activeMode.set('WASTE')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'WASTE'"
              [class.bg-slate-800]="activeMode() === 'WASTE'"
              [class.text-slate-400]="activeMode() !== 'WASTE'"
            >
              <mat-icon class="text-base">delete_sweep</mat-icon>
              <span>Waste</span>
            </button>
            <button
              (click)="activeMode.set('PRINTER')"
              class="py-2 flex flex-col items-center gap-0.5 font-medium transition-colors cursor-pointer"
              [class.text-yellow-400]="activeMode() === 'PRINTER'"
              [class.bg-slate-800]="activeMode() === 'PRINTER'"
              [class.text-slate-400]="activeMode() !== 'PRINTER'"
            >
              <mat-icon class="text-base">print</mat-icon>
              <span>Print</span>
            </button>
          </div>

          <!-- Main Interactive Viewport -->
          <div class="flex-1 p-3 overflow-y-auto space-y-3 text-xs">
            <!-- Simulated Barcode Viewfinder -->
            <div class="relative bg-slate-900 rounded-xl p-3 border border-slate-800 overflow-hidden">
              <div class="flex items-center justify-between text-[11px] text-slate-400 mb-2 font-mono">
                <span>LASER IMAGER / CAMERA SCAN</span>
                <span class="text-emerald-400 flex items-center gap-1">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> READY
                </span>
              </div>

              <!-- Reticle box -->
              <div class="relative h-20 bg-slate-950 rounded-lg flex items-center justify-center border border-dashed border-cyan-500/50">
                <div class="w-3/4 h-1 bg-red-500/80 shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse"></div>
                <span class="absolute text-[10px] text-slate-500 font-mono bottom-1">AIM SCANNER AT BARCODE</span>
              </div>

              <!-- Quick test scan barcodes buttons -->
              <div class="mt-2.5">
                <span class="text-[10px] text-slate-400 block mb-1">Quick-Scan Product Barcodes:</span>
                <div class="flex flex-wrap gap-1">
                  <button
                    (click)="scanBarcode('078742351982')"
                    class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-mono cursor-pointer"
                  >
                    Strawberries
                  </button>
                  <button
                    (click)="scanBarcode('033383401201')"
                    class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-mono cursor-pointer"
                  >
                    Avocados
                  </button>
                  <button
                    (click)="scanBarcode('041220881903')"
                    class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-mono cursor-pointer"
                  >
                    Honeycrisp
                  </button>
                  <button
                    (click)="scanBarcode('078742352217')"
                    class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-mono cursor-pointer"
                  >
                    Milk
                  </button>
                </div>
              </div>
            </div>

            <!-- MODE 1: LOOKUP -->
            @if (activeMode() === 'LOOKUP') {
              @if (scannedProduct(); as prod) {
                <div class="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2">
                  <div class="flex items-start justify-between">
                    <div>
                      <span class="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">{{ prod.sku }} · {{ prod.barcode }}</span>
                      <h3 class="font-bold text-white text-sm mt-0.5">{{ prod.name }}</h3>
                      <span class="text-slate-400 text-[11px]">{{ prod.category }}</span>
                    </div>
                    <div class="text-right">
                      <div class="text-sm font-bold font-mono text-emerald-400"><span>$</span>{{ prod.currentPrice.toFixed(2) }}</div>
                      <div class="text-[10px] text-slate-400">Cost: <span>$</span>{{ prod.costPrice.toFixed(2) }}</div>
                    </div>
                  </div>

                  <!-- Location & Inventory Numbers -->
                  <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                    <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span class="text-[10px] text-slate-400 block">Shelf Planogram Location</span>
                      <span class="font-mono font-bold text-white text-xs">Aisle 04 · Tier 2 · Bin 402</span>
                    </div>
                    <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span class="text-[10px] text-slate-400 block">Available to Promise (ATP)</span>
                      <span class="font-mono font-bold text-emerald-400 text-sm">
                        {{ getProductBalance(prod.id)?.atp || 0 }} units
                      </span>
                    </div>
                  </div>

                  <!-- Lots and Expiry -->
                  @if (getProductBalance(prod.id)?.lots; as lots) {
                    <div class="pt-1">
                      <span class="text-[10px] text-slate-400 font-mono uppercase block mb-1">Active Lots in Facility:</span>
                      @for (lot of lots; track lot.lotNumber) {
                        <div class="flex items-center justify-between py-1 px-2 rounded bg-slate-950/70 text-[10px] font-mono mb-1">
                          <span class="text-slate-300">{{ lot.lotNumber }} (Qty: {{ lot.quantity }})</span>
                          <span [class.text-amber-400]="lot.status === 'SHORT_DATED'" [class.text-slate-400]="lot.status === 'FRESH'">
                            Exp: {{ lot.expiryDate }} ({{ lot.daysToExpiry }}d)
                          </span>
                        </div>
                      }
                    </div>
                  }

                  <div class="pt-2 flex gap-2">
                    <button
                      (click)="state.printZebraLabel(prod.sku, 'SHELF_TAG')"
                      class="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-semibold text-[11px] cursor-pointer flex items-center justify-center gap-1"
                    >
                      <mat-icon class="text-xs">print</mat-icon> Print Shelf Tag
                    </button>
                    <button
                      (click)="activeMode.set('WASTE')"
                      class="px-3 py-1.5 bg-rose-950/70 hover:bg-rose-900 text-rose-200 rounded font-semibold text-[11px] cursor-pointer"
                    >
                      Report Damage
                    </button>
                  </div>
                </div>
              } @else {
                <div class="p-6 text-center text-slate-500 font-mono text-[11px]">
                  Scan a barcode above or tap a quick-scan product to inspect stock and shelf coordinates.
                </div>
              }
            }

            <!-- MODE 2: PICKING -->
            @if (activeMode() === 'PICKING') {
              <div class="space-y-2">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-yellow-400 font-bold">WAVE PICKING · ORDER #WMT-ORD-9821</span>
                  <span class="text-slate-400">CHILLED TOTE #T-42</span>
                </div>

                @for (item of activeOrderItems; track item.productId) {
                  <div
                    class="p-2.5 rounded-xl border transition-colors"
                    [class.bg-slate-900]="!item.isPicked"
                    [class.border-slate-800]="!item.isPicked"
                    [class.bg-emerald-950/40]="item.isPicked"
                    [class.border-emerald-800]="item.isPicked"
                  >
                    <div class="flex items-start justify-between">
                      <div>
                        <div class="font-mono text-[10px] text-cyan-400">Aisle 04 · Tier 2</div>
                        <div class="font-bold text-white text-xs mt-0.5">{{ item.name }}</div>
                        <div class="text-[10px] text-slate-400 font-mono">UPC: {{ item.barcode }} · Qty: {{ item.quantity }}</div>
                      </div>

                      <div>
                        @if (item.isPicked) {
                          <span class="text-emerald-400 font-bold font-mono text-[11px] flex items-center gap-1">
                            <mat-icon class="text-xs">check</mat-icon> VERIFIED
                          </span>
                        } @else {
                          <button
                            (click)="pickItem(item.productId, item.barcode)"
                            class="px-2.5 py-1 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold rounded text-[10px] cursor-pointer"
                          >
                            Scan Pick
                          </button>
                        }
                      </div>
                    </div>

                    @if (!item.isPicked && item.productId === 'prod-003') {
                      <div class="mt-2 pt-1.5 border-t border-slate-800 flex items-center justify-between text-[10px]">
                        <span class="text-amber-400">Honeycrisp low stock?</span>
                        <button
                          (click)="substituteHoneycrisp()"
                          class="px-2 py-0.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium cursor-pointer"
                        >
                          Propose Fuji Substitute
                        </button>
                      </div>
                    }

                    @if (item.substitutedWith) {
                      <div class="mt-1.5 p-1.5 bg-blue-950/70 rounded text-[10px] text-blue-200 font-mono">
                        ✓ Substituted with {{ item.substitutedWith.name }} (Consent verified)
                      </div>
                    }
                  </div>
                }
              </div>
            }

            <!-- MODE 3: RECEIVING -->
            @if (activeMode() === 'RECEIVING') {
              <div class="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2.5">
                <div class="font-bold text-white flex items-center gap-1.5">
                  <mat-icon class="text-cyan-400 text-sm">inventory</mat-icon>
                  Dock Receipt against PO-4401
                </div>
                <div class="text-[11px] text-slate-400">
                  Vendor: Pacific Berry Growers · Dock 04 · Temp: <span class="text-emerald-400 font-mono font-bold">34.2°F (PASS)</span>
                </div>

                <div class="bg-slate-950 p-2 rounded-lg border border-slate-800 space-y-1">
                  <div class="flex justify-between text-[11px]">
                    <span class="text-slate-400">Product:</span>
                    <span class="font-medium text-white">Fresh Strawberries (16 oz)</span>
                  </div>
                  <div class="flex justify-between text-[11px]">
                    <span class="text-slate-400">Invoiced:</span>
                    <span class="font-mono text-white">64 units (8 cases)</span>
                  </div>
                  <div class="flex justify-between text-[11px]">
                    <span class="text-slate-400">Scanned Count:</span>
                    <span class="font-mono text-yellow-400 font-bold">32 units (4 cases)</span>
                  </div>
                  <div class="flex justify-between text-[11px]">
                    <span class="text-slate-400">Assigned Lot:</span>
                    <span class="font-mono text-cyan-400">LOT-SB-2611C (Exp: 24h)</span>
                  </div>
                </div>

                <button
                  (click)="handleDockReceive()"
                  class="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg cursor-pointer text-xs"
                >
                  Confirm Dock Receipt & Post to Ledger
                </button>
              </div>
            }

            <!-- MODE 4: CYCLE COUNT -->
            @if (activeMode() === 'CYCLE_COUNT') {
              <div class="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2.5">
                <div class="font-bold text-white flex items-center gap-1.5">
                  <mat-icon class="text-yellow-400 text-sm">fact_check</mat-icon>
                  Bin Cycle Count Reconciliation
                </div>
                <div class="text-[11px] text-slate-400 font-mono">Location: Dairy Cooler 01 · Bin BIN-DRY-101</div>

                <div class="space-y-1.5">
                  <span class="text-[10px] text-slate-400 block font-mono">ITEM: Great Value Whole Milk (1 Gallon)</span>
                  <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-300">Book Balance:</span>
                    <span class="font-mono font-bold text-white text-xs">110 units</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <label for="physical-count-handheld" class="text-xs text-slate-300">Physical Count:</label>
                    <input
                      id="physical-count-handheld"
                      type="number"
                      [value]="physicalCountValue()"
                      (input)="onCountInput($event)"
                      class="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono font-bold text-yellow-300 w-24 text-center"
                    />
                  </div>
                </div>

                <button
                  (click)="handleReconcileCount()"
                  class="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg cursor-pointer text-xs"
                >
                  Post Variance Reconciliation
                </button>
              </div>
            }

            <!-- MODE 5: WASTE & DAMAGE -->
            @if (activeMode() === 'WASTE') {
              <div class="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2.5">
                <div class="font-bold text-rose-300 flex items-center gap-1.5">
                  <mat-icon class="text-rose-400 text-sm">delete_forever</mat-icon>
                  Shrink, Spoilage & Damage Write-off
                </div>

                <div class="space-y-2">
                  <div>
                    <span class="text-[10px] text-slate-400 block">Target Product:</span>
                    <span class="font-medium text-white text-xs">Fresh California Strawberries (16 oz)</span>
                  </div>

                  <div>
                    <span class="text-[10px] text-slate-400 block mb-1">Disposition Reason:</span>
                    <select
                      (change)="wasteReason.set($any($event.target).value)"
                      class="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-white"
                    >
                      <option value="EXPIRED_PAST_SELL_BY">Spoilage: Past Sell-by Date</option>
                      <option value="CRUSHED_IN_TRANSIT">Physical Damage: Crate Crushed</option>
                      <option value="COLD_CHAIN_BREACH">Cold Chain Temperature Excursion</option>
                    </select>
                  </div>

                  <div class="flex items-center gap-2">
                    <span class="text-xs text-slate-300">Units to Dispose:</span>
                    <input
                      type="number"
                      [value]="wasteUnits()"
                      (input)="wasteUnits.set(+$any($event.target).value)"
                      class="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono font-bold text-rose-400 w-20 text-center"
                    />
                  </div>
                </div>

                <button
                  (click)="handleWasteSubmit()"
                  class="w-full py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-lg cursor-pointer text-xs"
                >
                  Write Off & Print Hazardous/Disposal Tag
                </button>
              </div>
            }

            <!-- MODE 6: ZEBRA LABEL PRINTER ADAPTER -->
            @if (activeMode() === 'PRINTER') {
              <div class="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2.5">
                <div class="font-bold text-white flex items-center gap-1.5">
                  <mat-icon class="text-cyan-400 text-sm">print</mat-icon>
                  Zebra ZPL II Label Adapter
                </div>
                <div class="text-[11px] text-slate-400">
                  Connected: Mobile Zebra ZQ630 (Bluetooth ID: ZQ-1042-M4)
                </div>

                <div class="grid grid-cols-2 gap-2">
                  <button
                    (click)="state.printZebraLabel('WMT-STR-01', 'SHELF_TAG')"
                    class="p-2 bg-slate-800 hover:bg-slate-700 rounded text-center cursor-pointer"
                  >
                    <mat-icon class="text-yellow-400 text-base">label</mat-icon>
                    <div class="font-semibold text-xs mt-1">Shelf ESL Tag</div>
                    <div class="text-[9px] text-slate-400">2x1.25" barcode</div>
                  </button>
                  <button
                    (click)="state.printZebraLabel('WMT-STR-01', 'CLEARANCE_TAG')"
                    class="p-2 bg-slate-800 hover:bg-slate-700 rounded text-center cursor-pointer"
                  >
                    <mat-icon class="text-rose-400 text-base">local_offer</mat-icon>
                    <div class="font-semibold text-xs mt-1">Yellow Clearance</div>
                    <div class="text-[9px] text-slate-400">Markdown sticker</div>
                  </button>
                </div>

                <!-- Print Log -->
                <div class="pt-2 border-t border-slate-800">
                  <span class="text-[10px] text-slate-400 font-mono uppercase block mb-1">Recent Print Jobs:</span>
                  @for (log of state.labelPrinterLogs().slice(0, 3); track log.timestamp) {
                    <div class="p-1.5 bg-slate-950 rounded text-[10px] font-mono text-slate-300 mb-1 flex items-center justify-between">
                      <span>{{ log.labelType }} ({{ log.timestamp }})</span>
                      <span class="text-emerald-400">OK</span>
                    </div>
                  }
                </div>
              </div>
            }
          </div>

          <!-- Android Bottom Virtual Navigation Bar -->
          <div class="bg-slate-900 border-t border-slate-800 py-1 flex items-center justify-around text-slate-400">
            <button class="p-1 hover:text-white cursor-pointer"><mat-icon class="text-sm">arrow_back</mat-icon></button>
            <button class="p-1 hover:text-white cursor-pointer"><mat-icon class="text-sm">radio_button_unchecked</mat-icon></button>
            <button class="p-1 hover:text-white cursor-pointer"><mat-icon class="text-sm">crop_square</mat-icon></button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AssociateHandheldComponent {
  readonly state = inject(RetailStateService);
  readonly activeMode = signal<HandheldMode>('LOOKUP');
  readonly scannedBarcodeString = signal<string>('078742351982');
  readonly scannedProduct = signal<Product | null>(null);
  readonly physicalCountValue = signal<number>(114);
  readonly wasteUnits = signal<number>(2);
  readonly wasteReason = signal<string>('EXPIRED_PAST_SELL_BY');

  constructor() {
    // Default initial lookup product
    const initial = this.state.products().find(p => p.barcode === '078742351982') || null;
    this.scannedProduct.set(initial);
  }

  get activeOrderItems() {
    const ord = this.state.orders().find(o => o.id === 'ord-9821');
    return ord ? ord.items : [];
  }

  scanBarcode(barcode: string): void {
    this.scannedBarcodeString.set(barcode);
    const prod = this.state.products().find(p => p.barcode === barcode) || null;
    this.scannedProduct.set(prod);

    if (this.state.isAssociateOffline()) {
      this.state.queueAssociateOfflineAction({
        actionType: 'SCAN_VERIFY',
        payload: { barcode, productName: prod?.name }
      });
    } else {
      this.state.notify(`Scanned ${prod ? prod.name : barcode}`, 'info');
    }
  }

  getProductBalance(productId: string) {
    return this.state.inventoryBalances().find(
      b => b.productId === productId && b.locationId === this.state.selectedFacilityId()
    );
  }

  pickItem(productId: string, barcode: string): void {
    if (this.state.isAssociateOffline()) {
      this.state.queueAssociateOfflineAction({
        actionType: 'PICK_CONFIRM',
        payload: { orderId: 'ord-9821', productId, barcode }
      });
    } else {
      this.state.pickOrderItem('ord-9821', productId, barcode);
    }
  }

  substituteHoneycrisp(): void {
    this.state.substituteOrderItem(
      'ord-9821',
      'prod-003',
      'prod-004',
      'Honeycrisp out of stock on shelf; substituted with crisp Fuji Apples'
    );
  }

  handleDockReceive(): void {
    this.state.receiveDockDelivery('PO-4401', 'prod-001', 32, 'LOT-SB-2611C', '2026-11-10', 1);
  }

  onCountInput(event: Event): void {
    const val = +(event.target as HTMLInputElement).value;
    this.physicalCountValue.set(val);
  }

  handleReconcileCount(): void {
    this.state.reconcileCycleCount('prod-005', this.physicalCountValue(), 'Night shift physical shelf verification');
  }

  handleWasteSubmit(): void {
    this.state.recordWasteOrDamage('prod-001', this.wasteUnits(), this.wasteReason(), 'WASTE_EXPIRY');
    this.state.printZebraLabel('WMT-STR-01', 'CLEARANCE_TAG');
  }
}
