import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from './components/header/header.component';
import { ScenarioRunnerComponent } from './components/scenario-runner/scenario-runner.component';
import { AssociateHandheldComponent } from './components/handheld/associate-handheld.component';

// Views
import { OverviewViewComponent } from './views/overview-view.component';
import { InventoryViewComponent } from './views/inventory-view.component';
import { ReplenishmentViewComponent } from './views/replenishment-view.component';
import { OrdersViewComponent } from './views/orders-view.component';
import { DeliveryViewComponent } from './views/delivery-view.component';
import { PricingViewComponent } from './views/pricing-view.component';
import { LoyaltyViewComponent } from './views/loyalty-view.component';
import { StoresViewComponent } from './views/stores-view.component';
import { AnalyticsViewComponent } from './views/analytics-view.component';
import { AdminViewComponent } from './views/admin-view.component';

import { RetailStateService } from './core/services/retail-state.service';

export type MainTab =
  | 'overview'
  | 'inventory'
  | 'replenishment'
  | 'orders'
  | 'delivery'
  | 'pricing'
  | 'loyalty'
  | 'stores'
  | 'analytics'
  | 'admin';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    ScenarioRunnerComponent,
    AssociateHandheldComponent,
    OverviewViewComponent,
    InventoryViewComponent,
    ReplenishmentViewComponent,
    OrdersViewComponent,
    DeliveryViewComponent,
    PricingViewComponent,
    LoyaltyViewComponent,
    StoresViewComponent,
    AnalyticsViewComponent,
    AdminViewComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly state = inject(RetailStateService);
  readonly activeTab = signal<MainTab>('overview');
  readonly isScenarioDrawerOpen = signal<boolean>(true); // Open by default for immediate verification visibility

  readonly navItems: { id: MainTab; label: string; icon: string }[] = [
    { id: 'overview', label: 'Overview', icon: 'dashboard' },
    { id: 'inventory', label: 'Inventory', icon: 'inventory_2' },
    { id: 'replenishment', label: 'Replenishment', icon: 'auto_graph' },
    { id: 'orders', label: 'Orders', icon: 'shopping_cart' },
    { id: 'delivery', label: 'Delivery', icon: 'local_shipping' },
    { id: 'pricing', label: 'Pricing', icon: 'sell' },
    { id: 'loyalty', label: 'Loyalty', icon: 'card_membership' },
    { id: 'stores', label: 'Stores', icon: 'storefront' },
    { id: 'analytics', label: 'Analytics', icon: 'analytics' },
    { id: 'admin', label: 'Administration', icon: 'admin_panel_settings' }
  ];

  setTab(tab: string): void {
    this.activeTab.set(tab as MainTab);
  }

  toggleScenarioDrawer(): void {
    this.isScenarioDrawerOpen.update(v => !v);
  }
}
