import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-pricing-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Dynamic Pricing & Markdown Governance</span>
            <span aria-hidden="true">·</span>
            <span>4-Stage Approval & Channel Publication</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Dynamic Pricing Engine & Margin Floor Guardrails</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Transparent algorithmic pricing driven by product expiry dates, overstock clearance, and authorized competitor scraping. Never individualizes prices based on sensitive customer data.
          </p>
        </div>

        <!-- Stage Filter Tabs -->
        <div class="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium">
          <button
            (click)="stageFilter.set('ALL')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="stageFilter() === 'ALL'"
            [class.text-slate-900]="stageFilter() === 'ALL'"
            [class.shadow-xs]="stageFilter() === 'ALL'"
            [class.text-slate-600]="stageFilter() !== 'ALL'"
          >
            All Rules ({{ state.priceRules().length }})
          </button>
          <button
            (click)="stageFilter.set('RECOMMENDED')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="stageFilter() === 'RECOMMENDED'"
            [class.text-slate-900]="stageFilter() === 'RECOMMENDED'"
            [class.shadow-xs]="stageFilter() === 'RECOMMENDED'"
            [class.text-slate-600]="stageFilter() !== 'RECOMMENDED'"
          >
            Recommended
          </button>
          <button
            (click)="stageFilter.set('APPROVED')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="stageFilter() === 'APPROVED'"
            [class.text-slate-900]="stageFilter() === 'APPROVED'"
            [class.shadow-xs]="stageFilter() === 'APPROVED'"
            [class.text-slate-600]="stageFilter() !== 'APPROVED'"
          >
            Approved
          </button>
          <button
            (click)="stageFilter.set('PUBLISHED')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="stageFilter() === 'PUBLISHED'"
            [class.text-slate-900]="stageFilter() === 'PUBLISHED'"
            [class.shadow-xs]="stageFilter() === 'PUBLISHED'"
            [class.text-slate-600]="stageFilter() !== 'PUBLISHED'"
          >
            Published to ESL
          </button>
        </div>
      </div>

      <!-- Pricing Governance Rules Cards -->
      <div class="space-y-4">
        @for (rule of filteredRules(); track rule.id) {
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 text-xs">
            <!-- Card Header -->
            <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div class="flex items-center gap-2">
                <span class="font-mono font-bold text-slate-900 text-sm">{{ rule.sku }}</span>
                <span class="text-slate-400">·</span>
                <span class="font-bold text-slate-800 text-sm">{{ rule.productName }}</span>
                <span class="bg-slate-100 text-slate-700 font-mono text-[10px] px-2 py-0.5 rounded border border-slate-200">
                  {{ rule.ruleType }}
                </span>
                <span class="text-slate-400 font-mono text-[11px]">Scope: {{ rule.storeScope }}</span>
              </div>

              <!-- 4-Stage Status Indicator -->
              <div class="flex items-center gap-2">
                <div class="flex items-center gap-1 font-mono text-[11px] font-bold">
                  <span
                    class="px-2 py-0.5 rounded"
                    [class.bg-amber-100]="rule.stage === 'RECOMMENDED'"
                    [class.text-amber-800]="rule.stage === 'RECOMMENDED'"
                    [class.bg-blue-100]="rule.stage === 'APPROVED'"
                    [class.text-blue-800]="rule.stage === 'APPROVED'"
                    [class.bg-emerald-100]="rule.stage === 'PUBLISHED'"
                    [class.text-emerald-800]="rule.stage === 'PUBLISHED'"
                  >
                    STAGE: {{ rule.stage }}
                  </span>
                </div>
              </div>
            </div>

            <!-- Price Comparison Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 py-3 font-mono border-b border-slate-100">
              <div>
                <span class="text-slate-400 block text-[10px] font-sans">Current Base Price</span>
                <span class="text-slate-700 line-through text-sm"><span>$</span>{{ rule.basePrice.toFixed(2) }}</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px] font-sans">Recommended Markdown</span>
                <span class="font-bold text-emerald-700 text-base">
                  <span>$</span>{{ rule.recommendedPrice.toFixed(2) }}
                  <span class="text-xs text-emerald-600">(-{{ rule.markdownPct }}%)</span>
                </span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px] font-sans">Hard Margin Floor</span>
                <span class="text-slate-600 text-xs font-semibold"><span>$</span>{{ rule.currentFloorPrice.toFixed(2) }} (Enforced)</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px] font-sans">Competitor Index</span>
                @if (rule.competitorPrice) {
                  <span class="text-[#0071DC] font-semibold">
                    {{ rule.competitorPrice.competitor }}: <span>$</span>{{ rule.competitorPrice.observedPrice.toFixed(2) }}
                  </span>
                } @else {
                  <span class="text-slate-400">Internal Inventory Driven</span>
                }
              </div>
            </div>

            <!-- Rationale & Transparent Assumptions -->
            <div class="py-2.5 text-slate-700 text-xs leading-relaxed">
              <span class="font-semibold text-slate-900">Optimization Objective & Rationale: </span>
              <span>{{ rule.rationale }}</span>
            </div>

            <!-- Published Channel Confirmations -->
            <div class="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
              <div class="flex items-center gap-4 text-[11px] font-mono">
                <div class="flex items-center gap-1.5" [class.text-emerald-700]="rule.publishedChannels.shelfESL" [class.text-slate-400]="!rule.publishedChannels.shelfESL">
                  <mat-icon class="text-sm">
                    {{ rule.publishedChannels.shelfESL ? 'check_circle' : 'radio_button_unchecked' }}
                  </mat-icon>
                  <span>Shelf ESL Tags</span>
                </div>
                <div class="flex items-center gap-1.5" [class.text-emerald-700]="rule.publishedChannels.storePOS" [class.text-slate-400]="!rule.publishedChannels.storePOS">
                  <mat-icon class="text-sm">
                    {{ rule.publishedChannels.storePOS ? 'check_circle' : 'radio_button_unchecked' }}
                  </mat-icon>
                  <span>Store POS</span>
                </div>
                <div class="flex items-center gap-1.5" [class.text-emerald-700]="rule.publishedChannels.onlineApp" [class.text-slate-400]="!rule.publishedChannels.onlineApp">
                  <mat-icon class="text-sm">
                    {{ rule.publishedChannels.onlineApp ? 'check_circle' : 'radio_button_unchecked' }}
                  </mat-icon>
                  <span>Online Web/App</span>
                </div>
              </div>

              <!-- Workflow Actions -->
              <div class="flex items-center gap-2">
                @if (rule.stage === 'RECOMMENDED') {
                  <button
                    (click)="state.approvePriceRule(rule.id)"
                    class="px-3 py-1.5 bg-[#0071DC] hover:bg-blue-700 text-white font-semibold rounded-lg text-xs cursor-pointer shadow-sm transition-colors"
                  >
                    Approve Recommendation
                  </button>
                }

                @if (rule.stage === 'APPROVED') {
                  <button
                    (click)="state.publishPriceRule(rule.id)"
                    class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs cursor-pointer shadow-sm transition-colors"
                  >
                    Publish to Channels (ESL Sync)
                  </button>
                }

                @if (rule.stage === 'PUBLISHED') {
                  <span class="text-emerald-700 font-mono font-bold flex items-center gap-1 text-[11px]">
                    <mat-icon class="text-xs">verified</mat-icon> Active on Sales Floor
                  </span>
                }
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class PricingViewComponent {
  readonly state = inject(RetailStateService);
  readonly stageFilter = signal<'ALL' | 'RECOMMENDED' | 'APPROVED' | 'PUBLISHED'>('ALL');

  filteredRules() {
    const stage = this.stageFilter();
    if (stage === 'ALL') return this.state.priceRules();
    return this.state.priceRules().filter(r => r.stage === stage);
  }
}
