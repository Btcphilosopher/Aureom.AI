import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-replenishment-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Procurement & Demand Forecasting</span>
            <span aria-hidden="true">·</span>
            <span>Unconstrained Demand Engine</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Replenishment & Purchase Orders</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Calculates safety stock, lead times, case-pack rounding, and underlying demand adjusted for stockout periods. Constrained by shelf capacity and spoilage risk.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="activeTab.set('FORECAST')"
            class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer"
            [class.bg-[#0071DC]]="activeTab() === 'FORECAST'"
            [class.text-white]="activeTab() === 'FORECAST'"
            [class.border-[#0071DC]]="activeTab() === 'FORECAST'"
            [class.bg-white]="activeTab() !== 'FORECAST'"
            [class.text-slate-700]="activeTab() !== 'FORECAST'"
            [class.border-slate-300]="activeTab() !== 'FORECAST'"
          >
            <mat-icon class="text-sm mr-1 align-middle">auto_graph</mat-icon>
            Demand Forecast & ROP
          </button>
          <button
            (click)="activeTab.set('POS')"
            class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer"
            [class.bg-[#0071DC]]="activeTab() === 'POS'"
            [class.text-white]="activeTab() === 'POS'"
            [class.border-[#0071DC]]="activeTab() === 'POS'"
            [class.bg-white]="activeTab() !== 'POS'"
            [class.text-slate-700]="activeTab() !== 'POS'"
            [class.border-slate-300]="activeTab() !== 'POS'"
          >
            <mat-icon class="text-sm mr-1 align-middle">local_shipping</mat-icon>
            Purchase Orders ({{ state.purchaseOrders().length }})
          </button>
        </div>
      </div>

      <!-- VIEW 1: DEMAND FORECAST & REPLENISHMENT ENGINE -->
      @if (activeTab() === 'FORECAST') {
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 class="font-bold text-slate-900 text-sm">Automated Replenishment Optimization Matrix</h3>
              <p class="text-xs text-slate-500">
                Notice: Underlying demand accounts for suppressed sales on zero-inventory days.
              </p>
            </div>
            <div class="text-xs text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 font-mono">
              Configured Seasonality Factor: <span class="font-bold text-[#0071DC]">1.15x (Weekend Lift)</span>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
                <tr>
                  <th class="py-3 px-4 font-semibold font-sans">Product</th>
                  <th class="py-3 px-4 font-semibold text-right">On Hand / ATP</th>
                  <th class="py-3 px-4 font-semibold text-right">Reorder Point</th>
                  <th class="py-3 px-4 font-semibold text-right">Safety Stock</th>
                  <th class="py-3 px-4 font-semibold text-right">Observed Daily</th>
                  <th class="py-3 px-4 font-semibold text-right text-[#0071DC] font-bold">Underlying Demand</th>
                  <th class="py-3 px-4 font-semibold text-right">Stockout Days</th>
                  <th class="py-3 px-4 font-semibold text-right text-emerald-700 font-bold">Recommended Order</th>
                  <th class="py-3 px-4 font-semibold">Expiry Risk</th>
                  <th class="py-3 px-4 font-semibold font-sans">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (item of state.forecasts(); track item.productId) {
                  <tr class="hover:bg-slate-50 transition-colors">
                    <td class="py-3.5 px-4 font-sans font-medium text-slate-900">
                      <div>{{ item.productName }}</div>
                      <div class="text-[10px] font-mono text-slate-400">Lead time: {{ item.leadTimeDays }}d · Shelf Max: {{ item.shelfCapacityMax }}</div>
                    </td>
                    <td class="py-3.5 px-4 text-right">
                      <span class="font-bold" [class.text-rose-700]="item.currentATP <= item.reorderPoint">
                        {{ item.currentOnHand }} / {{ item.currentATP }}
                      </span>
                    </td>
                    <td class="py-3.5 px-4 text-right font-bold text-slate-800">{{ item.reorderPoint }}</td>
                    <td class="py-3.5 px-4 text-right text-slate-600">{{ item.safetyStock }}</td>
                    <td class="py-3.5 px-4 text-right text-slate-600">{{ item.avgDailySales }}/d</td>
                    <td class="py-3.5 px-4 text-right text-[#0071DC] font-bold bg-blue-50/40">
                      {{ item.underlyingDemand }}/d
                    </td>
                    <td class="py-3.5 px-4 text-right">
                      <span [class.text-rose-600]="item.stockoutDaysLast30 > 0" [class.font-bold]="item.stockoutDaysLast30 > 0">
                        {{ item.stockoutDaysLast30 }} days
                      </span>
                    </td>
                    <td class="py-3.5 px-4 text-right text-emerald-700 font-bold text-sm bg-emerald-50/40">
                      {{ item.roundedCasePackQty }} units
                    </td>
                    <td class="py-3.5 px-4">
                      <span
                        class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-emerald-100]="item.expiryRiskScore === 'LOW'"
                        [class.text-emerald-800]="item.expiryRiskScore === 'LOW'"
                        [class.bg-amber-100]="item.expiryRiskScore === 'MEDIUM'"
                        [class.text-amber-800]="item.expiryRiskScore === 'MEDIUM'"
                        [class.bg-rose-100]="item.expiryRiskScore === 'HIGH'"
                        [class.text-rose-800]="item.expiryRiskScore === 'HIGH'"
                      >
                        {{ item.expiryRiskScore }}
                      </span>
                    </td>
                    <td class="py-3.5 px-4 font-sans">
                      <button
                        (click)="state.generateReplenishmentPO(item.productId, item.roundedCasePackQty)"
                        class="px-3 py-1.5 bg-[#0071DC] hover:bg-blue-700 text-white rounded-lg font-semibold text-xs cursor-pointer shadow-sm transition-colors whitespace-nowrap"
                      >
                        Generate PO
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- VIEW 2: PURCHASE ORDERS & DOCK APPOINTMENTS -->
      @if (activeTab() === 'POS') {
        <div class="space-y-4">
          @for (po of state.purchaseOrders(); track po.poNumber) {
            <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 text-xs">
              <div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                <div class="flex items-center gap-3">
                  <span class="font-mono font-bold text-base text-slate-900">{{ po.poNumber }}</span>
                  <span
                    class="px-2 py-0.5 rounded text-[11px] font-mono font-bold"
                    [class.bg-emerald-100]="po.status === 'RECEIVED'"
                    [class.text-emerald-800]="po.status === 'RECEIVED'"
                    [class.bg-amber-100]="po.status === 'PARTIALLY_RECEIVED'"
                    [class.text-amber-800]="po.status === 'PARTIALLY_RECEIVED'"
                    [class.bg-blue-100]="po.status === 'IN_TRANSIT'"
                    [class.text-blue-800]="po.status === 'IN_TRANSIT'"
                    [class.bg-purple-100]="po.status === 'APPROVED'"
                    [class.text-purple-800]="po.status === 'APPROVED'"
                  >
                    {{ po.status }}
                  </span>
                </div>

                <div class="flex items-center gap-4 text-slate-500 font-mono">
                  <span>Ordered: {{ po.orderDate }}</span>
                  <span>Expected: {{ po.expectedDelivery }}</span>
                  <span class="text-slate-900 font-bold"><span>$</span>{{ po.totalCost.toFixed(2) }}</span>
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 py-3 text-slate-600">
                <div>
                  <span class="text-slate-400 block text-[11px]">Supplier / Vendor:</span>
                  <span class="font-semibold text-slate-900">{{ po.supplierName }}</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[11px]">Destination Facility:</span>
                  <span class="font-semibold text-slate-900">{{ po.destinationName }}</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[11px]">Dock Appointment:</span>
                  <span class="font-mono font-bold text-[#0071DC]">{{ po.dockAppointment }}</span>
                </div>
              </div>

              <!-- Discrepancy Note (if partial receipt) -->
              @if (po.discrepancyNote) {
                <div class="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px] mb-3 flex items-center gap-2">
                  <mat-icon class="text-amber-600 text-base">warning</mat-icon>
                  <span>{{ po.discrepancyNote }}</span>
                </div>
              }

              <!-- Items in PO -->
              <div class="bg-slate-50 rounded-lg p-3 border border-slate-200">
                <span class="text-[11px] font-mono text-slate-500 uppercase block mb-1">Invoiced Line Items:</span>
                @for (item of po.items; track item.productId) {
                  <div class="flex items-center justify-between text-xs py-1">
                    <span class="font-medium text-slate-800">{{ item.productName }} ({{ item.productSku }})</span>
                    <span class="font-mono">
                      Received: <span class="font-bold text-slate-900">{{ item.receivedQty }}</span> / {{ item.orderedQty }} units
                      ({{ item.caseCount }} cases)
                    </span>
                  </div>
                }
              </div>

              @if (po.status !== 'RECEIVED') {
                <div class="mt-4 flex justify-end gap-2">
                  <button
                    (click)="state.receiveDockDelivery(po.poNumber, po.items[0].productId, 32, 'LOT-REC-NEW', '2026-11-20', 11)"
                    class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs cursor-pointer"
                  >
                    Record Dock Inbound Scan
                  </button>
                </div>
              }
            </div>
          }
        </div>
      }
    </div>
  `
})
export class ReplenishmentViewComponent {
  readonly state = inject(RetailStateService);
  readonly activeTab = signal<'FORECAST' | 'POS'>('FORECAST');
}
