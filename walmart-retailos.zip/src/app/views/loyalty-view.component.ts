import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-loyalty-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Customer Loyalty & Points Ledger</span>
            <span aria-hidden="true">·</span>
            <span>Transactional Double-Spend Protection</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Walmart+ Loyalty Engine & Digital Cards</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Immutable loyalty point accounting, barcode/NFC credentials, active coupon redemption, returns point reversal, and customer-controlled privacy preferences.
          </p>
        </div>

        <!-- Simulated NFC Tap Button -->
        <button
          (click)="simulateNfcTap()"
          class="flex items-center gap-1.5 px-3 py-2 bg-[#0071DC] hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-sm"
        >
          <mat-icon class="text-sm">contactless</mat-icon>
          <span>Simulate NFC Terminal Tap</span>
        </button>
      </div>

      <!-- Members Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        @for (member of state.loyaltyMembers(); track member.id) {
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between">
            <!-- Digital Member Card Visual -->
            <div class="p-6 bg-gradient-to-br from-[#041E42] via-[#0071DC] to-[#041E42] text-white relative">
              <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-2">
                  <span class="w-7 h-7 rounded-full bg-[#FFC220] flex items-center justify-center font-black text-[#041E42] text-xs">
                    *
                  </span>
                  <span class="font-bold tracking-tight text-white text-base">Walmart+</span>
                </div>
                <span class="text-xs font-mono font-bold bg-white/20 px-2 py-0.5 rounded text-yellow-300">
                  {{ member.tier }}
                </span>
              </div>

              <div class="space-y-1">
                <div class="text-lg font-bold text-white">{{ member.fullName }}</div>
                <div class="text-xs text-blue-200 font-mono tracking-wider">MEMBER ID: {{ member.memberId }}</div>
              </div>

              <!-- Barcode / QR Simulation Strip -->
              <div class="mt-5 pt-3 border-t border-white/20 flex items-center justify-between">
                <div>
                  <div class="font-mono text-sm tracking-widest text-white/90">||| | | |||| || | || |||</div>
                  <span class="text-[10px] font-mono text-blue-200 block">{{ member.barcode }}</span>
                </div>

                <div class="text-right">
                  <span class="text-[10px] text-blue-200 block">Available Points</span>
                  <span class="text-xl font-bold font-mono text-yellow-300 tabular-nums">
                    {{ member.pointsBalance.toLocaleString() }} pts
                  </span>
                  <div class="text-[10px] text-blue-200">
                    (<span>$</span>{{ (member.pointsBalance / 100).toFixed(2) }} cash value)
                  </div>
                </div>
              </div>
            </div>

            <!-- Member Privileges & Active Coupons -->
            <div class="p-5 text-xs space-y-4">
              <div>
                <span class="text-[11px] font-mono uppercase text-slate-500 font-bold block mb-2">Active Digital Coupons:</span>
                <div class="space-y-2">
                  @for (coupon of member.activeCoupons; track coupon.code) {
                    <div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                      <div>
                        <div class="font-bold text-slate-900 font-mono text-[11px]">{{ coupon.code }}</div>
                        <div class="text-slate-600 text-[11px] mt-0.5">{{ coupon.description }}</div>
                      </div>
                      <span class="font-mono text-emerald-700 font-bold text-xs">
                        -<span>$</span>{{ coupon.discountAmount.toFixed(2) }}
                      </span>
                    </div>
                  }
                </div>
              </div>

              <!-- Privacy & Consent Controls -->
              <div class="pt-3 border-t border-slate-100 space-y-1.5 text-slate-600 text-[11px]">
                <div class="flex items-center justify-between">
                  <span>Marketing Communication Opt-in:</span>
                  <span class="font-mono font-bold text-emerald-700">GRANTED</span>
                </div>
                <div class="flex items-center justify-between">
                  <span>Purchase History Data Consent:</span>
                  <span class="font-mono font-bold text-emerald-700">CUSTOMER CONTROLLED</span>
                </div>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Transactional Points Ledger Table -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 class="font-bold text-slate-900 text-sm">Transactional Loyalty Points Ledger</h3>
            <p class="text-xs text-slate-500">
              Double-spend proof: Idempotency keys prevent replay and ensure accurate returns clawback.
            </p>
          </div>
          <span class="text-xs font-mono text-slate-500">{{ state.loyaltyLedger().length }} ledger transactions</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
              <tr>
                <th class="py-3 px-4 font-semibold">Timestamp</th>
                <th class="py-3 px-4 font-semibold">Member</th>
                <th class="py-3 px-4 font-semibold">Transaction Type</th>
                <th class="py-3 px-4 font-semibold text-right">Points Delta</th>
                <th class="py-3 px-4 font-semibold text-right">Balance After</th>
                <th class="py-3 px-4 font-semibold font-sans">Description</th>
                <th class="py-3 px-4 font-semibold">Idempotency Key</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (entry of state.loyaltyLedger(); track entry.id) {
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="py-3 px-4 text-slate-500 text-[11px]">{{ entry.timestamp | date:'short' }}</td>
                  <td class="py-3 px-4 font-bold text-slate-900">{{ entry.memberId }}</td>
                  <td class="py-3 px-4">
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-100]="entry.type === 'EARN_PURCHASE'"
                      [class.text-emerald-800]="entry.type === 'EARN_PURCHASE'"
                      [class.bg-amber-100]="entry.type === 'REDEMPTION'"
                      [class.text-amber-800]="entry.type === 'REDEMPTION'"
                      [class.bg-rose-100]="entry.type === 'RETURN_REVERSAL'"
                      [class.text-rose-800]="entry.type === 'RETURN_REVERSAL'"
                    >
                      {{ entry.type }}
                    </span>
                  </td>
                  <td
                    class="py-3 px-4 text-right font-bold text-sm"
                    [class.text-emerald-700]="entry.pointsDelta > 0"
                    [class.text-rose-700]="entry.pointsDelta < 0"
                  >
                    {{ entry.pointsDelta > 0 ? '+' : '' }}{{ entry.pointsDelta }} pts
                  </td>
                  <td class="py-3 px-4 text-right font-bold text-slate-900">{{ entry.balanceAfter }} pts</td>
                  <td class="py-3 px-4 font-sans text-slate-700">{{ entry.description }}</td>
                  <td class="py-3 px-4 text-slate-400 text-[10px]">{{ entry.idempotencyKey }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class LoyaltyViewComponent {
  readonly state = inject(RetailStateService);

  simulateNfcTap(): void {
    this.state.notify(
      'NFC Tap Verified: Member Elena Rostova (WMT-8849-01) authenticated at Register 04. 1,240 points available.',
      'success'
    );
    this.state.addAuditLog(
      'LOYALTY',
      'NFC_TAP_VERIFIED',
      'WMT-8849-01',
      'Physical simulated NFC token tap detected at Register 04. Secure member identification token exchanged.'
    );
  }
}
