import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

interface MetricDrilldown {
  name: string;
  definition: string;
  reportingPeriod: string;
  accountingDistinction: string;
  dataPoints: { label: string; value: string; note: string }[];
}

@Component({
  selector: 'app-analytics-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Operational Intelligence & Telemetry</span>
            <span aria-hidden="true">·</span>
            <span>Rigorous Transactional Metrics</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Analytics, Accuracy & Supplier Reliability</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Every metric displays an explicit mathematical definition, reporting period, and underlying transaction drill-down. Strictly separates observed sales from true demand.
          </p>
        </div>

        <div class="text-xs text-slate-500 font-mono bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
          Reporting Cycle: <span class="font-bold text-slate-800">Trailing 30 Days (T-30D)</span>
        </div>
      </div>

      <!-- Core 6 Metric Grid with Click-to-Drilldown -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Metric 1: Revenue vs Margin -->
        <button
          type="button"
          (click)="openDrilldown('FINANCIAL')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Gross Sales & Margin</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">$1,842,500</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>Gross Profit: <span class="font-bold text-emerald-700">$492,800</span></span>
            <span>·</span>
            <span>Margin: <span class="font-bold text-slate-800">26.7%</span></span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Total recognized gross revenues before returns, minus COGS.
          </p>
        </button>

        <!-- Metric 2: On-Shelf Availability -->
        <button
          type="button"
          (click)="openDrilldown('OSA')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">On-Shelf Availability (OSA)</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-emerald-700 tabular-nums">98.4%</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>Stockouts: <span class="font-bold text-rose-600">7 occurrences</span></span>
            <span>·</span>
            <span>Target: 97.5%</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Active SKUs physically available on the shelf during store operating hours.
          </p>
        </button>

        <!-- Metric 3: Shrink, Spoilage & Expiry -->
        <button
          type="button"
          (click)="openDrilldown('SHRINK')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Waste & Spoilage Loss</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-rose-700 tabular-nums">$4,120 (0.22%)</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>Perishables: 78%</span>
            <span>·</span>
            <span>Clearance salvaged: $1,890</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Value of inventory disposed due to expiry dates or transit crushing.
          </p>
        </button>

        <!-- Metric 4: Forecast Accuracy (MAPE) -->
        <button
          type="button"
          (click)="openDrilldown('FORECAST_ERROR')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Forecast Error (MAPE)</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">4.8% MAPE</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>Accuracy: <span class="font-bold text-emerald-700">95.2%</span></span>
            <span>·</span>
            <span>Unconstrained modeling</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Mean Absolute Percentage Error between forecasted and actual sales.
          </p>
        </button>

        <!-- Metric 5: Picking Accuracy & Rate -->
        <button
          type="button"
          (click)="openDrilldown('PICKING_RATE')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Associate Pick Rate</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">114 UPH</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>Accuracy: <span class="font-bold text-emerald-700">99.8%</span></span>
            <span>·</span>
            <span>Zebra barcode enforced</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Units Picked per Hour per associate across eCommerce fulfillment waves.
          </p>
        </button>

        <!-- Metric 6: Delivery OTIF & Punctuality -->
        <button
          type="button"
          (click)="openDrilldown('DELIVERY_OTIF')"
          class="text-left w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-[#0071DC] transition-all cursor-pointer group"
        >
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Delivery OTIF</span>
            <mat-icon class="text-slate-400 group-hover:text-[#0071DC] text-base">open_in_new</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-emerald-700 tabular-nums">98.2%</div>
          <div class="flex items-center gap-2 text-xs text-slate-600 mt-1 font-mono">
            <span>On-Time: 98.8%</span>
            <span>·</span>
            <span>In-Full: 99.4%</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-100">
            Definition: Orders arriving both strictly within the customer window and 100% complete.
          </p>
        </button>
      </div>

      <!-- Supplier Reliability Scorecards Table -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 class="font-bold text-slate-900 text-sm">Vendor & Supplier Reliability Scorecards</h3>
            <p class="text-xs text-slate-500">
              Evaluates PO adherence, fill rate, dock appointment punctuality, and cold chain temperature compliance.
            </p>
          </div>
          <span class="text-xs font-mono text-slate-500">4 Active Primary Vendors</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
              <tr>
                <th class="py-3 px-4 font-semibold font-sans">Vendor Name</th>
                <th class="py-3 px-4 font-semibold">Lead Time Adherence</th>
                <th class="py-3 px-4 font-semibold">Fill Rate</th>
                <th class="py-3 px-4 font-semibold">Cold Chain Pass Rate</th>
                <th class="py-3 px-4 font-semibold">Discrepancy Rate</th>
                <th class="py-3 px-4 font-semibold font-sans">Reliability Rating</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              <tr class="hover:bg-slate-50">
                <td class="py-3 px-4 font-sans font-medium text-slate-900">Pacific Berry Growers Co-op</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">96.4%</td>
                <td class="py-3 px-4 text-amber-700 font-bold">88.5% (Shortage flagged)</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.1% (34.2°F avg)</td>
                <td class="py-3 px-4 text-rose-700">11.5%</td>
                <td class="py-3 px-4 font-sans text-amber-700 font-bold">Tier 2 · Monitored</td>
              </tr>
              <tr class="hover:bg-slate-50">
                <td class="py-3 px-4 font-sans font-medium text-slate-900">Valley Verde Fresh Produce</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.2%</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.6%</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">100.0%</td>
                <td class="py-3 px-4 text-emerald-700">0.4%</td>
                <td class="py-3 px-4 font-sans text-emerald-700 font-bold">Tier 1 · Preferred</td>
              </tr>
              <tr class="hover:bg-slate-50">
                <td class="py-3 px-4 font-sans font-medium text-slate-900">Ozark Creameries LLC</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">98.7%</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.0%</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.8%</td>
                <td class="py-3 px-4 text-emerald-700">1.0%</td>
                <td class="py-3 px-4 font-sans text-emerald-700 font-bold">Tier 1 · Preferred</td>
              </tr>
              <tr class="hover:bg-slate-50">
                <td class="py-3 px-4 font-sans font-medium text-slate-900">Procter & Gamble Direct</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">99.8%</td>
                <td class="py-3 px-4 text-emerald-700 font-bold">100.0%</td>
                <td class="py-3 px-4 text-slate-400">N/A (Ambient)</td>
                <td class="py-3 px-4 text-emerald-700">0.0%</td>
                <td class="py-3 px-4 font-sans text-emerald-700 font-bold">Tier 1 · Preferred</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- METRIC DRILLDOWN MODAL -->
      @if (activeDrilldown(); as drill) {
        <div class="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div class="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span class="text-[10px] font-mono text-[#0071DC] uppercase font-bold">Underlying Transaction Drill-Down</span>
                <h3 class="font-bold text-slate-900 text-sm mt-0.5">{{ drill.name }}</h3>
              </div>
              <button
                (click)="activeDrilldown.set(null)"
                class="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div class="mt-4 space-y-3 font-sans">
              <div class="bg-slate-50 p-3 rounded-lg border border-slate-200">
                <span class="text-slate-500 font-bold block text-[11px]">Strict Metric Definition:</span>
                <p class="text-slate-800 text-xs mt-0.5">{{ drill.definition }}</p>
                <div class="mt-2 text-[11px] text-slate-500 font-mono">
                  Reporting Period: <span class="font-bold text-slate-800">{{ drill.reportingPeriod }}</span>
                </div>
              </div>

              <div>
                <span class="text-[11px] font-mono uppercase text-slate-500 font-bold block mb-1">
                  Accounting & Granular Ledger Items:
                </span>
                <div class="space-y-1.5 font-mono">
                  @for (dp of drill.dataPoints; track dp.label) {
                    <div class="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                      <span class="font-medium text-slate-800">{{ dp.label }}</span>
                      <div class="text-right">
                        <span class="font-bold text-slate-900">{{ dp.value }}</span>
                        <span class="text-[10px] text-slate-400 block font-sans">{{ dp.note }}</span>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>

            <div class="mt-5 pt-3 border-t border-slate-200 flex justify-end">
              <button
                (click)="activeDrilldown.set(null)"
                class="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold cursor-pointer"
              >
                Close Drilldown
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AnalyticsViewComponent {
  readonly state = inject(RetailStateService);
  readonly activeDrilldown = signal<MetricDrilldown | null>(null);

  openDrilldown(type: string): void {
    if (type === 'FINANCIAL') {
      this.activeDrilldown.set({
        name: 'Gross Sales & Margin Accounting',
        definition: 'Gross sales receipts captured across registers, online checkout, minus wholesale purchase cost.',
        reportingPeriod: 'Trailing 30 Days (T-30D)',
        accountingDistinction: 'Distinguishes cash receipts from accrued receivables.',
        dataPoints: [
          { label: 'Register POS Sales', value: '$1,220,400', note: 'Store #1042 registers' },
          { label: 'Online Grocery Delivery', value: '$462,100', note: 'App delivery orders' },
          { label: 'Curbside Click & Collect', value: '$160,000', note: 'Bay pickup orders' },
          { label: 'Wholesale COGS Deducted', value: '-$1,349,700', note: 'Supplier invoice cost' },
          { label: 'Net Gross Profit Margin', value: '$492,800', note: '26.7% realized gross margin' }
        ]
      });
    } else if (type === 'OSA') {
      this.activeDrilldown.set({
        name: 'On-Shelf Availability (OSA) & Stockout Records',
        definition: 'Percentage of total planogram bins with positive available stock during active shopping hours.',
        reportingPeriod: 'Trailing 30 Days',
        accountingDistinction: 'Excludes backroom pallet stock until physically placed on shelf.',
        dataPoints: [
          { label: 'Total Scanned Shelf Hours', value: '43,200 hrs', note: '38 cold sensors & RFID passes' },
          { label: 'Zero-Stock Duration', value: '691 hrs', note: 'Honeycrisp & Strawberries' },
          { label: 'Effective On-Shelf Ratio', value: '98.4%', note: '+0.6% above 97.5% baseline' }
        ]
      });
    } else if (type === 'SHRINK') {
      this.activeDrilldown.set({
        name: 'Waste, Spoilage & Expiry Losses',
        definition: 'Documented inventory write-offs logged in the immutable stock movement ledger with reason codes.',
        reportingPeriod: 'Trailing 30 Days',
        accountingDistinction: 'Separates transit damage from past-sell-by shelf disposal.',
        dataPoints: [
          { label: 'Fresh Strawberries Spoilage', value: '$1,240', note: 'Past sell-by date disposal' },
          { label: 'Bakery Country Sourdough', value: '$980', note: 'Daily fresh bake clearance' },
          { label: 'In-Transit Fruit Crushing', value: '$720', note: 'Bruised berries claim filed' },
          { label: 'Dairy Short-Date Reclamation', value: '$1,180', note: 'Donation credit captured' }
        ]
      });
    } else {
      this.activeDrilldown.set({
        name: 'Delivery OTIF & Fulfillment Accuracy',
        definition: 'Orders delivered within requested 2-hour window with 100% item accuracy or approved substitutions.',
        reportingPeriod: 'Trailing 30 Days',
        accountingDistinction: 'Failed or rescheduled stops treated strictly as defect.',
        dataPoints: [
          { label: 'Total Dispatched Waves', value: '412 Waves', note: 'Vans 102, 104 & Drone 88' },
          { label: 'On-Time Deliveries', value: '407 Stops', note: '98.8% punctuality' },
          { label: 'In-Full Item Fulfillment', value: '409 Orders', note: '99.4% picking completion' },
          { label: 'Composite OTIF Score', value: '98.2%', note: 'Exceeds regional 97.0% SLA' }
        ]
      });
    }
  }
}
