import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-stores-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Retail Store Network & Facilities</span>
            <span aria-hidden="true">·</span>
            <span>Supercenters, Neighborhood Markets & RDCs</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Facility Network & Store Operations</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Overview of brick-and-mortar nodes, backroom layout coordinates, cold-chain sensor status, and associate staffing levels.
          </p>
        </div>
      </div>

      <!-- Facility Cards Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        @for (fac of state.facilities(); track fac.id) {
          <div
            class="bg-white rounded-xl border shadow-sm p-5 flex flex-col justify-between transition-all"
            [class.border-[#0071DC]]="state.selectedFacilityId() === fac.id"
            [class.ring-2]="state.selectedFacilityId() === fac.id"
            [class.ring-[#0071DC]/20]="state.selectedFacilityId() === fac.id"
            [class.border-slate-200]="state.selectedFacilityId() !== fac.id"
          >
            <div>
              <div class="flex items-center justify-between mb-3">
                <span class="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                  {{ fac.code }}
                </span>
                <span
                  class="text-[10px] font-mono px-2 py-0.5 rounded font-bold"
                  [class.bg-emerald-100]="fac.tempStatus === 'NOMINAL'"
                  [class.text-emerald-800]="fac.tempStatus === 'NOMINAL'"
                >
                  {{ fac.tempStatus }}
                </span>
              </div>

              <h3 class="font-bold text-slate-900 text-base">{{ fac.name }}</h3>
              <p class="text-xs text-slate-500 mt-0.5">{{ fac.address }}, {{ fac.city }}, {{ fac.state }}</p>

              <!-- Facility Metrics Grid -->
              <div class="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-100 text-xs font-mono">
                <div>
                  <span class="text-slate-400 block text-[10px] font-sans">Active Shift Roster</span>
                  <span class="font-bold text-slate-800">{{ fac.activeAssociates }} Associates</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] font-sans">Sales Floor Area</span>
                  <span class="font-bold text-slate-800">{{ fac.shelfCapacitySqFt.toLocaleString() }} sq ft</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] font-sans">Cold Chain Telemetry</span>
                  <span class="font-bold text-emerald-700">{{ fac.avgTempFahrenheit }}°F ({{ fac.coldChainSensorsCount }} sensors)</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] font-sans">Capacity Utilization</span>
                  <span class="font-bold text-slate-800">{{ fac.capacityUtilizationPct }}%</span>
                </div>
              </div>
            </div>

            <div class="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span class="text-xs text-slate-500">
                {{ state.selectedFacilityId() === fac.id ? 'Active Focus Facility' : 'Standby Facility' }}
              </span>
              <button
                (click)="state.selectFacility(fac.id)"
                class="px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                [class.bg-[#0071DC]]="state.selectedFacilityId() !== fac.id"
                [class.text-white]="state.selectedFacilityId() !== fac.id"
                [class.hover:bg-blue-700]="state.selectedFacilityId() !== fac.id"
                [class.bg-slate-100]="state.selectedFacilityId() === fac.id"
                [class.text-slate-600]="state.selectedFacilityId() === fac.id"
              >
                {{ state.selectedFacilityId() === fac.id ? 'Selected' : 'Switch Context' }}
              </button>
            </div>
          </div>
        }
      </div>

      <!-- Planogram & Floor Plan Coordinates View -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <h3 class="font-bold text-slate-900 text-sm mb-1">Supercenter Floor Plan & Planogram Coordinates</h3>
        <p class="text-xs text-slate-500 mb-4">
          Hierarchical location mapping for picking wave optimization and restocking routes.
        </p>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div class="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span class="font-bold text-slate-900 block font-sans">Zone 1: Fresh Produce</span>
            <div class="mt-1 text-slate-600 text-[11px] space-y-0.5">
              <div>Aisle 01–04: Berries, Apples, Citrus</div>
              <div>Tier 1–3 Clamshell Racks</div>
              <div>Bins: BIN-PROD-201 to 404</div>
            </div>
          </div>
          <div class="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span class="font-bold text-slate-900 block font-sans">Zone 2: Dairy & Chilled</span>
            <div class="mt-1 text-slate-600 text-[11px] space-y-0.5">
              <div>Cooler Doors 01–08: Milk, Eggs, Butter</div>
              <div>Gravity-fed roller shelves</div>
              <div>Bins: BIN-DRY-101 to 148</div>
            </div>
          </div>
          <div class="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span class="font-bold text-slate-900 block font-sans">Zone 3: Meat & Seafood</span>
            <div class="mt-1 text-slate-600 text-[11px] space-y-0.5">
              <div>Meat Cases 01–04: Angus Beef, Poultry</div>
              <div>Dual-temp digital monitors</div>
              <div>Bins: BIN-MT-201 to 240</div>
            </div>
          </div>
          <div class="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span class="font-bold text-slate-900 block font-sans">Zone 4: Backroom Staging</span>
            <div class="mt-1 text-slate-600 text-[11px] space-y-0.5">
              <div>Dock Doors 01–06 (Crossdock)</div>
              <div>Staging: Ambient-A1, Chilled-C2, Frozen-F1</div>
              <div>Pallet Racks: PAL-01 to 80</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class StoresViewComponent {
  readonly state = inject(RetailStateService);
}
