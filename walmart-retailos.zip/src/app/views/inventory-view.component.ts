import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';
import { InventoryBalance, Product } from '../core/models/retail.types';

export interface InventoryRow extends InventoryBalance {
  product?: Product;
}

@Component({
  selector: 'app-inventory-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Action & Filter Bar -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <!-- Search and Category Filter -->
        <div class="flex items-center gap-3 flex-1 min-w-[280px]">
          <div class="relative flex-1 max-w-md">
            <mat-icon class="absolute left-3 top-2.5 text-slate-400 text-lg">search</mat-icon>
            <input
              type="text"
              placeholder="Search product SKU, name, or barcode..."
              [value]="searchQuery()"
              (input)="searchQuery.set($any($event.target).value)"
              class="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-[#0071DC] transition-colors"
            />
          </div>

          <!-- Category filter -->
          <select
            (change)="selectedCategory.set($any($event.target).value)"
            class="bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg px-3 py-2 cursor-pointer focus:outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="Fresh Produce">Fresh Produce</option>
            <option value="Dairy & Eggs">Dairy & Eggs</option>
            <option value="Meat & Seafood">Meat & Seafood</option>
            <option value="Bakery">Bakery</option>
            <option value="Household">Household</option>
          </select>
        </div>

        <!-- Inventory Workbench Actions -->
        <div class="flex items-center gap-2">
          <button
            (click)="activeSubTab.set('LEDGER')"
            class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer"
            [class.bg-[#0071DC]]="activeSubTab() === 'LEDGER'"
            [class.text-white]="activeSubTab() === 'LEDGER'"
            [class.border-[#0071DC]]="activeSubTab() === 'LEDGER'"
            [class.bg-white]="activeSubTab() !== 'LEDGER'"
            [class.text-slate-700]="activeSubTab() !== 'LEDGER'"
            [class.border-slate-300]="activeSubTab() !== 'LEDGER'"
          >
            <mat-icon class="text-sm mr-1 align-middle">receipt_long</mat-icon>
            Stock Movement Ledger
          </button>

          <button
            (click)="activeSubTab.set('BALANCES')"
            class="px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer"
            [class.bg-[#0071DC]]="activeSubTab() === 'BALANCES'"
            [class.text-white]="activeSubTab() === 'BALANCES'"
            [class.border-[#0071DC]]="activeSubTab() === 'BALANCES'"
            [class.bg-white]="activeSubTab() !== 'BALANCES'"
            [class.text-slate-700]="activeSubTab() !== 'BALANCES'"
            [class.border-slate-300]="activeSubTab() !== 'BALANCES'"
          >
            <mat-icon class="text-sm mr-1 align-middle">inventory_2</mat-icon>
            Inventory Balances
          </button>
        </div>
      </div>

      <!-- VIEW 1: INVENTORY BALANCES TABLE -->
      @if (activeSubTab() === 'BALANCES') {
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 class="text-base font-bold text-slate-900">Multi-Location Inventory Balances</h2>
              <p class="text-xs text-slate-500">
                Discrete accounting: On Hand = Reserved + Available to Promise (ATP). Strict immutable movements.
              </p>
            </div>
            <span class="text-xs font-mono text-slate-500">Showing {{ filteredItems().length }} of {{ state.products().length }} SKUs</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-50 text-slate-600 font-mono uppercase border-b border-slate-200">
                <tr>
                  <th class="py-3 px-4 font-semibold">SKU / Barcode</th>
                  <th class="py-3 px-4 font-semibold">Product Name</th>
                  <th class="py-3 px-4 font-semibold">Category / Temp</th>
                  <th class="py-3 px-4 font-semibold text-right">Cost</th>
                  <th class="py-3 px-4 font-semibold text-right">Sell Price</th>
                  <th class="py-3 px-4 font-semibold text-right text-slate-900">On Hand</th>
                  <th class="py-3 px-4 font-semibold text-right text-amber-700">Reserved</th>
                  <th class="py-3 px-4 font-semibold text-right text-emerald-700 font-bold">ATP</th>
                  <th class="py-3 px-4 font-semibold text-right text-blue-700">In Transit</th>
                  <th class="py-3 px-4 font-semibold text-right text-rose-700">Damaged</th>
                  <th class="py-3 px-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-mono">
                @for (item of filteredItems(); track item.productId) {
                  <tr class="hover:bg-slate-50/80 transition-colors">
                    <td class="py-3 px-4 font-bold text-slate-900">
                      <div>{{ item.product?.sku }}</div>
                      <div class="text-[10px] text-slate-400 font-normal">{{ item.product?.barcode }}</div>
                    </td>
                    <td class="py-3 px-4 font-sans font-medium text-slate-900">
                      {{ item.product?.name }}
                      @if (item.product?.isWeighted) {
                        <span class="ml-1 text-[10px] text-slate-500 font-mono">(Weighted: /lb)</span>
                      }
                    </td>
                    <td class="py-3 px-4 font-sans text-slate-600">
                      <div>{{ item.product?.category }}</div>
                      <div class="text-[10px] text-slate-400 font-mono">{{ item.product?.temperatureClass }}</div>
                    </td>
                    <td class="py-3 px-4 text-right text-slate-700"><span>$</span>{{ item.product?.costPrice?.toFixed(2) }}</td>
                    <td class="py-3 px-4 text-right text-slate-900 font-bold"><span>$</span>{{ item.product?.currentPrice?.toFixed(2) }}</td>
                    <td class="py-3 px-4 text-right font-bold text-slate-900">{{ item.onHand }}</td>
                    <td class="py-3 px-4 text-right text-amber-700 font-semibold">{{ item.reserved }}</td>
                    <td class="py-3 px-4 text-right text-emerald-700 font-bold text-sm bg-emerald-50/40">
                      {{ item.atp }}
                    </td>
                    <td class="py-3 px-4 text-right text-blue-700">{{ item.inTransit }}</td>
                    <td class="py-3 px-4 text-right text-rose-700">{{ item.damaged }}</td>
                    <td class="py-3 px-4 font-sans">
                      <div class="flex items-center gap-1.5">
                        <button
                          (click)="openLotsModal(item)"
                          class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px] cursor-pointer"
                          title="View lot numbers and expiry dates"
                        >
                          Lots ({{ item.lots.length }})
                        </button>
                        <button
                          (click)="openAdjustModal(item)"
                          class="px-2 py-1 bg-[#0071DC]/10 hover:bg-[#0071DC]/20 text-[#0071DC] rounded font-semibold text-[11px] cursor-pointer"
                          title="Record cycle count or write-off"
                        >
                          Adjust
                        </button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- VIEW 2: STOCK MOVEMENT LEDGER (AUDIT TRAIL) -->
      @if (activeSubTab() === 'LEDGER') {
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 class="text-base font-bold text-slate-900">Immutable Stock Movement Ledger</h2>
              <p class="text-xs text-slate-500">
                Traceable ledger recording every receipt, picking reservation, cycle count, waste write-off, and return.
              </p>
            </div>
            <span class="text-xs font-mono text-slate-500">{{ state.stockMovements().length }} total transactions</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-50 text-slate-600 font-mono uppercase border-b border-slate-200">
                <tr>
                  <th class="py-3 px-4 font-semibold">Timestamp</th>
                  <th class="py-3 px-4 font-semibold">Movement Type</th>
                  <th class="py-3 px-4 font-semibold">Product SKU / Name</th>
                  <th class="py-3 px-4 font-semibold text-right">Delta</th>
                  <th class="py-3 px-4 font-semibold text-right">Balance After</th>
                  <th class="py-3 px-4 font-semibold">Reason / Reference</th>
                  <th class="py-3 px-4 font-semibold">Operator</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-mono">
                @for (move of state.stockMovements(); track move.id) {
                  <tr class="hover:bg-slate-50 transition-colors">
                    <td class="py-3 px-4 text-slate-500 text-[11px]">
                      {{ move.timestamp | date:'short' }}
                    </td>
                    <td class="py-3 px-4">
                      <span
                        class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-emerald-100]="move.type === 'RECEIPT' || move.type === 'RETURN_RESTOCK'"
                        [class.text-emerald-800]="move.type === 'RECEIPT' || move.type === 'RETURN_RESTOCK'"
                        [class.bg-rose-100]="move.type === 'WASTE_EXPIRY' || move.type === 'DAMAGE_WRITEOFF'"
                        [class.text-rose-800]="move.type === 'WASTE_EXPIRY' || move.type === 'DAMAGE_WRITEOFF'"
                        [class.bg-blue-100]="move.type === 'CYCLE_COUNT'"
                        [class.text-blue-800]="move.type === 'CYCLE_COUNT'"
                        [class.bg-purple-100]="move.type === 'DISPATCH' || move.type === 'PICK_RESERVE'"
                        [class.text-purple-800]="move.type === 'DISPATCH' || move.type === 'PICK_RESERVE'"
                      >
                        {{ move.type }}
                      </span>
                    </td>
                    <td class="py-3 px-4 font-sans font-medium text-slate-900">
                      <div>{{ move.productName }}</div>
                      <div class="text-[10px] font-mono text-slate-400">{{ move.productSku }}</div>
                    </td>
                    <td
                      class="py-3 px-4 text-right font-bold text-sm"
                      [class.text-emerald-700]="move.delta > 0"
                      [class.text-rose-700]="move.delta < 0"
                    >
                      {{ move.delta > 0 ? '+' : '' }}{{ move.delta }}
                    </td>
                    <td class="py-3 px-4 text-right font-bold text-slate-900">{{ move.balanceAfter }}</td>
                    <td class="py-3 px-4 font-sans text-slate-700">
                      <div>{{ move.reason }}</div>
                      <div class="text-[10px] font-mono text-slate-400">Ref: {{ move.referenceId }}</div>
                    </td>
                    <td class="py-3 px-4 font-sans text-slate-600 text-[11px]">{{ move.performedBy }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- LOTS & EXPIRY MODAL -->
      @if (selectedLotItem(); as item) {
        <div class="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div class="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 class="font-bold text-slate-900 text-sm">Product Lots & Expiry Tracking</h3>
                <span class="text-slate-500 font-mono">{{ item.product?.sku }} · {{ item.product?.name }}</span>
              </div>
              <button
                (click)="selectedLotItem.set(null)"
                class="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div class="mt-4 space-y-3">
              @for (lot of item.lots; track lot.lotNumber) {
                <div class="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5 font-mono">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-slate-900">{{ lot.lotNumber }}</span>
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-amber-100]="lot.status === 'SHORT_DATED'"
                      [class.text-amber-800]="lot.status === 'SHORT_DATED'"
                      [class.bg-emerald-100]="lot.status === 'FRESH'"
                      [class.text-emerald-800]="lot.status === 'FRESH'"
                    >
                      {{ lot.status }}
                    </span>
                  </div>

                  <div class="grid grid-cols-2 gap-2 text-slate-600 text-[11px]">
                    <div>Expiry: <span class="font-bold text-slate-900">{{ lot.expiryDate }} ({{ lot.daysToExpiry }}d)</span></div>
                    <div>Quantity: <span class="font-bold text-slate-900">{{ lot.quantity }} units</span></div>
                    <div>Location: <span class="text-slate-900">{{ lot.aisle }} · {{ lot.shelf }} · {{ lot.bin }}</span></div>
                    <div>Received: <span class="text-slate-900">{{ lot.receivedDate }}</span></div>
                  </div>
                </div>
              }
            </div>

            <div class="mt-5 pt-3 border-t border-slate-200 flex justify-end">
              <button
                (click)="selectedLotItem.set(null)"
                class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      }

      <!-- STOCK ADJUSTMENT MODAL -->
      @if (adjustingItem(); as item) {
        <div class="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div class="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 class="font-bold text-slate-900 text-sm">Stock Ledger Adjustment</h3>
                <span class="text-slate-500 font-mono">{{ item.product?.sku }} · {{ item.product?.name }}</span>
              </div>
              <button
                (click)="adjustingItem.set(null)"
                class="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div class="mt-4 space-y-3 font-sans">
              <div>
                <label for="adj-type-select" class="block font-semibold text-slate-700 mb-1">Adjustment Type:</label>
                <select
                  id="adj-type-select"
                  (change)="adjustType.set($any($event.target).value)"
                  class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                >
                  <option value="CYCLE_COUNT">Cycle Count Physical Verification</option>
                  <option value="WASTE_EXPIRY">Waste / Spoilage (Past Sell-By)</option>
                  <option value="DAMAGE_WRITEOFF">Damage Write-off (In-transit bruise)</option>
                </select>
              </div>

              <div>
                <label for="adj-qty-input" class="block font-semibold text-slate-700 mb-1">
                  {{ adjustType() === 'CYCLE_COUNT' ? 'New Physical Count:' : 'Quantity to Write-Off:' }}
                </label>
                <input
                  id="adj-qty-input"
                  type="number"
                  [value]="adjustQty()"
                  (input)="adjustQty.set(+$any($event.target).value)"
                  class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label for="adj-reason-input" class="block font-semibold text-slate-700 mb-1">Recorded Reason (Audit Mandate):</label>
                <input
                  id="adj-reason-input"
                  type="text"
                  [value]="adjustReason()"
                  (input)="adjustReason.set($any($event.target).value)"
                  placeholder="e.g. End of aisle display damaged by cart collision"
                  class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
            </div>

            <div class="mt-6 pt-3 border-t border-slate-200 flex justify-end gap-2">
              <button
                (click)="adjustingItem.set(null)"
                class="px-3 py-1.5 border border-slate-300 text-slate-700 rounded-lg font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                (click)="commitAdjustment(item)"
                class="px-4 py-1.5 bg-[#0071DC] hover:bg-blue-700 text-white rounded-lg font-semibold cursor-pointer"
              >
                Post to Ledger
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class InventoryViewComponent {
  readonly state = inject(RetailStateService);

  readonly searchQuery = signal<string>('');
  readonly selectedCategory = signal<string>('ALL');
  readonly activeSubTab = signal<'BALANCES' | 'LEDGER'>('BALANCES');

  readonly selectedLotItem = signal<InventoryRow | null>(null);
  readonly adjustingItem = signal<InventoryRow | null>(null);
  readonly adjustType = signal<'CYCLE_COUNT' | 'WASTE_EXPIRY' | 'DAMAGE_WRITEOFF'>('CYCLE_COUNT');
  readonly adjustQty = signal<number>(10);
  readonly adjustReason = signal<string>('Routine shelf count reconciliation');

  readonly filteredItems = computed(() => {
    const list = this.state.currentFacilityBalances() as InventoryRow[];
    const query = this.searchQuery().toLowerCase().trim();
    const cat = this.selectedCategory();

    return list.filter(item => {
      const prod = item.product;
      if (!prod) return false;

      const matchesCat = cat === 'ALL' || prod.category === cat;
      const matchesQuery =
        !query ||
        prod.name.toLowerCase().includes(query) ||
        prod.sku.toLowerCase().includes(query) ||
        prod.barcode.toLowerCase().includes(query);

      return matchesCat && matchesQuery;
    });
  });

  openLotsModal(item: InventoryRow): void {
    this.selectedLotItem.set(item);
  }

  openAdjustModal(item: InventoryRow): void {
    this.adjustingItem.set(item);
    this.adjustQty.set(item.onHand);
  }

  commitAdjustment(item: InventoryRow): void {
    const type = this.adjustType();
    const qty = this.adjustQty();
    const reason = this.adjustReason();

    if (type === 'CYCLE_COUNT') {
      this.state.reconcileCycleCount(item.productId, qty, reason);
    } else {
      this.state.recordWasteOrDamage(item.productId, qty, reason, type);
    }
    this.adjustingItem.set(null);
  }
}
