import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-overview-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Store Hero & Status Banner -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-0">
          <!-- Facility Details -->
          <div class="lg:col-span-8 p-6 flex flex-col justify-between">
            <div>
              <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
                <span class="font-bold text-[#0071DC]">{{ state.currentFacility().code }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ state.currentFacility().city }}, {{ state.currentFacility().state }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ state.currentFacility().type }}</span>
                <span aria-hidden="true">·</span>
                <span class="text-emerald-700 font-medium">Real-Time Sync Active</span>
              </div>

              <h1 class="text-2xl font-bold tracking-tight text-slate-900">
                {{ state.currentFacility().name }}
              </h1>
              <p class="text-sm text-slate-600 mt-1 max-w-2xl">
                Real-time operational command center managing multi-department inventory balances, automated reorder triggers, dispatch waves, cold chain compliance, and associate tasks.
              </p>
            </div>

            <!-- Quick Operational Indicators -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
              <div>
                <span class="text-xs text-slate-500 block">Active Associates</span>
                <span class="text-lg font-bold font-mono text-slate-900">{{ state.currentFacility().activeAssociates }} on shift</span>
              </div>
              <div>
                <span class="text-xs text-slate-500 block">Sales Floor Area</span>
                <span class="text-lg font-bold font-mono text-slate-900">{{ state.currentFacility().shelfCapacitySqFt.toLocaleString() }} sq ft</span>
              </div>
              <div>
                <span class="text-xs text-slate-500 block">Cold Chain Temp</span>
                <span class="text-lg font-bold font-mono text-emerald-700">{{ state.currentFacility().avgTempFahrenheit }}°F (Nominal)</span>
              </div>
              <div>
                <span class="text-xs text-slate-500 block">Capacity Utilization</span>
                <span class="text-lg font-bold font-mono text-slate-900">{{ state.currentFacility().capacityUtilizationPct }}%</span>
              </div>
            </div>
          </div>

          <!-- Facility Exterior Photo Preview -->
          <div class="lg:col-span-4 bg-slate-900 relative min-h-[180px] lg:min-h-full overflow-hidden flex items-center justify-center">
            <img
              src="/src/assets/images/walmart_supercenter_exterior_1794229612581.jpg"
              alt="Walmart Supercenter Exterior"
              class="w-full h-full object-cover opacity-90 hover:scale-105 transition-transform duration-500"
              referrerpolicy="no-referrer"
            />
            <div class="absolute bottom-2 right-2 bg-slate-900/80 backdrop-blur-xs text-white px-2 py-1 rounded text-[11px] font-mono border border-slate-700">
              Facility Cam · Live
            </div>
          </div>
        </div>
      </div>

      <!-- Core Operational KPI Metrics Strip -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- KPI 1 -->
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-medium uppercase tracking-wider">On-Shelf Availability</span>
            <mat-icon class="text-emerald-600 text-lg">check_circle_outline</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">98.4%</div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mt-2">
            <span class="text-emerald-600 font-semibold">+0.6% vs benchmark</span>
            <span aria-hidden="true">·</span>
            <span>Target: 97.5%</span>
          </div>
        </div>

        <!-- KPI 2 -->
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-medium uppercase tracking-wider">Available-To-Promise (ATP)</span>
            <mat-icon class="text-[#0071DC] text-lg">inventory_2</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">412 units</div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mt-2">
            <span>On Hand: 473</span>
            <span aria-hidden="true">·</span>
            <span>Reserved: 61</span>
          </div>
        </div>

        <!-- KPI 3 -->
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-medium uppercase tracking-wider">Short-Dated Risk</span>
            <mat-icon class="text-amber-600 text-lg">warning_amber</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-amber-700 tabular-nums">
            {{ state.shortDatedLotsCount() }} Lots (56 units)
          </div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mt-2">
            <span>Expiry &lt; 48 hours</span>
            <span aria-hidden="true">·</span>
            <span class="text-amber-700 font-medium">Markdowns Active</span>
          </div>
        </div>

        <!-- KPI 4 -->
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-medium uppercase tracking-wider">Fulfillment OTIF</span>
            <mat-icon class="text-[#0071DC] text-lg">local_shipping</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900 tabular-nums">98.2%</div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mt-2">
            <span>{{ state.pendingOrdersCount() }} pending waves</span>
            <span aria-hidden="true">·</span>
            <span>3 delivery vans</span>
          </div>
        </div>
      </div>

      <!-- Two-Column Operational Workbench -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left Column: Critical Action Queue & Replenishment Triggers (7 cols) -->
        <div class="lg:col-span-7 space-y-6">
          <!-- Critical Replenishment Alert -->
          <div class="bg-amber-50 rounded-xl border border-amber-200 p-5">
            <div class="flex items-start justify-between">
              <div class="flex items-center gap-2 text-amber-900 font-bold text-sm">
                <mat-icon class="text-amber-600">notification_important</mat-icon>
                <span>Automated Reorder Trigger: Organic Honeycrisp Apples</span>
              </div>
              <span class="bg-amber-200 text-amber-900 text-[11px] font-mono px-2 py-0.5 rounded font-bold">
                ROP BREACHED
              </span>
            </div>

            <p class="text-xs text-amber-800 mt-2 leading-relaxed">
              Store #1042 available stock has dropped to <span class="font-bold font-mono">16 lbs</span> (below Reorder Point of 60 lbs). Under unconstrained demand forecasting (22.0 lbs/day baseline + 15% weekend lift), stockout risk is imminent within 18 hours.
            </p>

            <div class="mt-4 flex items-center justify-between pt-3 border-t border-amber-200/80">
              <div class="text-xs text-amber-900">
                Vendor: <span class="font-semibold">Valley Verde Fresh Produce</span> · Lead time: 3 days · MOQ: 50 lbs
              </div>
              <button
                (click)="state.generateReplenishmentPO('prod-003', 75)"
                class="px-3 py-1.5 bg-[#0071DC] hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-sm"
              >
                Approve PO-4409 (75 lbs)
              </button>
            </div>
          </div>

          <!-- Active Order Waves Table -->
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="p-4 border-b border-slate-200 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#0071DC]">shopping_cart_checkout</mat-icon>
                <h3 class="font-bold text-slate-900 text-sm">Active Fulfillment Waves</h3>
              </div>
              <button
                (click)="navTab.emit('orders')"
                class="text-xs text-[#0071DC] hover:underline font-medium cursor-pointer"
              >
                View all orders →
              </button>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-xs">
                <thead class="bg-slate-50 text-slate-500 font-mono uppercase border-b border-slate-200">
                  <tr>
                    <th class="py-2.5 px-4 font-semibold">Order #</th>
                    <th class="py-2.5 px-4 font-semibold">Customer / Channel</th>
                    <th class="py-2.5 px-4 font-semibold">Delivery Window</th>
                    <th class="py-2.5 px-4 font-semibold">Items</th>
                    <th class="py-2.5 px-4 font-semibold text-right">Total</th>
                    <th class="py-2.5 px-4 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  @for (order of state.orders(); track order.id) {
                    <tr class="hover:bg-slate-50 transition-colors">
                      <td class="py-3 px-4 font-mono font-bold text-slate-900">{{ order.orderNumber }}</td>
                      <td class="py-3 px-4">
                        <div class="font-medium text-slate-800">{{ order.customerName }}</div>
                        <div class="text-[11px] text-slate-400 font-mono">{{ order.channel }}</div>
                      </td>
                      <td class="py-3 px-4 text-slate-600 font-mono">{{ order.deliveryWindow }}</td>
                      <td class="py-3 px-4 text-slate-600 font-mono">{{ order.items.length }} items</td>
                      <td class="py-3 px-4 text-right font-mono font-bold text-slate-900"><span>$</span>{{ order.total.toFixed(2) }}</td>
                      <td class="py-3 px-4">
                        <span
                          class="px-2 py-0.5 rounded text-[11px] font-mono font-semibold"
                          [class.bg-blue-100]="order.orderStatus === 'RESERVED'"
                          [class.text-blue-800]="order.orderStatus === 'RESERVED'"
                          [class.bg-amber-100]="order.orderStatus === 'PICKING' || order.orderStatus === 'STAGED'"
                          [class.text-amber-800]="order.orderStatus === 'PICKING' || order.orderStatus === 'STAGED'"
                          [class.bg-purple-100]="order.orderStatus === 'DISPATCHED'"
                          [class.text-purple-800]="order.orderStatus === 'DISPATCHED'"
                          [class.bg-emerald-100]="order.orderStatus === 'DELIVERED'"
                          [class.text-emerald-800]="order.orderStatus === 'DELIVERED'"
                        >
                          {{ order.orderStatus }}
                        </span>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Right Column: Cold Chain Fleet & Immutable Stock Audit (5 cols) -->
        <div class="lg:col-span-5 space-y-6">
          <!-- Delivery Fleet Status -->
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#0071DC]">airport_shuttle</mat-icon>
                <h3 class="font-bold text-slate-900 text-sm">Fleet & Dispatch Status</h3>
              </div>
              <button
                (click)="navTab.emit('delivery')"
                class="text-xs text-[#0071DC] hover:underline font-medium cursor-pointer"
              >
                Dispatch map →
              </button>
            </div>

            <div class="space-y-3">
              @for (v of state.vehicles(); track v.id) {
                <div class="p-3 rounded-lg border border-slate-100 bg-slate-50 text-xs">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-2">
                      <span class="font-bold font-mono text-slate-900">{{ v.code }}</span>
                      <span class="text-slate-400">·</span>
                      <span class="text-slate-600 font-medium">{{ v.type }}</span>
                    </div>
                    <span
                      class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold"
                      [class.bg-emerald-100]="v.status === 'EN_ROUTE'"
                      [class.text-emerald-800]="v.status === 'EN_ROUTE'"
                      [class.bg-blue-100]="v.status === 'LOADING'"
                      [class.text-blue-800]="v.status === 'LOADING'"
                      [class.bg-slate-200]="v.status === 'IDLE'"
                      [class.text-slate-700]="v.status === 'IDLE'"
                    >
                      {{ v.status }}
                    </span>
                  </div>

                  <div class="mt-2 grid grid-cols-3 gap-2 text-[11px] text-slate-600 font-mono">
                    <div>Battery: <span class="font-bold text-slate-900">{{ v.currentBatteryOrFuelPct }}%</span></div>
                    <div>
                      @if (v.temperatureCelsius !== undefined) {
                        Temp: <span class="font-bold text-emerald-700">{{ v.temperatureCelsius }}°C</span>
                      } @else if (v.altitudeFt !== undefined) {
                        Alt: <span class="font-bold text-indigo-700">{{ v.altitudeFt }} ft</span>
                      }
                    </div>
                    <div>Orders: <span class="font-bold text-slate-900">{{ v.assignedOrderIds.length }}</span></div>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Traceable Stock Movement Stream -->
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-slate-700">history</mat-icon>
                <h3 class="font-bold text-slate-900 text-sm">Stock Movement Ledger</h3>
              </div>
              <button
                (click)="navTab.emit('inventory')"
                class="text-xs text-[#0071DC] hover:underline font-medium cursor-pointer"
              >
                View full ledger →
              </button>
            </div>

            <div class="divide-y divide-slate-100 text-xs">
              @for (m of state.stockMovements().slice(0, 4); track m.id) {
                <div class="py-2.5">
                  <div class="flex items-center justify-between">
                    <span class="font-semibold text-slate-800 truncate max-w-[200px]">{{ m.productName }}</span>
                    <span
                      class="font-mono font-bold"
                      [class.text-emerald-600]="m.delta > 0"
                      [class.text-rose-600]="m.delta < 0"
                    >
                      {{ m.delta > 0 ? '+' : '' }}{{ m.delta }}
                    </span>
                  </div>
                  <div class="flex items-center justify-between text-[11px] text-slate-400 mt-0.5 font-mono">
                    <span>{{ m.type }} · {{ m.referenceId }}</span>
                    <span>Bal: {{ m.balanceAfter }}</span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OverviewViewComponent {
  readonly state = inject(RetailStateService);
  readonly navTab = output<string>();
}
