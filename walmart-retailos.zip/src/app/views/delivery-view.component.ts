import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';

@Component({
  selector: 'app-delivery-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Fulfillment & Fleet Dispatch</span>
            <span aria-hidden="true">·</span>
            <span>Cold-Chain & Route Optimization</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Operational Dispatch & Vehicle Routing</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Monitors multi-temperature staging (Ambient, Chilled, Frozen), vehicle route capacity, live delivery windows, infeasible stop detection, and autonomous drone delivery adapter.
          </p>
        </div>

        <!-- Drone Delivery Simulation Trigger -->
        <button
          (click)="launchDroneSimulation()"
          class="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-sm"
        >
          <mat-icon class="text-sm">flight_takeoff</mat-icon>
          <span>Simulate Drone Flight (DR-88)</span>
        </button>
      </div>

      <!-- Staging Zones Breakdown -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- Ambient -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Ambient Staging Zone A1</span>
            <mat-icon class="text-slate-400">shelves</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900">1 Order Staged</div>
          <div class="text-xs text-slate-500 mt-1">Order #WMT-ORD-9820 (Bounty Paper Towels)</div>
          <div class="mt-3 text-[11px] font-mono text-slate-400 bg-slate-50 p-2 rounded border border-slate-100">
            Temp: 68.4°F · Target: 65-72°F
          </div>
        </div>

        <!-- Chilled -->
        <div class="bg-white p-4 rounded-xl border border-blue-200 shadow-sm bg-blue-50/20">
          <div class="flex items-center justify-between text-xs text-blue-800 mb-2">
            <span class="font-bold uppercase tracking-wider">Chilled Staging Zone C2</span>
            <mat-icon class="text-[#0071DC]">ac_unit</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-blue-950">1 Order Staged</div>
          <div class="text-xs text-slate-600 mt-1">Order #WMT-ORD-9821 (Strawberries, Milk, Bread)</div>
          <div class="mt-3 text-[11px] font-mono text-emerald-700 bg-emerald-50 p-2 rounded border border-emerald-200">
            Temp: 34.2°F · Cold-Chain Sensor Nominal
          </div>
        </div>

        <!-- Frozen -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span class="font-bold uppercase tracking-wider text-slate-700">Frozen Staging Zone F1</span>
            <mat-icon class="text-cyan-600">severe_cold</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-900">0 Active Orders</div>
          <div class="text-xs text-slate-500 mt-1">Capacity: 48 totes ready</div>
          <div class="mt-3 text-[11px] font-mono text-cyan-800 bg-cyan-50 p-2 rounded border border-cyan-100">
            Temp: -4.0°F · Deep Freeze Validated
          </div>
        </div>
      </div>

      <!-- Route Stops & Infeasible Detection -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 class="font-bold text-slate-900 text-sm">Active Delivery Route: Van-102 (Driver: Carlos Rivera)</h3>
            <p class="text-xs text-slate-500">
              Evaluates delivery time windows, payload weight, and vehicle capacity. Infeasible stops are flagged rather than inventing invalid routes.
            </p>
          </div>
          <span class="text-xs font-mono bg-blue-50 text-[#0071DC] px-2.5 py-1 rounded border border-blue-200 font-bold">
            Payload: 480 / 2,200 lbs (21.8% capacity)
          </span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
              <tr>
                <th class="py-3 px-4 font-semibold">Stop</th>
                <th class="py-3 px-4 font-semibold font-sans">Customer / Destination</th>
                <th class="py-3 px-4 font-semibold">Delivery Window</th>
                <th class="py-3 px-4 font-semibold">Planned Arrival</th>
                <th class="py-3 px-4 font-semibold text-[#0071DC] font-bold">Live Estimate</th>
                <th class="py-3 px-4 font-semibold text-right">Weight</th>
                <th class="py-3 px-4 font-semibold">Cold Chain</th>
                <th class="py-3 px-4 font-semibold font-sans">Feasibility / Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (stop of state.routeStops(); track stop.stopNumber) {
                <tr
                  class="transition-colors"
                  [class.bg-rose-50/50]="stop.isInfeasible"
                  [class.hover:bg-slate-50]="!stop.isInfeasible"
                >
                  <td class="py-3.5 px-4 font-bold text-slate-900">#{{ stop.stopNumber }}</td>
                  <td class="py-3.5 px-4 font-sans font-medium text-slate-900">
                    <div>{{ stop.customerName }}</div>
                    <div class="text-[10px] font-mono text-slate-400">{{ stop.address }}</div>
                  </td>
                  <td class="py-3.5 px-4 font-semibold text-slate-800">{{ stop.deliveryWindow }}</td>
                  <td class="py-3.5 px-4 text-slate-600">{{ stop.plannedArrival }}</td>
                  <td
                    class="py-3.5 px-4 font-bold"
                    [class.text-emerald-700]="!stop.isInfeasible"
                    [class.text-rose-700]="stop.isInfeasible"
                  >
                    {{ stop.liveEstimate }}
                  </td>
                  <td class="py-3.5 px-4 text-right text-slate-700">{{ stop.weightLbs }} lbs</td>
                  <td class="py-3.5 px-4">
                    @if (stop.coldChainRequired) {
                      <span class="text-blue-700 font-bold flex items-center gap-1">
                        <mat-icon class="text-xs">ac_unit</mat-icon> REQUIRED
                      </span>
                    } @else {
                      <span class="text-slate-400">Ambient</span>
                    }
                  </td>
                  <td class="py-3.5 px-4 font-sans">
                    @if (stop.isInfeasible) {
                      <div class="text-rose-700 text-[11px] leading-tight">
                        <span class="font-bold block flex items-center gap-1">
                          <mat-icon class="text-xs">error_outline</mat-icon> INFEASIBLE STOP
                        </span>
                        <span>{{ stop.infeasibleReason }}</span>
                      </div>
                    } @else {
                      <span class="text-emerald-700 font-semibold flex items-center gap-1 text-[11px]">
                        <mat-icon class="text-xs">check_circle</mat-icon> Validated Stop
                      </span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Autonomous Drone Delivery Adapter Simulation Panel -->
      <div class="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-xl p-5 border border-indigo-800 shadow-sm">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                ADAPTER SIMULATION · FAA PART 135
              </span>
              <span class="text-xs text-slate-400">Telemetry Feed</span>
            </div>
            <h3 class="text-base font-bold text-white mt-1">Autonomous Drone Delivery Fleet Adapter (Wing/Zipline Spec)</h3>
            <p class="text-xs text-indigo-200 mt-0.5 max-w-xl">
              Flight control operates within an authorized external system. RetailOS simulates dispatch status, package winch drop sequence, and airspace telemetry without claiming direct flight command.
            </p>
          </div>

          <!-- Live Telemetry Box -->
          <div class="flex items-center gap-4 bg-slate-900/90 p-3 rounded-xl border border-indigo-700 text-xs font-mono">
            <div>
              <span class="text-slate-400 block text-[10px]">UAV ID</span>
              <span class="font-bold text-white">DR-88 (Wing)</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">BATTERY</span>
              <span class="font-bold text-emerald-400">96% LiPo</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">ALTITUDE</span>
              <span class="font-bold text-indigo-300">180 FT AGL</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">PAYLOAD</span>
              <span class="font-bold text-yellow-300">2.8 / 5.5 LBS</span>
            </div>
          </div>
        </div>

        @if (droneSimMessage()) {
          <div class="mt-4 p-3 bg-indigo-900/60 rounded-lg border border-indigo-700 text-xs font-mono text-indigo-100 flex items-center justify-between">
            <span>{{ droneSimMessage() }}</span>
            <span class="text-emerald-400 font-bold">ACK 200</span>
          </div>
        }
      </div>
    </div>
  `
})
export class DeliveryViewComponent {
  readonly state = inject(RetailStateService);
  readonly droneSimMessage = signal<string | null>(null);

  launchDroneSimulation(): void {
    this.droneSimMessage.set(
      'Simulating drone flight: Drone DR-88 unmoored from Hub #1042 · Waypoint: 712 NW A St · Winch Tether Drop simulated · Status: COMPLETED · Telemetry logged.'
    );
    this.state.addAuditLog(
      'INTEGRATION',
      'DRONE_DISPATCH_SIMULATED',
      'DRONE-WING-88',
      'Simulated autonomous tether delivery drop for Order WMT-ORD-9821. FAA Part 135 mock adapter.'
    );
    this.state.notify('Drone delivery simulation executed. Telemetry recorded in audit trail.', 'info');
  }
}
