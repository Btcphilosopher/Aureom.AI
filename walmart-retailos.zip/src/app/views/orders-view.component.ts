import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService } from '../core/services/retail-state.service';
import { CustomerOrder, OrderItem } from '../core/models/retail.types';

@Component({
  selector: 'app-orders-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Orders Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Omnichannel Order Management</span>
            <span aria-hidden="true">·</span>
            <span>Transactional Stock Locking & State Machines</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Customer Orders & Fulfillment Waves</h2>
          <p class="text-xs text-slate-600 mt-0.5">
            Synchronizes Store POS transactions, Click-and-Collect bays, and Delivery waves with explicit Order & Payment state machines.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <!-- Channel Filters -->
          <div class="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
            <button
              (click)="channelFilter.set('ALL')"
              class="px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors"
              [class.bg-white]="channelFilter() === 'ALL'"
              [class.text-slate-900]="channelFilter() === 'ALL'"
              [class.shadow-xs]="channelFilter() === 'ALL'"
              [class.text-slate-600]="channelFilter() !== 'ALL'"
            >
              All Channels
            </button>
            <button
              (click)="channelFilter.set('ONLINE_DELIVERY')"
              class="px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors"
              [class.bg-white]="channelFilter() === 'ONLINE_DELIVERY'"
              [class.text-slate-900]="channelFilter() === 'ONLINE_DELIVERY'"
              [class.shadow-xs]="channelFilter() === 'ONLINE_DELIVERY'"
              [class.text-slate-600]="channelFilter() !== 'ONLINE_DELIVERY'"
            >
              Home Delivery
            </button>
            <button
              (click)="channelFilter.set('CLICK_COLLECT')"
              class="px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors"
              [class.bg-white]="channelFilter() === 'CLICK_COLLECT'"
              [class.text-slate-900]="channelFilter() === 'CLICK_COLLECT'"
              [class.shadow-xs]="channelFilter() === 'CLICK_COLLECT'"
              [class.text-slate-600]="channelFilter() !== 'CLICK_COLLECT'"
            >
              Curbside Pickup
            </button>
          </div>
        </div>
      </div>

      <!-- Orders Pipeline Cards -->
      <div class="space-y-4">
        @for (order of filteredOrders(); track order.id) {
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 text-xs">
            <!-- Order Header & Status Pill -->
            <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div class="flex items-center gap-3">
                <span class="font-mono font-bold text-base text-slate-900">{{ order.orderNumber }}</span>
                <span class="text-slate-400">·</span>
                <span class="font-semibold text-slate-700">{{ order.customerName }}</span>
                <span class="text-slate-400 font-mono text-[11px]">({{ order.channel }})</span>
                @if (order.loyaltyMemberId) {
                  <span class="bg-blue-50 text-[#0071DC] border border-blue-200 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                    Walmart+ Member #{{ order.loyaltyMemberId }}
                  </span>
                }
              </div>

              <!-- State Machine Indicators -->
              <div class="flex items-center gap-2">
                <span
                  class="px-2.5 py-1 rounded text-[11px] font-mono font-bold"
                  [class.bg-blue-100]="order.orderStatus === 'RESERVED'"
                  [class.text-blue-800]="order.orderStatus === 'RESERVED'"
                  [class.bg-amber-100]="order.orderStatus === 'PICKING' || order.orderStatus === 'STAGED'"
                  [class.text-amber-800]="order.orderStatus === 'PICKING' || order.orderStatus === 'STAGED'"
                  [class.bg-purple-100]="order.orderStatus === 'DISPATCHED'"
                  [class.text-purple-800]="order.orderStatus === 'DISPATCHED'"
                  [class.bg-emerald-100]="order.orderStatus === 'DELIVERED'"
                  [class.text-emerald-800]="order.orderStatus === 'DELIVERED'"
                  [class.bg-rose-100]="order.orderStatus === 'RETURNED' || order.orderStatus === 'CANCELLED'"
                  [class.text-rose-800]="order.orderStatus === 'RETURNED' || order.orderStatus === 'CANCELLED'"
                >
                  STATE: {{ order.orderStatus }}
                </span>

                <span
                  class="px-2 py-1 rounded text-[10px] font-mono font-bold"
                  [class.bg-emerald-50]="order.paymentStatus === 'CAPTURED'"
                  [class.text-emerald-700]="order.paymentStatus === 'CAPTURED'"
                  [class.border]="true"
                  [class.border-emerald-200]="order.paymentStatus === 'CAPTURED'"
                  [class.bg-blue-50]="order.paymentStatus === 'AUTHORIZED'"
                  [class.text-blue-700]="order.paymentStatus === 'AUTHORIZED'"
                  [class.border-blue-200]="order.paymentStatus === 'AUTHORIZED'"
                  [class.bg-amber-50]="order.paymentStatus === 'REFUNDED'"
                  [class.text-amber-700]="order.paymentStatus === 'REFUNDED'"
                  [class.border-amber-200]="order.paymentStatus === 'REFUNDED'"
                >
                  PAY: {{ order.paymentStatus }}
                </span>
              </div>
            </div>

            <!-- Delivery & Staging Info -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 py-3 text-slate-600 border-b border-slate-100">
              <div>
                <span class="text-slate-400 block text-[11px]">Delivery Window / Bay:</span>
                <span class="font-mono font-semibold text-slate-900">{{ order.deliveryWindow }}</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[11px]">Address:</span>
                <span class="text-slate-800">{{ order.deliveryAddress || 'Store Pickup Bay 04' }}</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[11px]">Staging Zone:</span>
                <span class="font-mono font-semibold text-[#0071DC]">{{ order.stagingZone || 'UNSTAGED' }}</span>
              </div>
            </div>

            <!-- Items Table -->
            <div class="mt-3">
              <span class="text-[11px] font-mono text-slate-500 uppercase block mb-1.5">Ordered Items & Verification:</span>
              <div class="space-y-1.5">
                @for (item of order.items; track item.productId) {
                  <div class="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                    <div class="flex items-center gap-2">
                      <mat-icon
                        class="text-base"
                        [class.text-emerald-600]="item.isPicked"
                        [class.text-slate-400]="!item.isPicked"
                      >
                        {{ item.isPicked ? 'check_circle' : 'radio_button_unchecked' }}
                      </mat-icon>
                      <div>
                        <span class="font-semibold text-slate-900">{{ item.name }}</span>
                        <span class="text-slate-500 font-mono ml-1 text-[11px]">({{ item.sku }})</span>
                        @if (item.substitutedWith) {
                          <div class="text-[10px] text-blue-700 font-mono mt-0.5">
                            ↳ Substituted with {{ item.substitutedWith.name }} (Consent verified · Delta: <span>$</span>{{ item.substitutedWith.priceDelta.toFixed(2) }})
                          </div>
                        }
                        @if (item.returnStatus) {
                          <div class="text-[10px] text-amber-700 font-mono mt-0.5">
                            ↳ Return Status: {{ item.returnStatus }}
                          </div>
                        }
                      </div>
                    </div>

                    <div class="flex items-center gap-4 font-mono">
                      <span>Qty: <span class="font-bold text-slate-900">{{ item.quantity }}</span></span>
                      <span class="font-bold text-slate-900"><span>$</span>{{ (item.unitPrice * item.quantity).toFixed(2) }}</span>

                      @if (order.orderStatus === 'DELIVERED' && (!item.returnStatus || item.returnStatus === 'NOT_RETURNED')) {
                        <button
                          (click)="openReturnModal(order, item)"
                          class="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded text-[10px] font-semibold cursor-pointer border border-rose-200"
                        >
                          Process Return
                        </button>
                      }
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Order Total & Lifecycle Controls -->
            <div class="mt-4 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div class="text-slate-500 font-mono text-[11px]">
                Subtotal: <span>$</span>{{ order.subtotal.toFixed(2) }} · Tax: <span>$</span>{{ order.tax.toFixed(2) }} ·
                <span class="font-bold text-slate-900 text-sm">Total: <span>$</span>{{ order.total.toFixed(2) }}</span>
              </div>

              <!-- Action buttons depending on state -->
              <div class="flex items-center gap-2">
                @if (order.orderStatus === 'RESERVED') {
                  <button
                    (click)="pickOrderFast(order.id)"
                    class="px-3 py-1.5 bg-[#0071DC] hover:bg-blue-700 text-white font-semibold rounded-lg text-xs cursor-pointer shadow-sm"
                  >
                    Pick & Stage Items
                  </button>
                }

                @if (order.orderStatus === 'STAGED') {
                  <button
                    (click)="state.dispatchOrder(order.id, 'veh-van-102')"
                    class="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg text-xs cursor-pointer shadow-sm"
                  >
                    Dispatch to Van-102
                  </button>
                }

                @if (order.orderStatus === 'DISPATCHED') {
                  <button
                    (click)="state.completeDelivery(order.id, order.customerName)"
                    class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs cursor-pointer shadow-sm"
                  >
                    Complete Delivery (POD)
                  </button>
                }
              </div>
            </div>
          </div>
        }
      </div>

      <!-- RETURN & REFUND MODAL -->
      @if (returnTarget(); as ret) {
        <div class="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div class="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 class="font-bold text-slate-900 text-sm">Process Item Return & Refund</h3>
                <span class="text-slate-500 font-mono">{{ ret.order.orderNumber }} · {{ ret.item.name }}</span>
              </div>
              <button
                (click)="returnTarget.set(null)"
                class="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div class="mt-4 space-y-3 font-sans">
              <div>
                <span class="text-slate-500 block">Item Refund Value:</span>
                <span class="text-lg font-bold font-mono text-slate-900"><span>$</span>{{ (ret.item.unitPrice * ret.item.quantity).toFixed(2) }}</span>
                <p class="text-[11px] text-slate-500 mt-0.5">
                  Reverses associated loyalty points and logs disposition on the inventory ledger.
                </p>
              </div>

              <div>
                <label for="ret-disp-select" class="block font-semibold text-slate-700 mb-1">Stock Disposition:</label>
                <select
                  id="ret-disp-select"
                  (change)="returnDisposition.set($any($event.target).value)"
                  class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                >
                  <option value="RESTOCK">Restock to Shelf (Unopened / In Good Condition)</option>
                  <option value="DISPOSE">Dispose / Written Off (Perishable / Opened)</option>
                </select>
              </div>

              <div>
                <label for="ret-reason-input" class="block font-semibold text-slate-700 mb-1">Return Reason:</label>
                <input
                  id="ret-reason-input"
                  type="text"
                  [value]="returnReason()"
                  (input)="returnReason.set($any($event.target).value)"
                  placeholder="e.g. Customer ordered incorrect pack size"
                  class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
            </div>

            <div class="mt-6 pt-3 border-t border-slate-200 flex justify-end gap-2">
              <button
                (click)="returnTarget.set(null)"
                class="px-3 py-1.5 border border-slate-300 text-slate-700 rounded-lg font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                (click)="commitReturn()"
                class="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold cursor-pointer"
              >
                Issue Refund & Reversal
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class OrdersViewComponent {
  readonly state = inject(RetailStateService);
  readonly channelFilter = signal<'ALL' | 'ONLINE_DELIVERY' | 'CLICK_COLLECT'>('ALL');

  readonly returnTarget = signal<{ order: CustomerOrder; item: OrderItem } | null>(null);
  readonly returnDisposition = signal<'RESTOCK' | 'DISPOSE'>('RESTOCK');
  readonly returnReason = signal<string>('Customer received duplicate item');

  filteredOrders() {
    const filter = this.channelFilter();
    if (filter === 'ALL') return this.state.orders();
    return this.state.orders().filter(o => o.channel === filter);
  }

  pickOrderFast(orderId: string): void {
    const ord = this.state.orders().find(o => o.id === orderId);
    if (!ord) return;
    for (const item of ord.items) {
      this.state.pickOrderItem(orderId, item.productId, item.barcode);
    }
  }

  openReturnModal(order: CustomerOrder, item: OrderItem): void {
    this.returnTarget.set({ order, item });
  }

  commitReturn(): void {
    const target = this.returnTarget();
    if (!target) return;
    this.state.processReturnAndRefund(
      target.order.id,
      target.item.productId,
      this.returnDisposition(),
      this.returnReason()
    );
    this.returnTarget.set(null);
  }
}
