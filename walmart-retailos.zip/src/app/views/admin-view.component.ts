import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RetailStateService, USER_ROLES_PERMISSIONS } from '../core/services/retail-state.service';
import { UserRole } from '../core/models/retail.types';

@Component({
  selector: 'app-admin-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span class="font-bold text-[#0071DC]">Governance & Access Control</span>
            <span aria-hidden="true">·</span>
            <span>Role-Based Access Control (RBAC) & Audit Log</span>
          </div>
          <h2 class="text-xl font-bold text-slate-900">Administration, Security & Integration Adapters</h2>
          <p class="text-xs text-slate-600 mt-0.5 max-w-2xl">
            Enforces granular store and regional scopes. Maintains an append-only audit trail of price changes, stock overrides, refunds, and integration events.
          </p>
        </div>

        <!-- Sub Tabs -->
        <div class="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium">
          <button
            (click)="activeSubTab.set('AUDIT')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="activeSubTab() === 'AUDIT'"
            [class.text-slate-900]="activeSubTab() === 'AUDIT'"
            [class.shadow-xs]="activeSubTab() === 'AUDIT'"
            [class.text-slate-600]="activeSubTab() !== 'AUDIT'"
          >
            Audit Trail ({{ state.auditLogs().length }})
          </button>
          <button
            (click)="activeSubTab.set('ROLES')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="activeSubTab() === 'ROLES'"
            [class.text-slate-900]="activeSubTab() === 'ROLES'"
            [class.shadow-xs]="activeSubTab() === 'ROLES'"
            [class.text-slate-600]="activeSubTab() !== 'ROLES'"
          >
            RBAC Permissions Matrix
          </button>
          <button
            (click)="activeSubTab.set('ADAPTERS')"
            class="px-2.5 py-1 rounded-md cursor-pointer transition-colors"
            [class.bg-white]="activeSubTab() === 'ADAPTERS'"
            [class.text-slate-900]="activeSubTab() === 'ADAPTERS'"
            [class.shadow-xs]="activeSubTab() === 'ADAPTERS'"
            [class.text-slate-600]="activeSubTab() !== 'ADAPTERS'"
          >
            Integration Adapters
          </button>
        </div>
      </div>

      <!-- VIEW 1: AUDIT TRAIL LOG -->
      @if (activeSubTab() === 'AUDIT') {
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-3">
              <span class="font-bold text-slate-900 text-sm">System Audit Records</span>
              <span class="text-xs text-slate-500 font-mono">Immutable append-only security log</span>
            </div>

            <!-- Category filter -->
            <div class="flex items-center gap-2 text-xs">
              <span class="text-slate-500">Filter Category:</span>
              <select
                (change)="auditCategoryFilter.set($any($event.target).value)"
                class="bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg px-2.5 py-1 focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Categories</option>
                <option value="INVENTORY">Inventory</option>
                <option value="PRICING">Pricing</option>
                <option value="ORDERS">Orders</option>
                <option value="LOYALTY">Loyalty</option>
                <option value="ACCESS">Access & Security</option>
                <option value="INTEGRATION">Integrations</option>
              </select>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
                <tr>
                  <th class="py-3 px-4 font-semibold">Timestamp</th>
                  <th class="py-3 px-4 font-semibold">Category</th>
                  <th class="py-3 px-4 font-semibold">Action</th>
                  <th class="py-3 px-4 font-semibold">Target Entity</th>
                  <th class="py-3 px-4 font-semibold">Operator / Role</th>
                  <th class="py-3 px-4 font-semibold font-sans">Details</th>
                  <th class="py-3 px-4 font-semibold">Severity</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (entry of filteredAuditLogs(); track entry.id) {
                  <tr class="hover:bg-slate-50 transition-colors">
                    <td class="py-3 px-4 text-slate-500 text-[11px] whitespace-nowrap">
                      {{ entry.timestamp | date:'mediumTime' }}
                    </td>
                    <td class="py-3 px-4 font-bold text-slate-800">{{ entry.category }}</td>
                    <td class="py-3 px-4 font-bold text-slate-900">{{ entry.action }}</td>
                    <td class="py-3 px-4 text-blue-700 font-bold">{{ entry.entityId }}</td>
                    <td class="py-3 px-4 font-sans text-slate-700">
                      <div>{{ entry.performedBy }}</div>
                      <div class="text-[10px] text-slate-400 font-mono">{{ entry.role }}</div>
                    </td>
                    <td class="py-3 px-4 font-sans text-slate-700 text-xs leading-snug max-w-md">
                      {{ entry.details }}
                    </td>
                    <td class="py-3 px-4">
                      <span
                        class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-slate-100]="entry.severity === 'INFO'"
                        [class.text-slate-700]="entry.severity === 'INFO'"
                        [class.bg-amber-100]="entry.severity === 'WARNING'"
                        [class.text-amber-800]="entry.severity === 'WARNING'"
                        [class.bg-rose-100]="entry.severity === 'CRITICAL'"
                        [class.text-rose-800]="entry.severity === 'CRITICAL'"
                      >
                        {{ entry.severity }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- VIEW 2: RBAC PERMISSIONS MATRIX -->
      @if (activeSubTab() === 'ROLES') {
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="p-5 border-b border-slate-200">
            <h3 class="font-bold text-slate-900 text-sm">Role-Based Access Control (RBAC) Specification</h3>
            <p class="text-xs text-slate-500 mt-0.5">
              Strictly enforced server-side. For example, associates are prevented from approving price modifications.
            </p>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
                <tr>
                  <th class="py-3 px-4 font-semibold font-sans">Role Persona</th>
                  <th class="py-3 px-4 font-semibold text-center">Adjust Stock</th>
                  <th class="py-3 px-4 font-semibold text-center">Approve Prices</th>
                  <th class="py-3 px-4 font-semibold text-center">Dispatch Waves</th>
                  <th class="py-3 px-4 font-semibold text-center">Process Refunds</th>
                  <th class="py-3 px-4 font-semibold text-center">Issue Loyalty</th>
                  <th class="py-3 px-4 font-semibold text-center">Modify POs</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (role of rolesList; track role) {
                  <tr
                    class="hover:bg-slate-50 transition-colors"
                    [class.bg-blue-50/50]="state.currentUser().role === role"
                  >
                    <td class="py-3 px-4 font-sans font-semibold text-slate-900">
                      <div class="flex items-center gap-2">
                        <span>{{ role }}</span>
                        @if (state.currentUser().role === role) {
                          <span class="bg-[#0071DC] text-white px-1.5 py-0.2 rounded text-[10px] font-mono font-bold">
                            CURRENT
                          </span>
                        }
                      </div>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canAdjustStock" [class.text-slate-300]="!getPerms(role).canAdjustStock" class="text-base">
                        {{ getPerms(role).canAdjustStock ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canApprovePrice" [class.text-slate-300]="!getPerms(role).canApprovePrice" class="text-base">
                        {{ getPerms(role).canApprovePrice ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canDispatchOrders" [class.text-slate-300]="!getPerms(role).canDispatchOrders" class="text-base">
                        {{ getPerms(role).canDispatchOrders ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canProcessRefunds" [class.text-slate-300]="!getPerms(role).canProcessRefunds" class="text-base">
                        {{ getPerms(role).canProcessRefunds ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canIssueLoyaltyPoints" [class.text-slate-300]="!getPerms(role).canIssueLoyaltyPoints" class="text-base">
                        {{ getPerms(role).canIssueLoyaltyPoints ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                    <td class="py-3 px-4 text-center">
                      <mat-icon [class.text-emerald-600]="getPerms(role).canModifyPOs" [class.text-slate-300]="!getPerms(role).canModifyPOs" class="text-base">
                        {{ getPerms(role).canModifyPOs ? 'check' : 'remove' }}
                      </mat-icon>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- VIEW 3: INTEGRATION ADAPTERS -->
      @if (activeSubTab() === 'ADAPTERS') {
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Adapter 1: Store POS -->
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#0071DC]">point_of_sale</mat-icon>
                <h4 class="font-bold text-slate-900 text-sm">Store POS Register Adapter</h4>
              </div>
              <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                CONNECTED (Lane 01-14)
              </span>
            </div>
            <p class="text-slate-600">
              Ingests scanner transactions, register cash receipts, and customer loyalty bar codes. Feeds transactional sales events into stock movement ledger.
            </p>
            <div class="p-2.5 bg-slate-50 rounded font-mono text-[11px] text-slate-700 space-y-1">
              <div>Protocol: TCP Socket / REST Webhook</div>
              <div>Event: POS_TICKET_COMMITTED</div>
              <div>Heartbeat: 42ms · In-Flight Sync: 0 pending</div>
            </div>
          </div>

          <!-- Adapter 2: Payment Provider -->
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-indigo-600">credit_card</mat-icon>
                <h4 class="font-bold text-slate-900 text-sm">Tokenized Payment Gateway</h4>
              </div>
              <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                PCI-DSS VAULT ACTIVE
              </span>
            </div>
            <p class="text-slate-600">
              Handles authorization tokens, delayed captures upon dispatch, and programmatic refund reversals. RetailOS never stores raw PAN card numbers.
            </p>
            <div class="p-2.5 bg-slate-50 rounded font-mono text-[11px] text-slate-700 space-y-1">
              <div>Idempotency Check: ENFORCED (UUID v4)</div>
              <div>Auto-Release Auth on Expiry: 72 hrs</div>
              <div>Status: Nominal</div>
            </div>
          </div>

          <!-- Adapter 3: EDI 850/856 Supplier Adapter -->
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-600">swap_horiz</mat-icon>
                <h4 class="font-bold text-slate-900 text-sm">EDI 850 / 856 Supplier Gateway</h4>
              </div>
              <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                AS2 SECURE LINK
              </span>
            </div>
            <p class="text-slate-600">
              Transmits EDI 850 Purchase Orders to vendor ERPs and ingests EDI 856 Advanced Shipping Notices (ASN) with container barcode manifests.
            </p>
            <div class="p-2.5 bg-slate-50 rounded font-mono text-[11px] text-slate-700 space-y-1">
              <div>Vendors Mapped: Pacific Berry, Valley Verde, Ozark, P&G</div>
              <div>Format: ANSI ASC X12 Version 5010</div>
            </div>
          </div>

          <!-- Adapter 4: Zebra ZPL II Printer Adapter -->
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-600">print</mat-icon>
                <h4 class="font-bold text-slate-900 text-sm">Zebra ZPL II Thermal Label Adapter</h4>
              </div>
              <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                TCP / RAW 9100 READY
              </span>
            </div>
            <p class="text-slate-600">
              Generates raw ZPL bytecode for electronic shelf label stickers, pallet LPN tags, and yellow clearance markdowns.
            </p>
            <div class="p-2.5 bg-slate-50 rounded font-mono text-[11px] text-slate-700 space-y-1">
              <div>Output Format: Native ^XA...^XZ Command String</div>
              <div>Printer Model: Zebra ZQ630 Plus & ZT411</div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AdminViewComponent {
  readonly state = inject(RetailStateService);
  readonly activeSubTab = signal<'AUDIT' | 'ROLES' | 'ADAPTERS'>('AUDIT');
  readonly auditCategoryFilter = signal<string>('ALL');

  readonly rolesList: UserRole[] = [
    'Enterprise Administrator',
    'Regional Manager',
    'Store Manager',
    'Inventory Associate',
    'Buyer',
    'Pricing Analyst',
    'Delivery Dispatcher',
    'Customer Service',
    'Auditor (Read-Only)'
  ];

  getPerms(role: UserRole) {
    return USER_ROLES_PERMISSIONS[role];
  }

  filteredAuditLogs() {
    const cat = this.auditCategoryFilter();
    if (cat === 'ALL') return this.state.auditLogs();
    return this.state.auditLogs().filter(l => l.category === cat);
  }
}
