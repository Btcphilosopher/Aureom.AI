// Core Domain Types for Walmart RetailOS Enterprise Management

export type FacilityType = 'SUPERCENTER' | 'NEIGHBORHOOD_MARKET' | 'RDC';

export interface Facility {
  id: string;
  code: string;
  name: string;
  type: FacilityType;
  address: string;
  city: string;
  state: string;
  activeAssociates: number;
  shelfCapacitySqFt: number;
  capacityUtilizationPct: number;
  coldChainSensorsCount: number;
  tempStatus: 'NOMINAL' | 'WARNING' | 'ALERT';
  avgTempFahrenheit: number;
}

export type ProductUnit = 'unit' | 'lb' | 'kg' | 'pack';
export type TaxCategory = 'GROCERY_EXEMPT' | 'STANDARD_TAX';
export type TemperatureClass = 'AMBIENT' | 'CHILLED' | 'FROZEN';

export interface ProductLot {
  lotNumber: string;
  expiryDate: string; // YYYY-MM-DD
  daysToExpiry: number;
  quantity: number;
  status: 'FRESH' | 'SHORT_DATED' | 'EXPIRED';
  aisle: string;
  shelf: string;
  bin: string;
  receivedDate: string;
}

export interface Product {
  id: string;
  sku: string;
  barcode: string; // UPC/EAN
  name: string;
  category: 'Fresh Produce' | 'Dairy & Eggs' | 'Meat & Seafood' | 'Bakery' | 'Pantry & Dry Goods' | 'Household';
  unit: ProductUnit;
  packSize: number; // e.g. 12 units/case
  costPrice: number;
  basePrice: number;
  currentPrice: number;
  markdownPercent?: number;
  markdownReason?: string;
  taxCategory: TaxCategory;
  isWeighted: boolean;
  temperatureClass: TemperatureClass;
  supplierId: string;
  supplierName: string;
  reorderPoint: number;
  safetyStock: number;
  supplierLeadDays: number;
  minOrderQty: number; // MOQ
}

export interface InventoryBalance {
  productId: string;
  locationId: string;
  onHand: number;
  reserved: number;
  atp: number; // Available to Promise = onHand - reserved
  inTransit: number;
  quarantined: number;
  damaged: number;
  expired: number;
  lots: ProductLot[];
}

export type StockMovementType =
  | 'RECEIPT'
  | 'PUT_AWAY'
  | 'PICK_RESERVE'
  | 'DISPATCH'
  | 'CYCLE_COUNT'
  | 'WASTE_EXPIRY'
  | 'DAMAGE_WRITEOFF'
  | 'RETURN_RESTOCK'
  | 'STORE_TRANSFER';

export interface StockMovement {
  id: string;
  timestamp: string;
  productId: string;
  productSku: string;
  productName: string;
  locationId: string;
  type: StockMovementType;
  delta: number;
  balanceAfter: number;
  reason: string;
  performedBy: string;
  referenceId: string; // PO number, Order ID, or Count ID
}

export interface PurchaseOrderItem {
  productId: string;
  productSku: string;
  productName: string;
  orderedQty: number;
  receivedQty: number;
  unitCost: number;
  caseCount: number;
  lotAssigned?: string;
  expiryAssigned?: string;
}

export type PurchaseOrderStatus = 'DRAFT' | 'APPROVED' | 'IN_TRANSIT' | 'PARTIALLY_RECEIVED' | 'RECEIVED' | 'CANCELLED';

export interface PurchaseOrder {
  poNumber: string;
  supplierId: string;
  supplierName: string;
  destinationLocationId: string;
  destinationName: string;
  orderDate: string;
  expectedDelivery: string;
  status: PurchaseOrderStatus;
  items: PurchaseOrderItem[];
  totalCost: number;
  dockAppointment: string;
  discrepancyNote?: string;
}

export interface ReplenishmentForecast {
  productId: string;
  productName: string;
  currentOnHand: number;
  currentATP: number;
  reorderPoint: number;
  safetyStock: number;
  avgDailySales: number;
  underlyingDemand: number; // Unconstrained demand accounting for stockouts
  stockoutDaysLast30: number;
  seasonalityMultiplier: number;
  forecastDailyDemand: number;
  recommendedOrderQty: number;
  roundedCasePackQty: number;
  leadTimeDays: number;
  shelfCapacityMax: number;
  expiryRiskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  manualOverrideQty?: number;
  overrideReason?: string;
}

export type OrderStatus =
  | 'PENDING_RESERVATION'
  | 'RESERVED'
  | 'WAVE_ASSIGNED'
  | 'PICKING'
  | 'STAGED'
  | 'DISPATCHED'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'RETURNED';

export type PaymentStatus = 'AUTHORIZED' | 'CAPTURED' | 'REFUNDED' | 'FAILED';

export interface OrderItem {
  productId: string;
  sku: string;
  barcode: string;
  name: string;
  quantity: number;
  unitPrice: number;
  isPicked: boolean;
  pickedLot?: string;
  substitutedWith?: {
    productId: string;
    sku: string;
    name: string;
    newPrice: number;
    priceDelta: number;
    reason: string;
    customerConsent: boolean;
  };
  returnStatus?: 'NOT_RETURNED' | 'RETURNED_DISPOSED' | 'RETURNED_RESTOCKED';
}

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  channel: 'STORE_POS' | 'ONLINE_DELIVERY' | 'CLICK_COLLECT';
  storeId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  loyaltyMemberId?: string;
  placedAt: string;
  deliveryWindow: string;
  deliveryAddress?: string;
  orderStatus: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentIdempotencyKey: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  assignedVehicleId?: string;
  assignedPicker?: string;
  stagingZone?: 'AMBIENT-A1' | 'CHILLED-C2' | 'FROZEN-F1';
  proofOfDelivery?: {
    signedBy: string;
    deliveredAt: string;
    photoVerificationUrl?: string;
    notes?: string;
  };
}

export interface DeliveryVehicle {
  id: string;
  code: string;
  type: 'REFRIGERATED_VAN' | 'ELECTRIC_VAN' | 'AUTONOMOUS_DRONE';
  driverName?: string;
  capacityLbs: number;
  currentLoadLbs: number;
  status: 'IDLE' | 'LOADING' | 'EN_ROUTE' | 'COMPLETED' | 'MAINTENANCE';
  currentBatteryOrFuelPct: number;
  temperatureCelsius?: number; // For cold chain tracking
  altitudeFt?: number; // For drone adapter
  assignedOrderIds: string[];
}

export interface DeliveryRouteStop {
  stopNumber: number;
  orderId: string;
  customerName: string;
  address: string;
  deliveryWindow: string;
  plannedArrival: string;
  liveEstimate: string;
  weightLbs: number;
  coldChainRequired: boolean;
  isInfeasible: boolean;
  infeasibleReason?: string;
  status: 'PENDING' | 'ARRIVED' | 'DELIVERED' | 'FAILED_RETURNED';
}

export type PricingWorkflowStage = 'RECOMMENDED' | 'APPROVED' | 'PUBLISHED' | 'CHANNEL_CONFIRMED';

export interface PriceRule {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  storeScope: 'ALL_NETWORK' | 'STORE_1042' | 'STORE_3841';
  ruleType: 'EXPIRY_MARKDOWN' | 'OVERSTOCK_CLEARANCE' | 'COMPETITOR_MATCH' | 'LOYALTY_EXCLUSIVE' | 'PROMOTIONAL';
  basePrice: number;
  competitorPrice?: {
    competitor: 'Target' | 'Amazon Fresh' | 'Kroger';
    observedPrice: number;
    scrapedAt: string;
  };
  recommendedPrice: number;
  currentFloorPrice: number; // Margin floor
  markdownPct: number;
  stage: PricingWorkflowStage;
  effectiveFrom: string;
  effectiveTo: string;
  rationale: string;
  requestedBy: string;
  approvedBy?: string;
  publishedChannels: {
    shelfESL: boolean;
    storePOS: boolean;
    onlineApp: boolean;
  };
}

export interface LoyaltyMember {
  id: string;
  memberId: string;
  barcode: string; // Scan code
  fullName: string;
  tier: 'Spark Member' | 'Walmart+ Member' | 'VIP Super Member';
  pointsBalance: number;
  lifetimePoints: number;
  joinedDate: string;
  communicationOptIn: boolean;
  purchaseDataUsageConsent: boolean;
  activeCoupons: {
    code: string;
    description: string;
    discountAmount: number;
    minSpend: number;
    expiryDate: string;
    used: boolean;
  }[];
}

export interface LoyaltyLedgerEntry {
  id: string;
  idempotencyKey: string;
  memberId: string;
  timestamp: string;
  orderId?: string;
  type: 'EARN_PURCHASE' | 'REDEMPTION' | 'BONUS_OFFER' | 'RETURN_REVERSAL' | 'MANUAL_ADJUSTMENT';
  pointsDelta: number;
  balanceAfter: number;
  description: string;
  reversible: boolean;
}

export type UserRole =
  | 'Enterprise Administrator'
  | 'Regional Manager'
  | 'Store Manager'
  | 'Inventory Associate'
  | 'Buyer'
  | 'Pricing Analyst'
  | 'Delivery Dispatcher'
  | 'Customer Service'
  | 'Auditor (Read-Only)';

export interface UserSession {
  name: string;
  role: UserRole;
  storeScope: string; // e.g., 'ST-1042' or 'ALL_NETWORK'
  permissions: {
    canAdjustStock: boolean;
    canApprovePrice: boolean;
    canDispatchOrders: boolean;
    canProcessRefunds: boolean;
    canIssueLoyaltyPoints: boolean;
    canModifyPOs: boolean;
    isReadOnly: boolean;
  };
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  category: 'INVENTORY' | 'PRICING' | 'ORDERS' | 'LOYALTY' | 'ACCESS' | 'INTEGRATION';
  action: string;
  entityId: string;
  performedBy: string;
  role: UserRole;
  storeCode: string;
  details: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
}

export interface AssociateOfflineAction {
  id: string;
  queuedAt: string;
  actionType: 'SCAN_VERIFY' | 'CYCLE_COUNT' | 'WASTE_RECORD' | 'PICK_CONFIRM';
  payload: Record<string, unknown>;
  status: 'PENDING_SYNC' | 'SYNCED' | 'CONFLICT';
  conflictMessage?: string;
}

export interface DemoScenarioStep {
  stepNumber: number;
  title: string;
  description: string;
  domain: 'RECEIVING' | 'INVENTORY' | 'ORDERS' | 'PICKING' | 'SUBSTITUTION' | 'DISPATCH' | 'LOYALTY' | 'PRICING' | 'REPLENISHMENT' | 'RETURNS';
  status: 'PENDING' | 'ACTIVE' | 'COMPLETED' | 'FAILED';
  resultSummary?: string;
}
