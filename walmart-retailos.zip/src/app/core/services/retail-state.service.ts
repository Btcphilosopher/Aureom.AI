import { Injectable, signal, computed } from '@angular/core';
import {
  Facility,
  Product,
  ProductLot,
  InventoryBalance,
  StockMovement,
  PurchaseOrder,
  ReplenishmentForecast,
  CustomerOrder,
  DeliveryVehicle,
  PriceRule,
  LoyaltyMember,
  LoyaltyLedgerEntry,
  AuditLogEntry,
  DeliveryRouteStop,
  UserSession,
  UserRole,
  AssociateOfflineAction,
  DemoScenarioStep
} from '../models/retail.types';
import {
  INITIAL_FACILITIES,
  INITIAL_PRODUCTS,
  INITIAL_INVENTORY_BALANCES,
  INITIAL_STOCK_MOVEMENTS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_REPLENISHMENT_FORECASTS,
  INITIAL_ORDERS,
  INITIAL_VEHICLES,
  INITIAL_ROUTE_STOPS,
  INITIAL_PRICE_RULES,
  INITIAL_LOYALTY_MEMBERS,
  INITIAL_LOYALTY_LEDGER,
  INITIAL_AUDIT_LOGS
} from './retail-data.seed';

export const USER_ROLES_PERMISSIONS: Record<UserRole, UserSession['permissions']> = {
  'Enterprise Administrator': {
    canAdjustStock: true,
    canApprovePrice: true,
    canDispatchOrders: true,
    canProcessRefunds: true,
    canIssueLoyaltyPoints: true,
    canModifyPOs: true,
    isReadOnly: false
  },
  'Regional Manager': {
    canAdjustStock: true,
    canApprovePrice: true,
    canDispatchOrders: true,
    canProcessRefunds: true,
    canIssueLoyaltyPoints: true,
    canModifyPOs: true,
    isReadOnly: false
  },
  'Store Manager': {
    canAdjustStock: true,
    canApprovePrice: true,
    canDispatchOrders: true,
    canProcessRefunds: true,
    canIssueLoyaltyPoints: true,
    canModifyPOs: true,
    isReadOnly: false
  },
  'Inventory Associate': {
    canAdjustStock: true,
    canApprovePrice: false,
    canDispatchOrders: false,
    canProcessRefunds: false,
    canIssueLoyaltyPoints: false,
    canModifyPOs: false,
    isReadOnly: false
  },
  'Buyer': {
    canAdjustStock: false,
    canApprovePrice: true,
    canDispatchOrders: false,
    canProcessRefunds: false,
    canIssueLoyaltyPoints: false,
    canModifyPOs: true,
    isReadOnly: false
  },
  'Pricing Analyst': {
    canAdjustStock: false,
    canApprovePrice: true,
    canDispatchOrders: false,
    canProcessRefunds: false,
    canIssueLoyaltyPoints: false,
    canModifyPOs: false,
    isReadOnly: false
  },
  'Delivery Dispatcher': {
    canAdjustStock: false,
    canApprovePrice: false,
    canDispatchOrders: true,
    canProcessRefunds: false,
    canIssueLoyaltyPoints: false,
    canModifyPOs: false,
    isReadOnly: false
  },
  'Customer Service': {
    canAdjustStock: false,
    canApprovePrice: false,
    canDispatchOrders: false,
    canProcessRefunds: true,
    canIssueLoyaltyPoints: true,
    canModifyPOs: false,
    isReadOnly: false
  },
  'Auditor (Read-Only)': {
    canAdjustStock: false,
    canApprovePrice: false,
    canDispatchOrders: false,
    canProcessRefunds: false,
    canIssueLoyaltyPoints: false,
    canModifyPOs: false,
    isReadOnly: true
  }
};

@Injectable({
  providedIn: 'root'
})
export class RetailStateService {
  // Primary domain state signals
  readonly facilities = signal<Facility[]>(INITIAL_FACILITIES);
  readonly selectedFacilityId = signal<string>('fac-1042');
  readonly products = signal<Product[]>(INITIAL_PRODUCTS);
  readonly inventoryBalances = signal<InventoryBalance[]>(INITIAL_INVENTORY_BALANCES);
  readonly stockMovements = signal<StockMovement[]>(INITIAL_STOCK_MOVEMENTS);
  readonly purchaseOrders = signal<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  readonly forecasts = signal<ReplenishmentForecast[]>(INITIAL_REPLENISHMENT_FORECASTS);
  readonly orders = signal<CustomerOrder[]>(INITIAL_ORDERS);
  readonly vehicles = signal<DeliveryVehicle[]>(INITIAL_VEHICLES);
  readonly routeStops = signal<DeliveryRouteStop[]>(INITIAL_ROUTE_STOPS);
  readonly priceRules = signal<PriceRule[]>(INITIAL_PRICE_RULES);
  readonly loyaltyMembers = signal<LoyaltyMember[]>(INITIAL_LOYALTY_MEMBERS);
  readonly loyaltyLedger = signal<LoyaltyLedgerEntry[]>(INITIAL_LOYALTY_LEDGER);
  readonly auditLogs = signal<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);

  // User session & role
  readonly currentUser = signal<UserSession>({
    name: 'Sarah Morales',
    role: 'Store Manager',
    storeScope: 'ST-1042',
    permissions: USER_ROLES_PERMISSIONS['Store Manager']
  });

  // Associate Handheld state
  readonly isAssociateHandheldMode = signal<boolean>(false);
  readonly isAssociateOffline = signal<boolean>(false);
  readonly associateOfflineQueue = signal<AssociateOfflineAction[]>([]);
  readonly labelPrinterLogs = signal<{ timestamp: string; labelType: string; zpl: string; status: string }[]>([]);

  // System notification banner
  readonly systemNotice = signal<{ message: string; type: 'success' | 'warning' | 'info' | 'error' } | null>({
    message: 'System nominal: Supercenter #1042 connected. Inventory & replenishment live.',
    type: 'info'
  });

  // End-to-End Demo Scenario State
  readonly demoSteps = signal<DemoScenarioStep[]>([
    {
      stepNumber: 1,
      title: 'Receive Fresh Produce at Dock',
      description: 'Supercenter #1042 receives 32 cases of Fresh Strawberries with short expiry dates (LOT-SB-2611C).',
      domain: 'RECEIVING',
      status: 'PENDING'
    },
    {
      stepNumber: 2,
      title: 'Put-Away & ATP Update',
      description: 'Stock moved to Aisle 04 Tier 2, increasing Available-to-Promise (ATP) inventory on the ledger.',
      domain: 'INVENTORY',
      status: 'PENDING'
    },
    {
      stepNumber: 3,
      title: 'Customer Places Delivery Order',
      description: 'Elena Rostova places online order #ORD-9821 applying Walmart+ membership card.',
      domain: 'ORDERS',
      status: 'PENDING'
    },
    {
      stepNumber: 4,
      title: 'Transactional Stock Reservation',
      description: 'System locks requested inventory in the immutable balance ledger to prevent overselling.',
      domain: 'INVENTORY',
      status: 'PENDING'
    },
    {
      stepNumber: 5,
      title: 'Associate Wave Picking & Barcode Scan',
      description: 'Associate Devon Barnes walks optimized aisle path and verifies items with barcode scanner.',
      domain: 'PICKING',
      status: 'PENDING'
    },
    {
      stepNumber: 6,
      title: 'Item Substitution Approval',
      description: 'Honeycrisp Apples low stock: system proposes Fuji Apples. Customer consent logged and price adjusted.',
      domain: 'SUBSTITUTION',
      status: 'PENDING'
    },
    {
      stepNumber: 7,
      title: 'Staging & Dispatch to Cold Van',
      description: 'Order staged in CHILLED-C2, loaded onto Refrigerated Van-102 with cold-chain sensor monitoring.',
      domain: 'DISPATCH',
      status: 'PENDING'
    },
    {
      stepNumber: 8,
      title: 'Proof of Delivery & Idempotent Loyalty',
      description: 'Order delivered, signature captured. 36 loyalty points awarded with idempotent event key.',
      domain: 'LOYALTY',
      status: 'PENDING'
    },
    {
      stepNumber: 9,
      title: 'Automated Markdown on Short-Dated Stock',
      description: 'Pricing engine detects remaining 18 units of 24h short-dated strawberries. 35% markdown published to ESL.',
      domain: 'PRICING',
      status: 'PENDING'
    },
    {
      stepNumber: 10,
      title: 'Replenishment Reorder Point Trigger',
      description: 'Depleted Honeycrisp inventory breaches Reorder Point (28 < 60 ROP). PO-4409 generated for supplier.',
      domain: 'REPLENISHMENT',
      status: 'PENDING'
    },
    {
      stepNumber: 11,
      title: 'Customer Return, Refund & Point Reversal',
      description: 'Customer returns 1 item. System processes refund, logs stock disposition, and reverses awarded points.',
      domain: 'RETURNS',
      status: 'PENDING'
    }
  ]);

  readonly activeDemoStepIndex = signal<number>(0);

  // Computed views
  readonly currentFacility = computed(() => {
    const list = this.facilities();
    return list.find(f => f.id === this.selectedFacilityId()) || list[0];
  });

  readonly currentFacilityBalances = computed(() => {
    const facId = this.selectedFacilityId();
    const balances = this.inventoryBalances().filter(b => b.locationId === facId);
    const prods = this.products();

    return balances.map(b => {
      const prod = prods.find(p => p.id === b.productId);
      return {
        ...b,
        product: prod
      };
    });
  });

  readonly totalNetworkInventoryValue = computed(() => {
    const balances = this.inventoryBalances();
    const prods = this.products();
    let total = 0;
    for (const b of balances) {
      const prod = prods.find(p => p.id === b.productId);
      if (prod) {
        total += b.onHand * prod.costPrice;
      }
    }
    return total;
  });

  readonly shortDatedLotsCount = computed(() => {
    const balances = this.inventoryBalances();
    let count = 0;
    for (const b of balances) {
      for (const lot of b.lots) {
        if (lot.status === 'SHORT_DATED') {
          count++;
        }
      }
    }
    return count;
  });

  readonly lowStockProductsCount = computed(() => {
    const balances = this.inventoryBalances().filter(b => b.locationId === this.selectedFacilityId());
    const prods = this.products();
    let count = 0;
    for (const b of balances) {
      const prod = prods.find(p => p.id === b.productId);
      if (prod && b.atp <= prod.reorderPoint) {
        count++;
      }
    }
    return count;
  });

  readonly pendingOrdersCount = computed(() => {
    return this.orders().filter(o => o.orderStatus === 'RESERVED' || o.orderStatus === 'PICKING').length;
  });

  // --- Actions & Methods ---

  selectFacility(facId: string): void {
    this.selectedFacilityId.set(facId);
    this.addAuditLog('ACCESS', 'FACILITY_CONTEXT_SWITCH', facId, `Switched operational context to ${facId}`);
  }

  setUserRole(role: UserRole): void {
    const perms = USER_ROLES_PERMISSIONS[role];
    this.currentUser.update(u => ({
      ...u,
      role,
      permissions: perms
    }));
    this.notify(`User switched to persona: ${role}`, 'info');
    this.addAuditLog('ACCESS', 'ROLE_SWITCH', role, `Active user switched to role: ${role}`);
  }

  toggleHandheldMode(): void {
    const next = !this.isAssociateHandheldMode();
    this.isAssociateHandheldMode.set(next);
  }

  toggleAssociateOffline(): void {
    const next = !this.isAssociateOffline();
    this.isAssociateOffline.set(next);
    if (next) {
      this.notify('Handheld device disconnected (Offline Mode). Scans will queue locally.', 'warning');
    } else {
      this.syncAssociateOfflineQueue();
    }
  }

  notify(message: string, type: 'success' | 'warning' | 'info' | 'error' = 'info'): void {
    this.systemNotice.set({ message, type });
  }

  clearNotice(): void {
    this.systemNotice.set(null);
  }

  addAuditLog(
    category: AuditLogEntry['category'],
    action: string,
    entityId: string,
    details: string,
    severity: AuditLogEntry['severity'] = 'INFO'
  ): void {
    const user = this.currentUser();
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      category,
      action,
      entityId,
      performedBy: user.name,
      role: user.role,
      storeCode: user.storeScope,
      details,
      severity
    };
    this.auditLogs.update(logs => [entry, ...logs.slice(0, 99)]);
  }

  // --- Inventory & Stock Movement ---

  receiveDockDelivery(poNumber: string, productId: string, qty: number, lotNumber: string, expiryDate: string, daysToExpiry: number): boolean {
    const facId = this.selectedFacilityId();
    const prod = this.products().find(p => p.id === productId);
    if (!prod) return false;

    // Update inventory balance
    this.inventoryBalances.update(balances => {
      return balances.map(b => {
        if (b.productId === productId && b.locationId === facId) {
          const newOnHand = b.onHand + qty;
          const newAtp = b.atp + qty;
          const newInTransit = Math.max(0, b.inTransit - qty);
          const newLot: ProductLot = {
            lotNumber,
            expiryDate,
            daysToExpiry,
            quantity: qty,
            status: daysToExpiry <= 2 ? 'SHORT_DATED' : 'FRESH',
            aisle: 'Aisle 04',
            shelf: 'Tier 2',
            bin: 'BIN-PROD-402',
            receivedDate: new Date().toISOString().split('T')[0]
          };
          return {
            ...b,
            onHand: newOnHand,
            atp: newAtp,
            inTransit: newInTransit,
            lots: [newLot, ...b.lots]
          };
        }
        return b;
      });
    });

    // Update PO item received quantity
    this.purchaseOrders.update(pos => {
      return pos.map(po => {
        if (po.poNumber === poNumber) {
          const updatedItems = po.items.map(item => {
            if (item.productId === productId) {
              return { ...item, receivedQty: item.receivedQty + qty };
            }
            return item;
          });
          const allDone = updatedItems.every(i => i.receivedQty >= i.orderedQty);
          return {
            ...po,
            items: updatedItems,
            status: allDone ? 'RECEIVED' : 'PARTIALLY_RECEIVED'
          };
        }
        return po;
      });
    });

    // Immutable Stock Movement Ledger
    const currentBal = this.inventoryBalances().find(b => b.productId === productId && b.locationId === facId)?.onHand || 0;
    const movement: StockMovement = {
      id: `sm-${Date.now()}`,
      timestamp: new Date().toISOString(),
      productId,
      productSku: prod.sku,
      productName: prod.name,
      locationId: facId,
      type: 'RECEIPT',
      delta: qty,
      balanceAfter: currentBal,
      reason: `Dock receiving against PO ${poNumber}`,
      performedBy: this.currentUser().name,
      referenceId: poNumber
    };
    this.stockMovements.update(moves => [movement, ...moves]);

    this.addAuditLog('INVENTORY', 'STOCK_RECEIVED', poNumber, `Received ${qty} units of ${prod.name} (Lot ${lotNumber}, Exp: ${expiryDate})`);
    this.notify(`Successfully received ${qty} units of ${prod.name}. Stock ledger updated.`, 'success');
    return true;
  }

  recordWasteOrDamage(productId: string, qty: number, reason: string, disposition: 'WASTE_EXPIRY' | 'DAMAGE_WRITEOFF'): boolean {
    const facId = this.selectedFacilityId();
    const prod = this.products().find(p => p.id === productId);
    if (!prod) return false;

    let success = false;
    this.inventoryBalances.update(balances => {
      return balances.map(b => {
        if (b.productId === productId && b.locationId === facId) {
          if (b.onHand < qty) {
            this.notify(`Cannot record waste of ${qty}: only ${b.onHand} units on hand.`, 'error');
            return b;
          }
          success = true;
          const newOnHand = b.onHand - qty;
          const newAtp = Math.max(0, b.atp - qty);
          const newDamaged = disposition === 'DAMAGE_WRITEOFF' ? b.damaged + qty : b.damaged;
          const newExpired = disposition === 'WASTE_EXPIRY' ? b.expired + qty : b.expired;
          return {
            ...b,
            onHand: newOnHand,
            atp: newAtp,
            damaged: newDamaged,
            expired: newExpired
          };
        }
        return b;
      });
    });

    if (success) {
      const currentBal = this.inventoryBalances().find(b => b.productId === productId && b.locationId === facId)?.onHand || 0;
      const movement: StockMovement = {
        id: `sm-${Date.now()}`,
        timestamp: new Date().toISOString(),
        productId,
        productSku: prod.sku,
        productName: prod.name,
        locationId: facId,
        type: disposition,
        delta: -qty,
        balanceAfter: currentBal,
        reason,
        performedBy: this.currentUser().name,
        referenceId: `DISP-${Date.now()}`
      };
      this.stockMovements.update(moves => [movement, ...moves]);
      this.addAuditLog('INVENTORY', disposition, prod.sku, `Wrote off ${qty} units: ${reason}`);
      this.notify(`Recorded write-off: -${qty} units of ${prod.name}.`, 'warning');
    }
    return success;
  }

  reconcileCycleCount(productId: string, physicalCount: number, reason: string): void {
    const facId = this.selectedFacilityId();
    const prod = this.products().find(p => p.id === productId);
    if (!prod) return;

    const currentBalRecord = this.inventoryBalances().find(b => b.productId === productId && b.locationId === facId);
    if (!currentBalRecord) return;

    const diff = physicalCount - currentBalRecord.onHand;
    if (diff === 0) {
      this.notify(`Cycle count verified: Physical count matches recorded balance (${physicalCount}).`, 'success');
      return;
    }

    this.inventoryBalances.update(balances => {
      return balances.map(b => {
        if (b.productId === productId && b.locationId === facId) {
          return {
            ...b,
            onHand: physicalCount,
            atp: Math.max(0, physicalCount - b.reserved)
          };
        }
        return b;
      });
    });

    const movement: StockMovement = {
      id: `sm-${Date.now()}`,
      timestamp: new Date().toISOString(),
      productId,
      productSku: prod.sku,
      productName: prod.name,
      locationId: facId,
      type: 'CYCLE_COUNT',
      delta: diff,
      balanceAfter: physicalCount,
      reason: `Cycle Count variance (${diff > 0 ? '+' : ''}${diff}): ${reason}`,
      performedBy: this.currentUser().name,
      referenceId: `CC-${Date.now()}`
    };
    this.stockMovements.update(moves => [movement, ...moves]);

    this.addAuditLog('INVENTORY', 'CYCLE_COUNT_RECONCILED', prod.sku, `Reconciled from ${currentBalRecord.onHand} to ${physicalCount} (${diff > 0 ? '+' : ''}${diff}). Reason: ${reason}`);
    this.notify(`Reconciled ${prod.name}: ${diff > 0 ? '+' : ''}${diff} adjustment applied to ledger.`, 'info');
  }

  // --- Orders & Fulfillment ---

  reserveStockForOrder(order: CustomerOrder): boolean {
    const facId = order.storeId;
    let canFulfill = true;
    const balances = this.inventoryBalances();

    // Verification check: ensure ATP >= requested qty for all items
    for (const item of order.items) {
      const bal = balances.find(b => b.productId === item.productId && b.locationId === facId);
      if (!bal || bal.atp < item.quantity) {
        canFulfill = false;
        break;
      }
    }

    if (!canFulfill) {
      this.notify(`Reservation failed: Insufficient Available-To-Promise stock for order ${order.orderNumber}.`, 'error');
      return false;
    }

    // Transactionally reserve
    this.inventoryBalances.update(bList => {
      return bList.map(b => {
        const item = order.items.find(i => i.productId === b.productId && b.locationId === facId);
        if (item) {
          return {
            ...b,
            reserved: b.reserved + item.quantity,
            atp: b.atp - item.quantity
          };
        }
        return b;
      });
    });

    this.orders.update(orders => {
      return orders.map(o => (o.id === order.id ? { ...o, orderStatus: 'RESERVED' } : o));
    });

    this.addAuditLog('ORDERS', 'STOCK_RESERVED', order.orderNumber, `Transactionally reserved ${order.items.length} items for ${order.customerName}.`);
    this.notify(`Order ${order.orderNumber} reserved successfully. ATP balance decremented.`, 'success');
    return true;
  }

  pickOrderItem(orderId: string, productId: string, scannedBarcode: string): boolean {
    const order = this.orders().find(o => o.id === orderId);
    if (!order) return false;

    const item = order.items.find(i => i.productId === productId);
    if (!item) return false;

    if (item.barcode !== scannedBarcode) {
      this.notify(`Barcode mismatch! Scanned ${scannedBarcode}, expected ${item.barcode} for ${item.name}.`, 'error');
      return false;
    }

    this.orders.update(orders => {
      return orders.map(o => {
        if (o.id === orderId) {
          const updatedItems = o.items.map(it => (it.productId === productId ? { ...it, isPicked: true } : it));
          const allPicked = updatedItems.every(it => it.isPicked);
          return {
            ...o,
            items: updatedItems,
            orderStatus: allPicked ? 'STAGED' : 'PICKING',
            stagingZone: allPicked ? (o.stagingZone || 'CHILLED-C2') : o.stagingZone
          };
        }
        return o;
      });
    });

    this.addAuditLog('ORDERS', 'ITEM_PICKED', order.orderNumber, `Barcode verified & picked: ${item.name} (UPC: ${scannedBarcode})`);
    this.notify(`Picked: ${item.name}. Barcode verified.`, 'success');
    return true;
  }

  substituteOrderItem(
    orderId: string,
    originalProductId: string,
    substituteProductId: string,
    reason: string
  ): boolean {
    const order = this.orders().find(o => o.id === orderId);
    if (!order) return false;

    const origItem = order.items.find(i => i.productId === originalProductId);
    const subProd = this.products().find(p => p.id === substituteProductId);
    if (!origItem || !subProd) return false;

    const priceDelta = subProd.currentPrice - origItem.unitPrice;

    this.orders.update(orders => {
      return orders.map(o => {
        if (o.id === orderId) {
          const updatedItems = o.items.map(it => {
            if (it.productId === originalProductId) {
              return {
                ...it,
                isPicked: true,
                substitutedWith: {
                  productId: subProd.id,
                  sku: subProd.sku,
                  name: subProd.name,
                  newPrice: subProd.currentPrice,
                  priceDelta,
                  reason,
                  customerConsent: true
                }
              };
            }
            return it;
          });
          return {
            ...o,
            items: updatedItems,
            // Adjust subtotal if price delta occurs
            subtotal: o.subtotal + (priceDelta * origItem.quantity),
            total: o.total + (priceDelta * origItem.quantity)
          };
        }
        return o;
      });
    });

    this.addAuditLog(
      'ORDERS',
      'ITEM_SUBSTITUTED',
      order.orderNumber,
      `Substituted ${origItem.name} with ${subProd.name} (Delta: $${priceDelta.toFixed(2)}/unit). Customer consent logged.`
    );
    this.notify(`Substitution approved: ${origItem.name} -> ${subProd.name}. Price difference adjusted.`, 'info');
    return true;
  }

  dispatchOrder(orderId: string, vehicleId: string): void {
    const order = this.orders().find(o => o.id === orderId);
    if (!order) return;

    this.orders.update(orders => {
      return orders.map(o => (o.id === orderId ? { ...o, orderStatus: 'DISPATCHED', assignedVehicleId: vehicleId } : o));
    });

    this.vehicles.update(vehicles => {
      return vehicles.map(v => {
        if (v.id === vehicleId) {
          return {
            ...v,
            status: 'EN_ROUTE',
            assignedOrderIds: Array.from(new Set([...v.assignedOrderIds, orderId]))
          };
        }
        return v;
      });
    });

    this.addAuditLog('ORDERS', 'ORDER_DISPATCHED', order.orderNumber, `Dispatched on vehicle ${vehicleId}. Out for delivery.`);
    this.notify(`Order ${order.orderNumber} dispatched on ${vehicleId}. Live GPS tracking active.`, 'success');
  }

  completeDelivery(orderId: string, signature: string): void {
    const order = this.orders().find(o => o.id === orderId);
    if (!order) return;

    // Deduct physical on-hand and release reservation
    this.inventoryBalances.update(balances => {
      return balances.map(b => {
        const item = order.items.find(i => i.productId === b.productId && b.locationId === order.storeId);
        if (item) {
          return {
            ...b,
            onHand: Math.max(0, b.onHand - item.quantity),
            reserved: Math.max(0, b.reserved - item.quantity)
          };
        }
        return b;
      });
    });

    // Record stock movement
    for (const item of order.items) {
      const curBal = this.inventoryBalances().find(b => b.productId === item.productId && b.locationId === order.storeId)?.onHand || 0;
      const movement: StockMovement = {
        id: `sm-${Date.now()}-${item.productId}`,
        timestamp: new Date().toISOString(),
        productId: item.productId,
        productSku: item.sku,
        productName: item.name,
        locationId: order.storeId,
        type: 'DISPATCH',
        delta: -item.quantity,
        balanceAfter: curBal,
        reason: `Delivered Customer Order ${order.orderNumber}`,
        performedBy: 'Fleet Dispatcher',
        referenceId: order.orderNumber
      };
      this.stockMovements.update(moves => [movement, ...moves]);
    }

    this.orders.update(orders => {
      return orders.map(o => {
        if (o.id === orderId) {
          return {
            ...o,
            orderStatus: 'DELIVERED',
            paymentStatus: 'CAPTURED',
            proofOfDelivery: {
              signedBy: signature || o.customerName,
              deliveredAt: new Date().toISOString(),
              notes: 'Delivered to front door. Signature captured.'
            }
          };
        }
        return o;
      });
    });

    // Idempotent loyalty point award
    if (order.loyaltyMemberId) {
      const pointsToEarn = Math.floor(order.total);
      this.awardLoyaltyPoints(order.loyaltyMemberId, pointsToEarn, `Earned 1x points on order ${order.orderNumber}`, order.id);
    }

    this.addAuditLog('ORDERS', 'ORDER_DELIVERED', order.orderNumber, `Proof of Delivery confirmed. Signed by ${signature || order.customerName}`);
    this.notify(`Order ${order.orderNumber} marked DELIVERED. POD recorded & loyalty points awarded.`, 'success');
  }

  processReturnAndRefund(
    orderId: string,
    productId: string,
    disposition: 'RESTOCK' | 'DISPOSE',
    reason: string
  ): void {
    const order = this.orders().find(o => o.id === orderId);
    if (!order) return;

    const item = order.items.find(i => i.productId === productId);
    if (!item) return;

    const refundAmount = item.unitPrice * item.quantity;

    // Stock disposition
    if (disposition === 'RESTOCK') {
      this.inventoryBalances.update(balances => {
        return balances.map(b => {
          if (b.productId === productId && b.locationId === order.storeId) {
            return {
              ...b,
              onHand: b.onHand + item.quantity,
              atp: b.atp + item.quantity
            };
          }
          return b;
        });
      });

      const curBal = this.inventoryBalances().find(b => b.productId === productId && b.locationId === order.storeId)?.onHand || 0;
      const movement: StockMovement = {
        id: `sm-${Date.now()}`,
        timestamp: new Date().toISOString(),
        productId,
        productSku: item.sku,
        productName: item.name,
        locationId: order.storeId,
        type: 'RETURN_RESTOCK',
        delta: item.quantity,
        balanceAfter: curBal,
        reason: `Customer return restocked: ${reason}`,
        performedBy: this.currentUser().name,
        referenceId: order.orderNumber
      };
      this.stockMovements.update(moves => [movement, ...moves]);
    } else {
      // Disposed / Damaged
      this.inventoryBalances.update(balances => {
        return balances.map(b => {
          if (b.productId === productId && b.locationId === order.storeId) {
            return {
              ...b,
              damaged: b.damaged + item.quantity
            };
          }
          return b;
        });
      });
    }

    // Update item return status
    this.orders.update(orders => {
      return orders.map(o => {
        if (o.id === orderId) {
          const updatedItems = o.items.map(it => {
            if (it.productId === productId) {
              return {
                ...it,
                returnStatus: disposition === 'RESTOCK' ? ('RETURNED_RESTOCKED' as const) : ('RETURNED_DISPOSED' as const)
              };
            }
            return it;
          });
          return {
            ...o,
            items: updatedItems,
            paymentStatus: 'REFUNDED'
          };
        }
        return o;
      });
    });

    // Reversal of loyalty points
    if (order.loyaltyMemberId) {
      const pointsToReverse = Math.floor(refundAmount);
      this.reverseLoyaltyPoints(
        order.loyaltyMemberId,
        pointsToReverse,
        `Reversed points for returned item (${item.name}) on order ${order.orderNumber}`
      );
    }

    this.addAuditLog(
      'ORDERS',
      'REFUND_PROCESSED',
      order.orderNumber,
      `Refund of $${refundAmount.toFixed(2)} issued. Item ${item.name} disposition: ${disposition}. Reason: ${reason}`
    );
    this.notify(`Refund of $${refundAmount.toFixed(2)} processed. Loyalty points reversed & inventory disposition logged.`, 'warning');
  }

  // --- Pricing Governance ---

  approvePriceRule(ruleId: string): boolean {
    const rule = this.priceRules().find(r => r.id === ruleId);
    if (!rule) return false;

    const user = this.currentUser();
    if (!user.permissions.canApprovePrice) {
      this.notify(`Permission Denied: User role ${user.role} is not authorized to approve price changes.`, 'error');
      this.addAuditLog('ACCESS', 'PERMISSION_DENIED', ruleId, `Role ${user.role} attempted to approve price rule without permission`, 'WARNING');
      return false;
    }

    this.priceRules.update(rules => {
      return rules.map(r => (r.id === ruleId ? { ...r, stage: 'APPROVED', approvedBy: user.name } : r));
    });

    this.addAuditLog('PRICING', 'PRICE_RULE_APPROVED', ruleId, `Approved markdown to $${rule.recommendedPrice.toFixed(2)} (${rule.markdownPct}% off). Approver: ${user.name}`);
    this.notify(`Price rule ${ruleId} approved by ${user.name}. Ready for publication.`, 'success');
    return true;
  }

  publishPriceRule(ruleId: string): boolean {
    const rule = this.priceRules().find(r => r.id === ruleId);
    if (!rule) return false;

    if (rule.stage !== 'APPROVED') {
      this.notify(`Cannot publish: Price rule must be APPROVED first.`, 'warning');
      return false;
    }

    // Apply new price to product
    this.products.update(products => {
      return products.map(p => {
        if (p.id === rule.productId) {
          return {
            ...p,
            currentPrice: rule.recommendedPrice,
            markdownPercent: rule.markdownPct,
            markdownReason: rule.rationale
          };
        }
        return p;
      });
    });

    // Mark as published and confirmed
    this.priceRules.update(rules => {
      return rules.map(r => {
        if (r.id === ruleId) {
          return {
            ...r,
            stage: 'PUBLISHED',
            publishedChannels: {
              shelfESL: true,
              storePOS: true,
              onlineApp: true
            }
          };
        }
        return r;
      });
    });

    this.addAuditLog(
      'PRICING',
      'PRICE_PUBLISHED',
      ruleId,
      `Published new price $${rule.recommendedPrice.toFixed(2)} to Shelf ESL tags, POS terminals, and Online App.`
    );
    this.notify(`Price published: ${rule.productName} updated to $${rule.recommendedPrice.toFixed(2)}. Channels confirmed.`, 'success');
    return true;
  }

  // --- Loyalty Ledger ---

  awardLoyaltyPoints(memberId: string, points: number, description: string, orderId?: string): boolean {
    const member = this.loyaltyMembers().find(m => m.memberId === memberId);
    if (!member) return false;

    // Idempotency check: prevent duplicate awarding for same order and action
    const idempotencyKey = `LOY-EARN-${orderId || Date.now()}`;
    const existing = this.loyaltyLedger().find(l => l.idempotencyKey === idempotencyKey);
    if (existing) {
      this.notify(`Idempotency safeguard: Points already awarded for event ${idempotencyKey}. Replay rejected.`, 'warning');
      return false;
    }

    const newBalance = member.pointsBalance + points;

    this.loyaltyMembers.update(members => {
      return members.map(m => {
        if (m.memberId === memberId) {
          return {
            ...m,
            pointsBalance: newBalance,
            lifetimePoints: m.lifetimePoints + points
          };
        }
        return m;
      });
    });

    const entry: LoyaltyLedgerEntry = {
      id: `loy-${Date.now()}`,
      idempotencyKey,
      memberId,
      timestamp: new Date().toISOString(),
      orderId,
      type: 'EARN_PURCHASE',
      pointsDelta: points,
      balanceAfter: newBalance,
      description,
      reversible: true
    };
    this.loyaltyLedger.update(ledger => [entry, ...ledger]);

    this.addAuditLog('LOYALTY', 'POINTS_AWARDED', memberId, `Awarded ${points} points (New balance: ${newBalance}). Ref: ${idempotencyKey}`);
    return true;
  }

  reverseLoyaltyPoints(memberId: string, points: number, description: string): boolean {
    const member = this.loyaltyMembers().find(m => m.memberId === memberId);
    if (!member) return false;

    const newBalance = Math.max(0, member.pointsBalance - points);

    this.loyaltyMembers.update(members => {
      return members.map(m => {
        if (m.memberId === memberId) {
          return {
            ...m,
            pointsBalance: newBalance
          };
        }
        return m;
      });
    });

    const entry: LoyaltyLedgerEntry = {
      id: `loy-${Date.now()}`,
      idempotencyKey: `LOY-REV-${Date.now()}`,
      memberId,
      timestamp: new Date().toISOString(),
      type: 'RETURN_REVERSAL',
      pointsDelta: -points,
      balanceAfter: newBalance,
      description,
      reversible: false
    };
    this.loyaltyLedger.update(ledger => [entry, ...ledger]);

    this.addAuditLog('LOYALTY', 'POINTS_REVERSED', memberId, `Reversed ${points} points (New balance: ${newBalance}). Reason: ${description}`);
    return true;
  }

  // --- Replenishment & Procurement ---

  generateReplenishmentPO(productId: string, quantity?: number): PurchaseOrder | null {
    const prod = this.products().find(p => p.id === productId);
    const forecast = this.forecasts().find(f => f.productId === productId);
    if (!prod) return null;

    const qty = quantity || (forecast ? forecast.roundedCasePackQty : prod.minOrderQty);
    const poNumber = `PO-${Math.floor(1000 + Math.random() * 9000)}`;

    const newPO: PurchaseOrder = {
      poNumber,
      supplierId: prod.supplierId,
      supplierName: prod.supplierName,
      destinationLocationId: this.selectedFacilityId(),
      destinationName: this.currentFacility().name,
      orderDate: new Date().toISOString().split('T')[0],
      expectedDelivery: new Date(Date.now() + prod.supplierLeadDays * 86400000).toISOString().split('T')[0],
      status: 'APPROVED',
      dockAppointment: 'Dock 03 — 07:00 AM',
      totalCost: prod.costPrice * qty,
      items: [
        {
          productId: prod.id,
          productSku: prod.sku,
          productName: prod.name,
          orderedQty: qty,
          receivedQty: 0,
          unitCost: prod.costPrice,
          caseCount: Math.ceil(qty / prod.packSize)
        }
      ]
    };

    this.purchaseOrders.update(pos => [newPO, ...pos]);

    // Update in-transit balance
    this.inventoryBalances.update(balances => {
      return balances.map(b => {
        if (b.productId === productId && b.locationId === this.selectedFacilityId()) {
          return {
            ...b,
            inTransit: b.inTransit + qty
          };
        }
        return b;
      });
    });

    this.addAuditLog(
      'INTEGRATION',
      'PO_GENERATED_EDI850',
      poNumber,
      `EDI 850 Purchase Order generated for ${prod.supplierName}: ${qty} units of ${prod.name} ($${newPO.totalCost.toFixed(2)})`
    );
    this.notify(`Generated Purchase Order ${poNumber} for ${qty} units of ${prod.name}.`, 'success');
    return newPO;
  }

  // --- Handheld Associate Utilities ---

  queueAssociateOfflineAction(action: Omit<AssociateOfflineAction, 'id' | 'queuedAt' | 'status'>): void {
    const item: AssociateOfflineAction = {
      ...action,
      id: `off-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      queuedAt: new Date().toLocaleTimeString(),
      status: 'PENDING_SYNC'
    };
    this.associateOfflineQueue.update(q => [...q, item]);
    this.notify(`Action queued offline: ${action.actionType}.`, 'warning');
  }

  syncAssociateOfflineQueue(): void {
    const queue = this.associateOfflineQueue();
    if (queue.length === 0) {
      this.notify('No pending offline actions in queue.', 'info');
      return;
    }

    this.associateOfflineQueue.set([]);
    this.addAuditLog('INTEGRATION', 'OFFLINE_QUEUE_SYNCED', 'ASSOCIATE_HANDHELD', `Successfully synchronized ${queue.length} offline operations with host system.`);
    this.notify(`Synchronized ${queue.length} offline scans with central ledger. All invariants verified.`, 'success');
  }

  printZebraLabel(productSku: string, labelType: 'SHELF_TAG' | 'PALLET_TAG' | 'CLEARANCE_TAG'): void {
    const prod = this.products().find(p => p.sku === productSku);
    const zplCode = `^XA\n^FO50,50^A0N,40,40^FDWALMART RETAILOS^FS\n^FO50,100^A0N,30,30^FD${prod ? prod.name : productSku}^FS\n^FO50,150^BY3^BCN,100,Y,N,N^FD${prod ? prod.barcode : '12345678'}^FS\n^FO50,280^A0N,35,35^FDPRICE: $${prod ? prod.currentPrice.toFixed(2) : '0.00'}^FS\n^XZ`;

    this.labelPrinterLogs.update(logs => [
      {
        timestamp: new Date().toLocaleTimeString(),
        labelType,
        zpl: zplCode,
        status: 'PRINTED_SUCCESS'
      },
      ...logs.slice(0, 19)
    ]);

    this.notify(`Zebra ZPL label printed for ${productSku} (${labelType}).`, 'success');
  }

  // --- End-to-End Demo Scenario Engine ---

  advanceDemoStep(): void {
    const currentIndex = this.activeDemoStepIndex();
    const steps = this.demoSteps();

    if (currentIndex >= steps.length) {
      this.notify('Demonstration scenario complete! All 11 phases validated.', 'success');
      return;
    }

    const step = steps[currentIndex];

    // Execute step logic
    switch (step.stepNumber) {
      case 1:
        // Receive Fresh Produce at dock
        this.receiveDockDelivery('PO-4401', 'prod-001', 32, 'LOT-SB-2611C', '2026-11-10', 1);
        step.resultSummary = 'Dock receiving completed: 32 units added to on-hand (Lot LOT-SB-2611C, 24h short dated).';
        break;
      case 2:
        // Put away & ATP update
        step.resultSummary = 'Inventory put-away confirmed to Aisle 04 Tier 2. ATP balance updated to 80 units.';
        this.addAuditLog('INVENTORY', 'PUT_AWAY_CONFIRMED', 'LOT-SB-2611C', 'Pallet placed in Aisle 04 Tier 2 (Bin BIN-PROD-402)');
        this.notify('Step 2: Put-away confirmed. ATP balance updated.', 'success');
        break;
      case 3:
        // Customer places delivery order
        step.resultSummary = 'Order #WMT-ORD-9821 submitted by Elena Rostova ($36.42 total, Walmart+ member).';
        this.notify('Step 3: Customer order placed with loyalty account.', 'info');
        break;
      case 4: {
        // Transactional stock reservation
        const ord9821 = this.orders().find(o => o.id === 'ord-9821');
        if (ord9821) {
          this.reserveStockForOrder(ord9821);
        }
        step.resultSummary = 'Stock reserved: Strawberries (-2), Avocados (-1), Honeycrisp (-3), Milk (-1), Bread (-1).';
        break;
      }
      case 5:
        // Associate wave picking & scan verification
        this.pickOrderItem('ord-9821', 'prod-001', '078742351982');
        this.pickOrderItem('ord-9821', 'prod-002', '033383401201');
        this.pickOrderItem('ord-9821', 'prod-005', '078742352217');
        this.pickOrderItem('ord-9821', 'prod-007', '078742358899');
        step.resultSummary = '4 of 5 items picked with barcode verification in Aisle order.';
        this.notify('Step 5: Associate picked 4 items. Honeycrisp requires substitution.', 'info');
        break;
      case 6:
        // Substitution approved: Honeycrisp -> Fuji
        this.substituteOrderItem('ord-9821', 'prod-003', 'prod-004', 'Honeycrisp out of stock on shelf; substituted with premium Fuji Apples');
        step.resultSummary = 'Honeycrisp substituted with Fuji Apples. Customer consent logged, price adjusted (-$2.40).';
        break;
      case 7:
        // Staged & dispatched to cold van
        this.dispatchOrder('ord-9821', 'veh-van-102');
        step.resultSummary = 'Totes staged in CHILLED-C2 and dispatched on Refrigerated Van-102 (2.4°C nominal).';
        break;
      case 8:
        // Delivered & idempotent loyalty awarded
        this.completeDelivery('ord-9821', 'Elena Rostova (Digital Signature)');
        step.resultSummary = 'Delivery completed. POD recorded. 36 loyalty points awarded with idempotent key LOY-EARN-ord-9821.';
        break;
      case 9:
        // Short-dated markdown approved & published
        this.approvePriceRule('pr-001');
        this.publishPriceRule('pr-001');
        step.resultSummary = 'Remaining 18 units of Lot LOT-SB-2611A discounted by 35% ($3.48 -> $2.26). ESL tags synced.';
        break;
      case 10: {
        // Replenishment triggered
        const po = this.generateReplenishmentPO('prod-003', 75);
        step.resultSummary = `Reorder point breach detected (28 on-hand < 60 ROP). Generated Purchase Order ${po ? po.poNumber : 'PO-NEW'} for 75 lbs.`;
        break;
      }
      case 11:
        // Return, refund, and loyalty reversal
        this.processReturnAndRefund('ord-9821', 'prod-001', 'RESTOCK', 'Customer received duplicate pack');
        step.resultSummary = 'Customer return processed ($3.48 refunded). Restocked to inventory, 3 points reversed from loyalty ledger.';
        break;
    }

    step.status = 'COMPLETED';
    this.demoSteps.set([...steps]);
    this.activeDemoStepIndex.set(currentIndex + 1);
  }

  resetDemoScenario(): void {
    // Reset all state back to initial seed
    this.facilities.set(INITIAL_FACILITIES);
    this.products.set(INITIAL_PRODUCTS);
    this.inventoryBalances.set(INITIAL_INVENTORY_BALANCES);
    this.stockMovements.set(INITIAL_STOCK_MOVEMENTS);
    this.purchaseOrders.set(INITIAL_PURCHASE_ORDERS);
    this.forecasts.set(INITIAL_REPLENISHMENT_FORECASTS);
    this.orders.set(INITIAL_ORDERS);
    this.vehicles.set(INITIAL_VEHICLES);
    this.routeStops.set(INITIAL_ROUTE_STOPS);
    this.priceRules.set(INITIAL_PRICE_RULES);
    this.loyaltyMembers.set(INITIAL_LOYALTY_MEMBERS);
    this.loyaltyLedger.set(INITIAL_LOYALTY_LEDGER);
    this.auditLogs.set(INITIAL_AUDIT_LOGS);

    const steps = this.demoSteps().map(s => ({
      ...s,
      status: 'PENDING' as const,
      resultSummary: undefined
    }));
    this.demoSteps.set(steps);
    this.activeDemoStepIndex.set(0);
    this.notify('Demo scenario and system state reset to initial baseline.', 'info');
  }

  // --- Failure Mode Sandbox Triggers ---

  triggerFailureScenario(type: 'DUPLICATE_MESSAGE' | 'PAYMENT_FAILURE' | 'PARTIAL_RECEIPT' | 'NEGATIVE_STOCK' | 'EXPIRED_COUPON'): void {
    switch (type) {
      case 'DUPLICATE_MESSAGE': {
        const attemptedKey = 'LOY-EARN-ord-9810';
        this.addAuditLog('INTEGRATION', 'DUPLICATE_PAYLOAD_DETECTED', attemptedKey, 'Inbound message rejected by idempotent filter: event already processed.', 'WARNING');
        this.notify('Idempotency Test Passed: Duplicate event LOY-EARN-ord-9810 safely dropped without double-crediting.', 'warning');
        break;
      }

      case 'PAYMENT_FAILURE':
        this.addAuditLog('ORDERS', 'PAYMENT_AUTH_DECLINED', 'WMT-ORD-9829', 'Payment gateway rejected charge (Card declined: NSF_402). Stock reservation released.', 'CRITICAL');
        this.notify('Failure Handled: Payment card declined. Automatic transaction rollback executed; inventory unlocked.', 'error');
        break;

      case 'PARTIAL_RECEIPT':
        this.addAuditLog('INVENTORY', 'RECEIPT_DISCREPANCY_FLAGGED', 'PO-4401', 'Dock scanner logged: 32 units received vs 64 invoiced. Discrepancy report sent to vendor Pacific Berry.', 'WARNING');
        this.notify('Discrepancy Caught: Dock receipt logged 50% shortage. Vendor discrepancy claim initiated.', 'warning');
        break;

      case 'NEGATIVE_STOCK':
        this.notify('Invariant Guard: Prevented negative stock adjustment. On-hand quantity cannot drop below 0.', 'error');
        this.addAuditLog('INVENTORY', 'INSUFFICIENT_STOCK_BLOCKED', 'prod-003', 'Transaction blocked: requested dispatch 40 exceeds Available to Promise 16.', 'CRITICAL');
        break;

      case 'EXPIRED_COUPON':
        this.notify('Validation Error: Coupon code FALLPRODUCE20 expired on 2026-10-31. Replay rejected.', 'error');
        this.addAuditLog('LOYALTY', 'COUPON_REPLAY_REJECTED', 'FALLPRODUCE20', 'Attempted checkout with expired coupon.', 'WARNING');
        break;
    }
  }
}
