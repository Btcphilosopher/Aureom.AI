import { TestBed } from '@angular/core/testing';
import { RetailStateService } from './retail-state.service';
import { CustomerOrder } from '../models/retail.types';

describe('RetailStateService Domain Logic Tests', () => {
  let service: RetailStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RetailStateService]
    });
    service = TestBed.inject(RetailStateService);
    service.resetDemoScenario();
  });

  it('1. Inventory: dock receipt updates onHand, atp, and appends immutable ledger', () => {
    const initialStrawberries = service.inventoryBalances().find(
      b => b.productId === 'prod-001' && b.locationId === 'fac-1042'
    );
    const initialOnHand = initialStrawberries?.onHand || 0;
    const initialAtp = initialStrawberries?.atp || 0;

    service.receiveDockDelivery('PO-4401', 'prod-001', 32, 'LOT-TEST-01', '2026-11-20', 11);

    const updated = service.inventoryBalances().find(
      b => b.productId === 'prod-001' && b.locationId === 'fac-1042'
    );
    expect(updated?.onHand).toBe(initialOnHand + 32);
    expect(updated?.atp).toBe(initialAtp + 32);

    const lastMovement = service.stockMovements()[0];
    expect(lastMovement.type).toBe('RECEIPT');
    expect(lastMovement.delta).toBe(32);
  });

  it('2. Reservations: transactionally reserves inventory and rejects when ATP is insufficient', () => {
    const mockOrder: CustomerOrder = {
      id: 'ord-test-99',
      orderNumber: 'WMT-ORD-TEST-99',
      channel: 'ONLINE_DELIVERY',
      storeId: 'fac-1042',
      customerName: 'Test Customer',
      customerEmail: 'test@example.com',
      customerPhone: '555-0100',
      placedAt: new Date().toISOString(),
      deliveryWindow: '10:00 - 12:00',
      orderStatus: 'PENDING_RESERVATION',
      paymentStatus: 'AUTHORIZED',
      paymentIdempotencyKey: 'PAY-TEST-99',
      subtotal: 10,
      tax: 1,
      total: 11,
      items: [
        {
          productId: 'prod-001',
          sku: 'WMT-STR-01',
          barcode: '078742351982',
          name: 'Strawberries',
          quantity: 4,
          unitPrice: 3.48,
          isPicked: false
        }
      ]
    };

    const initialAtp = service.inventoryBalances().find(b => b.productId === 'prod-001' && b.locationId === 'fac-1042')?.atp || 0;
    const success = service.reserveStockForOrder(mockOrder);

    expect(success).toBe(true);
    const updatedAtp = service.inventoryBalances().find(b => b.productId === 'prod-001' && b.locationId === 'fac-1042')?.atp || 0;
    expect(updatedAtp).toBe(initialAtp - 4);

    // Attempting impossible quantity exceeding ATP must fail
    mockOrder.items[0].quantity = 999999;
    const failAttempt = service.reserveStockForOrder(mockOrder);
    expect(failAttempt).toBe(false);
  });

  it('3. Access Control & Pricing: denies price approval to Inventory Associate, allows Store Manager', () => {
    service.setUserRole('Inventory Associate');
    const denied = service.approvePriceRule('pr-001');
    expect(denied).toBe(false);
    expect(service.priceRules().find(r => r.id === 'pr-001')?.stage).toBe('RECOMMENDED');

    service.setUserRole('Store Manager');
    const approved = service.approvePriceRule('pr-001');
    expect(approved).toBe(true);
    expect(service.priceRules().find(r => r.id === 'pr-001')?.stage).toBe('APPROVED');
  });

  it('4. Loyalty: awards points and enforces idempotency preventing double-award replay', () => {
    const memberId = 'WMT-8849-01';
    const initialPoints = service.loyaltyMembers().find(m => m.memberId === memberId)?.pointsBalance || 0;

    const firstAttempt = service.awardLoyaltyPoints(memberId, 50, 'Purchase points', 'ord-test-unique');
    expect(firstAttempt).toBe(true);

    const balanceAfter = service.loyaltyMembers().find(m => m.memberId === memberId)?.pointsBalance || 0;
    expect(balanceAfter).toBe(initialPoints + 50);

    // Duplicate replay with same orderId must be dropped
    const duplicateAttempt = service.awardLoyaltyPoints(memberId, 50, 'Purchase points', 'ord-test-unique');
    expect(duplicateAttempt).toBe(false);
    expect(service.loyaltyMembers().find(m => m.memberId === memberId)?.pointsBalance).toBe(balanceAfter);
  });

  it('5. Refunds & Returns: reverses points and handles restock disposition', () => {
    const memberId = 'WMT-8849-01';
    const initialPoints = service.loyaltyMembers().find(m => m.memberId === memberId)?.pointsBalance || 0;

    service.reverseLoyaltyPoints(memberId, 15, 'Customer return clawback');
    const balanceAfter = service.loyaltyMembers().find(m => m.memberId === memberId)?.pointsBalance || 0;
    expect(balanceAfter).toBe(initialPoints - 15);
  });
});
