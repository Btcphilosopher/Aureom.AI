import {
  Facility,
  Product,
  InventoryBalance,
  StockMovement,
  PurchaseOrder,
  ReplenishmentForecast,
  CustomerOrder,
  DeliveryVehicle,
  PriceRule,
  LoyaltyMember,
  LoyaltyLedgerEntry,
  AuditLogEntry,
  DeliveryRouteStop
} from '../models/retail.types';

export const INITIAL_FACILITIES: Facility[] = [
  {
    id: 'fac-1042',
    code: 'ST-1042',
    name: 'Supercenter #1042 - Bentonville Central',
    type: 'SUPERCENTER',
    address: '406 S Walton Blvd',
    city: 'Bentonville',
    state: 'AR',
    activeAssociates: 142,
    shelfCapacitySqFt: 185000,
    capacityUtilizationPct: 82.4,
    coldChainSensorsCount: 38,
    tempStatus: 'NOMINAL',
    avgTempFahrenheit: 34.6
  },
  {
    id: 'fac-3841',
    code: 'NM-3841',
    name: 'Neighborhood Market #3841 - Rogers North',
    type: 'NEIGHBORHOOD_MARKET',
    address: '2110 W Walnut St',
    city: 'Rogers',
    state: 'AR',
    activeAssociates: 58,
    shelfCapacitySqFt: 42000,
    capacityUtilizationPct: 76.1,
    coldChainSensorsCount: 16,
    tempStatus: 'NOMINAL',
    avgTempFahrenheit: 35.1
  },
  {
    id: 'fac-6014',
    code: 'RDC-6014',
    name: 'Regional DC #6014 - Dallas South Crossdock',
    type: 'RDC',
    address: '9200 Logistics Pkwy',
    city: 'Dallas',
    state: 'TX',
    activeAssociates: 310,
    shelfCapacitySqFt: 850000,
    capacityUtilizationPct: 88.9,
    coldChainSensorsCount: 74,
    tempStatus: 'NOMINAL',
    avgTempFahrenheit: 33.8
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-001',
    sku: 'WMT-STR-01',
    barcode: '078742351982',
    name: 'Fresh California Strawberries (16 oz)',
    category: 'Fresh Produce',
    unit: 'pack',
    packSize: 8, // 8 clamshells per master case
    costPrice: 1.85,
    basePrice: 3.48,
    currentPrice: 3.48,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: false,
    temperatureClass: 'CHILLED',
    supplierId: 'sup-berry-01',
    supplierName: 'Pacific Berry Growers Co-op',
    reorderPoint: 40,
    safetyStock: 20,
    supplierLeadDays: 2,
    minOrderQty: 32
  },
  {
    id: 'prod-002',
    sku: 'WMT-AVO-02',
    barcode: '033383401201',
    name: 'Organic Hass Avocados (Bag of 4)',
    category: 'Fresh Produce',
    unit: 'pack',
    packSize: 12,
    costPrice: 2.10,
    basePrice: 4.24,
    currentPrice: 4.24,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: false,
    temperatureClass: 'AMBIENT',
    supplierId: 'sup-organics-02',
    supplierName: 'Valley Verde Fresh Produce',
    reorderPoint: 35,
    safetyStock: 15,
    supplierLeadDays: 3,
    minOrderQty: 24
  },
  {
    id: 'prod-003',
    sku: 'WMT-HON-03',
    barcode: '041220881903',
    name: 'Organic Honeycrisp Apples',
    category: 'Fresh Produce',
    unit: 'lb',
    packSize: 25, // 25 lb box
    costPrice: 1.45,
    basePrice: 2.98,
    currentPrice: 2.98,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: true,
    temperatureClass: 'AMBIENT',
    supplierId: 'sup-organics-02',
    supplierName: 'Valley Verde Fresh Produce',
    reorderPoint: 60,
    safetyStock: 25,
    supplierLeadDays: 3,
    minOrderQty: 50
  },
  {
    id: 'prod-004',
    sku: 'WMT-FUJ-04',
    barcode: '041220881910',
    name: 'Washington Crisp Fuji Apples',
    category: 'Fresh Produce',
    unit: 'lb',
    packSize: 25,
    costPrice: 1.10,
    basePrice: 2.18,
    currentPrice: 2.18,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: true,
    temperatureClass: 'AMBIENT',
    supplierId: 'sup-organics-02',
    supplierName: 'Valley Verde Fresh Produce',
    reorderPoint: 50,
    safetyStock: 20,
    supplierLeadDays: 3,
    minOrderQty: 50
  },
  {
    id: 'prod-005',
    sku: 'WMT-MLK-05',
    barcode: '078742352217',
    name: 'Great Value Whole Vitamin D Milk (1 Gallon)',
    category: 'Dairy & Eggs',
    unit: 'unit',
    packSize: 4,
    costPrice: 2.15,
    basePrice: 3.12,
    currentPrice: 3.12,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: false,
    temperatureClass: 'CHILLED',
    supplierId: 'sup-dairy-03',
    supplierName: 'Ozark Creameries LLC',
    reorderPoint: 80,
    safetyStock: 40,
    supplierLeadDays: 1,
    minOrderQty: 48
  },
  {
    id: 'prod-006',
    sku: 'WMT-RIB-06',
    barcode: '021894401824',
    name: 'Choice Angus Beef Ribeye Steak (USDA Choice)',
    category: 'Meat & Seafood',
    unit: 'lb',
    packSize: 10,
    costPrice: 8.90,
    basePrice: 14.98,
    currentPrice: 14.98,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: true,
    temperatureClass: 'CHILLED',
    supplierId: 'sup-meat-04',
    supplierName: 'Midwest Prime Meats',
    reorderPoint: 25,
    safetyStock: 10,
    supplierLeadDays: 2,
    minOrderQty: 20
  },
  {
    id: 'prod-007',
    sku: 'WMT-BRD-07',
    barcode: '078742358899',
    name: 'Artisan Country French Sourdough Boule',
    category: 'Bakery',
    unit: 'unit',
    packSize: 12,
    costPrice: 1.40,
    basePrice: 3.28,
    currentPrice: 3.28,
    taxCategory: 'GROCERY_EXEMPT',
    isWeighted: false,
    temperatureClass: 'AMBIENT',
    supplierId: 'sup-bakery-05',
    supplierName: 'Heritage Bakery Works',
    reorderPoint: 30,
    safetyStock: 12,
    supplierLeadDays: 1,
    minOrderQty: 24
  },
  {
    id: 'prod-008',
    sku: 'WMT-PPR-08',
    barcode: '037000762411',
    name: 'Bounty Select-a-Size Paper Towels (12 Double Rolls)',
    category: 'Household',
    unit: 'pack',
    packSize: 6,
    costPrice: 14.20,
    basePrice: 22.48,
    currentPrice: 22.48,
    taxCategory: 'STANDARD_TAX',
    isWeighted: false,
    temperatureClass: 'AMBIENT',
    supplierId: 'sup-cpg-06',
    supplierName: 'Procter & Gamble Direct',
    reorderPoint: 45,
    safetyStock: 20,
    supplierLeadDays: 4,
    minOrderQty: 30
  }
];

export const INITIAL_INVENTORY_BALANCES: InventoryBalance[] = [
  {
    productId: 'prod-001',
    locationId: 'fac-1042',
    onHand: 56,
    reserved: 8,
    atp: 48,
    inTransit: 64,
    quarantined: 0,
    damaged: 2,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-SB-2611A',
        expiryDate: '2026-11-10', // Short dated! 24h away
        daysToExpiry: 1,
        quantity: 18,
        status: 'SHORT_DATED',
        aisle: 'Aisle 04',
        shelf: 'Tier 2',
        bin: 'BIN-PROD-402',
        receivedDate: '2026-11-06'
      },
      {
        lotNumber: 'LOT-SB-2611B',
        expiryDate: '2026-11-15',
        daysToExpiry: 6,
        quantity: 38,
        status: 'FRESH',
        aisle: 'Aisle 04',
        shelf: 'Tier 3',
        bin: 'BIN-PROD-404',
        receivedDate: '2026-11-08'
      }
    ]
  },
  {
    productId: 'prod-002',
    locationId: 'fac-1042',
    onHand: 42,
    reserved: 4,
    atp: 38,
    inTransit: 36,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-AV-991',
        expiryDate: '2026-11-18',
        daysToExpiry: 9,
        quantity: 42,
        status: 'FRESH',
        aisle: 'Aisle 02',
        shelf: 'Tier 1',
        bin: 'BIN-PROD-201',
        receivedDate: '2026-11-07'
      }
    ]
  },
  {
    productId: 'prod-003',
    locationId: 'fac-1042',
    onHand: 28, // Low stock, near ROP of 60
    reserved: 12,
    atp: 16,
    inTransit: 0,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-AP-701',
        expiryDate: '2026-11-20',
        daysToExpiry: 11,
        quantity: 28,
        status: 'FRESH',
        aisle: 'Aisle 03',
        shelf: 'Tier 2',
        bin: 'BIN-PROD-302',
        receivedDate: '2026-11-05'
      }
    ]
  },
  {
    productId: 'prod-004',
    locationId: 'fac-1042',
    onHand: 95,
    reserved: 6,
    atp: 89,
    inTransit: 50,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-FJ-804',
        expiryDate: '2026-11-22',
        daysToExpiry: 13,
        quantity: 95,
        status: 'FRESH',
        aisle: 'Aisle 03',
        shelf: 'Tier 1',
        bin: 'BIN-PROD-301',
        receivedDate: '2026-11-07'
      }
    ]
  },
  {
    productId: 'prod-005',
    locationId: 'fac-1042',
    onHand: 110,
    reserved: 14,
    atp: 96,
    inTransit: 96,
    quarantined: 0,
    damaged: 1,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-MK-512',
        expiryDate: '2026-11-19',
        daysToExpiry: 10,
        quantity: 110,
        status: 'FRESH',
        aisle: 'Dairy Cooler 01',
        shelf: 'Row 3',
        bin: 'BIN-DRY-101',
        receivedDate: '2026-11-08'
      }
    ]
  },
  {
    productId: 'prod-006',
    locationId: 'fac-1042',
    onHand: 34,
    reserved: 5,
    atp: 29,
    inTransit: 30,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-RB-302',
        expiryDate: '2026-11-14',
        daysToExpiry: 5,
        quantity: 34,
        status: 'FRESH',
        aisle: 'Meat Case 02',
        shelf: 'Tier 1',
        bin: 'BIN-MT-201',
        receivedDate: '2026-11-08'
      }
    ]
  },
  {
    productId: 'prod-007',
    locationId: 'fac-1042',
    onHand: 38,
    reserved: 6,
    atp: 32,
    inTransit: 24,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-SD-109',
        expiryDate: '2026-11-11',
        daysToExpiry: 2,
        quantity: 38,
        status: 'SHORT_DATED',
        aisle: 'Bakery Rack 01',
        shelf: 'Tier 2',
        bin: 'BIN-BK-102',
        receivedDate: '2026-11-08'
      }
    ]
  },
  {
    productId: 'prod-008',
    locationId: 'fac-1042',
    onHand: 72,
    reserved: 8,
    atp: 64,
    inTransit: 60,
    quarantined: 0,
    damaged: 0,
    expired: 0,
    lots: [
      {
        lotNumber: 'LOT-PP-440',
        expiryDate: '2029-12-31',
        daysToExpiry: 1100,
        quantity: 72,
        status: 'FRESH',
        aisle: 'Aisle 14',
        shelf: 'Pallet Rack',
        bin: 'BIN-HH-140',
        receivedDate: '2026-11-01'
      }
    ]
  }
];

export const INITIAL_STOCK_MOVEMENTS: StockMovement[] = [
  {
    id: 'sm-8841',
    timestamp: '2026-11-09T04:15:00Z',
    productId: 'prod-001',
    productSku: 'WMT-STR-01',
    productName: 'Fresh California Strawberries (16 oz)',
    locationId: 'fac-1042',
    type: 'RECEIPT',
    delta: +32,
    balanceAfter: 56,
    reason: 'Dock Receipt PO-4401 Pacific Berry',
    performedBy: 'Marcus Vance (Associate)',
    referenceId: 'PO-4401'
  },
  {
    id: 'sm-8840',
    timestamp: '2026-11-09T03:30:00Z',
    productId: 'prod-001',
    productSku: 'WMT-STR-01',
    productName: 'Fresh California Strawberries (16 oz)',
    locationId: 'fac-1042',
    type: 'DAMAGE_WRITEOFF',
    delta: -2,
    balanceAfter: 24,
    reason: 'Bruised in transit crate - quarantine disposal',
    performedBy: 'Marcus Vance (Associate)',
    referenceId: 'DISP-992'
  },
  {
    id: 'sm-8839',
    timestamp: '2026-11-08T22:10:00Z',
    productId: 'prod-005',
    productSku: 'WMT-MLK-05',
    productName: 'Great Value Whole Vitamin D Milk (1 Gallon)',
    locationId: 'fac-1042',
    type: 'CYCLE_COUNT',
    delta: +4,
    balanceAfter: 110,
    reason: 'Night shift cycle count variance reconciliation',
    performedBy: 'Alicia Chen (Team Lead)',
    referenceId: 'CC-1042-08'
  },
  {
    id: 'sm-8838',
    timestamp: '2026-11-08T19:44:00Z',
    productId: 'prod-006',
    productSku: 'WMT-RIB-06',
    productName: 'Choice Angus Beef Ribeye Steak (USDA Choice)',
    locationId: 'fac-1042',
    type: 'DISPATCH',
    delta: -4,
    balanceAfter: 34,
    reason: 'Online delivery dispatch Wave #W-402',
    performedBy: 'Devon Barnes (Picker)',
    referenceId: 'ORD-9810'
  }
];

export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    poNumber: 'PO-4401',
    supplierId: 'sup-berry-01',
    supplierName: 'Pacific Berry Growers Co-op',
    destinationLocationId: 'fac-1042',
    destinationName: 'Supercenter #1042',
    orderDate: '2026-11-07',
    expectedDelivery: '2026-11-09',
    status: 'PARTIALLY_RECEIVED',
    dockAppointment: 'Dock 04 — 06:30 AM',
    totalCost: 118.40,
    discrepancyNote: 'Ordered 8 cases (64 units), received 4 cases (32 units). Remaining 4 cases scheduled for 14:00 delivery.',
    items: [
      {
        productId: 'prod-001',
        productSku: 'WMT-STR-01',
        productName: 'Fresh California Strawberries (16 oz)',
        orderedQty: 64,
        receivedQty: 32,
        unitCost: 1.85,
        caseCount: 8,
        lotAssigned: 'LOT-SB-2611B',
        expiryAssigned: '2026-11-15'
      }
    ]
  },
  {
    poNumber: 'PO-4402',
    supplierId: 'sup-organics-02',
    supplierName: 'Valley Verde Fresh Produce',
    destinationLocationId: 'fac-1042',
    destinationName: 'Supercenter #1042',
    orderDate: '2026-11-08',
    expectedDelivery: '2026-11-10',
    status: 'IN_TRANSIT',
    dockAppointment: 'Dock 02 — 09:00 AM',
    totalCost: 147.50,
    items: [
      {
        productId: 'prod-003',
        productSku: 'WMT-HON-03',
        productName: 'Organic Honeycrisp Apples',
        orderedQty: 50,
        receivedQty: 0,
        unitCost: 1.45,
        caseCount: 2
      },
      {
        productId: 'prod-002',
        productSku: 'WMT-AVO-02',
        productName: 'Organic Hass Avocados (Bag of 4)',
        orderedQty: 36,
        receivedQty: 0,
        unitCost: 2.10,
        caseCount: 3
      }
    ]
  },
  {
    poNumber: 'PO-4403',
    supplierId: 'sup-dairy-03',
    supplierName: 'Ozark Creameries LLC',
    destinationLocationId: 'fac-1042',
    destinationName: 'Supercenter #1042',
    orderDate: '2026-11-08',
    expectedDelivery: '2026-11-10',
    status: 'APPROVED',
    dockAppointment: 'Dock 01 — 05:00 AM (Cold Chain)',
    totalCost: 206.40,
    items: [
      {
        productId: 'prod-005',
        productSku: 'WMT-MLK-05',
        productName: 'Great Value Whole Vitamin D Milk (1 Gallon)',
        orderedQty: 96,
        receivedQty: 0,
        unitCost: 2.15,
        caseCount: 24
      }
    ]
  }
];

export const INITIAL_REPLENISHMENT_FORECASTS: ReplenishmentForecast[] = [
  {
    productId: 'prod-001',
    productName: 'Fresh California Strawberries (16 oz)',
    currentOnHand: 56,
    currentATP: 48,
    reorderPoint: 40,
    safetyStock: 20,
    avgDailySales: 22,
    underlyingDemand: 25.5, // 2 stockout days suppressed observed sales
    stockoutDaysLast30: 2,
    seasonalityMultiplier: 1.20, // Weekend fresh berry promo
    forecastDailyDemand: 30.6,
    recommendedOrderQty: 64,
    roundedCasePackQty: 64, // Multiples of 8
    leadTimeDays: 2,
    shelfCapacityMax: 96,
    expiryRiskScore: 'MEDIUM'
  },
  {
    productId: 'prod-003',
    productName: 'Organic Honeycrisp Apples',
    currentOnHand: 28,
    currentATP: 16,
    reorderPoint: 60, // Below ROP! Trigger replenishment immediately
    safetyStock: 25,
    avgDailySales: 18,
    underlyingDemand: 22.0,
    stockoutDaysLast30: 4,
    seasonalityMultiplier: 1.15,
    forecastDailyDemand: 25.3,
    recommendedOrderQty: 75,
    roundedCasePackQty: 75, // Multiples of 25 lb case
    leadTimeDays: 3,
    shelfCapacityMax: 120,
    expiryRiskScore: 'LOW'
  },
  {
    productId: 'prod-005',
    productName: 'Great Value Whole Vitamin D Milk (1 Gallon)',
    currentOnHand: 110,
    currentATP: 96,
    reorderPoint: 80,
    safetyStock: 40,
    avgDailySales: 34,
    underlyingDemand: 34.0,
    stockoutDaysLast30: 0,
    seasonalityMultiplier: 1.05,
    forecastDailyDemand: 35.7,
    recommendedOrderQty: 96,
    roundedCasePackQty: 96,
    leadTimeDays: 1,
    shelfCapacityMax: 160,
    expiryRiskScore: 'LOW'
  },
  {
    productId: 'prod-006',
    productName: 'Choice Angus Beef Ribeye Steak',
    currentOnHand: 34,
    currentATP: 29,
    reorderPoint: 25,
    safetyStock: 10,
    avgDailySales: 8,
    underlyingDemand: 9.2,
    stockoutDaysLast30: 1,
    seasonalityMultiplier: 1.30, // Weekend grilling spike
    forecastDailyDemand: 12.0,
    recommendedOrderQty: 30,
    roundedCasePackQty: 30,
    leadTimeDays: 2,
    shelfCapacityMax: 50,
    expiryRiskScore: 'HIGH'
  }
];

export const INITIAL_ORDERS: CustomerOrder[] = [
  {
    id: 'ord-9821',
    orderNumber: 'WMT-ORD-9821',
    channel: 'ONLINE_DELIVERY',
    storeId: 'fac-1042',
    customerName: 'Elena Rostova',
    customerEmail: 'elena.rostova@example.com',
    customerPhone: '(479) 555-0144',
    loyaltyMemberId: 'WMT-8849-01',
    placedAt: '2026-11-09T04:45:00Z',
    deliveryWindow: '08:00 - 10:00 AM',
    deliveryAddress: '712 NW A St, Bentonville, AR 72712',
    orderStatus: 'RESERVED',
    paymentStatus: 'AUTHORIZED',
    paymentIdempotencyKey: 'PAY-AUTH-9821-20261109',
    stagingZone: 'CHILLED-C2',
    subtotal: 34.62,
    tax: 1.80,
    total: 36.42,
    assignedVehicleId: 'veh-van-102',
    assignedPicker: 'Devon Barnes',
    items: [
      {
        productId: 'prod-001',
        sku: 'WMT-STR-01',
        barcode: '078742351982',
        name: 'Fresh California Strawberries (16 oz)',
        quantity: 2,
        unitPrice: 3.48,
        isPicked: false
      },
      {
        productId: 'prod-002',
        sku: 'WMT-AVO-02',
        barcode: '033383401201',
        name: 'Organic Hass Avocados (Bag of 4)',
        quantity: 1,
        unitPrice: 4.24,
        isPicked: false
      },
      {
        productId: 'prod-003',
        sku: 'WMT-HON-03',
        barcode: '041220881903',
        name: 'Organic Honeycrisp Apples',
        quantity: 3,
        unitPrice: 2.98,
        isPicked: false
      },
      {
        productId: 'prod-005',
        sku: 'WMT-MLK-05',
        barcode: '078742352217',
        name: 'Great Value Whole Vitamin D Milk (1 Gallon)',
        quantity: 1,
        unitPrice: 3.12,
        isPicked: false
      },
      {
        productId: 'prod-007',
        sku: 'WMT-BRD-07',
        barcode: '078742358899',
        name: 'Artisan Country French Sourdough Boule',
        quantity: 1,
        unitPrice: 3.28,
        isPicked: false
      }
    ]
  },
  {
    id: 'ord-9820',
    orderNumber: 'WMT-ORD-9820',
    channel: 'CLICK_COLLECT',
    storeId: 'fac-1042',
    customerName: 'Marcus Sterling',
    customerEmail: 'm.sterling@example.org',
    customerPhone: '(479) 555-0812',
    loyaltyMemberId: 'WMT-7712-44',
    placedAt: '2026-11-09T03:20:00Z',
    deliveryWindow: 'Curbside Bay 04 (07:30 - 08:30)',
    orderStatus: 'STAGED',
    paymentStatus: 'AUTHORIZED',
    paymentIdempotencyKey: 'PAY-AUTH-9820-20261109',
    stagingZone: 'AMBIENT-A1',
    subtotal: 44.96,
    tax: 3.60,
    total: 48.56,
    assignedPicker: 'Devon Barnes',
    items: [
      {
        productId: 'prod-008',
        sku: 'WMT-PPR-08',
        barcode: '037000762411',
        name: 'Bounty Select-a-Size Paper Towels (12 Double Rolls)',
        quantity: 2,
        unitPrice: 22.48,
        isPicked: true
      }
    ]
  },
  {
    id: 'ord-9819',
    orderNumber: 'WMT-ORD-9819',
    channel: 'ONLINE_DELIVERY',
    storeId: 'fac-1042',
    customerName: 'Samantha Green',
    customerEmail: 'sgreen@example.net',
    customerPhone: '(479) 555-0391',
    placedAt: '2026-11-09T02:15:00Z',
    deliveryWindow: '09:00 - 11:00 AM',
    deliveryAddress: '1405 SE 14th St, Bentonville, AR 72712',
    orderStatus: 'DISPATCHED',
    paymentStatus: 'CAPTURED',
    paymentIdempotencyKey: 'PAY-AUTH-9819-20261109',
    subtotal: 51.04,
    tax: 2.15,
    total: 53.19,
    assignedVehicleId: 'veh-van-102',
    items: [
      {
        productId: 'prod-006',
        sku: 'WMT-RIB-06',
        barcode: '021894401824',
        name: 'Choice Angus Beef Ribeye Steak (USDA Choice)',
        quantity: 2,
        unitPrice: 14.98,
        isPicked: true
      },
      {
        productId: 'prod-005',
        sku: 'WMT-MLK-05',
        barcode: '078742352217',
        name: 'Great Value Whole Vitamin D Milk (1 Gallon)',
        quantity: 2,
        unitPrice: 3.12,
        isPicked: true
      },
      {
        productId: 'prod-007',
        sku: 'WMT-BRD-07',
        barcode: '078742358899',
        name: 'Artisan Country French Sourdough Boule',
        quantity: 1,
        unitPrice: 3.28,
        isPicked: true
      }
    ]
  }
];

export const INITIAL_VEHICLES: DeliveryVehicle[] = [
  {
    id: 'veh-van-102',
    code: 'VAN-102',
    type: 'REFRIGERATED_VAN',
    driverName: 'Carlos Rivera',
    capacityLbs: 2200,
    currentLoadLbs: 480,
    status: 'LOADING',
    currentBatteryOrFuelPct: 88,
    temperatureCelsius: 2.4, // Nominal cold chain
    assignedOrderIds: ['ord-9821', 'ord-9819']
  },
  {
    id: 'veh-van-104',
    code: 'VAN-104',
    type: 'ELECTRIC_VAN',
    driverName: 'Jamal Crawford',
    capacityLbs: 1800,
    currentLoadLbs: 120,
    status: 'IDLE',
    currentBatteryOrFuelPct: 94,
    temperatureCelsius: 18.0,
    assignedOrderIds: []
  },
  {
    id: 'veh-drone-88',
    code: 'DRONE-WING-88',
    type: 'AUTONOMOUS_DRONE',
    driverName: 'Automated Pilot (FAA Part 135)',
    capacityLbs: 5.5,
    currentLoadLbs: 2.8,
    status: 'IDLE',
    currentBatteryOrFuelPct: 96,
    altitudeFt: 180,
    assignedOrderIds: []
  }
];

export const INITIAL_ROUTE_STOPS: DeliveryRouteStop[] = [
  {
    stopNumber: 1,
    orderId: 'ord-9819',
    customerName: 'Samantha Green',
    address: '1405 SE 14th St, Bentonville, AR',
    deliveryWindow: '09:00 - 11:00 AM',
    plannedArrival: '09:18 AM',
    liveEstimate: '09:15 AM',
    weightLbs: 14.2,
    coldChainRequired: true,
    isInfeasible: false,
    status: 'PENDING'
  },
  {
    stopNumber: 2,
    orderId: 'ord-9821',
    customerName: 'Elena Rostova',
    address: '712 NW A St, Bentonville, AR',
    deliveryWindow: '08:00 - 10:00 AM',
    plannedArrival: '09:42 AM',
    liveEstimate: '09:38 AM',
    weightLbs: 9.8,
    coldChainRequired: true,
    isInfeasible: false,
    status: 'PENDING'
  },
  {
    stopNumber: 3,
    orderId: 'ord-demo-inf',
    customerName: 'Rural Farm Route Depot',
    address: '4482 Timber Creek Rd (48 miles out)',
    deliveryWindow: '08:30 - 09:30 AM',
    plannedArrival: '11:15 AM',
    liveEstimate: '11:22 AM (Exceeds Window)',
    weightLbs: 85.0,
    coldChainRequired: false,
    isInfeasible: true,
    infeasibleReason: 'Transit time 68 mins exceeds 09:30 delivery window constraint. Route optimizer flagged stop for redelivery re-assignment.',
    status: 'PENDING'
  }
];

export const INITIAL_PRICE_RULES: PriceRule[] = [
  {
    id: 'pr-001',
    productId: 'prod-001',
    productName: 'Fresh California Strawberries (16 oz)',
    sku: 'WMT-STR-01',
    storeScope: 'STORE_1042',
    ruleType: 'EXPIRY_MARKDOWN',
    basePrice: 3.48,
    recommendedPrice: 2.26, // 35% discount
    currentFloorPrice: 1.95, // Cost 1.85 + 0.10 margin floor
    markdownPct: 35,
    stage: 'RECOMMENDED',
    effectiveFrom: '2026-11-09T06:00:00Z',
    effectiveTo: '2026-11-10T23:59:59Z',
    rationale: 'Lot LOT-SB-2611A (18 units) has 24h remaining shelf life. Expiry algorithm recommends 35% markdown to clear inventory before spoilage loss.',
    requestedBy: 'Automated Pricing Engine',
    publishedChannels: {
      shelfESL: false,
      storePOS: false,
      onlineApp: false
    }
  },
  {
    id: 'pr-002',
    productId: 'prod-003',
    productName: 'Organic Honeycrisp Apples',
    sku: 'WMT-HON-03',
    storeScope: 'ALL_NETWORK',
    ruleType: 'COMPETITOR_MATCH',
    basePrice: 2.98,
    competitorPrice: {
      competitor: 'Target',
      observedPrice: 2.69,
      scrapedAt: '2026-11-09T03:00:00Z'
    },
    recommendedPrice: 2.68,
    currentFloorPrice: 1.65,
    markdownPct: 10,
    stage: 'PUBLISHED',
    effectiveFrom: '2026-11-08T00:00:00Z',
    effectiveTo: '2026-11-15T23:59:59Z',
    rationale: 'Automated price match against Target Bentonville ($2.69/lb). Retains Everyday Low Price guarantee with 41% gross margin.',
    requestedBy: 'Pricing Analyst (Jordan Reed)',
    approvedBy: 'Regional Director (Sarah Morales)',
    publishedChannels: {
      shelfESL: true,
      storePOS: true,
      onlineApp: true
    }
  },
  {
    id: 'pr-003',
    productId: 'prod-007',
    productName: 'Artisan Country French Sourdough Boule',
    sku: 'WMT-BRD-07',
    storeScope: 'STORE_1042',
    ruleType: 'EXPIRY_MARKDOWN',
    basePrice: 3.28,
    recommendedPrice: 1.98,
    currentFloorPrice: 1.50,
    markdownPct: 40,
    stage: 'APPROVED',
    effectiveFrom: '2026-11-09T07:00:00Z',
    effectiveTo: '2026-11-11T20:00:00Z',
    rationale: 'Daily fresh bakery bake clearance (Lot LOT-SD-109, 38 units). 40% reduction prevents food waste.',
    requestedBy: 'Bakery Dept Manager',
    approvedBy: 'Store Manager #1042',
    publishedChannels: {
      shelfESL: false,
      storePOS: true,
      onlineApp: false
    }
  }
];

export const INITIAL_LOYALTY_MEMBERS: LoyaltyMember[] = [
  {
    id: 'mem-001',
    memberId: 'WMT-8849-01',
    barcode: '400188490104',
    fullName: 'Elena Rostova',
    tier: 'Walmart+ Member',
    pointsBalance: 1240, // Worth $12.40
    lifetimePoints: 6850,
    joinedDate: '2025-03-14',
    communicationOptIn: true,
    purchaseDataUsageConsent: true,
    activeCoupons: [
      {
        code: 'SPARKFRESH10',
        description: '$10 off fresh produce order over $30',
        discountAmount: 10.00,
        minSpend: 30.00,
        expiryDate: '2026-11-30',
        used: false
      },
      {
        code: 'ORGANIC2OFF',
        description: '$2.00 off Organic Hass Avocados',
        discountAmount: 2.00,
        minSpend: 4.00,
        expiryDate: '2026-11-20',
        used: false
      }
    ]
  },
  {
    id: 'mem-002',
    memberId: 'WMT-7712-44',
    barcode: '400177124409',
    fullName: 'Marcus Sterling',
    tier: 'VIP Super Member',
    pointsBalance: 3420,
    lifetimePoints: 14200,
    joinedDate: '2024-09-01',
    communicationOptIn: true,
    purchaseDataUsageConsent: true,
    activeCoupons: [
      {
        code: 'EXPRESS5',
        description: '$5 off Next Day Delivery',
        discountAmount: 5.00,
        minSpend: 25.00,
        expiryDate: '2026-12-15',
        used: false
      }
    ]
  }
];

export const INITIAL_LOYALTY_LEDGER: LoyaltyLedgerEntry[] = [
  {
    id: 'loy-8891',
    idempotencyKey: 'LOY-EARN-ORD9810-20261108',
    memberId: 'WMT-8849-01',
    timestamp: '2026-11-08T19:55:00Z',
    orderId: 'ord-9810',
    type: 'EARN_PURCHASE',
    pointsDelta: +52,
    balanceAfter: 1240,
    description: '1x points on grocery purchase ($52.10 order total)',
    reversible: true
  },
  {
    id: 'loy-8890',
    idempotencyKey: 'LOY-RED-ORD9798-20261104',
    memberId: 'WMT-8849-01',
    timestamp: '2026-11-04T14:20:00Z',
    orderId: 'ord-9798',
    type: 'REDEMPTION',
    pointsDelta: -1000,
    balanceAfter: 1188,
    description: 'Redeemed 1,000 points for $10.00 cart instant savings',
    reversible: false
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-9901',
    timestamp: '2026-11-09T04:50:00Z',
    category: 'ORDERS',
    action: 'ORDER_RESERVED',
    entityId: 'WMT-ORD-9821',
    performedBy: 'RetailOS Transaction Engine',
    role: 'Enterprise Administrator',
    storeCode: 'ST-1042',
    details: 'Inventory reserved: 2x Strawberries, 1x Avocados, 3x Honeycrisp, 1x Milk, 1x Bread.',
    severity: 'INFO'
  },
  {
    id: 'aud-9900',
    timestamp: '2026-11-09T04:15:00Z',
    category: 'INVENTORY',
    action: 'STOCK_RECEIVED_PARTIAL',
    entityId: 'PO-4401',
    performedBy: 'Marcus Vance',
    role: 'Inventory Associate',
    storeCode: 'ST-1042',
    details: 'Dock 4 partial receipt: 32 of 64 units received (Pacific Berry Strawberries Lot LOT-SB-2611B). Temp verified: 34.2°F.',
    severity: 'WARNING'
  },
  {
    id: 'aud-9899',
    timestamp: '2026-11-08T23:00:00Z',
    category: 'PRICING',
    action: 'PRICE_PUBLISHED_ESL',
    entityId: 'pr-002',
    performedBy: 'Jordan Reed',
    role: 'Pricing Analyst',
    storeCode: 'ALL_NETWORK',
    details: 'Organic Honeycrisp Apples markdown published: $2.98 -> $2.68. ESL tags synced: 142 stores.',
    severity: 'INFO'
  },
  {
    id: 'aud-9898',
    timestamp: '2026-11-08T18:12:00Z',
    category: 'ACCESS',
    action: 'ROLE_PERMISSION_VERIFIED',
    entityId: 'USR-DEVON',
    performedBy: 'Security Policy Guard',
    role: 'Inventory Associate',
    storeCode: 'ST-1042',
    details: 'Attempted price modification denied: role Inventory Associate lacks PRICE_APPROVAL permission.',
    severity: 'WARNING'
  }
];
