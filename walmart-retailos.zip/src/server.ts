import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// In-memory demo data for backend REST endpoints
const demoMeta = {
  platform: 'Walmart RetailOS Enterprise Platform',
  version: '2.4.0-GA',
  database: 'PostgreSQL Invariant Engine (Transactional Outbox)',
  timestamp: new Date().toISOString()
};

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: demoMeta,
    services: {
      inventoryLedger: 'HEALTHY',
      pricingGovernance: 'HEALTHY',
      fulfillmentDispatch: 'HEALTHY',
      loyaltyLedger: 'HEALTHY',
      droneAdapter: 'STANDBY_FAA_PART135'
    }
  });
});

app.get('/api/facilities', (req, res) => {
  res.json([
    { id: 'fac-1042', code: 'ST-1042', name: 'Supercenter #1042 - Bentonville Central', type: 'SUPERCENTER', associates: 142 },
    { id: 'fac-3841', code: 'NM-3841', name: 'Neighborhood Market #3841 - Rogers North', type: 'NEIGHBORHOOD_MARKET', associates: 58 },
    { id: 'fac-6014', code: 'RDC-6014', name: 'Regional DC #6014 - Dallas South', type: 'RDC', associates: 310 }
  ]);
});

app.get('/api/inventory/status', (req, res) => {
  res.json({
    totalTrackedSkus: 8,
    activeFacility: 'ST-1042',
    networkInventoryHealth: '98.4%',
    shortDatedLots: 2,
    atpTotalUnits: 412
  });
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
