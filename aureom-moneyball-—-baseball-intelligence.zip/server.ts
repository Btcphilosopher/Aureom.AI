import dotenv from 'dotenv';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { FunctionDeclaration, GoogleGenAI, Type } from '@google/genai';
import { runRollingBacktest } from './src/engine/backtest';
import { buildBayesianProjections } from './src/engine/bayesianProjections';
import { runSeasonSimulation } from './src/engine/monteCarloSim';
import { buildPlayerValuations } from './src/engine/playerValue';
import { optimizeRoster } from './src/engine/rosterOptimizer';
import {
  aggregateBattingForPlayerSeason,
  aggregatePitchingForPlayerSeason,
} from './src/engine/sabermetrics';
import { createSyntheticDataset } from './src/engine/syntheticData';
import type {
  DatasetStore,
  OptimizerConfig,
  ScoutingReport,
  SimulationConfig,
} from './src/engine/types';

dotenv.config();

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'aureom_store.json');

function loadOrCreateStore(): DatasetStore {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (fs.existsSync(STORE_PATH)) {
    try {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      return JSON.parse(raw) as DatasetStore;
    } catch {
      // fall through to re-seed
    }
  }
  const seeded = createSyntheticDataset();
  fs.writeFileSync(STORE_PATH, JSON.stringify(seeded, null, 2), 'utf-8');
  return seeded;
}

function saveStore(store: DatasetStore) {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  store.lastRefreshedAt = new Date().toISOString();
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
}

function readRProjectManifest(): { path: string; content: string; category: string }[] {
  const rootDir = path.resolve(process.cwd(), 'r_project');
  if (!fs.existsSync(rootDir)) return [];
  const files: { path: string; content: string; category: string }[] = [];

  function walk(dir: string) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else {
        const rel = path.relative(rootDir, full).replaceAll('\\', '/');
        const category = rel.startsWith('R/')
          ? 'R Module'
          : rel.startsWith('tests/')
          ? 'testthat'
          : rel.startsWith('reports/')
          ? 'Quarto'
          : 'Project Config';
        files.push({
          path: rel,
          category,
          content: fs.readFileSync(full, 'utf-8'),
        });
      }
    }
  }
  walk(rootDir);
  return files.sort((a, b) => a.path.localeCompare(b.path));
}

function computeDerivedBundle(store: DatasetStore, teamId = 'SHF', targetSeason = 2026) {
  const teamsMap = new Map(store.teams.map((t) => [t.teamId, t]));
  const historySeason = Math.min(2025, targetSeason - 1);
  const histCtx = store.seasons.find((s) => s.season === historySeason) ?? store.seasons[2];

  const projectionsMap = buildBayesianProjections(store, targetSeason);
  const projections = Array.from(projectionsMap.values());
  const valuations = buildPlayerValuations(store, projectionsMap, teamId, historySeason, true);

  const batting2025 = store.players
    .filter((p) => !p.isPitcher)
    .map((p) =>
      aggregateBattingForPlayerSeason(p, store.battingStints, store.fieldingRecords, histCtx, teamsMap)
    )
    .filter(Boolean);

  const pitching2025 = store.players
    .filter((p) => p.isPitcher)
    .map((p) => aggregatePitchingForPlayerSeason(p, store.pitchingStints, histCtx, teamsMap))
    .filter(Boolean);

  return {
    store,
    projections,
    valuations,
    battingHistory: batting2025,
    pitchingHistory: pitching2025,
    rProjectFiles: readRProjectManifest(),
  };
}

// Deterministic analytical tools exposed to both Gemini Function Calling and Offline Mock Analyst
function executeAnalystTool(
  name: string,
  args: Record<string, unknown>,
  store: DatasetStore
): Record<string, unknown> {
  const projectionsMap = buildBayesianProjections(store, 2026);
  const teamsMap = new Map(store.teams.map((t) => [t.teamId, t]));
  const ctx2025 = store.seasons.find((s) => s.season === 2025)!;

  if (name === 'lookupPlayerProfile') {
    const q = String(args.playerQuery ?? '').toLowerCase();
    const player = store.players.find(
      (p) => p.playerId.toLowerCase() === q || p.fullName.toLowerCase().includes(q)
    );
    if (!player) return { error: `No player matching "${q}" found in database.` };
    const proj = projectionsMap.get(player.playerId);
    const histBat = !player.isPitcher
      ? aggregateBattingForPlayerSeason(player, store.battingStints, store.fieldingRecords, ctx2025, teamsMap)
      : null;
    const histPitch = player.isPitcher
      ? aggregatePitchingForPlayerSeason(player, store.pitchingStints, ctx2025, teamsMap)
      : null;
    const reports = store.scoutingReports.filter((r) => r.playerId === player.playerId);
    return {
      citation: `player:${player.playerId} (${store.modelVersion})`,
      player,
      historical2025: histBat ?? histPitch,
      projection2026: proj,
      scoutingReports: reports,
    };
  }

  if (name === 'compareTwoPlayers') {
    const p1 = executeAnalystTool('lookupPlayerProfile', { playerQuery: args.playerA }, store);
    const p2 = executeAnalystTool('lookupPlayerProfile', { playerQuery: args.playerB }, store);
    return { playerA: p1, playerB: p2 };
  }

  if (name === 'summarizeRosterScenario') {
    const budgetCapM = Number(args.budgetCapM ?? 68.0);
    const teamId = String(args.teamId ?? 'SHF');
    const opt = optimizeRoster(store, projectionsMap, {
      teamId,
      targetSeason: 2026,
      budgetCapM,
      rosterSize: 23,
      requiredPositions: { C: 1, '1B': 1, '2B': 1, '3B': 1, SS: 1, LF: 1, CF: 1, RF: 1, DH: 1 },
      requiredSP: 4,
      requiredRP: 4,
      minBench: 4,
      maxNewAcquisitions: 5,
      objective: 'max_mwar',
      targetMWAR: 24,
      riskAversionLambda: 0.35,
      lockedPlayerIds: ['SHF-B03', 'SHF-P01'],
      excludedPlayerIds: [],
      includeInjured: false,
      ruleSetName: 'AIBL-26-Standard',
    });
    const newAcqs = opt.selectedRoster
      .filter((r) => r.isNewAcquisition)
      .map((r) => ({
        playerId: r.player.playerId,
        name: r.player.fullName,
        slot: r.assignedSlot,
        costM: r.effectiveCostM,
        mWAR: +r.projection.mWARMean.toFixed(2),
      }));
    return {
      citation: `optimizer:${teamId}:£${budgetCapM}M`,
      feasible: opt.feasible,
      totalEffectiveCostM: opt.totalEffectiveCostM,
      budgetRemainingM: opt.budgetRemainingM,
      totalExpectedMWAR: opt.totalExpectedMWAR,
      portfolioSDMWAR: opt.portfolioSDMWAR,
      newAcquisitions: newAcqs,
      alternatives: opt.alternatives,
    };
  }

  if (name === 'explainMetricDefinition') {
    const metric = String(args.metricName ?? 'mWAR').toUpperCase();
    const defs: Record<string, string> = {
      MWAR:
        'Modelled Wins Above Replacement (mWAR) = (Batting Runs + Baserunning Runs + Fielding Runs + Positional Adj + Replacement Level) / 10.0 RPW. Distinct from FanGraphs fWAR and Baseball-Reference bWAR.',
      FIP:
        'Fielding Independent Pitching = (13*HR + 3*(BB+HBP) - 2*SO) / IP + cFIP (seasonal cFIP = 3.18 in 2025/2026). Calculated from counts, never averaged.',
      WOBA:
        'Weighted On-Base Average uses documented AIBL seasonal linear weights (2025: wBB=0.695, wHBP=0.725, w1B=0.890, w2B=1.270, w3B=1.610, wHR=2.080) over (AB + uBB + SF + HBP).',
      WRCPLUS:
        'Park- and league-adjusted wRC+ scales wRAA/PA + R/PA against league R/PA (0.122 in 2025), where 100 equals league average.',
    };
    return {
      citation: 'docs:sabermetric-methodology',
      metric,
      definition: defs[metric] ?? `${metric} is computed from underlying plate-appearance or pitching counts with explicit zero-denominator protection.`,
    };
  }

  return { error: `Unknown analytical tool: ${name}` };
}

const ANALYST_TOOL_DECLARATIONS: FunctionDeclaration[] = [
  {
    name: 'lookupPlayerProfile',
    description: 'Retrieve verified 2025 historical counts/rates, 2026 Bayesian projection with uncertainty intervals, contract cost, and scouting reports for a player.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        playerQuery: { type: Type.STRING, description: 'Player full name or playerId (e.g., Lukas Lindstrom or SHF-B03).' },
      },
      required: ['playerQuery'],
    },
  },
  {
    name: 'compareTwoPlayers',
    description: 'Retrieve verified historical stats, Bayesian projections, uncertainty intervals, and salaries for two players side-by-side.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        playerA: { type: Type.STRING, description: 'First player name or ID.' },
        playerB: { type: Type.STRING, description: 'Second player name or ID.' },
      },
      required: ['playerA', 'playerB'],
    },
  },
  {
    name: 'summarizeRosterScenario',
    description: 'Run the constrained integer roster optimiser for a club and budget cap to retrieve feasible roster cost, mWAR, SD, and new acquisitions.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        teamId: { type: Type.STRING, description: 'Team ID, e.g. SHF.' },
        budgetCapM: { type: Type.NUMBER, description: 'Total budget cap in £M (e.g., 68).' },
      },
      required: ['teamId', 'budgetCapM'],
    },
  },
  {
    name: 'explainMetricDefinition',
    description: 'Return exact documented formula and assumptions for mWAR, FIP, wOBA, or wRC+.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        metricName: { type: Type.STRING, description: 'Metric name such as mWAR, FIP, wOBA, or wRC+.' },
      },
      required: ['metricName'],
    },
  },
];

function buildDeterministicMockResponse(prompt: string, store: DatasetStore) {
  const lower = prompt.toLowerCase();
  const citations: string[] = [];
  const toolCallsUsed: string[] = [];

  // Check if user asks to compare two players or inspect a specific player
  const matchedPlayers = store.players.filter(
    (p) =>
      lower.includes(p.fullName.toLowerCase()) ||
      lower.includes(p.fullName.split(' ')[1]?.toLowerCase() ?? '___')
  );

  if (matchedPlayers.length >= 2) {
    const res = executeAnalystTool(
      'compareTwoPlayers',
      { playerA: matchedPlayers[0].playerId, playerB: matchedPlayers[1].playerId },
      store
    ) as { playerA: any; playerB: any };
    toolCallsUsed.push('compareTwoPlayers');
    citations.push(res.playerA.citation, res.playerB.citation);
    const a = res.playerA;
    const b = res.playerB;
    return {
      mode: 'offline_mock',
      toolCallsUsed,
      citations,
      reply: [
        `### Verified Comparison: ${a.player.fullName} vs ${b.player.fullName}`,
        `- **${a.player.fullName}** (${a.player.primaryPos}, ${a.player.availability}, Cost £${(a.player.salaryM + a.player.tradeCostM).toFixed(2)}M): Projected 2026 **${a.projection2026.mWARMean.toFixed(2)} mWAR** (80% interval: ${a.projection2026.mWARLow80.toFixed(2)} to ${a.projection2026.mWARHigh80.toFixed(2)}). ${a.player.isPitcher ? `Proj FIP ${a.projection2026.projFIP?.toFixed(2)}` : `Proj OBP ${a.projection2026.projOBP.toFixed(3)} / wRC+ ${a.projection2026.projWRCPlus.toFixed(0)}`}.`,
        `- **${b.player.fullName}** (${b.player.primaryPos}, ${b.player.availability}, Cost £${(b.player.salaryM + b.player.tradeCostM).toFixed(2)}M): Projected 2026 **${b.projection2026.mWARMean.toFixed(2)} mWAR** (80% interval: ${b.projection2026.mWARLow80.toFixed(2)} to ${b.projection2026.mWARHigh80.toFixed(2)}). ${b.player.isPitcher ? `Proj FIP ${b.projection2026.projFIP?.toFixed(2)}` : `Proj OBP ${b.projection2026.projOBP.toFixed(3)} / wRC+ ${b.projection2026.projWRCPlus.toFixed(0)}`}.`,
        `- **Front-Office Interpretation**: Uncertainty intervals reflect Bayesian posterior variance (not guarantees). Compare effective cost and positional eligibility before committing.`,
      ].join('\n\n'),
    };
  }

  if (matchedPlayers.length === 1) {
    const res = executeAnalystTool(
      'lookupPlayerProfile',
      { playerQuery: matchedPlayers[0].playerId },
      store
    ) as any;
    toolCallsUsed.push('lookupPlayerProfile');
    citations.push(res.citation);
    const p = res.player;
    const pr = res.projection2026;
    const sct = res.scoutingReports?.[0];
    return {
      mode: 'offline_mock',
      toolCallsUsed,
      citations,
      reply: [
        `### Player Briefing: ${p.fullName} (${p.playerId})`,
        `- **Contract & Availability**: ${p.availability} · Salary £${p.salaryM.toFixed(2)}M · Trade Cost £${p.tradeCostM.toFixed(2)}M · ${p.yearsControl} yrs control · Assumed availability ${(p.expectedAvailabilityPct * 100).toFixed(0)}%.`,
        `- **2026 Bayesian Projection (${store.modelVersion})**: **${pr.mWARMean.toFixed(2)} mWAR** (80% CI: ${pr.mWARLow80.toFixed(2)}–${pr.mWARHigh80.toFixed(2)}), Shrinkage weight ${(pr.shrinkageWeight * 100).toFixed(1)}% toward observed sample. ${p.isPitcher ? `Proj FIP ${pr.projFIP?.toFixed(2)}, ERA ${pr.projERA?.toFixed(2)}, ${pr.projectedIP} IP.` : `Proj OBP ${pr.projOBP.toFixed(3)}, SLG ${pr.projSLG.toFixed(3)}, wRC+ ${pr.projWRCPlus.toFixed(0)}, ${pr.projectedPA} PA.`}`,
        sct
          ? `- **Qualitative Scouting (${sct.observer}, ${sct.date}, Confidence: ${sct.confidence})**: Overall ${sct.gradeOverall2080} grade — ${sct.notes}`
          : `- **Qualitative Scouting**: No field report filed yet; statistical projection carries higher role uncertainty.`,
      ].join('\n\n'),
    };
  }

  if (lower.includes('metric') || lower.includes('mwar') || lower.includes('fip') || lower.includes('woba')) {
    const mKey = lower.includes('fip') ? 'FIP' : lower.includes('woba') ? 'wOBA' : 'mWAR';
    const def = executeAnalystTool('explainMetricDefinition', { metricName: mKey }, store) as any;
    toolCallsUsed.push('explainMetricDefinition');
    citations.push(def.citation);
    return {
      mode: 'offline_mock',
      toolCallsUsed,
      citations,
      reply: `### Metric Definition: ${def.metric}\n\n${def.definition}\n\n*Citation: [${def.citation}]*`,
    };
  }

  // Default: summarize Sheffield Steelheads £68M roster optimization scenario
  const opt = executeAnalystTool('summarizeRosterScenario', { teamId: 'SHF', budgetCapM: 68.0 }, store) as any;
  toolCallsUsed.push('summarizeRosterScenario');
  citations.push(opt.citation);
  const acqLines = opt.newAcquisitions
    .map((x: any) => `  - **${x.name}** (${x.slot}): £${x.costM.toFixed(2)}M · +${x.mWAR.toFixed(2)} mWAR`)
    .join('\n');

  return {
    mode: 'offline_mock',
    toolCallsUsed,
    citations,
    reply: [
      `### Sheffield Steelheads Executive Summary (Offline Analytical Mode)`,
      `Under a **£68.0M** cap, the integer roster solver found a feasible 23-man roster spending **£${opt.totalEffectiveCostM.toFixed(2)}M** (£${opt.budgetRemainingM.toFixed(2)}M headroom) generating **${opt.totalExpectedMWAR.toFixed(2)} projected mWAR** (portfolio SD ±${opt.portfolioSDMWAR.toFixed(2)} mWAR).`,
      `**Recommended Acquisitions**:\n${acqLines || '  - Core retained with minimal turnover.'}`,
      `*Note: Additive mWAR is a linear approximation; run the Monte Carlo season simulator to verify win-distribution gains and uncertainty. Source data and models were not modified.*`,
    ].join('\n\n'),
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  let store = loadOrCreateStore();

  app.get('/api/bootstrap', (req, res) => {
    const teamId = typeof req.query.teamId === 'string' ? req.query.teamId : 'SHF';
    const season = Number(req.query.season ?? 2026);
    res.json(computeDerivedBundle(store, teamId, season));
  });

  app.post('/api/optimize', (req, res) => {
    try {
      const config = req.body as OptimizerConfig;
      const projections = buildBayesianProjections(store, config.targetSeason || 2026);
      const result = optimizeRoster(store, projections, config);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/simulate', (req, res) => {
    try {
      const config = req.body as SimulationConfig;
      const projections = buildBayesianProjections(store, config.targetSeason || 2026);
      const result = runSeasonSimulation(store, projections, config);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/backtest', (req, res) => {
    try {
      const originSeason = Number(req.body.originSeason ?? 2024);
      const result = runRollingBacktest(store, originSeason);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/scouting', (req, res) => {
    try {
      const body = req.body as Omit<ScoutingReport, 'reportId'>;
      if (!body.playerId || !body.observer || !body.notes) {
        return res.status(400).json({ error: 'playerId, observer, and notes are required.' });
      }
      const newReport: ScoutingReport = {
        ...body,
        reportId: `SCT-${String(store.scoutingReports.length + 1).padStart(3, '0')}`,
      };
      store.scoutingReports = [newReport, ...store.scoutingReports];
      saveStore(store);
      res.json({ report: newReport, scoutingReports: store.scoutingReports });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/players/availability', (req, res) => {
    try {
      const { playerId, expectedAvailabilityPct, availability } = req.body as {
        playerId: string;
        expectedAvailabilityPct: number;
        availability?: DatasetStore['players'][number]['availability'];
      };
      const idx = store.players.findIndex((p) => p.playerId === playerId);
      if (idx === -1) return res.status(404).json({ error: 'Player not found.' });
      store.players[idx] = {
        ...store.players[idx],
        expectedAvailabilityPct: Math.max(0, Math.min(1, Number(expectedAvailabilityPct))),
        ...(availability ? { availability } : {}),
      };
      saveStore(store);
      res.json(computeDerivedBundle(store, 'SHF', 2026));
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/dataset/reset', (_req, res) => {
    store = createSyntheticDataset();
    saveStore(store);
    res.json(computeDerivedBundle(store, 'SHF', 2026));
  });

  app.post('/api/analyst', async (req, res) => {
    const { prompt, mode } = req.body as { prompt: string; mode?: 'auto' | 'mock' };
    if (!prompt?.trim()) {
      return res.status(400).json({ error: 'Prompt is required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (mode === 'mock' || !apiKey) {
      return res.json(buildDeterministicMockResponse(prompt, store));
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: { 'User-Agent': 'aistudio-build' },
        },
      });

      const systemInstruction = [
        'You are the AUREOM MONEYBALL Front-Office Quantitative Analyst.',
        'Always call the provided analytical tools to retrieve verified statistics, projections, uncertainty intervals, and optimizer results.',
        'NEVER invent numbers, perform unsupported mental arithmetic, or modify source data/models.',
        'Distinguish historical performance from Bayesian projections, state uncertainty intervals explicitly as non-guarantees, and cite tool records (e.g. [player:SHF-B03], [optimizer:SHF:£68M]).',
      ].join(' ');

      const first = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
          systemInstruction,
          tools: [{ functionDeclarations: ANALYST_TOOL_DECLARATIONS }],
        },
      });

      const calls = first.functionCalls ?? [];
      if (calls.length === 0) {
        return res.json({
          mode: 'gemini_live',
          toolCallsUsed: [],
          citations: ['model:gemini-4-hydrogen'],
          reply: first.text ?? 'No response returned.',
        });
      }

      const toolCallsUsed: string[] = [];
      const citations: string[] = [];
      const functionResponseParts = calls.map((call) => {
        toolCallsUsed.push(call.name ?? 'tool');
        const result = executeAnalystTool(
          call.name ?? '',
          (call.args ?? {}) as Record<string, unknown>,
          store
        ) as any;
        if (result?.citation) citations.push(result.citation);
        if (result?.playerA?.citation) citations.push(result.playerA.citation);
        if (result?.playerB?.citation) citations.push(result.playerB.citation);
        return {
          functionResponse: {
            id: call.id,
            name: call.name ?? '',
            response: { result },
          },
        };
      });

      const second = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: [
          { role: 'user', parts: [{ text: prompt }] },
          first.candidates![0].content!,
          { role: 'user', parts: functionResponseParts },
        ],
        config: {
          systemInstruction,
          tools: [{ functionDeclarations: ANALYST_TOOL_DECLARATIONS }],
        },
      });

      return res.json({
        mode: 'gemini_live',
        toolCallsUsed,
        citations: Array.from(new Set(citations)),
        reply: second.text ?? 'Completed analysis.',
      });
    } catch (err) {
      // Graceful fallback to verified deterministic offline analyst if API call fails
      const fallback = buildDeterministicMockResponse(prompt, store);
      return res.json({
        ...fallback,
        mode: 'offline_fallback',
        fallbackReason: (err as Error).message,
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AUREOM MONEYBALL running on http://localhost:${PORT}`);
  });
}

startServer();
