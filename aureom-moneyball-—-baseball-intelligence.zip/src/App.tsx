import React, { useEffect, useMemo, useState } from 'react';
import { Menu, MessageSquare, Moon, Sun, X } from 'lucide-react';
import type {
  BacktestMetrics,
  BayesianProjection,
  DatasetStore,
  OptimizerConfig,
  OptimizerResult,
  PlayerValuationRow,
  SabermetricBatting,
  SabermetricPitching,
  ScoutingReport,
  SimulationConfig,
  SimulationSummary,
} from './engine/types';
import { AnalystDrawer } from './components/AnalystDrawer';
import { PlayerDossierDrawer } from './components/PlayerDossierDrawer';
import {
  FieldingView,
  HittingView,
  type NavTab,
  OverviewView,
  PitchingView,
  PlayersView,
} from './components/WorkspacesCore';
import {
  DataModelsView,
  PlayerValueView,
  ReportsView,
  RosterBuilderView,
  ScoutingView,
  SimulationsView,
} from './components/WorkspacesStrategy';

const NAV_ITEMS: NavTab[] = [
  'Overview',
  'Players',
  'Hitting',
  'Pitching',
  'Fielding',
  'Scouting',
  'Player Value',
  'Roster Builder',
  'Simulations',
  'Reports',
  'Data & Models',
];

interface BootstrapPayload {
  store: DatasetStore;
  projections: BayesianProjection[];
  valuations: PlayerValuationRow[];
  battingHistory: SabermetricBatting[];
  pitchingHistory: SabermetricPitching[];
  rProjectFiles: { path: string; content: string; category: string }[];
}

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState<NavTab>('Overview');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const [teamId, setTeamId] = useState('SHF');
  const [season, setSeason] = useState(2026);
  const [competition, setCompetition] = useState('AIBL Regular Season');

  const [data, setData] = useState<BootstrapPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);
  const [analystOpen, setAnalystOpen] = useState(false);

  const [optConfig, setOptConfig] = useState<OptimizerConfig>({
    teamId: 'SHF',
    targetSeason: 2026,
    budgetCapM: 68.0,
    rosterSize: 23,
    requiredPositions: { C: 1, '1B': 1, '2B': 1, '3B': 1, SS: 1, LF: 1, CF: 1, RF: 1, DH: 1 },
    requiredSP: 4,
    requiredRP: 4,
    minBench: 4,
    maxNewAcquisitions: 5,
    objective: 'max_mwar',
    targetMWAR: 24,
    riskAversionLambda: 0.35,
    lockedPlayerIds: ['SHF-B03', 'SHF-P01'],
    excludedPlayerIds: [],
    includeInjured: false,
    ruleSetName: 'AIBL-26-Standard',
  });
  const [optResult, setOptResult] = useState<OptimizerResult | null>(null);
  const [optimizing, setOptimizing] = useState(false);

  const [simConfig, setSimConfig] = useState<SimulationConfig>({
    teamId: 'SHF',
    targetSeason: 2026,
    numSimulations: 350,
    seed: 2026,
    useCommonRandomNumbers: true,
    includeParameterUncertainty: true,
    extraInningGhostRunner: true,
    winTarget: 75,
    opponentStrengthOffset: 0,
    rosterPlayerIds: [],
    unavailablePlayerIds: [],
    lineupOrderIds: [],
    splitScenario: 'Neutral',
  });
  const [simSummary, setSimSummary] = useState<SimulationSummary | null>(null);
  const [baselineSummary, setBaselineSummary] = useState<SimulationSummary | null>(null);
  const [simulating, setSimulating] = useState(false);

  const [backtest, setBacktest] = useState<BacktestMetrics | null>(null);
  const [demoBanner, setDemoBanner] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const fetchBootstrapAndModels = async (tId = teamId, targetS = season) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/bootstrap?teamId=${tId}&season=${targetS}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = (await res.json()) as BootstrapPayload;
      setData(payload);

      const teamObj = payload.store.teams.find((t) => t.teamId === tId);
      const nextOptCfg: OptimizerConfig = {
        ...optConfig,
        teamId: tId,
        targetSeason: targetS,
        budgetCapM: teamObj?.budgetCapM ?? 68.0,
        lockedPlayerIds: tId === 'SHF' ? ['SHF-B03', 'SHF-P01'] : [],
      };
      setOptConfig(nextOptCfg);

      const [optRes, btRes] = await Promise.all([
        fetch('/api/optimize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(nextOptCfg),
        }),
        fetch('/api/backtest', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ originSeason: 2024 }),
        }),
      ]);

      const optJson = (await optRes.json()) as OptimizerResult;
      const btJson = (await btRes.json()) as BacktestMetrics;
      setOptResult(optJson);
      setBacktest(btJson);

      const rosterIds = optJson.selectedRoster.map((r) => r.player.playerId);
      const lineupIds = optJson.selectedRoster
        .filter((r) => !r.player.isPitcher && !r.assignedSlot.startsWith('BENCH'))
        .slice(0, 9)
        .map((r) => r.player.playerId);

      const initialSimCfg: SimulationConfig = {
        ...simConfig,
        teamId: tId,
        targetSeason: targetS,
        rosterPlayerIds: rosterIds,
        lineupOrderIds: lineupIds,
        unavailablePlayerIds: [],
      };
      setSimConfig(initialSimCfg);

      const simRes = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(initialSimCfg),
      });
      const simJson = (await simRes.json()) as SimulationSummary;
      setSimSummary(simJson);
      setBaselineSummary(simJson);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBootstrapAndModels('SHF', 2026);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const projectionsMap = useMemo(() => {
    const m = new Map<string, BayesianProjection>();
    if (data) {
      for (const p of data.projections) m.set(p.playerId, p);
    }
    return m;
  }, [data]);

  const handleRunOptimize = async (override?: OptimizerConfig) => {
    const cfg = override ?? optConfig;
    setOptimizing(true);
    try {
      const res = await fetch('/api/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      });
      const json = (await res.json()) as OptimizerResult;
      setOptResult(json);
    } finally {
      setOptimizing(false);
    }
  };

  const handleRunSimulation = async (override?: SimulationConfig) => {
    const cfg = override ?? simConfig;
    setSimulating(true);
    try {
      const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      });
      const json = (await res.json()) as SimulationSummary;
      setSimSummary(json);
    } finally {
      setSimulating(false);
    }
  };

  const handleSendToSimulator = async (playerIds: string[]) => {
    if (!data) return;
    const pMap = new Map(data.store.players.map((p) => [p.playerId, p]));
    const lineupIds = playerIds
      .filter((id) => {
        const p = pMap.get(id);
        return p && !p.isPitcher;
      })
      .slice(0, 9);
    const nextCfg: SimulationConfig = {
      ...simConfig,
      rosterPlayerIds: playerIds,
      lineupOrderIds: lineupIds,
      unavailablePlayerIds: [],
    };
    setSimConfig(nextCfg);
    setActiveTab('Simulations');
    await handleRunSimulation(nextCfg);
  };

  const handleAddScoutingReport = async (report: Omit<ScoutingReport, 'reportId'>) => {
    const res = await fetch('/api/scouting', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(report),
    });
    const json = await res.json();
    if (data && json.scoutingReports) {
      setData({
        ...data,
        store: { ...data.store, scoutingReports: json.scoutingReports },
      });
    }
  };

  const handleUpdateAvailability = async (playerId: string, pct: number) => {
    const res = await fetch('/api/players/availability', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerId, expectedAvailabilityPct: pct }),
    });
    const payload = (await res.json()) as BootstrapPayload;
    setData(payload);
    await handleRunOptimize();
  };

  const handleRunBacktest = async (originSeason: number) => {
    const res = await fetch('/api/backtest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ originSeason }),
    });
    const json = (await res.json()) as BacktestMetrics;
    setBacktest(json);
  };

  const handleResetDataset = async () => {
    const res = await fetch('/api/dataset/reset', { method: 'POST' });
    const payload = (await res.json()) as BootstrapPayload;
    setData(payload);
  };

  const handleRunDemoStep = async (step: number) => {
    if (!data || !optResult) return;
    if (step === 1) {
      setDemoBanner('Step 1: Inspecting validated player registry & multi-stint traded records (e.g. Kieran Vance, Lukas Lindstrom).');
      setActiveTab('Players');
    } else if (step === 2) {
      setDemoBanner('Step 2: Count-derived batting & pitching sabermetrics with park factors and mWAR decomposition.');
      setActiveTab('Hitting');
    } else if (step === 3) {
      setDemoBanner('Step 3: Hierarchical Empirical-Bayes partial pooling, posterior predictive checks, and rolling-origin backtests.');
      setActiveTab('Data & Models');
    } else if (step === 4) {
      setDemoBanner('Step 4: Five undervalued market-inefficiency targets ranked by surplus value, separating salary from trade cost.');
      setActiveTab('Player Value');
    } else if (step === 5) {
      const cfg = { ...optConfig, budgetCapM: 68.0, objective: 'max_mwar' as const };
      setOptConfig(cfg);
      await handleRunOptimize(cfg);
      setDemoBanner('Step 5: Solved 23-man position-complete Sheffield Steelheads roster under £68.0M cap.');
      setActiveTab('Roster Builder');
    } else if (step === 6) {
      const cfg = { ...optConfig, budgetCapM: 58.0, objective: 'min_cost_target' as const, targetMWAR: 23 };
      setOptConfig(cfg);
      await handleRunOptimize(cfg);
      setDemoBanner('Step 6: Low-Cost Value Build (£58.0M cap) solved alongside Expanded Contender alternative.');
      setActiveTab('Roster Builder');
    } else if (step === 7) {
      setDemoBanner('Step 7: Simulating 140-game AIBL season via 24-state base-out Monte Carlo engine.');
      setActiveTab('Simulations');
      await handleRunSimulation({ ...simConfig, unavailablePlayerIds: [] });
    } else if (step === 8) {
      const stressCfg: SimulationConfig = {
        ...simConfig,
        unavailablePlayerIds: ['SHF-P01'], // Ace Henrik Solberg lost
      };
      setSimConfig(stressCfg);
      setDemoBanner('Step 8: Stress-testing loss of ace SP Henrik Solberg (SHF-P01) vs pinned Baseline A.');
      setActiveTab('Simulations');
      await handleRunSimulation(stressCfg);
    } else if (step === 9) {
      setDemoBanner('Step 9: Ready to export Sheffield Steelheads executive management briefing (.md / Quarto .qmd).');
      setActiveTab('Reports');
    }
  };

  const selectedPlayer = data?.store.players.find((p) => p.playerId === selectedPlayerId) ?? null;

  return (
    <div className="min-h-screen flex bg-[#F8F6F1] text-[#0F172A] dark:bg-[#0B1320] dark:text-[#F1F5F9]">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-60 lg:flex-col border-r border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#0E1726] shrink-0">
        <div className="h-14 px-4 flex items-center border-b border-[#E2DFD7] dark:border-[#1E293B]">
          <span className="font-display text-xl font-bold tracking-tight whitespace-nowrap">
            AUREOM <span className="text-[#B91C1C] dark:text-[#EF4444]">MONEYBALL</span>
          </span>
        </div>

        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const active = activeTab === item;
            return (
              <button
                key={item}
                onClick={() => setActiveTab(item)}
                className={`w-full text-left px-3 py-2 rounded text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]'
                    : 'text-[#475569] dark:text-[#94A3B8] hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] hover:text-[#0F172A] dark:hover:text-white'
                }`}
              >
                {item}
              </button>
            );
          })}
        </nav>

        {data && (
          <div className="p-3 border-t border-[#E2DFD7] dark:border-[#1E293B] text-[11px] text-[#64748B] dark:text-[#94A3B8] space-y-1">
            <div>Provenance: Synthetic AIBL Feed</div>
            <div className="font-mono">Model: {data.store.modelVersion}</div>
            <div>Refreshed: {new Date(data.store.lastRefreshedAt).toLocaleDateString()}</div>
          </div>
        )}
      </aside>

      {/* Mobile Nav Drawer */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex bg-black/40">
          <div className="w-64 bg-white dark:bg-[#0E1726] h-full p-4 space-y-2 border-r border-[#E2DFD7] dark:border-[#1E293B]">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2DFD7] dark:border-[#1E293B]">
              <span className="font-display text-lg font-bold">AUREOM MONEYBALL</span>
              <button onClick={() => setMobileNavOpen(false)} aria-label="Close navigation">
                <X className="w-4 h-4" />
              </button>
            </div>
            {NAV_ITEMS.map((item) => (
              <button
                key={item}
                onClick={() => {
                  setActiveTab(item);
                  setMobileNavOpen(false);
                }}
                className={`w-full text-left px-3 py-2 rounded text-xs font-medium ${
                  activeTab === item
                    ? 'bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]'
                    : 'text-[#475569] dark:text-[#94A3B8]'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar (Strict Single-Row, Clean Controls) */}
        <header className="h-14 px-4 sm:px-6 border-b border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#0E1726] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileNavOpen(true)}
              className="lg:hidden p-1.5 rounded border border-[#E2DFD7] dark:border-[#334155]"
              aria-label="Open menu"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="text-xs font-medium text-[#64748B] dark:text-[#94A3B8] truncate">
              Baseball Intelligence <span aria-hidden="true">/</span>{' '}
              <span className="text-[#0F172A] dark:text-[#F1F5F9] font-semibold">{activeTab}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <select
              aria-label="Active team filter"
              value={teamId}
              onChange={(e) => {
                setTeamId(e.target.value);
                fetchBootstrapAndModels(e.target.value, season);
              }}
              className="px-2.5 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#334155] bg-[#F8F6F1] dark:bg-[#111B2E]"
            >
              {(data?.store.teams ?? [{ teamId: 'SHF', name: 'Sheffield Steelheads' }]).map((t) => (
                <option key={t.teamId} value={t.teamId}>
                  {t.name}
                </option>
              ))}
            </select>

            <select
              aria-label="Target season filter"
              value={season}
              onChange={(e) => {
                const s = Number(e.target.value);
                setSeason(s);
                fetchBootstrapAndModels(teamId, s);
              }}
              className="hidden sm:block px-2.5 py-1.5 text-xs font-mono rounded border border-[#E2DFD7] dark:border-[#334155] bg-[#F8F6F1] dark:bg-[#111B2E]"
            >
              <option value={2026}>2026 Proj</option>
              <option value={2025}>2025 Hist</option>
              <option value={2024}>2024 Hist</option>
            </select>

            <select
              aria-label="Competition filter"
              value={competition}
              onChange={(e) => setCompetition(e.target.value)}
              className="hidden md:block px-2.5 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#334155] bg-[#F8F6F1] dark:bg-[#111B2E]"
            >
              <option value="AIBL Regular Season">AIBL Regular Season</option>
              <option value="AIBL Postseason">AIBL Postseason (4-Team)</option>
            </select>

            <button
              onClick={() => setDarkMode((d) => !d)}
              className="p-2 rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B]"
              aria-label="Toggle light and dark theme"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => setAnalystOpen(true)}
              className="px-3.5 py-1.5 text-xs font-medium rounded bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320] hover:opacity-90 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              AI Analyst
            </button>
          </div>
        </header>

        {/* Active Guided Demo Banner */}
        {demoBanner && (
          <div className="px-6 py-2 bg-[#0B1320] text-white dark:bg-[#1E293B] text-xs flex items-center justify-between gap-4">
            <span>{demoBanner}</span>
            <button onClick={() => setDemoBanner(null)} className="text-white/70 hover:text-white">
              Dismiss
            </button>
          </div>
        )}

        {/* Workspace Viewport */}
        <main className="flex-1 p-4 sm:p-6 max-w-[1440px] w-full mx-auto">
          {loading ? (
            <div className="space-y-4">
              <div className="h-44 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] animate-pulse" />
              <div className="grid grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-24 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] animate-pulse" />
                ))}
              </div>
            </div>
          ) : error || !data || !optResult ? (
            <div className="p-6 rounded border border-[#DC2626] bg-white dark:bg-[#111B2E] text-sm space-y-2">
              <div className="font-semibold text-[#B91C1C]">Failed to load analytical dataset</div>
              <p className="text-xs text-[#64748B]">{error}</p>
              <button
                onClick={() => fetchBootstrapAndModels(teamId, season)}
                className="px-3 py-1.5 text-xs rounded bg-[#0B1320] text-white"
              >
                Retry
              </button>
            </div>
          ) : (
            <>
              {activeTab === 'Overview' && (
                <OverviewView
                  store={data.store}
                  teamId={teamId}
                  valuations={data.valuations}
                  optimizerResult={optResult}
                  simulationSummary={simSummary}
                  onNavigate={setActiveTab}
                  onSelectPlayer={setSelectedPlayerId}
                  onRunDemoStep={handleRunDemoStep}
                />
              )}

              {activeTab === 'Players' && (
                <PlayersView
                  store={data.store}
                  projections={projectionsMap}
                  teamFilter={teamId}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Hitting' && (
                <HittingView
                  store={data.store}
                  battingHistory={data.battingHistory}
                  projections={projectionsMap}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Pitching' && (
                <PitchingView
                  store={data.store}
                  pitchingHistory={data.pitchingHistory}
                  projections={projectionsMap}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Fielding' && (
                <FieldingView
                  store={data.store}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Scouting' && (
                <ScoutingView
                  store={data.store}
                  projections={projectionsMap}
                  onAddReport={handleAddScoutingReport}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Player Value' && (
                <PlayerValueView
                  valuations={data.valuations}
                  teamId={teamId}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Roster Builder' && (
                <RosterBuilderView
                  store={data.store}
                  config={optConfig}
                  result={optResult}
                  optimizing={optimizing}
                  onChangeConfig={setOptConfig}
                  onRunOptimize={handleRunOptimize}
                  onSendToSimulator={handleSendToSimulator}
                  onSelectPlayer={setSelectedPlayerId}
                />
              )}

              {activeTab === 'Simulations' && (
                <SimulationsView
                  store={data.store}
                  projections={projectionsMap}
                  simConfig={simConfig}
                  simSummary={simSummary}
                  baselineSummary={baselineSummary}
                  simulating={simulating}
                  onChangeSimConfig={setSimConfig}
                  onRunSimulation={handleRunSimulation}
                  onSaveAsBaseline={() => simSummary && setBaselineSummary(simSummary)}
                />
              )}

              {activeTab === 'Reports' && (
                <ReportsView
                  store={data.store}
                  teamId={teamId}
                  valuations={data.valuations}
                  optimizerResult={optResult}
                  simulationSummary={simSummary}
                  rProjectFiles={data.rProjectFiles}
                />
              )}

              {activeTab === 'Data & Models' && (
                <DataModelsView
                  store={data.store}
                  projections={projectionsMap}
                  backtest={backtest}
                  rProjectFiles={data.rProjectFiles}
                  onRunBacktest={handleRunBacktest}
                  onResetDataset={handleResetDataset}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Player Dossier Slide-Over */}
      {selectedPlayer && data && (
        <PlayerDossierDrawer
          player={selectedPlayer}
          projection={projectionsMap.get(selectedPlayer.playerId)}
          battingHist={data.battingHistory.find((b) => b.playerId === selectedPlayer.playerId)}
          pitchingHist={data.pitchingHistory.find((p) => p.playerId === selectedPlayer.playerId)}
          store={data.store}
          onClose={() => setSelectedPlayerId(null)}
          onUpdateAvailability={handleUpdateAvailability}
        />
      )}

      {/* AI Analyst Slide-Over */}
      <AnalystDrawer open={analystOpen} onClose={() => setAnalystOpen(false)} />
    </div>
  );
}
