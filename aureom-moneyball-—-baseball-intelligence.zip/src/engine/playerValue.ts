import {
  aggregateBattingForPlayerSeason,
  aggregatePitchingForPlayerSeason,
  safeDiv,
} from './sabermetrics';
import type {
  BayesianProjection,
  DatasetStore,
  PlayerValuationRow,
} from './types';

// Market price per Modelled WAR in AIBL (£M per marginal win above replacement)
export const MARKET_DOLLARS_PER_MWAR = 3.2;

export function buildPlayerValuations(
  store: DatasetStore,
  projections: Map<string, BayesianProjection>,
  targetTeamId: string,
  historySeason: number,
  amortizeTradeYears = true
): PlayerValuationRow[] {
  const teamsMap = new Map(store.teams.map((t) => [t.teamId, t]));
  const seasonCtx =
    store.seasons.find((s) => s.season === historySeason) ?? store.seasons[0];

  const rows: PlayerValuationRow[] = [];

  for (const player of store.players) {
    const projection = projections.get(player.playerId);
    if (!projection) continue;

    const historicalBat = !player.isPitcher
      ? aggregateBattingForPlayerSeason(
          player,
          store.battingStints,
          store.fieldingRecords,
          seasonCtx,
          teamsMap
        )
      : null;

    const historicalPitch = player.isPitcher
      ? aggregatePitchingForPlayerSeason(
          player,
          store.pitchingStints,
          seasonCtx,
          teamsMap
        )
      : null;

    // Separate salary from trade cost; amortize trade cost over years of control if toggled
    const tradeCostCharged =
      player.currentTeamId === targetTeamId
        ? 0
        : amortizeTradeYears
        ? player.tradeCostM / Math.max(1, player.yearsControl)
        : player.tradeCostM;

    const totalEffectiveCostM = +(player.salaryM + tradeCostCharged).toFixed(2);
    const mWARPerMillion =
      totalEffectiveCostM > 0 ? projection.mWARMean / totalEffectiveCostM : 0;
    const surplusValueM =
      projection.mWARMean * MARKET_DOLLARS_PER_MWAR - totalEffectiveCostM;

    // Shrunk platoon OBP delta (vs opposite-handed pitching minus same-handed)
    let platoonDeltaOBP = 0;
    if (!player.isPitcher) {
      const lhp = store.battingStints.find(
        (s) =>
          s.playerId === player.playerId &&
          s.season === historySeason &&
          s.splitVsHand === 'LHP'
      );
      const rhp = store.battingStints.find(
        (s) =>
          s.playerId === player.playerId &&
          s.season === historySeason &&
          s.splitVsHand === 'RHP'
      );
      if (lhp && rhp) {
        const obpL = safeDiv(lhp.h + lhp.bb + lhp.hbp, lhp.ab + lhp.bb + lhp.hbp + lhp.sf) ?? 0.31;
        const obpR = safeDiv(rhp.h + rhp.bb + rhp.hbp, rhp.ab + rhp.bb + rhp.hbp + rhp.sf) ?? 0.31;
        // Shrink small split difference toward positional baseline (prior = 180 PA per split)
        const nMin = Math.min(lhp.pa, rhp.pa);
        const shrink = nMin / (nMin + 180);
        const rawDiff = player.bats === 'L' ? obpR - obpL : obpL - obpR;
        platoonDeltaOBP = +(rawDiff * shrink).toFixed(3);
      }
    }

    const inefficiencyReasons: string[] = [];
    if (!player.isPitcher) {
      if (
        projection.projOBP >= 0.355 &&
        projection.projBA <= 0.258 &&
        totalEffectiveCostM <= 3.5
      ) {
        inefficiencyReasons.push('High-OBP / Low-BA Market Discount');
      }
      if (platoonDeltaOBP >= 0.012 && totalEffectiveCostM <= 3.2) {
        inefficiencyReasons.push('Shrunk Platoon Leverage');
      }
      if (player.eligiblePositions.length >= 3 && projection.mWARMean >= 1.3) {
        inefficiencyReasons.push('Multi-Positional Roster Flexibility');
      }
    } else {
      if (
        historicalPitch?.era !== null &&
        historicalPitch?.fip !== null &&
        historicalPitch &&
        historicalPitch.era - historicalPitch.fip >= 0.55 &&
        totalEffectiveCostM <= 4.0
      ) {
        inefficiencyReasons.push('FIP-vs-ERA Unlucky BABIP Rebound');
      }
      if (
        projection.projKPct >= 0.28 &&
        totalEffectiveCostM <= 2.5 &&
        player.pitchingRole !== 'SP'
      ) {
        inefficiencyReasons.push('High-K Bullpen Surplus');
      }
    }
    if (
      surplusValueM >= 2.8 &&
      (player.availability === 'Free Agent' || player.availability === 'Trade Target')
    ) {
      inefficiencyReasons.push('High Surplus Value / £M');
    }

    const acquirableForTeam =
      player.currentTeamId === targetTeamId ||
      player.availability === 'Free Agent' ||
      player.availability === 'Trade Target';

    rows.push({
      player,
      projection,
      historicalBat,
      historicalPitch,
      totalEffectiveCostM,
      mWARPerMillion,
      surplusValueM,
      platoonDeltaOBP,
      inefficiencyReasons,
      acquirableForTeam,
    });
  }

  return rows.sort((a, b) => b.surplusValueM - a.surplusValueM);
}
