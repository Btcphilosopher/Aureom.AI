import { normalizePAProbs } from './bayesianProjections';
import type {
  BayesianProjection,
  DatasetStore,
  PAOutcomeProbs,
  SimulationConfig,
  SimulationSummary,
} from './types';

function createPRNG(seed: number) {
  let s = seed >>> 0;
  return () => {
    s += 0x6d2b79f5;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box-Muller normal sample
function sampleNormal(rand: () => number): number {
  const u1 = Math.max(1e-9, rand());
  const u2 = rand();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

/**
 * Log5 / Odds-Ratio matchup probability combining batter PA vector and pitcher PA vector
 * against league baseline, strictly normalized to sum to 1.0.
 */
export function combineBatterPitcherProbs(
  batter: PAOutcomeProbs,
  pitcher: PAOutcomeProbs,
  league: PAOutcomeProbs
): PAOutcomeProbs {
  const combine = (b: number, p: number, l: number) => {
    const num = (b * p) / Math.max(1e-5, l);
    return Math.max(1e-6, num);
  };
  return normalizePAProbs({
    bbHbp: combine(batter.bbHbp, pitcher.bbHbp, league.bbHbp),
    so: combine(batter.so, pitcher.so, league.so),
    hr: combine(batter.hr, pitcher.hr, league.hr),
    single: combine(batter.single, pitcher.single, league.single),
    double: combine(batter.double, pitcher.double, league.double),
    triple: combine(batter.triple, pitcher.triple, league.triple),
    outInPlay: combine(batter.outInPlay, pitcher.outInPlay, league.outInPlay),
  });
}

// Base bitmask: 1=1B, 2=2B, 4=3B (0..7)
export interface BaseOutState {
  outs: number; // 0, 1, 2
  bases: number; // 0..7
}

export type SimEvent = 'BB_HBP' | 'SO' | 'HR' | '1B' | '2B' | '3B' | 'GB_OUT' | 'FB_OUT';

/**
 * Transparent, documented 24-state baseball transition function.
 * Explicit runner advancement rules:
 * - BB_HBP: forced runners advance 1 base; 3B scores only if bases loaded.
 * - 1B: 3B scores, 2B scores ~60% (here deterministic expected-advance or stochastic; we support deterministic/rand), 1B -> 2B (or 3B ~28%).
 * - 2B: 3B & 2B score; 1B -> 3B (scores ~42% of time).
 * - 3B: all runners score; batter to 3B.
 * - HR: all runners + batter score.
 * - SO: +1 out, runners hold.
 * - GB_OUT: if 1B occupied and outs < 2, 42% chance of double play (+2 outs, 1B out, 3B scores if outs now < 3); otherwise +1 out, runners hold/advance.
 * - FB_OUT: +1 out; if 3B occupied and outs < 2 (after out -> outs <= 2), sacrifice fly scores 3B (68% of time).
 */
export function stepBaseOutState(
  state: BaseOutState,
  event: SimEvent,
  rand: () => number
): { nextState: BaseOutState; runsScored: number } {
  let { outs, bases } = state;
  let runs = 0;
  const on1 = (bases & 1) !== 0;
  const on2 = (bases & 2) !== 0;
  const on3 = (bases & 4) !== 0;

  switch (event) {
    case 'BB_HBP': {
      if (on1 && on2 && on3) {
        runs += 1;
        bases = 7;
      } else if (on1 && on2) {
        bases = 7;
      } else if (on1 && on3) {
        bases = 7;
      } else if (on1) {
        bases = 3;
      } else {
        bases = bases | 1;
      }
      break;
    }
    case 'HR': {
      runs += 1 + (on1 ? 1 : 0) + (on2 ? 1 : 0) + (on3 ? 1 : 0);
      bases = 0;
      break;
    }
    case '3B': {
      runs += (on1 ? 1 : 0) + (on2 ? 1 : 0) + (on3 ? 1 : 0);
      bases = 4;
      break;
    }
    case '2B': {
      runs += (on3 ? 1 : 0) + (on2 ? 1 : 0);
      let nextBases = 2; // batter on 2B
      if (on1) {
        if (rand() < 0.42) runs += 1;
        else nextBases |= 4;
      }
      bases = nextBases;
      break;
    }
    case '1B': {
      if (on3) runs += 1;
      let nextBases = 1; // batter on 1B
      if (on2) {
        if (rand() < 0.62) runs += 1;
        else nextBases |= 4;
      }
      if (on1) {
        if ((nextBases & 4) === 0 && rand() < 0.28) nextBases |= 4;
        else nextBases |= 2;
      }
      bases = nextBases;
      break;
    }
    case 'SO': {
      outs += 1;
      break;
    }
    case 'GB_OUT': {
      if (on1 && outs < 2 && rand() < 0.42) {
        // Double play
        outs += 2;
        if (outs < 3 && on3) {
          runs += 1;
          bases = on2 ? 4 : 0;
        } else {
          bases = on2 ? 4 : 0;
        }
      } else {
        outs += 1;
        // Productive groundout advance if < 3 outs
        if (outs < 3) {
          let nextBases = 0;
          if (on3) runs += 1;
          if (on2) nextBases |= 4;
          if (on1) nextBases |= 2;
          bases = nextBases;
        }
      }
      break;
    }
    case 'FB_OUT': {
      outs += 1;
      if (outs < 3 && on3 && rand() < 0.68) {
        runs += 1;
        bases = bases & ~4; // remove 3B runner who scored on sac fly
      }
      break;
    }
  }

  return { nextState: { outs, bases }, runsScored: runs };
}

function drawPAEvent(probs: PAOutcomeProbs, rand: () => number): SimEvent {
  const r = rand();
  let cum = probs.bbHbp;
  if (r < cum) return 'BB_HBP';
  cum += probs.so;
  if (r < cum) return 'SO';
  cum += probs.hr;
  if (r < cum) return 'HR';
  cum += probs.single;
  if (r < cum) return '1B';
  cum += probs.double;
  if (r < cum) return '2B';
  cum += probs.triple;
  if (r < cum) return '3B';
  // Split out-in-play into 52% groundout / 48% flyout
  return rand() < 0.52 ? 'GB_OUT' : 'FB_OUT';
}

/**
 * Compute empirical 24-state Run Expectancy Matrix via analytical/Monte Carlo evaluation
 */
export function computeRunExpectancyMatrix(leagueProbs: PAOutcomeProbs, seed = 42): number[][] {
  const rand = createPRNG(seed);
  const re: number[][] = Array.from({ length: 8 }, () => [0, 0, 0]);
  const reps = 400;
  for (let b = 0; b < 8; b++) {
    for (let o = 0; o < 3; o++) {
      let totalRuns = 0;
      for (let i = 0; i < reps; i++) {
        let state: BaseOutState = { bases: b, outs: o };
        while (state.outs < 3) {
          const ev = drawPAEvent(leagueProbs, rand);
          const step = stepBaseOutState(state, ev, rand);
          totalRuns += step.runsScored;
          state = step.nextState;
        }
      }
      re[b][o] = +(totalRuns / reps).toFixed(3);
    }
  }
  return re;
}

export function runSeasonSimulation(
  store: DatasetStore,
  projections: Map<string, BayesianProjection>,
  config: SimulationConfig
): SimulationSummary {
  const seasonCtx =
    store.seasons.find((s) => s.season === config.targetSeason) ??
    store.seasons[store.seasons.length - 1];
  const nGames = seasonCtx.gamesPerTeam; // 140
  const nSims = Math.max(50, Math.min(2000, config.numSimulations));
  const unavailableSet = new Set(config.unavailablePlayerIds);

  const leagueProbs = normalizePAProbs({
    bbHbp: 0.095,
    so: 0.215,
    hr: 0.028,
    single: 0.155,
    double: 0.045,
    triple: 0.005,
    outInPlay: 0.457,
  });

  // Build active lineup (9 batters) and pitching staff from rosterPlayerIds
  const rosterPlayers = config.rosterPlayerIds
    .map((id) => ({
      player: store.players.find((p) => p.playerId === id),
      proj: projections.get(id),
    }))
    .filter((x) => x.player && x.proj) as {
    player: NonNullable<ReturnType<typeof store.players.find>>;
    proj: BayesianProjection;
  }[];

  const activeBatters = rosterPlayers.filter(
    (x) => !x.player.isPitcher && !unavailableSet.has(x.player.playerId)
  );
  const activePitchers = rosterPlayers.filter(
    (x) => x.player.isPitcher && !unavailableSet.has(x.player.playerId)
  );

  // Order lineup by provided lineupOrderIds or descending projected OBP+SLG
  const lineupMap = new Map(activeBatters.map((b) => [b.player.playerId, b]));
  const orderedLineup: typeof activeBatters = [];
  for (const id of config.lineupOrderIds) {
    const hit = lineupMap.get(id);
    if (hit) {
      orderedLineup.push(hit);
      lineupMap.delete(id);
    }
  }
  const remainingBatters = [...lineupMap.values()].sort(
    (a, b) => b.proj.projOBP + b.proj.projSLG - (a.proj.projOBP + a.proj.projSLG)
  );
  for (const b of remainingBatters) {
    if (orderedLineup.length < 9) orderedLineup.push(b);
  }

  // Replacement-level fallback if injury leaves fewer than 9 batters
  const replacementBatterProbs = normalizePAProbs({
    bbHbp: 0.072,
    so: 0.245,
    hr: 0.017,
    single: 0.145,
    double: 0.036,
    triple: 0.004,
    outInPlay: 0.481,
  });

  // Team pitching composite PA probability (weighted by projected IP of available SP & RP)
  // If key starter is removed via unavailablePlayerIds, replacement IP (worse FIP) fills the gap!
  const targetTeamIP = nGames * 8.95;
  let totalAvailIP = 0;
  let weightedPitchProbs = {
    bbHbp: 0,
    so: 0,
    hr: 0,
    single: 0,
    double: 0,
    triple: 0,
    outInPlay: 0,
  };
  for (const p of activePitchers) {
    const ip = p.proj.projectedIP;
    totalAvailIP += ip;
    weightedPitchProbs.bbHbp += p.proj.paProbs.bbHbp * ip;
    weightedPitchProbs.so += p.proj.paProbs.so * ip;
    weightedPitchProbs.hr += p.proj.paProbs.hr * ip;
    weightedPitchProbs.single += p.proj.paProbs.single * ip;
    weightedPitchProbs.double += p.proj.paProbs.double * ip;
    weightedPitchProbs.triple += p.proj.paProbs.triple * ip;
    weightedPitchProbs.outInPlay += p.proj.paProbs.outInPlay * ip;
  }

  // Fill any missing innings with replacement-level AAA pitcher (~5.15 FIP)
  const missingIP = Math.max(0, targetTeamIP - totalAvailIP);
  if (missingIP > 0) {
    weightedPitchProbs.bbHbp += 0.098 * missingIP;
    weightedPitchProbs.so += 0.175 * missingIP;
    weightedPitchProbs.hr += 0.036 * missingIP;
    weightedPitchProbs.single += 0.165 * missingIP;
    weightedPitchProbs.double += 0.049 * missingIP;
    weightedPitchProbs.triple += 0.006 * missingIP;
    weightedPitchProbs.outInPlay += 0.471 * missingIP;
  }

  const teamPitchingMeanProbs = normalizePAProbs(weightedPitchProbs);

  // Opponent composite probabilities adjusted by opponentStrengthOffset
  const oppOffOffset = config.opponentStrengthOffset;
  const oppBatterProbs = normalizePAProbs({
    ...leagueProbs,
    bbHbp: leagueProbs.bbHbp + oppOffOffset * 0.4,
    hr: leagueProbs.hr + oppOffOffset * 0.2,
    single: leagueProbs.single + oppOffOffset * 0.4,
    outInPlay: leagueProbs.outInPlay - oppOffOffset,
  });
  const oppPitcherProbs = normalizePAProbs({
    ...leagueProbs,
    so: leagueProbs.so + oppOffOffset * 0.6,
    bbHbp: leagueProbs.bbHbp - oppOffOffset * 0.4,
  });

  // Split adjustment for lineup scenario
  const splitBoost =
    config.splitScenario === 'Neutral' ? 0 : config.splitScenario === 'vsLHP' ? 0.004 : 0.006;

  const baseSeed = config.useCommonRandomNumbers ? config.seed : config.seed + rosterPlayers.length * 31;
  const rand = createPRNG(baseSeed);

  const winCounts: number[] = [];
  let sumRS = 0;
  let sumRA = 0;

  for (let s = 0; s < nSims; s++) {
    // Outer loop: Parameter Uncertainty (true talent draw from Bayesian posterior)
    const paramShiftOff = config.includeParameterUncertainty ? sampleNormal(rand) * 0.0085 : 0;
    const paramShiftPitch = config.includeParameterUncertainty ? sampleNormal(rand) * 0.0085 : 0;

    const simLineupProbs: PAOutcomeProbs[] = [];
    for (let i = 0; i < 9; i++) {
      const slot = orderedLineup[i];
      const baseP = slot ? slot.proj.paProbs : replacementBatterProbs;
      const handedBonus =
        slot && config.splitScenario === 'vsLHP' && slot.player.bats === 'R'
          ? 0.012
          : slot && config.splitScenario === 'vsRHP' && slot.player.bats === 'L'
          ? 0.012
          : 0;
      const batterTalentDraw = normalizePAProbs({
        ...baseP,
        bbHbp: Math.max(0.02, baseP.bbHbp + (paramShiftOff + splitBoost + handedBonus) * 0.35),
        hr: Math.max(0.003, baseP.hr + (paramShiftOff + handedBonus) * 0.2),
        single: Math.max(0.05, baseP.single + (paramShiftOff + handedBonus) * 0.45),
        outInPlay: Math.max(0.2, baseP.outInPlay - (paramShiftOff + splitBoost + handedBonus)),
      });
      simLineupProbs.push(combineBatterPitcherProbs(batterTalentDraw, oppPitcherProbs, leagueProbs));
    }

    const oppMatchupProbs = combineBatterPitcherProbs(
      oppBatterProbs,
      normalizePAProbs({
        ...teamPitchingMeanProbs,
        bbHbp: Math.max(0.02, teamPitchingMeanProbs.bbHbp + paramShiftPitch * 0.4),
        hr: Math.max(0.005, teamPitchingMeanProbs.hr + paramShiftPitch * 0.2),
        so: Math.max(0.08, teamPitchingMeanProbs.so - paramShiftPitch * 0.4),
      }),
      leagueProbs
    );

    // Inner loop: Simulate 140 games via 24-state base-out engine
    let wins = 0;
    let rs = 0;
    let ra = 0;

    for (let g = 0; g < nGames; g++) {
      let ourRuns = 0;
      let oppRuns = 0;
      let batterIdx = 0;

      // 9 regulation innings
      for (let inn = 1; inn <= 9; inn++) {
        // Our offense half-inning
        let state: BaseOutState = { outs: 0, bases: 0 };
        while (state.outs < 3) {
          const ev = drawPAEvent(simLineupProbs[batterIdx % 9], rand);
          const res = stepBaseOutState(state, ev, rand);
          ourRuns += res.runsScored;
          state = res.nextState;
          batterIdx++;
        }

        // Opponent offense half-inning (skip bottom 9th if we're home 50% of games and already ahead)
        if (inn === 9 && g % 2 === 0 && ourRuns > oppRuns) {
          continue;
        }
        let oppState: BaseOutState = { outs: 0, bases: 0 };
        while (oppState.outs < 3) {
          const ev = drawPAEvent(oppMatchupProbs, rand);
          const res = stepBaseOutState(oppState, ev, rand);
          oppRuns += res.runsScored;
          oppState = res.nextState;
        }
      }

      // Extra innings (up to 15 innings, with optional ghost runner on 2B = bitmask 2)
      let extraInn = 10;
      while (ourRuns === oppRuns && extraInn <= 15) {
        let state: BaseOutState = { outs: 0, bases: config.extraInningGhostRunner ? 2 : 0 };
        while (state.outs < 3) {
          const ev = drawPAEvent(simLineupProbs[batterIdx % 9], rand);
          const res = stepBaseOutState(state, ev, rand);
          ourRuns += res.runsScored;
          state = res.nextState;
          batterIdx++;
        }
        let oppState: BaseOutState = { outs: 0, bases: config.extraInningGhostRunner ? 2 : 0 };
        while (oppState.outs < 3) {
          const ev = drawPAEvent(oppMatchupProbs, rand);
          const res = stepBaseOutState(oppState, ev, rand);
          oppRuns += res.runsScored;
          oppState = res.nextState;
        }
        extraInn++;
      }

      if (ourRuns > oppRuns || (ourRuns === oppRuns && rand() < 0.5)) {
        wins++;
      }
      rs += ourRuns;
      ra += oppRuns;
    }

    winCounts.push(wins);
    sumRS += rs;
    sumRA += ra;
  }

  const sorted = [...winCounts].sort((a, b) => a - b);
  const mean = winCounts.reduce((a, b) => a + b, 0) / nSims;
  const variance = winCounts.reduce((s, w) => s + (w - mean) ** 2, 0) / Math.max(1, nSims - 1);
  const sd = Math.sqrt(variance);
  const mcSE = sd / Math.sqrt(nSims);

  const q = (p: number) => sorted[Math.min(sorted.length - 1, Math.max(0, Math.floor(p * (sorted.length - 1))))];

  const probExceedTarget = winCounts.filter((w) => w >= config.winTarget).length / nSims;
  // AIBL 4-team playoff berth threshold ~78 wins in a 140-game balanced schedule
  const playoffThreshold = Math.round(nGames * 0.557); // 78 wins
  const playoffProbability = winCounts.filter((w) => w >= playoffThreshold).length / nSims;

  // Build histogram
  const bucketMap = new Map<number, number>();
  for (const w of winCounts) {
    bucketMap.set(w, (bucketMap.get(w) ?? 0) + 1);
  }
  const minW = sorted[0];
  const maxW = sorted[sorted.length - 1];
  const winHistogram: { wins: number; count: number; pct: number }[] = [];
  for (let w = minW; w <= maxW; w++) {
    const count = bucketMap.get(w) ?? 0;
    winHistogram.push({ wins: w, count, pct: +(count / nSims).toFixed(4) });
  }

  const baseOutRunExpectancy24 = computeRunExpectancyMatrix(leagueProbs, config.seed);

  return {
    config,
    expectedWins: +mean.toFixed(2),
    sdWins: +sd.toFixed(2),
    mcStandardError: +mcSE.toFixed(3),
    p10Wins: q(0.1),
    p25Wins: q(0.25),
    p50Wins: q(0.5),
    p75Wins: q(0.75),
    p90Wins: q(0.9),
    expectedRunsScored: +(sumRS / nSims).toFixed(1),
    expectedRunsAllowed: +(sumRA / nSims).toFixed(1),
    probExceedTarget: +probExceedTarget.toFixed(4),
    playoffProbability: +playoffProbability.toFixed(4),
    winHistogram,
    baseOutRunExpectancy24,
    winDistributionSample: sorted,
    assumptionsDocumented: [
      `Schedule: ${nGames} balanced games against AIBL league composite opponents (offset ${(
        oppOffOffset * 1000
      ).toFixed(1)} pts).`,
      `Playoff probability defined strictly as >= ${playoffThreshold} wins (AIBL 4-team postseason format).`,
      `Extra innings: ${config.extraInningGhostRunner ? 'Automatic runner on 2B enabled starting 10th inning.' : 'Standard empty bases in extra innings.'}`,
      `Uncertainty separation: ${
        config.includeParameterUncertainty
          ? 'Outer loop samples true-talent posterior drift; inner loop simulates game-by-game play outcomes.'
          : 'Fixed point-estimate talent; game-level stochasticity only.'
      }`,
      `Missing innings / injured starters automatically backfilled with replacement-level AAA depth (~5.15 FIP).`,
    ],
  };
}
