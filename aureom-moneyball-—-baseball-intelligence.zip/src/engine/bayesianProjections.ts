import {
  aggregateBattingForPlayerSeason,
  aggregatePitchingForPlayerSeason,
  POSITIONAL_ADJ_PER_600PA,
} from './sabermetrics';
import type {
  BayesianProjection,
  DatasetStore,
  PAOutcomeProbs,
  PlayerMaster,
  SeasonContext,
} from './types';

function createPRNG(seed: number) {
  let s = seed >>> 0;
  return () => {
    s += 0x6d2b79f5;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Normal quantile approximation (Acklam)
function normInv(p: number): number {
  const a1 = -3.969683028665376e1;
  const a2 = 2.209460984245205e2;
  const a3 = -2.759285104469687e2;
  const a4 = 1.38357751867269e2;
  const a5 = -3.066479806614716e1;
  const a6 = 2.506628277459239;
  const b1 = -5.447609879822406e1;
  const b2 = 1.615858368580409e2;
  const b3 = -1.556989798598866e2;
  const b4 = 6.680131188771972e1;
  const b5 = -1.328068155288572e1;
  const c1 = -7.784894002430293e-3;
  const c2 = -3.223964580411365e-1;
  const c3 = -2.400758277161838;
  const c4 = -2.549732539343734;
  const c5 = 4.374664141464968;
  const c6 = 2.938163982698783;
  const d1 = 7.784695709041462e-3;
  const d2 = 3.224671290700398e-1;
  const d3 = 2.445134137142996;
  const d4 = 3.754408661907416;
  const pLow = 0.02425;
  const pHigh = 1 - pLow;

  if (p <= 0) return -4;
  if (p >= 1) return 4;
  if (p < pLow) {
    const q = Math.sqrt(-2 * Math.log(p));
    return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
      ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
  }
  if (p <= pHigh) {
    const q = p - 0.5;
    const r = q * q;
    return ((((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q) /
      (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1);
  }
  const q = Math.sqrt(-2 * Math.log(1 - p));
  return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
    ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
}

export function normalizePAProbs(raw: PAOutcomeProbs): PAOutcomeProbs {
  const vals = [
    Math.max(1e-6, raw.bbHbp),
    Math.max(1e-6, raw.so),
    Math.max(1e-6, raw.hr),
    Math.max(1e-6, raw.single),
    Math.max(1e-6, raw.double),
    Math.max(1e-6, raw.triple),
    Math.max(1e-6, raw.outInPlay),
  ];
  const sum = vals.reduce((a, b) => a + b, 0);
  return {
    bbHbp: vals[0] / sum,
    so: vals[1] / sum,
    hr: vals[2] / sum,
    single: vals[3] / sum,
    double: vals[4] / sum,
    triple: vals[5] / sum,
    outInPlay: vals[6] / sum,
  };
}

// Season recency weights (Marcel-style 5/4/3 for t-1, t-2, t-3)
function recencyWeight(deltaYears: number): number {
  if (deltaYears === 1) return 5;
  if (deltaYears === 2) return 4;
  if (deltaYears === 3) return 3;
  return Math.max(1, 3 - (deltaYears - 3));
}

export function buildBayesianProjections(
  store: DatasetStore,
  targetSeason: number,
  options?: {
    maxHistorySeason?: number; // Strictly enforce <= maxHistorySeason for backtesting!
    parkTeamOverride?: string;
    priorStrengthPA?: number;
    priorStrengthBF?: number;
  }
): Map<string, BayesianProjection> {
  const maxHistSeason = options?.maxHistorySeason ?? targetSeason - 1;
  const priorPA = options?.priorStrengthPA ?? 260; // Empirical-Bayes prior pseudo-PA for batters
  const priorBF = options?.priorStrengthBF ?? 220; // Empirical-Bayes prior pseudo-BF for pitchers

  const teamsMap = new Map(store.teams.map((t) => [t.teamId, t]));
  const seasonCtxTarget =
    store.seasons.find((s) => s.season === targetSeason) ??
    store.seasons[store.seasons.length - 1];

  // 1. Estimate empirical population priors across all available history <= maxHistSeason
  let popPA = 0,
    popBBHBP = 0,
    popSO = 0,
    popHR = 0,
    pop1B = 0,
    pop2B = 0,
    pop3B = 0,
    popOutIP = 0;

  let popBF = 0,
    popPK = 0,
    popPBB = 0,
    popPHR = 0,
    popPIP = 0,
    popPER = 0;

  const historicalBatMap = new Map<string, ReturnType<typeof aggregateBattingForPlayerSeason>[]>();
  const historicalPitchMap = new Map<string, ReturnType<typeof aggregatePitchingForPlayerSeason>[]>();

  const validSeasons = store.seasons
    .filter((s) => s.season <= maxHistSeason)
    .sort((a, b) => a.season - b.season);

  for (const sCtx of validSeasons) {
    for (const p of store.players) {
      if (!p.isPitcher) {
        const agg = aggregateBattingForPlayerSeason(
          p,
          store.battingStints,
          store.fieldingRecords,
          sCtx,
          teamsMap
        );
        if (agg && agg.pa > 0) {
          const list = historicalBatMap.get(p.playerId) ?? [];
          list.push(agg);
          historicalBatMap.set(p.playerId, list);

          popPA += agg.pa;
          popBBHBP += agg.bb + agg.hbp;
          popSO += agg.so;
          popHR += agg.hr;
          pop1B += agg.singles;
          pop2B += agg.doubles;
          pop3B += agg.triples;
          popOutIP += Math.max(0, agg.pa - (agg.bb + agg.hbp + agg.so + agg.hr + agg.singles + agg.doubles + agg.triples));
        }
      } else {
        const agg = aggregatePitchingForPlayerSeason(p, store.pitchingStints, sCtx, teamsMap);
        if (agg && agg.bf > 0 && agg.ip > 0) {
          const list = historicalPitchMap.get(p.playerId) ?? [];
          list.push(agg);
          historicalPitchMap.set(p.playerId, list);

          popBF += agg.bf;
          popPK += agg.so;
          popPBB += agg.bb + agg.hbp;
          popPHR += agg.hr;
          popPIP += agg.ip;
          popPER += agg.er;
        }
      }
    }
  }

  // Fallback empirical baseline if dataset empty
  const popProbs = normalizePAProbs(
    popPA > 0
      ? {
          bbHbp: popBBHBP / popPA,
          so: popSO / popPA,
          hr: popHR / popPA,
          single: pop1B / popPA,
          double: pop2B / popPA,
          triple: pop3B / popPA,
          outInPlay: popOutIP / popPA,
        }
      : {
          bbHbp: 0.095,
          so: 0.215,
          hr: 0.028,
          single: 0.155,
          double: 0.045,
          triple: 0.005,
          outInPlay: 0.457,
        }
  );

  const popPKRate = popBF > 0 ? popPK / popBF : 0.235;
  const popPBBRate = popBF > 0 ? popPBB / popBF : 0.078;
  const popPHRRate = popBF > 0 ? popPHR / popBF : 0.026;
  const popERA = popPIP > 0 ? (9 * popPER) / popPIP : 4.2;

  const result = new Map<string, BayesianProjection>();
  const rand = createPRNG(targetSeason * 97 + 13);

  for (const player of store.players) {
    const age = targetSeason - player.birthYear;
    // Smooth quadratic aging curve peaking at age 27 (standard empirical baseball delta)
    const ageAdjustmentLogOdds =
      age <= 27 ? (27 - age) * -0.008 : -(age - 27) * 0.018;
    const teamRef = options?.parkTeamOverride ?? player.currentTeamId ?? 'SHF';
    const parkTeam = teamsMap.get(teamRef);
    const parkFactorRuns = parkTeam ? parkTeam.parkFactorRuns : 100;
    const parkFactorHR = parkTeam ? parkTeam.parkFactorHR : 100;

    if (!player.isPitcher) {
      const histList = (historicalBatMap.get(player.playerId) ?? []).filter(Boolean) as NonNullable<
        ReturnType<typeof aggregateBattingForPlayerSeason>
      >[];

      // Weighted recent counts (neutralizing historical park factors toward 100 before pooling)
      let wPA = 0;
      let wBBHBP = 0,
        wSO = 0,
        wHR = 0,
        w1B = 0,
        w2B = 0,
        w3B = 0,
        wOutIP = 0;
      let wPAOppNum = 0,
        wPAOppDen = 0;
      let wFieldRuns = 0,
        wFieldPA = 0;
      let latestObsRate = popProbs.bbHbp + popProbs.single + popProbs.double + popProbs.triple + popProbs.hr;

      for (const h of histList) {
        const deltaY = Math.max(1, targetSeason - h.season);
        const rw = recencyWeight(deltaY) / 5; // normalize t-1 = 1.0, t-2 = 0.8, t-3 = 0.6
        const hTeam = teamsMap.get(h.teams[h.teams.length - 1] ?? 'SHF');
        const hPF = hTeam ? hTeam.parkFactorRuns / 100 : 1.0;
        const hPFHR = hTeam ? hTeam.parkFactorHR / 100 : 1.0;

        wPA += h.pa * rw;
        wBBHBP += (h.bb + h.hbp) * rw;
        wSO += h.so * rw;
        wHR += (h.hr / hPFHR) * rw;
        w1B += (h.singles / Math.sqrt(hPF)) * rw;
        w2B += (h.doubles / Math.sqrt(hPF)) * rw;
        w3B += h.triples * rw;
        const outIP = Math.max(0, h.pa - (h.bb + h.hbp + h.so + h.hr + h.singles + h.doubles + h.triples));
        wOutIP += outIP * rw;

        wPAOppNum += h.pa * rw;
        wPAOppDen += rw;
        wFieldRuns += h.fieldingRuns * rw;
        wFieldPA += h.pa * rw;

        if (h.season === maxHistSeason && h.obp !== null) {
          latestObsRate = h.obp;
        }
      }

      // Dirichlet-Multinomial Posterior: alpha_post = alpha_0 + weighted_observed_counts
      const alphaTotal = priorPA + wPA;
      const shrinkageWeight = wPA / alphaTotal;

      const postBBHBP = (priorPA * popProbs.bbHbp + wBBHBP) / alphaTotal;
      const postSO = (priorPA * popProbs.so + wSO) / alphaTotal;
      const postHR = ((priorPA * popProbs.hr + wHR) / alphaTotal) * (parkFactorHR / 100);
      const post1B = ((priorPA * popProbs.single + w1B) / alphaTotal) * Math.sqrt(parkFactorRuns / 100);
      const post2B = ((priorPA * popProbs.double + w2B) / alphaTotal) * Math.sqrt(parkFactorRuns / 100);
      const post3B = (priorPA * popProbs.triple + w3B) / alphaTotal;
      const postOutIP = (priorPA * popProbs.outInPlay + wOutIP) / alphaTotal;

      // Apply subtle aging shift to offensive production (HR & 1B/2B slightly adjusted, SO inversely)
      const ageOffMult = Math.exp(ageAdjustmentLogOdds);
      const paProbs = normalizePAProbs({
        bbHbp: postBBHBP * (0.97 + 0.03 * ageOffMult),
        so: postSO * (2 - ageOffMult) * 0.5 + postSO * 0.5,
        hr: postHR * ageOffMult,
        single: post1B * ageOffMult,
        double: post2B * ageOffMult,
        triple: post3B * (age <= 29 ? 1.0 : 0.9),
        outInPlay: postOutIP,
      });

      // Separated Playing Time Opportunity Estimate (PA)
      const basePosPA = player.primaryPos === 'C' ? 405 : 510;
      const rawEstPA = wPAOppDen > 0 ? 0.72 * (wPAOppNum / wPAOppDen) + 0.28 * basePosPA : basePosPA * 0.7;
      const availabilityMultiplier = player.expectedAvailabilityPct;
      const projectedPA = Math.round(Math.max(40, Math.min(620, rawEstPA * availabilityMultiplier)));

      // Compute projected rate metrics directly from posterior PA outcome vector
      const estNonBB = Math.max(0.5, 1 - paProbs.bbHbp - 0.008); // ~0.8% SF/SH
      const projBA = (paProbs.single + paProbs.double + paProbs.triple + paProbs.hr) / estNonBB;
      const projOBP = paProbs.bbHbp + paProbs.single + paProbs.double + paProbs.triple + paProbs.hr;
      const projSLG =
        (paProbs.single + 2 * paProbs.double + 3 * paProbs.triple + 4 * paProbs.hr) / estNonBB;
      const projWOBA =
        seasonCtxTarget.wBB * (paProbs.bbHbp * 0.91) +
        seasonCtxTarget.wHBP * (paProbs.bbHbp * 0.09) +
        seasonCtxTarget.w1B * paProbs.single +
        seasonCtxTarget.w2B * paProbs.double +
        seasonCtxTarget.w3B * paProbs.triple +
        seasonCtxTarget.wHR * paProbs.hr;

      const wRAA = ((projWOBA - seasonCtxTarget.lgWOBA) / seasonCtxTarget.wOBAScale) * projectedPA;
      const parkMult = parkFactorRuns / 100;
      const battingRuns = wRAA + (1 - parkMult) * seasonCtxTarget.rPerPA * projectedPA;
      const projWRCPlus =
        ((wRAA / Math.max(1, projectedPA) +
          seasonCtxTarget.rPerPA +
          (1 - parkMult) * seasonCtxTarget.rPerPA) /
          seasonCtxTarget.rPerPA) *
        100;

      // Shrunk defensive & baserunning runs
      const defPer600 = wFieldPA > 0 ? (wFieldRuns / wFieldPA) * 600 : 0;
      const shrunkDefRuns = (defPer600 * (wFieldPA / (wFieldPA + 450))) * (projectedPA / 600);
      const posAdjRuns = (projectedPA / 600) * (POSITIONAL_ADJ_PER_600PA[player.primaryPos] ?? 0);
      const repRuns = (projectedPA / 600) * seasonCtxTarget.replacementRunsPer600PA;
      const mWARMean = (battingRuns + shrunkDefRuns + posAdjRuns + repRuns) / seasonCtxTarget.runsPerWin;

      // Posterior variance for OBP & mWAR (Dirichlet variance scales inversely with alphaTotal + playing time uncertainty)
      const obpVar = (projOBP * (1 - projOBP)) / (alphaTotal + 1);
      const obpSD = Math.sqrt(obpVar) + 0.011; // includes year-to-year true talent drift
      const obpLow80 = Math.max(0.18, projOBP + normInv(0.1) * obpSD);
      const obpHigh80 = Math.min(0.52, projOBP + normInv(0.9) * obpSD);

      // mWAR uncertainty combines rate posterior SD + playing-time variance
      const rateWARSD = ((obpSD * 1.45) / seasonCtxTarget.wOBAScale) * (projectedPA / seasonCtxTarget.runsPerWin);
      const ptWARSD = Math.abs(mWARMean) * 0.14 + 0.25;
      const mWARSD = Math.sqrt(rateWARSD * rateWARSD + ptWARSD * ptWARSD);

      // Posterior Predictive Check (PPC): draw 80 binomial/multinomial replicates at observed sample size
      const nCheck = Math.max(60, Math.round(wPA));
      let exceedCount = 0;
      let repSum = 0;
      for (let d = 0; d < 80; d++) {
        // Sample OBP draw from posterior Beta approximation + Binomial replicate
        const pDraw = Math.max(0.15, Math.min(0.55, projOBP + (rand() - 0.5) * 2.2 * Math.sqrt(obpVar)));
        let hits = 0;
        for (let k = 0; k < nCheck; k++) {
          if (rand() < pDraw) hits++;
        }
        const repOBP = hits / nCheck;
        repSum += repOBP;
        if (repOBP >= latestObsRate) exceedCount++;
      }

      result.set(player.playerId, {
        playerId: player.playerId,
        targetSeason,
        modelVersion: store.modelVersion,
        isPitcher: false,
        projectedPA,
        projectedIP: 0,
        availabilityMultiplier,
        ageAtTarget: age,
        ageAdjustmentLogOdds,
        parkFactorApplied: parkFactorRuns,
        priorSampleSize: priorPA,
        observedWeightedSampleSize: Math.round(wPA),
        shrinkageWeight,
        projBA,
        projOBP,
        projSLG,
        projWOBA,
        projWRCPlus,
        projBBPct: paProbs.bbHbp * 0.91,
        projKPct: paProbs.so,
        projHRRate: paProbs.hr,
        projFIP: null,
        projERA: null,
        paProbs,
        mWARMean,
        mWARSD,
        mWARLow80: mWARMean + normInv(0.1) * mWARSD,
        mWARHigh80: mWARMean + normInv(0.9) * mWARSD,
        mWARLow95: mWARMean + normInv(0.025) * mWARSD,
        mWARHigh95: mWARMean + normInv(0.975) * mWARSD,
        obpLow80,
        obpHigh80,
        fipLow80: null,
        fipHigh80: null,
        ppcReplicateMean: repSum / 80,
        ppcObservedRate: latestObsRate,
        ppcBayesianPValue: exceedCount / 80,
      });
    } else {
      // PITCHER BAYESIAN PROJECTION (Beta-Binomial on K%, BB%, HR/BF)
      const histList = (historicalPitchMap.get(player.playerId) ?? []).filter(Boolean) as NonNullable<
        ReturnType<typeof aggregatePitchingForPlayerSeason>
      >[];

      let wBF = 0,
        wSO = 0,
        wBBHBP = 0,
        wHR = 0,
        wIP = 0,
        wER = 0;
      let wIPOppNum = 0,
        wIPOppDen = 0;
      let latestFIP = seasonCtxTarget.lgFIP;

      for (const h of histList) {
        const deltaY = Math.max(1, targetSeason - h.season);
        const rw = recencyWeight(deltaY) / 5;
        const hTeam = teamsMap.get(h.teams[h.teams.length - 1] ?? 'SHF');
        const hPF = hTeam ? hTeam.parkFactorRuns / 100 : 1.0;

        wBF += h.bf * rw;
        wSO += h.so * rw;
        wBBHBP += (h.bb + h.hbp) * rw;
        wHR += (h.hr / hPF) * rw;
        wIP += h.ip * rw;
        wER += (h.er / hPF) * rw;
        wIPOppNum += h.ip * rw;
        wIPOppDen += rw;
        if (h.season === maxHistSeason && h.fip !== null) {
          latestFIP = h.fip;
        }
      }

      const alphaTotal = priorBF + wBF;
      const shrinkageWeight = wBF / alphaTotal;
      const ageDecline = age > 29 ? (age - 29) * 0.04 : 0;

      const postK = (priorBF * popPKRate + wSO) / alphaTotal - ageDecline * 0.015;
      const postBB = (priorBF * popPBBRate + wBBHBP) / alphaTotal + ageDecline * 0.008;
      const postHR = ((priorBF * popPHRRate + wHR) / alphaTotal) * (parkFactorHR / 100);

      // Convert component rates per BF (~4.22 BF per IP) into projected FIP
      const bfPerIP = 4.22 + (postBB - popPBBRate) * 1.4 - (postK - popPKRate) * 0.6;
      const projFIP =
        (13 * postHR * bfPerIP + 3 * postBB * bfPerIP - 2 * postK * bfPerIP) +
        seasonCtxTarget.cFIP;
      const obsERA = wIP > 0 ? (9 * wER) / wIP : popERA;
      // Blend FIP and regressed ERA for ERA projection (recognizing FIP predicts future ERA better than noisy ERA)
      const projERA = 0.72 * projFIP + 0.28 * ((wIP * obsERA + 120 * popERA) / (wIP + 120)) * (parkFactorRuns / 100);

      const defaultIP = player.pitchingRole === 'SP' ? 145 : 58;
      const rawEstIP = wIPOppDen > 0 ? 0.72 * (wIPOppNum / wIPOppDen) + 0.28 * defaultIP : defaultIP * 0.8;
      const projectedIP = Math.round(Math.max(15, Math.min(205, rawEstIP * player.expectedAvailabilityPct)));

      const pitchingRuns = ((seasonCtxTarget.lgFIP - projFIP) / 9) * projectedIP;
      const repMult = player.pitchingRole === 'SP' ? 1.0 : 1.15;
      const repRuns = (projectedIP / 200) * seasonCtxTarget.replacementRunsPer200IP * repMult;
      const mWARMean = (pitchingRuns + repRuns) / seasonCtxTarget.runsPerWin;

      const fipSD = 0.34 + 2.4 / Math.sqrt(Math.max(40, alphaTotal));
      const fipLow80 = Math.max(1.8, projFIP + normInv(0.1) * fipSD);
      const fipHigh80 = Math.min(6.8, projFIP + normInv(0.9) * fipSD);

      const rateWARSD = ((fipSD / 9) * projectedIP) / seasonCtxTarget.runsPerWin;
      const ptWARSD = Math.abs(mWARMean) * 0.16 + 0.22;
      const mWARSD = Math.sqrt(rateWARSD * rateWARSD + ptWARSD * ptWARSD);

      // Pitcher opposing PA outcome vector (used by Monte Carlo matchup engine)
      const paProbs = normalizePAProbs({
        bbHbp: Math.max(0.03, postBB),
        so: Math.max(0.08, postK),
        hr: Math.max(0.006, postHR),
        single: 0.152,
        double: 0.044,
        triple: 0.005,
        outInPlay: Math.max(0.25, 1 - postBB - postK - postHR - 0.201),
      });

      // PPC for FIP
      let exceedCount = 0;
      let repSum = 0;
      for (let d = 0; d < 80; d++) {
        const repFIP = projFIP + (rand() - 0.5) * 2.2 * fipSD;
        repSum += repFIP;
        if (repFIP >= latestFIP) exceedCount++;
      }

      result.set(player.playerId, {
        playerId: player.playerId,
        targetSeason,
        modelVersion: store.modelVersion,
        isPitcher: true,
        projectedPA: 0,
        projectedIP,
        availabilityMultiplier: player.expectedAvailabilityPct,
        ageAtTarget: age,
        ageAdjustmentLogOdds,
        parkFactorApplied: parkFactorRuns,
        priorSampleSize: priorBF,
        observedWeightedSampleSize: Math.round(wBF),
        shrinkageWeight,
        projBA: 0.248,
        projOBP: 0.315,
        projSLG: 0.398,
        projWOBA: 0.315,
        projWRCPlus: 100,
        projBBPct: postBB,
        projKPct: postK,
        projHRRate: postHR,
        projFIP,
        projERA,
        paProbs,
        mWARMean,
        mWARSD,
        mWARLow80: mWARMean + normInv(0.1) * mWARSD,
        mWARHigh80: mWARMean + normInv(0.9) * mWARSD,
        mWARLow95: mWARMean + normInv(0.025) * mWARSD,
        mWARHigh95: mWARMean + normInv(0.975) * mWARSD,
        obpLow80: 0,
        obpHigh80: 0,
        fipLow80,
        fipHigh80,
        ppcReplicateMean: repSum / 80,
        ppcObservedRate: latestFIP,
        ppcBayesianPValue: exceedCount / 80,
      });
    }
  }

  return result;
}
