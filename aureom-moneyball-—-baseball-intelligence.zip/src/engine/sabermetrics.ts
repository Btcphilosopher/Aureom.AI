import type {
  BattingStint,
  FieldingRecord,
  PitchingStint,
  PlayerMaster,
  PositionCode,
  SabermetricBatting,
  SabermetricPitching,
  SeasonContext,
  TeamRecord,
} from './types';

// Positional adjustments in runs per 140-game / 600 PA season (transparent documented scale)
export const POSITIONAL_ADJ_PER_600PA: Record<PositionCode, number> = {
  C: 10.5,
  SS: 6.5,
  CF: 2.5,
  '2B': 2.5,
  '3B': 2.0,
  RF: -5.5,
  LF: -5.5,
  '1B': -10.5,
  DH: -14.5,
  SP: 0,
  RP: 0,
};

export function safeDiv(numerator: number, denominator: number): number | null {
  if (!Number.isFinite(numerator) || !Number.isFinite(denominator) || denominator <= 0) {
    return null;
  }
  return numerator / denominator;
}

/**
 * Aggregates batting stints from underlying counts (never averaging rates)
 * and prevents double-counting if multi-team stints exist.
 */
export function aggregateBattingForPlayerSeason(
  player: PlayerMaster,
  stints: BattingStint[],
  fielding: FieldingRecord[],
  seasonCtx: SeasonContext,
  teamsMap: Map<string, TeamRecord>
): SabermetricBatting | null {
  // Filter to full-split ('ALL') stints for player & season to avoid double-counting platoon splits
  const seasonStints = stints.filter(
    (s) => s.playerId === player.playerId && s.season === seasonCtx.season && s.splitVsHand === 'ALL'
  );
  if (seasonStints.length === 0) return null;

  // Deduplicate by stintId / teamId+stintOrder
  const seen = new Set<string>();
  const uniqueStints: BattingStint[] = [];
  for (const s of seasonStints) {
    const key = `${s.teamId}_${s.stintOrder}`;
    if (!seen.has(key)) {
      seen.add(key);
      uniqueStints.push(s);
    }
  }

  let g = 0,
    pa = 0,
    ab = 0,
    h = 0,
    doubles = 0,
    triples = 0,
    hr = 0,
    bb = 0,
    ibb = 0,
    hbp = 0,
    so = 0,
    sf = 0,
    sh = 0,
    sb = 0,
    cs = 0,
    gdp = 0;

  let weightedParkSum = 0;
  let paForPark = 0;
  const teamIds: string[] = [];

  for (const s of uniqueStints) {
    g += s.g;
    pa += s.pa;
    ab += s.ab;
    h += s.h;
    doubles += s.doubles;
    triples += s.triples;
    hr += s.hr;
    bb += s.bb;
    ibb += s.ibb;
    hbp += s.hbp;
    so += s.so;
    sf += s.sf;
    sh += s.sh;
    sb += s.sb;
    cs += s.cs;
    gdp += s.gdp;
    if (!teamIds.includes(s.teamId)) teamIds.push(s.teamId);
    const tm = teamsMap.get(s.teamId);
    const pf = tm ? tm.parkFactorRuns : 100;
    weightedParkSum += pf * Math.max(s.pa, 1);
    paForPark += Math.max(s.pa, 1);
  }

  const warnings: string[] = [];
  if (pa < 50) {
    warnings.push(`Small sample (${pa} PA): rate stats subject to high sampling variance.`);
  }

  const singles = Math.max(0, h - doubles - triples - hr);
  const totalBases = singles + 2 * doubles + 3 * triples + 4 * hr;

  const ba = safeDiv(h, ab);
  const obpDenom = ab + bb + hbp + sf;
  const obp = safeDiv(h + bb + hbp, obpDenom);
  const slg = safeDiv(totalBases, ab);
  const ops = obp !== null && slg !== null ? obp + slg : null;
  const iso = slg !== null && ba !== null ? slg - ba : null;
  const bbPct = safeDiv(bb, pa);
  const kPct = safeDiv(so, pa);
  const babipDenom = ab - so - hr + sf;
  const babip = safeDiv(h - hr, babipDenom);

  if (ab === 0) warnings.push('Zero at-bats (AB=0): BA and SLG undefined.');
  if (babipDenom <= 0) warnings.push('Zero balls-in-play denominator: BABIP undefined.');

  const uBB = Math.max(0, bb - ibb);
  const wOBA_Denom = ab + uBB + sf + hbp;
  const wOBA_Num =
    seasonCtx.wBB * uBB +
    seasonCtx.wHBP * hbp +
    seasonCtx.w1B * singles +
    seasonCtx.w2B * doubles +
    seasonCtx.w3B * triples +
    seasonCtx.wHR * hr;
  const wOBA = safeDiv(wOBA_Num, wOBA_Denom);

  const wRAA =
    wOBA !== null && pa > 0
      ? ((wOBA - seasonCtx.lgWOBA) / seasonCtx.wOBAScale) * pa
      : null;

  const avgParkFactor = paForPark > 0 ? weightedParkSum / paForPark : 100;
  const parkMultiplier = avgParkFactor / 100;

  let wRCPlus: number | null = null;
  let battingRuns = 0;
  if (wRAA !== null && pa > 0 && seasonCtx.rPerPA > 0) {
    // Standard park-adjusted wRC+ formula relative to league R/PA
    const parkAdjRuns = wRAA + (1 - parkMultiplier) * seasonCtx.rPerPA * pa;
    battingRuns = parkAdjRuns;
    const wRCPerPA = (wRAA / pa + seasonCtx.rPerPA + (1 - parkMultiplier) * seasonCtx.rPerPA);
    wRCPlus = (wRCPerPA / seasonCtx.rPerPA) * 100;
  }

  // Transparent baserunning runs: +0.20 per SB, -0.42 per CS, -0.18 per excess GDP
  const baserunningRuns = sb * 0.2 - cs * 0.42 - gdp * 0.08;

  // Fielding runs from range + arm + framing (NOT errors alone)
  const playerFielding = fielding.filter(
    (f) => f.playerId === player.playerId && f.season === seasonCtx.season
  );
  let fieldingRuns = 0;
  let totalInn = 0;
  for (const f of playerFielding) {
    fieldingRuns += f.rangeRunsEst + f.armRunsEst + f.framingRunsEst;
    totalInn += f.inn;
  }

  const posAdjPer600 = POSITIONAL_ADJ_PER_600PA[player.primaryPos] ?? 0;
  const positionalAdjRuns = (pa / 600) * posAdjPer600;
  const replacementRuns = (pa / 600) * seasonCtx.replacementRunsPer600PA;

  const totalRunsAboveReplacement =
    battingRuns + baserunningRuns + fieldingRuns + positionalAdjRuns + replacementRuns;
  const modelledWAR = totalRunsAboveReplacement / seasonCtx.runsPerWin;

  if (playerFielding.length === 0 && !player.isPitcher && player.primaryPos !== 'DH') {
    warnings.push('No granular fielding innings recorded; defensive runs defaulted to 0.0.');
  }

  return {
    playerId: player.playerId,
    season: seasonCtx.season,
    teams: teamIds,
    stintCount: uniqueStints.length,
    g,
    pa,
    ab,
    h,
    singles,
    doubles,
    triples,
    hr,
    bb,
    hbp,
    so,
    sf,
    sh,
    sb,
    cs,
    gdp,
    ba,
    obp,
    slg,
    ops,
    iso,
    bbPct,
    kPct,
    babip,
    wOBA,
    wRAA,
    wRCPlus,
    battingRuns,
    baserunningRuns,
    fieldingRuns,
    positionalAdjRuns,
    replacementRuns,
    modelledWAR,
    warnings,
  };
}

export function aggregatePitchingForPlayerSeason(
  player: PlayerMaster,
  stints: PitchingStint[],
  seasonCtx: SeasonContext,
  teamsMap: Map<string, TeamRecord>
): SabermetricPitching | null {
  const seasonStints = stints.filter(
    (s) => s.playerId === player.playerId && s.season === seasonCtx.season
  );
  if (seasonStints.length === 0) return null;

  const seen = new Set<string>();
  const uniqueStints: PitchingStint[] = [];
  for (const s of seasonStints) {
    const key = `${s.teamId}_${s.stintOrder}`;
    if (!seen.has(key)) {
      seen.add(key);
      uniqueStints.push(s);
    }
  }

  let g = 0,
    gs = 0,
    outsRecorded = 0,
    bf = 0,
    h = 0,
    er = 0,
    r = 0,
    hr = 0,
    bb = 0,
    hbp = 0,
    so = 0;

  let weightedParkSum = 0;
  let bfForPark = 0;
  const teamIds: string[] = [];

  for (const s of uniqueStints) {
    g += s.g;
    gs += s.gs;
    outsRecorded += s.outsRecorded;
    bf += s.bf;
    h += s.h;
    er += s.er;
    r += s.r;
    hr += s.hr;
    bb += s.bb;
    hbp += s.hbp;
    so += s.so;
    if (!teamIds.includes(s.teamId)) teamIds.push(s.teamId);
    const tm = teamsMap.get(s.teamId);
    const pf = tm ? tm.parkFactorRuns : 100;
    weightedParkSum += pf * Math.max(s.bf, 1);
    bfForPark += Math.max(s.bf, 1);
  }

  const warnings: string[] = [];
  const ip = outsRecorded / 3;
  if (ip <= 0) {
    warnings.push('Zero innings pitched (IP=0): rate statistics ERA, WHIP, HR/9, FIP undefined.');
  } else if (ip < 20) {
    warnings.push(`Small pitching sample (${ip.toFixed(1)} IP): FIP and ERA have wide variance.`);
  }

  const era = ip > 0 ? (9 * er) / ip : null;
  const whip = ip > 0 ? (bb + h) / ip : null;
  const kPct = safeDiv(so, bf);
  const bbPct = safeDiv(bb, bf);
  const kMinusBBPct = kPct !== null && bbPct !== null ? kPct - bbPct : null;
  const hrPer9 = ip > 0 ? (9 * hr) / ip : null;
  const fip =
    ip > 0 ? (13 * hr + 3 * (bb + hbp) - 2 * so) / ip + seasonCtx.cFIP : null;

  const avgPark = bfForPark > 0 ? weightedParkSum / bfForPark : 100;
  const parkAdjFIP = fip !== null ? fip / (avgPark / 100) : null;

  // Pitching Runs Above Average (FIP-based) + Replacement Level
  const pitchingRunsFIP =
    parkAdjFIP !== null && ip > 0 ? ((seasonCtx.lgFIP - parkAdjFIP) / 9) * ip : 0;
  const role: 'SP' | 'RP' | 'CL' =
    gs >= Math.max(1, g * 0.4) ? 'SP' : player.pitchingRole === 'CL' ? 'CL' : 'RP';
  // Relievers get slightly higher replacement baseline per IP because of higher leverage / lower volume
  const repMultiplier = role === 'SP' ? 1.0 : 1.15;
  const replacementRuns = (ip / 200) * seasonCtx.replacementRunsPer200IP * repMultiplier;
  const modelledWAR = (pitchingRunsFIP + replacementRuns) / seasonCtx.runsPerWin;

  return {
    playerId: player.playerId,
    season: seasonCtx.season,
    teams: teamIds,
    stintCount: uniqueStints.length,
    role,
    g,
    gs,
    ip,
    outsRecorded,
    bf,
    h,
    er,
    r,
    hr,
    bb,
    hbp,
    so,
    era,
    whip,
    kPct,
    bbPct,
    kMinusBBPct,
    hrPer9,
    fip,
    pitchingRunsFIP,
    replacementRuns,
    modelledWAR,
    warnings,
  };
}

export function formatIP(outsRecorded: number): string {
  const whole = Math.floor(outsRecorded / 3);
  const rem = outsRecorded % 3;
  return `${whole}.${rem}`;
}
