export type Handedness = 'L' | 'R' | 'S';
export type PositionCode = 'C' | '1B' | '2B' | '3B' | 'SS' | 'LF' | 'CF' | 'RF' | 'DH' | 'SP' | 'RP';
export type PitchingRole = 'SP' | 'RP' | 'CL' | 'NONE';
export type DataGranularity = 'stint_split' | 'season_aggregate' | 'game_log';
export type AvailabilityStatus = 'Rostered' | 'Free Agent' | 'Trade Target' | 'Injured List' | 'Restricted';

export interface DataProvenance {
  sourceId: string;
  sourceName: string;
  adapterType: 'synthetic_aibl' | 'lahman_adapter' | 'retrosheet_adapter';
  granularity: DataGranularity;
  license: string;
  retrievedAt: string;
  notes: string;
}

export interface TeamRecord {
  teamId: string;
  name: string;
  shortName: string;
  division: 'North' | 'South';
  stadium: string;
  parkFactorRuns: number; // 100 = neutral
  parkFactorHR: number;   // 100 = neutral
  budgetCapM: number;
  currentPayrollM: number;
}

export interface SeasonContext {
  season: number;
  competition: string;
  gamesPerTeam: number;
  playoffSpots: number;
  // Documented seasonal linear weights (v. transparent wOBA / FIP constants)
  wBB: number;
  wHBP: number;
  w1B: number;
  w2B: number;
  w3B: number;
  wHR: number;
  lgWOBA: number;
  wOBAScale: number;
  rPerPA: number;
  lgFIP: number;
  cFIP: number;
  runsPerWin: number;
  replacementRunsPer600PA: number;
  replacementRunsPer200IP: number;
}

export interface PlayerMaster {
  playerId: string;
  fullName: string;
  birthYear: number;
  bats: Handedness;
  throws: Handedness;
  primaryPos: PositionCode;
  eligiblePositions: PositionCode[];
  pitchingRole: PitchingRole;
  isPitcher: boolean;
  // Contract & acquisition separation
  currentTeamId: string | null; // null if FA
  salaryM: number;
  tradeCostM: number; // Estimated prospect/cash acquisition cost (0 for FA or rostered)
  yearsControl: number;
  contractType: 'Pre-Arb' | 'Arbitration' | 'Guaranteed' | 'Minor/Split' | 'Free Agent';
  availability: AvailabilityStatus;
  healthRiskNote: string;
  expectedAvailabilityPct: number; // 0..1 user-configurable assumption
}

export interface BattingStint {
  stintId: string;
  playerId: string;
  season: number;
  teamId: string;
  stintOrder: number;
  splitVsHand: 'ALL' | 'LHP' | 'RHP';
  g: number;
  pa: number;
  ab: number;
  h: number;
  doubles: number;
  triples: number;
  hr: number;
  r: number;
  rbi: number;
  bb: number;
  ibb: number;
  hbp: number;
  so: number;
  sf: number;
  sh: number;
  sb: number;
  cs: number;
  gdp: number;
  granularity: DataGranularity;
  sourceId: string;
}

export interface PitchingStint {
  stintId: string;
  playerId: string;
  season: number;
  teamId: string;
  stintOrder: number;
  role: 'SP' | 'RP' | 'CL';
  g: number;
  gs: number;
  outsRecorded: number; // IP = outsRecorded / 3
  bf: number;
  h: number;
  er: number;
  r: number;
  hr: number;
  bb: number;
  ibb: number;
  hbp: number;
  so: number;
  gbOuts: number;
  fbOuts: number;
  granularity: DataGranularity;
  sourceId: string;
}

export interface FieldingRecord {
  recordId: string;
  playerId: string;
  season: number;
  teamId: string;
  pos: PositionCode;
  g: number;
  inn: number;
  po: number;
  a: number;
  e: number;
  dp: number;
  rangeRunsEst: number; // Synthetic defensive runs component (not errors alone)
  armRunsEst: number;
  framingRunsEst: number; // Catchers only
  sourceId: string;
}

export interface TransactionRecord {
  txId: string;
  date: string; // YYYY-MM-DD
  playerId: string;
  fromTeamId: string | null;
  toTeamId: string | null;
  txType: 'TRADE' | 'SIGNING' | 'WAIVER' | 'IL_PLACEMENT' | 'ACTIVATION';
  notes: string;
}

export interface ScoutingReport {
  reportId: string;
  playerId: string;
  observer: string;
  date: string;
  roleProjection: string;
  gradeOverall2080: number;
  hitGrade: number;
  powerGrade: number;
  speedGrade: number;
  fieldGrade: number;
  armOrStuffGrade: number;
  confidence: 'Low' | 'Medium' | 'High';
  notes: string;
  evidence: string;
  followUpAction: string;
}

export interface SabermetricBatting {
  playerId: string;
  season: number;
  teams: string[];
  stintCount: number;
  g: number;
  pa: number;
  ab: number;
  h: number;
  singles: number;
  doubles: number;
  triples: number;
  hr: number;
  bb: number;
  hbp: number;
  so: number;
  sf: number;
  sh: number;
  sb: number;
  cs: number;
  gdp: number;
  ba: number | null;
  obp: number | null;
  slg: number | null;
  ops: number | null;
  iso: number | null;
  bbPct: number | null;
  kPct: number | null;
  babip: number | null;
  wOBA: number | null;
  wRAA: number | null;
  wRCPlus: number | null;
  battingRuns: number;
  baserunningRuns: number;
  fieldingRuns: number;
  positionalAdjRuns: number;
  replacementRuns: number;
  modelledWAR: number;
  warnings: string[];
}

export interface SabermetricPitching {
  playerId: string;
  season: number;
  teams: string[];
  stintCount: number;
  role: 'SP' | 'RP' | 'CL';
  g: number;
  gs: number;
  ip: number;
  outsRecorded: number;
  bf: number;
  h: number;
  er: number;
  r: number;
  hr: number;
  bb: number;
  hbp: number;
  so: number;
  era: number | null;
  whip: number | null;
  kPct: number | null;
  bbPct: number | null;
  kMinusBBPct: number | null;
  hrPer9: number | null;
  fip: number | null;
  pitchingRunsFIP: number;
  replacementRuns: number;
  modelledWAR: number;
  warnings: string[];
}

export interface PAOutcomeProbs {
  bbHbp: number;
  so: number;
  hr: number;
  single: number;
  double: number;
  triple: number;
  outInPlay: number;
}

export interface BayesianProjection {
  playerId: string;
  targetSeason: number;
  modelVersion: string;
  isPitcher: boolean;
  // Separated opportunity vs rate
  projectedPA: number;
  projectedIP: number;
  availabilityMultiplier: number;
  ageAtTarget: number;
  ageAdjustmentLogOdds: number;
  parkFactorApplied: number;
  // Prior vs Likelihood vs Posterior transparency
  priorSampleSize: number; // effective prior PA or BF
  observedWeightedSampleSize: number;
  shrinkageWeight: number; // weight given to observed data: obs / (obs + prior)
  // Rate projections (mean and 80% / 95% credible intervals)
  projBA: number;
  projOBP: number;
  projSLG: number;
  projWOBA: number;
  projWRCPlus: number;
  projBBPct: number;
  projKPct: number;
  projHRRate: number;
  projFIP: number | null;
  projERA: number | null;
  // Outcome probability vector (sums strictly to 1.0)
  paProbs: PAOutcomeProbs;
  // Credible intervals (explicitly uncertainty, not guarantees)
  mWARMean: number;
  mWARSD: number;
  mWARLow80: number;
  mWARHigh80: number;
  mWARLow95: number;
  mWARHigh95: number;
  obpLow80: number;
  obpHigh80: number;
  fipLow80: number | null;
  fipHigh80: number | null;
  // Posterior predictive check summary
  ppcReplicateMean: number;
  ppcObservedRate: number;
  ppcBayesianPValue: number;
}

export interface PlayerValuationRow {
  player: PlayerMaster;
  projection: BayesianProjection;
  historicalBat: SabermetricBatting | null;
  historicalPitch: SabermetricPitching | null;
  totalEffectiveCostM: number; // salary + amortized/explicit trade cost
  mWARPerMillion: number;
  surplusValueM: number; // (mWAR * $/WAR) - totalEffectiveCostM
  platoonDeltaOBP: number; // shrunk platoon edge vs opposite hand
  inefficiencyReasons: string[];
  acquirableForTeam: boolean;
}

export interface OptimizerConfig {
  teamId: string;
  targetSeason: number;
  budgetCapM: number;
  rosterSize: number;
  requiredPositions: Record<'C' | '1B' | '2B' | '3B' | 'SS' | 'LF' | 'CF' | 'RF' | 'DH', number>;
  requiredSP: number;
  requiredRP: number;
  minBench: number;
  maxNewAcquisitions: number;
  objective: 'max_mwar' | 'min_cost_target' | 'risk_adjusted';
  targetMWAR: number;
  riskAversionLambda: number;
  lockedPlayerIds: string[];
  excludedPlayerIds: string[];
  includeInjured: boolean;
  ruleSetName: string;
}

export interface AssignedRosterPlayer {
  player: PlayerMaster;
  projection: BayesianProjection;
  assignedSlot: string; // e.g., 'SS', 'BENCH_1', 'SP_1', 'RP_2'
  isNewAcquisition: boolean;
  effectiveCostM: number;
}

export interface OptimizerResult {
  feasible: boolean;
  statusMessage: string;
  unmetConstraints: string[];
  objectiveUsed: string;
  ruleSetName: string;
  selectedRoster: AssignedRosterPlayer[];
  totalSalaryM: number;
  totalTradeCostM: number;
  totalEffectiveCostM: number;
  budgetRemainingM: number;
  totalExpectedMWAR: number;
  portfolioSDMWAR: number;
  riskAdjustedScore: number;
  newAcquisitionsCount: number;
  alternatives: {
    label: string;
    totalEffectiveCostM: number;
    totalExpectedMWAR: number;
    portfolioSDMWAR: number;
    keyDifference: string;
    playerIds: string[];
  }[];
  approximationWarning: string;
}

export interface SimulationConfig {
  teamId: string;
  targetSeason: number;
  numSimulations: number;
  seed: number;
  useCommonRandomNumbers: boolean;
  includeParameterUncertainty: boolean;
  extraInningGhostRunner: boolean;
  winTarget: number;
  opponentStrengthOffset: number; // 0 = league average, +0.020 = tougher
  rosterPlayerIds: string[];
  unavailablePlayerIds: string[]; // injury / lost playing time test
  lineupOrderIds: string[]; // 9 batters
  splitScenario: 'Neutral' | 'vsLHP' | 'vsRHP';
}

export interface SimulationSummary {
  config: SimulationConfig;
  expectedWins: number;
  sdWins: number;
  mcStandardError: number;
  p10Wins: number;
  p25Wins: number;
  p50Wins: number;
  p75Wins: number;
  p90Wins: number;
  expectedRunsScored: number;
  expectedRunsAllowed: number;
  probExceedTarget: number;
  playoffProbability: number;
  winHistogram: { wins: number; count: number; pct: number }[];
  baseOutRunExpectancy24: number[][]; // 8 base states x 3 outs
  assumptionsDocumented: string[];
  winDistributionSample: number[];
}

export interface BacktestMetrics {
  originSeason: number;
  evalSeason: number;
  trainCutoffDate: string;
  nBatters: number;
  nPitchers: number;
  // Rate error (OBP for batters, FIP for pitchers)
  bayesianOBP_MAE: number;
  naiveOBP_MAE: number;
  leagueMeanOBP_MAE: number;
  bayesianOBP_RMSE: number;
  bayesianFIP_MAE: number;
  naiveFIP_MAE: number;
  // Playing time error
  pa_MAE: number;
  // Calibration
  coverage80Pct_Batters: number;
  coverage80Pct_Pitchers: number;
  // Leakage audit checks
  leakageChecks: { check: string; passed: boolean; detail: string }[];
  playerComparisons: {
    playerId: string;
    fullName: string;
    role: string;
    predOBPOrFIP: number;
    actualOBPOrFIP: number;
    naivePred: number;
    low80: number;
    high80: number;
    within80: boolean;
  }[];
}

export interface DatasetStore {
  provenances: DataProvenance[];
  teams: TeamRecord[];
  seasons: SeasonContext[];
  players: PlayerMaster[];
  battingStints: BattingStint[];
  pitchingStints: PitchingStint[];
  fieldingRecords: FieldingRecord[];
  transactions: TransactionRecord[];
  scoutingReports: ScoutingReport[];
  lastRefreshedAt: string;
  modelVersion: string;
}
