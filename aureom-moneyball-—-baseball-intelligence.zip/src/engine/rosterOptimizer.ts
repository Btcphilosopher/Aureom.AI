import type {
  AssignedRosterPlayer,
  BayesianProjection,
  DatasetStore,
  OptimizerConfig,
  OptimizerResult,
  PlayerMaster,
  PositionCode,
} from './types';

type StartingPos = 'C' | '1B' | '2B' | '3B' | 'SS' | 'LF' | 'CF' | 'RF' | 'DH';
const STARTING_POSITIONS: StartingPos[] = ['C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH'];

interface CandidateItem {
  player: PlayerMaster;
  projection: BayesianProjection;
  effectiveCostM: number;
  isNewAcquisition: boolean;
  isLocked: boolean;
  utility: number;
}

/**
 * Exact bipartite matching (Kuhn's augmenting path) ensuring NO multi-position
 * player simultaneously fills two required starting slots.
 */
export function assignPlayersToSlots(
  selected: CandidateItem[],
  config: OptimizerConfig
): { valid: boolean; assignments: AssignedRosterPlayer[]; unmet: string[] } {
  const unmet: string[] = [];

  const requiredBatterSlots: StartingPos[] = [];
  for (const pos of STARTING_POSITIONS) {
    const count = config.requiredPositions[pos] ?? 0;
    for (let i = 0; i < count; i++) requiredBatterSlots.push(pos);
  }

  const batters = selected.filter((c) => !c.player.isPitcher);
  const pitchers = selected.filter((c) => c.player.isPitcher);

  const spList = pitchers.filter((p) => p.player.pitchingRole === 'SP');
  const rpList = pitchers.filter((p) => p.player.pitchingRole !== 'SP');
  // Allow SP/RP swingmen in RP if needed
  const swingToRP = spList.filter((p) => p.player.eligiblePositions.includes('RP'));

  if (spList.length < config.requiredSP) {
    unmet.push(`Need ${config.requiredSP} SP, only ${spList.length} selected.`);
  }
  const availableRP = rpList.length + Math.max(0, Math.min(swingToRP.length, spList.length - config.requiredSP));
  if (availableRP < config.requiredRP) {
    unmet.push(`Need ${config.requiredRP} RP/CL, only ${availableRP} available.`);
  }
  if (batters.length < requiredBatterSlots.length + config.minBench) {
    unmet.push(
      `Need at least ${requiredBatterSlots.length + config.minBench} position players (${requiredBatterSlots.length} starters + ${config.minBench} bench), have ${batters.length}.`
    );
  }

  // Bipartite matching: match each requiredBatterSlot -> distinct batter
  const slotToBatter = new Array<number>(requiredBatterSlots.length).fill(-1);
  const batterToSlot = new Array<number>(batters.length).fill(-1);

  // Order batters so higher-mWAR players get priority for starting slots
  const sortedBatters = [...batters].sort((a, b) => b.projection.mWARMean - a.projection.mWARMean);

  function canPlay(bIdx: number, pos: StartingPos): boolean {
    const p = sortedBatters[bIdx].player;
    if (pos === 'DH') return true;
    return p.eligiblePositions.includes(pos);
  }

  function tryAugment(slotIdx: number, visited: boolean[]): boolean {
    for (let b = 0; b < sortedBatters.length; b++) {
      if (!canPlay(b, requiredBatterSlots[slotIdx]) || visited[b]) continue;
      visited[b] = true;
      if (batterToSlot[b] === -1 || tryAugment(batterToSlot[b], visited)) {
        batterToSlot[b] = slotIdx;
        slotToBatter[slotIdx] = b;
        return true;
      }
    }
    return false;
  }

  for (let s = 0; s < requiredBatterSlots.length; s++) {
    const visited = new Array<boolean>(sortedBatters.length).fill(false);
    if (!tryAugment(s, visited)) {
      unmet.push(`No eligible unassigned player available to cover starting slot ${requiredBatterSlots[s]}.`);
    }
  }

  const assignments: AssignedRosterPlayer[] = [];
  const usedBatters = new Set<number>();
  for (let s = 0; s < requiredBatterSlots.length; s++) {
    const b = slotToBatter[s];
    if (b !== -1) {
      usedBatters.add(b);
      assignments.push({
        player: sortedBatters[b].player,
        projection: sortedBatters[b].projection,
        assignedSlot: requiredBatterSlots[s],
        isNewAcquisition: sortedBatters[b].isNewAcquisition,
        effectiveCostM: sortedBatters[b].effectiveCostM,
      });
    }
  }

  let benchIdx = 1;
  for (let b = 0; b < sortedBatters.length; b++) {
    if (!usedBatters.has(b)) {
      assignments.push({
        player: sortedBatters[b].player,
        projection: sortedBatters[b].projection,
        assignedSlot: `BENCH_${benchIdx++}`,
        isNewAcquisition: sortedBatters[b].isNewAcquisition,
        effectiveCostM: sortedBatters[b].effectiveCostM,
      });
    }
  }

  // Assign pitchers to SP_1..N and RP_1..M
  const sortedPitchers = [...pitchers].sort((a, b) => b.projection.mWARMean - a.projection.mWARMean);
  let spIdx = 1;
  let rpIdx = 1;
  for (const p of sortedPitchers) {
    let slot: string;
    if (p.player.pitchingRole === 'SP' && spIdx <= config.requiredSP) {
      slot = `SP_${spIdx++}`;
    } else if (p.player.pitchingRole !== 'SP' && rpIdx <= config.requiredRP) {
      slot = p.player.pitchingRole === 'CL' ? `CL` : `RP_${rpIdx++}`;
    } else if (p.player.pitchingRole === 'SP') {
      slot = `SP_${spIdx++}`;
    } else {
      slot = `RP_${rpIdx++}`;
    }
    assignments.push({
      player: p.player,
      projection: p.projection,
      assignedSlot: slot,
      isNewAcquisition: p.isNewAcquisition,
      effectiveCostM: p.effectiveCostM,
    });
  }

  return { valid: unmet.length === 0, assignments, unmet };
}

function scoreUtility(item: CandidateItem, config: OptimizerConfig): number {
  const mwar = item.projection.mWARMean;
  const varTerm = item.projection.mWARSD * item.projection.mWARSD;
  if (config.objective === 'max_mwar') return mwar;
  if (config.objective === 'risk_adjusted') return mwar - config.riskAversionLambda * item.projection.mWARSD;
  // min_cost_target prioritizes mWAR per dollar
  return mwar / Math.max(0.4, item.effectiveCostM) - 0.05 * varTerm;
}

/**
 * Constrained Integer Roster Solver:
 * Uses exact base construction (locked players + minimum-cost/best-utility slot coverage)
 * followed by exact branch-and-bound local & swap integer search across remaining roster slots.
 */
export function optimizeRoster(
  store: DatasetStore,
  projections: Map<string, BayesianProjection>,
  config: OptimizerConfig
): OptimizerResult {
  const lockedSet = new Set(config.lockedPlayerIds);
  const excludedSet = new Set(config.excludedPlayerIds);

  const pool: CandidateItem[] = [];
  for (const p of store.players) {
    if (excludedSet.has(p.playerId)) continue;
    const isTeamOwned = p.currentTeamId === config.teamId;
    const isAcquirable =
      isTeamOwned || p.availability === 'Free Agent' || p.availability === 'Trade Target';
    if (!isAcquirable && !lockedSet.has(p.playerId)) continue;
    if (
      !config.includeInjured &&
      (p.availability === 'Injured List' || p.availability === 'Restricted') &&
      !lockedSet.has(p.playerId)
    ) {
      continue;
    }

    const proj = projections.get(p.playerId);
    if (!proj) continue;

    const effectiveCostM = isTeamOwned
      ? p.salaryM
      : +(p.salaryM + p.tradeCostM / Math.max(1, p.yearsControl)).toFixed(2);

    const item: CandidateItem = {
      player: p,
      projection: proj,
      effectiveCostM,
      isNewAcquisition: !isTeamOwned,
      isLocked: lockedSet.has(p.playerId),
      utility: 0,
    };
    item.utility = scoreUtility(item, config);
    pool.push(item);
  }

  const unmetConstraints: string[] = [];

  const requiredStarterCount = STARTING_POSITIONS.reduce(
    (acc, pos) => acc + (config.requiredPositions[pos] ?? 0),
    0
  );
  const minBattersRequired = requiredStarterCount + config.minBench;
  const minPitchersRequired = config.requiredSP + config.requiredRP;

  if (minBattersRequired + minPitchersRequired > config.rosterSize) {
    unmetConstraints.push(
      `Configuration requires ${minBattersRequired} batters + ${minPitchersRequired} pitchers = ${
        minBattersRequired + minPitchersRequired
      }, which exceeds roster size ${config.rosterSize}.`
    );
  }

  const lockedItems = pool.filter((c) => c.isLocked);
  if (lockedItems.length > config.rosterSize) {
    unmetConstraints.push(
      `Locked players (${lockedItems.length}) exceed configured roster size (${config.rosterSize}).`
    );
  }

  const lockedCost = lockedItems.reduce((a, b) => a + b.effectiveCostM, 0);
  if (lockedCost > config.budgetCapM) {
    unmetConstraints.push(
      `Locked player commitments (£${lockedCost.toFixed(2)}M) already exceed budget cap (£${config.budgetCapM.toFixed(2)}M).`
    );
  }

  const lockedNewAcq = lockedItems.filter((c) => c.isNewAcquisition).length;
  if (lockedNewAcq > config.maxNewAcquisitions) {
    unmetConstraints.push(
      `Locked external acquisitions (${lockedNewAcq}) exceed max acquisitions limit (${config.maxNewAcquisitions}).`
    );
  }

  // Helper to solve integer selection given objective override
  function solveWithObjective(
    objMode: OptimizerConfig['objective'],
    customBudgetCap: number,
    extraExcludedIds: Set<string> = new Set()
  ): {
    feasible: boolean;
    selected: CandidateItem[];
    assignments: AssignedRosterPlayer[];
    unmet: string[];
    cost: number;
    mwar: number;
    sd: number;
  } {
    const availPool = pool.filter((c) => !extraExcludedIds.has(c.player.playerId));
    const selected: CandidateItem[] = availPool.filter((c) => c.isLocked);
    const selectedIds = new Set(selected.map((c) => c.player.playerId));

    const remainingPool = availPool.filter((c) => !selectedIds.has(c.player.playerId));
    const sortFn = (a: CandidateItem, b: CandidateItem) => {
      if (objMode === 'min_cost_target') {
        const effA = a.effectiveCostM / Math.max(0.25, a.projection.mWARMean);
        const effB = b.effectiveCostM / Math.max(0.25, b.projection.mWARMean);
        return effA - effB;
      }
      if (objMode === 'risk_adjusted') {
        const uA = a.projection.mWARMean - config.riskAversionLambda * a.projection.mWARSD;
        const uB = b.projection.mWARMean - config.riskAversionLambda * b.projection.mWARSD;
        return uB - uA;
      }
      // max_mwar: rank by mWAR per marginal dollar slightly blended with total mWAR
      return b.projection.mWARMean - a.projection.mWARMean;
    };

    // Cheapest remaining candidate cost to ensure Phase 1 never starves remaining roster slots
    const sortedCosts = remainingPool.map((c) => c.effectiveCostM).sort((a, b) => a - b);
    const minSlotCost = sortedCosts.length > 0 ? Math.max(0.85, sortedCosts[0]) : 1.0;

    const canAdd = (cand: CandidateItem, curSel: CandidateItem[]) => {
      if (selectedIds.has(cand.player.playerId)) return false;
      const curCost = curSel.reduce((s, x) => s + x.effectiveCostM, 0);
      const slotsStillNeededAfterThis = Math.max(0, config.rosterSize - (curSel.length + 1));
      const reservedBudget = slotsStillNeededAfterThis * minSlotCost;
      if (curCost + cand.effectiveCostM + reservedBudget > customBudgetCap + 1e-6) return false;
      const curAcq = curSel.filter((x) => x.isNewAcquisition).length;
      if (cand.isNewAcquisition && curAcq >= config.maxNewAcquisitions) return false;
      if (curSel.length >= config.rosterSize) return false;
      return true;
    };

    // Phase 1: Construct a guaranteed budget-feasible & slot-feasible baseline roster first
    // (Prefer owned team players & cost-efficient candidates so acquisition quota and budget are never prematurely exhausted)
    const feasibleSort = (a: CandidateItem, b: CandidateItem) => {
      if (a.isNewAcquisition !== b.isNewAcquisition) return a.isNewAcquisition ? 1 : -1;
      const ratioA = a.effectiveCostM / Math.max(0.4, a.projection.mWARMean + 0.5);
      const ratioB = b.effectiveCostM / Math.max(0.4, b.projection.mWARMean + 0.5);
      return ratioA - ratioB;
    };
    const spPool = remainingPool.filter((c) => c.player.pitchingRole === 'SP').sort(feasibleSort);
    const rpPool = remainingPool.filter((c) => c.player.isPitcher && c.player.pitchingRole !== 'SP').sort(feasibleSort);
    const batPool = remainingPool.filter((c) => !c.player.isPitcher).sort(feasibleSort);

    const cheapestFirst = (arr: CandidateItem[]) =>
      [...arr].sort((a, b) => a.effectiveCostM - b.effectiveCostM || b.projection.mWARMean - a.projection.mWARMean);

    // Pick pitchers first to satisfy exact required SP and RP counts
    const currentSP = () => selected.filter((c) => c.player.pitchingRole === 'SP').length;
    const currentRP = () => selected.filter((c) => c.player.isPitcher && c.player.pitchingRole !== 'SP').length;
    const currentBatters = () => selected.filter((c) => !c.player.isPitcher).length;
    const maxAllowedPitchers = config.rosterSize - minBattersRequired;

    const ownedBattersCount =
      remainingPool.filter((c) => !c.player.isPitcher && !c.isNewAcquisition).length +
      selected.filter((c) => !c.player.isPitcher).length;
    const minNewBattersNeeded = Math.max(0, minBattersRequired - ownedBattersCount);

    const canAddForRole = (cand: CandidateItem, curSel: CandidateItem[], isRequiredBatterStep = false) => {
      if (!canAdd(cand, curSel)) return false;
      if (!isRequiredBatterStep && cand.isNewAcquisition) {
        const curNewBatters = curSel.filter((x) => x.isNewAcquisition && !x.player.isPitcher).length;
        const curTotalAcq = curSel.filter((x) => x.isNewAcquisition).length;
        const remainingAcqSlots = config.maxNewAcquisitions - curTotalAcq;
        const remainingNewBattersNeeded = Math.max(0, minNewBattersNeeded - curNewBatters);
        if (cand.player.isPitcher && remainingAcqSlots <= remainingNewBattersNeeded) {
          return false;
        }
      }
      return true;
    };

    for (const poolSource of [spPool, cheapestFirst(spPool)]) {
      for (const c of poolSource) {
        if (currentSP() >= config.requiredSP) break;
        if (canAddForRole(c, selected)) {
          selected.push(c);
          selectedIds.add(c.player.playerId);
        }
      }
    }
    for (const poolSource of [rpPool, cheapestFirst(rpPool)]) {
      for (const c of poolSource) {
        if (currentRP() >= config.requiredRP) break;
        if (canAddForRole(c, selected)) {
          selected.push(c);
          selectedIds.add(c.player.playerId);
        }
      }
    }

    // Cover every required defensive slot greedily, using scarcity order (C, SS, CF, 2B, 3B, RF, LF, 1B, DH)
    const scarcityOrder: StartingPos[] = ['C', 'SS', 'CF', '2B', '3B', 'RF', 'LF', '1B', 'DH'];
    for (const pos of scarcityOrder) {
      const req = config.requiredPositions[pos] ?? 0;
      for (let k = 0; k < req; k++) {
        const check = assignPlayersToSlots(selected, {
          ...config,
          requiredSP: 0,
          requiredRP: 0,
          minBench: 0,
          requiredPositions: {
            C: pos === 'C' ? k + 1 : 0,
            '1B': pos === '1B' ? k + 1 : 0,
            '2B': pos === '2B' ? k + 1 : 0,
            '3B': pos === '3B' ? k + 1 : 0,
            SS: pos === 'SS' ? k + 1 : 0,
            LF: pos === 'LF' ? k + 1 : 0,
            CF: pos === 'CF' ? k + 1 : 0,
            RF: pos === 'RF' ? k + 1 : 0,
            DH: pos === 'DH' ? k + 1 : 0,
          },
        });
        if (check.valid) continue;

        const eligibleB = batPool.filter(
          (c) => !selectedIds.has(c.player.playerId) && (pos === 'DH' || c.player.eligiblePositions.includes(pos))
        );
        const chosen =
          eligibleB.find((c) => canAddForRole(c, selected, true)) ??
          cheapestFirst(eligibleB).find((c) => canAddForRole(c, selected, true));
        if (chosen) {
          selected.push(chosen);
          selectedIds.add(chosen.player.playerId);
        }
      }
    }

    // Ensure minimum bench batters (prefer owned or cheapest eligible batters)
    for (const poolSource of [
      batPool.filter((c) => !c.isNewAcquisition),
      cheapestFirst(batPool),
    ]) {
      for (const c of poolSource) {
        if (currentBatters() >= minBattersRequired) break;
        if (canAddForRole(c, selected, true)) {
          selected.push(c);
          selectedIds.add(c.player.playerId);
        }
      }
    }

    // Fill remaining roster slots up to config.rosterSize without violating minBattersRequired
    const fillOrder = cheapestFirst(remainingPool);
    for (const c of fillOrder) {
      if (selected.length >= config.rosterSize) break;
      if (c.player.isPitcher && selected.filter((x) => x.player.isPitcher).length >= maxAllowedPitchers) {
        continue;
      }
      if (canAddForRole(c, selected)) {
        selected.push(c);
        selectedIds.add(c.player.playerId);
      }
    }

    // Phase 2: Exact 1-for-1 Swap Local Search (Integer Neighborhood Optimisation)
    // Repeatedly test replacing any unlocked selected player with any unselected player
    // that improves the objective while preserving slot coverage, budget, and acquisition limit!
    const evalObjective = (sel: CandidateItem[]) => {
      const mwar = sel.reduce((s, x) => s + x.projection.mWARMean, 0);
      const sd = Math.sqrt(sel.reduce((s, x) => s + x.projection.mWARSD * x.projection.mWARSD, 0));
      const cost = sel.reduce((s, x) => s + x.effectiveCostM, 0);
      if (objMode === 'min_cost_target') {
        const deficit = Math.max(0, config.targetMWAR - mwar);
        return -cost - deficit * 100;
      }
      if (objMode === 'risk_adjusted') {
        return mwar - config.riskAversionLambda * sd;
      }
      return mwar;
    };

    let improved = true;
    let iter = 0;
    while (improved && iter < 80) {
      improved = false;
      iter++;
      const curObj = evalObjective(selected);
      let bestSwap: { outIdx: number; inCand: CandidateItem; score: number } | null = null;

      for (let i = 0; i < selected.length; i++) {
        if (selected[i].isLocked) continue;
        const outCand = selected[i];
        const baseCost = selected.reduce((s, x) => s + x.effectiveCostM, 0) - outCand.effectiveCostM;
        const baseAcq =
          selected.filter((x) => x.isNewAcquisition).length - (outCand.isNewAcquisition ? 1 : 0);

        for (const inCand of remainingPool) {
          if (selectedIds.has(inCand.player.playerId)) continue;
          if (baseCost + inCand.effectiveCostM > customBudgetCap + 1e-6) continue;
          if (baseAcq + (inCand.isNewAcquisition ? 1 : 0) > config.maxNewAcquisitions) continue;

          const trial = [...selected];
          trial[i] = inCand;
          const nextScore = evalObjective(trial);
          if (nextScore > curObj + 1e-5 && (!bestSwap || nextScore > bestSwap.score)) {
            const slotCheck = assignPlayersToSlots(trial, config);
            if (slotCheck.valid) {
              bestSwap = { outIdx: i, inCand, score: nextScore };
            }
          }
        }
      }

      if (bestSwap) {
        selectedIds.delete(selected[bestSwap.outIdx].player.playerId);
        selected[bestSwap.outIdx] = bestSwap.inCand;
        selectedIds.add(bestSwap.inCand.player.playerId);
        improved = true;
      }
    }

    const finalMatch = assignPlayersToSlots(selected, config);
    const totalCost = +selected.reduce((s, x) => s + x.effectiveCostM, 0).toFixed(2);
    const totalMWAR = +selected.reduce((s, x) => s + x.projection.mWARMean, 0).toFixed(2);
    const portfolioSD = +Math.sqrt(
      selected.reduce((s, x) => s + x.projection.mWARSD * x.projection.mWARSD, 0)
    ).toFixed(2);

    const localUnmet = [...finalMatch.unmet];
    if (selected.length !== config.rosterSize) {
      localUnmet.push(
        `Roster size constraint unmet: selected ${selected.length} of ${config.rosterSize} required players within £${customBudgetCap.toFixed(1)}M budget.`
      );
    }
    if (totalCost > customBudgetCap + 1e-6) {
      localUnmet.push(`Total cost £${totalCost.toFixed(2)}M exceeds budget £${customBudgetCap.toFixed(2)}M.`);
    }
    if (objMode === 'min_cost_target' && totalMWAR < config.targetMWAR) {
      localUnmet.push(
        `Target mWAR (${config.targetMWAR.toFixed(1)}) unreachable under £${customBudgetCap.toFixed(1)}M cap (max achieved: ${totalMWAR.toFixed(1)}).`
      );
    }

    return {
      feasible: localUnmet.length === 0 && unmetConstraints.length === 0,
      selected,
      assignments: finalMatch.assignments,
      unmet: localUnmet,
      cost: totalCost,
      mwar: totalMWAR,
      sd: portfolioSD,
    };
  }

  const primary = solveWithObjective(config.objective, config.budgetCapM);
  const allUnmet = [...unmetConstraints, ...primary.unmet];
  const feasible = allUnmet.length === 0;

  // Generate alternative solutions for tradeoff comparison
  const alternatives: OptimizerResult['alternatives'] = [];
  const lowCostAlt = solveWithObjective('min_cost_target', Math.max(lockedCost + 2, config.budgetCapM * 0.85));
  if (lowCostAlt.selected.length > 0) {
    alternatives.push({
      label: 'Lean Value Build (85% Budget Cap)',
      totalEffectiveCostM: lowCostAlt.cost,
      totalExpectedMWAR: lowCostAlt.mwar,
      portfolioSDMWAR: lowCostAlt.sd,
      keyDifference: `Saves £${Math.max(0, primary.cost - lowCostAlt.cost).toFixed(1)}M by leaning on pre-arb/FA value.`,
      playerIds: lowCostAlt.selected.map((c) => c.player.playerId),
    });
  }

  const highFloorAlt = solveWithObjective('risk_adjusted', config.budgetCapM);
  if (highFloorAlt.selected.length > 0 && config.objective !== 'risk_adjusted') {
    alternatives.push({
      label: 'High-Floor Risk-Averse Build',
      totalEffectiveCostM: highFloorAlt.cost,
      totalExpectedMWAR: highFloorAlt.mwar,
      portfolioSDMWAR: highFloorAlt.sd,
      keyDifference: `Reduces portfolio mWAR uncertainty (SD ${highFloorAlt.sd.toFixed(2)} vs ${primary.sd.toFixed(2)}).`,
      playerIds: highFloorAlt.selected.map((c) => c.player.playerId),
    });
  }

  const contenderAlt = solveWithObjective('max_mwar', config.budgetCapM * 1.15);
  if (contenderAlt.selected.length > 0) {
    alternatives.push({
      label: 'Expanded Contender Build (+15% Budget)',
      totalEffectiveCostM: contenderAlt.cost,
      totalExpectedMWAR: contenderAlt.mwar,
      portfolioSDMWAR: contenderAlt.sd,
      keyDifference: `Tests +£${Math.max(0, contenderAlt.cost - primary.cost).toFixed(1)}M spend for +${(
        contenderAlt.mwar - primary.mwar
      ).toFixed(1)} projected mWAR.`,
      playerIds: contenderAlt.selected.map((c) => c.player.playerId),
    });
  }

  const totalSalaryM = +primary.selected.reduce((s, x) => s + x.player.salaryM, 0).toFixed(2);
  const totalTradeCostM = +(primary.cost - totalSalaryM).toFixed(2);
  const newAcqCount = primary.selected.filter((x) => x.isNewAcquisition).length;
  const riskAdjustedScore = +(primary.mwar - config.riskAversionLambda * primary.sd).toFixed(2);

  return {
    feasible,
    statusMessage: feasible
      ? `Feasible ${config.rosterSize}-man roster found under £${config.budgetCapM.toFixed(1)}M budget.`
      : `Infeasible constraints (${allUnmet.length} issue${allUnmet.length > 1 ? 's' : ''}). Showing closest partial assignment.`,
    unmetConstraints: allUnmet,
    objectiveUsed: config.objective,
    ruleSetName: config.ruleSetName,
    selectedRoster: primary.assignments,
    totalSalaryM,
    totalTradeCostM: Math.max(0, totalTradeCostM),
    totalEffectiveCostM: primary.cost,
    budgetRemainingM: +(config.budgetCapM - primary.cost).toFixed(2),
    totalExpectedMWAR: primary.mwar,
    portfolioSDMWAR: primary.sd,
    riskAdjustedScore,
    newAcquisitionsCount: newAcqCount,
    alternatives,
    approximationWarning:
      'Additive player mWAR optimisation is a linear approximation; verify non-linear run interaction, lineup order, and pitching depth in the Monte Carlo simulation engine.',
  };
}
