import React, { useState } from 'react';
import type { AssignedRosterPlayer, BayesianProjection } from '../engine/types';

export function DiamondScorecardSVG({
  starters,
}: {
  starters: { slot: string; name: string; mwar: number }[];
}) {
  const getSlot = (pos: string) => starters.find((s) => s.slot === pos);
  const coords: Record<string, { x: number; y: number }> = {
    CF: { x: 180, y: 36 },
    LF: { x: 72, y: 78 },
    RF: { x: 288, y: 78 },
    SS: { x: 132, y: 126 },
    '2B': { x: 228, y: 126 },
    '3B': { x: 88, y: 186 },
    '1B': { x: 272, y: 186 },
    SP_1: { x: 180, y: 186 },
    C: { x: 180, y: 266 },
    DH: { x: 306, y: 256 },
  };

  return (
    <svg
      viewBox="0 0 360 300"
      className="w-full h-auto max-h-[290px] select-none"
      role="img"
      aria-label="Sheffield Steelheads defensive alignment diamond diagram"
    >
      {/* Outfield arc */}
      <path
        d="M 32 155 Q 180 4 328 155 L 180 264 Z"
        className="fill-[#EDEAE2] dark:fill-[#152238] stroke-[#CBD5E1] dark:stroke-[#2A3A55]"
        strokeWidth="1.2"
      />
      {/* Infield dirt diamond */}
      <polygon
        points="180,104 258,182 180,260 102,182"
        className="fill-[#F8F6F1] dark:fill-[#0F192B] stroke-[#94A3B8] dark:stroke-[#3B4F70]"
        strokeWidth="1.2"
      />
      {/* Basepaths */}
      <line x1="180" y1="260" x2="258" y2="182" className="stroke-[#B91C1C]/40" strokeWidth="1.2" />
      <line x1="258" y1="182" x2="180" y2="104" className="stroke-[#B91C1C]/40" strokeWidth="1.2" />
      <line x1="180" y1="104" x2="102" y2="182" className="stroke-[#B91C1C]/40" strokeWidth="1.2" />
      <line x1="102" y1="182" x2="180" y2="260" className="stroke-[#B91C1C]/40" strokeWidth="1.2" />

      {/* Bases */}
      <rect x="176" y="100" width="8" height="8" transform="rotate(45 180 104)" className="fill-white stroke-[#475569]" strokeWidth="1" />
      <rect x="254" y="178" width="8" height="8" transform="rotate(45 258 182)" className="fill-white stroke-[#475569]" strokeWidth="1" />
      <rect x="98" y="178" width="8" height="8" transform="rotate(45 102 182)" className="fill-white stroke-[#475569]" strokeWidth="1" />
      <polygon points="180,264 175,259 175,255 185,255 185,259" className="fill-white stroke-[#475569]" strokeWidth="1" />

      {Object.entries(coords).map(([pos, pt]) => {
        const entry = getSlot(pos);
        const labelPos = pos === 'SP_1' ? 'SP' : pos;
        const shortName = entry ? entry.name.split(' ').slice(-1)[0] : 'Open';
        return (
          <g key={pos} transform={`translate(${pt.x}, ${pt.y})`}>
            <rect
              x="-38"
              y="-15"
              width="76"
              height="30"
              rx="4"
              className={
                entry
                  ? 'fill-white dark:fill-[#0B1320] stroke-[#CBD5E1] dark:stroke-[#334155]'
                  : 'fill-[#FEE2E2] dark:fill-[#450A0A] stroke-[#DC2626]'
              }
              strokeWidth="1"
            />
            <text
              x="-32"
              y="-2"
              className="fill-[#B91C1C] dark:fill-[#F87171] font-mono text-[9px] font-semibold"
            >
              {labelPos}
            </text>
            <text
              x="32"
              y="-2"
              textAnchor="end"
              className="fill-[#64748B] dark:fill-[#94A3B8] font-mono text-[9px]"
            >
              {entry ? `${entry.mwar.toFixed(1)}` : '—'}
            </text>
            <text
              x="0"
              y="10"
              textAnchor="middle"
              className="fill-[#0F172A] dark:fill-[#F1F5F9] text-[10px] font-medium"
            >
              {shortName}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function WinHistogramChart({
  bins,
  expectedWins,
  p10,
  p90,
  winTarget,
  compareBins,
}: {
  bins: { wins: number; count: number; pct: number }[];
  expectedWins: number;
  p10: number;
  p90: number;
  winTarget: number;
  compareBins?: { wins: number; count: number; pct: number }[];
}) {
  const [hoverBin, setHoverBin] = useState<{ wins: number; pct: number; comparePct?: number } | null>(null);
  if (bins.length === 0) return null;

  const minW = Math.min(...bins.map((b) => b.wins), ...(compareBins?.map((b) => b.wins) ?? [999]));
  const maxW = Math.max(...bins.map((b) => b.wins), ...(compareBins?.map((b) => b.wins) ?? [0]));
  const span = Math.max(1, maxW - minW + 1);
  const maxPct = Math.max(
    ...bins.map((b) => b.pct),
    ...(compareBins?.map((b) => b.pct) ?? [0]),
    0.05
  );

  const w = 640;
  const h = 230;
  const padL = 38;
  const padR = 16;
  const padT = 18;
  const padB = 34;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;
  const barW = Math.max(3, plotW / span - 1.5);

  const xForWin = (win: number) => padL + ((win - minW) / span) * plotW;
  const compareMap = new Map(compareBins?.map((b) => [b.wins, b.pct]) ?? []);
  const primaryMap = new Map(bins.map((b) => [b.wins, b.pct]));

  const allWins: number[] = [];
  for (let x = minW; x <= maxW; x++) allWins.push(x);

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto overflow-visible">
        {/* Horizontal gridlines */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const y = padT + plotH * (1 - t);
          return (
            <g key={t}>
              <line
                x1={padL}
                y1={y}
                x2={w - padR}
                y2={y}
                className="stroke-[#E2DFD7] dark:stroke-[#1E293B]"
                strokeWidth="1"
              />
              <text
                x={padL - 6}
                y={y + 3}
                textAnchor="end"
                className="fill-[#64748B] dark:fill-[#94A3B8] font-mono text-[9px]"
              >
                {(maxPct * t * 100).toFixed(0)}%
              </text>
            </g>
          );
        })}

        {/* P10–P90 shaded band */}
        <rect
          x={xForWin(p10)}
          y={padT}
          width={Math.max(4, xForWin(p90) - xForWin(p10))}
          height={plotH}
          className="fill-[#0B1320]/[0.05] dark:fill-white/[0.04]"
        />

        {/* Bars */}
        {allWins.map((win) => {
          const pct = primaryMap.get(win) ?? 0;
          const cPct = compareMap.get(win);
          const x = xForWin(win);
          const barH = (pct / maxPct) * plotH;
          const isAboveTarget = win >= winTarget;
          return (
            <g
              key={win}
              onMouseEnter={() => setHoverBin({ wins: win, pct, comparePct: cPct })}
              onMouseLeave={() => setHoverBin(null)}
              className="cursor-pointer"
            >
              <rect
                x={x}
                y={padT + plotH - barH}
                width={barW}
                height={Math.max(0, barH)}
                className={
                  isAboveTarget
                    ? 'fill-[#0B1320] dark:fill-[#E2E8F0] hover:fill-[#B91C1C]'
                    : 'fill-[#94A3B8] dark:fill-[#475569] hover:fill-[#B91C1C]'
                }
                opacity={0.88}
              />
              {cPct !== undefined && cPct > 0 && (
                <rect
                  x={x + barW * 0.2}
                  y={padT + plotH - (cPct / maxPct) * plotH}
                  width={Math.max(2, barW * 0.6)}
                  height={(cPct / maxPct) * plotH}
                  className="fill-[#B91C1C]"
                  opacity={0.55}
                />
              )}
            </g>
          );
        })}

        {/* Expected Wins & Target Vertical Lines */}
        <line
          x1={xForWin(expectedWins)}
          y1={padT}
          x2={xForWin(expectedWins)}
          y2={padT + plotH}
          className="stroke-[#B91C1C]"
          strokeWidth="1.8"
          strokeDasharray="4 3"
        />
        <text
          x={xForWin(expectedWins) + 4}
          y={padT + 10}
          className="fill-[#B91C1C] dark:fill-[#F87171] font-mono text-[10px] font-semibold"
        >
          E[W]={expectedWins.toFixed(1)}
        </text>

        <line
          x1={xForWin(winTarget)}
          y1={padT}
          x2={xForWin(winTarget)}
          y2={padT + plotH}
          className="stroke-[#0F766E] dark:stroke-[#2DD4BF]"
          strokeWidth="1.4"
          strokeDasharray="2 2"
        />
        <text
          x={xForWin(winTarget) - 4}
          y={padT + 22}
          textAnchor="end"
          className="fill-[#0F766E] dark:fill-[#2DD4BF] font-mono text-[9px]"
        >
          Target {winTarget}W
        </text>

        {/* X Axis labels */}
        {allWins
          .filter((win) => win % Math.max(2, Math.ceil(span / 10)) === 0)
          .map((win) => (
            <text
              key={win}
              x={xForWin(win) + barW / 2}
              y={h - 10}
              textAnchor="middle"
              className="fill-[#64748B] dark:fill-[#94A3B8] font-mono text-[10px]"
            >
              {win}
            </text>
          ))}
      </svg>

      {hoverBin && (
        <div className="absolute top-2 right-2 px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#334155] bg-white dark:bg-[#0B1320] text-xs font-mono shadow-sm pointer-events-none">
          <div>
            {hoverBin.wins} Wins · {(hoverBin.pct * 100).toFixed(1)}% of seasons
          </div>
          {hoverBin.comparePct !== undefined && (
            <div className="text-[#B91C1C] dark:text-[#F87171]">
              Comparison: {(hoverBin.comparePct * 100).toFixed(1)}%
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export interface ScatterPoint {
  id: string;
  label: string;
  sublabel: string;
  x: number;
  y: number;
  highlight?: boolean;
}

export function ScatterAnalyticsChart({
  points,
  xLabel,
  yLabel,
  xFormat = (v) => v.toFixed(2),
  yFormat = (v) => v.toFixed(2),
  diagonalReference = false,
  onSelect,
}: {
  points: ScatterPoint[];
  xLabel: string;
  yLabel: string;
  xFormat?: (v: number) => string;
  yFormat?: (v: number) => string;
  diagonalReference?: boolean;
  onSelect?: (id: string) => void;
}) {
  const [hovered, setHovered] = useState<ScatterPoint | null>(null);
  if (points.length === 0) return null;

  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);
  const padX = Math.max(0.01, (maxX - minX) * 0.12);
  const padY = Math.max(0.01, (maxY - minY) * 0.12);

  const loX = minX - padX;
  const hiX = maxX + padX;
  const loY = minY - padY;
  const hiY = maxY + padY;

  const w = 580;
  const h = 250;
  const pL = 48;
  const pR = 20;
  const pT = 16;
  const pB = 36;
  const plotW = w - pL - pR;
  const plotH = h - pT - pB;

  const mapX = (x: number) => pL + ((x - loX) / Math.max(1e-6, hiX - loX)) * plotW;
  const mapY = (y: number) => pT + plotH - ((y - loY) / Math.max(1e-6, hiY - loY)) * plotH;

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto">
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const yVal = loY + t * (hiY - loY);
          const y = mapY(yVal);
          const xVal = loX + t * (hiX - loX);
          const x = mapX(xVal);
          return (
            <g key={t}>
              <line x1={pL} y1={y} x2={w - pR} y2={y} className="stroke-[#E2DFD7] dark:stroke-[#1E293B]" strokeWidth="1" />
              <text x={pL - 6} y={y + 3} textAnchor="end" className="fill-[#64748B] dark:fill-[#94A3B8] font-mono text-[9px]">
                {yFormat(yVal)}
              </text>
              <text x={x} y={h - 18} textAnchor="middle" className="fill-[#64748B] dark:fill-[#94A3B8] font-mono text-[9px]">
                {xFormat(xVal)}
              </text>
            </g>
          );
        })}

        {diagonalReference && (
          <line
            x1={mapX(Math.max(loX, loY))}
            y1={mapY(Math.max(loX, loY))}
            x2={mapX(Math.min(hiX, hiY))}
            y2={mapY(Math.min(hiX, hiY))}
            className="stroke-[#94A3B8] dark:stroke-[#475569]"
            strokeDasharray="4 4"
            strokeWidth="1.2"
          />
        )}

        <text x={pL + plotW / 2} y={h - 3} textAnchor="middle" className="fill-[#475569] dark:fill-[#94A3B8] text-[10px] font-medium">
          {xLabel}
        </text>
        <text
          x={12}
          y={pT + plotH / 2}
          textAnchor="middle"
          transform={`rotate(-90 12 ${pT + plotH / 2})`}
          className="fill-[#475569] dark:fill-[#94A3B8] text-[10px] font-medium"
        >
          {yLabel}
        </text>

        {points.map((pt) => {
          const cx = mapX(pt.x);
          const cy = mapY(pt.y);
          return (
            <circle
              key={pt.id}
              cx={cx}
              cy={cy}
              r={pt.highlight ? 5.5 : 4}
              className={
                pt.highlight
                  ? 'fill-[#B91C1C] dark:fill-[#EF4444] stroke-white dark:stroke-[#0B1320] cursor-pointer'
                  : 'fill-[#0B1320]/70 dark:fill-[#94A3B8]/80 hover:fill-[#B91C1C] cursor-pointer'
              }
              strokeWidth="1.2"
              onMouseEnter={() => setHovered(pt)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onSelect?.(pt.id)}
            />
          );
        })}
      </svg>

      {hovered && (
        <div className="absolute top-2 right-2 px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#334155] bg-white dark:bg-[#0B1320] text-xs shadow-sm pointer-events-none">
          <div className="font-semibold text-[#0F172A] dark:text-[#F1F5F9]">{hovered.label}</div>
          <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">{hovered.sublabel}</div>
          <div className="font-mono text-[11px] mt-0.5">
            {xLabel}: {xFormat(hovered.x)} · {yLabel}: {yFormat(hovered.y)}
          </div>
        </div>
      )}
    </div>
  );
}

export function BaseOutMatrixGrid({ matrix }: { matrix: number[][] }) {
  const baseLabels = ['Empty', '1B', '2B', '1B-2B', '3B', '1B-3B', '2B-3B', 'Loaded'];
  if (!matrix || matrix.length !== 8) return null;
  const maxVal = Math.max(...matrix.flat(), 2.2);

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs border-collapse font-mono tabular-nums">
        <thead>
          <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
            <th className="py-1.5 px-2 text-left font-sans font-medium">Base State</th>
            <th className="py-1.5 px-2 text-right">0 Outs</th>
            <th className="py-1.5 px-2 text-right">1 Out</th>
            <th className="py-1.5 px-2 text-right">2 Outs</th>
          </tr>
        </thead>
        <tbody>
          {matrix.map((row, idx) => (
            <tr key={idx} className="border-b border-[#E2DFD7]/60 dark:border-[#1E293B]/60">
              <td className="py-1.5 px-2 font-sans text-[#0F172A] dark:text-[#E2E8F0]">{baseLabels[idx]}</td>
              {row.map((val, o) => {
                const alpha = Math.min(0.38, (val / maxVal) * 0.38);
                return (
                  <td
                    key={o}
                    className="py-1.5 px-2 text-right"
                    style={{ backgroundColor: `rgba(185, 28, 28, ${alpha.toFixed(2)})` }}
                  >
                    {val.toFixed(3)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function PosteriorIntervalBar({
  projection,
}: {
  projection: BayesianProjection;
}) {
  const lo = Math.min(-0.5, projection.mWARLow95 - 0.5);
  const hi = Math.max(5.5, projection.mWARHigh95 + 0.5);
  const pct = (v: number) => `${Math.max(0, Math.min(100, ((v - lo) / (hi - lo)) * 100))}%`;

  return (
    <div className="space-y-1.5">
      <div className="relative h-5 rounded bg-[#EDEAE2] dark:bg-[#1E293B]">
        {/* 95% CI whisker */}
        <div
          className="absolute top-1/2 -translate-y-1/2 h-0.5 bg-[#64748B] dark:bg-[#94A3B8]"
          style={{
            left: pct(projection.mWARLow95),
            width: `calc(${pct(projection.mWARHigh95)} - ${pct(projection.mWARLow95)})`,
          }}
        />
        {/* 80% CI interval bar */}
        <div
          className="absolute top-1/2 -translate-y-1/2 h-2.5 rounded-sm bg-[#0B1320]/70 dark:bg-[#E2E8F0]/70"
          style={{
            left: pct(projection.mWARLow80),
            width: `calc(${pct(projection.mWARHigh80)} - ${pct(projection.mWARLow80)})`,
          }}
        />
        {/* Posterior Mean */}
        <div
          className="absolute top-0.5 bottom-0.5 w-1 bg-[#B91C1C] dark:bg-[#EF4444]"
          style={{ left: pct(projection.mWARMean) }}
        />
      </div>
      <div className="flex justify-between text-[11px] font-mono text-[#64748B] dark:text-[#94A3B8]">
        <span>95% Lo: {projection.mWARLow95.toFixed(2)}</span>
        <span>80% CI: [{projection.mWARLow80.toFixed(2)}, {projection.mWARHigh80.toFixed(2)}]</span>
        <span>95% Hi: {projection.mWARHigh95.toFixed(2)}</span>
      </div>
    </div>
  );
}

export function extractStartersForDiamond(roster: AssignedRosterPlayer[]) {
  return roster.map((r) => ({
    slot: r.assignedSlot,
    name: r.player.fullName,
    mwar: r.projection.mWARMean,
  }));
}
