import React, { useState } from 'react';
import { X } from 'lucide-react';
import type {
  BayesianProjection,
  DatasetStore,
  PlayerMaster,
  SabermetricBatting,
  SabermetricPitching,
} from '../engine/types';
import { formatIP } from '../engine/sabermetrics';
import { PosteriorIntervalBar } from './Charts';

export function PlayerDossierDrawer({
  player,
  projection,
  battingHist,
  pitchingHist,
  store,
  onClose,
  onUpdateAvailability,
}: {
  player: PlayerMaster;
  projection: BayesianProjection | undefined;
  battingHist: SabermetricBatting | undefined;
  pitchingHist: SabermetricPitching | undefined;
  store: DatasetStore;
  onClose: () => void;
  onUpdateAvailability: (playerId: string, pct: number) => Promise<void>;
}) {
  const [availPct, setAvailPct] = useState(Math.round(player.expectedAvailabilityPct * 100));
  const [saving, setSaving] = useState(false);

  const playerReports = store.scoutingReports.filter((r) => r.playerId === player.playerId);
  const playerTx = store.transactions.filter((t) => t.playerId === player.playerId);
  const stints2025 = store.battingStints.filter(
    (s) => s.playerId === player.playerId && s.season === 2025 && s.splitVsHand === 'ALL'
  );
  const pitchStints2025 = store.pitchingStints.filter(
    (s) => s.playerId === player.playerId && s.season === 2025
  );

  const handleSaveAvailability = async () => {
    setSaving(true);
    try {
      await onUpdateAvailability(player.playerId, availPct / 100);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40">
      <div className="w-full max-w-2xl bg-white dark:bg-[#0B1320] text-[#0F172A] dark:text-[#F1F5F9] h-full overflow-y-auto border-l border-[#E2DFD7] dark:border-[#1E293B] p-6 space-y-6">
        <div className="flex items-start justify-between gap-4 border-b border-[#E2DFD7] dark:border-[#1E293B] pb-4">
          <div>
            <div className="text-xs text-[#64748B] dark:text-[#94A3B8] font-mono">
              {player.playerId} · {player.currentTeamId ?? 'Free Agent'} · {player.availability}
            </div>
            <h2 className="text-3xl font-bold tracking-tight mt-0.5">{player.fullName}</h2>
            <div className="text-xs text-[#475569] dark:text-[#94A3B8] mt-1">
              Pos: {player.eligiblePositions.join('/')} · Bats/Throws: {player.bats}/{player.throws} · Born {player.birthYear}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded border border-[#E2DFD7] dark:border-[#1E293B] hover:bg-[#F8F6F1] dark:hover:bg-[#111B2E]"
            aria-label="Close dossier"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Contract & Cost Separation */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B]">
            <div className="text-[#64748B] dark:text-[#94A3B8]">Annual Salary</div>
            <div className="font-mono text-base font-semibold mt-0.5">£{player.salaryM.toFixed(2)}M</div>
          </div>
          <div className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B]">
            <div className="text-[#64748B] dark:text-[#94A3B8]">Trade Acq. Cost</div>
            <div className="font-mono text-base font-semibold mt-0.5">£{player.tradeCostM.toFixed(2)}M</div>
          </div>
          <div className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B]">
            <div className="text-[#64748B] dark:text-[#94A3B8]">Control / Type</div>
            <div className="font-mono text-base font-semibold mt-0.5">{player.yearsControl} yr · {player.contractType}</div>
          </div>
          <div className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B]">
            <div className="text-[#64748B] dark:text-[#94A3B8]">Assumed Availability</div>
            <div className="font-mono text-base font-semibold mt-0.5">{Math.round(player.expectedAvailabilityPct * 100)}%</div>
          </div>
        </section>

        {/* Historical vs Projection Explicit Separation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] space-y-2">
            <div className="text-xs font-semibold text-[#64748B] dark:text-[#94A3B8]">
              Historical Record (2025 Observed Counts)
            </div>
            {!player.isPitcher && battingHist ? (
              <div className="grid grid-cols-3 gap-2 font-mono text-xs pt-1">
                <div><span className="text-[#64748B] block font-sans">PA</span>{battingHist.pa}</div>
                <div><span className="text-[#64748B] block font-sans">BA / OBP</span>{battingHist.ba?.toFixed(3)} / {battingHist.obp?.toFixed(3)}</div>
                <div><span className="text-[#64748B] block font-sans">SLG / wRC+</span>{battingHist.slg?.toFixed(3)} / {battingHist.wRCPlus?.toFixed(0)}</div>
                <div><span className="text-[#64748B] block font-sans">BB% / K%</span>{((battingHist.bbPct ?? 0) * 100).toFixed(1)}% / {((battingHist.kPct ?? 0) * 100).toFixed(1)}%</div>
                <div><span className="text-[#64748B] block font-sans">BABIP</span>{battingHist.babip?.toFixed(3)}</div>
                <div><span className="text-[#64748B] block font-sans">Hist mWAR</span>{battingHist.modelledWAR.toFixed(2)}</div>
              </div>
            ) : player.isPitcher && pitchingHist ? (
              <div className="grid grid-cols-3 gap-2 font-mono text-xs pt-1">
                <div><span className="text-[#64748B] block font-sans">IP / BF</span>{formatIP(pitchingHist.outsRecorded)} / {pitchingHist.bf}</div>
                <div><span className="text-[#64748B] block font-sans">ERA / FIP</span>{pitchingHist.era?.toFixed(2)} / {pitchingHist.fip?.toFixed(2)}</div>
                <div><span className="text-[#64748B] block font-sans">WHIP</span>{pitchingHist.whip?.toFixed(2)}</div>
                <div><span className="text-[#64748B] block font-sans">K% / BB%</span>{((pitchingHist.kPct ?? 0) * 100).toFixed(1)}% / {((pitchingHist.bbPct ?? 0) * 100).toFixed(1)}%</div>
                <div><span className="text-[#64748B] block font-sans">HR/9</span>{pitchingHist.hrPer9?.toFixed(2)}</div>
                <div><span className="text-[#64748B] block font-sans">Hist mWAR</span>{pitchingHist.modelledWAR.toFixed(2)}</div>
              </div>
            ) : (
              <p className="text-xs text-[#64748B]">No 2025 historical stints recorded.</p>
            )}
            {(stints2025.length > 1 || pitchStints2025.length > 1) && (
              <div className="pt-2 border-t border-[#E2DFD7] dark:border-[#1E293B] text-[11px] text-[#475569] dark:text-[#94A3B8]">
                Traded mid-2025: aggregated from {(stints2025.length || pitchStints2025.length)} distinct team stints without double-counting.
              </div>
            )}
          </div>

          <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] space-y-2">
            <div className="text-xs font-semibold text-[#B91C1C] dark:text-[#F87171]">
              2026 Bayesian Projection ({projection?.modelVersion})
            </div>
            {projection ? (
              <>
                <div className="grid grid-cols-3 gap-2 font-mono text-xs pt-1">
                  <div>
                    <span className="text-[#64748B] block font-sans">Opportunity</span>
                    {player.isPitcher ? `${projection.projectedIP} IP` : `${projection.projectedPA} PA`}
                  </div>
                  <div>
                    <span className="text-[#64748B] block font-sans">{player.isPitcher ? 'Proj FIP' : 'Proj OBP'}</span>
                    {player.isPitcher ? projection.projFIP?.toFixed(2) : projection.projOBP.toFixed(3)}
                  </div>
                  <div>
                    <span className="text-[#64748B] block font-sans">Mean mWAR</span>
                    {projection.mWARMean.toFixed(2)} (±{projection.mWARSD.toFixed(2)})
                  </div>
                  <div>
                    <span className="text-[#64748B] block font-sans">Shrinkage</span>
                    {(projection.shrinkageWeight * 100).toFixed(0)}% obs
                  </div>
                  <div>
                    <span className="text-[#64748B] block font-sans">Park Factor</span>
                    {projection.parkFactorApplied}
                  </div>
                  <div>
                    <span className="text-[#64748B] block font-sans">PPC p-val</span>
                    {projection.ppcBayesianPValue.toFixed(2)}
                  </div>
                </div>
                <div className="pt-2">
                  <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] mb-1">
                    Posterior mWAR Uncertainty Interval (not a guarantee)
                  </div>
                  <PosteriorIntervalBar projection={projection} />
                </div>
              </>
            ) : null}
          </div>
        </div>

        {/* User-Configurable Availability Assumption */}
        <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs font-semibold">Playing-Time / Availability Analytical Assumption</div>
            <span className="font-mono text-xs">{availPct}% expected availability</span>
          </div>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            {player.healthRiskNote} Adjusting this percentage updates projected PA/IP and mWAR across the optimizer and simulator; it is a user-configured analytical scenario, not a medical prediction.
          </p>
          <div className="flex items-center gap-3 pt-1">
            <input
              type="range"
              min={10}
              max={100}
              step={5}
              value={availPct}
              onChange={(e) => setAvailPct(Number(e.target.value))}
              className="flex-1 accent-[#B91C1C]"
            />
            <button
              onClick={handleSaveAvailability}
              disabled={saving}
              className="px-3 py-1.5 text-xs font-medium rounded bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320] hover:opacity-90 disabled:opacity-50 whitespace-nowrap"
            >
              {saving ? 'Updating...' : 'Apply Assumption'}
            </button>
          </div>
        </div>

        {/* Qualitative Scouting vs Transactions */}
        <div className="space-y-2">
          <h3 className="text-sm font-semibold">Qualitative Scouting Reports ({playerReports.length})</h3>
          {playerReports.length === 0 ? (
            <p className="text-xs text-[#64748B]">No qualitative scouting reports filed yet for {player.fullName}.</p>
          ) : (
            playerReports.map((r) => (
              <div key={r.reportId} className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B] text-xs space-y-1">
                <div className="flex justify-between font-medium">
                  <span>{r.observer} · {r.date}</span>
                  <span className="font-mono">Ovr {r.gradeOverall2080} · Confidence: {r.confidence}</span>
                </div>
                <p className="text-[#475569] dark:text-[#CBD5E1]">{r.notes}</p>
                <div className="text-[#64748B] dark:text-[#94A3B8]">Evidence: {r.evidence} · Action: {r.followUpAction}</div>
              </div>
            ))
          )}
        </div>

        {playerTx.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-semibold">Transaction History</h3>
            {playerTx.map((tx) => (
              <div key={tx.txId} className="text-xs p-2.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] flex justify-between gap-4">
                <span className="font-mono">{tx.date} · {tx.txType}</span>
                <span className="text-[#475569] dark:text-[#CBD5E1]">{tx.notes}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
