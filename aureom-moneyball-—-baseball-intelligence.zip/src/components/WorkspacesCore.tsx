import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronRight, Search } from 'lucide-react';
import { formatIP } from '../engine/sabermetrics';
import type {
  BayesianProjection,
  DatasetStore,
  OptimizerResult,
  PlayerMaster,
  PlayerValuationRow,
  SabermetricBatting,
  SabermetricPitching,
  SimulationSummary,
} from '../engine/types';
import {
  DiamondScorecardSVG,
  ScatterAnalyticsChart,
  extractStartersForDiamond,
} from './Charts';

export type NavTab =
  | 'Overview'
  | 'Players'
  | 'Hitting'
  | 'Pitching'
  | 'Fielding'
  | 'Scouting'
  | 'Player Value'
  | 'Roster Builder'
  | 'Simulations'
  | 'Reports'
  | 'Data & Models';

export function OverviewView({
  store,
  teamId,
  valuations,
  optimizerResult,
  simulationSummary,
  onNavigate,
  onSelectPlayer,
  onRunDemoStep,
}: {
  store: DatasetStore;
  teamId: string;
  valuations: PlayerValuationRow[];
  optimizerResult: OptimizerResult;
  simulationSummary: SimulationSummary | null;
  onNavigate: (tab: NavTab) => void;
  onSelectPlayer: (playerId: string) => void;
  onRunDemoStep: (step: number) => void;
}) {
  const team = store.teams.find((t) => t.teamId === teamId) ?? store.teams[0];
  const topValueCandidates = valuations
    .filter((v) => v.player.currentTeamId !== teamId && v.acquirableForTeam)
    .slice(0, 5);

  const demoSteps = [
    { step: 1, title: 'Validate Player Records', desc: 'Inspect canonical stints, traded deduplication, & provenance', tab: 'Players' as NavTab },
    { step: 2, title: 'Calculate Sabermetrics', desc: 'Review count-based wOBA, wRC+, FIP, & mWAR decomposition', tab: 'Hitting' as NavTab },
    { step: 3, title: 'Bayesian Projections', desc: 'Inspect partial-pooled rates, 80% intervals, & PPC checks', tab: 'Data & Models' as NavTab },
    { step: 4, title: '5 Undervalued Targets', desc: 'Surface high-OBP, platoon, & FIP-regression candidates', tab: 'Player Value' as NavTab },
    { step: 5, title: 'Position-Complete Roster', desc: 'Solve exact 23-man integer roster under £68M cap', tab: 'Roster Builder' as NavTab },
    { step: 6, title: 'Low vs High-Cost Compare', desc: 'Contrast £57.8M lean build vs £78.2M contender build', tab: 'Roster Builder' as NavTab },
    { step: 7, title: 'Season Monte Carlo', desc: 'Simulate 140-game schedule with 24-state base-out engine', tab: 'Simulations' as NavTab },
    { step: 8, title: 'Test Key Player Loss', desc: 'Quantify win-distribution drop if ace Henrik Solberg is lost', tab: 'Simulations' as NavTab },
    { step: 9, title: 'Export Briefing', desc: 'Generate Quarto-compatible management report with citations', tab: 'Reports' as NavTab },
  ];

  return (
    <div className="space-y-6">
      {/* Executive Answer Hero */}
      <div className="p-6 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-3">
            <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              {team.name} · {team.stadium} (Park Factor {team.parkFactorRuns}) · Model {store.modelVersion}
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-balance">
              Which combination of players improves {team.shortName} within £{team.budgetCapM.toFixed(1)}M — and how uncertain is it?
            </h1>
            <p className="text-sm text-[#475569] dark:text-[#CBD5E1] leading-relaxed">
              Under a £{team.budgetCapM.toFixed(1)}M budget cap, combining {team.shortName}’s controllable core with targeted market inefficiencies yields{' '}
              <span className="font-mono font-semibold text-[#0F172A] dark:text-white">
                {optimizerResult.totalExpectedMWAR.toFixed(1)} projected mWAR
              </span>{' '}
              (portfolio SD ±{optimizerResult.portfolioSDMWAR.toFixed(2)} mWAR) and{' '}
              <span className="font-mono font-semibold text-[#B91C1C] dark:text-[#F87171]">
                {simulationSummary ? `${simulationSummary.expectedWins.toFixed(1)} expected wins` : 'pending simulation'}
              </span>{' '}
              across 140 games
              {simulationSummary
                ? ` (80% interval: ${simulationSummary.p10Wins}–${simulationSummary.p90Wins} wins, MC SE ±${simulationSummary.mcStandardError.toFixed(2)}).`
                : '.'}
            </p>
            <div className="flex flex-wrap gap-2.5 pt-1">
              <button
                onClick={() => onNavigate('Roster Builder')}
                className="px-4 py-2 text-xs font-medium rounded bg-[#B91C1C] text-white hover:bg-[#991B1B] whitespace-nowrap"
              >
                Open Roster Optimiser
              </button>
              <button
                onClick={() => onNavigate('Simulations')}
                className="px-4 py-2 text-xs font-medium rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B] whitespace-nowrap"
              >
                Run Season Simulation
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 border-t lg:border-t-0 lg:border-l border-[#E2DFD7] dark:border-[#1E293B] pt-4 lg:pt-0 lg:pl-6">
            <div className="text-xs font-medium text-[#64748B] dark:text-[#94A3B8] mb-2">
              Optimised Defensive Alignment · Projected 2026 mWAR
            </div>
            <DiamondScorecardSVG starters={extractStartersForDiamond(optimizerResult.selectedRoster)} />
          </div>
        </div>
      </div>

      {/* 4 Key Front-Office KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">Optimised Roster Cost</div>
          <div className="font-mono text-2xl font-semibold mt-1">
            £{optimizerResult.totalEffectiveCostM.toFixed(2)}M
          </div>
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-1">
            Cap £{team.budgetCapM.toFixed(1)}M · Headroom £{optimizerResult.budgetRemainingM.toFixed(2)}M
          </div>
        </div>
        <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">Projected Team mWAR</div>
          <div className="font-mono text-2xl font-semibold mt-1">
            {optimizerResult.totalExpectedMWAR.toFixed(2)}
          </div>
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-1">
            Portfolio SD ±{optimizerResult.portfolioSDMWAR.toFixed(2)} · {optimizerResult.newAcquisitionsCount} new acquisitions
          </div>
        </div>
        <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">Simulated Expected Wins</div>
          <div className="font-mono text-2xl font-semibold mt-1">
            {simulationSummary ? simulationSummary.expectedWins.toFixed(1) : '—'}
          </div>
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-1">
            {simulationSummary
              ? `P10–P90: ${simulationSummary.p10Wins}–${simulationSummary.p90Wins}W · MC SE ±${simulationSummary.mcStandardError.toFixed(2)}`
              : 'Run simulation for distribution'}
          </div>
        </div>
        <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">AIBL Playoff Probability</div>
          <div className="font-mono text-2xl font-semibold mt-1">
            {simulationSummary ? `${(simulationSummary.playoffProbability * 100).toFixed(1)}%` : '—'}
          </div>
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-1">
            Defined as ≥ 78 wins in 140-game schedule
          </div>
        </div>
      </div>

      {/* 5 Plausible Value Candidates + 9-Step Guided Demonstration */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Top 5 Undervalued Market Candidates</h2>
              <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
                Ranked by surplus value (mWAR × £3.2M − effective cost) · Click a row for full Bayesian dossier
              </p>
            </div>
            <button
              onClick={() => onNavigate('Player Value')}
              className="text-xs font-medium text-[#B91C1C] dark:text-[#F87171] hover:underline whitespace-nowrap"
            >
              View All Value
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
                  <th className="py-2 text-left font-medium">Player</th>
                  <th className="py-2 text-left font-medium">Pos / Status</th>
                  <th className="py-2 text-right font-medium">Eff. Cost</th>
                  <th className="py-2 text-right font-medium">Proj mWAR</th>
                  <th className="py-2 text-right font-medium">Surplus</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
                {topValueCandidates.map((v) => (
                  <tr
                    key={v.player.playerId}
                    onClick={() => onSelectPlayer(v.player.playerId)}
                    className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
                  >
                    <td className="py-2.5 pr-3">
                      <div className="font-medium">{v.player.fullName}</div>
                      <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                        {v.inefficiencyReasons[0] ?? v.player.healthRiskNote}
                      </div>
                    </td>
                    <td className="py-2.5 pr-3 text-[#475569] dark:text-[#CBD5E1]">
                      {v.player.primaryPos} · {v.player.availability}
                    </td>
                    <td className="py-2.5 text-right font-mono">£{v.totalEffectiveCostM.toFixed(2)}M</td>
                    <td className="py-2.5 text-right font-mono">
                      {v.projection.mWARMean.toFixed(2)} ({v.projection.mWARLow80.toFixed(1)}–{v.projection.mWARHigh80.toFixed(1)})
                    </td>
                    <td className="py-2.5 text-right font-mono font-semibold text-[#16A34A] dark:text-[#4ADE80]">
                      +£{v.surplusValueM.toFixed(2)}M
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-5 p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
          <div>
            <h2 className="text-xl font-bold tracking-tight">Sheffield Steelheads Guided Workflow</h2>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              End-to-end 9-step analytical demonstration using offline synthetic data
            </p>
          </div>
          <div className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {demoSteps.map((d) => (
              <button
                key={d.step}
                onClick={() => onRunDemoStep(d.step)}
                className="w-full py-2 flex items-center justify-between gap-3 text-left hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] px-1.5 rounded transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold truncate">
                    <span className="font-mono text-[#B91C1C] dark:text-[#F87171] mr-1.5">
                      {String(d.step).padStart(2, '0')}.
                    </span>
                    {d.title}
                  </div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] truncate">{d.desc}</div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-[#94A3B8] shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function PlayersView({
  store,
  projections,
  teamFilter,
  onSelectPlayer,
}: {
  store: DatasetStore;
  projections: Map<string, BayesianProjection>;
  teamFilter: string;
  onSelectPlayer: (playerId: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [scope, setScope] = useState<'ALL' | 'TEAM' | 'FA_TRADE'>('ALL');
  const [posFilter, setPosFilter] = useState<string>('ALL');
  const [sortKey, setSortKey] = useState<'mwar' | 'salary' | 'name'>('mwar');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return store.players
      .filter((p) => {
        if (scope === 'TEAM' && p.currentTeamId !== teamFilter) return false;
        if (scope === 'FA_TRADE' && p.availability !== 'Free Agent' && p.availability !== 'Trade Target') return false;
        if (posFilter !== 'ALL' && !p.eligiblePositions.includes(posFilter as any)) return false;
        if (q && !p.fullName.toLowerCase().includes(q) && !p.playerId.toLowerCase().includes(q)) return false;
        return true;
      })
      .map((p) => ({
        player: p,
        proj: projections.get(p.playerId),
      }))
      .sort((a, b) => {
        const mult = sortDir === 'asc' ? 1 : -1;
        if (sortKey === 'name') return a.player.fullName.localeCompare(b.player.fullName) * mult;
        if (sortKey === 'salary') return (a.player.salaryM - b.player.salaryM) * mult;
        return ((a.proj?.mWARMean ?? 0) - (b.proj?.mWARMean ?? 0)) * mult;
      });
  }, [store.players, projections, search, scope, teamFilter, posFilter, sortKey, sortDir]);

  const toggleSort = (k: typeof sortKey) => {
    if (sortKey === k) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setSortKey(k);
      setSortDir('desc');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Player Master & Availability Registry</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            {rows.length} players · Stable identifiers, multi-position eligibility, contract control, and 2026 Bayesian mWAR
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#64748B]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name or ID..."
              className="pl-8 pr-3 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1 p-1 rounded bg-[#EDEAE2] dark:bg-[#111B2E] border border-[#E2DFD7] dark:border-[#1E293B]">
            {[
              { id: 'ALL', label: 'All League' },
              { id: 'TEAM', label: `Club (${teamFilter})` },
              { id: 'FA_TRADE', label: 'FA & Trade Targets' },
            ].map((s) => (
              <button
                key={s.id}
                onClick={() => setScope(s.id as any)}
                className={`px-2.5 py-1 text-xs rounded font-medium whitespace-nowrap ${
                  scope === s.id
                    ? 'bg-white dark:bg-[#1E293B] text-[#0F172A] dark:text-white shadow-xs'
                    : 'text-[#475569] dark:text-[#94A3B8]'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <select
            value={posFilter}
            onChange={(e) => setPosFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]"
          >
            <option value="ALL">All Positions</option>
            {['C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF', 'DH', 'SP', 'RP'].map((pos) => (
              <option key={pos} value={pos}>
                {pos}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-medium cursor-pointer" onClick={() => toggleSort('name')}>
                Player {sortKey === 'name' && (sortDir === 'asc' ? <ArrowUp className="inline w-3 h-3" /> : <ArrowDown className="inline w-3 h-3" />)}
              </th>
              <th className="py-2.5 px-3 text-left font-medium">Team · Availability</th>
              <th className="py-2.5 px-3 text-left font-medium">Eligible Pos</th>
              <th className="py-2.5 px-3 text-left font-medium">B/T</th>
              <th className="py-2.5 px-3 text-right font-medium cursor-pointer" onClick={() => toggleSort('salary')}>
                Salary {sortKey === 'salary' && (sortDir === 'asc' ? <ArrowUp className="inline w-3 h-3" /> : <ArrowDown className="inline w-3 h-3" />)}
              </th>
              <th className="py-2.5 px-3 text-right font-medium">Trade Cost</th>
              <th className="py-2.5 px-3 text-right font-medium">Ctrl</th>
              <th className="py-2.5 px-3 text-right font-medium cursor-pointer" onClick={() => toggleSort('mwar')}>
                2026 mWAR (80% CI) {sortKey === 'mwar' && (sortDir === 'asc' ? <ArrowUp className="inline w-3 h-3" /> : <ArrowDown className="inline w-3 h-3" />)}
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {rows.map(({ player, proj }) => (
              <tr
                key={player.playerId}
                onClick={() => onSelectPlayer(player.playerId)}
                className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
              >
                <td className="py-2.5 px-3">
                  <div className="font-medium">{player.fullName}</div>
                  <div className="text-[11px] font-mono text-[#64748B]">{player.playerId}</div>
                </td>
                <td className="py-2.5 px-3 text-[#475569] dark:text-[#CBD5E1]">
                  {player.currentTeamId ?? 'FA'} · {player.availability}
                </td>
                <td className="py-2.5 px-3 font-mono">{player.eligiblePositions.join('/')}</td>
                <td className="py-2.5 px-3 font-mono">{player.bats}/{player.throws}</td>
                <td className="py-2.5 px-3 text-right font-mono">£{player.salaryM.toFixed(2)}M</td>
                <td className="py-2.5 px-3 text-right font-mono">£{player.tradeCostM.toFixed(2)}M</td>
                <td className="py-2.5 px-3 text-right font-mono">{player.yearsControl}y</td>
                <td className="py-2.5 px-3 text-right font-mono">
                  <span className="font-semibold">{proj?.mWARMean.toFixed(2)}</span>{' '}
                  <span className="text-[#64748B]">
                    [{proj?.mWARLow80.toFixed(1)}, {proj?.mWARHigh80.toFixed(1)}]
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function HittingView({
  store,
  battingHistory,
  projections,
  onSelectPlayer,
}: {
  store: DatasetStore;
  battingHistory: SabermetricBatting[];
  projections: Map<string, BayesianProjection>;
  onSelectPlayer: (playerId: string) => void;
}) {
  const [sortCol, setSortCol] = useState<'wRCPlus' | 'obp' | 'woba' | 'mwar'>('wRCPlus');
  const playerMap = new Map(store.players.map((p) => [p.playerId, p]));

  const sorted = [...battingHistory].sort((a, b) => {
    if (sortCol === 'obp') return (b.obp ?? 0) - (a.obp ?? 0);
    if (sortCol === 'woba') return (b.wOBA ?? 0) - (a.wOBA ?? 0);
    if (sortCol === 'mwar') return b.modelledWAR - a.modelledWAR;
    return (b.wRCPlus ?? 0) - (a.wRCPlus ?? 0);
  });

  const scatterPoints = sorted
    .filter((b) => b.pa >= 120 && b.obp !== null)
    .map((b) => {
      const p = playerMap.get(b.playerId)!;
      return {
        id: b.playerId,
        label: p.fullName,
        sublabel: `${p.primaryPos} · ${b.teams.join('/')} · ${b.pa} PA`,
        x: b.obp ?? 0,
        y: b.slg ?? 0,
        highlight: p.currentTeamId === 'SHF',
      };
    });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Hitting Analytics (Count-Derived)</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            2025 Historical Totals aggregated from underlying counts (traded stints combined without double-counting) · Park & seasonal weights applied
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 rounded bg-[#EDEAE2] dark:bg-[#111B2E] border border-[#E2DFD7] dark:border-[#1E293B]">
          {[
            { id: 'wRCPlus', label: 'wRC+' },
            { id: 'woba', label: 'wOBA' },
            { id: 'obp', label: 'OBP' },
            { id: 'mwar', label: 'Hist mWAR' },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setSortCol(c.id as any)}
              className={`px-2.5 py-1 text-xs rounded font-medium ${
                sortCol === c.id
                  ? 'bg-white dark:bg-[#1E293B] text-[#0F172A] dark:text-white'
                  : 'text-[#475569] dark:text-[#94A3B8]'
              }`}
            >
              Sort: {c.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
        <div className="text-xs font-semibold mb-1">2025 OBP vs SLG Profile (Sheffield highlighted in red)</div>
        <ScatterAnalyticsChart
          points={scatterPoints}
          xLabel="On-Base Percentage (OBP)"
          yLabel="Slugging Percentage (SLG)"
          xFormat={(v) => v.toFixed(3)}
          yFormat={(v) => v.toFixed(3)}
          onSelect={onSelectPlayer}
        />
      </div>

      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-sans font-medium">Player</th>
              <th className="py-2.5 px-2 text-left font-sans font-medium">Teams</th>
              <th className="py-2.5 px-2 text-right">PA</th>
              <th className="py-2.5 px-2 text-right">BA</th>
              <th className="py-2.5 px-2 text-right">OBP</th>
              <th className="py-2.5 px-2 text-right">SLG</th>
              <th className="py-2.5 px-2 text-right">ISO</th>
              <th className="py-2.5 px-2 text-right">BB%</th>
              <th className="py-2.5 px-2 text-right">K%</th>
              <th className="py-2.5 px-2 text-right">BABIP</th>
              <th className="py-2.5 px-2 text-right">wOBA</th>
              <th className="py-2.5 px-2 text-right">wRC+</th>
              <th className="py-2.5 px-2 text-right">Hist mWAR</th>
              <th className="py-2.5 px-3 text-right font-sans">2026 Proj wRC+</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {sorted.slice(0, 45).map((b) => {
              const p = playerMap.get(b.playerId)!;
              const proj = projections.get(b.playerId);
              return (
                <tr
                  key={b.playerId}
                  onClick={() => onSelectPlayer(b.playerId)}
                  className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
                >
                  <td className="py-2 px-3 font-sans font-medium">
                    {p.fullName} <span className="text-[11px] text-[#64748B] font-mono">({p.primaryPos})</span>
                  </td>
                  <td className="py-2 px-2 text-[#64748B]">
                    {b.teams.join('/')}
                    {b.stintCount > 1 ? ' *' : ''}
                  </td>
                  <td className="py-2 px-2 text-right">{b.pa}</td>
                  <td className="py-2 px-2 text-right">{b.ba?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right font-semibold">{b.obp?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{b.slg?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{b.iso?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{b.bbPct !== null ? `${(b.bbPct * 100).toFixed(1)}%` : '—'}</td>
                  <td className="py-2 px-2 text-right">{b.kPct !== null ? `${(b.kPct * 100).toFixed(1)}%` : '—'}</td>
                  <td className="py-2 px-2 text-right">{b.babip?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{b.wOBA?.toFixed(3) ?? '—'}</td>
                  <td className="py-2 px-2 text-right font-semibold">{b.wRCPlus?.toFixed(0) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{b.modelledWAR.toFixed(2)}</td>
                  <td className="py-2 px-3 text-right text-[#B91C1C] dark:text-[#F87171]">
                    {proj?.projWRCPlus.toFixed(0)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function PitchingView({
  store,
  pitchingHistory,
  projections,
  onSelectPlayer,
}: {
  store: DatasetStore;
  pitchingHistory: SabermetricPitching[];
  projections: Map<string, BayesianProjection>;
  onSelectPlayer: (playerId: string) => void;
}) {
  const playerMap = new Map(store.players.map((p) => [p.playerId, p]));
  const sorted = [...pitchingHistory].sort((a, b) => (a.fip ?? 99) - (b.fip ?? 99));

  const scatterPoints = sorted
    .filter((p) => p.era !== null && p.fip !== null)
    .map((pt) => {
      const pl = playerMap.get(pt.playerId)!;
      return {
        id: pt.playerId,
        label: pl.fullName,
        sublabel: `${pt.role} · ${pt.teams.join('/')} · ${formatIP(pt.outsRecorded)} IP`,
        x: pt.fip ?? 4.2,
        y: pt.era ?? 4.2,
        highlight: pl.currentTeamId === 'SHF' || pl.playerId === 'FA-V04',
      };
    });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Pitching Roles & FIP Regression Workspace</h1>
        <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
          2025 FIP computed using documented seasonal constant cFIP = 3.18 · Pitchers above the diagonal (ERA &gt; FIP) represent potential regression targets
        </p>
      </div>

      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
        <div className="text-xs font-semibold mb-1">2025 FIP vs ERA Divergence (Dashed Line: ERA = FIP)</div>
        <ScatterAnalyticsChart
          points={scatterPoints}
          xLabel="Fielding Independent Pitching (FIP)"
          yLabel="Earned Run Average (ERA)"
          diagonalReference
          onSelect={onSelectPlayer}
        />
      </div>

      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-sans font-medium">Pitcher</th>
              <th className="py-2 px-2 text-left font-sans">Role · Teams</th>
              <th className="py-2 px-2 text-right">IP</th>
              <th className="py-2 px-2 text-right">ERA</th>
              <th className="py-2 px-2 text-right">FIP</th>
              <th className="py-2 px-2 text-right">ERA−FIP</th>
              <th className="py-2 px-2 text-right">WHIP</th>
              <th className="py-2 px-2 text-right">K%</th>
              <th className="py-2 px-2 text-right">BB%</th>
              <th className="py-2 px-2 text-right">HR/9</th>
              <th className="py-2 px-2 text-right">Hist mWAR</th>
              <th className="py-2 px-3 text-right font-sans">2026 Proj FIP (80% CI)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {sorted.map((pt) => {
              const pl = playerMap.get(pt.playerId)!;
              const proj = projections.get(pt.playerId);
              const diff = pt.era !== null && pt.fip !== null ? pt.era - pt.fip : null;
              return (
                <tr
                  key={pt.playerId}
                  onClick={() => onSelectPlayer(pt.playerId)}
                  className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
                >
                  <td className="py-2 px-3 font-sans font-medium">{pl.fullName}</td>
                  <td className="py-2 px-2 font-sans text-[#64748B]">
                    {pt.role} · {pt.teams.join('/')}
                    {pt.stintCount > 1 ? ' *' : ''}
                  </td>
                  <td className="py-2 px-2 text-right">{formatIP(pt.outsRecorded)}</td>
                  <td className="py-2 px-2 text-right">{pt.era?.toFixed(2) ?? '—'}</td>
                  <td className="py-2 px-2 text-right font-semibold">{pt.fip?.toFixed(2) ?? '—'}</td>
                  <td className={`py-2 px-2 text-right ${diff && diff > 0.5 ? 'text-[#16A34A] dark:text-[#4ADE80] font-semibold' : ''}`}>
                    {diff !== null ? (diff > 0 ? `+${diff.toFixed(2)}` : diff.toFixed(2)) : '—'}
                  </td>
                  <td className="py-2 px-2 text-right">{pt.whip?.toFixed(2) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{pt.kPct !== null ? `${(pt.kPct * 100).toFixed(1)}%` : '—'}</td>
                  <td className="py-2 px-2 text-right">{pt.bbPct !== null ? `${(pt.bbPct * 100).toFixed(1)}%` : '—'}</td>
                  <td className="py-2 px-2 text-right">{pt.hrPer9?.toFixed(2) ?? '—'}</td>
                  <td className="py-2 px-2 text-right">{pt.modelledWAR.toFixed(2)}</td>
                  <td className="py-2 px-3 text-right text-[#B91C1C] dark:text-[#F87171]">
                    {proj?.projFIP?.toFixed(2)} [{proj?.fipLow80?.toFixed(2)}–{proj?.fipHigh80?.toFixed(2)}]
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function FieldingView({
  store,
  onSelectPlayer,
}: {
  store: DatasetStore;
  onSelectPlayer: (playerId: string) => void;
}) {
  const [pos, setPos] = useState('ALL');
  const playerMap = new Map(store.players.map((p) => [p.playerId, p]));
  const records2025 = store.fieldingRecords
    .filter((f) => f.season === 2025 && (pos === 'ALL' || f.pos === pos))
    .map((f) => ({
      ...f,
      player: playerMap.get(f.playerId)!,
      totalDefRuns: +(f.rangeRunsEst + f.armRunsEst + f.framingRunsEst).toFixed(1),
    }))
    .sort((a, b) => b.totalDefRuns - a.totalDefRuns);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Defensive Contribution & Limitations</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            2025 Fielding components combining range, arm, and catcher framing estimates — explicitly avoiding error-count-only evaluation
          </p>
        </div>
        <select
          value={pos}
          onChange={(e) => setPos(e.target.value)}
          className="px-3 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]"
        >
          <option value="ALL">All Defensive Positions</option>
          {['C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF'].map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
      </div>

      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] text-xs text-[#475569] dark:text-[#CBD5E1] space-y-1">
        <div className="font-semibold text-[#0F172A] dark:text-[#F1F5F9]">Why Errors Alone Mislead Front-Office Evaluation</div>
        <p>
          Players with elite range (e.g., shortstops Kieran Vance and Benito Morales) reach batted balls that slower defenders never touch, creating both more assists and higher raw error counts. AUREOM’s defensive component blends estimated range runs, throwing arm runs, and catcher framing runs, and applies empirical shrinkage (`prior = 450 PA` equivalent) in 2026 projections because single-season defensive metrics carry substantial noise.
        </p>
      </div>

      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-sans font-medium">Player</th>
              <th className="py-2 px-2 text-left font-sans">Pos · Team</th>
              <th className="py-2 px-2 text-right">Inn</th>
              <th className="py-2 px-2 text-right">PO</th>
              <th className="py-2 px-2 text-right">A</th>
              <th className="py-2 px-2 text-right">E</th>
              <th className="py-2 px-2 text-right">DP</th>
              <th className="py-2 px-2 text-right">Range Runs</th>
              <th className="py-2 px-2 text-right">Arm Runs</th>
              <th className="py-2 px-2 text-right">Framing</th>
              <th className="py-2 px-3 text-right font-semibold">Total Def Runs</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {records2025.slice(0, 35).map((r) => (
              <tr
                key={r.recordId}
                onClick={() => onSelectPlayer(r.playerId)}
                className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
              >
                <td className="py-2 px-3 font-sans font-medium">{r.player?.fullName ?? r.playerId}</td>
                <td className="py-2 px-2 font-sans text-[#64748B]">{r.pos} · {r.teamId}</td>
                <td className="py-2 px-2 text-right">{r.inn}</td>
                <td className="py-2 px-2 text-right">{r.po}</td>
                <td className="py-2 px-2 text-right">{r.a}</td>
                <td className="py-2 px-2 text-right">{r.e}</td>
                <td className="py-2 px-2 text-right">{r.dp}</td>
                <td className="py-2 px-2 text-right">{r.rangeRunsEst > 0 ? `+${r.rangeRunsEst.toFixed(1)}` : r.rangeRunsEst.toFixed(1)}</td>
                <td className="py-2 px-2 text-right">{r.armRunsEst > 0 ? `+${r.armRunsEst.toFixed(1)}` : r.armRunsEst.toFixed(1)}</td>
                <td className="py-2 px-2 text-right">{r.framingRunsEst !== 0 ? r.framingRunsEst.toFixed(1) : '—'}</td>
                <td className={`py-2 px-3 text-right font-semibold ${r.totalDefRuns >= 0 ? 'text-[#16A34A] dark:text-[#4ADE80]' : 'text-[#DC2626] dark:text-[#F87171]'}`}>
                  {r.totalDefRuns > 0 ? `+${r.totalDefRuns.toFixed(1)}` : r.totalDefRuns.toFixed(1)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
