import React, { useMemo, useState } from 'react';
import { Download, Lock, Play, RotateCcw, Unlock } from 'lucide-react';
import type {
  BacktestMetrics,
  BayesianProjection,
  DatasetStore,
  OptimizerConfig,
  OptimizerResult,
  PlayerValuationRow,
  ScoutingReport,
  SimulationConfig,
  SimulationSummary,
} from '../engine/types';
import {
  BaseOutMatrixGrid,
  ScatterAnalyticsChart,
  WinHistogramChart,
} from './Charts';

export function ScoutingView({
  store,
  projections,
  onAddReport,
  onSelectPlayer,
}: {
  store: DatasetStore;
  projections: Map<string, BayesianProjection>;
  onAddReport: (report: Omit<ScoutingReport, 'reportId'>) => Promise<void>;
  onSelectPlayer: (playerId: string) => void;
}) {
  const [playerId, setPlayerId] = useState('FA-V01');
  const [observer, setObserver] = useState('H. MacKenzie (Pro Scouting)');
  const [roleProjection, setRoleProjection] = useState('Everyday Corner OF');
  const [gradeOverall, setGradeOverall] = useState(55);
  const [hitGrade, setHitGrade] = useState(55);
  const [powerGrade, setPowerGrade] = useState(50);
  const [speedGrade, setSpeedGrade] = useState(50);
  const [fieldGrade, setFieldGrade] = useState(50);
  const [armGrade, setArmGrade] = useState(55);
  const [confidence, setConfidence] = useState<'Low' | 'Medium' | 'High'>('High');
  const [notes, setNotes] = useState('');
  const [evidence, setEvidence] = useState('');
  const [followUpAction, setFollowUpAction] = useState('');
  const [saving, setSaving] = useState(false);

  const playerMap = new Map(store.players.map((p) => [p.playerId, p]));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) return;
    setSaving(true);
    try {
      await onAddReport({
        playerId,
        observer,
        date: '2026-11-14',
        roleProjection,
        gradeOverall2080: gradeOverall,
        hitGrade,
        powerGrade,
        speedGrade,
        fieldGrade,
        armOrStuffGrade: armGrade,
        confidence,
        notes,
        evidence: evidence || 'Live series look',
        followUpAction: followUpAction || 'Review with analytics desk',
      });
      setNotes('');
      setEvidence('');
      setFollowUpAction('');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Qualitative Scouting & Statistical Side-by-Side</h1>
        <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
          Qualitative 20–80 field reports remain strictly separated from measured statistics and are never silently converted into numeric projections.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Side-by-Side Reports */}
        <div className="lg:col-span-7 space-y-3">
          {store.scoutingReports.map((r) => {
            const p = playerMap.get(r.playerId);
            const proj = projections.get(r.playerId);
            return (
              <div
                key={r.reportId}
                className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-2.5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E2DFD7] dark:border-[#1E293B] pb-2">
                  <div>
                    <button
                      onClick={() => onSelectPlayer(r.playerId)}
                      className="text-sm font-bold hover:text-[#B91C1C] dark:hover:text-[#F87171] text-left"
                    >
                      {p?.fullName ?? r.playerId} ({p?.primaryPos})
                    </button>
                    <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                      {r.observer} · {r.date} · Confidence: {r.confidence}
                    </div>
                  </div>
                  <div className="font-mono text-xs text-right">
                    <div>20–80 Overall: <span className="font-bold">{r.gradeOverall2080}</span></div>
                    <div className="text-[11px] text-[#64748B]">Role: {r.roleProjection}</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <div className="font-semibold text-[#475569] dark:text-[#94A3B8]">Qualitative Field Assessment</div>
                    <div className="font-mono text-[11px] text-[#64748B]">
                      Hit {r.hitGrade} · Pwr {r.powerGrade} · Spd {r.speedGrade} · Fld {r.fieldGrade} · Arm/Stuff {r.armOrStuffGrade}
                    </div>
                    <p className="text-[#0F172A] dark:text-[#E2E8F0] leading-relaxed">{r.notes}</p>
                    <div className="text-[11px] text-[#64748B]">Evidence: {r.evidence}</div>
                    <div className="text-[11px] font-medium text-[#B91C1C] dark:text-[#F87171]">Next: {r.followUpAction}</div>
                  </div>

                  <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B] space-y-1">
                    <div className="font-semibold text-[#475569] dark:text-[#94A3B8]">Quantitative Projection (Separate)</div>
                    {proj ? (
                      <div className="font-mono text-[11px] space-y-0.5">
                        <div>2026 mWAR: <span className="font-semibold">{proj.mWARMean.toFixed(2)}</span> (80% CI: {proj.mWARLow80.toFixed(1)}–{proj.mWARHigh80.toFixed(1)})</div>
                        {p?.isPitcher ? (
                          <div>Proj FIP: {proj.projFIP?.toFixed(2)} · K%: {(proj.projKPct * 100).toFixed(1)}% · {proj.projectedIP} IP</div>
                        ) : (
                          <div>Proj OBP: {proj.projOBP.toFixed(3)} · wRC+: {proj.projWRCPlus.toFixed(0)} · {proj.projectedPA} PA</div>
                        )}
                        <div>Shrinkage: {(proj.shrinkageWeight * 100).toFixed(0)}% observed · Cost £{((p?.salaryM ?? 0) + (p?.tradeCostM ?? 0)).toFixed(2)}M</div>
                      </div>
                    ) : (
                      <div className="text-[11px] text-[#64748B]">No projection available.</div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Add Structured Report Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3 h-fit"
        >
          <h2 className="text-xl font-bold tracking-tight">Log Structured Scouting Report</h2>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <label className="space-y-1 col-span-2">
              <span className="font-medium">Player</span>
              <select
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
              >
                {store.players.slice(0, 40).map((p) => (
                  <option key={p.playerId} value={p.playerId}>
                    {p.fullName} ({p.primaryPos} · {p.currentTeamId ?? 'FA'})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="font-medium">Observer</span>
              <input
                value={observer}
                onChange={(e) => setObserver(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
              />
            </label>
            <label className="space-y-1">
              <span className="font-medium">Confidence</span>
              <select
                value={confidence}
                onChange={(e) => setConfidence(e.target.value as any)}
                className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </label>
            <label className="space-y-1 col-span-2">
              <span className="font-medium">Role Projection</span>
              <input
                value={roleProjection}
                onChange={(e) => setRoleProjection(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
              />
            </label>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            {[
              { label: 'Ovr', val: gradeOverall, set: setGradeOverall },
              { label: 'Hit', val: hitGrade, set: setHitGrade },
              { label: 'Power', val: powerGrade, set: setPowerGrade },
              { label: 'Speed', val: speedGrade, set: setSpeedGrade },
              { label: 'Field', val: fieldGrade, set: setFieldGrade },
              { label: 'Arm/Stuff', val: armGrade, set: setArmGrade },
            ].map((g) => (
              <label key={g.label} className="space-y-1">
                <span className="text-[11px] text-[#64748B]">{g.label} (20–80)</span>
                <input
                  type="number"
                  min={20}
                  max={80}
                  step={5}
                  value={g.val}
                  onChange={(e) => g.set(Number(e.target.value))}
                  className="w-full px-2 py-1 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
                />
              </label>
            ))}
          </div>

          <label className="block space-y-1 text-xs">
            <span className="font-medium">Observation Notes</span>
            <textarea
              rows={3}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Mechanical, plate discipline, or defensive observations..."
              className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
            />
          </label>
          <label className="block space-y-1 text-xs">
            <span className="font-medium">Supporting Evidence</span>
            <input
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
              placeholder="Series, video look, or matchup context..."
              className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
            />
          </label>
          <label className="block space-y-1 text-xs">
            <span className="font-medium">Follow-up Action</span>
            <input
              value={followUpAction}
              onChange={(e) => setFollowUpAction(e.target.value)}
              placeholder="Medical check, platoon review, or contract target..."
              className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
            />
          </label>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-2 text-xs font-medium rounded bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320] hover:opacity-90 disabled:opacity-50"
          >
            {saving ? 'Saving Report...' : 'Save Scouting Report'}
          </button>
        </form>
      </div>
    </div>
  );
}

export function PlayerValueView({
  valuations,
  teamId,
  onSelectPlayer,
}: {
  valuations: PlayerValuationRow[];
  teamId: string;
  onSelectPlayer: (playerId: string) => void;
}) {
  const [filterAvail, setFilterAvail] = useState<'ACQUIRABLE' | 'FA_ONLY' | 'ALL'>('ACQUIRABLE');
  const [amortizeTrade, setAmortizeTrade] = useState(true);

  const filtered = useMemo(() => {
    return valuations
      .filter((v) => {
        if (filterAvail === 'ACQUIRABLE') return v.player.currentTeamId !== teamId && v.acquirableForTeam;
        if (filterAvail === 'FA_ONLY') return v.player.availability === 'Free Agent';
        return true;
      })
      .map((v) => {
        const tradeCharge =
          v.player.currentTeamId === teamId
            ? 0
            : amortizeTrade
            ? v.player.tradeCostM / Math.max(1, v.player.yearsControl)
            : v.player.tradeCostM;
        const effCost = +(v.player.salaryM + tradeCharge).toFixed(2);
        const surplus = +(v.projection.mWARMean * 3.2 - effCost).toFixed(2);
        return { ...v, effCost, surplus };
      })
      .sort((a, b) => b.surplus - a.surplus);
  }, [valuations, filterAvail, teamId, amortizeTrade]);

  const scatterPts = filtered.slice(0, 38).map((v) => ({
    id: v.player.playerId,
    label: v.player.fullName,
    sublabel: `${v.player.primaryPos} · ${v.player.availability} · Surplus ${v.surplus >= 0 ? '+' : ''}£${v.surplus.toFixed(1)}M`,
    x: v.effCost,
    y: v.projection.mWARMean,
    highlight: v.inefficiencyReasons.length > 0,
  }));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Player Valuation & Market Inefficiencies</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            Separates annual salary, trade acquisition cost, contract horizon, uncertainty, and availability · Market rate assumed £3.2M / mWAR
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-1.5 text-xs cursor-pointer">
            <input
              type="checkbox"
              checked={amortizeTrade}
              onChange={(e) => setAmortizeTrade(e.target.checked)}
              className="accent-[#B91C1C]"
            />
            Amortize trade cost over control years
          </label>
          <div className="flex items-center gap-1 p-1 rounded bg-[#EDEAE2] dark:bg-[#111B2E] border border-[#E2DFD7] dark:border-[#1E293B]">
            {[
              { id: 'ACQUIRABLE', label: 'FA & Trade Targets' },
              { id: 'FA_ONLY', label: 'Free Agents Only' },
              { id: 'ALL', label: 'All League' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterAvail(f.id as any)}
                className={`px-2.5 py-1 text-xs rounded font-medium ${
                  filterAvail === f.id
                    ? 'bg-white dark:bg-[#1E293B] text-[#0F172A] dark:text-white'
                    : 'text-[#475569] dark:text-[#94A3B8]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E]">
        <div className="text-xs font-semibold mb-1">
          Effective Annual Cost (£M) vs Projected 2026 mWAR (Red = Market Inefficiency Signal)
        </div>
        <ScatterAnalyticsChart
          points={scatterPts}
          xLabel="Effective Annual Cost (£M)"
          yLabel="Projected 2026 mWAR"
          xFormat={(v) => `£${v.toFixed(1)}M`}
          yFormat={(v) => v.toFixed(1)}
          onSelect={onSelectPlayer}
        />
      </div>

      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-medium">Player</th>
              <th className="py-2 px-2 text-left font-medium">Availability · Pos</th>
              <th className="py-2 px-2 text-right font-medium">Salary</th>
              <th className="py-2 px-2 text-right font-medium">Trade Cost</th>
              <th className="py-2 px-2 text-right font-medium">Eff. Cost</th>
              <th className="py-2 px-2 text-right font-medium">Proj mWAR (±SD)</th>
              <th className="py-2 px-2 text-right font-medium">Platoon ΔOBP</th>
              <th className="py-2 px-2 text-right font-medium">Surplus (£M)</th>
              <th className="py-2.5 px-3 text-left font-medium">Identified Inefficiency / Note</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {filtered.slice(0, 32).map((v) => (
              <tr
                key={v.player.playerId}
                onClick={() => onSelectPlayer(v.player.playerId)}
                className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B] cursor-pointer"
              >
                <td className="py-2 px-3 font-medium">
                  {v.player.fullName}
                  <div className="text-[11px] font-mono text-[#64748B]">{v.player.yearsControl}y ctrl · {v.player.contractType}</div>
                </td>
                <td className="py-2 px-2 text-[#475569] dark:text-[#CBD5E1]">
                  {v.player.availability} · {v.player.eligiblePositions.join('/')}
                </td>
                <td className="py-2 px-2 text-right font-mono">£{v.player.salaryM.toFixed(2)}M</td>
                <td className="py-2 px-2 text-right font-mono">£{v.player.tradeCostM.toFixed(2)}M</td>
                <td className="py-2 px-2 text-right font-mono font-medium">£{v.effCost.toFixed(2)}M</td>
                <td className="py-2 px-2 text-right font-mono">
                  {v.projection.mWARMean.toFixed(2)} (±{v.projection.mWARSD.toFixed(2)})
                </td>
                <td className="py-2 px-2 text-right font-mono">
                  {v.player.isPitcher ? '—' : `${v.platoonDeltaOBP >= 0 ? '+' : ''}${v.platoonDeltaOBP.toFixed(3)}`}
                </td>
                <td className={`py-2 px-2 text-right font-mono font-semibold ${v.surplus >= 0 ? 'text-[#16A34A] dark:text-[#4ADE80]' : 'text-[#DC2626] dark:text-[#F87171]'}`}>
                  {v.surplus >= 0 ? '+' : ''}£{v.surplus.toFixed(2)}M
                </td>
                <td className="py-2 px-3 text-[11px] text-[#475569] dark:text-[#CBD5E1]">
                  {v.inefficiencyReasons.length > 0 ? v.inefficiencyReasons.join(' · ') : v.player.healthRiskNote}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function RosterBuilderView({
  store,
  config,
  result,
  optimizing,
  onChangeConfig,
  onRunOptimize,
  onSendToSimulator,
  onSelectPlayer,
}: {
  store: DatasetStore;
  config: OptimizerConfig;
  result: OptimizerResult;
  optimizing: boolean;
  onChangeConfig: (next: OptimizerConfig) => void;
  onRunOptimize: (overrideConfig?: OptimizerConfig) => Promise<void>;
  onSendToSimulator: (playerIds: string[]) => void;
  onSelectPlayer: (playerId: string) => void;
}) {
  const toggleLock = (id: string) => {
    const locked = config.lockedPlayerIds.includes(id)
      ? config.lockedPlayerIds.filter((x) => x !== id)
      : [...config.lockedPlayerIds, id];
    const excluded = config.excludedPlayerIds.filter((x) => x !== id);
    onChangeConfig({ ...config, lockedPlayerIds: locked, excludedPlayerIds: excluded });
  };

  const toggleExclude = (id: string) => {
    const excluded = config.excludedPlayerIds.includes(id)
      ? config.excludedPlayerIds.filter((x) => x !== id)
      : [...config.excludedPlayerIds, id];
    const locked = config.lockedPlayerIds.filter((x) => x !== id);
    onChangeConfig({ ...config, excludedPlayerIds: excluded, lockedPlayerIds: locked });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Constrained Integer Roster Builder</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            Rule set: {config.ruleSetName} · Exclusive bipartite slot assignment prevents multi-position double counting
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onRunOptimize()}
            disabled={optimizing}
            className="px-4 py-2 text-xs font-medium rounded bg-[#B91C1C] text-white hover:bg-[#991B1B] disabled:opacity-50 flex items-center gap-1.5 whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5" />
            {optimizing ? 'Solving...' : 'Solve Optimal Roster'}
          </button>
          <button
            onClick={() => onSendToSimulator(result.selectedRoster.map((r) => r.player.playerId))}
            className="px-3.5 py-2 text-xs font-medium rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B] whitespace-nowrap"
          >
            Verify in Monte Carlo
          </button>
        </div>
      </div>

      {/* Constraints Controls */}
      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] grid grid-cols-2 md:grid-cols-6 gap-4 text-xs">
        <label className="space-y-1">
          <span className="font-medium">Budget Cap (£M)</span>
          <input
            type="number"
            min={30}
            max={120}
            step={1}
            value={config.budgetCapM}
            onChange={(e) => onChangeConfig({ ...config, budgetCapM: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <label className="space-y-1">
          <span className="font-medium">Roster Size</span>
          <input
            type="number"
            min={21}
            max={28}
            value={config.rosterSize}
            onChange={(e) => onChangeConfig({ ...config, rosterSize: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <label className="space-y-1">
          <span className="font-medium">Max Acquisitions</span>
          <input
            type="number"
            min={0}
            max={15}
            value={config.maxNewAcquisitions}
            onChange={(e) => onChangeConfig({ ...config, maxNewAcquisitions: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <label className="space-y-1">
          <span className="font-medium">Min SP / RP</span>
          <div className="flex gap-1.5">
            <input
              type="number"
              min={3}
              max={6}
              value={config.requiredSP}
              onChange={(e) => onChangeConfig({ ...config, requiredSP: Number(e.target.value) })}
              className="w-1/2 px-2 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
            />
            <input
              type="number"
              min={3}
              max={8}
              value={config.requiredRP}
              onChange={(e) => onChangeConfig({ ...config, requiredRP: Number(e.target.value) })}
              className="w-1/2 px-2 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
            />
          </div>
        </label>
        <label className="space-y-1">
          <span className="font-medium">Objective</span>
          <select
            value={config.objective}
            onChange={(e) => onChangeConfig({ ...config, objective: e.target.value as any })}
            className="w-full px-2 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
          >
            <option value="max_mwar">Maximise Expected mWAR</option>
            <option value="risk_adjusted">Risk-Adjusted (E[mWAR] − λ·SD)</option>
            <option value="min_cost_target">Minimise Cost for Target mWAR</option>
          </select>
        </label>
        <label className="space-y-1">
          <span className="font-medium">
            {config.objective === 'min_cost_target' ? 'Target mWAR' : 'Risk Aversion λ'}
          </span>
          {config.objective === 'min_cost_target' ? (
            <input
              type="number"
              min={10}
              max={45}
              step={1}
              value={config.targetMWAR}
              onChange={(e) => onChangeConfig({ ...config, targetMWAR: Number(e.target.value) })}
              className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
            />
          ) : (
            <input
              type="number"
              min={0}
              max={2}
              step={0.1}
              value={config.riskAversionLambda}
              onChange={(e) => onChangeConfig({ ...config, riskAversionLambda: Number(e.target.value) })}
              className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
            />
          )}
        </label>
      </div>

      {/* Status & Unmet Constraints Banner */}
      <div
        className={`p-4 rounded border text-xs ${
          result.feasible
            ? 'border-[#16A34A]/40 bg-[#16A34A]/[0.06] dark:bg-[#16A34A]/10'
            : 'border-[#DC2626]/50 bg-[#DC2626]/[0.06] dark:bg-[#DC2626]/10'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-2 font-semibold">
          <span>{result.statusMessage}</span>
          <span className="font-mono">
            Cost £{result.totalEffectiveCostM.toFixed(2)}M (Salary £{result.totalSalaryM.toFixed(2)}M + Trade £{result.totalTradeCostM.toFixed(2)}M) · Expected {result.totalExpectedMWAR.toFixed(2)} mWAR (±{result.portfolioSDMWAR.toFixed(2)})
          </span>
        </div>
        {result.unmetConstraints.length > 0 && (
          <ul className="mt-2 list-disc list-inside text-[#B91C1C] dark:text-[#FCA5A5] space-y-0.5">
            {result.unmetConstraints.map((u, i) => (
              <li key={i}>{u}</li>
            ))}
          </ul>
        )}
        <div className="mt-2 text-[11px] text-[#64748B] dark:text-[#94A3B8]">
          {result.approximationWarning}
        </div>
      </div>

      {/* Alternative Solutions Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {result.alternatives.map((alt) => (
          <div
            key={alt.label}
            className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] flex flex-col justify-between gap-2 text-xs"
          >
            <div>
              <div className="font-semibold">{alt.label}</div>
              <div className="font-mono text-sm font-bold mt-1">
                £{alt.totalEffectiveCostM.toFixed(2)}M · {alt.totalExpectedMWAR.toFixed(2)} mWAR (SD ±{alt.portfolioSDMWAR.toFixed(2)})
              </div>
              <p className="text-[#64748B] dark:text-[#94A3B8] mt-1">{alt.keyDifference}</p>
            </div>
            <button
              onClick={() => onSendToSimulator(alt.playerIds)}
              className="self-start text-xs font-medium text-[#B91C1C] dark:text-[#F87171] hover:underline"
            >
              Simulate Alternative
            </button>
          </div>
        ))}
      </div>

      {/* Chosen Roster Table */}
      <div className="rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
              <th className="py-2.5 px-3 text-left font-medium">Assigned Slot</th>
              <th className="py-2 px-2 text-left font-medium">Player</th>
              <th className="py-2 px-2 text-left font-medium">Eligible</th>
              <th className="py-2 px-2 text-left font-medium">Origin / Status</th>
              <th className="py-2 px-2 text-right font-medium">Eff. Cost</th>
              <th className="py-2 px-2 text-right font-medium">Proj mWAR</th>
              <th className="py-2 px-2 text-right font-medium">80% Interval</th>
              <th className="py-2.5 px-3 text-right font-medium">Controls</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
            {result.selectedRoster.map((r) => {
              const isLocked = config.lockedPlayerIds.includes(r.player.playerId);
              return (
                <tr key={r.player.playerId} className="hover:bg-[#F8F6F1] dark:hover:bg-[#16233B]">
                  <td className="py-2 px-3 font-mono font-semibold text-[#B91C1C] dark:text-[#F87171]">
                    {r.assignedSlot}
                  </td>
                  <td
                    className="py-2 px-2 font-medium cursor-pointer hover:underline"
                    onClick={() => onSelectPlayer(r.player.playerId)}
                  >
                    {r.player.fullName}
                  </td>
                  <td className="py-2 px-2 font-mono">{r.player.eligiblePositions.join('/')}</td>
                  <td className="py-2 px-2 text-[#475569] dark:text-[#CBD5E1]">
                    {r.isNewAcquisition ? `New (${r.player.availability})` : `Retained (${config.teamId})`}
                  </td>
                  <td className="py-2 px-2 text-right font-mono">£{r.effectiveCostM.toFixed(2)}M</td>
                  <td className="py-2 px-2 text-right font-mono font-semibold">{r.projection.mWARMean.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right font-mono text-[#64748B]">
                    [{r.projection.mWARLow80.toFixed(1)}, {r.projection.mWARHigh80.toFixed(1)}]
                  </td>
                  <td className="py-2 px-3 text-right space-x-2 whitespace-nowrap">
                    <button
                      onClick={() => toggleLock(r.player.playerId)}
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[11px] ${
                        isLocked
                          ? 'border-[#0B1320] bg-[#0B1320] text-white dark:border-white dark:bg-white dark:text-[#0B1320]'
                          : 'border-[#E2DFD7] dark:border-[#334155]'
                      }`}
                    >
                      {isLocked ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
                      {isLocked ? 'Locked' : 'Lock'}
                    </button>
                    <button
                      onClick={() => toggleExclude(r.player.playerId)}
                      className="px-2 py-0.5 rounded border border-[#E2DFD7] dark:border-[#334155] text-[11px] hover:border-[#DC2626] hover:text-[#DC2626]"
                    >
                      Exclude
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {config.excludedPlayerIds.length > 0 && (
        <div className="flex items-center gap-2 text-xs text-[#64748B]">
          <span>Excluded IDs: {config.excludedPlayerIds.join(', ')}</span>
          <button
            onClick={() => onChangeConfig({ ...config, excludedPlayerIds: [] })}
            className="underline text-[#B91C1C]"
          >
            Clear Exclusions
          </button>
        </div>
      )}
    </div>
  );
}

export function SimulationsView({
  store,
  projections,
  simConfig,
  simSummary,
  baselineSummary,
  simulating,
  onChangeSimConfig,
  onRunSimulation,
  onSaveAsBaseline,
}: {
  store: DatasetStore;
  projections: Map<string, BayesianProjection>;
  simConfig: SimulationConfig;
  simSummary: SimulationSummary | null;
  baselineSummary: SimulationSummary | null;
  simulating: boolean;
  onChangeSimConfig: (next: SimulationConfig) => void;
  onRunSimulation: (override?: SimulationConfig) => Promise<void>;
  onSaveAsBaseline: () => void;
}) {
  const playerMap = new Map(store.players.map((p) => [p.playerId, p]));

  const toggleUnavailable = (id: string) => {
    const next = simConfig.unavailablePlayerIds.includes(id)
      ? simConfig.unavailablePlayerIds.filter((x) => x !== id)
      : [...simConfig.unavailablePlayerIds, id];
    onChangeSimConfig({ ...simConfig, unavailablePlayerIds: next });
  };

  const moveLineupSpot = (idx: number, dir: -1 | 1) => {
    const arr = [...simConfig.lineupOrderIds];
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= arr.length) return;
    [arr[idx], arr[swapIdx]] = [arr[swapIdx], arr[idx]];
    onChangeSimConfig({ ...simConfig, lineupOrderIds: arr });
  };

  const deltaWins =
    simSummary && baselineSummary
      ? simSummary.expectedWins - baselineSummary.expectedWins
      : null;
  const combinedSE =
    simSummary && baselineSummary
      ? Math.sqrt(simSummary.mcStandardError ** 2 + baselineSummary.mcStandardError ** 2)
      : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Monte Carlo Season Simulator & Lineup Engine</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            24-state base-out Markov game engine · Separates posterior parameter uncertainty from game-level stochasticity
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onSaveAsBaseline}
            disabled={!simSummary}
            className="px-3 py-2 text-xs font-medium rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B] whitespace-nowrap"
          >
            Pin Current as Baseline A
          </button>
          <button
            onClick={() => onRunSimulation()}
            disabled={simulating}
            className="px-4 py-2 text-xs font-medium rounded bg-[#B91C1C] text-white hover:bg-[#991B1B] disabled:opacity-50 flex items-center gap-1.5 whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5" />
            {simulating ? 'Simulating...' : `Run ${simConfig.numSimulations} Seasons`}
          </button>
        </div>
      </div>

      {/* Simulation Controls */}
      <div className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] grid grid-cols-2 md:grid-cols-6 gap-4 text-xs">
        <label className="space-y-1">
          <span className="font-medium">Simulations (N)</span>
          <input
            type="number"
            min={50}
            max={2000}
            step={50}
            value={simConfig.numSimulations}
            onChange={(e) => onChangeSimConfig({ ...simConfig, numSimulations: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <label className="space-y-1">
          <span className="font-medium">Win Target</span>
          <input
            type="number"
            min={50}
            max={105}
            value={simConfig.winTarget}
            onChange={(e) => onChangeSimConfig({ ...simConfig, winTarget: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <label className="space-y-1">
          <span className="font-medium">Split Assumption</span>
          <select
            value={simConfig.splitScenario}
            onChange={(e) => onChangeSimConfig({ ...simConfig, splitScenario: e.target.value as any })}
            className="w-full px-2 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]"
          >
            <option value="Neutral">Neutral League Mix</option>
            <option value="vsRHP">vs RHP Heavy</option>
            <option value="vsLHP">vs LHP Heavy</option>
          </select>
        </label>
        <label className="space-y-1">
          <span className="font-medium">RNG Seed</span>
          <input
            type="number"
            value={simConfig.seed}
            onChange={(e) => onChangeSimConfig({ ...simConfig, seed: Number(e.target.value) })}
            className="w-full px-2.5 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono"
          />
        </label>
        <div className="flex flex-col justify-center gap-1.5 col-span-2">
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={simConfig.includeParameterUncertainty}
              onChange={(e) => onChangeSimConfig({ ...simConfig, includeParameterUncertainty: e.target.checked })}
              className="accent-[#B91C1C]"
            />
            Include posterior talent uncertainty (outer loop)
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={simConfig.useCommonRandomNumbers}
              onChange={(e) => onChangeSimConfig({ ...simConfig, useCommonRandomNumbers: e.target.checked })}
              className="accent-[#B91C1C]"
            />
            Common Random Numbers (CRN) &amp; Extra-Inn 2B runner
          </label>
        </div>
      </div>

      {/* Results & Comparison */}
      {simSummary && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-bold tracking-tight">Simulated 140-Game Win Distribution</h2>
                <div className="text-xs text-[#64748B] dark:text-[#94A3B8] font-mono">
                  N={simSummary.config.numSimulations} · Mean {simSummary.expectedWins.toFixed(2)}W (±{simSummary.mcStandardError.toFixed(3)} MC SE) · SD {simSummary.sdWins.toFixed(2)}W
                </div>
              </div>
              {deltaWins !== null && combinedSE !== null && (
                <div className="text-xs font-mono px-3 py-1.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320]">
                  vs Baseline A: {deltaWins >= 0 ? '+' : ''}{deltaWins.toFixed(2)}W{' '}
                  {Math.abs(deltaWins) < 2 * combinedSE ? '(within 2× MC SE noise)' : '(statistically separated)'}
                </div>
              )}
            </div>

            <WinHistogramChart
              bins={simSummary.winHistogram}
              expectedWins={simSummary.expectedWins}
              p10={simSummary.p10Wins}
              p90={simSummary.p90Wins}
              winTarget={simSummary.config.winTarget}
              compareBins={baselineSummary?.winHistogram}
            />

            <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 pt-2 border-t border-[#E2DFD7] dark:border-[#1E293B] text-xs font-mono">
              <div><span className="text-[#64748B] font-sans block">P10 / P90</span>{simSummary.p10Wins} – {simSummary.p90Wins}W</div>
              <div><span className="text-[#64748B] font-sans block">Median (P50)</span>{simSummary.p50Wins}W</div>
              <div><span className="text-[#64748B] font-sans block">Runs Scored</span>{simSummary.expectedRunsScored}</div>
              <div><span className="text-[#64748B] font-sans block">Runs Allowed</span>{simSummary.expectedRunsAllowed}</div>
              <div><span className="text-[#64748B] font-sans block">P(≥{simSummary.config.winTarget}W)</span>{(simSummary.probExceedTarget * 100).toFixed(1)}%</div>
              <div><span className="text-[#64748B] font-sans block">Playoff Prob</span>{(simSummary.playoffProbability * 100).toFixed(1)}%</div>
            </div>

            <ul className="text-[11px] text-[#64748B] dark:text-[#94A3B8] space-y-0.5 list-disc list-inside pt-2">
              {simSummary.assumptionsDocumented.map((a, i) => (
                <li key={i}>{a}</li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4 p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
            <h2 className="text-xl font-bold tracking-tight">24-State Run Expectancy</h2>
            <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
              Expected runs to end of inning derived directly from the base-out transition engine.
            </p>
            <BaseOutMatrixGrid matrix={simSummary.baseOutRunExpectancy24} />
          </div>
        </div>
      )}

      {/* Lineup Order & Injury / Lost Playing Time Sensitivity Tester */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Lineup Order Proposal (1–9)</h2>
              <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
                Reorder batters and re-simulate; small differences within MC SE are flagged transparently
              </p>
            </div>
          </div>
          <div className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60 text-xs">
            {simConfig.lineupOrderIds.slice(0, 9).map((id, idx) => {
              const p = playerMap.get(id);
              const pr = projections.get(id);
              if (!p || !pr) return null;
              const isOut = simConfig.unavailablePlayerIds.includes(id);
              return (
                <div key={id} className="py-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono font-bold text-[#B91C1C] w-4">{idx + 1}.</span>
                    <div>
                      <span className={`font-medium ${isOut ? 'line-through text-[#94A3B8]' : ''}`}>{p.fullName}</span>
                      <span className="text-[11px] font-mono text-[#64748B] ml-2">
                        {p.primaryPos} · {p.bats} · OBP {pr.projOBP.toFixed(3)} · SLG {pr.projSLG.toFixed(3)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => moveLineupSpot(idx, -1)}
                      disabled={idx === 0}
                      className="px-1.5 py-0.5 rounded border border-[#E2DFD7] dark:border-[#334155] disabled:opacity-30"
                    >
                      ↑
                    </button>
                    <button
                      onClick={() => moveLineupSpot(idx, 1)}
                      disabled={idx === simConfig.lineupOrderIds.slice(0, 9).length - 1}
                      className="px-1.5 py-0.5 rounded border border-[#E2DFD7] dark:border-[#334155] disabled:opacity-30"
                    >
                      ↓
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Key-Player Loss & Availability Stress Test</h2>
              <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
                Simulate losing a core contributor (e.g. Henrik Solberg or Kieran Vance); lost IP/PA backfilled at replacement level
              </p>
            </div>
            {simConfig.unavailablePlayerIds.length > 0 && (
              <button
                onClick={() => onChangeSimConfig({ ...simConfig, unavailablePlayerIds: [] })}
                className="text-xs text-[#B91C1C] hover:underline flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" /> Restore All
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs max-h-72 overflow-y-auto pr-1">
            {simConfig.rosterPlayerIds.map((id) => {
              const p = playerMap.get(id);
              const pr = projections.get(id);
              if (!p || !pr) return null;
              const isOut = simConfig.unavailablePlayerIds.includes(id);
              return (
                <button
                  key={id}
                  onClick={() => toggleUnavailable(id)}
                  className={`p-2 rounded border text-left transition-colors ${
                    isOut
                      ? 'border-[#DC2626] bg-[#DC2626]/10 text-[#B91C1C] dark:text-[#FCA5A5]'
                      : 'border-[#E2DFD7] dark:border-[#1E293B] hover:bg-[#F8F6F1] dark:hover:bg-[#16233B]'
                  }`}
                >
                  <div className="flex justify-between font-medium">
                    <span>{p.fullName}</span>
                    <span className="font-mono">{pr.mWARMean.toFixed(1)}</span>
                  </div>
                  <div className="text-[11px] text-[#64748B]">
                    {p.primaryPos} · {isOut ? 'Marked Unavailable (Stress Test)' : 'Active'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export function ReportsView({
  store,
  teamId,
  valuations,
  optimizerResult,
  simulationSummary,
  rProjectFiles,
}: {
  store: DatasetStore;
  teamId: string;
  valuations: PlayerValuationRow[];
  optimizerResult: OptimizerResult;
  simulationSummary: SimulationSummary | null;
  rProjectFiles: { path: string; content: string; category: string }[];
}) {
  const team = store.teams.find((t) => t.teamId === teamId) ?? store.teams[0];
  const newAcqs = optimizerResult.selectedRoster.filter((r) => r.isNewAcquisition);
  const qmdTemplate = rProjectFiles.find((f) => f.path.endsWith('.qmd'))?.content ?? '';

  const buildMarkdownBriefing = () => {
    const lines = [
      `# AUREOM MONEYBALL — Management Roster & Simulation Briefing`,
      `**Club:** ${team.name} (${team.teamId}) | **Target Season:** 2026 | **Model:** ${store.modelVersion}`,
      `**Data Source:** ${store.provenances[0]?.sourceName} (${store.provenances[0]?.license})`,
      ``,
      `## Executive Conclusion`,
      `Under a £${team.budgetCapM.toFixed(1)}M budget cap, the constrained integer solver selected a ${optimizerResult.selectedRoster.length}-man roster spending **£${optimizerResult.totalEffectiveCostM.toFixed(2)}M** (£${optimizerResult.budgetRemainingM.toFixed(2)}M remaining), producing **${optimizerResult.totalExpectedMWAR.toFixed(2)} projected mWAR** (portfolio SD ±${optimizerResult.portfolioSDMWAR.toFixed(2)}).`,
      simulationSummary
        ? `Across ${simulationSummary.config.numSimulations} Monte Carlo 140-game seasons, expected performance is **${simulationSummary.expectedWins.toFixed(1)} wins** (80% uncertainty interval: ${simulationSummary.p10Wins}–${simulationSummary.p90Wins} wins, MC SE ±${simulationSummary.mcStandardError.toFixed(2)}).`
        : '',
      ``,
      `## Recommended Acquisitions`,
      ...newAcqs.map(
        (r) =>
          `- **${r.player.fullName}** (${r.assignedSlot} · ${r.player.availability}): Effective cost £${r.effectiveCostM.toFixed(2)}M, Projected ${r.projection.mWARMean.toFixed(2)} mWAR (80% CI: ${r.projection.mWARLow80.toFixed(1)} to ${r.projection.mWARHigh80.toFixed(1)}).`
      ),
      ``,
      `## Top 5 Market Inefficiency Candidates`,
      ...valuations
        .filter((v) => v.player.currentTeamId !== teamId && v.acquirableForTeam)
        .slice(0, 5)
        .map(
          (v) =>
            `- **${v.player.fullName}** (${v.player.primaryPos}): Surplus +£${v.surplusValueM.toFixed(2)}M — ${v.inefficiencyReasons.join('; ') || v.player.healthRiskNote}`
        ),
      ``,
      `## Assumptions & Limitations`,
      `- Modelled Wins Above Replacement (mWAR) is an internal linear-weights/FIP composite at 10.0 runs/win, distinct from FanGraphs fWAR or Baseball-Reference bWAR.`,
      `- Bayesian 80% and 95% credible intervals quantify posterior parameter & playing-time uncertainty and are NOT performance guarantees.`,
    ];
    return lines.join('\n');
  };

  const downloadFile = (filename: string, content: string, mime = 'text/markdown') => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Management Reports & Quarto Export</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            Export reproducible executive briefings grounded in verified optimizer and simulation outputs
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => downloadFile(`${team.teamId}_2026_management_briefing.md`, buildMarkdownBriefing())}
            className="px-3.5 py-2 text-xs font-medium rounded bg-[#B91C1C] text-white hover:bg-[#991B1B] flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export Briefing (.md)
          </button>
          {qmdTemplate && (
            <button
              onClick={() => downloadFile('management_report.qmd', qmdTemplate, 'text/plain')}
              className="px-3.5 py-2 text-xs font-medium rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B] flex items-center gap-1.5 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download Quarto (.qmd)
            </button>
          )}
        </div>
      </div>

      <div className="p-6 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-4">
        <div className="border-b border-[#E2DFD7] dark:border-[#1E293B] pb-3">
          <div className="text-xs font-mono text-[#64748B]">EXECUTIVE FRONT-OFFICE BRIEFING · {store.modelVersion}</div>
          <h2 className="text-2xl font-bold mt-1">{team.name} — 2026 Roster & Uncertainty Analysis</h2>
        </div>

        <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-[#0F172A] dark:text-[#E2E8F0]">
          {buildMarkdownBriefing()}
        </pre>
      </div>
    </div>
  );
}

export function DataModelsView({
  store,
  projections,
  backtest,
  rProjectFiles,
  onRunBacktest,
  onResetDataset,
}: {
  store: DatasetStore;
  projections: Map<string, BayesianProjection>;
  backtest: BacktestMetrics | null;
  rProjectFiles: { path: string; content: string; category: string }[];
  onRunBacktest: (originSeason: number) => Promise<void>;
  onResetDataset: () => Promise<void>;
}) {
  const [selectedRFile, setSelectedRFile] = useState(rProjectFiles[0]?.path ?? 'README.md');
  const activeFile = rProjectFiles.find((f) => f.path === selectedRFile) ?? rProjectFiles[0];

  const sampleProj = Array.from(projections.values()).slice(0, 14);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Data Provenance, Backtesting & R Source</h1>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            Model {store.modelVersion} · Last refreshed {new Date(store.lastRefreshedAt).toLocaleString()} · Reproducible R + targets + DuckDB codebase
          </p>
        </div>
        <button
          onClick={onResetDataset}
          className="px-3 py-1.5 text-xs font-medium rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B] flex items-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Synthetic Store
        </button>
      </div>

      {/* Data Provenance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {store.provenances.map((prov) => (
          <div key={prov.sourceId} className="p-4 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] text-xs space-y-1">
            <div className="font-semibold">{prov.sourceName}</div>
            <div className="font-mono text-[11px] text-[#64748B]">
              {prov.sourceId} · Granularity: {prov.granularity} · {prov.license}
            </div>
            <p className="text-[#475569] dark:text-[#CBD5E1] pt-1">{prov.notes}</p>
          </div>
        ))}
      </div>

      {/* Rolling-Origin Backtest */}
      <div className="p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold tracking-tight">Rolling-Origin Leakage-Free Backtest</h2>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Evaluates out-of-sample rate accuracy, playing-time error, and 80% credible interval calibration
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onRunBacktest(2023)}
              className="px-3 py-1.5 text-xs rounded border border-[#E2DFD7] dark:border-[#334155] hover:bg-[#F8F6F1] dark:hover:bg-[#1E293B]"
            >
              Run 2023 → 2024
            </button>
            <button
              onClick={() => onRunBacktest(2024)}
              className="px-3 py-1.5 text-xs rounded bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]"
            >
              Run 2024 → 2025
            </button>
          </div>
        </div>

        {backtest && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs font-mono">
              <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B]">
                <span className="font-sans text-[#64748B] block">Bayes OBP MAE</span>
                <span className="text-base font-bold">{backtest.bayesianOBP_MAE.toFixed(4)}</span>
                <span className="font-sans text-[11px] text-[#64748B] block">Naive: {backtest.naiveOBP_MAE.toFixed(4)}</span>
              </div>
              <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B]">
                <span className="font-sans text-[#64748B] block">League-Mean MAE</span>
                <span className="text-base font-bold">{backtest.leagueMeanOBP_MAE.toFixed(4)}</span>
                <span className="font-sans text-[11px] text-[#64748B] block">RMSE: {backtest.bayesianOBP_RMSE.toFixed(4)}</span>
              </div>
              <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B]">
                <span className="font-sans text-[#64748B] block">Bayes FIP MAE</span>
                <span className="text-base font-bold">{backtest.bayesianFIP_MAE.toFixed(3)}</span>
                <span className="font-sans text-[11px] text-[#64748B] block">Naive: {backtest.naiveFIP_MAE.toFixed(3)}</span>
              </div>
              <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B]">
                <span className="font-sans text-[#64748B] block">Playing Time PA MAE</span>
                <span className="text-base font-bold">{backtest.pa_MAE.toFixed(1)} PA</span>
                <span className="font-sans text-[11px] text-[#64748B] block">Cutoff: {backtest.trainCutoffDate}</span>
              </div>
              <div className="p-3 rounded bg-[#F8F6F1] dark:bg-[#0B1320] border border-[#E2DFD7] dark:border-[#1E293B]">
                <span className="font-sans text-[#64748B] block">80% CI Calibration</span>
                <span className="text-base font-bold">{(backtest.coverage80Pct_Batters * 100).toFixed(1)}%</span>
                <span className="font-sans text-[11px] text-[#64748B] block">Pitchers: {(backtest.coverage80Pct_Pitchers * 100).toFixed(1)}%</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              {backtest.leakageChecks.map((chk) => (
                <div key={chk.check} className="p-2.5 rounded border border-[#E2DFD7] dark:border-[#1E293B] flex justify-between gap-2">
                  <div>
                    <div className="font-semibold">{chk.check}</div>
                    <div className="text-[11px] text-[#64748B]">{chk.detail}</div>
                  </div>
                  <span className="font-mono font-semibold text-[#16A34A] shrink-0">
                    {chk.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Bayesian Prior / Posterior / PPC Table */}
      <div className="p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Bayesian Partial-Pooling & Posterior Predictive Checks</h2>
          <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
            Dirichlet-Multinomial (prior = 260 PA) &amp; Beta-Binomial (prior = 220 BF) · PPC p-values near 0.50 indicate well-calibrated replicates
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#E2DFD7] dark:border-[#1E293B] text-[#64748B] dark:text-[#94A3B8]">
                <th className="py-2 px-2 text-left font-sans">Player ID</th>
                <th className="py-2 px-2 text-right">Prior N</th>
                <th className="py-2 px-2 text-right">Obs Weighted N</th>
                <th className="py-2 px-2 text-right">Data Weight</th>
                <th className="py-2 px-2 text-right">Obs Latest</th>
                <th className="py-2 px-2 text-right">PPC Rep Mean</th>
                <th className="py-2 px-2 text-right">PPC p-val</th>
                <th className="py-2 px-2 text-right">Proj mWAR (95% CI)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2DFD7]/60 dark:divide-[#1E293B]/60">
              {sampleProj.map((pr) => (
                <tr key={pr.playerId}>
                  <td className="py-1.5 px-2">{pr.playerId}</td>
                  <td className="py-1.5 px-2 text-right">{pr.priorSampleSize}</td>
                  <td className="py-1.5 px-2 text-right">{pr.observedWeightedSampleSize}</td>
                  <td className="py-1.5 px-2 text-right">{(pr.shrinkageWeight * 100).toFixed(1)}%</td>
                  <td className="py-1.5 px-2 text-right">{pr.ppcObservedRate.toFixed(3)}</td>
                  <td className="py-1.5 px-2 text-right">{pr.ppcReplicateMean.toFixed(3)}</td>
                  <td className="py-1.5 px-2 text-right">{pr.ppcBayesianPValue.toFixed(2)}</td>
                  <td className="py-1.5 px-2 text-right">
                    {pr.mWARMean.toFixed(2)} [{pr.mWARLow95.toFixed(1)}, {pr.mWARHigh95.toFixed(1)}]
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* R Project Source Browser */}
      {rProjectFiles.length > 0 && (
        <div className="p-5 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-white dark:bg-[#111B2E] space-y-3">
          <div>
            <h2 className="text-xl font-bold tracking-tight">R Project Source & Reproducible Pipeline (`/r_project/`)</h2>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Complete R/Shiny/bslib/DuckDB/targets/renv/testthat/Quarto codebase packaged for local R execution
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-4 space-y-1 max-h-80 overflow-y-auto border border-[#E2DFD7] dark:border-[#1E293B] rounded p-2">
              {rProjectFiles.map((f) => (
                <button
                  key={f.path}
                  onClick={() => setSelectedRFile(f.path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex justify-between items-center ${
                    selectedRFile === f.path
                      ? 'bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]'
                      : 'hover:bg-[#F8F6F1] dark:hover:bg-[#16233B]'
                  }`}
                >
                  <span className="font-mono truncate">{f.path}</span>
                  <span className="text-[10px] opacity-75 shrink-0 ml-2">{f.category}</span>
                </button>
              ))}
            </div>
            <div className="lg:col-span-8">
              <pre className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#0B1320] font-mono text-[11px] overflow-auto max-h-80 leading-relaxed">
                {activeFile?.content}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
