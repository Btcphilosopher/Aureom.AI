import React, { useState } from 'react';
import { Send, X } from 'lucide-react';

interface AnalystMessage {
  role: 'user' | 'assistant';
  text: string;
  mode?: string;
  toolCallsUsed?: string[];
  citations?: string[];
}

const PRESET_PROMPTS = [
  'Summarize the Sheffield Steelheads £68M roster optimisation scenario.',
  'Compare Lukas Lindstrom and Victor Castellanos on OBP, uncertainty, and cost.',
  'Explain Mikkel Sorensen using his 2025 FIP vs ERA and 2026 projection.',
  'Explain how Modelled WAR (mWAR) is calculated and differs from fWAR.',
];

export function AnalystDrawer({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [mode, setMode] = useState<'auto' | 'mock'>('auto');
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<AnalystMessage[]>([
    {
      role: 'assistant',
      text: 'Front-Office Analyst ready. Ask about player comparisons, roster trade-offs, scouting follow-ups, or metric definitions. Every figure is retrieved via verified analytical tools and cited to application records—never invented in prose, and source data is never altered.',
      mode: 'system',
      citations: ['engine:deterministic-tools'],
    },
  ]);

  if (!open) return null;

  const sendPrompt = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || loading) return;
    setMessages((prev) => [...prev, { role: 'user', text: trimmed }]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/analyst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: trimmed, mode }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: data.reply ?? data.error ?? 'No reply generated.',
          mode: data.mode,
          toolCallsUsed: data.toolCallsUsed,
          citations: data.citations,
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: `Request failed: ${(err as Error).message}`,
          mode: 'error',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40">
      <div className="w-full max-w-xl bg-white dark:bg-[#0B1320] text-[#0F172A] dark:text-[#F1F5F9] h-full flex flex-col border-l border-[#E2DFD7] dark:border-[#1E293B]">
        <div className="p-4 border-b border-[#E2DFD7] dark:border-[#1E293B] flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold tracking-tight">Front-Office AI Analyst</h2>
            <div className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Tool-grounded · Read-only · Citations required
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-1 rounded bg-[#F8F6F1] dark:bg-[#111B2E] border border-[#E2DFD7] dark:border-[#1E293B]">
              <button
                onClick={() => setMode('auto')}
                className={`px-2.5 py-1 text-xs rounded font-medium ${
                  mode === 'auto'
                    ? 'bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]'
                    : 'text-[#475569] dark:text-[#94A3B8]'
                }`}
              >
                Auto API
              </button>
              <button
                onClick={() => setMode('mock')}
                className={`px-2.5 py-1 text-xs rounded font-medium ${
                  mode === 'mock'
                    ? 'bg-[#0B1320] text-white dark:bg-[#F1F5F9] dark:text-[#0B1320]'
                    : 'text-[#475569] dark:text-[#94A3B8]'
                }`}
              >
                Offline Mock
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded border border-[#E2DFD7] dark:border-[#1E293B] hover:bg-[#F8F6F1] dark:hover:bg-[#111B2E]"
              aria-label="Close AI analyst"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="px-4 py-2.5 border-b border-[#E2DFD7] dark:border-[#1E293B] flex flex-wrap gap-1.5">
          {PRESET_PROMPTS.map((q) => (
            <button
              key={q}
              onClick={() => sendPrompt(q)}
              className="text-left text-[11px] px-2.5 py-1 rounded border border-[#E2DFD7] dark:border-[#1E293B] hover:bg-[#F8F6F1] dark:hover:bg-[#111B2E] text-[#475569] dark:text-[#CBD5E1]"
            >
              {q}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded border text-xs leading-relaxed ${
                m.role === 'user'
                  ? 'bg-[#F8F6F1] dark:bg-[#111B2E] border-[#E2DFD7] dark:border-[#1E293B] ml-8'
                  : 'bg-white dark:bg-[#0F192B] border-[#E2DFD7] dark:border-[#1E293B] mr-4'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] text-[#64748B] dark:text-[#94A3B8] mb-1.5">
                <span className="font-semibold text-[#0F172A] dark:text-[#F1F5F9]">
                  {m.role === 'user' ? 'Front Office' : 'AUREOM Analyst'}
                </span>
                {m.mode && <span className="font-mono">{m.mode}</span>}
              </div>
              <div className="whitespace-pre-wrap">{m.text}</div>
              {(m.toolCallsUsed?.length || m.citations?.length) ? (
                <div className="mt-2 pt-2 border-t border-[#E2DFD7] dark:border-[#1E293B] text-[11px] font-mono text-[#64748B] dark:text-[#94A3B8]">
                  {m.toolCallsUsed?.length ? `Tools: ${m.toolCallsUsed.join(', ')} · ` : ''}
                  {m.citations?.length ? `Citations: ${m.citations.join(', ')}` : ''}
                </div>
              ) : null}
            </div>
          ))}
          {loading && (
            <div className="p-3 rounded border border-[#E2DFD7] dark:border-[#1E293B] text-xs text-[#64748B]">
              Calling analytical functions and verifying citations...
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendPrompt(input);
          }}
          className="p-3 border-t border-[#E2DFD7] dark:border-[#1E293B] flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for a verified comparison, scouting question, or briefing..."
            className="flex-1 px-3 py-2 text-xs rounded border border-[#E2DFD7] dark:border-[#1E293B] bg-[#F8F6F1] dark:bg-[#111B2E] focus:outline-none focus:border-[#B91C1C]"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-3.5 py-2 text-xs font-medium rounded bg-[#B91C1C] text-white hover:bg-[#991B1B] disabled:opacity-50 flex items-center gap-1.5 whitespace-nowrap"
          >
            <Send className="w-3.5 h-3.5" />
            Ask
          </button>
        </form>
      </div>
    </div>
  );
}
