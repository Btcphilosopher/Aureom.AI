library(testthat)
source("../../R/03_sabermetrics.R")
source("../../R/06_monte_carlo_sim.R")

test_that("Rate stats calculate from counts and guard zero denominators", {
  expect_true(is.na(safe_div(10, 0)))
  expect_equal(safe_div(120, 400), 0.300)
})

test_that("24-state base-out transitions handle bases-loaded walk and home run", {
  res_bb <- step_base_out(outs = 1L, bases = 7L, event = "BB_HBP")
  expect_equal(res_bb$runs, 1L)
  expect_equal(res_bb$bases, 7L)

  res_hr <- step_base_out(outs = 0L, bases = 5L, event = "HR")
  expect_equal(res_hr$runs, 3L)
  expect_equal(res_hr$bases, 0L)
})
