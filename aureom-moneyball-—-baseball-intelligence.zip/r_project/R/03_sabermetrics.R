library(data.table)

safe_div <- function(num, den) {
  ifelse(is.na(den) | den <= 0, NA_real_, num / den)
}

compute_batting_metrics <- function(batting_stints, fielding_records, seasons_dt, teams_dt) {
  dt <- copy(batting_stints)[split_vs_hand == "ALL"]
  # Deduplicate traded stints by (player_id, season, team_id, stint_order)
  dt <- unique(dt, by = c("player_id", "season", "team_id", "stint_order"))

  agg <- dt[, .(
    teams = paste(unique(team_id), collapse = "/"),
    stint_count = .N,
    g = sum(g), pa = sum(pa), ab = sum(ab), h = sum(h),
    doubles = sum(doubles), triples = sum(triples), hr = sum(hr),
    bb = sum(bb), ibb = sum(ibb), hbp = sum(hbp), so = sum(so),
    sf = sum(sf), sh = sum(sh), sb = sum(sb), cs = sum(cs), gdp = sum(gdp)
  ), by = .(player_id, season)]

  agg <- merge(agg, seasons_dt, by = "season", all.x = TRUE)
  agg[, singles := pmax(0L, h - doubles - triples - hr)]
  agg[, tb := singles + 2L * doubles + 3L * triples + 4L * hr]

  # Count-based rate calculations (never averaged across stints)
  agg[, ba := safe_div(h, ab)]
  agg[, obp := safe_div(h + bb + hbp, ab + bb + hbp + sf)]
  agg[, slg := safe_div(tb, ab)]
  agg[, ops := obp + slg]
  agg[, iso := slg - ba]
  agg[, bb_pct := safe_div(bb, pa)]
  agg[, k_pct := safe_div(so, pa)]
  agg[, babip := safe_div(h - hr, ab - so - hr + sf)]

  agg[, ubb := pmax(0L, bb - ibb)]
  agg[, woba := safe_div(
    w_bb * ubb + w_hbp * hbp + w_1b * singles + w_2b * doubles + w_3b * triples + w_hr * hr,
    ab + ubb + sf + hbp
  )]
  agg[, wraa := ifelse(is.na(woba), 0, ((woba - lg_woba) / woba_scale) * pa)]
  agg[, wrc_plus := ifelse(is.na(woba), NA_real_, ((wraa / pmax(1, pa) + r_per_pa) / r_per_pa) * 100)]

  # Merge fielding runs (range + arm + framing, NOT errors alone)
  fld <- fielding_records[, .(fielding_runs = sum(range_runs_est + arm_runs_est + framing_runs_est, na.rm = TRUE)),
                          by = .(player_id, season)]
  agg <- merge(agg, fld, by = c("player_id", "season"), all.x = TRUE)
  agg[is.na(fielding_runs), fielding_runs := 0]
  agg[, baserunning_runs := sb * 0.20 - cs * 0.42 - gdp * 0.08]
  agg[, replacement_runs := (pa / 600) * 20.0]
  agg[, modelled_war := (wraa + baserunning_runs + fielding_runs + replacement_runs) / runs_per_win]
  agg[]
}

compute_pitching_metrics <- function(pitching_stints, seasons_dt, teams_dt) {
  dt <- unique(copy(pitching_stints), by = c("player_id", "season", "team_id", "stint_order"))
  agg <- dt[, .(
    teams = paste(unique(team_id), collapse = "/"),
    g = sum(g), gs = sum(gs), outs_recorded = sum(outs_recorded),
    bf = sum(bf), h = sum(h), er = sum(er), hr = sum(hr),
    bb = sum(bb), hbp = sum(hbp), so = sum(so)
  ), by = .(player_id, season)]

  agg <- merge(agg, seasons_dt, by = "season", all.x = TRUE)
  agg[, ip := outs_recorded / 3.0]
  agg[, era := safe_div(9 * er, ip)]
  agg[, whip := safe_div(bb + h, ip)]
  agg[, k_pct := safe_div(so, bf)]
  agg[, bb_pct := safe_div(bb, bf)]
  agg[, hr_per_9 := safe_div(9 * hr, ip)]
  agg[, fip := safe_div(13 * hr + 3 * (bb + hbp) - 2 * so, ip) + c_fip]
  agg[, pitching_runs_fip := ifelse(is.na(fip), 0, ((lg_fip - fip) / 9) * ip)]
  agg[, replacement_runs := (ip / 200) * 18.0]
  agg[, modelled_war := (pitching_runs_fip + replacement_runs) / runs_per_win]
  agg[]
}
