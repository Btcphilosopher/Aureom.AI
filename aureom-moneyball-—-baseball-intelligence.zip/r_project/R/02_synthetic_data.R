library(data.table)
library(DBI)
library(duckdb)

seed_aibl_duckdb <- function(db_path = "data/aureom_moneyball.duckdb") {
  dir.create(dirname(db_path), showWarnings = FALSE, recursive = TRUE)
  con <- DBI::dbConnect(duckdb::duckdb(), dbdir = db_path)
  on.exit(DBI::dbDisconnect(con, shutdown = TRUE), add = TRUE)

  init_aureom_schema(con)

  teams_dt <- data.table(
    team_id = c("SHF", "LDN", "MCR", "BRS", "EDN", "LDS", "CDF", "BMH"),
    name = c("Sheffield Steelheads", "London Monarchs", "Manchester Ironworks", "Bristol Harbormen",
             "Edinburgh Thistles", "Leeds Millers", "Cardiff Dragons", "Birmingham Foundries"),
    division = c("North", "South", "North", "South", "North", "North", "South", "South"),
    stadium = c("Don Valley Foundry Park", "Thames Oval", "Ship Canal Field", "Avon Basin Stadium",
                "Firth Winds Park", "Aire Valley Yard", "Severn Bay Grounds", "Midlands Diamond"),
    park_factor_runs = c(98, 103, 101, 95, 94, 105, 100, 104),
    park_factor_hr = c(96, 106, 102, 91, 90, 108, 99, 105),
    budget_cap_m = c(68.0, 92.0, 76.0, 62.0, 60.0, 64.0, 66.0, 72.0)
  )

  seasons_dt <- data.table(
    season = c(2023L, 2024L, 2025L, 2026L),
    competition = c("AIBL Regular Season", "AIBL Regular Season", "AIBL Regular Season", "AIBL Regular Season (Projected)"),
    games_per_team = 140L,
    playoff_spots = 4L,
    w_bb = c(0.690, 0.692, 0.695, 0.695),
    w_hbp = c(0.720, 0.722, 0.725, 0.725),
    w_1b = c(0.885, 0.888, 0.890, 0.890),
    w_2b = c(1.260, 1.265, 1.270, 1.270),
    w_3b = c(1.600, 1.605, 1.610, 1.610),
    w_hr = c(2.060, 2.070, 2.080, 2.080),
    lg_woba = c(0.316, 0.318, 0.320, 0.320),
    woba_scale = c(1.220, 1.210, 1.200, 1.200),
    r_per_pa = c(0.118, 0.120, 0.122, 0.122),
    lg_fip = c(4.18, 4.22, 4.25, 4.25),
    c_fip = c(3.14, 3.16, 3.18, 3.18),
    runs_per_win = c(9.8, 9.9, 10.0, 10.0)
  )

  DBI::dbWriteTable(con, "teams", teams_dt, overwrite = TRUE)
  DBI::dbWriteTable(con, "seasons", seasons_dt, overwrite = TRUE)
  list(seeded_at = Sys.time(), db_path = db_path)
}

load_tables_from_duckdb <- function(db_path, seed_info = NULL) {
  con <- DBI::dbConnect(duckdb::duckdb(), dbdir = db_path, read_only = TRUE)
  on.exit(DBI::dbDisconnect(con, shutdown = TRUE), add = TRUE)
  list(
    teams = as.data.table(DBI::dbReadTable(con, "teams")),
    seasons = as.data.table(DBI::dbReadTable(con, "seasons")),
    players = as.data.table(DBI::dbReadTable(con, "players")),
    batting_stints = as.data.table(DBI::dbReadTable(con, "batting_stints")),
    pitching_stints = as.data.table(DBI::dbReadTable(con, "pitching_stints")),
    fielding_records = as.data.table(DBI::dbReadTable(con, "fielding_records")),
    transactions = as.data.table(DBI::dbReadTable(con, "transactions")),
    scouting_reports = as.data.table(DBI::dbReadTable(con, "scouting_reports"))
  )
}
