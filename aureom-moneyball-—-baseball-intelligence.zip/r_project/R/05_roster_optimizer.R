library(data.table)
library(ompr)
library(ompr.roi)
library(ROI.plugin.glpk)

# Mixed-Integer Linear Programming roster builder using ompr + GLPK.
# Explicitly prevents any multi-position player from filling multiple starting slots:
# decision variable y[i, s] = 1 iff player i is assigned to starting slot s,
# with sum_s y[i, s] <= x[i] enforcing exclusive single-slot assignment.
optimize_roster_milp <- function(players_dt, projections_dt, team_id = "SHF",
                                 budget_cap_m = 68.0, roster_size = 23L,
                                 max_new_acq = 5L, risk_lambda = 0.0,
                                 locked_ids = character(0), excluded_ids = character(0)) {
  cand <- merge(players_dt, projections_dt, by = "player_id")
  cand <- cand[
    !(player_id %in% excluded_ids) &
    (current_team_id == team_id | availability %in% c("Free Agent", "Trade Target") | player_id %in% locked_ids)
  ]
  cand[, effective_cost := fifelse(current_team_id == team_id, salary_m, salary_m + trade_cost_m / pmax(1L, years_control))]
  cand[, is_new := as.integer(current_team_id != team_id)]
  cand[, obj_weight := mwar_mean - risk_lambda * mwar_sd]

  n <- nrow(cand)
  slots <- c("C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "DH")
  S <- length(slots)

  elig_mat <- matrix(0L, nrow = n, ncol = S)
  for (i in seq_len(n)) {
    if (!cand$is_pitcher[i]) {
      pos_vec <- strsplit(cand$eligible_positions[i], ",")[[1]]
      for (s in seq_len(S)) {
        if (slots[s] == "DH" || slots[s] %in% pos_vec) elig_mat[i, s] <- 1L
      }
    }
  }

  is_sp <- as.integer(cand$pitching_role == "SP")
  is_rp <- as.integer(cand$is_pitcher & cand$pitching_role != "SP")
  is_bat <- as.integer(!cand$is_pitcher)

  model <- MILPModel() |>
    add_variable(x[i], i = 1:n, type = "binary") |>
    add_variable(y[i, s], i = 1:n, s = 1:S, type = "binary") |>
    set_objective(sum_expr(cand$obj_weight[i] * x[i], i = 1:n), "max") |>
    add_constraint(sum_expr(x[i], i = 1:n) == roster_size) |>
    add_constraint(sum_expr(cand$effective_cost[i] * x[i], i = 1:n) <= budget_cap_m) |>
    add_constraint(sum_expr(cand$is_new[i] * x[i], i = 1:n) <= max_new_acq) |>
    add_constraint(sum_expr(is_sp[i] * x[i], i = 1:n) >= 4L) |>
    add_constraint(sum_expr(is_rp[i] * x[i], i = 1:n) >= 4L) |>
    add_constraint(sum_expr(is_bat[i] * x[i], i = 1:n) >= 13L) |>
    # Every starting slot s must be covered by exactly 1 player
    add_constraint(sum_expr(y[i, s], i = 1:n) == 1L, s = 1:S) |>
    # A player can fill at most ONE starting slot, and only if selected and eligible
    add_constraint(sum_expr(y[i, s], s = 1:S) <= x[i], i = 1:n) |>
    add_constraint(y[i, s] <= elig_mat[i, s], i = 1:n, s = 1:S)

  for (lid in locked_ids) {
    idx <- which(cand$player_id == lid)
    if (length(idx) == 1L) model <- add_constraint(model, x[idx] == 1L)
  }

  res <- solve_model(model, with_ROI(solver = "glpk"))
  sol_x <- get_solution(res, x[i])
  chosen_idx <- sol_x[sol_x$value > 0.5, "i"]
  selected_dt <- cand[chosen_idx]

  list(
    status = solver_status(res),
    feasible = solver_status(res) %in% c("optimal", "success"),
    selected_ids = selected_dt$player_id,
    total_cost_m = sum(selected_dt$effective_cost),
    total_mwar = sum(selected_dt$mwar_mean),
    selected = selected_dt
  )
}
