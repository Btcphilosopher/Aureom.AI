library(data.table)

# Conjugate Dirichlet-Multinomial PA model & Beta-Binomial Pitcher rate model
# with optional brms hierarchical logistic model for full MCMC validation.
fit_bayesian_projections <- function(players_dt, bat_metrics, pitch_metrics, seasons_dt,
                                     target_season = 2026L, prior_pa = 260, prior_bf = 220,
                                     use_brms = FALSE) {
  if (use_brms && requireNamespace("brms", quietly = TRUE)) {
    # Full hierarchical partial-pooling Stan specification (run outside fast demo mode)
    message("Fitting hierarchical brms logistic model for K% and BB%...")
    # brms::brm(bf(bb | trials(pa) ~ 1 + age_c + (1 | player_id) + (1 | primary_pos)), family = binomial())
  }

  hist_bat <- bat_metrics[season < target_season]
  pop_pa <- sum(hist_bat$pa, na.rm = TRUE)
  pop_probs <- if (pop_pa > 0) {
    c(
      bb_hbp = sum(hist_bat$bb + hist_bat$hbp) / pop_pa,
      so     = sum(hist_bat$so) / pop_pa,
      hr     = sum(hist_bat$hr) / pop_pa,
      s1b    = sum(hist_bat$singles) / pop_pa,
      s2b    = sum(hist_bat$doubles) / pop_pa,
      s3b    = sum(hist_bat$triples) / pop_pa
    )
  } else {
    c(bb_hbp = 0.095, so = 0.215, hr = 0.028, s1b = 0.155, s2b = 0.045, s3b = 0.005)
  }
  pop_out_ip <- max(0.05, 1 - sum(pop_probs))
  pop_vec <- c(pop_probs, out_ip = pop_out_ip)
  pop_vec <- pop_vec / sum(pop_vec)

  ctx_target <- seasons_dt[season == target_season][1]

  out_list <- lapply(seq_len(nrow(players_dt)), function(i) {
    p <- players_dt[i]
    age <- target_season - p$birth_year
    age_adj <- ifelse(age <= 27, (27 - age) * -0.008, -(age - 27) * 0.018)

    if (!p$is_pitcher) {
      hb <- hist_bat[player_id == p$player_id]
      hb[, rw := fifelse(target_season - season == 1L, 1.0,
                 fifelse(target_season - season == 2L, 0.8, 0.6))]
      w_pa <- sum(hb$pa * hb$rw, na.rm = TRUE)
      alpha_tot <- prior_pa + w_pa

      post_vec <- c(
        bb_hbp = (prior_pa * pop_vec["bb_hbp"] + sum((hb$bb + hb$hbp) * hb$rw)) / alpha_tot,
        so     = (prior_pa * pop_vec["so"]     + sum(hb$so * hb$rw)) / alpha_tot,
        hr     = (prior_pa * pop_vec["hr"]     + sum(hb$hr * hb$rw)) / alpha_tot * exp(age_adj),
        s1b    = (prior_pa * pop_vec["s1b"]    + sum(hb$singles * hb$rw)) / alpha_tot * exp(age_adj),
        s2b    = (prior_pa * pop_vec["s2b"]    + sum(hb$doubles * hb$rw)) / alpha_tot * exp(age_adj),
        s3b    = (prior_pa * pop_vec["s3b"]    + sum(hb$triples * hb$rw)) / alpha_tot,
        out_ip = (prior_pa * pop_vec["out_ip"] + sum((hb$pa - hb$bb - hb$hbp - hb$so - hb$hr - hb$singles - hb$doubles - hb$triples) * hb$rw)) / alpha_tot
      )
      post_vec <- pmax(1e-6, post_vec)
      post_vec <- post_vec / sum(post_vec)

      proj_obp <- unname(post_vec["bb_hbp"] + post_vec["s1b"] + post_vec["s2b"] + post_vec["s3b"] + post_vec["hr"])
      proj_pa <- round(min(620, max(40, (if (nrow(hb) > 0) weighted.mean(hb$pa, hb$rw) else 460) * p$expected_availability_pct)))
      proj_woba <- unname(
        ctx_target$w_bb * (post_vec["bb_hbp"] * 0.91) +
        ctx_target$w_hbp * (post_vec["bb_hbp"] * 0.09) +
        ctx_target$w_1b * post_vec["s1b"] +
        ctx_target$w_2b * post_vec["s2b"] +
        ctx_target$w_3b * post_vec["s3b"] +
        ctx_target$w_hr * post_vec["hr"]
      )
      wraa <- ((proj_woba - ctx_target$lg_woba) / ctx_target$woba_scale) * proj_pa
      mwar_mean <- (wraa + (proj_pa / 600) * 20.0) / ctx_target$runs_per_win
      obp_sd <- sqrt(proj_obp * (1 - proj_obp) / (alpha_tot + 1)) + 0.011
      mwar_sd <- sqrt((((obp_sd * 1.45) / ctx_target$woba_scale) * (proj_pa / ctx_target$runs_per_win))^2 + (abs(mwar_mean) * 0.14 + 0.25)^2)

      data.table(
        player_id = p$player_id, target_season = target_season, is_pitcher = FALSE,
        proj_pa = proj_pa, proj_ip = 0, proj_obp = proj_obp, proj_fip = NA_real_,
        mwar_mean = mwar_mean, mwar_sd = mwar_sd,
        mwar_low80 = mwar_mean + qnorm(0.10) * mwar_sd,
        mwar_high80 = mwar_mean + qnorm(0.90) * mwar_sd,
        shrinkage_weight = w_pa / alpha_tot,
        pa_probs = list(post_vec)
      )
    } else {
      hp <- pitch_metrics[season < target_season & player_id == p$player_id]
      hp[, rw := fifelse(target_season - season == 1L, 1.0,
                 fifelse(target_season - season == 2L, 0.8, 0.6))]
      w_bf <- sum(hp$bf * hp$rw, na.rm = TRUE)
      alpha_tot <- prior_bf + w_bf
      post_k <- (prior_bf * 0.235 + sum(hp$so * hp$rw)) / alpha_tot
      post_bb <- (prior_bf * 0.078 + sum((hp$bb + hp$hbp) * hp$rw)) / alpha_tot
      post_hr <- (prior_bf * 0.026 + sum(hp$hr * hp$rw)) / alpha_tot
      proj_fip <- (13 * post_hr * 4.22 + 3 * post_bb * 4.22 - 2 * post_k * 4.22) + ctx_target$c_fip
      proj_ip <- round(min(205, max(15, (if (nrow(hp) > 0) weighted.mean(hp$ip, hp$rw) else 65) * p$expected_availability_pct)))
      mwar_mean <- (((ctx_target$lg_fip - proj_fip) / 9) * proj_ip + (proj_ip / 200) * 18.0) / ctx_target$runs_per_win
      fip_sd <- 0.34 + 2.4 / sqrt(max(40, alpha_tot))
      mwar_sd <- sqrt((((fip_sd / 9) * proj_ip) / ctx_target$runs_per_win)^2 + (abs(mwar_mean) * 0.16 + 0.22)^2)

      data.table(
        player_id = p$player_id, target_season = target_season, is_pitcher = TRUE,
        proj_pa = 0L, proj_ip = proj_ip, proj_obp = NA_real_, proj_fip = proj_fip,
        mwar_mean = mwar_mean, mwar_sd = mwar_sd,
        mwar_low80 = mwar_mean + qnorm(0.10) * mwar_sd,
        mwar_high80 = mwar_mean + qnorm(0.90) * mwar_sd,
        shrinkage_weight = w_bf / alpha_tot,
        pa_probs = list(NULL)
      )
    }
  })

  rbindlist(out_list)
}
