# 24-State Base-Out Monte Carlo Game & Season Simulation Engine
step_base_out <- function(outs, bases, event) {
  runs <- 0L
  on1 <- bitwAnd(bases, 1L) > 0L
  on2 <- bitwAnd(bases, 2L) > 0L
  on3 <- bitwAnd(bases, 4L) > 0L

  if (event == "BB_HBP") {
    if (on1 && on2 && on3) { runs <- 1L; bases <- 7L }
    else if (on1 && on2) { bases <- 7L }
    else if (on1 && on3) { bases <- 7L }
    else if (on1) { bases <- 3L }
    else { bases <- bitwOr(bases, 1L) }
  } else if (event == "HR") {
    runs <- 1L + as.integer(on1) + as.integer(on2) + as.integer(on3)
    bases <- 0L
  } else if (event == "3B") {
    runs <- as.integer(on1) + as.integer(on2) + as.integer(on3)
    bases <- 4L
  } else if (event == "2B") {
    runs <- as.integer(on2) + as.integer(on3)
    next_b <- 2L
    if (on1) { if (runif(1) < 0.42) runs <- runs + 1L else next_b <- bitwOr(next_b, 4L) }
    bases <- next_b
  } else if (event == "1B") {
    if (on3) runs <- runs + 1L
    next_b <- 1L
    if (on2) { if (runif(1) < 0.62) runs <- runs + 1L else next_b <- bitwOr(next_b, 4L) }
    if (on1) { if (bitwAnd(next_b, 4L) == 0L && runif(1) < 0.28) next_b <- bitwOr(next_b, 4L) else next_b <- bitwOr(next_b, 2L) }
    bases <- next_b
  } else if (event == "SO") {
    outs <- outs + 1L
  } else if (event == "GB_OUT") {
    if (on1 && outs < 2L && runif(1) < 0.42) {
      outs <- outs + 2L
      if (outs < 3L && on3) runs <- runs + 1L
      bases <- if (on2) 4L else 0L
    } else {
      outs <- outs + 1L
      if (outs < 3L) {
        if (on3) runs <- runs + 1L
        bases <- (if (on2) 4L else 0L) + (if (on1) 2L else 0L)
      }
    }
  } else if (event == "FB_OUT") {
    outs <- outs + 1L
    if (outs < 3L && on3 && runif(1) < 0.68) {
      runs <- runs + 1L
      bases <- bitwAnd(bases, 3L)
    }
  }
  list(outs = outs, bases = bases, runs = runs)
}

run_season_monte_carlo <- function(roster_ids, projections_dt, n_sims = 500L, n_games = 140L,
                                   seed = 2026L, win_target = 75L) {
  set.seed(seed)
  wins_vec <- integer(n_sims)
  batters <- projections_dt[player_id %in% roster_ids & !is_pitcher][1:9]
  default_p <- c(bb_hbp = 0.095, so = 0.215, hr = 0.028, s1b = 0.155, s2b = 0.045, s3b = 0.005, out_ip = 0.457)

  for (s in seq_len(n_sims)) {
    talent_shift <- rnorm(1, 0, 0.0085) # Outer parameter uncertainty draw
    w <- 0L
    for (g in seq_len(n_games)) {
      our_r <- 0L; opp_r <- 0L; b_idx <- 1L
      for (inn in 1:9) {
        outs <- 0L; bases <- 0L
        while (outs < 3L) {
          p_vec <- if (b_idx <= nrow(batters) && !is.null(batters$pa_probs[[b_idx]])) batters$pa_probs[[b_idx]] else default_p
          p_vec <- pmax(1e-5, p_vec + c(talent_shift * 0.3, 0, talent_shift * 0.2, talent_shift * 0.5, 0, 0, -talent_shift))
          p_vec <- p_vec / sum(p_vec)
          ev <- sample(c("BB_HBP", "SO", "HR", "1B", "2B", "3B", "GB_OUT", "FB_OUT"),
                       1L, prob = c(p_vec[1:6], p_vec[7] * 0.52, p_vec[7] * 0.48))
          res <- step_base_out(outs, bases, ev)
          our_r <- our_r + res$runs; outs <- res$outs; bases <- res$bases
          b_idx <- (b_idx %% 9L) + 1L
        }
        outs <- 0L; bases <- 0L
        while (outs < 3L) {
          ev <- sample(c("BB_HBP", "SO", "HR", "1B", "2B", "3B", "GB_OUT", "FB_OUT"),
                       1L, prob = c(default_p[1:6], default_p[7] * 0.52, default_p[7] * 0.48))
          res <- step_base_out(outs, bases, ev)
          opp_r <- opp_r + res$runs; outs <- res$outs; bases <- res$bases
        }
      }
      if (our_r > opp_r || (our_r == opp_r && runif(1) < 0.5)) w <- w + 1L
    }
    wins_vec[s] <- w
  }

  list(
    n_sims = n_sims,
    expected_wins = mean(wins_vec),
    sd_wins = sd(wins_vec),
    mc_se = sd(wins_vec) / sqrt(n_sims),
    quantiles = quantile(wins_vec, probs = c(0.10, 0.25, 0.50, 0.75, 0.90)),
    prob_exceed_target = mean(wins_vec >= win_target),
    wins = wins_vec
  )
}
