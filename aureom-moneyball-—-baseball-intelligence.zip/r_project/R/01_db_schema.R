library(DBI)
library(duckdb)

init_aureom_schema <- function(con) {
  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS data_provenance (
      source_id VARCHAR PRIMARY KEY,
      source_name VARCHAR NOT NULL,
      adapter_type VARCHAR NOT NULL,
      granularity VARCHAR NOT NULL,
      license VARCHAR NOT NULL,
      retrieved_at TIMESTAMP NOT NULL,
      notes VARCHAR
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS teams (
      team_id VARCHAR PRIMARY KEY,
      name VARCHAR NOT NULL,
      division VARCHAR NOT NULL,
      stadium VARCHAR NOT NULL,
      park_factor_runs DOUBLE NOT NULL,
      park_factor_hr DOUBLE NOT NULL,
      budget_cap_m DOUBLE NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS seasons (
      season INTEGER PRIMARY KEY,
      competition VARCHAR NOT NULL,
      games_per_team INTEGER NOT NULL,
      playoff_spots INTEGER NOT NULL,
      w_bb DOUBLE NOT NULL, w_hbp DOUBLE NOT NULL,
      w_1b DOUBLE NOT NULL, w_2b DOUBLE NOT NULL,
      w_3b DOUBLE NOT NULL, w_hr DOUBLE NOT NULL,
      lg_woba DOUBLE NOT NULL, woba_scale DOUBLE NOT NULL,
      r_per_pa DOUBLE NOT NULL, lg_fip DOUBLE NOT NULL,
      c_fip DOUBLE NOT NULL, runs_per_win DOUBLE NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS players (
      player_id VARCHAR PRIMARY KEY,
      full_name VARCHAR NOT NULL,
      birth_year INTEGER NOT NULL,
      bats VARCHAR NOT NULL,
      throws VARCHAR NOT NULL,
      primary_pos VARCHAR NOT NULL,
      eligible_positions VARCHAR NOT NULL,
      pitching_role VARCHAR NOT NULL,
      is_pitcher BOOLEAN NOT NULL,
      current_team_id VARCHAR,
      salary_m DOUBLE NOT NULL,
      trade_cost_m DOUBLE NOT NULL,
      years_control INTEGER NOT NULL,
      availability VARCHAR NOT NULL,
      expected_availability_pct DOUBLE NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS batting_stints (
      stint_id VARCHAR PRIMARY KEY,
      player_id VARCHAR NOT NULL,
      season INTEGER NOT NULL,
      team_id VARCHAR NOT NULL,
      stint_order INTEGER NOT NULL,
      split_vs_hand VARCHAR NOT NULL,
      g INTEGER, pa INTEGER, ab INTEGER, h INTEGER,
      doubles INTEGER, triples INTEGER, hr INTEGER,
      bb INTEGER, ibb INTEGER, hbp INTEGER, so INTEGER,
      sf INTEGER, sh INTEGER, sb INTEGER, cs INTEGER, gdp INTEGER,
      granularity VARCHAR NOT NULL,
      source_id VARCHAR NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS pitching_stints (
      stint_id VARCHAR PRIMARY KEY,
      player_id VARCHAR NOT NULL,
      season INTEGER NOT NULL,
      team_id VARCHAR NOT NULL,
      stint_order INTEGER NOT NULL,
      role VARCHAR NOT NULL,
      g INTEGER, gs INTEGER, outs_recorded INTEGER, bf INTEGER,
      h INTEGER, er INTEGER, r INTEGER, hr INTEGER,
      bb INTEGER, ibb INTEGER, hbp INTEGER, so INTEGER,
      granularity VARCHAR NOT NULL,
      source_id VARCHAR NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS fielding_records (
      record_id VARCHAR PRIMARY KEY,
      player_id VARCHAR NOT NULL,
      season INTEGER NOT NULL,
      team_id VARCHAR NOT NULL,
      pos VARCHAR NOT NULL,
      g INTEGER, inn DOUBLE, po INTEGER, a INTEGER, e INTEGER, dp INTEGER,
      range_runs_est DOUBLE, arm_runs_est DOUBLE, framing_runs_est DOUBLE,
      source_id VARCHAR NOT NULL
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS transactions (
      tx_id VARCHAR PRIMARY KEY,
      tx_date DATE NOT NULL,
      player_id VARCHAR NOT NULL,
      from_team_id VARCHAR,
      to_team_id VARCHAR,
      tx_type VARCHAR NOT NULL,
      notes VARCHAR
    );
  ")

  DBI::dbExecute(con, "
    CREATE TABLE IF NOT EXISTS scouting_reports (
      report_id VARCHAR PRIMARY KEY,
      player_id VARCHAR NOT NULL,
      observer VARCHAR NOT NULL,
      report_date DATE NOT NULL,
      role_projection VARCHAR NOT NULL,
      grade_overall INTEGER NOT NULL,
      confidence VARCHAR NOT NULL,
      notes VARCHAR,
      evidence VARCHAR,
      follow_up_action VARCHAR
    );
  ")
}
