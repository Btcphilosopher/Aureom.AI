library(data.table)

# Rolling-Origin Leakage-Free Backtest
run_rolling_backtest <- function(raw_tables, origin_season = 2024L) {
  eval_season <- origin_season + 1L
  cutoff_date <- as.Date(sprintf("%d-11-01", origin_season))

  # Strict temporal slice: NO future stints or post-cutoff transactions permitted
  train_bat <- raw_tables$batting_stints[season <= origin_season]
  train_pit <- raw_tables$pitching_stints[season <= origin_season]
  train_fld <- raw_tables$fielding_records[season <= origin_season]
  train_tx  <- raw_tables$transactions[as.Date(tx_date) <= cutoff_date]

  stopifnot(max(train_bat$season) <= origin_season)
  stopifnot(max(as.Date(train_tx$tx_date)) <= cutoff_date)

  bat_train_m <- compute_batting_metrics(train_bat, train_fld, raw_tables$seasons, raw_tables$teams)
  pit_train_m <- compute_pitching_metrics(train_pit, raw_tables$seasons, raw_tables$teams)
  preds <- fit_bayesian_projections(raw_tables$players, bat_train_m, pit_train_m, raw_tables$seasons, target_season = eval_season)

  actual_bat <- compute_batting_metrics(raw_tables$batting_stints[season == eval_season], raw_tables$fielding_records[season == eval_season], raw_tables$seasons, raw_tables$teams)
  merged <- merge(preds[!is_pitcher], actual_bat[pa >= 80], by = "player_id")
  naive <- bat_train_m[season == origin_season, .(player_id, naive_obp = obp)]
  merged <- merge(merged, naive, by = "player_id")

  list(
    origin_season = origin_season,
    eval_season = eval_season,
    n_batters = nrow(merged),
    bayesian_obp_mae = mean(abs(merged$proj_obp - merged$obp), na.rm = TRUE),
    naive_obp_mae = mean(abs(merged$naive_obp - merged$obp), na.rm = TRUE),
    pa_mae = mean(abs(merged$proj_pa - merged$pa), na.rm = TRUE)
  )
}
