library(targets)

tar_option_set(
  packages = c("data.table", "DBI", "duckdb", "ompr", "ompr.roi", "ROI.plugin.glpk"),
  format = "rds"
)

source("R/01_db_schema.R")
source("R/02_synthetic_data.R")
source("R/03_sabermetrics.R")
source("R/04_bayesian_projections.R")
source("R/05_roster_optimizer.R")
source("R/06_monte_carlo_sim.R")
source("R/07_backtest.R")

list(
  tar_target(db_path, "data/aureom_moneyball.duckdb"),
  tar_target(seed_data, seed_aibl_duckdb(db_path)),
  tar_target(raw_tables, load_tables_from_duckdb(db_path, seed_data)),
  tar_target(batting_metrics, compute_batting_metrics(raw_tables$batting_stints, raw_tables$fielding_records, raw_tables$seasons, raw_tables$teams)),
  tar_target(pitching_metrics, compute_pitching_metrics(raw_tables$pitching_stints, raw_tables$seasons, raw_tables$teams)),
  tar_target(projections_2026, fit_bayesian_projections(raw_tables$players, batting_metrics, pitching_metrics, raw_tables$seasons, target_season = 2026L)),
  tar_target(backtest_2024_2025, run_rolling_backtest(raw_tables, origin_season = 2024L)),
  tar_target(optimal_roster_shf, optimize_roster_milp(raw_tables$players, projections_2026, team_id = "SHF", budget_cap_m = 68.0, roster_size = 23L)),
  tar_target(season_sim_shf, run_season_monte_carlo(optimal_roster_shf$selected_ids, projections_2026, n_sims = 500L, seed = 2026L))
)
