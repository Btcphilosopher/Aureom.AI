# AUREOM MONEYBALL — Baseball Intelligence (R Project)

Reproducible baseball analytics, Bayesian projection, constrained integer roster optimisation, and Monte Carlo season simulation platform built in R.

## Architecture

- `app.R`: Shiny + `bslib` front-office terminal (Midnight Navy, Warm White, Baseball Red; Light/Dark themes).
- `R/01_db_schema.R`: `DBI` + `duckdb` analytical schema with explicit data provenance and granularity.
- `R/02_synthetic_data.R`: Offline AIBL & Sheffield Steelheads dataset generator with traded-player stints, platoon splits, contracts, and scouting reports.
- `R/03_sabermetrics.R`: Count-based batting, pitching, and fielding calculations + Modelled Wins Above Replacement (`mWAR`).
- `R/04_bayesian_projections.R`: Empirical-Bayes / Dirichlet-Multinomial PA model & `brms` hierarchical specification with partial pooling and posterior predictive checks.
- `R/05_roster_optimizer.R`: Mixed-Integer Linear Programming (`ompr` + `ROI.plugin.glpk`) with exclusive single-slot defensive assignments.
- `R/06_monte_carlo_sim.R`: 24-state base-out season simulator separating parameter uncertainty from game randomness with Common Random Numbers.
- `R/07_backtest.R`: Leakage-free rolling-origin evaluation.
- `_targets.R`: Reproducible analytical pipeline (`targets`).
- `reports/management_report.qmd`: Parameterized Quarto executive briefing template.
- `tests/testthat/test-analytics.R`: Unit and integration test suite.

## Startup Commands

```r
# 1. Restore locked R package dependencies
renv::restore()

# 2. Run the reproducible analytical pipeline (seeds DuckDB, fits projections, backtests, simulations)
targets::tar_make()

# 3. Execute automated testthat verification
testthat::test_local()

# 4. Launch the interactive Shiny front-office terminal
shiny::runApp("app.R", port = 3838)

# 5. Render the Quarto management report
quarto::quarto_render(
  "reports/management_report.qmd",
  execute_params = list(team_id = "SHF", target_season = 2026, budget_cap_m = 68.0)
)
```
