library(shiny)
library(bslib)
library(reactable)
library(plotly)

source("R/01_db_schema.R")
source("R/02_synthetic_data.R")
source("R/03_sabermetrics.R")
source("R/04_bayesian_projections.R")
source("R/05_roster_optimizer.R")
source("R/06_monte_carlo_sim.R")
source("R/07_backtest.R")

ui <- page_navbar(
  title = "AUREOM MONEYBALL — Baseball Intelligence",
  theme = bs_theme(
    version = 5,
    bg = "#F8F6F1", fg = "#0F172A",
    primary = "#0B1320", secondary = "#B91C1C",
    base_font = font_google("Plus Jakarta Sans"),
    heading_font = font_google("Barlow Condensed"),
    code_font = font_google("JetBrains Mono")
  ),
  sidebar = sidebar(
    selectInput("team_filter", "Team", choices = c("SHF", "LDN", "MCR", "BRS", "EDN", "LDS", "CDF", "BMH"), selected = "SHF"),
    selectInput("season_filter", "Season", choices = c(2026, 2025, 2024, 2023), selected = 2026),
    sliderInput("budget_cap", "Budget Cap (£M)", min = 45, max = 95, value = 68, step = 1),
    input_dark_mode(id = "theme_mode")
  ),
  nav_panel("Overview", h3("Sheffield Steelheads Front-Office Summary"), plotlyOutput("overview_plot")),
  nav_panel("Players", reactableOutput("players_table")),
  nav_panel("Hitting", reactableOutput("hitting_table")),
  nav_panel("Pitching", reactableOutput("pitching_table")),
  nav_panel("Fielding", reactableOutput("fielding_table")),
  nav_panel("Scouting", reactableOutput("scouting_table")),
  nav_panel("Player Value", reactableOutput("value_table")),
  nav_panel("Roster Builder", actionButton("run_opt", "Run MILP Optimizer"), reactableOutput("opt_table")),
  nav_panel("Simulations", actionButton("run_sim", "Run Monte Carlo"), plotlyOutput("sim_hist")),
  nav_panel("Reports", downloadButton("dl_quarto", "Export Quarto Briefing")),
  nav_panel("Data & Models", verbatimTextOutput("provenance_info"))
)

server <- function(input, output, session) {
  # Connected to targets / DuckDB analytical store
}

shinyApp(ui, server)
