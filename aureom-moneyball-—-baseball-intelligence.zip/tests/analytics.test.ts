import assert from 'node:assert/strict';
import test from 'node:test';
import { buildBayesianProjections, normalizePAProbs } from '../src/engine/bayesianProjections.ts';
import { runRollingBacktest } from '../src/engine/backtest.ts';
import {
  combineBatterPitcherProbs,
  runSeasonSimulation,
  stepBaseOutState,
} from '../src/engine/monteCarloSim.ts';
import { assignPlayersToSlots, optimizeRoster } from '../src/engine/rosterOptimizer.ts';
import {
  aggregateBattingForPlayerSeason,
  aggregatePitchingForPlayerSeason,
  safeDiv,
} from '../src/engine/sabermetrics.ts';
import { createSyntheticDataset } from '../src/engine/syntheticData.ts';
import type { BattingStint, OptimizerConfig, PitchingStint, PlayerMaster } from '../src/engine/types.ts';

const store = createSyntheticDataset();
const teamsMap = new Map(store.teams.map((t) => [t.teamId, t]));
const ctx2025 = store.seasons.find((s) => s.season === 2025)!;

test('1. Hand-worked batting & pitching sabermetric calculations', () => {
  const handBatter: PlayerMaster = {
    playerId: 'TEST-B1',
    fullName: 'Hand Worked Batter',
    birthYear: 1998,
    bats: 'R',
    throws: 'R',
    primaryPos: 'SS',
    eligiblePositions: ['SS'],
    pitchingRole: 'NONE',
    isPitcher: false,
    currentTeamId: 'SHF',
    salaryM: 2.0,
    tradeCostM: 0,
    yearsControl: 3,
    contractType: 'Pre-Arb',
    availability: 'Rostered',
    healthRiskNote: '',
    expectedAvailabilityPct: 1,
  };
  // AB=400, H=120 (20 2B, 2 3B, 18 HR => 80 1B), BB=50 (IBB=2), HBP=5, SF=5, SO=80 => PA=460
  const stint: BattingStint = {
    stintId: 'S1',
    playerId: 'TEST-B1',
    season: 2025,
    teamId: 'SHF',
    stintOrder: 1,
    splitVsHand: 'ALL',
    g: 120,
    pa: 460,
    ab: 400,
    h: 120,
    doubles: 20,
    triples: 2,
    hr: 18,
    r: 65,
    rbi: 70,
    bb: 50,
    ibb: 2,
    hbp: 5,
    so: 80,
    sf: 5,
    sh: 0,
    sb: 10,
    cs: 2,
    gdp: 6,
    granularity: 'stint_split',
    sourceId: 'TEST',
  };

  const agg = aggregateBattingForPlayerSeason(handBatter, [stint], [], ctx2025, teamsMap)!;
  assert.ok(Math.abs(agg.ba! - 120 / 400) < 1e-6); // .300
  assert.ok(Math.abs(agg.obp! - 175 / 460) < 1e-6); // .380435
  // Total bases = 80 + 40 + 6 + 72 = 198 => SLG = 198/400 = 0.495
  assert.ok(Math.abs(agg.slg! - 198 / 400) < 1e-6);
  assert.ok(Math.abs(agg.iso! - (0.495 - 0.3)) < 1e-6);
  // BABIP = (120 - 18) / (400 - 80 - 18 + 5) = 102 / 307
  assert.ok(Math.abs(agg.babip! - 102 / 307) < 1e-6);

  const handPitcher: PlayerMaster = {
    ...handBatter,
    playerId: 'TEST-P1',
    primaryPos: 'SP',
    eligiblePositions: ['SP'],
    pitchingRole: 'SP',
    isPitcher: true,
  };
  const pStint: PitchingStint = {
    stintId: 'PS1',
    playerId: 'TEST-P1',
    season: 2025,
    teamId: 'SHF',
    stintOrder: 1,
    role: 'SP',
    g: 30,
    gs: 30,
    outsRecorded: 540, // 180.0 IP
    bf: 740,
    h: 160,
    er: 60,
    r: 66,
    hr: 18,
    bb: 45,
    ibb: 2,
    hbp: 5,
    so: 190,
    gbOuts: 240,
    fbOuts: 180,
    granularity: 'stint_split',
    sourceId: 'TEST',
  };
  const pAgg = aggregatePitchingForPlayerSeason(handPitcher, [pStint], ctx2025, teamsMap)!;
  assert.ok(Math.abs(pAgg.era! - 3.0) < 1e-6); // 9*60/180 = 3.00
  assert.ok(Math.abs(pAgg.whip! - (45 + 160) / 180) < 1e-6);
  const expectedFIP = (13 * 18 + 3 * (45 + 5) - 2 * 190) / 180 + ctx2025.cFIP;
  assert.ok(Math.abs(pAgg.fip! - expectedFIP) < 1e-6);
});

test('2. Count-based aggregation (not rate averaging) & zero-denominator safety', () => {
  assert.equal(safeDiv(10, 0), null);
  assert.equal(safeDiv(10, -5), null);

  const player = store.players.find((p) => p.playerId === 'SHF-B03')!;
  const stints2025 = store.battingStints.filter(
    (s) => s.playerId === 'SHF-B03' && s.season === 2025 && s.splitVsHand === 'ALL'
  );
  assert.equal(stints2025.length, 2, 'Kieran Vance must have 2 traded stints in 2025');

  const agg = aggregateBattingForPlayerSeason(player, store.battingStints, store.fieldingRecords, ctx2025, teamsMap)!;
  const totalH = stints2025[0].h + stints2025[1].h;
  const totalAB = stints2025[0].ab + stints2025[1].ab;
  assert.ok(Math.abs(agg.ba! - totalH / totalAB) < 1e-9);
});

test('3. Traded-player deduplication prevents double-counting duplicate stints', () => {
  const player = store.players.find((p) => p.playerId === 'SHF-B03')!;
  const origStints = store.battingStints.filter(
    (s) => s.playerId === 'SHF-B03' && s.season === 2025 && s.splitVsHand === 'ALL'
  );
  // Inject a duplicate copy of stint 1
  const duplicated = [...origStints, { ...origStints[0], stintId: 'DUP-COPY' }];
  const aggClean = aggregateBattingForPlayerSeason(player, origStints, [], ctx2025, teamsMap)!;
  const aggDup = aggregateBattingForPlayerSeason(player, duplicated, [], ctx2025, teamsMap)!;
  assert.equal(aggDup.pa, aggClean.pa);
  assert.equal(aggDup.h, aggClean.h);
});

test('4. Bayesian projection reproducibility & probability normalization', () => {
  const projA = buildBayesianProjections(store, 2026);
  const projB = buildBayesianProjections(store, 2026);
  const vanceA = projA.get('SHF-B03')!;
  const vanceB = projB.get('SHF-B03')!;
  assert.equal(vanceA.projOBP, vanceB.projOBP);
  assert.equal(vanceA.mWARMean, vanceB.mWARMean);

  for (const [, p] of projA) {
    const sum =
      p.paProbs.bbHbp +
      p.paProbs.so +
      p.paProbs.hr +
      p.paProbs.single +
      p.paProbs.double +
      p.paProbs.triple +
      p.paProbs.outInPlay;
    assert.ok(Math.abs(sum - 1.0) < 1e-6, `PA probabilities sum to ${sum} for ${p.playerId}`);
  }

  const combined = combineBatterPitcherProbs(
    vanceA.paProbs,
    projA.get('SHF-P01')!.paProbs,
    normalizePAProbs({ bbHbp: 0.095, so: 0.215, hr: 0.028, single: 0.155, double: 0.045, triple: 0.005, outInPlay: 0.457 })
  );
  const sumComb = Object.values(combined).reduce((a, b) => a + b, 0);
  assert.ok(Math.abs(sumComb - 1.0) < 1e-6);
});

test('5. Baseball 24-state transitions (walks, HR, double plays, sac flies)', () => {
  // Bases loaded (7), 1 out -> BB scores 1 run, stays bases loaded (7), outs=1
  const walkRes = stepBaseOutState({ bases: 7, outs: 1 }, 'BB_HBP', () => 0.5);
  assert.equal(walkRes.runsScored, 1);
  assert.equal(walkRes.nextState.bases, 7);
  assert.equal(walkRes.nextState.outs, 1);

  // Runner on 1B & 3B (5), 0 outs -> HR scores 3 runs, clears bases
  const hrRes = stepBaseOutState({ bases: 5, outs: 0 }, 'HR', () => 0.5);
  assert.equal(hrRes.runsScored, 3);
  assert.equal(hrRes.nextState.bases, 0);

  // Runner on 3B (4), 1 out -> FB_OUT with rand=0.2 (<0.68) triggers sac fly scoring 1 run, outs=2
  const sfRes = stepBaseOutState({ bases: 4, outs: 1 }, 'FB_OUT', () => 0.2);
  assert.equal(sfRes.runsScored, 1);
  assert.equal(sfRes.nextState.outs, 2);
  assert.equal(sfRes.nextState.bases, 0);

  // Runner on 1B (1), 0 outs -> GB_OUT with rand=0.1 (<0.42) triggers double play (+2 outs)
  const dpRes = stepBaseOutState({ bases: 1, outs: 0 }, 'GB_OUT', () => 0.1);
  assert.equal(dpRes.nextState.outs, 2);
  assert.equal(dpRes.nextState.bases, 0);
});

test('6. Roster optimizer enforces budget, position uniqueness, and detects impossible scenarios', () => {
  const projections = buildBayesianProjections(store, 2026);
  const baseConfig: OptimizerConfig = {
    teamId: 'SHF',
    targetSeason: 2026,
    budgetCapM: 68.0,
    rosterSize: 23,
    requiredPositions: { C: 1, '1B': 1, '2B': 1, '3B': 1, SS: 1, LF: 1, CF: 1, RF: 1, DH: 1 },
    requiredSP: 4,
    requiredRP: 4,
    minBench: 4,
    maxNewAcquisitions: 5,
    objective: 'max_mwar',
    targetMWAR: 25,
    riskAversionLambda: 0.35,
    lockedPlayerIds: ['SHF-B03', 'SHF-P01'],
    excludedPlayerIds: [],
    includeInjured: false,
    ruleSetName: 'AIBL-26-Standard',
  };

  const sol = optimizeRoster(store, projections, baseConfig);
  assert.equal(sol.feasible, true, `Expected feasible solution, got: ${sol.unmetConstraints.join('; ')}`);
  assert.equal(sol.selectedRoster.length, 23);
  assert.ok(sol.totalEffectiveCostM <= 68.0 + 1e-6);

  // Check every player appears at most once (no multi-position double-filling)
  const uniqueIds = new Set(sol.selectedRoster.map((r) => r.player.playerId));
  assert.equal(uniqueIds.size, 23);

  // Impossible scenario: budget cap far too low (£12M for 23 players)
  const impossible = optimizeRoster(store, projections, { ...baseConfig, budgetCapM: 12.0 });
  assert.equal(impossible.feasible, false);
  assert.ok(impossible.unmetConstraints.length > 0);
});

test('7. Rolling-origin backtest enforces strict temporal boundary without leakage', () => {
  const bt = runRollingBacktest(store, 2024);
  assert.equal(bt.evalSeason, 2025);
  assert.ok(bt.nBatters >= 10);
  assert.ok(bt.nPitchers >= 5);
  assert.ok(bt.leakageChecks.every((c) => c.passed), 'All leakage audit checks must pass');
  // Bayesian partial pooling should outperform or stay tight vs naive baseline
  assert.ok(bt.bayesianOBP_MAE > 0 && bt.bayesianOBP_MAE < 0.06);
});

test('8. Monte Carlo simulation convergence & Common Random Numbers determinism', () => {
  const projections = buildBayesianProjections(store, 2026);
  const shfIds = store.players.filter((p) => p.currentTeamId === 'SHF' && p.availability !== 'Injured List').map((p) => p.playerId);
  const lineupIds = shfIds.filter((id) => !store.players.find((p) => p.playerId === id)!.isPitcher).slice(0, 9);

  const simLowN = runSeasonSimulation(store, projections, {
    teamId: 'SHF',
    targetSeason: 2026,
    numSimulations: 100,
    seed: 2026,
    useCommonRandomNumbers: true,
    includeParameterUncertainty: true,
    extraInningGhostRunner: true,
    winTarget: 75,
    opponentStrengthOffset: 0,
    rosterPlayerIds: shfIds,
    unavailablePlayerIds: [],
    lineupOrderIds: lineupIds,
    splitScenario: 'Neutral',
  });

  const simHighN = runSeasonSimulation(store, projections, {
    ...simLowN.config,
    numSimulations: 600,
  });

  const simRepeat = runSeasonSimulation(store, projections, simLowN.config);
  assert.equal(simLowN.expectedWins, simRepeat.expectedWins, 'Seeded CRN simulation must be reproducible');
  assert.ok(
    simHighN.mcStandardError < simLowN.mcStandardError,
    `MC SE should shrink with higher N (${simHighN.mcStandardError} < ${simLowN.mcStandardError})`
  );
});
