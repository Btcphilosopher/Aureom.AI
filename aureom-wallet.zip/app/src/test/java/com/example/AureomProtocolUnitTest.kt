package com.example

import com.example.domain.custody.InMemorySecretVault
import com.example.domain.engine.FiatOffRampAdapter
import com.example.domain.engine.HtlcProtocolEngine
import com.example.domain.engine.HtlcValidationResult
import com.example.domain.engine.OffRampQuoteResult
import com.example.domain.engine.QuoteEngine
import com.example.domain.engine.QuoteResult
import com.example.domain.engine.QuoteRevalidationResult
import com.example.domain.model.AddressValidationResult
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetId
import com.example.domain.model.AssetKind
import com.example.domain.model.AssetRegistry
import com.example.domain.model.BankPayoutState
import com.example.domain.model.ConversionLegState
import com.example.domain.model.EligibilityStatus
import com.example.domain.model.IntegrationStatus
import com.example.domain.model.ProviderBalanceState
import com.example.domain.model.RouteType
import com.example.domain.model.SwapState
import com.example.domain.util.MoneyMath
import com.example.domain.util.RedactingLogger
import com.example.domain.util.WebhookVerificationResult
import com.example.domain.util.WebhookVerifier
import java.math.BigInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AureomProtocolUnitTest {

  private fun sandboxBalances(): Map<AssetId, AssetBalance> =
    mapOf(
      AssetRegistry.BTC_TEST_ID to
        AssetBalance(AssetRegistry.BTC_TEST_ID, spendableBaseUnits = BigInteger.valueOf(5_000_000L)),
      AssetRegistry.LTC_TEST_ID to
        AssetBalance(AssetRegistry.LTC_TEST_ID, spendableBaseUnits = BigInteger.valueOf(200_000_000L)),
      AssetRegistry.ETH_SEP_ID to
        AssetBalance(AssetRegistry.ETH_SEP_ID, spendableBaseUnits = BigInteger("1000000000000000000")),
      AssetRegistry.WETH_SEP_ID to
        AssetBalance(AssetRegistry.WETH_SEP_ID, spendableBaseUnits = BigInteger("500000000000000000")),
      AssetRegistry.USDC_SEP_ID to
        AssetBalance(AssetRegistry.USDC_SEP_ID, spendableBaseUnits = BigInteger.valueOf(500_000_000L)),
    )

  @Test
  fun `asset registry distinguishes native wrapped bridged and blocks unverified`() {
    val eth = AssetRegistry.findById(AssetRegistry.ETH_SEP_ID)!!
    val weth = AssetRegistry.findById(AssetRegistry.WETH_SEP_ID)!!
    val usdc = AssetRegistry.findById(AssetRegistry.USDC_SEP_ID)!!
    val usdcBridged = AssetRegistry.findById(AssetRegistry.USDC_OP_BRIDGED_ID)!!
    val unverified = AssetRegistry.findById(AssetRegistry.UNVERIFIED_TOKEN_ID)!!

    assertNotEquals(eth.id, weth.id)
    assertEquals(AssetKind.NATIVE, eth.assetKind)
    assertEquals(AssetKind.WRAPPED, weth.assetKind)
    assertNotEquals(usdc.id, usdcBridged.id)
    assertEquals(AssetKind.BRIDGED, usdcBridged.assetKind)
    assertEquals(IntegrationStatus.UNVERIFIED_OBSERVATION, unverified.integrationStatus)
    assertFalse(unverified.isSpendableOrSwappable)
    assertTrue(
      AssetRegistry.validateAddress(unverified.id, "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC")
        is AddressValidationResult.Invalid
    )
  }

  @Test
  fun `decimal precision and slippage arithmetic remain exact`() {
    val parsed = MoneyMath.parseHumanToBaseUnits("0.00012345", 8)
    assertEquals(BigInteger.valueOf(12_345L), parsed)
    assertEquals("0.000123", MoneyMath.formatBaseUnits(parsed!!, 8, maxFractionDigits = 6))

    val minOut = MoneyMath.applySlippageMinOutput(BigInteger.valueOf(100_000_000L), 150) // 1.50%
    assertEquals(BigInteger.valueOf(98_500_000L), minOut)
  }

  @Test
  fun `quote engine rejects expired quotes, slippage drift, duplicate keys, and insufficient fees`() {
    val engine = QuoteEngine(quoteTtlMillis = 60_000L)
    val balances = sandboxBalances()
    val now = 1_000_000L

    val res =
      engine.evaluateQuotes(
        fromAssetId = AssetRegistry.BTC_TEST_ID,
        toAssetId = AssetRegistry.LTC_TEST_ID,
        inputBaseUnits = BigInteger.valueOf(500_000L),
        slippageBps = 100,
        balances = balances,
        emergencyPaused = false,
        nowMillis = now,
      )
    assertTrue(res is QuoteResult.Success)
    val quote = (res as QuoteResult.Success).quotes.first { it.routeType == RouteType.ATOMIC_SWAP }

    // Expired quote requires renewed approval
    val expired =
      engine.revalidateBeforeExecution(
        quote = quote,
        balances = balances,
        emergencyPaused = false,
        idempotencyKey = "k1",
        nowMillis = now + 120_000L,
      )
    assertTrue(expired is QuoteRevalidationResult.RequiresRenewedApproval)

    // Material drift > slippage requires renewed approval
    val drift =
      engine.revalidateBeforeExecution(
        quote = quote,
        balances = balances,
        emergencyPaused = false,
        idempotencyKey = "k2",
        simulatedMarketDriftBps = 250,
        nowMillis = now + 5_000L,
      )
    assertTrue(drift is QuoteRevalidationResult.RequiresRenewedApproval)

    // Valid execution consumes idempotency key, duplicate is rejected
    val valid =
      engine.revalidateBeforeExecution(
        quote = quote,
        balances = balances,
        emergencyPaused = false,
        idempotencyKey = "k3",
        nowMillis = now + 5_000L,
      )
    assertTrue(valid is QuoteRevalidationResult.Valid)

    val dup =
      engine.revalidateBeforeExecution(
        quote = quote,
        balances = balances,
        emergencyPaused = false,
        idempotencyKey = "k3",
        nowMillis = now + 6_000L,
      )
    assertTrue(dup is QuoteRevalidationResult.Blocked)

    // Insufficient fee token (USDC on Sepolia without ETH gas)
    val noGasBalances =
      mapOf(
        AssetRegistry.USDC_SEP_ID to
          AssetBalance(AssetRegistry.USDC_SEP_ID, spendableBaseUnits = BigInteger.valueOf(100_000_000L)),
        AssetRegistry.ETH_SEP_ID to
          AssetBalance(AssetRegistry.ETH_SEP_ID, spendableBaseUnits = BigInteger.ZERO),
      )
    val noGasRes =
      engine.evaluateQuotes(
        fromAssetId = AssetRegistry.USDC_SEP_ID,
        toAssetId = AssetRegistry.ETH_SEP_ID,
        inputBaseUnits = BigInteger.valueOf(20_000_000L),
        slippageBps = 100,
        balances = noGasBalances,
        emergencyPaused = false,
      )
    assertTrue(noGasRes is QuoteResult.Rejected)
  }

  @Test
  fun `htlc timelock ordering, secret redaction, redemption, timeout refund, and reorg recovery`() {
    val vault = InMemorySecretVault()
    val htlc = HtlcProtocolEngine(vault)
    val engine = QuoteEngine()
    val balances = sandboxBalances()

    // Incompatible pair rejected for HTLC
    val incompatible =
      htlc.validateCompatibilityAndBuildParams("s_bad", AssetRegistry.BTC_TEST_ID, AssetRegistry.XRP_TEST_ID)
    assertTrue(incompatible is HtlcValidationResult.Incompatible)

    val quoteRes =
      engine.evaluateQuotes(
        AssetRegistry.BTC_TEST_ID,
        AssetRegistry.LTC_TEST_ID,
        BigInteger.valueOf(1_000_000L),
        100,
        balances,
        false,
      ) as QuoteResult.Success
    val atomicQuote = quoteRes.quotes.first { it.routeType == RouteType.ATOMIC_SWAP }

    // 1. Happy path redemption
    val initiated = htlc.initiateAcceptedSwap(atomicQuote, "idem_happy")
    assertTrue(initiated.htlcParams!!.hasValidAsymmetricTimelock)
    assertTrue(
      initiated.htlcParams!!.initiatorLockDurationSeconds >=
        initiated.htlcParams!!.counterpartyLockDurationSeconds +
          HtlcProtocolEngine.MIN_SAFETY_MARGIN_SECONDS
    )

    val secretHex = vault.loadSecretHex(initiated.htlcParams!!.secretKeyRef)!!
    assertTrue(vault.verifyPreimageMatchesHash(secretHex, initiated.htlcParams!!.secretHashHex))

    // Secret redaction check
    RedactingLogger.clear()
    val redacted = RedactingLogger.log("Test", "preimage=$secretHex secret=$secretHex")
    assertFalse(redacted.contains(secretHex))
    assertTrue(redacted.contains("[REDACTED]"))

    val leg1 = htlc.onLeg1FundedAndConfirmed(initiated, "0xleg1")
    val leg2 = htlc.onLeg2FundedAndConfirmed(leg1, "0xleg2")
    val reorged = htlc.simulateChainReorg(leg2, affectedLeg = 2)
    assertEquals(SwapState.REORG_DETECTED, reorged.state)
    val recovered = htlc.recoverFromReorg(reorged)
    assertEquals(SwapState.SECOND_LEG_CONFIRMED, recovered.state)
    val completed = htlc.redeemWithProtectedSecret(recovered, "0xredeem")
    assertEquals(SwapState.COMPLETED, completed.state)

    // 2. Counterparty failure & refund path
    val timeoutSwap = htlc.initiateAcceptedSwap(atomicQuote, "idem_refund")
    val timeoutLeg1 = htlc.onLeg1FundedAndConfirmed(timeoutSwap, "0xleg1_timeout")
    val refundReady = htlc.simulateCounterpartyNonPerformance(timeoutLeg1)
    assertEquals(SwapState.REFUND_AVAILABLE, refundReady.state)
    assertTrue(refundReady.refundEligible)
    val refunded = htlc.executeRefund(refundReady, "0xrefund")
    assertEquals(SwapState.REFUNDED, refunded.state)
  }

  @Test
  fun `fiat offramp separates states and handles provider failure`() {
    val adapter = FiatOffRampAdapter()
    val qRes =
      adapter.createQuote(
        AssetRegistry.USDC_SEP_ID,
        BigInteger.valueOf(100_000_000L), // $100 USDC
        EligibilityStatus.ELIGIBLE,
      )
    assertTrue(qRes is OffRampQuoteResult.Success)
    val quote = (qRes as OffRampQuoteResult.Success).quote

    val failed = adapter.initiatePayout(quote, "off_fail", simulateProviderFailure = true)
    assertEquals(ConversionLegState.FAILED, failed.conversionState)
    assertEquals(ProviderBalanceState.NONE, failed.providerBalanceState)
    assertEquals(BankPayoutState.REJECTED, failed.bankPayoutState)

    val ok = adapter.initiatePayout(quote, "off_ok", simulateProviderFailure = false)
    assertEquals(ConversionLegState.CONVERTED_TO_USD, ok.conversionState)
    assertEquals(ProviderBalanceState.RESERVED_FOR_PAYOUT, ok.providerBalanceState)
    assertEquals(BankPayoutState.SETTLING, ok.bankPayoutState)

    val settled = adapter.markBankSettled(ok)
    assertEquals(ProviderBalanceState.DISBURSED, settled.providerBalanceState)
    assertEquals(BankPayoutState.PAID_OUT, settled.bankPayoutState)
  }

  @Test
  fun `webhook verifier validates hmac signature and blocks replay`() {
    val verifier = WebhookVerifier("super_secret_webhook_key".toByteArray())
    val ts = 1_700_000_000_000L
    val nonce = "nonce_abc_123"
    val body = """{"payoutId":"pay_1","status":"PAID_OUT"}"""
    val sig = verifier.computeSignatureHex(ts, nonce, body)

    val badSig = verifier.verifyWebhook(ts, nonce, body, "deadbeef", nowMillis = ts + 1000)
    assertTrue(badSig is WebhookVerificationResult.Rejected)

    val good = verifier.verifyWebhook(ts, nonce, body, sig, nowMillis = ts + 1000)
    assertTrue(good is WebhookVerificationResult.Verified)

    val replay = verifier.verifyWebhook(ts, nonce, body, sig, nowMillis = ts + 2000)
    assertTrue(replay is WebhookVerificationResult.Rejected)
  }
}
