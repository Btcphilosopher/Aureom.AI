package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ActionOutcome
import com.example.data.local.AureomDatabase
import com.example.data.local.AureomRepository
import com.example.domain.custody.InMemorySecretVault
import com.example.domain.custody.WalletAdapterRegistry
import com.example.domain.engine.QuoteResult
import com.example.domain.model.AssetRegistry
import com.example.domain.model.RouteType
import com.example.domain.model.SwapState
import java.math.BigInteger
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w412dp-h915dp")
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aureom Wallet", appName)
  }

  @Test
  fun `room persistence survives simulated restart and emergency pause permits refund`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = AureomDatabase.createInMemory(context)
    val sharedVault = InMemorySecretVault()
    val repo1 = AureomRepository(db, sharedVault, WalletAdapterRegistry())
    repo1.seedInitialSandboxIfEmpty()

    val balances = repo1.balancesFlow.first()
    val quoteRes =
      repo1.quoteEngine.evaluateQuotes(
        fromAssetId = AssetRegistry.BTC_TEST_ID,
        toAssetId = AssetRegistry.LTC_TEST_ID,
        inputBaseUnits = BigInteger.valueOf(500_000L),
        slippageBps = 100,
        balances = balances,
        emergencyPaused = false,
      ) as QuoteResult.Success
    val atomicQuote = quoteRes.quotes.first { it.routeType == RouteType.ATOMIC_SWAP }

    // Disconnected wallet is unauthorized to sign
    val unauth =
      repo1.acceptQuoteAndPrepareSwap(
        quote = atomicQuote,
        idempotencyKey = "idem_unauth",
        emergencyPaused = false,
        walletConnected = false,
      )
    assertTrue(unauth is ActionOutcome.Failure)

    // Authorize & fund Leg 1
    val accepted =
      repo1.acceptQuoteAndPrepareSwap(
        quote = atomicQuote,
        idempotencyKey = "idem_restart_1",
        emergencyPaused = false,
        walletConnected = true,
      ) as ActionOutcome.Success
    val funded = repo1.signAndFundSwapLeg1(accepted.data.id, walletConnected = true)
    assertTrue(funded is ActionOutcome.Success)

    // Simulate backend/app restart by creating a brand new repository instance over the persisted Room DB
    val repoAfterRestart = AureomRepository(db, sharedVault, WalletAdapterRegistry())
    val resumed = repoAfterRestart.resumeInterruptedSwaps()
    assertEquals(1, resumed.size)
    assertEquals(SwapState.FIRST_LEG_CONFIRMED, resumed.first().state)

    // Emergency pause blocks new quotes, but still permits refunding the existing locked swap!
    val blockedQuote =
      repoAfterRestart.quoteEngine.evaluateQuotes(
        AssetRegistry.BTC_TEST_ID,
        AssetRegistry.LTC_TEST_ID,
        BigInteger.valueOf(500_000L),
        100,
        repoAfterRestart.balancesFlow.first(),
        emergencyPaused = true,
      )
    assertTrue(blockedQuote is QuoteResult.Rejected)

    val timedOut = repoAfterRestart.simulateCounterpartyTimeout(resumed.first().id)
    assertTrue(timedOut is ActionOutcome.Success)
    val refunded = repoAfterRestart.signAndSubmitRefund(resumed.first().id, walletConnected = true)
    assertTrue(refunded is ActionOutcome.Success)
    assertEquals(SwapState.REFUNDED, (refunded as ActionOutcome.Success).data.state)

    db.close()
  }

  @Test
  fun `compose navigation renders home assets swap activity and settings`() {
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("hero_total_usd").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_send_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_receive_button").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_assets").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("asset_card_BTC-TEST").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_swap").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("get_quotes_button").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_activity").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("nav_settings").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("theme_dark").assertIsDisplayed()
    composeTestRule
      .onNodeWithTag("settings_lazy_column")
      .performScrollToNode(hasTestTag("emergency_pause_switch"))
    composeTestRule.onNodeWithTag("emergency_pause_switch").assertIsDisplayed()
  }
}
