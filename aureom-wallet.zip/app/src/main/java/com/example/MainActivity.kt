package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.AssetRegistry
import com.example.ui.components.ReceiveAssetBottomSheet
import com.example.ui.components.SendAssetBottomSheet
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.AssetsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SwapScreen
import com.example.ui.theme.AureomWalletTheme
import com.example.ui.viewmodel.AureomViewModel

enum class AureomDestination(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  HOME("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
  ASSETS("assets", "Assets", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
  SWAP("swap", "Swap", Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz),
  ACTIVITY("activity", "Activity", Icons.Filled.History, Icons.Outlined.History),
  SETTINGS("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings),
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: AureomViewModel = viewModel()
      val uiState by viewModel.uiState.collectAsStateWithLifecycle()

      AureomWalletTheme(themeMode = uiState.settings.themeMode) {
        AureomAppShell(viewModel = viewModel, uiState = uiState)
      }
    }
  }
}

@Composable
fun AureomAppShell(
  viewModel: AureomViewModel,
  uiState: com.example.ui.viewmodel.AureomUiState,
) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: AureomDestination.HOME.route

  var showReceiveSheet by rememberSaveable { mutableStateOf(false) }
  var showSendSheet by rememberSaveable { mutableStateOf(false) }
  var swapInitialMode by rememberSaveable { mutableIntStateOf(0) }

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(uiState.bannerMessage) {
    val msg = uiState.bannerMessage ?: return@LaunchedEffect
    snackbarHostState.showSnackbar(message = msg, duration = SnackbarDuration.Short)
    viewModel.dismissBanner()
  }

  fun navigateTo(route: String) {
    navController.navigate(route) {
      popUpTo(navController.graph.startDestinationId) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useNavRail = maxWidth >= 700.dp

    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = MaterialTheme.colorScheme.background,
      snackbarHost = {
        SnackbarHost(snackbarHostState) { data ->
          Snackbar(snackbarData = data)
        }
      },
      bottomBar = {
        if (!useNavRail) {
          NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
            AureomDestination.entries.forEach { dest ->
              val selected = currentRoute == dest.route
              NavigationBarItem(
                selected = selected,
                onClick = {
                  if (dest == AureomDestination.SWAP) swapInitialMode = 0
                  navigateTo(dest.route)
                },
                icon = {
                  Icon(
                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                    contentDescription = dest.label,
                  )
                },
                label = { Text(dest.label, maxLines = 1) },
                modifier = Modifier.testTag("nav_${dest.route}"),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (useNavRail) {
          NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
            AureomDestination.entries.forEach { dest ->
              val selected = currentRoute == dest.route
              NavigationRailItem(
                selected = selected,
                onClick = {
                  if (dest == AureomDestination.SWAP) swapInitialMode = 0
                  navigateTo(dest.route)
                },
                icon = {
                  Icon(
                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                    contentDescription = dest.label,
                  )
                },
                label = { Text(dest.label) },
                modifier = Modifier.testTag("nav_${dest.route}"),
              )
            }
          }
        }

        Box(modifier = Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
          NavHost(
            navController = navController,
            startDestination = AureomDestination.HOME.route,
            modifier = Modifier.fillMaxWidth().widthIn(max = 720.dp),
          ) {
            composable(AureomDestination.HOME.route) {
              HomeScreen(
                uiState = uiState,
                onOpenSend = { showSendSheet = true },
                onOpenReceive = { showReceiveSheet = true },
                onNavigateSwap = {
                  swapInitialMode = 0
                  navigateTo(AureomDestination.SWAP.route)
                },
                onNavigateCashOut = {
                  swapInitialMode = 1
                  navigateTo(AureomDestination.SWAP.route)
                },
                onNavigateAssets = { navigateTo(AureomDestination.ASSETS.route) },
                onNavigateActivity = { navigateTo(AureomDestination.ACTIVITY.route) },
                onSimulateRestart = { viewModel.simulateBackendRestartRecovery() },
              )
            }
            composable(AureomDestination.ASSETS.route) {
              AssetsScreen(uiState = uiState)
            }
            composable(AureomDestination.SWAP.route) {
              SwapScreen(
                uiState = uiState,
                initialMode = swapInitialMode,
                onRequestQuotes = viewModel::requestQuotes,
                onAcceptAndSignQuote = viewModel::acceptAndSignQuote,
                onObserveCounterpartyLeg2 = viewModel::observeCounterpartyLeg2,
                onRedeemHtlcSwap = viewModel::redeemHtlcSwap,
                onSimulateTimeout = viewModel::simulateCounterpartyTimeout,
                onSignRefund = viewModel::signAndRefundSwap,
                onSimulateReorg = viewModel::simulateReorg,
                onRecoverReorg = viewModel::recoverFromReorg,
                onSimulateRestart = viewModel::simulateBackendRestartRecovery,
                onRequestOffRampQuote = viewModel::requestOffRampQuote,
                onExecuteOffRamp = viewModel::executeOffRampPayout,
                onSettleBankPayout = viewModel::settleBankPayout,
              )
            }
            composable(AureomDestination.ACTIVITY.route) {
              ActivityScreen(uiState = uiState)
            }
            composable(AureomDestination.SETTINGS.route) {
              SettingsScreen(
                uiState = uiState,
                observationBoundaries = viewModel.repository.walletAdapters.observationBoundaries,
                onSetThemeMode = viewModel::setThemeMode,
                onToggleWalletConnected = viewModel::toggleWalletConnected,
                onToggleEmergencyPause = viewModel::toggleEmergencyPause,
                onSaveAutoConvertRule = viewModel::saveAutoConvertRule,
              )
            }
          }
        }
      }
    }
  }

  if (showReceiveSheet) {
    ReceiveAssetBottomSheet(
      initialAssetId = AssetRegistry.BTC_TEST_ID,
      balances = uiState.balances,
      accountForChain = { chainId ->
        if (uiState.settings.walletConnected) {
          viewModel.repository.walletAdapters.adapterForChain(chainId)?.getConnectedAccount(chainId)
        } else null
      },
      onSimulateTestDeposit = viewModel::simulateTestDeposit,
      onConfirmPendingDeposits = viewModel::confirmPendingDeposits,
      onDismiss = { showReceiveSheet = false },
    )
  }

  if (showSendSheet) {
    SendAssetBottomSheet(
      initialAssetId = AssetRegistry.BTC_TEST_ID,
      balances = uiState.balances,
      onExecuteSend = viewModel::executeSend,
      onDismiss = { showSendSheet = false },
    )
  }
}
