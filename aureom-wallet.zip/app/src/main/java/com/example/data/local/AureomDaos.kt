package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BalanceDao {
  @Query("SELECT * FROM balances")
  fun observeAll(): Flow<List<BalanceEntity>>

  @Query("SELECT * FROM balances WHERE assetKey = :assetKey LIMIT 1")
  suspend fun getByAssetKey(assetKey: String): BalanceEntity?

  @Query("SELECT COUNT(*) FROM balances")
  suspend fun count(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(balance: BalanceEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAll(balances: List<BalanceEntity>)
}

@Dao
interface SwapDao {
  @Query("SELECT * FROM swaps ORDER BY updatedAtMillis DESC")
  fun observeAll(): Flow<List<SwapEntity>>

  @Query("SELECT * FROM swaps WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): SwapEntity?

  @Query("SELECT * FROM swaps WHERE stateName NOT IN ('COMPLETED', 'EXPIRED', 'REFUNDED')")
  suspend fun getActiveSwaps(): List<SwapEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(swap: SwapEntity)
}

@Dao
interface ActivityDao {
  @Query("SELECT * FROM activities ORDER BY timestampMillis DESC")
  fun observeAll(): Flow<List<ActivityEntity>>

  @Query("SELECT COUNT(*) FROM activities")
  suspend fun count(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(activity: ActivityEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(activities: List<ActivityEntity>)
}

@Dao
interface FiatPayoutDao {
  @Query("SELECT * FROM fiat_payouts ORDER BY updatedAtMillis DESC")
  fun observeAll(): Flow<List<FiatPayoutEntity>>

  @Query("SELECT * FROM fiat_payouts WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): FiatPayoutEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(payout: FiatPayoutEntity)
}

@Dao
interface AutoConvertRuleDao {
  @Query("SELECT * FROM auto_convert_rules LIMIT 1")
  fun observeRule(): Flow<AutoConvertRuleEntity?>

  @Query("SELECT * FROM auto_convert_rules LIMIT 1")
  suspend fun getRule(): AutoConvertRuleEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(rule: AutoConvertRuleEntity)
}
