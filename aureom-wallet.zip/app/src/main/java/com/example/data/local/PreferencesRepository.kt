package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.aureomPrefs: DataStore<Preferences> by preferencesDataStore(name = "aureom_prefs")

data class WalletSettingsState(
  val themeMode: ThemeMode = ThemeMode.SYSTEM,
  val walletConnected: Boolean = true,
  val emergencyPauseNewSwaps: Boolean = false,
  val allowUnlimitedApprovals: Boolean = false,
  val lastPriceUpdateMillis: Long = System.currentTimeMillis(),
)

class PreferencesRepository(private val context: Context) {
  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val WALLET_CONNECTED = booleanPreferencesKey("wallet_connected")
    val EMERGENCY_PAUSE = booleanPreferencesKey("emergency_pause_new_swaps")
    val ALLOW_UNLIMITED_APPROVALS = booleanPreferencesKey("allow_unlimited_approvals")
    val LAST_PRICE_UPDATE = longPreferencesKey("last_price_update_millis")
  }

  val settingsFlow: Flow<WalletSettingsState> =
    context.aureomPrefs.data.map { prefs ->
      val themeName = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
      val themeMode = runCatching { ThemeMode.valueOf(themeName) }.getOrDefault(ThemeMode.SYSTEM)
      WalletSettingsState(
        themeMode = themeMode,
        walletConnected = prefs[Keys.WALLET_CONNECTED] ?: true,
        emergencyPauseNewSwaps = prefs[Keys.EMERGENCY_PAUSE] ?: false,
        allowUnlimitedApprovals = prefs[Keys.ALLOW_UNLIMITED_APPROVALS] ?: false,
        lastPriceUpdateMillis = prefs[Keys.LAST_PRICE_UPDATE] ?: System.currentTimeMillis(),
      )
    }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.aureomPrefs.edit { it[Keys.THEME_MODE] = mode.name }
  }

  suspend fun setWalletConnected(connected: Boolean) {
    context.aureomPrefs.edit { it[Keys.WALLET_CONNECTED] = connected }
  }

  suspend fun setEmergencyPause(paused: Boolean) {
    context.aureomPrefs.edit { it[Keys.EMERGENCY_PAUSE] = paused }
  }

  suspend fun setAllowUnlimitedApprovals(allowed: Boolean) {
    context.aureomPrefs.edit { it[Keys.ALLOW_UNLIMITED_APPROVALS] = allowed }
  }

  suspend fun touchPriceTimestamp(nowMillis: Long = System.currentTimeMillis()) {
    context.aureomPrefs.edit { it[Keys.LAST_PRICE_UPDATE] = nowMillis }
  }
}
