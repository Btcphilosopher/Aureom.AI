package com.example.data.local

import com.example.domain.custody.SecretVault
import com.example.domain.custody.SigningPreview
import com.example.domain.custody.WalletAdapterRegistry
import com.example.domain.engine.FiatOffRampAdapter
import com.example.domain.engine.HtlcProtocolEngine
import com.example.domain.engine.QuoteEngine
import com.example.domain.engine.QuoteRevalidationResult
import com.example.domain.model.ActivityCategory
import com.example.domain.model.ActivityEvent
import com.example.domain.model.AddressValidationResult
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.AutoConvertRule
import com.example.domain.model.FiatOffRampQuote
import com.example.domain.model.FiatPayoutRecord
import com.example.domain.model.RouteType
import com.example.domain.model.SwapQuote
import com.example.domain.model.SwapRecord
import com.example.domain.model.SwapState
import com.example.domain.model.WalletOperation
import com.example.domain.util.MoneyMath
import com.example.domain.util.RedactingLogger
import java.math.BigInteger
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

sealed class ActionOutcome<out T> {
  data class Success<T>(val data: T, val message: String) : ActionOutcome<T>()
  data class Failure(val reason: String) : ActionOutcome<Nothing>()
}

class AureomRepository(
  private val database: AureomDatabase,
  private val secretVault: SecretVault,
  val walletAdapters: WalletAdapterRegistry,
  val quoteEngine: QuoteEngine = QuoteEngine(),
  val htlcEngine: HtlcProtocolEngine = HtlcProtocolEngine(secretVault),
  val offRampAdapter: FiatOffRampAdapter = FiatOffRampAdapter(),
) {
  private val balanceDao = database.balanceDao()
  private val swapDao = database.swapDao()
  private val activityDao = database.activityDao()
  private val fiatPayoutDao = database.fiatPayoutDao()
  private val autoConvertRuleDao = database.autoConvertRuleDao()

  val balancesFlow: Flow<Map<AssetId, AssetBalance>> =
    balanceDao.observeAll().map { list -> list.associate { it.toDomain().let { b -> b.assetId to b } } }

  val swapsFlow: Flow<List<SwapRecord>> =
    swapDao.observeAll().map { list -> list.map { it.toDomain() } }

  val activitiesFlow: Flow<List<ActivityEvent>> =
    activityDao.observeAll().map { list -> list.map { it.toDomain() } }

  val fiatPayoutsFlow: Flow<List<FiatPayoutRecord>> =
    fiatPayoutDao.observeAll().map { list -> list.map { it.toDomain() } }

  val autoConvertRuleFlow: Flow<AutoConvertRule> =
    autoConvertRuleDao.observeRule().map { it?.toDomain() ?: AutoConvertRule() }

  suspend fun seedInitialSandboxIfEmpty() {
    if (balanceDao.count() == 0) {
      val initialBalances =
        listOf(
          AssetBalance(
            assetId = AssetRegistry.BTC_TEST_ID,
            spendableBaseUnits = BigInteger.valueOf(2_500_000L), // 0.025 BTC-TEST
            pendingUnconfirmedBaseUnits = BigInteger.valueOf(200_000L), // 0.002 BTC-TEST
            lockedHtlcBaseUnits = BigInteger.ZERO,
            observedHeight = 2_890_140L,
          ),
          AssetBalance(
            assetId = AssetRegistry.LTC_TEST_ID,
            spendableBaseUnits = BigInteger.valueOf(150_000_000L), // 1.50 LTC-TEST
            observedHeight = 3_410_220L,
          ),
          AssetBalance(
            assetId = AssetRegistry.ETH_SEP_ID,
            spendableBaseUnits = BigInteger("850000000000000000"), // 0.85 ETH-SEP
            observedHeight = 7_112_904L,
          ),
          AssetBalance(
            assetId = AssetRegistry.WETH_SEP_ID,
            spendableBaseUnits = BigInteger("250000000000000000"), // 0.25 WETH-SEP
            observedHeight = 7_112_904L,
          ),
          AssetBalance(
            assetId = AssetRegistry.USDC_SEP_ID,
            spendableBaseUnits = BigInteger.valueOf(450_000_000L), // 450.00 USDC
            observedHeight = 7_112_904L,
          ),
          AssetBalance(
            assetId = AssetRegistry.USDC_OP_BRIDGED_ID,
            spendableBaseUnits = BigInteger.valueOf(120_000_000L), // 120.00 USDC.e
            observedHeight = 19_441_010L,
          ),
          AssetBalance(
            assetId = AssetRegistry.XRP_TEST_ID,
            spendableBaseUnits = BigInteger.valueOf(250_000_000L), // 250.00 XRP-TEST
            observedHeight = 1_890_441L,
          ),
          AssetBalance(
            assetId = AssetRegistry.UNVERIFIED_TOKEN_ID,
            spendableBaseUnits = BigInteger("1000000000000000000000"), // Observed unverified
            observedHeight = 7_112_900L,
          ),
        )
      balanceDao.upsertAll(initialBalances.map { BalanceEntity.fromDomain(it) })
    }

    if (autoConvertRuleDao.getRule() == null) {
      autoConvertRuleDao.upsert(AutoConvertRuleEntity.defaultEntity())
    }

    if (activityDao.count() == 0) {
      val now = System.currentTimeMillis()
      val seedEvents =
        listOf(
          ActivityEvent(
            id = "act_seed_1",
            category = ActivityCategory.DEPOSIT,
            title = "Observed Unconfirmed Deposit",
            plainExplanation =
              "Observed 0.002000 BTC-TEST incoming to your Bitcoin Testnet address. Waiting for 3 confirmations before funds become spendable.",
            statusLabel = "Observed · 1/3 Confs",
            isConfirmed = false,
            assetTicker = "BTC-TEST",
            amountDisplay = "+0.002000 BTC-TEST",
            txHash = "0x8a4d9c1f2e0b77c43e19a8f10d3c6b21a5e04d8190b7c321a6f8203c4d9e102a",
            confirmationsText = "1 / 3 confirmations",
            timestampMillis = now - 180_000L,
          ),
          ActivityEvent(
            id = "act_seed_2",
            category = ActivityCategory.SECURITY,
            title = "Non-Custodial Dev Wallet Connected",
            plainExplanation =
              "Connected BIP-84, EVM Sepolia, and XRPL Testnet public addresses. Private signing keys remain on-device; coordinator only observes public chain data.",
            statusLabel = "Active · Sandbox",
            isConfirmed = true,
            assetTicker = "WALLET",
            amountDisplay = "3 Chain Adapters",
            timestampMillis = now - 600_000L,
          ),
        )
      activityDao.insertAll(seedEvents.map { ActivityEntity.fromDomain(it) })
    }
  }

  suspend fun resumeInterruptedSwaps(): List<SwapRecord> {
    val active = swapDao.getActiveSwaps().map { it.toDomain() }
    if (active.isNotEmpty()) {
      RedactingLogger.log(
        "RestartRecovery",
        "Resumed monitoring ${active.size} active swap(s) from persisted Room state.",
      )
    }
    return active
  }

  suspend fun observeTestDeposit(assetId: AssetId, amountBaseUnits: BigInteger): ActionOutcome<ActivityEvent> {
    val asset = AssetRegistry.findById(assetId)
      ?: return ActionOutcome.Failure("Asset not found in explicit registry.")
    if (!asset.isSpendableOrSwappable || WalletOperation.RECEIVE !in asset.supportedOperations) {
      return ActionOutcome.Failure("${asset.ticker} (${asset.integrationStatus.label}) cannot receive deposits.")
    }
    if (amountBaseUnits <= BigInteger.ZERO) {
      return ActionOutcome.Failure("Deposit amount must be positive.")
    }

    val existing = balanceDao.getByAssetKey(assetId.serializedKey())?.toDomain()
      ?: AssetBalance(assetId = assetId)
    val updated =
      existing.copy(
        pendingUnconfirmedBaseUnits = existing.pendingUnconfirmedBaseUnits + amountBaseUnits,
        observedHeight = existing.observedHeight + 1L,
      )
    balanceDao.upsert(BalanceEntity.fromDomain(updated))

    val amountStr = MoneyMath.formatBaseUnits(amountBaseUnits, asset.decimals)
    val txHash = htlcEngine.buildDeterministicTxHash("deposit", asset.ticker)
    val event =
      ActivityEvent(
        id = "act_${UUID.randomUUID().toString().take(8)}",
        category = ActivityCategory.DEPOSIT,
        title = "Observed Incoming ${asset.ticker}",
        plainExplanation =
          "Observed $amountStr ${asset.ticker} on ${asset.networkName}. Held in Pending until ${asset.confirmationPolicy.requiredConfirmations} confirmation(s) finalize.",
        statusLabel = "Observed · 0/${asset.confirmationPolicy.requiredConfirmations} Confs",
        isConfirmed = false,
        assetTicker = asset.ticker,
        amountDisplay = "+$amountStr ${asset.ticker}",
        txHash = txHash,
        confirmationsText = "0 / ${asset.confirmationPolicy.requiredConfirmations} confirmations",
        timestampMillis = System.currentTimeMillis(),
      )
    activityDao.insert(ActivityEntity.fromDomain(event))
    return ActionOutcome.Success(event, "Observed unconfirmed deposit of $amountStr ${asset.ticker}.")
  }

  suspend fun confirmPendingDeposits(assetId: AssetId): ActionOutcome<String> {
    val asset = AssetRegistry.findById(assetId)
      ?: return ActionOutcome.Failure("Unknown asset.")
    val existing = balanceDao.getByAssetKey(assetId.serializedKey())?.toDomain()
      ?: return ActionOutcome.Failure("No balance record.")
    if (existing.pendingUnconfirmedBaseUnits <= BigInteger.ZERO) {
      return ActionOutcome.Failure("No pending unconfirmed deposits for ${asset.ticker}.")
    }

    val confirmedAmount = existing.pendingUnconfirmedBaseUnits
    val updated =
      existing.copy(
        spendableBaseUnits = existing.spendableBaseUnits + confirmedAmount,
        pendingUnconfirmedBaseUnits = BigInteger.ZERO,
        observedHeight = existing.observedHeight + asset.confirmationPolicy.requiredConfirmations.toLong(),
      )
    balanceDao.upsert(BalanceEntity.fromDomain(updated))

    val amountStr = MoneyMath.formatBaseUnits(confirmedAmount, asset.decimals)
    val rule = autoConvertRuleDao.getRule()?.toDomain()
    val ruleNote =
      if (rule != null && rule.enabled && !rule.paused && rule.sourceAssetId == assetId && confirmedAmount >= rule.minDepositBaseUnits) {
        " Auto-convert rule matched, but non-custodial signer requires your confirmation before signing."
      } else {
        ""
      }

    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.DEPOSIT,
          title = "${asset.ticker} Deposit Confirmed",
          plainExplanation =
            "$amountStr ${asset.ticker} reached ${asset.confirmationPolicy.requiredConfirmations} confirmations on ${asset.networkName} and moved to Spendable balance.$ruleNote",
          statusLabel = "Confirmed",
          isConfirmed = true,
          assetTicker = asset.ticker,
          amountDisplay = "+$amountStr ${asset.ticker}",
          confirmationsText =
            "${asset.confirmationPolicy.requiredConfirmations} / ${asset.confirmationPolicy.requiredConfirmations} confirmations",
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(amountStr, "$amountStr ${asset.ticker} confirmed and spendable.")
  }

  suspend fun executeSend(
    assetId: AssetId,
    destinationAddress: String,
    memo: String?,
    amountBaseUnits: BigInteger,
    walletConnected: Boolean,
  ): ActionOutcome<ActivityEvent> {
    if (!walletConnected) {
      return ActionOutcome.Failure("Connect your non-custodial wallet in Settings before signing.")
    }
    val asset = AssetRegistry.findById(assetId)
      ?: return ActionOutcome.Failure("Unknown asset.")
    if (!asset.isSpendableOrSwappable || WalletOperation.SEND !in asset.supportedOperations) {
      return ActionOutcome.Failure("${asset.ticker} (${asset.integrationStatus.label}) cannot be sent.")
    }
    val validation = AssetRegistry.validateAddress(assetId, destinationAddress, memo)
    if (validation is AddressValidationResult.Invalid) {
      return ActionOutcome.Failure(validation.reason)
    }
    if (amountBaseUnits < asset.minimumAmountBaseUnits) {
      val minStr = MoneyMath.formatBaseUnits(asset.minimumAmountBaseUnits, asset.decimals)
      return ActionOutcome.Failure("Amount below minimum transfer threshold ($minStr ${asset.ticker}).")
    }

    val currentMap = balancesFlow.first()
    val assetBal = currentMap[assetId]?.spendableBaseUnits ?: BigInteger.ZERO
    if (assetBal < amountBaseUnits) {
      return ActionOutcome.Failure("Insufficient spendable ${asset.ticker} balance.")
    }

    val fee = quoteEngine.estimateNetworkFee(asset.feeAssetId)
    val feeAsset = AssetRegistry.findById(asset.feeAssetId)!!
    val feeBal = currentMap[asset.feeAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
    val neededFeeBalance = if (asset.feeAssetId == assetId) amountBaseUnits + fee else fee
    if (feeBal < neededFeeBalance) {
      return ActionOutcome.Failure(
        "Insufficient ${feeAsset.ticker} to pay estimated network fee (${MoneyMath.formatBaseUnits(fee, feeAsset.decimals)} ${feeAsset.ticker})."
      )
    }

    val adapter = walletAdapters.adapterForChain(asset.id.chainId)
      ?: return ActionOutcome.Failure("No wallet adapter configured for ${asset.networkName}.")

    val amountDisplay = MoneyMath.formatBaseUnits(amountBaseUnits, asset.decimals)
    val feeDisplay = MoneyMath.formatBaseUnits(fee, feeAsset.decimals)
    val preview =
      SigningPreview(
        title = "Send ${asset.ticker}",
        actionDescription = "Transfer $amountDisplay ${asset.ticker} on ${asset.networkName}",
        networkName = asset.networkName,
        chainId = asset.id.chainId,
        assetTicker = asset.ticker,
        tokenIdentifier = asset.id.tokenIdentifier,
        amountFormatted = "$amountDisplay ${asset.ticker}",
        feeFormatted = "$feeDisplay ${feeAsset.ticker}",
        destinationAddress = destinationAddress.trim(),
        destinationMemo = memo?.takeIf { it.isNotBlank() },
        simulationOutcome = "Simulation passed: balance & gas verified",
        custodyWarning = (validation as AddressValidationResult.Valid).warningNote,
      )

    val signed =
      adapter.signPreparedAction(
        preview = preview,
        payloadToSign = "${asset.id.serializedKey()}:$destinationAddress:$amountBaseUnits:$memo",
      )

    // Deduct principal and fee accurately
    if (asset.feeAssetId == assetId) {
      val cur = currentMap[assetId]!!
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          cur.copy(spendableBaseUnits = cur.spendableBaseUnits - amountBaseUnits - fee)
        )
      )
    } else {
      val principalBal = currentMap[assetId]!!
      val gasBal = currentMap[asset.feeAssetId]!!
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          principalBal.copy(spendableBaseUnits = principalBal.spendableBaseUnits - amountBaseUnits)
        )
      )
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          gasBal.copy(spendableBaseUnits = gasBal.spendableBaseUnits - fee)
        )
      )
    }

    val event =
      ActivityEvent(
        id = "act_${UUID.randomUUID().toString().take(8)}",
        category = ActivityCategory.SEND,
        title = "Sent ${asset.ticker}",
        plainExplanation =
          "Signed and broadcast $amountDisplay ${asset.ticker} to ${destinationAddress.take(10)}...${destinationAddress.takeLast(6)} on ${asset.networkName} (Fee: $feeDisplay ${feeAsset.ticker}).",
        statusLabel = "Confirmed",
        isConfirmed = true,
        assetTicker = asset.ticker,
        amountDisplay = "-$amountDisplay ${asset.ticker}",
        txHash = signed.txHash,
        confirmationsText =
          "${asset.confirmationPolicy.requiredConfirmations} / ${asset.confirmationPolicy.requiredConfirmations} confirmations",
        timestampMillis = System.currentTimeMillis(),
      )
    activityDao.insert(ActivityEntity.fromDomain(event))
    return ActionOutcome.Success(event, "Sent $amountDisplay ${asset.ticker}.")
  }

  suspend fun acceptQuoteAndPrepareSwap(
    quote: SwapQuote,
    idempotencyKey: String,
    emergencyPaused: Boolean,
    walletConnected: Boolean,
    simulatedMarketDriftBps: Int = 0,
  ): ActionOutcome<SwapRecord> {
    if (!walletConnected) {
      return ActionOutcome.Failure("Connect your non-custodial wallet in Settings to sign swaps.")
    }
    val balances = balancesFlow.first()
    when (
      val check =
        quoteEngine.revalidateBeforeExecution(
          quote = quote,
          balances = balances,
          emergencyPaused = emergencyPaused,
          idempotencyKey = idempotencyKey,
          simulatedMarketDriftBps = simulatedMarketDriftBps,
        )
    ) {
      is QuoteRevalidationResult.Blocked -> return ActionOutcome.Failure(check.reason)
      is QuoteRevalidationResult.RequiresRenewedApproval ->
        return ActionOutcome.Failure(check.reason)
      is QuoteRevalidationResult.Valid -> Unit
    }

    val record = htlcEngine.initiateAcceptedSwap(quote = quote, idempotencyKey = idempotencyKey)
    swapDao.upsert(SwapEntity.fromDomain(record))

    val inputAsset = AssetRegistry.findById(quote.inputAssetId)!!
    val outputAsset = AssetRegistry.findById(quote.outputAssetId)!!
    val inDisplay = MoneyMath.formatBaseUnits(quote.inputAmountBaseUnits, inputAsset.decimals)
    val outDisplay = MoneyMath.formatBaseUnits(quote.expectedOutputBaseUnits, outputAsset.decimals)

    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.SWAP,
          title = "${quote.routeType.shortTag} Accepted",
          plainExplanation =
            "Accepted quote to swap $inDisplay ${inputAsset.ticker} -> ~$outDisplay ${outputAsset.ticker} via ${quote.routeType.displayName}. Prepared funding step for your signature.",
          statusLabel = record.state.label,
          isConfirmed = false,
          assetTicker = inputAsset.ticker,
          amountDisplay = "$inDisplay ${inputAsset.ticker} -> ${outputAsset.ticker}",
          routeType = quote.routeType,
          relatedSwapId = record.id,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(record, "Quote accepted. Ready to sign Leg 1 funding.")
  }

  suspend fun signAndFundSwapLeg1(swapId: String, walletConnected: Boolean): ActionOutcome<SwapRecord> {
    if (!walletConnected) return ActionOutcome.Failure("Wallet disconnected.")
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap record not found.")
    if (current.state != SwapState.FUNDING_PREPARED) {
      return ActionOutcome.Failure("Swap is not awaiting Leg 1 funding (current: ${current.state.label}).")
    }

    val quote = current.quote
    val inputAsset = AssetRegistry.findById(quote.inputAssetId)!!
    val feeAsset = AssetRegistry.findById(quote.networkFeeAssetId)!!
    val balances = balancesFlow.first()

    val inBal = balances[quote.inputAssetId] ?: return ActionOutcome.Failure("Missing input balance.")
    val requiredPrincipal =
      if (quote.inputAssetId == quote.networkFeeAssetId) {
        quote.inputAmountBaseUnits + quote.networkFeeBaseUnits
      } else {
        quote.inputAmountBaseUnits
      }
    if (inBal.spendableBaseUnits < requiredPrincipal) {
      return ActionOutcome.Failure("Insufficient spendable ${inputAsset.ticker} for swap + fee.")
    }

    val adapter = walletAdapters.adapterForChain(inputAsset.id.chainId)
      ?: return ActionOutcome.Failure("Missing chain adapter for ${inputAsset.networkName}.")

    val inDisplay = MoneyMath.formatBaseUnits(quote.inputAmountBaseUnits, inputAsset.decimals)
    val feeDisplay = MoneyMath.formatBaseUnits(quote.networkFeeBaseUnits, feeAsset.decimals)
    val preview =
      SigningPreview(
        title = "Sign ${quote.routeType.shortTag} Leg 1",
        actionDescription = "Lock $inDisplay ${inputAsset.ticker} for ${quote.routeType.displayName}",
        networkName = inputAsset.networkName,
        chainId = inputAsset.id.chainId,
        assetTicker = inputAsset.ticker,
        tokenIdentifier = inputAsset.id.tokenIdentifier,
        amountFormatted = "$inDisplay ${inputAsset.ticker}",
        feeFormatted = "$feeDisplay ${feeAsset.ticker}",
        destinationAddress =
          if (current.htlcParams != null) {
            "HTLC Script Hash ${current.htlcParams.secretHashHex.take(12)}..."
          } else {
            quote.protocolsOrProviders.firstOrNull()
          },
        simulationOutcome = "Simulation passed: exact-allowance & finality rules checked",
        allowanceCapNote =
          if (quote.routeType == RouteType.ON_CHAIN_SWAP && inputAsset.id.tokenIdentifier != "native") {
            "Exact ERC-20 approval capped at $inDisplay ${inputAsset.ticker} (unlimited approvals disabled)"
          } else {
            null
          },
        custodyWarning = quote.custodyAssumptions,
      )

    val signed = adapter.signPreparedAction(preview, "fund:$swapId:${quote.quoteDigest}")

    // Move principal from spendable -> lockedHtlc (and deduct fee)
    if (quote.inputAssetId == quote.networkFeeAssetId) {
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          inBal.copy(
            spendableBaseUnits = inBal.spendableBaseUnits - quote.inputAmountBaseUnits - quote.networkFeeBaseUnits,
            lockedHtlcBaseUnits = inBal.lockedHtlcBaseUnits + quote.inputAmountBaseUnits,
          )
        )
      )
    } else {
      val feeBal = balances[quote.networkFeeAssetId]
        ?: return ActionOutcome.Failure("Missing fee balance.")
      if (feeBal.spendableBaseUnits < quote.networkFeeBaseUnits) {
        return ActionOutcome.Failure("Insufficient ${feeAsset.ticker} for network fee.")
      }
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          inBal.copy(
            spendableBaseUnits = inBal.spendableBaseUnits - quote.inputAmountBaseUnits,
            lockedHtlcBaseUnits = inBal.lockedHtlcBaseUnits + quote.inputAmountBaseUnits,
          )
        )
      )
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          feeBal.copy(spendableBaseUnits = feeBal.spendableBaseUnits - quote.networkFeeBaseUnits)
        )
      )
    }

    val updated = htlcEngine.onLeg1FundedAndConfirmed(current, signed.txHash)
    swapDao.upsert(SwapEntity.fromDomain(updated))

    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.SWAP,
          title = "Leg 1 Locked & Confirmed",
          plainExplanation =
            "Locked $inDisplay ${inputAsset.ticker} on ${inputAsset.networkName} (${updated.leg1Confirmations}/${updated.leg1RequiredConfirmations} confs). Monitoring counterparty leg.",
          statusLabel = updated.state.label,
          isConfirmed = true,
          assetTicker = inputAsset.ticker,
          amountDisplay = "$inDisplay ${inputAsset.ticker} locked",
          routeType = quote.routeType,
          txHash = signed.txHash,
          confirmationsText = "${updated.leg1Confirmations}/${updated.leg1RequiredConfirmations}",
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )

    // For single-chain DEX or Provider-Mediated swaps, auto-advance Leg 2 & complete cleanly if requested;
    // for Atomic HTLC swaps, pause at FIRST_LEG_CONFIRMED so user can observe both legs, test timeout/reorg, or proceed.
    if (quote.routeType != RouteType.ATOMIC_SWAP) {
      val leg2Hash = htlcEngine.buildDeterministicTxHash("leg2", swapId)
      val leg2Confirmed = htlcEngine.onLeg2FundedAndConfirmed(updated, leg2Hash)
      val completed =
        htlcEngine.redeemWithProtectedSecret(
          leg2Confirmed,
          htlcEngine.buildDeterministicTxHash("settle", swapId),
        )
      finalizeCompletedSwapBalances(completed)
      swapDao.upsert(SwapEntity.fromDomain(completed))
      val outAsset = AssetRegistry.findById(quote.outputAssetId)!!
      val outDisplay = MoneyMath.formatBaseUnits(quote.expectedOutputBaseUnits, outAsset.decimals)
      activityDao.insert(
        ActivityEntity.fromDomain(
          ActivityEvent(
            id = "act_${UUID.randomUUID().toString().take(8)}",
            category = ActivityCategory.SWAP,
            title = "${quote.routeType.shortTag} Completed",
            plainExplanation =
              "Settled $outDisplay ${outAsset.ticker} via ${quote.routeType.displayName}. Output is now spendable.",
            statusLabel = "Completed",
            isConfirmed = true,
            assetTicker = outAsset.ticker,
            amountDisplay = "+$outDisplay ${outAsset.ticker}",
            routeType = quote.routeType,
            txHash = completed.redemptionTxHash,
            relatedSwapId = swapId,
            timestampMillis = System.currentTimeMillis() + 1L,
          )
        )
      )
      return ActionOutcome.Success(completed, "Swap completed via ${quote.routeType.displayName}.")
    }

    return ActionOutcome.Success(updated, "Leg 1 locked & confirmed. Observing counterparty chain.")
  }

  suspend fun observeCounterpartyLeg2(swapId: String): ActionOutcome<SwapRecord> {
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    if (current.state != SwapState.FIRST_LEG_CONFIRMED) {
      return ActionOutcome.Failure("Leg 2 observation requires First Leg Confirmed state.")
    }
    val leg2TxHash = htlcEngine.buildDeterministicTxHash("htlc_leg2", swapId)
    val updated = htlcEngine.onLeg2FundedAndConfirmed(current, leg2TxHash)
    swapDao.upsert(SwapEntity.fromDomain(updated))

    val outAsset = AssetRegistry.findById(updated.quote.outputAssetId)!!
    val outStr = MoneyMath.formatBaseUnits(updated.quote.expectedOutputBaseUnits, outAsset.decimals)
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.SWAP,
          title = "Counterparty Leg 2 Confirmed",
          plainExplanation =
            "Independent chain observer verified $outStr ${outAsset.ticker} locked in counterparty HTLC (${updated.leg2Confirmations}/${updated.leg2RequiredConfirmations} confs). Ready for you to reveal secret & redeem.",
          statusLabel = updated.state.label,
          isConfirmed = true,
          assetTicker = outAsset.ticker,
          amountDisplay = "+$outStr ${outAsset.ticker} pending claim",
          routeType = updated.quote.routeType,
          txHash = leg2TxHash,
          confirmationsText = "${updated.leg2Confirmations}/${updated.leg2RequiredConfirmations}",
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(updated, "Counterparty Leg 2 confirmed. Ready to redeem.")
  }

  suspend fun signAndRedeemHtlcSwap(swapId: String, walletConnected: Boolean): ActionOutcome<SwapRecord> {
    if (!walletConnected) return ActionOutcome.Failure("Wallet disconnected.")
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    if (current.state != SwapState.SECOND_LEG_CONFIRMED) {
      return ActionOutcome.Failure("Both legs must be confirmed before redeeming.")
    }
    val outAsset = AssetRegistry.findById(current.quote.outputAssetId)!!
    val adapter = walletAdapters.adapterForChain(outAsset.id.chainId)
      ?: return ActionOutcome.Failure("No wallet adapter for ${outAsset.networkName}.")

    val outDisplay = MoneyMath.formatBaseUnits(current.quote.expectedOutputBaseUnits, outAsset.decimals)
    val preview =
      SigningPreview(
        title = "Redeem HTLC Output",
        actionDescription = "Reveal protected preimage on ${outAsset.networkName} to claim $outDisplay ${outAsset.ticker}",
        networkName = outAsset.networkName,
        chainId = outAsset.id.chainId,
        assetTicker = outAsset.ticker,
        tokenIdentifier = outAsset.id.tokenIdentifier,
        amountFormatted = "+$outDisplay ${outAsset.ticker}",
        feeFormatted = "Paid on redemption tx",
        destinationAddress = adapter.getConnectedAccount(outAsset.id.chainId).publicAddress,
        simulationOutcome = "Preimage SHA-256 commitment verified against local vault",
        custodyWarning = "Revealing the preimage allows counterparty to claim your Leg 1 funds atomically.",
      )
    val signed = adapter.signPreparedAction(preview, "redeem:$swapId")
    val completed = htlcEngine.redeemWithProtectedSecret(current, signed.txHash)
    if (completed.state == SwapState.COMPLETED) {
      finalizeCompletedSwapBalances(completed)
    }
    swapDao.upsert(SwapEntity.fromDomain(completed))

    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.SWAP,
          title = "Atomic Swap Completed",
          plainExplanation =
            "Redeemed $outDisplay ${outAsset.ticker} on ${outAsset.networkName} using your Keystore-protected secret. Output is now spendable.",
          statusLabel = completed.state.label,
          isConfirmed = completed.state == SwapState.COMPLETED,
          isError = completed.state == SwapState.MANUAL_REVIEW,
          assetTicker = outAsset.ticker,
          amountDisplay = "+$outDisplay ${outAsset.ticker}",
          routeType = current.quote.routeType,
          txHash = signed.txHash,
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(completed, "Atomic swap completed! $outDisplay ${outAsset.ticker} received.")
  }

  suspend fun simulateCounterpartyTimeout(swapId: String): ActionOutcome<SwapRecord> {
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    val updated = htlcEngine.simulateCounterpartyNonPerformance(current)
    swapDao.upsert(SwapEntity.fromDomain(updated))

    val inAsset = AssetRegistry.findById(updated.quote.inputAssetId)!!
    val inStr = MoneyMath.formatBaseUnits(updated.quote.inputAmountBaseUnits, inAsset.decimals)
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.RECOVERY,
          title = "Counterparty Timeout — Refund Available",
          plainExplanation =
            "Counterparty failed to lock Leg 2 before timelock expiry. Your $inStr ${inAsset.ticker} remains locked safely; sign the HTLC refund transaction to recover funds.",
          statusLabel = "Refund Available",
          isConfirmed = false,
          isError = true,
          assetTicker = inAsset.ticker,
          amountDisplay = "$inStr ${inAsset.ticker} refundable",
          routeType = updated.quote.routeType,
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(updated, "Counterparty timed out. HTLC refund path unlocked.")
  }

  suspend fun signAndSubmitRefund(swapId: String, walletConnected: Boolean): ActionOutcome<SwapRecord> {
    if (!walletConnected) return ActionOutcome.Failure("Wallet disconnected.")
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    if (!current.refundEligible && current.state != SwapState.REFUND_AVAILABLE) {
      return ActionOutcome.Failure("Refund is not yet unlocked.")
    }

    val inAsset = AssetRegistry.findById(current.quote.inputAssetId)!!
    val adapter = walletAdapters.adapterForChain(inAsset.id.chainId)
      ?: return ActionOutcome.Failure("No adapter for ${inAsset.networkName}.")
    val inStr = MoneyMath.formatBaseUnits(current.quote.inputAmountBaseUnits, inAsset.decimals)
    val preview =
      SigningPreview(
        title = "Sign HTLC Timeout Refund",
        actionDescription = "Reclaim locked $inStr ${inAsset.ticker} after timelock expiry",
        networkName = inAsset.networkName,
        chainId = inAsset.id.chainId,
        assetTicker = inAsset.ticker,
        tokenIdentifier = inAsset.id.tokenIdentifier,
        amountFormatted = "+$inStr ${inAsset.ticker}",
        feeFormatted = "Miner refund fee applied",
        destinationAddress = adapter.getConnectedAccount(inAsset.id.chainId).publicAddress,
        simulationOutcome = "Timelock block height elapsed; refund script branch valid",
        custodyWarning = "Refund requires your online signature; backend cannot move locked HTLC funds.",
      )
    val signed = adapter.signPreparedAction(preview, "refund:$swapId")
    val refunded = htlcEngine.executeRefund(current, signed.txHash)

    // Unlock principal back to spendable
    val bal = balanceDao.getByAssetKey(current.quote.inputAssetId.serializedKey())?.toDomain()
    if (bal != null) {
      val unlockAmount = current.quote.inputAmountBaseUnits.min(bal.lockedHtlcBaseUnits)
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          bal.copy(
            spendableBaseUnits = bal.spendableBaseUnits + unlockAmount,
            lockedHtlcBaseUnits = bal.lockedHtlcBaseUnits - unlockAmount,
          )
        )
      )
    }

    swapDao.upsert(SwapEntity.fromDomain(refunded))
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.RECOVERY,
          title = "HTLC Refund Confirmed",
          plainExplanation =
            "Signed timeout refund returned $inStr ${inAsset.ticker} from the HTLC contract back to your Spendable balance.",
          statusLabel = "Refunded",
          isConfirmed = true,
          assetTicker = inAsset.ticker,
          amountDisplay = "+$inStr ${inAsset.ticker}",
          routeType = refunded.quote.routeType,
          txHash = signed.txHash,
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(refunded, "HTLC refund confirmed. Funds restored to spendable.")
  }

  suspend fun simulateAndHandleReorg(swapId: String): ActionOutcome<SwapRecord> {
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    val affectedLeg = if (current.leg2TxHash != null) 2 else 1
    val reorged = htlcEngine.simulateChainReorg(current, affectedLeg = affectedLeg)
    swapDao.upsert(SwapEntity.fromDomain(reorged))
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.RECOVERY,
          title = "Chain Reorg Detected on Leg $affectedLeg",
          plainExplanation =
            reorged.reorgNotice ?: "Reorganisation detected; secret reveal paused until finality returns.",
          statusLabel = "Reorg Detected",
          isConfirmed = false,
          isError = true,
          assetTicker = AssetRegistry.findById(current.quote.inputAssetId)?.ticker ?: "ASSET",
          amountDisplay = "Finality Paused",
          routeType = current.quote.routeType,
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(reorged, "Reorg simulated — secret reveal safely paused.")
  }

  suspend fun recoverReorgedSwap(swapId: String): ActionOutcome<SwapRecord> {
    val current = swapDao.getById(swapId)?.toDomain()
      ?: return ActionOutcome.Failure("Swap not found.")
    val restored = htlcEngine.recoverFromReorg(current)
    swapDao.upsert(SwapEntity.fromDomain(restored))
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.RECOVERY,
          title = "Finality Restored After Reorg",
          plainExplanation =
            "Independent chain observer confirmed required finality blocks after reorganisation. Safe to continue.",
          statusLabel = restored.state.label,
          isConfirmed = true,
          assetTicker = AssetRegistry.findById(current.quote.outputAssetId)?.ticker ?: "ASSET",
          amountDisplay = "Finality OK",
          routeType = current.quote.routeType,
          relatedSwapId = swapId,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(restored, "Chain finality restored.")
  }

  suspend fun initiateFiatOffRamp(
    quote: FiatOffRampQuote,
    idempotencyKey: String,
    walletConnected: Boolean,
    simulateProviderFailure: Boolean = false,
  ): ActionOutcome<FiatPayoutRecord> {
    if (!walletConnected) return ActionOutcome.Failure("Wallet disconnected.")
    val balances = balancesFlow.first()
    val inBal = balances[quote.inputAssetId] ?: return ActionOutcome.Failure("Missing input balance.")
    val asset = AssetRegistry.findById(quote.inputAssetId)!!
    if (inBal.spendableBaseUnits < quote.inputAmountBaseUnits) {
      return ActionOutcome.Failure("Insufficient spendable ${asset.ticker} for off-ramp.")
    }

    val record =
      offRampAdapter.initiatePayout(
        quote = quote,
        idempotencyKey = idempotencyKey,
        simulateProviderFailure = simulateProviderFailure,
      )
    fiatPayoutDao.upsert(FiatPayoutEntity.fromDomain(record))

    val netUsdStr = MoneyMath.formatUsdCents(quote.netUsdPayoutCents)
    val inStr = MoneyMath.formatBaseUnits(quote.inputAmountBaseUnits, asset.decimals)

    if (record.failureReason == null) {
      balanceDao.upsert(
        BalanceEntity.fromDomain(
          inBal.copy(spendableBaseUnits = inBal.spendableBaseUnits - quote.inputAmountBaseUnits)
        )
      )
      activityDao.insert(
        ActivityEntity.fromDomain(
          ActivityEvent(
            id = "act_${UUID.randomUUID().toString().take(8)}",
            category = ActivityCategory.FIAT_PAYOUT,
            title = "Bank USD Off-Ramp Initiated",
            plainExplanation =
              "Converted $inStr ${asset.ticker} via ${quote.providerName}. Net $netUsdStr queued for ACH payout to ${quote.destinationMask} (${quote.estimatedPayoutWindow}).",
            statusLabel = record.bankPayoutState.label,
            isConfirmed = true,
            assetTicker = "USD (Bank)",
            amountDisplay = "+$netUsdStr ACH",
            routeType = RouteType.FIAT_OFF_RAMP,
            providerReference = quote.providerReference,
            timestampMillis = System.currentTimeMillis(),
          )
        )
      )
      return ActionOutcome.Success(record, "Off-ramp initiated ($netUsdStr ACH to ${quote.destinationMask}).")
    } else {
      activityDao.insert(
        ActivityEntity.fromDomain(
          ActivityEvent(
            id = "act_${UUID.randomUUID().toString().take(8)}",
            category = ActivityCategory.FIAT_PAYOUT,
            title = "Off-Ramp Provider Rejected",
            plainExplanation = record.failureReason ?: "Off-ramp failed.",
            statusLabel = "Rejected",
            isConfirmed = false,
            isError = true,
            assetTicker = asset.ticker,
            amountDisplay = "$inStr ${asset.ticker} returned",
            routeType = RouteType.FIAT_OFF_RAMP,
            providerReference = quote.providerReference,
            timestampMillis = System.currentTimeMillis(),
          )
        )
      )
      return ActionOutcome.Failure(record.failureReason ?: "Off-ramp rejected.")
    }
  }

  suspend fun settleBankPayout(payoutId: String): ActionOutcome<FiatPayoutRecord> {
    val current = fiatPayoutDao.getById(payoutId)?.toDomain()
      ?: return ActionOutcome.Failure("Payout record not found.")
    val settled = offRampAdapter.markBankSettled(current)
    fiatPayoutDao.upsert(FiatPayoutEntity.fromDomain(settled))
    val netUsdStr = MoneyMath.formatUsdCents(settled.quote.netUsdPayoutCents)
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.FIAT_PAYOUT,
          title = "Bank ACH Payout Settled",
          plainExplanation =
            "$netUsdStr USD settled into ${settled.quote.destinationMask}. Provider balance disbursed.",
          statusLabel = "Paid Out",
          isConfirmed = true,
          assetTicker = "USD (Bank)",
          amountDisplay = "+$netUsdStr Settled",
          routeType = RouteType.FIAT_OFF_RAMP,
          providerReference = settled.quote.providerReference,
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
    return ActionOutcome.Success(settled, "Bank ACH payout marked settled.")
  }

  suspend fun saveAutoConvertRule(rule: AutoConvertRule) {
    autoConvertRuleDao.upsert(AutoConvertRuleEntity.fromDomain(rule))
    activityDao.insert(
      ActivityEntity.fromDomain(
        ActivityEvent(
          id = "act_${UUID.randomUUID().toString().take(8)}",
          category = ActivityCategory.SECURITY,
          title = "Auto-Convert Rule Updated",
          plainExplanation =
            if (!rule.enabled || rule.paused) {
              "Receive-and-convert rule set to Manual Approval / Paused. Incoming deposits remain in your wallet untouched."
            } else {
              "Configured receive rule for ${AssetRegistry.findById(rule.sourceAssetId)?.ticker} -> ${rule.destinationType.label}. Non-custodial signing still requires device signer availability."
            },
          statusLabel = if (rule.enabled && !rule.paused) "Armed (Local Signer)" else "Manual Approval",
          isConfirmed = true,
          assetTicker = "POLICY",
          amountDisplay = if (rule.enabled && !rule.paused) "Active" else "Manual",
          timestampMillis = System.currentTimeMillis(),
        )
      )
    )
  }

  private suspend fun finalizeCompletedSwapBalances(completed: SwapRecord) {
    val inKey = completed.quote.inputAssetId.serializedKey()
    val outKey = completed.quote.outputAssetId.serializedKey()

    val inBal = balanceDao.getByAssetKey(inKey)?.toDomain()
    if (inBal != null) {
      val release = completed.quote.inputAmountBaseUnits.min(inBal.lockedHtlcBaseUnits)
      balanceDao.upsert(
        BalanceEntity.fromDomain(inBal.copy(lockedHtlcBaseUnits = inBal.lockedHtlcBaseUnits - release))
      )
    }

    val outBal = balanceDao.getByAssetKey(outKey)?.toDomain()
      ?: AssetBalance(assetId = completed.quote.outputAssetId)
    balanceDao.upsert(
      BalanceEntity.fromDomain(
        outBal.copy(spendableBaseUnits = outBal.spendableBaseUnits + completed.quote.expectedOutputBaseUnits)
      )
    )
  }
}
