package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ActivityCategory
import com.example.domain.model.ActivityEvent
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.AutoConvertRule
import com.example.domain.model.BankPayoutState
import com.example.domain.model.ConversionLegState
import com.example.domain.model.EligibilityStatus
import com.example.domain.model.FiatOffRampQuote
import com.example.domain.model.FiatPayoutRecord
import com.example.domain.model.HtlcParameters
import com.example.domain.model.ProviderBalanceState
import com.example.domain.model.RouteType
import com.example.domain.model.SwapQuote
import com.example.domain.model.SwapRecord
import com.example.domain.model.SwapState
import java.math.BigDecimal
import java.math.BigInteger

@Entity(tableName = "balances")
data class BalanceEntity(
  @PrimaryKey val assetKey: String,
  val spendableBaseUnits: String,
  val pendingUnconfirmedBaseUnits: String,
  val lockedHtlcBaseUnits: String,
  val observedHeight: Long,
  val isDemoEnvironment: Boolean,
) {
  fun toDomain(): AssetBalance =
    AssetBalance(
      assetId = AssetId.fromKey(assetKey),
      spendableBaseUnits = BigInteger(spendableBaseUnits),
      pendingUnconfirmedBaseUnits = BigInteger(pendingUnconfirmedBaseUnits),
      lockedHtlcBaseUnits = BigInteger(lockedHtlcBaseUnits),
      observedHeight = observedHeight,
      isDemoEnvironment = isDemoEnvironment,
    )

  companion object {
    fun fromDomain(balance: AssetBalance): BalanceEntity =
      BalanceEntity(
        assetKey = balance.assetId.serializedKey(),
        spendableBaseUnits = balance.spendableBaseUnits.toString(),
        pendingUnconfirmedBaseUnits = balance.pendingUnconfirmedBaseUnits.toString(),
        lockedHtlcBaseUnits = balance.lockedHtlcBaseUnits.toString(),
        observedHeight = balance.observedHeight,
        isDemoEnvironment = balance.isDemoEnvironment,
      )
  }
}

@Entity(tableName = "swaps")
data class SwapEntity(
  @PrimaryKey val id: String,
  val idempotencyKey: String,
  val quoteId: String,
  val inputAssetKey: String,
  val inputAmountBaseUnits: String,
  val outputAssetKey: String,
  val expectedOutputBaseUnits: String,
  val minimumOutputBaseUnits: String,
  val routeTypeName: String,
  val protocolsJoined: String,
  val networkFeeBaseUnits: String,
  val networkFeeAssetKey: String,
  val serviceFeeBaseUnits: String,
  val slippageBps: Int,
  val priceImpactBps: Int?,
  val quoteCreatedAtMillis: Long,
  val quoteExpiresAtMillis: Long,
  val estimatedCompletionSeconds: Int,
  val custodyAssumptions: String,
  val comparisonScopeNote: String,
  val quoteDigest: String,
  val stateName: String,
  // Non-secret HTLC metadata for restart recovery (actual secret stays in SecretVault)
  val hasHtlc: Boolean,
  val htlcProtocolSpec: String?,
  val htlcSecretHashHex: String?,
  val htlcSecretKeyRef: String?,
  val htlcInitiatorRole: String?,
  val htlcCounterpartyRole: String?,
  val htlcInitiatorLockHeight: Long?,
  val htlcCounterpartyLockHeight: Long?,
  val htlcInitiatorBlockTimeSec: Int?,
  val htlcCounterpartyBlockTimeSec: Int?,
  val htlcInitiatorLockDurationSec: Long?,
  val htlcCounterpartyLockDurationSec: Long?,
  val htlcSafetyMarginSec: Long?,
  val htlcInitiatorDeadlineMillis: Long?,
  val htlcCounterpartyDeadlineMillis: Long?,
  val leg1TxHash: String?,
  val leg1Confirmations: Int,
  val leg1RequiredConfirmations: Int,
  val leg2TxHash: String?,
  val leg2Confirmations: Int,
  val leg2RequiredConfirmations: Int,
  val redemptionTxHash: String?,
  val refundTxHash: String?,
  val lockStatusSummary: String,
  val expectedNextAction: String,
  val refundEligible: Boolean,
  val reorgNotice: String?,
  val failureReason: String?,
  val createdAtMillis: Long,
  val updatedAtMillis: Long,
) {
  fun toDomain(): SwapRecord {
    val quote =
      SwapQuote(
        quoteId = quoteId,
        inputAssetId = AssetId.fromKey(inputAssetKey),
        inputAmountBaseUnits = BigInteger(inputAmountBaseUnits),
        outputAssetId = AssetId.fromKey(outputAssetKey),
        expectedOutputBaseUnits = BigInteger(expectedOutputBaseUnits),
        minimumOutputBaseUnits = BigInteger(minimumOutputBaseUnits),
        routeType = RouteType.valueOf(routeTypeName),
        protocolsOrProviders = protocolsJoined.split("|").filter { it.isNotBlank() },
        networkFeeBaseUnits = BigInteger(networkFeeBaseUnits),
        networkFeeAssetId = AssetId.fromKey(networkFeeAssetKey),
        serviceFeeBaseUnits = BigInteger(serviceFeeBaseUnits),
        slippageBps = slippageBps,
        priceImpactBps = priceImpactBps,
        createdAtMillis = quoteCreatedAtMillis,
        expiresAtMillis = quoteExpiresAtMillis,
        estimatedCompletionSeconds = estimatedCompletionSeconds,
        custodyAssumptions = custodyAssumptions,
        comparisonScopeNote = comparisonScopeNote,
        quoteDigest = quoteDigest,
      )
    val htlcParams =
      if (hasHtlc && htlcSecretHashHex != null && htlcSecretKeyRef != null) {
        HtlcParameters(
          protocolSpec = htlcProtocolSpec ?: "BIP-199 P2WSH SHA-256 HTLC",
          hashAlgorithm = "SHA-256",
          initiatorRole = htlcInitiatorRole ?: "User Wallet",
          counterpartyRole = htlcCounterpartyRole ?: "Counterparty Node",
          secretHashHex = htlcSecretHashHex,
          secretKeyRef = htlcSecretKeyRef,
          initiatorLockHeight = htlcInitiatorLockHeight ?: 0L,
          counterpartyLockHeight = htlcCounterpartyLockHeight ?: 0L,
          initiatorBlockTimeSeconds = htlcInitiatorBlockTimeSec ?: 600,
          counterpartyBlockTimeSeconds = htlcCounterpartyBlockTimeSec ?: 150,
          initiatorLockDurationSeconds = htlcInitiatorLockDurationSec ?: 86_400L,
          counterpartyLockDurationSeconds = htlcCounterpartyLockDurationSec ?: 43_200L,
          safetyMarginSeconds = htlcSafetyMarginSec ?: 21_600L,
          initiatorLockDeadlineMillis = htlcInitiatorDeadlineMillis ?: 0L,
          counterpartyLockDeadlineMillis = htlcCounterpartyDeadlineMillis ?: 0L,
        )
      } else {
        null
      }
    return SwapRecord(
      id = id,
      idempotencyKey = idempotencyKey,
      quote = quote,
      state = SwapState.valueOf(stateName),
      htlcParams = htlcParams,
      leg1TxHash = leg1TxHash,
      leg1Confirmations = leg1Confirmations,
      leg1RequiredConfirmations = leg1RequiredConfirmations,
      leg2TxHash = leg2TxHash,
      leg2Confirmations = leg2Confirmations,
      leg2RequiredConfirmations = leg2RequiredConfirmations,
      redemptionTxHash = redemptionTxHash,
      refundTxHash = refundTxHash,
      lockStatusSummary = lockStatusSummary,
      expectedNextAction = expectedNextAction,
      refundEligible = refundEligible,
      reorgNotice = reorgNotice,
      failureReason = failureReason,
      createdAtMillis = createdAtMillis,
      updatedAtMillis = updatedAtMillis,
    )
  }

  companion object {
    fun fromDomain(record: SwapRecord): SwapEntity {
      val q = record.quote
      val h = record.htlcParams
      return SwapEntity(
        id = record.id,
        idempotencyKey = record.idempotencyKey,
        quoteId = q.quoteId,
        inputAssetKey = q.inputAssetId.serializedKey(),
        inputAmountBaseUnits = q.inputAmountBaseUnits.toString(),
        outputAssetKey = q.outputAssetId.serializedKey(),
        expectedOutputBaseUnits = q.expectedOutputBaseUnits.toString(),
        minimumOutputBaseUnits = q.minimumOutputBaseUnits.toString(),
        routeTypeName = q.routeType.name,
        protocolsJoined = q.protocolsOrProviders.joinToString("|"),
        networkFeeBaseUnits = q.networkFeeBaseUnits.toString(),
        networkFeeAssetKey = q.networkFeeAssetId.serializedKey(),
        serviceFeeBaseUnits = q.serviceFeeBaseUnits.toString(),
        slippageBps = q.slippageBps,
        priceImpactBps = q.priceImpactBps,
        quoteCreatedAtMillis = q.createdAtMillis,
        quoteExpiresAtMillis = q.expiresAtMillis,
        estimatedCompletionSeconds = q.estimatedCompletionSeconds,
        custodyAssumptions = q.custodyAssumptions,
        comparisonScopeNote = q.comparisonScopeNote,
        quoteDigest = q.quoteDigest,
        stateName = record.state.name,
        hasHtlc = h != null,
        htlcProtocolSpec = h?.protocolSpec,
        htlcSecretHashHex = h?.secretHashHex,
        htlcSecretKeyRef = h?.secretKeyRef,
        htlcInitiatorRole = h?.initiatorRole,
        htlcCounterpartyRole = h?.counterpartyRole,
        htlcInitiatorLockHeight = h?.initiatorLockHeight,
        htlcCounterpartyLockHeight = h?.counterpartyLockHeight,
        htlcInitiatorBlockTimeSec = h?.initiatorBlockTimeSeconds,
        htlcCounterpartyBlockTimeSec = h?.counterpartyBlockTimeSeconds,
        htlcInitiatorLockDurationSec = h?.initiatorLockDurationSeconds,
        htlcCounterpartyLockDurationSec = h?.counterpartyLockDurationSeconds,
        htlcSafetyMarginSec = h?.safetyMarginSeconds,
        htlcInitiatorDeadlineMillis = h?.initiatorLockDeadlineMillis,
        htlcCounterpartyDeadlineMillis = h?.counterpartyLockDeadlineMillis,
        leg1TxHash = record.leg1TxHash,
        leg1Confirmations = record.leg1Confirmations,
        leg1RequiredConfirmations = record.leg1RequiredConfirmations,
        leg2TxHash = record.leg2TxHash,
        leg2Confirmations = record.leg2Confirmations,
        leg2RequiredConfirmations = record.leg2RequiredConfirmations,
        redemptionTxHash = record.redemptionTxHash,
        refundTxHash = record.refundTxHash,
        lockStatusSummary = record.lockStatusSummary,
        expectedNextAction = record.expectedNextAction,
        refundEligible = record.refundEligible,
        reorgNotice = record.reorgNotice,
        failureReason = record.failureReason,
        createdAtMillis = record.createdAtMillis,
        updatedAtMillis = record.updatedAtMillis,
      )
    }
  }
}

@Entity(tableName = "activities")
data class ActivityEntity(
  @PrimaryKey val id: String,
  val categoryName: String,
  val title: String,
  val plainExplanation: String,
  val statusLabel: String,
  val isConfirmed: Boolean,
  val isError: Boolean,
  val assetTicker: String,
  val amountDisplay: String,
  val routeTypeName: String?,
  val txHash: String?,
  val confirmationsText: String?,
  val providerReference: String?,
  val relatedSwapId: String?,
  val timestampMillis: Long,
) {
  fun toDomain(): ActivityEvent =
    ActivityEvent(
      id = id,
      category = ActivityCategory.valueOf(categoryName),
      title = title,
      plainExplanation = plainExplanation,
      statusLabel = statusLabel,
      isConfirmed = isConfirmed,
      isError = isError,
      assetTicker = assetTicker,
      amountDisplay = amountDisplay,
      routeType = routeTypeName?.let { RouteType.valueOf(it) },
      txHash = txHash,
      confirmationsText = confirmationsText,
      providerReference = providerReference,
      relatedSwapId = relatedSwapId,
      timestampMillis = timestampMillis,
    )

  companion object {
    fun fromDomain(event: ActivityEvent): ActivityEntity =
      ActivityEntity(
        id = event.id,
        categoryName = event.category.name,
        title = event.title,
        plainExplanation = event.plainExplanation,
        statusLabel = event.statusLabel,
        isConfirmed = event.isConfirmed,
        isError = event.isError,
        assetTicker = event.assetTicker,
        amountDisplay = event.amountDisplay,
        routeTypeName = event.routeType?.name,
        txHash = event.txHash,
        confirmationsText = event.confirmationsText,
        providerReference = event.providerReference,
        relatedSwapId = event.relatedSwapId,
        timestampMillis = event.timestampMillis,
      )
  }
}

@Entity(tableName = "fiat_payouts")
data class FiatPayoutEntity(
  @PrimaryKey val id: String,
  val idempotencyKey: String,
  val quoteId: String,
  val providerName: String,
  val inputAssetKey: String,
  val inputAmountBaseUnits: String,
  val grossUsdCents: Long,
  val providerFeeUsdCents: Long,
  val netUsdPayoutCents: Long,
  val exchangeRateUsd: String,
  val minUsdCents: Long,
  val maxUsdCents: Long,
  val estimatedPayoutWindow: String,
  val eligibilityStatusName: String,
  val jurisdiction: String,
  val destinationMask: String,
  val expiresAtMillis: Long,
  val providerReference: String,
  val conversionStateName: String,
  val providerBalanceStateName: String,
  val bankPayoutStateName: String,
  val failureReason: String?,
  val createdAtMillis: Long,
  val updatedAtMillis: Long,
) {
  fun toDomain(): FiatPayoutRecord =
    FiatPayoutRecord(
      id = id,
      idempotencyKey = idempotencyKey,
      quote =
        FiatOffRampQuote(
          quoteId = quoteId,
          providerName = providerName,
          inputAssetId = AssetId.fromKey(inputAssetKey),
          inputAmountBaseUnits = BigInteger(inputAmountBaseUnits),
          grossUsdCents = grossUsdCents,
          providerFeeUsdCents = providerFeeUsdCents,
          netUsdPayoutCents = netUsdPayoutCents,
          exchangeRateUsd = BigDecimal(exchangeRateUsd),
          minUsdCents = minUsdCents,
          maxUsdCents = maxUsdCents,
          estimatedPayoutWindow = estimatedPayoutWindow,
          eligibilityStatus = EligibilityStatus.valueOf(eligibilityStatusName),
          jurisdiction = jurisdiction,
          destinationMask = destinationMask,
          expiresAtMillis = expiresAtMillis,
          providerReference = providerReference,
        ),
      conversionState = ConversionLegState.valueOf(conversionStateName),
      providerBalanceState = ProviderBalanceState.valueOf(providerBalanceStateName),
      bankPayoutState = BankPayoutState.valueOf(bankPayoutStateName),
      failureReason = failureReason,
      createdAtMillis = createdAtMillis,
      updatedAtMillis = updatedAtMillis,
    )

  companion object {
    fun fromDomain(record: FiatPayoutRecord): FiatPayoutEntity {
      val q = record.quote
      return FiatPayoutEntity(
        id = record.id,
        idempotencyKey = record.idempotencyKey,
        quoteId = q.quoteId,
        providerName = q.providerName,
        inputAssetKey = q.inputAssetId.serializedKey(),
        inputAmountBaseUnits = q.inputAmountBaseUnits.toString(),
        grossUsdCents = q.grossUsdCents,
        providerFeeUsdCents = q.providerFeeUsdCents,
        netUsdPayoutCents = q.netUsdPayoutCents,
        exchangeRateUsd = q.exchangeRateUsd.toPlainString(),
        minUsdCents = q.minUsdCents,
        maxUsdCents = q.maxUsdCents,
        estimatedPayoutWindow = q.estimatedPayoutWindow,
        eligibilityStatusName = q.eligibilityStatus.name,
        jurisdiction = q.jurisdiction,
        destinationMask = q.destinationMask,
        expiresAtMillis = q.expiresAtMillis,
        providerReference = q.providerReference,
        conversionStateName = record.conversionState.name,
        providerBalanceStateName = record.providerBalanceState.name,
        bankPayoutStateName = record.bankPayoutState.name,
        failureReason = record.failureReason,
        createdAtMillis = record.createdAtMillis,
        updatedAtMillis = record.updatedAtMillis,
      )
    }
  }
}

@Entity(tableName = "auto_convert_rules")
data class AutoConvertRuleEntity(
  @PrimaryKey val id: String,
  val enabled: Boolean,
  val paused: Boolean,
  val sourceAssetKey: String,
  val destinationTargetName: String,
  val minDepositBaseUnits: String,
  val minOutputBaseUnits: String,
  val maxFeeUsdCents: Long,
  val maxQuoteAgeSeconds: Int,
  val dailyLimitUsdCents: Long,
  val usedTodayUsdCents: Long,
  val allowedRoutesJoined: String,
) {
  fun toDomain(): AutoConvertRule =
    AutoConvertRule(
      id = id,
      enabled = enabled,
      paused = paused,
      sourceAssetId = AssetId.fromKey(sourceAssetKey),
      destinationType = AutoConvertRule.DestinationTarget.valueOf(destinationTargetName),
      minDepositBaseUnits = BigInteger(minDepositBaseUnits),
      minOutputBaseUnits = BigInteger(minOutputBaseUnits),
      maxFeeUsdCents = maxFeeUsdCents,
      maxQuoteAgeSeconds = maxQuoteAgeSeconds,
      dailyLimitUsdCents = dailyLimitUsdCents,
      usedTodayUsdCents = usedTodayUsdCents,
      allowedRoutes =
        allowedRoutesJoined.split("|").filter { it.isNotBlank() }.map { RouteType.valueOf(it) }.toSet(),
    )

  companion object {
    fun fromDomain(rule: AutoConvertRule): AutoConvertRuleEntity =
      AutoConvertRuleEntity(
        id = rule.id,
        enabled = rule.enabled,
        paused = rule.paused,
        sourceAssetKey = rule.sourceAssetId.serializedKey(),
        destinationTargetName = rule.destinationType.name,
        minDepositBaseUnits = rule.minDepositBaseUnits.toString(),
        minOutputBaseUnits = rule.minOutputBaseUnits.toString(),
        maxFeeUsdCents = rule.maxFeeUsdCents,
        maxQuoteAgeSeconds = rule.maxQuoteAgeSeconds,
        dailyLimitUsdCents = rule.dailyLimitUsdCents,
        usedTodayUsdCents = rule.usedTodayUsdCents,
        allowedRoutesJoined = rule.allowedRoutes.joinToString("|") { it.name },
      )

    fun defaultEntity(): AutoConvertRuleEntity =
      fromDomain(AutoConvertRule(sourceAssetId = AssetRegistry.BTC_TEST_ID))
  }
}
