package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities =
    [
      BalanceEntity::class,
      SwapEntity::class,
      ActivityEntity::class,
      FiatPayoutEntity::class,
      AutoConvertRuleEntity::class,
    ],
  version = 1,
  exportSchema = false,
)
abstract class AureomDatabase : RoomDatabase() {
  abstract fun balanceDao(): BalanceDao
  abstract fun swapDao(): SwapDao
  abstract fun activityDao(): ActivityDao
  abstract fun fiatPayoutDao(): FiatPayoutDao
  abstract fun autoConvertRuleDao(): AutoConvertRuleDao

  companion object {
    @Volatile private var instance: AureomDatabase? = null

    fun getInstance(context: Context): AureomDatabase {
      return instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                AureomDatabase::class.java,
                "aureom_wallet.db",
              )
              .build()
              .also { instance = it }
        }
    }

    fun createInMemory(context: Context): AureomDatabase =
      Room.inMemoryDatabaseBuilder(context.applicationContext, AureomDatabase::class.java)
        .allowMainThreadQueries()
        .build()
  }
}
