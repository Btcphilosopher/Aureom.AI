package com.example.domain.custody

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.example.domain.util.RedactingLogger
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class SecretCommitment(
  val secretKeyRef: String,
  val secretHashHex: String,
)

/**
 * Protects user-held HTLC preimage secrets in OS-backed Android Keystore AES-GCM storage
 * (with an isolated in-memory fallback for non-Android unit tests).
 * Secrets are never persisted in ordinary Room tables or logged in plaintext.
 */
interface SecretVault {
  fun createHtlcSecret(swapId: String): SecretCommitment
  fun loadSecretHex(secretKeyRef: String): String?
  fun verifyPreimageMatchesHash(secretHex: String, expectedHashHex: String): Boolean {
    val bytes = secretHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
    val actualHex = digest.joinToString("") { "%02x".format(it) }
    return MessageDigest.isEqual(
      actualHex.lowercase().toByteArray(),
      expectedHashHex.lowercase().toByteArray(),
    )
  }
  fun deleteSecret(secretKeyRef: String)
}

class AndroidKeystoreSecretVault(context: Context) : SecretVault {
  private val secretsDir = File(context.filesDir, "aureom_vault").apply { mkdirs() }
  private val secureRandom = SecureRandom()
  private val memoryFallback = LinkedHashMap<String, ByteArray>()

  override fun createHtlcSecret(swapId: String): SecretCommitment {
    val secretBytes = ByteArray(32)
    secureRandom.nextBytes(secretBytes)
    val hashBytes = MessageDigest.getInstance("SHA-256").digest(secretBytes)
    val hashHex = hashBytes.joinToString("") { "%02x".format(it) }
    val keyRef = "htlc_secret_$swapId"

    storeProtectedBytes(keyRef, secretBytes)
    // Clear local copy from memory immediately
    secretBytes.fill(0)
    RedactingLogger.log("SecretVault", "Created HTLC commitment secretHash=$hashHex ref=$keyRef")
    return SecretCommitment(secretKeyRef = keyRef, secretHashHex = hashHex)
  }

  override fun loadSecretHex(secretKeyRef: String): String? {
    val bytes = loadProtectedBytes(secretKeyRef) ?: return null
    val hex = bytes.joinToString("") { "%02x".format(it) }
    bytes.fill(0)
    return hex
  }

  override fun deleteSecret(secretKeyRef: String) {
    memoryFallback.remove(secretKeyRef)
    val file = File(secretsDir, "$secretKeyRef.enc")
    if (file.exists()) file.delete()
  }

  private fun storeProtectedBytes(keyRef: String, plaintext: ByteArray) {
    val aesKey = getOrCreateKeystoreAesKey()
    if (aesKey != null) {
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.ENCRYPT_MODE, aesKey)
      val iv = cipher.iv
      val ciphertext = cipher.doFinal(plaintext)
      val payload = ByteArray(1 + iv.size + ciphertext.size)
      payload[0] = iv.size.toByte()
      System.arraycopy(iv, 0, payload, 1, iv.size)
      System.arraycopy(ciphertext, 0, payload, 1 + iv.size, ciphertext.size)
      File(secretsDir, "$keyRef.enc").writeBytes(payload)
    } else {
      memoryFallback[keyRef] = plaintext.copyOf()
    }
  }

  private fun loadProtectedBytes(keyRef: String): ByteArray? {
    val file = File(secretsDir, "$keyRef.enc")
    if (file.exists()) {
      val aesKey = getOrCreateKeystoreAesKey() ?: return null
      val payload = file.readBytes()
      if (payload.size < 2) return null
      val ivLen = payload[0].toInt() and 0xFF
      val iv = payload.copyOfRange(1, 1 + ivLen)
      val ciphertext = payload.copyOfRange(1 + ivLen, payload.size)
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.DECRYPT_MODE, aesKey, GCMParameterSpec(128, iv))
      return cipher.doFinal(ciphertext)
    }
    return memoryFallback[keyRef]?.copyOf()
  }

  private fun getOrCreateKeystoreAesKey(): SecretKey? {
    return try {
      val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
      (keyStore.getKey(KEY_ALIAS, null) as? SecretKey) ?: run {
        val generator =
          KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec =
          KeyGenParameterSpec.Builder(
              KEY_ALIAS,
              KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        generator.generateKey()
      }
    } catch (_: Throwable) {
      null
    }
  }

  companion object {
    private const val KEY_ALIAS = "aureom_htlc_vault_aes256"
  }
}

class InMemorySecretVault : SecretVault {
  private val secureRandom = SecureRandom()
  private val secrets = LinkedHashMap<String, String>()

  override fun createHtlcSecret(swapId: String): SecretCommitment {
    val secretBytes = ByteArray(32)
    secureRandom.nextBytes(secretBytes)
    val hashBytes = MessageDigest.getInstance("SHA-256").digest(secretBytes)
    val hashHex = hashBytes.joinToString("") { "%02x".format(it) }
    val secretHex = secretBytes.joinToString("") { "%02x".format(it) }
    val keyRef = "htlc_secret_$swapId"
    secrets[keyRef] = secretHex
    return SecretCommitment(secretKeyRef = keyRef, secretHashHex = hashHex)
  }

  override fun loadSecretHex(secretKeyRef: String): String? = secrets[secretKeyRef]

  override fun deleteSecret(secretKeyRef: String) {
    secrets.remove(secretKeyRef)
  }
}
