package com.example.domain.model

import java.math.BigDecimal
import java.math.BigInteger

enum class EligibilityStatus(val label: String) {
  ELIGIBLE("Verified · US ACH Eligible"),
  KYC_PENDING("Identity Verification Pending"),
  JURISDICTION_BLOCKED("Jurisdiction Restricted"),
}

enum class ConversionLegState(val label: String) {
  NOT_STARTED("Not Started"),
  ASSET_LOCKED("Asset Sent to Provider"),
  CONVERTED_TO_USD("Converted to USD"),
  FAILED("Conversion Failed"),
}

enum class ProviderBalanceState(val label: String) {
  NONE("No Provider Balance"),
  USD_CREDITED("Provider USD Credited (Unsettled)"),
  RESERVED_FOR_PAYOUT("Reserved for Bank Payout"),
  DISBURSED("Disbursed"),
}

enum class BankPayoutState(val label: String) {
  NOT_INITIATED("Not Initiated"),
  QUEUED("ACH Payout Queued"),
  SETTLING("Bank Rail Settling (1–2 Business Days)"),
  PAID_OUT("Settled in Bank Account"),
  REJECTED("Payout Rejected"),
}

data class FiatOffRampQuote(
  val quoteId: String,
  val providerName: String,
  val inputAssetId: AssetId,
  val inputAmountBaseUnits: BigInteger,
  val grossUsdCents: Long,
  val providerFeeUsdCents: Long,
  val netUsdPayoutCents: Long,
  val exchangeRateUsd: BigDecimal,
  val minUsdCents: Long,
  val maxUsdCents: Long,
  val estimatedPayoutWindow: String,
  val eligibilityStatus: EligibilityStatus,
  val jurisdiction: String,
  val destinationMask: String,
  val expiresAtMillis: Long,
  val providerReference: String,
)

data class FiatPayoutRecord(
  val id: String,
  val idempotencyKey: String,
  val quote: FiatOffRampQuote,
  val conversionState: ConversionLegState,
  val providerBalanceState: ProviderBalanceState,
  val bankPayoutState: BankPayoutState,
  val failureReason: String? = null,
  val createdAtMillis: Long,
  val updatedAtMillis: Long,
)
