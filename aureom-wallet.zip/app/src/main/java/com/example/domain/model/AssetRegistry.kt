package com.example.domain.model

import java.math.BigDecimal
import java.math.BigInteger

/**
 * Versioned explicit asset registry.
 * - Identifies every asset by (chainId, tokenIdentifier), never by ticker alone.
 * - Keeps native, wrapped, bridged, and stablecoin assets strictly distinct.
 * - Surfaces unavailable, deprecated, and unverified observations transparently without allowing swaps.
 */
object AssetRegistry {
  const val REGISTRY_VERSION = "1.2.0"

  val BTC_TEST_ID = AssetId("bitcoin:testnet4", "native")
  val LTC_TEST_ID = AssetId("litecoin:testnet4", "native")
  val ETH_SEP_ID = AssetId("eip155:11155111", "native")
  val WETH_SEP_ID = AssetId("eip155:11155111", "0x7b79995e5f793A07Bc00c21412e50Ecae098E7f9")
  val USDC_SEP_ID = AssetId("eip155:11155111", "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238")
  val USDC_OP_BRIDGED_ID =
    AssetId("eip155:11155420", "0x5fd84259d66Cd46123540766Be93DFE6D43130D7-bridged")
  val XRP_TEST_ID = AssetId("xrpl:testnet", "native")
  val SOL_DEV_ID = AssetId("solana:devnet", "native")
  val UST_LEGACY_ID = AssetId("terra:columbus-5", "uusd")
  val UNVERIFIED_TOKEN_ID =
    AssetId("eip155:11155111", "0xdead00000000000000000000000000000000beef")

  val assets: List<AssetDefinition> =
    listOf(
      AssetDefinition(
        id = BTC_TEST_ID,
        assetName = "Bitcoin Testnet",
        ticker = "BTC-TEST",
        networkName = "Bitcoin Testnet4",
        assetKind = AssetKind.NATIVE,
        decimals = 8,
        supportedOperations =
          setOf(
            WalletOperation.RECEIVE,
            WalletOperation.SEND,
            WalletOperation.SWAP_INPUT,
            WalletOperation.SWAP_OUTPUT,
            WalletOperation.FIAT_OFF_RAMP,
          ),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 3,
            blockTimeSeconds = 600,
            finalityNote = "3 confirmations (~30 min) required before HTLC secret reveal or spend.",
          ),
        supportedRoutes =
          setOf(RouteType.ATOMIC_SWAP, RouteType.PROVIDER_MEDIATED, RouteType.FIAT_OFF_RAMP),
        minimumAmountBaseUnits = BigInteger.valueOf(50_000L), // 0.0005 BTC
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = BTC_TEST_ID,
        indicativeUsdPrice = BigDecimal("88400.00"),
      ),
      AssetDefinition(
        id = LTC_TEST_ID,
        assetName = "Litecoin Testnet",
        ticker = "LTC-TEST",
        networkName = "Litecoin Testnet4",
        assetKind = AssetKind.NATIVE,
        decimals = 8,
        supportedOperations =
          setOf(
            WalletOperation.RECEIVE,
            WalletOperation.SEND,
            WalletOperation.SWAP_INPUT,
            WalletOperation.SWAP_OUTPUT,
          ),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 6,
            blockTimeSeconds = 150,
            finalityNote =
              "6 confirmations (~15 min) required; SHA-256 HTLC compatible with Bitcoin Testnet.",
          ),
        supportedRoutes = setOf(RouteType.ATOMIC_SWAP, RouteType.PROVIDER_MEDIATED),
        minimumAmountBaseUnits = BigInteger.valueOf(500_000L), // 0.005 LTC
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = LTC_TEST_ID,
        indicativeUsdPrice = BigDecimal("96.50"),
      ),
      AssetDefinition(
        id = ETH_SEP_ID,
        assetName = "Sepolia Ether",
        ticker = "ETH-SEP",
        networkName = "Ethereum Sepolia",
        assetKind = AssetKind.NATIVE,
        decimals = 18,
        supportedOperations =
          setOf(
            WalletOperation.RECEIVE,
            WalletOperation.SEND,
            WalletOperation.SWAP_INPUT,
            WalletOperation.SWAP_OUTPUT,
            WalletOperation.FIAT_OFF_RAMP,
          ),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 12,
            blockTimeSeconds = 12,
            finalityNote = "12 confirmations (~2.4 min) for execution safety on Sepolia.",
          ),
        supportedRoutes =
          setOf(RouteType.ON_CHAIN_SWAP, RouteType.PROVIDER_MEDIATED, RouteType.FIAT_OFF_RAMP),
        minimumAmountBaseUnits = BigInteger("5000000000000000"), // 0.005 ETH
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = ETH_SEP_ID,
        indicativeUsdPrice = BigDecimal("3120.00"),
      ),
      AssetDefinition(
        id = WETH_SEP_ID,
        assetName = "Wrapped Ether (Sepolia)",
        ticker = "WETH-SEP",
        networkName = "Ethereum Sepolia",
        assetKind = AssetKind.WRAPPED,
        decimals = 18,
        supportedOperations =
          setOf(
            WalletOperation.RECEIVE,
            WalletOperation.SEND,
            WalletOperation.SWAP_INPUT,
            WalletOperation.SWAP_OUTPUT,
          ),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 12,
            blockTimeSeconds = 12,
            finalityNote = "ERC-20 contract token; distinct from native ETH gas asset.",
          ),
        supportedRoutes = setOf(RouteType.ON_CHAIN_SWAP, RouteType.PROVIDER_MEDIATED),
        minimumAmountBaseUnits = BigInteger("5000000000000000"), // 0.005 WETH
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = ETH_SEP_ID,
        issuer = "WETH9 Canonical Contract",
        riskDisclosure = "Wrapped ERC-20 token; requires native ETH-SEP for gas fees.",
        indicativeUsdPrice = BigDecimal("3120.00"),
      ),
      AssetDefinition(
        id = USDC_SEP_ID,
        assetName = "USD Coin (Sepolia)",
        ticker = "USDC",
        networkName = "Ethereum Sepolia",
        assetKind = AssetKind.STABLECOIN,
        decimals = 6,
        supportedOperations =
          setOf(
            WalletOperation.RECEIVE,
            WalletOperation.SEND,
            WalletOperation.SWAP_INPUT,
            WalletOperation.SWAP_OUTPUT,
            WalletOperation.FIAT_OFF_RAMP,
          ),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 12,
            blockTimeSeconds = 12,
            finalityNote = "12 confirmations on Sepolia; requires ETH-SEP to pay transfer gas.",
          ),
        supportedRoutes =
          setOf(RouteType.ON_CHAIN_SWAP, RouteType.PROVIDER_MEDIATED, RouteType.FIAT_OFF_RAMP),
        minimumAmountBaseUnits = BigInteger.valueOf(5_000_000L), // 5.00 USDC
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = ETH_SEP_ID,
        issuer = "Circle Internet Financial (Testnet)",
        riskDisclosure =
          "Digital stablecoin token — distinct from US dollars in a bank account. Not FDIC insured and not guaranteed to hold a $1.00 peg.",
        indicativeUsdPrice = BigDecimal("1.00"),
      ),
      AssetDefinition(
        id = USDC_OP_BRIDGED_ID,
        assetName = "Bridged USDC.e (OP Sepolia)",
        ticker = "USDC.e",
        networkName = "Optimism Sepolia",
        assetKind = AssetKind.BRIDGED,
        decimals = 6,
        supportedOperations = setOf(WalletOperation.RECEIVE, WalletOperation.SEND),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 10,
            blockTimeSeconds = 2,
            finalityNote = "Bridged L2 token; kept strictly separate from native Sepolia USDC.",
          ),
        supportedRoutes = setOf(RouteType.PROVIDER_MEDIATED),
        minimumAmountBaseUnits = BigInteger.valueOf(5_000_000L),
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = ETH_SEP_ID,
        issuer = "Optimism Bridge Escrowed Token",
        riskDisclosure =
          "Bridged representation subject to bridge contract & issuer risks. Not redeemable 1:1 directly without bridge settlement.",
        indicativeUsdPrice = BigDecimal("0.999"),
      ),
      AssetDefinition(
        id = XRP_TEST_ID,
        assetName = "XRP Testnet",
        ticker = "XRP-TEST",
        networkName = "XRP Ledger Testnet",
        assetKind = AssetKind.NATIVE,
        decimals = 6,
        supportedOperations =
          setOf(WalletOperation.RECEIVE, WalletOperation.SEND, WalletOperation.SWAP_INPUT),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 1,
            blockTimeSeconds = 4,
            finalityNote = "1 validated ledger (~4 sec). Destination Tag required for custodial deposits.",
          ),
        supportedRoutes = setOf(RouteType.PROVIDER_MEDIATED),
        minimumAmountBaseUnits = BigInteger.valueOf(10_000_000L), // 10 XRP
        integrationStatus = IntegrationStatus.TESTNET,
        feeAssetId = XRP_TEST_ID,
        requiresMemo = true,
        memoLabel = "Destination Tag",
        indicativeUsdPrice = BigDecimal("0.62"),
      ),
      AssetDefinition(
        id = SOL_DEV_ID,
        assetName = "Solana Devnet",
        ticker = "SOL-DEV",
        networkName = "Solana Devnet",
        assetKind = AssetKind.NATIVE,
        decimals = 9,
        supportedOperations = emptySet(),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 32,
            blockTimeSeconds = 1,
            finalityNote = "Finalized commitment; adapter pending security review.",
          ),
        supportedRoutes = emptySet(),
        minimumAmountBaseUnits = BigInteger.valueOf(100_000_000L),
        integrationStatus = IntegrationStatus.UNAVAILABLE,
        feeAssetId = SOL_DEV_ID,
        riskDisclosure = "Chain adapter unavailable in v1.2.0; deposits disabled.",
        indicativeUsdPrice = BigDecimal("175.00"),
      ),
      AssetDefinition(
        id = UST_LEGACY_ID,
        assetName = "TerraUSD Classic (Legacy)",
        ticker = "USTC",
        networkName = "Terra Classic",
        assetKind = AssetKind.STABLECOIN,
        decimals = 6,
        supportedOperations = emptySet(),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 6,
            blockTimeSeconds = 6,
            finalityNote = "Deprecated asset — swaps and sends permanently disabled.",
          ),
        supportedRoutes = emptySet(),
        minimumAmountBaseUnits = BigInteger.valueOf(1_000_000L),
        integrationStatus = IntegrationStatus.DEPRECATED,
        feeAssetId = UST_LEGACY_ID,
        issuer = "Legacy Algorithmic Protocol",
        riskDisclosure = "Deprecated algorithmic token that lost its USD peg. Swaps disabled.",
        indicativeUsdPrice = BigDecimal("0.02"),
      ),
      AssetDefinition(
        id = UNVERIFIED_TOKEN_ID,
        assetName = "Observed Unknown ERC-20",
        ticker = "UNK-ERC20",
        networkName = "Ethereum Sepolia",
        assetKind = AssetKind.UNKNOWN,
        decimals = 18,
        supportedOperations = emptySet(),
        confirmationPolicy =
          ConfirmationPolicy(
            requiredConfirmations = 12,
            blockTimeSeconds = 12,
            finalityNote = "Unverified contract observation; blocked from spending or swapping.",
          ),
        supportedRoutes = emptySet(),
        minimumAmountBaseUnits = BigInteger.ZERO,
        integrationStatus = IntegrationStatus.UNVERIFIED_OBSERVATION,
        feeAssetId = ETH_SEP_ID,
        riskDisclosure =
          "Unverified token observed on-chain. Never auto-approved for swaps or spending.",
        indicativeUsdPrice = BigDecimal.ZERO,
      ),
    )

  private val byId: Map<AssetId, AssetDefinition> = assets.associateBy { it.id }

  fun findById(id: AssetId): AssetDefinition? = byId[id]

  fun findBySerializedKey(key: String): AssetDefinition? = byId[AssetId.fromKey(key)]

  fun operationalAssets(): List<AssetDefinition> =
    assets.filter { it.isSpendableOrSwappable }

  fun swappableInputAssets(): List<AssetDefinition> =
    assets.filter {
      it.isSpendableOrSwappable && WalletOperation.SWAP_INPUT in it.supportedOperations
    }

  fun swappableOutputAssets(): List<AssetDefinition> =
    assets.filter {
      it.isSpendableOrSwappable && WalletOperation.SWAP_OUTPUT in it.supportedOperations
    }

  fun validateAddress(assetId: AssetId, address: String, memo: String? = null): AddressValidationResult {
    val asset = findById(assetId) ?: return AddressValidationResult.Invalid("Unknown asset ID")
    if (!asset.isSpendableOrSwappable) {
      return AddressValidationResult.Invalid(
        "${asset.ticker} (${asset.integrationStatus.label}) cannot accept transfers."
      )
    }
    val trimmed = address.trim()
    if (trimmed.isEmpty()) {
      return AddressValidationResult.Invalid("Destination address is required.")
    }
    if (asset.requiresMemo && memo.isNullOrBlank()) {
      return AddressValidationResult.Invalid(
        "${asset.memoLabel ?: "Memo"} is required for ${asset.networkName} transfers."
      )
    }

    val formatOk =
      when {
        asset.id.chainId.startsWith("bitcoin:") ->
          Regex("^(tb1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{14,74}|[mn2][a-km-zA-HJ-NP-Z1-9]{25,34})$")
            .matches(trimmed)
        asset.id.chainId.startsWith("litecoin:") ->
          Regex("^(tltc1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{14,74}|[mnQ2][a-km-zA-HJ-NP-Z1-9]{25,34})$")
            .matches(trimmed)
        asset.id.chainId.startsWith("eip155:") ->
          Regex("^0x[a-fA-F0-9]{40}$").matches(trimmed)
        asset.id.chainId.startsWith("xrpl:") ->
          Regex("^r[1-9A-HJ-NP-Za-km-z]{24,34}$").matches(trimmed)
        else -> false
      }

    if (!formatOk) {
      return AddressValidationResult.Invalid(
        "Address does not match ${asset.networkName} format."
      )
    }
    if (asset.requiresMemo && !memo.isNullOrBlank() && !Regex("^[0-9]{1,10}$").matches(memo.trim())) {
      return AddressValidationResult.Invalid("Destination Tag must be a 1–10 digit integer.")
    }

    return AddressValidationResult.Valid(
      normalizedAddress = trimmed,
      warningNote =
        "Syntactically valid ${asset.networkName} address. Format validation does NOT confirm this address belongs to your intended recipient.",
    )
  }
}
