package com.example.domain.engine

import com.example.domain.custody.SecretVault
import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.HtlcParameters
import com.example.domain.model.RouteType
import com.example.domain.model.SwapQuote
import com.example.domain.model.SwapRecord
import com.example.domain.model.SwapState
import com.example.domain.util.RedactingLogger
import java.security.MessageDigest
import java.util.UUID

sealed class HtlcValidationResult {
  data class Compatible(val params: HtlcParameters) : HtlcValidationResult()
  data class Incompatible(val reason: String) : HtlcValidationResult()
}

/**
 * Pure BIP-199 SHA-256 HTLC Atomic Swap State Machine & Chain Compatibility Validator.
 * - Enforces asymmetric timelocks: Initiator Lock T_A >= Counterparty Lock T_B + Safety Margin.
 * - Accounts for differing block times (BTC 600s vs LTC 150s) and confirmation finality.
 * - Never marks an initiated swap COMPLETED before both legs meet finality and secret redemption succeeds.
 */
class HtlcProtocolEngine(
  private val secretVault: SecretVault,
) {
  companion object {
    const val MIN_SAFETY_MARGIN_SECONDS = 21_600L // 6 hours minimum margin for finality + inclusion + reorg
    const val INITIATOR_LOCK_SECONDS = 86_400L // 24 hours
    const val COUNTERPARTY_LOCK_SECONDS = 43_200L // 12 hours
  }

  fun validateCompatibilityAndBuildParams(
    swapId: String,
    inputAssetId: AssetId,
    outputAssetId: AssetId,
    nowMillis: Long = System.currentTimeMillis(),
  ): HtlcValidationResult {
    val pair = setOf(inputAssetId, outputAssetId)
    if (pair != setOf(AssetRegistry.BTC_TEST_ID, AssetRegistry.LTC_TEST_ID)) {
      return HtlcValidationResult.Incompatible(
        "Atomic HTLC swap only implemented for verified SHA-256 pair BTC-TEST <-> LTC-TEST."
      )
    }

    val inputAsset = AssetRegistry.findById(inputAssetId)!!
    val outputAsset = AssetRegistry.findById(outputAssetId)!!

    val initiatorBlockTime = inputAsset.confirmationPolicy.blockTimeSeconds
    val counterpartyBlockTime = outputAsset.confirmationPolicy.blockTimeSeconds

    val initiatorBlocks = INITIATOR_LOCK_SECONDS / initiatorBlockTime
    val counterpartyBlocks = COUNTERPARTY_LOCK_SECONDS / counterpartyBlockTime

    if (INITIATOR_LOCK_SECONDS < COUNTERPARTY_LOCK_SECONDS + MIN_SAFETY_MARGIN_SECONDS) {
      return HtlcValidationResult.Incompatible(
        "Unsafe timelock ordering: initiator lock must exceed counterparty lock by at least $MIN_SAFETY_MARGIN_SECONDS seconds."
      )
    }

    val commitment = secretVault.createHtlcSecret(swapId)
    val params =
      HtlcParameters(
        protocolSpec = "BIP-199 P2WSH SHA-256 HTLC",
        hashAlgorithm = "SHA-256",
        initiatorRole = "User Wallet (${inputAsset.ticker} Initiator)",
        counterpartyRole = "Counterparty Node (${outputAsset.ticker} Responder)",
        secretHashHex = commitment.secretHashHex,
        secretKeyRef = commitment.secretKeyRef,
        initiatorLockHeight = 2_890_000L + initiatorBlocks,
        counterpartyLockHeight = 3_410_000L + counterpartyBlocks,
        initiatorBlockTimeSeconds = initiatorBlockTime,
        counterpartyBlockTimeSeconds = counterpartyBlockTime,
        initiatorLockDurationSeconds = INITIATOR_LOCK_SECONDS,
        counterpartyLockDurationSeconds = COUNTERPARTY_LOCK_SECONDS,
        safetyMarginSeconds = MIN_SAFETY_MARGIN_SECONDS,
        initiatorLockDeadlineMillis = nowMillis + INITIATOR_LOCK_SECONDS * 1_000L,
        counterpartyLockDeadlineMillis = nowMillis + COUNTERPARTY_LOCK_SECONDS * 1_000L,
      )

    if (!params.hasValidAsymmetricTimelock) {
      return HtlcValidationResult.Incompatible("Asymmetric timelock check failed.")
    }
    return HtlcValidationResult.Compatible(params)
  }

  fun initiateAcceptedSwap(
    quote: SwapQuote,
    idempotencyKey: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    val swapId = "swp_${UUID.randomUUID().toString().take(8)}"
    val inputAsset = AssetRegistry.findById(quote.inputAssetId)!!
    val outputAsset = AssetRegistry.findById(quote.outputAssetId)!!

    if (quote.routeType == RouteType.ATOMIC_SWAP) {
      val htlcCheck =
        validateCompatibilityAndBuildParams(
          swapId = swapId,
          inputAssetId = quote.inputAssetId,
          outputAssetId = quote.outputAssetId,
          nowMillis = nowMillis,
        )
      val htlcParams =
        when (htlcCheck) {
          is HtlcValidationResult.Compatible -> htlcCheck.params
          is HtlcValidationResult.Incompatible -> error(htlcCheck.reason)
        }
      return SwapRecord(
        id = swapId,
        idempotencyKey = idempotencyKey,
        quote = quote,
        state = SwapState.FUNDING_PREPARED,
        htlcParams = htlcParams,
        leg1RequiredConfirmations = inputAsset.confirmationPolicy.requiredConfirmations,
        leg2RequiredConfirmations = outputAsset.confirmationPolicy.requiredConfirmations,
        lockStatusSummary =
          "HTLC commitment created. Waiting for your signed Leg 1 funding tx on ${inputAsset.networkName}.",
        expectedNextAction = "Sign & broadcast Leg 1 HTLC funding transaction",
        refundEligible = false,
        createdAtMillis = nowMillis,
        updatedAtMillis = nowMillis,
      )
    }

    // Non-HTLC routes (ON_CHAIN_SWAP or PROVIDER_MEDIATED)
    return SwapRecord(
      id = swapId,
      idempotencyKey = idempotencyKey,
      quote = quote,
      state = SwapState.FUNDING_PREPARED,
      htlcParams = null,
      leg1RequiredConfirmations = inputAsset.confirmationPolicy.requiredConfirmations,
      leg2RequiredConfirmations = outputAsset.confirmationPolicy.requiredConfirmations,
      lockStatusSummary =
        if (quote.routeType == RouteType.ON_CHAIN_SWAP) {
          "Exact-allowance DEX swap prepared on ${inputAsset.networkName}."
        } else {
          "Provider-mediated settlement prepared via ${quote.protocolsOrProviders.firstOrNull() ?: "Partner"}."
        },
      expectedNextAction = "Sign & submit swap transaction",
      refundEligible = false,
      createdAtMillis = nowMillis,
      updatedAtMillis = nowMillis,
    )
  }

  fun onLeg1FundedAndConfirmed(
    record: SwapRecord,
    leg1TxHash: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(record.state == SwapState.FUNDING_PREPARED || record.state == SwapState.REORG_DETECTED) {
      "Cannot confirm Leg 1 from state ${record.state}"
    }
    return record.copy(
      state = SwapState.FIRST_LEG_CONFIRMED,
      leg1TxHash = leg1TxHash,
      leg1Confirmations = record.leg1RequiredConfirmations,
      reorgNotice = null,
      lockStatusSummary =
        if (record.htlcParams != null) {
          "Leg 1 confirmed (${record.leg1RequiredConfirmations}/${record.leg1RequiredConfirmations} confs). Funds time-locked in HTLC; observing counterparty chain independently."
        } else {
          "Input transfer confirmed on-chain (${record.leg1RequiredConfirmations} confs)."
        },
      expectedNextAction =
        if (record.htlcParams != null) {
          "Awaiting counterparty Leg 2 HTLC funding & finality"
        } else {
          "Awaiting settlement output confirmation"
        },
      updatedAtMillis = nowMillis,
    )
  }

  fun onLeg2FundedAndConfirmed(
    record: SwapRecord,
    leg2TxHash: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(record.state == SwapState.FIRST_LEG_CONFIRMED || record.state == SwapState.REORG_DETECTED) {
      "Cannot confirm Leg 2 from state ${record.state}"
    }
    return record.copy(
      state = SwapState.SECOND_LEG_CONFIRMED,
      leg2TxHash = leg2TxHash,
      leg2Confirmations = record.leg2RequiredConfirmations,
      reorgNotice = null,
      lockStatusSummary =
        "Both HTLC legs confirmed! Your local secret is ready to reveal on-chain to claim output.",
      expectedNextAction = "Sign Leg 2 redemption (reveals preimage secret on-chain)",
      updatedAtMillis = nowMillis,
    )
  }

  fun redeemWithProtectedSecret(
    record: SwapRecord,
    redemptionTxHash: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(record.state == SwapState.SECOND_LEG_CONFIRMED || record.state == SwapState.REDEEMING) {
      "Cannot redeem from state ${record.state}"
    }
    val params = record.htlcParams
    if (params != null) {
      val secretHex =
        secretVault.loadSecretHex(params.secretKeyRef)
          ?: return record.copy(
            state = SwapState.MANUAL_REVIEW,
            failureReason = "Protected HTLC secret missing from local vault; manual review required.",
            expectedNextAction = "Inspect recovery logs / support manual review",
            updatedAtMillis = nowMillis,
          )
      val matches = secretVault.verifyPreimageMatchesHash(secretHex, params.secretHashHex)
      if (!matches) {
        return record.copy(
          state = SwapState.MANUAL_REVIEW,
          failureReason = "Preimage verification against SHA-256 commitment failed.",
          expectedNextAction = "Do not broadcast invalid preimage; wait for refund timelock",
          updatedAtMillis = nowMillis,
        )
      }
      RedactingLogger.log(
        "HtlcEngine",
        "Verified HTLC preimage secret=[REDACTED] for swap=${record.id} txHash=$redemptionTxHash",
      )
    }

    return record.copy(
      state = SwapState.COMPLETED,
      redemptionTxHash = redemptionTxHash,
      lockStatusSummary = "Settled & unlocked. Output funds are now spendable in your wallet.",
      expectedNextAction = "None — atomic swap completed",
      refundEligible = false,
      updatedAtMillis = nowMillis,
    )
  }

  fun simulateCounterpartyNonPerformance(
    record: SwapRecord,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(
      record.state == SwapState.FIRST_LEG_CONFIRMED ||
        record.state == SwapState.REORG_DETECTED ||
        record.state == SwapState.FUNDING_PREPARED
    ) {
      "Counterparty failure simulation requires active locked leg."
    }
    return record.copy(
      state = SwapState.REFUND_AVAILABLE,
      refundEligible = true,
      failureReason =
        "Counterparty failed to fund Leg 2 before its timelock deadline. Initiator timelock has now expired.",
      lockStatusSummary =
        "Leg 1 remains safely locked in your HTLC script. Refund path is now unlocked.",
      expectedNextAction = "User signature required online to broadcast HTLC Refund Tx",
      updatedAtMillis = nowMillis,
    )
  }

  fun executeRefund(
    record: SwapRecord,
    refundTxHash: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(record.state == SwapState.REFUND_AVAILABLE || record.state == SwapState.REFUNDING) {
      "Refund is only available when timelock has elapsed."
    }
    record.htlcParams?.let { secretVault.deleteSecret(it.secretKeyRef) }
    return record.copy(
      state = SwapState.REFUNDED,
      refundTxHash = refundTxHash,
      refundEligible = false,
      lockStatusSummary = "HTLC refund confirmed. Locked principal returned to spendable balance (minus miner fee).",
      expectedNextAction = "None — funds recovered",
      updatedAtMillis = nowMillis,
    )
  }

  fun simulateChainReorg(
    record: SwapRecord,
    affectedLeg: Int = 2,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    val dropFrom =
      if (affectedLeg == 1) maxOf(0, record.leg1Confirmations - 2)
      else maxOf(0, record.leg2Confirmations - 3)
    return record.copy(
      state = SwapState.REORG_DETECTED,
      leg1Confirmations = if (affectedLeg == 1) dropFrom else record.leg1Confirmations,
      leg2Confirmations = if (affectedLeg == 2) dropFrom else record.leg2Confirmations,
      reorgNotice =
        "1-block chain reorganisation observed on Leg $affectedLeg. Confirmations dropped below finality threshold; holding secret reveal until re-confirmed.",
      lockStatusSummary = "Finality paused due to chain reorganisation. Independent chain monitor re-verifying.",
      expectedNextAction = "Wait for re-confirmation before revealing secret",
      updatedAtMillis = nowMillis,
    )
  }

  fun recoverFromReorg(
    record: SwapRecord,
    nowMillis: Long = System.currentTimeMillis(),
  ): SwapRecord {
    require(record.state == SwapState.REORG_DETECTED) { "Swap is not in reorg state" }
    val restoredState =
      if (record.leg2TxHash != null) SwapState.SECOND_LEG_CONFIRMED else SwapState.FIRST_LEG_CONFIRMED
    return record.copy(
      state = restoredState,
      leg1Confirmations =
        if (record.leg1TxHash != null) record.leg1RequiredConfirmations else record.leg1Confirmations,
      leg2Confirmations =
        if (record.leg2TxHash != null) record.leg2RequiredConfirmations else record.leg2Confirmations,
      reorgNotice = null,
      lockStatusSummary = "Chain stabilised and required finality confirmations restored.",
      expectedNextAction =
        if (restoredState == SwapState.SECOND_LEG_CONFIRMED) {
          "Sign Leg 2 redemption (reveals preimage secret on-chain)"
        } else {
          "Awaiting counterparty Leg 2 HTLC funding"
        },
      updatedAtMillis = nowMillis,
    )
  }

  fun buildDeterministicTxHash(prefix: String, swapId: String): String {
    val hash =
      MessageDigest.getInstance("SHA-256")
        .digest("$prefix:$swapId:${System.nanoTime()}".toByteArray())
        .joinToString("") { "%02x".format(it) }
    return "0x$hash"
  }
}
