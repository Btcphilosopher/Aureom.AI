package com.example.domain.model

enum class ActivityCategory(val label: String) {
  DEPOSIT("Deposit"),
  SEND("Send"),
  SWAP("Swap"),
  FIAT_PAYOUT("Fiat Payout"),
  RECOVERY("Recovery"),
  SECURITY("Security"),
}

data class ActivityEvent(
  val id: String,
  val category: ActivityCategory,
  val title: String,
  val plainExplanation: String,
  val statusLabel: String,
  val isConfirmed: Boolean,
  val isError: Boolean = false,
  val assetTicker: String,
  val amountDisplay: String,
  val routeType: RouteType? = null,
  val txHash: String? = null,
  val confirmationsText: String? = null,
  val providerReference: String? = null,
  val relatedSwapId: String? = null,
  val timestampMillis: Long,
)
