package com.example.domain.util

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Signed webhook verification (HMAC-SHA256) and replay protection (timestamp skew + nonce cache).
 */
class WebhookVerifier(
  private val sharedSecret: ByteArray,
  private val maxClockSkewMillis: Long = 300_000L,
) {
  private val seenNonces = LinkedHashMap<String, Long>()

  fun computeSignatureHex(timestampMillis: Long, nonce: String, payload: String): String {
    val signedInput = "$timestampMillis.$nonce.$payload"
    val mac = Mac.getInstance("HmacSHA256")
    mac.init(SecretKeySpec(sharedSecret, "HmacSHA256"))
    val bytes = mac.doFinal(signedInput.toByteArray(StandardCharsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
  }

  @Synchronized
  fun verifyWebhook(
    timestampMillis: Long,
    nonce: String,
    payload: String,
    providedSignatureHex: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): WebhookVerificationResult {
    if (nonce.isBlank()) {
      return WebhookVerificationResult.Rejected("Missing replay nonce")
    }
    if (kotlin.math.abs(nowMillis - timestampMillis) > maxClockSkewMillis) {
      return WebhookVerificationResult.Rejected("Timestamp outside replay protection window")
    }
    if (seenNonces.containsKey(nonce)) {
      return WebhookVerificationResult.Rejected("Replay detected: duplicate webhook nonce")
    }

    val expectedHex = computeSignatureHex(timestampMillis, nonce, payload)
    val expectedBytes = expectedHex.toByteArray(StandardCharsets.UTF_8)
    val providedBytes = providedSignatureHex.trim().lowercase().toByteArray(StandardCharsets.UTF_8)
    if (!MessageDigest.isEqual(expectedBytes, providedBytes)) {
      return WebhookVerificationResult.Rejected("Invalid HMAC-SHA256 webhook signature")
    }

    // Evict expired nonces before recording
    val cutoff = nowMillis - maxClockSkewMillis
    val iterator = seenNonces.entries.iterator()
    while (iterator.hasNext()) {
      if (iterator.next().value < cutoff) iterator.remove()
    }
    seenNonces[nonce] = timestampMillis
    return WebhookVerificationResult.Verified
  }
}

sealed class WebhookVerificationResult {
  data object Verified : WebhookVerificationResult()
  data class Rejected(val reason: String) : WebhookVerificationResult()
}
