package com.example.domain.util

import java.util.concurrent.CopyOnWriteArrayList

/**
 * Redacts secrets, private keys, recovery phrases, and HTLC preimages before recording or printing logs.
 */
object RedactingLogger {

  private val secretPatterns =
    listOf(
      Regex("(?i)(secret|preimage|private_?key|mnemonic|recovery_?phrase|seed)\\s*[:=]\\s*[^\\s,;]+"),
      Regex("(?i)(bearer\\s+)[A-Za-z0-9._-]+"),
      Regex("\\b([a-fA-F0-9]{64})\\b"),
    )

  private val recentEntries = CopyOnWriteArrayList<String>()

  fun redact(message: String): String {
    var sanitized = message
    secretPatterns.forEachIndexed { idx, regex ->
      sanitized =
        when (idx) {
          0 -> regex.replace(sanitized) { match ->
            val prefix = match.value.substringBefore(':').substringBefore('=')
            "$prefix=[REDACTED]"
          }
          1 -> regex.replace(sanitized) { "${it.groupValues[1]}[REDACTED]" }
          else -> regex.replace(sanitized) { match ->
            val raw = match.value
            // Preserve tx hashes only when explicitly prefixed as tx/hash in caller, otherwise mask raw 64-hex secrets
            if (sanitized.contains("tx=", ignoreCase = true) ||
                sanitized.contains("secretHash=", ignoreCase = true) ||
                sanitized.contains("txHash=", ignoreCase = true)
            ) {
              raw.take(10) + "..." + raw.takeLast(6)
            } else {
              "[REDACTED_HEX_64]"
            }
          }
        }
    }
    return sanitized
  }

  fun log(tag: String, message: String): String {
    val entry = "[$tag] ${redact(message)}"
    recentEntries.add(entry)
    if (recentEntries.size > 100) {
      recentEntries.removeAt(0)
    }
    return entry
  }

  fun snapshot(): List<String> = recentEntries.toList()

  fun clear() {
    recentEntries.clear()
  }
}
