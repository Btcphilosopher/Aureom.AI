package com.example.domain.custody

import com.example.domain.model.AddressValidationResult
import com.example.domain.model.AssetDefinition
import com.example.domain.model.AssetRegistry
import com.example.domain.util.RedactingLogger
import java.security.MessageDigest

data class ConnectedAccount(
  val chainId: String,
  val networkName: String,
  val publicAddress: String,
  val memoOrTag: String? = null,
  val adapterName: String,
)

data class SigningPreview(
  val title: String,
  val actionDescription: String,
  val networkName: String,
  val chainId: String,
  val assetTicker: String,
  val tokenIdentifier: String,
  val amountFormatted: String,
  val feeFormatted: String,
  val destinationAddress: String?,
  val destinationMemo: String? = null,
  val simulationOutcome: String,
  val allowanceCapNote: String? = null,
  val custodyWarning: String,
)

data class SignedTransactionResult(
  val txHash: String,
  val signedByAddress: String,
  val signatureAlgorithm: String,
)

data class BoundaryItem(
  val action: String,
  val backendCanObserve: String,
  val userSignatureRequired: Boolean,
  val securityRationale: String,
)

/**
 * Non-custodial wallet adapter interface.
 * Private keys never leave the local secure wallet/Keystore; backend adapters only prepare unsigned payloads.
 */
interface ChainWalletAdapter {
  val supportedChainIds: Set<String>
  val adapterName: String
  val signatureAlgorithm: String

  fun getConnectedAccount(chainId: String): ConnectedAccount
  fun validateAddress(asset: AssetDefinition, address: String, memo: String?): AddressValidationResult
  fun signPreparedAction(preview: SigningPreview, payloadToSign: String): SignedTransactionResult
}

class BitcoinLikeTestnetAdapter(
  override val supportedChainIds: Set<String>,
  override val adapterName: String,
  private val addressByChain: Map<String, String>,
) : ChainWalletAdapter {
  override val signatureAlgorithm: String = "ECDSA-secp256k1 (Local Dev Signer)"

  override fun getConnectedAccount(chainId: String): ConnectedAccount {
    val address = addressByChain[chainId] ?: error("Unsupported chain $chainId")
    val network =
      if (chainId.startsWith("bitcoin")) "Bitcoin Testnet4" else "Litecoin Testnet4"
    return ConnectedAccount(
      chainId = chainId,
      networkName = network,
      publicAddress = address,
      adapterName = adapterName,
    )
  }

  override fun validateAddress(
    asset: AssetDefinition,
    address: String,
    memo: String?,
  ): AddressValidationResult = AssetRegistry.validateAddress(asset.id, address, memo)

  override fun signPreparedAction(
    preview: SigningPreview,
    payloadToSign: String,
  ): SignedTransactionResult {
    val digest =
      MessageDigest.getInstance("SHA-256")
        .digest("$payloadToSign:${System.nanoTime()}".toByteArray())
        .joinToString("") { "%02x".format(it) }
    val txHash = "0x$digest".take(66)
    val account = getConnectedAccount(preview.chainId)
    RedactingLogger.log(
      "WalletAdapter",
      "Signed ${preview.title} on ${preview.chainId} tx=$txHash",
    )
    return SignedTransactionResult(
      txHash = txHash,
      signedByAddress = account.publicAddress,
      signatureAlgorithm = signatureAlgorithm,
    )
  }
}

class EvmTestnetWalletAdapter : ChainWalletAdapter {
  override val supportedChainIds: Set<String> = setOf("eip155:11155111", "eip155:11155420")
  override val adapterName: String = "Aureom EVM Dev Wallet Adapter"
  override val signatureAlgorithm: String = "EIP-1559 ECDSA (Non-Custodial)"

  override fun getConnectedAccount(chainId: String): ConnectedAccount {
    val network =
      if (chainId == "eip155:11155420") "Optimism Sepolia" else "Ethereum Sepolia"
    return ConnectedAccount(
      chainId = chainId,
      networkName = network,
      publicAddress = "0x7A4c91F2E8B4d10a62C38e1B5590c8E1234a9F01",
      adapterName = adapterName,
    )
  }

  override fun validateAddress(
    asset: AssetDefinition,
    address: String,
    memo: String?,
  ): AddressValidationResult = AssetRegistry.validateAddress(asset.id, address, memo)

  override fun signPreparedAction(
    preview: SigningPreview,
    payloadToSign: String,
  ): SignedTransactionResult {
    val digest =
      MessageDigest.getInstance("SHA-256")
        .digest("evm:$payloadToSign:${System.nanoTime()}".toByteArray())
        .joinToString("") { "%02x".format(it) }
    val txHash = "0x$digest"
    RedactingLogger.log(
      "EvmWalletAdapter",
      "Signed EVM action '${preview.title}' tx=$txHash",
    )
    return SignedTransactionResult(
      txHash = txHash,
      signedByAddress = getConnectedAccount(preview.chainId).publicAddress,
      signatureAlgorithm = signatureAlgorithm,
    )
  }
}

class XrpTestnetWalletAdapter : ChainWalletAdapter {
  override val supportedChainIds: Set<String> = setOf("xrpl:testnet")
  override val adapterName: String = "Aureom XRPL Dev Wallet Adapter"
  override val signatureAlgorithm: String = "Ed25519 (XRPL Non-Custodial)"

  override fun getConnectedAccount(chainId: String): ConnectedAccount =
    ConnectedAccount(
      chainId = chainId,
      networkName = "XRP Ledger Testnet",
      publicAddress = "rN7n7otQDd6FczFgLdSqtcsAUxDkw6fzRH",
      memoOrTag = "409812",
      adapterName = adapterName,
    )

  override fun validateAddress(
    asset: AssetDefinition,
    address: String,
    memo: String?,
  ): AddressValidationResult = AssetRegistry.validateAddress(asset.id, address, memo)

  override fun signPreparedAction(
    preview: SigningPreview,
    payloadToSign: String,
  ): SignedTransactionResult {
    val digest =
      MessageDigest.getInstance("SHA-256")
        .digest("xrpl:$payloadToSign:${System.nanoTime()}".toByteArray())
        .joinToString("") { "%02x".format(it) }
        .uppercase()
    RedactingLogger.log("XrpWalletAdapter", "Signed XRPL payment tx=$digest")
    return SignedTransactionResult(
      txHash = digest,
      signedByAddress = getConnectedAccount("xrpl:testnet").publicAddress,
      signatureAlgorithm = signatureAlgorithm,
    )
  }
}

class WalletAdapterRegistry {
  private val btcLtcAdapter =
    BitcoinLikeTestnetAdapter(
      supportedChainIds = setOf("bitcoin:testnet4", "litecoin:testnet4"),
      adapterName = "Aureom UTXO Dev Adapter (BIP-84)",
      addressByChain =
        mapOf(
          "bitcoin:testnet4" to "tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx",
          "litecoin:testnet4" to "tltc1q2n9x8k4m7v3p5y6z8w2c4e6r8t0u2x4a7s9d1f",
        ),
    )
  private val evmAdapter = EvmTestnetWalletAdapter()
  private val xrpAdapter = XrpTestnetWalletAdapter()

  private val adapters = listOf(btcLtcAdapter, evmAdapter, xrpAdapter)

  fun adapterForChain(chainId: String): ChainWalletAdapter? =
    adapters.firstOrNull { chainId in it.supportedChainIds }

  fun allConnectedAccounts(): List<ConnectedAccount> =
    listOf(
      btcLtcAdapter.getConnectedAccount("bitcoin:testnet4"),
      btcLtcAdapter.getConnectedAccount("litecoin:testnet4"),
      evmAdapter.getConnectedAccount("eip155:11155111"),
      evmAdapter.getConnectedAccount("eip155:11155420"),
      xrpAdapter.getConnectedAccount("xrpl:testnet"),
    )

  val observationBoundaries: List<BoundaryItem> =
    listOf(
      BoundaryItem(
        action = "Receive Address & Deposit Monitoring",
        backendCanObserve = "Public receiving address, UTXO/transfer tx hashes, block confirmations.",
        userSignatureRequired = false,
        securityRationale = "Read-only public chain observation; no private key access needed.",
      ),
      BoundaryItem(
        action = "Quote Discovery & Route Evaluation",
        backendCanObserve = "Input/output asset IDs, amounts, slippage tolerance, quote expiry.",
        userSignatureRequired = false,
        securityRationale = "Coordinator computes candidate routes without touching funds.",
      ),
      BoundaryItem(
        action = "Send Transfer / Token Allowance",
        backendCanObserve = "Unsigned tx payload, exact allowance cap, public broadcast tx hash.",
        userSignatureRequired = true,
        securityRationale =
          "Only the local wallet holds signing keys. Unlimited ERC-20 approvals are disabled by default.",
      ),
      BoundaryItem(
        action = "HTLC Atomic Swap Funding & Redemption",
        backendCanObserve =
          "SHA-256 secretHash commitment, timelock heights, public HTLC funding/redeem txs.",
        userSignatureRequired = true,
        securityRationale =
          "HTLC secret preimage is generated and sealed in Android Keystore locally until Leg 2 reaches finality.",
      ),
      BoundaryItem(
        action = "HTLC Timeout Refund",
        backendCanObserve = "Timelock expiry block height and refund readiness alert.",
        userSignatureRequired = true,
        securityRationale =
          "Backend cannot unilaterally move locked funds; user signature broadcasts the refund tx after timelock.",
      ),
    )
}
