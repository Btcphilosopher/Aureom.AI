package com.example.domain.model

import java.math.BigInteger

enum class SwapState(val label: String, val isTerminal: Boolean, val requiresAttention: Boolean) {
  CREATED("Created", false, false),
  QUOTED("Quoted", false, false),
  ACCEPTED("Accepted", false, false),
  FUNDING_PREPARED("Funding Prepared", false, true),
  FIRST_LEG_CONFIRMED("First Leg Confirmed", false, false),
  SECOND_LEG_CONFIRMED("Second Leg Confirmed", false, true),
  REDEEMING("Redeeming", false, false),
  COMPLETED("Completed", true, false),
  EXPIRED("Expired", true, false),
  REFUND_AVAILABLE("Refund Available", false, true),
  REFUNDING("Refunding", false, false),
  REFUNDED("Refunded", true, false),
  REORG_DETECTED("Reorg Detected — Re-verifying", false, true),
  MANUAL_REVIEW("Manual Review", false, true),
}

data class SwapQuote(
  val quoteId: String,
  val inputAssetId: AssetId,
  val inputAmountBaseUnits: BigInteger,
  val outputAssetId: AssetId,
  val expectedOutputBaseUnits: BigInteger,
  val minimumOutputBaseUnits: BigInteger,
  val routeType: RouteType,
  val protocolsOrProviders: List<String>,
  val networkFeeBaseUnits: BigInteger,
  val networkFeeAssetId: AssetId,
  val serviceFeeBaseUnits: BigInteger,
  val slippageBps: Int,
  val priceImpactBps: Int?,
  val createdAtMillis: Long,
  val expiresAtMillis: Long,
  val estimatedCompletionSeconds: Int,
  val custodyAssumptions: String,
  val comparisonScopeNote: String,
  val quoteDigest: String,
) {
  fun isExpired(nowMillis: Long): Boolean = nowMillis > expiresAtMillis
}

/**
 * Full BIP-199 / SHA-256 HTLC protocol parameters.
 * Secret preimage is NEVER stored directly in this object; only secretHashHex and secretKeyRef are persisted.
 */
data class HtlcParameters(
  val protocolSpec: String = "BIP-199 P2WSH SHA-256 HTLC",
  val hashAlgorithm: String = "SHA-256",
  val initiatorRole: String = "User Wallet (Non-Custodial)",
  val counterpartyRole: String = "Counterparty Liquidity Node",
  val secretHashHex: String,
  val secretKeyRef: String,
  val initiatorLockHeight: Long,
  val counterpartyLockHeight: Long,
  val initiatorBlockTimeSeconds: Int,
  val counterpartyBlockTimeSeconds: Int,
  val initiatorLockDurationSeconds: Long,
  val counterpartyLockDurationSeconds: Long,
  val safetyMarginSeconds: Long,
  val initiatorLockDeadlineMillis: Long,
  val counterpartyLockDeadlineMillis: Long,
) {
  val hasValidAsymmetricTimelock: Boolean
    get() = initiatorLockDurationSeconds >= counterpartyLockDurationSeconds + safetyMarginSeconds
}

data class SwapRecord(
  val id: String,
  val idempotencyKey: String,
  val quote: SwapQuote,
  val state: SwapState,
  val htlcParams: HtlcParameters?,
  val leg1TxHash: String? = null,
  val leg1Confirmations: Int = 0,
  val leg1RequiredConfirmations: Int = 3,
  val leg2TxHash: String? = null,
  val leg2Confirmations: Int = 0,
  val leg2RequiredConfirmations: Int = 6,
  val redemptionTxHash: String? = null,
  val refundTxHash: String? = null,
  val lockStatusSummary: String,
  val expectedNextAction: String,
  val refundEligible: Boolean = false,
  val reorgNotice: String? = null,
  val failureReason: String? = null,
  val createdAtMillis: Long,
  val updatedAtMillis: Long,
)
