package com.example.domain.util

import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

/**
 * Exact integer base-unit & BigDecimal financial math.
 * Avoids IEEE-754 floating-point drift for balances, fees, quotes, and slippage bounds.
 */
object MoneyMath {

  private val TEN = BigDecimal.TEN

  fun parseHumanToBaseUnits(humanInput: String, decimals: Int): BigInteger? {
    val trimmed = humanInput.trim()
    if (trimmed.isEmpty()) return null
    return try {
      val bd = BigDecimal(trimmed)
      if (bd < BigDecimal.ZERO) return null
      if (bd.scale() > decimals) return null
      val scaled = bd.movePointRight(decimals)
      scaled.toBigIntegerExact()
    } catch (_: Exception) {
      null
    }
  }

  fun baseUnitsToBigDecimal(baseUnits: BigInteger, decimals: Int): BigDecimal {
    return BigDecimal(baseUnits).movePointLeft(decimals)
  }

  fun formatBaseUnits(
    baseUnits: BigInteger,
    decimals: Int,
    maxFractionDigits: Int = minOf(decimals, 6),
    stripTrailingZeros: Boolean = true,
  ): String {
    if (baseUnits == BigInteger.ZERO) return "0.00"
    val bd = baseUnitsToBigDecimal(baseUnits, decimals)
    val rounded = bd.setScale(maxFractionDigits, RoundingMode.DOWN)
    val normalized = if (stripTrailingZeros) rounded.stripTrailingZeros() else rounded
    val plain = normalized.toPlainString()
    return if (!plain.contains('.')) "$plain.00" else plain
  }

  fun estimateUsd(baseUnits: BigInteger, decimals: Int, usdPerUnit: BigDecimal): BigDecimal {
    val qty = baseUnitsToBigDecimal(baseUnits, decimals)
    return qty.multiply(usdPerUnit).setScale(2, RoundingMode.HALF_UP)
  }

  fun formatUsd(amount: BigDecimal): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale.US)
    formatter.minimumFractionDigits = 2
    formatter.maximumFractionDigits = 2
    return formatter.format(amount)
  }

  fun formatUsdCents(cents: Long): String {
    val bd = BigDecimal(cents).movePointLeft(2)
    return formatUsd(bd)
  }

  fun convertBaseUnits(
    inputBaseUnits: BigInteger,
    inputDecimals: Int,
    inputUsdRate: BigDecimal,
    outputDecimals: Int,
    outputUsdRate: BigDecimal,
    feeBps: Int,
  ): BigInteger {
    if (inputBaseUnits <= BigInteger.ZERO || outputUsdRate <= BigDecimal.ZERO) {
      return BigInteger.ZERO
    }
    val inputQty = baseUnitsToBigDecimal(inputBaseUnits, inputDecimals)
    val grossUsd = inputQty.multiply(inputUsdRate)
    val netFactor = BigDecimal(10_000 - feeBps).divide(BigDecimal(10_000), 12, RoundingMode.DOWN)
    val netUsd = grossUsd.multiply(netFactor)
    val outQty = netUsd.divide(outputUsdRate, outputDecimals, RoundingMode.DOWN)
    return outQty.movePointRight(outputDecimals).toBigInteger()
  }

  fun applySlippageMinOutput(expectedOutputBaseUnits: BigInteger, slippageBps: Int): BigInteger {
    require(slippageBps in 0..5_000) { "Slippage bps must be between 0 and 5000" }
    val factor = BigInteger.valueOf((10_000 - slippageBps).toLong())
    return expectedOutputBaseUnits.multiply(factor).divide(BigInteger.valueOf(10_000L))
  }

  fun pow10(decimals: Int): BigInteger = TEN.pow(decimals).toBigInteger()
}
