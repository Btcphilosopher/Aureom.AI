package com.example.domain.model

import java.math.BigDecimal
import java.math.BigInteger

enum class AssetKind(val badgeLabel: String) {
  NATIVE("Native"),
  WRAPPED("Wrapped"),
  BRIDGED("Bridged"),
  STABLECOIN("Stablecoin"),
  UNKNOWN("Unverified Token"),
}

enum class IntegrationStatus(val label: String, val isOperational: Boolean) {
  SUPPORTED("Supported", true),
  TESTNET("Testnet", true),
  UNAVAILABLE("Unavailable", false),
  DEPRECATED("Deprecated", false),
  UNVERIFIED_OBSERVATION("Unverified Observation", false),
}

enum class WalletOperation {
  RECEIVE,
  SEND,
  SWAP_INPUT,
  SWAP_OUTPUT,
  FIAT_OFF_RAMP,
}

/**
 * Four explicitly separated conversion route architectures.
 * Never conflate a bridge or custodial service with an atomic swap.
 */
enum class RouteType(
  val displayName: String,
  val shortTag: String,
  val custodyModel: String,
  val plainExplanation: String,
) {
  ATOMIC_SWAP(
    displayName = "Atomic Swap (HTLC)",
    shortTag = "Atomic HTLC",
    custodyModel = "Non-custodial peer-to-peer",
    plainExplanation =
      "Direct exchange between compatible blockchains using SHA-256 hash-time-locked contracts. Neither party holds the other's keys; funds are protected by asymmetric timelocks.",
  ),
  ON_CHAIN_SWAP(
    displayName = "On-Chain Swap (DEX)",
    shortTag = "On-Chain DEX",
    custodyModel = "Non-custodial smart contract",
    plainExplanation =
      "Single-chain exchange executed through a decentralized liquidity pool router. Subject to pool slippage, gas fees, and smart-contract execution risk.",
  ),
  PROVIDER_MEDIATED(
    displayName = "Provider-Mediated Conversion",
    shortTag = "Provider Quote",
    custodyModel = "Custodial conversion partner",
    plainExplanation =
      "Executed by an integrated liquidity provider off-chain or across settlement accounts. This is NOT an atomic swap; it requires trusting the provider during settlement.",
  ),
  FIAT_OFF_RAMP(
    displayName = "Fiat Off-Ramp (Bank Payout)",
    shortTag = "Fiat Off-Ramp",
    custodyModel = "Regulated banking & payment provider",
    plainExplanation =
      "Converts eligible crypto through an off-ramp partner and initiates an ACH/bank payout in US dollars. Atomic swaps cannot create bank deposits directly.",
  ),
}

/**
 * Composite identifier: assets MUST be keyed by (chainId, tokenIdentifier), never by ticker alone.
 */
data class AssetId(
  val chainId: String,
  val tokenIdentifier: String,
) {
  fun serializedKey(): String = "$chainId::$tokenIdentifier"

  companion object {
    fun fromKey(key: String): AssetId {
      val parts = key.split("::", limit = 2)
      return AssetId(parts[0], parts.getOrElse(1) { "native" })
    }
  }
}

data class ConfirmationPolicy(
  val requiredConfirmations: Int,
  val blockTimeSeconds: Int,
  val finalityNote: String,
)

data class AssetDefinition(
  val id: AssetId,
  val assetName: String,
  val ticker: String,
  val networkName: String,
  val assetKind: AssetKind,
  val decimals: Int,
  val supportedOperations: Set<WalletOperation>,
  val confirmationPolicy: ConfirmationPolicy,
  val supportedRoutes: Set<RouteType>,
  val minimumAmountBaseUnits: BigInteger,
  val integrationStatus: IntegrationStatus,
  val feeAssetId: AssetId,
  val requiresMemo: Boolean = false,
  val memoLabel: String? = null,
  val issuer: String? = null,
  val riskDisclosure: String? = null,
  val indicativeUsdPrice: BigDecimal,
) {
  val isSpendableOrSwappable: Boolean
    get() = integrationStatus.isOperational && assetKind != AssetKind.UNKNOWN

  val isStablecoin: Boolean
    get() = assetKind == AssetKind.STABLECOIN
}

data class AssetBalance(
  val assetId: AssetId,
  val spendableBaseUnits: BigInteger = BigInteger.ZERO,
  val pendingUnconfirmedBaseUnits: BigInteger = BigInteger.ZERO,
  val lockedHtlcBaseUnits: BigInteger = BigInteger.ZERO,
  val observedHeight: Long = 0L,
  val isDemoEnvironment: Boolean = true,
) {
  val totalBaseUnits: BigInteger
    get() = spendableBaseUnits + pendingUnconfirmedBaseUnits + lockedHtlcBaseUnits
}

sealed class AddressValidationResult {
  data class Valid(val normalizedAddress: String, val warningNote: String) :
    AddressValidationResult()

  data class Invalid(val reason: String) : AddressValidationResult()
}
