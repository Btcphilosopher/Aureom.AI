package com.example.domain.model

import java.math.BigInteger

/**
 * Optional Receive-and-Convert rule.
 * Defaults to manual approval (enabled = false).
 * Unattended execution in non-custodial mode is explicitly gated on constrained local signer policy availability.
 */
data class AutoConvertRule(
  val id: String = "default_receive_rule",
  val enabled: Boolean = false,
  val paused: Boolean = false,
  val sourceAssetId: AssetId = AssetRegistry.BTC_TEST_ID,
  val destinationType: DestinationTarget = DestinationTarget.STABLECOIN_USDC,
  val minDepositBaseUnits: BigInteger = BigInteger.valueOf(100_000L), // 0.001 BTC-TEST
  val minOutputBaseUnits: BigInteger = BigInteger.valueOf(50_000_000L), // 50.00 USDC
  val maxFeeUsdCents: Long = 1_500L, // $15.00
  val maxQuoteAgeSeconds: Int = 90,
  val dailyLimitUsdCents: Long = 250_000L, // $2,500.00
  val usedTodayUsdCents: Long = 0L,
  val allowedRoutes: Set<RouteType> = setOf(RouteType.ATOMIC_SWAP, RouteType.ON_CHAIN_SWAP),
) {
  enum class DestinationTarget(val label: String) {
    STABLECOIN_USDC("USDC on Sepolia (Digital Token)"),
    FIAT_BANK_USD("US Dollars via Eligible Bank Payout"),
  }
}
