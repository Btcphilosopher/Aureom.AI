package com.example.domain.engine

import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.RouteType
import com.example.domain.model.SwapQuote
import com.example.domain.model.WalletOperation
import com.example.domain.util.MoneyMath
import java.math.BigInteger
import java.security.MessageDigest
import java.util.UUID

sealed class QuoteResult {
  data class Success(val quotes: List<SwapQuote>, val comparisonScope: String) : QuoteResult()
  data class Rejected(val reason: String) : QuoteResult()
}

sealed class QuoteRevalidationResult {
  data object Valid : QuoteRevalidationResult()
  data class RequiresRenewedApproval(val reason: String, val refreshedQuote: SwapQuote?) :
    QuoteRevalidationResult()
  data class Blocked(val reason: String) : QuoteRevalidationResult()
}

class QuoteEngine(
  private val quoteTtlMillis: Long = 120_000L,
) {
  private val seenIdempotencyKeys = LinkedHashSet<String>()

  fun evaluateQuotes(
    fromAssetId: AssetId,
    toAssetId: AssetId,
    inputBaseUnits: BigInteger,
    slippageBps: Int,
    balances: Map<AssetId, AssetBalance>,
    emergencyPaused: Boolean,
    nowMillis: Long = System.currentTimeMillis(),
  ): QuoteResult {
    if (emergencyPaused) {
      return QuoteResult.Rejected(
        "Emergency swap pause is active. New quotes are halted; existing swap recovery and refunds remain available."
      )
    }
    if (fromAssetId == toAssetId) {
      return QuoteResult.Rejected("Source and destination assets must be different.")
    }
    val fromAsset =
      AssetRegistry.findById(fromAssetId)
        ?: return QuoteResult.Rejected("Unsupported source asset.")
    val toAsset =
      AssetRegistry.findById(toAssetId)
        ?: return QuoteResult.Rejected("Unsupported destination asset.")

    if (!fromAsset.isSpendableOrSwappable || WalletOperation.SWAP_INPUT !in fromAsset.supportedOperations) {
      return QuoteResult.Rejected(
        "${fromAsset.ticker} (${fromAsset.integrationStatus.label}) is not eligible as a swap input."
      )
    }
    if (!toAsset.isSpendableOrSwappable || WalletOperation.SWAP_OUTPUT !in toAsset.supportedOperations) {
      return QuoteResult.Rejected(
        "${toAsset.ticker} (${toAsset.integrationStatus.label}) is not eligible as a swap output."
      )
    }
    if (inputBaseUnits < fromAsset.minimumAmountBaseUnits) {
      val minDisplay = MoneyMath.formatBaseUnits(fromAsset.minimumAmountBaseUnits, fromAsset.decimals)
      return QuoteResult.Rejected("Minimum swap amount for ${fromAsset.ticker} is $minDisplay.")
    }
    if (slippageBps !in 10..500) {
      return QuoteResult.Rejected("Slippage tolerance must be between 0.10% and 5.00%.")
    }

    val fromBalance = balances[fromAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
    if (fromBalance < inputBaseUnits) {
      return QuoteResult.Rejected("Insufficient spendable ${fromAsset.ticker} balance.")
    }

    val candidates = mutableListOf<SwapQuote>()
    val sameEvmChain =
      fromAsset.id.chainId == toAsset.id.chainId && fromAsset.id.chainId.startsWith("eip155:")
    val isCompatibleHtlcPair =
      setOf(fromAssetId, toAssetId) == setOf(AssetRegistry.BTC_TEST_ID, AssetRegistry.LTC_TEST_ID)

    // 1. Atomic Swap (HTLC) — only for verified compatible cross-chain pairs
    if (isCompatibleHtlcPair) {
      val networkFee = estimateNetworkFee(fromAssetId)
      val serviceFee = BigInteger.ZERO // Direct P2P HTLC protocol has 0 coordinator fee
      val effectiveInput =
        if (fromAsset.feeAssetId == fromAssetId) (inputBaseUnits - networkFee).max(BigInteger.ZERO)
        else inputBaseUnits
      if (effectiveInput > BigInteger.ZERO) {
        val expectedOut =
          MoneyMath.convertBaseUnits(
            inputBaseUnits = effectiveInput,
            inputDecimals = fromAsset.decimals,
            inputUsdRate = fromAsset.indicativeUsdPrice,
            outputDecimals = toAsset.decimals,
            outputUsdRate = toAsset.indicativeUsdPrice,
            feeBps = 15, // 0.15% liquidity node spread
          )
        val minOut = MoneyMath.applySlippageMinOutput(expectedOut, slippageBps)
        candidates +=
          buildQuote(
            fromAssetId = fromAssetId,
            toAssetId = toAssetId,
            inputBaseUnits = inputBaseUnits,
            expectedOut = expectedOut,
            minOut = minOut,
            routeType = RouteType.ATOMIC_SWAP,
            protocols = listOf("BIP-199 SHA-256 HTLC", "Aureom P2P Liquidity Node"),
            networkFee = networkFee,
            networkFeeAssetId = fromAsset.feeAssetId,
            serviceFee = serviceFee,
            slippageBps = slippageBps,
            priceImpactBps = 12,
            estimatedSeconds = 2700,
            custodyAssumptions =
              "Non-custodial HTLC across ${fromAsset.networkName} and ${toAsset.networkName}. Funds remain time-locked under your cryptographic hash commitment; requires user signature & liveness before timelock expiry.",
            scopeNote =
              "Compared against 2 integrated testnet routes (Atomic HTLC vs Provider-Mediated); not a global market-wide best-execution guarantee.",
            nowMillis = nowMillis,
          )
      }
    }

    // 2. On-Chain DEX Swap — only when both assets reside on the same supported EVM chain
    if (sameEvmChain && RouteType.ON_CHAIN_SWAP in fromAsset.supportedRoutes && RouteType.ON_CHAIN_SWAP in toAsset.supportedRoutes) {
      val feeAsset = AssetRegistry.findById(fromAsset.feeAssetId)!!
      val gasFee = estimateNetworkFee(fromAsset.feeAssetId)
      val gasBalance = balances[fromAsset.feeAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
      val requiredFeeAsset =
        if (fromAsset.feeAssetId == fromAssetId) inputBaseUnits + gasFee else gasFee
      if (gasBalance >= requiredFeeAsset) {
        val serviceFee =
          inputBaseUnits.multiply(BigInteger.valueOf(20L)).divide(BigInteger.valueOf(10_000L))
        val expectedOut =
          MoneyMath.convertBaseUnits(
            inputBaseUnits = inputBaseUnits,
            inputDecimals = fromAsset.decimals,
            inputUsdRate = fromAsset.indicativeUsdPrice,
            outputDecimals = toAsset.decimals,
            outputUsdRate = toAsset.indicativeUsdPrice,
            feeBps = 30, // 0.30% LP + router fee
          )
        val minOut = MoneyMath.applySlippageMinOutput(expectedOut, slippageBps)
        candidates +=
          buildQuote(
            fromAssetId = fromAssetId,
            toAssetId = toAssetId,
            inputBaseUnits = inputBaseUnits,
            expectedOut = expectedOut,
            minOut = minOut,
            routeType = RouteType.ON_CHAIN_SWAP,
            protocols = listOf("Sepolia AMM v3 Pool", "Exact-Allowance Router"),
            networkFee = gasFee,
            networkFeeAssetId = feeAsset.id,
            serviceFee = serviceFee,
            slippageBps = slippageBps,
            priceImpactBps = 24,
            estimatedSeconds = 45,
            custodyAssumptions =
              "Non-custodial on-chain smart contract swap on ${fromAsset.networkName}. Uses exact-amount ERC-20 allowance approval; subject to pool price movement and gas fees.",
            scopeNote =
              "Compared across integrated ${fromAsset.networkName} DEX pool & integrated provider quote.",
            nowMillis = nowMillis,
          )
      }
    }

    // 3. Provider-Mediated Conversion — available when both assets support provider routing
    if (RouteType.PROVIDER_MEDIATED in fromAsset.supportedRoutes &&
        RouteType.PROVIDER_MEDIATED in toAsset.supportedRoutes
    ) {
      val networkFee = estimateNetworkFee(fromAsset.feeAssetId)
      val feeBalance = balances[fromAsset.feeAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
      val requiredFeeBalance =
        if (fromAsset.feeAssetId == fromAssetId) inputBaseUnits + networkFee else networkFee
      if (feeBalance >= requiredFeeBalance) {
        val serviceFee =
          inputBaseUnits.multiply(BigInteger.valueOf(45L)).divide(BigInteger.valueOf(10_000L))
        val expectedOut =
          MoneyMath.convertBaseUnits(
            inputBaseUnits = inputBaseUnits,
            inputDecimals = fromAsset.decimals,
            inputUsdRate = fromAsset.indicativeUsdPrice,
            outputDecimals = toAsset.decimals,
            outputUsdRate = toAsset.indicativeUsdPrice,
            feeBps = 65, // 0.65% spread + provider service fee
          )
        val minOut = MoneyMath.applySlippageMinOutput(expectedOut, slippageBps)
        candidates +=
          buildQuote(
            fromAssetId = fromAssetId,
            toAssetId = toAssetId,
            inputBaseUnits = inputBaseUnits,
            expectedOut = expectedOut,
            minOut = minOut,
            routeType = RouteType.PROVIDER_MEDIATED,
            protocols = listOf("Helios Testnet Liquidity Desk"),
            networkFee = networkFee,
            networkFeeAssetId = fromAsset.feeAssetId,
            serviceFee = serviceFee,
            slippageBps = slippageBps,
            priceImpactBps = null,
            estimatedSeconds = 180,
            custodyAssumptions =
              "Custodial provider-mediated conversion (NOT an atomic swap). Your input transfer settles with the provider before the provider delivers ${toAsset.ticker}.",
            scopeNote =
              "Compared among explicitly integrated Aureom routes only; not an exhaustive market aggregation.",
            nowMillis = nowMillis,
          )
      }
    }

    if (candidates.isEmpty()) {
      val feeAsset = AssetRegistry.findById(fromAsset.feeAssetId)
      val feeBal = balances[fromAsset.feeAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
      val estFee = estimateNetworkFee(fromAsset.feeAssetId)
      return if (feeBal < estFee) {
        QuoteResult.Rejected(
          "Insufficient ${feeAsset?.ticker ?: "fee token"} balance to cover estimated network fees."
        )
      } else {
        QuoteResult.Rejected(
          "No verified conversion route is implemented between ${fromAsset.ticker} (${fromAsset.networkName}) and ${toAsset.ticker} (${toAsset.networkName})."
        )
      }
    }

    val sorted = candidates.sortedByDescending { it.expectedOutputBaseUnits }
    return QuoteResult.Success(
      quotes = sorted,
      comparisonScope =
        "Ranked by expected net output across ${sorted.size} explicitly integrated route(s). Check custody assumptions before approving.",
    )
  }

  fun revalidateBeforeExecution(
    quote: SwapQuote,
    balances: Map<AssetId, AssetBalance>,
    emergencyPaused: Boolean,
    idempotencyKey: String,
    simulatedMarketDriftBps: Int = 0,
    nowMillis: Long = System.currentTimeMillis(),
  ): QuoteRevalidationResult {
    if (emergencyPaused) {
      return QuoteRevalidationResult.Blocked(
        "Emergency pause enabled: new swaps are blocked while existing recoveries remain active."
      )
    }
    if (idempotencyKey in seenIdempotencyKeys) {
      return QuoteRevalidationResult.Blocked(
        "Duplicate swap request rejected (idempotency key already processed)."
      )
    }
    if (quote.isExpired(nowMillis)) {
      val refreshed =
        (evaluateQuotes(
          fromAssetId = quote.inputAssetId,
          toAssetId = quote.outputAssetId,
          inputBaseUnits = quote.inputAmountBaseUnits,
          slippageBps = quote.slippageBps,
          balances = balances,
          emergencyPaused = false,
          nowMillis = nowMillis,
        ) as? QuoteResult.Success)?.quotes?.firstOrNull { it.routeType == quote.routeType }
      return QuoteRevalidationResult.RequiresRenewedApproval(
        reason = "Quote expired before signing. Review refreshed quote and approve again.",
        refreshedQuote = refreshed,
      )
    }
    if (simulatedMarketDriftBps > quote.slippageBps) {
      return QuoteRevalidationResult.RequiresRenewedApproval(
        reason =
          "Material rate change (${simulatedMarketDriftBps / 100.0}%) exceeded your ${quote.slippageBps / 100.0}% slippage bound. Renewed approval required.",
        refreshedQuote = null,
      )
    }

    val inputBal = balances[quote.inputAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
    if (inputBal < quote.inputAmountBaseUnits) {
      return QuoteRevalidationResult.Blocked("Insufficient spendable input balance.")
    }

    val feeBal = balances[quote.networkFeeAssetId]?.spendableBaseUnits ?: BigInteger.ZERO
    val requiredFeeBal =
      if (quote.networkFeeAssetId == quote.inputAssetId) {
        quote.inputAmountBaseUnits + quote.networkFeeBaseUnits
      } else {
        quote.networkFeeBaseUnits
      }
    if (feeBal < requiredFeeBal) {
      val feeAsset = AssetRegistry.findById(quote.networkFeeAssetId)
      return QuoteRevalidationResult.Blocked(
        "Insufficient ${feeAsset?.ticker ?: "fee asset"} to pay network fee."
      )
    }

    seenIdempotencyKeys.add(idempotencyKey)
    return QuoteRevalidationResult.Valid
  }

  fun estimateNetworkFee(feeAssetId: AssetId): BigInteger =
    when (feeAssetId) {
      AssetRegistry.BTC_TEST_ID -> BigInteger.valueOf(2_500L) // 0.000025 BTC
      AssetRegistry.LTC_TEST_ID -> BigInteger.valueOf(25_000L) // 0.00025 LTC
      AssetRegistry.ETH_SEP_ID -> BigInteger("1200000000000000") // 0.0012 ETH
      AssetRegistry.XRP_TEST_ID -> BigInteger.valueOf(12L) // 0.000012 XRP
      else -> BigInteger.ZERO
    }

  private fun buildQuote(
    fromAssetId: AssetId,
    toAssetId: AssetId,
    inputBaseUnits: BigInteger,
    expectedOut: BigInteger,
    minOut: BigInteger,
    routeType: RouteType,
    protocols: List<String>,
    networkFee: BigInteger,
    networkFeeAssetId: AssetId,
    serviceFee: BigInteger,
    slippageBps: Int,
    priceImpactBps: Int?,
    estimatedSeconds: Int,
    custodyAssumptions: String,
    scopeNote: String,
    nowMillis: Long,
  ): SwapQuote {
    val quoteId = "qt_${UUID.randomUUID().toString().take(8)}"
    val digestInput =
      "$quoteId|${fromAssetId.serializedKey()}|$inputBaseUnits|${toAssetId.serializedKey()}|$expectedOut|${routeType.name}|$nowMillis"
    val digest =
      MessageDigest.getInstance("SHA-256")
        .digest(digestInput.toByteArray())
        .joinToString("") { "%02x".format(it) }
        .take(16)
    return SwapQuote(
      quoteId = quoteId,
      inputAssetId = fromAssetId,
      inputAmountBaseUnits = inputBaseUnits,
      outputAssetId = toAssetId,
      expectedOutputBaseUnits = expectedOut,
      minimumOutputBaseUnits = minOut,
      routeType = routeType,
      protocolsOrProviders = protocols,
      networkFeeBaseUnits = networkFee,
      networkFeeAssetId = networkFeeAssetId,
      serviceFeeBaseUnits = serviceFee,
      slippageBps = slippageBps,
      priceImpactBps = priceImpactBps,
      createdAtMillis = nowMillis,
      expiresAtMillis = nowMillis + quoteTtlMillis,
      estimatedCompletionSeconds = estimatedSeconds,
      custodyAssumptions = custodyAssumptions,
      comparisonScopeNote = scopeNote,
      quoteDigest = digest,
    )
  }
}
