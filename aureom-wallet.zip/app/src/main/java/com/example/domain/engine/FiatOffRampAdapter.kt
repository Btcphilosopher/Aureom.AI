package com.example.domain.engine

import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.BankPayoutState
import com.example.domain.model.ConversionLegState
import com.example.domain.model.EligibilityStatus
import com.example.domain.model.FiatOffRampQuote
import com.example.domain.model.FiatPayoutRecord
import com.example.domain.model.WalletOperation
import com.example.domain.model.ProviderBalanceState
import com.example.domain.util.MoneyMath
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.util.UUID

sealed class OffRampQuoteResult {
  data class Success(val quote: FiatOffRampQuote) : OffRampQuoteResult()
  data class Rejected(val reason: String) : OffRampQuoteResult()
}

/**
 * Simulated regulated Fiat Off-Ramp adapter (credentials remain server-side in production).
 * Strictly separates:
 * 1) Crypto -> USD conversion leg
 * 2) Provider USD balance state
 * 3) Bank ACH payout state
 */
class FiatOffRampAdapter(
  private val providerName: String = "AcmePay Off-Ramp (Sandbox)",
) {
  private val seenIdempotencyKeys = LinkedHashSet<String>()

  fun createQuote(
    inputAssetId: AssetId,
    inputAmountBaseUnits: BigInteger,
    eligibilityStatus: EligibilityStatus = EligibilityStatus.ELIGIBLE,
    destinationMask: String = "Chase Checking •••• 4821",
    nowMillis: Long = System.currentTimeMillis(),
  ): OffRampQuoteResult {
    val asset =
      AssetRegistry.findById(inputAssetId)
        ?: return OffRampQuoteResult.Rejected("Unknown input asset.")
    if (!asset.isSpendableOrSwappable || WalletOperation.FIAT_OFF_RAMP !in asset.supportedOperations) {
      return OffRampQuoteResult.Rejected(
        "${asset.ticker} is not supported for fiat off-ramp withdrawal."
      )
    }
    if (eligibilityStatus == EligibilityStatus.JURISDICTION_BLOCKED) {
      return OffRampQuoteResult.Rejected("Fiat off-ramp is unavailable in the selected jurisdiction.")
    }

    val grossUsd = MoneyMath.estimateUsd(inputAmountBaseUnits, asset.decimals, asset.indicativeUsdPrice)
    val grossCents = grossUsd.movePointRight(2).toLong()
    val minCents = 1_000L // $10.00
    val maxCents = 1_000_000L // $10,000.00
    if (grossCents < minCents) {
      return OffRampQuoteResult.Rejected("Minimum eligible bank cash-out is $10.00 USD.")
    }
    if (grossCents > maxCents) {
      return OffRampQuoteResult.Rejected("Maximum single sandbox cash-out is $10,000.00 USD.")
    }

    // $1.50 flat + 0.50% provider conversion fee
    val feeCents = 150L + (grossCents * 50L) / 10_000L
    val netCents = (grossCents - feeCents).coerceAtLeast(0L)
    val effectiveRate =
      asset.indicativeUsdPrice.setScale(2, RoundingMode.HALF_UP)

    val ref = "PROV-${UUID.randomUUID().toString().take(8).uppercase()}"
    return OffRampQuoteResult.Success(
      FiatOffRampQuote(
        quoteId = "fq_${UUID.randomUUID().toString().take(8)}",
        providerName = providerName,
        inputAssetId = inputAssetId,
        inputAmountBaseUnits = inputAmountBaseUnits,
        grossUsdCents = grossCents,
        providerFeeUsdCents = feeCents,
        netUsdPayoutCents = netCents,
        exchangeRateUsd = effectiveRate,
        minUsdCents = minCents,
        maxUsdCents = maxCents,
        estimatedPayoutWindow = "1–2 business days (ACH)",
        eligibilityStatus = eligibilityStatus,
        jurisdiction = "United States (Sandbox)",
        destinationMask = destinationMask,
        expiresAtMillis = nowMillis + 120_000L,
        providerReference = ref,
      )
    )
  }

  fun initiatePayout(
    quote: FiatOffRampQuote,
    idempotencyKey: String,
    simulateProviderFailure: Boolean = false,
    nowMillis: Long = System.currentTimeMillis(),
  ): FiatPayoutRecord {
    require(idempotencyKey !in seenIdempotencyKeys) {
      "Duplicate off-ramp payout request rejected (idempotency key reused)."
    }
    if (nowMillis > quote.expiresAtMillis) {
      return FiatPayoutRecord(
        id = "pay_${UUID.randomUUID().toString().take(8)}",
        idempotencyKey = idempotencyKey,
        quote = quote,
        conversionState = ConversionLegState.FAILED,
        providerBalanceState = ProviderBalanceState.NONE,
        bankPayoutState = BankPayoutState.REJECTED,
        failureReason = "Off-ramp quote expired before execution. Request a fresh quote.",
        createdAtMillis = nowMillis,
        updatedAtMillis = nowMillis,
      )
    }
    if (quote.eligibilityStatus != EligibilityStatus.ELIGIBLE) {
      return FiatPayoutRecord(
        id = "pay_${UUID.randomUUID().toString().take(8)}",
        idempotencyKey = idempotencyKey,
        quote = quote,
        conversionState = ConversionLegState.NOT_STARTED,
        providerBalanceState = ProviderBalanceState.NONE,
        bankPayoutState = BankPayoutState.REJECTED,
        failureReason = "Identity verification must be complete before bank payout can execute.",
        createdAtMillis = nowMillis,
        updatedAtMillis = nowMillis,
      )
    }

    seenIdempotencyKeys.add(idempotencyKey)

    if (simulateProviderFailure) {
      return FiatPayoutRecord(
        id = "pay_${UUID.randomUUID().toString().take(8)}",
        idempotencyKey = idempotencyKey,
        quote = quote,
        conversionState = ConversionLegState.FAILED,
        providerBalanceState = ProviderBalanceState.NONE,
        bankPayoutState = BankPayoutState.REJECTED,
        failureReason =
          "Provider liquidity rail temporarily rejected settlement (${quote.providerReference}). No bank payout initiated.",
        createdAtMillis = nowMillis,
        updatedAtMillis = nowMillis,
      )
    }

    return FiatPayoutRecord(
      id = "pay_${UUID.randomUUID().toString().take(8)}",
      idempotencyKey = idempotencyKey,
      quote = quote,
      conversionState = ConversionLegState.CONVERTED_TO_USD,
      providerBalanceState = ProviderBalanceState.RESERVED_FOR_PAYOUT,
      bankPayoutState = BankPayoutState.SETTLING,
      createdAtMillis = nowMillis,
      updatedAtMillis = nowMillis,
    )
  }

  fun markBankSettled(record: FiatPayoutRecord, nowMillis: Long = System.currentTimeMillis()): FiatPayoutRecord {
    require(record.bankPayoutState == BankPayoutState.SETTLING || record.bankPayoutState == BankPayoutState.QUEUED) {
      "Cannot settle payout from state ${record.bankPayoutState}"
    }
    return record.copy(
      providerBalanceState = ProviderBalanceState.DISBURSED,
      bankPayoutState = BankPayoutState.PAID_OUT,
      updatedAtMillis = nowMillis,
    )
  }
}
