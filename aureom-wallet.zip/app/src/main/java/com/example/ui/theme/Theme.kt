package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class ThemeMode(val label: String) {
  SYSTEM("System"),
  LIGHT("Warm Light"),
  DARK("Midnight Dark"),
}

private val AureomLightColorScheme =
  lightColorScheme(
    primary = MidnightBlue,
    onPrimary = Color.White,
    primaryContainer = MidnightContainer,
    onPrimaryContainer = OnMidnightContainer,
    secondary = BurnishedGold,
    onSecondary = Color.White,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = OnGoldContainer,
    tertiary = SlateTeal,
    onTertiary = Color.White,
    tertiaryContainer = SlateTealContainer,
    onTertiaryContainer = Color(0xFF052B2A),
    background = WarmWhite,
    onBackground = InkPrimary,
    surface = WarmPaper,
    onSurface = InkPrimary,
    surfaceVariant = WarmSand,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = WarmPaper,
    surfaceContainerLow = Color(0xFFF6F2EA),
    surfaceContainer = WarmSand,
    surfaceContainerHigh = WarmSandHigh,
    outline = WarmOutline,
    outlineVariant = WarmOutlineSubtle,
    error = CrimsonAlert,
    onError = Color.White,
    errorContainer = CrimsonContainer,
    onErrorContainer = Color(0xFF410002),
  )

private val AureomDarkColorScheme =
  darkColorScheme(
    primary = IceBluePrimary,
    onPrimary = DeepOnPrimary,
    primaryContainer = MidnightPrimaryContainer,
    onPrimaryContainer = WarmIvoryText,
    secondary = AureomGold,
    onSecondary = Color(0xFF281B00),
    secondaryContainer = DarkGoldContainer,
    onSecondaryContainer = OnDarkGoldContainer,
    tertiary = DarkTeal,
    onTertiary = Color(0xFF002725),
    tertiaryContainer = DarkTealContainer,
    onTertiaryContainer = Color(0xFFB5EFEC),
    background = DeepMidnight,
    onBackground = WarmIvoryText,
    surface = MidnightCard,
    onSurface = WarmIvoryText,
    surfaceVariant = MidnightElevated,
    onSurfaceVariant = MutedIvoryText,
    surfaceContainerLowest = DeepMidnight,
    surfaceContainerLow = MidnightCard,
    surfaceContainer = MidnightElevated,
    surfaceContainerHigh = MidnightElevatedHigh,
    outline = DarkOutline,
    outlineVariant = Color(0xFF1D3052),
    error = CrimsonAlertDark,
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = CrimsonContainer,
  )

val AureomShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun AureomWalletTheme(
  themeMode: ThemeMode = ThemeMode.SYSTEM,
  content: @Composable () -> Unit,
) {
  val useDarkTheme =
    when (themeMode) {
      ThemeMode.SYSTEM -> isSystemInDarkTheme()
      ThemeMode.LIGHT -> false
      ThemeMode.DARK -> true
    }

  val colorScheme = if (useDarkTheme) AureomDarkColorScheme else AureomLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AureomTypography,
    shapes = AureomShapes,
    content = content,
  )
}
