package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.custody.BoundaryItem
import com.example.domain.model.AssetRegistry
import com.example.domain.model.AutoConvertRule
import com.example.domain.util.MoneyMath
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.ThemeMode
import com.example.ui.viewmodel.AureomUiState

@Composable
fun SettingsScreen(
  uiState: AureomUiState,
  observationBoundaries: List<BoundaryItem>,
  onSetThemeMode: (ThemeMode) -> Unit,
  onToggleWalletConnected: (Boolean) -> Unit,
  onToggleEmergencyPause: (Boolean) -> Unit,
  onSaveAutoConvertRule: (AutoConvertRule) -> Unit,
  modifier: Modifier = Modifier,
) {
  var editingRule by remember(uiState.autoConvertRule) { mutableStateOf(uiState.autoConvertRule) }

  LazyColumn(
    modifier = modifier.fillMaxSize().testTag("settings_lazy_column"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Text("Settings & Security Controls", style = MaterialTheme.typography.headlineSmall)
    }

    // 1. Theme Selector (Warm Light / Midnight Dark / System)
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text("Appearance", style = MaterialTheme.typography.titleSmall)
          SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            ThemeMode.entries.forEachIndexed { idx, mode ->
              SegmentedButton(
                selected = uiState.settings.themeMode == mode,
                onClick = { onSetThemeMode(mode) },
                shape = SegmentedButtonDefaults.itemShape(index = idx, count = ThemeMode.entries.size),
                modifier = Modifier.testTag("theme_${mode.name.lowercase()}"),
              ) {
                Text(mode.label, maxLines = 1)
              }
            }
          }
        }
      }
    }

    // 2. Non-Custodial Wallet Adapter Status
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Non-Custodial Dev Wallet Adapter", style = MaterialTheme.typography.titleSmall)
              Text(
                "Private keys & recovery phrases stay off the backend. Never enter recovery phrases into support or AI forms.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = uiState.settings.walletConnected,
              onCheckedChange = onToggleWalletConnected,
              modifier = Modifier.testTag("wallet_connect_switch"),
            )
          }

          if (uiState.connectedAccounts.isNotEmpty()) {
            HorizontalDivider()
            uiState.connectedAccounts.forEach { acc ->
              Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("${acc.networkName} (${acc.adapterName})", style = MaterialTheme.typography.labelSmall)
                Text(acc.publicAddress, style = MonoCaptionStyle)
              }
            }
          }
        }
      }
    }

    // 3. Emergency Suspension & Allowance Controls
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text("Circuit Breaker & Approval Policy", style = MaterialTheme.typography.titleSmall)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Emergency Pause New Swaps", style = MaterialTheme.typography.bodyMedium)
              Text(
                "Halts new quotes and swap initiation without blocking existing HTLC refunds or recoveries.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = uiState.settings.emergencyPauseNewSwaps,
              onCheckedChange = onToggleEmergencyPause,
              modifier = Modifier.testTag("emergency_pause_switch"),
            )
          }
          HorizontalDivider()
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Token Allowance Policy", style = MaterialTheme.typography.bodyMedium)
              Text(
                "Unlimited ERC-20 approvals are disabled by default; exact swap amounts are approved per transaction.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            StatusPill(text = "Exact Only", tone = StatusTone.CONFIRMED)
          }
        }
      }
    }

    // 4. Optional Receive-and-Convert Rule (Default: Manual Approval)
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Optional Receive-and-Convert Rule", style = MaterialTheme.typography.titleSmall)
              Text(
                "Defaults to Manual Approval. Unattended execution requires an online constrained local signer; deposits wait for your signature otherwise.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = editingRule.enabled,
              onCheckedChange = { editingRule = editingRule.copy(enabled = it) },
              modifier = Modifier.testTag("autoconvert_switch"),
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Pause Rule", style = MaterialTheme.typography.bodyMedium)
            Switch(
              checked = editingRule.paused,
              onCheckedChange = { editingRule = editingRule.copy(paused = it) },
            )
          }

          val srcAsset = AssetRegistry.findById(editingRule.sourceAssetId)
          Text(
            "Source: ${srcAsset?.ticker} -> ${editingRule.destinationType.label}",
            style = MonoCaptionStyle,
          )
          Text(
            "Min Deposit: ${srcAsset?.let { MoneyMath.formatBaseUnits(editingRule.minDepositBaseUnits, it.decimals) }} ${srcAsset?.ticker} · Max Fee: ${MoneyMath.formatUsdCents(editingRule.maxFeeUsdCents)}",
            style = MonoCaptionStyle,
          )
          Text(
            "Max Quote Age: ${editingRule.maxQuoteAgeSeconds}s · Daily Limit: ${MoneyMath.formatUsdCents(editingRule.dailyLimitUsdCents)} · Routes: ${editingRule.allowedRoutes.joinToString { it.shortTag }}",
            style = MonoCaptionStyle,
          )

          if (editingRule.enabled && !editingRule.paused) {
            Surface(color = AmberContainer, shape = RoundedCornerShape(10.dp)) {
              Text(
                "Non-custodial boundary: When the local wallet signer is locked or backgrounded, automatic conversion will NOT execute silently — it queues a manual approval prompt.",
                style = MaterialTheme.typography.bodySmall,
                color = AmberPending,
                modifier = Modifier.padding(10.dp),
              )
            }
          }

          Button(
            onClick = { onSaveAutoConvertRule(editingRule) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text("Save Conversion Policy")
          }
        }
      }
    }

    // 5. Backend Observation vs. User Signature Boundary Matrix
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text("Custody & Observation Boundary", style = MaterialTheme.typography.titleSmall)
          observationBoundaries.forEach { item ->
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(item.action, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                StatusPill(
                  text = if (item.userSignatureRequired) "User Signature" else "Observe Only",
                  tone = if (item.userSignatureRequired) StatusTone.PRIMARY else StatusTone.NEUTRAL,
                )
              }
              Text("Coordinator observes: ${item.backendCanObserve}", style = MaterialTheme.typography.bodySmall)
              Text(
                item.securityRationale,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              HorizontalDivider(modifier = Modifier.padding(top = 6.dp))
            }
          }
        }
      }
    }

    // 6. Redacted Diagnostics Log Verification
    if (uiState.redactedLogSnapshot.isNotEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text("Redacted Security Diagnostics", style = MaterialTheme.typography.titleSmall)
            uiState.redactedLogSnapshot.takeLast(5).forEach { line ->
              Text(line, style = MonoCaptionStyle)
            }
          }
        }
      }
    }
  }
}
