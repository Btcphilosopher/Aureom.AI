package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ActionOutcome
import com.example.data.local.AureomDatabase
import com.example.data.local.AureomRepository
import com.example.data.local.PreferencesRepository
import com.example.data.local.WalletSettingsState
import com.example.domain.custody.AndroidKeystoreSecretVault
import com.example.domain.custody.ConnectedAccount
import com.example.domain.engine.OffRampQuoteResult
import com.example.domain.engine.QuoteResult
import com.example.domain.model.ActivityEvent
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetId
import com.example.domain.model.AssetRegistry
import com.example.domain.model.AutoConvertRule
import com.example.domain.model.EligibilityStatus
import com.example.domain.model.FiatOffRampQuote
import com.example.domain.model.FiatPayoutRecord
import com.example.domain.model.SwapQuote
import com.example.domain.model.SwapRecord
import com.example.domain.util.MoneyMath
import com.example.domain.util.RedactingLogger
import com.example.ui.theme.ThemeMode
import java.math.BigDecimal
import java.math.BigInteger
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AureomUiState(
  val balances: Map<AssetId, AssetBalance> = emptyMap(),
  val swaps: List<SwapRecord> = emptyList(),
  val activities: List<ActivityEvent> = emptyList(),
  val fiatPayouts: List<FiatPayoutRecord> = emptyList(),
  val autoConvertRule: AutoConvertRule = AutoConvertRule(),
  val settings: WalletSettingsState = WalletSettingsState(),
  val connectedAccounts: List<ConnectedAccount> = emptyList(),
  val activeQuotes: List<SwapQuote> = emptyList(),
  val quoteComparisonScope: String? = null,
  val quoteError: String? = null,
  val activeOffRampQuote: FiatOffRampQuote? = null,
  val offRampError: String? = null,
  val bannerMessage: String? = null,
  val bannerIsError: Boolean = false,
  val resumedSwapCount: Int = 0,
  val estimatedTotalUsd: BigDecimal = BigDecimal.ZERO,
  val estimatedSpendableUsd: BigDecimal = BigDecimal.ZERO,
  val estimatedPendingUsd: BigDecimal = BigDecimal.ZERO,
  val estimatedLockedUsd: BigDecimal = BigDecimal.ZERO,
  val demoStepsCompleted: Set<Int> = setOf(1, 2), // Wallet connected & assets displayed on launch
  val redactedLogSnapshot: List<String> = emptyList(),
)

private data class WorkingUiBuffers(
  val quotes: List<SwapQuote> = emptyList(),
  val comparisonScope: String? = null,
  val quoteError: String? = null,
  val offRampQuote: FiatOffRampQuote? = null,
  val offRampError: String? = null,
  val bannerMessage: String? = null,
  val bannerIsError: Boolean = false,
  val resumedSwapCount: Int = 0,
  val demoSteps: Set<Int> = setOf(1, 2),
)

class AureomViewModel(application: Application) : AndroidViewModel(application) {
  private val database = AureomDatabase.getInstance(application)
  private val secretVault = AndroidKeystoreSecretVault(application)
  val repository =
    AureomRepository(
      database = database,
      secretVault = secretVault,
      walletAdapters = com.example.domain.custody.WalletAdapterRegistry(),
    )
  private val preferences = PreferencesRepository(application)

  private val buffers = MutableStateFlow(WorkingUiBuffers())

  val uiState: StateFlow<AureomUiState> =
    combine(
        repository.balancesFlow,
        repository.swapsFlow,
        repository.activitiesFlow,
        repository.fiatPayoutsFlow,
        repository.autoConvertRuleFlow,
        preferences.settingsFlow,
        buffers,
      ) { values ->
        @Suppress("UNCHECKED_CAST")
        val balances = values[0] as Map<AssetId, AssetBalance>
        @Suppress("UNCHECKED_CAST")
        val swaps = values[1] as List<SwapRecord>
        @Suppress("UNCHECKED_CAST")
        val activities = values[2] as List<ActivityEvent>
        @Suppress("UNCHECKED_CAST")
        val payouts = values[3] as List<FiatPayoutRecord>
        val rule = values[4] as AutoConvertRule
        val settings = values[5] as WalletSettingsState
        val buf = values[6] as WorkingUiBuffers

        var spendableUsd = BigDecimal.ZERO
        var pendingUsd = BigDecimal.ZERO
        var lockedUsd = BigDecimal.ZERO
        for ((id, bal) in balances) {
          val asset = AssetRegistry.findById(id) ?: continue
          if (!asset.isSpendableOrSwappable) continue
          spendableUsd += MoneyMath.estimateUsd(bal.spendableBaseUnits, asset.decimals, asset.indicativeUsdPrice)
          pendingUsd += MoneyMath.estimateUsd(bal.pendingUnconfirmedBaseUnits, asset.decimals, asset.indicativeUsdPrice)
          lockedUsd += MoneyMath.estimateUsd(bal.lockedHtlcBaseUnits, asset.decimals, asset.indicativeUsdPrice)
        }
        val totalUsd = spendableUsd + pendingUsd + lockedUsd

        AureomUiState(
          balances = balances,
          swaps = swaps,
          activities = activities,
          fiatPayouts = payouts,
          autoConvertRule = rule,
          settings = settings,
          connectedAccounts =
            if (settings.walletConnected) repository.walletAdapters.allConnectedAccounts()
            else emptyList(),
          activeQuotes = buf.quotes,
          quoteComparisonScope = buf.comparisonScope,
          quoteError = buf.quoteError,
          activeOffRampQuote = buf.offRampQuote,
          offRampError = buf.offRampError,
          bannerMessage = buf.bannerMessage,
          bannerIsError = buf.bannerIsError,
          resumedSwapCount = buf.resumedSwapCount,
          estimatedTotalUsd = totalUsd,
          estimatedSpendableUsd = spendableUsd,
          estimatedPendingUsd = pendingUsd,
          estimatedLockedUsd = lockedUsd,
          demoStepsCompleted = buf.demoSteps,
          redactedLogSnapshot = RedactingLogger.snapshot(),
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AureomUiState(),
      )

  init {
    viewModelScope.launch {
      repository.seedInitialSandboxIfEmpty()
      val resumed = repository.resumeInterruptedSwaps()
      if (resumed.isNotEmpty()) {
        buffers.update {
          it.copy(
            resumedSwapCount = resumed.size,
            demoSteps = it.demoSteps + 7,
            bannerMessage = "Resumed monitoring ${resumed.size} persisted swap(s) after restart.",
            bannerIsError = false,
          )
        }
      }
      preferences.touchPriceTimestamp()
    }
  }

  fun dismissBanner() {
    buffers.update { it.copy(bannerMessage = null, bannerIsError = false) }
  }

  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch { preferences.setThemeMode(mode) }
  }

  fun toggleWalletConnected(connected: Boolean) {
    viewModelScope.launch {
      preferences.setWalletConnected(connected)
      if (connected) markDemoStep(1)
      showBanner(
        if (connected) "Non-custodial wallet adapter connected."
        else "Wallet disconnected — signing actions blocked.",
        isError = !connected,
      )
    }
  }

  fun toggleEmergencyPause(paused: Boolean) {
    viewModelScope.launch {
      preferences.setEmergencyPause(paused)
      showBanner(
        if (paused) "Emergency pause enabled: new quotes/swaps halted; HTLC refunds remain open."
        else "Emergency pause lifted.",
        isError = paused,
      )
    }
  }

  fun setAllowUnlimitedApprovals(allowed: Boolean) {
    viewModelScope.launch { preferences.setAllowUnlimitedApprovals(allowed) }
  }

  fun simulateTestDeposit(assetId: AssetId, amountBaseUnits: BigInteger) {
    viewModelScope.launch {
      when (val outcome = repository.observeTestDeposit(assetId, amountBaseUnits)) {
        is ActionOutcome.Success -> {
          markDemoStep(3)
          markDemoStep(10)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun confirmPendingDeposits(assetId: AssetId) {
    viewModelScope.launch {
      when (val outcome = repository.confirmPendingDeposits(assetId)) {
        is ActionOutcome.Success -> {
          markDemoStep(3)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun executeSend(assetId: AssetId, destination: String, memo: String?, amountBaseUnits: BigInteger) {
    viewModelScope.launch {
      val connected = uiState.value.settings.walletConnected
      when (val outcome = repository.executeSend(assetId, destination, memo, amountBaseUnits, connected)) {
        is ActionOutcome.Success -> {
          markDemoStep(10)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun requestQuotes(
    fromAssetId: AssetId,
    toAssetId: AssetId,
    inputHuman: String,
    slippageBps: Int,
  ) {
    val fromAsset = AssetRegistry.findById(fromAssetId) ?: return
    val baseUnits = MoneyMath.parseHumanToBaseUnits(inputHuman, fromAsset.decimals)
    if (baseUnits == null || baseUnits <= BigInteger.ZERO) {
      buffers.update {
        it.copy(quotes = emptyList(), quoteError = "Enter a valid decimal amount (up to ${fromAsset.decimals} decimals).")
      }
      return
    }
    val state = uiState.value
    when (
      val result =
        repository.quoteEngine.evaluateQuotes(
          fromAssetId = fromAssetId,
          toAssetId = toAssetId,
          inputBaseUnits = baseUnits,
          slippageBps = slippageBps,
          balances = state.balances,
          emergencyPaused = state.settings.emergencyPauseNewSwaps,
        )
    ) {
      is QuoteResult.Success -> {
        markDemoStep(4)
        buffers.update {
          it.copy(
            quotes = result.quotes,
            comparisonScope = result.comparisonScope,
            quoteError = null,
          )
        }
      }
      is QuoteResult.Rejected -> {
        buffers.update {
          it.copy(quotes = emptyList(), comparisonScope = null, quoteError = result.reason)
        }
      }
    }
  }

  fun acceptAndSignQuote(quote: SwapQuote) {
    viewModelScope.launch {
      val state = uiState.value
      val idempotencyKey = "idem_${quote.quoteId}_${UUID.randomUUID().toString().take(6)}"
      when (
        val accept =
          repository.acceptQuoteAndPrepareSwap(
            quote = quote,
            idempotencyKey = idempotencyKey,
            emergencyPaused = state.settings.emergencyPauseNewSwaps,
            walletConnected = state.settings.walletConnected,
          )
      ) {
        is ActionOutcome.Success -> {
          // Immediately sign Leg 1 funding from the preview confirmation
          when (
            val fund = repository.signAndFundSwapLeg1(accept.data.id, state.settings.walletConnected)
          ) {
            is ActionOutcome.Success -> {
              buffers.update { it.copy(quotes = emptyList(), quoteError = null) }
              if (quote.outputAssetId == AssetRegistry.USDC_SEP_ID) {
                markDemoStep(8)
              }
              markDemoStep(10)
              showBanner(fund.message, isError = false)
            }
            is ActionOutcome.Failure -> showBanner(fund.reason, isError = true)
          }
        }
        is ActionOutcome.Failure -> showBanner(accept.reason, isError = true)
      }
    }
  }

  fun observeCounterpartyLeg2(swapId: String) {
    viewModelScope.launch {
      when (val outcome = repository.observeCounterpartyLeg2(swapId)) {
        is ActionOutcome.Success -> showBanner(outcome.message, isError = false)
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun redeemHtlcSwap(swapId: String) {
    viewModelScope.launch {
      val connected = uiState.value.settings.walletConnected
      when (val outcome = repository.signAndRedeemHtlcSwap(swapId, connected)) {
        is ActionOutcome.Success -> {
          markDemoStep(5)
          markDemoStep(10)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun simulateCounterpartyTimeout(swapId: String) {
    viewModelScope.launch {
      when (val outcome = repository.simulateCounterpartyTimeout(swapId)) {
        is ActionOutcome.Success -> showBanner(outcome.message, isError = true)
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun signAndRefundSwap(swapId: String) {
    viewModelScope.launch {
      val connected = uiState.value.settings.walletConnected
      when (val outcome = repository.signAndSubmitRefund(swapId, connected)) {
        is ActionOutcome.Success -> {
          markDemoStep(6)
          markDemoStep(10)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun simulateReorg(swapId: String) {
    viewModelScope.launch {
      when (val outcome = repository.simulateAndHandleReorg(swapId)) {
        is ActionOutcome.Success -> showBanner(outcome.message, isError = true)
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun recoverFromReorg(swapId: String) {
    viewModelScope.launch {
      when (val outcome = repository.recoverReorgedSwap(swapId)) {
        is ActionOutcome.Success -> showBanner(outcome.message, isError = false)
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun simulateBackendRestartRecovery() {
    viewModelScope.launch {
      val resumed = repository.resumeInterruptedSwaps()
      markDemoStep(7)
      buffers.update {
        it.copy(
          resumedSwapCount = resumed.size,
          bannerMessage =
            if (resumed.isNotEmpty()) {
              "Simulated restart: recovered ${resumed.size} active swap(s) from Room persistence with Keystore secret references intact."
            } else {
              "Simulated restart: Room & Keystore vault checked (0 in-flight swaps currently open)."
            },
          bannerIsError = false,
        )
      }
    }
  }

  fun requestOffRampQuote(
    inputAssetId: AssetId,
    amountHuman: String,
    eligibilityStatus: EligibilityStatus = EligibilityStatus.ELIGIBLE,
  ) {
    val asset = AssetRegistry.findById(inputAssetId) ?: return
    val baseUnits = MoneyMath.parseHumanToBaseUnits(amountHuman, asset.decimals)
    if (baseUnits == null || baseUnits <= BigInteger.ZERO) {
      buffers.update { it.copy(offRampQuote = null, offRampError = "Enter a valid amount.") }
      return
    }
    when (val res = repository.offRampAdapter.createQuote(inputAssetId, baseUnits, eligibilityStatus)) {
      is OffRampQuoteResult.Success -> {
        buffers.update { it.copy(offRampQuote = res.quote, offRampError = null) }
      }
      is OffRampQuoteResult.Rejected -> {
        buffers.update { it.copy(offRampQuote = null, offRampError = res.reason) }
      }
    }
  }

  fun executeOffRampPayout(quote: FiatOffRampQuote, simulateProviderFailure: Boolean = false) {
    viewModelScope.launch {
      val connected = uiState.value.settings.walletConnected
      val key = "offramp_${quote.quoteId}_${UUID.randomUUID().toString().take(6)}"
      when (
        val outcome =
          repository.initiateFiatOffRamp(
            quote = quote,
            idempotencyKey = key,
            walletConnected = connected,
            simulateProviderFailure = simulateProviderFailure,
          )
      ) {
        is ActionOutcome.Success -> {
          markDemoStep(9)
          markDemoStep(10)
          buffers.update { it.copy(offRampQuote = null, offRampError = null) }
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun settleBankPayout(payoutId: String) {
    viewModelScope.launch {
      when (val outcome = repository.settleBankPayout(payoutId)) {
        is ActionOutcome.Success -> {
          markDemoStep(9)
          showBanner(outcome.message, isError = false)
        }
        is ActionOutcome.Failure -> showBanner(outcome.reason, isError = true)
      }
    }
  }

  fun saveAutoConvertRule(rule: AutoConvertRule) {
    viewModelScope.launch {
      repository.saveAutoConvertRule(rule)
      showBanner("Receive-and-convert policy saved.", isError = false)
    }
  }

  private fun markDemoStep(step: Int) {
    buffers.update { it.copy(demoSteps = it.demoSteps + step) }
  }

  private fun showBanner(message: String, isError: Boolean) {
    buffers.update { it.copy(bannerMessage = message, bannerIsError = isError) }
  }
}
