package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.AssetRegistry
import com.example.domain.model.BankPayoutState
import com.example.domain.util.MoneyMath
import com.example.ui.components.PersistentNetworkBar
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.EmeraldConfirmed
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.MidnightBluePressed
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.MonoValueStyle
import com.example.ui.viewmodel.AureomUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
  uiState: AureomUiState,
  onOpenSend: () -> Unit,
  onOpenReceive: () -> Unit,
  onNavigateSwap: () -> Unit,
  onNavigateCashOut: () -> Unit,
  onNavigateAssets: () -> Unit,
  onNavigateActivity: () -> Unit,
  onSimulateRestart: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val timestampFmt = SimpleDateFormat("MMM d, yyyy · HH:mm:ss z", Locale.US)
  val priceTimeText = timestampFmt.format(Date(uiState.settings.lastPriceUpdateMillis))

  val activeSwaps = uiState.swaps.filter { !it.state.isTerminal }
  val usdcBalance = uiState.balances[AssetRegistry.USDC_SEP_ID]
  val usdcAsset = AssetRegistry.findById(AssetRegistry.USDC_SEP_ID)!!
  val usdcSpendableStr =
    MoneyMath.formatBaseUnits(
      usdcBalance?.spendableBaseUnits ?: java.math.BigInteger.ZERO,
      usdcAsset.decimals,
    )
  val settledBankUsdCents =
    uiState.fiatPayouts
      .filter { it.bankPayoutState == BankPayoutState.PAID_OUT }
      .sumOf { it.quote.netUsdPayoutCents }
  val settlingBankUsdCents =
    uiState.fiatPayouts
      .filter { it.bankPayoutState == BankPayoutState.SETTLING || it.bankPayoutState == BankPayoutState.QUEUED }
      .sumOf { it.quote.netUsdPayoutCents }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      PersistentNetworkBar(
        walletConnected = uiState.settings.walletConnected,
        emergencyPaused = uiState.settings.emergencyPauseNewSwaps,
      )
    }

    // Hero Balance Card — Midnight Blue & Burnished Gold aesthetic
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .drawBehind {
                drawRect(
                  brush =
                    Brush.linearGradient(
                      colors = listOf(MidnightBlue, MidnightBluePressed, Color(0xFF132D5A))
                    )
                )
                // Subtle architectural vault lines
                drawCircle(
                  color = Color(0x18E0B45C),
                  radius = size.width * 0.42f,
                  center = Offset(size.width * 0.92f, size.height * 0.15f),
                )
                drawCircle(
                  color = Color(0x10FAF8F4),
                  radius = size.width * 0.28f,
                  center = Offset(size.width * 0.88f, size.height * 0.22f),
                )
              }
              .padding(20.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "ESTIMATED PORTFOLIO VALUE (USD)",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFD5DFEF),
              )
              Surface(
                color = Color(0x28E0B45C),
                shape = RoundedCornerShape(8.dp),
              ) {
                Text(
                  text = "Indicative Estimate",
                  style = MaterialTheme.typography.labelSmall,
                  color = Color(0xFFF6D992),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                )
              }
            }

            Text(
              text = MoneyMath.formatUsd(uiState.estimatedTotalUsd),
              style = MaterialTheme.typography.displaySmall,
              color = Color(0xFFFAF8F4),
              modifier = Modifier.testTag("hero_total_usd"),
            )

            Text(
              text = "Price snapshot: $priceTimeText",
              style = MonoCaptionStyle,
              color = Color(0xFFB4C3DC),
            )

            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              BalanceBucketChip(
                label = "Spendable",
                amount = MoneyMath.formatUsd(uiState.estimatedSpendableUsd),
                tint = Color(0xFF8BE2B6),
                modifier = Modifier.weight(1f),
              )
              BalanceBucketChip(
                label = "Pending",
                amount = MoneyMath.formatUsd(uiState.estimatedPendingUsd),
                tint = Color(0xFFF9C873),
                modifier = Modifier.weight(1f),
              )
              BalanceBucketChip(
                label = "HTLC Locked",
                amount = MoneyMath.formatUsd(uiState.estimatedLockedUsd),
                tint = Color(0xFFAEC7FF),
                modifier = Modifier.weight(1f),
              )
            }
          }
        }
      }
    }

    // Large Send / Receive / Swap / Cash Out Action Buttons
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          LargeWalletActionButton(
            label = "Send",
            icon = Icons.AutoMirrored.Filled.CallMade,
            primary = true,
            onClick = onOpenSend,
            modifier = Modifier.weight(1f).testTag("home_send_button"),
          )
          LargeWalletActionButton(
            label = "Receive",
            icon = Icons.AutoMirrored.Filled.CallReceived,
            primary = true,
            onClick = onOpenReceive,
            modifier = Modifier.weight(1f).testTag("home_receive_button"),
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          LargeWalletActionButton(
            label = "Swap",
            icon = Icons.Filled.SwapHoriz,
            primary = false,
            onClick = onNavigateSwap,
            modifier = Modifier.weight(1f).testTag("home_swap_button"),
          )
          LargeWalletActionButton(
            label = "Cash Out",
            icon = Icons.Filled.AccountBalance,
            primary = false,
            onClick = onNavigateCashOut,
            modifier = Modifier.weight(1f).testTag("home_cashout_button"),
          )
        }
      }
    }

    // Explicit Distinction: USD-Denominated Stablecoins vs. Bank USD
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Dollar Positions (Kept Strictly Separate)", style = MaterialTheme.typography.titleSmall)
            TextButton(onClick = onNavigateAssets) { Text("Details") }
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLow,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f),
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Stablecoin Token (Sepolia)", style = MaterialTheme.typography.labelSmall)
                Text("$usdcSpendableStr USDC", style = MonoValueStyle, fontWeight = FontWeight.Bold)
                Text(
                  "Not bank USD · No $1.00 guarantee",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLow,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f),
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Bank Account USD (ACH)", style = MaterialTheme.typography.labelSmall)
                Text(
                  MoneyMath.formatUsdCents(settledBankUsdCents),
                  style = MonoValueStyle,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  if (settlingBankUsdCents > 0L) "+${MoneyMath.formatUsdCents(settlingBankUsdCents)} settling"
                  else "Via regulated off-ramp",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }
      }
    }

    // Active Swap / Recovery Alert
    if (activeSwaps.isNotEmpty()) {
      item {
        val focus = activeSwaps.first()
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = AmberContainer),
          border = BorderStroke(1.dp, AmberPending.copy(alpha = 0.4f)),
          onClick = onNavigateSwap,
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = AmberPending)
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${activeSwaps.size} Active Swap · ${focus.state.label}",
                style = MaterialTheme.typography.titleSmall,
                color = AmberPending,
              )
              Text(
                text = focus.expectedNextAction,
                style = MaterialTheme.typography.bodySmall,
                color = AmberPending,
              )
            }
            Text("Open", style = MaterialTheme.typography.labelLarge, color = AmberPending)
          }
        }
      }
    }

    // Interactive 10-Step Working Demonstration Checklist
    item {
      val steps =
        listOf(
          1 to "Connect non-custodial dev wallet",
          2 to "Display explicit versioned asset registry",
          3 to "Receive test deposit (Observed -> Confirmed)",
          4 to "Obtain & compare conversion quote",
          5 to "Complete compatible HTLC atomic swap",
          6 to "Demonstrate counterparty failure & refund",
          7 to "Survive app/backend restart during monitoring",
          8 to "Convert into USD stablecoin (with disclosures)",
          9 to "Simulate eligible bank USD off-ramp payout",
          10 to "Inspect plain-language activity timeline",
        )
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column {
              Text("Working Demo Walkthrough", style = MaterialTheme.typography.titleSmall)
              Text(
                "${uiState.demoStepsCompleted.size}/10 demonstration steps exercised",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            TextButton(onClick = onSimulateRestart) {
              Text("Test Restart")
            }
          }
          steps.forEach { (num, label) ->
            val done = num in uiState.demoStepsCompleted
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = if (done) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (done) EmeraldConfirmed else MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = "$num. $label",
                style = MaterialTheme.typography.bodySmall,
                color =
                  if (done) MaterialTheme.colorScheme.onSurface
                  else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }
    }

    // Recent Activity Preview
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Recent Activity", style = MaterialTheme.typography.titleMedium)
        TextButton(onClick = onNavigateActivity) { Text("View All") }
      }
    }

    if (uiState.activities.isEmpty()) {
      item {
        Text(
          "No wallet events yet. Receive a test deposit or request a swap quote.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    } else {
      items(uiState.activities.take(4), key = { it.id }) { event ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          onClick = onNavigateActivity,
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                event.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
              )
              Spacer(Modifier.width(8.dp))
              StatusPill(
                text = event.statusLabel,
                tone =
                  when {
                    event.isError -> StatusTone.ERROR
                    event.isConfirmed -> StatusTone.CONFIRMED
                    else -> StatusTone.PENDING
                  },
              )
            }
            Text(
              event.plainExplanation,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun BalanceBucketChip(
  label: String,
  amount: String,
  tint: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    color = Color(0x1FFFFFFF),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFFD5DFEF))
      Text(amount, style = MonoValueStyle, color = tint, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
private fun LargeWalletActionButton(
  label: String,
  icon: ImageVector,
  primary: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  if (primary) {
    Button(
      onClick = onClick,
      modifier = modifier.height(54.dp),
      shape = RoundedCornerShape(16.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
    ) {
      Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
      Spacer(Modifier.width(8.dp))
      Text(label, style = MaterialTheme.typography.labelLarge)
    }
  } else {
    OutlinedButton(
      onClick = onClick,
      modifier = modifier.height(54.dp),
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline),
    ) {
      Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
      Spacer(Modifier.width(8.dp))
      Text(label, style = MaterialTheme.typography.labelLarge)
    }
  }
}
