package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetDefinition
import com.example.domain.model.AssetKind
import com.example.domain.model.AssetRegistry
import com.example.domain.model.BankPayoutState
import com.example.domain.model.IntegrationStatus
import com.example.domain.util.MoneyMath
import com.example.ui.components.AssetRegistryDetailSheet
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.toTone
import com.example.ui.theme.AmberPending
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.MonoValueStyle
import com.example.ui.viewmodel.AureomUiState
import java.math.BigInteger

private enum class AssetFilter(val label: String) {
  ALL("All"),
  OPERATIONAL("Testnet / Active"),
  STABLECOINS("Stablecoins"),
  UNVERIFIED("Unverified"),
  DISABLED("Unavailable / Deprecated"),
}

@Composable
fun AssetsScreen(
  uiState: AureomUiState,
  modifier: Modifier = Modifier,
) {
  var filter by remember { mutableStateOf(AssetFilter.ALL) }
  var inspectedAsset by remember { mutableStateOf<AssetDefinition?>(null) }

  val filteredAssets =
    remember(filter) {
      when (filter) {
        AssetFilter.ALL -> AssetRegistry.assets
        AssetFilter.OPERATIONAL -> AssetRegistry.assets.filter { it.isSpendableOrSwappable }
        AssetFilter.STABLECOINS -> AssetRegistry.assets.filter { it.assetKind == AssetKind.STABLECOIN }
        AssetFilter.UNVERIFIED ->
          AssetRegistry.assets.filter {
            it.integrationStatus == IntegrationStatus.UNVERIFIED_OBSERVATION
          }
        AssetFilter.DISABLED ->
          AssetRegistry.assets.filter {
            it.integrationStatus == IntegrationStatus.UNAVAILABLE ||
              it.integrationStatus == IntegrationStatus.DEPRECATED
          }
      }
    }

  val settledBankUsdCents =
    uiState.fiatPayouts
      .filter { it.bankPayoutState == BankPayoutState.PAID_OUT }
      .sumOf { it.quote.netUsdPayoutCents }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Explicit Asset Registry", style = MaterialTheme.typography.headlineSmall)
        Text(
          "Registry v${AssetRegistry.REGISTRY_VERSION} · Assets identified by (chainId, tokenIdentifier). Native, wrapped, bridged, and stablecoin assets stay distinct.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    item {
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        AssetFilter.entries.forEach { f ->
          FilterChip(
            selected = filter == f,
            onClick = { filter = f },
            label = { Text(f.label) },
            modifier = Modifier.testTag("asset_filter_${f.name.lowercase()}"),
          )
        }
      }
    }

    // Separate Bank USD card so it is never conflated with USD stablecoin tokens
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "US Dollars (Regulated Bank Payouts)",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
              "Separate from on-chain stablecoins (USDC / USDC.e). Requires fiat off-ramp eligibility.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
          Text(
            MoneyMath.formatUsdCents(settledBankUsdCents),
            style = MonoValueStyle,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
        }
      }
    }

    items(filteredAssets, key = { it.id.serializedKey() }) { asset ->
      val balance = uiState.balances[asset.id] ?: AssetBalance(asset.id)
      val spendableStr = MoneyMath.formatBaseUnits(balance.spendableBaseUnits, asset.decimals)
      val pendingStr = MoneyMath.formatBaseUnits(balance.pendingUnconfirmedBaseUnits, asset.decimals)
      val lockedStr = MoneyMath.formatBaseUnits(balance.lockedHtlcBaseUnits, asset.decimals)
      val estUsd =
        if (asset.isSpendableOrSwappable) {
          MoneyMath.formatUsd(
            MoneyMath.estimateUsd(balance.totalBaseUnits, asset.decimals, asset.indicativeUsdPrice)
          )
        } else {
          "Unvalued"
        }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        onClick = { inspectedAsset = asset },
        modifier = Modifier.fillMaxWidth().testTag("asset_card_${asset.ticker}"),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(asset.assetName, style = MaterialTheme.typography.titleSmall)
                StatusPill(text = asset.assetKind.badgeLabel, tone = StatusTone.NEUTRAL)
              }
              Text(
                "${asset.ticker} · ${asset.networkName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Text(
                "${asset.id.chainId} · ${asset.id.tokenIdentifier.take(20)}${if (asset.id.tokenIdentifier.length > 20) "..." else ""}",
                style = MonoCaptionStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              StatusPill(text = asset.integrationStatus.label, tone = asset.integrationStatus.toTone())
              Text(
                estUsd,
                style = MonoValueStyle,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp),
              )
            }
          }

          HorizontalDivider()
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              "Spendable: $spendableStr",
              style = MonoCaptionStyle,
              color = MaterialTheme.colorScheme.onSurface,
            )
            if (balance.pendingUnconfirmedBaseUnits > BigInteger.ZERO) {
              Text("Pending: $pendingStr", style = MonoCaptionStyle, color = AmberPending)
            }
            if (balance.lockedHtlcBaseUnits > BigInteger.ZERO) {
              Text(
                "Locked: $lockedStr",
                style = MonoCaptionStyle,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }

          asset.riskDisclosure?.let { note ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLow,
              shape = RoundedCornerShape(8.dp),
            ) {
              Text(
                note,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(8.dp),
              )
            }
          }
        }
      }
    }
  }

  inspectedAsset?.let { asset ->
    AssetRegistryDetailSheet(
      asset = asset,
      balance = uiState.balances[asset.id] ?: AssetBalance(asset.id),
      onDismiss = { inspectedAsset = null },
    )
  }
}
