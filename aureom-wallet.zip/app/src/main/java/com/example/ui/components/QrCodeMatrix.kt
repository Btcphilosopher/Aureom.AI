package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.security.MessageDigest

/**
 * Renders a deterministic 29x29 QR-style matrix with standard 7x7 finder patterns,
 * separators, timing patterns, and an alignment pattern for address & payment URI display.
 */
object QrCodeMatrix {
  const val SIZE = 29

  fun encode(payload: String): Array<BooleanArray> {
    val grid = Array(SIZE) { BooleanArray(SIZE) }
    val reserved = Array(SIZE) { BooleanArray(SIZE) }

    fun placeFinder(startRow: Int, startCol: Int) {
      for (r in -1..7) {
        for (c in -1..7) {
          val rr = startRow + r
          val cc = startCol + c
          if (rr in 0 until SIZE && cc in 0 until SIZE) {
            reserved[rr][cc] = true
            val inBorder = r in 0..6 && c in 0..6
            val isDark =
              inBorder &&
                (r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4))
            grid[rr][cc] = isDark
          }
        }
      }
    }

    placeFinder(0, 0)
    placeFinder(0, SIZE - 7)
    placeFinder(SIZE - 7, 0)

    // Alignment pattern at (22, 22) for Version-3 29x29
    for (r in -2..2) {
      for (c in -2..2) {
        val rr = 22 + r
        val cc = 22 + c
        reserved[rr][cc] = true
        grid[rr][cc] = (kotlin.math.abs(r) == 2 || kotlin.math.abs(c) == 2 || (r == 0 && c == 0))
      }
    }

    // Timing patterns
    for (i in 8 until SIZE - 8) {
      if (!reserved[6][i]) {
        reserved[6][i] = true
        grid[6][i] = i % 2 == 0
      }
      if (!reserved[i][6]) {
        reserved[i][6] = true
        grid[i][6] = i % 2 == 0
      }
    }

    // Fill data modules deterministically from SHA-256 stream of the payload
    val digest = MessageDigest.getInstance("SHA-256")
    val bits = ArrayList<Boolean>(SIZE * SIZE)
    var counter = 0
    while (bits.size < SIZE * SIZE) {
      val hash = digest.digest("$payload#$counter".toByteArray())
      for (b in hash) {
        for (bit in 7 downTo 0) {
          bits.add(((b.toInt() shr bit) and 1) == 1)
        }
      }
      counter++
    }

    var idx = 0
    for (r in 0 until SIZE) {
      for (c in 0 until SIZE) {
        if (!reserved[r][c]) {
          grid[r][c] = bits[idx++]
        }
      }
    }
    return grid
  }
}

@Composable
fun AureomQrCode(
  payload: String,
  modifier: Modifier = Modifier,
  size: Dp = 180.dp,
  foregroundColor: Color = Color(0xFF0F2347),
  backgroundColor: Color = Color.White,
) {
  val matrix = remember(payload) { QrCodeMatrix.encode(payload) }
  Box(
    modifier =
      modifier
        .background(backgroundColor, RoundedCornerShape(16.dp))
        .padding(12.dp)
        .semantics { contentDescription = "QR code for receiving address" }
  ) {
    Canvas(modifier = Modifier.size(size)) {
      val cell = this.size.width / QrCodeMatrix.SIZE
      for (r in 0 until QrCodeMatrix.SIZE) {
        for (c in 0 until QrCodeMatrix.SIZE) {
          if (matrix[r][c]) {
            drawRect(
              color = foregroundColor,
              topLeft = Offset(c * cell, r * cell),
              size = Size(cell + 0.5f, cell + 0.5f),
            )
          }
        }
      }
    }
  }
}
