package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.ActivityCategory
import com.example.domain.model.ActivityEvent
import com.example.ui.components.RouteBadge
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.MonoValueStyle
import com.example.ui.viewmodel.AureomUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ActivityScreen(
  uiState: AureomUiState,
  modifier: Modifier = Modifier,
) {
  var selectedCategory by remember { mutableStateOf<ActivityCategory?>(null) }
  var inspectedEvent by remember { mutableStateOf<ActivityEvent?>(null) }
  val timeFormat = remember { SimpleDateFormat("MMM d · HH:mm:ss", Locale.US) }

  val filtered =
    remember(uiState.activities, selectedCategory) {
      if (selectedCategory == null) uiState.activities
      else uiState.activities.filter { it.category == selectedCategory }
    }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Activity Timeline", style = MaterialTheme.typography.headlineSmall)
        Text(
          "Plain-language explanations with verifiable transaction hashes, confirmation counts, and route custody types.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    item {
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        FilterChip(
          selected = selectedCategory == null,
          onClick = { selectedCategory = null },
          label = { Text("All") },
        )
        ActivityCategory.entries.forEach { cat ->
          FilterChip(
            selected = selectedCategory == cat,
            onClick = { selectedCategory = cat },
            label = { Text(cat.label) },
          )
        }
      }
    }

    if (filtered.isEmpty()) {
      item {
        Text(
          "No events in this category yet.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    } else {
      items(filtered, key = { it.id }) { event ->
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          onClick = { inspectedEvent = event },
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                event.title,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f),
              )
              StatusPill(
                text = event.statusLabel,
                tone =
                  when {
                    event.isError -> StatusTone.ERROR
                    event.isConfirmed -> StatusTone.CONFIRMED
                    else -> StatusTone.PENDING
                  },
              )
            }
            Text(
              event.plainExplanation,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                event.routeType?.let { RouteBadge(it) }
                Text(
                  timeFormat.format(Date(event.timestampMillis)),
                  style = MonoCaptionStyle,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              Text(event.amountDisplay, style = MonoValueStyle, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }

  inspectedEvent?.let { ev ->
    AlertDialog(
      onDismissRequest = { inspectedEvent = null },
      title = { Text(ev.title) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(ev.plainExplanation, style = MaterialTheme.typography.bodyMedium)
          HorizontalDivider()
          Text("Category: ${ev.category.label}", style = MonoCaptionStyle)
          Text("Amount: ${ev.amountDisplay}", style = MonoCaptionStyle)
          ev.routeType?.let { Text("Route Custody: ${it.custodyModel}", style = MonoCaptionStyle) }
          ev.confirmationsText?.let { Text("Confirmations: $it", style = MonoCaptionStyle) }
          ev.txHash?.let { Text("Tx Hash: $it", style = MonoCaptionStyle) }
          ev.providerReference?.let { Text("Provider Ref: $it", style = MonoCaptionStyle) }
          Text("Secrets/Preimages: Sealed locally, never exposed in activity log.", style = MonoCaptionStyle)
        }
      },
      confirmButton = {
        TextButton(onClick = { inspectedEvent = null }) { Text("Close") }
      },
    )
  }
}
