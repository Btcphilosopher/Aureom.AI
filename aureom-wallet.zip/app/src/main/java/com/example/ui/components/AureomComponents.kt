package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.custody.ConnectedAccount
import com.example.domain.custody.SigningPreview
import com.example.domain.model.AddressValidationResult
import com.example.domain.model.AssetBalance
import com.example.domain.model.AssetDefinition
import com.example.domain.model.AssetId
import com.example.domain.model.AssetKind
import com.example.domain.model.AssetRegistry
import com.example.domain.model.IntegrationStatus
import com.example.domain.model.RouteType
import com.example.domain.model.WalletOperation
import com.example.domain.util.MoneyMath
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.EmeraldConfirmed
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.MonoValueStyle
import java.math.BigInteger

@Composable
fun PersistentNetworkBar(
  walletConnected: Boolean,
  emergencyPaused: Boolean,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color =
      if (emergencyPaused) CrimsonContainer
      else MaterialTheme.colorScheme.surfaceContainerHigh,
    shape = RoundedCornerShape(14.dp),
    border =
      BorderStroke(
        1.dp,
        if (emergencyPaused) CrimsonAlert.copy(alpha = 0.4f)
        else MaterialTheme.colorScheme.outlineVariant,
      ),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f),
      ) {
        Icon(
          imageVector =
            if (emergencyPaused) Icons.Filled.PauseCircle
            else if (walletConnected) Icons.Filled.Shield
            else Icons.Filled.Warning,
          contentDescription = "Network status",
          tint =
            if (emergencyPaused) CrimsonAlert
            else if (walletConnected) EmeraldConfirmed
            else AmberPending,
          modifier = Modifier.size(18.dp),
        )
        Column {
          Text(
            text =
              if (emergencyPaused) "EMERGENCY PAUSE ACTIVE · New Swaps Halted"
              else "TESTNET SANDBOX · BTC-4 / LTC-4 / Sepolia",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (emergencyPaused) CrimsonAlert else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text =
              if (walletConnected) "Non-custodial signer connected · Live-value disabled"
              else "Wallet disconnected · Connect in Settings to sign",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
      ) {
        Text(
          text = "v${AssetRegistry.REGISTRY_VERSION}",
          style = MonoCaptionStyle,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
      }
    }
  }
}

@Composable
fun StatusPill(
  text: String,
  tone: StatusTone,
  modifier: Modifier = Modifier,
) {
  val (bg, fg) =
    when (tone) {
      StatusTone.CONFIRMED -> EmeraldContainer to EmeraldConfirmed
      StatusTone.PENDING -> AmberContainer to AmberPending
      StatusTone.ERROR -> CrimsonContainer to CrimsonAlert
      StatusTone.NEUTRAL ->
        MaterialTheme.colorScheme.surfaceContainerHigh to MaterialTheme.colorScheme.onSurfaceVariant
      StatusTone.PRIMARY ->
        MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    }
  Surface(
    modifier = modifier,
    color = bg,
    shape = RoundedCornerShape(8.dp),
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.SemiBold,
      color = fg,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

enum class StatusTone {
  CONFIRMED,
  PENDING,
  ERROR,
  NEUTRAL,
  PRIMARY,
}

fun IntegrationStatus.toTone(): StatusTone =
  when (this) {
    IntegrationStatus.SUPPORTED -> StatusTone.CONFIRMED
    IntegrationStatus.TESTNET -> StatusTone.PRIMARY
    IntegrationStatus.UNAVAILABLE -> StatusTone.NEUTRAL
    IntegrationStatus.DEPRECATED -> StatusTone.ERROR
    IntegrationStatus.UNVERIFIED_OBSERVATION -> StatusTone.PENDING
  }

@Composable
fun RouteBadge(routeType: RouteType, modifier: Modifier = Modifier) {
  val tone =
    when (routeType) {
      RouteType.ATOMIC_SWAP -> StatusTone.CONFIRMED
      RouteType.ON_CHAIN_SWAP -> StatusTone.PRIMARY
      RouteType.PROVIDER_MEDIATED -> StatusTone.PENDING
      RouteType.FIAT_OFF_RAMP -> StatusTone.NEUTRAL
    }
  StatusPill(text = routeType.shortTag, tone = tone, modifier = modifier)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiveAssetBottomSheet(
  initialAssetId: AssetId,
  balances: Map<AssetId, AssetBalance>,
  accountForChain: (String) -> ConnectedAccount?,
  onSimulateTestDeposit: (AssetId, BigInteger) -> Unit,
  onConfirmPendingDeposits: (AssetId) -> Unit,
  onDismiss: () -> Unit,
) {
  val receivableAssets = remember {
    AssetRegistry.assets.filter {
      it.isSpendableOrSwappable && WalletOperation.RECEIVE in it.supportedOperations
    }
  }
  var selectedAsset by remember {
    mutableStateOf(
      receivableAssets.firstOrNull { it.id == initialAssetId } ?: receivableAssets.first()
    )
  }
  val account = accountForChain(selectedAsset.id.chainId)
  val balance = balances[selectedAsset.id] ?: AssetBalance(selectedAsset.id)
  val clipboard = LocalClipboardManager.current
  var copied by remember(selectedAsset.id) { mutableStateOf(false) }

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Text("Receive Asset", style = MaterialTheme.typography.headlineSmall)

      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        receivableAssets.forEach { asset ->
          FilterChip(
            selected = asset.id == selectedAsset.id,
            onClick = {
              selectedAsset = asset
              copied = false
            },
            label = { Text(asset.ticker) },
          )
        }
      }

      Card(
        colors =
          CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(14.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = "NETWORK: ${selectedAsset.networkName.uppercase()}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
          Text(
            text =
              "This address accepts ONLY ${selectedAsset.assetName} (${selectedAsset.ticker}) on ${selectedAsset.networkName}. Token ID: ${selectedAsset.id.tokenIdentifier.take(18)}${if (selectedAsset.id.tokenIdentifier.length > 18) "..." else ""}.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
        }
      }

      if (account != null) {
        val qrPayload =
          if (selectedAsset.requiresMemo && account.memoOrTag != null) {
            "${selectedAsset.id.chainId}:${account.publicAddress}?tag=${account.memoOrTag}"
          } else {
            "${selectedAsset.id.chainId}:${account.publicAddress}"
          }
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          AureomQrCode(payload = qrPayload, size = 170.dp)
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Receiving Address", style = MaterialTheme.typography.labelSmall)
                Text(
                  text = account.publicAddress,
                  style = MonoValueStyle,
                )
              }
              IconButton(
                onClick = {
                  clipboard.setText(AnnotatedString(account.publicAddress))
                  copied = true
                }
              ) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy receiving address")
              }
            }
          }
          if (copied) {
            Text(
              "Address copied to clipboard",
              style = MaterialTheme.typography.labelSmall,
              color = EmeraldConfirmed,
            )
          }
        }

        if (selectedAsset.requiresMemo) {
          Surface(
            color = AmberContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                "${selectedAsset.memoLabel ?: "Destination Tag"} Required: ${account.memoOrTag ?: "409812"}",
                style = MaterialTheme.typography.titleSmall,
                color = AmberPending,
              )
              Text(
                "Deposits missing this tag may require manual recovery.",
                style = MaterialTheme.typography.bodySmall,
                color = AmberPending,
              )
            }
          }
        }
      }

      HorizontalDivider()
      Text("Observed vs. Confirmed Deposits", style = MaterialTheme.typography.titleSmall)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column {
          Text("Spendable (Confirmed)", style = MaterialTheme.typography.labelSmall)
          Text(
            "${MoneyMath.formatBaseUnits(balance.spendableBaseUnits, selectedAsset.decimals)} ${selectedAsset.ticker}",
            style = MonoValueStyle,
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("Pending (Unconfirmed)", style = MaterialTheme.typography.labelSmall)
          Text(
            "${MoneyMath.formatBaseUnits(balance.pendingUnconfirmedBaseUnits, selectedAsset.decimals)} ${selectedAsset.ticker}",
            style = MonoValueStyle,
            color = AmberPending,
          )
        }
      }
      Text(
        selectedAsset.confirmationPolicy.finalityNote,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = {
            val testDepositUnits =
              MoneyMath.parseHumanToBaseUnits(
                when (selectedAsset.ticker) {
                  "BTC-TEST" -> "0.005"
                  "LTC-TEST" -> "0.5"
                  "ETH-SEP", "WETH-SEP" -> "0.1"
                  else -> "25.0"
                },
                selectedAsset.decimals,
              ) ?: selectedAsset.minimumAmountBaseUnits
            onSimulateTestDeposit(selectedAsset.id, testDepositUnits)
          },
          modifier = Modifier.weight(1f).testTag("simulate_deposit_button"),
        ) {
          Text("Simulate Deposit")
        }
        Button(
          onClick = { onConfirmPendingDeposits(selectedAsset.id) },
          enabled = balance.pendingUnconfirmedBaseUnits > BigInteger.ZERO,
          modifier = Modifier.weight(1f).testTag("confirm_deposit_button"),
        ) {
          Text("Confirm Pending")
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendAssetBottomSheet(
  initialAssetId: AssetId,
  balances: Map<AssetId, AssetBalance>,
  onExecuteSend: (AssetId, String, String?, BigInteger) -> Unit,
  onDismiss: () -> Unit,
) {
  val sendableAssets = remember {
    AssetRegistry.assets.filter {
      it.isSpendableOrSwappable && WalletOperation.SEND in it.supportedOperations
    }
  }
  var selectedAsset by remember {
    mutableStateOf(sendableAssets.firstOrNull { it.id == initialAssetId } ?: sendableAssets.first())
  }
  var destination by remember(selectedAsset.id) {
    mutableStateOf(
      when {
        selectedAsset.id.chainId.startsWith("bitcoin") -> "tb1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3q0sl5k7"
        selectedAsset.id.chainId.startsWith("litecoin") -> "tltc1q4p8z6w7k3m9n2v5x7y8z0a2c4e6g8h0j2l4n6p"
        selectedAsset.id.chainId.startsWith("xrpl") -> "rPT1Sjq2YGrBMTttX4GZHjKu9dyfzbpAYe"
        else -> "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC"
      }
    )
  }
  var memo by remember(selectedAsset.id) {
    mutableStateOf(if (selectedAsset.requiresMemo) "104521" else "")
  }
  var amountText by remember(selectedAsset.id) {
    mutableStateOf(
      when (selectedAsset.ticker) {
        "BTC-TEST" -> "0.002"
        "ETH-SEP", "WETH-SEP" -> "0.05"
        "LTC-TEST" -> "0.25"
        else -> "15.0"
      }
    )
  }
  var showPreview by remember { mutableStateOf(false) }

  val balance = balances[selectedAsset.id] ?: AssetBalance(selectedAsset.id)
  val feeAsset = AssetRegistry.findById(selectedAsset.feeAssetId) ?: selectedAsset
  val parsedAmount = MoneyMath.parseHumanToBaseUnits(amountText, selectedAsset.decimals)
  val validation = AssetRegistry.validateAddress(selectedAsset.id, destination, memo.ifBlank { null })

  val estFee =
    when (feeAsset.id) {
      AssetRegistry.BTC_TEST_ID -> BigInteger.valueOf(2_500L)
      AssetRegistry.LTC_TEST_ID -> BigInteger.valueOf(25_000L)
      AssetRegistry.ETH_SEP_ID -> BigInteger("1200000000000000")
      AssetRegistry.XRP_TEST_ID -> BigInteger.valueOf(12L)
      else -> BigInteger.ZERO
    }
  val feeBal = balances[feeAsset.id]?.spendableBaseUnits ?: BigInteger.ZERO
  val insufficientFee =
    if (parsedAmount == null) false
    else if (feeAsset.id == selectedAsset.id) feeBal < parsedAmount + estFee
    else feeBal < estFee
  val insufficientPrincipal = parsedAmount != null && balance.spendableBaseUnits < parsedAmount

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text("Send Asset", style = MaterialTheme.typography.headlineSmall)

      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        sendableAssets.forEach { asset ->
          FilterChip(
            selected = asset.id == selectedAsset.id,
            onClick = { selectedAsset = asset },
            label = { Text(asset.ticker) },
          )
        }
      }

      Text(
        "Spendable: ${MoneyMath.formatBaseUnits(balance.spendableBaseUnits, selectedAsset.decimals)} ${selectedAsset.ticker} · Network: ${selectedAsset.networkName}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      OutlinedTextField(
        value = destination,
        onValueChange = { destination = it },
        label = { Text("Destination Address (${selectedAsset.networkName})") },
        modifier = Modifier.fillMaxWidth().testTag("send_destination_input"),
        singleLine = true,
      )

      if (selectedAsset.requiresMemo) {
        OutlinedTextField(
          value = memo,
          onValueChange = { memo = it },
          label = { Text("${selectedAsset.memoLabel ?: "Memo"} (Required)") },
          modifier = Modifier.fillMaxWidth().testTag("send_memo_input"),
          singleLine = true,
        )
      }

      OutlinedTextField(
        value = amountText,
        onValueChange = { amountText = it },
        label = { Text("Amount (${selectedAsset.ticker})") },
        modifier = Modifier.fillMaxWidth().testTag("send_amount_input"),
        singleLine = true,
      )

      if (validation is AddressValidationResult.Invalid) {
        Text(validation.reason, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
      } else if (validation is AddressValidationResult.Valid) {
        Surface(color = AmberContainer, shape = RoundedCornerShape(10.dp)) {
          Text(
            validation.warningNote,
            style = MaterialTheme.typography.bodySmall,
            color = AmberPending,
            modifier = Modifier.padding(10.dp),
          )
        }
      }

      if (insufficientPrincipal) {
        Text(
          "Insufficient spendable ${selectedAsset.ticker} balance.",
          color = CrimsonAlert,
          style = MaterialTheme.typography.bodySmall,
        )
      } else if (insufficientFee) {
        Text(
          "Insufficient ${feeAsset.ticker} balance to pay estimated network fee (${MoneyMath.formatBaseUnits(estFee, feeAsset.decimals)} ${feeAsset.ticker}).",
          color = CrimsonAlert,
          style = MaterialTheme.typography.bodySmall,
        )
      }

      Text(
        "Estimated Network Fee: ${MoneyMath.formatBaseUnits(estFee, feeAsset.decimals)} ${feeAsset.ticker}",
        style = MonoValueStyle,
      )

      val canPreview =
        validation is AddressValidationResult.Valid &&
          parsedAmount != null &&
          parsedAmount >= selectedAsset.minimumAmountBaseUnits &&
          !insufficientPrincipal &&
          !insufficientFee

      Button(
        onClick = { showPreview = true },
        enabled = canPreview,
        modifier = Modifier.fillMaxWidth().testTag("send_review_button"),
      ) {
        Text("Review Human-Readable Signing Preview")
      }
    }
  }

  if (showPreview && parsedAmount != null) {
    SigningPreviewDialog(
      preview =
        SigningPreview(
          title = "Confirm ${selectedAsset.ticker} Send",
          actionDescription = "Non-custodial transfer on ${selectedAsset.networkName}",
          networkName = selectedAsset.networkName,
          chainId = selectedAsset.id.chainId,
          assetTicker = selectedAsset.ticker,
          tokenIdentifier = selectedAsset.id.tokenIdentifier,
          amountFormatted =
            "${MoneyMath.formatBaseUnits(parsedAmount, selectedAsset.decimals)} ${selectedAsset.ticker}",
          feeFormatted = "${MoneyMath.formatBaseUnits(estFee, feeAsset.decimals)} ${feeAsset.ticker}",
          destinationAddress = destination.trim(),
          destinationMemo = memo.ifBlank { null },
          simulationOutcome = "Simulation OK · Balance & gas verified",
          custodyWarning =
            "A syntactically valid address does NOT prove recipient ownership. Signing keys remain on your device.",
        ),
      onConfirmSign = {
        showPreview = false
        onExecuteSend(selectedAsset.id, destination.trim(), memo.ifBlank { null }, parsedAmount)
        onDismiss()
      },
      onDismiss = { showPreview = false },
    )
  }
}

@Composable
fun SigningPreviewDialog(
  preview: SigningPreview,
  onConfirmSign: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Filled.Lock, contentDescription = null) },
    title = { Text(preview.title) },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(preview.actionDescription, style = MaterialTheme.typography.bodyMedium)
        HorizontalDivider()
        PreviewRow("Network", "${preview.networkName} (${preview.chainId})")
        PreviewRow("Asset", preview.assetTicker)
        PreviewRow("Token ID", preview.tokenIdentifier)
        PreviewRow("Amount", preview.amountFormatted)
        PreviewRow("Est. Fee", preview.feeFormatted)
        preview.destinationAddress?.let { PreviewRow("Destination", it) }
        preview.destinationMemo?.let { PreviewRow("Memo / Tag", it) }
        PreviewRow("Simulation", preview.simulationOutcome)
        preview.allowanceCapNote?.let { PreviewRow("Allowance", it) }
        Surface(color = AmberContainer, shape = RoundedCornerShape(10.dp)) {
          Text(
            preview.custodyWarning,
            style = MaterialTheme.typography.bodySmall,
            color = AmberPending,
            modifier = Modifier.padding(10.dp),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirmSign,
        modifier = Modifier.testTag("confirm_sign_button"),
      ) {
        Text("Approve & Sign")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
private fun PreviewRow(label: String, value: String) {
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(
      label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(value, style = MonoValueStyle)
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetRegistryDetailSheet(
  asset: AssetDefinition,
  balance: AssetBalance,
  onDismiss: () -> Unit,
) {
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(asset.assetName, style = MaterialTheme.typography.headlineSmall)
          Text(
            "${asset.ticker} · ${asset.networkName}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        StatusPill(text = asset.integrationStatus.label, tone = asset.integrationStatus.toTone())
      }

      HorizontalDivider()
      PreviewRow("Registry Version", "v${AssetRegistry.REGISTRY_VERSION}")
      PreviewRow("Chain Identifier", asset.id.chainId)
      PreviewRow("Token Identifier", asset.id.tokenIdentifier)
      PreviewRow("Asset Kind", asset.assetKind.badgeLabel)
      PreviewRow("Decimals", asset.decimals.toString())
      PreviewRow(
        "Minimum Amount",
        "${MoneyMath.formatBaseUnits(asset.minimumAmountBaseUnits, asset.decimals)} ${asset.ticker}",
      )
      PreviewRow(
        "Confirmation Policy",
        "${asset.confirmationPolicy.requiredConfirmations} confs (${asset.confirmationPolicy.blockTimeSeconds}s block) — ${asset.confirmationPolicy.finalityNote}",
      )
      PreviewRow(
        "Supported Operations",
        if (asset.supportedOperations.isEmpty()) "None (Observation / Disabled)"
        else asset.supportedOperations.joinToString(", ") { it.name },
      )
      PreviewRow(
        "Supported Routes",
        if (asset.supportedRoutes.isEmpty()) "None"
        else asset.supportedRoutes.joinToString(", ") { it.displayName },
      )
      asset.issuer?.let { PreviewRow("Issuer", it) }

      HorizontalDivider()
      Text("Balance Breakdown", style = MaterialTheme.typography.titleSmall)
      PreviewRow(
        "Spendable",
        "${MoneyMath.formatBaseUnits(balance.spendableBaseUnits, asset.decimals)} ${asset.ticker}",
      )
      PreviewRow(
        "Pending / Unconfirmed",
        "${MoneyMath.formatBaseUnits(balance.pendingUnconfirmedBaseUnits, asset.decimals)} ${asset.ticker}",
      )
      PreviewRow(
        "Locked in HTLC",
        "${MoneyMath.formatBaseUnits(balance.lockedHtlcBaseUnits, asset.decimals)} ${asset.ticker}",
      )

      asset.riskDisclosure?.let { note ->
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(12.dp),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              Icons.Outlined.Info,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Text(
              note,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
          }
        }
      }
    }
  }
}
