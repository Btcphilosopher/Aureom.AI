package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.custody.SigningPreview
import com.example.domain.model.AssetRegistry
import com.example.domain.model.BankPayoutState
import com.example.domain.model.EligibilityStatus
import com.example.domain.model.FiatPayoutRecord
import com.example.domain.model.RouteType
import com.example.domain.model.SwapQuote
import com.example.domain.model.SwapRecord
import com.example.domain.model.SwapState
import com.example.domain.util.MoneyMath
import com.example.ui.components.RouteBadge
import com.example.ui.components.SigningPreviewDialog
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldConfirmed
import com.example.ui.theme.MonoCaptionStyle
import com.example.ui.theme.MonoValueStyle
import com.example.ui.viewmodel.AureomUiState

@Composable
fun SwapScreen(
  uiState: AureomUiState,
  initialMode: Int = 0, // 0 = Asset Swap, 1 = Dollar Conversion
  onRequestQuotes: (com.example.domain.model.AssetId, com.example.domain.model.AssetId, String, Int) -> Unit,
  onAcceptAndSignQuote: (SwapQuote) -> Unit,
  onObserveCounterpartyLeg2: (String) -> Unit,
  onRedeemHtlcSwap: (String) -> Unit,
  onSimulateTimeout: (String) -> Unit,
  onSignRefund: (String) -> Unit,
  onSimulateReorg: (String) -> Unit,
  onRecoverReorg: (String) -> Unit,
  onSimulateRestart: () -> Unit,
  onRequestOffRampQuote: (com.example.domain.model.AssetId, String, EligibilityStatus) -> Unit,
  onExecuteOffRamp: (com.example.domain.model.FiatOffRampQuote, Boolean) -> Unit,
  onSettleBankPayout: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedMode by remember(initialMode) { mutableIntStateOf(initialMode) }

  // Asset Swap inputs
  val inputAssets = remember { AssetRegistry.swappableInputAssets() }
  val outputAssets = remember { AssetRegistry.swappableOutputAssets() }
  var fromAsset by remember { mutableStateOf(AssetRegistry.findById(AssetRegistry.BTC_TEST_ID)!!) }
  var toAsset by remember { mutableStateOf(AssetRegistry.findById(AssetRegistry.LTC_TEST_ID)!!) }
  var amountText by remember { mutableStateOf("0.005") }
  var slippageBps by remember { mutableIntStateOf(100) } // 1.00%
  var pendingSignQuote by remember { mutableStateOf<SwapQuote?>(null) }

  // Dollar conversion mode: 0 = Stablecoin (USDC), 1 = Eligible Bank USD
  var dollarMode by remember { mutableIntStateOf(0) }
  var offRampAsset by remember { mutableStateOf(AssetRegistry.findById(AssetRegistry.USDC_SEP_ID)!!) }
  var offRampAmountText by remember { mutableStateOf("50.0") }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Swap & Dollar Conversion", style = MaterialTheme.typography.headlineSmall)
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
          SegmentedButton(
            selected = selectedMode == 0,
            onClick = { selectedMode = 0 },
            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
          ) {
            Text("Asset Swap")
          }
          SegmentedButton(
            selected = selectedMode == 1,
            onClick = { selectedMode = 1 },
            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
          ) {
            Text("Dollar Conversion")
          }
        }
      }
    }

    if (selectedMode == 0) {
      // Asset Swap Builder
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text("From Asset", style = MaterialTheme.typography.labelMedium)
            Row(
              modifier = Modifier.horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              inputAssets.forEach { asset ->
                FilterChip(
                  selected = fromAsset.id == asset.id,
                  onClick = { fromAsset = asset },
                  label = { Text(asset.ticker) },
                )
              }
            }

            Text("To Asset", style = MaterialTheme.typography.labelMedium)
            Row(
              modifier = Modifier.horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              outputAssets.forEach { asset ->
                FilterChip(
                  selected = toAsset.id == asset.id,
                  onClick = { toAsset = asset },
                  label = { Text(asset.ticker) },
                )
              }
            }

            OutlinedTextField(
              value = amountText,
              onValueChange = { amountText = it },
              label = { Text("Input Amount (${fromAsset.ticker})") },
              modifier = Modifier.fillMaxWidth().testTag("swap_amount_input"),
              singleLine = true,
            )

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Text("Slippage:", style = MaterialTheme.typography.labelMedium)
              listOf(50 to "0.5%", 100 to "1.0%", 200 to "2.0%").forEach { (bps, lbl) ->
                FilterChip(
                  selected = slippageBps == bps,
                  onClick = { slippageBps = bps },
                  label = { Text(lbl) },
                )
              }
            }

            Button(
              onClick = { onRequestQuotes(fromAsset.id, toAsset.id, amountText, slippageBps) },
              modifier = Modifier.fillMaxWidth().testTag("get_quotes_button"),
            ) {
              Text("Evaluate Explicitly Supported Routes")
            }

            uiState.quoteError?.let { err ->
              Text(err, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }

      // Quote Results
      if (uiState.activeQuotes.isNotEmpty()) {
        item {
          uiState.quoteComparisonScope?.let { scope ->
            Text(
              scope,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        items(uiState.activeQuotes, key = { it.quoteId }) { quote ->
          QuoteCard(
            quote = quote,
            onReviewAndSign = { pendingSignQuote = quote },
          )
        }
      }
    } else {
      // Dollar Conversion: Stablecoin vs Eligible Bank USD
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              "Choose Dollar Destination",
              style = MaterialTheme.typography.titleSmall,
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
              SegmentedButton(
                selected = dollarMode == 0,
                onClick = { dollarMode = 0 },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
              ) {
                Text("Dollar Stablecoin")
              }
              SegmentedButton(
                selected = dollarMode == 1,
                onClick = { dollarMode = 1 },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
              ) {
                Text("US Dollars (Bank)")
              }
            }

            if (dollarMode == 0) {
              val usdc = AssetRegistry.findById(AssetRegistry.USDC_SEP_ID)!!
              Surface(color = AmberContainer, shape = RoundedCornerShape(10.dp)) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    "Dollar-Denominated Crypto: ${usdc.assetName} (${usdc.networkName})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = AmberPending,
                  )
                  Text(
                    "Issuer: ${usdc.issuer} · Token: ${usdc.id.tokenIdentifier}. ${usdc.riskDisclosure}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberPending,
                  )
                }
              }
              Button(
                onClick = {
                  selectedMode = 0
                  fromAsset = AssetRegistry.findById(AssetRegistry.ETH_SEP_ID)!!
                  toAsset = usdc
                  amountText = "0.05"
                  onRequestQuotes(fromAsset.id, toAsset.id, "0.05", slippageBps)
                },
                modifier = Modifier.fillMaxWidth().testTag("quote_stablecoin_button"),
              ) {
                Text("Quote ETH-SEP -> USDC (On-Chain DEX / Provider)")
              }
            } else {
              val offRampEligible = remember {
                listOf(
                  AssetRegistry.findById(AssetRegistry.USDC_SEP_ID)!!,
                  AssetRegistry.findById(AssetRegistry.BTC_TEST_ID)!!,
                  AssetRegistry.findById(AssetRegistry.ETH_SEP_ID)!!,
                )
              }
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(10.dp),
              ) {
                Text(
                  "Bank USD Off-Ramp: An atomic swap cannot create a bank deposit. Conversion, provider USD balance, and ACH bank payout are tracked separately.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(10.dp),
                )
              }

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                offRampEligible.forEach { asset ->
                  FilterChip(
                    selected = offRampAsset.id == asset.id,
                    onClick = { offRampAsset = asset },
                    label = { Text(asset.ticker) },
                  )
                }
              }

              OutlinedTextField(
                value = offRampAmountText,
                onValueChange = { offRampAmountText = it },
                label = { Text("Amount to Cash Out (${offRampAsset.ticker})") },
                modifier = Modifier.fillMaxWidth().testTag("offramp_amount_input"),
                singleLine = true,
              )

              Button(
                onClick = {
                  onRequestOffRampQuote(offRampAsset.id, offRampAmountText, EligibilityStatus.ELIGIBLE)
                },
                modifier = Modifier.fillMaxWidth().testTag("get_offramp_quote_button"),
              ) {
                Text("Get Eligible Bank Payout Quote")
              }

              uiState.offRampError?.let { err ->
                Text(err, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
              }

              uiState.activeOffRampQuote?.let { fq ->
                HorizontalDivider()
                Text("Off-Ramp Quote (${fq.providerName})", style = MaterialTheme.typography.titleSmall)
                Text("Eligibility: ${fq.eligibilityStatus.label} (${fq.jurisdiction})", style = MaterialTheme.typography.bodySmall)
                Text("Destination: ${fq.destinationMask}", style = MonoValueStyle)
                Text("Rate: 1 ${offRampAsset.ticker} = ${MoneyMath.formatUsd(fq.exchangeRateUsd)}", style = MonoValueStyle)
                Text("Gross: ${MoneyMath.formatUsdCents(fq.grossUsdCents)} · Fee: ${MoneyMath.formatUsdCents(fq.providerFeeUsdCents)}", style = MonoValueStyle)
                Text("Net Payout: ${MoneyMath.formatUsdCents(fq.netUsdPayoutCents)} · ${fq.estimatedPayoutWindow}", style = MonoValueStyle, fontWeight = FontWeight.Bold)
                Text("Limits: ${MoneyMath.formatUsdCents(fq.minUsdCents)} – ${MoneyMath.formatUsdCents(fq.maxUsdCents)} · Ref: ${fq.providerReference}", style = MonoCaptionStyle)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(
                    onClick = { onExecuteOffRamp(fq, false) },
                    modifier = Modifier.weight(1f).testTag("execute_offramp_button"),
                  ) {
                    Text("Withdraw USD")
                  }
                  OutlinedButton(
                    onClick = { onExecuteOffRamp(fq, true) },
                    modifier = Modifier.weight(1f),
                  ) {
                    Text("Test Failure")
                  }
                }
              }
            }
          }
        }
      }

      if (uiState.fiatPayouts.isNotEmpty()) {
        item {
          Text("Off-Ramp & Bank Payout Tracking", style = MaterialTheme.typography.titleMedium)
        }
        items(uiState.fiatPayouts, key = { it.id }) { payout ->
          FiatPayoutCard(payout = payout, onSettleBankPayout = { onSettleBankPayout(payout.id) })
        }
      }
    }

    // Active & Historical Swaps (HTLC State Machine & Recovery)
    if (uiState.swaps.isNotEmpty()) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Swap Execution & HTLC Recovery", style = MaterialTheme.typography.titleMedium)
          OutlinedButton(onClick = onSimulateRestart) {
            Text("Simulate Restart")
          }
        }
      }
      items(uiState.swaps, key = { it.id }) { swap ->
        SwapMonitorCard(
          swap = swap,
          onObserveLeg2 = { onObserveCounterpartyLeg2(swap.id) },
          onRedeem = { onRedeemHtlcSwap(swap.id) },
          onSimulateTimeout = { onSimulateTimeout(swap.id) },
          onSignRefund = { onSignRefund(swap.id) },
          onSimulateReorg = { onSimulateReorg(swap.id) },
          onRecoverReorg = { onRecoverReorg(swap.id) },
        )
      }
    }
  }

  pendingSignQuote?.let { quote ->
    val inAsset = AssetRegistry.findById(quote.inputAssetId)!!
    val outAsset = AssetRegistry.findById(quote.outputAssetId)!!
    val feeAsset = AssetRegistry.findById(quote.networkFeeAssetId)!!
    SigningPreviewDialog(
      preview =
        SigningPreview(
          title = "Approve ${quote.routeType.shortTag}",
          actionDescription =
            "Swap ${MoneyMath.formatBaseUnits(quote.inputAmountBaseUnits, inAsset.decimals)} ${inAsset.ticker} for min ${MoneyMath.formatBaseUnits(quote.minimumOutputBaseUnits, outAsset.decimals)} ${outAsset.ticker}",
          networkName = inAsset.networkName,
          chainId = inAsset.id.chainId,
          assetTicker = inAsset.ticker,
          tokenIdentifier = inAsset.id.tokenIdentifier,
          amountFormatted =
            "${MoneyMath.formatBaseUnits(quote.inputAmountBaseUnits, inAsset.decimals)} ${inAsset.ticker}",
          feeFormatted =
            "${MoneyMath.formatBaseUnits(quote.networkFeeBaseUnits, feeAsset.decimals)} ${feeAsset.ticker}",
          destinationAddress = quote.protocolsOrProviders.joinToString(" + "),
          simulationOutcome = "Quote digest ${quote.quoteDigest} valid; slippage ${quote.slippageBps / 100.0}%",
          allowanceCapNote =
            if (quote.routeType == RouteType.ON_CHAIN_SWAP && inAsset.id.tokenIdentifier != "native") {
              "Exact-amount ERC-20 approval only"
            } else {
              null
            },
          custodyWarning = quote.custodyAssumptions,
        ),
      onConfirmSign = {
        val approved = quote
        pendingSignQuote = null
        onAcceptAndSignQuote(approved)
      },
      onDismiss = { pendingSignQuote = null },
    )
  }
}

@Composable
private fun QuoteCard(
  quote: SwapQuote,
  onReviewAndSign: () -> Unit,
) {
  val inAsset = AssetRegistry.findById(quote.inputAssetId)!!
  val outAsset = AssetRegistry.findById(quote.outputAssetId)!!
  val feeAsset = AssetRegistry.findById(quote.networkFeeAssetId)!!

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        RouteBadge(quote.routeType)
        Text(
          "Est. ~${quote.estimatedCompletionSeconds / 60}m ${quote.estimatedCompletionSeconds % 60}s",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Text(
        "Expected: ${MoneyMath.formatBaseUnits(quote.expectedOutputBaseUnits, outAsset.decimals)} ${outAsset.ticker}",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
      )
      Text(
        "Minimum (${quote.slippageBps / 100.0}% slippage): ${MoneyMath.formatBaseUnits(quote.minimumOutputBaseUnits, outAsset.decimals)} ${outAsset.ticker}",
        style = MonoValueStyle,
      )
      Text(
        "Protocol(s): ${quote.protocolsOrProviders.joinToString(", ")}",
        style = MaterialTheme.typography.bodySmall,
      )
      Text(
        "Network Fee: ${MoneyMath.formatBaseUnits(quote.networkFeeBaseUnits, feeAsset.decimals)} ${feeAsset.ticker} · Service Fee: ${MoneyMath.formatBaseUnits(quote.serviceFeeBaseUnits, inAsset.decimals)} ${inAsset.ticker}",
        style = MonoCaptionStyle,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        shape = RoundedCornerShape(10.dp),
      ) {
        Text(
          quote.custodyAssumptions,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(10.dp),
        )
      }

      Button(
        onClick = onReviewAndSign,
        modifier = Modifier.fillMaxWidth().testTag("accept_quote_${quote.routeType.name}"),
      ) {
        Text("Review & Approve Quote")
      }
    }
  }
}

@Composable
private fun SwapMonitorCard(
  swap: SwapRecord,
  onObserveLeg2: () -> Unit,
  onRedeem: () -> Unit,
  onSimulateTimeout: () -> Unit,
  onSignRefund: () -> Unit,
  onSimulateReorg: () -> Unit,
  onRecoverReorg: () -> Unit,
) {
  val inAsset = AssetRegistry.findById(swap.quote.inputAssetId)!!
  val outAsset = AssetRegistry.findById(swap.quote.outputAssetId)!!
  val tone =
    when {
      swap.state == SwapState.COMPLETED || swap.state == SwapState.REFUNDED -> StatusTone.CONFIRMED
      swap.state == SwapState.REFUND_AVAILABLE || swap.state == SwapState.REORG_DETECTED || swap.state == SwapState.MANUAL_REVIEW ->
        StatusTone.ERROR
      else -> StatusTone.PENDING
    }

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
          RouteBadge(swap.quote.routeType)
          Text(
            "${inAsset.ticker} -> ${outAsset.ticker}",
            style = MaterialTheme.typography.titleSmall,
          )
        }
        StatusPill(text = swap.state.label, tone = tone)
      }

      Text(swap.lockStatusSummary, style = MaterialTheme.typography.bodySmall)
      Text(
        "Next Action: ${swap.expectedNextAction}",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
      )

      swap.htlcParams?.let { h ->
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerLow,
          shape = RoundedCornerShape(10.dp),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
          ) {
            Text("HTLC Spec: ${h.protocolSpec}", style = MonoCaptionStyle, fontWeight = FontWeight.Bold)
            Text("Hash H(s): ${h.secretHashHex.take(24)}... (Secret sealed in Keystore)", style = MonoCaptionStyle)
            Text(
              "Asymmetric Timelocks: Initiator ${h.initiatorLockDurationSeconds / 3600}h (#${h.initiatorLockHeight}) > Counterparty ${h.counterpartyLockDurationSeconds / 3600}h (#${h.counterpartyLockHeight}) · Safety Margin ${h.safetyMarginSeconds / 3600}h",
              style = MonoCaptionStyle,
            )
            Text(
              "Leg 1 Confs: ${swap.leg1Confirmations}/${swap.leg1RequiredConfirmations} · Leg 2 Confs: ${swap.leg2Confirmations}/${swap.leg2RequiredConfirmations}",
              style = MonoCaptionStyle,
            )
          }
        }
      }

      swap.reorgNotice?.let { notice ->
        Surface(color = AmberContainer, shape = RoundedCornerShape(8.dp)) {
          Text(notice, style = MaterialTheme.typography.bodySmall, color = AmberPending, modifier = Modifier.padding(8.dp))
        }
      }

      swap.failureReason?.let { err ->
        Text(err, style = MaterialTheme.typography.bodySmall, color = CrimsonAlert)
      }

      // Context-sensitive state machine controls
      when (swap.state) {
        SwapState.FIRST_LEG_CONFIRMED -> {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = onObserveLeg2,
              modifier = Modifier.weight(1f).testTag("observe_leg2_button"),
            ) {
              Text("Observe Leg 2")
            }
            OutlinedButton(
              onClick = onSimulateTimeout,
              modifier = Modifier.weight(1f).testTag("simulate_timeout_button"),
            ) {
              Text("Test Timeout")
            }
          }
          OutlinedButton(onClick = onSimulateReorg, modifier = Modifier.fillMaxWidth()) {
            Text("Simulate 1-Block Reorg")
          }
        }
        SwapState.SECOND_LEG_CONFIRMED -> {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = onRedeem,
              modifier = Modifier.weight(1f).testTag("redeem_htlc_button"),
            ) {
              Text("Redeem Output")
            }
            OutlinedButton(onClick = onSimulateReorg, modifier = Modifier.weight(1f)) {
              Text("Test Reorg")
            }
          }
        }
        SwapState.REORG_DETECTED -> {
          Button(onClick = onRecoverReorg, modifier = Modifier.fillMaxWidth()) {
            Text("Re-Verify Finality Blocks")
          }
        }
        SwapState.REFUND_AVAILABLE -> {
          Button(
            onClick = onSignRefund,
            modifier = Modifier.fillMaxWidth().testTag("sign_refund_button"),
          ) {
            Text("Sign & Broadcast HTLC Refund")
          }
        }
        else -> Unit
      }
    }
  }
}

@Composable
private fun FiatPayoutCard(
  payout: FiatPayoutRecord,
  onSettleBankPayout: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          "Bank USD Payout · ${MoneyMath.formatUsdCents(payout.quote.netUsdPayoutCents)}",
          style = MaterialTheme.typography.titleSmall,
        )
        StatusPill(
          text = payout.bankPayoutState.label,
          tone =
            when (payout.bankPayoutState) {
              BankPayoutState.PAID_OUT -> StatusTone.CONFIRMED
              BankPayoutState.REJECTED -> StatusTone.ERROR
              else -> StatusTone.PENDING
            },
        )
      }
      Text("Conversion State: ${payout.conversionState.label}", style = MonoCaptionStyle)
      Text("Provider Balance State: ${payout.providerBalanceState.label}", style = MonoCaptionStyle)
      Text("Bank Payout State: ${payout.bankPayoutState.label}", style = MonoCaptionStyle)
      Text("Ref: ${payout.quote.providerReference} · ${payout.quote.destinationMask}", style = MonoCaptionStyle)
      payout.failureReason?.let { Text(it, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall) }

      if (payout.bankPayoutState == BankPayoutState.SETTLING) {
        OutlinedButton(onClick = onSettleBankPayout, modifier = Modifier.fillMaxWidth()) {
          Text("Simulate Bank ACH Settlement")
        }
      }
    }
  }
}
