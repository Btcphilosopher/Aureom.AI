# Aureom Wallet (Android)

**Aureom Wallet** is a non-custodial Android cryptocurrency wallet built with Kotlin, Jetpack Compose, Material 3, Room, DataStore, and Android Keystore. It implements an explicit versioned asset registry, multi-route quote evaluation, a recoverable BIP-199 SHA-256 HTLC atomic swap state machine, and separated USD stablecoin vs. eligible bank USD off-ramp tracking.

> **Environment Status:** All live-value transfers are disabled. The application operates in a deterministic **Testnet / Local Sandbox** environment (`BTC-TEST`, `LTC-TEST`, `ETH-SEP`, `WETH-SEP`, `USDC` Sepolia, `USDC.e` OP Sepolia, `XRP-TEST`) with clearly labeled simulated chain/provider adapters where external testnet nodes or banking rails are unavailable.

---

## 1. What Is Implemented, Simulated, and Tested

| Capability | Status | Details |
| :--- | :--- | :--- |
| **Non-Custodial Wallet Adapter** | Implemented (Dev Signer) | `ChainWalletAdapter` interface with BIP-84 UTXO, EVM Sepolia, and XRPL adapters. Private keys never leave the device; recovery phrases are never accepted by any API or UI form. |
| **Protected Secret Storage** | Implemented | `AndroidKeystoreSecretVault` wraps 32-byte HTLC preimage secrets using AES-256-GCM keys in `AndroidKeyStore` (`InMemorySecretVault` for JVM unit tests). `RedactingLogger` masks secrets/preimages. |
| **Explicit Asset Registry (`v1.2.0`)** | Implemented | Composite `(chainId, tokenIdentifier)` identification. Separates `NATIVE`, `WRAPPED`, `BRIDGED`, `STABLECOIN`, and `UNKNOWN` (`UNVERIFIED_OBSERVATION`), plus `UNAVAILABLE` and `DEPRECATED` assets. |
| **Receive & Send Flows** | Implemented + Simulated Chain | QR code generator (`QrCodeMatrix`), prominent network & Destination Tag/Memo display, strict address format validation, gas/fee-token balance checks, recipient ownership disclaimer, and human-readable `SigningPreviewDialog`. |
| **Swap Quote Engine** | Implemented | Exact `BigInteger` / `BigDecimal` math (`MoneyMath`), route separation (`ATOMIC_SWAP`, `ON_CHAIN_SWAP`, `PROVIDER_MEDIATED`, `FIAT_OFF_RAMP`), slippage bounds, quote expiry, drift revalidation, and idempotency keys. |
| **HTLC Atomic Swap (`BTC-TEST ↔ LTC-TEST`)** | Implemented + Simulated Chain | Full BIP-199 SHA-256 HTLC state machine (`FUNDING_PREPARED` → `FIRST_LEG_CONFIRMED` → `SECOND_LEG_CONFIRMED` → `COMPLETED`, plus `REORG_DETECTED`, `REFUND_AVAILABLE`, `REFUNDED`, `MANUAL_REVIEW`). |
| **Restart Recovery** | Implemented | Non-secret swap metadata, lock heights, and tx hashes persist in Room (`AureomDatabase`); `resumeInterruptedSwaps()` restores monitoring on restart while preimages remain in Keystore. |
| **Dollar Conversion** | Implemented + Simulated Provider | Strictly separates **USD-denominated stablecoins** (`USDC` with issuer & non-guarantee disclosure) from **Bank USD payouts** (`FiatOffRampAdapter` with separate conversion, provider balance, and ACH payout states). |
| **Optional Auto-Convert Rule** | Implemented | Persisted in Room, defaulting to **Manual Approval (`enabled = false`)**, with min deposit/output, max fee, quote age, daily limit, route allowlist, pause switch, and non-custodial signer boundary notice. |
| **Security Controls** | Implemented | Exact-amount ERC-20 allowance default, Emergency Pause circuit breaker (allows HTLC refunds while blocking new swaps), `WebhookVerifier` (HMAC-SHA256 + replay nonce/window check). |

---

## 2. Supported Asset Matrix (`v1.2.0`)

| Ticker | Chain ID | Token Identifier | Kind | Status | Min Confs |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `BTC-TEST` | `bitcoin:testnet4` | `native` | Native | Testnet | 3 |
| `LTC-TEST` | `litecoin:testnet4` | `native` | Native | Testnet | 6 |
| `ETH-SEP` | `eip155:11155111` | `native` | Native | Testnet | 12 |
| `WETH-SEP` | `eip155:11155111` | `0x7b7999...E7f9` | Wrapped | Testnet | 12 |
| `USDC` | `eip155:11155111` | `0x1c7D4B...7238` | Stablecoin | Testnet | 12 |
| `USDC.e` | `eip155:11155420` | `0x5fd842...30D7-bridged` | Bridged | Testnet | 10 |
| `XRP-TEST` | `xrpl:testnet` | `native` (Destination Tag req.) | Native | Testnet | 1 |
| `SOL-DEV` | `solana:devnet` | `native` | Native | Unavailable | 32 |
| `USTC` | `terra:columbus-5` | `uusd` | Stablecoin | Deprecated | 6 |
| `UNK-ERC20` | `eip155:11155111` | `0xdead...beef` | Unverified | Unverified Observation | 12 |

---

## 3. Atomic Swap Protocol Specification (BIP-199 SHA-256 HTLC)

Compatible pair: **`BTC-TEST` (600s block time) ↔ `LTC-TEST` (150s block time)**

- **Commitment:** 32-byte random secret `s` generated locally via `SecureRandom`, sealed in `AndroidKeyStore`; shared commitment `H = SHA-256(s)`.
- **Script Semantics:** `OP_IF OP_SHA256 <H> OP_EQUALVERIFY <CounterpartyPubKey> OP_ELSE <LockHeight> OP_CHECKLOCKTIMEVERIFY OP_DROP <RefundPubKey> OP_ENDIF OP_CHECKSIG`
- **Asymmetric Timelocks:** Initiator Lock `T_A = 24h` (`86,400s`), Counterparty Lock `T_B = 12h` (`43,200s`), Safety Margin `>= 6h` (`21,600s`) to absorb confirmation finality, chain reorganisations, and transaction inclusion delays.
- **Operational Limits:** Funds are temporarily time-locked during active swaps; both redemption and timeout refunds require miner fees and an online user signature.

---

## 4. Running Tests

```bash
gradle :app:testDebugUnitTest
```

Covers all protocol invariants (`AureomProtocolUnitTest`) and Robolectric persistence, restart recovery, emergency pause, and Compose UI navigation (`ExampleRobolectricTest`).
