# Node API and Management API

Every node (all three profiles) serves the **public API** on `api_listen` (default
`127.0.0.1:<port>`) and the **admin API** on a separate listener `admin_listen`
(default `127.0.0.1` only). JSON everywhere. Amounts and fees are **decimal strings of
base units**; heights and timestamps (ms since epoch) are JSON integers; hashes are
lowercase hex; addresses are bech32m (`<hrp>1…`), token ids bech32m (`<hrp>tok1…`).

Every response object includes `"observed_at_ms"` (node wall clock when the response was
built) so clients can label stale observations.

Errors: HTTP 4xx/5xx with `{"error": {"code": "<snake_case>", "message": "..."}}`.

## Public API (`/v1`)

| method | path | notes |
|---|---|---|
| GET | `/v1/network` | identity, genesis hash, profile, asset, policies |
| GET | `/v1/health` | liveness/sync/alerts summary |
| GET | `/v1/blocks/{latest\|height\|block_id}` | full block |
| GET | `/v1/blocks?before=<height>&limit=<n≤100>` | block summaries, newest first |
| GET | `/v1/accounts/{address}` | balances, nonce, vesting, tokens |
| GET | `/v1/accounts/{address}/transactions?limit=` | tx ids touching the address (explorer index) |
| GET | `/v1/transactions/{txid}` | lifecycle status + receipt |
| POST | `/v1/transactions` | body `{"tx": "<hex SignedTx>"}` |
| GET | `/v1/mempool` | local mempool view |
| GET | `/v1/consensus/status` | profile-specific |
| GET | `/v1/validators` | PoS/PoA validator set (PoW: empty with note) |
| GET | `/v1/peers` | connected peers |
| GET | `/v1/sync` | synchronisation progress and trust anchor |
| GET | `/v1/supply` | native supply report + reconciliation |
| GET | `/v1/tokens` and `/v1/tokens/{token_id}` | token registry |
| GET | `/v1/multisigs/{address}` | multisig signers, threshold, proposals |
| GET | `/v1/distributions/{dist_id}` | claim distribution |
| GET | `/v1/proposals` | governance proposals (PoS/PoA) |
| GET | `/v1/events?kind=<kind>&limit=` | indexed supply/admin events: `mint, burn, transfer, token_create, token_admin, vesting, msig_execute, slash, reward, validator_update, gov` |
| GET | `/metrics` | Prometheus text format |

### `GET /v1/network`
```json
{"network_name":"Aureom Development Network","chain_id":"aureom-dev-pow-1","profile":"pow",
 "backend":"aureom-nakamoto","backend_version":"0.1.0","protocol_version":1,"node_version":"0.1.0",
 "genesis_hash":"…","node_name":"node0",
 "native_asset":{"name":"…","ticker":"ADC","decimals":6,"address_hrp":"aurd"},
 "monetary_policy":{…genesis…},"fee_policy":{…genesis…},"limits":{…genesis…},
 "finality":"probabilistic","confirmations_recommended":6,
 "fault_assumption":"…human readable…","observed_at_ms":0}
```
`backend` is `aureom-nakamoto` (PoW) or `cometbft` (PoS/PoA, `backend_version` = CometBFT version).
`finality` is `probabilistic` (PoW) or `deterministic-bft` (PoS/PoA).

### `GET /v1/health`
```json
{"status":"ok|degraded|halted","height":12,"tip_id":"…","tip_time_ms":0,"tip_age_ms":1200,
 "peers":2,"syncing":false,"mempool_txs":0,
 "storage":{"db_path":"…","db_bytes":123,"db_version":1,"pruning":{"keep_blocks":0,"keep_undo":1000}},
 "alerts":[{"level":"warning|critical","code":"no_peers","message":"…"}],"observed_at_ms":0}
```

### `GET /v1/blocks/{id}`
```json
{"height":5,"id":"…","prev_id":"…","timestamp_ms":0,"proposer":"aurd1…","tx_count":1,
 "size_bytes":512,"state_root":"…","tx_root":"…","receipt_root":"…",
 "txs":[{…tx json…}],"receipts":[{…receipt json…}],
 "consensus":{"pow":{"target":"…","nonce":"…","pow_hash":"…","work":"…","cumulative_work":"…"}}
          |  {"bft":{"cometbft_block_hash":"…","app_hash":"…"}},
 "confirmations":3,"finality":"probabilistic|final","on_main_chain":true,"observed_at_ms":0}
```
Tx json: `{"id","version","chain_id","sender","sender_pubkey","nonce","fee","expiry_height","action":{"type":"transfer",…},"memo"}`.
Receipt json: `{"txid","status":"success|failed","error":null|"INSUFFICIENT_FUNDS",…,"error_code","fee_paid","events":[{"kind","attrs":{…}}]}`.

### `GET /v1/accounts/{address}`
```json
{"address":"aurd1…","nonce":3,"height":12,
 "native":{"total":"…","available":"…","locked_vesting":"…","immature":"…","bonded":"…","unbonding":"…"},
 "vesting":[{"total":"…","start_height":0,"cliff_height":10,"end_height":110,"vested":"…","locked":"…"}],
 "immature":[{"amount":"…","mature_height":20}],
 "tokens":[{"token_id":"aurdtok1…","symbol":"GLD","name":"…","decimals":2,"balance":"…","frozen":false,
            "issuer_permissions":{"mint_authority":null,"admin":null,"pausable":false,"freezable":false}}],
 "multisig":null|{"signers":[…],"threshold":2},"observed_at_ms":0}
```

### `GET /v1/transactions/{txid}`
```json
{"id":"…","status":"received|validated|pending|included|confirmed|finalised|rejected|dropped|unknown",
 "block_height":7,"block_id":"…","index":0,"confirmations":4,"finality":"probabilistic|final",
 "receipt":{…},"tx":{…},"reason":null,"observed_at_ms":0}
```
### `POST /v1/transactions`
Request `{"tx":"<hex>"}`. `202 {"id":"…","status":"pending","note":"accepted by this node's mempool; inclusion is not guaranteed"}`.
`400 {"error":{"code":"bad_signature|bad_nonce|fee_too_low|wrong_chain|malformed|too_large|expired|insufficient_fee_balance|unsupported_action|mempool_full|sender_limit|duplicate","message":"…"}}`.

### `GET /v1/consensus/status`
PoW:
```json
{"profile":"pow","engine":"aureom-nakamoto","height":12,"tip":"…","cumulative_work":"…",
 "target":"…","difficulty":"…","target_block_time_ms":2000,"recent_block_times_ms":[…],
 "reorgs":[{"at_ms":0,"depth":2,"old_tip":"…","new_tip":"…","fork_height":10}],
 "mining":{"enabled":true,"address":"aurd1…","hashes":123},
 "finality":"probabilistic","confirmations_recommended":6,
 "fault_assumption":"…","observed_at_ms":0}
```
BFT:
```json
{"profile":"pos|poa","engine":"cometbft","cometbft_version":"0.38.26","height":12,"app_height":12,
 "latest_block_hash":"…","latest_app_hash":"…","catching_up":false,
 "total_power":40,"last_commit":{"signed_power":30,"total_power":40,"signers":3,"validators":4},
 "quorum":"> 2/3 of voting power","fault_assumption":"…","finality":"deterministic-bft",
 "epoch":{"length":10,"next":20}|null,"observed_at_ms":0}
```

### `GET /v1/validators`
```json
{"profile":"pos","total_power":40,"validators":[{"operator":"aurd1…","moniker":"v0",
 "consensus_pubkey":"<base64>","consensus_address":"<HEX>","power":10,"bonded":"…",
 "status":"active|inactive|jailed|tombstoned|removed","jailed_until":0,"missed_in_window":0,
 "signed_last_block":true|null}],"observed_at_ms":0}
```

### `GET /v1/peers`
`{"peers":[{"id":"…","address":"127.0.0.1:…","direction":"inbound|outbound","height":12,"score":0,"connected_since_ms":0,"protocol_version":1}],"max_peers":16,"observed_at_ms":0}`

### `GET /v1/sync`
`{"syncing":false,"local_height":12,"best_known_height":12,"progress":1.0,"trust_anchor":{"kind":"genesis|checkpoint|trusted-height","height":0,"hash":"…","note":"…"},"validation":"full","errors":[…],"observed_at_ms":0}`

### `GET /v1/supply`
Native supply report (`total, genesis, minted, burned, staked, unbonding, escrow, locked_vesting, immature, treasury, circulating, max_supply, reconciled, tokens_reconciled, problems[]`, `height`, `asset`).

### `GET /v1/tokens`
`{"tokens":[{"token_id","symbol","name","decimals","supply","max_supply","creator","mint_authority","admin","pausable","freezable","paused","metadata_uri","created_height","verified":"on-chain facts: supply, permissions; issuer-supplied: name, symbol, metadata_uri"}]}`

## Admin API (`/admin/v1`) — separate listener, bearer token

`Authorization: Bearer <token>` (token file created with mode 0600 at node init). The
listener binds to `127.0.0.1` by default; binding elsewhere requires an explicit config
change and prints a warning. Requests without a valid token get `401`.

| method | path | body |
|---|---|---|
| GET | `/admin/v1/status` | — |
| POST | `/admin/v1/peer-actions` | `{"action":"connect|disconnect|ban|unban","peer":"host:port|peer_id"}` (PoW; BFT returns `501` — peer management is CometBFT's) |
| POST | `/admin/v1/snapshots` | `{}` → writes a verified state snapshot, returns path/height/root |
| POST | `/admin/v1/mining` | `{"enabled":bool}` (PoW only) |
| POST | `/admin/v1/shutdown` | `{}` |

There is no endpoint that signs, executes shell commands, edits balances, edits
validators or writes the database directly.

## Console server (`chainworks console`)

Serves the built console plus:

* `GET /api/manifest` — `{network:{name,chain_id,profile,genesis_hash,…}, nodes:[{name,role,proxy:"/proxy/<name>",api_url}], generated_at_ms}`
* `GET /proxy/<node>/v1/...` — GET passthrough to that node's public API
* `POST /proxy/<node>/v1/transactions` — passthrough for **already signed** transactions
* `GET /api/deployment` — export package file list with SHA-256 checksums
* `GET /api/recovery` — snapshots and backups found in the network directory
* `GET /api/keys` — public key inventory (role, label, address, pubkey). Never secrets.
* `GET /api/config-proposals` — consensus-critical configuration changes are *proposals* (governance txs) — this lists on-chain proposals via node API.

The console never proxies the admin API.

## Backend differences in the common API

| endpoint | PoW | PoS / PoA |
|---|---|---|
| `GET /v1/mempool` | `{count, bytes, max_count, max_bytes, max_per_sender, txs:[{id,sender,nonce,fee,size,type,added_ms}]}` | `{count, txs:[{id, added_ms}]}` — CometBFT owns the mempool |
| `GET /v1/peers` | Aureom peers with scores and bans; `self_id` | CometBFT `net_info` peers |
| `POST /admin/v1/peer-actions` | connect / disconnect / ban / unban | `501` (configure CometBFT) |
| `POST /admin/v1/mining` | toggles the dev miner | `501` |
| `GET /v1/transactions/{id}` final states | `included` → `confirmed` (≥ `confirmations_recommended`), probabilistic | `finalised` |
| `POST /v1/transactions` ordering | nonces may arrive out of order (≤ 32 ahead) | each sender's nonces must reach a node in order |

Other shapes used by the console: `GET /v1/multisigs/{addr}` →
`{address, signers[], threshold, balance, proposals:[{id, proposer, inner, approvals[], threshold, expiry_height, status, error}]}`;
`GET /v1/proposals` → `{profile, proposals:[{id, proposer, kind, created_height, expiry_height, executed_height, approvals[], approving_power, total_power, status}], threshold, scheduled_upgrades[]}`;
`GET /v1/accounts/{addr}/transactions` → `{address, transactions:[{txid, height}]}`;
console `/api/keys` → `{keys:[{role,label,address,pubkey,node?}]}`; `/api/deployment` →
`{package, files:[{path, sha256, bytes}], excluded[]}`; `/api/recovery` →
`{snapshots:[{path,node,height,state_root_prefix,bytes,created_ms}], backups:[{path,node,height,files,created_ms}]}`.
