# Dependency inventory

Generated from `cargo metadata`, `console/package.json` and the Python project metadata. Licences are as declared by each package.

## External engines

| component | version | licence | role |
|---|---|---|---|
| CometBFT | v0.38.26 (built from source via the Go module proxy, `tools/build-cometbft.sh`) | Apache-2.0 | BFT consensus engine for PoS/PoA |
| PostgreSQL | 16 (optional, Docker image) | PostgreSQL License | optional explorer index |

## Rust (direct dependencies)

| crate | version | licence | used by |
|---|---|---|---|
| anyhow | 1.0.105 | MIT OR Apache-2.0 | aureom-cli, aureom-node |
| argon2 | 0.5.3 | MIT OR Apache-2.0 | aureom-core |
| axum | 0.8.9 | MIT | aureom-node |
| base64 | 0.22.1 | MIT OR Apache-2.0 | aureom-cli, aureom-core, aureom-node |
| base64 | 0.23.1 | MIT OR Apache-2.0 | aureom-cli, aureom-core, aureom-node |
| bech32 | 0.11.1 | MIT | aureom-core |
| bytes | 1.12.2 | MIT | aureom-node |
| chacha20poly1305 | 0.10.1 | Apache-2.0 OR MIT | aureom-core |
| clap | 4.6.10 | MIT OR Apache-2.0 | aureom-cli, aureom-node |
| ed25519-dalek | 2.2.0 | BSD-3-Clause | aureom-core |
| hex | 0.4.3 | MIT OR Apache-2.0 | aureom-cli, aureom-core, aureom-node |
| parking_lot | 0.12.5 | MIT OR Apache-2.0 | aureom-node |
| parking_lot | 0.13.0 | MIT OR Apache-2.0 | aureom-node |
| primitive-types | 0.13.1 | MIT OR Apache-2.0 | aureom-core |
| prost | 0.14.6 | Apache-2.0 | aureom-node |
| rand_core | 0.6.4 | MIT OR Apache-2.0 | aureom-core, aureom-node |
| redb | 5.0.0 | MIT OR Apache-2.0 | aureom-node |
| reqwest | 0.13.5 | MIT OR Apache-2.0 | aureom-cli, aureom-node |
| rpassword | 7.5.5 | Apache-2.0 | aureom-cli |
| serde | 1.0.229 | MIT OR Apache-2.0 | aureom-cli, aureom-core, aureom-node |
| serde_json | 1.0.154 | MIT OR Apache-2.0 | aureom-cli, aureom-core, aureom-node |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | aureom-core |
| subtle | 2.6.1 | BSD-3-Clause | aureom-node |
| tendermint-proto | 0.41.0 | Apache-2.0 | aureom-node |
| thiserror | 2.0.21 | MIT OR Apache-2.0 | aureom-core, aureom-node |
| tokio | 1.54.1 | MIT | aureom-node |
| tower-http | 0.6.11 | MIT | aureom-node |
| tracing | 0.1.44 | MIT | aureom-node |
| tracing-subscriber | 0.3.23 | MIT | aureom-node |
| zeroize | 1.9.2 | Apache-2.0 OR MIT | aureom-core |

Transitive Rust crates in the normal (non-dev) dependency graph: 228. Licence expressions:

| licence expression | crates |
|---|---|
| MIT OR Apache-2.0 | 119 |
| MIT | 41 |
| Apache-2.0 OR MIT | 20 |
| Unicode-3.0 | 18 |
| Apache-2.0 | 9 |
| Zlib | 4 |
| BSD-3-Clause | 3 |
| Unlicense OR MIT | 3 |
| MIT/Apache-2.0 | 3 |
| BSD-2-Clause OR Apache-2.0 OR MIT | 2 |
| (MIT OR Apache-2.0) AND Unicode-3.0 | 1 |
| Apache-2.0/MIT | 1 |
| MIT AND BSD-3-Clause | 1 |
| MIT OR Apache-2.0 OR BSD-1-Clause | 1 |
| Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | 1 |
| Apache-2.0 OR BSL-1.0 | 1 |

## Python

| package | version | licence |
|---|---|---|
| click | 8.x | BSD-3-Clause |
| cryptography | 42+ (tested 50.0.1) | Apache-2.0 OR BSD-3-Clause |
| jsonschema | 4.x | MIT |
| psycopg[binary] (optional) | 3.2.3 | LGPL-3.0-only |
| pytest (tests) | 9.x | MIT |

## Console (npm, exact pins)

| package | version |
|---|---|
| react (runtime) | 18.3.1 |
| react-dom (runtime) | 18.3.1 |
| @types/react (build) | 18.3.12 |
| @types/react-dom (build) | 18.3.1 |
| @vitejs/plugin-react (build) | 4.3.4 |
| typescript (build) | 5.6.3 |
| vite (build) | 5.4.11 |

React, React DOM, Vite and TypeScript are MIT/Apache-2.0 licensed. No cryptographic primitive is implemented in this repository; see PROTOCOL.md section 2.
