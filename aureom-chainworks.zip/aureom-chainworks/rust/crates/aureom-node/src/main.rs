//! aureom-node — AUREOM CHAINWORKS node (development software, not production-secure).

mod abci;
mod api;
mod config;
mod faults;
mod mempool;
mod p2p;
mod pow_chain;
mod pow_node;
mod store;
mod views;

use anyhow::{bail, Context, Result};
use aureom_core::genesis::{ChainParams, Profile};
use clap::{Parser, Subcommand};
use config::NodeConfig;
use std::path::PathBuf;
use std::sync::Arc;

#[derive(Parser)]
#[command(name = "aureom-node", version, about = "AUREOM CHAINWORKS node (development network software)")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Run the node.
    Run {
        #[arg(long)]
        config: PathBuf,
    },
    /// Offline audit: re-execute every stored block from genesis and compare state roots.
    VerifyChain {
        #[arg(long)]
        config: PathBuf,
    },
    /// Offline: consistent copy of the database to a backup directory (node must be stopped).
    Backup {
        #[arg(long)]
        config: PathBuf,
        #[arg(long)]
        out: PathBuf,
    },
    /// Offline: verify a snapshot against the locally recorded state root at its height,
    /// then replay stored blocks above it, checking every state root. `--repair` writes
    /// the replayed state back (recovers a damaged state table when blocks are intact).
    Replay {
        #[arg(long)]
        config: PathBuf,
        #[arg(long)]
        snapshot: PathBuf,
        #[arg(long)]
        repair: bool,
    },
    /// Offline: rebuild the explorer indexes from stored blocks and receipts.
    Reindex {
        #[arg(long)]
        config: PathBuf,
    },
}

fn load(cfg_path: &PathBuf) -> Result<(NodeConfig, Arc<ChainParams>)> {
    let (cfg, _) = NodeConfig::load(cfg_path)?;
    let g = std::fs::read_to_string(&cfg.genesis_path).with_context(|| format!("read genesis {}", cfg.genesis_path.display()))?;
    let p = ChainParams::from_json_str(&g).map_err(|e| anyhow::anyhow!(e))?;
    let got = hex::encode(p.hash);
    if got != cfg.expected_genesis_hash.to_lowercase() {
        bail!("genesis hash mismatch: file hashes to {got} but node config expects {} — refusing to start on an unintended chain", cfg.expected_genesis_hash);
    }
    if cfg.profile != p.profile.as_str() {
        bail!("node config profile {:?} differs from genesis consensus profile {:?}; the profile is fixed at genesis and cannot be switched", cfg.profile, p.profile.as_str());
    }
    Ok((cfg, Arc::new(p)))
}

fn dblock(b: &[u8]) -> Result<aureom_core::pow::Block> {
    use aureom_core::codec::Decode;
    aureom_core::pow::Block::decode(b).map_err(|e| anyhow::anyhow!("corrupt block: {e}"))
}

fn read_token(path: &std::path::Path) -> Result<String> {
    let t = std::fs::read_to_string(path).with_context(|| format!("read admin token {}", path.display()))?.trim().to_string();
    if t.len() < 32 {
        bail!("admin token too short (need >= 32 chars)");
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::metadata(path)?.permissions().mode() & 0o077;
        if mode != 0 {
            tracing::warn!("admin token file {} is readable by group/others (mode {:o})", path.display(), mode);
        }
    }
    Ok(t)
}

async fn serve(b: api::B, cfg: &NodeConfig) -> Result<()> {
    let token = read_token(&cfg.admin_token_path)?;
    let admin_addr: std::net::SocketAddr = cfg.admin_listen.parse().context("admin_listen")?;
    if !admin_addr.ip().is_loopback() {
        tracing::warn!("ADMIN API bound to non-loopback address {admin_addr}; ensure network-level access control");
    }
    let pub_l = tokio::net::TcpListener::bind(&cfg.api_listen).await.with_context(|| format!("bind api {}", cfg.api_listen))?;
    let adm_l = tokio::net::TcpListener::bind(admin_addr).await.with_context(|| format!("bind admin {admin_addr}"))?;
    tracing::info!("public API on {} ; admin API on {}", cfg.api_listen, admin_addr);
    let pr = api::public_router(b.clone());
    let ar = api::admin_router(api::AdminState { b, token: Arc::new(token) });
    let p = tokio::spawn(async move { axum::serve(pub_l, pr).await });
    let a = tokio::spawn(async move { axum::serve(adm_l, ar).await });
    tokio::select! {
        r = p => { r??; }
        r = a => { r??; }
        _ = tokio::signal::ctrl_c() => { tracing::info!("interrupt: shutting down"); }
    }
    Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt().with_env_filter(tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into())).with_target(false).init();
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::Run { config } => {
            let (cfg, p) = load(&config)?;
            for f in faults::any_enabled() {
                tracing::warn!("DEV FAULT INJECTION ACTIVE: {f}");
            }
            tracing::info!("node {} profile {} chain {} genesis {}", cfg.node_name, p.profile.as_str(), p.doc.chain_id, hex::encode(p.hash));
            match p.profile {
                Profile::Pow => {
                    let n = pow_node::PowNode::open(cfg.clone(), p)?;
                    tracing::info!("chain loaded at height {} (state root verified)", n.chain.lock().height());
                    n.clone().run().await?;
                    serve(Arc::new(api::Backend::Pow(n)), &cfg).await?;
                }
                _ => {
                    let app = abci::App::open(p.clone(), &cfg)?;
                    tracing::info!("application state at height {} (state root verified)", app.last_height);
                    let app = Arc::new(parking_lot::Mutex::new(app));
                    let listen = cfg.bft.as_ref().context("bft section missing in node config")?.abci_listen.clone();
                    let a2 = app.clone();
                    tokio::spawn(async move {
                        if let Err(e) = abci::serve_abci(a2, listen).await {
                            tracing::error!("abci server: {e}");
                            std::process::exit(1);
                        }
                    });
                    let n = Arc::new(abci::BftNode { cfg: cfg.clone(), p, app, http: reqwest::Client::new(), started_ms: views::now_ms(), shutdown_notify: tokio::sync::Notify::new() });
                    serve(Arc::new(api::Backend::Bft(n)), &cfg).await?;
                }
            }
        }
        Cmd::VerifyChain { config } => {
            let (cfg, p) = load(&config)?;
            match p.profile {
                Profile::Pow => {
                    let c = pow_chain::Chain::open(p.clone(), store::Store::open(&cfg.data_dir)?, mempool::Mempool::new(cfg.mempool.clone()), u64::MAX, None)?;
                    let h = c.verify_chain()?;
                    println!("{}", serde_json::json!({"ok": true, "profile": "pow", "verified_height": h, "state_root": hex::encode(c.state.root())}));
                }
                _ => {
                    let app = abci::App::open(p.clone(), &cfg)?;
                    let (h, st) = abci::replay(&p, &app.store, p.genesis_state(), 0)?;
                    if st.root() != app.state.root() {
                        bail!("replayed state differs from stored state");
                    }
                    println!("{}", serde_json::json!({"ok": true, "profile": p.profile.as_str(), "verified_height": h, "state_root": hex::encode(st.root())}));
                }
            }
        }
        Cmd::Backup { config, out } => {
            let (cfg, _) = load(&config)?;
            let s = store::Store::open(&cfg.data_dir)?;
            let dest = s.backup_to(&out)?;
            let h = s.tip_height()?.unwrap_or(0);
            println!("{}", serde_json::json!({"ok": true, "backup": dest.display().to_string(), "tip_height": h}));
        }
        Cmd::Replay { config, snapshot, repair } => {
            let (cfg, p) = load(&config)?;
            let data = std::fs::read(&snapshot)?;
            let (hdr, st) = aureom_core::snapshot::read_verified(&data).map_err(|e| anyhow::anyhow!("snapshot rejected: {e}"))?;
            if hdr.genesis_hash != p.hash || hdr.chain_id != p.doc.chain_id {
                bail!("snapshot belongs to a different chain");
            }
            let s = store::Store::open(&cfg.data_dir)?;
            let trusted = match p.profile {
                Profile::Pow => {
                    let id = s.height(hdr.height)?.context("snapshot height not on local main chain")?;
                    let b = dblock(&s.get(store::T::Blocks, &id)?.context("block")?)?;
                    b.header.state_root
                }
                _ => abci::recorded_root(&s, hdr.height)?,
            };
            if trusted != hdr.state_root {
                bail!("snapshot state root {} does not match the locally validated block at height {} ({}) — rejected", hex::encode(hdr.state_root), hdr.height, hex::encode(trusted));
            }
            drop(s);
            let (tip, replayed) = match p.profile {
                Profile::Pow => {
                    let s = store::Store::open(&cfg.data_dir)?;
                    let tip = s.tip_height()?.unwrap_or(0);
                    let mut st = st;
                    for h in hdr.height + 1..=tip {
                        let id = s.height(h)?.context("block id")?;
                        let b = dblock(&s.get(store::T::Blocks, &id)?.context("block")?)?;
                        let mut ctx = aureom_core::exec::BlockCtx::new(h, Some(b.header.miner));
                        let mut ov = st.overlay();
                        aureom_core::exec::execute_txs(&mut ov, &p, &mut ctx, &b.txs).map_err(|(i, e)| anyhow::anyhow!("height {h} tx {i}: {e}"))?;
                        aureom_core::exec::pow_coinbase(&mut ov, &p, &mut ctx, &b.header.miner);
                        let cs = ov.into_changes();
                        st.apply(&cs);
                        if st.root() != b.header.state_root {
                            bail!("state root mismatch at height {h}");
                        }
                    }
                    (tip, st)
                }
                _ => {
                    let s = store::Store::open(&cfg.data_dir)?;
                    abci::replay(&p, &s, st, hdr.height)?
                }
            };
            let s = store::Store::open(&cfg.data_dir)?;
            let stored = s.load_state()?;
            let matches = stored.root() == replayed.root();
            if repair && !matches {
                s.clear(store::T::State)?;
                let mut b = store::Batch::default();
                for (k, v) in replayed.entries() {
                    b.put(store::T::State, k.clone(), v.clone());
                }
                s.write(b)?;
            }
            println!("{}", serde_json::json!({"ok": true, "snapshot_height": hdr.height, "replayed_to": tip, "state_root": hex::encode(replayed.root()),
                "stored_state_matched": matches, "repaired": repair && !matches}));
        }
        Cmd::Reindex { config } => {
            let (cfg, p) = load(&config)?;
            let s = store::Store::open(&cfg.data_dir)?;
            for t in [store::T::TxIndex, store::T::AddrIndex, store::T::Events] {
                s.clear(t)?;
            }
            let tip = s.tip_height()?.unwrap_or(0);
            let mut n = 0;
            for h in 1..=tip {
                let Some(id) = s.height(h)? else { continue };
                let id: [u8; 32] = id.try_into().unwrap();
                let raw = s.get(store::T::Blocks, &id)?.context("block")?;
                let txs: Vec<aureom_core::types::SignedTx> = match p.profile {
                    Profile::Pow => dblock(&raw)?.txs,
                    _ => abci::block_txs(&raw)?,
                };
                let rc = pow_chain::receipts_decode(&s.get(store::T::Receipts, &id)?.unwrap_or_default()).unwrap_or_default();
                let mut b = store::Batch::default();
                views::index_block(&mut b, h, &id, &txs, &rc, &[], false);
                s.write(b)?;
                n += txs.len();
            }
            println!("{}", serde_json::json!({"ok": true, "reindexed_blocks": tip, "transactions": n}));
        }
    }
    Ok(())
}
