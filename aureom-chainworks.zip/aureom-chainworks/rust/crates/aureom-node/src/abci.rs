//! CometBFT ABCI 2.0 (v0.38) application for the PoS and PoA profiles.
//!
//! CometBFT owns peer-to-peer networking, the mempool, block storage, proposer
//! selection, voting, evidence handling and double-sign protection. This application
//! owns transaction validity, execution, the state commitment (app hash), validator-set
//! updates, slashing and governance. Blocks committed by CometBFT are final.

use crate::api::ApiError;
use crate::config::NodeConfig;
use crate::mempool::StatusRec;
use crate::store::{Batch, Store, T};
use crate::views::{self, now_ms, with_observed};
use anyhow::{bail, Context, Result};
use aureom_core::codec::{Decode, Reader, Writer};
use aureom_core::crypto::{Addr, Hash32};
use aureom_core::exec::{self, BlockCtx, Misbehavior, VoteInfo};
use aureom_core::genesis::{genesis_hash_of_value, ChainParams, Profile};
use aureom_core::state::State;
use aureom_core::types::*;
use parking_lot::Mutex;
use prost::Message;
use serde_json::{json, Value};
use std::collections::{BTreeSet, HashMap};
use std::sync::Arc;
use tendermint_proto::v0_38::abci::{self as pb, request::Value as Req, response::Value as Resp};
use tendermint_proto::v0_38::crypto::{public_key::Sum, PublicKey};
use tokio::io::{AsyncReadExt, AsyncWriteExt, BufReader, BufWriter};
use tokio::net::TcpListener;

pub const CODE_OK: u32 = 0;
pub const CODE_INADMISSIBLE: u32 = 1;
pub const CODE_EXEC_FAILED: u32 = 2;
pub const CODE_MEMPOOL: u32 = 3;

#[derive(Clone, Debug)]
pub struct AppBlock {
    pub height: u64,
    pub time_ms: u64,
    pub comet_hash: Hash32,
    pub proposer: Addr,
    pub txs: Vec<Vec<u8>>,
    pub codes: Vec<u8>,
    pub state_root: Hash32,
    /// Consensus inputs to execution, kept so the block can be replayed offline.
    pub votes: Vec<(Addr, u64, bool)>,
    pub evidence: Vec<(Addr, u64, String)>,
}

impl AppBlock {
    fn encode(&self) -> Vec<u8> {
        let mut w = Writer::new();
        w.u64(self.height);
        w.u64(self.time_ms);
        w.fixed(&self.comet_hash);
        w.fixed(&self.proposer);
        w.vec(&self.txs, |w, t| w.bytes(t));
        w.bytes(&self.codes);
        w.fixed(&self.state_root);
        w.vec(&self.votes, |w, (a, p, s)| {
            w.fixed(a);
            w.u64(*p);
            w.bool(*s);
        });
        w.vec(&self.evidence, |w, (a, h, k)| {
            w.fixed(a);
            w.u64(*h);
            w.string(k);
        });
        w.finish()
    }
    fn decode(b: &[u8]) -> Result<Self> {
        let mut r = Reader::new(b);
        let v = AppBlock {
            height: r.u64()?,
            time_ms: r.u64()?,
            comet_hash: r.fixed()?,
            proposer: r.fixed()?,
            txs: r.vec(100_000, 4, |r| r.bytes(1 << 20))?,
            codes: r.bytes(100_000)?,
            state_root: r.fixed()?,
            votes: r.vec(10_000, 29, |r| Ok((r.fixed()?, r.u64()?, r.bool()?)))?,
            evidence: r.vec(10_000, 32, |r| Ok((r.fixed()?, r.u64()?, r.string(32)?)))?,
        };
        r.end()?;
        Ok(v)
    }
}

#[derive(Default, Clone)]
pub struct LastCommit {
    pub height: u64,
    pub signed_power: u64,
    pub total_power: u64,
    pub signers: BTreeSet<Addr>,
    pub validators: usize,
}

pub struct App {
    pub p: Arc<ChainParams>,
    pub store: Store,
    pub state: State,
    pub last_height: u64,
    pub last_app_hash: Hash32,
    pub last_time_ms: u64,
    pending: Option<(u64, Batch, Vec<Hash32>)>,
    check: HashMap<Addr, (u64, u128, usize)>,
    pub pending_ids: HashMap<Hash32, u64>,
    pub history: HashMap<Hash32, StatusRec>,
    pub last_commit: LastCommit,
    pub halted: Option<String>,
    pub keep_blocks: u64,
    pub max_per_sender: usize,
    pub initialized: bool,
}

fn ts_ms(t: &Option<tendermint_proto::google::protobuf::Timestamp>) -> u64 {
    t.as_ref().map(|t| (t.seconds.max(0) as u64) * 1000 + (t.nanos.max(0) as u64) / 1_000_000).unwrap_or(0)
}

fn addr20(b: &[u8]) -> Option<Addr> {
    b.try_into().ok()
}

fn votes_of(ci: &Option<pb::CommitInfo>) -> Vec<VoteInfo> {
    ci.as_ref()
        .map(|c| {
            c.votes
                .iter()
                .filter_map(|v| {
                    let val = v.validator.as_ref()?;
                    Some(VoteInfo { consensus_address: addr20(&val.address)?, power: val.power.max(0) as u64, signed: v.block_id_flag == 2 })
                })
                .collect()
        })
        .unwrap_or_default()
}

fn misbehavior_of(m: &[pb::Misbehavior]) -> Vec<Misbehavior> {
    m.iter()
        .filter_map(|x| {
            let val = x.validator.as_ref()?;
            Some(Misbehavior {
                consensus_address: addr20(&val.address)?,
                height: x.height.max(0) as u64,
                kind: if x.r#type == 1 { "duplicate_vote".into() } else { "light_client_attack".into() },
            })
        })
        .collect()
}

impl App {
    pub fn open(p: Arc<ChainParams>, cfg: &NodeConfig) -> Result<App> {
        let store = Store::open(&cfg.data_dir)?;
        let mut app = App {
            p: p.clone(),
            store,
            state: State::new(),
            last_height: 0,
            last_app_hash: [0; 32],
            last_time_ms: 0,
            pending: None,
            check: HashMap::new(),
            pending_ids: HashMap::new(),
            history: HashMap::new(),
            last_commit: LastCommit::default(),
            halted: None,
            keep_blocks: cfg.pruning.keep_blocks,
            max_per_sender: cfg.mempool.max_per_sender,
            initialized: false,
        };
        if let Some(gh) = app.store.meta("genesis_hash")? {
            if gh != p.hash {
                bail!("database belongs to genesis {} but node is configured for {}", hex::encode(gh), hex::encode(p.hash));
            }
            app.state = app.store.load_state()?;
            app.last_height = app.store.tip_height()?.unwrap_or(0);
            app.last_app_hash = app.store.meta("app_hash")?.context("app_hash")?.try_into().map_err(|_| anyhow::anyhow!("bad app hash"))?;
            app.last_time_ms = app.store.meta("tip_time_ms")?.map(|v| u64::from_be_bytes(v.try_into().unwrap())).unwrap_or(0);
            let root = app.state.root();
            if root != app.last_app_hash {
                bail!("crash-recovery check failed: stored state root {} != committed app hash {} at height {}", hex::encode(root), hex::encode(app.last_app_hash), app.last_height);
            }
            app.initialized = true;
        }
        Ok(app)
    }

    fn info(&self) -> pb::ResponseInfo {
        pb::ResponseInfo {
            data: format!("aureom-chainworks/{}", self.p.profile.as_str()),
            version: aureom_core::NODE_SOFTWARE_VERSION.into(),
            app_version: aureom_core::SUPPORTED_PROTOCOL_VERSION as u64,
            last_block_height: self.last_height as i64,
            last_block_app_hash: if self.initialized { self.last_app_hash.to_vec().into() } else { Default::default() },
        }
    }

    fn init_chain(&mut self, r: pb::RequestInitChain) -> Result<pb::ResponseInitChain> {
        if r.chain_id != self.p.doc.chain_id {
            bail!("InitChain chain_id {} != genesis {}", r.chain_id, self.p.doc.chain_id);
        }
        let v: Value = serde_json::from_slice(&r.app_state_bytes).context("app_state is not JSON")?;
        let h = genesis_hash_of_value(&v).map_err(|e| anyhow::anyhow!(e))?;
        if h != self.p.hash {
            bail!("CometBFT app_state genesis hash {} != expected {}", hex::encode(h), hex::encode(self.p.hash));
        }
        let st = self.p.genesis_state();
        let ours: Vec<([u8; 32], u64)> = st.overlay().valset().0;
        let mut theirs: Vec<([u8; 32], u64)> = r
            .validators
            .iter()
            .filter_map(|u| match u.pub_key.as_ref()?.sum.as_ref()? {
                Sum::Ed25519(k) => Some((k.as_slice().try_into().ok()?, u.power as u64)),
                _ => None,
            })
            .collect();
        theirs.sort();
        if ours != theirs {
            bail!("CometBFT genesis validators do not match the Aureom genesis validator set");
        }
        let root = st.root();
        let mut b = Batch::default();
        for (k, v) in st.entries() {
            b.put(T::State, k.clone(), v.clone());
        }
        b.meta("genesis_hash", self.p.hash.to_vec());
        b.meta("profile", self.p.profile.as_str().as_bytes().to_vec());
        b.meta("tip_height", 0u64.to_be_bytes().to_vec());
        b.meta("app_hash", root.to_vec());
        self.store.write(b)?;
        self.state = st;
        self.last_app_hash = root;
        self.last_height = 0;
        self.initialized = true;
        tracing::info!("InitChain: genesis {} verified, app hash {}", hex::encode(self.p.hash), hex::encode(root));
        Ok(pb::ResponseInitChain { consensus_params: None, validators: vec![], app_hash: root.to_vec().into() })
    }

    fn check_tx(&mut self, r: pb::RequestCheckTx) -> pb::ResponseCheckTx {
        let recheck = r.r#type == 1;
        let fail = |code: u32, log: String| pb::ResponseCheckTx { code, log, codespace: "aureom".into(), ..Default::default() };
        let tx = match exec::decode_tx(&self.p, &r.tx) {
            Ok(t) => t,
            Err(e) => return fail(CODE_INADMISSIBLE, format!("{}: {e}", e.code())),
        };
        let id = tx.txid();
        let res = self.check_inner(&tx, r.tx.len(), recheck);
        match res {
            Ok(()) => {
                self.pending_ids.entry(id).or_insert(now_ms());
                pb::ResponseCheckTx { code: CODE_OK, ..Default::default() }
            }
            Err((code, log)) => {
                if recheck {
                    self.pending_ids.remove(&id);
                    self.record(id, "dropped", Some(format!("invalid on recheck: {log}")));
                }
                fail(code, log)
            }
        }
    }

    fn check_inner(&mut self, tx: &SignedTx, size: usize, recheck: bool) -> Result<(), (u32, String)> {
        if !recheck {
            exec::stateless_check(&self.p, tx, size).map_err(|e| (CODE_INADMISSIBLE, format!("{}: {e}", e.code())))?;
        }
        let t = &tx.tx;
        let h = self.last_height + 1;
        if t.expiry_height != 0 && h > t.expiry_height {
            return Err((CODE_INADMISSIBLE, format!("expired: valid until height {}", t.expiry_height)));
        }
        let sender = t.sender();
        let acct = self.state.account(&sender);
        let (next, fees, count) = self.check.get(&sender).copied().unwrap_or((acct.nonce, 0, 0));
        if t.nonce != next {
            return Err((CODE_INADMISSIBLE, format!("bad_nonce: expected {next}, got {}", t.nonce)));
        }
        if count >= self.max_per_sender {
            return Err((CODE_MEMPOOL, "sender_limit: too many pending transactions".into()));
        }
        let avail = acct.available(h);
        if fees + t.fee as u128 > avail {
            return Err((CODE_INADMISSIBLE, format!("insufficient_fee_balance: available {}", avail.saturating_sub(fees))));
        }
        self.check.insert(sender, (next + 1, fees + t.fee as u128, count + 1));
        Ok(())
    }

    fn record(&mut self, id: Hash32, status: &'static str, reason: Option<String>) {
        if self.history.len() > 20_000 {
            self.history.clear();
        }
        self.history.insert(id, StatusRec { status, reason, at_ms: now_ms() });
    }

    /// Simulate a block on an overlay; returns admissible txs (filter) or the first error.
    fn simulate(&self, h: u64, proposer: &[u8], votes: &[VoteInfo], ev: &[Misbehavior], txs: &[prost::bytes::Bytes], filter: bool, max_bytes: usize) -> Result<Vec<prost::bytes::Bytes>, String> {
        let prop = addr20(proposer).and_then(|a| self.state.overlay().operator_of_consaddr(&a));
        let mut ctx = BlockCtx::new(h, prop);
        let mut ov = self.state.overlay();
        exec::begin_block_bft(&mut ov, &self.p, &mut ctx, votes, ev)?;
        let mut out = vec![];
        let mut bytes = 0usize;
        let max_txs = self.p.doc.limits.max_block_txs as usize;
        let max_bytes = max_bytes.min(self.p.doc.limits.max_block_bytes as usize);
        for raw in txs {
            let r = exec::decode_tx(&self.p, raw).and_then(|t| exec::apply_tx(&mut ov, &self.p, &mut ctx, &t, raw.len()));
            match r {
                Ok(_) => {
                    if out.len() >= max_txs || bytes + raw.len() > max_bytes {
                        if filter {
                            break;
                        }
                        return Err("block exceeds size or count limits".into());
                    }
                    bytes += raw.len();
                    out.push(raw.clone());
                }
                Err(e) => {
                    if !filter {
                        return Err(format!("inadmissible transaction: {e}"));
                    }
                }
            }
        }
        Ok(out)
    }

    fn finalize(&mut self, r: pb::RequestFinalizeBlock) -> Result<pb::ResponseFinalizeBlock, String> {
        let h = r.height as u64;
        if h != self.last_height + 1 {
            return Err(format!("FinalizeBlock height {h} but last committed {}", self.last_height));
        }
        let votes = votes_of(&r.decided_last_commit);
        let ev = misbehavior_of(&r.misbehavior);
        let prop_cons = addr20(&r.proposer_address).unwrap_or([0; 20]);
        let prop = self.state.overlay().operator_of_consaddr(&prop_cons);
        let mut ctx = BlockCtx::new(h, prop);
        let time_ms = ts_ms(&r.time);
        let st = &mut self.state;
        let mut ov = st.overlay();
        let begin_events = match exec::begin_block_bft(&mut ov, &self.p, &mut ctx, &votes, &ev) {
            Ok(e) => e,
            Err(halt) => {
                self.halted = Some(halt.clone());
                return Err(halt);
            }
        };
        let mut results = vec![];
        let mut receipts = vec![];
        let mut decoded = vec![];
        let mut codes = vec![];
        for raw in &r.txs {
            match exec::decode_tx(&self.p, raw).and_then(|t| exec::apply_tx(&mut ov, &self.p, &mut ctx, &t, raw.len()).map(|rc| (t, rc))) {
                Ok((t, rc)) => {
                    let code = if rc.status == STATUS_SUCCESS { CODE_OK } else { CODE_EXEC_FAILED };
                    results.push(pb::ExecTxResult {
                        code,
                        log: if code == 0 { String::new() } else { exec::err::name(rc.error_code).into() },
                        data: rc.txid.to_vec().into(),
                        codespace: "aureom".into(),
                        ..Default::default()
                    });
                    codes.push(code as u8);
                    decoded.push(t);
                    receipts.push(rc);
                }
                Err(e) => {
                    // Should be impossible after ProcessProposal; deterministic skip.
                    results.push(pb::ExecTxResult { code: CODE_INADMISSIBLE, log: e.to_string(), codespace: "aureom".into(), ..Default::default() });
                    codes.push(CODE_INADMISSIBLE as u8);
                }
            }
        }
        let (updates, end_events) = exec::end_block_bft(&mut ov, &self.p, &mut ctx);
        let cs = ov.into_changes();
        st.apply(&cs);
        let root = st.root();
        let mut block_events = begin_events;
        block_events.extend(end_events);
        let bid: Hash32 = r.hash.as_ref().try_into().unwrap_or([0; 32]);
        let blk = AppBlock { height: h, time_ms, comet_hash: bid, proposer: prop_cons, txs: r.txs.iter().map(|b| b.to_vec()).collect(), codes, state_root: root,
            votes: votes.iter().map(|v| (v.consensus_address, v.power, v.signed)).collect(),
            evidence: ev.iter().map(|e| (e.consensus_address, e.height, e.kind.clone())).collect() };
        let mut b = Batch::default();
        b.state_changes(&cs);
        b.put(T::Blocks, bid.to_vec(), blk.encode());
        b.height(h, Some(bid.to_vec()));
        b.put(T::Receipts, bid.to_vec(), crate::pow_chain::receipts_encode(&receipts));
        // events of the block itself are stored alongside receipts for the explorer
        views::index_block(&mut b, h, &bid, &decoded, &receipts, &block_events, false);
        b.meta("tip_height", h.to_be_bytes().to_vec());
        b.meta("tip_id", bid.to_vec());
        b.meta("tip_time_ms", time_ms.to_be_bytes().to_vec());
        b.meta("app_hash", root.to_vec());
        let included: Vec<Hash32> = decoded.iter().map(|t| t.txid()).collect();
        self.pending = Some((h, b, included));
        self.last_time_ms = time_ms;
        let total: u64 = votes.iter().map(|v| v.power).sum();
        self.last_commit = LastCommit {
            height: h.saturating_sub(1),
            signed_power: votes.iter().filter(|v| v.signed).map(|v| v.power).sum(),
            total_power: total,
            signers: votes.iter().filter(|v| v.signed).map(|v| v.consensus_address).collect(),
            validators: votes.len(),
        };
        let vu = updates
            .iter()
            .map(|(k, pw)| pb::ValidatorUpdate { pub_key: Some(PublicKey { sum: Some(Sum::Ed25519(k.to_vec())) }), power: *pw as i64 })
            .collect();
        if !updates.is_empty() {
            tracing::info!("height {h}: {} validator update(s), effective at height {}", updates.len(), h + 2);
        }
        Ok(pb::ResponseFinalizeBlock { events: vec![], tx_results: results, validator_updates: vu, consensus_param_updates: None, app_hash: root.to_vec().into() })
    }

    fn commit(&mut self) -> Result<pb::ResponseCommit> {
        let Some((h, batch, included)) = self.pending.take() else { bail!("Commit without FinalizeBlock") };
        self.store.write(batch)?;
        self.last_height = h;
        self.last_app_hash = self.state.root();
        self.check.clear();
        for id in included {
            self.pending_ids.remove(&id);
            self.history.remove(&id);
        }
        let retain = if self.keep_blocks > 0 && h > self.keep_blocks { (h - self.keep_blocks) as i64 } else { 0 };
        Ok(pb::ResponseCommit { retain_height: retain })
    }

    pub fn handle(&mut self, req: Req) -> Resp {
        match req {
            Req::Echo(e) => Resp::Echo(pb::ResponseEcho { message: e.message }),
            Req::Flush(_) => Resp::Flush(pb::ResponseFlush {}),
            Req::Info(_) => Resp::Info(self.info()),
            Req::InitChain(r) => match self.init_chain(r) {
                Ok(x) => Resp::InitChain(x),
                Err(e) => {
                    tracing::error!("InitChain refused: {e}");
                    Resp::Exception(pb::ResponseException { error: e.to_string() })
                }
            },
            Req::Query(q) => {
                let key = hex::decode(q.path.trim_start_matches("/state/")).unwrap_or_default();
                let v = self.state.get(&key).cloned().unwrap_or_default();
                Resp::Query(pb::ResponseQuery { code: 0, key: key.into(), value: v.into(), height: self.last_height as i64, ..Default::default() })
            }
            Req::CheckTx(r) => Resp::CheckTx(self.check_tx(r)),
            Req::Commit(_) => match self.commit() {
                Ok(c) => Resp::Commit(c),
                Err(e) => {
                    tracing::error!("commit failed: {e}");
                    Resp::Exception(pb::ResponseException { error: e.to_string() })
                }
            },
            Req::ListSnapshots(_) => Resp::ListSnapshots(Default::default()),
            Req::OfferSnapshot(_) => Resp::OfferSnapshot(pb::ResponseOfferSnapshot { result: 3 }), // REJECT: state sync not offered in v1
            Req::LoadSnapshotChunk(_) => Resp::LoadSnapshotChunk(Default::default()),
            Req::ApplySnapshotChunk(_) => Resp::ApplySnapshotChunk(pb::ResponseApplySnapshotChunk { result: 2, ..Default::default() }),
            Req::PrepareProposal(r) => {
                let votes: Vec<VoteInfo> = r
                    .local_last_commit
                    .as_ref()
                    .map(|c| c.votes.iter().filter_map(|v| {
                        let val = v.validator.as_ref()?;
                        Some(VoteInfo { consensus_address: addr20(&val.address)?, power: val.power.max(0) as u64, signed: v.block_id_flag == 2 })
                    }).collect())
                    .unwrap_or_default();
                let ev = misbehavior_of(&r.misbehavior);
                let txs = self.simulate(r.height as u64, &r.proposer_address, &votes, &ev, &r.txs, true, r.max_tx_bytes.max(0) as usize).unwrap_or_default();
                Resp::PrepareProposal(pb::ResponsePrepareProposal { txs })
            }
            Req::ProcessProposal(r) => {
                let votes = votes_of(&r.proposed_last_commit);
                let ev = misbehavior_of(&r.misbehavior);
                let status = match self.simulate(r.height as u64, &r.proposer_address, &votes, &ev, &r.txs, false, usize::MAX) {
                    Ok(_) => 1,
                    Err(e) => {
                        tracing::warn!("rejecting proposal at height {}: {e}", r.height);
                        2
                    }
                };
                Resp::ProcessProposal(pb::ResponseProcessProposal { status })
            }
            Req::ExtendVote(_) => Resp::ExtendVote(Default::default()),
            Req::VerifyVoteExtension(_) => Resp::VerifyVoteExtension(pb::ResponseVerifyVoteExtension { status: 1 }),
            Req::FinalizeBlock(r) => match self.finalize(r) {
                Ok(x) => Resp::FinalizeBlock(x),
                Err(e) => {
                    tracing::error!("HALT: {e}");
                    Resp::Exception(pb::ResponseException { error: e })
                }
            },
        }
    }
}

/// Re-execute stored BFT blocks from `start` state (height `from`) and check app hashes.
pub fn replay(p: &ChainParams, store: &Store, mut st: State, from: u64) -> Result<(u64, State)> {
    let tip = store.tip_height()?.unwrap_or(0);
    for h in from + 1..=tip {
        let id = store.height(h)?.with_context(|| format!("missing block {h}"))?;
        let blk = AppBlock::decode(&store.get(T::Blocks, &id)?.context("block body")?)?;
        let votes: Vec<VoteInfo> = blk.votes.iter().map(|(a, p, s)| VoteInfo { consensus_address: *a, power: *p, signed: *s }).collect();
        let ev: Vec<Misbehavior> = blk.evidence.iter().map(|(a, h, k)| Misbehavior { consensus_address: *a, height: *h, kind: k.clone() }).collect();
        let prop = st.overlay().operator_of_consaddr(&blk.proposer);
        let mut ctx = BlockCtx::new(h, prop);
        let mut ov = st.overlay();
        exec::begin_block_bft(&mut ov, p, &mut ctx, &votes, &ev).map_err(|e| anyhow::anyhow!(e))?;
        for raw in &blk.txs {
            if let Ok(t) = exec::decode_tx(p, raw) {
                let _ = exec::apply_tx(&mut ov, p, &mut ctx, &t, raw.len());
            }
        }
        exec::end_block_bft(&mut ov, p, &mut ctx);
        let cs = ov.into_changes();
        st.apply(&cs);
        if st.root() != blk.state_root {
            bail!("app hash mismatch at height {h}: replay {} vs recorded {}", hex::encode(st.root()), hex::encode(blk.state_root));
        }
    }
    Ok((tip, st))
}

/// Admissible (executed) transactions of a stored block, aligned with its receipts.
pub fn block_txs(raw: &[u8]) -> Result<Vec<SignedTx>> {
    let b = AppBlock::decode(raw)?;
    Ok(b.txs.iter().zip(b.codes.iter()).filter(|(_, c)| **c as u32 != CODE_INADMISSIBLE).filter_map(|(t, _)| SignedTx::decode(t).ok()).collect())
}

/// State root recorded for a committed height (trusted local header data).
pub fn recorded_root(store: &Store, h: u64) -> Result<Hash32> {
    let id = store.height(h)?.with_context(|| format!("no block at height {h}"))?;
    Ok(AppBlock::decode(&store.get(T::Blocks, &id)?.context("block body")?)?.state_root)
}

// ------------------------------------------------------------------ socket server

async fn read_uvarint<R: AsyncReadExt + Unpin>(r: &mut R) -> Result<Option<u64>> {
    let mut x: u64 = 0;
    for i in 0..10 {
        let b = match r.read_u8().await {
            Ok(b) => b,
            Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof && i == 0 => return Ok(None),
            Err(e) => return Err(e.into()),
        };
        x |= ((b & 0x7f) as u64) << (7 * i);
        if b & 0x80 == 0 {
            return Ok(Some(x));
        }
    }
    bail!("varint too long")
}

pub async fn serve_abci(app: Arc<Mutex<App>>, listen: String) -> Result<()> {
    let l = TcpListener::bind(&listen).await.with_context(|| format!("bind ABCI {listen}"))?;
    tracing::info!("ABCI server listening on {listen}");
    loop {
        let (s, peer) = l.accept().await?;
        let app = app.clone();
        tokio::spawn(async move {
            let (rd, wr) = s.into_split();
            let mut rd = BufReader::new(rd);
            let mut wr = BufWriter::new(wr);
            loop {
                let len = match read_uvarint(&mut rd).await {
                    Ok(Some(n)) => n as usize,
                    Ok(None) => break,
                    Err(e) => {
                        tracing::warn!("abci {peer}: {e}");
                        break;
                    }
                };
                if len > 64 << 20 {
                    tracing::error!("abci message too large");
                    break;
                }
                let mut buf = vec![0u8; len];
                if rd.read_exact(&mut buf).await.is_err() {
                    break;
                }
                let req = match pb::Request::decode(buf.as_slice()) {
                    Ok(r) => r,
                    Err(e) => {
                        tracing::error!("abci decode: {e}");
                        break;
                    }
                };
                let Some(v) = req.value else { continue };
                let is_flush = matches!(v, Req::Flush(_));
                let resp = app.lock().handle(v);
                let out = pb::Response { value: Some(resp) }.encode_length_delimited_to_vec();
                if wr.write_all(&out).await.is_err() {
                    break;
                }
                if is_flush && wr.flush().await.is_err() {
                    break;
                }
            }
        });
    }
}

// ------------------------------------------------------------------ node API

pub struct BftNode {
    pub cfg: NodeConfig,
    pub p: Arc<ChainParams>,
    pub app: Arc<Mutex<App>>,
    pub http: reqwest::Client,
    pub started_ms: u64,
    pub shutdown_notify: tokio::sync::Notify,
}

impl BftNode {
    fn rpc_base(&self) -> String {
        self.cfg.bft.as_ref().unwrap().cometbft_rpc.trim_end_matches('/').to_string()
    }
    async fn rpc(&self, path: &str) -> Result<Value> {
        let r = self.http.get(format!("{}{}", self.rpc_base(), path)).timeout(std::time::Duration::from_secs(3)).send().await?;
        let v: Value = r.json().await?;
        if let Some(e) = v.get("error") {
            bail!("cometbft rpc error: {e}");
        }
        Ok(v["result"].clone())
    }

    pub fn network(&self) -> Value {
        let g = &self.p.doc;
        let poa = self.p.profile == Profile::Poa;
        with_observed(json!({
            "network_name": g.network_name, "chain_id": g.chain_id, "profile": self.p.profile.as_str(),
            "backend": "cometbft", "backend_version": "0.38.x (see /v1/consensus/status)",
            "protocol_version": PROTOCOL_VERSION, "node_version": aureom_core::NODE_SOFTWARE_VERSION,
            "genesis_hash": hex::encode(self.p.hash), "node_name": self.cfg.node_name,
            "native_asset": g.native_asset, "monetary_policy": g.monetary_policy, "fee_policy": g.fee_policy, "limits": g.limits,
            "treasuries": (0..g.treasuries.len()).map(|i| json!({"label": g.treasuries[i].label, "address": self.p.addr(&self.p.treasury_addrs[i])})).collect::<Vec<_>>(),
            "finality": "deterministic-bft",
            "fault_assumption": if poa {
                "CometBFT (Tendermint) BFT among explicit authorities: safety if < 1/3 of voting power is Byzantine; liveness needs > 2/3 online. Permissioned: trust rests on the authority operators."
            } else {
                "CometBFT (Tendermint) BFT: safety if < 1/3 of bonded voting power is Byzantine; liveness needs > 2/3 online and partial synchrony. New nodes need a recent trusted checkpoint (weak subjectivity)."
            },
        }))
    }

    pub async fn health(&self) -> Value {
        let st = self.rpc("/status").await;
        let ni = self.rpc("/net_info").await;
        let (h, tip_id, t, size, entries, halted, mempool) = {
            let a = self.app.lock();
            (a.last_height, a.store.meta("tip_id").ok().flatten().map(hex::encode), a.last_time_ms, a.store.db_bytes(), a.state.len(), a.halted.clone(), a.pending_ids.len())
        };
        let now = now_ms();
        let mut alerts = vec![];
        let (peers, catching_up) = match (&st, &ni) {
            (Ok(s), Ok(n)) => (n["n_peers"].as_str().and_then(|x| x.parse().ok()).unwrap_or(0u64), s["sync_info"]["catching_up"].as_bool().unwrap_or(false)),
            _ => {
                alerts.push(json!({"level": "critical", "code": "consensus_engine_unreachable", "message": "CometBFT RPC not reachable; this application is not receiving blocks"}));
                (0, false)
            }
        };
        if peers == 0 {
            alerts.push(json!({"level": "warning", "code": "no_peers", "message": "no connected peers"}));
        }
        let age = now.saturating_sub(t);
        if t > 0 && age > 30_000 {
            alerts.push(json!({"level": "warning", "code": "stale_tip", "message": format!("no block committed for {} s (quorum may be lost)", age / 1000)}));
        }
        if let Some(hx) = &halted {
            alerts.push(json!({"level": "critical", "code": "halted", "message": hx}));
        }
        for f in crate::faults::any_enabled() {
            alerts.push(json!({"level": "warning", "code": "fault_injection_active", "message": f}));
        }
        let status = if halted.is_some() { "halted" } else if alerts.is_empty() { "ok" } else { "degraded" };
        with_observed(json!({"status": status, "height": h, "tip_id": tip_id, "tip_time_ms": t, "tip_age_ms": age, "peers": peers, "syncing": catching_up,
            "mempool_txs": mempool, "storage": {"db_path": self.cfg.data_dir.join("chain.redb").display().to_string(), "db_bytes": size, "db_version": crate::store::DB_VERSION,
                "state_entries": entries, "pruning": {"keep_blocks": self.cfg.pruning.keep_blocks, "note": "CometBFT retain_height"}},
            "alerts": alerts, "uptime_ms": now - self.started_ms}))
    }

    fn block_by_id(&self, a: &App, id: &Hash32) -> Result<Option<Value>, ApiError> {
        let Some(b) = a.store.get(T::Blocks, id).map_err(ApiError::internal)? else { return Ok(None) };
        let blk = AppBlock::decode(&b).map_err(ApiError::internal)?;
        let rc = a.store.get(T::Receipts, id).map_err(ApiError::internal)?.map(|x| crate::pow_chain::receipts_decode(&x).unwrap_or_default()).unwrap_or_default();
        let ov = a.state.overlay();
        let proposer = ov.operator_of_consaddr(&blk.proposer).map(|o| a.p.addr(&o));
        let txs: Vec<Value> = blk.txs.iter().map(|t| match SignedTx::decode(t) {
            Ok(s) => aureom_core::json::unsigned_tx_json(&a.p, &s.tx),
            Err(_) => json!({"malformed": hex::encode(t)}),
        }).collect();
        Ok(Some(json!({"height": blk.height, "id": hex::encode(id), "timestamp_ms": blk.time_ms, "proposer": proposer,
            "proposer_consensus_address": hex::encode_upper(blk.proposer), "tx_count": blk.txs.len(),
            "size_bytes": blk.txs.iter().map(|t| t.len()).sum::<usize>(), "state_root": hex::encode(blk.state_root),
            "txs": txs, "tx_codes": blk.codes, "receipts": rc.iter().map(aureom_core::json::receipt_json).collect::<Vec<_>>(),
            "consensus": {"bft": {"cometbft_block_hash": hex::encode_upper(blk.comet_hash), "app_hash": hex::encode(blk.state_root),
                "note": "app_hash after this block appears in the header of the next CometBFT block"}},
            "on_main_chain": true, "confirmations": a.last_height - blk.height + 1, "finality": "final"})))
    }

    pub fn block(&self, ident: &str) -> Result<Value, ApiError> {
        let a = self.app.lock();
        let id: Hash32 = if ident == "latest" || ident.parse::<u64>().is_ok() {
            let h = if ident == "latest" { a.last_height } else { ident.parse().unwrap() };
            a.store.height(h).map_err(ApiError::internal)?.and_then(|v| v.try_into().ok()).ok_or(ApiError::not_found("no block at that height"))?
        } else {
            hex::decode(ident).ok().and_then(|b| b.try_into().ok()).ok_or(ApiError::bad("block identifier must be latest|height|hex id"))?
        };
        Ok(with_observed(self.block_by_id(&a, &id)?.ok_or(ApiError::not_found("unknown block"))?))
    }

    pub fn blocks(&self, before: Option<u64>, limit: usize) -> Value {
        let a = self.app.lock();
        let top = before.map(|b| b.saturating_sub(1)).unwrap_or(a.last_height).min(a.last_height);
        let mut v = vec![];
        for h in (1..=top).rev().take(limit) {
            if let Ok(Some(id)) = a.store.height(h) {
                if let Ok(Some(b)) = a.store.get(T::Blocks, &id) {
                    if let Ok(blk) = AppBlock::decode(&b) {
                        let prop = a.state.overlay().operator_of_consaddr(&blk.proposer).map(|o| a.p.addr(&o));
                        v.push(json!({"height": h, "id": hex::encode(&id), "timestamp_ms": blk.time_ms, "proposer": prop, "tx_count": blk.txs.len(), "confirmations": a.last_height - h + 1, "finality": "final"}));
                    }
                }
            }
        }
        with_observed(json!({"blocks": v, "tip_height": a.last_height}))
    }

    pub fn transaction(&self, txid: &str) -> Result<Value, ApiError> {
        let id: Hash32 = hex::decode(txid).ok().and_then(|b| b.try_into().ok()).ok_or(ApiError::bad("txid must be 64 hex chars"))?;
        let a = self.app.lock();
        if let Some(v) = a.store.get(T::TxIndex, &id).map_err(ApiError::internal)? {
            let (h, bid, idx) = views::decode_txindex(&v);
            let blk = AppBlock::decode(&a.store.get(T::Blocks, &bid).map_err(ApiError::internal)?.ok_or(ApiError::internal("block missing"))?).map_err(ApiError::internal)?;
            let rc = crate::pow_chain::receipts_decode(&a.store.get(T::Receipts, &bid).map_err(ApiError::internal)?.unwrap_or_default()).unwrap_or_default();
            let receipt = rc.iter().find(|r| r.txid == id);
            let tx = blk.txs.iter().filter_map(|t| SignedTx::decode(t).ok()).find(|t| t.txid() == id);
            return Ok(with_observed(json!({"id": txid, "status": "finalised", "block_height": h, "block_id": hex::encode(bid), "index": idx,
                "confirmations": a.last_height - h + 1, "finality": "final",
                "tx": tx.map(|t| aureom_core::json::unsigned_tx_json(&a.p, &t.tx)), "receipt": receipt.map(aureom_core::json::receipt_json)})));
        }
        if a.pending_ids.contains_key(&id) {
            return Ok(with_observed(json!({"id": txid, "status": "pending", "note": "accepted by CometBFT mempool via CheckTx; inclusion is not guaranteed"})));
        }
        if let Some(r) = a.history.get(&id) {
            return Ok(with_observed(json!({"id": txid, "status": r.status, "reason": r.reason, "at_ms": r.at_ms})));
        }
        Ok(with_observed(json!({"id": txid, "status": "unknown"})))
    }

    pub async fn submit(&self, hexs: &str) -> Result<Value, ApiError> {
        let bytes = hex::decode(hexs.trim_start_matches("0x")).map_err(|_| ApiError::bad("tx must be hex"))?;
        let tx = exec::decode_tx(&self.p, &bytes).map_err(|e| ApiError::code(400, e.code(), &e.to_string()))?;
        exec::stateless_check(&self.p, &tx, bytes.len()).map_err(|e| ApiError::code(400, e.code(), &e.to_string()))?;
        let id = tx.txid();
        {
            // replay protection is enforced by execution; reject obvious replays early with a clear code
            let a = self.app.lock();
            let acct = a.state.account(&tx.tx.sender());
            if tx.tx.nonce < acct.nonce {
                return Err(ApiError::code(400, "bad_nonce", &format!("bad nonce: account nonce is {}, transaction nonce {} was already used", acct.nonce, tx.tx.nonce)));
            }
        }
        let r = match self.rpc(&format!("/broadcast_tx_sync?tx=0x{}", hex::encode(&bytes))).await {
            Ok(r) => r,
            Err(e) if e.to_string().contains("already exists in cache") => {
                return Err(ApiError::code(400, "duplicate", "transaction already seen by this node's mempool (replay or resubmission)"));
            }
            Err(e) => return Err(ApiError::code(503, "consensus_engine_unreachable", &e.to_string())),
        };
        let code = r["code"].as_u64().unwrap_or(0);
        if code != 0 {
            let log = r["log"].as_str().unwrap_or("").to_string();
            self.app.lock().record(id, "rejected", Some(log.clone()));
            let c = log.split(':').next().unwrap_or("rejected").to_string();
            return Err(ApiError::code(400, &c, &log));
        }
        Ok(json!({"id": hex::encode(id), "status": "pending", "note": "accepted by this node's CometBFT mempool; inclusion is not guaranteed"}))
    }

    pub fn account(&self, addr: &str) -> Result<Value, ApiError> {
        let a = self.app.lock();
        let ad = a.p.parse_addr(addr).map_err(ApiError::bad)?;
        Ok(with_observed(views::account_view(&a.state, &a.p, a.last_height + 1, &ad)))
    }

    pub fn account_txs(&self, addr: &str, limit: usize) -> Result<Value, ApiError> {
        let a = self.app.lock();
        let ad = a.p.parse_addr(addr).map_err(ApiError::bad)?;
        let v = a.store.scan(T::AddrIndex, &ad, limit, true).map_err(ApiError::internal)?;
        let ids: Vec<Value> = v.iter().map(|(k, id)| json!({"txid": hex::encode(id), "height": u64::from_be_bytes(k[20..28].try_into().unwrap())})).collect();
        Ok(with_observed(json!({"address": addr, "transactions": ids, "source": "rebuildable explorer index"})))
    }

    pub fn mempool(&self) -> Value {
        let a = self.app.lock();
        with_observed(json!({"count": a.pending_ids.len(), "txs": a.pending_ids.iter().take(100).map(|(id, t)| json!({"id": hex::encode(id), "added_ms": t})).collect::<Vec<_>>(),
            "note": "CometBFT owns the mempool (size limits in its config.toml); this lists transactions this node admitted via CheckTx"}))
    }

    pub async fn consensus(&self) -> Value {
        let st = self.rpc("/status").await.ok();
        let cs = self.rpc("/consensus_state").await.ok();
        let (h, total, lc) = {
            let a = self.app.lock();
            let total: u64 = a.state.overlay().valset().0.iter().map(|x| x.1).sum();
            (a.last_height, total, a.last_commit.clone())
        };
        let epoch = if self.p.profile == Profile::Pos {
            let e = self.p.pos().epoch_length;
            json!({"length": e, "next": (h / e + 1) * e})
        } else {
            Value::Null
        };
        with_observed(json!({
            "profile": self.p.profile.as_str(), "engine": "cometbft",
            "cometbft_version": st.as_ref().and_then(|s| s["node_info"]["version"].as_str()).unwrap_or("unreachable"),
            "height": st.as_ref().and_then(|s| s["sync_info"]["latest_block_height"].as_str()).and_then(|x| x.parse::<u64>().ok()),
            "app_height": h,
            "round_state": cs.as_ref().and_then(|c| c["round_state"]["height/round/step"].as_str()),
            "latest_block_hash": st.as_ref().and_then(|s| s["sync_info"]["latest_block_hash"].as_str()),
            "latest_app_hash": st.as_ref().and_then(|s| s["sync_info"]["latest_app_hash"].as_str()),
            "catching_up": st.as_ref().and_then(|s| s["sync_info"]["catching_up"].as_bool()),
            "total_power": total,
            "last_commit": {"height": lc.height, "signed_power": lc.signed_power, "total_power": lc.total_power, "signers": lc.signers.len(), "validators": lc.validators},
            "quorum": "> 2/3 of voting power must precommit for a block to be committed",
            "fault_assumption": "safety: < 1/3 Byzantine voting power; liveness: > 2/3 voting power online, partial synchrony",
            "finality": "deterministic-bft",
            "epoch": epoch,
            "validator_update_delay": "updates returned at height H take effect at H+2",
        }))
    }

    pub fn validators(&self) -> Value {
        let a = self.app.lock();
        let signers = a.last_commit.signers.clone();
        with_observed(views::validators_view(&a.state, &a.p, a.last_height + 1, Some(&signers)))
    }

    pub async fn peers(&self) -> Value {
        match self.rpc("/net_info").await {
            Ok(n) => {
                let v: Vec<Value> = n["peers"].as_array().cloned().unwrap_or_default().iter().map(|p| json!({
                    "id": p["node_info"]["id"], "address": p["remote_ip"], "direction": if p["is_outbound"].as_bool().unwrap_or(false) { "outbound" } else { "inbound" },
                    "moniker": p["node_info"]["moniker"], "connected_since_ms": Value::Null, "protocol_version": p["node_info"]["protocol_version"]["p2p"],
                })).collect();
                with_observed(json!({"peers": v, "engine": "cometbft", "note": "peer identities are CometBFT node keys (authenticated, encrypted SecretConnection)"}))
            }
            Err(e) => with_observed(json!({"peers": [], "error": e.to_string()})),
        }
    }

    pub async fn sync(&self) -> Value {
        let st = self.rpc("/status").await.ok();
        let b = self.cfg.bft.as_ref().unwrap();
        let anchor = match (&b.trust_height, &b.trust_hash) {
            (Some(h), Some(x)) => json!({"kind": "trusted-height", "height": h, "hash": x, "period": b.trust_period, "note": "operator-supplied recent checkpoint (weak subjectivity)"}),
            _ => json!({"kind": "genesis", "height": 0, "hash": hex::encode(self.p.hash), "note": "blocksync from genesis: commits verified from the genesis validator set. A recent trusted checkpoint is required to rule out long-range attacks by unbonded keys."}),
        };
        let lh = self.app.lock().last_height;
        let best = st.as_ref().and_then(|s| s["sync_info"]["latest_block_height"].as_str()).and_then(|x| x.parse::<u64>().ok()).unwrap_or(lh);
        with_observed(json!({"syncing": st.as_ref().and_then(|s| s["sync_info"]["catching_up"].as_bool()).unwrap_or(false),
            "local_height": lh, "best_known_height": best, "progress": if best == 0 { 1.0 } else { lh as f64 / best as f64 },
            "trust_anchor": anchor, "validation": "CometBFT verifies commits/signatures; this application re-executes every transaction and checks app hashes",
            "errors": []}))
    }

    pub fn snapshot(&self) -> Result<Value> {
        let a = self.app.lock();
        let id: Hash32 = a.store.meta("tip_id")?.and_then(|v| v.try_into().ok()).unwrap_or([0; 32]);
        let hdr = aureom_core::snapshot::SnapshotHeader { chain_id: a.p.doc.chain_id.clone(), genesis_hash: a.p.hash, height: a.last_height, block_id: id, state_root: a.state.root(), entries: a.state.len() as u64 };
        let data = aureom_core::snapshot::write(&hdr, &a.state);
        crate::pow_node::write_snapshot_file(&self.cfg.snapshot_dir, &self.cfg.node_name, a.last_height, &hdr.state_root, &data, &id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use aureom_core::codec::Encode;
    use aureom_core::crypto::test_keypair;
    use aureom_core::genesis::tests::dev_genesis;

    fn app(profile: &str) -> (App, tempdir::Dir) {
        let d = tempdir::Dir::new();
        let p = Arc::new(ChainParams::from_value(&dev_genesis(profile)).unwrap());
        let cfg: NodeConfig = serde_json::from_value(json!({
            "node_name": "t", "profile": profile, "genesis_path": "g.json", "expected_genesis_hash": hex::encode(p.hash),
            "data_dir": d.0.to_str().unwrap(), "api_listen": "127.0.0.1:0", "admin_listen": "127.0.0.1:0", "admin_token_path": "x"
        })).unwrap();
        let mut a = App::open(p.clone(), &cfg).unwrap();
        let g = serde_json::to_vec(&dev_genesis(profile)).unwrap();
        let vals = p.genesis_state().overlay().valset().0.iter().map(|(k, pw)| pb::ValidatorUpdate { pub_key: Some(PublicKey { sum: Some(Sum::Ed25519(k.to_vec())) }), power: *pw as i64 }).collect();
        let r = a.handle(Req::InitChain(pb::RequestInitChain { chain_id: p.doc.chain_id.clone(), app_state_bytes: g.into(), validators: vals, initial_height: 1, ..Default::default() }));
        assert!(matches!(r, Resp::InitChain(_)), "{r:?}");
        (a, d)
    }

    fn transfer(p: &ChainParams, nonce: u64) -> Vec<u8> {
        let kp = test_keypair("alice");
        UnsignedTx { version: 1, chain_id: p.doc.chain_id.clone(), nonce, fee: 5000, expiry_height: 0, sender_pubkey: kp.public(),
            action: Action::Transfer { to: test_keypair("bob").address(), amount: 1 }, memo: vec![] }.sign(&kp).encode()
    }

    fn process(a: &mut App, txs: Vec<Vec<u8>>) -> i32 {
        match a.handle(Req::ProcessProposal(pb::RequestProcessProposal { txs: txs.into_iter().map(Into::into).collect(), height: 1, ..Default::default() })) {
            Resp::ProcessProposal(r) => r.status,
            r => panic!("{r:?}"),
        }
    }

    #[test]
    fn process_proposal_rejects_malformed_and_invalid_blocks() {
        let (mut a, _d) = app("pos");
        let p = a.p.clone();
        assert_eq!(process(&mut a, vec![transfer(&p, 0)]), 1, "valid proposal accepted");
        assert_eq!(process(&mut a, vec![b"garbage".to_vec()]), 2, "malformed tx bytes");
        let mut bad_sig = transfer(&p, 0);
        let n = bad_sig.len();
        bad_sig[n - 1] ^= 1;
        assert_eq!(process(&mut a, vec![bad_sig]), 2, "bad signature");
        assert_eq!(process(&mut a, vec![transfer(&p, 0), transfer(&p, 0)]), 2, "replay inside a block");
        assert_eq!(process(&mut a, vec![transfer(&p, 5)]), 2, "nonce gap");
        assert_eq!(process(&mut a, vec![vec![0u8; 70_000]]), 2, "oversized tx");
    }

    #[test]
    fn init_chain_rejects_mismatched_genesis() {
        let d = tempdir::Dir::new();
        let p = Arc::new(ChainParams::from_value(&dev_genesis("poa")).unwrap());
        let cfg: NodeConfig = serde_json::from_value(json!({
            "node_name": "t", "profile": "poa", "genesis_path": "g.json", "expected_genesis_hash": hex::encode(p.hash),
            "data_dir": d.0.to_str().unwrap(), "api_listen": "127.0.0.1:0", "admin_listen": "127.0.0.1:0", "admin_token_path": "x"
        })).unwrap();
        let mut a = App::open(p.clone(), &cfg).unwrap();
        let mut other = dev_genesis("poa");
        other["network_name"] = "tampered".into();
        let r = a.handle(Req::InitChain(pb::RequestInitChain { chain_id: p.doc.chain_id.clone(), app_state_bytes: serde_json::to_vec(&other).unwrap().into(), initial_height: 1, ..Default::default() }));
        assert!(matches!(r, Resp::Exception(_)));
    }

    #[test]
    fn finalize_commit_persists_and_recovers() {
        let (mut a, d) = app("poa");
        let p = a.p.clone();
        let r = a.handle(Req::FinalizeBlock(pb::RequestFinalizeBlock { txs: vec![transfer(&p, 0).into()], height: 1, hash: vec![7u8; 32].into(), ..Default::default() }));
        let Resp::FinalizeBlock(f) = r else { panic!() };
        assert_eq!(f.tx_results[0].code, CODE_OK);
        let _ = a.handle(Req::Commit(pb::RequestCommit {}));
        let root = a.state.root();
        assert_eq!(f.app_hash.as_ref(), &root[..]);
        drop(a);
        let cfg: NodeConfig = serde_json::from_value(json!({
            "node_name": "t", "profile": "poa", "genesis_path": "g.json", "expected_genesis_hash": hex::encode(p.hash),
            "data_dir": d.0.to_str().unwrap(), "api_listen": "127.0.0.1:0", "admin_listen": "127.0.0.1:0", "admin_token_path": "x"
        })).unwrap();
        let b = App::open(p.clone(), &cfg).unwrap();
        assert_eq!(b.last_height, 1);
        assert_eq!(b.state.root(), root);
    }

    mod tempdir {
        pub struct Dir(pub std::path::PathBuf);
        impl Dir {
            pub fn new() -> Self {
                let p = std::env::temp_dir().join(format!("aureom-test-{}-{}", std::process::id(), std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
                std::fs::create_dir_all(&p).unwrap();
                Dir(p)
            }
        }
        impl Drop for Dir {
            fn drop(&mut self) {
                let _ = std::fs::remove_dir_all(&self.0);
            }
        }
    }
}
