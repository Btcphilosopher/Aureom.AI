//! PoW node runtime: peers, synchronisation, propagation, mining, API views.

use crate::api::ApiError;
use crate::config::NodeConfig;
use crate::mempool::{Mempool, Reject};
use crate::p2p::{self, Bucket, Msg};
use crate::pow_chain::{Accepted, Chain};
use crate::store::{Store, T};
use crate::views::{self, now_ms, with_observed};
use anyhow::{bail, Context, Result};
use aureom_core::codec::{Decode, Encode};
use aureom_core::crypto::{verify, Hash32, Keypair};
use aureom_core::exec;
use aureom_core::genesis::ChainParams;
use aureom_core::pow::{self, Block};
use aureom_core::U256;
use parking_lot::Mutex;
use rand_core::RngCore;
use serde_json::{json, Value};
use std::collections::{HashMap, VecDeque};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::mpsc;

pub struct PeerInfo {
    pub id: String,
    pub addr: String,
    pub listen_addr: Option<String>,
    pub direction: &'static str,
    pub tx: mpsc::Sender<Msg>,
    pub best_height: u64,
    pub best_work: U256,
    pub score: i32,
    pub connected_since: u64,
    pub protocol_version: u16,
}

pub struct PowNode {
    pub cfg: NodeConfig,
    pub p: Arc<ChainParams>,
    pub chain: Mutex<Chain>,
    pub key: Keypair,
    pub peers: Mutex<HashMap<u64, PeerInfo>>,
    pub bans: Mutex<HashMap<String, u64>>,
    pub manual: Mutex<Vec<String>>,
    pub discovered: Mutex<Vec<String>>,
    pub mining_enabled: AtomicBool,
    pub hashes: AtomicU64,
    pub shutdown: AtomicBool,
    pub shutdown_notify: tokio::sync::Notify,
    next_conn: AtomicU64,
    pub sync_errors: Mutex<VecDeque<String>>,
    pub recent_block_times: Mutex<VecDeque<u64>>,
    pub started_ms: u64,
}

const MAX_FRAME_EXTRA: usize = 65_536;
const BAN_MS: u64 = 10 * 60 * 1000;

fn load_node_key(path: &std::path::Path) -> Result<Keypair> {
    let s = std::fs::read_to_string(path).with_context(|| format!("read node key {}", path.display()))?;
    let v: Value = serde_json::from_str(&s)?;
    let seed = hex::decode(v["seed"].as_str().context("seed")?)?;
    let seed: [u8; 32] = seed.try_into().map_err(|_| anyhow::anyhow!("node key seed must be 32 bytes"))?;
    Ok(Keypair::from_seed(&seed))
}

impl PowNode {
    pub fn open(cfg: NodeConfig, p: Arc<ChainParams>) -> Result<Arc<PowNode>> {
        let pc = cfg.pow.clone().context("pow section missing in node config")?;
        let store = Store::open(&cfg.data_dir)?;
        let checkpoint = match &pc.checkpoint {
            Some(c) => Some((c.height, hex::decode(&c.block_id)?.try_into().map_err(|_| anyhow::anyhow!("checkpoint id"))?)),
            None => None,
        };
        let chain = Chain::open(p.clone(), store, Mempool::new(cfg.mempool.clone()), cfg.pruning.keep_undo_blocks, checkpoint)?;
        let key = load_node_key(&pc.node_key_path)?;
        if pc.mining.enabled {
            p.parse_addr(&pc.mining.miner_address).map_err(|e| anyhow::anyhow!("miner_address: {e}"))?;
        }
        Ok(Arc::new(PowNode {
            mining_enabled: AtomicBool::new(pc.mining.enabled),
            cfg,
            p,
            chain: Mutex::new(chain),
            key,
            peers: Mutex::new(HashMap::new()),
            bans: Mutex::new(HashMap::new()),
            manual: Mutex::new(vec![]),
            discovered: Mutex::new(vec![]),
            hashes: AtomicU64::new(0),
            shutdown: AtomicBool::new(false),
            shutdown_notify: tokio::sync::Notify::new(),
            next_conn: AtomicU64::new(1),
            sync_errors: Mutex::new(VecDeque::new()),
            recent_block_times: Mutex::new(VecDeque::new()),
            started_ms: now_ms(),
        }))
    }

    fn pc(&self) -> &crate::config::PowConfig {
        self.cfg.pow.as_ref().unwrap()
    }
    pub fn peer_id(&self) -> String {
        hex::encode(self.key.public())
    }
    fn max_frame(&self) -> usize {
        self.p.doc.limits.max_block_bytes as usize + MAX_FRAME_EXTRA
    }
    fn note_error(&self, e: String) {
        let mut q = self.sync_errors.lock();
        q.push_back(format!("{} {}", now_ms(), e));
        if q.len() > 50 {
            q.pop_front();
        }
    }

    pub async fn run(self: Arc<Self>) -> Result<()> {
        let listen = self.pc().p2p_listen.clone();
        let listener = TcpListener::bind(&listen).await.with_context(|| format!("bind p2p {listen}"))?;
        tracing::info!("p2p listening on {listen} as peer {}", &self.peer_id()[..16]);
        let me = self.clone();
        tokio::spawn(async move {
            loop {
                match listener.accept().await {
                    Ok((s, addr)) => {
                        let n = me.clone();
                        tokio::spawn(async move {
                            if let Err(e) = n.clone().handle_conn(s, "inbound", addr.to_string(), None).await {
                                tracing::debug!("inbound {addr}: {e}");
                            }
                        });
                    }
                    Err(e) => tracing::warn!("accept: {e}"),
                }
            }
        });
        let me = self.clone();
        tokio::spawn(async move { me.dialer().await });
        let me = self.clone();
        tokio::spawn(async move { me.heartbeat().await });
        let me = self.clone();
        std::thread::spawn(move || me.miner());
        Ok(())
    }

    fn is_banned(&self, key: &str) -> bool {
        let mut b = self.bans.lock();
        let now = now_ms();
        b.retain(|_, until| *until > now);
        b.contains_key(key)
    }

    async fn dialer(self: Arc<Self>) {
        loop {
            if self.shutdown.load(Ordering::Relaxed) {
                return;
            }
            let mut targets: Vec<String> = self.pc().bootstrap_peers.clone();
            targets.extend(self.manual.lock().iter().cloned());
            if self.pc().discovery {
                targets.extend(self.discovered.lock().iter().cloned());
            }
            targets.sort();
            targets.dedup();
            let (connected, count): (Vec<String>, usize) = {
                let p = self.peers.lock();
                (p.values().flat_map(|x| [Some(x.addr.clone()), x.listen_addr.clone()]).flatten().collect(), p.len())
            };
            for t in targets {
                if count >= self.pc().max_peers || connected.contains(&t) || self.is_banned(&t) || t == self.pc().p2p_listen {
                    continue;
                }
                let me = self.clone();
                tokio::spawn(async move {
                    match tokio::time::timeout(std::time::Duration::from_secs(3), TcpStream::connect(&t)).await {
                        Ok(Ok(s)) => {
                            if let Err(e) = me.clone().handle_conn(s, "outbound", t.clone(), Some(t.clone())).await {
                                tracing::debug!("outbound {t}: {e}");
                            }
                        }
                        _ => {}
                    }
                });
            }
            tokio::time::sleep(std::time::Duration::from_millis(2000)).await;
        }
    }

    async fn heartbeat(self: Arc<Self>) {
        loop {
            tokio::time::sleep(std::time::Duration::from_secs(4)).await;
            let tip = self.tip_msg();
            let peers: Vec<mpsc::Sender<Msg>> = self.peers.lock().values().map(|p| p.tx.clone()).collect();
            for t in peers {
                let _ = t.try_send(tip.clone());
                let _ = t.try_send(Msg::Ping(now_ms()));
            }
        }
    }

    fn tip_msg(&self) -> Msg {
        let c = self.chain.lock();
        let m = c.tip_meta();
        Msg::Tip { height: m.height, work: m.cumwork.to_big_endian(), id: c.tip() }
    }

    fn hello(&self, challenge: [u8; 32]) -> Msg {
        let c = self.chain.lock();
        let m = c.tip_meta();
        let port = self.pc().p2p_listen.rsplit(':').next().and_then(|x| x.parse().ok()).unwrap_or(0);
        Msg::Hello {
            protocol_min: p2p::P2P_PROTOCOL_MIN,
            protocol_max: p2p::P2P_PROTOCOL_MAX,
            chain_id: self.p.doc.chain_id.clone(),
            genesis_hash: self.p.hash,
            node_pubkey: self.key.public(),
            challenge,
            best_height: m.height,
            best_work: m.cumwork.to_big_endian(),
            listen_port: port,
            software: format!("aureom-node/{}", aureom_core::NODE_SOFTWARE_VERSION),
        }
    }

    async fn handle_conn(self: Arc<Self>, s: TcpStream, direction: &'static str, addr: String, dial: Option<String>) -> Result<()> {
        if self.is_banned(&addr) {
            bail!("banned address");
        }
        s.set_nodelay(true)?;
        let (mut rd, mut wr) = s.into_split();
        let max = self.max_frame();
        let mut challenge = [0u8; 32];
        rand_core::OsRng.fill_bytes(&mut challenge);
        write_frame(&mut wr, &p2p::encode(&self.hello(challenge))).await?;
        let to = std::time::Duration::from_secs(10);
        let their = p2p::decode(&tokio::time::timeout(to, read_frame(&mut rd, 4096)).await??, max)?;
        let Msg::Hello { protocol_min, protocol_max, chain_id, genesis_hash, node_pubkey, challenge: their_ch, best_height, best_work, listen_port, .. } = their else {
            bail!("expected hello");
        };
        if chain_id != self.p.doc.chain_id || genesis_hash != self.p.hash {
            let _ = write_frame(&mut wr, &p2p::encode(&Msg::Disconnect("wrong chain or genesis".into()))).await;
            bail!("peer on different chain {chain_id} / {}", hex::encode(&genesis_hash[..6]));
        }
        let ver = protocol_max.min(p2p::P2P_PROTOCOL_MAX);
        if ver < protocol_min.max(p2p::P2P_PROTOCOL_MIN) {
            let _ = write_frame(&mut wr, &p2p::encode(&Msg::Disconnect("no common protocol version".into()))).await;
            bail!("incompatible protocol versions {protocol_min}..{protocol_max}");
        }
        if node_pubkey == self.key.public() {
            bail!("self connection");
        }
        let pid = hex::encode(node_pubkey);
        if self.is_banned(&pid) {
            bail!("banned peer id");
        }
        if !self.pc().allowed_peers.is_empty() && !self.pc().allowed_peers.contains(&pid) {
            bail!("peer not in allowlist");
        }
        let sig = self.key.sign(&p2p::handshake_message(&self.p.doc.chain_id, &self.p.hash, &their_ch, &self.key.public(), &node_pubkey));
        write_frame(&mut wr, &p2p::encode(&Msg::HelloAck { signature: sig })).await?;
        let ack = p2p::decode(&tokio::time::timeout(to, read_frame(&mut rd, 4096)).await??, max)?;
        let Msg::HelloAck { signature } = ack else { bail!("expected hello_ack") };
        if !verify(&node_pubkey, &p2p::handshake_message(&self.p.doc.chain_id, &self.p.hash, &challenge, &node_pubkey, &self.key.public()), &signature) {
            bail!("peer failed authentication");
        }
        let ip = addr.rsplit_once(':').map(|x| x.0.to_string()).unwrap_or_default();
        let listen_addr = if dial.is_some() { dial.clone() } else if listen_port > 0 { Some(format!("{ip}:{listen_port}")) } else { None };
        if let Some(la) = &listen_addr {
            if self.is_banned(la) {
                bail!("banned listen address");
            }
        }
        let (tx, mut rx) = mpsc::channel::<Msg>(256);
        let conn = self.next_conn.fetch_add(1, Ordering::Relaxed);
        {
            let mut peers = self.peers.lock();
            if peers.values().any(|p| p.id == pid) {
                bail!("duplicate connection to peer");
            }
            if peers.len() >= self.pc().max_peers {
                bail!("connection limit reached");
            }
            peers.insert(conn, PeerInfo {
                id: pid.clone(),
                addr: addr.clone(),
                listen_addr,
                direction,
                tx: tx.clone(),
                best_height,
                best_work: U256::from_big_endian(&best_work),
                score: 0,
                connected_since: now_ms(),
                protocol_version: ver,
            });
        }
        tracing::info!("peer connected {direction} {addr} id={}", &pid[..12]);
        let delay = crate::faults::p2p_delay_ms();
        let writer = tokio::spawn(async move {
            while let Some(m) = rx.recv().await {
                if delay > 0 {
                    tokio::time::sleep(std::time::Duration::from_millis(delay)).await;
                }
                let disconnect = matches!(m, Msg::Disconnect(_));
                if write_frame(&mut wr, &p2p::encode(&m)).await.is_err() || disconnect {
                    break;
                }
            }
        });
        // initial sync request
        if U256::from_big_endian(&best_work) > self.chain.lock().tip_meta().cumwork {
            let loc = self.chain.lock().locator();
            let _ = tx.try_send(Msg::GetBlocks { locator: loc, max: 64 });
        }
        let now = now_ms();
        let mut msgs = Bucket::new(400.0, 200.0, now);
        let mut bytes = Bucket::new((8 * max) as f64, (4 * max) as f64, now);
        let res: Result<()> = async {
            loop {
                let frame = tokio::select! {
                    f = read_frame(&mut rd, max) => f?,
                    _ = self.shutdown_notify.notified() => return Ok(()),
                };
                let now = now_ms();
                if !msgs.take(1.0, now) || !bytes.take(frame.len() as f64, now) {
                    if self.penalise(conn, 10, "rate limit exceeded") {
                        return Ok(());
                    }
                    continue;
                }
                let msg = match p2p::decode(&frame, max) {
                    Ok(m) => m,
                    Err(e) => {
                        if self.penalise(conn, 50, &format!("malformed message: {e}")) {
                            return Ok(());
                        }
                        continue;
                    }
                };
                if let Msg::Disconnect(r) = &msg {
                    tracing::info!("peer {addr} disconnected: {r}");
                    return Ok(());
                }
                if !self.peers.lock().contains_key(&conn) {
                    return Ok(());
                }
                self.on_message(conn, &tx, msg);
            }
        }
        .await;
        self.peers.lock().remove(&conn);
        writer.abort();
        tracing::info!("peer gone {addr}");
        res
    }

    /// Returns true if the peer was banned/disconnected.
    fn penalise(&self, conn: u64, pts: i32, why: &str) -> bool {
        let mut peers = self.peers.lock();
        let Some(p) = peers.get_mut(&conn) else { return true };
        p.score -= pts;
        tracing::warn!("peer {} score {} ({why})", p.addr, p.score);
        if p.score <= -100 {
            let until = now_ms() + BAN_MS;
            let mut bans = self.bans.lock();
            bans.insert(p.id.clone(), until);
            bans.insert(p.addr.clone(), until);
            if let Some(l) = &p.listen_addr {
                bans.insert(l.clone(), until);
            }
            let _ = p.tx.try_send(Msg::Disconnect(format!("banned: {why}")));
            peers.remove(&conn);
            drop(bans);
            drop(peers);
            self.note_error(format!("banned peer: {why}"));
            return true;
        }
        false
    }

    fn broadcast(&self, except: Option<u64>, m: Msg) {
        let peers = self.peers.lock();
        for (c, p) in peers.iter() {
            if Some(*c) != except {
                let _ = p.tx.try_send(m.clone()); // full queue: drop (backpressure)
            }
        }
    }

    fn on_message(&self, conn: u64, tx: &mpsc::Sender<Msg>, msg: Msg) {
        match msg {
            Msg::Ping(n) => {
                let _ = tx.try_send(Msg::Pong(n));
            }
            Msg::Pong(_) => {}
            Msg::Tip { height, work, .. } => {
                let w = U256::from_big_endian(&work);
                if let Some(p) = self.peers.lock().get_mut(&conn) {
                    p.best_height = height;
                    p.best_work = w;
                }
                let c = self.chain.lock();
                if w > c.tip_meta().cumwork {
                    let _ = tx.try_send(Msg::GetBlocks { locator: c.locator(), max: 64 });
                }
            }
            Msg::Tx(b) => match self.submit_tx_bytes(&b, Some(conn)) {
                Ok(_) => {}
                Err(e) => {
                    if !matches!(e.code(), "duplicate" | "bad_nonce" | "conflicting_nonce" | "mempool_full" | "sender_limit" | "nonce_gap_too_large" | "insufficient_fee_balance" | "expired") {
                        self.penalise(conn, 5, &format!("invalid tx: {}", e.message()));
                    }
                }
            },
            Msg::Block(b) => self.on_block_bytes(conn, tx, &b),
            Msg::GetBlocks { locator, max } => {
                let blocks = self.chain.lock().blocks_after(&locator, (max as usize).min(64), self.max_frame() - MAX_FRAME_EXTRA);
                if tx.try_send(Msg::Blocks(blocks)).is_err() {
                    self.penalise(conn, 100, "not reading responses (backpressure)");
                }
            }
            Msg::Blocks(v) => {
                if v.is_empty() {
                    return;
                }
                // header pre-validation of the whole batch before executing any body
                let mut decoded = vec![];
                for b in &v {
                    match Block::decode(b) {
                        Ok(x) => decoded.push(x),
                        Err(e) => {
                            self.penalise(conn, 100, &format!("malformed block in batch: {e}"));
                            return;
                        }
                    }
                }
                for w in decoded.windows(2) {
                    if w[1].header.prev_id != w[0].header.id() {
                        self.penalise(conn, 100, "unlinked block batch");
                        return;
                    }
                }
                if decoded.iter().any(|b| !b.header.meets_target()) {
                    self.penalise(conn, 100, "block batch contains insufficient proof of work");
                    return;
                }
                for b in decoded {
                    if !self.accept_and_relay(b, Some(conn)) {
                        return;
                    }
                }
                let (behind, loc) = {
                    let c = self.chain.lock();
                    let pw = self.peers.lock().get(&conn).map(|p| p.best_work).unwrap_or_default();
                    (pw > c.tip_meta().cumwork, c.locator())
                };
                if behind {
                    let _ = tx.try_send(Msg::GetBlocks { locator: loc, max: 64 });
                }
            }
            Msg::GetPeers => {
                let addrs: Vec<String> = self.peers.lock().values().filter_map(|p| p.listen_addr.clone()).take(32).collect();
                let _ = tx.try_send(Msg::Peers(addrs));
            }
            Msg::Peers(v) => {
                if self.pc().discovery {
                    let mut d = self.discovered.lock();
                    for a in v.into_iter().take(32) {
                        if !d.contains(&a) && d.len() < 256 {
                            d.push(a);
                        }
                    }
                }
            }
            Msg::Hello { .. } | Msg::HelloAck { .. } => {
                self.penalise(conn, 20, "unexpected handshake message");
            }
            Msg::Disconnect(_) => {}
        }
    }

    fn on_block_bytes(&self, conn: u64, tx: &mpsc::Sender<Msg>, b: &[u8]) {
        let blk = match Block::decode(b) {
            Ok(x) => x,
            Err(e) => {
                self.penalise(conn, 100, &format!("malformed block: {e}"));
                return;
            }
        };
        let id = blk.header.id();
        let orphan = !self.chain.lock().index.contains_key(&blk.header.prev_id);
        self.accept_and_relay(blk, Some(conn));
        if orphan {
            let loc = self.chain.lock().locator();
            let _ = tx.try_send(Msg::GetBlocks { locator: loc, max: 64 });
            tracing::debug!("orphan {} -> requesting ancestors", hex::encode(&id[..6]));
        }
    }

    /// Accept a block into the chain; relay if it changed our tip. Returns false on a
    /// misbehaviour rejection.
    pub fn accept_and_relay(&self, blk: Block, from: Option<u64>) -> bool {
        let bytes = blk.encode();
        let ts = blk.header.timestamp_ms;
        let res = self.chain.lock().accept_block(blk, now_ms());
        match res {
            Ok(Accepted::Extended) | Ok(Accepted::Reorg { .. }) => {
                {
                    let mut q = self.recent_block_times.lock();
                    q.push_back(ts);
                    if q.len() > 30 {
                        q.pop_front();
                    }
                }
                self.broadcast(from, Msg::Block(bytes));
                true
            }
            Ok(_) => true,
            Err(e) => {
                self.note_error(format!("block rejected: {e}"));
                if e.is_misbehaviour() {
                    if let Some(c) = from {
                        self.penalise(c, 100, &e.to_string());
                    }
                    false
                } else {
                    true
                }
            }
        }
    }

    pub fn submit_tx_bytes(&self, b: &[u8], from: Option<u64>) -> Result<Hash32, Reject> {
        let tx = exec::decode_tx(&self.p, b).map_err(Reject::Invalid)?;
        let id = tx.txid();
        let res = {
            let mut c = self.chain.lock();
            let h = c.height() + 1;
            let Chain { mempool, state, p, .. } = &mut *c;
            mempool.add(p, state, h, tx, b.len(), now_ms())
        };
        match res {
            Ok(id) => {
                self.broadcast(from, Msg::Tx(b.to_vec()));
                Ok(id)
            }
            Err(e) => {
                if from.is_none() && !matches!(e, Reject::Duplicate) {
                    self.chain.lock().mempool.record(id, "rejected", Some(e.message()));
                }
                Err(e)
            }
        }
    }

    fn miner(self: Arc<Self>) {
        let addr = match self.p.parse_addr(&self.pc().mining.miner_address) {
            Ok(a) => a,
            Err(_) => {
                if self.mining_enabled.load(Ordering::Relaxed) {
                    tracing::error!("mining disabled: invalid miner address");
                }
                self.mining_enabled.store(false, Ordering::Relaxed);
                [0; 20]
            }
        };
        let limit = self.pc().mining.max_hashes_per_sec;
        let mut rng_nonce = [0u8; 8];
        loop {
            if self.shutdown.load(Ordering::Relaxed) {
                return;
            }
            if !self.mining_enabled.load(Ordering::Relaxed) || addr == [0; 20] {
                std::thread::sleep(std::time::Duration::from_millis(250));
                continue;
            }
            let (tmpl, seq) = {
                let c = self.chain.lock();
                if c.halted.is_some() {
                    drop(c);
                    std::thread::sleep(std::time::Duration::from_secs(1));
                    continue;
                }
                (c.template(addr, now_ms()), c.tip_changed_seq)
            };
            let mut h = tmpl.header.clone();
            rand_core::OsRng.fill_bytes(&mut rng_nonce);
            h.nonce = u64::from_be_bytes(rng_nonce);
            let start = std::time::Instant::now();
            let mut done = 0u64;
            let mut found = false;
            while start.elapsed().as_millis() < 2000 {
                let batch = 2000;
                if pow::mine(&mut h, batch) {
                    found = true;
                    break;
                }
                done += batch;
                self.hashes.fetch_add(batch, Ordering::Relaxed);
                if limit > 0 {
                    let should = done as f64 / limit as f64;
                    let el = start.elapsed().as_secs_f64();
                    if should > el {
                        std::thread::sleep(std::time::Duration::from_secs_f64(should - el));
                    }
                }
                if self.chain.lock().tip_changed_seq != seq || !self.mining_enabled.load(Ordering::Relaxed) {
                    break;
                }
            }
            if found {
                let blk = Block { header: h, txs: tmpl.txs };
                tracing::info!("mined block {} at height {}", hex::encode(&blk.header.id()[..6]), blk.header.height);
                self.accept_and_relay(blk, None);
            }
        }
    }

    // ------------------------------------------------------------------ API

    pub fn network(&self) -> Value {
        let g = &self.p.doc;
        with_observed(json!({
            "network_name": g.network_name, "chain_id": g.chain_id, "profile": "pow",
            "backend": "aureom-nakamoto", "backend_version": aureom_core::NODE_SOFTWARE_VERSION,
            "protocol_version": aureom_core::types::PROTOCOL_VERSION, "node_version": aureom_core::NODE_SOFTWARE_VERSION,
            "genesis_hash": hex::encode(self.p.hash), "node_name": self.cfg.node_name, "peer_id": self.peer_id(),
            "native_asset": g.native_asset, "monetary_policy": g.monetary_policy, "fee_policy": g.fee_policy, "limits": g.limits,
            "treasuries": (0..g.treasuries.len()).map(|i| json!({"label": g.treasuries[i].label, "address": self.p.addr(&self.p.treasury_addrs[i])})).collect::<Vec<_>>(),
            "finality": "probabilistic", "confirmations_recommended": self.p.pow().confirmations_recommended,
            "fault_assumption": "Nakamoto consensus: settlement is probabilistic. Any party controlling more hash power than the honest miners can rewrite history; a small development network provides no such resistance.",
        }))
    }

    pub fn health(&self) -> Value {
        let c = self.chain.lock();
        let peers = self.peers.lock().len();
        let tip = c.tip_meta();
        let now = now_ms();
        let age = now.saturating_sub(tip.timestamp_ms);
        let best_peer = self.peers.lock().values().map(|p| p.best_height).max().unwrap_or(0);
        let syncing = best_peer > tip.height + 1;
        let mut alerts = vec![];
        if peers == 0 {
            alerts.push(json!({"level": "warning", "code": "no_peers", "message": "node has no connected peers"}));
        }
        if age > self.p.pow().target_block_time_ms * 20 && c.height() > 0 {
            alerts.push(json!({"level": "warning", "code": "stale_tip", "message": format!("tip is {} s old", age / 1000)}));
        }
        if let Some(h) = &c.halted {
            alerts.push(json!({"level": "critical", "code": "halted", "message": h}));
        }
        if let Some(r) = c.reorgs.back() {
            if now - r.at_ms < 60_000 {
                alerts.push(json!({"level": "warning", "code": "recent_reorg", "message": format!("reorganisation depth {} at height {}", r.depth, r.fork_height)}));
            }
        }
        for f in crate::faults::any_enabled() {
            alerts.push(json!({"level": "warning", "code": "fault_injection_active", "message": f}));
        }
        let status = if c.halted.is_some() { "halted" } else if alerts.is_empty() { "ok" } else { "degraded" };
        with_observed(json!({
            "status": status, "height": tip.height, "tip_id": hex::encode(c.tip()), "tip_time_ms": tip.timestamp_ms, "tip_age_ms": age,
            "peers": peers, "syncing": syncing, "mempool_txs": c.mempool.len(),
            "storage": {"db_path": c.store.path.display().to_string(), "db_bytes": c.store.db_bytes(), "db_version": crate::store::DB_VERSION,
                "state_entries": c.state.len(), "pruning": {"keep_undo_blocks": self.cfg.pruning.keep_undo_blocks, "keep_blocks": 0, "note": "PoW prunes undo logs only"}},
            "alerts": alerts, "uptime_ms": now - self.started_ms,
        }))
    }

    pub fn block(&self, ident: &str) -> Result<Value, ApiError> {
        let c = self.chain.lock();
        let id: Hash32 = if ident == "latest" {
            c.tip()
        } else if let Ok(h) = ident.parse::<u64>() {
            *c.main.get(h as usize).ok_or(ApiError::not_found("no block at that height"))?
        } else {
            hex::decode(ident).ok().and_then(|b| b.try_into().ok()).ok_or(ApiError::bad("block identifier must be latest|height|hex id"))?
        };
        let v = c.block_json(&id).map_err(ApiError::internal)?.ok_or(ApiError::not_found("unknown block"))?;
        Ok(with_observed(v))
    }

    pub fn blocks(&self, before: Option<u64>, limit: usize) -> Value {
        let c = self.chain.lock();
        let top = before.map(|b| b.saturating_sub(1)).unwrap_or(c.height()).min(c.height());
        let v: Vec<Value> = (0..=top).rev().take(limit).filter_map(|h| c.block_summary(h)).collect();
        with_observed(json!({"blocks": v, "tip_height": c.height()}))
    }

    pub fn transaction(&self, txid: &str) -> Result<Value, ApiError> {
        let id: Hash32 = hex::decode(txid).ok().and_then(|b| b.try_into().ok()).ok_or(ApiError::bad("txid must be 64 hex chars"))?;
        let c = self.chain.lock();
        if let Some(e) = c.mempool.by_id.get(&id) {
            return Ok(with_observed(json!({"id": txid, "status": "pending", "tx": aureom_core::json::unsigned_tx_json(&self.p, &e.tx.tx),
                "note": "in this node's mempool; inclusion is not guaranteed"})));
        }
        if let Some(v) = c.store.get(T::TxIndex, &id).map_err(ApiError::internal)? {
            let (h, bid, idx) = views::decode_txindex(&v);
            let blk = c.block(&bid).map_err(ApiError::internal)?.ok_or(ApiError::internal("indexed block missing"))?;
            let rc = c.receipts(&bid).map_err(ApiError::internal)?;
            let conf = c.height() - h + 1;
            let need = self.p.pow().confirmations_recommended;
            return Ok(with_observed(json!({
                "id": txid, "status": if conf >= need { "confirmed" } else { "included" },
                "block_height": h, "block_id": hex::encode(bid), "index": idx, "confirmations": conf,
                "finality": "probabilistic", "confirmations_recommended": need,
                "tx": aureom_core::json::unsigned_tx_json(&self.p, &blk.txs[idx as usize].tx),
                "receipt": rc.get(idx as usize).map(aureom_core::json::receipt_json),
            })));
        }
        if let Some(r) = c.mempool.history.get(&id) {
            return Ok(with_observed(json!({"id": txid, "status": r.status, "reason": r.reason, "at_ms": r.at_ms})));
        }
        Ok(with_observed(json!({"id": txid, "status": "unknown", "note": "not known to this node (it may exist elsewhere)"})))
    }

    pub fn account(&self, addr: &str) -> Result<Value, ApiError> {
        let a = self.p.parse_addr(addr).map_err(ApiError::bad)?;
        let c = self.chain.lock();
        Ok(with_observed(views::account_view(&c.state, &self.p, c.height() + 1, &a)))
    }

    pub fn account_txs(&self, addr: &str, limit: usize) -> Result<Value, ApiError> {
        let a = self.p.parse_addr(addr).map_err(ApiError::bad)?;
        let c = self.chain.lock();
        let v = c.store.scan(T::AddrIndex, &a, limit, true).map_err(ApiError::internal)?;
        let ids: Vec<Value> = v.iter().map(|(k, id)| json!({"txid": hex::encode(id), "height": u64::from_be_bytes(k[20..28].try_into().unwrap())})).collect();
        Ok(with_observed(json!({"address": addr, "transactions": ids, "source": "rebuildable explorer index"})))
    }

    pub fn consensus(&self) -> Value {
        let c = self.chain.lock();
        let m = c.tip_meta();
        let times: Vec<u64> = {
            let mut v = vec![];
            let h = c.height();
            let start = h.saturating_sub(20);
            let mut prev = None;
            for i in start..=h {
                let t = c.index[&c.main[i as usize]].timestamp_ms;
                if let Some(p) = prev {
                    v.push(t.saturating_sub(p));
                }
                prev = Some(t);
            }
            v
        };
        let miner = &self.pc().mining;
        with_observed(json!({
            "profile": "pow", "engine": "aureom-nakamoto", "height": m.height, "tip": hex::encode(c.tip()),
            "cumulative_work": m.cumwork.to_string(), "target": format!("{:064x}", m.target),
            "difficulty": format!("{:.0}", pow::difficulty(m.target)),
            "target_block_time_ms": self.p.pow().target_block_time_ms, "retarget_interval": self.p.pow().retarget_interval,
            "recent_block_times_ms": times, "reorgs": c.reorgs.iter().collect::<Vec<_>>(),
            "mining": {"enabled": self.mining_enabled.load(Ordering::Relaxed), "address": miner.miner_address, "hashes": self.hashes.load(Ordering::Relaxed), "max_hashes_per_sec": miner.max_hashes_per_sec},
            "finality": "probabilistic", "confirmations_recommended": self.p.pow().confirmations_recommended,
            "halted": c.halted,
            "fault_assumption": "Probabilistic settlement under an honest-majority-of-hash-power assumption. Not resistant to a well-resourced majority-work attacker.",
        }))
    }

    pub fn peers_json(&self) -> Value {
        let peers = self.peers.lock();
        let v: Vec<Value> = peers.values().map(|p| json!({"id": p.id, "address": p.addr, "listen_address": p.listen_addr, "direction": p.direction,
            "height": p.best_height, "score": p.score, "connected_since_ms": p.connected_since, "protocol_version": p.protocol_version})).collect();
        let bans: Vec<Value> = self.bans.lock().iter().map(|(k, until)| json!({"key": k, "until_ms": until})).collect();
        with_observed(json!({"peers": v, "max_peers": self.pc().max_peers, "bans": bans, "self_id": self.peer_id(), "discovery": self.pc().discovery}))
    }

    pub fn sync(&self) -> Value {
        let c = self.chain.lock();
        let best = self.peers.lock().values().map(|p| p.best_height).max().unwrap_or(0).max(c.height());
        let anchor = match &c.checkpoint {
            Some((h, id)) => json!({"kind": "checkpoint", "height": h, "hash": hex::encode(id), "note": "operator-configured trusted checkpoint; chain must contain it"}),
            None => json!({"kind": "genesis", "height": 0, "hash": hex::encode(c.main[0]), "note": "full validation from the genesis block (hash bound to the genesis document)"}),
        };
        with_observed(json!({
            "syncing": best > c.height() + 1, "local_height": c.height(), "best_known_height": best,
            "progress": if best == 0 { 1.0 } else { c.height() as f64 / best as f64 },
            "trust_anchor": anchor, "validation": "full: proof of work, targets, timestamps, signatures, state transitions",
            "errors": self.sync_errors.lock().iter().rev().take(10).cloned().collect::<Vec<_>>(),
        }))
    }

    pub fn snapshot(&self) -> Result<Value> {
        let c = self.chain.lock();
        let h = c.height();
        let tip = c.block(&c.tip())?.unwrap();
        let hdr = aureom_core::snapshot::SnapshotHeader {
            chain_id: self.p.doc.chain_id.clone(),
            genesis_hash: self.p.hash,
            height: h,
            block_id: c.tip(),
            state_root: tip.header.state_root,
            entries: c.state.len() as u64,
        };
        let data = aureom_core::snapshot::write(&hdr, &c.state);
        write_snapshot_file(&self.cfg.snapshot_dir, &self.cfg.node_name, h, &hdr.state_root, &data, &hdr.block_id)
    }
}

pub fn write_snapshot_file(dir: &std::path::Path, node: &str, h: u64, root: &Hash32, data: &[u8], block_id: &Hash32) -> Result<Value> {
    std::fs::create_dir_all(dir)?;
    let path = dir.join(format!("{node}-h{h}-{}.aursnap", hex::encode(&root[..6])));
    std::fs::write(&path, data)?;
    Ok(json!({"path": path.display().to_string(), "height": h, "block_id": hex::encode(block_id), "state_root": hex::encode(root),
        "bytes": data.len(), "sha256": hex::encode(aureom_core::crypto::sha256(data)),
        "note": "verify with `aureom-cli snapshot verify` against a trusted block's state root before use"}))
}

async fn read_frame<R: AsyncReadExt + Unpin>(r: &mut R, max: usize) -> Result<Vec<u8>> {
    let mut len = [0u8; 4];
    r.read_exact(&mut len).await?;
    let n = u32::from_be_bytes(len) as usize;
    if n > max {
        bail!("frame of {n} bytes exceeds limit {max}");
    }
    let mut buf = vec![0u8; n];
    r.read_exact(&mut buf).await?;
    Ok(buf)
}

async fn write_frame<W: AsyncWriteExt + Unpin>(w: &mut W, b: &[u8]) -> Result<()> {
    w.write_all(&(b.len() as u32).to_be_bytes()).await?;
    w.write_all(b).await?;
    Ok(())
}
