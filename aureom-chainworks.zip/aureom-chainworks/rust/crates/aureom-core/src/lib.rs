//! AUREOM CHAINWORKS ledger core: protocol types, canonical encoding, deterministic
//! state machine, genesis handling and PoW consensus rules.
//!
//! This is development software. It has not been audited. See docs/SECURITY-LIMITATIONS.md.

pub mod codec;
pub mod crypto;
pub mod exec;
pub mod extension;
pub mod genesis;
pub mod json;
pub mod keystore;
pub mod merkle;
pub mod pow;
pub mod snapshot;
pub mod state;
pub mod types;
pub mod vectors;

#[cfg(test)]
mod exec_tests;

pub use primitive_types::U256;

/// floor(a * b / c) in 256-bit arithmetic. Panics only if c == 0 (callers guarantee c > 0);
/// saturates to u128::MAX if the quotient does not fit (never happens for a <= c or b <= c).
pub fn mul_div(a: u128, b: u128, c: u128) -> u128 {
    assert!(c > 0, "mul_div by zero");
    let r = U256::from(a) * U256::from(b) / U256::from(c);
    if r > U256::from(u128::MAX) {
        u128::MAX
    } else {
        r.as_u128()
    }
}

pub const NODE_SOFTWARE_VERSION: &str = env!("CARGO_PKG_VERSION");
/// Highest protocol version this software can execute.
pub const SUPPORTED_PROTOCOL_VERSION: u16 = 1;
