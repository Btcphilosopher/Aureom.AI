"""Console server: serves console/dist and a read-only manifest; proxies GETs to node
public APIs and POSTs of already-signed transactions. It never proxies the admin API,
never handles keys and cannot modify ledger state except by relaying signed transactions
into normal consensus."""
from __future__ import annotations

import hashlib
import json
import mimetypes
import pathlib
import re
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .network import Network
from .util import ROOT, read_json

ALLOWED_GET = re.compile(r"^(?!.*\.\.)(/v1/[A-Za-z0-9/_\-.]*(\?[A-Za-z0-9=&_\-.]*)?|/metrics)$")


def manifest(net: Network) -> dict:
    g = read_json(net.genesis_path)
    nodes = []
    for n in net.nodes():
        nodes.append({"name": n["name"], "role": ("miner" if n.get("miner") else "validator" if n.get("validator") else "full node"),
                      "proxy": f"/proxy/{n['name']}", "api_url": net.api(n["name"]), "p2p_listen": f"127.0.0.1:{n['p2p_port']}", "joiner": bool(n.get("joiner"))})
    return {"network": {"name": g["network_name"], "network_name": g["network_name"], "chain_id": g["chain_id"], "profile": g["consensus"]["profile"],
                        "genesis_hash": net.genesis_hash, "native_asset": g["native_asset"], "monetary_policy": g["monetary_policy"],
                        "fee_policy": g["fee_policy"], "limits": g["limits"], "consensus": g["consensus"], "governance": g["governance"],
                        "treasuries": [{"label": t["label"], "address": net._treasury_address(i)} for i, t in enumerate(g.get("treasuries", []))]},
            "nodes": nodes, "generated_at_ms": int(time.time() * 1000)}


def keys_inventory(net: Network) -> dict:
    out = []
    for f in sorted((net.secrets / "accounts").glob("*.json")):
        v = read_json(f)
        out.append({"role": v.get("role"), "label": v.get("label"), "address": v.get("address"), "pubkey": v.get("pubkey")})
    for f in sorted((net.dir / "public" / "nodes").glob("*.json")):
        v = read_json(f)
        out.append({"role": "p2p/consensus identity", "label": v["node"], "node": v["node"], "pubkey": v.get("peer_id") or v.get("consensus_pubkey"),
                    "address": v.get("consensus_address")})
    return {"keys": out, "note": "public parts only"}


def deployment(net: Network) -> dict:
    d = net.dir / "export"
    files = []
    if (d / "CHECKSUMS.sha256").exists():
        for ln in (d / "CHECKSUMS.sha256").read_text().splitlines():
            h, p = ln.split("  ", 1)
            files.append({"path": p, "sha256": h, "bytes": (d / p).stat().st_size if (d / p).exists() else None})
    return {"package": str(d) if files else None, "files": files,
            "excluded": ["secrets/*", "nodes/*/cometbft/config/priv_validator_key.json", "nodes/*/cometbft/config/node_key.json", "nodes/*/data"],
            "note": "run `chainworks export <dir>` to (re)build the package" if not files else ""}


def recovery(net: Network) -> dict:
    snaps, backups = [], []
    for n in net.nodes():
        for f in sorted((net.node_dir(n["name"]) / "snapshots").glob("*.aursnap")):
            m = re.search(r"-h(\d+)-([0-9a-f]+)\.aursnap$", f.name)
            snaps.append({"path": str(f.relative_to(net.dir)), "node": n["name"], "height": int(m.group(1)) if m else None,
                          "state_root_prefix": m.group(2) if m else None, "bytes": f.stat().st_size, "created_ms": int(f.stat().st_mtime * 1000), "verified": None})
    for m in sorted((net.dir / "backups").glob("*/backup-manifest.json")):
        v = read_json(m)
        backups.append({"path": str(m.parent.relative_to(net.dir)), "node": v["node"], "height": v["tip_height"], "files": len(v["files"]),
                        "created_ms": int(m.stat().st_mtime * 1000), "verified": None})
    return {"snapshots": snaps, "backups": backups}


def serve(net: Network, port: int = 8787, host: str = "127.0.0.1"):
    dist = ROOT / "console" / "dist"

    class H(BaseHTTPRequestHandler):
        def log_message(self, fmt, *a):
            pass

        def _send(self, code, body, ctype="application/json"):
            data = body if isinstance(body, bytes) else json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy", "frame-ancestors 'none'")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def _proxy(self, method, node, rest, body=None):
            try:
                base = net.api(node)
            except Exception:
                return self._send(404, {"error": {"code": "unknown_node", "message": node}})
            req = urllib.request.Request(base + rest, data=body, method=method, headers={"content-type": "application/json"} if body else {})
            try:
                with urllib.request.urlopen(req, timeout=4) as r:
                    return self._send(r.status, r.read(), r.headers.get("content-type", "application/json"))
            except urllib.error.HTTPError as e:
                return self._send(e.code, e.read())
            except Exception as e:  # noqa: BLE001
                return self._send(502, {"error": {"code": "node_unreachable", "message": str(e)}})

        def do_GET(self):
            p = self.path
            routes = {"/api/manifest": lambda: manifest(net), "/api/keys": lambda: keys_inventory(net),
                      "/api/deployment": lambda: deployment(net), "/api/recovery": lambda: recovery(net)}
            if p in routes:
                return self._send(200, routes[p]())
            m = re.match(r"^/proxy/([a-z0-9-]+)(/.*)$", p)
            if m:
                if not ALLOWED_GET.match(m.group(2)):
                    return self._send(403, {"error": {"code": "forbidden", "message": "only public /v1 GET endpoints are proxied"}})
                return self._proxy("GET", m.group(1), m.group(2))
            rel = p.split("?")[0].lstrip("/") or "index.html"
            f = (dist / rel).resolve()
            if not str(f).startswith(str(dist.resolve())) or not f.is_file():
                f = dist / "index.html"
            if not f.exists():
                return self._send(500, {"error": {"code": "console_not_built", "message": "run npm run build in console/"}})
            return self._send(200, f.read_bytes(), mimetypes.guess_type(str(f))[0] or "application/octet-stream")

        def do_POST(self):
            m = re.match(r"^/proxy/([a-z0-9-]+)(/v1/transactions)$", self.path)
            if not m:
                return self._send(403, {"error": {"code": "forbidden", "message": "only signed transaction submission is proxied"}})
            n = int(self.headers.get("content-length", "0"))
            if n > 200_000:
                return self._send(413, {"error": {"code": "too_large", "message": "body too large"}})
            body = self.rfile.read(n)
            try:
                v = json.loads(body)
                assert set(v) == {"tx"} and re.fullmatch(r"(0x)?[0-9a-fA-F]+", v["tx"])
            except Exception:
                return self._send(400, {"error": {"code": "bad_request", "message": 'body must be {"tx": "<hex signed transaction>"}'}})
            return self._proxy("POST", m.group(1), m.group(2), body)

    srv = ThreadingHTTPServer((host, port), H)
    return srv
