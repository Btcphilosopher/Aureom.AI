"""Network directory lifecycle: init -> keys -> genesis build -> validate -> up/status/down,
plus joining nodes, backup/restore, snapshots and replay.

Layout of a network directory:
    network.json            launch-wizard spec (human input)
    genesis.json            derived, consensus-critical; hash pinned in every node config
    genesis.hash
    public/                 exportable public material (node ids, addresses)
    secrets/                0700: keystores, dev passphrases, admin tokens, node keys, locks
    nodes/<name>/node.json  node configuration (no secrets inside; paths to secret files)
    nodes/<name>/data/      node database (redb)
    nodes/<name>/cometbft/  CometBFT home (BFT profiles; contains CometBFT's own keys)
    nodes/<name>/logs/
    run/<name>.json         process ids (local target)
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import subprocess
import time

from . import spec as specmod
from .util import ChainworksError, cli, find_bin, random_token, read_json, try_get, wait_for, write_json, write_secret


class Network:
    def __init__(self, d):
        self.dir = pathlib.Path(d).resolve()

    # ------------------------------------------------------------------ paths
    @property
    def spec_path(self):
        return self.dir / "network.json"

    @property
    def spec(self) -> dict:
        return read_json(self.spec_path)

    def save_spec(self, s):
        write_json(self.spec_path, s)

    @property
    def secrets(self):
        return self.dir / "secrets"

    def node_dir(self, n):
        return self.dir / "nodes" / n

    def keystore(self, label):
        return self.secrets / "accounts" / f"{label}.json"

    def passfile(self, label):
        return self.secrets / "passphrases" / f"{label}.pass"

    @property
    def genesis_path(self):
        return self.dir / "genesis.json"

    @property
    def profile(self):
        return self.spec["profile"]

    def nodes(self) -> list[dict]:
        return self.spec["nodes"]

    def node(self, name) -> dict:
        for n in self.nodes():
            if n["name"] == name:
                return n
        raise ChainworksError(f"unknown node {name}")

    def api(self, name) -> str:
        return f"http://127.0.0.1:{self.node(name)['api_port']}"

    def admin(self, name) -> tuple[str, str]:
        tok = (self.secrets / "nodes" / name / "admin.token").read_text().strip()
        return f"http://127.0.0.1:{self.node(name)['admin_port']}", tok

    def host(self, name) -> str:
        if self.spec.get("target") == "docker":
            return name if self.profile == "pow" else f"{name}-app"
        return "127.0.0.1"

    def listen_host(self) -> str:
        return "0.0.0.0" if self.spec.get("target") == "docker" else "127.0.0.1"

    # ------------------------------------------------------------------ init & keys
    @classmethod
    def init(cls, d, profile, force=False, **kw) -> "Network":
        net = cls(d)
        if net.spec_path.exists() and not force:
            raise ChainworksError(f"{net.spec_path} exists (use --force to overwrite)")
        net.dir.mkdir(parents=True, exist_ok=True)
        s = specmod.default_spec(profile, **kw)
        net.save_spec(s)
        (net.dir / "public").mkdir(exist_ok=True)
        net.secrets.mkdir(exist_ok=True)
        os.chmod(net.secrets, 0o700)
        (net.secrets / "README.txt").write_text("Private material. Never commit, export or upload this directory.\n")
        return net

    def ensure_account_key(self, label, role="account") -> dict:
        ks = self.keystore(label)
        if ks.exists():
            v = read_json(ks)
            return {"label": label, "address": v["address"], "pubkey": v["pubkey"], "created": False}
        s = self.spec
        pf = self.passfile(label)
        if not pf.exists():
            write_secret(pf, random_token(16))
        args = ["keys", "create", "--role", role, "--label", label, "--hrp", s["native_asset"]["address_hrp"], "--out", ks, "--passphrase-file", pf]
        if s.get("dev", {}).get("fast_kdf"):
            args.append("--fast-kdf")
        r = cli(*args)
        return {"label": label, "address": r["address"], "pubkey": r["pubkey"], "created": True}

    def address(self, label) -> str:
        return read_json(self.keystore(label))["address"]

    def ensure_node_keys(self, name) -> dict:
        nd = self.node_dir(name)
        sec = self.secrets / "nodes" / name
        sec.mkdir(parents=True, exist_ok=True)
        tok = sec / "admin.token"
        if not tok.exists():
            write_secret(tok, random_token(32))
        out = {"node": name}
        if self.profile == "pow":
            nk = sec / "node_key.json"
            if not nk.exists():
                cli("keys", "create", "--role", "node", "--label", name, "--out", nk)
            out["peer_id"] = read_json(nk)["pubkey"]
        else:
            home = nd / "cometbft"
            if not (home / "config" / "priv_validator_key.json").exists():
                home.mkdir(parents=True, exist_ok=True)
                subprocess.run([find_bin("cometbft"), "init", "--home", str(home)], check=True, capture_output=True)
            pv = read_json(home / "config" / "priv_validator_key.json")
            out["consensus_pubkey"] = pv["pub_key"]["value"]
            out["consensus_address"] = pv["address"]
            out["comet_node_id"] = subprocess.run([find_bin("cometbft"), "show-node-id", "--home", str(home)], check=True, capture_output=True, text=True).stdout.strip()
        write_json(self.dir / "public" / "nodes" / f"{name}.json", out)
        return out

    def create_all_keys(self) -> list:
        res = []
        for a in self.spec["accounts"]:
            res.append(self.ensure_account_key(a["label"], a.get("role", "account")))
        for n in self.nodes():
            res.append(self.ensure_node_keys(n["name"]))
        return res

    # ------------------------------------------------------------------ genesis
    def build_genesis(self, force=False) -> dict:
        if self.genesis_path.exists() and not force:
            raise ChainworksError("genesis.json already exists; consensus-critical files are not silently rebuilt (use --force on a network that has never been launched)")
        s = self.spec
        self.create_all_keys()
        allocs = []
        for a in s["accounts"]:
            if a.get("allocation") in (None, "0"):
                continue
            e = {"address": self.address(a["label"]), "amount": str(a["allocation"]), "label": a["label"]}
            if a.get("vesting"):
                e["vesting"] = a["vesting"]
            allocs.append(e)
        treas = []
        for t in s.get("treasuries", []):
            treas.append({"label": t["label"], "signers": [self.address(x) for x in t["signers"]], "threshold": t["threshold"], "amount": str(t["amount"])})
        vals = []
        if self.profile != "pow":
            for n in self.nodes():
                if not n.get("validator"):
                    continue
                pub = read_json(self.dir / "public" / "nodes" / f"{n['name']}.json")
                v = {"operator": self.address(n["operator"]), "consensus_pubkey": pub["consensus_pubkey"], "moniker": n["name"]}
                if self.profile == "pos":
                    v["self_bond"] = str(n["self_bond"])
                else:
                    v["power"] = int(n["power"])
                vals.append(v)
        mp = json.loads(json.dumps(s["monetary_policy"]))
        if mp["kind"] == "authority" and not mp["authority"]["mint_authority"].startswith(s["native_asset"]["address_hrp"] + "1"):
            mp["authority"]["mint_authority"] = self._treasury_address(0)
        if mp["kind"] == "fixed" and "max_supply" not in mp:
            pass
        gt = s.get("genesis_time_ms") or (int(time.time() * 1000) // 1000 * 1000)
        g = {
            "genesis_format": 1, "protocol_version": 1, "network_name": s["network_name"], "chain_id": s["chain_id"],
            "genesis_time_ms": gt, "consensus": s["consensus"], "native_asset": s["native_asset"], "monetary_policy": mp,
            "fee_policy": s["fee_policy"], "limits": s["limits"], "allocations": allocs, "treasuries": treas,
            "validators": vals, "governance": s["governance"], "upgrades": s.get("upgrades", []),
        }
        py = specmod.validate_genesis_py(g)
        if not py["ok"]:
            raise ChainworksError("genesis validation failed: " + "; ".join(py["errors"]))
        write_json(self.genesis_path, g)
        r = cli("genesis", "validate", self.genesis_path)
        if not r["ok"]:
            self.genesis_path.unlink()
            raise ChainworksError("genesis rejected by node software: " + "; ".join(r["errors"]))
        h = cli("genesis", "hash", self.genesis_path)
        from . import protocol
        if protocol.genesis_hash(g).hex() != h["genesis_hash"]:
            raise ChainworksError("Python and Rust genesis hashes disagree — refusing to continue")
        (self.dir / "genesis.hash").write_text(h["genesis_hash"] + "\n")
        self.write_node_configs()
        return {"genesis_hash": h["genesis_hash"], "state_root": h["state_root"], "warnings": r["warnings"] + py["warnings"], "chain_id": g["chain_id"]}

    def _treasury_address(self, i):
        from . import bech32m, protocol
        return bech32m.encode(self.spec["native_asset"]["address_hrp"], protocol.treasury_address(i))

    @property
    def genesis_hash(self) -> str:
        return (self.dir / "genesis.hash").read_text().strip()

    def write_node_configs(self):
        s = self.spec
        lh = self.listen_host()
        for n in self.nodes():
            self.write_node_config(n, lh)
        if self.profile != "pow":
            self.write_cometbft_genesis()
            for n in self.nodes():
                self.configure_cometbft(n)

    def write_node_config(self, n, lh=None):
        lh = lh or self.listen_host()
        name = n["name"]
        nd = self.node_dir(name)
        (nd / "logs").mkdir(parents=True, exist_ok=True)
        rel = lambda p: os.path.relpath(p, nd)
        admin_host = "0.0.0.0" if self.spec.get("target") == "docker" else self.spec["admin"]["admin_listen_host"]
        cfg = {
            "node_name": name, "profile": self.profile, "genesis_path": rel(self.genesis_path),
            "expected_genesis_hash": self.genesis_hash, "data_dir": "data",
            "api_listen": f"{lh}:{n['api_port']}", "admin_listen": f"{admin_host}:{n['admin_port']}",
            "admin_token_path": rel(self.secrets / "nodes" / name / "admin.token"),
            "snapshot_dir": "snapshots",
            "pruning": {"keep_undo_blocks": 1000, "keep_blocks": 0},
        }
        if self.profile == "pow":
            peers = [f"{self.host(o['name'])}:{o['p2p_port']}" for o in self.nodes() if o["name"] != name and not o.get("joiner")]
            cfg["pow"] = {
                "p2p_listen": f"{lh}:{n['p2p_port']}", "node_key_path": rel(self.secrets / "nodes" / name / "node_key.json"),
                "bootstrap_peers": n.get("bootstrap_peers", peers), "max_peers": 16, "discovery": False,
                "mining": {"enabled": bool(n.get("miner")), "miner_address": self.address(n["miner_account"]) if n.get("miner_account") else "",
                           "max_hashes_per_sec": n.get("max_hashes_per_sec", 300_000)},
            }
            if n.get("checkpoint"):
                cfg["pow"]["checkpoint"] = n["checkpoint"]
        else:
            cfg["bft"] = {"abci_listen": f"127.0.0.1:{n['abci_port']}", "cometbft_rpc": f"http://127.0.0.1:{n['rpc_port']}", "cometbft_home": "cometbft"}
            if n.get("trust_height"):
                cfg["bft"].update({"trust_height": n["trust_height"], "trust_hash": n["trust_hash"], "trust_period": "168h0m0s"})
        write_json(nd / "node.json", cfg)

    def cometbft_genesis(self) -> dict:
        g = read_json(self.genesis_path)
        t = dt.datetime.fromtimestamp(g["genesis_time_ms"] / 1000, tz=dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
        vals = []
        for v in g["validators"]:
            pk = base64.b64decode(v["consensus_pubkey"])
            power = int(v["self_bond"]) // int(g["consensus"]["pos"]["power_unit"]) if g["consensus"]["profile"] == "pos" else v["power"]
            vals.append({"address": hashlib.sha256(pk).digest()[:20].hex().upper(), "pub_key": {"type": "tendermint/PubKeyEd25519", "value": v["consensus_pubkey"]},
                         "power": str(power), "name": v["moniker"]})
        prof = g["consensus"]["profile"]
        ev_age = g["consensus"][prof]["evidence_max_age_blocks"]
        return {
            "genesis_time": t, "chain_id": g["chain_id"], "initial_height": "1",
            "consensus_params": {
                "block": {"max_bytes": str(g["limits"]["max_block_bytes"] + 1_048_576), "max_gas": "-1"},
                "evidence": {"max_age_num_blocks": str(ev_age), "max_age_duration": "172800000000000", "max_bytes": "1048576"},
                "validator": {"pub_key_types": ["ed25519"]}, "version": {"app": "1"}, "abci": {"vote_extensions_enable_height": "0"},
            },
            "validators": vals, "app_hash": "", "app_state": g,
        }

    def write_cometbft_genesis(self):
        cg = self.cometbft_genesis()
        txt = json.dumps(cg, indent=2)
        for n in self.nodes():
            p = self.node_dir(n["name"]) / "cometbft" / "config" / "genesis.json"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(txt)
        (self.dir / "public" / "cometbft-genesis.sha256").write_text(hashlib.sha256(txt.encode()).hexdigest() + "\n")

    def configure_cometbft(self, n):
        name = n["name"]
        home = self.node_dir(name) / "cometbft"
        lh = self.listen_host()
        peers = []
        for o in self.nodes():
            if o["name"] == name or o.get("joiner"):
                continue
            pub = read_json(self.dir / "public" / "nodes" / f"{o['name']}.json")
            peers.append(f"{pub['comet_node_id']}@{self.host(o['name'])}:{o['p2p_port']}")
        if n.get("joiner"):
            peers = n.get("persistent_peers") or peers
        settings = {
            "": {"moniker": f'"{name}"', "proxy_app": f'"tcp://127.0.0.1:{n["abci_port"]}"', "log_level": '"info"'},
            "rpc": {"laddr": f'"tcp://127.0.0.1:{n["rpc_port"]}"'},
            "p2p": {"laddr": f'"tcp://{lh}:{n["p2p_port"]}"', "persistent_peers": f'"{",".join(peers)}"', "addr_book_strict": "false",
                    "allow_duplicate_ip": "true", "pex": "false", "external_address": f'"{self.host(name)}:{n["p2p_port"]}"' if self.spec.get("target") == "docker" else '""'},
            "consensus": {"timeout_commit": '"1s"', "timeout_propose": '"2s"', "create_empty_blocks": "true", "create_empty_blocks_interval": '"0s"'},
            "mempool": {"size": "5000", "max_tx_bytes": str(self.spec["limits"]["max_tx_bytes"]), "max_txs_bytes": "67108864"},
            "statesync": {"enable": "false"},
            "instrumentation": {"prometheus": "false"},
        }
        cfgp = home / "config" / "config.toml"
        patch_toml(cfgp, settings)

    # ------------------------------------------------------------------ validation
    def validate(self) -> dict:
        report = {"checks": [], "ok": True}

        def check(name, ok, detail=""):
            report["checks"].append({"check": name, "ok": bool(ok), "detail": detail})
            if not ok:
                report["ok"] = False

        g = read_json(self.genesis_path)
        py = specmod.validate_genesis_py(g)
        check("genesis passes Python schema/economic validation", py["ok"], "; ".join(py["errors"]))
        r = cli("genesis", "validate", self.genesis_path)
        check("genesis passes node-software validation", r["ok"], "; ".join(r["errors"]))
        from . import protocol
        h_py = protocol.genesis_hash(g).hex()
        check("Python and Rust genesis hashes agree", h_py == r.get("genesis_hash"), h_py)
        check("genesis.hash file matches genesis.json", h_py == self.genesis_hash)
        report["genesis_hash"] = h_py
        report["warnings"] = r.get("warnings", []) + py.get("warnings", [])
        text = json.dumps(g)
        check("genesis contains no private-key material", not re.search(r'"(seed|priv_key|ciphertext|passphrase)"', text))
        cg_hashes = set()
        for n in self.nodes():
            cfgp = self.node_dir(n["name"]) / "node.json"
            if not cfgp.exists():
                check(f"{n['name']}: node config exists", False)
                continue
            c = read_json(cfgp)
            check(f"{n['name']}: pins genesis hash", c["expected_genesis_hash"] == h_py)
            check(f"{n['name']}: profile matches genesis", c["profile"] == g["consensus"]["profile"])
            check(f"{n['name']}: admin API bound to loopback", c["admin_listen"].startswith("127.0.0.1") or self.spec.get("target") == "docker",
                  c["admin_listen"])
            tokp = (cfgp.parent / c["admin_token_path"]).resolve()
            check(f"{n['name']}: admin token file is private (0600)", tokp.exists() and (tokp.stat().st_mode & 0o077) == 0)
            if self.profile != "pow":
                cgp = self.node_dir(n["name"]) / "cometbft" / "config" / "genesis.json"
                if cgp.exists():
                    cg = cgp.read_bytes()
                    cg_hashes.add(hashlib.sha256(cg).hexdigest())
                    app = json.loads(cg)["app_state"]
                    check(f"{n['name']}: CometBFT app_state hashes to the Aureom genesis", protocol.genesis_hash(app).hex() == h_py)
        if self.profile != "pow":
            check("all CometBFT genesis files identical", len(cg_hashes) == 1, ", ".join(sorted(cg_hashes)))
            # validator keys must not be duplicated across nodes
            keys = [read_json(self.dir / "public" / "nodes" / f"{n['name']}.json").get("consensus_pubkey") for n in self.nodes()]
            check("no validator key is shared between nodes", len(keys) == len(set(keys)))
        ports = [n[k] for n in self.nodes() for k in n if k.endswith("_port")]
        check("no port collisions", len(ports) == len(set(ports)))
        return report

    # ------------------------------------------------------------------ processes
    def pidfile(self, n):
        return self.dir / "run" / f"{n}.json"

    def is_running(self, n) -> bool:
        pf = self.pidfile(n)
        if not pf.exists():
            return False
        return any(_alive(p) for p in read_json(pf).values())

    def _lock_validator_key(self, name):
        """Refuse to run a second active instance of the same consensus key."""
        pub = read_json(self.dir / "public" / "nodes" / f"{name}.json")
        lock = self.secrets / "locks" / f"{pub['consensus_address']}.lock"
        lock.parent.mkdir(parents=True, exist_ok=True)
        if lock.exists():
            other = read_json(lock)
            if _alive(other.get("pid", -1)):
                raise ChainworksError(f"validator key {pub['consensus_address']} is already active (pid {other['pid']}, node {other['node']}); "
                                      "running two instances of one validator key risks double signing")
        return lock

    def start_node(self, name, env=None, wait=True):
        if self.is_running(name):
            return {"node": name, "status": "already running"}
        nd = self.node_dir(name)
        logs = nd / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        e = dict(os.environ)
        e.update(env or {})
        e.setdefault("RUST_LOG", "info")
        pids = {}
        app_log = open(logs / "node.log", "ab")
        p = subprocess.Popen([find_bin("aureom-node"), "run", "--config", str(nd / "node.json")], cwd=nd, stdout=app_log, stderr=subprocess.STDOUT,
                             env=e, start_new_session=True)
        pids["app"] = p.pid
        if self.profile != "pow":
            lock = self._lock_validator_key(name)
            n = self.node(name)
            wait_for(lambda: _port_open(n["abci_port"]) or p.poll() is not None, 20, 0.2, f"{name} ABCI port")
            if p.poll() is not None:
                raise ChainworksError(f"{name} exited early; see {logs / 'node.log'}")
            cl = open(logs / "cometbft.log", "ab")
            c = subprocess.Popen([find_bin("cometbft"), "start", "--home", str(nd / "cometbft")], cwd=nd, stdout=cl, stderr=subprocess.STDOUT,
                                 env=e, start_new_session=True)
            pids["cometbft"] = c.pid
            write_json(lock, {"pid": c.pid, "node": name, "since": int(time.time())})
        write_json(self.pidfile(name), pids)
        if wait:
            wait_for(lambda: try_get(self.api(name) + "/v1/health") or (p.poll() is not None and "exited"), 30, 0.3, f"{name} API")
            if p.poll() is not None:
                raise ChainworksError(f"{name} exited; see {logs / 'node.log'}")
        return {"node": name, "status": "started", "pids": pids}

    def stop_node(self, name, kill=False, timeout=10):
        pf = self.pidfile(name)
        if not pf.exists():
            return {"node": name, "status": "not running"}
        pids = read_json(pf)
        order = ["cometbft", "app"]
        for k in order:
            pid = pids.get(k)
            if pid and _alive(pid):
                try:
                    os.killpg(pid, signal.SIGKILL if kill else signal.SIGTERM)
                except ProcessLookupError:
                    pass
                end = time.time() + timeout
                while _alive(pid) and time.time() < end:
                    time.sleep(0.1)
                if _alive(pid):
                    os.killpg(pid, signal.SIGKILL)
        pf.unlink()
        if self.profile != "pow":
            pub = read_json(self.dir / "public" / "nodes" / f"{name}.json")
            (self.secrets / "locks" / f"{pub['consensus_address']}.lock").unlink(missing_ok=True)
        return {"node": name, "status": "killed" if kill else "stopped"}

    def up(self, names=None, env=None):
        v = self.validate()
        if not v["ok"]:
            bad = [c for c in v["checks"] if not c["ok"]]
            raise ChainworksError(f"validation failed, not launching: {bad}")
        out = []
        for n in (names or [x["name"] for x in self.nodes() if not x.get("joiner")]):
            out.append(self.start_node(n, env=env, wait=False))
        for n in (names or [x["name"] for x in self.nodes() if not x.get("joiner")]):
            wait_for(lambda: try_get(self.api(n) + "/v1/health"), 40, 0.3, f"{n} API")
        return out

    def down(self, names=None):
        return [self.stop_node(n) for n in (names or [x["name"] for x in self.nodes()])]

    def status(self) -> list[dict]:
        out = []
        for n in self.nodes():
            h = try_get(self.api(n["name"]) + "/v1/health")
            net = try_get(self.api(n["name"]) + "/v1/network")
            row = {"node": n["name"], "process": "running" if self.is_running(n["name"]) else "stopped", "reachable": h is not None}
            if h:
                row.update({"status": h["status"], "height": h["height"], "peers": h["peers"], "syncing": h["syncing"], "tip_age_ms": h["tip_age_ms"],
                            "alerts": [a["code"] for a in h["alerts"]]})
            if net:
                row["on_intended_chain"] = net["genesis_hash"] == self.genesis_hash and net["chain_id"] == self.spec["chain_id"]
            out.append(row)
        return out

    # ------------------------------------------------------------------ joining node
    def add_node(self, name, trust_from: str | None = None) -> dict:
        s = self.spec
        if any(n["name"] == name for n in s["nodes"]):
            raise ChainworksError(f"node {name} exists")
        base = max(max(v for k, v in n.items() if k.endswith("_port")) for n in s["nodes"]) + 1
        base = (base + 9) // 10 * 10
        n = {"name": name, "api_port": base, "admin_port": base + 1, "p2p_port": base + 2, "joiner": True}
        if self.profile == "pow":
            n.update({"miner": False})
        else:
            n.update({"validator": False, "abci_port": base + 3, "rpc_port": base + 4})
            if trust_from:
                b = try_get(self.api(trust_from) + "/v1/blocks/latest")
                if b:
                    n["trust_height"] = b["height"]
                    n["trust_hash"] = b["consensus"]["bft"]["cometbft_block_hash"]
        s["nodes"].append(n)
        self.save_spec(s)
        self.ensure_node_keys(name)
        self.write_node_config(n)
        if self.profile != "pow":
            cg = (self.node_dir(s["nodes"][0]["name"]) / "cometbft" / "config" / "genesis.json").read_text()
            (self.node_dir(name) / "cometbft" / "config" / "genesis.json").write_text(cg)
            self.configure_cometbft(n)
        return n

    # ------------------------------------------------------------------ recovery
    def snapshot(self, name) -> dict:
        url, tok = self.admin(name)
        from .util import http
        s, v = http("POST", url + "/admin/v1/snapshots", {}, {"authorization": f"Bearer {tok}"}, timeout=30)
        if s != 200:
            raise ChainworksError(f"snapshot failed: {v}")
        return v

    def backup(self, name, dest=None) -> dict:
        was = self.is_running(name)
        if was:
            self.stop_node(name)
        ts = time.strftime("%Y%m%dT%H%M%S")
        dest = pathlib.Path(dest or self.dir / "backups" / f"{name}-{ts}")
        r = _node_cmd("backup", self.node_dir(name), "--out", str(dest))
        files = {}
        for f in sorted(dest.rglob("*")):
            if f.is_file():
                files[str(f.relative_to(dest))] = hashlib.sha256(f.read_bytes()).hexdigest()
        if self.profile != "pow":
            # CometBFT block store and state; validator signing state is NOT copied into backups
            # meant for other machines, but is required to restore the same validator safely.
            src = self.node_dir(name) / "cometbft" / "data"
            shutil.copytree(src, dest / "cometbft-data", ignore=shutil.ignore_patterns("*.lock"))
        manifest = {"node": name, "tip_height": r["tip_height"], "files": files, "created": ts,
                    "note": "restore only onto the same node identity; never run a restored validator alongside the original"}
        write_json(dest / "backup-manifest.json", manifest)
        if was:
            self.start_node(name)
        return {"backup": str(dest), **manifest}

    def restore(self, name, src) -> dict:
        src = pathlib.Path(src)
        m = read_json(src / "backup-manifest.json")
        for rel, h in m["files"].items():
            if hashlib.sha256((src / rel).read_bytes()).hexdigest() != h:
                raise ChainworksError(f"backup file {rel} checksum mismatch — refusing to restore")
        if self.is_running(name):
            self.stop_node(name)
        data = self.node_dir(name) / "data"
        if data.exists():
            shutil.move(str(data), str(data) + f".replaced-{int(time.time())}")
        data.mkdir(parents=True)
        shutil.copy2(src / "chain.redb", data / "chain.redb")
        if self.profile != "pow" and (src / "cometbft-data").exists():
            cd = self.node_dir(name) / "cometbft" / "data"
            # keep the newer signing state: never move a validator's last-signed height backwards
            pvs = cd / "priv_validator_state.json"
            keep = pvs.read_text() if pvs.exists() else None
            shutil.move(str(cd), str(cd) + f".replaced-{int(time.time())}")
            shutil.copytree(src / "cometbft-data", cd)
            if keep:
                old = json.loads(keep)
                new = json.loads((cd / "priv_validator_state.json").read_text())
                if int(old.get("height", "0")) > int(new.get("height", "0")):
                    pvs.write_text(keep)
        return {"restored": name, "tip_height": m["tip_height"], "verified_checksums": len(m["files"])}

    def replay(self, name, snapshot, repair=False) -> dict:
        args = ["--snapshot", str(snapshot)] + (["--repair"] if repair else [])
        return _node_cmd("replay", self.node_dir(name), *args)

    def verify_chain(self, name) -> dict:
        return _node_cmd("verify-chain", self.node_dir(name))


def _node_cmd(cmd, nd, *args):
    from .util import run_json
    return run_json([find_bin("aureom-node"), cmd, "--config", str(nd / "node.json"), *args])


def _alive(pid) -> bool:
    try:
        os.kill(int(pid), 0)
    except (ProcessLookupError, ValueError, TypeError):
        return False
    except PermissionError:
        return True
    try:  # reap zombies of our own children
        r = os.waitpid(int(pid), os.WNOHANG)
        if r[0] == int(pid):
            return False
    except ChildProcessError:
        pass
    try:
        with open(f"/proc/{pid}/stat") as f:
            return f.read().split()[2] != "Z"
    except FileNotFoundError:
        return False


def _port_open(port) -> bool:
    import socket
    s = socket.socket()
    s.settimeout(0.2)
    try:
        s.connect(("127.0.0.1", int(port)))
        return True
    except OSError:
        return False
    finally:
        s.close()


def patch_toml(path: pathlib.Path, settings: dict[str, dict[str, str]]):
    """Replace `key = value` lines inside sections of CometBFT's config.toml."""
    lines = path.read_text().splitlines()
    section = ""
    seen = set()
    out = []
    for ln in lines:
        m = re.match(r"^\[([^\]]+)\]\s*$", ln)
        if m:
            section = m.group(1)
        kv = re.match(r"^([a-z_]+)\s*=", ln)
        if kv and section in settings and kv.group(1) in settings[section]:
            k = kv.group(1)
            out.append(f"{k} = {settings[section][k]}")
            seen.add((section, k))
            continue
        out.append(ln)
    missing = [(s, k) for s, d in settings.items() for k in d if (s, k) not in seen]
    if missing:
        raise ChainworksError(f"config.toml keys not found: {missing}")
    path.write_text("\n".join(out) + "\n")
