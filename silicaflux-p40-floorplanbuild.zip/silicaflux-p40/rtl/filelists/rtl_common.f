// Technology-independent RTL shared by all builds (paths relative to repo root)
rtl/common/sf_sync2.sv
rtl/common/sf_reset_sync.sv
rtl/common/sf_rr_arb.sv
