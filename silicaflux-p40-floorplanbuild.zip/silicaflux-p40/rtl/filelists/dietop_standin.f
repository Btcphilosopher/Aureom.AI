// STAND-IN DieTop (used because Projects 31-39 DieTop is absent; see audit)
rtl/standin/sf_data_fabric.sv
rtl/standin/sf_control_core.sv
rtl/standin/sf_dma.sv
rtl/standin/sf_vector_cluster.sv
rtl/standin/sf_tensor_cluster.sv
rtl/standin/sf_scratchpad.sv
rtl/standin/sf_host_if.sv
rtl/standin/sf_ext_mem_if.sv
rtl/standin/sf_power_mgr.sv
rtl/standin/sf_test_ras.sv
rtl/standin/silicaflux_dietop_standin.sv
