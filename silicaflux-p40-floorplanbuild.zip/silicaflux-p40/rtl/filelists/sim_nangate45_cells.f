// Simulation models of the Nangate45 cells/macros bound by tech_nangate45.f
rtl/sim_models/nangate45_sim_models.sv
