// Technology binding: Nangate45 / FreePDK45 (educational, non-manufacturable)
rtl/physical/tech/nangate45/sf_sram_sp_nangate45.sv
rtl/physical/tech/nangate45/sf_icg_nangate45.sv
