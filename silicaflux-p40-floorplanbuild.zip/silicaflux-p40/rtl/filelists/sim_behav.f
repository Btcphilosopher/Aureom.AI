// Behavioural models for technology-independent RTL simulation
rtl/sim_models/sf_sram_sp_behav.sv
rtl/sim_models/sf_icg_behav.sv
