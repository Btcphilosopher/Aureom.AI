// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_sram_sp  (BEHAVIOURAL SIMULATION MODEL ONLY)
// Technology-independent single-port SRAM with bit write mask.
// Contract (identical to the nangate45 fakeram45 binding):
//   * ce & !we : rdata is valid in the cycle after the read edge.
//   * ce &  we : masked write; rdata becomes X (do not consume).
//   * !ce      : rdata becomes X (do not consume).
// The deliberately strict X behaviour catches consumers that rely on stale data.
// Never synthesised: synthesis uses rtl/physical/tech/<tech>/sf_sram_sp_<tech>.sv
// -----------------------------------------------------------------------------
module sf_sram_sp #(
  parameter int DEPTH = 64,
  parameter int WIDTH = 32,
  parameter int AW    = $clog2(DEPTH)
) (
  input  logic             clk,
  input  logic             ce,
  input  logic             we,
  input  logic [AW-1:0]    addr,
  input  logic [WIDTH-1:0] wdata,
  input  logic [WIDTH-1:0] wmask,
  output logic [WIDTH-1:0] rdata
);
  logic [WIDTH-1:0] mem [DEPTH];
  always_ff @(posedge clk) begin
    if (ce) begin
      if (we) begin
        mem[addr] <= (wdata & wmask) | (mem[addr] & ~wmask);
        rdata     <= 'x;
      end else begin
        rdata     <= mem[addr];
      end
    end else begin
      rdata <= 'x;
    end
  end
endmodule
