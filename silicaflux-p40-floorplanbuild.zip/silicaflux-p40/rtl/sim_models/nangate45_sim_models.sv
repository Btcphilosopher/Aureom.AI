// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | Simulation models for technology-bound cells that the
// tech wrappers instantiate directly (SIMULATION ONLY - never synthesised).
//   * fakeram45_{64,128,256}x32 : follows the bsg_fakeram interface convention
//     (registered read, bit-masked write). These macros are ABSTRACT models from
//     OpenROAD-flow-scripts; there is no silicon behind them.
//   * CLKGATETST_X1              : Nangate45 latch-based ICG (state_function IQ&CK).
// -----------------------------------------------------------------------------
module sf_fakeram45_model #(parameter int DEPTH = 64, parameter int WIDTH = 32,
                            parameter int AW = $clog2(DEPTH)) (
  input  logic clk, input logic ce_in, input logic we_in,
  input  logic [AW-1:0] addr_in, input logic [WIDTH-1:0] wd_in,
  input  logic [WIDTH-1:0] w_mask_in, output logic [WIDTH-1:0] rd_out);
  logic [WIDTH-1:0] mem [DEPTH];
  always_ff @(posedge clk) begin
    if (ce_in) begin
      if (we_in) begin
        mem[addr_in] <= (wd_in & w_mask_in) | (mem[addr_in] & ~w_mask_in);
        rd_out <= 'x;
      end else rd_out <= mem[addr_in];
    end else rd_out <= 'x;
  end
endmodule

module fakeram45_64x32 (input logic clk, input logic ce_in, input logic we_in,
  input logic [5:0] addr_in, input logic [31:0] wd_in, input logic [31:0] w_mask_in,
  output logic [31:0] rd_out);
  sf_fakeram45_model #(.DEPTH(64), .WIDTH(32)) m (.*);
endmodule

module fakeram45_128x32 (input logic clk, input logic ce_in, input logic we_in,
  input logic [6:0] addr_in, input logic [31:0] wd_in, input logic [31:0] w_mask_in,
  output logic [31:0] rd_out);
  sf_fakeram45_model #(.DEPTH(128), .WIDTH(32)) m (.*);
endmodule

module fakeram45_256x32 (input logic clk, input logic ce_in, input logic we_in,
  input logic [7:0] addr_in, input logic [31:0] wd_in, input logic [31:0] w_mask_in,
  output logic [31:0] rd_out);
  sf_fakeram45_model #(.DEPTH(256), .WIDTH(32)) m (.*);
endmodule

module CLKGATETST_X1 (input logic CK, input logic E, input logic SE, output logic GCK);
  logic iq;
  always_latch begin
    if (!CK) iq = E | SE;
  end
  assign GCK = iq & CK;
endmodule
