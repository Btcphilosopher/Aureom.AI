// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_icg  (BEHAVIOURAL SIMULATION MODEL ONLY)
// Latch-based integrated clock gate: enable is captured while clk is low,
// so gclk never glitches. test_en forces the clock on (DFT).
// -----------------------------------------------------------------------------
module sf_icg (
  input  logic clk,
  input  logic en,
  input  logic test_en,
  output logic gclk
);
  logic en_l;
  always_latch begin
    if (!clk) en_l = en | test_en;
  end
  assign gclk = clk & en_l;
endmodule
