// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_sync2
// Two-flop synchroniser for a single-bit LEVEL signal entering the `clk` domain.
// Not for multi-bit buses (use a handshake/snapshot scheme; see sf_test_ras).
// -----------------------------------------------------------------------------
module sf_sync2 #(
  parameter logic RESET_VAL = 1'b0
) (
  input  logic clk,
  input  logic rst_n,
  input  logic d,
  output logic q
);
  logic s1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s1 <= RESET_VAL;
      q  <= RESET_VAL;
    end else begin
      s1 <= d;
      q  <= s1;
    end
  end
endmodule
