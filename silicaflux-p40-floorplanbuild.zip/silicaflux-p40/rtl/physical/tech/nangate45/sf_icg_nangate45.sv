// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_icg -> Nangate45 CLKGATETST_X1
// Integrated clock-gating cell with test-enable (SE) for DFT.
// -----------------------------------------------------------------------------
module sf_icg (
  input  logic clk,
  input  logic en,
  input  logic test_en,
  output logic gclk
);
  CLKGATETST_X1 u_icg (.CK(clk), .E(en), .SE(test_en), .GCK(gclk));
endmodule
