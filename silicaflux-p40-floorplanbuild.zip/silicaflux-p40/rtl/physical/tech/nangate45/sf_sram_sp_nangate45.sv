// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_sram_sp -> Nangate45 (FreePDK45, EDUCATIONAL)
// Technology-specific binding of the generic single-port SRAM onto the
// fakeram45 hard-macro abstracts (LEF + Liberty) shipped with
// OpenROAD-flow-scripts. fakeram45 macros are timing/physical ABSTRACTS with no
// silicon implementation: they are suitable for floorplanning research only.
//
// Unsupported geometries instantiate a deliberately non-existent module so that
// `hierarchy -check` FAILS with a self-describing name rather than silently
// inferring a flop array.
// -----------------------------------------------------------------------------
module sf_sram_sp #(
  parameter int DEPTH = 64,
  parameter int WIDTH = 32,
  parameter int AW    = $clog2(DEPTH)
) (
  input  logic             clk,
  input  logic             ce,
  input  logic             we,
  input  logic [AW-1:0]    addr,
  input  logic [WIDTH-1:0] wdata,
  input  logic [WIDTH-1:0] wmask,
  output logic [WIDTH-1:0] rdata
);
  generate
    if (DEPTH == 64 && WIDTH == 32) begin : g_m64x32
      fakeram45_64x32 u_macro (.clk(clk), .ce_in(ce), .we_in(we), .addr_in(addr),
                               .wd_in(wdata), .w_mask_in(wmask), .rd_out(rdata));
    end else if (DEPTH == 128 && WIDTH == 32) begin : g_m128x32
      fakeram45_128x32 u_macro (.clk(clk), .ce_in(ce), .we_in(we), .addr_in(addr),
                                .wd_in(wdata), .w_mask_in(wmask), .rd_out(rdata));
    end else if (DEPTH == 256 && WIDTH == 32) begin : g_m256x32
      fakeram45_256x32 u_macro (.clk(clk), .ce_in(ce), .we_in(we), .addr_in(addr),
                                .wd_in(wdata), .w_mask_in(wmask), .rd_out(rdata));
    end else begin : g_unsupported
      SF_MISSING_NANGATE45_SRAM_MACRO_FOR_REQUESTED_GEOMETRY u_missing (.clk(clk));
    end
  endgenerate
endmodule
