// -----------------------------------------------------------------------------
// SilicaFlux Project 40 FLOORPLANBUILD | silicaflux_floorplan_wrapper
// Aureom.AI | SilicaFlux-HPC
//
// Physical top level. Deliberately thin - it exists only for legitimate
// integration needs and does NOT re-implement the SoC architecture:
//   * a stable, technology-neutral port list for pin planning
//     (port names are referenced by the pin-plan groups in the floorplan YAML)
//   * reset conditioning (async-assert / sync-deassert) and DFT test_mode
//   * the single binding point for `silicaflux_dietop` (stand-in or real DieTop)
// Technology-specific cells (SRAM macros, clock gates) are bound underneath via
// rtl/physical/tech/<tech>/ wrappers selected by the technology profile.
// No pad cells: I/O is ABSTRACT pin placement (no pad-ring/bump library).
// -----------------------------------------------------------------------------
module silicaflux_floorplan_wrapper #(
  parameter int NV            = 1,
  parameter int NT            = 1,
  parameter int VBANK_DEPTH   = 64,
  parameter int TBANK_DEPTH   = 64,
  parameter int SCRATCH_DEPTH = 256
) (
  // clock / reset / test
  input  logic        clk,
  input  logic        rst_n,
  input  logic        test_mode,
  // host port (synchronous to clk, 4-phase req/ack)
  input  logic        host_req,
  input  logic        host_we,
  input  logic [15:0] host_addr,
  input  logic [31:0] host_wdata,
  output logic        host_ack,
  output logic [31:0] host_rdata,
  output logic        host_err,
  // external memory port (synchronous to clk, 4-phase req/ack)
  output logic        ext_req,
  output logic        ext_we,
  output logic [14:0] ext_addr,
  output logic [31:0] ext_wdata,
  input  logic        ext_ack,
  input  logic [31:0] ext_rdata,
  // interrupt / thermal sensor alert (asynchronous)
  output logic        irq,
  input  logic        therm_alert,
  // JTAG (asynchronous to clk)
  input  logic        tck,
  input  logic        tms,
  input  logic        tdi,
  input  logic        trst_n,
  output logic        tdo
);
  logic core_rst_n;

  sf_reset_sync u_rst_sync (
    .clk(clk), .arst_n(rst_n), .test_mode(test_mode), .rst_n_sync(core_rst_n));

  silicaflux_dietop #(
    .NV(NV), .NT(NT), .VBANK_DEPTH(VBANK_DEPTH), .TBANK_DEPTH(TBANK_DEPTH),
    .SCRATCH_DEPTH(SCRATCH_DEPTH)
  ) u_dietop (
    .clk(clk), .rst_n(core_rst_n), .test_mode(test_mode),
    .host_req(host_req), .host_we(host_we), .host_addr(host_addr), .host_wdata(host_wdata),
    .host_ack(host_ack), .host_rdata(host_rdata), .host_err(host_err),
    .ext_req(ext_req), .ext_we(ext_we), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
    .ext_ack(ext_ack), .ext_rdata(ext_rdata),
    .irq(irq), .therm_alert(therm_alert),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo));
endmodule
