// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_power_mgr  (STAND-IN INTEGRATION RTL)
// Clock-domain enables and thermal throttling (POWERCLOCK-style policy).
// Scope is deliberately limited to what physically exists in this design:
//   * per-engine-class clock-domain enables (consumed by sf_icg in the clusters)
//   * thermal throttling of tensor compute steps when the external therm_alert
//     pin is asserted (duty = 1 / 2^shift)
//   * activity counters
// There is NO voltage or frequency scaling: no regulator or PLL interface
// exists in this design, so none is claimed.
//
// CSRs: 0x08 PM_CLK_EN [0]=vector [1]=tensor (reset 2'b11)
//       0x09 PM_THROTTLE [0]=enable [3:1]=shift
//       0x0A PM_STATUS [0]=therm_alert(sync) [1]=throttling
//       0x0B PERF_CYCLES 0x0C PERF_TEN_ACTIVE 0x0D PERF_THROTTLED
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_power_mgr (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        therm_alert_async,
  input  logic        ten_computing,
  // CSR bus
  input  logic        csr_valid,
  input  logic        csr_we,
  input  logic [7:0]  csr_addr,
  input  logic [31:0] csr_wdata,
  output logic        csr_hit,
  output logic [31:0] csr_rdata,
  // domain controls
  output logic        vec_en,
  output logic        ten_en,
  output logic        ten_step_allow
);
  logic       therm;
  logic       thr_en;
  logic [2:0] thr_shift;
  logic [6:0] thr_cnt;
  logic       throttling;
  logic [31:0] cyc, ten_act, thr_cyc;

  sf_sync2 u_therm_sync (.clk(clk), .rst_n(rst_n), .d(therm_alert_async), .q(therm));

  assign throttling = thr_en && therm;

  logic [6:0] thr_mask;
  always_comb begin
    thr_mask = 7'h00;
    for (int b = 0; b < 7; b++) if (b < thr_shift) thr_mask[b] = 1'b1;
  end

  assign ten_step_allow = ten_en && (!throttling || ((thr_cnt & thr_mask) == 7'h00));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      vec_en <= 1'b1; ten_en <= 1'b1; thr_en <= 1'b0; thr_shift <= 3'd1;
      thr_cnt <= '0; cyc <= '0; ten_act <= '0; thr_cyc <= '0;
    end else begin
      if (csr_valid && csr_we) begin
        case (csr_addr)
          8'h08: begin vec_en <= csr_wdata[0]; ten_en <= csr_wdata[1]; end
          8'h09: begin thr_en <= csr_wdata[0]; thr_shift <= csr_wdata[3:1]; end
          default: ;
        endcase
      end
      thr_cnt <= thr_cnt + 7'd1;
      cyc     <= cyc + 32'd1;
      if (ten_computing) ten_act <= ten_act + 32'd1;
      if (ten_computing && !ten_step_allow) thr_cyc <= thr_cyc + 32'd1;
    end
  end

  always_comb begin
    csr_hit   = 1'b1;
    csr_rdata = 32'h0;
    case (csr_addr)
      8'h08: csr_rdata = {30'd0, ten_en, vec_en};
      8'h09: csr_rdata = {28'd0, thr_shift, thr_en};
      8'h0A: csr_rdata = {30'd0, throttling, therm};
      8'h0B: csr_rdata = cyc;
      8'h0C: csr_rdata = ten_act;
      8'h0D: csr_rdata = thr_cyc;
      default: csr_hit = 1'b0;
    endcase
  end
endmodule
