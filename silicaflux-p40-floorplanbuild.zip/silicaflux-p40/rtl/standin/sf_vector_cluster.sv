// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_vector_cluster  (STAND-IN INTEGRATION RTL)
// A 4-lane INT8 SIMD vector engine with three private SRAM banks (A, B, C).
//
// Fabric slave view (local address = addr[9:0]):
//   addr[9:8] bank (0=A, 1=B, 2=C, 3=invalid -> err), addr[AW-1:0] word.
//   Fabric accesses are accepted only while the engine is idle.
//
// Command (from control core): op, len, a, b, c (bank-local word offsets).
//   op 0 ADD8  1 SUB8  2 MAX8(signed)  3 RELU8(A)  4 XOR32  5 AND32
//   op 6 MUL8 (low byte of each lane product)
//   op 7 DOT8 : C[c] = sum_i sum_lanes signed(A[a+i].l) * signed(B[b+i].l)
//   Out-of-range operands or unknown op -> cmd_err (no bank is written).
//
// Clock gating: the datapath pipeline (v1/v2/result/accumulator) runs on a
// gated clock enabled only while a command is active (sf_icg).
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_vector_cluster #(
  parameter int DEPTH = 64,
  parameter int AW    = $clog2(DEPTH)
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        test_mode,
  // fabric slave
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_we,
  input  logic [15:0] req_addr,
  input  logic [31:0] req_wdata,
  output logic        rsp_valid,
  output logic        rsp_err,
  output logic [31:0] rsp_rdata,
  // command
  input  logic        cmd_start,
  input  logic [3:0]  cmd_op,
  input  logic [15:0] cmd_len,
  input  logic [15:0] cmd_a,
  input  logic [15:0] cmd_b,
  input  logic [15:0] cmd_c,
  output logic        cmd_done,
  output logic        cmd_err,
  output logic        busy
);
  localparam logic [3:0] OP_ADD = 4'd0, OP_SUB = 4'd1, OP_MAX = 4'd2, OP_RELU = 4'd3,
                         OP_XOR = 4'd4, OP_AND = 4'd5, OP_MUL = 4'd6, OP_DOT  = 4'd7;

  typedef enum logic [2:0] {S_IDLE, S_RUN, S_DRAIN, S_DOTWR, S_DONE} state_t;
  state_t state;

  // ---------------- latched command ----------------
  logic [3:0]  op_q;
  logic [AW:0] len_q, idx_q;
  logic [AW:0] a_q, b_q, c_q;

  // ---------------- banks ----------------
  logic          a_ce, a_we, b_ce, b_we, c_ce, c_we;
  logic [AW-1:0] a_addr, b_addr, c_addr;
  logic [31:0]   a_wd, b_wd, c_wd, a_rd, b_rd, c_rd;

  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_a (.clk(clk), .ce(a_ce), .we(a_we),
    .addr(a_addr), .wdata(a_wd), .wmask(32'hFFFF_FFFF), .rdata(a_rd));
  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_b (.clk(clk), .ce(b_ce), .we(b_we),
    .addr(b_addr), .wdata(b_wd), .wmask(32'hFFFF_FFFF), .rdata(b_rd));
  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_c (.clk(clk), .ce(c_ce), .we(c_we),
    .addr(c_addr), .wdata(c_wd), .wmask(32'hFFFF_FFFF), .rdata(c_rd));

  // ---------------- gated datapath ----------------
  logic gclk_dp;
  logic dp_en;
  assign dp_en = (state != S_IDLE);
  sf_icg u_cg_dp (.clk(clk), .en(dp_en), .test_en(test_mode), .gclk(gclk_dp));

  logic          v1, v2;
  logic [AW-1:0] w1, w2;
  logic [31:0]   res_q;
  logic [31:0]   acc_q;
  logic          issue;
  logic          clear_acc;

  // lane arithmetic (combinational on SRAM outputs); 4 lanes x INT8
  logic [31:0]        lane_res;
  logic signed [17:0] dot_sum;
  logic [7:0]         la, lb, lr;
  logic [15:0]        lp;
  always_comb begin
    dot_sum  = '0;
    lane_res = '0;
    la = '0; lb = '0; lr = '0; lp = '0;
    for (int l = 0; l < 4; l++) begin
      la = a_rd[8*l +: 8];
      lb = b_rd[8*l +: 8];
      lp = $signed(la) * $signed(lb);
      case (op_q)
        OP_ADD:  lr = la + lb;
        OP_SUB:  lr = la - lb;
        OP_MAX:  lr = ($signed(la) > $signed(lb)) ? la : lb;
        OP_RELU: lr = la[7] ? 8'h00 : la;
        OP_XOR:  lr = la ^ lb;
        OP_AND:  lr = la & lb;
        OP_MUL:  lr = lp[7:0];
        default: lr = 8'h00;
      endcase
      lane_res[8*l +: 8] = lr;
      dot_sum = dot_sum + {{2{lp[15]}}, lp};
    end
  end

  always_ff @(posedge gclk_dp or negedge rst_n) begin
    if (!rst_n) begin
      v1 <= 1'b0; v2 <= 1'b0; w1 <= '0; w2 <= '0; res_q <= '0; acc_q <= '0;
    end else begin
      v1 <= issue;
      w1 <= AW'(c_q + idx_q);
      v2 <= v1 && (op_q != OP_DOT);
      w2 <= w1;
      if (v1) res_q <= lane_res;
      if (clear_acc)            acc_q <= '0;
      else if (v1 && op_q == OP_DOT) acc_q <= acc_q + {{14{dot_sum[17]}}, dot_sum};
    end
  end

  // ---------------- command validation ----------------
  logic        uses_b, is_dot, args_ok;
  logic [16:0] a_end, b_end, c_end;
  always_comb begin
    uses_b  = (cmd_op != OP_RELU);
    is_dot  = (cmd_op == OP_DOT);
    a_end   = {1'b0, cmd_a} + {1'b0, cmd_len};
    b_end   = {1'b0, cmd_b} + {1'b0, cmd_len};
    c_end   = {1'b0, cmd_c} + (is_dot ? 17'd1 : {1'b0, cmd_len});
    args_ok = (cmd_op <= OP_DOT) && (cmd_len != 16'd0)
            && (a_end <= 17'(DEPTH))
            && (!uses_b || (b_end <= 17'(DEPTH)))
            && (c_end <= 17'(DEPTH));
  end

  // ---------------- control FSM (ungated clock) ----------------
  assign issue     = (state == S_RUN);
  assign clear_acc = (state == S_RUN) && (idx_q == '0);
  assign busy      = (state != S_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; op_q <= '0; len_q <= '0; idx_q <= '0;
      a_q <= '0; b_q <= '0; c_q <= '0; cmd_done <= 1'b0; cmd_err <= 1'b0;
    end else begin
      cmd_done <= 1'b0;
      cmd_err  <= 1'b0;
      case (state)
        S_IDLE: if (cmd_start) begin
          if (args_ok) begin
            op_q  <= cmd_op;
            len_q <= (AW+1)'(cmd_len);
            a_q   <= (AW+1)'(cmd_a);
            b_q   <= (AW+1)'(cmd_b);
            c_q   <= (AW+1)'(cmd_c);
            idx_q <= '0;
            state <= S_RUN;
          end else begin
            cmd_done <= 1'b1;
            cmd_err  <= 1'b1;
          end
        end
        S_RUN: begin
          if (idx_q == len_q - 1'b1) state <= S_DRAIN;
          else                       idx_q <= idx_q + 1'b1;
        end
        S_DRAIN: if (!v1 && !v2) state <= (op_q == OP_DOT) ? S_DOTWR : S_DONE;
        S_DOTWR: state <= S_DONE;
        S_DONE: begin
          cmd_done <= 1'b1;
          state    <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  // ---------------- bank port arbitration ----------------
  logic        f_acc;      // fabric access accepted this cycle
  logic [1:0]  f_bank;
  logic        rsp_pend;
  logic [1:0]  rsp_bank;
  logic        rsp_bad;

  logic f_word_ok, f_ok;
  assign req_ready = (state == S_IDLE);
  assign f_acc     = req_valid & req_ready;
  assign f_bank    = req_addr[9:8];
  // words beyond DEPTH inside the 8-bit word field are rejected (no aliasing)
  assign f_word_ok = ({8'h00, req_addr[7:0]} < 16'(DEPTH));
  assign f_ok      = f_word_ok && (f_bank != 2'd3);

  always_comb begin
    a_ce = 1'b0; a_we = 1'b0; a_addr = '0; a_wd = req_wdata;
    b_ce = 1'b0; b_we = 1'b0; b_addr = '0; b_wd = req_wdata;
    c_ce = 1'b0; c_we = 1'b0; c_addr = '0; c_wd = req_wdata;
    if (state != S_IDLE) begin
      a_ce   = issue;
      a_addr = AW'(a_q + idx_q);
      b_ce   = issue && (op_q != OP_RELU);
      b_addr = AW'(b_q + idx_q);
      if (v2) begin
        c_ce = 1'b1; c_we = 1'b1; c_addr = w2; c_wd = res_q;
      end else if (state == S_DOTWR) begin
        c_ce = 1'b1; c_we = 1'b1; c_addr = AW'(c_q); c_wd = acc_q;
      end
    end else if (f_acc && f_ok) begin
      case (f_bank)
        2'd0: begin a_ce = 1'b1; a_we = req_we; a_addr = req_addr[AW-1:0]; end
        2'd1: begin b_ce = 1'b1; b_we = req_we; b_addr = req_addr[AW-1:0]; end
        2'd2: begin c_ce = 1'b1; c_we = req_we; c_addr = req_addr[AW-1:0]; end
        default: ;
      endcase
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_pend <= 1'b0; rsp_bank <= '0; rsp_bad <= 1'b0;
    end else begin
      rsp_pend <= f_acc;
      rsp_bank <= f_bank;
      rsp_bad  <= !f_ok;
    end
  end

  // write responses carry no data; reads return the addressed bank output
  logic rsp_was_write;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)     rsp_was_write <= 1'b0;
    else if (f_acc) rsp_was_write <= req_we;
  end

  assign rsp_valid = rsp_pend;
  assign rsp_err   = rsp_bad;
  always_comb begin
    rsp_rdata = 32'h0;
    if (!rsp_bad && !rsp_was_write) begin
      case (rsp_bank)
        2'd0: rsp_rdata = a_rd;
        2'd1: rsp_rdata = b_rd;
        2'd2: rsp_rdata = c_rd;
        default: rsp_rdata = 32'h0;
      endcase
    end
  end
endmodule
