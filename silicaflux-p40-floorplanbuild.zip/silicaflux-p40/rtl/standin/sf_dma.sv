// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_dma  (STAND-IN INTEGRATION RTL)
// Word-copy DMA engine (fabric master 2): dst[i] = src[i], i = 0..len-1.
// One outstanding fabric transaction; aborts with err on any fabric error.
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_dma (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        start,
  input  logic [15:0] src,
  input  logic [15:0] dst,
  input  logic [15:0] len,
  output logic        done,
  output logic        err,
  output logic        busy,
  // fabric master
  output logic        m_req_valid,
  input  logic        m_req_ready,
  output logic        m_req_we,
  output logic [15:0] m_req_addr,
  output logic [31:0] m_req_wdata,
  input  logic        m_rsp_valid,
  input  logic        m_rsp_err,
  input  logic [31:0] m_rsp_rdata
);
  typedef enum logic [2:0] {D_IDLE, D_RREQ, D_RWAIT, D_WREQ, D_WWAIT, D_DONE} dstate_t;
  dstate_t ds;
  logic [15:0] s_q, d_q, n_q, i_q;
  logic [31:0] buf_q;
  logic        err_q;

  assign busy        = (ds != D_IDLE);
  assign m_req_valid = (ds == D_RREQ) || (ds == D_WREQ);
  assign m_req_we    = (ds == D_WREQ);
  assign m_req_addr  = (ds == D_WREQ) ? (d_q + i_q) : (s_q + i_q);
  assign m_req_wdata = buf_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ds <= D_IDLE; s_q <= '0; d_q <= '0; n_q <= '0; i_q <= '0;
      buf_q <= '0; err_q <= 1'b0; done <= 1'b0; err <= 1'b0;
    end else begin
      done <= 1'b0;
      err  <= 1'b0;
      case (ds)
        D_IDLE: if (start) begin
          s_q <= src; d_q <= dst; n_q <= len; i_q <= '0; err_q <= 1'b0;
          ds  <= (len == 16'd0) ? D_DONE : D_RREQ;
        end
        D_RREQ:  if (m_req_ready) ds <= D_RWAIT;
        D_RWAIT: if (m_rsp_valid) begin
          buf_q <= m_rsp_rdata;
          if (m_rsp_err) begin err_q <= 1'b1; ds <= D_DONE; end
          else ds <= D_WREQ;
        end
        D_WREQ:  if (m_req_ready) ds <= D_WWAIT;
        D_WWAIT: if (m_rsp_valid) begin
          if (m_rsp_err) begin err_q <= 1'b1; ds <= D_DONE; end
          else if (i_q == n_q - 16'd1) ds <= D_DONE;
          else begin i_q <= i_q + 16'd1; ds <= D_RREQ; end
        end
        D_DONE: begin
          done <= 1'b1;
          err  <= err_q;
          ds   <= D_IDLE;
        end
        default: ds <= D_IDLE;
      endcase
    end
  end
endmodule
