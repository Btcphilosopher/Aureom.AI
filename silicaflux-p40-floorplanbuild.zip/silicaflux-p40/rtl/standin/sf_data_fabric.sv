// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_data_fabric  (STAND-IN INTEGRATION RTL)
// Crossbar "spine" connecting NM masters to NS slaves.
//
// Protocol (per port):
//   request : valid/ready handshake, {we, addr[15:0], wdata[31:0]}
//   response: rsp_valid pulse with {err, rdata}; one outstanding request per
//             master; a master must not raise a new request before its response.
// Each slave serves one transaction at a time; masters contending for the same
// slave are arbitrated round-robin. Different slaves operate concurrently.
//
// Word address map (16-bit word addresses):
//   0x0xxx            control-core command RAM                      slave 0
//   0x1 cc bb wwwwwwww vector cluster cc (addr[11:10]), bank bb     slaves 1..NV
//   0x2 cc bb wwwwwwww tensor cluster cc                            slaves NV+1..NV+NT
//   0x3xxx            shared scratchpad                             slave NV+NT+1
//   0x8000-0xFFFF     external memory window                        slave NV+NT+2
//   anything else     decode error (err=1, rdata=0xDEADBEEF)
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_data_fabric #(
  parameter int NM = 3,
  parameter int NV = 1,
  parameter int NT = 1,
  parameter int NS = NV + NT + 3,
  parameter int SIW = $clog2(NS)
) (
  input  logic              clk,
  input  logic              rst_n,
  // master side
  input  logic [NM-1:0]     m_req_valid,
  output logic [NM-1:0]     m_req_ready,
  input  logic [NM-1:0]     m_req_we,
  input  logic [NM*16-1:0]  m_req_addr,
  input  logic [NM*32-1:0]  m_req_wdata,
  output logic [NM-1:0]     m_rsp_valid,
  output logic [NM-1:0]     m_rsp_err,
  output logic [NM*32-1:0]  m_rsp_rdata,
  // slave side
  output logic [NS-1:0]     s_req_valid,
  input  logic [NS-1:0]     s_req_ready,
  output logic [NS-1:0]     s_req_we,
  output logic [NS*16-1:0]  s_req_addr,
  output logic [NS*32-1:0]  s_req_wdata,
  input  logic [NS-1:0]     s_rsp_valid,
  input  logic [NS-1:0]     s_rsp_err,
  input  logic [NS*32-1:0]  s_rsp_rdata,
  // RAS
  output logic [15:0]       decode_err_count
);
  localparam int MIW = (NM > 1) ? $clog2(NM) : 1;
  localparam int S_CMD  = 0;
  localparam int S_VEC0 = 1;
  localparam int S_TEN0 = 1 + NV;
  localparam int S_SCR  = 1 + NV + NT;
  localparam int S_EXT  = 2 + NV + NT;

  // ---------------- address decode (per master) ----------------
  logic [NM-1:0]      dec_ok;
  logic [NM*SIW-1:0]  dec_idx;
  logic [15:0]        a;

  always_comb begin
    a = '0;
    for (int m = 0; m < NM; m++) begin
      a          = m_req_addr[m*16 +: 16];
      dec_ok[m]  = 1'b0;
      dec_idx[m*SIW +: SIW] = '0;
      if (a[15]) begin
        dec_ok[m]  = 1'b1;
        dec_idx[m*SIW +: SIW] = SIW'(S_EXT);
      end else begin
        case (a[14:12])
          3'h0: begin dec_ok[m] = 1'b1; dec_idx[m*SIW +: SIW] = SIW'(S_CMD); end
          3'h1: if ({30'd0, a[11:10]} < NV) begin
                  dec_ok[m]  = 1'b1;
                  dec_idx[m*SIW +: SIW] = SIW'(S_VEC0) + SIW'(a[11:10]);
                end
          3'h2: if ({30'd0, a[11:10]} < NT) begin
                  dec_ok[m]  = 1'b1;
                  dec_idx[m*SIW +: SIW] = SIW'(S_TEN0) + SIW'(a[11:10]);
                end
          3'h3: begin dec_ok[m] = 1'b1; dec_idx[m*SIW +: SIW] = SIW'(S_SCR); end
          default: ;
        endcase
      end
    end
  end

  // ---------------- per-master outstanding tracking ----------------
  logic [NM-1:0] m_pending;   // accepted, waiting for response
  logic [NM-1:0] m_err_rsp;   // decode-error response scheduled for next cycle

  // ---------------- per-slave arbitration ----------------
  logic [NS-1:0]      s_busy;
  logic [NS*MIW-1:0]  s_owner;
  logic [NS*NM-1:0]   s_gnt;
  logic [NS*MIW-1:0]  s_gidx;
  logic [NS-1:0]      s_any;
  logic [NS-1:0]      s_hs;
  logic [NS*NM-1:0]   s_req_vec;

  genvar gs;
  generate
    for (gs = 0; gs < NS; gs++) begin : g_slave
      always_comb begin
        for (int m = 0; m < NM; m++)
          s_req_vec[gs*NM + m] = m_req_valid[m] & dec_ok[m] & (dec_idx[m*SIW +: SIW] == SIW'(gs))
                             & ~m_pending[m] & ~s_busy[gs];
      end
      sf_rr_arb #(.N(NM)) u_arb (
        .clk(clk), .rst_n(rst_n), .req(s_req_vec[gs*NM +: NM]), .advance(s_hs[gs]),
        .gnt(s_gnt[gs*NM +: NM]), .gnt_idx(s_gidx[gs*MIW +: MIW]), .any(s_any[gs]));

      assign s_req_valid[gs]           = s_any[gs];
      assign s_req_we[gs]              = m_req_we[s_gidx[gs*MIW +: MIW]];
      assign s_req_addr[gs*16 +: 16]   = m_req_addr[s_gidx[gs*MIW +: MIW]*16 +: 16];
      assign s_req_wdata[gs*32 +: 32]  = m_req_wdata[s_gidx[gs*MIW +: MIW]*32 +: 32];
      assign s_hs[gs]                  = s_any[gs] & s_req_ready[gs];

      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          s_busy[gs]                <= 1'b0;
          s_owner[gs*MIW +: MIW]    <= '0;
        end else if (s_hs[gs]) begin
          s_busy[gs]                <= 1'b1;
          s_owner[gs*MIW +: MIW]    <= s_gidx[gs*MIW +: MIW];
        end else if (s_busy[gs] && s_rsp_valid[gs]) begin
          s_busy[gs]  <= 1'b0;
        end
      end
    end
  endgenerate

  // ---------------- master ready / response routing ----------------
  logic [NM-1:0] dec_err_accept;
  always_comb begin
    m_req_ready = '0;
    m_rsp_valid = '0;
    m_rsp_err   = '0;
    m_rsp_rdata = '0;
    for (int m = 0; m < NM; m++) begin
      dec_err_accept[m] = m_req_valid[m] & ~dec_ok[m] & ~m_pending[m];
      m_req_ready[m]    = dec_err_accept[m];
      for (int s = 0; s < NS; s++) begin
        if (s_hs[s] && s_gnt[s*NM + m]) m_req_ready[m] = 1'b1;
        if (s_busy[s] && s_rsp_valid[s] && (s_owner[s*MIW +: MIW] == MIW'(m))) begin
          m_rsp_valid[m]           = 1'b1;
          m_rsp_err[m]             = s_rsp_err[s];
          m_rsp_rdata[m*32 +: 32]  = s_rsp_rdata[s*32 +: 32];
        end
      end
      if (m_err_rsp[m]) begin
        m_rsp_valid[m]          = 1'b1;
        m_rsp_err[m]            = 1'b1;
        m_rsp_rdata[m*32 +: 32] = 32'hDEAD_BEEF;
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_pending        <= '0;
      m_err_rsp        <= '0;
      decode_err_count <= '0;
    end else begin
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) m_pending[m] <= 1'b1;
        else if (m_rsp_valid[m])              m_pending[m] <= 1'b0;
        m_err_rsp[m] <= dec_err_accept[m];
      end
      if ((|dec_err_accept) && (decode_err_count != 16'hFFFF))
        decode_err_count <= decode_err_count + 16'd1;
    end
  end
endmodule
