// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_host_if  (STAND-IN INTEGRATION RTL)
// Synchronous 4-phase host register/memory port (fabric master 0).
//   host raises host_req with {we, addr, wdata}; the port performs the access,
//   presents {rdata, err} and raises host_ack; host drops host_req; port drops
//   host_ack. host_addr[15:12] == 4'h4 selects the CSR window (addr[7:0]);
//   everything else is a fabric access.
// All host-side inputs are registered once (synchronous to clk; constrained in
// the SDC with input delays). Outputs are driven from flops.
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_host_if (
  input  logic        clk,
  input  logic        rst_n,
  // pins
  input  logic        host_req,
  input  logic        host_we,
  input  logic [15:0] host_addr,
  input  logic [31:0] host_wdata,
  output logic        host_ack,
  output logic [31:0] host_rdata,
  output logic        host_err,
  // fabric master
  output logic        m_req_valid,
  input  logic        m_req_ready,
  output logic        m_req_we,
  output logic [15:0] m_req_addr,
  output logic [31:0] m_req_wdata,
  input  logic        m_rsp_valid,
  input  logic        m_rsp_err,
  input  logic [31:0] m_rsp_rdata,
  // CSR bus (single-cycle)
  output logic        csr_valid,
  output logic        csr_we,
  output logic [7:0]  csr_addr,
  output logic [31:0] csr_wdata,
  input  logic        csr_hit,
  input  logic [31:0] csr_rdata
);
  typedef enum logic [1:0] {H_IDLE, H_FREQ, H_FWAIT, H_ACK} hstate_t;
  hstate_t hs;
  logic        req_r, we_r;
  logic [15:0] addr_r;
  logic [31:0] wdata_r;
  logic        we_q;
  logic [15:0] addr_q;
  logic [31:0] wdata_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_r <= 1'b0; we_r <= 1'b0; addr_r <= '0; wdata_r <= '0;
    end else begin
      req_r <= host_req; we_r <= host_we; addr_r <= host_addr; wdata_r <= host_wdata;
    end
  end

  logic is_csr;
  assign is_csr      = (addr_r[15:12] == 4'h4);
  assign csr_valid   = (hs == H_IDLE) && req_r && is_csr;
  assign csr_we      = we_r;
  assign csr_addr    = addr_r[7:0];
  assign csr_wdata   = wdata_r;

  assign m_req_valid = (hs == H_FREQ);
  assign m_req_we    = we_q;
  assign m_req_addr  = addr_q;
  assign m_req_wdata = wdata_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hs <= H_IDLE; we_q <= 1'b0; addr_q <= '0; wdata_q <= '0;
      host_ack <= 1'b0; host_rdata <= '0; host_err <= 1'b0;
    end else begin
      case (hs)
        H_IDLE: if (req_r) begin
          if (is_csr) begin
            host_rdata <= we_r ? 32'h0 : csr_rdata;
            host_err   <= !csr_hit;
            host_ack   <= 1'b1;
            hs         <= H_ACK;
          end else begin
            we_q <= we_r; addr_q <= addr_r; wdata_q <= wdata_r;
            hs   <= H_FREQ;
          end
        end
        H_FREQ:  if (m_req_ready) hs <= H_FWAIT;
        H_FWAIT: if (m_rsp_valid) begin
          host_rdata <= m_rsp_rdata;
          host_err   <= m_rsp_err;
          host_ack   <= 1'b1;
          hs         <= H_ACK;
        end
        H_ACK: if (!req_r) begin
          host_ack <= 1'b0;
          hs       <= H_IDLE;
        end
        default: hs <= H_IDLE;
      endcase
    end
  end
endmodule
