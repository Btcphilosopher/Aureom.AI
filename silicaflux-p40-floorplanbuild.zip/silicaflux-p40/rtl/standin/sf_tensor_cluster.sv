// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_tensor_cluster  (STAND-IN INTEGRATION RTL)
// 4x4 output-stationary INT8 systolic array (INT32 accumulation) with three
// private SRAM banks: TA (A, row-major), TB (B, column-major), TC (C results).
// Mirrors the TENSORCORE baseline (4x4 INT8 MAC, INT32 accumulate).
//
//   TA[a+i] = {A[i][3], A[i][2], A[i][1], A[i][0]}      (byte k = A[i][k])
//   TB[b+j] = {B[3][j], B[2][j], B[1][j], B[0][j]}      (byte k = B[k][j])
//   TC[c + 4*i + j] = C[i][j] (+= previous C[i][j] if cmd_acc)
//
// Wavefront: at compute step s, row i is fed A[i][s-i] and column j is fed
// B[s-j][j] (zero outside 0..K-1); PE(i,j) therefore multiplies
// A[i][k] * B[k][j] with k = s-i-j. Steps s = 0 .. K+R+C-3 (10 steps).
//
// The PE array runs on a gated clock enabled only for compute steps that the
// power manager allows (thermal throttling stretches the wavefront in time but
// never alters the arithmetic).
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_tensor_cluster #(
  parameter int DEPTH = 64,
  parameter int AW    = $clog2(DEPTH)
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        test_mode,
  // fabric slave
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_we,
  input  logic [15:0] req_addr,
  input  logic [31:0] req_wdata,
  output logic        rsp_valid,
  output logic        rsp_err,
  output logic [31:0] rsp_rdata,
  // command
  input  logic        cmd_start,
  input  logic        cmd_acc,
  input  logic [15:0] cmd_a,
  input  logic [15:0] cmd_b,
  input  logic [15:0] cmd_c,
  output logic        cmd_done,
  output logic        cmd_err,
  output logic        busy,
  output logic        computing,
  // power manager step permission (domain enable & thermal throttle)
  input  logic        step_allow
);
  localparam int R = 4, C = 4, K = 4;
  localparam int NSTEP = K + R + C - 2;   // 10

  typedef enum logic [2:0] {S_IDLE, S_LOAD, S_LWAIT, S_COMP, S_DRAIN, S_DONE} state_t;
  state_t state;

  logic [AW:0] a_q, b_q, c_q;
  logic        acc_q;
  logic [2:0]  lk;          // load issue index
  logic        lv;          // load data valid this cycle
  logic [1:0]  lk_d;        // index of data arriving
  logic [3:0]  step;
  logic [4:0]  dn;          // drain index 0..15

  logic [32*R-1:0] a_word;  // rows of A
  logic [32*C-1:0] b_word;  // columns of B

  // ---------------- banks ----------------
  logic          ta_ce, ta_we, tb_ce, tb_we, tc_ce, tc_we;
  logic [AW-1:0] ta_addr, tb_addr, tc_addr;
  logic [31:0]   ta_wd, tb_wd, tc_wd, ta_rd, tb_rd, tc_rd;

  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_a (.clk(clk), .ce(ta_ce), .we(ta_we),
    .addr(ta_addr), .wdata(ta_wd), .wmask(32'hFFFF_FFFF), .rdata(ta_rd));
  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_b (.clk(clk), .ce(tb_ce), .we(tb_we),
    .addr(tb_addr), .wdata(tb_wd), .wmask(32'hFFFF_FFFF), .rdata(tb_rd));
  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank_c (.clk(clk), .ce(tc_ce), .we(tc_we),
    .addr(tc_addr), .wdata(tc_wd), .wmask(32'hFFFF_FFFF), .rdata(tc_rd));

  // ---------------- PE array (gated clock) ----------------
  logic do_step, clear_acc, gclk_pe;
  assign computing = (state == S_COMP);
  assign do_step   = computing && step_allow;
  assign clear_acc = do_step && (step == 4'd0) && !acc_q;
  sf_icg u_cg_pe (.clk(clk), .en(do_step), .test_en(test_mode), .gclk(gclk_pe));

  logic [8*R-1:0]    a_edge;
  logic [8*C-1:0]    b_edge;
  logic [8*R*C-1:0]  pe_a_out, pe_b_out;
  logic [32*R*C-1:0] pe_acc;

  // edge feed: row i gets A[i][s-i], column j gets B[s-j][j]
  always_comb begin
    a_edge = '0;
    b_edge = '0;
    for (int i = 0; i < R; i++)
      for (int k = 0; k < K; k++)
        if ({1'b0, step} == 5'(i + k)) a_edge[8*i +: 8] = a_word[32*i + 8*k +: 8];
    for (int j = 0; j < C; j++)
      for (int k = 0; k < K; k++)
        if ({1'b0, step} == 5'(j + k)) b_edge[8*j +: 8] = b_word[32*j + 8*k +: 8];
  end

  genvar gi, gj;
  generate
    for (gi = 0; gi < R; gi++) begin : g_row
      for (gj = 0; gj < C; gj++) begin : g_col
        logic [7:0] a_in, b_in;
        if (gj == 0) begin : g_aedge
          assign a_in = a_edge[8*gi +: 8];
        end else begin : g_apass
          assign a_in = pe_a_out[8*(gi*C + gj - 1) +: 8];
        end
        if (gi == 0) begin : g_bedge
          assign b_in = b_edge[8*gj +: 8];
        end else begin : g_bpass
          assign b_in = pe_b_out[8*((gi-1)*C + gj) +: 8];
        end
        sf_tensor_pe u_pe (
          .clk   (gclk_pe),
          .rst_n (rst_n),
          .clear (clear_acc),
          .a_in  (a_in),
          .b_in  (b_in),
          .a_out (pe_a_out[8*(gi*C + gj) +: 8]),
          .b_out (pe_b_out[8*(gi*C + gj) +: 8]),
          .acc   (pe_acc[32*(gi*C + gj) +: 32])
        );
      end
    end
  endgenerate

  // ---------------- command validation ----------------
  logic args_ok;
  always_comb begin
    args_ok = (({1'b0, cmd_a} + 17'd4)  <= 17'(DEPTH))
           && (({1'b0, cmd_b} + 17'd4)  <= 17'(DEPTH))
           && (({1'b0, cmd_c} + 17'd16) <= 17'(DEPTH));
  end

  // ---------------- control FSM ----------------
  assign busy = (state != S_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; a_q <= '0; b_q <= '0; c_q <= '0; acc_q <= 1'b0;
      lk <= '0; lv <= 1'b0; lk_d <= '0; step <= '0; dn <= '0;
      a_word <= '0; b_word <= '0; cmd_done <= 1'b0; cmd_err <= 1'b0;
    end else begin
      cmd_done <= 1'b0;
      cmd_err  <= 1'b0;
      lv       <= (state == S_LOAD);
      lk_d     <= lk[1:0];
      if (lv) begin
        a_word[32*lk_d +: 32] <= ta_rd;
        b_word[32*lk_d +: 32] <= tb_rd;
      end
      case (state)
        S_IDLE: if (cmd_start) begin
          if (args_ok) begin
            a_q   <= (AW+1)'(cmd_a);
            b_q   <= (AW+1)'(cmd_b);
            c_q   <= (AW+1)'(cmd_c);
            acc_q <= cmd_acc;
            lk    <= '0;
            state <= S_LOAD;
          end else begin
            cmd_done <= 1'b1;
            cmd_err  <= 1'b1;
          end
        end
        S_LOAD: begin
          if (lk == 3'd3) state <= S_LWAIT;
          lk <= lk + 3'd1;
        end
        S_LWAIT: if (!lv) begin       // last row/column captured
          step  <= '0;
          state <= S_COMP;
        end
        S_COMP: if (do_step) begin
          if (step == 4'(NSTEP - 1)) begin
            dn    <= '0;
            state <= S_DRAIN;
          end else begin
            step <= step + 4'd1;
          end
        end
        S_DRAIN: begin
          if (dn == 5'd15) state <= S_DONE;
          dn <= dn + 5'd1;
        end
        S_DONE: begin
          cmd_done <= 1'b1;
          state    <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  // ---------------- bank port arbitration ----------------
  logic       f_acc, f_ok, rsp_pend, rsp_bad, rsp_was_write;
  logic [1:0] f_bank, rsp_bank;
  assign req_ready = (state == S_IDLE);
  assign f_acc     = req_valid & req_ready;
  assign f_bank    = req_addr[9:8];
  assign f_ok      = ({8'h00, req_addr[7:0]} < 16'(DEPTH)) && (f_bank != 2'd3);

  always_comb begin
    ta_ce = 1'b0; ta_we = 1'b0; ta_addr = '0; ta_wd = req_wdata;
    tb_ce = 1'b0; tb_we = 1'b0; tb_addr = '0; tb_wd = req_wdata;
    tc_ce = 1'b0; tc_we = 1'b0; tc_addr = '0; tc_wd = req_wdata;
    if (state == S_LOAD) begin
      ta_ce = 1'b1; ta_addr = AW'(a_q + (AW+1)'(lk));
      tb_ce = 1'b1; tb_addr = AW'(b_q + (AW+1)'(lk));
    end else if (state == S_DRAIN) begin
      tc_ce = 1'b1; tc_we = 1'b1; tc_addr = AW'(c_q + (AW+1)'(dn));
      tc_wd = pe_acc[32*dn[3:0] +: 32];
    end else if (state == S_IDLE && f_acc && f_ok) begin
      case (f_bank)
        2'd0: begin ta_ce = 1'b1; ta_we = req_we; ta_addr = req_addr[AW-1:0]; end
        2'd1: begin tb_ce = 1'b1; tb_we = req_we; tb_addr = req_addr[AW-1:0]; end
        2'd2: begin tc_ce = 1'b1; tc_we = req_we; tc_addr = req_addr[AW-1:0]; end
        default: ;
      endcase
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_pend <= 1'b0; rsp_bank <= '0; rsp_bad <= 1'b0; rsp_was_write <= 1'b0;
    end else begin
      rsp_pend <= f_acc;
      if (f_acc) begin
        rsp_bank      <= f_bank;
        rsp_bad       <= !f_ok;
        rsp_was_write <= req_we;
      end
    end
  end

  assign rsp_valid = rsp_pend;
  assign rsp_err   = rsp_bad;
  always_comb begin
    rsp_rdata = 32'h0;
    if (!rsp_bad && !rsp_was_write) begin
      case (rsp_bank)
        2'd0: rsp_rdata = ta_rd;
        2'd1: rsp_rdata = tb_rd;
        2'd2: rsp_rdata = tc_rd;
        default: rsp_rdata = 32'h0;
      endcase
    end
  end
endmodule

// -----------------------------------------------------------------------------
// Output-stationary INT8 x INT8 -> INT32 MAC processing element.
// -----------------------------------------------------------------------------
module sf_tensor_pe (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        clear,
  input  logic [7:0]  a_in,
  input  logic [7:0]  b_in,
  output logic [7:0]  a_out,
  output logic [7:0]  b_out,
  output logic [31:0] acc
);
  logic signed [15:0] prod;
  assign prod = $signed(a_in) * $signed(b_in);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      a_out <= '0; b_out <= '0; acc <= '0;
    end else begin
      a_out <= a_in;
      b_out <= b_in;
      acc   <= (clear ? 32'd0 : acc) + {{16{prod[15]}}, prod};
    end
  end
endmodule
