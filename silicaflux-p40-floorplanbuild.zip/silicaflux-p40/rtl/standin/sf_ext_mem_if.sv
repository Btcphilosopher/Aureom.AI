// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_ext_mem_if  (STAND-IN INTEGRATION RTL)
// Fabric slave bridging the 0x8000-0xFFFF window to an off-chip 4-phase
// memory port. RAS: a watchdog converts a missing/stuck ext_ack into an error
// response after TIMEOUT cycles and counts the event.
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_ext_mem_if #(
  parameter int TIMEOUT = 1024
) (
  input  logic        clk,
  input  logic        rst_n,
  // fabric slave
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_we,
  input  logic [15:0] req_addr,
  input  logic [31:0] req_wdata,
  output logic        rsp_valid,
  output logic        rsp_err,
  output logic [31:0] rsp_rdata,
  // pins
  output logic        ext_req,
  output logic        ext_we,
  output logic [14:0] ext_addr,
  output logic [31:0] ext_wdata,
  input  logic        ext_ack,
  input  logic [31:0] ext_rdata,
  // RAS
  output logic [15:0] timeout_count
);
  typedef enum logic [1:0] {X_IDLE, X_WAIT, X_RELEASE} xstate_t;
  xstate_t xs;
  logic        ack_r;
  logic [31:0] rdata_r;
  logic [10:0] wd;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ack_r <= 1'b0; rdata_r <= '0; end
    else        begin ack_r <= ext_ack; rdata_r <= ext_rdata; end
  end

  assign req_ready = (xs == X_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      xs <= X_IDLE; ext_req <= 1'b0; ext_we <= 1'b0; ext_addr <= '0; ext_wdata <= '0;
      rsp_valid <= 1'b0; rsp_err <= 1'b0; rsp_rdata <= '0; wd <= '0; timeout_count <= '0;
    end else begin
      rsp_valid <= 1'b0;
      case (xs)
        X_IDLE: if (req_valid) begin
          ext_req   <= 1'b1;
          ext_we    <= req_we;
          ext_addr  <= req_addr[14:0];
          ext_wdata <= req_wdata;
          wd        <= '0;
          xs        <= X_WAIT;
        end
        X_WAIT: begin
          wd <= wd + 11'd1;
          if (ack_r) begin
            rsp_valid <= 1'b1;
            rsp_err   <= 1'b0;
            rsp_rdata <= ext_we ? 32'h0 : rdata_r;
            ext_req   <= 1'b0;
            wd        <= '0;
            xs        <= X_RELEASE;
          end else if ({21'd0, wd} == TIMEOUT - 1) begin
            rsp_valid <= 1'b1;
            rsp_err   <= 1'b1;
            rsp_rdata <= 32'h0;
            ext_req   <= 1'b0;
            wd        <= '0;
            if (timeout_count != 16'hFFFF) timeout_count <= timeout_count + 16'd1;
            xs        <= X_RELEASE;
          end
        end
        X_RELEASE: begin
          wd <= wd + 11'd1;
          if (!ack_r || ({21'd0, wd} == TIMEOUT - 1)) xs <= X_IDLE;
        end
        default: xs <= X_IDLE;
      endcase
    end
  end
endmodule
