// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_test_ras  (STAND-IN INTEGRATION RTL)
// IEEE 1149.1-style TAP (TCK domain) giving IDCODE, BYPASS and a coherent
// snapshot of RAS/status state from the core clock domain.
//
// CDC scheme for STATUS (multi-bit, so no per-bit synchronisers):
//   * Loading IR=STATUS raises snap_req (TCK domain level).
//   * The core domain freezes `snapshot` while its synchronised snap_req is high
//     and reflects that back as snap_ack.
//   * Capture-DR samples {snap_ack_sync, snapshot[30:0]}. Bit 31 = 1 guarantees
//     the frozen value was stable before capture. Requires a few core-clock
//     cycles between Update-IR and Capture-DR (TCK well below f_clk).
// IDCODE value is a placeholder with manufacturer field 0 (no JEDEC ID claimed).
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_test_ras #(
  parameter logic [31:0] IDCODE = 32'h15F4_0001
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [30:0] status_in,     // core domain
  input  logic        tck,
  input  logic        tms,
  input  logic        tdi,
  input  logic        trst_n,
  output logic        tdo
);
  // ---------------- TAP state machine ----------------
  localparam logic [3:0]
    TLR = 4'h0, RTI = 4'h1, SDR = 4'h2, CDR = 4'h3, SHDR = 4'h4, E1DR = 4'h5,
    PDR = 4'h6, E2DR = 4'h7, UDR = 4'h8, SIR = 4'h9, CIR = 4'hA, SHIR = 4'hB,
    E1IR = 4'hC, PIR = 4'hD, E2IR = 4'hE, UIR = 4'hF;
  localparam logic [3:0] IR_IDCODE = 4'b0001, IR_STATUS = 4'b0010, IR_BYPASS = 4'b1111;

  logic        snap_req_t;      // TCK domain
  logic        snap_req_c;      // core domain (synchronised)
  logic [30:0] snapshot_q;      // core domain, frozen while snap_req_c
  logic [3:0]  st, st_n;
  logic [3:0]  ir, ir_sh;
  logic [31:0] dr_sh;
  logic        snap_ack_t;

  always_comb begin
    case (st)
      TLR:  st_n = tms ? TLR  : RTI;
      RTI:  st_n = tms ? SDR  : RTI;
      SDR:  st_n = tms ? SIR  : CDR;
      CDR:  st_n = tms ? E1DR : SHDR;
      SHDR: st_n = tms ? E1DR : SHDR;
      E1DR: st_n = tms ? UDR  : PDR;
      PDR:  st_n = tms ? E2DR : PDR;
      E2DR: st_n = tms ? UDR  : SHDR;
      UDR:  st_n = tms ? SDR  : RTI;
      SIR:  st_n = tms ? TLR  : CIR;
      CIR:  st_n = tms ? E1IR : SHIR;
      SHIR: st_n = tms ? E1IR : SHIR;
      E1IR: st_n = tms ? UIR  : PIR;
      PIR:  st_n = tms ? E2IR : PIR;
      E2IR: st_n = tms ? UIR  : SHIR;
      default: st_n = tms ? SDR : RTI;   // UIR
    endcase
  end

  logic [4:0] dr_len_m1;
  always_comb begin
    case (ir)
      IR_IDCODE, IR_STATUS: dr_len_m1 = 5'd31;
      default:              dr_len_m1 = 5'd0;   // BYPASS and unknown
    endcase
  end

  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) begin
      st <= TLR; ir <= IR_IDCODE; ir_sh <= '0; dr_sh <= '0;
    end else begin
      st <= st_n;
      case (st)
        TLR:  ir <= IR_IDCODE;
        CIR:  ir_sh <= 4'b0101;
        SHIR: ir_sh <= {tdi, ir_sh[3:1]};
        UIR:  ir <= ir_sh;
        CDR: begin
          case (ir)
            IR_IDCODE: dr_sh <= IDCODE;
            IR_STATUS: dr_sh <= {snap_ack_t, snapshot_q};
            default:   dr_sh <= 32'h0;
          endcase
        end
        SHDR: begin
          if (dr_len_m1 == 5'd0) dr_sh[0] <= tdi;
          else                   dr_sh <= {tdi, dr_sh[31:1]};
        end
        default: ;
      endcase
    end
  end

  // TDO changes on the falling edge of TCK
  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n) tdo <= 1'b0;
    else if (st == SHIR) tdo <= ir_sh[0];
    else if (st == SHDR) tdo <= dr_sh[0];
    else tdo <= 1'b0;
  end

  // ---------------- snapshot handshake ----------------

  assign snap_req_t = (ir == IR_STATUS);

  sf_sync2 u_req_sync (.clk(clk), .rst_n(rst_n), .d(snap_req_t), .q(snap_req_c));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)          snapshot_q <= '0;
    else if (!snap_req_c) snapshot_q <= status_in;
  end
  sf_sync2 u_ack_sync (.clk(tck), .rst_n(trst_n), .d(snap_req_c), .q(snap_ack_t));
endmodule
