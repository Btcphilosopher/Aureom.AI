// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_scratchpad  (STAND-IN INTEGRATION RTL)
// Shared single-bank SRAM scratchpad, fabric slave (window 0x3000-0x3FFF).
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_scratchpad #(
  parameter int DEPTH = 256,
  parameter int AW    = $clog2(DEPTH)
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_we,
  input  logic [15:0] req_addr,
  input  logic [31:0] req_wdata,
  output logic        rsp_valid,
  output logic        rsp_err,
  output logic [31:0] rsp_rdata
);
  logic ok, pend, bad, wr;
  logic [31:0] rd;
  assign req_ready = 1'b1;
  assign ok = ({4'h0, req_addr[11:0]} < 16'(DEPTH));
  sf_sram_sp #(.DEPTH(DEPTH), .WIDTH(32)) u_bank (.clk(clk), .ce(req_valid && ok),
    .we(req_we), .addr(req_addr[AW-1:0]), .wdata(req_wdata), .wmask(32'hFFFF_FFFF),
    .rdata(rd));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin pend <= 1'b0; bad <= 1'b0; wr <= 1'b0; end
    else begin
      pend <= req_valid;
      if (req_valid) begin bad <= !ok; wr <= req_we; end
    end
  end
  assign rsp_valid = pend;
  assign rsp_err   = bad;
  assign rsp_rdata = (bad || wr) ? 32'h0 : rd;
endmodule
