// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_control_core  (STAND-IN INTEGRATION RTL)
// Command processor: fetches 4-word commands from a 16-entry ring held in its
// private command SRAM (fabric slave 0, word address 0x0000-0x003F) through the
// fabric (it is also fabric master 1), dispatches them to DMA / vector / tensor
// engines, and retires them in order.
//
// Command words:
//   w0[31:28] opcode   0 NOP | 1 DMA | 2 VEC | 3 TEN | 4 IRQ
//   w0[27:24] vec op (VEC) / bit24 accumulate (TEN)
//   w0[19:16] cluster index (VEC/TEN)
//   w0[15:0]  length (DMA words / VEC elements)
//   w1[15:0]  src / A offset    w2[15:0] dst / B offset    w3[15:0] C offset
//
// Errors halt the queue (head still advances past the failing command); the
// host clears the halt via CSR IRQ bit1.  Error codes:
//   1 bad opcode  2 bad cluster  3 engine clock domain disabled
//   4 engine argument/bounds error  5 command fetch fabric error  6 DMA error
//
// CSRs (word offsets inside the host CSR window):
//   0x00 ID  0x01 CTRL  0x02 CMD_TAIL  0x03 CMD_HEAD  0x04 STATUS
//   0x05 DONE_COUNT  0x06 IRQ(W1C)  0x07 ERR_COUNT  0x0F SCRATCH
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module sf_control_core #(
  parameter int NV = 1,
  parameter int NT = 1,
  parameter logic [31:0] CHIP_ID = 32'h5346_4001
) (
  input  logic          clk,
  input  logic          rst_n,
  // fabric master (command fetch)
  output logic          m_req_valid,
  input  logic          m_req_ready,
  output logic          m_req_we,
  output logic [15:0]   m_req_addr,
  output logic [31:0]   m_req_wdata,
  input  logic          m_rsp_valid,
  input  logic          m_rsp_err,
  input  logic [31:0]   m_rsp_rdata,
  // fabric slave (command RAM)
  input  logic          s_req_valid,
  output logic          s_req_ready,
  input  logic          s_req_we,
  input  logic [15:0]   s_req_addr,
  input  logic [31:0]   s_req_wdata,
  output logic          s_rsp_valid,
  output logic          s_rsp_err,
  output logic [31:0]   s_rsp_rdata,
  // CSR bus
  input  logic          csr_valid,
  input  logic          csr_we,
  input  logic [7:0]    csr_addr,
  input  logic [31:0]   csr_wdata,
  output logic          csr_hit,
  output logic [31:0]   csr_rdata,
  // DMA
  output logic          dma_start,
  output logic [15:0]   dma_src,
  output logic [15:0]   dma_dst,
  output logic [15:0]   dma_len,
  input  logic          dma_done,
  input  logic          dma_err,
  // vector clusters (shared argument bus, per-cluster start)
  output logic [NV-1:0] vec_start,
  output logic [3:0]    eng_op,
  output logic          eng_acc,
  output logic [15:0]   eng_len,
  output logic [15:0]   eng_a,
  output logic [15:0]   eng_b,
  output logic [15:0]   eng_c,
  input  logic [NV-1:0] vec_done,
  input  logic [NV-1:0] vec_err,
  // tensor clusters
  output logic [NT-1:0] ten_start,
  input  logic [NT-1:0] ten_done,
  input  logic [NT-1:0] ten_err,
  // power-manager domain enables
  input  logic          pm_vec_en,
  input  logic          pm_ten_en,
  // status
  output logic          irq,
  output logic          busy,
  output logic          halted,
  output logic [15:0]   done_count,
  output logic [15:0]   err_count
);
  localparam logic [3:0] OPC_NOP = 4'd0, OPC_DMA = 4'd1, OPC_VEC = 4'd2,
                         OPC_TEN = 4'd3, OPC_IRQ = 4'd4;
  localparam logic [3:0] E_OPC = 4'd1, E_CLUSTER = 4'd2, E_DISABLED = 4'd3,
                         E_ENGINE = 4'd4, E_FETCH = 4'd5, E_DMA = 4'd6;

  // ---------------- command RAM (fabric slave 0) ----------------
  logic        cr_ce, cr_we, cr_pend, cr_bad, cr_wr;
  logic [5:0]  cr_addr;
  logic [31:0] cr_rd;
  assign s_req_ready = 1'b1;
  assign cr_ce   = s_req_valid && (s_req_addr[11:6] == 6'd0);
  assign cr_we   = s_req_we;
  assign cr_addr = s_req_addr[5:0];
  sf_sram_sp #(.DEPTH(64), .WIDTH(32)) u_cmdram (.clk(clk), .ce(cr_ce), .we(cr_we),
    .addr(cr_addr), .wdata(s_req_wdata), .wmask(32'hFFFF_FFFF), .rdata(cr_rd));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cr_pend <= 1'b0; cr_bad <= 1'b0; cr_wr <= 1'b0;
    end else begin
      cr_pend <= s_req_valid;
      if (s_req_valid) begin
        cr_bad <= (s_req_addr[11:6] != 6'd0);
        cr_wr  <= s_req_we;
      end
    end
  end
  assign s_rsp_valid = cr_pend;
  assign s_rsp_err   = cr_bad;
  assign s_rsp_rdata = (cr_bad || cr_wr) ? 32'h0 : cr_rd;

  // ---------------- CSRs ----------------
  logic        enable;
  logic [4:0]  tail, head;
  logic [31:0] scratch;
  logic [3:0]  last_err;
  logic        irq_pend;

  // ---------------- command FSM ----------------
  typedef enum logic [2:0] {C_IDLE, C_FREQ, C_FWAIT, C_EXEC, C_WAIT, C_RETIRE} cstate_t;
  cstate_t cs;
  logic [1:0]  wi;
  logic [31:0] w0, w1, w2, w3;
  logic [3:0]  opc;
  logic [3:0]  cl;
  logic [1:0]  kind;          // 0 dma 1 vec 2 ten
  logic        cmd_fail;
  logic [3:0]  cmd_code;
  logic        raise_irq;

  assign opc = w0[31:28];
  assign cl  = w0[19:16];
  assign busy = (cs != C_IDLE);

  assign m_req_valid = (cs == C_FREQ);
  assign m_req_we    = 1'b0;
  assign m_req_wdata = 32'h0;
  assign m_req_addr  = {10'd0, head[3:0], wi};

  assign eng_op  = w0[27:24];
  assign eng_acc = w0[24];
  assign eng_len = w0[15:0];
  assign eng_a   = w1[15:0];
  assign eng_b   = w2[15:0];
  assign eng_c   = w3[15:0];
  assign dma_src = w1[15:0];
  assign dma_dst = w2[15:0];
  assign dma_len = w0[15:0];

  logic sel_done, sel_err;
  always_comb begin
    sel_done = 1'b0;
    sel_err  = 1'b0;
    case (kind)
      2'd0: begin sel_done = dma_done; sel_err = dma_err; end
      2'd1: for (int v = 0; v < NV; v++)
              if (cl == 4'(v)) begin sel_done = vec_done[v]; sel_err = vec_err[v]; end
      2'd2: for (int t = 0; t < NT; t++)
              if (cl == 4'(t)) begin sel_done = ten_done[t]; sel_err = ten_err[t]; end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cs <= C_IDLE; wi <= '0; w0 <= '0; w1 <= '0; w2 <= '0; w3 <= '0;
      kind <= '0; cmd_fail <= 1'b0; cmd_code <= '0; raise_irq <= 1'b0;
      dma_start <= 1'b0; vec_start <= '0; ten_start <= '0;
      head <= '0; done_count <= '0; err_count <= '0; halted <= 1'b0;
      last_err <= '0; irq_pend <= 1'b0;
      enable <= 1'b0; tail <= '0; scratch <= '0;
    end else begin
      dma_start <= 1'b0;
      vec_start <= '0;
      ten_start <= '0;

      // ---- CSR writes ----
      if (csr_valid && csr_we) begin
        case (csr_addr)
          8'h01: enable  <= csr_wdata[0];
          8'h02: tail    <= csr_wdata[4:0];
          8'h06: begin
                   if (csr_wdata[0]) irq_pend <= 1'b0;
                   if (csr_wdata[1]) begin halted <= 1'b0; last_err <= '0; end
                 end
          8'h0F: scratch <= csr_wdata;
          default: ;
        endcase
      end

      case (cs)
        C_IDLE: if (enable && !halted && (head != tail)) begin
          wi <= '0;
          cs <= C_FREQ;
        end
        C_FREQ: if (m_req_ready) cs <= C_FWAIT;
        C_FWAIT: if (m_rsp_valid) begin
          case (wi)
            2'd0: w0 <= m_rsp_rdata;
            2'd1: w1 <= m_rsp_rdata;
            2'd2: w2 <= m_rsp_rdata;
            default: w3 <= m_rsp_rdata;
          endcase
          if (m_rsp_err) begin
            cmd_fail <= 1'b1; cmd_code <= E_FETCH; raise_irq <= 1'b0;
            cs <= C_RETIRE;
          end else if (wi == 2'd3) begin
            cs <= C_EXEC;
          end else begin
            wi <= wi + 2'd1;
            cs <= C_FREQ;
          end
        end
        C_EXEC: begin
          cmd_fail  <= 1'b0;
          cmd_code  <= '0;
          raise_irq <= 1'b0;
          cs        <= C_RETIRE;
          case (opc)
            OPC_NOP: ;
            OPC_IRQ: raise_irq <= 1'b1;
            OPC_DMA: begin
              kind <= 2'd0; dma_start <= 1'b1; cs <= C_WAIT;
            end
            OPC_VEC: begin
              if ({28'd0, cl} >= NV)  begin cmd_fail <= 1'b1; cmd_code <= E_CLUSTER;  end
              else if (!pm_vec_en)    begin cmd_fail <= 1'b1; cmd_code <= E_DISABLED; end
              else begin
                kind <= 2'd1;
                for (int v = 0; v < NV; v++) if (cl == 4'(v)) vec_start[v] <= 1'b1;
                cs <= C_WAIT;
              end
            end
            OPC_TEN: begin
              if ({28'd0, cl} >= NT)  begin cmd_fail <= 1'b1; cmd_code <= E_CLUSTER;  end
              else if (!pm_ten_en)    begin cmd_fail <= 1'b1; cmd_code <= E_DISABLED; end
              else begin
                kind <= 2'd2;
                for (int t = 0; t < NT; t++) if (cl == 4'(t)) ten_start[t] <= 1'b1;
                cs <= C_WAIT;
              end
            end
            default: begin cmd_fail <= 1'b1; cmd_code <= E_OPC; end
          endcase
        end
        C_WAIT: if (sel_done) begin
          if (sel_err) begin
            cmd_fail <= 1'b1;
            cmd_code <= (kind == 2'd0) ? E_DMA : E_ENGINE;
          end
          cs <= C_RETIRE;
        end
        C_RETIRE: begin
          head       <= head + 5'd1;
          done_count <= done_count + 16'd1;
          if (cmd_fail) begin
            halted    <= 1'b1;
            last_err  <= cmd_code;
            irq_pend  <= 1'b1;
            if (err_count != 16'hFFFF) err_count <= err_count + 16'd1;
          end else if (raise_irq) begin
            irq_pend <= 1'b1;
          end
          cs <= C_IDLE;
        end
        default: cs <= C_IDLE;
      endcase
    end
  end

  assign irq = irq_pend;

  // ---------------- CSR read mux ----------------
  always_comb begin
    csr_hit   = 1'b1;
    csr_rdata = 32'h0;
    case (csr_addr)
      8'h00: csr_rdata = CHIP_ID;
      8'h01: csr_rdata = {31'd0, enable};
      8'h02: csr_rdata = {27'd0, tail};
      8'h03: csr_rdata = {27'd0, head};
      8'h04: csr_rdata = {16'd0, 4'd0, last_err, 5'd0, irq_pend, halted, busy};
      8'h05: csr_rdata = {16'd0, done_count};
      8'h06: csr_rdata = {31'd0, irq_pend};
      8'h07: csr_rdata = {16'd0, err_count};
      8'h0F: csr_rdata = scratch;
      default: csr_hit = 1'b0;
    endcase
  end
endmodule
