"""EDA smoke tier: lint, RTL simulation, elaboration failures, netlist generation."""
import subprocess

import pytest
import yaml

from conftest import need
from sfpd import synth
from sfpd.config import load_config
from sfpd.util import PHYS_DIR, REPO_ROOT, PipelineError, resolve_filelist

pytestmark = pytest.mark.eda


@need("verilator")
def test_verilator_lint_clean(min_cfg, tech, tmp_path):
    out = synth.lint(min_cfg, tech, tmp_path)
    assert out["passed"] and out["warnings"] == []


@need("iverilog", "vvp")
@pytest.mark.parametrize("binding", ["sim_behav.f", "tech"])
def test_rtl_system_testbench_min(min_cfg, tech, tmp_path, binding):
    files = []
    for fl in min_cfg.rtl_filelists():
        files += resolve_filelist(fl)
    if binding == "tech":
        files += resolve_filelist(REPO_ROOT / tech.raw["rtl_binding_filelist"])
        files += resolve_filelist(REPO_ROOT / tech.raw["sim_cell_filelist"])
    else:
        files += resolve_filelist(REPO_ROOT / "rtl/filelists" / binding)
    vvp = tmp_path / "tb.vvp"
    subprocess.run(["iverilog", "-g2012", "-o", str(vvp), "-s", "tb_silicaflux", *map(str, files),
                    str(REPO_ROOT / "tb/tb_silicaflux.sv")], check=True, capture_output=True)
    out = subprocess.run(["vvp", "-n", str(vvp)], capture_output=True, text=True, timeout=600).stdout
    assert "TB_RESULT PASS" in out, out[-2000:]


def _yosys(script):
    return subprocess.run(["yosys", "-q", "-p", script], capture_output=True, text=True)


@need("yosys")
def test_unsupported_sram_geometry_fails_clearly(tech):
    wrapper = REPO_ROOT / "rtl/physical/tech/nangate45/sf_sram_sp_nangate45.sv"
    libs = " ".join(f"read_liberty -lib {p};" for p in tech.all_libs())
    r = _yosys(f"{libs} read_verilog -sv {wrapper}; hierarchy -check -top sf_sram_sp -chparam DEPTH 48")
    assert r.returncode != 0
    assert "SF_MISSING_NANGATE45_SRAM_MACRO_FOR_REQUESTED_GEOMETRY" in (r.stdout + r.stderr)


@need("yosys")
def test_netlist_generation_smoke(tech, tmp_path):
    """Map a real block (tensor PE) onto Nangate45 cells; every cell must be a library cell."""
    lib = tech.all_libs(macro_names=[])[0]
    out = tmp_path / "pe.v"
    src = REPO_ROOT / "rtl/standin/sf_tensor_cluster.sv"
    r = _yosys(f"read_verilog -sv {src}; hierarchy -top sf_tensor_pe; synth -top sf_tensor_pe; "
               f"dfflibmap -liberty {lib}; abc -liberty {lib}; opt_clean; write_verilog -noattr {out}")
    assert r.returncode == 0, r.stderr
    summary = synth.analyse_netlist(out, tech)
    assert summary["unresolved_modules"] == []
    txt = out.read_text()
    assert "DFFR_X" in txt and ("FA_X1" in txt or "XOR2_X" in txt or "XNOR2_X" in txt)


def test_external_dietop_requires_existing_filelist(tmp_path):
    raw = yaml.safe_load((PHYS_DIR / "config/silicaflux_min.yaml").read_text())
    raw["rtl"]["dietop_source"] = "external"
    raw["rtl"]["dietop_filelist"] = "rtl/filelists/does_not_exist.f"
    p = tmp_path / "ext.yaml"
    p.write_text(yaml.safe_dump(raw))
    with pytest.raises(PipelineError, match="external DieTop filelist not found"):
        load_config(p).rtl_filelists()
