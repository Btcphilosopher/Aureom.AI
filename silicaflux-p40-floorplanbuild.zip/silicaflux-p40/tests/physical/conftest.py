"""Shared fixtures for SilicaFlux Project 40 physical-pipeline tests.

Markers:
  eda   - needs Yosys / Verilator / Icarus (CI smoke tier)
  flow  - needs completed OpenROAD build results (full physical tier; skipped when absent)
"""
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "physical/silicaflux/scripts"))

from sfpd.util import PHYS_DIR  # noqa: E402


def pytest_configure(config):
    config.addinivalue_line("markers", "eda: requires Yosys/Verilator/Icarus")
    config.addinivalue_line("markers", "flow: requires completed OpenROAD build results")


def need(*tools):
    missing = [t for t in tools if shutil.which(t) is None]
    return pytest.mark.skipif(bool(missing), reason=f"missing tools: {missing}")


def built(config):
    """Published results present (the shipped archive excludes build/ intermediates)."""
    return (PHYS_DIR / "results" / config / "stage_state.json").exists() and \
        (PHYS_DIR / "reports" / config / "summary.json").exists()


def has_build(config):
    return (PHYS_DIR / "build" / config / "state.json").exists()


@pytest.fixture(scope="session")
def tech():
    from sfpd.tech import load_tech
    return load_tech("nangate45")


@pytest.fixture
def min_cfg():
    from sfpd.config import load_config
    return load_config("silicaflux_min")
