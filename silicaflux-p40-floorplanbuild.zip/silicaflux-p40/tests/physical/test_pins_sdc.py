import re

from sfpd.pins import assign_pins, check_pin_edges, edge_region, pins_to_tcl
from sfpd.sdc import generate_sdc

WRAPPER_PORTS = (["clk", "rst_n", "test_mode", "host_req", "host_we", "host_ack", "host_err", "ext_req",
                  "ext_we", "ext_ack", "irq", "therm_alert", "tck", "tms", "tdi", "trst_n", "tdo"]
                 + [f"host_addr[{i}]" for i in range(16)] + [f"host_wdata[{i}]" for i in range(32)]
                 + [f"host_rdata[{i}]" for i in range(32)] + [f"ext_addr[{i}]" for i in range(15)]
                 + [f"ext_wdata[{i}]" for i in range(32)] + [f"ext_rdata[{i}]" for i in range(32)])
OUTPUTS = {"host_ack", "host_err", "ext_req", "ext_we", "irq", "tdo"}


def ports():
    return [{"name": n, "io": "OUTPUT" if (n in OUTPUTS or n.startswith(("host_rdata", "ext_addr", "ext_wdata")))
             else "INPUT"} for n in WRAPPER_PORTS]


def test_every_wrapper_port_assigned(min_cfg):
    pp = assign_pins(min_cfg, ports())
    assert pp["total_ports"] == 176
    assert pp["unassigned"] == []
    assert len(pp["groups"]["host"]["pins"]) == 84 and len(pp["groups"]["extmem"]["pins"]) == 82


def test_unassigned_reported(min_cfg):
    pp = assign_pins(min_cfg, ports() + [{"name": "debug_out", "io": "OUTPUT"}])
    assert pp["unassigned"] == ["debug_out"]


def test_edge_span_region():
    assert edge_region("left", [0.0, 0.5], (0, 0, 100, 200)) == "left:0.00-100.00"
    assert edge_region("top", None, (0, 0, 100, 200)) == "top:*"


def test_pin_tcl_and_edge_check(min_cfg):
    pp = assign_pins(min_cfg, ports())
    tcl = pins_to_tcl(pp, (0, 0, 400, 400))
    assert "set_io_pin_constraint -region left:8.00-180.00" in tcl
    geom = {"die": [0, 0, 400, 400], "io_pins": [
        {"name": "clk", "placed": 1, "bbox": [200, 399.9, 200.1, 400], "sig": "SIGNAL"},
        {"name": "irq", "placed": 1, "bbox": [0, 50, 0.1, 50.1], "sig": "SIGNAL"},
        {"name": "tdo", "placed": 0, "bbox": [0, 0, 0, 0], "sig": "SIGNAL"}]}
    issues = {i["pin"]: i["issue"] for i in check_pin_edges(geom, pp)}
    assert "clk" not in issues and "planned bottom" in issues["irq"] and issues["tdo"] == "unplaced"


def test_sdc_directions_and_domains(min_cfg, tech, tmp_path):
    p = generate_sdc(min_cfg, tech, tmp_path / "x.sdc", ports())
    s = p.read_text()
    assert "create_clock -name core_clk -period 5.0 [get_ports {clk}]" in s
    assert "set_clock_groups -asynchronous -group {core_clk} -group {jtag_tck}" in s
    assert "set_case_analysis 0 [get_ports {test_mode}]" in s
    assert re.search(r"set_false_path -from \[get_ports \{rst_n trst_n therm_alert\}\]", s)
    for line in s.splitlines():
        if line.startswith("set_input_delay"):
            assert "host_rdata" not in line and "ext_addr" not in line and "tdo" not in line
        if line.startswith("set_output_delay"):
            assert "host_wdata" not in line and "ext_rdata" not in line
    assert "set_clock_uncertainty -hold 0.05" in s
