import shutil

import pytest
import yaml

from sfpd.lef import parse_lef
from sfpd.liberty import parse_liberty
from sfpd.tech import load_tech, tech_report
from sfpd.util import PHYS_DIR


def test_nangate45_profile_valid(tech):
    rep = tech_report(tech)
    assert rep["valid"], rep["issues"]
    assert rep["manufacturable"] is False
    assert rep["dbu_per_micron"] == 2000
    assert rep["site_size_um"] == [0.19, 1.4]
    msgs = " ".join(i["message"] for i in rep["issues"])
    assert "NOT manufacturable" in msgs and "ABSTRACT" in msgs


def test_uninstalled_and_template_profiles_fail_clearly():
    sky = load_tech("sky130hd")
    assert any("NOT INSTALLED" in e for e in sky.errors)
    fnd = load_tech("foundry_template")
    assert any("REPLACE_ME" in e for e in fnd.errors)
    assert any("file not found" in e for e in fnd.errors)


def test_inconsistent_profile_detected(tmp_path):
    raw = yaml.safe_load((PHYS_DIR / "config/tech/nangate45.yaml").read_text())
    raw["site"] = "NO_SUCH_SITE"
    raw["routing"]["min_signal_layer"] = "metal99"
    raw["operating_conditions"]["voltage_v"] = 0.7
    p = tmp_path / "broken.yaml"
    p.write_text(yaml.safe_dump(raw))
    tp = load_tech(p)
    errs = " | ".join(tp.errors)
    assert "NO_SUCH_SITE" in errs and "metal99" in errs and "nom_voltage" in errs


def test_fakeram_lef_abstract():
    lef = parse_lef(PHYS_DIR / "tech/nangate45/lef/fakeram45_64x32.lef")
    m = lef.macros["fakeram45_64x32"]
    assert m.is_block and (m.width, m.height) == (20.14, 61.6)
    assert {"X", "Y"} <= set(m.symmetry)
    assert {p.name for p in m.power_pins()} == {"VDD", "VSS"}
    assert m.signal_pin_side() == "W"
    assert all(p.layers <= {"metal3", "metal4"} for p in m.signal_pins())


def test_liberty_scan():
    lib = parse_liberty(PHYS_DIR / "tech/nangate45/lib/NangateOpenCellLibrary_typical.lib")
    assert lib.nom_voltage == pytest.approx(1.1)
    assert lib.cells["CLKGATETST_X1"].is_clock_gate
    assert lib.cells["DFFR_X1"].area > 0
