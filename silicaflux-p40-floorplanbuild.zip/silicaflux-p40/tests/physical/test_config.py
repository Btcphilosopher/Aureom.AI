import copy

import pytest
import yaml

from sfpd.config import estimate_core, load_config, validate_config
from sfpd.util import PHYS_DIR, PipelineError


@pytest.mark.parametrize("name", ["silicaflux_min", "silicaflux_hpc_concept"])
def test_shipped_configs_validate(name):
    cfg = load_config(name)
    assert cfg.tech_name == "nangate45"
    assert cfg.top == "silicaflux_floorplan_wrapper"
    assert cfg.raw["floorplan"]["sizing"] == "auto"     # never trust concept dimensions


def _raw():
    return yaml.safe_load((PHYS_DIR / "config/silicaflux_min.yaml").read_text())


@pytest.mark.parametrize("mutate,needle", [
    (lambda r: r.pop("clocks"), "clocks"),
    (lambda r: r["floorplan"].__setitem__("target_utilization", 1.5), "target_utilization"),
    (lambda r: r["floorplan"].__setitem__("area_margin", 0.9), "area_margin"),
    (lambda r: r["regions"]["vector"].__setitem__("rect", [0.5, 0.2, 0.4, 0.9]), "rect"),
    (lambda r: r["macro_groups"][0].__setitem__("region", "nowhere"), "unknown region"),
    (lambda r: r["macro_groups"][0].__setitem__("edge", "diagonal"), "edge"),
    (lambda r: r["rtl"]["parameters"].__setitem__("NV", 5), "NV"),
    (lambda r: r["floorplan"].__setitem__("sizing", "fixed"), "die.width_um"),
    (lambda r: r["clocks"][0].__setitem__("period_ns", -1), "period_ns"),
    (lambda r: r["regions"]["vector"].__setitem__("match", ["([unclosed"]), "bad regex"),
])
def test_invalid_configs_rejected(mutate, needle):
    raw = _raw()
    mutate(raw)
    errs = validate_config(raw)
    assert errs, "mutation should make the config invalid"
    assert any(needle in e for e in errs), errs


def test_load_config_raises_clearly(tmp_path):
    raw = _raw()
    raw["floorplan"]["target_utilization"] = 0.0
    p = tmp_path / "bad.yaml"
    p.write_text(yaml.safe_dump(raw))
    with pytest.raises(PipelineError, match="target_utilization"):
        load_config(p)


def test_core_estimate_uses_synthesis_and_macros():
    fp = {"target_utilization": 0.5, "aspect_ratio": 1.0, "area_margin": 1.2, "macro_halo_um": 5.0}
    e = estimate_core(10000.0, [(20.0, 60.0)], fp, 0.19, 1.4)
    assert e["core_min_area_um2"] == pytest.approx(10000 / 0.5 + 30 * 70)
    assert e["core_area_um2"] >= e["core_target_area_um2"] - 1e-6
    assert round(e["core_width_um"] / 0.19, 6) == int(round(e["core_width_um"] / 0.19))
    assert round(e["core_height_um"] / 1.4, 6) == int(round(e["core_height_um"] / 1.4))
    lower = estimate_core(10000.0, [(20.0, 60.0)], dict(fp, target_utilization=0.7), 0.19, 1.4)
    assert lower["core_area_um2"] < e["core_area_um2"]


def test_core_estimate_fits_largest_macro():
    fp = {"target_utilization": 0.9, "aspect_ratio": 1.0, "area_margin": 1.0, "macro_halo_um": 5.0}
    e = estimate_core(10.0, [(200.0, 10.0)], fp, 0.19, 1.4)
    assert e["core_width_um"] >= 210.0


def test_aspect_ratio_respected():
    fp = {"target_utilization": 0.5, "aspect_ratio": 2.0, "area_margin": 1.0, "macro_halo_um": 0.0}
    e = estimate_core(50000.0, [], fp, 0.19, 1.4)
    assert e["core_height_um"] / e["core_width_um"] == pytest.approx(2.0, rel=0.02)
