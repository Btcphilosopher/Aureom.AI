"""Full-physical tier: validates the committed OpenROAD build results and reports.

Skipped automatically when the build has not been run (e.g. CI without OpenROAD)."""
import csv
import json

import pytest

from conftest import built, has_build
from sfpd.util import PHYS_DIR, read_json

pytestmark = pytest.mark.flow
CONFIGS = ["silicaflux_min", "silicaflux_hpc_concept"]


def summary(cfg):
    if not built(cfg):
        pytest.skip(f"{cfg} not built")
    return read_json(PHYS_DIR / "reports" / cfg / "summary.json")


@pytest.mark.parametrize("cfg", CONFIGS)
def test_milestones_are_honest(cfg):
    s = summary(cfg)
    ms = {m["milestone"]: m["achieved"] for m in s["milestones"]}
    assert ms["Routing complete"] is False and ms["Signoff complete"] is False
    assert ms["Synthesis complete"] and ms["Floorplan complete"] and ms["Placement complete"]
    order = [m["achieved"] for m in s["milestones"]]
    assert order == sorted(order, reverse=True), "a milestone cannot pass after an earlier one fails"
    assert s["technology"]["manufacturable"] is False
    assert s["rtl_source"] == "standin"


@pytest.mark.parametrize("cfg", CONFIGS)
def test_physical_checks(cfg):
    s = summary(cfg)
    assert s["macro_legality"]["legal"] and s["macro_legality"]["errors"] == 0
    assert s["io"]["unplaced"] == [] and s["io"]["placed"] == s["io"]["ports"] == 176
    assert s["io"]["unassigned_to_group"] == []
    assert all(s["pdn"]["check_power_grid"].values()) and s["pdn"]["unconnected_pg_pins"] == 0
    assert s["placement"]["unplaced_instances"] == 0 and s["placement"]["check_placement_clean"]
    assert s["congestion"]["total_overflow"] == 0
    assert s["synthesis"]["unresolved_modules"] == []
    assert "PASS" in s["verification"]["gate_level_simulation"]
    assert all("PASS" in v for v in s["verification"]["rtl_simulation"].values())


@pytest.mark.parametrize("cfg", CONFIGS)
def test_timing_labelled_and_closed(cfg):
    s = summary(cfg)
    stages = {t["stage"]: t for t in s["timing"]}
    assert {"pre-CTS (ideal clocks)", "post-CTS", "post-global-route"} <= set(stages)
    assert all(t["signoff"] is False for t in s["timing"])
    assert all("estimate" in t["parasitics"] for t in s["timing"])
    final = stages["post-global-route"]
    assert final["setup_violations"] == 0 and final["hold_violations"] == 0
    assert final["setup_worst_slack_ns"] > 0 and final["hold_worst_slack_ns"] >= 0
    unc = s["unconstrained_endpoints"]
    assert unc["other"] == 0, "every unconstrained endpoint must be classified"


@pytest.mark.parametrize("cfg", CONFIGS)
def test_sizing_derived_from_synthesis(cfg):
    s = summary(cfg)
    z = s["sizing"]
    assert z["sizing_mode"] == "auto"
    assert z["core_area_um2"] >= z["core_min_area_um2"] * z["area_margin"] * 0.999
    assert s["memory_macro_count"] == {"silicaflux_min": 8, "silicaflux_hpc_concept": 26}[cfg]


@pytest.mark.parametrize("cfg", CONFIGS)
def test_artefacts_exist(cfg):
    summary(cfg)
    r = PHYS_DIR / "results" / cfg
    for f in ("synth_netlist.v", "floorplan.def", "floorplan.odb", "grt.odb", "final_netlist.v",
              "pin_placement.tcl", f"{cfg}.sdc", "post_grt_timing.rpt", "congestion.json"):
        assert (r / f).exists() and (r / f).stat().st_size > 0, f
    for f in ("summary.json", "summary.csv", "macros.csv", "pins.csv", "blocks.csv", "timing.csv",
              "power_density.json", "timingflow_export.json", "powergrid_thermallab_export.json"):
        assert (PHYS_DIR / "reports" / cfg / f).exists(), f
    th = read_json(PHYS_DIR / "reports" / cfg / "powergrid_thermallab_export.json")
    assert th["temperatures"] is None
    for stage in ("floorplan", "grt"):
        assert (PHYS_DIR / "plots" / cfg / f"{cfg}_{stage}.png").exists()
    with open(PHYS_DIR / "reports" / cfg / "macros.csv") as fh:
        assert len(list(csv.DictReader(fh))) == summary(cfg)["memory_macro_count"]


@pytest.mark.parametrize("cfg", CONFIGS)
def test_report_reproducible(cfg):
    """Regenerating reports from the same build gives identical content (timestamps aside)."""
    summary(cfg)
    if not has_build(cfg):
        pytest.skip("build/ intermediates not present (archive ships published results only)")
    from sfpd.flow import Flow
    from sfpd.reports import build_reports
    f = Flow(cfg)
    a = build_reports(f)
    csv1 = {p.name: p.read_text() for p in (PHYS_DIR / "reports" / cfg).glob("*.csv")}
    b = build_reports(f)
    csv2 = {p.name: p.read_text() for p in (PHYS_DIR / "reports" / cfg).glob("*.csv")}
    for d in (a, b):
        d.pop("generated_utc")
    assert json.dumps(a, sort_keys=True, default=str) == json.dumps(b, sort_keys=True, default=str)
    csv1.pop("summary.csv"), csv2.pop("summary.csv")
    assert csv1 == csv2
