import pytest

from sfpd.config import FloorplanConfig
from sfpd.geometry import intersect, inside
from sfpd.lef import parse_lef
from sfpd.macro_plan import plan_macros, plan_to_tcl
from sfpd.util import PHYS_DIR, PipelineError

LEF = parse_lef(PHYS_DIR / "tech/nangate45/lef/fakeram45_64x32.lef")
ALLOWED = ["R0", "R180", "MX", "MY"]


def cfg(groups, regions, halo=5.0, chan=12.0):
    raw = {"floorplan": {"macro_halo_um": halo, "pin_access_channel_um": chan},
           "regions": regions, "macro_groups": groups}
    return FloorplanConfig("t", raw, PHYS_DIR)


def macros(n, prefix="u/b"):
    return [{"name": f"{prefix}{i}", "master": "fakeram45_64x32", "w": 20.14, "h": 61.6} for i in range(n)]


def test_left_edge_stack_faces_east_and_is_legal():
    core = (10.0, 10.0, 310.0, 310.0)
    c = cfg([{"name": "g", "match": "u/b", "region": "r", "edge": "left"}],
            {"r": {"rect": [0.0, 0.0, 0.5, 1.0]}})
    plan = plan_macros(c, macros(3), core, LEF, 0.19, 1.4, ALLOWED)
    ms = plan["macros"]
    assert all(m["pin_side"] == "E" for m in ms)
    for i in range(3):
        assert inside(ms[i]["bbox"], core)
        for j in range(i + 1, 3):
            assert intersect(ms[i]["bbox"], ms[j]["bbox"]) is None
        assert abs(((ms[i]["x"] - core[0]) / 0.19) - round((ms[i]["x"] - core[0]) / 0.19)) < 1e-6
        assert abs(((ms[i]["y"] - core[1]) / 1.4) - round((ms[i]["y"] - core[1]) / 1.4)) < 1e-6
    assert "sf_place_macro {u/b0}" in plan_to_tcl(plan)


def test_right_edge_faces_west():
    core = (0.0, 0.0, 300.0, 300.0)
    c = cfg([{"name": "g", "match": "u/b", "region": "r", "edge": "right"}], {"r": {"rect": [0.5, 0.0, 1.0, 1.0]}})
    plan = plan_macros(c, macros(2), core, LEF, 0.19, 1.4, ALLOWED)
    assert {m["orient"] for m in plan["macros"]} == {"R0"}
    assert {m["pin_side"] for m in plan["macros"]} == {"W"}


def test_infeasible_region_refused():
    core = (0.0, 0.0, 300.0, 300.0)
    c = cfg([{"name": "g", "match": "u/b", "region": "r", "edge": "left"}], {"r": {"rect": [0.0, 0.0, 0.3, 0.5]}})
    with pytest.raises(PipelineError, match="does not fit"):
        plan_macros(c, macros(3), core, LEF, 0.19, 1.4, ALLOWED)


def test_uncovered_macro_refused():
    core = (0.0, 0.0, 300.0, 300.0)
    c = cfg([{"name": "g", "match": "u/b0", "region": "r", "edge": "left"}], {"r": {"rect": [0.0, 0.0, 0.5, 1.0]}})
    with pytest.raises(PipelineError, match="not covered"):
        plan_macros(c, macros(2), core, LEF, 0.19, 1.4, ALLOWED)


def test_group_without_macros_refused():
    core = (0.0, 0.0, 300.0, 300.0)
    c = cfg([{"name": "g", "match": "nothing", "region": "r", "edge": "left"}], {"r": {"rect": [0.0, 0.0, 0.5, 1.0]}})
    with pytest.raises(PipelineError, match="matches no macro"):
        plan_macros(c, [], core, LEF, 0.19, 1.4, ALLOWED)


def test_bottom_row_keeps_pin_access_channel_after_snapping():
    """Regression: bottom-edge rows used to snap x DOWN, eroding the W-facing pin channel
    below the configured minimum when the region starts at the core edge (found by the
    independent legality checker on the HPC configuration)."""
    from sfpd.config import load_config
    from sfpd.legality import check_macros
    from sfpd.tech import load_tech
    core = (15.01, 15.4, 618.83, 620.2)          # actual HPC core: origin not on the 0.19 grid
    c = cfg([{"name": "g", "match": "u/b", "region": "r", "edge": "bottom"}], {"r": {"rect": [0.0, 0.0, 0.3, 0.3]}})
    plan = plan_macros(c, macros(3), core, LEF, 0.19, 1.4, ALLOWED)
    for m in plan["macros"]:
        assert m["pin_side"] == "W"
    assert plan["macros"][0]["x"] - core[0] >= 12.0 - 1e-6
    geom = {"core": list(core), "macros": []}
    for m in plan["macros"]:
        x0, y0, x1, y1 = m["bbox"]
        geom["macros"].append({"name": m["name"], "master": m["master"], "orient": m["orient"],
                               "status": "FIRM", "bbox": list(m["bbox"]), "pins": [
                                   {"name": "addr_in[0]", "sig": "SIGNAL", "io": "INPUT", "net": "n",
                                    "special": 0, "bbox": [x0, y0 + 5, x0 + 0.07, y0 + 5.07]}]})
    rep = check_macros(geom, load_config("silicaflux_min"), load_tech("nangate45"), plan)
    assert not [f for f in rep["findings"] if f["check"] == "pin_access"], rep["findings"]
