from sfpd.audit import run_audit
from sfpd.sweep import deep_merge, rank


def test_audit_reports_absent_upstream(tmp_path):
    rep = run_audit(tmp_path)
    assert all(v == "not present in this workspace" for v in rep["projects_31_39"].values())
    deps = {d["key"]: d["status"] for d in rep["dependencies"]}
    for tool in ("timingflow", "powergrid", "floorplanlab", "thermallab"):
        assert deps[tool] == "missing", "Project 40 handoff exports must not count as the tool"
    assert deps["projects_31_39_rtl"].startswith("missing_upstream")
    assert (tmp_path / "dependency_report.md").exists()


def test_deep_merge_semantics():
    base = {"floorplan": {"a": 1, "b": 2}, "regions": {"x": {"rect": [0, 0, 1, 1], "kind": "k"}, "y": {}},
            "macro_groups": [1, 2]}
    out = deep_merge(base, {"floorplan": {"b": 3}, "regions": {"x": {"rect": [0, 0, 0.5, 0.5]}},
                            "macro_groups": [9]})
    assert out["floorplan"] == {"a": 1, "b": 3}
    assert out["regions"]["x"] == {"rect": [0, 0, 0.5, 0.5]} and "y" in out["regions"]
    assert out["macro_groups"] == [9] and base["floorplan"]["b"] == 2


def _pt(i, **m):
    return {"id": i, "status": "complete", "metrics": dict({"macro_legal": True, "setup_violations": 0,
                                                            "grt_overflow": 0}, **m)}


def test_rank_penalises_violations_and_skips_infeasible():
    pts = [_pt("small_but_failing", die_area_um2=100, setup_violations=3),
           _pt("big_clean", die_area_um2=200), _pt("mid_clean", die_area_um2=150),
           {"id": "bad", "status": "infeasible", "metrics": {}}]
    r = rank(pts)
    ids = [p["id"] for p in r]
    assert ids[:2] == ["mid_clean", "big_clean"]
    assert ids[2] == "small_but_failing"            # regression: penalty precedence bug
    assert r[-1]["rank"] is None
