import copy

import pytest

from sfpd.config import load_config
from sfpd.legality import check_macros


def pin(name, sig, bbox, net="n1", special=0):
    return {"name": name, "sig": sig, "io": "INPUT", "net": net, "special": special, "bbox": bbox}


def macro(name, bbox, orient="R0", pins=None):
    x0, y0, x1, y1 = bbox
    if pins is None:   # signal pins on the west edge (R0), power pins on metal4
        pins = [pin("addr_in[0]", "SIGNAL", [x0, y0 + 5, x0 + 0.07, y0 + 5.07]),
                pin("clk", "SIGNAL", [x0, y0 + 9, x0 + 0.07, y0 + 9.07], net="clk"),
                pin("VDD", "POWER", [x0 + 4, y0 + 2, x0 + 4.3, y1 - 2], net="VDD", special=1),
                pin("VSS", "GROUND", [x0 + 8, y0 + 2, x0 + 8.3, y1 - 2], net="VSS", special=1)]
    return {"name": name, "master": "fakeram45_64x32", "orient": orient, "status": "FIRM",
            "bbox": list(bbox), "pins": pins}


@pytest.fixture
def geom():
    return {"core": [0, 0, 300, 300], "die": [-10, -10, 310, 310],
            "macros": [macro("m0", (100, 100, 120.14, 161.6)), macro("m1", (100, 180, 120.14, 241.6))]}


def errors(rep, check):
    return [f for f in rep["findings"] if f["check"] == check and f["severity"] == "error"]


def run(geom, tech, stage="floorplan", plan=None):
    return check_macros(geom, load_config("silicaflux_min"), tech, plan, stage)


def test_legal_baseline(geom, tech):
    rep = run(geom, tech)
    assert rep["legal"], rep["findings"]


def test_overlap_detected(geom, tech):
    geom["macros"][1]["bbox"] = [105, 150, 125.14, 211.6]
    assert errors(run(geom, tech), "overlap")


def test_boundary_violation_detected(geom, tech):
    geom["macros"][0]["bbox"] = [290, 100, 310.14, 161.6]
    assert errors(run(geom, tech), "boundary")


def test_halo_violation_detected(geom, tech):
    geom["macros"][1]["bbox"] = [100, 163, 120.14, 224.6]   # 1.4 um gap < 5 um halo
    assert errors(run(geom, tech), "halo_clearance")


def test_unsupported_orientation_detected(geom, tech):
    geom["macros"][0]["orient"] = "R90"
    assert errors(run(geom, tech), "orientation")


def test_pins_facing_boundary_detected(geom, tech):
    geom["macros"] = [macro("edge", (6, 100, 26.14, 161.6))]   # west pin edge 6 um from core edge
    assert errors(run(geom, tech), "pin_access")


def test_pin_edge_blocked_by_macro(geom, tech):
    geom["macros"].append(macro("blocker", (75, 110, 95.14, 171.6)))   # 4.86 um west of m0's pins
    assert errors(run(geom, tech), "pin_access")


def test_unconnected_signal_pin(geom, tech):
    geom["macros"][0]["pins"][0]["net"] = ""
    assert errors(run(geom, tech), "unconnected_signal_pin")


def test_clock_pin_on_non_clock_net(geom, tech):
    geom["macros"][0]["pins"][1]["net"] = "some_data_net"
    assert errors(run(geom, tech), "clock_pin_connection")


def test_unconnected_power_pin_after_pdn(geom, tech):
    geom["macros"][0]["pins"][2]["special"] = 0
    assert not errors(run(geom, tech, "floorplan"), "unconnected_power_pin")
    assert errors(run(geom, tech, "pdn"), "unconnected_power_pin")


def test_blockage_intersection(geom, tech):
    plan = {"macros": [], "channel_blockages": [[110, 0, 130, 300]]}
    assert errors(run(geom, tech, plan=plan), "blockage_intersection")


def test_missing_and_moved_macro(geom, tech):
    plan = {"macros": [{"name": "m0", "bbox": [50, 50, 70.14, 111.6], "orient": "R0"},
                       {"name": "ghost", "bbox": [0, 0, 1, 1], "orient": "R0"}],
            "channel_blockages": []}
    rep = run(geom, tech, plan=plan)
    assert errors(rep, "plan_mismatch") and errors(rep, "missing_macro")
