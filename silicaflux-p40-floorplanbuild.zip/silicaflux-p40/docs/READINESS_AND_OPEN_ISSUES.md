# Readiness assessment and open issues — SilicaFlux Project 40

## Readiness by milestone
| Conceptual architecture | ✅ achieved | ✅ achieved | floorplan configs + stand-in DieTop functional organisation (DieTop of Projects 31-39 absent) |
| RTL verified | ✅ achieved | ✅ achieved | Verilator lint + self-checking RTL simulation (behavioural and technology-bound) |
| Synthesis complete | ✅ achieved | ✅ achieved | Yosys netlist on technology cells, 0 unresolved modules, gate-level simulation passes |
| Floorplan complete | ✅ achieved | ✅ achieved | legal macros, all I/O pins placed on planned edges, PDN connectivity checks pass |
| Placement complete | ✅ achieved | ✅ achieved | global + detailed placement, check_placement clean, 0 unplaced instances |
| CTS complete | ✅ achieved | ✅ achieved | TritonCTS run as a distinct stage; post-CTS setup and hold met with propagated clocks |
| Routing complete | ❌ not achieved | ❌ not achieved | global routing only (congestion estimate); detailed routing not run (gated in config) |
| Signoff complete | ❌ not achieved | ❌ not achieved | no foundry DRC/LVS decks, no detailed routing, no RC extraction; technology is educational |

**What this means.** The pipeline itself is working and verified: every stage is gated by checks that
can fail, and they did fail during development (see *Defects found*). The *design* it was exercised on
is a stand-in, and the *technology* is educational. The physical results are therefore valid evidence that
the pipeline works. They are **not** evidence about a SilicaFlux chip.

## Key physical findings
* **Gated-clock hold problem (real, both configurations).** Flops behind the vector/tensor ICGs see
  ~0.27 ns more clock insertion delay than the ungated control flops that launch into them. TritonCTS
  balances each gated subtree separately.
  * Before repair: MIN 656 hold violations, worst -0.3887 ns;
    HPC 1483, worst -0.3044 ns. The worst paths include
    reset removal checks into the tensor PE array.
  * Closed by `repair_timing -hold`, reported as its own step (MIN 591
    cells, HPC 2238 cells).
  * A production flow should instead balance the gated-domain insertion delay in CTS, or retime the reset tree.
* **Suggested regions are not fences.** Area fraction placed inside each suggested region:
  * MIN: control 48%, dma 0%, extmem 11%, fabric 64%, host 13%, power 0%, scratch 21%, tensor 48%, test_ras 0%, vector 94%.
  * HPC: control 5%, dma 0%, extmem 0%, fabric 48%, host 0%, power 0%, scratch 21%, ten0 70%, ten1 79%, ten2 42%, ten3 75%, test_ras 1%, vec0 67%, vec1 60%, vec2 39%, vec3 15%.
  * Vector logic follows its SRAM. Tensor logic outgrows its suggested area. In HPC the small
    bottom-band blocks (host, DMA, test/RAS, power manager) leave space that vec3/ten2 logic absorbs.
  * Next step: either enforce regions (OpenDB regions/fences) or size them from attributed block area.
* **Macro-region feasibility is a hard constraint.** The region layouts are normalised, so they are not
  aspect- or utilisation-invariant. Four sweep points were refused by the planner rather than producing
  an illegal floorplan (see sweep table).
* **Congestion is not limiting** at these sizes (≤ 23.93% global-route usage, 0 overflow).

## Configuration sweep (silicaflux_min, actual flow results)
Ranking: score = 10*[setup violations] + 10*[GRT overflow] + 10*[illegal macros]
        + 0.35*norm(die area) + 0.25*norm(GRT wirelength) + 0.20*norm(GRT usage)
        + 0.10*norm(power) - 0.10*norm(setup worst slack); lower is better;
norm() is min-max over completed points; infeasible points are unranked.

| Rank | Point | Dimension | Score | Die µm² | GRT usage % | Wirelength µm | Setup WS ns | Hold WS ns | Power mW |
|---|---|---|---|---|---|---|---|---|---|
| 1 | `chan_narrow` | routing-channel width | 0.1849 | 133,798 | 19.89 | 498,955 | 2.7084 | 0.0204 | 10.55 |
| 2 | `vt_adjacent` | vector/tensor proximity | 0.2079 | 137,964 | 19.51 | 506,114 | 2.821 | 0.0202 | 10.57 |
| 3 | `baseline` | baseline | 0.2108 | 137,964 | 19.37 | 503,076 | 2.7601 | 0.0202 | 10.57 |
| 4 | `ar_0p7_rowbanks` | aspect ratio | 0.2474 | 138,209 | 19.37 | 503,496 | 2.7253 | 0.0201 | 10.61 |
| 5 | `sram_face_spine` | SRAM placement / interconnect attachment (central) | 0.2524 | 137,964 | 19.44 | 504,228 | 2.7304 | 0.0197 | 10.60 |
| 6 | `ar_1p4_widescratch` | aspect ratio | 0.3046 | 138,352 | 19.48 | 506,097 | 2.6865 | 0.0202 | 10.54 |
| 7 | `chan_wide` | routing-channel width | 0.4365 | 149,784 | 18.21 | 513,954 | 2.6906 | 0.0208 | 10.52 |
| 8 | `util_0p30` | core utilisation | 0.5357 | 170,924 | 15.79 | 513,930 | 2.6844 | 0.0202 | 10.65 |
| 9 | `vbank_128x32` | memory macro size | 0.5828 | 147,313 | 19.43 | 520,726 | 2.783 | 0.0206 | 11.43 |
| – | `ar_0p7` | aspect ratio | **infeasible** | macro group 'vec_banks': u_dietop/g_vec[0].u_vec/u_bank_c.g_m64x32.u_macro does not fit region 'vector' (15.01, 112.5, 161.66, 301.0) (needs (20.14, 9 | | | | | |
| – | `ar_1p4` | aspect ratio | **infeasible** | macro group 'scratchpad': u_dietop/u_scratch/u_bank.genblk1.genblk1.g_m256x32.u_macro does not fit region 'scratch' (187.83, 15.4, 274.25, 152.96) (ne | | | | | |
| – | `util_0p55` | core utilisation | **infeasible** | macro group 'vec_banks': u_dietop/g_vec[0].u_vec/u_bank_c.g_m64x32.u_macro does not fit region 'vector' (15.01, 118.22, 123.83, 317.8) (needs (20.14,  | | | | | |
| – | `util_0p55_rowbanks` | core utilisation | **infeasible** | macro group 'scratchpad': u_dietop/u_scratch/u_bank.genblk1.genblk1.g_m256x32.u_macro does not fit region 'scratch' (196.38, 15.4, 287.07, 118.22) (ne | | | | | |

Interpretation:
* On this small, uncongested design the completed points differ by only a few percent. The ranking is
  driven mainly by die area: narrower macro channels win, while 30% utilisation and 128×32 vector banks cost area.
* The fabric RTL is a single crossbar, so the "interconnect" point varies SRAM *attachment geometry*
  only, not NoC topology.
* `vt_adjacent` gave the best setup slack but scattered vector logic (36% in region).

## Defects found by testing during this build (all fixed)
1. **TB golden error** — HPC throttling test compared cluster 0 against cluster 3 operands.
2. **TB depth assumption** — bounds-error tests assumed 64-word banks. They are now derived from bank-depth parameters.
   The 128×32 sweep point exposed this, and its RTL correctly accepted the in-range command.
3. **Slack units** — OpenSTA returns seconds, so every slack printed as 0.0000. Now converted to ns.
4. **SDC direction bug** — mixed pin groups put input delays on outputs (exposed by STA-0440 warnings).
5. **Macro-planner snap direction** — bottom/top rows snapped x *down*, eroding the 12 µm pin-access channel.
   The independent legality checker caught it on HPC; a regression test was added.
6. **Audit false positive** — Project 40's own handoff exports were counted as "TimingFlow/PowerGrid/ThermalLab present".
7. **I/O count** — PDN power terminals (VDD/VSS) were counted as signal ports (178 vs 176).
8. **Sweep ranking** — Python operator-precedence bug in the setup-violation penalty; regression test added.
9. **Makefile** — stamp/cd paths broke chained stages. Found by the clean `make` rebuild.

Tool limitation worked around: Yosys 0.33 `abc` has no `-dont_use`, so a filtered Liberty is generated.

## Reproducibility
* A clean `make silicaflux-clean silicaflux-all` of MIN (86 s) reproduced the independently built sweep
  `baseline` point exactly: setup WS, hold WS, wirelength and power to full precision.
* Report regeneration is byte-stable (`test_report_reproducible`).
* Published MIN results are from that clean rebuild. The HPC run was produced stage by stage with the same code.

## Open issues
1. **Real DieTop absent.** Projects 31–39 must be imported, the audit re-run, and both configurations
   rebuilt with `dietop_source: external`. Port contract: see `docs/STANDIN_DIETOP.md`.
2. **Detailed routing not run.** As a result: no routing milestone, no post-route extraction, no
   antenna/fill/DRC. TritonRoute is available in OpenROAD but was not exercised.
3. **No foundry technology.** Nangate45 is non-manufacturable, single corner (typical 1.1 V / 25 °C);
   fakeram45 macros are abstracts. No OCV/AOCV, no multi-corner analysis.
4. **Residual electrical violation.** MIN post-global-route has 1 max-capacitance
   violation(s) and HPC 2. These are small overshoots left after incremental
   `repair_design` with 10% margins.
5. **Pre-CTS setup TNS anomaly.** MIN reports −0.02 ns setup TNS with 0 violating endpoints and
   +2.6 ns WS at the ideal-clock stage. Not investigated; absent at all later stages.
6. **Timing choices made in this build (review):**
   * hold uncertainty 0.05 ns (core) / 0.10 ns (TCK), versus setup uncertainty 0.15 / 0.5 ns;
   * hold-repair target margin 0.02 ns, so the reported hold WS (~0.02 ns) equals the repair target, not natural slack.
7. **I/O is abstract.** No pad ring, bump map or package; pins are on metal5/metal6 at the die edge.
8. **DFT.** test_mode bypasses ICGs and the reset synchroniser, but no scan chains are inserted.
9. **Handoff schemas provisional.** TimingFlow/PowerGrid/ThermalLab exports use provisional schemas because
   those tools are absent. No temperatures are produced; the power model is vectorless and uncalibrated.
10. **Region adherence** is measured, not enforced (see findings).
11. **CI.** The full-physical tier needs OpenROAD (manual dispatch). Unit and EDA-smoke tiers run without it.
