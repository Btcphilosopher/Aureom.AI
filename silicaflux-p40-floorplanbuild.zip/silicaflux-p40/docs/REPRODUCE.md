# Reproducing the results

## Environment actually used
* Ubuntu 24.04.5, x86-64, 1 CPU, 3 GB RAM.
* Tool versions are recorded in each `reports/<config>/summary.json` and in `reports/audit/`.
* iverilog: `12.0`
* matplotlib: `3.11.2`
* openroad: `2.0-12381-g01bba3695`
* python: `3.12.3`
* verilator: `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`
* yosys: `Yosys 0.33 (git sha1 2584903a060)`
* Technology: Nangate45 subset from OpenROAD-flow-scripts `bfcc1895`. See
  `physical/silicaflux/tech/nangate45/PROVENANCE.md`; verify with `sha256sum -c SHA256SUMS`.

## Install
`make install-tools` (see `physical/silicaflux/scripts/install_tools.sh`):
* `apt` provides Yosys, Verilator and Icarus.
* OpenROAD comes from the litex-hub conda build via micromamba. It needs the `anaconda` channel for
  libboost 1.73. The upstream Ubuntu 22.04 `.deb` cannot run on 24.04 without libpython3.10 and libortools.so.9.
* `sfpd` finds OpenROAD on `$PATH`, in `$OPENROAD`, or at `/opt/eda/bin/openroad`.

## Run
```bash
make silicaflux-all                                 # MIN
make silicaflux-all CONFIG=silicaflux_hpc_concept   # HPC concept
make silicaflux-sweep                               # 13-point sweep (resumable: --only/--force)
make silicaflux-test
```

## Measured stage runtimes (1 CPU)
| Stage | MIN (s) | HPC (s) |
|---|---|---|
| lint | 0.1 | 0.2 |
| sim | 0.5 | 2.0 |
| synth | 23.6 | 26.2 |
| gls | 5.3 | 37.3 |
| inventory | 0.7 | 1.3 |
| plan | 0.0 | 0.0 |
| floorplan | 1.0 | 3.8 |
| pdn | 1.3 | 4.5 |
| place | 14.5 | 54.1 |
| cts | 12.4 | 43.8 |
| grt | 18.6 | 128.7 |

## Determinism
The flow is single-threaded and seeded by OpenROAD defaults. A clean MIN rebuild reproduced an
independently built sweep baseline exactly. Report regeneration is byte-stable.
