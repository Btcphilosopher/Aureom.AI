# DRC / LVS readiness — SilicaFlux Project 40

DRC and LVS are exposed as **gated downstream tasks** (`make silicaflux-drc|lvs|signoff` exit 2 with an
explanation). Signoff is not claimed for any configuration.

## Why they are gated
| Prerequisite | Status in this archive |
|---|---|
| Foundry DRC rule deck (Calibre / ICV / Pegasus) | **absent**: educational technology, no foundry |
| Foundry LVS rule deck + device extraction | **absent** |
| Detailed-routed layout | **absent**: global routing only (congestion / wire planning) |
| GDSII with real cell and SRAM layouts | **absent**: fakeram45 macros are abstracts (LEF/Liberty only) |
| Parasitic extraction rules (RCX / StarRC / Quantus) | **absent** for signoff; timing uses estimates |
| Final signoff netlist (post-route, post-ECO) | **absent**: `final_netlist.v` is post-global-route |
| Multi-corner timing libraries | **absent**: single typical corner |

## What becomes possible with each addition
* **With TritonRoute (already in OpenROAD):** detailed routing, then OpenROAD's internal route DRC report.
  That is a router-level check, *not* foundry DRC.
* **With an open, manufacturable PDK (e.g. SKY130 via `config/tech/sky130hd.yaml`, currently not
  installed):**
  * KLayout/Magic DRC and Netgen LVS with the PDK's open decks;
  * an SRAM generator (e.g. OpenRAM) would be needed to replace fakeram abstracts;
  * the stand-in RTL binds through `rtl/physical/tech/<tech>/`.
* **With licensed foundry technology** (`config/tech/foundry_template.yaml`): commercial DRC/LVS/extraction
  decks, foundry SRAM compilers, and the foundry's signoff corners. None of this is provided or implied.

## Required verification tools (for a future signoff flow)
DRC: KLayout or Magic (open PDKs), or Calibre/ICV/Pegasus (foundry). LVS: Netgen (open) or Calibre/ICV.
Extraction: OpenRCX (open rules) or StarRC/Quantus (foundry). STA signoff: OpenSTA/PrimeTime with
extracted SPEF across all corners.
