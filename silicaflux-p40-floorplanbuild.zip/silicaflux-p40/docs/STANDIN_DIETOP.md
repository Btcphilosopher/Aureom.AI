# Stand-in DieTop (`rtl/standin/`)

Used **only because the integrated DieTop of Projects 31–39 is absent**. When the real DieTop is
available, drop `rtl/filelists/dietop_standin.f` and bind the real one. Do not merge the two.

## Port contract (`silicaflux_dietop`)
* Clock/reset/test: `clk`, `rst_n` (synchronised in the wrapper), `test_mode`.
* Host port: 4-phase `host_req/ack`, `host_we`, `host_addr[15:0]`, `host_wdata/rdata[31:0]`, `host_err`.
* External memory: 4-phase `ext_req/ack`, `ext_we`, `ext_addr[14:0]`, `ext_wdata/rdata[31:0]`.
* Misc: `irq`, `therm_alert` (async).
* JTAG: `tck`, `tms`, `tdi`, `trst_n`, `tdo`.
* Parameters: `NV`, `NT` (1..4), `VBANK_DEPTH`, `TBANK_DEPTH`, `SCRATCH_DEPTH`.

## Functional blocks (instance → floorplan region)
| Instance | Function | Region kind |
|---|---|---|
| `u_ctrl` | command processor; 16-entry command ring in its own 64×32 SRAM | control (gold) |
| `u_fabric` | 3-master crossbar "NoC spine", round-robin per slave, decode-error RAS | noc |
| `u_dma` | word-copy DMA (fabric master 2) | control |
| `g_vec[i].u_vec` | 4-lane INT8 SIMD (add/sub/max/relu/xor/and/mul/dot), 3 SRAM banks, gated datapath | vector (cyan) |
| `g_ten[i].u_ten` | 4×4 output-stationary INT8 systolic array, INT32 accumulate, 3 SRAM banks, gated PE array | tensor (violet) |
| `u_scratch` | 256×32 shared scratchpad | sram |
| `u_extmem` | external-memory bridge with timeout watchdog | io |
| `u_host` | host port, CSR window | io |
| `u_pm` | clock-domain enables + thermal throttling (no DVFS: no regulator/PLL exists) | power (gold) |
| `u_ras` | JTAG TAP: IDCODE (placeholder, no JEDEC ID), BYPASS, coherent STATUS snapshot across clock domains | test |

## Address map (16-bit word addresses)
* `0x0000–0x003F` command RAM.
* `0x1ccbbwww…` vector cluster `cc` (bits 11:10), bank `bb` (9:8).
* `0x2…` tensor clusters (same layout).
* `0x3000–0x30FF` scratchpad.
* `0x4000` + CSR (host only).
* `0x8000–0xFFFF` external memory.
* Anything else returns a decode error (`0xDEADBEEF`, counted).

## Command format (4 words)
* `w0[31:28]` opcode: 0 NOP, 1 DMA, 2 VEC, 3 TEN, 4 IRQ.
* `w0[27:24]` vector op / tensor accumulate flag.
* `w0[19:16]` cluster index.
* `w0[15:0]` length.
* `w1`–`w3`: source/A, destination/B, C offsets.
* Errors halt the queue with a code: 1 opcode, 2 cluster, 3 domain disabled, 4 bounds, 5 fetch, 6 DMA.

## Verification
`tb/tb_silicaflux.sv` runs 186 checks (MIN) or 459 (4+4). It covers CSRs, fabric decode, every vector op,
DMA plus matrix multiply with accumulate, error paths, domain disable, thermal throttling (results
unchanged, compute stretched ≥3×), the external-memory watchdog, and JTAG IDCODE/BYPASS/STATUS. It passes
against behavioural RTL, technology-bound RTL, and the synthesised gate-level netlist.
