# SilicaFlux Project 40 — FLOORPLANBUILD
**Automated RTL-to-floorplan and physical-design pipeline · Aureom.AI | SilicaFlux-HPC**

A reproducible pipeline that takes the SilicaFlux hierarchy from RTL through synthesis, floorplanning,
macro placement, I/O planning, PDN, placement, CTS and global routing on a real (open, educational)
technology, with independent legality checks and machine-readable reports. Every number below comes
from tool output in this archive; nothing is drawn from the concept illustration.

> **Read this first — scope of the claims**
> * **RTL source is a STAND-IN.** The repository audit found none of Projects 31–39 (no DieTop,
>   TimingFlow, PowerGrid, FloorplanLab or ThermalLab). `rtl/standin/` is a compact, fully verified
>   stand-in DieTop exercising every functional region. Swap in the real DieTop with
>   `rtl.dietop_source: external` + `rtl.dietop_filelist`.
> * **Technology is educational and non-manufacturable:** Nangate45 Open Cell Library on FreePDK45,
>   single typical corner, with **fakeram45 SRAM abstracts** (no silicon behind them). No advanced-node
>   or foundry data is used or implied. `config/tech/foundry_template.yaml` shows what a licensed
>   profile needs; validation fails until real files exist.
> * **Highest milestone achieved: CTS complete** (both configurations). Routing complete and signoff
>   are **not** claimed: only global routing was run, and no DRC/LVS decks or extraction exist.

## Status
| Milestone | silicaflux_min | silicaflux_hpc_concept | Evidence |
|---|---|---|---|
| Conceptual architecture | ✅ achieved | ✅ achieved | floorplan configs + stand-in DieTop functional organisation (DieTop of Projects 31-39 absent) |
| RTL verified | ✅ achieved | ✅ achieved | Verilator lint + self-checking RTL simulation (behavioural and technology-bound) |
| Synthesis complete | ✅ achieved | ✅ achieved | Yosys netlist on technology cells, 0 unresolved modules, gate-level simulation passes |
| Floorplan complete | ✅ achieved | ✅ achieved | legal macros, all I/O pins placed on planned edges, PDN connectivity checks pass |
| Placement complete | ✅ achieved | ✅ achieved | global + detailed placement, check_placement clean, 0 unplaced instances |
| CTS complete | ✅ achieved | ✅ achieved | TritonCTS run as a distinct stage; post-CTS setup and hold met with propagated clocks |
| Routing complete | ❌ not achieved | ❌ not achieved | global routing only (congestion estimate); detailed routing not run (gated in config) |
| Signoff complete | ❌ not achieved | ❌ not achieved | no foundry DRC/LVS decks, no detailed routing, no RC extraction; technology is educational |

## Results
| | silicaflux_min | silicaflux_hpc_concept |
|---|---|---|
| Clusters (vector + tensor) | 1 + 1 | 4 + 4 |
| Die (µm), sized from synthesis | 370.87 × 372.0 | 633.83 × 635.2 |
| Core (µm) | 340.86 × 341.60 | 603.82 × 604.80 |
| Standard cells (final, incl. CTS/repair) | 21,327 · 38,483 µm² | 72,865 · 127,228 µm² |
| SRAM macros (fakeram45 abstracts) | 8 · 13,750 µm² | 26 · 36,081 µm² |
| Std-cell utilisation of placeable core | 40.6% | 41.8% |
| Macro legality / I/O pins placed | legal · 176/176 | legal · 176/176 |
| PDN connectivity (check_power_grid VDD/VSS, P/G pins) | pass · 0 unconnected | pass · 0 unconnected |
| Clock sinks (core_clk / jtag_tck), ICGs | 1887 / 59, 2 | 5319 / 59, 8 |
| CTS buffers / hold-repair cells | 336 / 591 | 1001 / 2238 |
| Post-CTS hold **before** repair | 656 viol., WS -0.3887 ns | 1483 viol., WS -0.3044 ns |
| Post-global-route setup WS / TNS / viol. | +2.7601 ns / 0.0 / 0 | +2.6893 ns / 0.0 / 0 |
| Post-global-route hold WS / viol. | +0.0202 ns / 0 | +0.0192 ns / 0 |
| Post-global-route max-cap violations | 1 | 2 |
| Global route overflow / usage / wirelength | 0 / 19.37% / 503,076 µm | 0 / 23.93% / 1,783,511 µm |
| Unconstrained endpoints (tie / case / async / other) | 258 / 2 / 1 / 0 | 834 / 8 / 1 / 0 |
| Power estimate (vectorless, typical) | 10.57 mW | 31.69 mW |
| RTL sim / gate-level sim | TB_RESULT PASS checks=186, TB_RESULT PASS checks=186 / TB_RESULT PASS checks=186 | TB_RESULT PASS checks=459, TB_RESULT PASS checks=459 / TB_RESULT PASS checks=459 |

Timing is at a 5.0 ns core clock and 50 ns TCK. These clocks are design constraints chosen for this 45 nm
educational flow, not performance claims. All timing uses *estimated* parasitics (placement or
global-route); none is signoff.

Annotated floorplans are drawn from OpenROAD coordinates: `physical/silicaflux/plots/<config>/`.

## Quick start
```bash
make install-tools                                  # Yosys, Verilator, Icarus, OpenROAD (see docs/REPRODUCE.md)
make silicaflux-all                                 # MIN: audit, techcheck, lint ... groute, reports (~90 s, 1 CPU)
make silicaflux-all CONFIG=silicaflux_hpc_concept   # HPC concept (~5 min, 1 CPU)
make silicaflux-sweep                               # configuration sweep (resumable)
make silicaflux-test                                # 65 tests: unit + EDA smoke + flow results
```
Targets: `silicaflux-{audit,techcheck,lint,sim,synth,floorplan,pdn,place,cts,groute,timing,report,all,sweep,test}`.
`silicaflux-{drc,lvs,signoff}` are **gated**: they refuse with an explanation (exit 2).
There is no detailed-routing target because detailed routing is not functional here.

## Layout
```
rtl/physical/silicaflux_floorplan_wrapper.sv   physical top: stable ports, reset sync, test_mode, DieTop binding
rtl/physical/tech/nangate45/                   technology bindings (SRAM -> fakeram45, ICG -> CLKGATETST_X1)
rtl/standin/                                   STAND-IN DieTop (see docs/STANDIN_DIETOP.md)
rtl/common/, rtl/sim_models/, rtl/filelists/, rtl/lint/
tb/tb_silicaflux.sv                            self-checking system testbench (RTL, tech-bound and gate-level)
physical/silicaflux/config/                    silicaflux_min.yaml, silicaflux_hpc_concept.yaml, tech/, sweeps/
physical/silicaflux/scripts/sfpd/              Python pipeline (planner, legality, reports, plots, sweep, audit)
physical/silicaflux/scripts/tcl/               OpenROAD stage scripts (installed-version commands only)
physical/silicaflux/constraints/               generated SDC per configuration
physical/silicaflux/tech/nangate45/            vendored educational technology subset (+ PROVENANCE, SHA256SUMS)
physical/silicaflux/results/<config>/          netlists, DEF/ODB, pin placement, SDC, timing/congestion/PDN reports, logs
physical/silicaflux/reports/<config>/          JSON/CSV reports, milestones, handoff exports
physical/silicaflux/reports/audit/             repository audit / dependency report
physical/silicaflux/reports/sweeps/min_sweep/  ranked sweep results + chart
physical/silicaflux/plots/<config>/            annotated floorplan views + power-density map
tests/physical/                                pytest suite;  .github/workflows/ CI definition (not pushed)
docs/                                          REPRODUCE, READINESS_AND_OPEN_ISSUES, DRC_LVS_READINESS, STANDIN_DIETOP
```
