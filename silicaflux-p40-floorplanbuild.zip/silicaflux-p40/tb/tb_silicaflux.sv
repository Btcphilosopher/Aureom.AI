// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | tb_silicaflux
// Self-checking system testbench for silicaflux_floorplan_wrapper.
// Runs unchanged against: behavioural RTL, technology-bound RTL (fakeram45 +
// CLKGATETST_X1 models) and the synthesised gate-level netlist (+GATE_LEVEL).
// Golden models are written independently of the RTL (plain loops over arrays).
// Prints "TB_RESULT PASS checks=<n>" or "TB_RESULT FAIL errors=<n>".
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module tb_silicaflux;
  parameter int NV = 1;
  parameter int NT = 1;
  parameter int VBANK_DEPTH = 64;
  parameter int TBANK_DEPTH = 64;
  parameter int SCRATCH_DEPTH = 256;
  parameter int SEED = 40;

  localparam real TCLK = 10.0;
  localparam real TTCK = 47.0;   // asynchronous, slower JTAG clock

  logic clk = 0, rst_n = 0, test_mode = 0;
  logic host_req = 0, host_we = 0;
  logic [15:0] host_addr = 0;
  logic [31:0] host_wdata = 0;
  wire host_ack, host_err;
  wire [31:0] host_rdata;
  wire ext_req, ext_we;
  wire [14:0] ext_addr;
  wire [31:0] ext_wdata;
  logic ext_ack = 0;
  logic [31:0] ext_rdata = 0;
  wire irq;
  logic therm_alert = 0;
  logic tck = 0, tms = 1, tdi = 0, trst_n = 0;
  wire tdo;

  always #(TCLK/2) clk = ~clk;
  always #(TTCK/2) tck = ~tck;

`ifdef GATE_LEVEL
  silicaflux_floorplan_wrapper dut (
`else
  silicaflux_floorplan_wrapper #(.NV(NV), .NT(NT), .VBANK_DEPTH(VBANK_DEPTH),
    .TBANK_DEPTH(TBANK_DEPTH), .SCRATCH_DEPTH(SCRATCH_DEPTH)) dut (
`endif
    .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
    .host_req(host_req), .host_we(host_we), .host_addr(host_addr), .host_wdata(host_wdata),
    .host_ack(host_ack), .host_rdata(host_rdata), .host_err(host_err),
    .ext_req(ext_req), .ext_we(ext_we), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
    .ext_ack(ext_ack), .ext_rdata(ext_rdata), .irq(irq), .therm_alert(therm_alert),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo));

  int errors = 0;
  int checks = 0;
  int rnd_state;

  task automatic check(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin
      errors++;
      $display("[FAIL] %s: got %08h expected %08h (t=%0t)", what, got, exp, $time);
    end
  endtask

  function automatic logic [31:0] prand();
    rnd_state = rnd_state * 1103515245 + 12345;
    return {rnd_state[30:16], rnd_state[14:0], rnd_state[31], rnd_state[15]};
  endfunction

  // ---------------- external memory model (random latency, 4-phase) ----------------
  logic [31:0] extmem [0:32767];
  int ext_lat_seed = 7;
  initial begin
    for (int i = 0; i < 32768; i++) extmem[i] = 32'h0;
    forever begin
      @(posedge clk);
      if (ext_req && !ext_ack) begin
        // dead zone 0x7F00-0x7FFF never acknowledges (RAS timeout test)
        if (ext_addr[14:8] != 7'h7F) begin
          ext_lat_seed = (ext_lat_seed * 1103515245 + 12345);
          repeat ((ext_lat_seed >>> 16) & 3) @(posedge clk);
          #1;
          if (ext_we) extmem[ext_addr] = ext_wdata;
          else        ext_rdata = extmem[ext_addr];
          ext_ack = 1;
          wait (!ext_req);
          @(posedge clk); #1;
          ext_ack = 0;
        end
      end
    end
  end

  // ---------------- host bus tasks (4-phase) ----------------
  task automatic host_access(input logic we, input logic [15:0] a, input logic [31:0] wd,
                             output logic [31:0] rd, output logic err);
    @(posedge clk); #1;
    host_we = we; host_addr = a; host_wdata = wd; host_req = 1;
    wait (host_ack === 1'b1);
    @(posedge clk); #1;
    rd = host_rdata; err = host_err;
    host_req = 0;
    wait (host_ack === 1'b0);
  endtask

  task automatic hw(input logic [15:0] a, input logic [31:0] d);
    logic [31:0] rd; logic e;
    host_access(1'b1, a, d, rd, e);
    if (e) begin errors++; $display("[FAIL] host write err @%04h", a); end
  endtask

  task automatic hr(input logic [15:0] a, output logic [31:0] d);
    logic e;
    host_access(1'b0, a, 32'h0, d, e);
    if (e) begin errors++; $display("[FAIL] host read err @%04h", a); end
  endtask

  localparam logic [15:0] CSR = 16'h4000;
  function automatic logic [15:0] VEC(input int c, input int bank, input int w);
    return 16'h1000 | 16'(c << 10) | 16'(bank << 8) | 16'(w);
  endfunction
  function automatic logic [15:0] TEN(input int c, input int bank, input int w);
    return 16'h2000 | 16'(c << 10) | 16'(bank << 8) | 16'(w);
  endfunction

  // ---------------- command queue helpers ----------------
  int tail = 0;
  task automatic enqueue(input logic [31:0] w0, w1, w2, w3);
    int slot;
    slot = tail % 16;
    hw(16'(slot*4 + 0), w0);
    hw(16'(slot*4 + 1), w1);
    hw(16'(slot*4 + 2), w2);
    hw(16'(slot*4 + 3), w3);
    tail = (tail + 1) % 32;
  endtask
  task automatic doorbell();
    hw(CSR | 16'h02, 32'(tail));
  endtask
  task automatic wait_head(input int max_cycles);
    logic [31:0] h;
    int n;
    n = 0;
    h = 0;
    while ((h[4:0] != tail[4:0]) || (n == 0)) begin
      hr(CSR | 16'h03, h);
      n++;
      if (n > max_cycles) begin
        errors++; $display("[FAIL] queue did not drain");
        h[4:0] = tail[4:0];
      end
    end
  endtask
  task automatic wait_halt(output logic [31:0] status);
    int n;
    n = 0;
    do begin
      hr(CSR | 16'h04, status);
      n++;
    end while (!status[1] && n < 2000);
  endtask

  function automatic logic [31:0] cmd(input int opc, input int sub, input int cl, input int len);
    return (32'(opc) << 28) | (32'(sub) << 24) | (32'(cl) << 16) | 32'(len);
  endfunction

  // ---------------- golden models ----------------
  function automatic logic [31:0] gold_lane(input int op, input logic [31:0] a, input logic [31:0] b);
    logic [31:0] r;
    for (int l = 0; l < 4; l++) begin
      logic signed [7:0] x, y;
      logic signed [15:0] p;
      x = a[8*l +: 8]; y = b[8*l +: 8]; p = x * y;
      case (op)
        0: r[8*l +: 8] = x + y;
        1: r[8*l +: 8] = x - y;
        2: r[8*l +: 8] = (x > y) ? x : y;
        3: r[8*l +: 8] = (x < 0) ? 8'sd0 : x;
        4: r[8*l +: 8] = x ^ y;
        5: r[8*l +: 8] = x & y;
        6: r[8*l +: 8] = p[7:0];
        default: r[8*l +: 8] = 0;
      endcase
    end
    return r;
  endfunction

  function automatic logic signed [31:0] gold_dot(input logic [31:0] a, input logic [31:0] b);
    logic signed [31:0] s;
    s = 0;
    for (int l = 0; l < 4; l++) s += $signed(a[8*l +: 8]) * $signed(b[8*l +: 8]);
    return s;
  endfunction

  // A row-major words, B column-major words -> C[i][j]
  function automatic logic signed [31:0] gold_mm(input logic [127:0] aw, input logic [127:0] bw,
                                                  input int i, input int j);
    logic signed [31:0] s;
    s = 0;
    for (int k = 0; k < 4; k++) s += $signed(aw[32*i + 8*k +: 8]) * $signed(bw[32*j + 8*k +: 8]);
    return s;
  endfunction

  // ---------------- JTAG tasks ----------------
  task automatic tck_cycle(input logic tms_v, input logic tdi_v, output logic tdo_v);
    @(negedge tck); tms = tms_v; tdi = tdi_v;
    @(posedge tck); tdo_v = tdo;
  endtask
  task automatic tap_reset();
    logic d;
    for (int i = 0; i < 6; i++) tck_cycle(1'b1, 1'b0, d);
    tck_cycle(1'b0, 1'b0, d);   // -> Run-Test/Idle
  endtask
  task automatic tap_shift_ir(input logic [3:0] ir);
    logic d;
    tck_cycle(1, 0, d); tck_cycle(1, 0, d);          // Select-DR, Select-IR
    tck_cycle(0, 0, d); tck_cycle(0, 0, d);          // Capture-IR, Shift-IR
    for (int i = 0; i < 4; i++) tck_cycle(i == 3, ir[i], d);  // last bit -> Exit1-IR
    tck_cycle(1, 0, d);                               // Update-IR
    tck_cycle(0, 0, d);                               // Run-Test/Idle
  endtask
  task automatic tap_shift_dr(input int n, input logic [31:0] din, output logic [31:0] dout);
    logic d;
    dout = 0;
    tck_cycle(1, 0, d);                               // Select-DR
    tck_cycle(0, 0, d);                               // Capture-DR
    tck_cycle(0, 0, d);                               // Shift-DR
    for (int i = 0; i < n; i++) begin
      tck_cycle(i == n - 1, din[i], d);
      dout[i] = d;
    end
    tck_cycle(1, 0, d);                               // Update-DR
    tck_cycle(0, 0, d);                               // Run-Test/Idle
  endtask

  // ---------------- test sequence ----------------
  logic [31:0] rd, st;
  logic e;
  logic [31:0] va [64], vb [64];
  logic [127:0] ta1, tb1, ta2, tb2;
  logic [127:0] ta1_c0, tb1_c0;      // cluster-0 operands (T8 reuses TA/TB[0..3] of cluster 0)
  int base_err;
  logic [31:0] ext0_expected;
  logic [31:0] cyc0, cyc1, act0, act1, thr0, thr1;

  initial begin
    rnd_state = SEED;
    repeat (3) @(posedge clk);
    #1 rst_n = 1; trst_n = 1;
    repeat (5) @(posedge clk);

    // ---------- T1: CSR basics ----------
    hr(CSR | 16'h00, rd); check("T1 CHIP_ID", rd, 32'h5346_4001);
    hw(CSR | 16'h0F, 32'hA5A5_5A5A); hr(CSR | 16'h0F, rd); check("T1 SCRATCH", rd, 32'hA5A5_5A5A);
    host_access(1'b0, CSR | 16'h77, 0, rd, e); check("T1 unmapped CSR err", {31'd0, e}, 32'd1);
    hr(CSR | 16'h08, rd); check("T1 PM_CLK_EN reset", rd, 32'h3);

    // ---------- T2: scratchpad + external memory through the fabric ----------
    for (int i = 0; i < 16; i++) begin va[i] = prand(); hw(16'h3000 | 16'(i*13 % SCRATCH_DEPTH), va[i]); end
    for (int i = 0; i < 16; i++) begin hr(16'h3000 | 16'(i*13 % SCRATCH_DEPTH), rd); check("T2 scratch rd", rd, va[i]); end
    for (int i = 0; i < 8; i++) begin vb[i] = prand(); hw(16'h8000 | 16'(i*1021), vb[i]); end
    for (int i = 0; i < 8; i++) begin
      hr(16'h8000 | 16'(i*1021), rd); check("T2 ext rd", rd, vb[i]);
      check("T2 ext model", extmem[i*1021], vb[i]);
    end

    ext0_expected = vb[0];

    // ---------- T3: decode error ----------
    host_access(1'b0, 16'h5000, 0, rd, e);
    check("T3 decode err flag", {31'd0, e}, 32'd1);
    check("T3 decode err data", rd, 32'hDEAD_BEEF);
    hr(CSR | 16'h0E, rd); check("T3 RAS decode count", {16'd0, rd[15:0]}, 32'd1);
    host_access(1'b0, VEC(0, 3, 0), 0, rd, e); check("T3 bad bank err", {31'd0, e}, 32'd1);

    // enable the command processor
    hw(CSR | 16'h01, 32'h1);

    // ---------- T4: vector engine, every op, every cluster ----------
    for (int c = 0; c < NV; c++) begin
      for (int i = 0; i < 8; i++) begin
        va[i] = prand(); vb[i] = prand();
        hw(VEC(c, 0, 4 + i), va[i]);
        hw(VEC(c, 1, 9 + i), vb[i]);
      end
      for (int op = 0; op < 7; op++) enqueue(cmd(2, op, c, 8), 4, 9, op*8);
      enqueue(cmd(2, 7, c, 8), 4, 9, 60);      // DOT8
      doorbell();
      wait_head(5000);
      for (int op = 0; op < 7; op++)
        for (int i = 0; i < 8; i++) begin
          hr(VEC(c, 2, op*8 + i), rd);
          check($sformatf("T4 vec c%0d op%0d i%0d", c, op, i), rd, gold_lane(op, va[i], vb[i]));
        end
      begin
        logic signed [31:0] dsum;
        dsum = 0;
        for (int i = 0; i < 8; i++) dsum += gold_dot(va[i], vb[i]);
        hr(VEC(c, 2, 60), rd); check($sformatf("T4 vec c%0d DOT8", c), rd, dsum);
      end
    end
    hr(CSR | 16'h04, st); check("T4 not halted", {31'd0, st[1]}, 32'd0);

    // ---------- T5: DMA + tensor 4x4 matmul with accumulate, every cluster ----------
    hr(CSR | 16'h0C, act0);
    for (int c = 0; c < NT; c++) begin
      for (int i = 0; i < 4; i++) begin
        ta1[32*i +: 32] = prand(); tb1[32*i +: 32] = prand();
        ta2[32*i +: 32] = prand(); tb2[32*i +: 32] = prand();
        extmem[16'h0010 + i] = ta1[32*i +: 32]; extmem[16'h0014 + i] = tb1[32*i +: 32];
        extmem[16'h0018 + i] = ta2[32*i +: 32]; extmem[16'h001C + i] = tb2[32*i +: 32];
      end
      if (c == 0) begin ta1_c0 = ta1; tb1_c0 = tb1; end
      enqueue(cmd(1, 0, 0, 4), 16'h8010, TEN(c, 0, 0), 0);   // A1 -> TA[0..3]
      enqueue(cmd(1, 0, 0, 4), 16'h8014, TEN(c, 1, 0), 0);   // B1 -> TB[0..3]
      enqueue(cmd(1, 0, 0, 4), 16'h8018, TEN(c, 0, 4), 0);   // A2 -> TA[4..7]
      enqueue(cmd(1, 0, 0, 4), 16'h801C, TEN(c, 1, 4), 0);   // B2 -> TB[4..7]
      enqueue(cmd(3, 0, c, 0), 0, 0, 0);                     // C1 = A1*B1  -> TC[0..15]
      enqueue(cmd(3, 1, c, 0), 4, 4, 16);                    // C2 = C1 + A2*B2 -> TC[16..31]
      enqueue(cmd(1, 0, 0, 16), TEN(c, 2, 16), 16'h8100, 0); // C2 -> ext 0x100
      enqueue(cmd(4, 0, 0, 0), 0, 0, 0);                     // IRQ marker
      doorbell();
      wait_head(20000);
      check($sformatf("T5 irq c%0d", c), {31'd0, irq}, 32'd1);
      hw(CSR | 16'h06, 32'h1);
      check($sformatf("T5 irq clear c%0d", c), {31'd0, irq}, 32'd0);
      for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) begin
          hr(TEN(c, 2, i*4 + j), rd);
          check($sformatf("T5 ten c%0d C1[%0d][%0d]", c, i, j), rd, gold_mm(ta1, tb1, i, j));
          check($sformatf("T5 ten c%0d C2[%0d][%0d]", c, i, j), extmem[16'h0100 + i*4 + j],
                gold_mm(ta1, tb1, i, j) + gold_mm(ta2, tb2, i, j));
        end
    end
    hr(CSR | 16'h0C, act1);
    checks++; if (act1 <= act0) begin errors++; $display("[FAIL] T5 tensor activity counter"); end

    // ---------- T6: error handling and queue halt ----------
    hr(CSR | 16'h07, rd); base_err = rd;
    enqueue(32'hF000_0000, 0, 0, 0);                 // bad opcode
    enqueue(cmd(0, 0, 0, 0), 0, 0, 0);               // NOP must wait for clear
    doorbell();
    wait_halt(st);
    check("T6 halted", {31'd0, st[1]}, 32'd1);
    check("T6 err code opc", {28'd0, st[11:8]}, 32'd1);
    hr(CSR | 16'h03, rd); check("T6 head stops after bad cmd", rd, 32'((tail + 31) % 32));
    hw(CSR | 16'h06, 32'h3);
    wait_head(2000);
    hr(CSR | 16'h07, rd); check("T6 err count", rd, 32'(base_err + 1));
    enqueue(cmd(2, 0, 0, VBANK_DEPTH - 4), 10, 0, 0); // A overflows bank (derived from bank depth)
    doorbell(); wait_halt(st); check("T6 bounds code", {28'd0, st[11:8]}, 32'd4); hw(CSR | 16'h06, 32'h3);
    enqueue(cmd(2, 0, NV, 4), 0, 0, 0);              // cluster index out of range
    doorbell(); wait_halt(st); check("T6 cluster code", {28'd0, st[11:8]}, 32'd2); hw(CSR | 16'h06, 32'h3);
    enqueue(cmd(1, 0, 0, 2), 16'h5000, 16'h3000, 0); // DMA from unmapped address
    doorbell(); wait_halt(st); check("T6 dma code", {28'd0, st[11:8]}, 32'd6); hw(CSR | 16'h06, 32'h3);
    enqueue(cmd(3, 0, 0, 0), TBANK_DEPTH - 2, 0, 0); // tensor A overflows bank (derived from depth)
    doorbell(); wait_halt(st); check("T6 ten bounds code", {28'd0, st[11:8]}, 32'd4); hw(CSR | 16'h06, 32'h3);

    // ---------- T7: clock-domain enable ----------
    hw(CSR | 16'h08, 32'h1);                         // tensor domain off
    enqueue(cmd(3, 0, 0, 0), 0, 0, 0);
    doorbell(); wait_halt(st); check("T7 disabled code", {28'd0, st[11:8]}, 32'd3); hw(CSR | 16'h06, 32'h3);
    hw(CSR | 16'h08, 32'h3);

    // ---------- T8: thermal throttling preserves results, stretches compute ----------
    hr(CSR | 16'h0C, act0); hr(CSR | 16'h0D, thr0);
    enqueue(cmd(3, 0, 0, 0), 0, 0, 32);              // C = A1*B1 -> TC[32..47], unthrottled
    doorbell(); wait_head(5000);
    hr(CSR | 16'h0C, act1); cyc0 = act1 - act0;
    hw(CSR | 16'h09, 32'h5);                         // enable, shift=2 -> duty 1/4
    therm_alert = 1;
    repeat (4) @(posedge clk);
    hr(CSR | 16'h0A, rd); check("T8 PM_STATUS", rd, 32'h3);
    hr(CSR | 16'h0C, act0);
    enqueue(cmd(3, 0, 0, 0), 0, 0, 48);              // same matmul, throttled -> TC[48..63]
    doorbell(); wait_head(5000);
    hr(CSR | 16'h0C, act1); cyc1 = act1 - act0;
    hr(CSR | 16'h0D, thr1);
    therm_alert = 0; hw(CSR | 16'h09, 32'h0);
    checks++; if (!(thr1 > thr0)) begin errors++; $display("[FAIL] T8 throttle counter"); end
    checks++; if (!(cyc1 >= 3 * cyc0)) begin errors++; $display("[FAIL] T8 throttled compute %0d vs %0d", cyc1, cyc0); end
    for (int i = 0; i < 16; i++) begin
      logic [31:0] r0, r1;
      hr(TEN(0, 2, 32 + i), r0); hr(TEN(0, 2, 48 + i), r1);
      check("T8 throttled==unthrottled", r1, r0);
      check("T8 golden", r0, gold_mm(ta1_c0, tb1_c0, i / 4, i % 4));
    end

    // ---------- T9: external memory watchdog ----------
    host_access(1'b0, 16'hFF00, 0, rd, e);
    check("T9 ext timeout err", {31'd0, e}, 32'd1);
    hr(CSR | 16'h0E, rd); check("T9 RAS timeout count", {16'd0, rd[31:16]}, 32'd1);
    hr(16'h8000, rd); check("T9 ext recovers", rd, ext0_expected);

    // ---------- T10: JTAG TAP ----------
    tap_reset();
    tap_shift_dr(32, 32'h0, rd); check("T10 IDCODE after reset", rd, 32'h15F4_0001);
    tap_shift_ir(4'b0001);
    tap_shift_dr(32, 32'h0, rd); check("T10 IDCODE", rd, 32'h15F4_0001);
    tap_shift_ir(4'b1111);
    tap_shift_dr(8, 32'h0000_00A5, rd); check("T10 BYPASS", {24'd0, rd[7:0]}, 32'h0000_004A);
    tap_shift_ir(4'b0010);
    repeat (4) @(posedge tck);
    tap_shift_dr(32, 32'h0, rd);
    begin
      logic [31:0] dc;
      hr(CSR | 16'h05, dc);
      check("T10 STATUS snapshot valid", {31'd0, rd[31]}, 32'd1);
      check("T10 STATUS done_count", {24'd0, rd[30:23]}, {24'd0, dc[7:0]});
      check("T10 STATUS decode errs", {24'd0, rd[14:7]}, 32'd2);
    end

    // ---------- summary ----------
    repeat (10) @(posedge clk);
    if (errors == 0) $display("TB_RESULT PASS checks=%0d", checks);
    else             $display("TB_RESULT FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end

  // global watchdog
  initial begin
    #(TCLK * 400000);
    $display("TB_RESULT FAIL errors=watchdog");
    $finish;
  end
endmodule
