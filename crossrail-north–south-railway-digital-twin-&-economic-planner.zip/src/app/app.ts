import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from './services/crossrail-state';
import { HeaderComponent } from './components/header/header';
import { ProvenanceModalComponent } from './components/provenance-modal/provenance-modal';
import { OverviewComponent } from './components/overview/overview';
import { SchemeBuilderComponent } from './components/scheme-builder/scheme-builder';
import { GisCorridorComponent } from './components/gis-corridor/gis-corridor';
import { AlignmentDesignerComponent } from './components/alignment-designer/alignment-designer';
import { TunnelGeologyComponent } from './components/tunnel-geology/tunnel-geology';
import { StationCapacityComponent } from './components/station-capacity/station-capacity';
import { Construction4dComponent } from './components/construction-4d/construction-4d';
import { OperationsSimulatorComponent } from './components/operations-simulator/operations-simulator';
import { DemandModellingComponent } from './components/demand-modelling/demand-modelling';
import { HousingLandComponent } from './components/housing-land/housing-land';
import { EconomicAppraisalComponent } from './components/economic-appraisal/economic-appraisal';
import { FinanceCostsComponent } from './components/finance-costs/finance-costs';
import { DigitalTwin3dComponent } from './components/digital-twin-3d/digital-twin-3d';
import { DecisionRoomComponent } from './components/decision-room/decision-room';

@Component({
  selector: 'app-root',
  imports: [
    HeaderComponent,
    ProvenanceModalComponent,
    OverviewComponent,
    SchemeBuilderComponent,
    GisCorridorComponent,
    AlignmentDesignerComponent,
    TunnelGeologyComponent,
    StationCapacityComponent,
    Construction4dComponent,
    OperationsSimulatorComponent,
    DemandModellingComponent,
    HousingLandComponent,
    EconomicAppraisalComponent,
    FinanceCostsComponent,
    DigitalTwin3dComponent,
    DecisionRoomComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App {
  state = inject(CrossrailState);
}
