import { computed, Injectable, signal } from '@angular/core';
import {
  INITIAL_ALIGNMENT,
  INITIAL_BOREHOLES,
  INITIAL_CONSTRUCTION_TASKS,
  INITIAL_DEMAND_OD,
  INITIAL_PROVENANCE_RECORDS,
  INITIAL_SCHEMES,
  INITIAL_STATIONS,
  INITIAL_TBMS,
  INITIAL_TUNNELS
} from '../data/default-railway-data';
import {
  AlignmentNode,
  BoreholeData,
  ConstructionTask,
  DemandODPair,
  EconomicAppraisalMetrics,
  MonteCarloResult,
  ProvenanceRecord,
  SchemeConfig,
  SchemeOptionId,
  StationData,
  TbmMachine,
  TunnelBore
} from '../models';

export type NavigationTab = 
  | 'overview' 
  | 'scheme' 
  | 'gis' 
  | 'alignment' 
  | 'tunnels' 
  | 'stations' 
  | 'construction' 
  | 'operations' 
  | 'demand' 
  | 'land_housing' 
  | 'economics' 
  | 'finance' 
  | 'digital_twin' 
  | 'decision_room' 
  | 'scenarios';

@Injectable({
  providedIn: 'root'
})
export class CrossrailState {
  // Navigation & UI state
  activeTab = signal<NavigationTab>('overview');
  activeProvenance = signal<ProvenanceRecord | null>(null);
  selectedStationId = signal<string>('st_tcr');
  selectedNodeId = signal<string | null>('al_09');
  
  // 4D Construction Simulation Clock
  simYear = signal<number>(2033);
  isPlayingSim = signal<boolean>(false);
  simSpeed = signal<number>(1);
  private simIntervalId: ReturnType<typeof setInterval> | null = null;

  // Active Scheme selection
  activeSchemeId = signal<SchemeOptionId>('baseline');
  schemes = signal<SchemeConfig[]>(INITIAL_SCHEMES);

  // Core engineering objects
  alignmentNodes = signal<AlignmentNode[]>(INITIAL_ALIGNMENT);
  stations = signal<StationData[]>(INITIAL_STATIONS);
  tunnels = signal<TunnelBore[]>(INITIAL_TUNNELS);
  tbms = signal<TbmMachine[]>(INITIAL_TBMS);
  boreholes = signal<BoreholeData[]>(INITIAL_BOREHOLES);
  constructionTasks = signal<ConstructionTask[]>(INITIAL_CONSTRUCTION_TASKS);
  demandODPairs = signal<DemandODPair[]>(INITIAL_DEMAND_OD);
  provenanceRecords = signal<ProvenanceRecord[]>(INITIAL_PROVENANCE_RECORDS);

  // User Interactive Scenario Modifiers (Sensitivity adjustments)
  capexMultiplier = signal<number>(1.0); // e.g. 1.2 for +20%
  ridershipMultiplier = signal<number>(1.0); // e.g. 0.85 for -15%
  openingDelayYears = signal<number>(0); // 0 to 5 years
  discountRateOverride = signal<number>(3.5); // 3.5%
  trainFrequencyTph = signal<number>(30); // 12 to 36 tph
  landValueUpliftMultiplier = signal<number>(1.0);

  // Active Scheme object
  activeScheme = computed(() => {
    const id = this.activeSchemeId();
    return this.schemes().find(s => s.id === id) || this.schemes()[0];
  });

  // Selected station
  selectedStation = computed(() => {
    const id = this.selectedStationId();
    return this.stations().find(s => s.id === id) || this.stations()[0];
  });

  // Selected alignment node
  selectedNode = computed(() => {
    const id = this.selectedNodeId();
    return this.alignmentNodes().find(n => n.id === id) || this.alignmentNodes()[0];
  });

  // Calculated Route Geometry Metrics
  totalRouteLengthKm = computed(() => {
    const nodes = this.alignmentNodes();
    if (nodes.length === 0) return 92.4;
    return Math.max(...nodes.map(n => n.chainageKm));
  });

  totalTunnelLengthKm = computed(() => {
    const portals = this.alignmentNodes().filter(n => n.type === 'portal');
    if (portals.length >= 2) {
      return Math.abs(portals[1].chainageKm - portals[0].chainageKm);
    }
    return 36.8;
  });

  totalTrackKm = computed(() => {
    return Number((this.totalRouteLengthKm() * 2).toFixed(1));
  });

  // Capital Cost Model Breakdown (£ billions)
  capexBreakdown = computed(() => {
    const routeKm = this.totalRouteLengthKm();
    const tunnelKm = this.totalTunnelLengthKm();
    const undergroundStationsCount = this.stations().filter(s => s.type === 'DEEP TUBE STATION' || s.type === 'CUT-AND-COVER BOX').length;
    const surfaceStationsCount = this.stations().length - undergroundStationsCount;
    const mult = this.capexMultiplier();

    // Rates based on UK Rail Major Project Benchmarks (Crossrail / HS2 / Jubilee Line Extension)
    const tunnellingCost = Number((tunnelKm * 0.185 * mult).toFixed(2)); // £185m/km twin-bore deep EPB
    const stationCavernsCost = Number((undergroundStationsCount * 0.62 * mult).toFixed(2)); // £620m per central deep interchange station
    const surfaceStationsAndWorks = Number(((surfaceStationsCount * 0.12 + (routeKm - tunnelKm) * 0.045) * mult).toFixed(2));
    const systemsAndSignalling = Number(((routeKm * 0.065 + this.trainFrequencyTph() * 0.04) * mult).toFixed(2)); // 25kV OLE + CBTC
    const rollingStock = Number(((this.trainFrequencyTph() * 1.8 * 0.022) * mult).toFixed(2)); // High-capacity EMUs
    const landAndSafeguarding = Number((2.45 * mult).toFixed(2));
    const indirectsAndDesign = Number(((tunnellingCost + stationCavernsCost) * 0.16).toFixed(2));
    const optimismBiasAndRisk = Number(((tunnellingCost + stationCavernsCost + surfaceStationsAndWorks + systemsAndSignalling) * 0.28).toFixed(2));

    const total = Number((tunnellingCost + stationCavernsCost + surfaceStationsAndWorks + systemsAndSignalling + rollingStock + landAndSafeguarding + indirectsAndDesign + optimismBiasAndRisk).toFixed(2));

    return {
      tunnellingCost,
      stationCavernsCost,
      surfaceStationsAndWorks,
      systemsAndSignalling,
      rollingStock,
      landAndSafeguarding,
      indirectsAndDesign,
      optimismBiasAndRisk,
      total
    };
  });

  // Annual Operations & Maintenance Cost (£ millions)
  annualOpex = computed(() => {
    const routeKm = this.totalRouteLengthKm();
    const tph = this.trainFrequencyTph();
    const stationsCount = this.stations().length;
    
    const tractionEnergyM = Number((tph * routeKm * 0.12).toFixed(1));
    const trackAndTunnelMaintM = Number((routeKm * 1.45).toFixed(1));
    const stationOpsM = Number((stationsCount * 4.8).toFixed(1));
    const rollingStockMaintM = Number((tph * 2.2 * 1.8).toFixed(1));
    const adminAndOverheadsM = Number(((tractionEnergyM + trackAndTunnelMaintM + stationOpsM) * 0.12).toFixed(1));

    const totalOpexM = Number((tractionEnergyM + trackAndTunnelMaintM + stationOpsM + rollingStockMaintM + adminAndOverheadsM).toFixed(1));
    return {
      tractionEnergyM,
      trackAndTunnelMaintM,
      stationOpsM,
      rollingStockMaintM,
      adminAndOverheadsM,
      totalOpexM
    };
  });

  // Transport Demand & Ridership Model
  demandMetrics = computed(() => {
    const rMult = this.ridershipMultiplier();
    const tph = this.trainFrequencyTph();
    const freqFactor = Math.sqrt(tph / 30);
    
    // Baseline annual passenger journeys (Millions)
    const baseRidershipM = 270.0;
    const annualRidershipM = Number((baseRidershipM * rMult * freqFactor).toFixed(1));
    const dailyRidershipPax = Math.round((annualRidershipM * 1000000) / 330);
    const peakHourPax = Math.round(dailyRidershipPax * 0.18);
    const avgJourneyTimeSavingsMin = 18.4;
    const modeShiftFromHighwayPaxDaily = Math.round(dailyRidershipPax * 0.23);

    // Revenue Model (£ Millions)
    const avgFareGbp = 3.65;
    const annualFareRevenueM = Number(((annualRidershipM * avgFareGbp)).toFixed(1));
    const annualRetailAdvertisingM = Number((annualFareRevenueM * 0.14).toFixed(1));
    const totalCommercialRevenueM = Number((annualFareRevenueM + annualRetailAdvertisingM).toFixed(1));

    return {
      annualRidershipM,
      dailyRidershipPax,
      peakHourPax,
      avgJourneyTimeSavingsMin,
      modeShiftFromHighwayPaxDaily,
      annualFareRevenueM,
      annualRetailAdvertisingM,
      totalCommercialRevenueM
    };
  });

  // Housing, Land & Employment Model
  housingAndLandMetrics = computed(() => {
    const landMult = this.landValueUpliftMultiplier();
    const stationsList = this.stations();
    
    let totalHomes500m = 0;
    let totalHomes1000m = 0;
    let totalDevelopableHa = 0;
    let totalDirectJobs = 0;
    let totalModelledValueUpliftM = 0;

    stationsList.forEach(st => {
      totalHomes500m += st.housingPotential500m;
      totalHomes1000m += st.housingPotential1000m;
      totalDevelopableHa += st.developableLandHa;
      totalDirectJobs += st.directStationAreaJobs;
      const baseVal = st.developableLandHa * st.currentLandValueMperHa;
      const upliftVal = baseVal * (st.modelledValueUpliftPct / 100) * landMult;
      totalModelledValueUpliftM += upliftVal;
    });

    const totalHomesEnabled = Math.round(totalHomes1000m * 1.08);
    const directConstructionJobs = 28500;
    const permanentOperationalJobs = 3400;
    const accessibilityEnabledJobsTotal = Math.round(totalDirectJobs * 1.65);

    return {
      totalHomes500m,
      totalHomes1000m,
      totalHomesEnabled,
      totalDevelopableHa: Number(totalDevelopableHa.toFixed(1)),
      directConstructionJobs,
      permanentOperationalJobs,
      accessibilityEnabledJobsTotal,
      totalModelledValueUpliftM: Number(totalModelledValueUpliftM.toFixed(1))
    };
  });

  // Full 60-Year Economic Cost-Benefit Analysis (DfT WebTAG Standards)
  economicAppraisal = computed<EconomicAppraisalMetrics>(() => {
    const capex = this.capexBreakdown().total;
    const annualOpexM = this.annualOpex().totalOpexM;
    const annualFareM = this.demandMetrics().annualFareRevenueM;
    const annualNonFareM = this.demandMetrics().annualRetailAdvertisingM;
    const ridershipM = this.demandMetrics().annualRidershipM;
    const housing = this.housingAndLandMetrics();
    const discRate = this.discountRateOverride() / 100;
    const delay = this.openingDelayYears();

    // 60-Year Discounted Calculations
    let pvBenefitsGbpBn = 0;
    let timeSavingsPvBn = 0;
    let agglomerationPvBn = 0;
    let labourMarketPvBn = 0;
    let carbonPvBn = 0;
    let reliabilityAccidentsPvBn = 0;

    const baseYear = 2026;
    const openingYear = 2038 + delay;

    for (let yr = openingYear; yr <= baseYear + 60; yr++) {
      const t = yr - baseYear;
      const discountFactor = Math.pow(1 / (1 + discRate), t);
      
      // Annual monetised benefits (£bn)
      const annualTimeSavings = (ridershipM * 18.4 * (14.80 / 60)) / 1000; // Value of time £14.80/hr
      const annualAgglomeration = (annualTimeSavings * 0.42); // Wider agglomeration elasticity
      const annualLabourDeepening = (annualTimeSavings * 0.22);
      const annualCarbon = 0.085; // Mode shift from highway
      const annualReliability = 0.065;

      timeSavingsPvBn += annualTimeSavings * discountFactor;
      agglomerationPvBn += annualAgglomeration * discountFactor;
      labourMarketPvBn += annualLabourDeepening * discountFactor;
      carbonPvBn += annualCarbon * discountFactor;
      reliabilityAccidentsPvBn += annualReliability * discountFactor;
    }

    pvBenefitsGbpBn = Number((timeSavingsPvBn + agglomerationPvBn + labourMarketPvBn + carbonPvBn + reliabilityAccidentsPvBn).toFixed(2));

    // Present Value of Costs (Discounted Capex spread over 10 yrs + Discounted Opex over 60 yrs - Residual value)
    let pvCostsGbpBn = capex * 0.82; // Discounted capital spend schedule
    for (let yr = openingYear; yr <= baseYear + 60; yr++) {
      const t = yr - baseYear;
      const discountFactor = Math.pow(1 / (1 + discRate), t);
      pvCostsGbpBn += (annualOpexM / 1000) * discountFactor;
    }
    // Net out commercial farebox revenue if viewed from public fiscal stance, but standard WebTAG keeps PVC as public outlay
    pvCostsGbpBn = Number(pvCostsGbpBn.toFixed(2));

    const npvGbpBn = Number((pvBenefitsGbpBn - pvCostsGbpBn).toFixed(2));
    const bcr = Number((pvBenefitsGbpBn / Math.max(0.1, pvCostsGbpBn)).toFixed(2));

    return {
      capexTotalGbpBn: capex,
      annualOpexGbpM: annualOpexM,
      annualFareRevenueGbpM: annualFareM,
      annualNonFareRevenueGbpM: annualNonFareM,
      pvCostsGbpBn,
      pvBenefitsGbpBn,
      npvGbpBn,
      bcr,
      timeSavingsPvBn: Number(timeSavingsPvBn.toFixed(2)),
      agglomerationProductivityPvBn: Number(agglomerationPvBn.toFixed(2)),
      labourMarketdeepeningPvBn: Number(labourMarketPvBn.toFixed(2)),
      carbonReductionPvBn: Number(carbonPvBn.toFixed(2)),
      reliabilityAccidentsPvBn: Number(reliabilityAccidentsPvBn.toFixed(2)),
      homesEnabledTotal: housing.totalHomesEnabled,
      directJobsConstruction: housing.directConstructionJobs,
      permanentOperationalJobs: housing.permanentOperationalJobs,
      accessibilityEnabledJobsTotal: housing.accessibilityEnabledJobsTotal,
      annualRidershipMillions: ridershipM
    };
  });

  // 10,000-Iteration Monte Carlo Simulation Result
  monteCarloSimulation = computed<MonteCarloResult>(() => {
    const baseCapex = this.capexBreakdown().total;
    const baseRidership = this.demandMetrics().annualRidershipM;
    const baseBCR = this.economicAppraisal().bcr;
    const baseNPV = this.economicAppraisal().npvGbpBn;

    // Seeded synthetic distribution generator
    const costDistribution: number[] = [];
    const bcrDistribution: number[] = [];
    const ridershipDistribution: number[] = [];
    const npvDistribution: number[] = [];

    const iterations = 10000;
    // Box-Muller normal approximation
    for (let i = 0; i < iterations; i++) {
      const u1 = Math.random();
      const u2 = Math.random();
      const z0 = Math.sqrt(-2.0 * Math.log(u1 || 0.0001)) * Math.cos(2.0 * Math.PI * u2);
      const z1 = Math.sqrt(-2.0 * Math.log(u1 || 0.0001)) * Math.sin(2.0 * Math.PI * u2);

      // Cost has right-skewed lognormal distribution (mean = baseCapex, sd = 15%)
      const simCost = Number((baseCapex * Math.exp(z0 * 0.14 - 0.01)).toFixed(2));
      const simRidership = Number((baseRidership * (1 + z1 * 0.12)).toFixed(1));
      const simBCR = Number((baseBCR * (simRidership / baseRidership) / (simCost / baseCapex)).toFixed(2));
      const simNPV = Number((baseNPV + (simRidership - baseRidership) * 0.35 - (simCost - baseCapex) * 1.1).toFixed(2));

      costDistribution.push(simCost);
      bcrDistribution.push(simBCR);
      ridershipDistribution.push(simRidership);
      npvDistribution.push(simNPV);
    }

    costDistribution.sort((a, b) => a - b);
    bcrDistribution.sort((a, b) => a - b);
    ridershipDistribution.sort((a, b) => a - b);
    npvDistribution.sort((a, b) => a - b);

    return {
      iterations,
      costDistribution,
      bcrDistribution,
      ridershipDistribution,
      npvDistribution,
      costP10: costDistribution[Math.floor(iterations * 0.1)],
      costP50: costDistribution[Math.floor(iterations * 0.5)],
      costP90: costDistribution[Math.floor(iterations * 0.9)],
      bcrP10: bcrDistribution[Math.floor(iterations * 0.1)],
      bcrP50: bcrDistribution[Math.floor(iterations * 0.5)],
      bcrP90: bcrDistribution[Math.floor(iterations * 0.9)],
      ridershipP10: ridershipDistribution[Math.floor(iterations * 0.1)],
      ridershipP50: ridershipDistribution[Math.floor(iterations * 0.5)],
      ridershipP90: ridershipDistribution[Math.floor(iterations * 0.9)]
    };
  });

  // TBM Simulation Progress at current simYear
  tbmSimStatus = computed(() => {
    const yr = this.simYear();
    const tbms = this.tbms();

    return tbms.map(tbm => {
      let activeKm = 0;
      let status = tbm.status;

      if (yr < 2031) {
        activeKm = 0;
        status = 'COMMISSIONING';
      } else if (yr >= 2037) {
        activeKm = tbm.totalDriveKm;
        status = 'COMPLETED';
      } else {
        const progressFrac = Math.min(1, Math.max(0, (yr - 2031) / 5.5));
        activeKm = Number((tbm.totalDriveKm * progressFrac).toFixed(2));
        status = progressFrac >= 1 ? 'BREAKTHROUGH' : 'BORING';
      }

      const segments = Math.round((activeKm / tbm.totalDriveKm) * tbm.totalSegmentsNeeded);
      const spoilTonnes = Math.round(activeKm * 78000);

      return {
        ...tbm,
        drivenKm: activeKm,
        status,
        installedSegmentsCount: segments,
        spoilExcavatedTonnes: spoilTonnes
      };
    });
  });

  // Spoil Logistics Breakdown (Truck vs Rail vs Barge)
  spoilLogistics = computed(() => {
    let totalSpoilTonnes = 0;
    this.tbmSimStatus().forEach(t => totalSpoilTonnes += t.spoilExcavatedTonnes);
    
    const bargeTonnes = Math.round(totalSpoilTonnes * 0.55); // 55% River Thames barge transport
    const railTonnes = Math.round(totalSpoilTonnes * 0.35);  // 35% freight rail
    const truckTonnes = Math.round(totalSpoilTonnes * 0.10); // 10% electric/HGV truck

    const bargeMovements = Math.round(bargeTonnes / 1200); // 1,200 tonne barges
    const railMovements = Math.round(railTonnes / 1500);   // 1,500 tonne freight trains
    const truckMovements = Math.round(truckTonnes / 20);   // 20 tonne tippers

    return {
      totalSpoilTonnes,
      bargeTonnes,
      railTonnes,
      truckTonnes,
      bargeMovements,
      railMovements,
      truckMovements,
      co2SavedVsAllRoadTonnes: Math.round(totalSpoilTonnes * 0.0142)
    };
  });

  // Methods for user actions
  selectTab(tab: NavigationTab) {
    this.activeTab.set(tab);
  }

  setScheme(schemeId: SchemeOptionId) {
    this.activeSchemeId.set(schemeId);
    const target = this.schemes().find(s => s.id === schemeId);
    if (target) {
      if (schemeId === 'option_a') {
        this.capexMultiplier.set(1.05);
        this.trainFrequencyTph.set(32);
      } else if (schemeId === 'option_b') {
        this.capexMultiplier.set(0.85);
        this.trainFrequencyTph.set(24);
      } else if (schemeId === 'london_growth_2050') {
        this.capexMultiplier.set(1.22);
        this.trainFrequencyTph.set(36);
        this.landValueUpliftMultiplier.set(1.4);
      } else {
        this.capexMultiplier.set(1.0);
        this.trainFrequencyTph.set(30);
        this.landValueUpliftMultiplier.set(1.0);
      }
    }
  }

  updateAlignmentNodeDepth(nodeId: string, deltaDepthM: number) {
    this.alignmentNodes.update(nodes => 
      nodes.map(n => {
        if (n.id === nodeId) {
          const newDepth = Math.max(0, n.depthBelowSurfaceM + deltaDepthM);
          return {
            ...n,
            depthBelowSurfaceM: newDepth,
            trackElevationM: n.groundElevationM - newDepth
          };
        }
        return n;
      })
    );
  }

  updateAlignmentNodeRadius(nodeId: string, radiusM: number) {
    this.alignmentNodes.update(nodes =>
      nodes.map(n => n.id === nodeId ? { ...n, horizontalRadiusM: radiusM } : n)
    );
  }

  updateStationDevelopableLand(stationId: string, additionalHa: number) {
    this.stations.update(stations =>
      stations.map(st => {
        if (st.id === stationId) {
          const newHa = Math.max(1, st.developableLandHa + additionalHa);
          return {
            ...st,
            developableLandHa: newHa,
            housingPotential500m: Math.round(newHa * 260),
            housingPotential1000m: Math.round(newHa * 580)
          };
        }
        return st;
      })
    );
  }

  toggleSimPlay() {
    if (this.isPlayingSim()) {
      this.pauseSim();
    } else {
      this.playSim();
    }
  }

  playSim() {
    this.isPlayingSim.set(true);
    if (this.simIntervalId) clearInterval(this.simIntervalId);
    
    this.simIntervalId = setInterval(() => {
      const curr = this.simYear();
      if (curr >= 2044) {
        this.simYear.set(2028);
      } else {
        this.simYear.set(curr + 1);
      }
    }, 2000 / this.simSpeed());
  }

  pauseSim() {
    this.isPlayingSim.set(false);
    if (this.simIntervalId) {
      clearInterval(this.simIntervalId);
      this.simIntervalId = null;
    }
  }

  setSimYear(year: number) {
    this.simYear.set(year);
  }

  openProvenance(metricKey: string) {
    const rec = this.provenanceRecords().find(r => r.metricKey === metricKey);
    if (rec) {
      this.activeProvenance.set(rec);
    } else {
      this.activeProvenance.set({
        metricKey,
        label: `${metricKey} Parameter Data Provenance`,
        source: 'SYNTHETIC STRATEGIC MODEL',
        citation: 'Crossrail North-South Integrated Strategic Development Model (2026)',
        baseYear: 2026,
        model: 'Dynamic Cascading Railway Infrastructure & Spatial Economic Engine',
        assumptions: ['Transparent parametric propagation based on UK rail engineering guidelines'],
        calculationMethod: 'Derived dynamically from active alignment geometry, service patterns and WebTAG elasticities',
        confidence: 'HIGH'
      });
    }
  }

  closeProvenance() {
    this.activeProvenance.set(null);
  }
}
