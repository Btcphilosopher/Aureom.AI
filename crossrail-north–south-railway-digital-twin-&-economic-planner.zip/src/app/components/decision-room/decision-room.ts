import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-decision-room',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6 max-w-7xl mx-auto">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-purple-400">Strategic Outline Business Case (SOBC)</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">HM Treasury Five-Case Model Evidence Dossier</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Crossrail North–South Decision Room &amp; Dossier</h2>
        </div>

        <!-- Export Buttons -->
        <div class="flex flex-wrap items-center gap-2">
          <button 
            (click)="exportJson()"
            class="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200 rounded-lg transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-sky-400">data_object</mat-icon>
            <span>Export JSON</span>
          </button>

          <button 
            (click)="exportCsv()"
            class="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200 rounded-lg transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-emerald-400">table_chart</mat-icon>
            <span>Export CSV</span>
          </button>

          <button 
            (click)="printReport()"
            class="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">print</mat-icon>
            <span>Print SOBC Dossier</span>
          </button>
        </div>
      </div>

      <!-- Strategic Disclaimer Notice -->
      <div class="p-4 bg-slate-900/90 border border-slate-800 rounded-xl flex items-start gap-3 text-xs text-slate-300">
        <mat-icon class="text-sky-400 shrink-0 mt-0.5">account_balance</mat-icon>
        <div>
          <span class="font-bold text-white block mb-0.5">Five-Case Model Evidence Transparency</span>
          <span>All metrics below are derived transparently from the integrated engineering, demand, and economic appraisal cascade. No automated black-box declarations of feasibility are asserted; decision-makers assess trade-offs across capital intensity, housing unlock, and network relief.</span>
        </div>
      </div>

      <!-- The HM Treasury 5-Case Framework Tabs -->
      <div class="space-y-4">
        <!-- 1. The Strategic Case -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 class="text-sm font-bold font-mono text-sky-400 uppercase flex items-center gap-2">
              <span class="w-5 h-5 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center text-xs">1</span>
              <span>The Strategic Case (Connectivity, Capacity &amp; Housing)</span>
            </h3>
            <span class="text-[10px] text-slate-400 font-mono">London Growth &amp; Decongestion</span>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300">
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Strategic Transport Problem:</span>
              <p>Severe structural overcrowding on Northern, Victoria, and Piccadilly Underground lines; lack of direct high-capacity rail connectivity between Surrey and Hertfordshire via central London.</p>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Capacity Solution:</span>
              <p>36.8km twin-bore deep regional tunnel delivering 45,000 passengers per hour per direction with seamless cross-platform interchange with Elizabeth Line at Tottenham Court Road.</p>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Spatial Regeneration Impact:</span>
              <p>Unlocks over {{ state.housingAndLandMetrics().totalHomesEnabled.toLocaleString() }} new homes in key Opportunity Areas including Upper Lea Valley, Northumberland Park, and Wimbledon.</p>
            </div>
          </div>
        </div>

        <!-- 2. The Economic Case -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 class="text-sm font-bold font-mono text-emerald-400 uppercase flex items-center gap-2">
              <span class="w-5 h-5 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">2</span>
              <span>The Economic Case (Value for Money &amp; WebTAG Appraisal)</span>
            </h3>
            <span class="text-[10px] text-emerald-400 font-mono">BCR {{ state.economicAppraisal().bcr }}</span>
          </div>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 text-[10px] block uppercase">Present Value Benefits</span>
              <span class="text-lg font-bold text-emerald-400 mt-1 block">£{{ state.economicAppraisal().pvBenefitsGbpBn }}bn</span>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 text-[10px] block uppercase">Present Value Costs</span>
              <span class="text-lg font-bold text-amber-300 mt-1 block">£{{ state.economicAppraisal().pvCostsGbpBn }}bn</span>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 text-[10px] block uppercase">Net Present Value</span>
              <span class="text-lg font-bold text-sky-300 mt-1 block">£{{ state.economicAppraisal().npvGbpBn }}bn</span>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 text-[10px] block uppercase">Agglomeration Uplift</span>
              <span class="text-lg font-bold text-white mt-1 block">£{{ state.economicAppraisal().agglomerationProductivityPvBn }}bn</span>
            </div>
          </div>
        </div>

        <!-- 3. The Commercial & Financial Case -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 class="text-sm font-bold font-mono text-amber-400 uppercase flex items-center gap-2">
              <span class="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs">3</span>
              <span>The Commercial &amp; Financial Case (Funding &amp; Procurement)</span>
            </h3>
            <span class="text-[10px] text-amber-400 font-mono">£{{ state.capexBreakdown().total }}bn Capex</span>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
            <div class="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-1.5">
              <span class="text-slate-400 block text-[10px] font-mono">Procurement Strategy:</span>
              <p>NEC4 Target Price Contracts with pain/gain share mechanisms across 4 major tunnelling drive packages, 12 station design-and-build contracts, and an integrated Railway Systems framework.</p>
            </div>
            <div class="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 space-y-1.5">
              <span class="text-slate-400 block text-[10px] font-mono">Annual Operational Sustainability:</span>
              <p>Commercial farebox and retail revenue of £{{ state.demandMetrics().totalCommercialRevenueM }}m/yr fully covers annual operating expenditure of £{{ state.annualOpex().totalOpexM }}m/yr with positive operating surplus.</p>
            </div>
          </div>
        </div>

        <!-- 4. The Management Case -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 class="text-sm font-bold font-mono text-purple-400 uppercase flex items-center gap-2">
              <span class="w-5 h-5 rounded bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs">4</span>
              <span>The Management Case (Programme Delivery &amp; Risk Governance)</span>
            </h3>
            <span class="text-[10px] text-purple-300 font-mono">2028 → 2038 Delivery Schedule</span>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300">
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Statutory Powers:</span>
              <p>Hybrid Bill in Parliament with Environmental Impact Assessment (EIA) and active 2015 safeguarding refresh.</p>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Risk Governance:</span>
              <p>Quantitative Schedule and Cost Risk Assessment (QSRA/QCRA) with 28% optimism bias contingency reserve.</p>
            </div>
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Systems Integration:</span>
              <p>Phased testing regime with digital twin simulation of rolling stock CBTC interlockings and trial operations.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DecisionRoomComponent {
  state = inject(CrossrailState);

  exportJson() {
    const data = {
      project: 'Crossrail North-South Railway Digital Twin',
      activeScheme: this.state.activeScheme(),
      alignmentNodes: this.state.alignmentNodes(),
      stations: this.state.stations(),
      capexBreakdown: this.state.capexBreakdown(),
      economicAppraisal: this.state.economicAppraisal(),
      monteCarlo: this.state.monteCarloSimulation(),
      generatedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `crossrail_north_south_sobc_${this.state.activeSchemeId()}.json`;
    a.click();
  }

  exportCsv() {
    const rows = [
      ['Station Name', 'Code', 'Zone', 'Borough', 'Depth (m)', 'Platforms', 'AM Entries', 'Homes Enabled (1km)', 'Land Uplift (%)'],
      ...this.state.stations().map(s => [
        s.name, s.code, s.zone, s.borough, s.depthMeters, s.platformsCount, s.amPeakEntries, s.housingPotential1000m, s.modelledValueUpliftPct
      ])
    ];
    const csvContent = rows.map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `crossrail_north_south_stations_${this.state.activeSchemeId()}.csv`;
    a.click();
  }

  printReport() {
    window.print();
  }
}
