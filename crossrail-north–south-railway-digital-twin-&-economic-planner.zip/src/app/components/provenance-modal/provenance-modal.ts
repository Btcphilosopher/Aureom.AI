import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-provenance-modal',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (state.activeProvenance(); as prov) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-150">
        <div class="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden text-slate-100">
          <!-- Header -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
            <div class="flex items-center gap-3">
              <span class="p-2 bg-sky-500/10 text-sky-400 rounded-lg border border-sky-500/20">
                <mat-icon class="text-sky-400">verified</mat-icon>
              </span>
              <div>
                <h3 class="text-base font-bold tracking-tight text-white">{{ prov.label }}</h3>
                <div class="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span class="text-sky-400 font-mono">{{ prov.source }}</span>
                  <span>·</span>
                  <span>Base Year {{ prov.baseYear }}</span>
                  <span>·</span>
                  <span class="text-emerald-400 font-medium">{{ prov.confidence }} Confidence</span>
                </div>
              </div>
            </div>
            <button 
              (click)="state.closeProvenance()" 
              class="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Close provenance modal">
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <!-- Body -->
          <div class="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-sm">
            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">Authoritative Citation &amp; Evidence Baseline</h4>
              <p class="text-slate-200 bg-slate-950/50 p-3 rounded-lg border border-slate-800/80 font-mono text-xs">
                {{ prov.citation }}
              </p>
            </div>

            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">Analytical Model Applied</h4>
              <p class="text-slate-300 font-medium">
                {{ prov.model }}
              </p>
            </div>

            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Key Underlying Engineering &amp; Economic Assumptions</h4>
              <ul class="space-y-2">
                @for (item of prov.assumptions; track $index) {
                  <li class="flex items-start gap-2 text-slate-300 text-xs bg-slate-800/40 p-2.5 rounded border border-slate-800">
                    <span class="text-sky-400 mt-0.5">▸</span>
                    <span>{{ item }}</span>
                  </li>
                }
              </ul>
            </div>

            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">Calculation Methodology</h4>
              <p class="text-slate-300 text-xs bg-slate-950/40 p-3 rounded border border-slate-800 leading-relaxed font-mono">
                {{ prov.calculationMethod }}
              </p>
            </div>

            <div class="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-200/90 flex items-start gap-2">
              <mat-icon class="text-amber-400 shrink-0 text-base">info</mat-icon>
              <span>
                <strong>Model Discipline Note:</strong> While Crossrail 2 safeguarding remains active, statutory alignment and financing decisions are currently paused. All outputs in this platform represent synthetic strategic planning scenarios and WebTAG-compliant economic forecasts.
              </span>
            </div>
          </div>

          <!-- Footer -->
          <div class="flex items-center justify-end px-6 py-3 border-t border-slate-800 bg-slate-950/60">
            <button 
              (click)="state.closeProvenance()" 
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors">
              Dismiss Inspection
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class ProvenanceModalComponent {
  state = inject(CrossrailState);
}
