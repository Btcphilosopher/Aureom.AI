import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { SchemeOptionId } from '../../models';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-scheme-builder',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-purple-400">Strategic Scenario &amp; Option Matrix</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Multi-Option Configuration &amp; Parameter Workbench</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Scheme Builder &amp; Strategic Options Manager</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-purple-500/10 border border-purple-500/20 px-3 py-1.5 rounded-lg text-purple-300">
            Active: {{ state.activeScheme().name }}
          </span>
        </div>
      </div>

      <!-- Scheme Version Selector Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (scheme of state.schemes(); track scheme.id) {
          <button 
            type="button"
            (click)="selectScheme(scheme.id)"
            [class]="state.activeSchemeId() === scheme.id ? 'border-sky-500 ring-1 ring-sky-500 bg-slate-900' : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'"
            class="p-4 rounded-xl border transition-all cursor-pointer space-y-3 relative flex flex-col justify-between text-left w-full">
            <div>
              <div class="flex justify-between items-start">
                <span class="text-[10px] font-mono font-bold uppercase text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
                  {{ scheme.id.replace('_', ' ') }}
                </span>
                @if (state.activeSchemeId() === scheme.id) {
                  <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                }
              </div>
              <h4 class="font-bold text-white text-sm mt-2 leading-snug">{{ scheme.name }}</h4>
              <p class="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">{{ scheme.description }}</p>
            </div>

            <div class="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-400 w-full">
              <div>
                <span>Route / Tunnel:</span>
                <span class="text-white block font-bold">{{ scheme.totalLengthKm }}k / {{ scheme.tunnelLengthKm }}k</span>
              </div>
              <div>
                <span>Peak Headway:</span>
                <span class="text-emerald-400 block font-bold">{{ scheme.peakTph }} tph</span>
              </div>
            </div>
          </button>
        }
      </div>

      <!-- Factual Scenario Comparison Matrix (No Black Box 'Best' Badge) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
        <div class="px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div>
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Factual Strategic Option Comparison Matrix</h3>
            <p class="text-[11px] text-slate-400">All options evaluated under standard HM Treasury Green Book and DfT WebTAG guidelines.</p>
          </div>
          <span class="text-[10px] text-slate-400 font-mono">4 Discrete Strategic Configurations</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead class="bg-slate-950/80 border-b border-slate-800 font-mono text-[10px] text-slate-400 uppercase">
              <tr>
                <th class="py-3 px-4">Metric / Dimension</th>
                <th class="py-3 px-4">Baseline (Safeguarded)</th>
                <th class="py-3 px-4">Option A (Balham Hub)</th>
                <th class="py-3 px-4">Option B (Phased Core)</th>
                <th class="py-3 px-4">London Growth 2050</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono">
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Total Route Length (km)</td>
                <td class="py-2.5 px-4 text-white">92.4 km</td>
                <td class="py-2.5 px-4 text-white">93.1 km</td>
                <td class="py-2.5 px-4 text-white">76.5 km</td>
                <td class="py-2.5 px-4 text-white">98.2 km</td>
              </tr>
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Twin Bored Tunnel (km)</td>
                <td class="py-2.5 px-4 text-sky-400">36.8 km</td>
                <td class="py-2.5 px-4 text-sky-400">37.4 km</td>
                <td class="py-2.5 px-4 text-sky-400">28.2 km</td>
                <td class="py-2.5 px-4 text-sky-400">39.5 km</td>
              </tr>
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Stations (Underground / Total)</td>
                <td class="py-2.5 px-4 text-white">12 / 34</td>
                <td class="py-2.5 px-4 text-white">12 / 34</td>
                <td class="py-2.5 px-4 text-white">9 / 28</td>
                <td class="py-2.5 px-4 text-white">14 / 37</td>
              </tr>
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Baseline Capital Cost (£bn)</td>
                <td class="py-2.5 px-4 text-amber-300 font-bold">£31.4bn</td>
                <td class="py-2.5 px-4 text-amber-300 font-bold">£32.9bn</td>
                <td class="py-2.5 px-4 text-amber-300 font-bold">£26.7bn</td>
                <td class="py-2.5 px-4 text-amber-300 font-bold">£38.3bn</td>
              </tr>
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Annual Ridership (Pax)</td>
                <td class="py-2.5 px-4 text-white">270m</td>
                <td class="py-2.5 px-4 text-white">285m</td>
                <td class="py-2.5 px-4 text-white">215m</td>
                <td class="py-2.5 px-4 text-white">340m</td>
              </tr>
              <tr class="hover:bg-slate-800/40">
                <td class="py-2.5 px-4 font-sans font-medium text-slate-300">Homes Enabled in 1km Isochrone</td>
                <td class="py-2.5 px-4 text-emerald-400">200,000</td>
                <td class="py-2.5 px-4 text-emerald-400">208,000</td>
                <td class="py-2.5 px-4 text-emerald-400">145,000</td>
                <td class="py-2.5 px-4 text-emerald-400">280,000</td>
              </tr>
              <tr class="hover:bg-slate-800/40 bg-slate-950/60">
                <td class="py-3 px-4 font-sans font-bold text-sky-300">WebTAG Benefit-Cost Ratio (BCR)</td>
                <td class="py-3 px-4 text-sky-300 font-bold text-sm">2.35</td>
                <td class="py-3 px-4 text-sky-300 font-bold text-sm">2.41</td>
                <td class="py-3 px-4 text-sky-300 font-bold text-sm">2.18</td>
                <td class="py-3 px-4 text-sky-300 font-bold text-sm">2.68</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class SchemeBuilderComponent {
  state = inject(CrossrailState);

  selectScheme(id: SchemeOptionId) {
    this.state.setScheme(id);
  }
}
