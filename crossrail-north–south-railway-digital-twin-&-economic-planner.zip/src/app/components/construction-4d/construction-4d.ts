import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-construction-4d',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">4D Construction Digital Twin</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">TBM Fleet Physics, Spoil Logistics &amp; Carbon Accounting</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">4D Construction Programme &amp; TBM Fleet Simulator</h2>
        </div>
        
        <!-- Live Playback Controls -->
        <div class="flex items-center gap-3 bg-slate-900 border border-slate-800 p-2 rounded-xl">
          <button 
            (click)="state.toggleSimPlay()"
            class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">{{ state.isPlayingSim() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ state.isPlayingSim() ? 'Pause Simulation' : 'Run 4D Timeline' }}</span>
          </button>

          <div class="flex items-center gap-2 text-xs">
            <span class="text-slate-400 font-mono">YEAR:</span>
            <input 
              type="range" 
              min="2027" 
              max="2040" 
              step="1" 
              [value]="state.simYear()"
              (input)="onYearSlide($event)"
              class="w-32 accent-emerald-400 h-1.5 bg-slate-800 rounded cursor-pointer">
            <span class="font-mono font-bold text-amber-400 text-sm min-w-[3rem]">{{ state.simYear() }}</span>
          </div>
        </div>
      </div>

      <!-- TBM Live Fleet Status Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (tbm of state.tbmSimStatus(); track tbm.id) {
          <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3 relative overflow-hidden">
            <!-- Animated Boring Pulse when active -->
            @if (tbm.status === 'BORING') {
              <div class="absolute top-0 right-0 w-16 h-16 bg-sky-500/10 rounded-bl-full flex items-start justify-end p-2 pointer-events-none">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
            }

            <div class="flex justify-between items-start">
              <div>
                <span class="text-[10px] font-mono font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
                  {{ tbm.id }}
                </span>
                <h4 class="font-bold text-white text-sm mt-1">{{ tbm.name }}</h4>
              </div>
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase"
                    [class.bg-emerald-500_20]="tbm.status === 'BORING' || tbm.status === 'COMPLETED'"
                    [class.text-emerald-300]="tbm.status === 'BORING' || tbm.status === 'COMPLETED'"
                    [class.bg-amber-500_20]="tbm.status === 'COMMISSIONING'"
                    [class.text-amber-300]="tbm.status === 'COMMISSIONING'">
                {{ tbm.status }}
              </span>
            </div>

            <!-- Progress Bar -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px] font-mono">
                <span class="text-slate-400">Drive Progress:</span>
                <span class="font-bold text-white">{{ tbm.drivenKm }} / {{ tbm.totalDriveKm }} km</span>
              </div>
              <div class="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div class="h-full bg-gradient-to-r from-sky-500 to-emerald-400 transition-all duration-300"
                     [style.width.%]="(tbm.drivenKm / tbm.totalDriveKm) * 100"></div>
              </div>
            </div>

            <!-- Physics & Telemetry -->
            <div class="grid grid-cols-2 gap-2 text-[10px] font-mono bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
              <div>
                <span class="text-slate-500 block">Advance Rate:</span>
                <span class="text-emerald-400 font-bold">{{ tbm.advanceRateMPerDay }} m/day</span>
              </div>
              <div>
                <span class="text-slate-500 block">Spoil Mined:</span>
                <span class="text-slate-200 font-bold">{{ (tbm.spoilExcavatedTonnes / 1000).toFixed(0) }}k tonnes</span>
              </div>
              <div>
                <span class="text-slate-500 block">Segment Rings:</span>
                <span class="text-slate-200 font-bold">{{ tbm.installedSegmentsCount }} / {{ tbm.totalSegmentsNeeded }}</span>
              </div>
              <div>
                <span class="text-slate-500 block">Thrust Force:</span>
                <span class="text-slate-200 font-bold">{{ (tbm.thrustKn / 1000).toFixed(1) }} MN</span>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Spoil Logistics & Environmental Carbon Row -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Spoil Logistics (6 cols) -->
        <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Spoil Material Logistics (River Thames Barge &amp; Rail)</h3>
            <span class="text-[10px] text-emerald-400 font-mono">90% Sustainable Transport</span>
          </div>

          <div class="grid grid-cols-3 gap-3 text-center text-xs">
            <div class="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <span class="text-sky-400 font-mono text-[10px] uppercase font-bold">Thames Barges (55%)</span>
              <div class="text-lg font-bold font-mono text-white mt-1">{{ (state.spoilLogistics().bargeTonnes / 1000).toFixed(0) }}k tonnes</div>
              <div class="text-[10px] text-slate-500 mt-0.5">{{ state.spoilLogistics().bargeMovements }} Barge Trips</div>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <span class="text-amber-400 font-mono text-[10px] uppercase font-bold">Freight Rail (35%)</span>
              <div class="text-lg font-bold font-mono text-white mt-1">{{ (state.spoilLogistics().railTonnes / 1000).toFixed(0) }}k tonnes</div>
              <div class="text-[10px] text-slate-500 mt-0.5">{{ state.spoilLogistics().railMovements }} Rail Trips</div>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <span class="text-slate-400 font-mono text-[10px] uppercase font-bold">Electric HGV (10%)</span>
              <div class="text-lg font-bold font-mono text-white mt-1">{{ (state.spoilLogistics().truckTonnes / 1000).toFixed(0) }}k tonnes</div>
              <div class="text-[10px] text-slate-500 mt-0.5">{{ state.spoilLogistics().truckMovements }} HGV Trips</div>
            </div>
          </div>

          <div class="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-xs text-emerald-300 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-sm">eco</mat-icon>
              <span>CO₂ Saved vs 100% Road Haulage:</span>
            </div>
            <span class="font-mono font-bold text-sm">{{ state.spoilLogistics().co2SavedVsAllRoadTonnes.toLocaleString() }} tonnes CO₂e</span>
          </div>
        </div>

        <!-- Construction Carbon & Materials Footprint (6 cols) -->
        <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Capital Carbon Accounting (PAS 2080 Standard)</h3>
            <span class="text-[10px] text-sky-400 font-mono">Embodied &amp; Operational</span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Embodied Carbon (Concrete/Steel):</span>
              <span class="text-base font-bold text-white font-mono">1.45 Mt CO₂e</span>
              <span class="text-[10px] text-emerald-400 block">70% GGBS Low-Carbon Cement</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400 block text-[10px] font-mono">Construction Plant &amp; Logistics:</span>
              <span class="text-base font-bold text-white font-mono">0.28 Mt CO₂e</span>
              <span class="text-[10px] text-sky-400 block">100% Green Grid Grid Connections</span>
            </div>
          </div>

          <div class="p-3 bg-slate-950/60 border border-slate-800 rounded-lg text-xs space-y-1 text-slate-300">
            <div class="flex justify-between">
              <span>Carbon Payback Period (vs Car Mode Shift):</span>
              <span class="font-mono font-bold text-emerald-400">7.2 Years from Full Opening</span>
            </div>
            <div class="flex justify-between">
              <span>Operational Carbon Neutrality:</span>
              <span class="font-mono font-bold text-sky-300">Zero Direct Scope 1 Emissions (100% OLE Electric)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 4D Master Programme Gantt Schedule -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Integrated 4D Master Programme (2027 → 2040)</h3>
          <span class="text-[10px] text-amber-400 font-mono">Critical Path Highlighted</span>
        </div>

        <div class="space-y-2 overflow-x-auto">
          @for (task of state.constructionTasks(); track task.id) {
            <div class="grid grid-cols-12 gap-3 items-center text-xs p-2 rounded hover:bg-slate-800/40 transition-colors">
              <div class="col-span-4 flex items-center gap-2">
                @if (task.criticalPath) {
                  <span class="w-2 h-2 rounded-full bg-amber-400 shrink-0" title="Critical Path Activity"></span>
                }
                <span class="font-medium text-slate-200 truncate">{{ task.name }}</span>
              </div>
              <div class="col-span-2 font-mono text-[10px] text-slate-400">
                {{ task.startYear }} → {{ task.endYear }}
              </div>
              <div class="col-span-4">
                <!-- Timeline bar representation -->
                <div class="w-full h-3 bg-slate-950 rounded border border-slate-800 relative overflow-hidden">
                  <div class="h-full rounded"
                       [class.bg-amber-500]="task.criticalPath"
                       [class.bg-sky-500]="!task.criticalPath"
                       [style.width.%]="task.progressPct"></div>
                </div>
              </div>
              <div class="col-span-2 text-right font-mono font-bold text-slate-300">
                £{{ task.costM }}m
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class Construction4dComponent {
  state = inject(CrossrailState);

  onYearSlide(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.setSimYear(val);
  }
}
