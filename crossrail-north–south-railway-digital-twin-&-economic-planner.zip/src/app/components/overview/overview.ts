import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-overview',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 overflow-y-auto h-full text-slate-100 max-w-7xl mx-auto">
      <!-- Statutory Clarification & Status Banner -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div class="flex items-start gap-3">
          <span class="p-2 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/20 shrink-0 mt-0.5">
            <mat-icon>shield</mat-icon>
          </span>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-mono font-bold tracking-wider text-amber-400 uppercase">SYNTHETIC STRATEGIC MODEL</span>
              <span class="text-slate-600">·</span>
              <span class="text-xs text-slate-400">Safeguarded Corridor Infrastructure Planning</span>
            </div>
            <p class="text-xs text-slate-300 mt-1 leading-relaxed">
              Transport for London route safeguarding remains in active legal force. This software is an independent, versioned engineering and economic digital twin platform for strategic option testing, cost escalation, 4D construction, and spatial economic appraisal.
            </p>
          </div>
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <button 
            (click)="state.openProvenance('CAPEX')"
            class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-sky-400 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">info</mat-icon>
            <span>Assumptions Drawer</span>
          </button>
        </div>
      </div>

      <!-- Executive Infrastructure KPI Grid -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <!-- Route Length -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.openProvenance('CAPEX')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Total Route</div>
          <div class="text-2xl font-display font-black text-white mt-1 tabular-nums">
            {{ state.totalRouteLengthKm() }} <span class="text-xs font-normal text-slate-400">km</span>
          </div>
          <div class="text-[10px] text-sky-400 font-mono mt-1">
            {{ state.totalTunnelLengthKm() }} km twin tunnel
          </div>
        </button>

        <!-- Stations Count -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.selectTab('stations')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Stations</div>
          <div class="text-2xl font-display font-black text-white mt-1 tabular-nums">
            {{ state.stations().length }}
          </div>
          <div class="text-[10px] text-emerald-400 font-mono mt-1">
            12 new deep caverns
          </div>
        </button>

        <!-- Capital Model (Capex) -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.openProvenance('CAPEX')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Capital Model</div>
          <div class="text-2xl font-display font-black text-amber-300 mt-1 tabular-nums">
            £{{ state.capexBreakdown().total }} <span class="text-xs font-normal text-slate-400">bn</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-1">
            2026 prices + risk
          </div>
        </button>

        <!-- Annual Ridership -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.openProvenance('RIDERSHIP')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Annual Demand</div>
          <div class="text-2xl font-display font-black text-white mt-1 tabular-nums">
            {{ state.demandMetrics().annualRidershipM }} <span class="text-xs font-normal text-slate-400">m</span>
          </div>
          <div class="text-[10px] text-sky-400 font-mono mt-1">
            {{ (state.demandMetrics().dailyRidershipPax / 1000).toFixed(0) }}k pax/day
          </div>
        </button>

        <!-- Homes Enabled -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.openProvenance('HOUSING')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Homes Enabled</div>
          <div class="text-2xl font-display font-black text-emerald-400 mt-1 tabular-nums">
            {{ (state.housingAndLandMetrics().totalHomesEnabled / 1000).toFixed(0) }} <span class="text-xs font-normal text-slate-400">k</span>
          </div>
          <div class="text-[10px] text-emerald-400 font-mono mt-1">
            In 1km catchments
          </div>
        </button>

        <!-- WebTAG BCR -->
        <button type="button" class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-xl hover:border-slate-700 transition-all cursor-pointer text-left w-full"
             (click)="state.openProvenance('BCR')">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">WebTAG BCR</div>
          <div class="text-2xl font-display font-black text-sky-300 mt-1 tabular-nums">
            {{ state.economicAppraisal().bcr }}
          </div>
          <div class="text-[10px] text-sky-400 font-mono mt-1">
            High Value for Money
          </div>
        </button>
      </div>

      <!-- Core Propagation Chain Live Status -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h3 class="text-sm font-bold tracking-tight text-white uppercase font-mono">The Integrated Engineering–Economic Propagation Chain</h3>
            <p class="text-xs text-slate-400 mt-0.5">Every geometric alignment or service decision automatically cascades through the whole system in real time.</p>
          </div>
          <span class="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
            Live Cascade Synchronised
          </span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-6 lg:grid-cols-11 gap-2 text-center text-xs">
          <!-- Step 1 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('alignment')">
            <div class="font-mono text-[10px] text-sky-400">01. ALIGNMENT</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">{{ state.totalRouteLengthKm() }} km</div>
            <div class="text-[9px] text-slate-500 mt-0.5">36.8km deep</div>
          </button>

          <!-- Step 2 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('finance')">
            <div class="font-mono text-[10px] text-amber-400">02. CAPEX</div>
            <div class="font-bold text-amber-300 mt-1 text-[11px]">£{{ state.capexBreakdown().total }}bn</div>
            <div class="text-[9px] text-slate-500 mt-0.5">12 Categories</div>
          </button>

          <!-- Step 3 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('construction')">
            <div class="font-mono text-[10px] text-sky-400">03. 4D PROGRAM</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">2028→2038</div>
            <div class="text-[9px] text-slate-500 mt-0.5">4 TBM Drives</div>
          </button>

          <!-- Step 4 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('operations')">
            <div class="font-mono text-[10px] text-emerald-400">04. SERVICE</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">{{ state.trainFrequencyTph() }} tph</div>
            <div class="text-[9px] text-slate-500 mt-0.5">Automated EMU</div>
          </button>

          <!-- Step 5 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('stations')">
            <div class="font-mono text-[10px] text-sky-400">05. CAPACITY</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">45,000</div>
            <div class="text-[9px] text-slate-500 mt-0.5">pax/hr/dir</div>
          </button>

          <!-- Step 6 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('demand')">
            <div class="font-mono text-[10px] text-sky-400">06. JOURNEYS</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">-18.4 min</div>
            <div class="text-[9px] text-slate-500 mt-0.5">Average savings</div>
          </button>

          <!-- Step 7 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('demand')">
            <div class="font-mono text-[10px] text-sky-400">07. DEMAND</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">{{ state.demandMetrics().annualRidershipM }}m</div>
            <div class="text-[9px] text-slate-500 mt-0.5">23% Mode shift</div>
          </button>

          <!-- Step 8 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('finance')">
            <div class="font-mono text-[10px] text-amber-400">08. REVENUE</div>
            <div class="font-bold text-amber-300 mt-1 text-[11px]">£{{ state.demandMetrics().totalCommercialRevenueM }}m</div>
            <div class="text-[9px] text-slate-500 mt-0.5">Annual net</div>
          </button>

          <!-- Step 9 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('land_housing')">
            <div class="font-mono text-[10px] text-emerald-400">09. HOUSING</div>
            <div class="font-bold text-emerald-400 mt-1 text-[11px]">200k</div>
            <div class="text-[9px] text-slate-500 mt-0.5">Homes enabled</div>
          </button>

          <!-- Step 10 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('land_housing')">
            <div class="font-mono text-[10px] text-sky-400">10. ECONOMY</div>
            <div class="font-bold text-slate-200 mt-1 text-[11px]">£{{ state.housingAndLandMetrics().totalModelledValueUpliftM.toFixed(0) }}m</div>
            <div class="text-[9px] text-slate-500 mt-0.5">Land Uplift</div>
          </button>

          <!-- Step 11 -->
          <button type="button" class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 hover:border-sky-500/40 transition-colors cursor-pointer w-full text-center"
               (click)="state.selectTab('economics')">
            <div class="font-mono text-[10px] text-sky-300">11. BCR</div>
            <div class="font-bold text-sky-300 mt-1 text-[11px]">{{ state.economicAppraisal().bcr }}</div>
            <div class="text-[9px] text-slate-500 mt-0.5">WebTAG NPV £{{ state.economicAppraisal().npvGbpBn }}bn</div>
          </button>
        </div>
      </div>

      <!-- Two Column Section: Live Sensitivity Workbench & Scenario Summary -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Sensitivity Workbench -->
        <div class="lg:col-span-1 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <h4 class="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono flex items-center gap-2">
              <mat-icon class="text-sky-400 !w-4 !h-4 !leading-4 text-sm">tune</mat-icon>
              <span>Scenario Sensitivity Controls</span>
            </h4>
            <button 
              (click)="resetSensitivities()"
              class="text-[11px] text-slate-400 hover:text-white transition-colors underline">
              Reset
            </button>
          </div>

          <!-- Capex Sensitivity -->
          <div class="space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-400">Capital Cost Sensitivity:</span>
              <span class="font-mono text-amber-300 font-bold">
                {{ ((state.capexMultiplier() - 1) * 100) >= 0 ? '+' : '' }}{{ ((state.capexMultiplier() - 1) * 100).toFixed(0) }}% (£{{ state.capexBreakdown().total }}bn)
              </span>
            </div>
            <input 
              type="range" 
              min="0.7" 
              max="1.5" 
              step="0.05" 
              [value]="state.capexMultiplier()"
              (input)="onCapexSlide($event)"
              class="w-full accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer">
          </div>

          <!-- Ridership Sensitivity -->
          <div class="space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-400">Demand Elasticity Modifier:</span>
              <span class="font-mono text-sky-400 font-bold">
                {{ ((state.ridershipMultiplier() - 1) * 100) >= 0 ? '+' : '' }}{{ ((state.ridershipMultiplier() - 1) * 100).toFixed(0) }}% ({{ state.demandMetrics().annualRidershipM }}m)
              </span>
            </div>
            <input 
              type="range" 
              min="0.7" 
              max="1.3" 
              step="0.05" 
              [value]="state.ridershipMultiplier()"
              (input)="onRidershipSlide($event)"
              class="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer">
          </div>

          <!-- Train Frequency TPH -->
          <div class="space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-400">Peak Service Frequency:</span>
              <span class="font-mono text-emerald-400 font-bold">{{ state.trainFrequencyTph() }} tph</span>
            </div>
            <input 
              type="range" 
              min="12" 
              max="36" 
              step="2" 
              [value]="state.trainFrequencyTph()"
              (input)="onTphSlide($event)"
              class="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer">
          </div>

          <!-- Delivery Delay -->
          <div class="space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="text-slate-400">Programme Delivery Delay:</span>
              <span class="font-mono text-slate-200 font-bold">+{{ state.openingDelayYears() }} Years ({{ 2038 + state.openingDelayYears() }})</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="5" 
              step="1" 
              [value]="state.openingDelayYears()"
              (input)="onDelaySlide($event)"
              class="w-full accent-slate-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer">
          </div>

          <div class="p-3 bg-slate-950/60 border border-slate-800 rounded-lg text-xs space-y-1 text-slate-300">
            <div class="text-[11px] font-bold text-slate-400 uppercase font-mono">Real-Time Appraisal Impact</div>
            <div class="flex justify-between">
              <span>Present Value of Benefits (PVB):</span>
              <span class="font-mono text-emerald-400">£{{ state.economicAppraisal().pvBenefitsGbpBn }}bn</span>
            </div>
            <div class="flex justify-between">
              <span>Present Value of Costs (PVC):</span>
              <span class="font-mono text-amber-300">£{{ state.economicAppraisal().pvCostsGbpBn }}bn</span>
            </div>
            <div class="flex justify-between border-t border-slate-800 pt-1 font-bold">
              <span>Net Present Value (NPV):</span>
              <span class="font-mono text-sky-300">£{{ state.economicAppraisal().npvGbpBn }}bn</span>
            </div>
          </div>
        </div>

        <!-- Scheme Narrative & Key Strategic Facts -->
        <div class="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h4 class="text-base font-bold text-white font-display">{{ state.activeScheme().name }}</h4>
              <p class="text-xs text-slate-400 mt-0.5">{{ state.activeScheme().description }}</p>
            </div>
            <button 
              (click)="state.selectTab('scheme')"
              class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg transition-colors shrink-0">
              Configure Schemes
            </button>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div class="bg-slate-950/50 p-3.5 rounded-lg border border-slate-800/80 space-y-2">
              <h5 class="font-mono text-[11px] font-bold uppercase text-sky-400">Railway Engineering Specs</h5>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Tunnel Technology:</span>
                <span class="font-mono text-slate-100">Twin EPB 6.8m internal bore</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Signalling &amp; Control:</span>
                <span class="font-mono text-slate-100">Digital CBTC + ATO (30 tph core)</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Traction Power:</span>
                <span class="font-mono text-slate-100">25 kV AC 50 Hz Overhead OLE</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5">
                <span>Rolling Stock Fleet:</span>
                <span class="font-mono text-slate-100">68x 9-Car / 11-Car EMUs</span>
              </div>
            </div>

            <div class="bg-slate-950/50 p-3.5 rounded-lg border border-slate-800/80 space-y-2">
              <h5 class="font-mono text-[11px] font-bold uppercase text-emerald-400">Economic &amp; Spatial Impact</h5>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Station Area Value Uplift:</span>
                <span class="font-mono text-emerald-400">£{{ state.housingAndLandMetrics().totalModelledValueUpliftM.toFixed(0) }}m</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Direct Construction Jobs:</span>
                <span class="font-mono text-slate-100">28,500 direct FTEs</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5 border-b border-slate-800/60">
                <span>Accessibility Enabled Jobs:</span>
                <span class="font-mono text-slate-100">84,000 cluster jobs</span>
              </div>
              <div class="flex justify-between text-slate-300 py-0.5">
                <span>CO₂ Emissions Reduction:</span>
                <span class="font-mono text-slate-100">42,000 tonnes/yr (highway shift)</span>
              </div>
            </div>
          </div>

          <!-- Quick Navigation Actions -->
          <div class="pt-2 flex flex-wrap gap-2">
            <button (click)="state.selectTab('gis')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700">
              <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-sky-400">map</mat-icon>
              <span>Explore London GIS</span>
            </button>
            <button (click)="state.selectTab('alignment')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700">
              <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-amber-400">timeline</mat-icon>
              <span>Edit Alignment CAD</span>
            </button>
            <button (click)="state.selectTab('construction')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700">
              <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-emerald-400">precision_manufacturing</mat-icon>
              <span>Launch 4D TBM Simulator</span>
            </button>
            <button (click)="state.selectTab('decision_room')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700">
              <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-purple-400">assignment</mat-icon>
              <span>Generate Strategic Outline Case</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OverviewComponent {
  state = inject(CrossrailState);

  onCapexSlide(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.capexMultiplier.set(val);
  }

  onRidershipSlide(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.ridershipMultiplier.set(val);
  }

  onTphSlide(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.trainFrequencyTph.set(val);
  }

  onDelaySlide(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.openingDelayYears.set(val);
  }

  resetSensitivities() {
    this.state.capexMultiplier.set(1.0);
    this.state.ridershipMultiplier.set(1.0);
    this.state.trainFrequencyTph.set(30);
    this.state.openingDelayYears.set(0);
    this.state.landValueUpliftMultiplier.set(1.0);
  }
}
