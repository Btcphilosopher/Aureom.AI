import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-station-capacity',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-sky-400">Pedestrian Dynamics &amp; Station Engineering</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Station Sizing, Passenger Throughput &amp; Evacuation</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Station Design &amp; Interchange Capacity Engine</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-sky-500/10 border border-sky-500/20 px-3 py-1.5 rounded-lg text-sky-300">
            34 Regional Stations · 12 Major Interchanges
          </span>
        </div>
      </div>

      <!-- Station Selector Tabs -->
      <div class="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        @for (station of state.stations(); track station.id) {
          <button 
            (click)="selectStation(station.id)"
            [class]="state.selectedStationId() === station.id ? 'bg-sky-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'"
            class="px-3 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2">
            <span class="font-mono text-[10px] opacity-75">{{ station.code }}</span>
            <span>{{ station.name }}</span>
          </button>
        }
      </div>

      @if (state.selectedStation(); as st) {
        <!-- Station Detailed Inspection Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <!-- Left: Parametric Design & Architectural Elements (6 cols) -->
          <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span class="text-xs font-mono font-bold text-sky-400">{{ st.type }}</span>
                <h3 class="text-lg font-bold text-white font-display mt-0.5">{{ st.name }} Station Architecture</h3>
              </div>
              <span class="text-xs font-mono bg-slate-800 px-2.5 py-1 rounded text-slate-300">
                Depth: {{ st.depthMeters }}m
              </span>
            </div>

            <!-- Architectural Objects Blueprint -->
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Platforms</span>
                <span class="text-base font-bold text-white font-mono">{{ st.platformsCount }}x Platforms</span>
                <span class="text-[10px] text-sky-400 block mt-0.5">{{ st.platformLengthM }}m Full Length</span>
              </div>

              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Ticket Halls</span>
                <span class="text-base font-bold text-white font-mono">{{ st.ticketHallsCount }} Halls</span>
                <span class="text-[10px] text-slate-400 block mt-0.5">36 Gate Lines</span>
              </div>

              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Escalator Banks</span>
                <span class="text-base font-bold text-amber-300 font-mono">{{ st.escalatorBanksCount }} Banks</span>
                <span class="text-[10px] text-amber-400 block mt-0.5">9,600 pax/hr cap</span>
              </div>

              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Lifts / Elevators</span>
                <span class="text-base font-bold text-white font-mono">{{ st.liftsCount }} High-Cap</span>
                <span class="text-[10px] text-emerald-400 block mt-0.5">Step-free to train</span>
              </div>

              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Retail &amp; Real Estate</span>
                <span class="text-base font-bold text-white font-mono">4,200 m²</span>
                <span class="text-[10px] text-slate-400 block mt-0.5">Concourse + Street</span>
              </div>

              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <span class="text-slate-500 block text-[10px] font-mono uppercase">Cycle Hub</span>
                <span class="text-base font-bold text-white font-mono">650 Spaces</span>
                <span class="text-[10px] text-emerald-400 block mt-0.5">Secure Hub + Repair</span>
              </div>
            </div>

            <!-- Evacuation & Fruin Level of Service Simulation -->
            <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
              <div class="flex justify-between items-center">
                <span class="font-mono text-[11px] font-bold text-slate-300 uppercase">Emergency Evacuation (NFPA 130 Standard)</span>
                <span class="text-xs font-mono text-emerald-400 font-bold">COMPLIANT (3.4 min)</span>
              </div>
              <div class="space-y-1.5 text-xs text-slate-300">
                <div class="flex justify-between">
                  <span>Platform Evacuation Time (target &lt; 4 min):</span>
                  <span class="font-mono font-bold text-white">3.4 min to Point of Safety</span>
                </div>
                <div class="flex justify-between">
                  <span>Station Clear Time (target &lt; 6 min):</span>
                  <span class="font-mono font-bold text-white">4.8 min to Public Open Realm</span>
                </div>
                <div class="flex justify-between">
                  <span>Fruin Level of Service (LOS) AM Peak:</span>
                  <span class="font-mono text-sky-400 font-bold">LOS C (Stable Flow)</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Right: Capacity Engine & Interchange Connectivity (6 cols) -->
          <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 class="text-sm font-bold font-mono text-slate-200 uppercase">AM Peak Pedestrian Flow Analysis</h3>
              <span class="text-[10px] text-amber-400 font-mono">07:30 - 08:30 Peak Hour</span>
            </div>

            <!-- Flow Matrix Summary -->
            <div class="grid grid-cols-3 gap-3 text-center">
              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <div class="text-slate-400 text-[10px] font-mono uppercase">Peak Entries</div>
                <div class="text-xl font-bold font-mono text-white mt-1">{{ st.amPeakEntries.toLocaleString() }}</div>
                <div class="text-[10px] text-slate-500 mt-0.5">pax/hour</div>
              </div>
              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <div class="text-slate-400 text-[10px] font-mono uppercase">Peak Exits</div>
                <div class="text-xl font-bold font-mono text-white mt-1">{{ st.amPeakExits.toLocaleString() }}</div>
                <div class="text-[10px] text-slate-500 mt-0.5">pax/hour</div>
              </div>
              <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <div class="text-slate-400 text-[10px] font-mono uppercase">Interchange</div>
                <div class="text-xl font-bold font-mono text-sky-400 mt-1">{{ st.amPeakInterchange.toLocaleString() }}</div>
                <div class="text-[10px] text-slate-500 mt-0.5">line transfers</div>
              </div>
            </div>

            <!-- Bottleneck Analysis Banner -->
            <div class="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-2 text-xs">
              <div class="flex items-center justify-between font-bold text-amber-300">
                <span class="flex items-center gap-1.5">
                  <mat-icon class="!w-4 !h-4 !leading-4 text-xs text-amber-400">warning</mat-icon>
                  Critical Constraint Bottleneck
                </span>
                <span class="font-mono text-amber-200">{{ st.escalatorUtilisationPct }}% Utilisation</span>
              </div>
              <div class="text-slate-200">{{ st.criticalBottleneck }}</div>
              <div class="text-[11px] text-amber-200/80">
                Model recommendation: Add secondary inclined shaft or 2x 26-person high-speed transfer lifts during detailed design stage.
              </div>
            </div>

            <!-- Multi-Line Interchange Connections -->
            <div class="space-y-2">
              <div class="font-mono text-[11px] font-bold text-slate-300 uppercase">Interchange Routes &amp; Walk Times</div>
              <div class="space-y-1.5 text-xs">
                @for (ic of st.interchanges; track ic.name) {
                  <div class="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div>
                      <span class="font-bold text-white block">{{ ic.name }}</span>
                      <span class="text-[10px] text-slate-400">{{ ic.lineType }} · {{ ic.verticalTransferM }}m vertical shift</span>
                    </div>
                    <div class="text-right font-mono">
                      <span class="text-sky-400 font-bold text-sm">{{ ic.walkTimeMin }} min</span>
                      <span class="text-[10px] text-slate-500 block">{{ ic.crowdingLevel }} Crowding</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class StationCapacityComponent {
  state = inject(CrossrailState);

  selectStation(id: string) {
    this.state.selectedStationId.set(id);
  }
}
