import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { BoreholeData } from '../../models';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tunnel-geology',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">Underground London Sub-Surface Model</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Deep Bored Tunnels, Shafts &amp; Stratigraphy</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Geological Cross-Section &amp; Tunnel Infrastructure</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg text-amber-300">
            36.8 km Twin Bored Drives · 6.8m Internal Dia.
          </span>
        </div>
      </div>

      <!-- Synthetic Geology Model Disclaimer -->
      <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between text-xs text-slate-300">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-sm">terrain</mat-icon>
          <span><strong>Geotechnical Disclaimer:</strong> Ground stratigraphy and borehole profiles represent a synthetic strategic planning model based on published British Geological Survey (BGS) London Basin regional formations, not certified site investigations.</span>
        </div>
      </div>

      <!-- Geological Cross-Section Visualizer Banner -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold font-mono text-slate-200 uppercase">London Basin Sub-surface Longitudinal Profile</h3>
          <div class="flex items-center gap-3 text-[11px] font-mono">
            <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-[#94a3b8]"></span> Made Ground</span>
            <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-[#78350f]"></span> London Clay</span>
            <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-[#b45309]"></span> Lambeth Group</span>
            <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-[#eab308]"></span> Thanet Sand</span>
            <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-[#cbd5e1]"></span> Chalk Aquifer</span>
          </div>
        </div>

        <!-- Geological Strata Canvas representation -->
        <div class="h-56 bg-slate-950 rounded-xl border border-slate-800 p-3 relative overflow-hidden flex flex-col justify-between">
          <svg class="w-full h-full" viewBox="0 0 900 200" preserveAspectRatio="none">
            <!-- Made Ground Layer (0-4m) -->
            <path d="M 0,20 Q 250,15 500,22 T 900,18 L 900,35 L 0,35 Z" fill="#94a3b8" opacity="0.6" />
            
            <!-- London Clay Layer (4-35m) -->
            <path d="M 0,35 L 900,35 L 900,110 Q 500,135 0,115 Z" fill="#78350f" opacity="0.85" />
            <text x="350" y="80" fill="#ffffff" font-size="12" font-family="monospace" opacity="0.5" letter-spacing="3">LONDON CLAY FORMATION (STIFF IMPERMEABLE)</text>

            <!-- Lambeth Group Layer (35-50m) -->
            <path d="M 0,115 Q 500,135 900,110 L 900,150 Q 500,165 0,155 Z" fill="#b45309" opacity="0.85" />
            <text x="380" y="138" fill="#ffffff" font-size="10" font-family="monospace" opacity="0.4">LAMBETH GROUP (SAND &amp; GRAVEL CHANNELS)</text>

            <!-- Thanet Sand Layer (50-65m) -->
            <path d="M 0,155 Q 500,165 900,150 L 900,175 L 0,175 Z" fill="#eab308" opacity="0.75" />

            <!-- Chalk Bedrock & Deep Aquifer (65m+) -->
            <rect x="0" y="175" width="900" height="25" fill="#cbd5e1" opacity="0.85" />
            <text x="400" y="192" fill="#09121f" font-size="10" font-family="monospace" font-weight="bold">WHITE CHALK FORMATION (ARTESIAN AQUIFER)</text>

            <!-- Crossrail 2 Twin Tunnel Alignment Invert -->
            <path d="M 50,30 Q 180,95 350,92 T 650,88 L 850,28" 
                  fill="none" 
                  stroke="#38bdf8" 
                  stroke-width="5" 
                  stroke-linecap="round"
                  class="drop-shadow-[0_0_6px_rgba(56,189,248,0.8)]" />

            <!-- Station Cavern Boxes -->
            <rect x="180" y="78" width="28" height="28" fill="#0284c7" stroke="#fff" stroke-width="1.5" rx="3" />
            <text x="175" y="72" fill="#38bdf8" font-size="9" font-family="monospace">CLAPHAM</text>

            <rect x="350" y="76" width="32" height="32" fill="#0284c7" stroke="#fff" stroke-width="1.5" rx="3" />
            <text x="348" y="70" fill="#38bdf8" font-size="9" font-family="monospace">VICTORIA</text>

            <rect x="490" y="74" width="34" height="34" fill="#0284c7" stroke="#fff" stroke-width="1.5" rx="3" />
            <text x="495" y="68" fill="#38bdf8" font-size="9" font-family="monospace">TCR</text>

            <rect x="580" y="72" width="36" height="36" fill="#0284c7" stroke="#fff" stroke-width="1.5" rx="3" />
            <text x="575" y="66" fill="#38bdf8" font-size="9" font-family="monospace">EUSTON</text>

            <rect x="710" y="75" width="28" height="28" fill="#0284c7" stroke="#fff" stroke-width="1.5" rx="3" />
            <text x="705" y="70" fill="#38bdf8" font-size="9" font-family="monospace">DALSTON</text>

            <!-- Borehole Columns -->
            <line x1="80" y1="20" x2="80" y2="185" stroke="#eab308" stroke-width="2" stroke-dasharray="3 2" />
            <text x="70" y="16" fill="#eab308" font-size="9" font-family="monospace">BH-01</text>

            <line x1="280" y1="20" x2="280" y2="185" stroke="#eab308" stroke-width="2" stroke-dasharray="3 2" />
            <text x="270" y="16" fill="#eab308" font-size="9" font-family="monospace">BH-05</text>

            <line x1="590" y1="20" x2="590" y2="185" stroke="#eab308" stroke-width="2" stroke-dasharray="3 2" />
            <text x="580" y="16" fill="#eab308" font-size="9" font-family="monospace">BH-09</text>

            <line x1="820" y1="20" x2="820" y2="185" stroke="#eab308" stroke-width="2" stroke-dasharray="3 2" />
            <text x="810" y="16" fill="#eab308" font-size="9" font-family="monospace">BH-12</text>
          </svg>
        </div>
      </div>

      <!-- Two-Column Grid: Tunnel Drives & Synthetic Borehole Profiles -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Tunnel Drives Specification (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Deep Bored Tunnel Drives &amp; Technology</h3>
            <span class="text-[10px] text-sky-400 font-mono">Twin 6.8m EPB Shields</span>
          </div>

          <div class="space-y-3">
            @for (tunnel of state.tunnels(); track tunnel.id) {
              <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <div class="font-bold text-white text-sm">{{ tunnel.name }}</div>
                  <span class="text-xs font-mono font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded">
                    {{ tunnel.lengthKm }} km
                  </span>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-slate-300">
                  <div>
                    <span class="text-slate-500 block">Diameter:</span>
                    <span class="font-mono text-white">{{ tunnel.internalDiameterM }}m ID / {{ tunnel.externalDiameterM }}m OD</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Lining:</span>
                    <span class="font-mono text-white">SGI Bolted Precast</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Geology:</span>
                    <span class="font-mono text-amber-300">{{ tunnel.primaryGeology }}</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Groundwater:</span>
                    <span class="font-mono text-slate-200">{{ tunnel.groundwaterRisk }}</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Synthetic Borehole Inspector (5 cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Synthetic Geotechnical Boreholes</h3>
            <span class="text-[10px] text-amber-400 font-mono">BGS Geological Survey</span>
          </div>

          <!-- Borehole Selector -->
          <div class="flex gap-1.5 overflow-x-auto pb-1">
            @for (bh of state.boreholes(); track bh.id) {
              <button 
                (click)="selectedBorehole.set(bh)"
                [class]="selectedBorehole().id === bh.id ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-950/60 text-slate-400 border-slate-800'"
                class="px-2.5 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all whitespace-nowrap">
                {{ bh.id }}
              </button>
            }
          </div>

          <!-- Active Borehole Details -->
          @if (selectedBorehole(); as bh) {
            <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3 text-xs">
              <div class="flex justify-between items-start">
                <div>
                  <h4 class="font-bold text-white text-sm">{{ bh.name }}</h4>
                  <div class="text-[11px] text-slate-400 font-mono mt-0.5">{{ bh.location }}</div>
                </div>
                <div class="text-right font-mono">
                  <span class="text-amber-400 font-bold block">{{ bh.totalDepthM }}m Depth</span>
                  <span class="text-[10px] text-sky-400">GW: {{ bh.groundwaterDepthM }}m</span>
                </div>
              </div>

              <!-- Strata Stack Column -->
              <div class="space-y-1.5 pt-2">
                <div class="font-mono text-[10px] font-bold text-slate-400 uppercase">Strata Log &amp; Soil Mechanics</div>
                @for (stratum of bh.strata; track stratum.layer) {
                  <div class="p-2 rounded border border-slate-800/80 bg-slate-900/80 flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                      <span class="w-3.5 h-3.5 rounded" [style.backgroundColor]="stratum.color"></span>
                      <div>
                        <span class="font-bold text-slate-100 block">{{ stratum.layer }}</span>
                        <span class="text-[10px] text-slate-400">{{ stratum.description }}</span>
                      </div>
                    </div>
                    <span class="font-mono text-[11px] text-slate-300 shrink-0 font-semibold">
                      {{ stratum.fromM }}–{{ stratum.toM }}m
                    </span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TunnelGeologyComponent {
  state = inject(CrossrailState);
  selectedBorehole = signal<BoreholeData>(this.state.boreholes()[2]); // default Euston
}
