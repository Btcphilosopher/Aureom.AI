import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-digital-twin-3d',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-hidden bg-slate-950 text-slate-100 p-6 space-y-4">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-sky-400">London Subterranean &amp; Surface Digital Twin</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">3D Multi-Mode Spatial Visualization</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-0.5">Crossrail North–South Digital Twin Viewport</h2>
        </div>

        <!-- Mode Switcher Tabs -->
        <div class="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl">
          <button 
            (click)="twinMode.set('isometric')"
            [class]="twinMode() === 'isometric' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all">
            3D Isometric
          </button>
          <button 
            (click)="twinMode.set('profile')"
            [class]="twinMode() === 'profile' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all">
            Geological Profile
          </button>
          <button 
            (click)="twinMode.set('operations')"
            [class]="twinMode() === 'operations' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all">
            Live Trains
          </button>
        </div>
      </div>

      <!-- Main Interactive Viewport Canvas -->
      <div class="flex-1 bg-slate-950 rounded-2xl border border-slate-800 relative overflow-hidden cad-grid flex items-center justify-center min-h-0">
        <!-- SVG 3D Isometric / Profile Rendering -->
        <svg class="w-full h-full select-none" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="tunnelGlow" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0284c7" stop-opacity="0.9"/>
              <stop offset="100%" stop-color="#38bdf8" stop-opacity="0.9"/>
            </linearGradient>
            <linearGradient id="groundIso" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#1e293b" stop-opacity="0.7"/>
              <stop offset="100%" stop-color="#0f172a" stop-opacity="0.9"/>
            </linearGradient>
          </defs>

          @if (twinMode() === 'isometric') {
            <!-- Surface Topography Polygon Grid -->
            <polygon points="100,220 900,120 850,420 50,520" fill="url(#groundIso)" stroke="#334155" stroke-width="1.5" />
            
            <!-- Isometric Thames Ribbon -->
            <path d="M 120,380 Q 400,280 820,240" fill="none" stroke="#0369a1" stroke-width="24" opacity="0.4" stroke-linecap="round" />
            <text x="440" y="275" fill="#38bdf8" font-size="10" font-family="monospace" opacity="0.5">RIVER THAMES</text>

            <!-- Subterranean Geological Depth Volume -->
            <polygon points="50,520 850,420 850,540 50,580" fill="#09121f" stroke="#1e293b" stroke-width="1" />
            
            <!-- Twin Bored Tunnel Centerlines (Deep Isometric Path) -->
            <path d="M 150,470 C 260,390 380,330 460,290 C 540,250 680,190 780,150" 
                  fill="none" 
                  stroke="url(#tunnelGlow)" 
                  stroke-width="8" 
                  stroke-linecap="round"
                  class="drop-shadow-[0_0_12px_rgba(2,132,199,0.8)]" />
            
            <!-- Surface Tracks -->
            <path d="M 80,510 L 150,470" fill="none" stroke="#f59e0b" stroke-width="4" stroke-dasharray="4 2" />
            <path d="M 780,150 L 860,110" fill="none" stroke="#f59e0b" stroke-width="4" stroke-dasharray="4 2" />

            <!-- Isometric Station Caverns -->
            <!-- Wimbledon -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_wimbledon')">
              <circle cx="150" cy="470" r="8" fill="#a855f7" stroke="#fff" stroke-width="2" />
              <text x="120" y="495" fill="#fff" font-size="11" font-weight="bold">Wimbledon</text>
            </g>

            <!-- Clapham Jct -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_clapham_jct')">
              <circle cx="280" cy="385" r="7" fill="#0284c7" stroke="#fff" stroke-width="2" />
              <text x="240" y="410" fill="#fff" font-size="11" font-weight="bold">Clapham Jct</text>
            </g>

            <!-- Victoria -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_victoria')">
              <circle cx="410" cy="315" r="8" fill="#0284c7" stroke="#fff" stroke-width="2" />
              <text x="380" y="340" fill="#fff" font-size="11" font-weight="bold">Victoria</text>
            </g>

            <!-- Tottenham Court Road -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_tcr')">
              <circle cx="490" cy="275" r="9" fill="#0284c7" stroke="#38bdf8" stroke-width="3" />
              <text x="495" y="260" fill="#38bdf8" font-size="11" font-weight="bold">Tottenham Court Rd</text>
            </g>

            <!-- Euston St Pancras -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_euston_stp')">
              <circle cx="560" cy="240" r="8" fill="#0284c7" stroke="#fff" stroke-width="2" />
              <text x="565" y="225" fill="#fff" font-size="11" font-weight="bold">Euston / St P</text>
            </g>

            <!-- Dalston -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_dalston')">
              <circle cx="680" cy="190" r="7" fill="#0284c7" stroke="#fff" stroke-width="2" />
              <text x="685" y="175" fill="#fff" font-size="11" font-weight="bold">Dalston</text>
            </g>

            <!-- Tottenham Hale -->
            <g class="cursor-pointer" (click)="state.selectedStationId.set('st_tottenham_hale')">
              <circle cx="780" cy="150" r="8" fill="#f59e0b" stroke="#fff" stroke-width="2" />
              <text x="785" y="135" fill="#fff" font-size="11" font-weight="bold">Tottenham Hale</text>
            </g>

            <!-- Live Animated Train Object (Moving Along Curve) -->
            <circle cx="440" cy="300" r="5" fill="#10b981" class="animate-ping" />
            <circle cx="440" cy="300" r="4" fill="#ffffff" />
            <text x="450" y="302" fill="#10b981" font-size="9" font-family="monospace">EMU-912 (88 km/h)</text>
          }

          @if (twinMode() === 'profile') {
            <!-- Full Geological Profile Stratigraphy -->
            <rect x="50" y="100" width="900" height="40" fill="#94a3b8" opacity="0.6" />
            <rect x="50" y="140" width="900" height="180" fill="#78350f" opacity="0.8" />
            <rect x="50" y="320" width="900" height="120" fill="#b45309" opacity="0.8" />
            <rect x="50" y="440" width="900" height="100" fill="#cbd5e1" opacity="0.8" />

            <text x="80" y="240" fill="#ffffff" font-size="14" font-family="monospace" opacity="0.4" letter-spacing="4">LONDON CLAY BED</text>
            <text x="80" y="380" fill="#ffffff" font-size="12" font-family="monospace" opacity="0.4">LAMBETH GROUP</text>
            <text x="80" y="490" fill="#09121f" font-size="12" font-family="monospace" font-weight="bold">WHITE CHALK AQUIFER</text>

            <!-- Tunnel Path with Depth Indicator -->
            <path d="M 80,120 Q 250,280 500,270 T 920,120" fill="none" stroke="#38bdf8" stroke-width="6" />
            
            <!-- Stations on Profile -->
            <circle cx="220" cy="270" r="7" fill="#0284c7" stroke="#fff" stroke-width="2" />
            <text x="200" y="300" fill="#fff" font-size="10" font-family="monospace">CLAPHAM (28m)</text>

            <circle cx="480" cy="270" r="7" fill="#0284c7" stroke="#fff" stroke-width="2" />
            <text x="460" y="300" fill="#fff" font-size="10" font-family="monospace">TCR (36m)</text>

            <circle cx="600" cy="265" r="7" fill="#0284c7" stroke="#fff" stroke-width="2" />
            <text x="580" y="295" fill="#fff" font-size="10" font-family="monospace">EUSTON (38m)</text>
          }

          @if (twinMode() === 'operations') {
            <!-- Live Transit Operations Diagram -->
            <path d="M 50,300 L 950,300" fill="none" stroke="#0284c7" stroke-width="8" stroke-linecap="round" />
            
            <!-- Dynamic Train Nodes Moving -->
            <circle cx="200" cy="300" r="8" fill="#10b981" />
            <text x="180" y="280" fill="#10b981" font-size="10" font-family="monospace">TRAIN 101 · 92 km/h</text>

            <circle cx="450" cy="300" r="8" fill="#10b981" />
            <text x="430" y="280" fill="#10b981" font-size="10" font-family="monospace">TRAIN 102 · DWELLING TCR</text>

            <circle cx="700" cy="300" r="8" fill="#10b981" />
            <text x="680" y="280" fill="#10b981" font-size="10" font-family="monospace">TRAIN 103 · 98 km/h</text>
          }
        </svg>

        <!-- Viewport Floating Telemetry Card -->
        <div class="absolute bottom-4 left-4 bg-slate-900/90 border border-slate-800 backdrop-blur rounded-xl p-3 text-xs font-mono space-y-1">
          <div class="text-[10px] text-slate-400 font-bold uppercase">Digital Twin Coordinates</div>
          <div class="text-slate-300">Active Scheme: <strong class="text-white">{{ state.activeScheme().name }}</strong></div>
          <div class="text-slate-300">Core Frequency: <strong class="text-emerald-400">{{ state.trainFrequencyTph() }} tph</strong></div>
          <div class="text-slate-300">Bored Tunnel: <strong class="text-sky-400">{{ state.totalTunnelLengthKm() }} km twin drive</strong></div>
        </div>
      </div>
    </div>
  `
})
export class DigitalTwin3dComponent {
  state = inject(CrossrailState);
  twinMode = signal<'isometric' | 'profile' | 'operations'>('isometric');
}
