import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState, NavigationTab } from '../../services/crossrail-state';
import { SchemeOptionId } from '../../models';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-header',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 border-b border-slate-800 bg-slate-950/95 backdrop-blur px-4 flex items-center justify-between gap-3 shrink-0 z-30 select-none">
      <!-- Zone 1: Brand Title -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center font-black text-white text-base shadow-sm ring-1 ring-white/20">
            <span class="tracking-tighter">N↕S</span>
          </div>
          <div class="flex flex-col">
            <span class="font-display font-black tracking-tight text-white text-base leading-none">CROSSRAIL NORTH–SOUTH</span>
            <span class="text-[10px] text-slate-400 font-mono tracking-wider mt-0.5 uppercase">London Regional Railway Digital Twin</span>
          </div>
        </div>
      </div>

      <!-- Zone 2: Navigation Links -->
      <nav class="hidden 2xl:flex items-center gap-1 overflow-x-auto py-1 text-xs font-semibold scrollbar-none">
        @for (item of navItems; track item.id) {
          <button
            (click)="state.selectTab(item.id)"
            [class]="state.activeTab() === item.id 
              ? 'bg-sky-500/15 text-sky-300 border border-sky-500/30 shadow-sm' 
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'"
            class="px-2.5 py-1.5 rounded-lg transition-all whitespace-nowrap flex items-center gap-1.5">
            <mat-icon class="text-xs !w-4 !h-4 !leading-4">{{ item.icon }}</mat-icon>
            <span>{{ item.label }}</span>
          </button>
        }
      </nav>

      <!-- Compact Nav for smaller screens -->
      <div class="flex 2xl:hidden items-center gap-1">
        <select 
          [value]="state.activeTab()"
          (change)="onMobileNavChange($event)"
          class="bg-slate-900 border border-slate-700 text-xs text-sky-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-sky-500">
          @for (item of navItems; track item.id) {
            <option [value]="item.id">{{ item.label }}</option>
          }
        </select>
      </div>

      <!-- Zone 3: Actions & Controls -->
      <div class="flex items-center gap-2 shrink-0">
        <!-- Scheme Switcher -->
        <div class="flex items-center bg-slate-900/90 border border-slate-800 rounded-lg p-0.5">
          <span class="px-2 text-[11px] text-slate-400 font-mono hidden sm:inline">SCHEME:</span>
          <select 
            [value]="state.activeSchemeId()"
            (change)="onSchemeChange($event)"
            class="bg-transparent text-xs text-slate-200 font-medium py-1 px-2 focus:outline-none cursor-pointer">
            <option value="baseline" class="bg-slate-900 text-slate-100">Baseline (Safeguarded)</option>
            <option value="option_a" class="bg-slate-900 text-slate-100">Option A (Balham Hub)</option>
            <option value="option_b" class="bg-slate-900 text-slate-100">Option B (Value Engineered)</option>
            <option value="london_growth_2050" class="bg-slate-900 text-slate-100">London Growth 2050 (High Density)</option>
          </select>
        </div>

        <!-- 4D Simulation Time Scrubber & Play -->
        <div class="flex items-center gap-1 bg-slate-900/90 border border-slate-800 rounded-lg px-2 py-1">
          <button 
            (click)="state.toggleSimPlay()" 
            [title]="state.isPlayingSim() ? 'Pause 4D Construction Simulation' : 'Play 4D Construction Simulation'"
            class="p-1 hover:bg-slate-800 rounded text-sky-400 hover:text-white transition-colors flex items-center justify-center">
            <mat-icon class="!w-4 !h-4 !leading-4">{{ state.isPlayingSim() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>
          <span class="text-xs font-mono font-bold text-amber-400 min-w-[3.5rem] text-center">
            {{ state.simYear() }}
          </span>
        </div>

        <!-- Data Provenance Inspector Button -->
        <button 
          (click)="state.openProvenance('CAPEX')"
          class="p-2 text-slate-400 hover:text-sky-300 hover:bg-slate-900 border border-slate-800 rounded-lg transition-colors"
          title="Inspect Data Provenance & Methodology">
          <mat-icon class="!w-4 !h-4 !leading-4 text-sm">policy</mat-icon>
        </button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  state = inject(CrossrailState);

  navItems: { id: NavigationTab; label: string; icon: string }[] = [
    { id: 'overview', label: 'Executive Centre', icon: 'dashboard' },
    { id: 'scheme', label: 'Scheme Builder', icon: 'account_tree' },
    { id: 'gis', label: 'Corridor & GIS', icon: 'map' },
    { id: 'alignment', label: 'Alignment CAD', icon: 'timeline' },
    { id: 'tunnels', label: 'Tunnels & Geology', icon: 'layers' },
    { id: 'stations', label: 'Stations & Pedestrians', icon: 'subway' },
    { id: 'construction', label: '4D Construction & TBM', icon: 'precision_manufacturing' },
    { id: 'operations', label: 'Operations & Timetable', icon: 'train' },
    { id: 'demand', label: 'Demand & Journeys', icon: 'commute' },
    { id: 'land_housing', label: 'Housing & Land Uplift', icon: 'apartment' },
    { id: 'economics', label: 'Economic CBA & Monte Carlo', icon: 'trending_up' },
    { id: 'finance', label: 'Capex & Whole-Life Cost', icon: 'payments' },
    { id: 'digital_twin', label: '3D Digital Twin', icon: 'view_in_ar' },
    { id: 'decision_room', label: 'Decision Room & SOBC', icon: 'assignment' }
  ];

  onMobileNavChange(e: Event) {
    const target = e.target as HTMLSelectElement;
    this.state.selectTab(target.value as NavigationTab);
  }

  onSchemeChange(e: Event) {
    const target = e.target as HTMLSelectElement;
    this.state.setScheme(target.value as SchemeOptionId);
  }
}
