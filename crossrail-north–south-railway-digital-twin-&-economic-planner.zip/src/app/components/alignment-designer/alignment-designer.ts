import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-alignment-designer',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-hidden bg-slate-950 text-slate-100 p-6 space-y-5">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-sky-400">Railway Engineering Workstation</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Horizontal &amp; Vertical Alignment CAD Editor</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Crossrail North–South Geometric Alignment</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-300">
            Total Alignment: <strong class="text-white">{{ state.totalRouteLengthKm() }} km</strong> ({{ state.totalTunnelLengthKm() }} km Bored Tunnel)
          </span>
        </div>
      </div>

      <!-- Main Two-Column Layout -->
      <div class="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 overflow-hidden">
        <!-- Left: Alignment Nodes Table (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div class="px-4 py-3 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between shrink-0">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">Alignment Vertices &amp; Curve Elements</h3>
            <span class="text-[10px] text-slate-500 font-mono">15 Chainage Control Nodes</span>
          </div>
          <div class="flex-1 overflow-y-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead class="bg-slate-950/80 sticky top-0 border-b border-slate-800 font-mono text-[10px] text-slate-400 uppercase">
                <tr>
                  <th class="py-2.5 px-3">Chainage</th>
                  <th class="py-2.5 px-3">Element / Station</th>
                  <th class="py-2.5 px-2">Type</th>
                  <th class="py-2.5 px-2 text-right">Radius (m)</th>
                  <th class="py-2.5 px-2 text-right">Gradient</th>
                  <th class="py-2.5 px-2 text-right">Depth (m)</th>
                  <th class="py-2.5 px-3 text-right">Speed</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-mono">
                @for (node of state.alignmentNodes(); track node.id) {
                  <tr 
                    (click)="selectNode(node.id)"
                    [class]="state.selectedNodeId() === node.id ? 'bg-sky-500/15 text-sky-200' : 'hover:bg-slate-800/50 text-slate-300'"
                    class="cursor-pointer transition-colors">
                    <td class="py-2 px-3 text-sky-400 font-bold">
                      km {{ node.chainageKm.toFixed(1) }}
                    </td>
                    <td class="py-2 px-3 font-sans font-medium text-slate-100 flex items-center gap-1.5">
                      @if (node.isStation) {
                        <span class="w-2 h-2 rounded-full bg-sky-400 inline-block"></span>
                      }
                      <span>{{ node.name }}</span>
                    </td>
                    <td class="py-2 px-2 text-[10px] text-slate-400 uppercase">
                      {{ node.type.replace('_', ' ') }}
                    </td>
                    <td class="py-2 px-2 text-right tabular-nums">
                      {{ node.horizontalRadiusM === 0 ? 'Tangent' : 'R=' + node.horizontalRadiusM }}
                    </td>
                    <td class="py-2 px-2 text-right tabular-nums" [class.text-amber-400]="Math.abs(node.gradientPct) > 2.0">
                      {{ node.gradientPct > 0 ? '+' : '' }}{{ node.gradientPct }}%
                    </td>
                    <td class="py-2 px-2 text-right tabular-nums text-slate-200 font-bold">
                      {{ node.depthBelowSurfaceM }}m
                    </td>
                    <td class="py-2 px-3 text-right tabular-nums text-emerald-400 font-bold">
                      {{ node.designSpeedKmh }} km/h
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Right: Interactive Parameter Workbench & Elevation CAD (5 cols) -->
        <div class="lg:col-span-5 flex flex-col gap-4 overflow-y-auto">
          @if (state.selectedNode(); as node) {
            <!-- Selected Vertex Engineering Editor -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div>
                  <span class="text-[10px] font-mono font-bold uppercase text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded">
                    CHAINAGE {{ node.chainageKm.toFixed(1) }} KM
                  </span>
                  <h4 class="text-base font-bold text-white font-display mt-1">{{ node.name }}</h4>
                </div>
                <div class="text-right">
                  <span class="text-[10px] text-slate-400 font-mono block">Geological Strata</span>
                  <span class="text-xs font-bold text-amber-400">{{ node.geologyLayer }}</span>
                </div>
              </div>

              <!-- Interactive Depth Adjustment Slider -->
              <div class="space-y-1.5">
                <div class="flex justify-between text-xs">
                  <span class="text-slate-400">Track Invert Depth Below Surface:</span>
                  <span class="font-mono text-sky-400 font-bold">{{ node.depthBelowSurfaceM }} m (El. {{ node.trackElevationM }}m OD)</span>
                </div>
                <div class="flex items-center gap-2">
                  <button (click)="adjustDepth(node.id, -2)" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded border border-slate-700">-2m</button>
                  <input 
                    type="range" 
                    min="0" 
                    max="50" 
                    step="1" 
                    [value]="node.depthBelowSurfaceM"
                    (input)="onDepthChange(node.id, $event)"
                    class="flex-1 accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer">
                  <button (click)="adjustDepth(node.id, 2)" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded border border-slate-700">+2m</button>
                </div>
                <p class="text-[10px] text-slate-500">Modifying depth dynamically recalculates station cavern excavation volumes and TBM launch shaft depths.</p>
              </div>

              <!-- Horizontal Radius & Cant Deficiency -->
              <div class="grid grid-cols-2 gap-3 text-xs bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                <div>
                  <span class="text-slate-400 block text-[10px]">Horizontal Radius (R):</span>
                  <div class="flex items-center gap-1 mt-1">
                    <input 
                      type="number" 
                      step="100" 
                      [value]="node.horizontalRadiusM"
                      (change)="onRadiusChange(node.id, $event)"
                      class="bg-slate-900 border border-slate-700 rounded px-2 py-1 font-mono text-white text-xs w-full focus:outline-none focus:ring-1 focus:ring-sky-500">
                    <span class="text-slate-500 font-mono">m</span>
                  </div>
                </div>

                <div>
                  <span class="text-slate-400 block text-[10px]">Cant Deficiency (I):</span>
                  <div class="mt-1.5 font-mono text-white font-bold flex items-center justify-between">
                    <span>{{ node.cantDeficiencyMm }} mm</span>
                    <span class="text-[9px] text-emerald-400">PASS (&lt; 110mm)</span>
                  </div>
                </div>
              </div>

              <!-- Design Verification Indicators -->
              <div class="p-3 bg-slate-950/40 rounded-lg border border-slate-800/80 space-y-1.5 text-xs">
                <div class="font-mono text-[10px] font-bold text-slate-400 uppercase">Track Geometry Compliance Checks</div>
                <div class="flex items-center justify-between text-slate-300">
                  <span>Track Gauge:</span>
                  <span class="font-mono text-slate-100">1,435 mm Standard Gauge</span>
                </div>
                <div class="flex items-center justify-between text-slate-300">
                  <span>Cant (Superelevation):</span>
                  <span class="font-mono text-slate-100">{{ node.cantMm }} mm</span>
                </div>
                <div class="flex items-center justify-between text-slate-300">
                  <span>Longitudinal Gradient:</span>
                  <span class="font-mono" [class.text-emerald-400]="Math.abs(node.gradientPct) <= 2.5" [class.text-amber-400]="Math.abs(node.gradientPct) > 2.5">
                    {{ node.gradientPct }}% (Max 3.0% RSSB Standard)
                  </span>
                </div>
              </div>
            </div>
          }

          <!-- Schematic Elevation Longitudinal Profile -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">Vertical Alignment Profile</h4>
              <span class="text-[10px] font-mono text-slate-500">Exaggeration 100:1</span>
            </div>
            
            <div class="h-36 bg-slate-950 rounded-lg border border-slate-800 p-2 relative overflow-hidden cad-grid-dense flex items-end">
              <!-- Ground Surface Line -->
              <svg class="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
                <!-- Ground Surface -->
                <path d="M 0,30 Q 100,20 200,35 T 400,25" fill="none" stroke="#64748b" stroke-width="2" stroke-dasharray="3 3"/>
                <!-- Track Alignment Invert -->
                <path d="M 0,32 Q 50,45 100,75 T 200,80 T 300,70 L 400,30" fill="none" stroke="#0284c7" stroke-width="3"/>
                <!-- Station Markers on Profile -->
                <circle cx="10" cy="32" r="3" fill="#a855f7" />
                <circle cx="95" cy="75" r="3" fill="#38bdf8" />
                <circle cx="150" cy="78" r="3" fill="#38bdf8" />
                <circle cx="210" cy="80" r="3" fill="#38bdf8" />
                <circle cx="280" cy="68" r="3" fill="#38bdf8" />
                <circle cx="390" cy="30" r="3" fill="#f59e0b" />
              </svg>
            </div>
            <div class="flex justify-between text-[10px] font-mono text-slate-500">
              <span>km 0.0 (Wimbledon)</span>
              <span>km 28.5 (Euston)</span>
              <span>km 62.4 (Broxbourne)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AlignmentDesignerComponent {
  state = inject(CrossrailState);
  Math = Math;

  selectNode(id: string) {
    this.state.selectedNodeId.set(id);
  }

  adjustDepth(nodeId: string, deltaM: number) {
    this.state.updateAlignmentNodeDepth(nodeId, deltaM);
  }

  onDepthChange(nodeId: string, e: Event) {
    const target = e.target as HTMLInputElement;
    const current = this.state.alignmentNodes().find(n => n.id === nodeId)?.depthBelowSurfaceM ?? 0;
    const delta = Number(target.value) - current;
    this.state.updateAlignmentNodeDepth(nodeId, delta);
  }

  onRadiusChange(nodeId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.updateAlignmentNodeRadius(nodeId, val);
  }
}
