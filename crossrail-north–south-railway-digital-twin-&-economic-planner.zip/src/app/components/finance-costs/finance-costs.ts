import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-finance-costs',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">Infrastructure Capital Economics</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">12-Category Cost Breakdown &amp; Financing Stack</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Capital Cost, Escalation &amp; Funding Model</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg text-amber-300">
            Total Capital Spend: <strong>£{{ state.capexBreakdown().total }}bn</strong> (2026 Prices)
          </span>
        </div>
      </div>

      <!-- 12-Category Capital Cost Breakdown Table & Chart Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 12-Category Cost Table (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div class="px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Bottom-Up Capital Cost Breakdown</h3>
            <span class="text-[10px] text-amber-400 font-mono">QRA Optimism Bias Included</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead class="bg-slate-950/80 border-b border-slate-800 font-mono text-[10px] text-slate-400 uppercase">
                <tr>
                  <th class="py-2.5 px-4">WBS Cost Category</th>
                  <th class="py-2.5 px-3">Scope Description</th>
                  <th class="py-2.5 px-4 text-right">Cost (£bn)</th>
                  <th class="py-2.5 px-4 text-right">Share (%)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-mono">
                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">1. Deep Bored Tunnelling</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">36.8km Twin EPB drives + cross-passages</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().tunnellingCost }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().tunnellingCost / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">2. Station Caverns &amp; Boxes</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">12 Central subterranean interchange stations</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().stationCavernsCost }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().stationCavernsCost / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">3. Surface Rail &amp; Portals</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">55.6km surface four-tracking &amp; grade separation</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().surfaceStationsAndWorks }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().surfaceStationsAndWorks / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">4. Systems &amp; 25kV Signalling</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">Overhead 25kV OLE, CBTC Moving Block</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().systemsAndSignalling }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().systemsAndSignalling / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">5. Rolling Stock EMU Fleet</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">68x 9-11 car high-capacity regional trainsets</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().rollingStock }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().rollingStock / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">6. Land &amp; Safeguarding</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">Compulsory purchase, rights &amp; compensation</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().landAndSafeguarding }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().landAndSafeguarding / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-sans font-medium text-slate-100">7. Professional Services &amp; PM</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">Detailed engineering, consents, insurance</td>
                  <td class="py-2.5 px-4 text-right font-bold text-white tabular-nums">£{{ state.capexBreakdown().indirectsAndDesign }}bn</td>
                  <td class="py-2.5 px-4 text-right text-slate-400 tabular-nums">{{ ((state.capexBreakdown().indirectsAndDesign / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="hover:bg-slate-800/40 transition-colors bg-amber-500/5">
                  <td class="py-2.5 px-4 font-sans font-medium text-amber-300">8. Optimism Bias &amp; QRA Risk</td>
                  <td class="py-2.5 px-3 font-sans text-slate-400">28% Green Book risk allocation at design stage</td>
                  <td class="py-2.5 px-4 text-right font-bold text-amber-300 tabular-nums">£{{ state.capexBreakdown().optimismBiasAndRisk }}bn</td>
                  <td class="py-2.5 px-4 text-right text-amber-300 tabular-nums">{{ ((state.capexBreakdown().optimismBiasAndRisk / state.capexBreakdown().total) * 100).toFixed(1) }}%</td>
                </tr>

                <tr class="bg-slate-950 font-bold border-t-2 border-slate-700">
                  <td class="py-3 px-4 font-sans text-white uppercase">TOTAL SCHEME CAPITAL COST</td>
                  <td class="py-3 px-3 font-sans text-slate-400">All 8 WBS packages</td>
                  <td class="py-3 px-4 text-right text-amber-400 text-sm">£{{ state.capexBreakdown().total }}bn</td>
                  <td class="py-3 px-4 text-right text-white">100.0%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Financing Structure Stack (5 cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Funding &amp; Financing Stack Allocation</h3>
            <span class="text-[10px] text-sky-400 font-mono">Hybrid Public-Private</span>
          </div>

          <!-- Financing Layers -->
          <div class="space-y-2.5 text-xs">
            <div class="p-3 bg-slate-950/60 rounded-lg border border-slate-800 space-y-1">
              <div class="flex justify-between items-center">
                <span class="font-bold text-white">Central Government DfT / Treasury Grant</span>
                <span class="font-mono text-sky-400 font-bold">40% (£{{ (state.capexBreakdown().total * 0.4).toFixed(1) }}bn)</span>
              </div>
              <p class="text-[10px] text-slate-400">National Infrastructure and Construction Pipeline allocation.</p>
            </div>

            <div class="p-3 bg-slate-950/60 rounded-lg border border-slate-800 space-y-1">
              <div class="flex justify-between items-center">
                <span class="font-bold text-white">GLA Business Rate Supplement (BRS)</span>
                <span class="font-mono text-emerald-400 font-bold">25% (£{{ (state.capexBreakdown().total * 0.25).toFixed(1) }}bn)</span>
              </div>
              <p class="text-[10px] text-slate-400">2p in the £ business rate levy on rateable values &gt; £75,000 (Crossrail 1 precedent).</p>
            </div>

            <div class="p-3 bg-slate-950/60 rounded-lg border border-slate-800 space-y-1">
              <div class="flex justify-between items-center">
                <span class="font-bold text-white">Developer Value Capture (Mayoral CIL &amp; s106)</span>
                <span class="font-mono text-amber-300 font-bold">15% (£{{ (state.capexBreakdown().total * 0.15).toFixed(1) }}bn)</span>
              </div>
              <p class="text-[10px] text-slate-400">Levy on new residential &amp; commercial floorspace within 1km station isochrones.</p>
            </div>

            <div class="p-3 bg-slate-950/60 rounded-lg border border-slate-800 space-y-1">
              <div class="flex justify-between items-center">
                <span class="font-bold text-white">TfL Farebox Backed Prudential Borrowing</span>
                <span class="font-mono text-slate-300 font-bold">20% (£{{ (state.capexBreakdown().total * 0.2).toFixed(1) }}bn)</span>
              </div>
              <p class="text-[10px] text-slate-400">Long-term green bonds serviced by £{{ state.demandMetrics().totalCommercialRevenueM }}m/yr net commercial farebox.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FinanceCostsComponent {
  state = inject(CrossrailState);
}
