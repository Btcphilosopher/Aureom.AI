import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { BoreholeData, StationData } from '../../models';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-gis-corridor',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row overflow-hidden bg-slate-950 text-slate-100">
      <!-- Left: Interactive London GIS Map Viewport -->
      <div class="flex-1 relative overflow-hidden bg-slate-950 cad-grid">
        <!-- Map Canvas / SVG Interactive Layer -->
        <svg #mapSvg 
          class="w-full h-full cursor-grab active:cursor-grabbing select-none"
          [attr.viewBox]="viewBox()"
          (mousedown)="startPan($event)"
          (mousemove)="doPan($event)"
          (mouseup)="endPan()"
          (mouseleave)="endPan()"
          (wheel)="onZoom($event)">
          
          <defs>
            <!-- Safeguarded Land Pattern -->
            <pattern id="safeguardedPattern" width="10" height="10" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="10" stroke="#dc241f" stroke-width="1.5" stroke-opacity="0.35" />
            </pattern>
            <!-- River Thames Gradient -->
            <linearGradient id="thamesGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0f2b48" stop-opacity="0.8"/>
              <stop offset="100%" stop-color="#071b30" stop-opacity="0.9"/>
            </linearGradient>
          </defs>

          <!-- River Thames Path (London Landmark Reference) -->
          <path d="M 50,560 C 150,540 220,580 320,520 C 380,480 430,490 510,480 C 580,470 640,510 720,490 C 800,470 880,510 950,480"
                fill="none" 
                stroke="url(#thamesGradient)" 
                stroke-width="32" 
                stroke-linecap="round" />
          <text x="520" y="475" fill="#38bdf8" font-size="10" font-family="monospace" opacity="0.4" letter-spacing="2">RIVER THAMES</text>

          <!-- Greater London Outer Boundary Contour (Stylised) -->
          <ellipse cx="500" cy="450" rx="460" ry="400" fill="none" stroke="#1e293b" stroke-dasharray="4 4" stroke-width="1.5" />
          <text x="90" y="120" fill="#475569" font-size="11" font-family="monospace">GREATER LONDON METROPOLITAN BOUNDARY</text>

          <!-- Safeguarded Land Envelope (if enabled) -->
          @if (showSafeguarding()) {
            <g class="safeguarded-corridor">
              <!-- Safeguarding polygon buffer around the central alignment -->
              <path d="M 230,730 L 260,700 L 330,590 L 370,510 L 420,410 L 460,340 L 510,290 L 570,220 L 620,160 L 645,175 L 595,240 L 535,310 L 485,360 L 445,430 L 395,530 L 355,610 L 285,720 Z" 
                    fill="url(#safeguardedPattern)" 
                    stroke="#dc241f" 
                    stroke-width="1" 
                    stroke-opacity="0.6" />
            </g>
          }

          <!-- Surface Railway Branches (Surrey & Herts) -->
          <g class="surface-branches" stroke="#f59e0b" stroke-width="3" stroke-linecap="round" fill="none" opacity="0.8">
            <!-- Surrey Branches to Wimbledon -->
            <path d="M 120,840 Q 180,780 245,715" stroke-dasharray="6 3" />
            <path d="M 200,890 Q 220,800 245,715" stroke-dasharray="6 3" />
            <!-- Herts Branches beyond Tottenham Hale -->
            <path d="M 610,180 L 680,90" stroke-dasharray="6 3" />
            <path d="M 610,180 L 590,80" stroke-dasharray="6 3" />
          </g>

          <!-- Core Tunnel Alignment Path (Twin Bore) -->
          <path [attr.d]="corridorPathD()" 
                fill="none" 
                stroke="#0284c7" 
                stroke-width="6" 
                stroke-linecap="round" 
                stroke-linejoin="round" 
                class="transition-all duration-300 drop-shadow-[0_0_8px_rgba(2,132,199,0.5)]" />
          
          <!-- Inner Track Centerline -->
          <path [attr.d]="corridorPathD()" 
                fill="none" 
                stroke="#ffffff" 
                stroke-width="1.5" 
                stroke-dasharray="5 3" 
                stroke-linecap="round" />

          <!-- Station Catchment 1km Buffer Rings (if enabled) -->
          @if (showCatchments()) {
            @for (st of state.stations(); track st.id) {
              <circle 
                [attr.cx]="getStationSvgX(st)" 
                [attr.cy]="getStationSvgY(st)" 
                r="36" 
                fill="#38bdf8" 
                fill-opacity="0.04" 
                stroke="#38bdf8" 
                stroke-opacity="0.25" 
                stroke-width="1" 
                stroke-dasharray="3 3" />
            }
          }

          <!-- Station Nodes -->
          @for (st of state.stations(); track st.id) {
            <g class="station-node cursor-pointer group" 
               (click)="selectStation(st.id)">
              <!-- Outer halo on select -->
              @if (state.selectedStationId() === st.id) {
                <circle 
                  [attr.cx]="getStationSvgX(st)" 
                  [attr.cy]="getStationSvgY(st)" 
                  r="14" 
                  fill="none" 
                  stroke="#38bdf8" 
                  stroke-width="2.5" 
                  class="animate-pulse" />
              }

              <!-- Station Dot -->
              <circle 
                [attr.cx]="getStationSvgX(st)" 
                [attr.cy]="getStationSvgY(st)" 
                r="7" 
                [attr.fill]="st.type === 'SURFACE REGIONAL' ? '#f59e0b' : (st.type === 'TERMINAL INTERCHANGE' ? '#a855f7' : '#0284c7')" 
                stroke="#ffffff" 
                stroke-width="2" />

              <!-- Station Label -->
              <text 
                [attr.x]="getStationSvgX(st) + 12" 
                [attr.y]="getStationSvgY(st) + 4" 
                fill="#f8fafc" 
                font-size="11" 
                font-weight="700" 
                class="pointer-events-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                {{ st.name }}
              </text>
              <text 
                [attr.x]="getStationSvgX(st) + 12" 
                [attr.y]="getStationSvgY(st) + 16" 
                fill="#94a3b8" 
                font-size="9" 
                font-family="monospace"
                class="pointer-events-none">
                Z{{ st.zone }} · {{ (st.amPeakEntries / 1000).toFixed(1) }}k AM flow
              </text>
            </g>
          }

          <!-- Borehole Markers (if enabled) -->
          @if (showBoreholes()) {
            @for (bh of state.boreholes(); track bh.id) {
              <g class="borehole-marker cursor-pointer" (click)="state.selectTab('tunnels')">
                <rect 
                  [attr.x]="getBoreholeSvgX(bh) - 4" 
                  [attr.y]="getBoreholeSvgY(bh) - 4" 
                  width="8" 
                  height="8" 
                  fill="#eab308" 
                  stroke="#000" 
                  stroke-width="1" />
                <text 
                  [attr.x]="getBoreholeSvgX(bh) + 6" 
                  [attr.y]="getBoreholeSvgY(bh) - 6" 
                  fill="#eab308" 
                  font-size="8" 
                  font-family="monospace">
                  {{ bh.id }} ({{ bh.totalDepthM }}m)
                </text>
              </g>
            }
          }
        </svg>

        <!-- Floating Map Overlay Controls -->
        <div class="absolute top-4 left-4 bg-slate-900/90 border border-slate-800 backdrop-blur rounded-xl p-3 shadow-lg flex flex-col gap-2 max-w-xs text-xs">
          <div class="font-mono text-[11px] font-bold text-slate-300 uppercase flex items-center justify-between border-b border-slate-800 pb-2">
            <span>GIS Corridor Layers</span>
            <span class="text-[10px] text-sky-400">EPSG:27700 (BNG)</span>
          </div>

          <!-- Layer Toggles -->
          <label class="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
            <input type="checkbox" [checked]="showSafeguarding()" (change)="showSafeguarding.set(!showSafeguarding())" class="rounded accent-sky-500">
            <span>Safeguarded Land Limits (TfL 2015 Order)</span>
          </label>

          <label class="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
            <input type="checkbox" [checked]="showCatchments()" (change)="showCatchments.set(!showCatchments())" class="rounded accent-sky-500">
            <span>1km Station Catchment Rings</span>
          </label>

          <label class="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
            <input type="checkbox" [checked]="showBoreholes()" (change)="showBoreholes.set(!showBoreholes())" class="rounded accent-sky-500">
            <span>Geological Boreholes (Ground Stratigraphy)</span>
          </label>
        </div>

        <!-- Zoom Controls -->
        <div class="absolute bottom-4 right-4 bg-slate-900/90 border border-slate-800 backdrop-blur rounded-xl p-1.5 shadow-lg flex flex-col gap-1 text-slate-300">
          <button (click)="zoomIn()" class="p-1.5 hover:bg-slate-800 rounded transition-colors" title="Zoom in">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">add</mat-icon>
          </button>
          <button (click)="zoomOut()" class="p-1.5 hover:bg-slate-800 rounded transition-colors" title="Zoom out">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">remove</mat-icon>
          </button>
          <button (click)="resetView()" class="p-1.5 hover:bg-slate-800 rounded transition-colors" title="Reset View">
            <mat-icon class="!w-4 !h-4 !leading-4 text-xs">center_focus_strong</mat-icon>
          </button>
        </div>
      </div>

      <!-- Right: Station & Catchment Planning Inspector Drawer -->
      <div class="w-full lg:w-96 border-l border-slate-800 bg-slate-900/95 backdrop-blur p-5 overflow-y-auto space-y-5 shrink-0 text-xs">
        @if (state.selectedStation(); as station) {
          <!-- Station Header -->
          <div class="border-b border-slate-800 pb-3">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded">
                {{ station.code }} · ZONE {{ station.zone }}
              </span>
              <span class="text-[11px] text-slate-400 font-mono">
                {{ station.type }}
              </span>
            </div>
            <h3 class="text-lg font-bold text-white font-display mt-1">{{ station.name }}</h3>
            <p class="text-[11px] text-slate-400">{{ station.borough }} Borough</p>
          </div>

          <!-- Station Engineering Specifications -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
            <div class="font-mono text-[11px] font-bold text-slate-300 uppercase">Station Geometry</div>
            <div class="grid grid-cols-2 gap-2 text-slate-300">
              <div>
                <span class="text-slate-500 block text-[10px]">Track Depth:</span>
                <span class="font-mono font-bold text-white">{{ station.depthMeters }}m below surface</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">Platform Length:</span>
                <span class="font-mono font-bold text-white">{{ station.platformLengthM }}m ({{ station.platformsCount }} platforms)</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">Ticket Halls:</span>
                <span class="font-mono font-bold text-white">{{ station.ticketHallsCount }} Halls</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">Escalators &amp; Lifts:</span>
                <span class="font-mono font-bold text-white">{{ station.escalatorBanksCount }} banks / {{ station.liftsCount }} lifts</span>
              </div>
            </div>
          </div>

          <!-- Peak Passenger Flows & Bottlenecks -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
            <div class="font-mono text-[11px] font-bold text-amber-400 uppercase flex items-center justify-between">
              <span>AM Peak Pedestrian Flow</span>
              <span class="text-[10px] text-slate-400">07:30–08:30</span>
            </div>
            <div class="grid grid-cols-3 gap-1.5 text-center">
              <div class="bg-slate-900 p-2 rounded border border-slate-800">
                <span class="text-[10px] text-slate-400 block">Entries</span>
                <span class="font-mono font-bold text-white">{{ station.amPeakEntries.toLocaleString() }}</span>
              </div>
              <div class="bg-slate-900 p-2 rounded border border-slate-800">
                <span class="text-[10px] text-slate-400 block">Exits</span>
                <span class="font-mono font-bold text-white">{{ station.amPeakExits.toLocaleString() }}</span>
              </div>
              <div class="bg-slate-900 p-2 rounded border border-slate-800">
                <span class="text-[10px] text-slate-400 block">Interchange</span>
                <span class="font-mono font-bold text-sky-400">{{ station.amPeakInterchange.toLocaleString() }}</span>
              </div>
            </div>

            <!-- Bottleneck Warning -->
            <div class="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-200/90 text-[11px] space-y-1">
              <div class="font-bold flex items-center gap-1">
                <mat-icon class="!w-3.5 !h-3.5 !leading-3.5 text-xs text-amber-400">warning</mat-icon>
                <span>Critical Node Bottleneck</span>
              </div>
              <div>{{ station.criticalBottleneck }}</div>
              <div class="text-[10px] text-amber-300/80">Escalator Utilisation: {{ station.escalatorUtilisationPct }}% · Concourse: {{ station.concourseDensityPaxM2 }} pax/m²</div>
            </div>
          </div>

          <!-- Multi-modal Interchanges -->
          <div class="space-y-2">
            <div class="font-mono text-[11px] font-bold text-slate-300 uppercase">Interchange Connections</div>
            <div class="space-y-1.5">
              @for (ic of station.interchanges; track ic.name) {
                <div class="flex items-center justify-between p-2 bg-slate-950/40 rounded border border-slate-800/80">
                  <div>
                    <span class="font-bold text-white block">{{ ic.name }}</span>
                    <span class="text-[10px] text-slate-400">{{ ic.lineType }} · {{ ic.verticalTransferM }}m vertical</span>
                  </div>
                  <div class="text-right font-mono text-[11px]">
                    <span class="text-sky-400">{{ ic.walkTimeMin }} min</span>
                    <span class="text-[9px] text-slate-500 block">{{ ic.crowdingLevel }} Crowding</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Housing & Station-led Development Capacity -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
            <div class="font-mono text-[11px] font-bold text-emerald-400 uppercase">Station-Led Housing &amp; Land</div>
            <div class="space-y-1.5 text-slate-300">
              <div class="flex justify-between">
                <span>Developable Land:</span>
                <span class="font-mono font-bold text-white">{{ station.developableLandHa }} ha</span>
              </div>
              <div class="flex justify-between">
                <span>Housing Potential (1km):</span>
                <span class="font-mono font-bold text-emerald-400">{{ station.housingPotential1000m.toLocaleString() }} homes</span>
              </div>
              <div class="flex justify-between">
                <span>Direct Area Employment:</span>
                <span class="font-mono font-bold text-white">{{ station.directStationAreaJobs.toLocaleString() }} jobs</span>
              </div>
              <div class="flex justify-between">
                <span>Modelled Land Value Uplift:</span>
                <span class="font-mono font-bold text-emerald-400">+{{ station.modelledValueUpliftPct }}%</span>
              </div>
            </div>

            <!-- Interactive Modify Button -->
            <button 
              (click)="addStationDevelopableLand(station.id)"
              class="w-full mt-2 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 font-semibold rounded-lg transition-colors text-center">
              + Allocate +5ha Development Land
            </button>
          </div>
        }
      </div>
    </div>
  `
})
export class GisCorridorComponent {
  state = inject(CrossrailState);

  showSafeguarding = signal(true);
  showCatchments = signal(true);
  showBoreholes = signal(true);

  // SVG Pan/Zoom state
  viewX = signal(0);
  viewY = signal(0);
  viewW = signal(1000);
  viewH = signal(900);
  isPanning = false;
  startX = 0;
  startY = 0;

  viewBox = () => `${this.viewX()} ${this.viewY()} ${this.viewW()} ${this.viewH()}`;

  // SVG coordinates mapping from London geographic space
  getStationSvgX(st: StationData): number {
    const coords: Record<string, number> = {
      st_wimbledon: 245,
      st_tooting: 285,
      st_clapham_jct: 335,
      st_chelsea: 380,
      st_victoria: 430,
      st_tcr: 470,
      st_euston_stp: 495,
      st_angel: 535,
      st_dalston: 575,
      st_seven_sisters: 605,
      st_tottenham_hale: 635,
      st_broxbourne: 720
    };
    return coords[st.id] ?? 500;
  }

  getStationSvgY(st: StationData): number {
    const coords: Record<string, number> = {
      st_wimbledon: 715,
      st_tooting: 650,
      st_clapham_jct: 580,
      st_chelsea: 510,
      st_victoria: 440,
      st_tcr: 370,
      st_euston_stp: 320,
      st_angel: 280,
      st_dalston: 240,
      st_seven_sisters: 180,
      st_tottenham_hale: 140,
      st_broxbourne: 60
    };
    return coords[st.id] ?? 450;
  }

  getBoreholeSvgX(bh: BoreholeData): number {
    if (bh.id.includes('01')) return 230;
    if (bh.id.includes('05')) return 375;
    if (bh.id.includes('09')) return 490;
    return 630;
  }

  getBoreholeSvgY(bh: BoreholeData): number {
    if (bh.id.includes('01')) return 725;
    if (bh.id.includes('05')) return 515;
    if (bh.id.includes('09')) return 325;
    return 145;
  }

  corridorPathD(): string {
    return 'M 245,715 C 270,680 280,660 285,650 C 310,615 320,595 335,580 C 360,545 370,525 380,510 C 405,475 415,455 430,440 C 450,405 460,385 470,370 C 485,345 490,330 495,320 C 515,300 525,290 535,280 C 555,260 565,250 575,240 C 590,210 600,195 605,180 C 620,160 628,150 635,140 L 720,60';
  }

  selectStation(id: string) {
    this.state.selectedStationId.set(id);
  }

  addStationDevelopableLand(stationId: string) {
    this.state.updateStationDevelopableLand(stationId, 5.0);
  }

  // Pan and Zoom logic
  startPan(e: MouseEvent) {
    this.isPanning = true;
    this.startX = e.clientX;
    this.startY = e.clientY;
  }

  doPan(e: MouseEvent) {
    if (!this.isPanning) return;
    const dx = (e.clientX - this.startX) * (this.viewW() / 800);
    const dy = (e.clientY - this.startY) * (this.viewH() / 700);
    this.viewX.set(this.viewX() - dx);
    this.viewY.set(this.viewY() - dy);
    this.startX = e.clientX;
    this.startY = e.clientY;
  }

  endPan() {
    this.isPanning = false;
  }

  onZoom(e: WheelEvent) {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 0.9 : 1.1;
    const newW = Math.max(300, Math.min(2000, this.viewW() * factor));
    const newH = Math.max(250, Math.min(1800, this.viewH() * factor));
    this.viewW.set(newW);
    this.viewH.set(newH);
  }

  zoomIn() {
    this.viewW.set(Math.max(300, this.viewW() * 0.8));
    this.viewH.set(Math.max(250, this.viewH() * 0.8));
  }

  zoomOut() {
    this.viewW.set(Math.min(2000, this.viewW() * 1.25));
    this.viewH.set(Math.min(1800, this.viewH() * 1.25));
  }

  resetView() {
    this.viewX.set(0);
    this.viewY.set(0);
    this.viewW.set(1000);
    this.viewH.set(900);
  }
}
