import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-economic-appraisal',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-sky-400">DfT WebTAG Cost-Benefit Analysis (CBA)</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">60-Year Discounted Cash Flows &amp; 10,000-Run Monte Carlo</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Economic Appraisal &amp; Risk Distribution Engine</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-sky-500/10 border border-sky-500/20 px-3 py-1.5 rounded-lg text-sky-300">
            BCR: <strong>{{ state.economicAppraisal().bcr }}</strong> · NPV: <strong>£{{ state.economicAppraisal().npvGbpBn }}bn</strong>
          </span>
        </div>
      </div>

      <!-- CBA Master Indicators -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button type="button" class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl cursor-pointer hover:border-slate-700 text-left w-full"
             (click)="state.openProvenance('BCR')">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Benefit-Cost Ratio (BCR)</div>
          <div class="text-3xl font-display font-black text-sky-300 mt-1 tabular-nums">
            {{ state.economicAppraisal().bcr }}
          </div>
          <div class="text-[10px] text-emerald-400 font-mono mt-1">High Value for Money (&gt; 2.0)</div>
        </button>

        <button type="button" class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl cursor-pointer hover:border-slate-700 text-left w-full"
             (click)="state.openProvenance('BCR')">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Net Present Value (NPV)</div>
          <div class="text-3xl font-display font-black text-white mt-1 tabular-nums">
            £{{ state.economicAppraisal().npvGbpBn }} <span class="text-xs font-normal text-slate-400">bn</span>
          </div>
          <div class="text-[10px] text-sky-400 font-mono mt-1">60-Year Discounted Net Benefit</div>
        </button>

        <button type="button" class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl cursor-pointer hover:border-slate-700 text-left w-full"
             (click)="state.openProvenance('BCR')">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Present Value of Benefits (PVB)</div>
          <div class="text-3xl font-display font-black text-emerald-400 mt-1 tabular-nums">
            £{{ state.economicAppraisal().pvBenefitsGbpBn }} <span class="text-xs font-normal text-slate-400">bn</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-1">Time + Agglomeration + Carbon</div>
        </button>

        <button type="button" class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl cursor-pointer hover:border-slate-700 text-left w-full"
             (click)="state.openProvenance('CAPEX')">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Present Value of Costs (PVC)</div>
          <div class="text-3xl font-display font-black text-amber-300 mt-1 tabular-nums">
            £{{ state.economicAppraisal().pvCostsGbpBn }} <span class="text-xs font-normal text-slate-400">bn</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-1">Discounted Capital &amp; Lifecycle Opex</div>
        </button>
      </div>

      <!-- 60-Year Economic Benefit Breakdown (WebTAG Standards) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">60-Year WebTAG Benefit Breakdown</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <!-- Time Savings -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-400 block text-[10px] font-mono">User Travel Time Savings:</span>
            <span class="text-lg font-bold font-mono text-sky-400">£{{ state.economicAppraisal().timeSavingsPvBn }}bn</span>
            <span class="text-[10px] text-slate-500 block">VTTS £14.80/hour</span>
          </div>

          <!-- Agglomeration -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-400 block text-[10px] font-mono">Agglomeration Productivity:</span>
            <span class="text-lg font-bold font-mono text-emerald-400">£{{ state.economicAppraisal().agglomerationProductivityPvBn }}bn</span>
            <span class="text-[10px] text-slate-500 block">0.04 Elasticity to Density</span>
          </div>

          <!-- Labour Market -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-400 block text-[10px] font-mono">Labour Market Deepening:</span>
            <span class="text-lg font-bold font-mono text-white">£{{ state.economicAppraisal().labourMarketdeepeningPvBn }}bn</span>
            <span class="text-[10px] text-slate-500 block">Skills matching &amp; mobility</span>
          </div>

          <!-- Carbon Reduction -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-400 block text-[10px] font-mono">Carbon Emission Abatement:</span>
            <span class="text-lg font-bold font-mono text-emerald-300">£{{ state.economicAppraisal().carbonReductionPvBn }}bn</span>
            <span class="text-[10px] text-slate-500 block">DESNZ Carbon Price curve</span>
          </div>

          <!-- Reliability & Safety -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-400 block text-[10px] font-mono">Reliability &amp; Accidents:</span>
            <span class="text-lg font-bold font-mono text-slate-300">£{{ state.economicAppraisal().reliabilityAccidentsPvBn }}bn</span>
            <span class="text-[10px] text-slate-500 block">Road network decongestion</span>
          </div>
        </div>
      </div>

      <!-- 10,000-Iteration Monte Carlo Quantitative Risk Simulation (QRA) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">10,000-Iteration Monte Carlo Risk Simulation</h3>
            <p class="text-[11px] text-slate-400">Probabilistic confidence intervals (P10 pessimistic, P50 median, P90 optimistic).</p>
          </div>
          <span class="text-[10px] text-amber-400 font-mono bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
            10,000 Stochastic Iterations
          </span>
        </div>

        <!-- Monte Carlo Probability Distributions Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <!-- Capex Distribution -->
          <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
            <span class="text-[11px] font-bold text-slate-300 font-mono uppercase">Capital Cost Distribution (£bn)</span>
            <div class="space-y-1 font-mono pt-1">
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-slate-400">
                <span>P10 (Low Cost):</span>
                <span class="text-emerald-400 font-bold">£{{ state.monteCarloSimulation().costP10 }}bn</span>
              </div>
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-white">
                <span>P50 (Median Baseline):</span>
                <span class="text-sky-300 font-bold">£{{ state.monteCarloSimulation().costP50 }}bn</span>
              </div>
              <div class="flex justify-between py-0.5 text-slate-400">
                <span>P90 (High Outturn):</span>
                <span class="text-amber-400 font-bold">£{{ state.monteCarloSimulation().costP90 }}bn</span>
              </div>
            </div>
          </div>

          <!-- BCR Distribution -->
          <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
            <span class="text-[11px] font-bold text-slate-300 font-mono uppercase">Benefit-Cost Ratio (BCR)</span>
            <div class="space-y-1 font-mono pt-1">
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-slate-400">
                <span>P10 (Pessimistic):</span>
                <span class="text-amber-400 font-bold">{{ state.monteCarloSimulation().bcrP10 }}</span>
              </div>
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-white">
                <span>P50 (Median BCR):</span>
                <span class="text-sky-300 font-bold">{{ state.monteCarloSimulation().bcrP50 }}</span>
              </div>
              <div class="flex justify-between py-0.5 text-slate-400">
                <span>P90 (Upside Case):</span>
                <span class="text-emerald-400 font-bold">{{ state.monteCarloSimulation().bcrP90 }}</span>
              </div>
            </div>
          </div>

          <!-- Ridership Distribution -->
          <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
            <span class="text-[11px] font-bold text-slate-300 font-mono uppercase">Annual Ridership (Million Pax)</span>
            <div class="space-y-1 font-mono pt-1">
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-slate-400">
                <span>P10 (Low Growth):</span>
                <span class="text-slate-300 font-bold">{{ state.monteCarloSimulation().ridershipP10 }}m</span>
              </div>
              <div class="flex justify-between py-0.5 border-b border-slate-800 text-white">
                <span>P50 (Median):</span>
                <span class="text-sky-300 font-bold">{{ state.monteCarloSimulation().ridershipP50 }}m</span>
              </div>
              <div class="flex justify-between py-0.5 text-slate-400">
                <span>P90 (High Transit):</span>
                <span class="text-emerald-400 font-bold">{{ state.monteCarloSimulation().ridershipP90 }}m</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EconomicAppraisalComponent {
  state = inject(CrossrailState);
}
