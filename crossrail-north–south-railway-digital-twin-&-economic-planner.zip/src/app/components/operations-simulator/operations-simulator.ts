import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-operations-simulator',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">Railway Operations &amp; Timetable Engineering</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Traction Dynamics, Headways &amp; Core Line Capacity</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Operations Simulator &amp; Service Planner</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg text-emerald-300">
            {{ state.trainFrequencyTph() }} Trains/Hour/Direction ({{ (3600 / state.trainFrequencyTph()).toFixed(0) }}s Headway)
          </span>
        </div>
      </div>

      <!-- Train Performance & Line Capacity Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Rolling Stock Specifications (6 cols) -->
        <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">High-Capacity Regional EMU Vehicle Model</h3>
            <span class="text-[10px] text-sky-400 font-mono">Class 345+ Evolution</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Train Length:</span>
              <span class="text-base font-bold text-white font-mono">220 m (9-Car)</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">Continuous Walkway</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Passenger Capacity:</span>
              <span class="text-base font-bold text-sky-400 font-mono">1,500 Pax</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">450 seated / 1,050 std</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Maximum Design Speed:</span>
              <span class="text-base font-bold text-emerald-400 font-mono">140 km/h</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">100 km/h in tunnels</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Acceleration:</span>
              <span class="text-base font-bold text-white font-mono">1.1 m/s²</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">0-80 km/h in 22s</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Service Braking:</span>
              <span class="text-base font-bold text-white font-mono">1.0 m/s²</span>
              <span class="text-[10px] text-emerald-400 block mt-0.5">Regenerative 32%</span>
            </div>

            <div class="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px] font-mono">Standard Station Dwell:</span>
              <span class="text-base font-bold text-amber-300 font-mono">35 Seconds</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">Wide double doors</span>
            </div>
          </div>

          <!-- Traction Power & Energy Consumption -->
          <div class="p-3.5 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-[11px] font-bold text-slate-300 uppercase">Traction Energy &amp; Power Sub-stations</div>
            <div class="flex justify-between text-slate-300 py-0.5">
              <span>Specific Energy Consumption:</span>
              <span class="font-mono text-white">18.4 kWh / train-km</span>
            </div>
            <div class="flex justify-between text-slate-300 py-0.5">
              <span>Regenerative Braking Recovery:</span>
              <span class="font-mono text-emerald-400">32.4% Energy Returned to Grid</span>
            </div>
            <div class="flex justify-between text-slate-300 py-0.5">
              <span>Bulk Supply Feeders:</span>
              <span class="font-mono text-white">4x 400kV / 25kV National Grid Infeeds</span>
            </div>
          </div>
        </div>

        <!-- Service Pattern & Capacity Engine (6 cols) -->
        <div class="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Peak Service Pattern &amp; Throughput</h3>
            <span class="text-[10px] text-emerald-400 font-mono">CBTC Moving Block</span>
          </div>

          <!-- Frequency Slider -->
          <div class="space-y-2 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
            <div class="flex justify-between text-xs">
              <span class="text-slate-300 font-medium">Core Tunnel Peak Frequency:</span>
              <span class="font-mono text-emerald-400 font-bold">{{ state.trainFrequencyTph() }} Trains Per Hour (tph)</span>
            </div>
            <input 
              type="range" 
              min="12" 
              max="36" 
              step="2" 
              [value]="state.trainFrequencyTph()"
              (input)="onFrequencyChange($event)"
              class="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded cursor-pointer">
            <div class="flex justify-between text-[10px] font-mono text-slate-500">
              <span>12 tph (Standard)</span>
              <span>24 tph (Elizabeth Line baseline)</span>
              <span>36 tph (Maximum ATO limit)</span>
            </div>
          </div>

          <!-- Total Hourly Directional Capacity -->
          <div class="grid grid-cols-2 gap-3 text-center">
            <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span class="text-[10px] font-mono text-slate-400 uppercase">Core Hourly Capacity</span>
              <div class="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {{ (state.trainFrequencyTph() * 1500).toLocaleString() }}
              </div>
              <span class="text-[10px] text-slate-500">passengers / hour / direction</span>
            </div>

            <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span class="text-[10px] font-mono text-slate-400 uppercase">Line Headway</span>
              <div class="text-2xl font-bold font-mono text-sky-400 mt-1">
                {{ (3600 / state.trainFrequencyTph()).toFixed(0) }}s
              </div>
              <span class="text-[10px] text-slate-500">minimum signal spacing</span>
            </div>
          </div>

          <!-- Service Branches Pattern -->
          <div class="space-y-1.5 text-xs">
            <div class="font-mono text-[10px] font-bold text-slate-400 uppercase">Branch Routing Allocation (30 tph Standard)</div>
            <div class="p-2 bg-slate-950/40 rounded border border-slate-800 flex justify-between">
              <span>Hertford East &amp; Broxbourne ↔ Wimbledon (All-Stations)</span>
              <span class="font-mono font-bold text-sky-400">12 tph</span>
            </div>
            <div class="p-2 bg-slate-950/40 rounded border border-slate-800 flex justify-between">
              <span>New Southgate / Welwyn ↔ Hampton Court &amp; Shepperton</span>
              <span class="font-mono font-bold text-sky-400">10 tph</span>
            </div>
            <div class="p-2 bg-slate-950/40 rounded border border-slate-800 flex justify-between">
              <span>Tottenham Hale ↔ Chessington South &amp; Epsom</span>
              <span class="font-mono font-bold text-sky-400">8 tph</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OperationsSimulatorComponent {
  state = inject(CrossrailState);

  onFrequencyChange(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.trainFrequencyTph.set(val);
  }
}
