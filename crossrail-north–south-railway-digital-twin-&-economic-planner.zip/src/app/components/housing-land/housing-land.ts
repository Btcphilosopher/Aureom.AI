import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-housing-land',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">Transit-Oriented Development &amp; Land Uplift</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Housing Delivery, Land Value Capture &amp; Opportunity Areas</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">Station Housing Capacity &amp; Land Value Capture</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg text-emerald-300">
            {{ state.housingAndLandMetrics().totalHomesEnabled.toLocaleString() }} Homes Enabled · £{{ state.housingAndLandMetrics().totalModelledValueUpliftM.toFixed(0) }}m Modelled Land Uplift
          </span>
        </div>
      </div>

      <!-- Headline Spatial Metrics -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400 uppercase">500m Core Station Walking Catchment</div>
          <div class="text-2xl font-bold font-display text-white mt-1 font-mono">
            {{ state.housingAndLandMetrics().totalHomes500m.toLocaleString() }} <span class="text-xs font-normal text-slate-400">homes</span>
          </div>
          <div class="text-[10px] text-emerald-400 font-mono mt-1">High-density direct frontage</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400 uppercase">1,000m Extended Transit Isochrone</div>
          <div class="text-2xl font-bold font-display text-emerald-400 mt-1 font-mono">
            {{ state.housingAndLandMetrics().totalHomes1000m.toLocaleString() }} <span class="text-xs font-normal text-slate-400">homes</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-1">10-12 min walking catchment</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Developable Brownfield Area</div>
          <div class="text-2xl font-bold font-display text-sky-400 mt-1 font-mono">
            {{ state.housingAndLandMetrics().totalDevelopableHa }} <span class="text-xs font-normal text-slate-400">hectares</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-1">Upper Lea Valley + SW Corridors</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div class="text-[11px] font-mono text-slate-400 uppercase">Modelled Land Value Uplift</div>
          <div class="text-2xl font-bold font-display text-amber-300 mt-1 font-mono">
            £{{ (state.housingAndLandMetrics().totalModelledValueUpliftM / 1000).toFixed(2) }} <span class="text-xs font-normal text-slate-400">bn</span>
          </div>
          <div class="text-[10px] text-amber-400 font-mono mt-1">Potential Value Capture base</div>
        </div>
      </div>

      <!-- Two-Column Grid: Station Housing Table & Interactive Site Simulator -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Station Housing Allocation Table (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div class="px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Station-By-Station Housing Potential</h3>
            <span class="text-[10px] text-slate-400 font-mono">GLA SHLAA Densities</span>
          </div>

          <div class="overflow-y-auto max-h-96">
            <table class="w-full text-left text-xs border-collapse">
              <thead class="bg-slate-950/80 sticky top-0 border-b border-slate-800 font-mono text-[10px] text-slate-400 uppercase">
                <tr>
                  <th class="py-2.5 px-3">Station Node</th>
                  <th class="py-2.5 px-2 text-right">Land (Ha)</th>
                  <th class="py-2.5 px-2 text-right">Homes (500m)</th>
                  <th class="py-2.5 px-2 text-right">Homes (1km)</th>
                  <th class="py-2.5 px-2 text-right">Land Uplift</th>
                  <th class="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-mono">
                @for (st of state.stations(); track st.id) {
                  <tr class="hover:bg-slate-800/40 transition-colors">
                    <td class="py-2.5 px-3 font-sans font-semibold text-slate-100">
                      {{ st.name }} (Z{{ st.zone }})
                    </td>
                    <td class="py-2.5 px-2 text-right text-slate-300 tabular-nums">{{ st.developableLandHa }} ha</td>
                    <td class="py-2.5 px-2 text-right text-slate-300 tabular-nums">{{ st.housingPotential500m.toLocaleString() }}</td>
                    <td class="py-2.5 px-2 text-right text-emerald-400 font-bold tabular-nums">{{ st.housingPotential1000m.toLocaleString() }}</td>
                    <td class="py-2.5 px-2 text-right text-amber-300 tabular-nums">+{{ st.modelledValueUpliftPct }}%</td>
                    <td class="py-2.5 px-3 text-right">
                      <button 
                        (click)="addLand(st.id)"
                        class="px-2 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 text-[10px] rounded border border-emerald-500/30">
                        +5 Ha
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Right: Interactive Parcel Development Simulator (5 cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Parametric Development Site Calculator</h3>
            <span class="text-[10px] text-sky-400 font-mono">Interactive Site FAR</span>
          </div>

          <!-- Site Area Slider -->
          <div class="space-y-1 text-xs">
            <div class="flex justify-between">
              <span class="text-slate-400">Masterplan Site Area:</span>
              <span class="font-mono text-white font-bold">{{ siteAreaHa() }} Hectares</span>
            </div>
            <input 
              type="range" 
              min="2" 
              max="50" 
              step="1" 
              [value]="siteAreaHa()" 
              (input)="siteAreaHa.set(+$any($event.target).value)"
              class="w-full accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer">
          </div>

          <!-- Floor Area Ratio (FAR) Slider -->
          <div class="space-y-1 text-xs">
            <div class="flex justify-between">
              <span class="text-slate-400">Plot Ratio Density (FAR):</span>
              <span class="font-mono text-emerald-400 font-bold">{{ plotRatioFar() }}:1 FAR</span>
            </div>
            <input 
              type="range" 
              min="1.5" 
              max="8.0" 
              step="0.5" 
              [value]="plotRatioFar()" 
              (input)="plotRatioFar.set(+$any($event.target).value)"
              class="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded cursor-pointer">
          </div>

          <!-- Calculated Yield Output -->
          <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-[10px] font-bold text-slate-400 uppercase">Modelled Scheme Development Yield</div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-300">Total Gross Internal Area (GIA):</span>
              <span class="font-mono font-bold text-white">{{ (siteAreaHa() * 10000 * plotRatioFar()).toLocaleString() }} m²</span>
            </div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-300">Residential Dwellings (70% mix):</span>
              <span class="font-mono font-bold text-emerald-400">{{ Math.round((siteAreaHa() * 10000 * plotRatioFar() * 0.7) / 75).toLocaleString() }} Homes</span>
            </div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-300">Commercial Workspace Jobs:</span>
              <span class="font-mono font-bold text-sky-400">{{ Math.round((siteAreaHa() * 10000 * plotRatioFar() * 0.25) / 14).toLocaleString() }} Jobs</span>
            </div>
            <div class="flex justify-between py-0.5 font-bold">
              <span class="text-slate-200">Estimated CIL / Section 106 Value Capture:</span>
              <span class="font-mono text-amber-300">£{{ ((siteAreaHa() * 10000 * plotRatioFar() * 0.7 * 185) / 1000000).toFixed(1) }}m</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HousingLandComponent {
  state = inject(CrossrailState);
  Math = Math;

  siteAreaHa = signal(12);
  plotRatioFar = signal(3.5);

  addLand(stationId: string) {
    this.state.updateStationDevelopableLand(stationId, 5.0);
  }
}
