import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CrossrailState } from '../../services/crossrail-state';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-demand-modelling',
  imports: [MatIconModule, CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col overflow-y-auto bg-slate-950 text-slate-100 p-6 space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold uppercase tracking-wider text-sky-400">4-Stage Transport Demand Engine</span>
            <span class="text-slate-600">·</span>
            <span class="text-xs text-slate-400">Origin-Destination Assignment &amp; Journey Times</span>
          </div>
          <h2 class="text-xl font-bold font-display text-white mt-1">London Transport Demand &amp; Journey Times Matrix</h2>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono bg-sky-500/10 border border-sky-500/20 px-3 py-1.5 rounded-lg text-sky-300">
            {{ state.demandMetrics().annualRidershipM }}m Annual Journeys · -18.4 min Avg Time Saving
          </span>
        </div>
      </div>

      <!-- 4-Stage Transport Model Pipeline Architecture -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">The 4-Stage Transport Planning Framework</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <!-- Step 1 -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
            <div class="font-mono text-[10px] font-bold text-sky-400 uppercase">1. Trip Generation</div>
            <div class="font-bold text-slate-100">Population &amp; Employment</div>
            <p class="text-[11px] text-slate-400">Borough-level SHLAA housing completions + ONS employment growth (+1.1% p.a.).</p>
          </div>

          <!-- Step 2 -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
            <div class="font-mono text-[10px] font-bold text-sky-400 uppercase">2. Trip Distribution</div>
            <div class="font-bold text-slate-100">Doubly-Constrained Gravity</div>
            <p class="text-[11px] text-slate-400">Spatial interaction matrix calibrated on TfL Travel in London Survey (LTIS).</p>
          </div>

          <!-- Step 3 -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
            <div class="font-mono text-[10px] font-bold text-emerald-400 uppercase">3. Mode Choice</div>
            <div class="font-bold text-slate-100">Nested Logit Elasticity</div>
            <p class="text-[11px] text-slate-400">23% mode switch from private automobile; 68% abstraction from crowded tube lines.</p>
          </div>

          <!-- Step 4 -->
          <div class="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
            <div class="font-mono text-[10px] font-bold text-amber-400 uppercase">4. Network Assignment</div>
            <div class="font-bold text-slate-100">Capacity-Restrained User Equilibrium</div>
            <p class="text-[11px] text-slate-400">Wardrop equilibrium accounting for in-vehicle time, interchange penalties &amp; crowding.</p>
          </div>
        </div>
      </div>

      <!-- Origin-Destination Journey Times Matrix Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
        <div class="px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div>
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">Key Regional Origin–Destination Corridor Pairs</h3>
            <p class="text-[11px] text-slate-400">Door-to-door transit time comparison with baseline and Crossrail North-South.</p>
          </div>
          <span class="text-[10px] text-emerald-400 font-mono">10 Primary Calibration Corridors</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead class="bg-slate-950/80 border-b border-slate-800 font-mono text-[10px] text-slate-400 uppercase">
              <tr>
                <th class="py-3 px-4">Origin Node</th>
                <th class="py-3 px-4">Destination Node</th>
                <th class="py-3 px-3 text-right">Baseline Time</th>
                <th class="py-3 px-3 text-right">Crossrail N-S</th>
                <th class="py-3 px-3 text-right">Time Saved</th>
                <th class="py-3 px-3 text-right">Daily Trips</th>
                <th class="py-3 px-3 text-right">Car Mode Shift</th>
                <th class="py-3 px-4 text-right">Annual Time Value</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (od of state.demandODPairs(); track od.origin + od.destination) {
                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-2.5 px-4 font-semibold text-slate-200">{{ od.origin }}</td>
                  <td class="py-2.5 px-4 font-semibold text-slate-200">{{ od.destination }}</td>
                  <td class="py-2.5 px-3 text-right font-mono text-slate-400 tabular-nums">{{ od.baselineTimeMin }} min</td>
                  <td class="py-2.5 px-3 text-right font-mono text-sky-400 font-bold tabular-nums">{{ od.crossrailTimeMin }} min</td>
                  <td class="py-2.5 px-3 text-right font-mono text-emerald-400 font-bold tabular-nums">
                    -{{ od.timeSavingsMin }} min
                  </td>
                  <td class="py-2.5 px-3 text-right font-mono text-slate-300 tabular-nums">{{ od.dailyTripsCrossrail.toLocaleString() }}</td>
                  <td class="py-2.5 px-3 text-right font-mono text-amber-300 tabular-nums">{{ od.modeShiftFromCarPct }}%</td>
                  <td class="py-2.5 px-4 text-right font-mono font-bold text-slate-100 tabular-nums">£{{ od.economicValueGbpAnnualM }}m/yr</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class DemandModellingComponent {
  state = inject(CrossrailState);
}
