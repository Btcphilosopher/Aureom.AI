export interface ProvenanceRecord {
  metricKey: string;
  label: string;
  source: 'ACTUAL PUBLISHED INFORMATION' | 'SYNTHETIC STRATEGIC MODEL' | 'ENGINEERING ASSUMPTION' | 'USER INPUT' | 'SCENARIO' | 'FORECAST' | 'ECONOMIC ESTIMATE';
  citation: string;
  baseYear: number;
  model: string;
  assumptions: string[];
  calculationMethod: string;
  confidence: 'HIGH' | 'MEDIUM' | 'SCENARIO_DEPENDENT';
}

export type SchemeOptionId = 'baseline' | 'option_a' | 'option_b' | 'option_c' | 'london_growth_2050' | 'accelerated_delivery' | 'high_cost';

export interface SchemeConfig {
  id: SchemeOptionId;
  name: string;
  status: string;
  baseYear: number;
  openingYear: number;
  designHorizon: number;
  description: string;
  totalLengthKm: number;
  tunnelLengthKm: number;
  surfaceLengthKm: number;
  stationsCount: number;
  newUndergroundStationsCount: number;
  peakTph: number;
  offPeakTph: number;
  trainType: string;
  trainLengthMeters: number;
  trainCapacityPax: number;
  capexInflationPct: number;
  discountRatePct: number;
  appraisalYears: number;
  populationGrowthPct: number;
  employmentGrowthPct: number;
}

export interface AlignmentNode {
  id: string;
  name: string;
  chainageKm: number;
  type: 'surface_station' | 'underground_station' | 'portal' | 'shaft' | 'waypoint' | 'junction';
  latitude: number;
  longitude: number;
  groundElevationM: number;
  trackElevationM: number; // relative to sea level / ordnance datum
  depthBelowSurfaceM: number;
  horizontalRadiusM: number; // 0 for straight tangent
  cantMm: number;
  cantDeficiencyMm: number;
  designSpeedKmh: number;
  gradientPct: number;
  geologyLayer: 'Made Ground' | 'London Clay' | 'Lambeth Group' | 'Thanet Sand' | 'Chalk';
  isStation: boolean;
  stationCode?: string;
  zone?: number;
  interchanges?: string[];
  platformsCount?: number;
  platformLengthM?: number;
}

export interface StationData {
  id: string;
  name: string;
  code: string;
  type: 'DEEP TUBE STATION' | 'CUT-AND-COVER BOX' | 'SURFACE REGIONAL' | 'TERMINAL INTERCHANGE';
  borough: string;
  zone: number;
  depthMeters: number;
  platformLengthM: number;
  platformsCount: number;
  ticketHallsCount: number;
  escalatorBanksCount: number;
  liftsCount: number;
  amPeakEntries: number;
  amPeakExits: number;
  amPeakInterchange: number;
  criticalBottleneck: string;
  escalatorUtilisationPct: number;
  concourseDensityPaxM2: number;
  interchanges: {
    name: string;
    lineType: 'Elizabeth line' | 'Underground' | 'National Rail' | 'Overground' | 'HS2 Interface' | 'Thameslink';
    walkTimeMin: number;
    verticalTransferM: number;
    crowdingLevel: 'Low' | 'Moderate' | 'High' | 'Severe';
  }[];
  housingPotential500m: number;
  housingPotential1000m: number;
  developableLandHa: number;
  currentLandValueMperHa: number;
  modelledValueUpliftPct: number;
  jobsAccessible30min: number;
  jobsAccessible45min: number;
  directStationAreaJobs: number;
}

export interface TunnelBore {
  id: string;
  name: string;
  boreType: 'TWIN BORE' | 'SINGLE BORE' | 'STATION CAVERN' | 'CROSS PASSAGE' | 'VENT SHAFT';
  startChainageKm: number;
  endChainageKm: number;
  lengthKm: number;
  internalDiameterM: number;
  externalDiameterM: number;
  liningType: 'Precast Concrete Segments (SGI bolted)' | 'Cast Iron' | 'Sprayed Concrete Lining (SCL)';
  tbmAssigned?: string;
  primaryGeology: string;
  groundwaterRisk: 'Low' | 'Moderate' | 'High (Pressurised Aquifer)';
  depthRangeM: [number, number];
}

export interface TbmMachine {
  id: string;
  name: string;
  type: 'Earth Pressure Balance (EPB)' | 'Mixshield / Slurry';
  cutterheadDiameterM: number;
  launchSite: string;
  destinationSite: string;
  totalDriveKm: number;
  drivenKm: number;
  advanceRateMPerDay: number;
  thrustKn: number;
  torqueKnm: number;
  installedSegmentsCount: number;
  totalSegmentsNeeded: number;
  spoilExcavatedTonnes: number;
  status: 'COMMISSIONING' | 'BORING' | 'MAINTENANCE' | 'BREAKTHROUGH' | 'COMPLETED' | 'STANDBY';
  shiftPattern: '24/7 (3x8h shifts)';
  crewSize: number;
  availabilityPct: number;
}

export interface ConstructionTask {
  id: string;
  name: string;
  category: 'CONSENTS' | 'ENABLING' | 'SHAFTS' | 'TUNNELLING' | 'STATIONS' | 'SURFACE_SYSTEMS' | 'SYSTEMS_TESTING';
  startYear: number;
  endYear: number;
  progressPct: number;
  costM: number;
  criticalPath: boolean;
  predecessors: string[];
}

export interface DemandODPair {
  origin: string;
  destination: string;
  baselineTimeMin: number;
  crossrailTimeMin: number;
  timeSavingsMin: number;
  dailyTripsBaseline: number;
  dailyTripsCrossrail: number;
  modeShiftFromCarPct: number;
  modeShiftFromBusTubePct: number;
  economicValueGbpAnnualM: number;
}

export interface EconomicAppraisalMetrics {
  capexTotalGbpBn: number;
  annualOpexGbpM: number;
  annualFareRevenueGbpM: number;
  annualNonFareRevenueGbpM: number;
  pvCostsGbpBn: number; // 60-year discounted
  pvBenefitsGbpBn: number;
  npvGbpBn: number;
  bcr: number;
  // Benefit breakdown
  timeSavingsPvBn: number;
  agglomerationProductivityPvBn: number;
  labourMarketdeepeningPvBn: number;
  carbonReductionPvBn: number;
  reliabilityAccidentsPvBn: number;
  // Real world impacts
  homesEnabledTotal: number;
  directJobsConstruction: number;
  permanentOperationalJobs: number;
  accessibilityEnabledJobsTotal: number;
  annualRidershipMillions: number;
}

export interface MonteCarloResult {
  iterations: number;
  costDistribution: number[]; // £bn
  bcrDistribution: number[];
  ridershipDistribution: number[]; // million pax
  npvDistribution: number[]; // £bn
  costP10: number;
  costP50: number;
  costP90: number;
  bcrP10: number;
  bcrP50: number;
  bcrP90: number;
  ridershipP10: number;
  ridershipP50: number;
  ridershipP90: number;
}

export interface BoreholeData {
  id: string;
  name: string;
  chainageKm: number;
  location: string;
  surfaceElevationM: number;
  totalDepthM: number;
  strata: {
    layer: string;
    fromM: number;
    toM: number;
    color: string;
    description: string;
  }[];
  groundwaterDepthM: number;
}
