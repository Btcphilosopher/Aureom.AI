# ================================================================
# COFFEEHARVEST.jl
#
# Coffee plantation digital twin + harvesting optimiser
#
# Research / agricultural simulation software
# ================================================================

using Random
using Statistics
using LinearAlgebra
using Printf


# ================================================================
# 1. COFFEE PLANT
# ================================================================

mutable struct CoffeeTree

    id::Int

    x::Float64
    y::Float64

    elevation::Float64
    slope::Float64

    # Estimated number of cherries
    total_cherries::Int

    # Ripeness fractions
    green_fraction::Float64
    ripe_fraction::Float64
    overripe_fraction::Float64

    # Estimated yield
    expected_mass_kg::Float64

    harvested_mass_kg::Float64

end


# ================================================================
# 2. TERRAIN
# ================================================================

struct TerrainCell

    x::Float64
    y::Float64

    elevation::Float64
    slope::Float64

end


struct Plantation

    width_m::Float64
    height_m::Float64

    trees::Vector{CoffeeTree}
    terrain::Vector{TerrainCell}

end


# ================================================================
# 3. HARVESTER
# ================================================================

mutable struct Harvester

    x::Float64
    y::Float64

    speed_mps::Float64

    harvesting_rate::Float64

    fuel_litres::Float64

    fuel_burn_lph::Float64

    hopper_capacity_kg::Float64

    hopper_mass_kg::Float64

    damage_rate::Float64

    selectivity::Float64

end


# ================================================================
# 4. HARVESTING CONFIGURATION
# ================================================================

struct HarvestConfig

    ripe_threshold::Float64

    minimum_pick_fraction::Float64

    maximum_slope_deg::Float64

    travel_speed_mps::Float64

    harvest_efficiency::Float64

    cherry_mass_g::Float64

end


# ================================================================
# 5. GENERATE PLANTATION
# ================================================================

function generate_plantation(
    rows::Int,
    trees_per_row::Int,
    row_spacing::Float64,
    tree_spacing::Float64
)

    trees =
        CoffeeTree[]

    id = 1

    for row in 1:rows

        y =
            row *
            row_spacing


        for tree_index in
            1:trees_per_row

            x =
                tree_index *
                tree_spacing


            # Synthetic terrain

            elevation =
                100.0 +
                10.0 *
                sin(x / 100.0) +
                8.0 *
                cos(y / 80.0)


            slope =
                abs(
                    8.0 *
                    sin(
                        x / 150.0
                    )
                )


            cherries =
                rand(
                    800:2500
                )


            ripe =
                rand(
                    0.35:0.01:0.80
                )


            green =
                rand(
                    0.10:0.01:0.40
                )


            overripe =
                max(
                    0.0,
                    1.0 -
                    ripe -
                    green
                )


            expected_mass =
                cherries *
                0.002


            push!(
                trees,

                CoffeeTree(

                    id,

                    x,
                    y,

                    elevation,
                    slope,

                    cherries,

                    green,
                    ripe,
                    overripe,

                    expected_mass,

                    0.0
                )
            )


            id += 1

        end
    end


    width =
        trees_per_row *
        tree_spacing


    height =
        rows *
        row_spacing


    terrain =
        TerrainCell[]


    return Plantation(
        width,
        height,
        trees,
        terrain
    )

end


# ================================================================
# 6. RIPE CHERRY ESTIMATION
# ================================================================

function ripe_cherries(
    tree::CoffeeTree
)

    return round(
        Int,

        tree.total_cherries *
        tree.ripe_fraction
    )

end


function ripe_mass(
    tree::CoffeeTree,
    cherry_mass_g
)

    return (
        ripe_cherries(tree) *
        cherry_mass_g /
        1000.0
    )

end


# ================================================================
# 7. HARVESTABILITY
# ================================================================

function harvestability(
    tree,
    config
)

    if tree.slope >
       config.maximum_slope_deg

        return 0.0
    end


    ripe =
        tree.ripe_fraction


    if ripe <
       config.ripe_threshold

        return 0.0
    end


    # More ripe fruit = greater priority

    return min(
        1.0,
        ripe /
        config.minimum_pick_fraction
    )

end


# ================================================================
# 8. TREE PRIORITY
# ================================================================

function tree_priority(
    tree,
    harvester,
    config
)

    h =
        harvestability(
            tree,
            config
        )


    if h == 0.0
        return 0.0
    end


    dx =
        tree.x -
        harvester.x


    dy =
        tree.y -
        harvester.y


    distance =
        sqrt(
            dx^2 +
            dy^2
        )


    distance_factor =
        1.0 /
        (
            1.0 +
            distance
        )


    yield_factor =
        ripe_mass(
            tree,
            config.cherry_mass_g
        )


    # Higher yield + higher ripeness +
    # nearby location = higher priority.

    return (
        0.50 * h +
        0.35 * yield_factor +
        0.15 * distance_factor
    )

end


# ================================================================
# 9. FIND NEXT TREE
# ================================================================

function next_tree(
    plantation,
    harvester,
    config
)

    best_tree =
        nothing

    best_score =
        -Inf


    for tree in
        plantation.trees

        if tree.harvested_mass_kg >
           0.0

            continue
        end


        score =
            tree_priority(
                tree,
                harvester,
                config
            )


        if score >
           best_score

            best_score =
                score

            best_tree =
                tree

        end

    end


    return best_tree

end


# ================================================================
# 10. MOVE HARVESTER
# ================================================================

function move_to!(
    harvester,
    tree,
    dt
)

    dx =
        tree.x -
        harvester.x


    dy =
        tree.y -
        harvester.y


    distance =
        sqrt(
            dx^2 +
            dy^2
        )


    if distance < 0.01

        return distance
    end


    step =
        min(
            distance,
            harvester.speed_mps *
            dt
        )


    harvester.x +=
        dx /
        distance *
        step


    harvester.y +=
        dy /
        distance *
        step


    return step

end


# ================================================================
# 11. SELECTIVE HARVEST
# ================================================================

function harvest!(
    tree,
    harvester,
    config,
    dt
)

    available =
        ripe_mass(
            tree,
            config.cherry_mass_g
        )


    if available <= 0.0
        return 0.0
    end


    # Machine capacity per second

    capacity =
        harvester.harvesting_rate *
        dt


    harvestable =
        min(
            available,
            capacity
        )


    # Selectivity

    harvested =
        harvestable *
        harvester.selectivity *
        config.harvest_efficiency


    # Plant / fruit damage

    damaged =
        harvested *
        harvester.damage_rate


    usable =
        max(
            0.0,
            harvested -
            damaged
        )


    tree.harvested_mass_kg +=
        usable


    harvester.hopper_mass_kg +=
        usable


    return usable

end


# ================================================================
# 12. HOPPER MANAGEMENT
# ================================================================

function hopper_full(
    harvester
)

    return (
        harvester.hopper_mass_kg >=
        harvester.hopper_capacity_kg
    )

end


function unload!(
    harvester
)

    harvested =
        harvester.hopper_mass_kg


    harvester.hopper_mass_kg =
        0.0


    return harvested

end


# ================================================================
# 13. FUEL MODEL
# ================================================================

function consume_fuel!(
    harvester,
    dt
)

    burn =
        harvester.fuel_burn_lph *
        dt /
        3600.0


    harvester.fuel_litres =
        max(
            0.0,
            harvester.fuel_litres -
            burn
        )

end


# ================================================================
# 14. HARVEST SIMULATION
# ================================================================

function simulate_harvest!(
    plantation,
    harvester,
    config;

    duration_hours=8.0,
    dt=1.0
)

    harvested_total =
        0.0


    hopper_unloads =
        0


    steps =
        Int(
            duration_hours *
            3600 /
            dt
        )


    for step in
        1:steps

        target =
            next_tree(
                plantation,
                harvester,
                config
            )


        if target === nothing

            break
        end


        move_to!(
            harvester,
            target,
            dt
        )


        dx =
            target.x -
            harvester.x


        dy =
            target.y -
            harvester.y


        distance =
            sqrt(
                dx^2 +
                dy^2
            )


        if distance < 1.0

            harvested =
                harvest!(
                    target,
                    harvester,
                    config,
                    dt
                )


            harvested_total +=
                harvested

        end


        consume_fuel!(
            harvester,
            dt
        )


        if hopper_full(
            harvester
        )

            harvested_total +=
                unload!(
                    harvester
                )

            hopper_unloads += 1

        end


        if harvester.fuel_litres <= 0

            break
        end

    end


    return (
        harvested_kg=harvested_total,
        hopper_unloads=hopper_unloads,
        fuel_remaining=harvester.fuel_litres
    )

end


# ================================================================
# 15. HARVEST FORECAST
# ================================================================

function plantation_forecast(
    plantation,
    config
)

    total =
        0.0


    ripe =
        0.0


    overripe =
        0.0


    for tree in
        plantation.trees

        total +=
            tree.expected_mass_kg


        ripe +=
            ripe_mass(
                tree,
                config.cherry_mass_g
            )


        overripe +=
            tree.expected_mass_kg *
            tree.overripe_fraction

    end


    return (
        total_mass=total,
        ripe_mass=ripe,
        overripe_mass=overripe
    )

end


# ================================================================
# 16. MULTI-MACHINE FLEET SIMULATION
# ================================================================

function simulate_fleet(
    plantation,
    machine_count,
    config
)

    machines =
        Harvester[]


    for i in
        1:machine_count

        push!(
            machines,

            Harvester(

                0.0,
                i * 5.0,

                2.0,

                0.12,

                100.0,

                8.0,

                100.0,

                0.01,

                0.90
            )
        )

    end


    results =
        []


    for machine in
        machines

        result =
            simulate_harvest!(
                plantation,
                machine,
                config
            )

        push!(
            results,
            result
        )

    end


    return results

end


# ================================================================
# 17. MONTE CARLO YIELD MODEL
# ================================================================

function monte_carlo_yield(
    plantation,
    config;
    simulations=10_000
)

    results =
        Vector{Float64}(
            undef,
            simulations
        )


    base =
        plantation_forecast(
            plantation,
            config
        ).ripe_mass


    for i in
        1:simulations

        weather_factor =
            clamp(
                rand(
                    NormalLike()
                ),
                0.70,
                1.20
            )

        detection_factor =
            clamp(
                0.90 +
                0.05 *
                randn(),
                0.60,
                1.0
            )

        machine_factor =
            clamp(
                0.92 +
                0.04 *
                randn(),
                0.70,
                1.0
            )


        results[i] =
            base *
            weather_factor *
            detection_factor *
            machine_factor

    end


    return results

end


# ================================================================
# SIMPLE NORMAL RANDOM HELPER
# ================================================================

struct NormalLike end


Base.rand(::NormalLike) =
    1.0 +
    0.08 *
    randn()


# ================================================================
# 18. HARVEST ECONOMICS
# ================================================================

function harvest_economics(
    harvested_kg,
    coffee_price_per_kg,
    labour_cost,
    machine_cost,
    processing_cost
)

    revenue =
        harvested_kg *
        coffee_price_per_kg


    total_cost =
        labour_cost +
        machine_cost +
        processing_cost


    profit =
        revenue -
        total_cost


    return (
        revenue=revenue,
        cost=total_cost,
        profit=profit,
        margin=
            profit /
            max(
                revenue,
                1.0
            )
    )

end


# ================================================================
# 19. EXAMPLE
# ================================================================

Random.seed!(42)


plantation =
    generate_plantation(
        50,
        100,
        3.0,
        1.5
    )


config =
    HarvestConfig(

        0.55,

        0.60,

        35.0,

        1.5,

        0.92,

        2.0
    )


forecast =
    plantation_forecast(
        plantation,
        config
    )


println()
println(
    "===================================================="
)

println(
    "          COFFEEHARVEST.JL"
)

println(
    "===================================================="
)


@printf(
    "Trees:                 %,d\n",
    length(
        plantation.trees
    )
)


@printf(
    "Expected crop:         %.2f tonnes\n",
    forecast.total_mass /
    1000
)


@printf(
    "Ripe crop:             %.2f tonnes\n",
    forecast.ripe_mass /
    1000
)


@printf(
    "Overripe potential:    %.2f tonnes\n",
    forecast.overripe_mass /
    1000
)


harvester =
    Harvester(

        0.0,
        0.0,

        1.5,

        0.12,

        100.0,

        8.0,

        100.0,

        0.01,

        0.90
    )


result =
    simulate_harvest!(
        plantation,
        harvester,
        config;

        duration_hours=8.0
    )


println()
println(
    "HARVEST SIMULATION"
)

println(
    "----------------------------------------------------"
)


@printf(
    "Harvested:            %.2f kg\n",
    result.harvested_kg
)


@printf(
    "Fuel remaining:       %.2f L\n",
    result.fuel_remaining
)


@printf(
    "Hopper unloads:       %d\n",
    result.hopper_unloads
)


# ================================================================
# 20. ECONOMIC MODEL
# ================================================================

economics =
    harvest_economics(

        result.harvested_kg,

        4.50,

        450.0,

        300.0,

        250.0
    )


println()
println(
    "ECONOMICS"
)

println(
    "----------------------------------------------------"
)


@printf(
    "Revenue:              $%.2f\n",
    economics.revenue
)


@printf(
    "Cost:                 $%.2f\n",
    economics.cost
)


@printf(
    "Profit:               $%.2f\n",
    economics.profit
)


@printf(
    "Margin:               %.1f%%\n",
    economics.margin *
    100
)


println()
println(
    "===================================================="
)
