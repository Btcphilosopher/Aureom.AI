# Aureom.AI AuctionProof · Cryptographic Specification (V1)

This specification defines the cryptographic data structures, domain-separated commitment schemes, deterministic replay invariants, and quorum certificate formats for **Aureom.AI AuctionProof**.

---

## 1. Sealed-Bid Commit–Reveal Scheme

### 1.1 Domain Separation & Canonical Concatenation

To eliminate length extension attacks, delimiter collisions, and rainbow-table precomputation, commitments enforce a fixed domain prefix and strict formatting:

$$\text{Domain Prefix} = \texttt{"AUCTIONPROOF\_COMMIT\_V1"}$$

Canonical string format:
```
AUCTIONPROOF_COMMIT_V1:<auctionId>:<bidderId>:<amount.toFixed(2)>:<currency>:<conditionsDigest>:<secretNonce>
```

- `auctionId`: ASCII string identifying the target auction.
- `bidderId`: Unique identifier of the verified bidder entity.
- `amount`: Bid value normalized to exactly two decimal places (e.g. `64800.00`).
- `currency`: ISO 4217 uppercase code (e.g. `USD`, `EUR`, `USDC`).
- `conditionsDigest`: Hexadecimal SHA-256 digest of any bespoke legal/commercial terms.
- `secretNonce`: 256-bit (32-byte) hex string generated from a CSPRNG (`crypto.getRandomValues`).

Commitment Hash calculation:
$$\text{CommitmentHash} = \text{SHA-256}(\text{CanonicalCommitmentString})$$

### 1.2 Nonce Entropy Invariant

Low-range bid amounts ($10k–$500k) have small numeric domains that could easily be brute-forced via dictionary or rainbow-table attacks if hashed nakedly. The 256-bit secret nonce ensures $2^{256}$ search space, making pre-image brute force computationally impossible.

---

## 2. Append-Only Event Log Hash Chain

The auction ledger is organized as a cryptographically linked append-only hash chain:

$$H_0 = \text{"GENESIS\_ROOT"}$$
$$H_i = \text{SHA-256}\Big(\text{seqId}_i \parallel \text{prevHash}_{i-1} \parallel \text{timestampIso}_i \parallel \text{eventType}_i \parallel \text{actorId}_i \parallel \text{canonicalJson}(\text{payload}_i)\Big)$$

Where:
- $\text{seqId}_i = \text{seqId}_{i-1} + 1$
- $\text{prevHash}_i = H_{i-1}$

### Merkle Root Digest of Event Log

$$\text{EventLogDigest} = \text{SHA-256}\Big(\texttt{"AUCTIONPROOF\_LOG\_ROOT\_V1:"} + \bigoplus_{k=1}^N H_k\Big)$$

---

## 3. Deterministic Validation Invariants

Validators execute independent replay of the canonical event log. The replay engine checks:

1. **Hash-Chain Continuity**: $\forall i > 0, \text{prevHash}_i == H_{i-1}$.
2. **Authoritative Clock & Deadlines**: Client timestamps are informational. Acceptance sequence is determined by the server's signed monotonically increasing sequence ID. Bids received after `commitDeadlineIso` are rejected.
3. **Escrow Solvency**: Bidder must have locked $\ge \text{rules.depositRequiredAmount}$ in `BIDDER_DEPOSIT_ACCOUNT`.
4. **Vickrey Second-Price Calculation**:
   $$\text{Winner} = \operatorname{argmax}_{b \in \mathcal{B}_{\text{eligible}}} (\text{amount}(b))$$
   $$\text{ClearingPrice} = \max\Big(\text{reservePrice}, \max_{b \neq \text{Winner}} (\text{amount}(b))\Big)$$
5. **Stake Independence**: Validator stake weights NEVER influence bid ranking or winning prices. Stake is strictly an economic bond for validator honesty.

---

## 4. Quorum Certificate (QC) & Dissent Preservation

A Quorum Certificate requires $\ge 67\%$ supporting bonded stake across assigned committee nodes.

$$\text{SupportingStakeRatio} = \frac{\sum_{v \in \mathcal{V}_{\text{agree}}} \text{bondedStake}(v)}{\sum_{v \in \mathcal{V}_{\text{committee}}} \text{bondedStake}(v)} \ge 0.67$$

### Preservation of Dissent (Anti-Concealment Invariant)

Unlike naive voting protocols that hide dissenting opinions, AuctionProof Quorum Certificates explicitly record:
- Dissenting validator IDs
- Dissent reason codes
- Dissenting calculated prices/winners

### Slashing Invariant (Signed Equivocation)

If any validator $v$ signs two distinct attestations $A_1 \neq A_2$ with contradictory outcomes for the same `auctionId` and `eventLogDigest`:
$$\text{EquivocationProof} = \Big(\text{sig}_v(A_1), \text{sig}_v(A_2), A_1, A_2\Big)$$
This constitutes mathematical proof of misconduct. Slashing is automatic and does not depend on subjective majority vote.
