# Aureom.AI AuctionProof · API Documentation

## Base Architecture
- REST & Cryptographic RPC Endpoints
- Canonical JSON Payload serialization
- Cryptographic Receipts on every accepted transaction

---

## 1. Bidder & Commitment Endpoints

### `POST /api/v1/auctions/:id/commitments`
Submit a sealed cryptographic bid commitment with locked deposit.

**Request:**
```json
{
  "bidderId": "bidder-quantum-01",
  "bidderName": "Quantum Horizon Compute LLC",
  "commitmentHash": "b4a8e2cb91d5754020a1fefc39bf50392336e4f3a7f80db7d9b9a67e81cc13b4",
  "depositAmountUsd": 10000,
  "clientTimestampIso": "2026-11-11T10:14:20Z"
}
```

**Response (Signed Receipt):**
```json
{
  "receiptSequenceId": 105,
  "serverReceivedIso": "2026-11-11T10:14:22Z",
  "commitmentHash": "b4a8e2cb91d5754020a1fefc39bf50392336e4f3a7f80db7d9b9a67e81cc13b4",
  "escrowJournalId": "JRN-10105",
  "status": "COMMITTED",
  "serverSignature": "sig_srv_0912fa8102"
}
```

---

### `POST /api/v1/auctions/:id/reveals`
Reveal the secret parameters during the published reveal window.

**Request:**
```json
{
  "bidderId": "bidder-quantum-01",
  "amount": 64800.00,
  "currency": "USD",
  "conditionsDigest": "COND_STANDARD_TERMS_V1",
  "secretNonce": "8f2a1b9e0c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f"
}
```

**Response:**
```json
{
  "status": "REVEALED_VERIFIED",
  "reconstructedHash": "b4a8e2cb91d5754020a1fefc39bf50392336e4f3a7f80db7d9b9a67e81cc13b4",
  "hashMatch": true,
  "eventSeqId": 14,
  "recordedAtIso": "2026-11-11T12:08:14Z"
}
```

---

## 2. Validator Attestation & Consensus Endpoints

### `POST /api/v1/auctions/:id/attestations`
Validator node broadcasts its independent replay result and signed attestation.

**Request:**
```json
{
  "validatorId": "val-helvetia",
  "ruleVersion": "v1.4.0",
  "eventLogDigest": "e411b90cd9f38812c300fa71b691a7f4e912bc08d321556094b8e217",
  "computedWinnerId": "bidder-1",
  "computedClearingPrice": 59200,
  "feeCalculation": {
    "buyerFee": 888,
    "sellerFee": 1184,
    "validatorRewardPool": 1200,
    "sellerNetProceeds": 58016
  },
  "verdict": "CONFIRMED",
  "reasonCodes": ["SECOND_PRICE_SEALED_WINNER_PAYS_SECOND_PRICE"],
  "signature": "sig_ed25519_val_helvetia_001928"
}
```

---

## 3. Escrow & Audit Endpoints

### `GET /api/v1/auctions/:id/audit-packet`
Export the complete self-contained cryptographic audit package.

**Response:** Contains RFC-compliant verifiable package with event log, canonical rules, Merkle root, validator signatures, Quorum Certificate, double-entry trial balance, and anti-manipulation signals.
