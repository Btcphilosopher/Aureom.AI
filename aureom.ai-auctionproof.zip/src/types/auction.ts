/**
 * Aureom.AI AuctionProof - Domain Types & Specifications
 * Stake-backed verifiable auction engine, commit-reveal, escrow, and audit proofs.
 */

export type AuctionMechanism = 'ENGLISH' | 'FIRST_PRICE_SEALED' | 'SECOND_PRICE_SEALED';

export type AuctionCategory = 'EQUIPMENT' | 'SOFTWARE_LICENSE' | 'COMPUTE_CAPACITY' | 'COMMODITY';

export type AuctionStatus =
  | 'DRAFT'
  | 'PUBLISHED'
  | 'OPEN'
  | 'CLOSED'
  | 'VALIDATING'
  | 'AWARDED'
  | 'PAYMENT_PENDING'
  | 'DELIVERY_PENDING'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'DISPUTED'
  | 'FAILED'
  | 'REFUNDED';

export type TieBreakingPolicy = 'EARLIEST_RECEIPT' | 'CANONICAL_HASH_ORDER';

export interface ComputeSpecifications {
  hardwareClass: string; // e.g. "8x NVIDIA H100 SXM5 80GB"
  hostRamGb: number; // e.g. 1024
  interconnect: string; // e.g. "NVSwitch 900 GB/s + 3.2 Tbps InfiniBand"
  availablePeriodHours: number; // e.g. 720 (30 days)
  datacenterLocation: string; // e.g. "Equinix FR4, Frankfurt, Tier IV"
  softwareStack: string; // e.g. "Ubuntu 24.04 LTS, CUDA 12.6, vLLM 0.6.2, ROCm ready"
  usageLimitComputeHours: number; // e.g. 5760 GPU-hours
  uptimeSlaPercent: number; // e.g. 99.95%
  benchmarkTargetTflops: number; // e.g. 15,800 FP8 TFLOPS
  telemetryWorkerKeyId: string; // mTLS public key digest of worker agent
}

export interface LicenseSpecifications {
  licenseGrantType: 'EXCLUSIVE_ASSIGNMENT' | 'NON_EXCLUSIVE_COMMERCIAL' | 'SOURCE_AVAILABLE_DEPLOYMENT';
  permittedDeployments: number; // 0 = unlimited
  intellectualPropertyDisclaimer: string;
  patentCovenant: boolean;
  warrantyPeriodDays: number;
  digitalCertificateFingerprint: string;
}

export interface AuctionRules {
  rulesVersion: string; // e.g. "v1.2.0"
  rulesHash: string; // SHA-256 of canonical rule json
  mechanism: AuctionMechanism;
  currency: 'USD' | 'EUR' | 'USDC';
  reservePrice: number;
  minBidIncrement: number; // for English auctions
  antiSnipingWindowSeconds: number; // e.g. 300s (5 min) extension if bid placed in last 300s
  antiSnipingExtensionSeconds: number; // e.g. 300s
  commitDeadlineIso: string;
  revealDeadlineIso: string;
  depositRequiredAmount: number;
  unrevealedPenaltyPercent: number; // penalty deducted from deposit if bidder commits but fails to reveal
  buyerFeePercent: number; // e.g. 1.5%
  sellerFeePercent: number; // e.g. 2.0%
  validatorFeeReward: number; // fixed compensation pool for committee
  tieBreakingPolicy: TieBreakingPolicy;
  quorumThresholdPercent: number; // e.g. 67% (2/3 majority)
  committeeSize: number; // e.g. 5 validators
  thresholdEncryptionAdapter: 'SIMULATED_THRESHOLD_DECRYPTION' | 'STANDARD_COMMIT_REVEAL';
}

export interface BidCommitment {
  commitmentHash: string; // SHA256(AUCTIONPROOF_COMMIT_V1:auctionId:bidderId:amount:currency:conditionsDigest:nonce)
  auctionId: string;
  bidderId: string;
  bidderName: string;
  receiptSequenceId: number;
  serverReceivedIso: string;
  clientTimestampIso: string;
  depositLockedAmount: number;
  status: 'COMMITTED' | 'REVEALED' | 'NON_REVEALED' | 'DISQUALIFIED';
  revealedPayload?: {
    amount: number;
    currency: string;
    conditionsDigest: string;
    secretNonce: string;
    revealedAtIso: string;
    rawCanonicalString: string;
  };
}

export interface EnglishBid {
  bidId: string;
  auctionId: string;
  bidderId: string;
  bidderName: string;
  amount: number;
  receiptSequenceId: number;
  serverReceivedIso: string;
  clientTimestampIso: string;
  extensionTriggered: boolean;
  newDeadlineIso?: string;
  status: 'ACCEPTED' | 'OUTBID' | 'WITHDRAWN_ILLEGAL' | 'INVALID_INCREMENT';
}

export type LedgerEventType =
  | 'AUCTION_INITIALIZED'
  | 'RULES_PUBLISHED'
  | 'BIDDER_REGISTERED'
  | 'DEPOSIT_ESCROWED'
  | 'COMMITMENT_RECORDED'
  | 'BID_RECORDED'
  | 'REVEAL_RECORDED'
  | 'REVEAL_WINDOW_CLOSED'
  | 'NON_REVEAL_PENALTY_ENFORCED'
  | 'VALIDATION_COMMITTEE_ASSIGNED'
  | 'ATTESTATION_SUBMITTED'
  | 'QUORUM_CERTIFICATE_ISSUED'
  | 'EQUIVOCATION_DETECTED'
  | 'VALIDATOR_SLASHED'
  | 'OUTCOME_AWARDED'
  | 'PAYMENT_CONFIRMED'
  | 'DELIVERY_EVIDENCE_POSTED'
  | 'DELIVERY_DISPUTED'
  | 'DISPUTE_RESOLVED'
  | 'ESCROW_RELEASED';

export interface LedgerEvent {
  seqId: number;
  prevHash: string;
  hash: string;
  timestampIso: string;
  eventType: LedgerEventType;
  actorId: string;
  payload: Record<string, unknown>;
  signature: string;
}

export interface ValidatorNode {
  validatorId: string;
  name: string;
  operatorEntity: string;
  jurisdiction: string;
  bondedStakeUsd: number;
  reputationScore: number; // 0-100
  expertise: ('COMPUTE_SYSTEMS' | 'INDUSTRIAL_EQUIPMENT' | 'SOFTWARE_LICENSING' | 'GENERAL_COMMODITY')[];
  status: 'ACTIVE' | 'SUSPENDED' | 'SLASHED';
  totalValidated: number;
  uptimePercent: number;
  accuracyRatePercent: number;
  slashedTotalUsd: number;
  declaredConflicts: string[]; // list of seller/bidder entity IDs validator cannot verify
  publicKeyFingerprint: string;
}

export interface ValidationAttestation {
  attestationId: string;
  auctionId: string;
  validatorId: string;
  ruleVersion: string;
  eventLogDigest: string; // root hash of replay log
  computedWinnerId: string | null;
  computedClearingPrice: number;
  feeCalculation: {
    buyerFee: number;
    sellerFee: number;
    validatorRewardPool: number;
    sellerNetProceeds: number;
  };
  reasonCodes: string[];
  signature: string;
  signedAtIso: string;
  verdict: 'CONFIRMED' | 'DISSENTING' | 'MALICIOUS_EQUIVOCATION';
}

export interface QuorumCertificate {
  certificateId: string;
  auctionId: string;
  eventLogDigest: string;
  ruleHash: string;
  totalCommitteeStakeUsd: number;
  supportingStakeUsd: number;
  quorumStakePercent: number;
  thresholdReached: boolean;
  winnerBidderId: string | null;
  clearingPrice: number;
  agreeingValidators: string[];
  dissentingValidators: {
    validatorId: string;
    dissentReason: string;
    claimedWinnerId: string | null;
    claimedPrice: number;
  }[];
  missingValidators: string[];
  timestampIso: string;
  qcDigest: string;
}

export type EscrowAccountType =
  | 'BIDDER_DEPOSIT_ACCOUNT'
  | 'BUYER_SETTLEMENT_HOLD'
  | 'SELLER_ESCROW_BOND'
  | 'VALIDATOR_BOND_RESERVE'
  | 'VALIDATOR_REWARD_POOL'
  | 'SLASHING_PENALTY_POOL'
  | 'PLATFORM_FEE_ACCOUNT';

export interface EscrowJournalEntry {
  entryId: string;
  auctionId: string;
  timestampIso: string;
  idempotencyKey: string;
  description: string;
  debitAccount: EscrowAccountType;
  creditAccount: EscrowAccountType;
  amount: number;
  currency: string;
  settled: boolean;
}

export interface AntiManipulationSignal {
  signalId: string;
  auctionId: string;
  type:
    | 'SELLER_BIDDER_AFFILIATION'
    | 'BIDDER_COLLUSION_CLUSTER'
    | 'REPEATED_NON_REVEAL_PATTERN'
    | 'SUSPICIOUS_BID_TIMING_SNIPING'
    | 'VALIDATOR_CONCENTRATION_RISK'
    | 'UNEXPLAINED_BID_SPREAD';
  severity: 'INFO' | 'WARNING' | 'ELEVATED' | 'HIGH';
  targetEntityId: string;
  description: string;
  evidence: Record<string, unknown>;
  disclaimer: string; // Explains that this is an investigative signal, not automated guilt
  investigationStatus: 'MONITORING' | 'ESCALATED' | 'DISMISSED' | 'CONFIRMED_FRAUD';
}

export interface ComputeWorkerTelemetry {
  workerId: string;
  signature: string;
  epochTimestampIso: string;
  gpuUtilizationPercent: number;
  vramAllocatedGb: number;
  measuredTflops: number;
  temperatureCelsius: number;
  infinibandThroughputGbps: number;
  jobId: string;
  uptimeVerifiedSeconds: number;
}

export interface AuctionItem {
  id: string;
  title: string;
  subtitle: string;
  category: AuctionCategory;
  sellerId: string;
  sellerName: string;
  sellerRating: number;
  description: string;
  status: AuctionStatus;
  currentHighBid?: number;
  winningBidderId?: string;
  winningPrice?: number;
  rules: AuctionRules;
  computeSpecs?: ComputeSpecifications;
  licenseSpecs?: LicenseSpecifications;
  equipmentSpecs?: {
    manufacturer: string;
    serialNumber: string;
    manufactureYear: number;
    inspectionCertificateDigest: string;
    shippingOrigin: string;
    transitWindowDays: number;
  };
  eventLog: LedgerEvent[];
  commitments: BidCommitment[];
  englishBids: EnglishBid[];
  committeeValidators: string[]; // IDs
  attestations: ValidationAttestation[];
  quorumCertificate?: QuorumCertificate;
  escrowEntries: EscrowJournalEntry[];
  signals: AntiManipulationSignal[];
  computeTelemetry?: ComputeWorkerTelemetry[];
  deliveryEvidence?: {
    submittedAtIso: string;
    evidenceType: 'SHIPPING_CARRIER_API' | 'SOFTWARE_LICENSE_KEY_DIGEST' | 'COMPUTE_SLURM_RUN_DIGEST';
    carrierOrVerifier: string;
    trackingOrTokenDigest: string;
    signedBySeller: string;
    inspectionWindowExpiryIso: string;
    buyerAccepted: boolean;
    buyerDisputeReason?: string;
  };
}
