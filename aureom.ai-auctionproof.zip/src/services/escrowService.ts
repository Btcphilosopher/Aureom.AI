/**
 * Aureom.AI AuctionProof - Double-Entry Escrow & Financial Ledger Service
 * Strictly balanced debits and credits, idempotent transaction keys,
 * deposit release, validator compensation, and slashing pools.
 */

import { EscrowAccountType, EscrowJournalEntry } from '../types/auction';

export interface EscrowAccountSummary {
  account: EscrowAccountType;
  balance: number;
  currency: string;
}

export interface TrialBalanceResult {
  isBalanced: boolean;
  totalDebits: number;
  totalCredits: number;
  delta: number;
  accountSummaries: EscrowAccountSummary[];
}

/**
 * Validates that every journal entry maintains double-entry equality and computes balances.
 */
export function computeTrialBalance(entries: EscrowJournalEntry[]): TrialBalanceResult {
  const debitTotals = new Map<EscrowAccountType, number>();
  const creditTotals = new Map<EscrowAccountType, number>();

  let totalDebits = 0;
  let totalCredits = 0;

  for (const entry of entries) {
    totalDebits += entry.amount;
    totalCredits += entry.amount;

    debitTotals.set(entry.debitAccount, (debitTotals.get(entry.debitAccount) || 0) + entry.amount);
    creditTotals.set(entry.creditAccount, (creditTotals.get(entry.creditAccount) || 0) + entry.amount);
  }

  const allAccounts: EscrowAccountType[] = [
    'BIDDER_DEPOSIT_ACCOUNT',
    'BUYER_SETTLEMENT_HOLD',
    'SELLER_ESCROW_BOND',
    'VALIDATOR_BOND_RESERVE',
    'VALIDATOR_REWARD_POOL',
    'SLASHING_PENALTY_POOL',
    'PLATFORM_FEE_ACCOUNT',
  ];

  const accountSummaries: EscrowAccountSummary[] = allAccounts.map(acc => {
    const debits = debitTotals.get(acc) || 0;
    const credits = creditTotals.get(acc) || 0;
    // Net balance = Credits - Debits (liability perspective for escrow)
    const balance = credits - debits;
    return {
      account: acc,
      balance,
      currency: 'USD',
    };
  });

  const delta = Math.abs(totalDebits - totalCredits);

  return {
    isBalanced: delta < 0.001,
    totalDebits,
    totalCredits,
    delta,
    accountSummaries,
  };
}

/**
 * Creates an idempotent journal entry.
 */
export function createJournalEntry(params: {
  auctionId: string;
  description: string;
  debitAccount: EscrowAccountType;
  creditAccount: EscrowAccountType;
  amount: number;
  idempotencyKey?: string;
}): EscrowJournalEntry {
  return {
    entryId: `JRN-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
    auctionId: params.auctionId,
    timestampIso: new Date().toISOString(),
    idempotencyKey:
      params.idempotencyKey ||
      `IDEMP-${params.auctionId}-${params.debitAccount}-${params.creditAccount}-${params.amount}`,
    description: params.description,
    debitAccount: params.debitAccount,
    creditAccount: params.creditAccount,
    amount: params.amount,
    currency: 'USD',
    settled: true,
  };
}
