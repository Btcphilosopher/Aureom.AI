/**
 * Aureom.AI AuctionProof - Anti-Manipulation Detection Engine
 * Heuristic monitoring for shill bidding, related bidder rings, non-reveal patterns,
 * validator concentration, and timing anomalies.
 * Note: These are investigative signals, not automatic proof of fraud.
 */

import { AntiManipulationSignal, AuctionItem, ValidatorNode } from '../types/auction';

export interface ParticipantRelationship {
  entityId: string;
  name: string;
  associatedEntities: { entityId: string; relationType: 'PARENT_COMPANY' | 'COMMON_DIRECTOR' | 'SHARED_IP_SUBNET' }[];
  historicalNonRevealCount: number;
  historicalTotalCommitments: number;
}

// Fictional participant corporate and network graph
export const KNOWN_PARTICIPANT_GRAPH: Record<string, ParticipantRelationship> = {
  'seller-1': {
    entityId: 'seller-1',
    name: 'Aureom Compute Infrastructure AG',
    associatedEntities: [
      { entityId: 'bidder-shadow', relationType: 'COMMON_DIRECTOR' },
      { entityId: 'bidder-5', relationType: 'SHARED_IP_SUBNET' },
    ],
    historicalNonRevealCount: 0,
    historicalTotalCommitments: 12,
  },
  'bidder-1': {
    entityId: 'bidder-1',
    name: 'DeepSynthetix AI Labs (San Francisco)',
    associatedEntities: [],
    historicalNonRevealCount: 0,
    historicalTotalCommitments: 45,
  },
  'bidder-2': {
    entityId: 'bidder-2',
    name: 'Neuromorphic Compute Fund (Zurich)',
    associatedEntities: [],
    historicalNonRevealCount: 1,
    historicalTotalCommitments: 28,
  },
  'bidder-3': {
    entityId: 'bidder-3',
    name: 'Cognitive Dynamics Ltd (London)',
    associatedEntities: [{ entityId: 'bidder-4', relationType: 'PARENT_COMPANY' }],
    historicalNonRevealCount: 0,
    historicalTotalCommitments: 19,
  },
  'bidder-4': {
    entityId: 'bidder-4',
    name: 'Cognitive Quant Partners (London)',
    associatedEntities: [{ entityId: 'bidder-3', relationType: 'PARENT_COMPANY' }],
    historicalNonRevealCount: 3,
    historicalTotalCommitments: 8,
  },
  'bidder-5': {
    entityId: 'bidder-5',
    name: 'Aura Cloud Ventures GmbH',
    associatedEntities: [{ entityId: 'seller-1', relationType: 'SHARED_IP_SUBNET' }],
    historicalNonRevealCount: 2,
    historicalTotalCommitments: 6,
  },
  'bidder-unrevealed': {
    entityId: 'bidder-unrevealed',
    name: 'Apex Strategic Reserves Corp',
    associatedEntities: [],
    historicalNonRevealCount: 4,
    historicalTotalCommitments: 5,
  },
};

/**
 * Runs anti-manipulation heuristics across an auction.
 */
export function runAntiManipulationAudit(
  auction: AuctionItem,
  validators: ValidatorNode[]
): AntiManipulationSignal[] {
  const signals: AntiManipulationSignal[] = [];

  // 1. Seller-Associated Bidding (Shill Bidding) Check
  const sellerMeta = KNOWN_PARTICIPANT_GRAPH[auction.sellerId];
  if (sellerMeta) {
    for (const assoc of sellerMeta.associatedEntities) {
      // Check if associated entity bid in this auction
      const matchedCommitment = auction.commitments.find(c => c.bidderId === assoc.entityId);
      const matchedEnglishBid = auction.englishBids.find(b => b.bidderId === assoc.entityId);

      if (matchedCommitment || matchedEnglishBid) {
        signals.push({
          signalId: `SIG-SHILL-${assoc.entityId}-${Date.now().toString().slice(-4)}`,
          auctionId: auction.id,
          type: 'SELLER_BIDDER_AFFILIATION',
          severity: 'HIGH',
          targetEntityId: assoc.entityId,
          description: `Bidder '${assoc.entityId}' shares known corporate/network relationship (${assoc.relationType}) with auction seller '${auction.sellerName}'. Potential shill bid to artificially inflate reserve or second price.`,
          evidence: {
            relationType: assoc.relationType,
            sellerId: auction.sellerId,
            bidderId: assoc.entityId,
            auctionMechanism: auction.rules.mechanism,
          },
          disclaimer:
            'Investigation signal only. Does not constitute automatic proof of fraud. Independent review required before disqualification.',
          investigationStatus: 'ESCALATED',
        });
      }
    }
  }

  // 2. Related Bidder Collusion Rings (Bid Pooling)
  for (const commit of auction.commitments) {
    const meta = KNOWN_PARTICIPANT_GRAPH[commit.bidderId];
    if (meta && meta.associatedEntities.length > 0) {
      for (const assoc of meta.associatedEntities) {
        const coBidder = auction.commitments.find(c => c.bidderId === assoc.entityId);
        if (coBidder && commit.bidderId < assoc.entityId) {
          // unique pair
          signals.push({
            signalId: `SIG-RING-${commit.bidderId}-${assoc.entityId}`,
            auctionId: auction.id,
            type: 'BIDDER_COLLUSION_CLUSTER',
            severity: 'ELEVATED',
            targetEntityId: `${commit.bidderId}+${assoc.entityId}`,
            description: `Bidders '${commit.bidderName}' and '${coBidder.bidderName}' share corporate ties (${assoc.relationType}). Participating together in sealed auctions may indicate bid rotation or price-suppression pooling.`,
            evidence: {
              bidderA: commit.bidderId,
              bidderB: assoc.entityId,
              relation: assoc.relationType,
            },
            disclaimer:
              'Joint bidding may occur for legitimate conglomerate allocations. Formal audit recommended before outcome certification.',
            investigationStatus: 'MONITORING',
          });
        }
      }
    }
  }

  // 3. Repeated Non-Reveal Pattern
  for (const commit of auction.commitments) {
    if (commit.status === 'NON_REVEALED') {
      const meta = KNOWN_PARTICIPANT_GRAPH[commit.bidderId];
      const nonRevealRate =
        meta && meta.historicalTotalCommitments > 0
          ? ((meta.historicalNonRevealCount + 1) / (meta.historicalTotalCommitments + 1)) * 100
          : 50;

      signals.push({
        signalId: `SIG-NONREVEAL-${commit.bidderId}`,
        auctionId: auction.id,
        type: 'REPEATED_NON_REVEAL_PATTERN',
        severity: nonRevealRate > 30 ? 'ELEVATED' : 'WARNING',
        targetEntityId: commit.bidderId,
        description: `Bidder '${commit.bidderName}' failed to reveal bid within the published reveal window. Historical non-reveal rate: ${nonRevealRate.toFixed(1)}%. Potential probing or option-holding strategy.`,
        evidence: {
          bidderId: commit.bidderId,
          historicalNonReveals: meta?.historicalNonRevealCount || 1,
          depositForfeited:
            commit.depositLockedAmount * (auction.rules.unrevealedPenaltyPercent / 100),
        },
        disclaimer:
          'May be due to network timeout or localized key loss. Statutory penalty applied automatically per auction rules.',
        investigationStatus: 'MONITORING',
      });
    }
  }

  // 4. Validator Operator Concentration Risk
  const committeeNodes = validators.filter(v => auction.committeeValidators.includes(v.validatorId));
  const operatorCounts = new Map<string, number>();
  for (const v of committeeNodes) {
    const c = operatorCounts.get(v.operatorEntity) || 0;
    operatorCounts.set(v.operatorEntity, c + 1);
  }

  for (const [operator, count] of operatorCounts.entries()) {
    if (count > 1) {
      signals.push({
        signalId: `SIG-VAL-CONC-${operator}`,
        auctionId: auction.id,
        type: 'VALIDATOR_CONCENTRATION_RISK',
        severity: 'WARNING',
        targetEntityId: operator,
        description: `Validator operator '${operator}' controls ${count} nodes in the 5-node validation committee (${((count / committeeNodes.length) * 100).toFixed(0)}% of committee seats). Violates recommended 1-node-per-operator concentration ceiling.`,
        evidence: {
          operatorEntity: operator,
          seatsHeld: count,
          committeeSize: committeeNodes.length,
        },
        disclaimer:
          'Operator concentration risk does not prove collusion, but degrades Sybil resistance. Rebalancing advised for subsequent epochs.',
        investigationStatus: 'MONITORING',
      });
    }
  }

  // 5. Anti-Sniping Window Extensions in English Auctions
  if (auction.rules.mechanism === 'ENGLISH') {
    const extensions = auction.englishBids.filter(b => b.extensionTriggered);
    if (extensions.length >= 3) {
      signals.push({
        signalId: `SIG-SNIPING-CLUSTER-${auction.id}`,
        auctionId: auction.id,
        type: 'SUSPICIOUS_BID_TIMING_SNIPING',
        severity: 'INFO',
        targetEntityId: auction.id,
        description: `High-frequency bid clustering triggered ${extensions.length} successive anti-sniping deadline extensions. Defensive anti-sniping extension protected participants from latency arbitrage.`,
        evidence: {
          extensionCount: extensions.length,
          lastExtensionBidder: extensions[extensions.length - 1].bidderName,
        },
        disclaimer: 'System operational metric: anti-sniping functioning as specified.',
        investigationStatus: 'DISMISSED',
      });
    }
  }

  return signals;
}

/**
 * Canonical limitations disclosure for cryptographic verification
 */
export const CRYPTOGRAPHIC_LIMITATIONS_DISCLOSURE = [
  'Off-platform agreements: Cryptographic validation proves recorded bids were submitted, but cannot detect off-chain side-payments or profit sharing.',
  'Bid rigging & buyer cartels: Independent replay validates mathematical execution; it cannot prove bidders did not secretly coordinate bid levels in advance.',
  'Physical asset quality & delivery: Validators confirm receipt tokens and digital carrier digests; they cannot verify physical machine tolerances or condition merely by validator consensus.',
  'Hardware performance attestation: Authenticated worker mTLS benchmarks verify GPU FLOPS during observation windows, but cannot rule out selective throttle or environmental variance afterwards.',
];
