/**
 * Aureom.AI AuctionProof - Deterministic Validation Engine
 * Independent replay of auction event logs, invariant verification,
 * winner/clearing-price calculation, and quorum certificate generation.
 */

import {
  AuctionItem,
  AuctionRules,
  LedgerEvent,
  QuorumCertificate,
  ValidationAttestation,
  ValidatorNode,
} from '../types/auction';
import {
  computeCommitmentHash,
  computeEventHash,
  computeEventLogDigest,
  generateActorSignature,
} from '../utils/crypto';

export interface ReplayInspectionCheck {
  step: string;
  passed: boolean;
  details: string;
}

export interface DeterministicEngineResult {
  auctionId: string;
  rulesVersion: string;
  eventLogDigest: string;
  totalEventsReplayed: number;
  winnerBidderId: string | null;
  winnerBidderName: string | null;
  clearingPrice: number;
  highBidAmount: number;
  secondHighestBidAmount: number;
  reserveMet: boolean;
  eligibleBidsCount: number;
  disqualifiedBidsCount: number;
  unrevealedBidsCount: number;
  tieOccurred: boolean;
  tieResolutionDetails?: string;
  feeCalculations: {
    buyerFee: number;
    sellerFee: number;
    validatorRewardPool: number;
    sellerNetProceeds: number;
    totalPayableByBuyer: number;
  };
  checks: ReplayInspectionCheck[];
  reasonCodes: string[];
}

/**
 * Replays an auction from its raw immutable event log and current state.
 * Any validator or independent auditor can run this function locally to reproduce the exact outcome.
 */
export async function replayAuctionLog(auction: AuctionItem): Promise<DeterministicEngineResult> {
  const checks: ReplayInspectionCheck[] = [];
  const reasonCodes: string[] = [];

  // Check 1: Chain Integrity
  let chainValid = true;
  for (let i = 0; i < auction.eventLog.length; i++) {
    const ev = auction.eventLog[i];
    const expectedPrev = i === 0 ? 'GENESIS_ROOT' : auction.eventLog[i - 1].hash;
    if (ev.prevHash !== expectedPrev) {
      chainValid = false;
      checks.push({
        step: `Event Log Hash Link #${ev.seqId}`,
        passed: false,
        details: `Broken prevHash link at seqId ${ev.seqId}. Expected ${expectedPrev.substring(0, 10)}..., got ${ev.prevHash.substring(0, 10)}...`,
      });
      break;
    }
  }
  if (chainValid) {
    checks.push({
      step: 'Event Log Hash-Chain Integrity',
      passed: true,
      details: `All ${auction.eventLog.length} sequential event records cryptographically chained.`,
    });
  }

  // Check 2: Rules Immutability
  const rules = auction.rules;
  checks.push({
    step: 'Auction Rules Immutability',
    passed: true,
    details: `Rules version ${rules.rulesVersion} with rule digest ${rules.rulesHash.substring(0, 12)}...`,
  });

  const eventLogDigest = await computeEventLogDigest(auction.eventLog);

  let winnerBidderId: string | null = null;
  let winnerBidderName: string | null = null;
  let clearingPrice = 0;
  let highBidAmount = 0;
  let secondHighestBidAmount = 0;
  let tieOccurred = false;
  let tieResolutionDetails = '';
  let eligibleBidsCount = 0;
  let disqualifiedBidsCount = 0;
  let unrevealedBidsCount = 0;

  if (rules.mechanism === 'ENGLISH') {
    // English auction: Ascending bids replay
    const validBids = auction.englishBids
      .filter(b => b.status === 'ACCEPTED')
      .sort((a, b) => b.amount - a.amount || a.receiptSequenceId - b.receiptSequenceId);

    eligibleBidsCount = validBids.length;
    disqualifiedBidsCount = auction.englishBids.length - validBids.length;

    if (validBids.length > 0) {
      const topBid = validBids[0];
      highBidAmount = topBid.amount;

      if (topBid.amount >= rules.reservePrice) {
        winnerBidderId = topBid.bidderId;
        winnerBidderName = topBid.bidderName;
        clearingPrice = topBid.amount;
        reasonCodes.push('ENGLISH_TOP_BID_REACHED_RESERVE');
      } else {
        reasonCodes.push('RESERVE_PRICE_NOT_MET');
      }
    } else {
      reasonCodes.push('NO_VALID_BIDS_SUBMITTED');
    }
  } else {
    // Sealed Bid Mechanisms (FIRST_PRICE_SEALED or SECOND_PRICE_SEALED)
    // 1. Verify commit-reveal integrity for each commitment
    interface ValidatedSealedBid {
      bidderId: string;
      bidderName: string;
      amount: number;
      receiptSequenceId: number;
      commitmentHash: string;
      revealedAtIso: string;
      depositLocked: number;
    }

    const verifiedBids: ValidatedSealedBid[] = [];

    for (const commit of auction.commitments) {
      if (commit.status === 'NON_REVEALED') {
        unrevealedBidsCount++;
        reasonCodes.push(`UNREVEALED_COMMITMENT_${commit.bidderId}`);
        continue;
      }

      if (commit.status === 'DISQUALIFIED') {
        disqualifiedBidsCount++;
        continue;
      }

      if (commit.status === 'REVEALED' && commit.revealedPayload) {
        // Verify hash reconstruction
        const expectedHash = await computeCommitmentHash({
          auctionId: auction.id,
          bidderId: commit.bidderId,
          amount: commit.revealedPayload.amount,
          currency: commit.revealedPayload.currency,
          conditionsDigest: commit.revealedPayload.conditionsDigest,
          nonce: commit.revealedPayload.secretNonce,
        });

        if (expectedHash.toLowerCase() === commit.commitmentHash.toLowerCase()) {
          // Verify deposit requirement
          if (commit.depositLockedAmount >= rules.depositRequiredAmount) {
            verifiedBids.push({
              bidderId: commit.bidderId,
              bidderName: commit.bidderName,
              amount: commit.revealedPayload.amount,
              receiptSequenceId: commit.receiptSequenceId,
              commitmentHash: commit.commitmentHash,
              revealedAtIso: commit.revealedPayload.revealedAtIso,
              depositLocked: commit.depositLockedAmount,
            });
          } else {
            disqualifiedBidsCount++;
            reasonCodes.push(`INSUFFICIENT_DEPOSIT_${commit.bidderId}`);
          }
        } else {
          disqualifiedBidsCount++;
          reasonCodes.push(`HASH_MISMATCH_REVEAL_TAMPER_${commit.bidderId}`);
        }
      }
    }

    eligibleBidsCount = verifiedBids.length;

    // Filter against reserve price
    const reserveEligibleBids = verifiedBids.filter(b => b.amount >= rules.reservePrice);

    if (reserveEligibleBids.length === 0) {
      reasonCodes.push('NO_REVEALED_BIDS_MET_RESERVE');
    } else {
      // Sort bids according to tie-breaking policy
      reserveEligibleBids.sort((a, b) => {
        if (b.amount !== a.amount) {
          return b.amount - a.amount; // highest bid first
        }
        // Tie detected
        tieOccurred = true;
        if (rules.tieBreakingPolicy === 'EARLIEST_RECEIPT') {
          return a.receiptSequenceId - b.receiptSequenceId;
        } else {
          return a.commitmentHash.localeCompare(b.commitmentHash);
        }
      });

      const topBid = reserveEligibleBids[0];
      highBidAmount = topBid.amount;
      winnerBidderId = topBid.bidderId;
      winnerBidderName = topBid.bidderName;

      if (tieOccurred) {
        tieResolutionDetails = `Tie-break applied using ${rules.tieBreakingPolicy}. Winner ${topBid.bidderName} prioritized over equal bids.`;
        reasonCodes.push(`TIE_BROKEN_${rules.tieBreakingPolicy}`);
      }

      if (rules.mechanism === 'FIRST_PRICE_SEALED') {
        clearingPrice = topBid.amount;
        reasonCodes.push('FIRST_PRICE_SEALED_WINNER_PAYS_BID');
      } else if (rules.mechanism === 'SECOND_PRICE_SEALED') {
        if (reserveEligibleBids.length > 1) {
          secondHighestBidAmount = reserveEligibleBids[1].amount;
          // Vickrey second price rule: max(reservePrice, secondHighestBid)
          clearingPrice = Math.max(rules.reservePrice, secondHighestBidAmount);
          reasonCodes.push('SECOND_PRICE_SEALED_WINNER_PAYS_SECOND_PRICE');
        } else {
          // If only 1 bid met reserve, winner pays reserve price
          secondHighestBidAmount = rules.reservePrice;
          clearingPrice = rules.reservePrice;
          reasonCodes.push('SECOND_PRICE_SEALED_SINGLE_BID_PAYS_RESERVE');
        }
      }
    }
  }

  // Fees calculation
  const buyerFee = winnerBidderId ? Math.round(clearingPrice * (rules.buyerFeePercent / 100)) : 0;
  const sellerFee = winnerBidderId ? Math.round(clearingPrice * (rules.sellerFeePercent / 100)) : 0;
  const validatorRewardPool = rules.validatorFeeReward;
  const sellerNetProceeds = winnerBidderId ? clearingPrice - sellerFee : 0;
  const totalPayableByBuyer = winnerBidderId ? clearingPrice + buyerFee : 0;

  checks.push({
    step: 'Reserve Price Invariant',
    passed: winnerBidderId !== null ? clearingPrice >= rules.reservePrice : true,
    details: winnerBidderId
      ? `Clearing price $${clearingPrice.toLocaleString()} satisfies minimum reserve $${rules.reservePrice.toLocaleString()}.`
      : `No winner awarded; reserve was $${rules.reservePrice.toLocaleString()}.`,
  });

  checks.push({
    step: 'Stake-Independent Outcome Ranking',
    passed: true,
    details: 'Outcome calculated strictly from canonical event log bids; validator stake weights had zero influence on bid ranking.',
  });

  return {
    auctionId: auction.id,
    rulesVersion: rules.rulesVersion,
    eventLogDigest,
    totalEventsReplayed: auction.eventLog.length,
    winnerBidderId,
    winnerBidderName,
    clearingPrice,
    highBidAmount,
    secondHighestBidAmount,
    reserveMet: winnerBidderId !== null,
    eligibleBidsCount,
    disqualifiedBidsCount,
    unrevealedBidsCount,
    tieOccurred,
    tieResolutionDetails,
    feeCalculations: {
      buyerFee,
      sellerFee,
      validatorRewardPool,
      sellerNetProceeds,
      totalPayableByBuyer,
    },
    checks,
    reasonCodes,
  };
}

/**
 * Generates an attestation from a validator node after running independent replay.
 */
export async function generateValidatorAttestation(
  validator: ValidatorNode,
  auction: AuctionItem,
  verdictOverride?: 'CONFIRMED' | 'DISSENTING' | 'MALICIOUS_EQUIVOCATION',
  maliciousWinnerId?: string,
  maliciousPrice?: number
): Promise<ValidationAttestation> {
  const result = await replayAuctionLog(auction);
  const verdict = verdictOverride || 'CONFIRMED';

  const winner = verdict === 'MALICIOUS_EQUIVOCATION' && maliciousWinnerId ? maliciousWinnerId : result.winnerBidderId;
  const price = verdict === 'MALICIOUS_EQUIVOCATION' && maliciousPrice ? maliciousPrice : result.clearingPrice;

  const payloadToSign = `${auction.id}|${validator.validatorId}|${result.eventLogDigest}|${winner}|${price}|${verdict}`;
  const signature = await generateActorSignature(validator.validatorId, payloadToSign);

  return {
    attestationId: `ATT-${validator.validatorId}-${Date.now().toString().slice(-6)}`,
    auctionId: auction.id,
    validatorId: validator.validatorId,
    ruleVersion: auction.rules.rulesVersion,
    eventLogDigest: result.eventLogDigest,
    computedWinnerId: winner,
    computedClearingPrice: price,
    feeCalculation: {
      buyerFee: result.feeCalculations.buyerFee,
      sellerFee: result.feeCalculations.sellerFee,
      validatorRewardPool: auction.rules.validatorFeeReward,
      sellerNetProceeds: result.feeCalculations.sellerNetProceeds,
    },
    reasonCodes:
      verdict === 'MALICIOUS_EQUIVOCATION'
        ? ['MALICIOUS_FORGED_RESULT_ATTEMPT', 'UNAUTHORIZED_PRICE_DIVERGENCE']
        : verdict === 'DISSENTING'
          ? ['DISSENT_DISPUTED_INTERPRETATION']
          : result.reasonCodes,
    signature,
    signedAtIso: new Date().toISOString(),
    verdict,
  };
}

/**
 * Computes Quorum Certificate from all committee validator attestations.
 * Explicitly preserves dissent, detects signed equivocation, and verifies threshold.
 */
export function buildQuorumCertificate(
  auction: AuctionItem,
  committeeValidators: ValidatorNode[],
  attestations: ValidationAttestation[]
): {
  quorumCertificate: QuorumCertificate;
  equivocations: { validatorId: string; signatures: string[]; conflictingPrices: number[] }[];
} {
  const totalStake = committeeValidators.reduce((sum, v) => sum + v.bondedStakeUsd, 0);

  // Group attestations by validator
  const byValidator = new Map<string, ValidationAttestation[]>();
  for (const att of attestations) {
    const list = byValidator.get(att.validatorId) || [];
    list.push(att);
    byValidator.set(att.validatorId, list);
  }

  // Detect Equivocation (validator signed multiple conflicting attestations)
  const equivocations: { validatorId: string; signatures: string[]; conflictingPrices: number[] }[] = [];
  for (const [vId, atts] of byValidator.entries()) {
    if (atts.length > 1) {
      const distinctPrices = Array.from(new Set(atts.map(a => a.computedClearingPrice)));
      const distinctWinners = Array.from(new Set(atts.map(a => a.computedWinnerId)));
      if (distinctPrices.length > 1 || distinctWinners.length > 1) {
        equivocations.push({
          validatorId: vId,
          signatures: atts.map(a => a.signature),
          conflictingPrices: distinctPrices,
        });
      }
    }
  }

  // Find majority outcome (winnerId + price)
  interface OutcomeCandidate {
    winnerId: string | null;
    price: number;
    agreeingValidatorIds: string[];
    supportingStake: number;
  }

  const outcomes = new Map<string, OutcomeCandidate>();

  for (const att of attestations) {
    if (att.verdict === 'MALICIOUS_EQUIVOCATION') continue; // exclude known equivocations from honest tally
    const key = `${att.computedWinnerId}_${att.computedClearingPrice}`;
    const vNode = committeeValidators.find(v => v.validatorId === att.validatorId);
    const stake = vNode ? vNode.bondedStakeUsd : 0;

    const existing = outcomes.get(key) || {
      winnerId: att.computedWinnerId,
      price: att.computedClearingPrice,
      agreeingValidatorIds: [],
      supportingStake: 0,
    };

    if (!existing.agreeingValidatorIds.includes(att.validatorId)) {
      existing.agreeingValidatorIds.push(att.validatorId);
      existing.supportingStake += stake;
    }
    outcomes.set(key, existing);
  }

  // Pick candidate with largest stake weight
  let bestCandidate: OutcomeCandidate = {
    winnerId: null,
    price: 0,
    agreeingValidatorIds: [],
    supportingStake: 0,
  };

  for (const candidate of outcomes.values()) {
    if (candidate.supportingStake > bestCandidate.supportingStake) {
      bestCandidate = candidate;
    }
  }

  const quorumStakePercent = totalStake > 0 ? (bestCandidate.supportingStake / totalStake) * 100 : 0;
  const thresholdReached = quorumStakePercent >= auction.rules.quorumThresholdPercent;

  // Dissenting validators (those who voted for a different outcome)
  const dissentingValidators: QuorumCertificate['dissentingValidators'] = [];
  for (const att of attestations) {
    if (
      !bestCandidate.agreeingValidatorIds.includes(att.validatorId) &&
      !dissentingValidators.some(d => d.validatorId === att.validatorId)
    ) {
      dissentingValidators.push({
        validatorId: att.validatorId,
        dissentReason: att.reasonCodes.join(', ') || 'Alternative price/winner computed',
        claimedWinnerId: att.computedWinnerId,
        claimedPrice: att.computedClearingPrice,
      });
    }
  }

  // Missing validators
  const respondedIds = Array.from(byValidator.keys());
  const missingValidators = committeeValidators
    .filter(v => !respondedIds.includes(v.validatorId))
    .map(v => v.validatorId);

  const qcDigest = `QC_${auction.id}_${bestCandidate.supportingStake}_${bestCandidate.price}`;

  const quorumCertificate: QuorumCertificate = {
    certificateId: `QC-${auction.id.slice(-6)}-${Date.now().toString().slice(-4)}`,
    auctionId: auction.id,
    eventLogDigest: attestations[0]?.eventLogDigest || '0'.repeat(64),
    ruleHash: auction.rules.rulesHash,
    totalCommitteeStakeUsd: totalStake,
    supportingStakeUsd: bestCandidate.supportingStake,
    quorumStakePercent: Math.round(quorumStakePercent * 10) / 10,
    thresholdReached,
    winnerBidderId: bestCandidate.winnerId,
    clearingPrice: bestCandidate.price,
    agreeingValidators: bestCandidate.agreeingValidatorIds,
    dissentingValidators,
    missingValidators,
    timestampIso: new Date().toISOString(),
    qcDigest,
  };

  return { quorumCertificate, equivocations };
}
