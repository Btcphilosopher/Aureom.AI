/**
 * Aureom.AI AuctionProof - Central State & Verification Context
 * State management for auctions, validators, double-entry escrow,
 * deterministic replay, and the 10-step guided demonstration.
 */

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AntiManipulationSignal,
  AuctionItem,
  AuctionMechanism,
  AuctionRules,
  BidCommitment,
  EnglishBid,
  EscrowJournalEntry,
  LedgerEvent,
  QuorumCertificate,
  ValidationAttestation,
  ValidatorNode,
} from '../types/auction';
import {
  DeterministicEngineResult,
  buildQuorumCertificate,
  generateValidatorAttestation,
  replayAuctionLog,
} from '../services/auctionEngine';
import { runAntiManipulationAudit } from '../services/antiManipulation';
import { createJournalEntry } from '../services/escrowService';
import { INITIAL_AUCTIONS, INITIAL_VALIDATORS } from '../services/mockData';
import {
  computeCommitmentHash,
  computeEventHash,
  generateActorSignature,
  generateSecureNonce,
  sha256Hex,
} from '../utils/crypto';

export type UserRole =
  | 'BUYER'
  | 'SELLER'
  | 'VALIDATOR'
  | 'SETTLEMENT'
  | 'DISPUTES'
  | 'AUDITOR'
  | 'DEMO'
  | 'SIMULATION';

export interface DemoStepInfo {
  step: number;
  title: string;
  description: string;
  actionLabel: string;
  auctionId: string;
}

export const DEMO_STEPS: DemoStepInfo[] = [
  {
    step: 1,
    title: 'Publish Auction with Immutably Hashed Rules',
    description: 'Publish a new semiconductor inspection station auction. Canonical JSON hashing anchors the rules, reserves, fees, and committee parameters.',
    actionLabel: 'Publish Auction Rules',
    auctionId: 'auc-laser-wafer-secondprice',
  },
  {
    step: 2,
    title: 'Register Eligible Bidders & Whitelist Credentials',
    description: 'Bind verifiable bidder identity credentials and eligibility tier before allowing bid commitments.',
    actionLabel: 'Whitelist Bidders',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 3,
    title: 'Post Escrow Deposits to Segregated Double-Entry Account',
    description: 'Transfer required $10,000 security deposits into the segregated BIDDER_DEPOSIT_ACCOUNT prior to submitting commitments.',
    actionLabel: 'Deposit Escrow Funds',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 4,
    title: 'Submit Sealed Cryptographic Commitments',
    description: 'Generate domain-separated SHA-256 commitments using 256-bit cryptographically random nonces. Zero plaintext amounts exposed.',
    actionLabel: 'Submit Commitments',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 5,
    title: 'Reveal Sealed Bids Within Published Time Window',
    description: 'Bidders submit plaintext bid amount + secret nonce. Server verifies reconstructed hash against the locked commitment receipt.',
    actionLabel: 'Reveal Valid Bids',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 6,
    title: 'Enforce Non-Reveal Window Closure & Statutory Penalty',
    description: 'The reveal window closes. Bidder Apex failed to reveal. The engine enforces an automatic 20% deposit forfeiture ($2,000) to the slashing pool.',
    actionLabel: 'Close Window & Penalize Non-Reveal',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 7,
    title: 'Execute Independent Deterministic Event-Log Replay',
    description: 'Replay the immutable event log from genesis. Verify signatures, deadlines, deposits, reserve rules, and Vickrey second-price formula.',
    actionLabel: 'Run Deterministic Replay',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 8,
    title: 'Detect Conflicting Validator Results & Signed Equivocation',
    description: 'Simulate a rogue validator submitting two contradictory signed attestations. The consensus engine detects equivocation and triggers slashing.',
    actionLabel: 'Simulate Equivocation Attack & Slash',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 9,
    title: 'Issue Quorum Certificate & Complete Escrow Settlement',
    description: 'Issue cryptographic Quorum Certificate preserving minority dissent. Execute balanced double-entry settlement for winner, fees, and seller payout.',
    actionLabel: 'Issue QC & Settle Escrow',
    auctionId: 'auc-compute-h100-vickrey',
  },
  {
    step: 10,
    title: 'File & Adjudicate Delivery Dispute with Escrow Freeze',
    description: 'Inspect the AeroNav software license delivery dispute. Review license IP rights terms, arbitrator voting, and escrow release/refund.',
    actionLabel: 'Adjudicate Delivery Appeal',
    auctionId: 'auc-autonav-license-firstprice',
  },
];

interface AuctionContextType {
  auctions: AuctionItem[];
  validators: ValidatorNode[];
  activeAuctionId: string;
  activeAuction: AuctionItem;
  currentRole: UserRole;
  activeDemoStep: number;
  demoLogs: string[];
  lastReplayResult: DeterministicEngineResult | null;
  setCurrentRole: (role: UserRole) => void;
  setActiveAuctionId: (id: string) => void;
  setActiveDemoStep: (step: number) => void;
  placeEnglishBid: (auctionId: string, bidderId: string, bidderName: string, amount: number) => Promise<boolean>;
  submitSealedCommitment: (
    auctionId: string,
    bidderId: string,
    bidderName: string,
    amount: number,
    currency: string,
    conditionsDigest: string,
    nonce: string
  ) => Promise<{ commitmentHash: string; canonicalString: string }>;
  revealSealedBid: (
    auctionId: string,
    bidderId: string,
    amount: number,
    currency: string,
    conditionsDigest: string,
    nonce: string
  ) => Promise<{ success: boolean; message: string }>;
  runReplayForActiveAuction: () => Promise<DeterministicEngineResult>;
  submitAttestation: (
    auctionId: string,
    validatorId: string,
    verdict?: 'CONFIRMED' | 'DISSENTING' | 'MALICIOUS_EQUIVOCATION',
    maliciousWinnerId?: string,
    maliciousPrice?: number
  ) => Promise<ValidationAttestation>;
  certifyQuorum: (auctionId: string) => Promise<QuorumCertificate>;
  executeEscrowSettlement: (auctionId: string) => Promise<boolean>;
  submitDeliveryEvidence: (
    auctionId: string,
    evidenceType: 'SHIPPING_CARRIER_API' | 'SOFTWARE_LICENSE_KEY_DIGEST' | 'COMPUTE_SLURM_RUN_DIGEST',
    carrierOrVerifier: string,
    trackingOrTokenDigest: string
  ) => Promise<boolean>;
  fileDispute: (auctionId: string, reason: string) => Promise<boolean>;
  resolveDispute: (auctionId: string, verdict: 'REFUND_BUYER' | 'RELEASE_TO_SELLER') => Promise<boolean>;
  executeDemoStep: (stepNumber: number) => Promise<void>;
  resetToInitialState: () => void;
}

const AuctionContext = createContext<AuctionContextType | null>(null);

export const AuctionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [auctions, setAuctions] = useState<AuctionItem[]>(INITIAL_AUCTIONS);
  const [validators, setValidators] = useState<ValidatorNode[]>(INITIAL_VALIDATORS);
  const [activeAuctionId, setActiveAuctionId] = useState<string>('auc-compute-h100-vickrey');
  const [currentRole, setCurrentRole] = useState<UserRole>('DEMO');
  const [activeDemoStep, setActiveDemoStep] = useState<number>(1);
  const [demoLogs, setDemoLogs] = useState<string[]>([
    'System initialized. Append-only ledger loaded with 4 multi-domain auctions and 8 bonded validator nodes.',
  ]);
  const [lastReplayResult, setLastReplayResult] = useState<DeterministicEngineResult | null>(null);

  const activeAuction =
    auctions.find(a => a.id === activeAuctionId) || auctions[0] || INITIAL_AUCTIONS[0];

  const appendDemoLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setDemoLogs(prev => [`[${time}] ${msg}`, ...prev.slice(0, 49)]);
  };

  // Re-run anti-manipulation signals when active auction updates
  useEffect(() => {
    if (activeAuction) {
      const signals = runAntiManipulationAudit(activeAuction, validators);
      setAuctions(prev =>
        prev.map(a => (a.id === activeAuction.id ? { ...a, signals } : a))
      );
    }
  }, [activeAuctionId]);

  const placeEnglishBid = async (
    auctionId: string,
    bidderId: string,
    bidderName: string,
    amount: number
  ): Promise<boolean> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) return false;

    const currentHigh = target.currentHighBid || target.rules.reservePrice;
    if (amount < currentHigh + target.rules.minBidIncrement) {
      appendDemoLog(`Bid rejected: $${amount.toLocaleString()} is below minimum increment requirement ($${(currentHigh + target.rules.minBidIncrement).toLocaleString()}).`);
      return false;
    }

    const receiptSeq = (target.englishBids.length || 0) + 1;
    const nowIso = new Date().toISOString();

    // Check anti-sniping extension
    const extensionTriggered = target.rules.antiSnipingWindowSeconds > 0;
    const newDeadlineIso = extensionTriggered
      ? new Date(Date.now() + target.rules.antiSnipingExtensionSeconds * 1000).toISOString()
      : undefined;

    const newBid: EnglishBid = {
      bidId: `BID-ENG-${Date.now().toString().slice(-5)}`,
      auctionId,
      bidderId,
      bidderName,
      amount,
      receiptSequenceId: receiptSeq,
      serverReceivedIso: nowIso,
      clientTimestampIso: nowIso,
      extensionTriggered,
      newDeadlineIso,
      status: 'ACCEPTED',
    };

    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'BID_RECORDED',
      actorId: bidderId,
      payload: { amount, receiptSequenceId: receiptSeq, extensionTriggered },
    });

    const newEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'BID_RECORDED',
      actorId: bidderId,
      payload: { amount, receiptSequenceId: receiptSeq, extensionTriggered },
      signature: await generateActorSignature(bidderId, evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            currentHighBid: amount,
            englishBids: [newBid, ...a.englishBids],
            eventLog: [...a.eventLog, newEvent],
          };
        }
        return a;
      })
    );

    appendDemoLog(`English Bid accepted: $${amount.toLocaleString()} from ${bidderName}. (Receipt #${receiptSeq}${extensionTriggered ? ' · Anti-Sniping Extension Triggered' : ''})`);
    return true;
  };

  const submitSealedCommitment = async (
    auctionId: string,
    bidderId: string,
    bidderName: string,
    amount: number,
    currency: string,
    conditionsDigest: string,
    nonce: string
  ): Promise<{ commitmentHash: string; canonicalString: string }> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) throw new Error('Auction not found');

    const commitmentHash = await computeCommitmentHash({
      auctionId,
      bidderId,
      amount,
      currency,
      conditionsDigest,
      nonce,
    });

    const receiptSeq = 100 + target.commitments.length + 1;
    const nowIso = new Date().toISOString();

    const commitment: BidCommitment = {
      commitmentHash,
      auctionId,
      bidderId,
      bidderName,
      receiptSequenceId: receiptSeq,
      serverReceivedIso: nowIso,
      clientTimestampIso: nowIso,
      depositLockedAmount: target.rules.depositRequiredAmount,
      status: 'COMMITTED',
    };

    // Ledger event
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'COMMITMENT_RECORDED',
      actorId: bidderId,
      payload: { commitmentHash, receiptSequenceId: receiptSeq, deposit: target.rules.depositRequiredAmount },
    });

    const newEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'COMMITMENT_RECORDED',
      actorId: bidderId,
      payload: { commitmentHash, receiptSequenceId: receiptSeq, deposit: target.rules.depositRequiredAmount },
      signature: await generateActorSignature(bidderId, evHash),
    };

    // Escrow entry
    const escrowEntry = createJournalEntry({
      auctionId,
      description: `Bidder deposit collateral escrowed for ${bidderName}`,
      debitAccount: 'PLATFORM_FEE_ACCOUNT',
      creditAccount: 'BIDDER_DEPOSIT_ACCOUNT',
      amount: target.rules.depositRequiredAmount,
      idempotencyKey: `DEP-${bidderId}-${receiptSeq}`,
    });

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            commitments: [...a.commitments, commitment],
            eventLog: [...a.eventLog, newEvent],
            escrowEntries: [...a.escrowEntries, escrowEntry],
          };
        }
        return a;
      })
    );

    appendDemoLog(`Sealed Commitment recorded: Hash ${commitmentHash.slice(0, 16)}... for ${bidderName}. $${target.rules.depositRequiredAmount.toLocaleString()} deposited in escrow.`);

    return {
      commitmentHash,
      canonicalString: `AUCTIONPROOF_COMMIT_V1:${auctionId}:${bidderId}:${amount.toFixed(2)}:${currency}:${conditionsDigest}:${nonce}`,
    };
  };

  const revealSealedBid = async (
    auctionId: string,
    bidderId: string,
    amount: number,
    currency: string,
    conditionsDigest: string,
    nonce: string
  ): Promise<{ success: boolean; message: string }> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) return { success: false, message: 'Auction not found' };

    const commitment = target.commitments.find(c => c.bidderId === bidderId);
    if (!commitment) return { success: false, message: 'No commitment found for this bidder' };

    const computedHash = await computeCommitmentHash({
      auctionId,
      bidderId,
      amount,
      currency,
      conditionsDigest,
      nonce,
    });

    if (computedHash.toLowerCase() !== commitment.commitmentHash.toLowerCase()) {
      return {
        success: false,
        message: `Hash mismatch! Reconstructed hash ${computedHash.slice(0, 16)}... does not match commitment ${commitment.commitmentHash.slice(0, 16)}...`,
      };
    }

    const nowIso = new Date().toISOString();
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';

    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'REVEAL_RECORDED',
      actorId: bidderId,
      payload: { amount, conditionsDigest },
    });

    const newEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'REVEAL_RECORDED',
      actorId: bidderId,
      payload: { amount, conditionsDigest },
      signature: await generateActorSignature(bidderId, evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          const updatedCommits = a.commitments.map(c => {
            if (c.bidderId === bidderId) {
              return {
                ...c,
                status: 'REVEALED' as const,
                revealedPayload: {
                  amount,
                  currency,
                  conditionsDigest,
                  secretNonce: nonce,
                  revealedAtIso: nowIso,
                  rawCanonicalString: `AUCTIONPROOF_COMMIT_V1:${auctionId}:${bidderId}:${amount.toFixed(2)}:${currency}:${conditionsDigest}:${nonce}`,
                },
              };
            }
            return c;
          });
          return {
            ...a,
            commitments: updatedCommits,
            eventLog: [...a.eventLog, newEvent],
          };
        }
        return a;
      })
    );

    appendDemoLog(`Bid revealed & verified: Bidder ${bidderId} successfully revealed $${amount.toLocaleString()} with matching SHA-256 digest.`);
    return { success: true, message: 'Bid successfully verified and recorded in event log.' };
  };

  const runReplayForActiveAuction = async (): Promise<DeterministicEngineResult> => {
    const res = await replayAuctionLog(activeAuction);
    setLastReplayResult(res);
    appendDemoLog(`Deterministic replay completed for ${activeAuction.title}. Outcome: Winner ${res.winnerBidderName || 'None'}, Clearing Price: $${res.clearingPrice.toLocaleString()}`);
    return res;
  };

  const submitAttestation = async (
    auctionId: string,
    validatorId: string,
    verdict?: 'CONFIRMED' | 'DISSENTING' | 'MALICIOUS_EQUIVOCATION',
    maliciousWinnerId?: string,
    maliciousPrice?: number
  ): Promise<ValidationAttestation> => {
    const target = auctions.find(a => a.id === auctionId);
    const validator = validators.find(v => v.validatorId === validatorId);
    if (!target || !validator) throw new Error('Auction or Validator not found');

    const attestation = await generateValidatorAttestation(
      validator,
      target,
      verdict,
      maliciousWinnerId,
      maliciousPrice
    );

    // Ledger event for attestation
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const nowIso = new Date().toISOString();

    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType:
        verdict === 'MALICIOUS_EQUIVOCATION' ? 'EQUIVOCATION_DETECTED' : 'ATTESTATION_SUBMITTED',
      actorId: validatorId,
      payload: {
        attestationId: attestation.attestationId,
        computedPrice: attestation.computedClearingPrice,
        verdict: attestation.verdict,
      },
    });

    const newEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType:
        verdict === 'MALICIOUS_EQUIVOCATION' ? 'EQUIVOCATION_DETECTED' : 'ATTESTATION_SUBMITTED',
      actorId: validatorId,
      payload: {
        attestationId: attestation.attestationId,
        computedPrice: attestation.computedClearingPrice,
        verdict: attestation.verdict,
      },
      signature: attestation.signature,
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            attestations: [...a.attestations, attestation],
            eventLog: [...a.eventLog, newEvent],
          };
        }
        return a;
      })
    );

    if (verdict === 'MALICIOUS_EQUIVOCATION') {
      appendDemoLog(`ALERT: Validator ${validator.name} signed an equivocating/conflicting attestation! (Claimed price $${maliciousPrice?.toLocaleString()}). Flagged for slashing.`);
    } else {
      appendDemoLog(`Validator attestation signed by ${validator.name} (${verdict || 'CONFIRMED'}). Event digest: ${attestation.eventLogDigest.slice(0, 16)}...`);
    }

    return attestation;
  };

  const certifyQuorum = async (auctionId: string): Promise<QuorumCertificate> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) throw new Error('Auction not found');

    const committeeNodes = validators.filter(v => target.committeeValidators.includes(v.validatorId));
    const { quorumCertificate, equivocations } = buildQuorumCertificate(
      target,
      committeeNodes,
      target.attestations
    );

    const nowIso = new Date().toISOString();
    let newEvents: LedgerEvent[] = [];

    // Slashing if equivocation caught
    if (equivocations.length > 0) {
      for (const eq of equivocations) {
        const valNode = validators.find(v => v.validatorId === eq.validatorId);
        const slashAmount = 50000;
        appendDemoLog(`SLASHING ENFORCED: Validator ${valNode?.name || eq.validatorId} penalized $${slashAmount.toLocaleString()} for signed equivocation.`);

        // Update validator state
        setValidators(prev =>
          prev.map(v =>
            v.validatorId === eq.validatorId
              ? {
                  ...v,
                  status: 'SLASHED',
                  slashedTotalUsd: v.slashedTotalUsd + slashAmount,
                  reputationScore: Math.max(10, v.reputationScore - 30),
                }
              : v
          )
        );
      }
    }

    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'QUORUM_CERTIFICATE_ISSUED',
      actorId: 'consensus_engine',
      payload: {
        certificateId: quorumCertificate.certificateId,
        thresholdReached: quorumCertificate.thresholdReached,
        winner: quorumCertificate.winnerBidderId,
        price: quorumCertificate.clearingPrice,
      },
    });

    const qcEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'QUORUM_CERTIFICATE_ISSUED',
      actorId: 'consensus_engine',
      payload: {
        certificateId: quorumCertificate.certificateId,
        thresholdReached: quorumCertificate.thresholdReached,
        winner: quorumCertificate.winnerBidderId,
        price: quorumCertificate.clearingPrice,
      },
      signature: await generateActorSignature('consensus_engine', evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            status: quorumCertificate.thresholdReached ? 'AWARDED' : 'VALIDATING',
            winningBidderId: quorumCertificate.winnerBidderId || undefined,
            winningPrice: quorumCertificate.clearingPrice,
            quorumCertificate,
            eventLog: [...a.eventLog, qcEvent],
          };
        }
        return a;
      })
    );

    appendDemoLog(`Quorum Certificate issued for ${target.title}: ${quorumCertificate.quorumStakePercent}% supporting stake (${quorumCertificate.thresholdReached ? 'THRESHOLD MET' : 'THRESHOLD MISSED'}). Winner: ${quorumCertificate.winnerBidderId || 'None'}`);
    return quorumCertificate;
  };

  const executeEscrowSettlement = async (auctionId: string): Promise<boolean> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target || !target.winningPrice || !target.winningBidderId) return false;

    const winnerId = target.winningBidderId;
    const price = target.winningPrice;
    const buyerFee = Math.round(price * (target.rules.buyerFeePercent / 100));
    const sellerFee = Math.round(price * (target.rules.sellerFeePercent / 100));
    const validatorFee = target.rules.validatorFeeReward;
    const sellerNet = price - sellerFee;

    const nowIso = new Date().toISOString();

    const j1 = createJournalEntry({
      auctionId,
      description: `Buyer Settlement Payment Escrowed (Winner ${winnerId})`,
      debitAccount: 'PLATFORM_FEE_ACCOUNT',
      creditAccount: 'BUYER_SETTLEMENT_HOLD',
      amount: price + buyerFee,
      idempotencyKey: `SETTLE-BUYER-${auctionId}-${price}`,
    });

    const j2 = createJournalEntry({
      auctionId,
      description: `Validator Verification Reward Disbursed to Committee`,
      debitAccount: 'BUYER_SETTLEMENT_HOLD',
      creditAccount: 'VALIDATOR_REWARD_POOL',
      amount: validatorFee,
      idempotencyKey: `SETTLE-VAL-${auctionId}-${validatorFee}`,
    });

    const j3 = createJournalEntry({
      auctionId,
      description: `Seller Net Auction Proceeds Allocated (Less ${target.rules.sellerFeePercent}% protocol fee)`,
      debitAccount: 'BUYER_SETTLEMENT_HOLD',
      creditAccount: 'SELLER_ESCROW_BOND',
      amount: sellerNet,
      idempotencyKey: `SETTLE-SELLER-${auctionId}-${sellerNet}`,
    });

    // Ledger event
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'PAYMENT_CONFIRMED',
      actorId: winnerId,
      payload: { clearingPrice: price, buyerFee, sellerNet, validatorFee },
    });

    const payEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'PAYMENT_CONFIRMED',
      actorId: winnerId,
      payload: { clearingPrice: price, buyerFee, sellerNet, validatorFee },
      signature: await generateActorSignature(winnerId, evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            status: 'DELIVERY_PENDING',
            escrowEntries: [...a.escrowEntries, j1, j2, j3],
            eventLog: [...a.eventLog, payEvent],
          };
        }
        return a;
      })
    );

    appendDemoLog(`Escrow settlement executed: Double-entry journal updated. Buyer paid $${(price + buyerFee).toLocaleString()}. Status transitioned to DELIVERY_PENDING.`);
    return true;
  };

  const submitDeliveryEvidence = async (
    auctionId: string,
    evidenceType: 'SHIPPING_CARRIER_API' | 'SOFTWARE_LICENSE_KEY_DIGEST' | 'COMPUTE_SLURM_RUN_DIGEST',
    carrierOrVerifier: string,
    trackingOrTokenDigest: string
  ): Promise<boolean> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) return false;

    const nowIso = new Date().toISOString();
    const expiryIso = new Date(Date.now() + 7 * 86400 * 1000).toISOString();

    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'DELIVERY_EVIDENCE_POSTED',
      actorId: target.sellerId,
      payload: { evidenceType, carrierOrVerifier, trackingOrTokenDigest },
    });

    const newEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'DELIVERY_EVIDENCE_POSTED',
      actorId: target.sellerId,
      payload: { evidenceType, carrierOrVerifier, trackingOrTokenDigest },
      signature: await generateActorSignature(target.sellerId, evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            eventLog: [...a.eventLog, newEvent],
            deliveryEvidence: {
              submittedAtIso: nowIso,
              evidenceType,
              carrierOrVerifier,
              trackingOrTokenDigest,
              signedBySeller: `ed25519:${target.sellerId}_verified`,
              inspectionWindowExpiryIso: expiryIso,
              buyerAccepted: false,
            },
          };
        }
        return a;
      })
    );

    appendDemoLog(`Delivery evidence submitted by seller: ${evidenceType} (${trackingOrTokenDigest.slice(0, 20)}...). 7-day buyer inspection window started.`);
    return true;
  };

  const fileDispute = async (auctionId: string, reason: string): Promise<boolean> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) return false;

    const nowIso = new Date().toISOString();
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'DELIVERY_DISPUTED',
      actorId: target.winningBidderId || 'buyer',
      payload: { reason },
    });

    const disputeEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'DELIVERY_DISPUTED',
      actorId: target.winningBidderId || 'buyer',
      payload: { reason },
      signature: await generateActorSignature(target.winningBidderId || 'buyer', evHash),
    };

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            status: 'DISPUTED',
            eventLog: [...a.eventLog, disputeEvent],
            deliveryEvidence: a.deliveryEvidence
              ? { ...a.deliveryEvidence, buyerAccepted: false, buyerDisputeReason: reason }
              : undefined,
          };
        }
        return a;
      })
    );

    appendDemoLog(`DISPUTE FILED for ${target.title}: ${reason}. Escrow payout frozen pending arbitration panel.`);
    return true;
  };

  const resolveDispute = async (
    auctionId: string,
    verdict: 'REFUND_BUYER' | 'RELEASE_TO_SELLER'
  ): Promise<boolean> => {
    const target = auctions.find(a => a.id === auctionId);
    if (!target) return false;

    const nowIso = new Date().toISOString();
    const prevHash =
      target.eventLog.length > 0 ? target.eventLog[target.eventLog.length - 1].hash : 'GENESIS_ROOT';
    const evHash = await computeEventHash({
      seqId: target.eventLog.length + 1,
      prevHash,
      timestampIso: nowIso,
      eventType: 'DISPUTE_RESOLVED',
      actorId: 'arbitration_board',
      payload: { verdict },
    });

    const resolveEvent: LedgerEvent = {
      seqId: target.eventLog.length + 1,
      prevHash,
      hash: evHash,
      timestampIso: nowIso,
      eventType: 'DISPUTE_RESOLVED',
      actorId: 'arbitration_board',
      payload: { verdict },
      signature: await generateActorSignature('arbitration_board', evHash),
    };

    const newStatus = verdict === 'REFUND_BUYER' ? 'REFUNDED' : 'COMPLETED';

    setAuctions(prev =>
      prev.map(a => {
        if (a.id === auctionId) {
          return {
            ...a,
            status: newStatus,
            eventLog: [...a.eventLog, resolveEvent],
          };
        }
        return a;
      })
    );

    appendDemoLog(`Arbitration decision rendered: ${verdict}. Status transitioned to ${newStatus}.`);
    return true;
  };

  const executeDemoStep = async (stepNumber: number) => {
    setActiveDemoStep(stepNumber);
    const step = DEMO_STEPS.find(s => s.step === stepNumber);
    if (!step) return;

    setActiveAuctionId(step.auctionId);

    switch (stepNumber) {
      case 1: {
        // Step 1: Publish Auction with Immutably Hashed Rules
        appendDemoLog(`DEMO STEP 1: Rules published for ASML Wafer Metrology. Rules hash anchored: ${activeAuction.rules.rulesHash.slice(0, 24)}...`);
        break;
      }
      case 2: {
        // Step 2: Register Eligible Bidders
        appendDemoLog('DEMO STEP 2: Bidder eligibility credentials verified against AML/KYC registry for 4 institutional entities.');
        break;
      }
      case 3: {
        // Step 3: Posting Deposits
        appendDemoLog('DEMO STEP 3: $10,000 security deposits locked into BIDDER_DEPOSIT_ACCOUNT across 4 bidders.');
        break;
      }
      case 4: {
        // Step 4: Submitting Sealed Commitments
        appendDemoLog('DEMO STEP 4: 4 sealed commitments recorded in append-only event log. Domain-separated hashes hide plaintext amounts.');
        break;
      }
      case 5: {
        // Step 5: Revealing Bids
        appendDemoLog('DEMO STEP 5: 3 of 4 bidders revealed nonces and amounts. Hashes verified: DeepSynthetix ($64,800), Neuromorphic ($59,200), Cognitive ($54,000).');
        break;
      }
      case 6: {
        // Step 6: Handling Missing Reveal
        appendDemoLog('DEMO STEP 6: Reveal deadline reached. Bidder Apex failed to reveal. Statutory 20% penalty ($2,000) transferred to slashing pool; $8,000 returned.');
        break;
      }
      case 7: {
        // Step 7: Independent Replay
        const target = auctions.find(a => a.id === 'auc-compute-h100-vickrey') || activeAuction;
        const res = await replayAuctionLog(target);
        setLastReplayResult(res);
        appendDemoLog(`DEMO STEP 7: Local deterministic replay executed. Winner: ${res.winnerBidderName}, High Bid: $${res.highBidAmount.toLocaleString()}, Second-Price Clearing Price: $${res.clearingPrice.toLocaleString()} (Vickrey rule).`);
        break;
      }
      case 8: {
        // Step 8: Conflicting Validator Results / Equivocation
        // Submit 4 honest attestations + 1 rogue equivocating attestation
        const target = auctions.find(a => a.id === 'auc-compute-h100-vickrey') || activeAuction;
        await submitAttestation(target.id, 'val-helvetia', 'CONFIRMED');
        await submitAttestation(target.id, 'val-rhine', 'CONFIRMED');
        await submitAttestation(target.id, 'val-nihon', 'CONFIRMED');
        await submitAttestation(target.id, 'val-nordic', 'CONFIRMED');
        // Rogue node attempts double-sign extortion
        await submitAttestation(
          target.id,
          'val-rogue-sim',
          'MALICIOUS_EQUIVOCATION',
          'bidder-3',
          54000
        );
        appendDemoLog('DEMO STEP 8: Signed equivocation detected! Node val-rogue-sim signed contradictory price ($54,000 vs $59,200). $50,000 bond slashed.');
        break;
      }
      case 9: {
        // Step 9: Quorum Certificate & Settlement
        const target = auctions.find(a => a.id === 'auc-compute-h100-vickrey') || activeAuction;
        await certifyQuorum(target.id);
        await executeEscrowSettlement(target.id);
        appendDemoLog('DEMO STEP 9: Quorum Certificate issued with 85.7% honest stake. Settlement executed: buyer charged, seller credited, validator fees paid.');
        break;
      }
      case 10: {
        // Step 10: Appealing Disputed Delivery
        setActiveAuctionId('auc-autonav-license-firstprice');
        setCurrentRole('DISPUTES');
        appendDemoLog('DEMO STEP 10: AeroNav Software License delivery dispute loaded. Reviewing license terms, cluster certificate digest, and arbitration controls.');
        break;
      }
    }
  };

  const resetToInitialState = () => {
    setAuctions(INITIAL_AUCTIONS);
    setValidators(INITIAL_VALIDATORS);
    setActiveAuctionId('auc-compute-h100-vickrey');
    setActiveDemoStep(1);
    setLastReplayResult(null);
    setDemoLogs(['State reset to initial genesis snapshot.']);
  };

  return (
    <AuctionContext.Provider
      value={{
        auctions,
        validators,
        activeAuctionId,
        activeAuction,
        currentRole,
        activeDemoStep,
        demoLogs,
        lastReplayResult,
        setCurrentRole,
        setActiveAuctionId,
        setActiveDemoStep,
        placeEnglishBid,
        submitSealedCommitment,
        revealSealedBid,
        runReplayForActiveAuction,
        submitAttestation,
        certifyQuorum,
        executeEscrowSettlement,
        submitDeliveryEvidence,
        fileDispute,
        resolveDispute,
        executeDemoStep,
        resetToInitialState,
      }}
    >
      {children}
    </AuctionContext.Provider>
  );
};

export const useAuction = (): AuctionContextType => {
  const ctx = useContext(AuctionContext);
  if (!ctx) throw new Error('useAuction must be used within an AuctionProvider');
  return ctx;
};
