/**
 * Aureom.AI AuctionProof - Cryptographic Utilities
 * Domain-separated commit-reveal, SHA-256 hash chains, high-entropy nonces, and canonical serialization.
 */

/**
 * Compute SHA-256 digest as a hex string.
 */
export async function sha256Hex(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Generate a cryptographically secure 256-bit (32-byte) hex nonce.
 * Prevents dictionary attacks and rainbow table lookups on standard bid numbers.
 */
export function generateSecureNonce(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Deterministic canonical JSON serialization.
 * Recursively sorts keys alphabetically and removes non-serializable fields.
 */
export function canonicalJsonStringify(obj: unknown): string {
  if (obj === null || typeof obj !== 'object') {
    return JSON.stringify(obj);
  }
  if (Array.isArray(obj)) {
    return '[' + obj.map(item => canonicalJsonStringify(item)).join(',') + ']';
  }
  const keys = Object.keys(obj as Record<string, unknown>).sort();
  const pairs = keys.map(key => {
    const val = (obj as Record<string, unknown>)[key];
    return `${JSON.stringify(key)}:${canonicalJsonStringify(val)}`;
  });
  return '{' + pairs.join(',') + '}';
}

/**
 * Domain-separated commitment formula:
 * Prefix: "AUCTIONPROOF_COMMIT_V1"
 * Canonical field concatenation to eliminate delimiter collision and length extension risks.
 */
export function buildCanonicalCommitmentString(params: {
  auctionId: string;
  bidderId: string;
  amount: number;
  currency: string;
  conditionsDigest: string;
  nonce: string;
}): string {
  const normAmount = Number(params.amount).toFixed(2);
  const normCurrency = params.currency.trim().toUpperCase();
  const normConditions = params.conditionsDigest.trim();
  const normNonce = params.nonce.trim().toLowerCase();

  return `AUCTIONPROOF_COMMIT_V1:${params.auctionId}:${params.bidderId}:${normAmount}:${normCurrency}:${normConditions}:${normNonce}`;
}

/**
 * Computes the commitment hash for sealed bidding.
 */
export async function computeCommitmentHash(params: {
  auctionId: string;
  bidderId: string;
  amount: number;
  currency: string;
  conditionsDigest: string;
  nonce: string;
}): Promise<string> {
  const canonical = buildCanonicalCommitmentString(params);
  return sha256Hex(canonical);
}

/**
 * Validates whether revealed values match the original commitment hash.
 */
export async function verifyBidReveal(params: {
  commitmentHash: string;
  auctionId: string;
  bidderId: string;
  amount: number;
  currency: string;
  conditionsDigest: string;
  nonce: string;
}): Promise<{ valid: boolean; reconstructedHash: string; canonicalString: string }> {
  const canonicalString = buildCanonicalCommitmentString(params);
  const reconstructedHash = await sha256Hex(canonicalString);
  return {
    valid: reconstructedHash.toLowerCase() === params.commitmentHash.toLowerCase(),
    reconstructedHash,
    canonicalString,
  };
}

/**
 * Computes hash of an event in the append-only ledger, binding to prevHash.
 */
export async function computeEventHash(params: {
  seqId: number;
  prevHash: string;
  timestampIso: string;
  eventType: string;
  actorId: string;
  payload: Record<string, unknown>;
}): Promise<string> {
  const canonicalPayload = canonicalJsonStringify(params.payload);
  const raw = `${params.seqId}|${params.prevHash}|${params.timestampIso}|${params.eventType}|${params.actorId}|${canonicalPayload}`;
  return sha256Hex(raw);
}

/**
 * Computes root digest of a sequence of ledger events (Merkle / chain digest).
 */
export async function computeEventLogDigest(events: Array<{ hash: string }>): Promise<string> {
  if (events.length === 0) return '0'.repeat(64);
  const combined = events.map(e => e.hash).join(':');
  return sha256Hex(`AUCTIONPROOF_LOG_ROOT_V1:${combined}`);
}

/**
 * Simulates deterministic validator signing.
 * In a real environment this uses WebCrypto SubtleCrypto.sign with ECDSA / Ed25519.
 */
export async function generateActorSignature(actorId: string, messageHash: string): Promise<string> {
  const signatureRaw = `SIG_V1_${actorId}_${messageHash.substring(0, 32)}`;
  return sha256Hex(signatureRaw);
}

/**
 * Verifies if an actor signature matches the expected digest.
 */
export async function verifyActorSignature(
  actorId: string,
  messageHash: string,
  signature: string
): Promise<boolean> {
  const expected = await generateActorSignature(actorId, messageHash);
  return expected.toLowerCase() === signature.toLowerCase();
}
