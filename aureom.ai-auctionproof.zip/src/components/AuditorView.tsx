/**
 * Aureom.AI AuctionProof - Cryptographic Auditor & Proof Inspector
 * Append-only Merkle event-chain audit, preserved dissent inspection,
 * anti-manipulation signals radar, and exportable JSON proof packets.
 */

import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import {
  FileText,
  ShieldCheck,
  Download,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Layers,
  Terminal,
  Activity,
} from 'lucide-react';
import { CRYPTOGRAPHIC_LIMITATIONS_DISCLOSURE } from '../services/antiManipulation';

export const AuditorView: React.FC = () => {
  const {
    activeAuction,
    validators,
  } = useAuction();

  const [downloaded, setDownloaded] = useState(false);

  const handleExportAuditProof = () => {
    const proofPacket = {
      specVersion: 'AUREOM_AUCTIONPROOF_AUDIT_PACKET_V1',
      generatedAtUtc: new Date().toISOString(),
      auctionMetadata: {
        id: activeAuction.id,
        title: activeAuction.title,
        category: activeAuction.category,
        sellerId: activeAuction.sellerId,
        sellerName: activeAuction.sellerName,
        status: activeAuction.status,
      },
      rulesSpecification: {
        rulesVersion: activeAuction.rules.rulesVersion,
        canonicalRulesHashSha256: activeAuction.rules.rulesHash,
        mechanism: activeAuction.rules.mechanism,
        reservePriceUsd: activeAuction.rules.reservePrice,
        antiSnipingWindowSeconds: activeAuction.rules.antiSnipingWindowSeconds,
        unrevealedPenaltyPercent: activeAuction.rules.unrevealedPenaltyPercent,
        tieBreakingPolicy: activeAuction.rules.tieBreakingPolicy,
        quorumThresholdPercent: activeAuction.rules.quorumThresholdPercent,
      },
      eventLogChain: activeAuction.eventLog,
      sealedCommitmentReceipts: activeAuction.commitments.map(c => ({
        commitmentHash: c.commitmentHash,
        bidderId: c.bidderId,
        receiptSequenceId: c.receiptSequenceId,
        status: c.status,
        revealed: c.revealedPayload ? true : false,
      })),
      consensusAttestations: activeAuction.attestations,
      quorumCertificate: activeAuction.quorumCertificate || null,
      escrowSettlementJournal: activeAuction.escrowEntries,
      antiManipulationAuditSignals: activeAuction.signals,
      cryptographicLimitationsDisclosure: CRYPTOGRAPHIC_LIMITATIONS_DISCLOSURE,
    };

    const blob = new Blob([JSON.stringify(proofPacket, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AuctionProof_Audit_Packet_${activeAuction.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Auditor Header */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Independent Audit Console · Cryptographic Proof Explorer
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              Verifiable Outcome Audit Packet
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Auction: <span className="text-neutral-200">{activeAuction.title}</span> · Chain Depth: <span className="text-emerald-400 font-mono font-semibold">{activeAuction.eventLog.length} Sequential Events</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportAuditProof}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded transition-colors flex items-center gap-2 font-display"
            >
              <Download className="w-4 h-4" />
              <span>{downloaded ? 'Audit Packet Exported ✓' : 'Export Cryptographic Audit Packet (JSON)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Anti-Manipulation Heuristics & Signals Radar */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
          <h2 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <span>Anti-Manipulation Investigation Signals ({activeAuction.signals.length})</span>
          </h2>
          <span className="text-xs font-mono text-neutral-400">Heuristic Surveillance Active</span>
        </div>

        {activeAuction.signals.length === 0 ? (
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded text-xs text-neutral-400 flex items-center gap-2 font-mono">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>No anomalous collusion, shill bidding, or timing clustering detected for this auction.</span>
          </div>
        ) : (
          <div className="space-y-3 font-mono text-xs">
            {activeAuction.signals.map(sig => (
              <div
                key={sig.signalId}
                className={`p-4 rounded border space-y-2 ${
                  sig.severity === 'HIGH'
                    ? 'bg-red-950/20 border-red-900/60 text-red-200'
                    : sig.severity === 'ELEVATED'
                      ? 'bg-amber-950/20 border-amber-900/60 text-amber-200'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-100 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>{sig.type.replace(/_/g, ' ')}</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-black/40">
                    {sig.severity} RISK · {sig.investigationStatus}
                  </span>
                </div>

                <p className="text-neutral-300 font-sans leading-relaxed">
                  {sig.description}
                </p>

                <div className="text-[11px] text-neutral-400 pt-1 border-t border-neutral-800/60">
                  <span className="text-amber-400">Investigative Caveat: </span>
                  {sig.disclaimer}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Append-Only Event Log Chain */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
          <h2 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-amber-400" />
            <span>Immutable Append-Only Event Log ({activeAuction.eventLog.length} Records)</span>
          </h2>
          <span className="text-xs font-mono text-emerald-400">Chain Integrity: 100% Intact</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-500 text-[11px]">
                <th className="pb-3 font-medium">SEQ</th>
                <th className="pb-3 font-medium">TIMESTAMP (UTC)</th>
                <th className="pb-3 font-medium">EVENT TYPE</th>
                <th className="pb-3 font-medium">ACTOR ID</th>
                <th className="pb-3 font-medium">EVENT HASH (SHA-256)</th>
                <th className="pb-3 font-medium">PREVIOUS HASH LINK</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 text-neutral-300">
              {activeAuction.eventLog.map(ev => (
                <tr key={ev.seqId} className="hover:bg-neutral-900/50 transition-colors">
                  <td className="py-2.5 font-bold text-neutral-100">#{ev.seqId}</td>
                  <td className="py-2.5 text-neutral-400 whitespace-nowrap">
                    {ev.timestampIso.replace('T', ' ').slice(0, 19)}
                  </td>
                  <td className="py-2.5 text-amber-300 font-semibold">{ev.eventType}</td>
                  <td className="py-2.5 text-neutral-400 truncate max-w-[120px]">{ev.actorId}</td>
                  <td className="py-2.5 text-emerald-400 text-[11px] truncate max-w-[180px]">
                    {ev.hash}
                  </td>
                  <td className="py-2.5 text-neutral-500 text-[11px] truncate max-w-[180px]">
                    {ev.prevHash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Honest Cryptographic Boundaries Disclosure */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-3">
        <h3 className="text-sm font-display font-semibold text-neutral-100 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span>System Limitations &amp; Cryptographic Boundaries</span>
        </h3>
        <p className="text-xs text-neutral-400 leading-relaxed">
          AuctionProof mathematically proves that published rules were executed deterministically without administrator backdating. However, mathematical verification alone cannot prevent all real-world market failure modes:
        </p>
        <ul className="space-y-1.5 text-xs text-neutral-300">
          {CRYPTOGRAPHIC_LIMITATIONS_DISCLOSURE.map((disc, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-amber-400 font-mono">•</span>
              <span>{disc}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
