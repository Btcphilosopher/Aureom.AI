/**
 * Aureom.AI AuctionProof - Validator Network & Deterministic Consensus
 * Registry with bonded stakes, operator relationships, independent event-log replay,
 * signed attestation broadcasting, and slashing protocols for equivocation.
 */

import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import {
  ShieldCheck,
  ShieldAlert,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCw,
  FileCheck,
  Award,
} from 'lucide-react';
import { DeterministicEngineResult } from '../services/auctionEngine';

export const ValidatorView: React.FC = () => {
  const {
    validators,
    activeAuction,
    runReplayForActiveAuction,
    lastReplayResult,
    submitAttestation,
    certifyQuorum,
  } = useAuction();

  const [selectedValidatorId, setSelectedValidatorId] = useState<string>('val-helvetia');
  const [replaying, setReplaying] = useState<boolean>(false);
  const [attesting, setAttesting] = useState<boolean>(false);
  const [certifying, setCertifying] = useState<boolean>(false);

  // Equivocation simulation inputs
  const [simulateMalicious, setSimulateMalicious] = useState<boolean>(false);
  const [maliciousPrice, setMaliciousPrice] = useState<number>(54000);

  const committeeNodes = validators.filter(v =>
    activeAuction.committeeValidators.includes(v.validatorId)
  );

  const totalCommitteeStake = committeeNodes.reduce((sum, v) => sum + v.bondedStakeUsd, 0);

  const handleRunReplay = async () => {
    setReplaying(true);
    try {
      await runReplayForActiveAuction();
    } finally {
      setReplaying(false);
    }
  };

  const handleSignAttestation = async (verdict: 'CONFIRMED' | 'DISSENTING' | 'MALICIOUS_EQUIVOCATION') => {
    setAttesting(true);
    try {
      if (verdict === 'MALICIOUS_EQUIVOCATION') {
        await submitAttestation(
          activeAuction.id,
          selectedValidatorId,
          'MALICIOUS_EQUIVOCATION',
          'bidder-3',
          maliciousPrice
        );
      } else {
        await submitAttestation(activeAuction.id, selectedValidatorId, verdict);
      }
    } finally {
      setAttesting(false);
    }
  };

  const handleCertify = async () => {
    setCertifying(true);
    try {
      await certifyQuorum(activeAuction.id);
    } finally {
      setCertifying(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Overview */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Stake-Backed Consensus Network · Independent Local Replay
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              Validator Registry & Committee Consensus
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Economic Bond: <span className="text-neutral-200 font-mono">${(validators.reduce((sum, v) => sum + v.bondedStakeUsd, 0)).toLocaleString()} Total Bonded Collateral</span> · Slashing Defense: <span className="text-emerald-400">Signed Equivocation & Fabricated Records</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRunReplay}
              disabled={replaying}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-semibold text-xs rounded border border-neutral-700 flex items-center gap-2 font-display"
            >
              {replaying ? <RotateCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 text-emerald-400" />}
              <span>Run Local Deterministic Replay</span>
            </button>
            <button
              onClick={handleCertify}
              disabled={certifying || activeAuction.attestations.length === 0}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded flex items-center gap-2 font-display"
            >
              {certifying ? <RotateCw className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}
              <span>Issue Quorum Certificate</span>
            </button>
          </div>
        </div>
      </div>

      {/* Committee Overview Strip */}
      <div className="border border-neutral-800 bg-[#0e1116] rounded-lg p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
          <div className="text-neutral-300">
            Assigned Committee for <strong className="text-neutral-100">{activeAuction.title.slice(0, 32)}...</strong>:
          </div>
          <div className="flex items-center gap-4 text-neutral-400">
            <span>Committee Size: <span className="text-neutral-200">{committeeNodes.length} Nodes</span></span>
            <span>·</span>
            <span>Total Committee Bond: <span className="text-emerald-400 font-bold">${totalCommitteeStake.toLocaleString()}</span></span>
            <span>·</span>
            <span>Quorum Threshold: <span className="text-amber-400 font-bold">{activeAuction.rules.quorumThresholdPercent}%</span></span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Replay Engine & Attestation Station */}
        <div className="lg:col-span-2 space-y-6">
          {/* Replay Results Card */}
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-amber-400" />
                <span>Deterministic Replay Engine Output</span>
              </h2>
              {lastReplayResult ? (
                <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Replay Invariants Verified
                </span>
              ) : (
                <span className="text-xs font-mono text-neutral-500">Replay Pending Execution</span>
              )}
            </div>

            {lastReplayResult ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                    <span className="text-neutral-500 text-[10px] block">REPLAYED EVENTS</span>
                    <span className="text-neutral-100 font-bold text-sm">{lastReplayResult.totalEventsReplayed} Logs</span>
                  </div>
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                    <span className="text-neutral-500 text-[10px] block">CALCULATED WINNER</span>
                    <span className="text-neutral-100 font-bold text-sm truncate">{lastReplayResult.winnerBidderName?.split(' ')[0]}</span>
                  </div>
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                    <span className="text-neutral-500 text-[10px] block">CLEARING PRICE</span>
                    <span className="text-amber-300 font-bold text-sm">${lastReplayResult.clearingPrice.toLocaleString()}</span>
                  </div>
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                    <span className="text-neutral-500 text-[10px] block">VALIDATOR REWARD POOL</span>
                    <span className="text-emerald-400 font-bold text-sm">${lastReplayResult.feeCalculations.validatorRewardPool.toLocaleString()}</span>
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-neutral-800 rounded font-mono text-xs space-y-1">
                  <div className="text-neutral-500 text-[10px]">REPLAY ROOT DIGEST (MERKLE LOG):</div>
                  <div className="text-neutral-300 break-all">{lastReplayResult.eventLogDigest}</div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="text-neutral-400 font-mono font-semibold">Invariant Verifications:</div>
                  {lastReplayResult.checks.map((chk, i) => (
                    <div key={i} className="flex items-start gap-2 p-2 bg-neutral-900/60 border border-neutral-800/80 rounded">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-neutral-200 font-medium">{chk.step}</div>
                        <div className="text-neutral-400 text-[11px]">{chk.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-8 text-center border border-dashed border-neutral-800 rounded space-y-2">
                <p className="text-sm text-neutral-400">
                  Click <strong>&quot;Run Local Deterministic Replay&quot;</strong> to execute the raw immutable event log through the deterministic validation engine.
                </p>
                <p className="text-xs text-neutral-500 font-mono">
                  Guarantees stake-independent ranking: validator stake weight does not alter winner calculation.
                </p>
              </div>
            )}
          </div>

          {/* Attestation Broadcast Panel */}
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <h3 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <span>Broadcast Signed Validation Record / Attestation</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Select Signing Validator Node</label>
                <select
                  value={selectedValidatorId}
                  onChange={e => setSelectedValidatorId(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
                >
                  {validators.map(v => (
                    <option key={v.validatorId} value={v.validatorId}>
                      {v.name} (${v.bondedStakeUsd.toLocaleString()} · {v.status})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end gap-2">
                <button
                  type="button"
                  onClick={() => handleSignAttestation('CONFIRMED')}
                  disabled={attesting}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors"
                >
                  {attesting ? 'Signing...' : 'Sign & Broadcast Confirmation'}
                </button>
                <button
                  type="button"
                  onClick={() => handleSignAttestation('DISSENTING')}
                  disabled={attesting}
                  className="px-3 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors"
                  title="Preserve minority dissent"
                >
                  Dissent
                </button>
              </div>
            </div>

            {/* Rogue Equivocation Test Drawer */}
            <div className="p-4 bg-red-950/20 border border-red-900/40 rounded space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-red-400 font-semibold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Adversarial Equivocation Attack Simulation (Test Slashing)</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSimulateMalicious(!simulateMalicious)}
                  className="text-[11px] text-neutral-400 underline"
                >
                  {simulateMalicious ? 'Hide' : 'Configure Attack'}
                </button>
              </div>

              {simulateMalicious && (
                <div className="space-y-3 pt-2">
                  <p className="text-neutral-400 text-[11px] leading-relaxed">
                    Test the slashing protocol by broadcasting a second, contradictory signed attestation with an altered clearing price. The engine catches conflicting digital signatures from the same public key and slashes the validator&apos;s bonded stake.
                  </p>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      value={maliciousPrice}
                      onChange={e => setMaliciousPrice(Number(e.target.value))}
                      className="bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 text-red-300 w-36"
                    />
                    <button
                      type="button"
                      onClick={() => handleSignAttestation('MALICIOUS_EQUIVOCATION')}
                      disabled={attesting}
                      className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded text-xs"
                    >
                      Broadcast Contradictory Attestation
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Col: Validator Registry List */}
        <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <h3 className="text-sm font-display font-semibold text-neutral-100">
              Network Validator Registry ({validators.length})
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">100% Bonded</span>
          </div>

          <div className="space-y-2.5 max-h-[580px] overflow-y-auto font-mono text-xs">
            {validators.map(v => {
              const inCommittee = activeAuction.committeeValidators.includes(v.validatorId);
              return (
                <div
                  key={v.validatorId}
                  className={`p-3 rounded border transition-colors ${
                    v.status === 'SLASHED'
                      ? 'bg-red-950/20 border-red-900 text-red-300'
                      : v.status === 'SUSPENDED'
                        ? 'bg-neutral-900 border-neutral-800 text-neutral-500'
                        : inCommittee
                          ? 'bg-neutral-900/90 border-amber-500/40 text-neutral-200'
                          : 'bg-neutral-900/50 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-100">{v.name}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        v.status === 'ACTIVE'
                          ? 'text-emerald-400 bg-emerald-950/40'
                          : 'text-red-400 bg-red-950/40'
                      }`}
                    >
                      {v.status}
                    </span>
                  </div>

                  <div className="text-[11px] text-neutral-400 mt-1">
                    Operator: <span className="text-neutral-300">{v.operatorEntity}</span>
                  </div>
                  <div className="text-[11px] text-neutral-500">{v.jurisdiction}</div>

                  <div className="mt-2 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[11px]">
                    <span>Bond: <strong className="text-neutral-200">${v.bondedStakeUsd.toLocaleString()}</strong></span>
                    <span>Uptime: <strong className="text-emerald-400">{v.uptimePercent}%</strong></span>
                    {v.slashedTotalUsd > 0 && (
                      <span className="text-red-400 font-bold">Slashed: ${v.slashedTotalUsd.toLocaleString()}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
