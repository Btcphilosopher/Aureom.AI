/**
 * Aureom.AI AuctionProof - Disputes & Appeals Module
 * Adjudication of delivery non-conformance, software license IP boundary audits,
 * arbitrator multi-sig voting, and escrow freeze/release resolution.
 */

import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import {
  Activity,
  AlertTriangle,
  Scale,
  ShieldCheck,
  CheckCircle2,
  FileText,
  RotateCcw,
} from 'lucide-react';

export const DisputesView: React.FC = () => {
  const {
    activeAuction,
    fileDispute,
    resolveDispute,
  } = useAuction();

  const [disputeReason, setDisputeReason] = useState<string>(
    'Delivered software license binary fails cryptographic attestation on edge cluster #4, #7, #9 due to missing patch bundle.'
  );
  const [filing, setFiling] = useState(false);
  const [resolving, setResolving] = useState(false);

  const handleFileDispute = async (e: React.FormEvent) => {
    e.preventDefault();
    setFiling(true);
    try {
      await fileDispute(activeAuction.id, disputeReason);
    } finally {
      setFiling(false);
    }
  };

  const handleResolve = async (verdict: 'REFUND_BUYER' | 'RELEASE_TO_SELLER') => {
    setResolving(true);
    try {
      await resolveDispute(activeAuction.id, verdict);
    } finally {
      setResolving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Disputes Header */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Arbitration &amp; Appeals Board · Independent Review Layer
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              Dispute Adjudication &amp; Legal IP Boundaries
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Auction: <span className="text-neutral-200">{activeAuction.title}</span> · Status: <span className="text-red-400 font-bold font-mono">{activeAuction.status}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-neutral-400">
              Escrow State: <strong className="text-amber-400">FROZEN PENDING ARBITRATION</strong>
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Dispute Case File */}
        <div className="lg:col-span-2 space-y-6">
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                <span>Active Case File: Delivery Non-Conformance &amp; IP Rights</span>
              </h2>
              <span className="text-xs font-mono text-neutral-400">Case ID: DISP-{activeAuction.id.slice(-6)}</span>
            </div>

            {/* Buyer Claim */}
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded space-y-2 text-xs">
              <div className="text-neutral-400 font-mono font-semibold text-[11px] uppercase">
                Buyer Delivery Grievance:
              </div>
              <p className="text-neutral-200 leading-relaxed font-sans">
                {activeAuction.deliveryEvidence?.buyerDisputeReason ||
                  'Buyer reported delivery defect: cryptographic license token verification fails on designated runtime infrastructure.'}
              </p>
            </div>

            {/* Software IP Transfer Boundaries Warning */}
            <div className="p-4 bg-amber-950/20 border border-amber-900/50 rounded space-y-2 text-xs text-neutral-300">
              <div className="font-semibold text-amber-400 flex items-center gap-1.5 font-mono">
                <FileText className="w-4 h-4" />
                <span>Legal &amp; Cryptographic IP Transfer Scope</span>
              </div>
              <p className="leading-relaxed">
                For software licenses and algorithms, validators and arbitrators verify digital signature chains and token digests. <strong>Crucial legal invariant:</strong> Possession of repository source code or a license token does NOT confer copyright ownership or patent transfer unless explicit assignment contracts are recorded.
              </p>
            </div>

            {/* Arbitrator Voting Panel */}
            <div className="pt-4 border-t border-neutral-800 space-y-3">
              <h3 className="text-sm font-display font-semibold text-neutral-100">
                Arbitrator Panel Adjudication Actions
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
                <button
                  type="button"
                  onClick={() => handleResolve('REFUND_BUYER')}
                  disabled={resolving || activeAuction.status !== 'DISPUTED'}
                  className="p-3 bg-red-950/40 hover:bg-red-950/60 border border-red-800 text-red-200 rounded font-semibold text-left transition-colors"
                >
                  <div className="font-bold text-red-300">1. Uphold Buyer Claim</div>
                  <div className="text-[11px] text-neutral-400 mt-1">
                    Execute 100% refund of Buyer Settlement Hold. Deduct damages from Seller Escrow Bond.
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleResolve('RELEASE_TO_SELLER')}
                  disabled={resolving || activeAuction.status !== 'DISPUTED'}
                  className="p-3 bg-emerald-950/40 hover:bg-emerald-950/60 border border-emerald-800 text-emerald-200 rounded font-semibold text-left transition-colors"
                >
                  <div className="font-bold text-emerald-300">2. Dismiss Dispute &amp; Pay Seller</div>
                  <div className="text-[11px] text-neutral-400 mt-1">
                    Confirm delivery meets published contract terms. Release net funds to seller.
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: File New Dispute */}
        <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
          <h3 className="text-sm font-display font-semibold text-neutral-100 flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-400" />
            <span>File New Delivery Dispute</span>
          </h3>

          <p className="text-xs text-neutral-400 leading-relaxed">
            If the delivered physical equipment, software license, or compute allocation fails to match the immutably published specifications, lodge a formal dispute within the 7-day inspection window.
          </p>

          <form onSubmit={handleFileDispute} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-neutral-400 mb-1">Dispute Reason &amp; Evidence</label>
              <textarea
                rows={4}
                required
                value={disputeReason}
                onChange={e => setDisputeReason(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded p-3 text-neutral-200 text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              disabled={filing}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-semibold text-xs rounded border border-neutral-700 transition-colors"
            >
              {filing ? 'Recording on Ledger...' : 'Freeze Escrow & File Dispute'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
