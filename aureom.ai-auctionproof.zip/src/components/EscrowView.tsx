/**
 * Aureom.AI AuctionProof - Double-Entry Escrow & Financial Settlement
 * Strictly balanced debits/credits, idempotent settlement execution,
 * segregated account balances, and slashing penalty pools.
 */

import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import { computeTrialBalance } from '../services/escrowService';
import {
  Scale,
  CheckCircle2,
  DollarSign,
  AlertTriangle,
  RotateCw,
  ArrowRightLeft,
  FileSpreadsheet,
} from 'lucide-react';

export const EscrowView: React.FC = () => {
  const {
    activeAuction,
    executeEscrowSettlement,
  } = useAuction();

  const [settling, setSettling] = useState(false);

  const trialBalance = computeTrialBalance(activeAuction.escrowEntries);

  const handleExecuteSettlement = async () => {
    setSettling(true);
    try {
      await executeEscrowSettlement(activeAuction.id);
    } finally {
      setSettling(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Escrow Header */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Idempotent Financial Operations · Segregated Escrow Accounts
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              Double-Entry Escrow &amp; Settlement Ledger
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Active Auction: <span className="text-neutral-200">{activeAuction.title}</span> · State: <span className="text-emerald-400 font-semibold font-mono">{activeAuction.status}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className={`px-3 py-2 rounded border text-xs font-mono flex items-center gap-2 ${
              trialBalance.isBalanced
                ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                : 'bg-red-950/30 border-red-800 text-red-300'
            }`}>
              <CheckCircle2 className="w-4 h-4" />
              <span>Trial Balance: {trialBalance.isBalanced ? 'Balanced (Δ = $0.00)' : 'Unbalanced!'}</span>
            </div>

            <button
              onClick={handleExecuteSettlement}
              disabled={settling || activeAuction.status !== 'AWARDED'}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-neutral-950 font-bold text-xs rounded transition-colors font-display"
            >
              {settling ? 'Executing Idempotent Transfers...' : 'Execute Escrow Settlement'}
            </button>
          </div>
        </div>
      </div>

      {/* Segregated Escrow Account Balances */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {trialBalance.accountSummaries.map(acc => (
          <div key={acc.account} className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1 font-mono">
            <div className="text-neutral-500 text-[10px] tracking-wider truncate">
              {acc.account.replace(/_/g, ' ')}
            </div>
            <div className={`text-base font-bold ${
              acc.balance > 0
                ? 'text-neutral-100'
                : acc.balance < 0
                  ? 'text-amber-400'
                  : 'text-neutral-500'
            }`}>
              ${Math.abs(acc.balance).toLocaleString()} {acc.currency}
            </div>
            <div className="text-[10px] text-neutral-500">
              Segregated Net Position
            </div>
          </div>
        ))}
      </div>

      {/* Double-Entry Journal Table */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
          <h2 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-amber-400" />
            <span>Immutable Double-Entry Journal Entries ({activeAuction.escrowEntries.length})</span>
          </h2>
          <span className="text-xs font-mono text-neutral-400">
            Total Debits: ${trialBalance.totalDebits.toLocaleString()} · Total Credits: ${trialBalance.totalCredits.toLocaleString()}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-500 text-[11px]">
                <th className="pb-3 font-medium">TIMESTAMP (UTC)</th>
                <th className="pb-3 font-medium">DESCRIPTION</th>
                <th className="pb-3 font-medium">DEBIT ACCOUNT</th>
                <th className="pb-3 font-medium">CREDIT ACCOUNT</th>
                <th className="pb-3 font-medium text-right">AMOUNT (USD)</th>
                <th className="pb-3 font-medium text-right">IDEMPOTENCY KEY</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 text-neutral-300">
              {activeAuction.escrowEntries.map(entry => (
                <tr key={entry.entryId} className="hover:bg-neutral-900/50 transition-colors">
                  <td className="py-3 text-neutral-500 whitespace-nowrap">
                    {entry.timestampIso.replace('T', ' ').slice(0, 19)}
                  </td>
                  <td className="py-3 font-medium text-neutral-200">
                    {entry.description}
                  </td>
                  <td className="py-3 text-red-300">
                    {entry.debitAccount.replace(/_/g, ' ')}
                  </td>
                  <td className="py-3 text-emerald-300">
                    {entry.creditAccount.replace(/_/g, ' ')}
                  </td>
                  <td className="py-3 text-right font-bold text-neutral-100">
                    ${entry.amount.toLocaleString()}
                  </td>
                  <td className="py-3 text-right text-neutral-500 text-[11px] truncate max-w-[140px]">
                    {entry.idempotencyKey}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
