/**
 * Aureom.AI AuctionProof - Top Navigation Bar
 * Follows strict 3-zone contract, restrained luxury graphite aesthetic,
 * clean typographic links and functional view switching.
 */

import React from 'react';
import { useAuction, UserRole } from '../context/AuctionContext';
import { ShieldCheck, RotateCcw, Cpu, Scale, FileText, Layers, Users, Activity, PlayCircle } from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    auctions,
    activeAuctionId,
    setActiveAuctionId,
    resetToInitialState,
  } = useAuction();

  const navItems: { role: UserRole; label: string; icon: React.ReactNode }[] = [
    { role: 'DEMO', label: 'Guided Demo', icon: <PlayCircle className="w-4 h-4" /> },
    { role: 'BUYER', label: 'Buyer & Bids', icon: <Users className="w-4 h-4" /> },
    { role: 'SELLER', label: 'Seller & Rules', icon: <Layers className="w-4 h-4" /> },
    { role: 'VALIDATOR', label: 'Validator Network', icon: <ShieldCheck className="w-4 h-4" /> },
    { role: 'SETTLEMENT', label: 'Escrow Ledger', icon: <Scale className="w-4 h-4" /> },
    { role: 'DISPUTES', label: 'Disputes & Appeals', icon: <Activity className="w-4 h-4" /> },
    { role: 'AUDITOR', label: 'Cryptographic Audit', icon: <FileText className="w-4 h-4" /> },
    { role: 'SIMULATION', label: 'Stress Simulation', icon: <Cpu className="w-4 h-4" /> },
  ];

  return (
    <header className="border-b border-neutral-800 bg-[#0c0e12] sticky top-0 z-40">
      {/* Zone 1 - 2 - 3 Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-400/20 to-neutral-800 border border-amber-500/40 flex items-center justify-center text-amber-400 font-mono font-bold text-sm">
            AP
          </div>
          <span className="font-display font-bold text-lg tracking-tight text-neutral-100 whitespace-nowrap">
            Aureom.AI <span className="text-amber-400 font-normal">AuctionProof</span>
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 overflow-x-auto py-1">
          {navItems.map(item => {
            const active = currentRole === item.role;
            return (
              <button
                key={item.role}
                onClick={() => setCurrentRole(item.role)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-neutral-800 text-amber-400 border border-neutral-700/80 shadow-xs'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/40'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={resetToInitialState}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-neutral-400 hover:text-neutral-100 bg-neutral-900 border border-neutral-800 rounded hover:border-neutral-700 transition-colors whitespace-nowrap"
            title="Reset system state to genesis baseline"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Genesis</span>
          </button>
        </div>
      </div>

      {/* Sub-bar: Active Auction Switcher & Metadata Bar */}
      <div className="bg-[#12151b] border-t border-neutral-800/60 px-4 sm:px-6 lg:px-8 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 overflow-x-auto py-0.5">
            <span className="text-neutral-500 font-mono uppercase tracking-wider text-[11px] shrink-0">
              Active Auction:
            </span>
            {auctions.map(auc => {
              const selected = auc.id === activeAuctionId;
              return (
                <button
                  key={auc.id}
                  onClick={() => setActiveAuctionId(auc.id)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 ${
                    selected
                      ? 'bg-neutral-800 text-neutral-100 border border-amber-500/30'
                      : 'text-neutral-400 hover:text-neutral-200 bg-neutral-900/60 border border-neutral-800/60'
                  }`}
                >
                  <span className="font-medium truncate max-w-[220px]">{auc.title}</span>
                  <span className="text-[10px] font-mono text-amber-400/80">{auc.rules.mechanism.replace(/_/g, ' ')}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-neutral-400 font-mono text-[11px] shrink-0">
            <span>Authoritative Clock: <span className="text-neutral-200">2026-11-11 UTC</span></span>
            <span aria-hidden="true">·</span>
            <span>Ledger: <span className="text-emerald-400">Append-Only SHA-256</span></span>
            <span aria-hidden="true">·</span>
            <span>Validators: <span className="text-amber-400">8 Bonded Nodes ($2.8M)</span></span>
          </div>
        </div>
      </div>
    </header>
  );
};
