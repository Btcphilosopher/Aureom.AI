/**
 * Aureom.AI AuctionProof - Seller Portal
 * Auction publication with canonical SHA-256 rule versioning,
 * delivery evidence submission, and escrow release tracking.
 */

import React, { useState } from 'react';
import { useAuction } from '../context/AuctionContext';
import {
  Layers,
  UploadCloud,
  FileCheck2,
  Clock,
  ShieldCheck,
  AlertTriangle,
  FileText,
  KeyRound,
} from 'lucide-react';

export const SellerView: React.FC = () => {
  const {
    activeAuction,
    submitDeliveryEvidence,
  } = useAuction();

  // Delivery evidence form state
  const [evidenceType, setEvidenceType] = useState<
    'SHIPPING_CARRIER_API' | 'SOFTWARE_LICENSE_KEY_DIGEST' | 'COMPUTE_SLURM_RUN_DIGEST'
  >(
    activeAuction.category === 'COMPUTE_CAPACITY'
      ? 'COMPUTE_SLURM_RUN_DIGEST'
      : activeAuction.category === 'SOFTWARE_LICENSE'
        ? 'SOFTWARE_LICENSE_KEY_DIGEST'
        : 'SHIPPING_CARRIER_API'
  );
  const [carrierOrVerifier, setCarrierOrVerifier] = useState<string>('DHL Express Cargo / Bureau Veritas');
  const [trackingOrTokenDigest, setTrackingOrTokenDigest] = useState<string>(
    'sha256:d89204910fbb102948bb9210c4d812399120ff948123'
  );
  const [submittingEvidence, setSubmittingEvidence] = useState<boolean>(false);

  const handleSubmitEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingEvidence(true);
    try {
      await submitDeliveryEvidence(
        activeAuction.id,
        evidenceType,
        carrierOrVerifier,
        trackingOrTokenDigest
      );
    } finally {
      setSubmittingEvidence(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Seller Header */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Seller Protocol Console · Rule Versioning & Escrow Fulfillment
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              {activeAuction.title}
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Seller Entity: <span className="text-neutral-200">{activeAuction.sellerName}</span> · Rating: <span className="text-amber-400 font-mono">★ {activeAuction.sellerRating}</span> · Lifecycle Status: <span className="text-emerald-400 font-semibold">{activeAuction.status}</span>
            </p>
          </div>
          <div className="p-3 bg-neutral-900 border border-neutral-800 rounded font-mono text-xs">
            <div className="text-neutral-500 text-[10px]">RESERVE FLOOR</div>
            <div className="text-neutral-100 font-bold text-sm">${activeAuction.rules.reservePrice.toLocaleString()} {activeAuction.rules.currency}</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Published Rule Specifications & Immutability Proof */}
        <div className="lg:col-span-2 space-y-6">
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-display font-semibold text-neutral-100 flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-amber-400" />
                <span>Immutably Published Auction Rules ({activeAuction.rules.rulesVersion})</span>
              </h2>
              <span className="text-xs font-mono text-neutral-400">Rules Hash Anchored</span>
            </div>

            <div className="p-3 bg-black/50 border border-neutral-800 rounded font-mono text-xs space-y-1">
              <div className="text-neutral-500 text-[10px]">CANONICAL RULES DIGEST (SHA-256):</div>
              <div className="text-amber-300 break-all">{activeAuction.rules.rulesHash}</div>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Rules cannot be silently altered after publishing. The deterministic validation engine strictly validates that the replayed outcome respects this canonical rule hash.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 font-mono text-xs">
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">AUCTION MECHANISM</span>
                <span className="text-neutral-100 font-semibold">{activeAuction.rules.mechanism}</span>
              </div>
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">TIE-BREAKING POLICY</span>
                <span className="text-neutral-100 font-semibold">{activeAuction.rules.tieBreakingPolicy}</span>
              </div>
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">COMMITTEE QUORUM</span>
                <span className="text-neutral-100 font-semibold">{activeAuction.rules.quorumThresholdPercent}% Stake Weight</span>
              </div>
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">BUYER PROTOCOL FEE</span>
                <span className="text-neutral-100 font-semibold">{activeAuction.rules.buyerFeePercent}%</span>
              </div>
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">SELLER PROTOCOL FEE</span>
                <span className="text-neutral-100 font-semibold">{activeAuction.rules.sellerFeePercent}%</span>
              </div>
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded">
                <span className="text-neutral-500 text-[10px] block">VALIDATOR REWARD POOL</span>
                <span className="text-emerald-400 font-semibold">${activeAuction.rules.validatorFeeReward.toLocaleString()}</span>
              </div>
            </div>

            {/* Category-Specific Specifications */}
            {activeAuction.category === 'COMPUTE_CAPACITY' && activeAuction.computeSpecs && (
              <div className="pt-4 border-t border-neutral-800 space-y-3">
                <h3 className="text-sm font-display font-semibold text-neutral-200">
                  Compute Capacity SLA & Telemetry Specifications
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                  <div>Hardware Class: <span className="text-neutral-100 block">{activeAuction.computeSpecs.hardwareClass}</span></div>
                  <div>Host Memory: <span className="text-neutral-100 block">{activeAuction.computeSpecs.hostRamGb} GB DDR5</span></div>
                  <div>Interconnect: <span className="text-neutral-100 block">{activeAuction.computeSpecs.interconnect}</span></div>
                  <div>Available Period: <span className="text-neutral-100 block">{activeAuction.computeSpecs.availablePeriodHours} Hours (30 Days)</span></div>
                  <div>Uptime SLA: <span className="text-emerald-400 block">{activeAuction.computeSpecs.uptimeSlaPercent}%</span></div>
                  <div>Benchmark Target: <span className="text-amber-300 block">{activeAuction.computeSpecs.benchmarkTargetTflops.toLocaleString()} FP8 TFLOPS</span></div>
                </div>
              </div>
            )}

            {activeAuction.category === 'SOFTWARE_LICENSE' && activeAuction.licenseSpecs && (
              <div className="pt-4 border-t border-neutral-800 space-y-3">
                <h3 className="text-sm font-display font-semibold text-neutral-200">
                  Intellectual Property & Licensing Boundaries
                </h3>
                <div className="p-3 bg-amber-950/20 border border-amber-900/40 rounded text-xs text-neutral-300 space-y-2">
                  <div className="text-amber-400 font-semibold flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4" />
                    <span>License Rights Scope: {activeAuction.licenseSpecs.licenseGrantType}</span>
                  </div>
                  <p className="leading-relaxed">
                    {activeAuction.licenseSpecs.intellectualPropertyDisclaimer}
                  </p>
                  <div className="text-[11px] font-mono text-neutral-400 pt-1">
                    Permitted Deployments: {activeAuction.licenseSpecs.permittedDeployments} Clusters · Patent Covenant: {activeAuction.licenseSpecs.patentCovenant ? 'Enforced' : 'None'} · Digital Fingerprint: {activeAuction.licenseSpecs.digitalCertificateFingerprint.slice(0, 24)}...
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Post Delivery Evidence & Escrow Release */}
        <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-display font-semibold text-neutral-100 flex items-center gap-2">
              <UploadCloud className="w-4 h-4 text-amber-400" />
              <span>Post Delivery Evidence</span>
            </h3>
            <span className="text-xs font-mono text-neutral-400">Escrow Milestone</span>
          </div>

          <p className="text-xs text-neutral-400 leading-relaxed">
            Upon auction award and buyer settlement confirmation, post verifiable delivery evidence to initiate the buyer inspection window.
          </p>

          <form onSubmit={handleSubmitEvidence} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-neutral-400 mb-1">Evidence Type</label>
              <select
                value={evidenceType}
                onChange={e => setEvidenceType(e.target.value as any)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
              >
                <option value="SHIPPING_CARRIER_API">Carrier API Bill of Lading (Physical)</option>
                <option value="SOFTWARE_LICENSE_KEY_DIGEST">Cryptographic License Key Digest (Software)</option>
                <option value="COMPUTE_SLURM_RUN_DIGEST">Slurm / WireGuard Provisioning Token (Compute)</option>
              </select>
            </div>

            <div>
              <label className="block text-neutral-400 mb-1">Carrier or Verifier Entity</label>
              <input
                type="text"
                value={carrierOrVerifier}
                onChange={e => setCarrierOrVerifier(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
              />
            </div>

            <div>
              <label className="block text-neutral-400 mb-1">Tracking Token / Digest (SHA-256)</label>
              <input
                type="text"
                value={trackingOrTokenDigest}
                onChange={e => setTrackingOrTokenDigest(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={submittingEvidence}
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded transition-colors font-display"
            >
              {submittingEvidence ? 'Signing & Recording...' : 'Submit Evidence & Start Inspection Window'}
            </button>
          </form>

          {activeAuction.deliveryEvidence && (
            <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs space-y-1 font-mono">
              <div className="text-emerald-400 font-semibold">Active Delivery Record on Ledger:</div>
              <div className="text-neutral-300">Carrier: {activeAuction.deliveryEvidence.carrierOrVerifier}</div>
              <div className="text-neutral-400 truncate">Token: {activeAuction.deliveryEvidence.trackingOrTokenDigest}</div>
              <div className="text-neutral-500 text-[10px]">
                Inspection Cutoff: {activeAuction.deliveryEvidence.inspectionWindowExpiryIso.slice(0, 10)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
