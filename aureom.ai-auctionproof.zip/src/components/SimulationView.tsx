/**
 * Aureom.AI AuctionProof - Validator Network Stress & Failure Simulator
 * Compares Centralized verification vs Bonded Multi-Validator Network under
 * adversary collusion, network dropouts, equivocation, and Sybil concentration.
 */

import React, { useState } from 'react';
import { runValidatorSimulation, SimulationParams, SimulationResult } from '../services/simulationEngine';
import {
  Cpu,
  ShieldAlert,
  AlertTriangle,
  Play,
  RotateCw,
  TrendingDown,
  Scale,
  Zap,
  CheckCircle2,
  DollarSign,
} from 'lucide-react';

export const SimulationView: React.FC = () => {
  const [architecture, setArchitecture] = useState<'CENTRALIZED_PLATFORM' | 'BONDED_MULTI_VALIDATOR'>(
    'BONDED_MULTI_VALIDATOR'
  );
  const [attackVector, setAttackVector] = useState<SimulationParams['attackVector']>(
    'EQUIVOCATION_EXTORTION'
  );
  const [adversaryPercent, setAdversaryPercent] = useState<number>(33);
  const [networkDropoutPercent, setNetworkDropoutPercent] = useState<number>(10);
  const [committeeSize, setCommitteeSize] = useState<number>(5);
  const [runs, setRuns] = useState<number>(500);
  const [simulating, setSimulating] = useState<boolean>(false);

  const [result, setResult] = useState<SimulationResult>(() =>
    runValidatorSimulation({
      architecture: 'BONDED_MULTI_VALIDATOR',
      committeeSize: 5,
      totalNetworkValidators: 8,
      adversaryPercent: 33,
      networkDropoutPercent: 10,
      attackVector: 'EQUIVOCATION_EXTORTION',
      runs: 500,
    })
  );

  const handleRunSimulation = () => {
    setSimulating(true);
    setTimeout(() => {
      const res = runValidatorSimulation({
        architecture,
        committeeSize,
        totalNetworkValidators: 8,
        adversaryPercent,
        networkDropoutPercent,
        attackVector,
        runs,
      });
      setResult(res);
      setSimulating(false);
    }, 150);
  };

  return (
    <div className="space-y-6">
      {/* Simulation Header */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Empirical Consensus Stress Suite · Monte Carlo Validation
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              Centralized vs. Bonded Multi-Validator Resilience Matrix
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Tests safety, liveness, and economic slashing thresholds under Byzantine attack conditions.
            </p>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={simulating}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded transition-colors flex items-center gap-2 font-display"
          >
            {simulating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span>Execute Monte Carlo Stress Run ({runs} Iterations)</span>
          </button>
        </div>
      </div>

      {/* Control Panel Grid */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
        <h2 className="text-sm font-display font-semibold text-neutral-100">
          Simulation Parameters &amp; Attack Vectors
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {/* Architecture Selector */}
          <div>
            <label className="block text-neutral-400 mb-1">Architecture</label>
            <select
              value={architecture}
              onChange={e => setArchitecture(e.target.value as any)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 font-semibold"
            >
              <option value="BONDED_MULTI_VALIDATOR">Aureom.AI Bonded Committee (2/3 Quorum)</option>
              <option value="CENTRALIZED_PLATFORM">Centralized Platform Authority (Single Node)</option>
            </select>
          </div>

          {/* Attack Vector Selector */}
          <div>
            <label className="block text-neutral-400 mb-1">Simulated Attack Scenario</label>
            <select
              value={attackVector}
              onChange={e => setAttackVector(e.target.value as any)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
            >
              <option value="EQUIVOCATION_EXTORTION">Signed Equivocation (Double-Sign Extortion)</option>
              <option value="COLLUSIVE_WINNER_SPOOFING">Collusive Winner Spoofing (Cartel Bribes)</option>
              <option value="NETWORK_PARTITION">Network Partition &amp; Node Dropouts</option>
              <option value="OPERATOR_SYBIL_CONCENTRATION">Operator Sybil Concentration (Gini Surge)</option>
              <option value="NONE_HONEST">Honest Baseline (0% Adversary)</option>
            </select>
          </div>

          {/* Adversary Stake % Slider */}
          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Adversarial Stake:</span>
              <span className="text-amber-400 font-bold">{adversaryPercent}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              step="5"
              value={adversaryPercent}
              onChange={e => setAdversaryPercent(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
              <span>0% (Honest)</span>
              <span>33% (BFT Limit)</span>
              <span>60% (Cartel)</span>
            </div>
          </div>

          {/* Network Dropout % Slider */}
          <div>
            <div className="flex justify-between text-neutral-400 mb-1">
              <span>Node Dropout / Outage:</span>
              <span className="text-amber-400 font-bold">{networkDropoutPercent}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="5"
              value={networkDropoutPercent}
              onChange={e => setNetworkDropoutPercent(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
              <span>0% Normal</span>
              <span>25% Degradation</span>
              <span>50% Severe</span>
            </div>
          </div>
        </div>
      </div>

      {/* Results Dashboard Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 font-mono">
        {/* Metric 1: Incorrect Award Rate */}
        <div className={`p-4 rounded-lg border space-y-1 ${
          result.incorrectAwardRate > 0
            ? 'bg-red-950/30 border-red-800 text-red-200'
            : 'bg-[#12151c] border-neutral-800 text-neutral-100'
        }`}>
          <div className="text-[10px] text-neutral-500 uppercase">INCORRECT AWARD RATE</div>
          <div className={`text-xl font-bold ${result.incorrectAwardRate > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
            {result.incorrectAwardRate}%
          </div>
          <div className="text-[10px] text-neutral-400">
            {result.incorrectAwardRate === 0 ? 'Zero Invalid Outcomes' : 'Corrupt Award Breached'}
          </div>
        </div>

        {/* Metric 2: Consensus Availability */}
        <div className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1">
          <div className="text-[10px] text-neutral-500 uppercase">LIVENESS / AVAILABILITY</div>
          <div className="text-xl font-bold text-neutral-100">
            {result.availabilityRate}%
          </div>
          <div className="text-[10px] text-neutral-400">
            Quorum Certified
          </div>
        </div>

        {/* Metric 3: Dispute Escalation */}
        <div className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1">
          <div className="text-[10px] text-neutral-500 uppercase">DISPUTE ESCALATION</div>
          <div className="text-xl font-bold text-amber-400">
            {result.disputeEscalationRate}%
          </div>
          <div className="text-[10px] text-neutral-400">
            Arbitration Invoked
          </div>
        </div>

        {/* Metric 4: Slashed Bond Recovery */}
        <div className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1">
          <div className="text-[10px] text-neutral-500 uppercase">SLASHED BOND RECOVERY</div>
          <div className="text-xl font-bold text-emerald-400">
            ${(result.totalBondSlashedUsd / 1000).toFixed(0)}k
          </div>
          <div className="text-[10px] text-neutral-400">
            {result.slashingTriggeredCount} Nodes Penalized
          </div>
        </div>

        {/* Metric 5: Median Consensus Latency */}
        <div className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1">
          <div className="text-[10px] text-neutral-500 uppercase">MEDIAN LATENCY</div>
          <div className="text-xl font-bold text-neutral-200">
            {result.medianLatencyMs} ms
          </div>
          <div className="text-[10px] text-neutral-400">
            Deterministic Replay
          </div>
        </div>

        {/* Metric 6: Gini Concentration */}
        <div className="p-4 bg-[#12151c] border border-neutral-800 rounded-lg space-y-1">
          <div className="text-[10px] text-neutral-500 uppercase">GINI CONCENTRATION</div>
          <div className="text-xl font-bold text-neutral-200">
            {result.giniConcentration.toFixed(2)}
          </div>
          <div className="text-[10px] text-neutral-400">
            {result.giniConcentration >= 0.9 ? 'Monopoly Risk' : 'Distributed Committee'}
          </div>
        </div>
      </div>

      {/* Analysis & Economic Caveat Box */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
        <h3 className="text-sm font-display font-semibold text-neutral-100 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400" />
          <span>Consensus Resilience Analysis</span>
        </h3>

        <p className="text-xs text-neutral-300 leading-relaxed font-sans">
          {result.summaryAnalysis}
        </p>

        <div className="p-4 bg-amber-950/20 border border-amber-900/40 rounded space-y-2 text-xs">
          <div className="font-semibold text-amber-400 font-mono flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Core Economic Reality: Stake is not Proof of Honesty</span>
          </div>
          <ul className="space-y-1.5 text-neutral-300 list-disc list-inside">
            {result.caveatNotes.map((note, i) => (
              <li key={i}>{note}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
