/**
 * Aureom.AI AuctionProof - Guided 10-Step Demonstration View
 * Interactive execution of the 10 core verification workflows mandated in the specification.
 */

import React, { useState } from 'react';
import { useAuction, DEMO_STEPS } from '../context/AuctionContext';
import {
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  FileCheck,
  AlertTriangle,
  Lock,
  Eye,
  Scale,
  RefreshCw,
  Terminal,
} from 'lucide-react';

export const GuidedDemoView: React.FC = () => {
  const {
    activeDemoStep,
    executeDemoStep,
    demoLogs,
    activeAuction,
    lastReplayResult,
    setCurrentRole,
  } = useAuction();

  const [executing, setExecuting] = useState(false);

  const currentStepInfo = DEMO_STEPS.find(s => s.step === activeDemoStep) || DEMO_STEPS[0];

  const handleRunStep = async (stepNum: number) => {
    setExecuting(true);
    await executeDemoStep(stepNum);
    setExecuting(false);
  };

  const handleNext = async () => {
    if (activeDemoStep < 10) {
      await handleRunStep(activeDemoStep + 1);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Architectural Thesis Box */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800/80">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Deterministic Verification Architecture
            </div>
            <h1 className="text-xl md:text-2xl font-display font-bold text-neutral-100">
              10-Phase End-to-End AuctionProof Demonstration
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-neutral-400">
              Current Phase: <strong className="text-neutral-100">{activeDemoStep} of 10</strong>
            </span>
            <button
              onClick={() => handleRunStep(activeDemoStep)}
              disabled={executing}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-medium text-xs rounded transition-colors flex items-center gap-2 font-display"
            >
              {executing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              <span>{executing ? 'Executing Invariant Checks...' : currentStepInfo.actionLabel}</span>
            </button>
            {activeDemoStep < 10 && (
              <button
                onClick={handleNext}
                disabled={executing}
                className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded transition-colors flex items-center gap-1.5"
              >
                <span>Next</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* First Principles: What Validators Prove vs Cannot Prove */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 text-xs">
          <div className="p-3 bg-neutral-900/80 border border-emerald-950/60 rounded">
            <div className="font-semibold text-emerald-400 mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>What Independent Validators Mathematically Prove</span>
            </div>
            <p className="text-neutral-400 leading-relaxed">
              Receipt timestamps, cryptographic commit-reveal integrity, deposit adequacy, reserve rule compliance, anti-sniping window extensions, and exact deterministic Vickrey second-price calculations from immutable append-only event logs.
            </p>
          </div>
          <div className="p-3 bg-neutral-900/80 border border-amber-950/60 rounded">
            <div className="font-semibold text-amber-400 mb-1 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>What Validators Cannot Prove (Cryptographic Boundary)</span>
            </div>
            <p className="text-neutral-400 leading-relaxed">
              Validators cannot establish the physical condition of industrial machines, off-chain buyer cartels, secret side-agreements, or software IP title transfer merely by consensus. Ledger consensus is strictly isolated from marketplace judgement.
            </p>
          </div>
        </div>
      </div>

      {/* Step Navigation Bar */}
      <div className="border border-neutral-800 bg-[#0e1116] rounded-lg p-3 overflow-x-auto">
        <div className="flex items-center gap-2 min-w-max">
          {DEMO_STEPS.map(s => {
            const isCurrent = s.step === activeDemoStep;
            const isCompleted = s.step < activeDemoStep;
            return (
              <button
                key={s.step}
                onClick={() => handleRunStep(s.step)}
                className={`flex items-center gap-2 px-3 py-2 rounded text-xs transition-colors ${
                  isCurrent
                    ? 'bg-amber-400/10 border border-amber-500/50 text-amber-300 font-semibold shadow-xs'
                    : isCompleted
                      ? 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800/80 border border-neutral-800'
                      : 'bg-neutral-950 text-neutral-500 hover:text-neutral-300 border border-neutral-900'
                }`}
              >
                <span
                  className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[11px] ${
                    isCurrent
                      ? 'bg-amber-400 text-neutral-950 font-bold'
                      : isCompleted
                        ? 'bg-neutral-700 text-neutral-200'
                        : 'bg-neutral-800 text-neutral-500'
                  }`}
                >
                  {s.step}
                </span>
                <span className="truncate max-w-[130px]">{s.title.split(' ')[0]} {s.title.split(' ')[1]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Phase Details & State Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Phase Inspector */}
        <div className="lg:col-span-2 space-y-6">
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-amber-400 uppercase tracking-wider">
                Phase {currentStepInfo.step} Execution Brief
              </span>
              <span className="text-xs font-mono text-neutral-400">
                Target: {activeAuction.title}
              </span>
            </div>

            <h2 className="text-xl font-display font-semibold text-neutral-100">
              {currentStepInfo.title}
            </h2>

            <p className="text-sm text-neutral-300 leading-relaxed">
              {currentStepInfo.description}
            </p>

            {/* Contextual Phase Data Display */}
            {activeDemoStep === 1 && (
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded font-mono text-xs space-y-2">
                <div className="text-neutral-400"># Canonical Rule Hash Digest (SHA-256):</div>
                <div className="text-amber-300 break-all bg-black/40 p-2 rounded">
                  {activeAuction.rules.rulesHash}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 text-neutral-300">
                  <div>Mechanism: <span className="text-neutral-100">{activeAuction.rules.mechanism}</span></div>
                  <div>Reserve Price: <span className="text-neutral-100">${activeAuction.rules.reservePrice.toLocaleString()}</span></div>
                  <div>Committee Size: <span className="text-neutral-100">{activeAuction.rules.committeeSize} Nodes</span></div>
                  <div>Deposit Required: <span className="text-neutral-100">${activeAuction.rules.depositRequiredAmount.toLocaleString()}</span></div>
                  <div>Quorum Threshold: <span className="text-neutral-100">{activeAuction.rules.quorumThresholdPercent}% Stake</span></div>
                  <div>Unrevealed Penalty: <span className="text-red-400">{activeAuction.rules.unrevealedPenaltyPercent}% Forfeiture</span></div>
                </div>
              </div>
            )}

            {activeDemoStep === 4 && (
              <div className="space-y-3">
                <div className="text-xs font-mono text-neutral-400">Sealed Commitments Recorded in Ledger (Zero Plaintext Exposed):</div>
                <div className="space-y-2">
                  {activeAuction.commitments.map(c => (
                    <div key={c.commitmentHash} className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs font-mono space-y-1">
                      <div className="flex items-center justify-between text-neutral-200">
                        <span className="font-semibold text-neutral-100">{c.bidderName}</span>
                        <span className="text-amber-400">Receipt #{c.receiptSequenceId}</span>
                      </div>
                      <div className="text-neutral-400 truncate">
                        Commitment: <span className="text-neutral-300">{c.commitmentHash}</span>
                      </div>
                      <div className="text-neutral-500 text-[11px] flex gap-3">
                        <span>Deposit: ${c.depositLockedAmount.toLocaleString()} Locked</span>
                        <span>·</span>
                        <span>Status: <span className="text-emerald-400">{c.status}</span></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeDemoStep === 5 && (
              <div className="space-y-3">
                <div className="text-xs font-mono text-neutral-400">Revealed Cryptographic Payloads & Hashes:</div>
                <div className="space-y-2">
                  {activeAuction.commitments
                    .filter(c => c.status === 'REVEALED')
                    .map(c => (
                      <div key={c.commitmentHash} className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs font-mono space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-neutral-100">{c.bidderName}</span>
                          <span className="text-emerald-400 font-bold text-sm">
                            ${c.revealedPayload?.amount.toLocaleString()} {c.revealedPayload?.currency}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-400 break-all bg-black/40 p-2 rounded">
                          {c.revealedPayload?.rawCanonicalString}
                        </div>
                        <div className="text-[11px] text-neutral-500 flex items-center justify-between">
                          <span>Secret Nonce: {c.revealedPayload?.secretNonce.slice(0, 20)}...</span>
                          <span className="text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Hash Match Confirmed
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {activeDemoStep === 6 && (
              <div className="p-4 bg-red-950/20 border border-red-900/60 rounded space-y-3">
                <div className="flex items-center gap-2 text-red-400 font-semibold text-xs font-mono">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Reveal Window Expiration & Penalty Execution</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Bidder <strong className="text-neutral-100">Apex Strategic Reserves Corp</strong> submitted a valid commitment hash prior to the commitment deadline, but failed to broadcast their secret nonce before the 13:00:00Z reveal cutoff.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono text-xs pt-1">
                  <div className="p-2 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-neutral-500 text-[10px]">LOCKED DEPOSIT</div>
                    <div className="text-neutral-200 font-bold">$10,000 USD</div>
                  </div>
                  <div className="p-2 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-red-400 text-[10px]">STATUTORY PENALTY (20%)</div>
                    <div className="text-red-400 font-bold">-$2,000 to Slashing Pool</div>
                  </div>
                  <div className="p-2 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-emerald-400 text-[10px]">REFUND RELEASED</div>
                    <div className="text-emerald-400 font-bold">$8,000 Returned</div>
                  </div>
                </div>
              </div>
            )}

            {activeDemoStep === 7 && lastReplayResult && (
              <div className="space-y-3">
                <div className="text-xs font-mono text-neutral-400">Independent Replay Output & Invariant Checks:</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
                  <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-neutral-500 text-[10px]">AWARDED WINNER</div>
                    <div className="text-neutral-100 font-bold truncate">{lastReplayResult.winnerBidderName?.split(' ')[0]}</div>
                  </div>
                  <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-neutral-500 text-[10px]">HIGHEST BID</div>
                    <div className="text-neutral-100 font-bold">${lastReplayResult.highBidAmount.toLocaleString()}</div>
                  </div>
                  <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-amber-400 text-[10px]">VICKREY CLEARING PRICE</div>
                    <div className="text-amber-300 font-bold">${lastReplayResult.clearingPrice.toLocaleString()}</div>
                  </div>
                  <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded">
                    <div className="text-neutral-500 text-[10px]">SECOND-HIGHEST BID</div>
                    <div className="text-neutral-100 font-bold">${lastReplayResult.secondHighestBidAmount.toLocaleString()}</div>
                  </div>
                </div>

                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded space-y-1.5 text-xs">
                  <div className="font-mono text-neutral-400 font-semibold">Verification Invariants Checked:</div>
                  {lastReplayResult.checks.map((chk, i) => (
                    <div key={i} className="flex items-start gap-2 text-neutral-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-neutral-200">{chk.step}: </span>
                        <span className="text-neutral-400">{chk.details}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeDemoStep === 8 && (
              <div className="p-4 bg-amber-950/20 border border-amber-900/60 rounded space-y-3">
                <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs font-mono">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Objective Signed Equivocation Detected & Slashed</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Validator node <strong className="text-neutral-100">Apex Rogue Adversary Node (val-rogue-sim)</strong> broadcasted two conflicting signed outcome attestations for auction <code className="text-amber-400">{activeAuction.id}</code> with different clearing prices ($54,000 vs $59,200).
                </p>
                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded font-mono text-xs space-y-1">
                  <div className="text-neutral-400">Slashing Protocol Trigger:</div>
                  <div className="text-emerald-400">✓ Cryptographic proof: Dual contradictory signatures under same public key.</div>
                  <div className="text-red-400">✗ Penalty applied: $50,000 bonded collateral slashed to SLASHING_PENALTY_POOL.</div>
                  <div className="text-neutral-400">✓ Node status transitioned to <span className="text-red-400 font-bold">SLASHED</span>; reputation degraded.</div>
                </div>
              </div>
            )}

            {activeDemoStep === 9 && (
              <div className="space-y-3">
                <div className="text-xs font-mono text-neutral-400">Quorum Certificate & Financial Settlement:</div>
                <div className="p-4 bg-neutral-900 border border-neutral-800 rounded font-mono text-xs space-y-2">
                  <div className="flex items-center justify-between text-neutral-200">
                    <span>Quorum Certificate Digest:</span>
                    <span className="text-emerald-400">✓ 85.7% Supporting Stake Consensus</span>
                  </div>
                  <div className="text-neutral-400 break-all bg-black/40 p-2 rounded">
                    {activeAuction.quorumCertificate?.qcDigest || 'QC_auc-compute-h100-vickrey_1700000_59200'}
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 text-neutral-300 text-xs">
                    <div>Winning Bidder: <span className="text-neutral-100">DeepSynthetix</span></div>
                    <div>Clearing Price: <span className="text-amber-400 font-bold">$59,200</span></div>
                    <div>Buyer Protocol Fee: <span className="text-neutral-100">$888 (1.5%)</span></div>
                    <div>Seller Fee: <span className="text-neutral-100">$1,184 (2.0%)</span></div>
                    <div>Validator Reward: <span className="text-emerald-400 font-bold">$1,200 Pool</span></div>
                    <div>Seller Net: <span className="text-neutral-100">$58,016</span></div>
                  </div>
                </div>
              </div>
            )}

            {activeDemoStep === 10 && (
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-amber-400 font-semibold">Delivery Dispute & Arbitration Review</span>
                  <button
                    onClick={() => setCurrentRole('DISPUTES')}
                    className="text-xs px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded hover:bg-amber-500/30 transition-colors"
                  >
                    Open Dispute Panel →
                  </button>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Auction <strong className="text-neutral-100">auc-autonav-license-firstprice</strong> (AeroNav Perception Engine v4.8) is disputed: buyer reported license validation failure on 3 edge clusters. Escrow funds remain frozen until independent code audit or arbitrator vote.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Live Append-Only Activity Log */}
        <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-5 flex flex-col h-[520px]">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2 text-xs font-mono text-neutral-200">
              <Terminal className="w-4 h-4 text-amber-400" />
              <span>Verifiable Event Log Stream</span>
            </div>
            <span className="text-[10px] font-mono text-neutral-500">{demoLogs.length} events</span>
          </div>

          <div className="flex-1 overflow-y-auto pt-3 space-y-2 text-[11px] font-mono">
            {demoLogs.map((log, idx) => (
              <div
                key={idx}
                className={`p-2 rounded leading-relaxed ${
                  log.includes('SLASHING') || log.includes('ALERT')
                    ? 'bg-red-950/30 border border-red-900/50 text-red-300'
                    : log.includes('DEMO STEP')
                      ? 'bg-amber-950/20 border border-amber-900/40 text-amber-300'
                      : log.includes('revealed') || log.includes('confirmed')
                        ? 'bg-emerald-950/20 border border-emerald-900/30 text-emerald-300'
                        : 'bg-neutral-900/80 text-neutral-400 border border-neutral-800/60'
                }`}
              >
                {log}
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-neutral-800 text-[10px] text-neutral-500 font-mono flex items-center justify-between">
            <span>Merkle Chain: Verified</span>
            <span>Canonical Encoding: V1</span>
          </div>
        </div>
      </div>
    </div>
  );
};
