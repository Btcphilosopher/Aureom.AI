/**
 * Aureom.AI AuctionProof - Buyer / Bidder Interface
 * English ascending bids, cryptographic commit-reveal generator,
 * high-entropy nonce management, and downloadable bid receipts.
 */

import React, { useState, useEffect } from 'react';
import { useAuction } from '../context/AuctionContext';
import {
  Lock,
  Eye,
  Key,
  ShieldAlert,
  Download,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  TrendingUp,
} from 'lucide-react';
import {
  buildCanonicalCommitmentString,
  computeCommitmentHash,
  generateSecureNonce,
  verifyBidReveal,
} from '../utils/crypto';

export const BuyerView: React.FC = () => {
  const {
    activeAuction,
    placeEnglishBid,
    submitSealedCommitment,
    revealSealedBid,
  } = useAuction();

  // English Bid State
  const currentHigh = activeAuction.currentHighBid || activeAuction.rules.reservePrice;
  const minNextBid = currentHigh + activeAuction.rules.minBidIncrement;
  const [englishAmount, setEnglishAmount] = useState<number>(minNextBid);
  const [englishBidderName, setEnglishBidderName] = useState<string>('Apex Strategic Industrial');
  const [englishPlacing, setEnglishPlacing] = useState<boolean>(false);

  // Sealed Bid Generator State
  const [bidderId, setBidderId] = useState<string>('bidder-quantum');
  const [bidderName, setBidderName] = useState<string>('Quantum Horizon Compute LLC');
  const [sealedAmount, setSealedAmount] = useState<number>(activeAuction.rules.reservePrice + 5000);
  const [currency, setCurrency] = useState<string>(activeAuction.rules.currency);
  const [conditionsDigest, setConditionsDigest] = useState<string>('COND_STANDARD_TERMS_V1');
  const [secretNonce, setSecretNonce] = useState<string>('');
  const [calculatedHash, setCalculatedHash] = useState<string>('');
  const [canonicalString, setCanonicalString] = useState<string>('');
  const [commitmentSubmitting, setCommitmentSubmitting] = useState<boolean>(false);
  const [copiedNonce, setCopiedNonce] = useState<boolean>(false);
  const [receiptSaved, setReceiptSaved] = useState<boolean>(false);

  // Reveal State
  const [revealCommitmentHash, setRevealCommitmentHash] = useState<string>('');
  const [revealAmount, setRevealAmount] = useState<number>(0);
  const [revealNonce, setRevealNonce] = useState<string>('');
  const [revealStatusMsg, setRevealStatusMsg] = useState<string>('');
  const [revealing, setRevealing] = useState<boolean>(false);

  // Generate initial random nonce on mount
  useEffect(() => {
    handleRegenerateNonce();
  }, []);

  const handleRegenerateNonce = () => {
    const nonce = generateSecureNonce();
    setSecretNonce(nonce);
  };

  // Recalculate hash whenever input parameters change
  useEffect(() => {
    if (!secretNonce) return;
    const str = buildCanonicalCommitmentString({
      auctionId: activeAuction.id,
      bidderId,
      amount: sealedAmount,
      currency,
      conditionsDigest,
      nonce: secretNonce,
    });
    setCanonicalString(str);

    computeCommitmentHash({
      auctionId: activeAuction.id,
      bidderId,
      amount: sealedAmount,
      currency,
      conditionsDigest,
      nonce: secretNonce,
    }).then(setCalculatedHash);
  }, [activeAuction.id, bidderId, sealedAmount, currency, conditionsDigest, secretNonce]);

  const handleCopyNonce = () => {
    navigator.clipboard.writeText(secretNonce);
    setCopiedNonce(true);
    setTimeout(() => setCopiedNonce(false), 2000);
  };

  const handleDownloadSecretReceipt = () => {
    const payload = {
      notice: 'CONFIDENTIAL AUREOM.AI AUCTIONPROOF SECRET RECEIPT. DO NOT SHARE UNTIL REVEAL WINDOW OPENS.',
      auctionId: activeAuction.id,
      auctionTitle: activeAuction.title,
      bidderId,
      bidderName,
      bidAmount: sealedAmount,
      currency,
      conditionsDigest,
      secretNonce,
      commitmentHash: calculatedHash,
      canonicalString,
      timestampUtc: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AuctionProof_Receipt_${activeAuction.id}_${bidderId}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setReceiptSaved(true);
  };

  const handleSubmitCommitment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!secretNonce) return;
    setCommitmentSubmitting(true);
    try {
      await submitSealedCommitment(
        activeAuction.id,
        bidderId,
        bidderName,
        sealedAmount,
        currency,
        conditionsDigest,
        secretNonce
      );
      setReceiptSaved(false);
      handleRegenerateNonce();
    } finally {
      setCommitmentSubmitting(false);
    }
  };

  const handlePlaceEnglish = async (e: React.FormEvent) => {
    e.preventDefault();
    setEnglishPlacing(true);
    try {
      await placeEnglishBid(activeAuction.id, 'bidder-manual-01', englishBidderName, englishAmount);
      setEnglishAmount(englishAmount + activeAuction.rules.minBidIncrement);
    } finally {
      setEnglishPlacing(false);
    }
  };

  const handleExecuteReveal = async (e: React.FormEvent) => {
    e.preventDefault();
    setRevealing(true);
    setRevealStatusMsg('');
    try {
      const res = await revealSealedBid(
        activeAuction.id,
        bidderId,
        revealAmount,
        currency,
        conditionsDigest,
        revealNonce
      );
      setRevealStatusMsg(res.message);
    } finally {
      setRevealing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Overview Banner */}
      <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase text-amber-400 tracking-wider mb-1">
              Bidder Portal · Authoritative Auction Clock Active
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-100">
              {activeAuction.title}
            </h1>
            <p className="text-xs text-neutral-400 mt-1">
              Category: <span className="text-neutral-200">{activeAuction.category}</span> · Mechanism: <span className="text-amber-400 font-semibold">{activeAuction.rules.mechanism.replace(/_/g, ' ')}</span> · Required Deposit: <span className="text-neutral-200 font-mono">${activeAuction.rules.depositRequiredAmount.toLocaleString()}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-right font-mono text-xs">
              <div className="text-neutral-500 text-[10px]">CURRENT MIN RESERVE</div>
              <div className="text-neutral-100 font-bold text-sm">${activeAuction.rules.reservePrice.toLocaleString()} {activeAuction.rules.currency}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Mechanism-Specific Bidding Panels */}
      {activeAuction.rules.mechanism === 'ENGLISH' ? (
        /* English Ascending Auction View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-display font-semibold text-neutral-100 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-amber-400" />
                  <span>Place Ascending English Bid</span>
                </h2>
                <span className="text-xs font-mono text-neutral-400">
                  Min Increment: +${activeAuction.rules.minBidIncrement.toLocaleString()}
                </span>
              </div>

              {activeAuction.rules.antiSnipingWindowSeconds > 0 && (
                <div className="p-3 bg-amber-950/20 border border-amber-900/60 rounded text-xs text-amber-300">
                  <strong>Defensive Anti-Sniping Active:</strong> Any bid placed within {activeAuction.rules.antiSnipingWindowSeconds}s of the deadline automatically extends the closing clock by {activeAuction.rules.antiSnipingExtensionSeconds}s to eradicate latency front-running.
                </div>
              )}

              <form onSubmit={handlePlaceEnglish} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                  <div>
                    <label className="block text-neutral-400 mb-1">Bidder Entity Name</label>
                    <input
                      type="text"
                      value={englishBidderName}
                      onChange={e => setEnglishBidderName(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-400 mb-1">Your Bid Amount (USD)</label>
                    <input
                      type="number"
                      min={minNextBid}
                      step={activeAuction.rules.minBidIncrement}
                      value={englishAmount}
                      onChange={e => setEnglishAmount(Number(e.target.value))}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 font-bold focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-neutral-400">
                    Buyer Protocol Fee (1.5%): <span className="font-mono text-neutral-200">${Math.round(englishAmount * 0.015).toLocaleString()}</span>
                  </div>
                  <button
                    type="submit"
                    disabled={englishPlacing || englishAmount < minNextBid}
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded transition-colors font-display"
                  >
                    {englishPlacing ? 'Broadcasting...' : `Submit Ascending Bid ($${englishAmount.toLocaleString()})`}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Col: Accepted Bids Order Book */}
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-5">
            <h3 className="text-sm font-display font-semibold text-neutral-100 mb-3">
              Authoritative Bid Sequence Log
            </h3>
            <div className="space-y-2 text-xs font-mono max-h-[420px] overflow-y-auto">
              {activeAuction.englishBids.length === 0 ? (
                <div className="text-neutral-500 py-6 text-center">No bids recorded yet.</div>
              ) : (
                activeAuction.englishBids.map((b, i) => (
                  <div
                    key={b.bidId}
                    className={`p-3 rounded border ${
                      i === 0
                        ? 'bg-amber-950/20 border-amber-500/50 text-amber-200'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span>${b.amount.toLocaleString()}</span>
                      <span className="text-[11px] text-neutral-400">#{b.receiptSequenceId}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-1 truncate">{b.bidderName}</div>
                    {b.extensionTriggered && (
                      <div className="text-[10px] text-amber-400 mt-1">Clock extended by 5m</div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Sealed Bid (Commit-Reveal) Interface */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Commit Generator */}
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-display font-semibold text-neutral-100 flex items-center gap-2">
                <Lock className="w-5 h-5 text-amber-400" />
                <span>Sealed Bid Commitment Generator</span>
              </h2>
              <span className="text-xs font-mono text-emerald-400">Domain: AUCTIONPROOF_COMMIT_V1</span>
            </div>

            <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs text-neutral-400 space-y-1">
              <div className="font-semibold text-neutral-200 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>Confidentiality & Nonce Entropy Architecture</span>
              </div>
              <p>
                To prevent dictionary guessing attacks against round numbers (e.g. $50,000), a 256-bit cryptographically secure nonce is bound to your bid before hashing. Plaintext amounts are NEVER broadcast to the network until the reveal window opens.
              </p>
            </div>

            <form onSubmit={handleSubmitCommitment} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                <div>
                  <label className="block text-neutral-400 mb-1">Bidder ID</label>
                  <input
                    type="text"
                    value={bidderId}
                    onChange={e => setBidderId(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Bidder Entity Legal Name</label>
                  <input
                    type="text"
                    value={bidderName}
                    onChange={e => setBidderName(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Confidential Bid Amount ({currency})</label>
                  <input
                    type="number"
                    min={activeAuction.rules.reservePrice}
                    step={100}
                    value={sealedAmount}
                    onChange={e => setSealedAmount(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Conditions Digest</label>
                  <input
                    type="text"
                    value={conditionsDigest}
                    onChange={e => setConditionsDigest(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100"
                  />
                </div>
              </div>

              {/* Secret Nonce Field */}
              <div className="space-y-1 font-mono text-xs">
                <div className="flex items-center justify-between text-neutral-400">
                  <label>256-Bit Cryptographic Secret Nonce (High Entropy)</label>
                  <button
                    type="button"
                    onClick={handleRegenerateNonce}
                    className="text-amber-400 hover:text-amber-300 text-[11px] underline"
                  >
                    Regenerate Nonce
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={secretNonce}
                    className="flex-1 bg-black/60 border border-neutral-800 rounded px-3 py-2 text-amber-300 font-mono text-[11px]"
                  />
                  <button
                    type="button"
                    onClick={handleCopyNonce}
                    className="p-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded text-xs"
                    title="Copy secret nonce"
                  >
                    {copiedNonce ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Calculated Commitment Hash Display */}
              <div className="p-3 bg-black/40 border border-neutral-800 rounded font-mono text-xs space-y-1">
                <div className="text-neutral-500 text-[10px]">PUBLIC COMMITMENT HASH (SHA-256):</div>
                <div className="text-emerald-400 break-all">{calculatedHash}</div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownloadSecretReceipt}
                  className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs rounded border border-neutral-700 flex items-center gap-1.5 font-mono"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{receiptSaved ? 'Secret Receipt Saved ✓' : 'Save Secret Receipt JSON'}</span>
                </button>

                <button
                  type="submit"
                  disabled={commitmentSubmitting}
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded font-display"
                >
                  {commitmentSubmitting
                    ? 'Locking Escrow...'
                    : `Lock $${activeAuction.rules.depositRequiredAmount.toLocaleString()} & Broadcast Commitment`}
                </button>
              </div>
            </form>
          </div>

          {/* Reveal Tool */}
          <div className="border border-neutral-800 bg-[#12151c] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-display font-semibold text-neutral-100 flex items-center gap-2">
                <Eye className="w-5 h-5 text-amber-400" />
                <span>Reveal Sealed Bid Tool</span>
              </h2>
              <span className="text-xs font-mono text-neutral-400">Phase: Reveal Window</span>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              When the reveal window opens, submit your plaintext bid amount and secret nonce. The deterministic engine will reconstruct the canonical string and verify the hash before qualifying your bid.
            </p>

            <form onSubmit={handleExecuteReveal} className="space-y-4">
              <div className="space-y-3 font-mono text-xs">
                <div>
                  <label className="block text-neutral-400 mb-1">Plaintext Bid Amount ({currency})</label>
                  <input
                    type="number"
                    required
                    value={revealAmount || ''}
                    onChange={e => setRevealAmount(Number(e.target.value))}
                    placeholder="e.g. 64800"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-neutral-100 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Secret Nonce (64 Hex Characters)</label>
                  <input
                    type="text"
                    required
                    value={revealNonce}
                    onChange={e => setRevealNonce(e.target.value)}
                    placeholder="Enter secret nonce from saved receipt"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-amber-300 font-mono text-xs"
                  />
                </div>
              </div>

              {revealStatusMsg && (
                <div
                  className={`p-3 rounded text-xs font-mono ${
                    revealStatusMsg.includes('success') || revealStatusMsg.includes('verified')
                      ? 'bg-emerald-950/30 text-emerald-300 border border-emerald-900'
                      : 'bg-red-950/30 text-red-300 border border-red-900'
                  }`}
                >
                  {revealStatusMsg}
                </div>
              )}

              <button
                type="submit"
                disabled={revealing || !revealAmount || !revealNonce}
                className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-semibold text-xs rounded border border-neutral-700 transition-colors"
              >
                {revealing ? 'Verifying Hash Match...' : 'Broadcast Bid Reveal to Ledger'}
              </button>
            </form>

            {/* Non-Reveal Policy Warning */}
            <div className="p-3 bg-red-950/20 border border-red-900/60 rounded text-xs text-neutral-300 space-y-1">
              <div className="font-semibold text-red-400 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Statutory Non-Reveal Penalty Policy</span>
              </div>
              <p>
                Failing to reveal your commitment before the deadline forfeits <strong className="text-red-400">{activeAuction.rules.unrevealedPenaltyPercent}%</strong> of your deposit (${((activeAuction.rules.depositRequiredAmount * activeAuction.rules.unrevealedPenaltyPercent) / 100).toLocaleString()}) to the slashing pool and disqualifies the bid.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
