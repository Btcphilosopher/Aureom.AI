/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuctionProvider, useAuction } from './context/AuctionContext';
import { Navbar } from './components/Navbar';
import { GuidedDemoView } from './components/GuidedDemoView';
import { BuyerView } from './components/BuyerView';
import { SellerView } from './components/SellerView';
import { ValidatorView } from './components/ValidatorView';
import { EscrowView } from './components/EscrowView';
import { DisputesView } from './components/DisputesView';
import { AuditorView } from './components/AuditorView';
import { SimulationView } from './components/SimulationView';
import { ComputeTelemetryPanel } from './components/ComputeTelemetryPanel';

const AppContent: React.FC = () => {
  const { currentRole, activeAuction } = useAuction();

  return (
    <div className="min-h-screen flex flex-col bg-[#0d0f12] text-neutral-100 antialiased selection:bg-amber-500/30 selection:text-amber-200">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Render Active Role View */}
        {currentRole === 'DEMO' && (
          <>
            <GuidedDemoView />
            {activeAuction.category === 'COMPUTE_CAPACITY' && <ComputeTelemetryPanel />}
          </>
        )}
        {currentRole === 'BUYER' && (
          <>
            <BuyerView />
            {activeAuction.category === 'COMPUTE_CAPACITY' && <ComputeTelemetryPanel />}
          </>
        )}
        {currentRole === 'SELLER' && (
          <>
            <SellerView />
            {activeAuction.category === 'COMPUTE_CAPACITY' && <ComputeTelemetryPanel />}
          </>
        )}
        {currentRole === 'VALIDATOR' && <ValidatorView />}
        {currentRole === 'SETTLEMENT' && <EscrowView />}
        {currentRole === 'DISPUTES' && <DisputesView />}
        {currentRole === 'AUDITOR' && <AuditorView />}
        {currentRole === 'SIMULATION' && <SimulationView />}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 bg-[#0c0e12] py-6 text-xs text-neutral-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-neutral-300 font-bold font-display">Aureom.AI AuctionProof</span>
            <span aria-hidden="true">·</span>
            <span>Canonical Commit-Reveal Protocol V1</span>
            <span aria-hidden="true">·</span>
            <span>Vickrey Second-Price &amp; English Engine</span>
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <span>Deterministic Replay: Active</span>
            <span aria-hidden="true">·</span>
            <span>Double-Entry Escrow: Verified</span>
            <span aria-hidden="true">·</span>
            <span>Quorum: 2/3 Stake Weight</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuctionProvider>
      <AppContent />
    </AuctionProvider>
  );
}
