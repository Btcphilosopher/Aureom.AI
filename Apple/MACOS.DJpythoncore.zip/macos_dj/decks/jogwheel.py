"""Jog wheel abstraction: scratch and pitch-bend input translated to
deck transport deltas.

Hardware jog wheels report relative rotation ticks; this module converts
those ticks into either a scratch (temporary direct position control) or
a pitch-bend nudge (temporary speed offset), depending on touch state.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class JogMode(Enum):
    VINYL = auto()   # touch = scratch, release = pitch bend on the rim
    CDJ = auto()      # touch has no effect, rim always bends pitch


@dataclass
class JogWheelState:
    touched: bool = False
    mode: JogMode = JogMode.VINYL
    ticks_per_revolution: int = 800
    scratch_sensitivity: float = 1.0
    bend_sensitivity: float = 0.02  # max pitch bend fraction at full rim speed


class JogWheel:
    """Translates raw rotation ticks into deck control deltas.

    `process_tick` returns either a `("scratch_seconds", delta)` or a
    `("pitch_bend", fraction)` instruction for the owning deck to apply;
    it does not touch deck state directly so it stays trivially testable.
    """

    def __init__(self, state: JogWheelState | None = None) -> None:
        self.state = state or JogWheelState()

    def set_touched(self, touched: bool) -> None:
        self.state.touched = touched

    def set_mode(self, mode: JogMode) -> None:
        self.state.mode = mode

    def process_tick(self, ticks: int, bpm: float = 120.0) -> tuple[str, float]:
        revolutions = ticks / self.state.ticks_per_revolution

        if self.state.mode is JogMode.VINYL and self.state.touched:
            # Scratching: 1 revolution ~= 1 beat's worth of movement, a
            # reasonable approximation for a standard 8"/12" jog wheel feel.
            beat_seconds = 60.0 / max(bpm, 1e-6)
            delta_seconds = revolutions * beat_seconds
            return ("scratch_seconds", delta_seconds)

        # Rim bend (CDJ mode, or vinyl mode released).
        bend_fraction = revolutions * self.state.bend_sensitivity * 50
        bend_fraction = max(-0.5, min(0.5, bend_fraction))
        return ("pitch_bend", bend_fraction)
