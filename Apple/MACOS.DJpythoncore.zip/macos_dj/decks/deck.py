"""The professional deck abstraction.

`Deck` is a state machine (backed by `Transport`) that owns a loaded
track, its playback cursor (`TrackPlayer`), beatgrid, pitch, EQ, filter,
cue point, loop engine, and hot cue bank. It exposes the DJ command verbs
(PLAY, PAUSE, STOP, CUE, SEEK, PITCH, PITCH_RESET, LOOP, LOOP_EXIT,
HOT_CUE, SYNC) as methods, each of which publishes an `Event` so the UI
and other decks (sync) can react without a direct reference to this
object.

`process_block` is the only method meant to be called from (or adjacent
to) the audio callback -- it does no allocation beyond what
`TrackPlayer`/`ThreeBandEQ`/`ResonantFilter` already preallocate, and it
touches no database, disk, or logging on that path.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from macos_dj.analysis.beatgrid import BeatGrid
from macos_dj.audio.player import TrackPlayer
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger
from macos_dj.decks.cue import CueManager
from macos_dj.decks.hotcue import HotCueBank, HotCueType
from macos_dj.decks.loop import LoopEngine
from macos_dj.decks.transport import InvalidTransportTransition, Transport, TransportState
from macos_dj.dsp.eq import ThreeBandEQ
from macos_dj.dsp.filter import ResonantFilter
from macos_dj.dsp.gain import Gain
from macos_dj.library.tracks import Track

logger = get_logger(__name__)

DEFAULT_PITCH_RANGE = 0.08  # +/- 8%


@dataclass
class DeckParameters:
    """Snapshot of everything the UI / session serialiser needs about a deck."""

    deck_id: str
    track_id: Optional[str] = None
    playing: bool = False
    position_seconds: float = 0.0
    bpm: Optional[float] = None
    pitch: float = 0.0
    pitch_range: float = DEFAULT_PITCH_RANGE
    gain_db: float = 0.0
    eq_low_db: float = 0.0
    eq_mid_db: float = 0.0
    eq_high_db: float = 0.0
    filter_position: float = 0.0
    is_master: bool = False


class Deck:
    def __init__(self, deck_id: str, sample_rate: int = 44100, channels: int = 2, event_bus: Optional[EventBus] = None) -> None:
        self.deck_id = deck_id
        self.sample_rate = sample_rate
        self.channels = channels
        self.events = event_bus or global_event_bus

        self.transport = Transport()
        self.player = TrackPlayer()
        self.cue = CueManager()
        self.loop = LoopEngine()
        self.hotcues = HotCueBank()
        self.eq = ThreeBandEQ(sample_rate=sample_rate, channels=channels)
        self.filter = ResonantFilter(sample_rate=sample_rate, channels=channels)
        self.gain = Gain()

        self.track: Optional[Track] = None
        self.beatgrid: Optional[BeatGrid] = None

        self._pitch = 0.0  # -1.0..+1.0 fraction of pitch_range
        self._pitch_range = DEFAULT_PITCH_RANGE
        self._pitch_bend = 0.0  # transient jog-wheel bend, added on top
        self.is_master = False
        self._sync_source: Optional["Deck"] = None

    # --- Loading --------------------------------------------------------

    def load_track(self, track: Track, samples: np.ndarray, sample_rate: int) -> None:
        self.track = track
        self.beatgrid = track.beatgrid
        self.player.load_decoded(samples, sample_rate)
        self.loop.set_beatgrid(self.beatgrid) if self.beatgrid else None
        self.cue.clear()
        self.hotcues.clear_all()
        self.transport.load()
        self.events.emit(EventType.TRACK_LOADED, source=self.deck_id, deck_id=self.deck_id, track_id=track.id)

    def eject(self) -> None:
        self.track = None
        self.beatgrid = None
        self.player = TrackPlayer(stretcher=self.player.stretcher)
        self.transport.unload()

    # --- Transport commands ---------------------------------------------

    def play(self) -> None:
        try:
            self.transport.play()
        except InvalidTransportTransition:
            logger.debug("Deck %s: ignored PLAY from state %s", self.deck_id, self.transport.state)
            return
        self.events.emit(EventType.PLAY, source=self.deck_id, deck_id=self.deck_id)

    def pause(self) -> None:
        try:
            self.transport.pause()
        except InvalidTransportTransition:
            return
        self.events.emit(EventType.PAUSE, source=self.deck_id, deck_id=self.deck_id)

    def stop(self) -> None:
        try:
            self.transport.stop()
        except InvalidTransportTransition:
            return
        self.player.seek_seconds(0.0)
        self.events.emit(EventType.STOP, source=self.deck_id, deck_id=self.deck_id)

    def cue_press(self) -> None:
        """CDJ-style CUE button: while stopped/paused, jump to cue and hold;
        while playing, set a new cue at the current position and stop."""
        if self.transport.state is TransportState.PLAYING:
            self.cue.set_cue(self.player.position_seconds)
            self.stop()
            return
        if not self.cue.has_cue():
            self.cue.set_cue(self.player.position_seconds)
        self.player.seek_seconds(self.cue.cue_position())
        try:
            self.transport.cue_down()
        except InvalidTransportTransition:
            pass
        self.events.emit(EventType.CUE, source=self.deck_id, deck_id=self.deck_id, position=self.cue.cue_position())

    def cue_release(self) -> None:
        """Releasing CUE while held (CUED state) returns to the cue point and pauses."""
        if self.transport.state is TransportState.CUED:
            self.player.seek_seconds(self.cue.cue_position())
            self.transport.stop()

    def seek(self, position_seconds: float) -> None:
        self.player.seek_seconds(position_seconds)
        self.events.emit(EventType.SEEK, source=self.deck_id, deck_id=self.deck_id, position=position_seconds)

    def seek_relative(self, delta_seconds: float) -> None:
        self.seek(self.player.position_seconds + delta_seconds)

    # --- Pitch ------------------------------------------------------------

    def set_pitch_range(self, range_fraction: float) -> None:
        self._pitch_range = range_fraction

    def set_pitch(self, pitch_fraction: float) -> None:
        """`pitch_fraction` is -1.0..+1.0 across the current pitch range."""
        self._pitch = max(-1.0, min(1.0, pitch_fraction))
        self.events.emit(
            EventType.PITCH_CHANGED, source=self.deck_id, deck_id=self.deck_id, pitch=self.effective_pitch_percent()
        )

    def pitch_bend(self, fraction: float) -> None:
        """Transient bend (jog wheel), summed with the base pitch but not stored."""
        self._pitch_bend = max(-0.5, min(0.5, fraction))

    def reset_pitch(self) -> None:
        self.set_pitch(0.0)

    def effective_pitch_percent(self) -> float:
        return self._pitch * self._pitch_range

    def playback_rate(self) -> float:
        return 1.0 + self.effective_pitch_percent() + self._pitch_bend

    def effective_bpm(self) -> Optional[float]:
        if self.beatgrid is None:
            return None
        return self.beatgrid.bpm * (1.0 + self.effective_pitch_percent())

    # --- Sync ---------------------------------------------------------------

    def sync_to(self, master: "Deck") -> None:
        """Match tempo (and, if playing, beat phase) to `master`. Reversible:
        does not alter the underlying track/beatgrid, only this deck's pitch."""
        if self.beatgrid is None or master.beatgrid is None or master.beatgrid.bpm <= 0:
            return
        self._sync_source = master
        target_bpm = master.effective_bpm() or master.beatgrid.bpm
        ratio = target_bpm / self.beatgrid.bpm
        new_pitch_fraction = (ratio - 1.0) / self._pitch_range if self._pitch_range else 0.0
        self.set_pitch(new_pitch_fraction)

        if self.transport.is_playing and master.transport.is_playing:
            master_phase = master.beatgrid.phase_offset_seconds(master.player.position_seconds)
            my_phase = self.beatgrid.phase_offset_seconds(self.player.position_seconds)
            correction = my_phase - master_phase
            self.player.seek_seconds(self.player.position_seconds - correction)

        self.events.emit(EventType.DECK_SYNCED, source=self.deck_id, deck_id=self.deck_id, master_deck=master.deck_id)

    def set_master(self, is_master: bool) -> None:
        self.is_master = is_master
        self.events.emit(EventType.DECK_MASTER_CHANGED, source=self.deck_id, deck_id=self.deck_id, is_master=is_master)

    # --- Loop -----------------------------------------------------------

    def loop_in(self) -> None:
        self.loop.loop_in(self.player.position_seconds)

    def loop_out(self) -> None:
        loop = self.loop.loop_out(self.player.position_seconds)
        if loop:
            self.events.emit(EventType.LOOP_CHANGED, source=self.deck_id, deck_id=self.deck_id,
                              start=loop.start_seconds, end=loop.end_seconds)

    def set_beat_loop(self, beats: float) -> None:
        loop = self.loop.set_beat_loop(self.player.position_seconds, beats)
        self.events.emit(EventType.LOOP_CHANGED, source=self.deck_id, deck_id=self.deck_id,
                          start=loop.start_seconds, end=loop.end_seconds)

    def loop_exit(self) -> None:
        self.loop.exit()
        self.events.emit(EventType.LOOP_EXITED, source=self.deck_id, deck_id=self.deck_id)

    # --- Hot cues ---------------------------------------------------------

    def trigger_hot_cue(self, slot: int) -> None:
        existing = self.hotcues.get(slot)
        if existing is None:
            cue = self.hotcues.set(slot, self.player.position_seconds)
            self.events.emit(EventType.HOT_CUE_SET, source=self.deck_id, deck_id=self.deck_id, slot=slot, position=cue.position_seconds)
            return
        self.player.seek_seconds(existing.position_seconds)
        if self.transport.state in (TransportState.STOPPED, TransportState.CUED, TransportState.PAUSED):
            try:
                self.transport.play()
            except InvalidTransportTransition:
                pass
        self.events.emit(EventType.HOT_CUE_TRIGGERED, source=self.deck_id, deck_id=self.deck_id, slot=slot)

    def clear_hot_cue(self, slot: int) -> None:
        self.hotcues.clear(slot)
        self.events.emit(EventType.HOT_CUE_CLEARED, source=self.deck_id, deck_id=self.deck_id, slot=slot)

    # --- EQ / filter / gain convenience ------------------------------------

    def set_eq(self, low_db: Optional[float] = None, mid_db: Optional[float] = None, high_db: Optional[float] = None) -> None:
        if low_db is not None:
            self.eq.set_low(low_db)
        if mid_db is not None:
            self.eq.set_mid(mid_db)
        if high_db is not None:
            self.eq.set_high(high_db)
        self.events.emit(EventType.EQ_CHANGED, source=self.deck_id, deck_id=self.deck_id, bands=self.eq.bands_db())

    def set_filter(self, knob_position: float) -> None:
        self.filter.set_knob_position(knob_position)
        self.events.emit(EventType.FILTER_CHANGED, source=self.deck_id, deck_id=self.deck_id, position=knob_position)

    def set_gain_db(self, gain_db: float) -> None:
        self.gain.set_db(gain_db)
        self.events.emit(EventType.VOLUME_CHANGED, source=self.deck_id, deck_id=self.deck_id, gain_db=gain_db)

    # --- Real-time-adjacent processing --------------------------------------

    def process_block(self, n_frames: int) -> np.ndarray:
        """Produce the next `n_frames` of this deck's post-EQ/filter/gain
        signal. Safe to call from the audio thread: no allocation beyond
        the preallocated numpy operations inside EQ/filter/player, no I/O.
        """
        if self.transport.state is not TransportState.PLAYING:
            return np.zeros((n_frames, self.channels), dtype=np.float32)

        rate = self.playback_rate()
        block = self.player.read_block(n_frames, rate)

        wrapped_end_pos = self.loop.wrap_position(self.player.position_seconds)
        if wrapped_end_pos != self.player.position_seconds:
            self.player.seek_seconds(wrapped_end_pos)

        if self.player.at_end():
            self.stop()

        block = self.eq.process(block)
        block = self.filter.process(block)
        block = self.gain.process(block)
        return block

    # --- Serialisation ------------------------------------------------------

    def to_parameters(self) -> DeckParameters:
        return DeckParameters(
            deck_id=self.deck_id,
            track_id=self.track.id if self.track else None,
            playing=self.transport.is_playing,
            position_seconds=self.player.position_seconds,
            bpm=self.beatgrid.bpm if self.beatgrid else None,
            pitch=self._pitch,
            pitch_range=self._pitch_range,
            gain_db=0.0,
            eq_low_db=self.eq.low_db,
            eq_mid_db=self.eq.mid_db,
            eq_high_db=self.eq.high_db,
            filter_position=0.0,
            is_master=self.is_master,
        )
