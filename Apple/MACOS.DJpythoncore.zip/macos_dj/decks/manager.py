"""DeckManager: owns the pool of decks and the master/sync relationship.

    DeckManager(decks=4)

creates decks named "A", "B", "C", "D" (extending alphabetically for
more). The architecture supports any deck count -- nothing elsewhere in
the codebase hard-codes four.
"""

from __future__ import annotations

import string
from typing import Dict, List, Optional

from macos_dj.core.events import EventBus, global_event_bus
from macos_dj.decks.deck import Deck


def _deck_id_for_index(index: int) -> str:
    if index < 26:
        return string.ascii_uppercase[index]
    return f"D{index + 1}"  # D27, D28, ... beyond the alphabet


class DeckManager:
    def __init__(
        self,
        decks: int = 4,
        sample_rate: int = 44100,
        channels: int = 2,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.events = event_bus or global_event_bus
        self.sample_rate = sample_rate
        self.channels = channels
        self._decks: Dict[str, Deck] = {}
        self._master_deck_id: Optional[str] = None

        for i in range(decks):
            deck_id = _deck_id_for_index(i)
            self._decks[deck_id] = Deck(deck_id, sample_rate=sample_rate, channels=channels, event_bus=self.events)

    def add_deck(self) -> Deck:
        """Add another deck beyond the initial pool (extensibility hook)."""
        deck_id = _deck_id_for_index(len(self._decks))
        deck = Deck(deck_id, sample_rate=self.sample_rate, channels=self.channels, event_bus=self.events)
        self._decks[deck_id] = deck
        return deck

    def __getitem__(self, deck_id: str) -> Deck:
        return self._decks[deck_id]

    def get(self, deck_id: str) -> Optional[Deck]:
        return self._decks.get(deck_id)

    def all(self) -> List[Deck]:
        return list(self._decks.values())

    def ids(self) -> List[str]:
        return list(self._decks.keys())

    @property
    def count(self) -> int:
        return len(self._decks)

    def set_master(self, deck_id: str) -> None:
        for did, deck in self._decks.items():
            deck.set_master(did == deck_id)
        self._master_deck_id = deck_id

    @property
    def master_deck(self) -> Optional[Deck]:
        return self._decks.get(self._master_deck_id) if self._master_deck_id else None

    def sync_deck(self, deck_id: str, master_deck_id: Optional[str] = None) -> None:
        target = self._decks[deck_id]
        master_id = master_deck_id or self._master_deck_id
        if master_id is None or master_id not in self._decks:
            return
        target.sync_to(self._decks[master_id])

    def process_all(self, n_frames: int) -> Dict[str, "np.ndarray"]:  # noqa: F821 - see below
        import numpy as np  # local import: avoids importing numpy at module load for pure orchestration users

        return {deck_id: deck.process_block(n_frames) for deck_id, deck in self._decks.items()}
