"""Hot cue model and bank (8 slots, CUE 1-8)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Dict, List, Optional

MAX_HOT_CUES = 8

_DEFAULT_COLORS = [
    "#FF3B30", "#FF9500", "#FFCC00", "#34C759",
    "#00C7BE", "#30B0C7", "#007AFF", "#AF52DE",
]


class HotCueType(Enum):
    CUE = auto()
    LOOP = auto()
    LOAD = auto()  # "load track and jump here" style cue


@dataclass
class HotCue:
    slot: int  # 1-8
    position_seconds: float
    label: str = ""
    color: str = "#FFFFFF"
    type: HotCueType = HotCueType.CUE
    loop_length_beats: Optional[float] = None

    def __post_init__(self) -> None:
        if not (1 <= self.slot <= MAX_HOT_CUES):
            raise ValueError(f"Hot cue slot must be 1-{MAX_HOT_CUES}, got {self.slot}")
        if self.color == "#FFFFFF":
            self.color = _DEFAULT_COLORS[(self.slot - 1) % len(_DEFAULT_COLORS)]


class HotCueBank:
    """Manages up to 8 hot cues for a single deck."""

    def __init__(self) -> None:
        self._cues: Dict[int, HotCue] = {}

    def set(
        self,
        slot: int,
        position_seconds: float,
        label: str = "",
        type: HotCueType = HotCueType.CUE,
        loop_length_beats: Optional[float] = None,
    ) -> HotCue:
        cue = HotCue(
            slot=slot,
            position_seconds=position_seconds,
            label=label,
            type=type,
            loop_length_beats=loop_length_beats,
        )
        self._cues[slot] = cue
        return cue

    def get(self, slot: int) -> Optional[HotCue]:
        return self._cues.get(slot)

    def clear(self, slot: int) -> None:
        self._cues.pop(slot, None)

    def clear_all(self) -> None:
        self._cues.clear()

    def all_cues(self) -> List[HotCue]:
        return [self._cues[slot] for slot in sorted(self._cues.keys())]

    def is_set(self, slot: int) -> bool:
        return slot in self._cues
