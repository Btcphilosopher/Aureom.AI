"""Loop engine: beat-quantised and arbitrary loop support."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from macos_dj.analysis.beatgrid import BeatGrid

STANDARD_LOOP_BEAT_LENGTHS: List[float] = [0.5, 1, 2, 4, 8, 16, 32]


@dataclass
class Loop:
    start_seconds: float
    end_seconds: float
    active: bool = True

    @property
    def length_seconds(self) -> float:
        return max(0.0, self.end_seconds - self.start_seconds)


class LoopEngine:
    """Manages the active loop and a single "reloop" memory slot for a deck."""

    def __init__(self, beatgrid: Optional[BeatGrid] = None) -> None:
        self.beatgrid = beatgrid
        self._pending_in: Optional[float] = None
        self._active_loop: Optional[Loop] = None
        self._last_loop: Optional[Loop] = None

    def set_beatgrid(self, beatgrid: BeatGrid) -> None:
        self.beatgrid = beatgrid

    @property
    def active_loop(self) -> Optional[Loop]:
        return self._active_loop if self._active_loop and self._active_loop.active else None

    def loop_in(self, position_seconds: float) -> None:
        self._pending_in = position_seconds
        self._active_loop = None

    def loop_out(self, position_seconds: float) -> Optional[Loop]:
        if self._pending_in is None:
            return None
        start = self._pending_in
        end = max(position_seconds, start + 0.01)
        loop = Loop(start_seconds=start, end_seconds=end, active=True)
        self._active_loop = loop
        self._last_loop = loop
        self._pending_in = None
        return loop

    def set_beat_loop(self, position_seconds: float, beats: float) -> Loop:
        """Create a beat-quantised loop of `beats` length starting at
        `position_seconds`, snapped to the nearest beat if a beatgrid is set.
        """
        start = position_seconds
        length_seconds = beats * 2.0  # fallback: 2s/beat if no grid (120bpm-ish)
        if self.beatgrid is not None and self.beatgrid.beat_length_seconds > 0:
            start = self.beatgrid.nearest_beat_position(position_seconds)
            length_seconds = beats * self.beatgrid.beat_length_seconds
        loop = Loop(start_seconds=start, end_seconds=start + length_seconds, active=True)
        self._active_loop = loop
        self._last_loop = loop
        return loop

    def double(self) -> Optional[Loop]:
        if self._active_loop is None:
            return None
        length = self._active_loop.length_seconds
        self._active_loop.end_seconds = self._active_loop.start_seconds + length * 2
        return self._active_loop

    def halve(self) -> Optional[Loop]:
        if self._active_loop is None:
            return None
        length = self._active_loop.length_seconds
        self._active_loop.end_seconds = self._active_loop.start_seconds + max(length / 2, 0.01)
        return self._active_loop

    def move(self, delta_seconds: float) -> Optional[Loop]:
        if self._active_loop is None:
            return None
        self._active_loop.start_seconds += delta_seconds
        self._active_loop.end_seconds += delta_seconds
        return self._active_loop

    def exit(self) -> None:
        if self._active_loop is not None:
            self._active_loop.active = False

    def reloop(self) -> Optional[Loop]:
        if self._last_loop is None:
            return None
        self._last_loop.active = True
        self._active_loop = self._last_loop
        return self._active_loop

    def wrap_position(self, position_seconds: float) -> float:
        """If a loop is active and playback has passed its end, wrap the
        position back to the loop start. Called from the deck's playback
        tick, kept allocation-free for the real-time-adjacent path."""
        loop = self.active_loop
        if loop is None:
            return position_seconds
        if position_seconds >= loop.end_seconds:
            overflow = position_seconds - loop.end_seconds
            span = max(loop.length_seconds, 1e-6)
            return loop.start_seconds + (overflow % span)
        return position_seconds
