"""Deck transport state machine (PLAY / PAUSE / STOP / CUE / SEEK)."""

from __future__ import annotations

from enum import Enum, auto
from typing import Optional


class TransportState(Enum):
    EMPTY = auto()      # no track loaded
    STOPPED = auto()
    CUED = auto()        # paused at cue point, ready to play
    PLAYING = auto()
    PAUSED = auto()


class InvalidTransportTransition(Exception):
    pass


class Transport:
    """A small explicit state machine governing deck playback state.

    Keeping transitions explicit (rather than a scatter of booleans)
    makes illegal states like "playing but also stopped" structurally
    impossible and makes the whole thing trivially unit-testable.
    """

    _VALID_TRANSITIONS = {
        TransportState.EMPTY: {TransportState.STOPPED},
        TransportState.STOPPED: {TransportState.PLAYING, TransportState.CUED, TransportState.EMPTY},
        TransportState.CUED: {TransportState.PLAYING, TransportState.STOPPED, TransportState.EMPTY},
        TransportState.PLAYING: {TransportState.PAUSED, TransportState.STOPPED, TransportState.CUED, TransportState.EMPTY},
        TransportState.PAUSED: {TransportState.PLAYING, TransportState.CUED, TransportState.STOPPED, TransportState.EMPTY},
    }

    def __init__(self) -> None:
        self.state = TransportState.EMPTY

    def can_transition(self, target: TransportState) -> bool:
        return target in self._VALID_TRANSITIONS.get(self.state, set())

    def transition(self, target: TransportState) -> None:
        if not self.can_transition(target):
            raise InvalidTransportTransition(f"Cannot go from {self.state} to {target}")
        self.state = target

    def load(self) -> None:
        self.state = TransportState.STOPPED  # loading always resets to stopped

    def play(self) -> None:
        self.transition(TransportState.PLAYING)

    def pause(self) -> None:
        self.transition(TransportState.PAUSED)

    def stop(self) -> None:
        self.transition(TransportState.STOPPED)

    def cue_down(self) -> None:
        """CDJ-style: pressing cue while stopped/paused jumps to cue and holds."""
        self.transition(TransportState.CUED)

    def unload(self) -> None:
        self.state = TransportState.EMPTY

    @property
    def is_playing(self) -> bool:
        return self.state is TransportState.PLAYING

    @property
    def is_loaded(self) -> bool:
        return self.state is not TransportState.EMPTY
