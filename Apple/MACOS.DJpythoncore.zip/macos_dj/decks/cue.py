"""Cue point model and simple cue-point store."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class CuePoint:
    position_seconds: float
    label: str = ""


class CueManager:
    """Manages the single primary cue point of a deck (CDJ-style temp cue)."""

    def __init__(self) -> None:
        self._cue: Optional[CuePoint] = None
        self._resume_position: float = 0.0

    @property
    def cue(self) -> Optional[CuePoint]:
        return self._cue

    def set_cue(self, position_seconds: float, label: str = "") -> CuePoint:
        self._cue = CuePoint(position_seconds=position_seconds, label=label)
        return self._cue

    def clear(self) -> None:
        self._cue = None

    def has_cue(self) -> bool:
        return self._cue is not None

    def cue_position(self) -> float:
        return self._cue.position_seconds if self._cue else 0.0
