"""SQLite-backed music library database.

All schema changes happen through `_MIGRATIONS` so an existing user's
library is upgraded in place rather than requiring a wipe. Every method
here is safe to call off the audio thread only (this module does file
I/O) -- the analysis/import pipeline runs it via `core.scheduler`.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator, List, Optional

from macos_dj.analysis.beatgrid import BeatGrid
from macos_dj.core.logging import get_logger
from macos_dj.library.tracks import Track

logger = get_logger(__name__)

_SCHEMA_VERSION = 1

_MIGRATIONS: List[str] = [
    """
    CREATE TABLE IF NOT EXISTS tracks (
        id TEXT PRIMARY KEY,
        file_path TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        artist TEXT NOT NULL,
        album TEXT,
        genre TEXT,
        year INTEGER,
        duration_seconds REAL,
        sample_rate INTEGER,
        channels INTEGER,
        bitrate_kbps INTEGER,
        bpm REAL,
        bpm_locked INTEGER DEFAULT 0,
        musical_key TEXT,
        key_locked INTEGER DEFAULT 0,
        energy INTEGER,
        beatgrid_json TEXT,
        rating INTEGER DEFAULT 0,
        play_count INTEGER DEFAULT 0,
        date_added TEXT,
        last_played_at TEXT,
        analysis_failed INTEGER DEFAULT 0,
        analysis_error TEXT
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_tracks_artist ON tracks(artist);",
    "CREATE INDEX IF NOT EXISTS idx_tracks_title ON tracks(title);",
    "CREATE INDEX IF NOT EXISTS idx_tracks_bpm ON tracks(bpm);",
    "CREATE INDEX IF NOT EXISTS idx_tracks_key ON tracks(musical_key);",
    """
    CREATE TABLE IF NOT EXISTS playlists (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        is_smart INTEGER DEFAULT 0,
        smart_rule_json TEXT,
        created_at TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS playlist_tracks (
        playlist_id TEXT NOT NULL,
        track_id TEXT NOT NULL,
        position INTEGER NOT NULL,
        PRIMARY KEY (playlist_id, position),
        FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
        FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        track_id TEXT NOT NULL,
        deck_id TEXT,
        session_id TEXT,
        played_at TEXT NOT NULL
    );
    """,
    "PRAGMA user_version = 1;",
]


class LibraryDatabase:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._migrate()

    def _connect(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn"):
            conn = sqlite3.connect(str(self.path), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON;")
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def _cursor(self) -> Iterator[sqlite3.Cursor]:
        conn = self._connect()
        cur = conn.cursor()
        try:
            yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cur.close()

    def _migrate(self) -> None:
        conn = self._connect()
        current_version = conn.execute("PRAGMA user_version;").fetchone()[0]
        if current_version >= _SCHEMA_VERSION:
            return
        with self._cursor() as cur:
            for statement in _MIGRATIONS:
                cur.execute(statement)
        logger.info("Library database migrated to schema version %d at %s", _SCHEMA_VERSION, self.path)

    # --- Track CRUD -------------------------------------------------------

    def upsert_track(self, track: Track) -> None:
        beatgrid_json = _beatgrid_to_json(track.beatgrid)
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO tracks (
                    id, file_path, title, artist, album, genre, year,
                    duration_seconds, sample_rate, channels, bitrate_kbps,
                    bpm, bpm_locked, musical_key, key_locked, energy,
                    beatgrid_json, rating, play_count, date_added,
                    last_played_at, analysis_failed, analysis_error
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    file_path=excluded.file_path, title=excluded.title,
                    artist=excluded.artist, album=excluded.album,
                    genre=excluded.genre, year=excluded.year,
                    duration_seconds=excluded.duration_seconds,
                    sample_rate=excluded.sample_rate, channels=excluded.channels,
                    bitrate_kbps=excluded.bitrate_kbps, bpm=excluded.bpm,
                    bpm_locked=excluded.bpm_locked, musical_key=excluded.musical_key,
                    key_locked=excluded.key_locked, energy=excluded.energy,
                    beatgrid_json=excluded.beatgrid_json, rating=excluded.rating,
                    play_count=excluded.play_count, date_added=excluded.date_added,
                    last_played_at=excluded.last_played_at,
                    analysis_failed=excluded.analysis_failed,
                    analysis_error=excluded.analysis_error
                """,
                (
                    track.id, track.file_path, track.title, track.artist, track.album,
                    track.genre, track.year, track.duration_seconds, track.sample_rate,
                    track.channels, track.bitrate_kbps, track.bpm, int(track.bpm_locked),
                    track.musical_key, int(track.key_locked), track.energy, beatgrid_json,
                    track.rating, track.play_count, track.date_added.isoformat(),
                    track.last_played_at.isoformat() if track.last_played_at else None,
                    int(track.analysis_failed), track.analysis_error,
                ),
            )

    def get_track(self, track_id: str) -> Optional[Track]:
        with self._cursor() as cur:
            cur.execute("SELECT * FROM tracks WHERE id = ?", (track_id,))
            row = cur.fetchone()
        return _row_to_track(row) if row else None

    def get_track_by_path(self, file_path: str) -> Optional[Track]:
        with self._cursor() as cur:
            cur.execute("SELECT * FROM tracks WHERE file_path = ?", (file_path,))
            row = cur.fetchone()
        return _row_to_track(row) if row else None

    def all_tracks(self) -> List[Track]:
        with self._cursor() as cur:
            cur.execute("SELECT * FROM tracks ORDER BY artist, title")
            rows = cur.fetchall()
        return [_row_to_track(r) for r in rows]

    def delete_track(self, track_id: str) -> None:
        with self._cursor() as cur:
            cur.execute("DELETE FROM tracks WHERE id = ?", (track_id,))

    def record_play(self, track_id: str, deck_id: str = "", session_id: str = "") -> None:
        with self._cursor() as cur:
            cur.execute(
                "INSERT INTO history (track_id, deck_id, session_id, played_at) VALUES (?,?,?,?)",
                (track_id, deck_id, session_id, datetime.utcnow().isoformat()),
            )
            cur.execute("UPDATE tracks SET play_count = play_count + 1, last_played_at = ? WHERE id = ?",
                        (datetime.utcnow().isoformat(), track_id))

    def close(self) -> None:
        if hasattr(self._local, "conn"):
            self._local.conn.close()
            del self._local.conn


def _beatgrid_to_json(beatgrid: Optional[BeatGrid]) -> Optional[str]:
    if beatgrid is None:
        return None
    return json.dumps(
        {
            "bpm": beatgrid.bpm,
            "first_beat_seconds": beatgrid.first_beat_seconds,
            "beats_per_bar": beatgrid.beats_per_bar,
            "confidence": beatgrid.confidence,
            "manually_adjusted": beatgrid.manually_adjusted,
        }
    )


def _beatgrid_from_json(data: Optional[str]) -> Optional[BeatGrid]:
    if not data:
        return None
    try:
        obj = json.loads(data)
        return BeatGrid(
            bpm=obj["bpm"],
            first_beat_seconds=obj.get("first_beat_seconds", 0.0),
            beats_per_bar=obj.get("beats_per_bar", 4),
            confidence=obj.get("confidence", 1.0),
            manually_adjusted=obj.get("manually_adjusted", False),
        )
    except (json.JSONDecodeError, KeyError):
        return None


def _row_to_track(row: sqlite3.Row) -> Track:
    return Track(
        id=row["id"],
        file_path=row["file_path"],
        title=row["title"],
        artist=row["artist"],
        album=row["album"] or "",
        genre=row["genre"] or "",
        year=row["year"],
        duration_seconds=row["duration_seconds"] or 0.0,
        sample_rate=row["sample_rate"] or 44100,
        channels=row["channels"] or 2,
        bitrate_kbps=row["bitrate_kbps"],
        bpm=row["bpm"],
        bpm_locked=bool(row["bpm_locked"]),
        musical_key=row["musical_key"],
        key_locked=bool(row["key_locked"]),
        energy=row["energy"],
        beatgrid=_beatgrid_from_json(row["beatgrid_json"]),
        rating=row["rating"] or 0,
        play_count=row["play_count"] or 0,
        date_added=_parse_datetime(row["date_added"]) or datetime.utcnow(),
        last_played_at=_parse_datetime(row["last_played_at"]),
        analysis_failed=bool(row["analysis_failed"]),
        analysis_error=row["analysis_error"],
    )


def _parse_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None
