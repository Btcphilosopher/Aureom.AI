"""DJ session play history: what was played, when, on which deck, in
which session. Backed by the `history` table in `LibraryDatabase`, with
CSV export for sharing a setlist.
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from macos_dj.library.database import LibraryDatabase


@dataclass
class HistoryEntry:
    track_id: str
    track_title: str
    track_artist: str
    deck_id: str
    session_id: str
    played_at: datetime


class DJHistory:
    def __init__(self, database: LibraryDatabase) -> None:
        self.database = database

    def record(self, track_id: str, deck_id: str, session_id: str = "") -> None:
        self.database.record_play(track_id, deck_id=deck_id, session_id=session_id)

    def entries_for_session(self, session_id: str) -> List[HistoryEntry]:
        with self.database._cursor() as cur:  # noqa: SLF001 - intentional, thin composition
            cur.execute(
                """
                SELECT h.track_id, h.deck_id, h.session_id, h.played_at, t.title, t.artist
                FROM history h JOIN tracks t ON t.id = h.track_id
                WHERE h.session_id = ?
                ORDER BY h.played_at ASC
                """,
                (session_id,),
            )
            rows = cur.fetchall()
        return [
            HistoryEntry(
                track_id=r["track_id"], track_title=r["title"], track_artist=r["artist"],
                deck_id=r["deck_id"] or "", session_id=r["session_id"] or "",
                played_at=datetime.fromisoformat(r["played_at"]),
            )
            for r in rows
        ]

    def all_entries(self, limit: int = 500) -> List[HistoryEntry]:
        with self.database._cursor() as cur:  # noqa: SLF001
            cur.execute(
                """
                SELECT h.track_id, h.deck_id, h.session_id, h.played_at, t.title, t.artist
                FROM history h JOIN tracks t ON t.id = h.track_id
                ORDER BY h.played_at DESC LIMIT ?
                """,
                (limit,),
            )
            rows = cur.fetchall()
        return [
            HistoryEntry(
                track_id=r["track_id"], track_title=r["title"], track_artist=r["artist"],
                deck_id=r["deck_id"] or "", session_id=r["session_id"] or "",
                played_at=datetime.fromisoformat(r["played_at"]),
            )
            for r in rows
        ]

    def export_csv(self, entries: List[HistoryEntry]) -> str:
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["played_at", "deck", "artist", "title", "session_id"])
        for e in entries:
            writer.writerow([e.played_at.isoformat(), e.deck_id, e.track_artist, e.track_title, e.session_id])
        return buffer.getvalue()
