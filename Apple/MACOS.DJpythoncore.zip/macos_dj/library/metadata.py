"""Metadata extraction and the library scanner.

`scan_directory` walks a library location, decodes just enough of each
file to read tags and duration, and builds/updates `Track` records. A
single corrupted or unsupported file must never abort the scan -- errors
are logged and the file is skipped.

Editing metadata through the application (title/artist/etc.) only ever
touches the database record (`Track`), never the underlying audio file's
own tags, per the "never modify original files" requirement.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator, List, Optional

from macos_dj.audio.player import SUPPORTED_EXTENSIONS, probe_duration_seconds
from macos_dj.core.logging import get_logger
from macos_dj.library.tracks import Track

logger = get_logger(__name__)


@dataclass
class ScanResult:
    scanned: int = 0
    imported: int = 0
    updated: int = 0
    failed: int = 0
    errors: List[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.errors is None:
            self.errors = []


def iter_audio_files(directory: Path) -> Iterator[Path]:
    for path in directory.rglob("*"):
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS:
            yield path


def read_tags(path: Path) -> dict:
    """Best-effort tag read using `mutagen` when available; falls back to
    filename-derived title/artist so import never blocks on tag support."""
    tags = {"title": path.stem, "artist": "Unknown Artist", "album": "", "genre": "", "year": None}
    try:
        import mutagen  # type: ignore

        audio = mutagen.File(path, easy=True)
        if audio is not None and audio.tags:
            def first(key: str) -> Optional[str]:
                values = audio.tags.get(key)
                return values[0] if values else None

            tags["title"] = first("title") or tags["title"]
            tags["artist"] = first("artist") or tags["artist"]
            tags["album"] = first("album") or tags["album"]
            tags["genre"] = first("genre") or tags["genre"]
            year_raw = first("date") or first("year")
            if year_raw:
                try:
                    tags["year"] = int(str(year_raw)[:4])
                except ValueError:
                    pass
    except ImportError:
        logger.debug("mutagen not installed; using filename-derived metadata for %s", path)
    except Exception as exc:  # noqa: BLE001 - tag libraries raise many varied error types
        logger.warning("Failed to read tags for %s: %s", path, exc)
    return tags


def build_track_from_file(path: Path) -> Optional[Track]:
    try:
        tags = read_tags(path)
        duration = probe_duration_seconds(str(path))
        return Track(
            file_path=str(path),
            title=tags["title"],
            artist=tags["artist"],
            album=tags["album"],
            genre=tags["genre"],
            year=tags["year"],
            duration_seconds=duration,
        )
    except Exception as exc:  # noqa: BLE001 - never let one file crash the scan
        logger.error("Failed to build track record for %s: %s", path, exc)
        return None


def scan_directory(
    directory: Path,
    existing_paths: Optional[set[str]] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> tuple[List[Track], ScanResult]:
    """Scan `directory` recursively; returns newly discovered tracks plus a
    result summary. `existing_paths` lets the caller skip already-imported
    files. Never raises for an individual bad file.
    """
    existing_paths = existing_paths or set()
    result = ScanResult()
    new_tracks: List[Track] = []

    if not directory.exists():
        logger.warning("Library location does not exist: %s", directory)
        return new_tracks, result

    all_files = list(iter_audio_files(directory))
    total = len(all_files)

    for i, path in enumerate(all_files):
        result.scanned += 1
        if str(path) in existing_paths:
            continue
        try:
            track = build_track_from_file(path)
            if track is None:
                result.failed += 1
                result.errors.append(f"{path}: failed to build track")
                continue
            new_tracks.append(track)
            result.imported += 1
        except Exception as exc:  # noqa: BLE001 - guarantee scan continuation
            result.failed += 1
            result.errors.append(f"{path}: {exc}")
            logger.error("Error scanning %s: %s", path, exc)
        finally:
            if on_progress:
                on_progress(i + 1, total)

    return new_tracks, result
