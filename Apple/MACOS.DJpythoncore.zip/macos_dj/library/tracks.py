"""The `Track` data model plus lightweight analysis-state helpers.

`Track` is the central record representing one audio file the library
knows about. Analysis results (BPM, beatgrid, key, waveform, energy) are
attached here but the *heavy* data (full waveform arrays) is generally
kept out of this dataclass in memory and instead lazily loaded/generated
via `analysis` modules -- this model stores only what is cheap to keep
resident and what belongs in the database.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from macos_dj.analysis.beatgrid import BeatGrid


@dataclass
class Track:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    file_path: str = ""

    title: str = "Unknown Title"
    artist: str = "Unknown Artist"
    album: str = ""
    genre: str = ""
    year: Optional[int] = None

    duration_seconds: float = 0.0
    sample_rate: int = 44100
    channels: int = 2
    bitrate_kbps: Optional[int] = None

    bpm: Optional[float] = None
    bpm_locked: bool = False  # true once a user manually corrects the BPM
    musical_key: Optional[str] = None
    key_locked: bool = False
    energy: Optional[int] = None  # 1-10

    beatgrid: Optional[BeatGrid] = None

    rating: int = 0  # 0-5 stars
    play_count: int = 0
    date_added: datetime = field(default_factory=datetime.utcnow)
    last_played_at: Optional[datetime] = None

    analysis_failed: bool = False
    analysis_error: Optional[str] = None

    def exists_on_disk(self) -> bool:
        return bool(self.file_path) and Path(self.file_path).exists()

    def apply_bpm_estimate(self, bpm: float, force: bool = False) -> bool:
        """Apply an automatically detected BPM, respecting a manual lock
        unless `force` is explicitly requested by the user."""
        if self.bpm_locked and not force:
            return False
        self.bpm = bpm
        return True

    def apply_key_estimate(self, key: str, force: bool = False) -> bool:
        if self.key_locked and not force:
            return False
        self.musical_key = key
        return True

    def set_manual_bpm(self, bpm: float) -> None:
        self.bpm = bpm
        self.bpm_locked = True

    def set_manual_key(self, key: str) -> None:
        self.musical_key = key
        self.key_locked = True

    def register_play(self) -> None:
        self.play_count += 1
        self.last_played_at = datetime.utcnow()

    @property
    def display_name(self) -> str:
        return f"{self.artist} - {self.title}" if self.artist else self.title
