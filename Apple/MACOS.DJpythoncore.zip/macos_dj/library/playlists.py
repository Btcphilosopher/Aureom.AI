"""Playlist engine: regular and smart (rule-based) playlists."""

from __future__ import annotations

import operator
import uuid
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from macos_dj.library.tracks import Track

_OPS: Dict[str, Callable[[object, object], bool]] = {
    "=": operator.eq,
    "!=": operator.ne,
    ">": operator.gt,
    ">=": operator.ge,
    "<": operator.lt,
    "<=": operator.le,
}

_FIELD_GETTERS: Dict[str, Callable[[Track], object]] = {
    "bpm": lambda t: t.bpm,
    "genre": lambda t: t.genre,
    "artist": lambda t: t.artist,
    "album": lambda t: t.album,
    "rating": lambda t: t.rating,
    "energy": lambda t: t.energy,
    "key": lambda t: t.musical_key,
    "year": lambda t: t.year,
    "play_count": lambda t: t.play_count,
}


@dataclass
class SmartRule:
    field: str
    op: str
    value: object

    def matches(self, track: Track) -> bool:
        getter = _FIELD_GETTERS.get(self.field)
        comparator = _OPS.get(self.op)
        if getter is None or comparator is None:
            return False
        track_value = getter(track)
        if track_value is None:
            return False
        try:
            return comparator(track_value, self.value)
        except TypeError:
            return False


@dataclass
class SmartRuleGroup:
    """A group of rules combined with AND (default) or OR."""

    rules: List[SmartRule] = field(default_factory=list)
    match_all: bool = True  # True = AND, False = OR

    def matches(self, track: Track) -> bool:
        if not self.rules:
            return True
        results = (rule.matches(track) for rule in self.rules)
        return all(results) if self.match_all else any(results)


@dataclass
class Playlist:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "New Playlist"
    track_ids: List[str] = field(default_factory=list)
    is_smart: bool = False
    smart_rules: Optional[SmartRuleGroup] = None

    def add_track(self, track_id: str) -> None:
        if track_id not in self.track_ids:
            self.track_ids.append(track_id)

    def remove_track(self, track_id: str) -> None:
        if track_id in self.track_ids:
            self.track_ids.remove(track_id)

    def reorder_track(self, track_id: str, new_index: int) -> None:
        if track_id not in self.track_ids:
            return
        self.track_ids.remove(track_id)
        new_index = max(0, min(new_index, len(self.track_ids)))
        self.track_ids.insert(new_index, track_id)

    def resolve_smart(self, all_tracks: List[Track]) -> List[Track]:
        if not self.is_smart or self.smart_rules is None:
            return []
        return [t for t in all_tracks if self.smart_rules.matches(t)]


class PlaylistManager:
    def __init__(self) -> None:
        self._playlists: Dict[str, Playlist] = {}

    def create(self, name: str, is_smart: bool = False, smart_rules: Optional[SmartRuleGroup] = None) -> Playlist:
        playlist = Playlist(name=name, is_smart=is_smart, smart_rules=smart_rules)
        self._playlists[playlist.id] = playlist
        return playlist

    def delete(self, playlist_id: str) -> None:
        self._playlists.pop(playlist_id, None)

    def get(self, playlist_id: str) -> Optional[Playlist]:
        return self._playlists.get(playlist_id)

    def all(self) -> List[Playlist]:
        return list(self._playlists.values())

    def rename(self, playlist_id: str, new_name: str) -> None:
        playlist = self._playlists.get(playlist_id)
        if playlist:
            playlist.name = new_name


def compatible_key_rule(camelot_key: str) -> SmartRule:
    """Convenience rule builder for 'KEY = compatible' style smart playlists."""
    return SmartRule(field="key", op="=", value=camelot_key)
