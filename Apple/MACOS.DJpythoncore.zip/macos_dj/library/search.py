"""Fast local search with fuzzy matching across the track library."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import List, Optional

from macos_dj.library.tracks import Track

_SEARCHABLE_FIELDS = ("title", "artist", "album", "genre", "musical_key")


@dataclass
class SearchResult:
    track: Track
    score: float  # 0..1, higher is a better match


def _field_score(query: str, value: Optional[str]) -> float:
    if not value:
        return 0.0
    value_lower = value.lower()
    if query in value_lower:
        # Substring hits score highly, weighted by how much of the field they cover.
        return 0.6 + 0.4 * (len(query) / max(len(value_lower), 1))
    return SequenceMatcher(None, query, value_lower).ratio()


def search_tracks(
    tracks: List[Track],
    query: str,
    min_score: float = 0.35,
    bpm: Optional[float] = None,
    bpm_tolerance: float = 2.0,
    rating: Optional[int] = None,
    key: Optional[str] = None,
    limit: int = 100,
) -> List[SearchResult]:
    """Fuzzy free-text search across title/artist/album/genre/key, with
    optional exact-ish filters (bpm range, rating, key).
    """
    query = query.strip().lower()
    results: List[SearchResult] = []

    for track in tracks:
        if bpm is not None and track.bpm is not None and abs(track.bpm - bpm) > bpm_tolerance:
            continue
        if rating is not None and track.rating < rating:
            continue
        if key is not None and (track.musical_key or "").lower() != key.lower():
            continue

        if not query:
            results.append(SearchResult(track=track, score=1.0))
            continue

        best_score = 0.0
        for field_name in _SEARCHABLE_FIELDS:
            value = getattr(track, field_name, None)
            best_score = max(best_score, _field_score(query, value))
        if best_score >= min_score:
            results.append(SearchResult(track=track, score=best_score))

    results.sort(key=lambda r: r.score, reverse=True)
    return results[:limit]
