"""Persistent application configuration.

Configuration is stored as JSON under the user's Application Support
directory on macOS (falling back sensibly on other platforms so the
project remains testable on Linux/CI). All fields are typed dataclasses
so the rest of the codebase gets autocompletion and validation instead of
passing raw dicts around.
"""

from __future__ import annotations

import json
import platform
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


def default_config_dir() -> Path:
    if platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "MACOS.DJ"
    # Non-macOS fallback (Linux CI, development machines).
    return Path.home() / ".macos_dj"


def default_library_dir() -> Path:
    return Path.home() / "Music" / "MACOS.DJ Library"


def default_recording_dir() -> Path:
    return Path.home() / "Music" / "MACOS.DJ Recordings"


@dataclass
class AudioConfig:
    sample_rate: int = 44100
    buffer_size: int = 256
    output_device: Optional[str] = None
    monitor_device: Optional[str] = None
    channels: int = 2


@dataclass
class DeckConfig:
    deck_count: int = 4
    default_pitch_range: float = 0.08  # +/- 8%
    available_pitch_ranges: List[float] = field(
        default_factory=lambda: [0.06, 0.10, 0.16, 1.00]
    )


@dataclass
class LibraryConfig:
    locations: List[str] = field(default_factory=lambda: [str(default_library_dir())])
    database_path: str = ""  # resolved lazily against config_dir if empty


@dataclass
class RecordingConfig:
    output_dir: str = str(default_recording_dir())
    format: str = "wav"
    bit_depth: int = 24


@dataclass
class AnalysisConfig:
    auto_analyze_on_import: bool = True
    overwrite_manual_bpm: bool = False
    overwrite_manual_key: bool = False
    max_concurrent_jobs: int = 2


@dataclass
class NetworkConfig:
    api_enabled: bool = False
    api_host: str = "127.0.0.1"
    api_port: int = 17832


@dataclass
class UIConfig:
    theme: str = "dark"
    keyboard_shortcuts: Dict[str, str] = field(
        default_factory=lambda: {
            "space": "PLAY_PAUSE",
            "q": "CUE",
            "left": "SEEK_BACKWARD",
            "right": "SEEK_FORWARD",
            "a": "FOCUS_DECK_A",
            "b": "FOCUS_DECK_B",
            "c": "FOCUS_DECK_C",
            "d": "FOCUS_DECK_D",
        }
    )


@dataclass
class AppConfig:
    audio: AudioConfig = field(default_factory=AudioConfig)
    decks: DeckConfig = field(default_factory=DeckConfig)
    library: LibraryConfig = field(default_factory=LibraryConfig)
    recording: RecordingConfig = field(default_factory=RecordingConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
    network: NetworkConfig = field(default_factory=NetworkConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    midi_mappings_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "AppConfig":
        cfg = AppConfig()
        for section_name in ("audio", "decks", "library", "recording", "analysis", "network", "ui"):
            if section_name in data and isinstance(data[section_name], dict):
                section_cls = type(getattr(cfg, section_name))
                current = asdict(getattr(cfg, section_name))
                current.update(data[section_name])
                setattr(cfg, section_name, section_cls(**current))
        if "midi_mappings_path" in data:
            cfg.midi_mappings_path = data["midi_mappings_path"]
        return cfg


class ConfigurationManager:
    """Loads, saves, and provides access to :class:`AppConfig`."""

    def __init__(self, config_dir: Optional[Path] = None) -> None:
        self.config_dir = config_dir or default_config_dir()
        self.config_path = self.config_dir / "config.json"
        self.config: AppConfig = AppConfig()

    def load(self) -> AppConfig:
        if self.config_path.exists():
            try:
                with self.config_path.open("r", encoding="utf-8") as fh:
                    data = json.load(fh)
                self.config = AppConfig.from_dict(data)
                logger.info("Loaded configuration from %s", self.config_path)
            except (json.JSONDecodeError, OSError) as exc:
                logger.error("Failed to load configuration (%s); using defaults", exc)
                self.config = AppConfig()
        else:
            logger.info("No configuration found; using defaults")
            self.config = AppConfig()

        if not self.config.library.database_path:
            self.config.library.database_path = str(self.config_dir / "library.sqlite3")
        if not self.config.midi_mappings_path:
            self.config.midi_mappings_path = str(self.config_dir / "midi_mappings.json")
        return self.config

    def save(self) -> None:
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = self.config_path.with_suffix(".json.tmp")
            with tmp_path.open("w", encoding="utf-8") as fh:
                json.dump(self.config.to_dict(), fh, indent=2, sort_keys=True)
            tmp_path.replace(self.config_path)  # atomic on POSIX
            logger.info("Saved configuration to %s", self.config_path)
        except OSError as exc:
            logger.error("Failed to save configuration: %s", exc)
