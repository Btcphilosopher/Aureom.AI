"""Application-wide event bus.

Every subsystem publishes structured, immutable events here instead of
calling into other subsystems directly. The UI layer (or any future
native macOS front-end) subscribes to the event types it cares about and
never needs a direct reference to the audio engine, deck manager, or
library. This keeps the real-time and non-real-time worlds loosely
coupled and makes the whole system testable in isolation.

Thread-safety: `EventBus.publish` may be called from any thread (audio
callback threads included, though publishing itself does no blocking
work -- handlers are invoked synchronously on the calling thread by
default, or dispatched onto a worker via `publish_async`). Handlers that
do expensive work should offload to `core.scheduler`.
"""

from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, DefaultDict, Dict, List, Optional
from collections import defaultdict

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


class EventType(Enum):
    TRACK_LOADED = auto()
    TRACK_LOAD_FAILED = auto()
    PLAY = auto()
    PAUSE = auto()
    STOP = auto()
    CUE = auto()
    SEEK = auto()
    BPM_CHANGED = auto()
    PITCH_CHANGED = auto()
    LOOP_CHANGED = auto()
    LOOP_EXITED = auto()
    HOT_CUE_TRIGGERED = auto()
    HOT_CUE_SET = auto()
    HOT_CUE_CLEARED = auto()
    DECK_SYNCED = auto()
    DECK_MASTER_CHANGED = auto()
    EQ_CHANGED = auto()
    FILTER_CHANGED = auto()
    VOLUME_CHANGED = auto()
    CROSSFADER_CHANGED = auto()
    MIDI_INPUT = auto()
    MIDI_DEVICE_CONNECTED = auto()
    MIDI_DEVICE_DISCONNECTED = auto()
    AUDIO_ERROR = auto()
    AUDIO_DEVICE_CHANGED = auto()
    AUDIO_DEVICE_LOST = auto()
    RECORDING_STARTED = auto()
    RECORDING_STOPPED = auto()
    ANALYSIS_STARTED = auto()
    ANALYSIS_COMPLETED = auto()
    ANALYSIS_FAILED = auto()
    LIBRARY_SCAN_STARTED = auto()
    LIBRARY_SCAN_PROGRESS = auto()
    LIBRARY_SCAN_COMPLETED = auto()
    SESSION_SAVED = auto()
    SESSION_LOADED = auto()
    PERFORMANCE_SAMPLE = auto()
    EFFECT_CHANGED = auto()


@dataclass(frozen=True)
class Event:
    type: EventType
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.monotonic)
    source: Optional[str] = None


Handler = Callable[[Event], None]


class EventBus:
    """A simple, thread-safe publish/subscribe event bus."""

    def __init__(self) -> None:
        self._handlers: DefaultDict[EventType, List[Handler]] = defaultdict(list)
        self._lock = threading.RLock()
        self._async_queue: "queue.Queue[Event]" = queue.Queue()
        self._worker: Optional[threading.Thread] = None
        self._running = False

    def subscribe(self, event_type: EventType, handler: Handler) -> Callable[[], None]:
        """Register `handler` for `event_type`. Returns an unsubscribe callable."""
        with self._lock:
            self._handlers[event_type].append(handler)

        def unsubscribe() -> None:
            with self._lock:
                handlers = self._handlers.get(event_type, [])
                if handler in handlers:
                    handlers.remove(handler)

        return unsubscribe

    def subscribe_all(self, handler: Handler) -> Callable[[], None]:
        """Subscribe to every event type currently defined."""
        unsubs = [self.subscribe(t, handler) for t in EventType]

        def unsubscribe_all() -> None:
            for u in unsubs:
                u()

        return unsubscribe_all

    def publish(self, event: Event) -> None:
        """Dispatch `event` synchronously to all subscribed handlers.

        Handler exceptions are caught and logged so one broken subscriber
        (e.g. a UI widget) cannot bring down the publisher (which may be
        deck or mixer code on a latency-sensitive path).
        """
        with self._lock:
            handlers = list(self._handlers.get(event.type, ()))
        for handler in handlers:
            try:
                handler(event)
            except Exception:  # noqa: BLE001 - isolate subscriber failures
                logger.exception("Event handler raised for %s", event.type)

    def emit(self, event_type: EventType, source: Optional[str] = None, **payload: Any) -> None:
        """Convenience: build and publish an event in one call."""
        self.publish(Event(type=event_type, payload=payload, source=source))

    def publish_async(self, event: Event) -> None:
        """Queue `event` for delivery on the bus's background worker thread.

        Useful when a caller is on a latency-sensitive path and cannot
        afford handler execution time synchronously.
        """
        self._ensure_worker()
        self._async_queue.put(event)

    def _ensure_worker(self) -> None:
        if self._worker is not None and self._worker.is_alive():
            return
        self._running = True
        self._worker = threading.Thread(target=self._drain_loop, name="EventBus", daemon=True)
        self._worker.start()

    def _drain_loop(self) -> None:
        while self._running:
            try:
                event = self._async_queue.get(timeout=0.25)
            except queue.Empty:
                continue
            self.publish(event)

    def shutdown(self) -> None:
        self._running = False
        if self._worker is not None:
            self._worker.join(timeout=1.0)


# Process-wide default bus. Subsystems may also construct their own
# private EventBus() for isolated testing.
global_event_bus = EventBus()
