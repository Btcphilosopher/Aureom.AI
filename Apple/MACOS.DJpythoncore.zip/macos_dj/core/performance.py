"""Performance monitoring: CPU, RAM, audio buffer health, callback timing.

Sampled on a low-priority background thread and published through the
event bus so the UI can show it without the monitor itself ever touching
the real-time path (it only *reads* counters the audio engine already
maintains, such as `EngineStats`).
"""

from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from macos_dj.audio.engine import AudioEngine, EngineStats
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PerformanceSample:
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    buffer_usage_percent: float = 0.0
    last_callback_ms: float = 0.0
    max_callback_ms: float = 0.0
    underruns: int = 0
    overruns: int = 0
    active_decks: int = 0
    active_effects: int = 0
    timestamp: float = field(default_factory=time.time)


class PerformanceMonitor:
    def __init__(
        self,
        engine: Optional[AudioEngine] = None,
        event_bus: Optional[EventBus] = None,
        sample_interval_seconds: float = 1.0,
    ) -> None:
        self.engine = engine
        self.events = event_bus or global_event_bus
        self.sample_interval_seconds = sample_interval_seconds
        self.latest: PerformanceSample = PerformanceSample()

        self._active_decks_provider = lambda: 0
        self._active_effects_provider = lambda: 0

        self._running = False
        self._thread: Optional[threading.Thread] = None

    def set_active_decks_provider(self, provider) -> None:  # noqa: ANN001
        self._active_decks_provider = provider

    def set_active_effects_provider(self, provider) -> None:  # noqa: ANN001
        self._active_effects_provider = provider

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, name="PerformanceMonitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def sample_once(self) -> PerformanceSample:
        cpu_percent, memory_mb = _process_resource_usage()

        stats: EngineStats = self.engine.stats if self.engine else EngineStats()
        buffer_capacity_ms = (self.engine.buffer_size / self.engine.sample_rate) * 1000.0 if self.engine and self.engine.sample_rate else 1.0
        buffer_usage = min(100.0, (stats.last_callback_duration_ms / buffer_capacity_ms) * 100.0) if buffer_capacity_ms else 0.0

        sample = PerformanceSample(
            cpu_percent=cpu_percent,
            memory_mb=memory_mb,
            buffer_usage_percent=buffer_usage,
            last_callback_ms=stats.last_callback_duration_ms,
            max_callback_ms=stats.max_callback_duration_ms,
            underruns=stats.underruns,
            overruns=stats.overruns,
            active_decks=self._active_decks_provider(),
            active_effects=self._active_effects_provider(),
        )
        self.latest = sample
        return sample

    def _loop(self) -> None:
        while self._running:
            try:
                sample = self.sample_once()
                self.events.emit(
                    EventType.PERFORMANCE_SAMPLE,
                    cpu_percent=sample.cpu_percent,
                    memory_mb=sample.memory_mb,
                    buffer_usage_percent=sample.buffer_usage_percent,
                    underruns=sample.underruns,
                    overruns=sample.overruns,
                )
            except Exception:
                logger.exception("Performance sampling failed")
            time.sleep(self.sample_interval_seconds)


def _process_resource_usage() -> tuple[float, float]:
    """Return (cpu_percent, memory_mb) for the current process.

    Uses `psutil` when available for accurate CPU percentage; falls back
    to RSS-only reporting via `resource` on POSIX so the monitor still
    works without the optional dependency.
    """
    try:
        import psutil  # type: ignore

        process = psutil.Process(os.getpid())
        return process.cpu_percent(interval=None), process.memory_info().rss / (1024 * 1024)
    except ImportError:
        pass

    try:
        import resource

        usage = resource.getrusage(resource.RUSAGE_SELF)
        # ru_maxrss is KB on Linux, bytes on macOS.
        rss_kb = usage.ru_maxrss / 1024 if usage.ru_maxrss > 10_000_000 else usage.ru_maxrss
        return 0.0, rss_kb / 1024
    except Exception:
        return 0.0, 0.0
