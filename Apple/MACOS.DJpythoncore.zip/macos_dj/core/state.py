"""Thread-safe application state container.

`ApplicationState` is the single serialisable snapshot of "everything the
UI would need to render right now" -- deck states, mixer state, crossfader
position, active session name, and library/analysis progress counters. It
is intentionally a plain, cheap-to-copy structure so it can be published
to the UI boundary at a moderate frame rate without touching audio-thread
data structures directly.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, TypeVar, Generic

T = TypeVar("T")


class StateContainer(Generic[T]):
    """A generic thread-safe box around an immutable state value.

    Readers call `.get()` for a lock-free-ish snapshot (a single
    attribute read of an already-published reference); writers call
    `.set()` or `.update()` under a lock. This mirrors the "atomic
    pointer swap" pattern commonly used to hand data from a worker
    thread to a real-time thread without the real-time thread ever
    blocking on a lock.
    """

    def __init__(self, initial: T) -> None:
        self._lock = threading.Lock()
        self._value = initial

    def get(self) -> T:
        return self._value

    def set(self, value: T) -> None:
        with self._lock:
            self._value = value

    def update(self, fn: "callable[[T], T]") -> T:
        with self._lock:
            self._value = fn(self._value)
            return self._value


@dataclass
class MixerSnapshot:
    channel_gains: Dict[str, float] = field(default_factory=dict)
    crossfader_position: float = 0.0
    master_gain: float = 1.0
    master_peak_db: float = -120.0
    master_rms_db: float = -120.0
    clipping: bool = False


@dataclass
class DeckSnapshot:
    deck_id: str
    track_title: Optional[str] = None
    playing: bool = False
    position_seconds: float = 0.0
    duration_seconds: float = 0.0
    bpm: Optional[float] = None
    pitch: float = 0.0
    is_master: bool = False


@dataclass
class ApplicationState:
    """Top-level, UI-facing snapshot of the whole application."""

    decks: Dict[str, DeckSnapshot] = field(default_factory=dict)
    mixer: MixerSnapshot = field(default_factory=MixerSnapshot)
    session_name: Optional[str] = None
    library_scan_progress: Optional[float] = None  # 0.0-1.0, None = idle
    performance: Dict[str, Any] = field(default_factory=dict)
    recording_active: bool = False


global_state: StateContainer[ApplicationState] = StateContainer(ApplicationState())
