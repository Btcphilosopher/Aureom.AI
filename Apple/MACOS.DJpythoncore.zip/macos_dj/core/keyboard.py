"""Configurable keyboard shortcut layer.

Translates a key name (e.g. "space", "q", "left") into a `Command` via
the same `CommandBus` used by MIDI and the network API, using the
mapping stored in `UIConfig.keyboard_shortcuts`. The actual OS-level key
capture is left to the eventual native UI; this module only owns the
name -> command resolution so it is fully unit-testable headless.
"""

from __future__ import annotations

from typing import Dict, Optional

from macos_dj.core.commands import Command, CommandBus, CommandContext
from macos_dj.core.logging import get_logger

logger = get_logger(__name__)

_FOCUS_DECK_COMMANDS = {"FOCUS_DECK_A", "FOCUS_DECK_B", "FOCUS_DECK_C", "FOCUS_DECK_D"}


class KeyboardController:
    def __init__(self, command_bus: CommandBus, shortcuts: Dict[str, str]) -> None:
        self.command_bus = command_bus
        self.shortcuts = dict(shortcuts)
        self.focused_deck_id: Optional[str] = None

    def set_shortcut(self, key: str, command_name: str) -> None:
        self.shortcuts[key.lower()] = command_name

    def remove_shortcut(self, key: str) -> None:
        self.shortcuts.pop(key.lower(), None)

    def handle_key_press(self, key: str) -> bool:
        key = key.lower()
        command_name = self.shortcuts.get(key)
        if command_name is None:
            return False

        if command_name in _FOCUS_DECK_COMMANDS:
            self.focused_deck_id = command_name.rsplit("_", 1)[-1]
            return True

        if command_name == "PLAY_PAUSE":
            # Resolved against whichever deck currently has UI focus.
            return self.command_bus.execute(Command.PLAY, CommandContext(deck_id=self.focused_deck_id))

        if command_name in ("SEEK_FORWARD", "SEEK_BACKWARD"):
            delta = 5.0 if command_name == "SEEK_FORWARD" else -5.0
            return self.command_bus.execute(
                Command.SEEK_RELATIVE, CommandContext(deck_id=self.focused_deck_id, value=delta)
            )

        return self.command_bus.execute_by_name(command_name, CommandContext(deck_id=self.focused_deck_id))
