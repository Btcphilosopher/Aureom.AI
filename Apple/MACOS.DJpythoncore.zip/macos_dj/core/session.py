"""Session state serialisation, save/load, and crash-recovery checkpoints.

A `Session` captures everything needed to restore a DJ set in progress:
per-deck loaded track + playback state + pitch/EQ/loops/hot cues, plus
mixer state (crossfader, channel faders/EQ, assignments). Sessions are
written atomically (write to a temp file, then rename) so a crash mid-save
can never corrupt the on-disk session or, critically, the music library
database, which is never touched by session save/load at all.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)

SESSION_FORMAT_VERSION = 1


@dataclass
class HotCueState:
    slot: int
    position_seconds: float
    label: str = ""
    color: str = ""
    type: str = "CUE"


@dataclass
class DeckState:
    deck_id: str
    track_id: Optional[str] = None
    file_path: Optional[str] = None
    position_seconds: float = 0.0
    playing: bool = False
    pitch: float = 0.0
    pitch_range: float = 0.08
    eq_low_db: float = 0.0
    eq_mid_db: float = 0.0
    eq_high_db: float = 0.0
    filter_position: float = 0.0
    cue_position: Optional[float] = None
    hot_cues: List[HotCueState] = field(default_factory=list)
    loop_start: Optional[float] = None
    loop_end: Optional[float] = None
    loop_active: bool = False
    is_master: bool = False


@dataclass
class MixerState:
    crossfader_position: float = 0.0
    channel_faders_db: Dict[str, float] = field(default_factory=dict)
    channel_crossfader_assign: Dict[str, str] = field(default_factory=dict)
    master_gain_db: float = 0.0


@dataclass
class Session:
    name: str = "Untitled Session"
    created_at: float = field(default_factory=time.time)
    saved_at: float = field(default_factory=time.time)
    format_version: int = SESSION_FORMAT_VERSION
    decks: List[DeckState] = field(default_factory=list)
    mixer: MixerState = field(default_factory=MixerState)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "Session":
        decks = [
            DeckState(
                **{**d, "hot_cues": [HotCueState(**hc) for hc in d.get("hot_cues", [])]}
            )
            for d in data.get("decks", [])
        ]
        mixer_data = data.get("mixer", {})
        return Session(
            name=data.get("name", "Untitled Session"),
            created_at=data.get("created_at", time.time()),
            saved_at=data.get("saved_at", time.time()),
            format_version=data.get("format_version", SESSION_FORMAT_VERSION),
            decks=decks,
            mixer=MixerState(**mixer_data) if mixer_data else MixerState(),
        )


class SessionManager:
    """Handles save/load plus periodic crash-recovery checkpointing."""

    def __init__(self, sessions_dir: Path) -> None:
        self.sessions_dir = sessions_dir
        self.checkpoint_path = sessions_dir / "_last_session_checkpoint.json"

    def save(self, session: Session, path: Optional[Path] = None) -> Path:
        session.saved_at = time.time()
        target = path or (self.sessions_dir / f"{_safe_filename(session.name)}.json")
        target.parent.mkdir(parents=True, exist_ok=True)
        self._atomic_write(target, session.to_dict())
        logger.info("Session saved: %s", target)
        return target

    def load(self, path: Path) -> Optional[Session]:
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            return Session.from_dict(data)
        except (OSError, json.JSONDecodeError) as exc:
            logger.error("Failed to load session %s: %s", path, exc)
            return None

    def checkpoint(self, session: Session) -> None:
        """Write a crash-recovery checkpoint. Called periodically (e.g. every
        few seconds) from a background timer, never from the audio thread."""
        try:
            self._atomic_write(self.checkpoint_path, session.to_dict())
        except OSError as exc:
            logger.warning("Failed to write crash-recovery checkpoint: %s", exc)

    def has_recoverable_checkpoint(self) -> bool:
        return self.checkpoint_path.exists()

    def load_checkpoint(self) -> Optional[Session]:
        if not self.has_recoverable_checkpoint():
            return None
        return self.load(self.checkpoint_path)

    def clear_checkpoint(self) -> None:
        """Call after a clean shutdown so the next launch doesn't offer a
        stale 'restore last session' prompt."""
        try:
            self.checkpoint_path.unlink(missing_ok=True)
        except OSError:
            logger.exception("Failed to clear crash-recovery checkpoint")

    @staticmethod
    def _atomic_write(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = path.with_suffix(path.suffix + ".tmp")
        with tmp_path.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        tmp_path.replace(path)  # atomic on POSIX filesystems


def _safe_filename(name: str) -> str:
    return "".join(c if c.isalnum() or c in (" ", "-", "_") else "_" for c in name).strip() or "session"
