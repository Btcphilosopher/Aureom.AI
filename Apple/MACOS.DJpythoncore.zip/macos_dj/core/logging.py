"""Structured logging for MACOS.DJ.

Provides a single entry point (`get_logger`) that configures a consistent,
structured logging format across every subsystem (audio, analysis, MIDI,
library, networking). Real-time audio code must NEVER call into the
logging subsystem from inside an audio callback -- log only from the
non-real-time application threads, or push a lightweight event onto a
queue that is drained elsewhere.
"""

from __future__ import annotations

import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Optional

_CONFIGURED = False
_LOG_DIR = Path.home() / "Library" / "Logs" / "MACOS.DJ"

_FORMAT = "%(asctime)s.%(msecs)03d | %(levelname)-8s | %(name)-24s | %(message)s"
_DATEFMT = "%Y-%m-%d %H:%M:%S"


def configure_logging(
    level: int = logging.INFO,
    log_dir: Optional[Path] = None,
    to_console: bool = True,
    to_file: bool = True,
) -> None:
    """Configure the root ``macos_dj`` logger tree. Idempotent."""
    global _CONFIGURED, _LOG_DIR
    if _CONFIGURED:
        return

    if log_dir is not None:
        _LOG_DIR = log_dir

    root = logging.getLogger("macos_dj")
    root.setLevel(level)
    root.propagate = False

    formatter = logging.Formatter(_FORMAT, datefmt=_DATEFMT)

    if to_console:
        console = logging.StreamHandler(stream=sys.stderr)
        console.setFormatter(formatter)
        console.setLevel(level)
        root.addHandler(console)

    if to_file:
        try:
            _LOG_DIR.mkdir(parents=True, exist_ok=True)
            file_handler = logging.handlers.RotatingFileHandler(
                _LOG_DIR / "macos_dj.log",
                maxBytes=5 * 1024 * 1024,
                backupCount=5,
                encoding="utf-8",
            )
            file_handler.setFormatter(formatter)
            file_handler.setLevel(level)
            root.addHandler(file_handler)
        except OSError:
            # Filesystem unavailable (sandboxed test environment, read-only
            # disk, etc). Console logging still works, so degrade gracefully
            # rather than raising during startup.
            root.addHandler(logging.NullHandler())

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger, e.g. ``get_logger(__name__)``.

    Automatically ensures the logging subsystem has been configured with
    sane defaults if the application has not already called
    :func:`configure_logging` explicitly.
    """
    if not _CONFIGURED:
        configure_logging()
    if not name.startswith("macos_dj"):
        name = f"macos_dj.{name}"
    return logging.getLogger(name)
