"""The command system: a single verb set callable from UI, MIDI, keyboard,
or the local network API.

Every user-facing action funnels through `CommandBus.execute`, which
looks up a `CommandHandler` by name and invokes it with a normalised
payload. This keeps input sources decoupled from the deck/mixer/library
objects they ultimately affect -- a MIDI mapping and a keyboard shortcut
can trigger the exact same "PLAY" command without either knowing about
the other.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Callable, Dict, Optional

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


class Command(Enum):
    PLAY = auto()
    PAUSE = auto()
    STOP = auto()
    LOAD_TRACK = auto()
    SET_BPM = auto()
    SET_PITCH = auto()
    RESET_PITCH = auto()
    TRIGGER_CUE = auto()
    SET_LOOP = auto()
    EXIT_LOOP = auto()
    TRIGGER_HOT_CUE = auto()
    CLEAR_HOT_CUE = auto()
    SET_EQ = auto()
    SET_FILTER = auto()
    SET_VOLUME = auto()
    SET_CROSSFADER = auto()
    SYNC = auto()
    SEEK = auto()
    SEEK_RELATIVE = auto()


@dataclass
class CommandContext:
    """The payload a command handler receives. `deck_id` is the primary
    target for deck-scoped commands; other fields are command-specific."""

    deck_id: Optional[str] = None
    value: Optional[float] = None
    extra: Dict[str, Any] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.extra is None:
            self.extra = {}


CommandHandler = Callable[[CommandContext], None]


class CommandBus:
    """Central dispatcher: register handlers once at application wiring
    time, then execute commands from any input source by name."""

    def __init__(self) -> None:
        self._handlers: Dict[Command, CommandHandler] = {}

    def register(self, command: Command, handler: CommandHandler) -> None:
        self._handlers[command] = handler

    def execute(self, command: Command, context: Optional[CommandContext] = None) -> bool:
        handler = self._handlers.get(command)
        if handler is None:
            logger.warning("No handler registered for command %s", command)
            return False
        context = context or CommandContext()
        try:
            handler(context)
            return True
        except Exception:
            logger.exception("Command handler for %s raised", command)
            return False

    def execute_by_name(self, name: str, context: Optional[CommandContext] = None) -> bool:
        try:
            command = Command[name]
        except KeyError:
            logger.warning("Unknown command name: %s", name)
            return False
        return self.execute(command, context)
