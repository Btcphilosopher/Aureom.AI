"""Non-real-time task scheduler.

Everything that must NOT happen on the real-time audio thread (BPM
analysis, waveform generation, database writes, file I/O, network calls)
is submitted here. The scheduler is a thin wrapper around a bounded
thread pool with named priority lanes, so heavy analysis jobs don't
starve quick UI-facing tasks like "save this cue point".
"""

from __future__ import annotations

import concurrent.futures
import threading
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Callable, Dict, Optional

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


class Priority(Enum):
    HIGH = auto()    # UI-facing, must feel instant (cue save, seek persist)
    NORMAL = auto()   # library writes, metadata edits
    LOW = auto()      # BPM/beat/waveform/key analysis, library scans


@dataclass
class ScheduledTask:
    future: concurrent.futures.Future
    name: str
    priority: Priority


class Scheduler:
    """Runs callables off the real-time thread using dedicated pools.

    A dedicated single-thread pool for HIGH priority avoids ordering
    surprises for latency-sensitive persistence tasks, while NORMAL/LOW
    share a larger pool sized for background analysis throughput.
    """

    def __init__(self, background_workers: int = 4) -> None:
        self._high_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="dj-high"
        )
        self._pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, background_workers), thread_name_prefix="dj-bg"
        )
        self._lock = threading.Lock()
        self._tasks: Dict[str, ScheduledTask] = {}
        self._counter = 0

    def submit(
        self,
        func: Callable[..., Any],
        *args: Any,
        name: Optional[str] = None,
        priority: Priority = Priority.NORMAL,
        **kwargs: Any,
    ) -> concurrent.futures.Future:
        pool = self._high_pool if priority is Priority.HIGH else self._pool

        def _run() -> Any:
            try:
                return func(*args, **kwargs)
            except Exception:
                logger.exception("Scheduled task %r failed", name)
                raise

        future = pool.submit(_run)
        with self._lock:
            self._counter += 1
            task_name = name or f"task-{self._counter}"
            self._tasks[task_name] = ScheduledTask(future=future, name=task_name, priority=priority)

        def _cleanup(fut: concurrent.futures.Future, task_name: str = task_name) -> None:
            with self._lock:
                self._tasks.pop(task_name, None)

        future.add_done_callback(_cleanup)
        return future

    def pending_count(self) -> int:
        with self._lock:
            return len(self._tasks)

    def shutdown(self, wait: bool = True) -> None:
        self._high_pool.shutdown(wait=wait)
        self._pool.shutdown(wait=wait)


global_scheduler = Scheduler()
