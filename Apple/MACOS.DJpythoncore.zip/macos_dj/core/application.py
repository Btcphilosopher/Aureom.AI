"""Top-level application: wires every subsystem together.

`Application` is intentionally a thin composition root -- it constructs
each subsystem, registers command handlers on the shared `CommandBus`,
and connects the mixer's per-block output to the audio engine, recorder,
and spectrum analyser. Business logic lives in the subsystems themselves
(decks, mixer, library, analysis); this class should stay boring.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import numpy as np

from macos_dj.analysis.pipeline import AnalysisPipeline
from macos_dj.analysis.spectrum import SpectrumAnalyzer
from macos_dj.audio.engine import AudioEngine
from macos_dj.audio.mixer import Mixer
from macos_dj.audio.player import decode_file
from macos_dj.audio.routing import AudioDevice
from macos_dj.controllers.mapping import MappingEngine
from macos_dj.controllers.midi import MidiInputManager
from macos_dj.core.commands import Command, CommandBus, CommandContext
from macos_dj.core.configuration import ConfigurationManager
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import configure_logging, get_logger
from macos_dj.core.performance import PerformanceMonitor
from macos_dj.core.scheduler import Priority, Scheduler
from macos_dj.core.session import DeckState, MixerState, Session, SessionManager
from macos_dj.decks.manager import DeckManager
from macos_dj.library.database import LibraryDatabase
from macos_dj.library.history import DJHistory
from macos_dj.library.metadata import build_track_from_file, scan_directory
from macos_dj.library.playlists import PlaylistManager
from macos_dj.library.tracks import Track
from macos_dj.recording.recorder import Recorder

logger = get_logger(__name__)


class Application:
    def __init__(self, config_dir: Optional[Path] = None) -> None:
        configure_logging()

        self.config_manager = ConfigurationManager(config_dir=config_dir)
        self.config = self.config_manager.load()

        self.events: EventBus = global_event_bus
        self.scheduler = Scheduler(background_workers=self.config.analysis.max_concurrent_jobs)
        self.command_bus = CommandBus()

        self.deck_manager = DeckManager(
            decks=self.config.decks.deck_count,
            sample_rate=self.config.audio.sample_rate,
            channels=self.config.audio.channels,
            event_bus=self.events,
        )
        for deck in self.deck_manager.all():
            deck.set_pitch_range(self.config.decks.default_pitch_range)

        self.mixer = Mixer(
            channel_ids=self.deck_manager.ids(),
            sample_rate=self.config.audio.sample_rate,
            channels=self.config.audio.channels,
            event_bus=self.events,
        )

        self.audio_engine = AudioEngine(
            sample_rate=self.config.audio.sample_rate,
            buffer_size=self.config.audio.buffer_size,
            channels=self.config.audio.channels,
            event_bus=self.events,
        )
        self.audio_engine.set_render_callback(self._render_block)

        self.spectrum_analyzer = SpectrumAnalyzer(sample_rate=self.config.audio.sample_rate, channels=self.config.audio.channels)
        self.recorder = Recorder(sample_rate=self.config.audio.sample_rate, channels=self.config.audio.channels, event_bus=self.events)
        self.performance_monitor = PerformanceMonitor(engine=self.audio_engine, event_bus=self.events)
        self.performance_monitor.set_active_decks_provider(
            lambda: sum(1 for d in self.deck_manager.all() if d.transport.is_playing)
        )

        self.library_db = LibraryDatabase(Path(self.config.library.database_path))
        self.history = DJHistory(self.library_db)
        self.playlist_manager = PlaylistManager()
        self.analysis_pipeline = AnalysisPipeline(event_bus=self.events)

        self.midi_manager = MidiInputManager(event_bus=self.events)
        self.mapping_engine = MappingEngine()

        self.session_manager = SessionManager(sessions_dir=self.config_manager.config_dir / "sessions")

        self._register_command_handlers()

    # --- Lifecycle -----------------------------------------------------------

    def start_audio(self) -> None:
        if self.config.audio.output_device:
            device = next(
                (d for d in self.audio_engine.device_registry.refresh() if d.name == self.config.audio.output_device),
                None,
            )
            if device:
                self.audio_engine.set_output_device(device)
        self.audio_engine.start()
        self.performance_monitor.start()

    def stop_audio(self) -> None:
        self.performance_monitor.stop()
        self.audio_engine.stop()

    def shutdown(self) -> None:
        self.stop_audio()
        self.midi_manager.close_all()
        if self.recorder.status.active:
            self.recorder.stop()
        self.scheduler.shutdown(wait=False)
        self.library_db.close()
        self.session_manager.clear_checkpoint()

    # --- Real-time render path ------------------------------------------------

    def _render_block(self, n_frames: int) -> np.ndarray:
        deck_blocks: Dict[str, np.ndarray] = {
            deck_id: deck.process_block(n_frames) for deck_id, deck in zip(self.deck_manager.ids(), self.deck_manager.all())
        }
        master_block = self.mixer.process(deck_blocks)
        self.spectrum_analyzer.push(master_block)
        if self.recorder.status.active:
            self.recorder.write_block(master_block)
        return master_block

    # --- Library --------------------------------------------------------------

    def scan_library(self) -> None:
        existing_paths = {t.file_path for t in self.library_db.all_tracks()}
        self.events.emit(EventType.LIBRARY_SCAN_STARTED)

        def _job() -> None:
            all_new_tracks = []
            for location in self.config.library.locations:
                new_tracks, result = scan_directory(Path(location), existing_paths=existing_paths)
                all_new_tracks.extend(new_tracks)
                for error in result.errors:
                    logger.warning("Library scan error: %s", error)
            for track in all_new_tracks:
                self.library_db.upsert_track(track)
                if self.config.analysis.auto_analyze_on_import:
                    self.scheduler.submit(self._analyze_and_store, track, name=f"analyze-{track.id}", priority=Priority.LOW)
            self.events.emit(EventType.LIBRARY_SCAN_COMPLETED, imported=len(all_new_tracks))

        self.scheduler.submit(_job, name="library-scan", priority=Priority.LOW)

    def _analyze_and_store(self, track: Track) -> None:
        result = self.analysis_pipeline.analyze(track)
        self.library_db.upsert_track(result.track)

    def import_and_load_track(self, deck_id: str, file_path: str) -> Optional[Track]:
        existing = self.library_db.get_track_by_path(file_path)
        track = existing or build_track_from_file(Path(file_path))
        if track is None:
            return None
        if existing is None:
            self.library_db.upsert_track(track)
            self.scheduler.submit(self._analyze_and_store, track, name=f"analyze-{track.id}", priority=Priority.LOW)

        try:
            samples, sample_rate = decode_file(track.file_path, target_sample_rate=self.config.audio.sample_rate)
        except Exception:
            logger.exception("Failed to load track %s onto deck %s", file_path, deck_id)
            self.events.emit(EventType.TRACK_LOAD_FAILED, deck_id=deck_id, path=file_path)
            return None

        deck = self.deck_manager.get(deck_id)
        if deck is None:
            return None
        deck.load_track(track, samples, sample_rate)
        return track

    # --- Session ----------------------------------------------------------------

    def build_session_snapshot(self, name: str = "Untitled Session") -> Session:
        deck_states = []
        for deck in self.deck_manager.all():
            loop = deck.loop.active_loop
            deck_states.append(
                DeckState(
                    deck_id=deck.deck_id,
                    track_id=deck.track.id if deck.track else None,
                    file_path=deck.track.file_path if deck.track else None,
                    position_seconds=deck.player.position_seconds,
                    playing=deck.transport.is_playing,
                    pitch=deck._pitch,  # noqa: SLF001 - session serialisation is a privileged reader
                    pitch_range=deck._pitch_range,  # noqa: SLF001
                    eq_low_db=deck.eq.low_db, eq_mid_db=deck.eq.mid_db, eq_high_db=deck.eq.high_db,
                    cue_position=deck.cue.cue_position() if deck.cue.has_cue() else None,
                    loop_start=loop.start_seconds if loop else None,
                    loop_end=loop.end_seconds if loop else None,
                    loop_active=loop is not None,
                    is_master=deck.is_master,
                )
            )
        mixer_state = MixerState(
            crossfader_position=self.mixer.crossfader_position,
            channel_faders_db={cid: 0.0 for cid in self.mixer.channel_strips},
            channel_crossfader_assign={cid: s.crossfader_assign.name for cid, s in self.mixer.channel_strips.items()},
            master_gain_db=0.0,
        )
        return Session(name=name, decks=deck_states, mixer=mixer_state)

    def save_session(self, name: str = "Untitled Session") -> Path:
        session = self.build_session_snapshot(name)
        path = self.session_manager.save(session)
        self.events.emit(EventType.SESSION_SAVED, name=name)
        return path

    def checkpoint_session(self) -> None:
        self.session_manager.checkpoint(self.build_session_snapshot())

    def restore_session(self, session: Session) -> None:
        for deck_state in session.decks:
            if not deck_state.file_path:
                continue
            self.import_and_load_track(deck_state.deck_id, deck_state.file_path)
            deck = self.deck_manager.get(deck_state.deck_id)
            if deck is None:
                continue
            deck.set_pitch_range(deck_state.pitch_range)
            deck.set_pitch(deck_state.pitch)
            deck.set_eq(deck_state.eq_low_db, deck_state.eq_mid_db, deck_state.eq_high_db)
            deck.seek(deck_state.position_seconds)
            if deck_state.cue_position is not None:
                deck.cue.set_cue(deck_state.cue_position)
            if deck_state.is_master:
                self.deck_manager.set_master(deck_state.deck_id)
        self.mixer.set_crossfader(session.mixer.crossfader_position)
        self.events.emit(EventType.SESSION_LOADED, name=session.name)

    # --- Command handler registration -------------------------------------------

    def _register_command_handlers(self) -> None:
        def deck_of(ctx: CommandContext):
            return self.deck_manager.get(ctx.deck_id) if ctx.deck_id else None

        def _play(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.play()

        def _pause(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.pause()

        def _stop(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.stop()

        def _cue(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.cue_press()

        def _seek(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and ctx.value is not None:
                deck.seek(ctx.value)

        def _seek_relative(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and ctx.value is not None:
                deck.seek_relative(ctx.value)

        def _set_pitch(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and ctx.value is not None:
                deck.set_pitch(ctx.value)

        def _reset_pitch(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.reset_pitch()

        def _set_bpm(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and deck.beatgrid and ctx.value is not None:
                deck.beatgrid.set_bpm(ctx.value)
                if deck.track:
                    deck.track.set_manual_bpm(ctx.value)

        def _trigger_cue(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            slot = ctx.extra.get("slot")
            if deck and slot:
                deck.trigger_hot_cue(int(slot))

        def _set_loop(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and ctx.value:
                deck.set_beat_loop(float(ctx.value))

        def _exit_loop(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.loop_exit()

        def _set_eq(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck:
                deck.set_eq(
                    low_db=ctx.extra.get("low"), mid_db=ctx.extra.get("mid"), high_db=ctx.extra.get("high")
                )

        def _set_filter(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            if deck and ctx.value is not None:
                deck.set_filter(ctx.value)

        def _set_volume(ctx: CommandContext) -> None:
            channel_id = ctx.deck_id
            if channel_id and channel_id in self.mixer.channel_strips and ctx.value is not None:
                self.mixer.channel(channel_id).set_fader_db(ctx.value)

        def _set_crossfader(ctx: CommandContext) -> None:
            if ctx.value is not None:
                self.mixer.set_crossfader(ctx.value)

        def _sync(ctx: CommandContext) -> None:
            deck = deck_of(ctx)
            master_id = ctx.extra.get("master_deck_id")
            if deck:
                self.deck_manager.sync_deck(deck.deck_id, master_id)

        self.command_bus.register(Command.PLAY, _play)
        self.command_bus.register(Command.PAUSE, _pause)
        self.command_bus.register(Command.STOP, _stop)
        self.command_bus.register(Command.TRIGGER_CUE, _cue)
        self.command_bus.register(Command.SEEK, _seek)
        self.command_bus.register(Command.SEEK_RELATIVE, _seek_relative)
        self.command_bus.register(Command.SET_PITCH, _set_pitch)
        self.command_bus.register(Command.RESET_PITCH, _reset_pitch)
        self.command_bus.register(Command.SET_BPM, _set_bpm)
        self.command_bus.register(Command.TRIGGER_HOT_CUE, _trigger_cue)
        self.command_bus.register(Command.SET_LOOP, _set_loop)
        self.command_bus.register(Command.EXIT_LOOP, _exit_loop)
        self.command_bus.register(Command.SET_EQ, _set_eq)
        self.command_bus.register(Command.SET_FILTER, _set_filter)
        self.command_bus.register(Command.SET_VOLUME, _set_volume)
        self.command_bus.register(Command.SET_CROSSFADER, _set_crossfader)
        self.command_bus.register(Command.SYNC, _sync)
