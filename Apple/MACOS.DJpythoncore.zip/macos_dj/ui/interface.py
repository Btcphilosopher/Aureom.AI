"""The UI boundary.

This is the only surface a future native macOS interface (or any other
front-end) should depend on. It exposes read-only application state
snapshots (decks, mixer, meters, library search, playlists, effects) and
a single command entry point (`UIBoundary.execute`) built on
`core.commands.CommandBus`. Nothing here imports UI toolkit code, and the
audio engine / deck manager never import this module -- the dependency
points one way, from UI down into the engine, never back.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from macos_dj.audio.channel import ChannelMeter
from macos_dj.audio.master import MeterReading
from macos_dj.core.commands import Command, CommandBus, CommandContext
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.decks.deck import DeckParameters
from macos_dj.decks.manager import DeckManager
from macos_dj.library.playlists import Playlist, PlaylistManager
from macos_dj.library.search import SearchResult, search_tracks
from macos_dj.library.tracks import Track


@dataclass
class LibrarySnapshot:
    tracks: List[Track]
    total_count: int


@dataclass
class MixerSnapshot:
    crossfader_position: float
    channel_meters: Dict[str, ChannelMeter]
    master_meter: MeterReading


class UIBoundary:
    """Facade the UI layer talks to. Construct once at application wiring
    time with references to the live engine subsystems; the UI never
    touches those subsystems directly."""

    def __init__(
        self,
        deck_manager: DeckManager,
        command_bus: CommandBus,
        playlist_manager: PlaylistManager,
        tracks_provider,  # Callable[[], List[Track]]
        mixer=None,  # macos_dj.audio.mixer.Mixer, kept loosely typed to avoid a hard import cycle
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.deck_manager = deck_manager
        self.command_bus = command_bus
        self.playlist_manager = playlist_manager
        self._tracks_provider = tracks_provider
        self.mixer = mixer
        self.events = event_bus or global_event_bus

    # --- State snapshots (read-only) ---------------------------------------

    def deck_snapshot(self, deck_id: str) -> Optional[DeckParameters]:
        deck = self.deck_manager.get(deck_id)
        return deck.to_parameters() if deck else None

    def all_deck_snapshots(self) -> Dict[str, DeckParameters]:
        return {d.deck_id: d.to_parameters() for d in self.deck_manager.all()}

    def library_snapshot(self, query: str = "") -> LibrarySnapshot:
        tracks = self._tracks_provider()
        if query:
            results: List[SearchResult] = search_tracks(tracks, query)
            tracks = [r.track for r in results]
        return LibrarySnapshot(tracks=tracks, total_count=len(tracks))

    def playlists(self) -> List[Playlist]:
        return self.playlist_manager.all()

    def mixer_snapshot(self) -> Optional[MixerSnapshot]:
        if self.mixer is None:
            return None
        return MixerSnapshot(
            crossfader_position=self.mixer.crossfader_position,
            channel_meters=self.mixer.meters(),
            master_meter=self.mixer.master.last_reading,
        )

    # --- Commands -----------------------------------------------------------

    def execute(self, command_name: str, deck_id: Optional[str] = None, value: Optional[float] = None, **extra) -> bool:
        return self.command_bus.execute_by_name(command_name, CommandContext(deck_id=deck_id, value=value, extra=extra))

    # --- Subscriptions --------------------------------------------------------

    def subscribe(self, event_type: EventType, handler) -> None:  # noqa: ANN001
        self.events.subscribe(event_type, handler)
