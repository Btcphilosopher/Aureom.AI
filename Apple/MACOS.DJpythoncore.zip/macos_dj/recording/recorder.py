"""Master output recorder.

`Recorder.write_block` is called from the same place the audio engine
pulls the master mix (a "tap" after the master bus), so recorded audio
always matches what the audience hears, limiter included. File writing
happens on a background thread via a queue so the real-time-adjacent
`write_block` call never blocks on disk I/O.
"""

from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np

from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class RecordingStatus:
    active: bool = False
    paused: bool = False
    duration_seconds: float = 0.0
    peak_level: float = 0.0
    output_path: Optional[str] = None


class Recorder:
    def __init__(
        self,
        sample_rate: int = 44100,
        channels: int = 2,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self.events = event_bus or global_event_bus

        self.status = RecordingStatus()
        self._queue: "queue.Queue[np.ndarray | None]" = queue.Queue()
        self._writer_thread: Optional[threading.Thread] = None
        self._sound_file = None  # type: ignore[assignment]
        self._frames_written = 0
        self._peak = 0.0
        self._lock = threading.Lock()

    def start(self, output_path: Path, fmt: str = "wav", bit_depth: int = 24) -> bool:
        with self._lock:
            if self.status.active:
                logger.warning("Recorder already active; ignoring start()")
                return False

            try:
                import soundfile as sf  # type: ignore
            except ImportError:
                logger.error("Cannot start recording: soundfile is not installed")
                return False

            output_path.parent.mkdir(parents=True, exist_ok=True)
            subtype = {16: "PCM_16", 24: "PCM_24", 32: "PCM_32"}.get(bit_depth, "PCM_24")

            try:
                self._sound_file = sf.SoundFile(
                    str(output_path), mode="w", samplerate=self.sample_rate,
                    channels=self.channels, format=fmt.upper(), subtype=subtype,
                )
            except Exception as exc:  # noqa: BLE001
                logger.error("Failed to open recording file %s: %s", output_path, exc)
                return False

            self._frames_written = 0
            self._peak = 0.0
            self.status = RecordingStatus(active=True, paused=False, output_path=str(output_path))
            self._writer_thread = threading.Thread(target=self._writer_loop, name="Recorder", daemon=True)
            self._writer_thread.start()

        self.events.emit(EventType.RECORDING_STARTED, path=str(output_path))
        logger.info("Recording started: %s", output_path)
        return True

    def write_block(self, block: np.ndarray) -> None:
        """Enqueue a copy of `block` for the writer thread. Safe to call
        frequently from the mixer's real-time-adjacent path; does not
        touch disk itself."""
        if not self.status.active or self.status.paused:
            return
        self._queue.put(block.copy())
        peak = float(np.max(np.abs(block))) if block.size else 0.0
        if peak > self._peak:
            self._peak = peak
            self.status.peak_level = peak

    def pause(self) -> None:
        self.status.paused = True

    def resume(self) -> None:
        self.status.paused = False

    def stop(self) -> Optional[str]:
        with self._lock:
            if not self.status.active:
                return None
            self.status.active = False
            self._queue.put(None)  # sentinel

        if self._writer_thread is not None:
            self._writer_thread.join(timeout=5.0)

        path = self.status.output_path
        self.events.emit(EventType.RECORDING_STOPPED, path=path, duration_seconds=self.status.duration_seconds)
        logger.info("Recording stopped: %s (%.1fs)", path, self.status.duration_seconds)
        return path

    def _writer_loop(self) -> None:
        try:
            while True:
                item = self._queue.get()
                if item is None:
                    break
                if self._sound_file is not None:
                    self._sound_file.write(item)
                    self._frames_written += len(item)
                    self.status.duration_seconds = self._frames_written / self.sample_rate
        except Exception:
            logger.exception("Recorder writer thread failed")
        finally:
            if self._sound_file is not None:
                try:
                    self._sound_file.close()
                except Exception:
                    logger.exception("Error closing recording file")
                self._sound_file = None
