"""Extensible effects framework.

Every effect implements the `Effect` interface (`process`, plus
parameter get/set and bypass). Effects are chainable via `EffectChain`,
which the deck/channel signal path plugs into:

    Deck -> EQ -> Filter -> EffectChain -> Channel -> Master

All effects here are deterministic, allocation-conscious reference
implementations. Heavier/plugin-quality effects (convolution reverb,
etc.) can implement the same interface and be swapped in without
touching the chain or mixer code.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from macos_dj.dsp.gain import db_to_linear


class Effect(ABC):
    """Common interface every DSP effect must implement."""

    name: str = "Effect"

    def __init__(self) -> None:
        self.enabled: bool = True
        self.mix: float = 1.0  # dry/wet, 0..1

    @abstractmethod
    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        """Process a (frames, channels) float32 buffer and return it."""
        raise NotImplementedError

    def set_parameter(self, name: str, value: float) -> None:
        if hasattr(self, name):
            setattr(self, name, value)
        else:
            raise KeyError(f"{self.__class__.__name__} has no parameter {name!r}")

    def get_parameters(self) -> Dict[str, float]:
        return {}

    def reset(self) -> None:
        """Clear internal state (delay lines, filter memory, etc)."""
        return None


class _DelayLine:
    """A simple circular buffer delay line shared by delay/echo/flanger/phaser."""

    def __init__(self, max_samples: int, channels: int) -> None:
        self.buffer = np.zeros((max_samples, channels), dtype=np.float32)
        self.write_pos = 0
        self.size = max_samples

    def write(self, frame: np.ndarray) -> None:
        self.buffer[self.write_pos] = frame
        self.write_pos = (self.write_pos + 1) % self.size

    def read(self, delay_samples: int) -> np.ndarray:
        idx = (self.write_pos - delay_samples) % self.size
        return self.buffer[idx]


class DelayEffect(Effect):
    """Simple digital delay with feedback."""

    name = "Delay"

    def __init__(self, delay_ms: float = 375.0, feedback: float = 0.35, mix: float = 0.3, max_delay_ms: float = 4000.0) -> None:
        super().__init__()
        self.delay_ms = delay_ms
        self.feedback = min(max(feedback, 0.0), 0.98)
        self.mix = mix
        self._max_delay_ms = max_delay_ms
        self._line: Optional[_DelayLine] = None
        self._sample_rate = 44100

    def _ensure_line(self, sample_rate: int, channels: int) -> None:
        needed = int(sample_rate * self._max_delay_ms / 1000.0) + 1
        if self._line is None or self._line.size != needed or self._sample_rate != sample_rate:
            self._line = _DelayLine(needed, channels)
            self._sample_rate = sample_rate

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        if not self.enabled:
            return audio
        frames, channels = audio.shape
        self._ensure_line(sample_rate, channels)
        assert self._line is not None
        delay_samples = max(1, int(sample_rate * self.delay_ms / 1000.0))
        out = np.empty_like(audio)
        for i in range(frames):
            delayed = self._line.read(delay_samples)
            wet = delayed
            fed = audio[i] + delayed * self.feedback
            self._line.write(fed)
            out[i] = audio[i] * (1 - self.mix) + wet * self.mix
        return out

    def get_parameters(self) -> Dict[str, float]:
        return {"delay_ms": self.delay_ms, "feedback": self.feedback, "mix": self.mix}

    def reset(self) -> None:
        self._line = None


class EchoEffect(DelayEffect):
    """A tempo-friendly delay preset with higher feedback (multiple repeats)."""

    name = "Echo"

    def __init__(self, delay_ms: float = 250.0, feedback: float = 0.55, mix: float = 0.35) -> None:
        super().__init__(delay_ms=delay_ms, feedback=feedback, mix=mix)


class ReverbEffect(Effect):
    """A lightweight Schroeder-style reverb (comb + allpass network)."""

    name = "Reverb"

    _COMB_TUNINGS_MS = [29.7, 37.1, 41.1, 43.7]
    _ALLPASS_TUNINGS_MS = [5.0, 1.7]

    def __init__(self, room_size: float = 0.5, damping: float = 0.5, mix: float = 0.25) -> None:
        super().__init__()
        self.room_size = min(max(room_size, 0.0), 1.0)
        self.damping = min(max(damping, 0.0), 1.0)
        self.mix = mix
        self._combs: List[_DelayLine] = []
        self._comb_filters: List[float] = []
        self._allpasses: List[_DelayLine] = []
        self._sample_rate = 0
        self._channels = 0

    def _ensure(self, sample_rate: int, channels: int) -> None:
        if self._sample_rate == sample_rate and self._channels == channels and self._combs:
            return
        self._sample_rate = sample_rate
        self._channels = channels
        self._combs = [
            _DelayLine(max(1, int(sample_rate * ms / 1000.0)), channels)
            for ms in self._COMB_TUNINGS_MS
        ]
        self._comb_filters = [0.0] * len(self._combs)
        self._allpasses = [
            _DelayLine(max(1, int(sample_rate * ms / 1000.0)), channels)
            for ms in self._ALLPASS_TUNINGS_MS
        ]

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        if not self.enabled:
            return audio
        frames, channels = audio.shape
        self._ensure(sample_rate, channels)
        feedback = 0.28 + 0.7 * self.room_size
        out = np.empty_like(audio)
        for i in range(frames):
            x = audio[i]
            comb_sum = np.zeros(channels, dtype=np.float32)
            for ci, comb in enumerate(self._combs):
                delayed = comb.read(comb.size - 1)
                filtered = self._comb_filters[ci] * self.damping + delayed * (1 - self.damping)
                self._comb_filters[ci] = filtered
                comb.write(x + filtered * feedback)
                comb_sum += filtered
            wet = comb_sum / max(len(self._combs), 1)
            for ap in self._allpasses:
                delayed = ap.read(ap.size - 1)
                ap_out = -wet * 0.5 + delayed
                ap.write(wet + delayed * 0.5)
                wet = ap_out
            out[i] = x * (1 - self.mix) + wet * self.mix
        return out

    def get_parameters(self) -> Dict[str, float]:
        return {"room_size": self.room_size, "damping": self.damping, "mix": self.mix}

    def reset(self) -> None:
        self._combs = []
        self._allpasses = []


class _LFOModulatedDelay(Effect):
    """Shared base for phaser/flanger: a short delay modulated by an LFO."""

    def __init__(self, rate_hz: float, depth_ms: float, base_ms: float, feedback: float, mix: float) -> None:
        super().__init__()
        self.rate_hz = rate_hz
        self.depth_ms = depth_ms
        self.base_ms = base_ms
        self.feedback = min(max(feedback, -0.95), 0.95)
        self.mix = mix
        self._phase = 0.0
        self._line: Optional[_DelayLine] = None
        self._sample_rate = 0

    def _ensure_line(self, sample_rate: int, channels: int) -> None:
        needed = int(sample_rate * (self.base_ms + self.depth_ms + 5) / 1000.0) + 2
        if self._line is None or self._line.size != needed or self._sample_rate != sample_rate:
            self._line = _DelayLine(needed, channels)
            self._sample_rate = sample_rate

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        if not self.enabled:
            return audio
        frames, channels = audio.shape
        self._ensure_line(sample_rate, channels)
        assert self._line is not None
        phase_inc = 2 * math.pi * self.rate_hz / sample_rate
        out = np.empty_like(audio)
        for i in range(frames):
            lfo = (math.sin(self._phase) + 1.0) / 2.0
            delay_ms = self.base_ms + lfo * self.depth_ms
            delay_samples = max(1, int(sample_rate * delay_ms / 1000.0))
            delayed = self._line.read(delay_samples)
            self._line.write(audio[i] + delayed * self.feedback)
            out[i] = audio[i] * (1 - self.mix) + delayed * self.mix
            self._phase += phase_inc
            if self._phase > 2 * math.pi:
                self._phase -= 2 * math.pi
        return out

    def get_parameters(self) -> Dict[str, float]:
        return {"rate_hz": self.rate_hz, "depth_ms": self.depth_ms, "feedback": self.feedback, "mix": self.mix}

    def reset(self) -> None:
        self._line = None
        self._phase = 0.0


class FlangerEffect(_LFOModulatedDelay):
    name = "Flanger"

    def __init__(self, rate_hz: float = 0.25, depth_ms: float = 3.0, feedback: float = 0.4, mix: float = 0.4) -> None:
        super().__init__(rate_hz=rate_hz, depth_ms=depth_ms, base_ms=1.0, feedback=feedback, mix=mix)


class PhaserEffect(_LFOModulatedDelay):
    """Approximated here as a very short modulated delay (a cheap stand-in
    for a true allpass-cascade phaser -- swap for a native implementation
    for accurate phasing artifacts)."""

    name = "Phaser"

    def __init__(self, rate_hz: float = 0.5, depth_ms: float = 0.6, feedback: float = 0.3, mix: float = 0.5) -> None:
        super().__init__(rate_hz=rate_hz, depth_ms=depth_ms, base_ms=0.3, feedback=feedback, mix=mix)


class DistortionEffect(Effect):
    name = "Distortion"

    def __init__(self, drive_db: float = 12.0, mix: float = 0.5) -> None:
        super().__init__()
        self.drive_db = drive_db
        self.mix = mix

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        if not self.enabled:
            return audio
        drive = db_to_linear(self.drive_db)
        driven = np.tanh(audio * drive)
        return audio * (1 - self.mix) + driven * self.mix

    def get_parameters(self) -> Dict[str, float]:
        return {"drive_db": self.drive_db, "mix": self.mix}


class BitcrusherEffect(Effect):
    name = "Bitcrusher"

    def __init__(self, bit_depth: float = 8.0, sample_rate_divisor: int = 4, mix: float = 0.5) -> None:
        super().__init__()
        self.bit_depth = bit_depth
        self.sample_rate_divisor = max(1, sample_rate_divisor)
        self.mix = mix
        self._hold = None
        self._counter = 0

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        if not self.enabled:
            return audio
        levels = 2 ** max(1, int(self.bit_depth))
        step = 2.0 / levels
        quantized = np.round(audio / step) * step

        frames, channels = audio.shape
        if self._hold is None or self._hold.shape != (channels,):
            self._hold = np.zeros(channels, dtype=np.float32)
        out = np.empty_like(audio)
        for i in range(frames):
            if self._counter % self.sample_rate_divisor == 0:
                self._hold = quantized[i]
            out[i] = self._hold
            self._counter += 1
        return audio * (1 - self.mix) + out * self.mix

    def get_parameters(self) -> Dict[str, float]:
        return {"bit_depth": self.bit_depth, "sample_rate_divisor": float(self.sample_rate_divisor), "mix": self.mix}

    def reset(self) -> None:
        self._hold = None
        self._counter = 0


@dataclass
class EffectSlot:
    effect: Effect
    enabled: bool = True


class EffectChain:
    """An ordered, chainable sequence of effects applied to one signal path."""

    def __init__(self) -> None:
        self.slots: List[EffectSlot] = []

    def append(self, effect: Effect) -> None:
        self.slots.append(EffectSlot(effect=effect))

    def remove(self, effect: Effect) -> None:
        self.slots = [s for s in self.slots if s.effect is not effect]

    def clear(self) -> None:
        self.slots.clear()

    def process(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        for slot in self.slots:
            if slot.enabled and slot.effect.enabled:
                audio = slot.effect.process(audio, sample_rate)
        return audio


EFFECT_REGISTRY: Dict[str, type] = {
    "delay": DelayEffect,
    "echo": EchoEffect,
    "reverb": ReverbEffect,
    "flanger": FlangerEffect,
    "phaser": PhaserEffect,
    "distortion": DistortionEffect,
    "bitcrusher": BitcrusherEffect,
}


def create_effect(effect_id: str, **kwargs: float) -> Effect:
    cls = EFFECT_REGISTRY.get(effect_id.lower())
    if cls is None:
        raise KeyError(f"Unknown effect id: {effect_id!r}")
    return cls(**kwargs)
