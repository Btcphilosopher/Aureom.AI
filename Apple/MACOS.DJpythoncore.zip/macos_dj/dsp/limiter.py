"""Master brickwall peak limiter.

A lookahead-free, feed-forward limiter suitable as the last stage before
the master output / recorder tap. It is deliberately simple and cheap so
it is safe to run unconditionally in the real-time audio callback: no
allocations per block, bounded work per sample.
"""

from __future__ import annotations

import numpy as np

from macos_dj.dsp.gain import db_to_linear


class Limiter:
    def __init__(
        self,
        sample_rate: int = 44100,
        threshold_db: float = -0.3,
        release_ms: float = 50.0,
        attack_ms: float = 1.0,
    ) -> None:
        self.sample_rate = sample_rate
        self.threshold = db_to_linear(threshold_db)
        self._release_coeff = self._time_to_coeff(release_ms)
        self._attack_coeff = self._time_to_coeff(attack_ms)
        self._envelope = 1.0
        self.gain_reduction_db = 0.0

    def _time_to_coeff(self, ms: float) -> float:
        ms = max(ms, 0.1)
        return float(np.exp(-1.0 / (self.sample_rate * (ms / 1000.0))))

    def set_threshold_db(self, db: float) -> None:
        self.threshold = db_to_linear(db)

    def process(self, buffer: np.ndarray) -> np.ndarray:
        """Process a (frames, channels) buffer in place, mono-summed detection."""
        peak_per_frame = np.max(np.abs(buffer), axis=1) if buffer.ndim > 1 else np.abs(buffer)
        env = self._envelope
        gains = np.empty_like(peak_per_frame, dtype=np.float64)
        for i, peak in enumerate(peak_per_frame):
            target_gain = 1.0
            if peak > self.threshold and peak > 0:
                target_gain = self.threshold / peak
            coeff = self._attack_coeff if target_gain < env else self._release_coeff
            env = target_gain + coeff * (env - target_gain)
            gains[i] = env
        self._envelope = env
        self.gain_reduction_db = float(20.0 * np.log10(max(min(gains), 1e-9)))
        if buffer.ndim > 1:
            buffer *= gains[:, None]
        else:
            buffer *= gains
        np.clip(buffer, -1.0, 1.0, out=buffer)
        return buffer
