"""Simple, allocation-free gain / trim stage.

Gain is expressed in linear amplitude for the audio-thread hot path and
in decibels for anything UI-facing; helpers convert between the two.
"""

from __future__ import annotations

import math

import numpy as np


def db_to_linear(db: float) -> float:
    return float(10.0 ** (db / 20.0))


def linear_to_db(linear: float) -> float:
    linear = max(linear, 1e-9)
    return float(20.0 * math.log10(linear))


class Gain:
    """Applies a smoothed linear gain to an audio buffer in place.

    Smoothing avoids zipper noise / clicks when gain changes are applied
    between callback blocks (e.g. a fader move) by ramping toward the
    target over the block instead of jumping instantaneously.
    """

    __slots__ = ("target", "_current")

    def __init__(self, initial_db: float = 0.0) -> None:
        self.target = db_to_linear(initial_db)
        self._current = self.target

    def set_db(self, db: float) -> None:
        self.target = db_to_linear(db)

    def set_linear(self, linear: float) -> None:
        self.target = max(0.0, linear)

    def process(self, buffer: np.ndarray) -> np.ndarray:
        """Apply gain in place to a (frames, channels) float32 buffer."""
        n = buffer.shape[0]
        if n == 0:
            return buffer
        if abs(self.target - self._current) < 1e-6:
            buffer *= self._current
            return buffer
        ramp = np.linspace(self._current, self.target, num=n, dtype=np.float32)
        buffer *= ramp[:, None] if buffer.ndim > 1 else ramp
        self._current = self.target
        return buffer
