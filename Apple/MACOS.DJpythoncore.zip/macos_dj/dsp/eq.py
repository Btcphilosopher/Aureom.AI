"""Three-band EQ built from cascaded biquad shelving/peaking filters.

This is a Python reference implementation of the classic DJ-mixer-style
3-band EQ (LOW / MID / HIGH, each with a +/- range and a "kill" at full
counter-clockwise). It uses the RBJ (Robert Bristow-Johnson) biquad
cookbook formulas, which are well understood, deterministic, and easy to
unit test -- a good baseline that a future native, analogue-modelled EQ
can replace behind the same `ThreeBandEQ` interface.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass
class BiquadCoefficients:
    b0: float
    b1: float
    b2: float
    a1: float
    a2: float


class Biquad:
    """A single Direct Form I biquad filter, stereo-capable.

    Keeps its own state (z1, z2 per channel) so it can be called block by
    block from the audio thread without allocating.
    """

    __slots__ = ("coeffs", "_z1", "_z2")

    def __init__(self, coeffs: BiquadCoefficients, channels: int = 2) -> None:
        self.coeffs = coeffs
        self._z1 = np.zeros(channels, dtype=np.float64)
        self._z2 = np.zeros(channels, dtype=np.float64)

    def set_coefficients(self, coeffs: BiquadCoefficients) -> None:
        self.coeffs = coeffs

    def process(self, buffer: np.ndarray) -> np.ndarray:
        """Process a (frames, channels) float32/float64 buffer in place."""
        c = self.coeffs
        frames, channels = buffer.shape
        if channels != self._z1.shape[0]:
            self._z1 = np.zeros(channels, dtype=np.float64)
            self._z2 = np.zeros(channels, dtype=np.float64)
        z1, z2 = self._z1, self._z2
        for i in range(frames):
            x = buffer[i].astype(np.float64)
            y = c.b0 * x + z1
            z1 = c.b1 * x - c.a1 * y + z2
            z2 = c.b2 * x - c.a2 * y
            buffer[i] = y
        self._z1, self._z2 = z1, z2
        return buffer


def _low_shelf(freq: float, sample_rate: float, gain_db: float, q: float = 0.707) -> BiquadCoefficients:
    a = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)
    two_sqrt_a_alpha = 2 * math.sqrt(a) * alpha

    b0 = a * ((a + 1) - (a - 1) * cos_w0 + two_sqrt_a_alpha)
    b1 = 2 * a * ((a - 1) - (a + 1) * cos_w0)
    b2 = a * ((a + 1) - (a - 1) * cos_w0 - two_sqrt_a_alpha)
    a0 = (a + 1) + (a - 1) * cos_w0 + two_sqrt_a_alpha
    a1 = -2 * ((a - 1) + (a + 1) * cos_w0)
    a2 = (a + 1) + (a - 1) * cos_w0 - two_sqrt_a_alpha
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


def _high_shelf(freq: float, sample_rate: float, gain_db: float, q: float = 0.707) -> BiquadCoefficients:
    a = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)
    two_sqrt_a_alpha = 2 * math.sqrt(a) * alpha

    b0 = a * ((a + 1) + (a - 1) * cos_w0 + two_sqrt_a_alpha)
    b1 = -2 * a * ((a - 1) + (a + 1) * cos_w0)
    b2 = a * ((a + 1) + (a - 1) * cos_w0 - two_sqrt_a_alpha)
    a0 = (a + 1) - (a - 1) * cos_w0 + two_sqrt_a_alpha
    a1 = 2 * ((a - 1) - (a + 1) * cos_w0)
    a2 = (a + 1) - (a - 1) * cos_w0 - two_sqrt_a_alpha
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


def _peaking(freq: float, sample_rate: float, gain_db: float, q: float = 1.0) -> BiquadCoefficients:
    a = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)

    b0 = 1 + alpha * a
    b1 = -2 * cos_w0
    b2 = 1 - alpha * a
    a0 = 1 + alpha / a
    a1 = -2 * cos_w0
    a2 = 1 - alpha / a
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


#: EQ kill gain: DJ mixer EQs typically go well past -26dB to a hard kill.
KILL_GAIN_DB = -60.0

LOW_FREQ_HZ = 250.0
MID_FREQ_HZ = 1000.0
HIGH_FREQ_HZ = 6000.0


class ThreeBandEQ:
    """LOW / MID / HIGH channel EQ with a shared, replaceable interface.

    Gains are expressed in dB, typically in the range [-26, +6] with a
    "kill" convenience method that snaps a band to `KILL_GAIN_DB`.
    """

    def __init__(self, sample_rate: int = 44100, channels: int = 2) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self._low_gain_db = 0.0
        self._mid_gain_db = 0.0
        self._high_gain_db = 0.0
        self._low = Biquad(_low_shelf(LOW_FREQ_HZ, sample_rate, 0.0), channels)
        self._mid = Biquad(_peaking(MID_FREQ_HZ, sample_rate, 0.0, q=0.9), channels)
        self._high = Biquad(_high_shelf(HIGH_FREQ_HZ, sample_rate, 0.0), channels)

    @property
    def low_db(self) -> float:
        return self._low_gain_db

    @property
    def mid_db(self) -> float:
        return self._mid_gain_db

    @property
    def high_db(self) -> float:
        return self._high_gain_db

    def set_low(self, gain_db: float) -> None:
        self._low_gain_db = gain_db
        self._low.set_coefficients(_low_shelf(LOW_FREQ_HZ, self.sample_rate, gain_db))

    def set_mid(self, gain_db: float) -> None:
        self._mid_gain_db = gain_db
        self._mid.set_coefficients(_peaking(MID_FREQ_HZ, self.sample_rate, gain_db, q=0.9))

    def set_high(self, gain_db: float) -> None:
        self._high_gain_db = gain_db
        self._high.set_coefficients(_high_shelf(HIGH_FREQ_HZ, self.sample_rate, gain_db))

    def kill_low(self) -> None:
        self.set_low(KILL_GAIN_DB)

    def kill_mid(self) -> None:
        self.set_mid(KILL_GAIN_DB)

    def kill_high(self) -> None:
        self.set_high(KILL_GAIN_DB)

    def bands_db(self) -> Tuple[float, float, float]:
        return (self._low_gain_db, self._mid_gain_db, self._high_gain_db)

    def process(self, buffer: np.ndarray) -> np.ndarray:
        """Process a (frames, channels) buffer through LOW -> MID -> HIGH."""
        self._low.process(buffer)
        self._mid.process(buffer)
        self._high.process(buffer)
        return buffer
