"""Resonant LOW-PASS / HIGH-PASS / BAND-PASS filter for the mixer/channel filter knob.

Modelled as a single classic DJ-style filter control: center position is
"off" (bypass), turning right sweeps a low-pass cutoff down from Nyquist,
turning left sweeps a high-pass cutoff up from DC. This mirrors the
familiar single-knob filter found on club mixers and DJ controllers.
"""

from __future__ import annotations

import math
from enum import Enum, auto

import numpy as np

from macos_dj.dsp.eq import Biquad, BiquadCoefficients


class FilterMode(Enum):
    LOW_PASS = auto()
    HIGH_PASS = auto()
    BAND_PASS = auto()
    OFF = auto()


def _lowpass(freq: float, sample_rate: float, q: float) -> BiquadCoefficients:
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)
    b0 = (1 - cos_w0) / 2
    b1 = 1 - cos_w0
    b2 = (1 - cos_w0) / 2
    a0 = 1 + alpha
    a1 = -2 * cos_w0
    a2 = 1 - alpha
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


def _highpass(freq: float, sample_rate: float, q: float) -> BiquadCoefficients:
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)
    b0 = (1 + cos_w0) / 2
    b1 = -(1 + cos_w0)
    b2 = (1 + cos_w0) / 2
    a0 = 1 + alpha
    a1 = -2 * cos_w0
    a2 = 1 - alpha
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


def _bandpass(freq: float, sample_rate: float, q: float) -> BiquadCoefficients:
    w0 = 2 * math.pi * freq / sample_rate
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2 * q)
    b0 = alpha
    b1 = 0.0
    b2 = -alpha
    a0 = 1 + alpha
    a1 = -2 * cos_w0
    a2 = 1 - alpha
    return BiquadCoefficients(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


MIN_FREQ_HZ = 20.0
MAX_FREQ_HZ = 20000.0


class ResonantFilter:
    """A single-knob sweepable filter: LP, HP, or BP with resonance and mix."""

    def __init__(self, sample_rate: int = 44100, channels: int = 2) -> None:
        self.sample_rate = sample_rate
        self.mode = FilterMode.OFF
        self.frequency_hz = MAX_FREQ_HZ
        self.resonance = 0.707  # Q
        self.mix = 1.0  # 0 = dry, 1 = fully filtered
        self._biquad = Biquad(_lowpass(MAX_FREQ_HZ, sample_rate, self.resonance), channels)

    def set_frequency(self, freq_hz: float) -> None:
        self.frequency_hz = float(min(max(freq_hz, MIN_FREQ_HZ), MAX_FREQ_HZ))
        self._recompute()

    def set_resonance(self, q: float) -> None:
        self.resonance = float(max(0.1, min(q, 20.0)))
        self._recompute()

    def set_mode(self, mode: FilterMode) -> None:
        self.mode = mode
        self._recompute()

    def set_mix(self, mix: float) -> None:
        self.mix = float(min(max(mix, 0.0), 1.0))

    def set_knob_position(self, position: float) -> None:
        """Map a single -1..+1 mixer-style knob to mode + frequency.

        position == 0 -> bypass. Negative -> high-pass sweeping up from
        DC as the knob moves further left. Positive -> low-pass sweeping
        down from Nyquist as the knob moves further right.
        """
        position = max(-1.0, min(1.0, position))
        if abs(position) < 1e-3:
            self.set_mode(FilterMode.OFF)
            return
        if position > 0:
            # Exponential sweep from ~20kHz down to ~200Hz.
            t = position
            freq = MAX_FREQ_HZ * (200.0 / MAX_FREQ_HZ) ** t
            self.set_mode(FilterMode.LOW_PASS)
            self.set_frequency(freq)
        else:
            t = -position
            freq = MIN_FREQ_HZ * (2000.0 / MIN_FREQ_HZ) ** t
            self.set_mode(FilterMode.HIGH_PASS)
            self.set_frequency(freq)

    def _recompute(self) -> None:
        if self.mode == FilterMode.LOW_PASS:
            self._biquad.set_coefficients(_lowpass(self.frequency_hz, self.sample_rate, self.resonance))
        elif self.mode == FilterMode.HIGH_PASS:
            self._biquad.set_coefficients(_highpass(self.frequency_hz, self.sample_rate, self.resonance))
        elif self.mode == FilterMode.BAND_PASS:
            self._biquad.set_coefficients(_bandpass(self.frequency_hz, self.sample_rate, self.resonance))

    def process(self, buffer: np.ndarray) -> np.ndarray:
        if self.mode == FilterMode.OFF:
            return buffer
        if self.mix >= 0.999:
            return self._biquad.process(buffer)
        dry = buffer.copy()
        wet = self._biquad.process(buffer)
        buffer[:] = dry * (1.0 - self.mix) + wet * self.mix
        return buffer
