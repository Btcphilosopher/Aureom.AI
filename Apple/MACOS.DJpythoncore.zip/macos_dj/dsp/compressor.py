"""Feed-forward RMS compressor.

Optional dynamics stage usable on the master bus or an individual
channel. Kept separate from `Limiter` (peak, brickwall) since a
compressor's musical role -- gentle gain reduction with ratio/knee -- is
different from a limiter's safety role.
"""

from __future__ import annotations

import numpy as np

from macos_dj.dsp.gain import db_to_linear, linear_to_db


class Compressor:
    def __init__(
        self,
        sample_rate: int = 44100,
        threshold_db: float = -18.0,
        ratio: float = 4.0,
        attack_ms: float = 10.0,
        release_ms: float = 150.0,
        knee_db: float = 6.0,
        makeup_db: float = 0.0,
    ) -> None:
        self.sample_rate = sample_rate
        self.threshold_db = threshold_db
        self.ratio = max(ratio, 1.0)
        self.knee_db = max(knee_db, 0.0)
        self.makeup = db_to_linear(makeup_db)
        self._attack_coeff = self._coeff(attack_ms)
        self._release_coeff = self._coeff(release_ms)
        self._envelope_db = -120.0
        self.gain_reduction_db = 0.0

    def _coeff(self, ms: float) -> float:
        ms = max(ms, 0.1)
        return float(np.exp(-1.0 / (self.sample_rate * (ms / 1000.0))))

    def _gain_computer(self, level_db: float) -> float:
        """Soft-knee gain computer; returns the target level in dB post-compression."""
        overshoot = level_db - self.threshold_db
        if overshoot <= -self.knee_db / 2:
            return level_db
        if overshoot >= self.knee_db / 2:
            return self.threshold_db + overshoot / self.ratio
        # Within the knee: smooth quadratic interpolation.
        knee_frac = (overshoot + self.knee_db / 2) / self.knee_db
        gain_reduction = (1 - 1 / self.ratio) * (knee_frac ** 2) * (self.knee_db / 2)
        return level_db - gain_reduction

    def process(self, buffer: np.ndarray) -> np.ndarray:
        level = np.abs(buffer).max(axis=1) if buffer.ndim > 1 else np.abs(buffer)
        env_db = self._envelope_db
        gains = np.empty(buffer.shape[0], dtype=np.float64)
        for i, sample_level in enumerate(level):
            input_db = linear_to_db(max(sample_level, 1e-9))
            target_db = self._gain_computer(input_db)
            reduction_db = target_db - input_db  # <= 0
            coeff = self._attack_coeff if reduction_db < env_db else self._release_coeff
            env_db = reduction_db + coeff * (env_db - reduction_db)
            gains[i] = db_to_linear(env_db)
        self._envelope_db = env_db
        self.gain_reduction_db = float(env_db)
        if buffer.ndim > 1:
            buffer *= gains[:, None]
        else:
            buffer *= gains
        buffer *= self.makeup
        return buffer
