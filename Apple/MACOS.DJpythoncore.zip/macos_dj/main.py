"""MACOS.DJ entry point.

Boots the Application composition root, offers crash recovery if a
previous session checkpoint exists, starts the audio engine, and (if
enabled in configuration) the local control API. This file is
deliberately thin -- almost everything interesting lives in
`macos_dj.core.application.Application` and the subsystem modules it
wires together.

This is a headless bring-up entry point for the Python foundation; the
eventual native macOS UI will drive the same `Application`/`UIBoundary`
objects instead of this CLI loop.
"""

from __future__ import annotations

import argparse
import signal
import sys
import time

from macos_dj.core.application import Application
from macos_dj.core.logging import get_logger
from macos_dj.networking.api import CommandDispatcher, LocalAPIServer, build_default_routes

logger = get_logger("main")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="macos-dj", description="MACOS.DJ Python core engine")
    parser.add_argument("--no-audio", action="store_true", help="Do not start the audio engine (headless/dev mode)")
    parser.add_argument("--scan-library", action="store_true", help="Scan configured library locations on startup")
    parser.add_argument("--restore-session", action="store_true", help="Offer to restore the last crash-recovery checkpoint")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    app = Application()

    if args.restore_session and app.session_manager.has_recoverable_checkpoint():
        checkpoint = app.session_manager.load_checkpoint()
        if checkpoint is not None:
            logger.info("Recoverable session checkpoint found: %s (saved %s)", checkpoint.name, checkpoint.saved_at)
            app.restore_session(checkpoint)

    if args.scan_library:
        app.scan_library()

    api_server = None
    if app.config.network.api_enabled:
        dispatcher = CommandDispatcher()

        def _state_snapshot() -> dict:
            deck_params = {d.deck_id: d.to_parameters().__dict__ for d in app.deck_manager.all()}
            return {
                "decks": deck_params,
                "library": {"track_count": len(app.library_db.all_tracks())},
                "session": {"name": "current"},
            }

        build_default_routes(
            dispatcher,
            state_provider=_state_snapshot,
            command_handler=lambda body: {
                "ok": app.command_bus.execute_by_name(body.get("command", ""), None) if body.get("command") else False
            },
        )
        api_server = LocalAPIServer(dispatcher, host=app.config.network.api_host, port=app.config.network.api_port)
        api_server.start()

    if not args.no_audio:
        app.start_audio()

    shutdown_requested = {"flag": False}

    def _handle_signal(signum, frame) -> None:  # noqa: ANN001
        logger.info("Received signal %s; shutting down", signum)
        shutdown_requested["flag"] = True

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    logger.info("MACOS.DJ core engine running (%d decks). Press Ctrl+C to exit.", app.deck_manager.count)

    try:
        last_checkpoint = time.monotonic()
        while not shutdown_requested["flag"]:
            time.sleep(0.25)
            if time.monotonic() - last_checkpoint > 10.0:
                app.checkpoint_session()
                last_checkpoint = time.monotonic()
    finally:
        if api_server is not None:
            api_server.stop()
        app.shutdown()

    return 0


if __name__ == "__main__":
    sys.exit(main())
