"""MIDI mapping system: raw input -> DJ command.

Mappings are data (loadable/saveable as JSON) rather than code, so
supporting a new controller is a matter of authoring a mapping file, not
writing Python. `MappingEngine` translates a raw `MidiMessage` into a
`MappedCommand` using the active `ControllerMapping`.

    MIDI INPUT -> MAPPING -> DJ COMMAND -> DECK / MIXER
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class MidiTrigger:
    """What raw MIDI event a mapping entry responds to."""

    message_type: str  # "note_on", "note_off", "control_change", "pitch_bend"
    channel: int
    control_or_note: int

    def key(self) -> tuple:
        return (self.message_type, self.channel, self.control_or_note)


@dataclass
class MappingEntry:
    trigger: MidiTrigger
    command: str          # e.g. "PLAY", "SET_EQ_LOW", "TRIGGER_HOT_CUE"
    target_deck: Optional[str] = None
    parameter_scale: float = 1.0  # scales a 0..1 normalised value to command units
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MappedCommand:
    command: str
    target_deck: Optional[str]
    value: Optional[float]
    extra: Dict[str, Any]


class ControllerMapping:
    """A named collection of mapping entries for one controller model."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._entries: Dict[tuple, MappingEntry] = {}

    def add(self, entry: MappingEntry) -> None:
        self._entries[entry.trigger.key()] = entry

    def remove(self, trigger: MidiTrigger) -> None:
        self._entries.pop(trigger.key(), None)

    def lookup(self, trigger: MidiTrigger) -> Optional[MappingEntry]:
        return self._entries.get(trigger.key())

    def entries(self) -> List[MappingEntry]:
        return list(self._entries.values())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "entries": [
                {
                    "message_type": e.trigger.message_type,
                    "channel": e.trigger.channel,
                    "control_or_note": e.trigger.control_or_note,
                    "command": e.command,
                    "target_deck": e.target_deck,
                    "parameter_scale": e.parameter_scale,
                    "extra": e.extra,
                }
                for e in self._entries.values()
            ],
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "ControllerMapping":
        mapping = ControllerMapping(data.get("name", "Unnamed"))
        for raw in data.get("entries", []):
            trigger = MidiTrigger(
                message_type=raw["message_type"],
                channel=raw["channel"],
                control_or_note=raw["control_or_note"],
            )
            entry = MappingEntry(
                trigger=trigger,
                command=raw["command"],
                target_deck=raw.get("target_deck"),
                parameter_scale=raw.get("parameter_scale", 1.0),
                extra=raw.get("extra", {}),
            )
            mapping.add(entry)
        return mapping

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2)

    @staticmethod
    def load(path: Path) -> "ControllerMapping":
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return ControllerMapping.from_dict(data)


class MappingEngine:
    """Resolves raw MIDI messages to DJ commands via the active mapping."""

    def __init__(self, mapping: Optional[ControllerMapping] = None) -> None:
        self.mapping = mapping or ControllerMapping("Default")

    def set_mapping(self, mapping: ControllerMapping) -> None:
        self.mapping = mapping

    def resolve(self, trigger: MidiTrigger, raw_value: int) -> Optional[MappedCommand]:
        entry = self.mapping.lookup(trigger)
        if entry is None:
            return None

        normalised = raw_value / 127.0 if trigger.message_type in ("control_change", "pitch_bend") else None
        value = normalised * entry.parameter_scale if normalised is not None else None
        return MappedCommand(command=entry.command, target_deck=entry.target_deck, value=value, extra=entry.extra)


def default_two_deck_mapping() -> ControllerMapping:
    """A minimal, sane starting mapping usable with generic class-compliant
    MIDI controllers, intended as a template users customise."""
    mapping = ControllerMapping("Generic 2-Deck")
    entries = [
        MappingEntry(MidiTrigger("note_on", 0, 0x0B), "PLAY", target_deck="A"),
        MappingEntry(MidiTrigger("note_on", 1, 0x0B), "PLAY", target_deck="B"),
        MappingEntry(MidiTrigger("note_on", 0, 0x0C), "CUE", target_deck="A"),
        MappingEntry(MidiTrigger("note_on", 1, 0x0C), "CUE", target_deck="B"),
        MappingEntry(MidiTrigger("control_change", 0, 0x00), "SET_EQ_HIGH", target_deck="A", parameter_scale=52.0, extra={"offset": -26.0}),
        MappingEntry(MidiTrigger("control_change", 0, 0x01), "SET_EQ_MID", target_deck="A", parameter_scale=52.0, extra={"offset": -26.0}),
        MappingEntry(MidiTrigger("control_change", 0, 0x02), "SET_EQ_LOW", target_deck="A", parameter_scale=52.0, extra={"offset": -26.0}),
        MappingEntry(MidiTrigger("control_change", 6, 0x00), "SET_CROSSFADER", parameter_scale=2.0, extra={"offset": -1.0}),
    ]
    for e in entries:
        mapping.add(e)
    return mapping
