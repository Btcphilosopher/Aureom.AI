"""In-memory model of a connected control surface's current input state.

Kept separate from the raw MIDI layer so a future non-MIDI control
surface (HID, network OSC) can populate the same state shape.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class ControllerState:
    device_name: str
    connected: bool = True
    button_states: Dict[int, bool] = field(default_factory=dict)   # control number -> pressed
    knob_values: Dict[int, float] = field(default_factory=dict)     # control number -> 0..1
    fader_values: Dict[int, float] = field(default_factory=dict)    # control number -> 0..1
    jog_deltas: Dict[int, int] = field(default_factory=dict)        # control number -> last tick delta
    pad_velocities: Dict[int, int] = field(default_factory=dict)    # note number -> 0..127

    def set_button(self, control: int, pressed: bool) -> None:
        self.button_states[control] = pressed

    def set_knob(self, control: int, value_0_127: int) -> None:
        self.knob_values[control] = max(0.0, min(1.0, value_0_127 / 127.0))

    def set_fader(self, control: int, value_0_127: int) -> None:
        self.fader_values[control] = max(0.0, min(1.0, value_0_127 / 127.0))

    def set_jog_delta(self, control: int, delta: int) -> None:
        self.jog_deltas[control] = delta

    def set_pad(self, note: int, velocity: int) -> None:
        self.pad_velocities[note] = velocity
