"""MIDI input abstraction.

Uses `python-rtmidi`/`mido` when available for real hardware; the
`MidiDevice`/`MidiInputManager` interfaces are backend-agnostic so a
future Core MIDI-native binding can be dropped in behind them. Device
disconnects are handled gracefully: audio playback must never be
interrupted by a MIDI failure.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Callable, List, Optional

from macos_dj.controllers.mapping import MidiTrigger
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class MidiDevice:
    device_id: str
    name: str
    is_input: bool


@dataclass(frozen=True)
class MidiMessage:
    trigger: MidiTrigger
    value: int  # velocity, CC value, or pitch-bend high byte (0-127)
    raw: tuple


MessageHandler = Callable[[MidiMessage], None]


def _parse_message(raw_bytes: List[int]) -> Optional[MidiMessage]:
    if not raw_bytes:
        return None
    status = raw_bytes[0]
    msg_type = status & 0xF0
    channel = status & 0x0F

    if msg_type == 0x90 and len(raw_bytes) >= 3:  # note on
        note, velocity = raw_bytes[1], raw_bytes[2]
        if velocity == 0:
            return MidiMessage(MidiTrigger("note_off", channel, note), 0, tuple(raw_bytes))
        return MidiMessage(MidiTrigger("note_on", channel, note), velocity, tuple(raw_bytes))
    if msg_type == 0x80 and len(raw_bytes) >= 3:  # note off
        note = raw_bytes[1]
        return MidiMessage(MidiTrigger("note_off", channel, note), 0, tuple(raw_bytes))
    if msg_type == 0xB0 and len(raw_bytes) >= 3:  # control change
        control, value = raw_bytes[1], raw_bytes[2]
        return MidiMessage(MidiTrigger("control_change", channel, control), value, tuple(raw_bytes))
    if msg_type == 0xE0 and len(raw_bytes) >= 3:  # pitch bend
        value = raw_bytes[2]
        return MidiMessage(MidiTrigger("pitch_bend", channel, 0), value, tuple(raw_bytes))
    return None


class MidiInputManager:
    """Enumerates and opens MIDI input ports, dispatching parsed messages."""

    def __init__(self, event_bus: Optional[EventBus] = None) -> None:
        self.events = event_bus or global_event_bus
        self._ports: dict = {}
        self._handlers: List[MessageHandler] = []
        self._lock = threading.Lock()

    def add_handler(self, handler: MessageHandler) -> None:
        with self._lock:
            self._handlers.append(handler)

    def list_devices(self) -> List[MidiDevice]:
        try:
            import mido  # type: ignore
        except ImportError:
            logger.debug("mido not installed; no MIDI devices available")
            return []
        try:
            return [MidiDevice(device_id=name, name=name, is_input=True) for name in mido.get_input_names()]
        except Exception as exc:  # noqa: BLE001 - backend/driver errors vary by platform
            logger.error("Failed to enumerate MIDI devices: %s", exc)
            return []

    def open(self, device: MidiDevice) -> bool:
        try:
            import mido  # type: ignore
        except ImportError:
            logger.warning("Cannot open MIDI device %s: mido is not installed", device.name)
            return False

        try:
            port = mido.open_input(device.name, callback=self._make_callback(device))
            self._ports[device.device_id] = port
            self.events.emit(EventType.MIDI_DEVICE_CONNECTED, device=device.name)
            logger.info("Opened MIDI input: %s", device.name)
            return True
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to open MIDI device %s: %s", device.name, exc)
            return False

    def close(self, device_id: str) -> None:
        port = self._ports.pop(device_id, None)
        if port is not None:
            try:
                port.close()
            except Exception:
                logger.exception("Error closing MIDI port %s", device_id)
            self.events.emit(EventType.MIDI_DEVICE_DISCONNECTED, device=device_id)

    def close_all(self) -> None:
        for device_id in list(self._ports.keys()):
            self.close(device_id)

    def _make_callback(self, device: MidiDevice) -> Callable:
        def _callback(mido_message) -> None:  # noqa: ANN001
            try:
                raw_bytes = list(mido_message.bytes())
                parsed = _parse_message(raw_bytes)
                if parsed is None:
                    return
                self.events.emit(EventType.MIDI_INPUT, device=device.name, trigger=parsed.trigger, value=parsed.value)
                with self._lock:
                    handlers = list(self._handlers)
                for handler in handlers:
                    try:
                        handler(parsed)
                    except Exception:
                        logger.exception("MIDI handler raised")
            except Exception:
                # A malformed/unsupported message must never crash the
                # input thread or interrupt audio playback.
                logger.exception("Error handling MIDI message from %s", device.name)

        return _callback
