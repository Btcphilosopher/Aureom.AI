"""Real-time spectrum analyser.

`SpectrumAnalyzer.push` accepts audio blocks fed from the mixer's output
tap (called from the audio-adjacent path, but doing only a cheap ring
buffer copy -- no allocation) and `SpectrumAnalyzer.compute` runs the
actual FFT on a *separate* thread/call so the visualisation work never
adds latency to the audio callback itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from macos_dj.audio.buffer import RingBuffer

#: Standard octave-ish energy bands for a simple bar-graph style analyser.
DEFAULT_BANDS_HZ: List[Tuple[float, float]] = [
    (20, 60), (60, 120), (120, 250), (250, 500),
    (500, 1000), (1000, 2000), (2000, 4000), (4000, 8000), (8000, 16000),
]


@dataclass
class SpectrumSnapshot:
    frequencies_hz: np.ndarray
    magnitudes_db: np.ndarray
    peak_frequency_hz: float
    band_energies: List[float]  # normalised 0..1, one per DEFAULT_BANDS_HZ entry


class SpectrumAnalyzer:
    def __init__(self, sample_rate: int = 44100, fft_size: int = 2048, channels: int = 2) -> None:
        self.sample_rate = sample_rate
        self.fft_size = fft_size
        self._ring = RingBuffer(capacity_frames=fft_size * 4, channels=channels)
        self._window = np.hanning(fft_size)

    def push(self, block: np.ndarray) -> None:
        """Feed audio into the analyser's capture ring buffer. Cheap: a
        bounded memcpy into a preallocated buffer, safe to call from the
        mixer's output-tap path."""
        self._ring.write(block)

    def compute(self) -> SpectrumSnapshot:
        """Run the FFT over the most recent `fft_size` samples. Call this
        from a UI-refresh-rate timer (e.g. 30-60Hz), never from the audio
        callback -- it allocates and does real work."""
        mono_frames = self._ring.read(self.fft_size)
        mono = mono_frames.mean(axis=1) if mono_frames.ndim > 1 else mono_frames

        windowed = mono * self._window
        spectrum = np.fft.rfft(windowed)
        magnitudes = np.abs(spectrum)
        freqs = np.fft.rfftfreq(self.fft_size, d=1.0 / self.sample_rate)

        with np.errstate(divide="ignore"):
            magnitudes_db = 20 * np.log10(np.maximum(magnitudes, 1e-9))

        peak_idx = int(np.argmax(magnitudes)) if magnitudes.size else 0
        peak_freq = float(freqs[peak_idx]) if magnitudes.size else 0.0

        band_energies = []
        total_energy = float(np.sum(magnitudes ** 2)) or 1.0
        for lo, hi in DEFAULT_BANDS_HZ:
            mask = (freqs >= lo) & (freqs < hi)
            band_energy = float(np.sum(magnitudes[mask] ** 2)) / total_energy
            band_energies.append(min(1.0, band_energy * len(DEFAULT_BANDS_HZ)))

        return SpectrumSnapshot(
            frequencies_hz=freqs,
            magnitudes_db=magnitudes_db,
            peak_frequency_hz=peak_freq,
            band_energies=band_energies,
        )
