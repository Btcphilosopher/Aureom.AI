"""Multiresolution waveform generation.

Precomputes downsampled min/max envelopes at several resolutions so the
UI can render an "overview" waveform (whole track) and a "zoom" waveform
(a few seconds around the playhead) without re-processing the full audio
file on every redraw or zoom change.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np


@dataclass
class WaveformLevel:
    samples_per_pixel: int
    # For each pixel: (min, max) amplitude in [-1, 1].
    min_values: np.ndarray
    max_values: np.ndarray
    rms_values: np.ndarray


@dataclass
class MultiResolutionWaveform:
    duration_seconds: float
    sample_rate: int
    levels: Dict[int, WaveformLevel] = field(default_factory=dict)

    def overview(self) -> WaveformLevel:
        return self.levels[max(self.levels.keys())]

    def best_level_for_pixel_density(self, pixels_per_second: float) -> WaveformLevel:
        """Pick the finest-available level whose resolution is still coarser
        than what's needed, to avoid rendering more points than pixels."""
        target_samples_per_pixel = self.sample_rate / max(pixels_per_second, 1e-6)
        candidates = sorted(self.levels.keys())
        best = candidates[0]
        for spp in candidates:
            if spp <= target_samples_per_pixel:
                best = spp
            else:
                break
        return self.levels[best]


DEFAULT_LEVELS_SAMPLES_PER_PIXEL = [64, 256, 1024, 4096, 16384]


def generate_waveform(
    samples: np.ndarray,
    sample_rate: int,
    levels_samples_per_pixel: List[int] | None = None,
) -> MultiResolutionWaveform:
    """Generate min/max/RMS envelopes at several downsampling ratios.

    This must only ever be invoked from a background analysis job, never
    from the audio callback -- it processes the entire file.
    """
    if samples.ndim > 1:
        mono = samples.mean(axis=1)
    else:
        mono = samples
    mono = mono.astype(np.float32)

    duration = len(mono) / sample_rate if sample_rate else 0.0
    levels_samples_per_pixel = levels_samples_per_pixel or DEFAULT_LEVELS_SAMPLES_PER_PIXEL

    waveform = MultiResolutionWaveform(duration_seconds=duration, sample_rate=sample_rate)
    for spp in levels_samples_per_pixel:
        waveform.levels[spp] = _downsample(mono, spp)
    return waveform


def _downsample(mono: np.ndarray, samples_per_pixel: int) -> WaveformLevel:
    n = len(mono)
    if n == 0 or samples_per_pixel <= 0:
        empty = np.zeros(0, dtype=np.float32)
        return WaveformLevel(samples_per_pixel=samples_per_pixel, min_values=empty, max_values=empty, rms_values=empty)

    n_pixels = max(1, n // samples_per_pixel)
    trimmed = mono[: n_pixels * samples_per_pixel]
    reshaped = trimmed.reshape(n_pixels, samples_per_pixel)

    min_values = reshaped.min(axis=1)
    max_values = reshaped.max(axis=1)
    rms_values = np.sqrt(np.mean(np.square(reshaped, dtype=np.float64), axis=1)).astype(np.float32)

    return WaveformLevel(
        samples_per_pixel=samples_per_pixel,
        min_values=min_values,
        max_values=max_values,
        rms_values=rms_values,
    )
