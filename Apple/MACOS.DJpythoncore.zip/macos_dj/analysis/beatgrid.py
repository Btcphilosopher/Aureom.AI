"""Beat-grid model and engine.

A `BeatGrid` is the authoritative timing map for a track: first beat
offset, BPM, and derived beat/bar positions. It supports manual
correction (nudge, shift, BPM adjust) since automatic detection is never
perfect, and correction must never be silently discarded.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from macos_dj.analysis.beat_detection import Beat
from macos_dj.analysis.bpm import BPMEstimate, refine_bpm_from_beats

BEATS_PER_BAR = 4


@dataclass
class BeatGrid:
    bpm: float
    first_beat_seconds: float = 0.0
    beats_per_bar: int = BEATS_PER_BAR
    confidence: float = 1.0
    manually_adjusted: bool = False
    detected_beats: List[Beat] = field(default_factory=list)

    @property
    def beat_length_seconds(self) -> float:
        if self.bpm <= 0:
            return 0.0
        return 60.0 / self.bpm

    @property
    def bar_length_seconds(self) -> float:
        return self.beat_length_seconds * self.beats_per_bar

    def beat_index_at(self, position_seconds: float) -> float:
        """Fractional beat index at a given playback position (can be negative
        before the first beat)."""
        if self.beat_length_seconds <= 0:
            return 0.0
        return (position_seconds - self.first_beat_seconds) / self.beat_length_seconds

    def position_of_beat(self, beat_index: float) -> float:
        return self.first_beat_seconds + beat_index * self.beat_length_seconds

    def nearest_beat_position(self, position_seconds: float) -> float:
        idx = round(self.beat_index_at(position_seconds))
        return self.position_of_beat(idx)

    def bar_index_at(self, position_seconds: float) -> float:
        return self.beat_index_at(position_seconds) / self.beats_per_bar

    def phase_offset_seconds(self, position_seconds: float) -> float:
        """Signed offset in seconds from `position_seconds` to the nearest beat."""
        nearest = self.nearest_beat_position(position_seconds)
        return position_seconds - nearest

    # --- Manual correction -------------------------------------------------

    def nudge(self, delta_seconds: float) -> None:
        """Shift the whole grid (used for micro beat-alignment corrections)."""
        self.first_beat_seconds += delta_seconds
        self.manually_adjusted = True

    def shift_to(self, new_first_beat_seconds: float) -> None:
        self.first_beat_seconds = new_first_beat_seconds
        self.manually_adjusted = True

    def set_bpm(self, new_bpm: float, anchor_seconds: Optional[float] = None) -> None:
        """Change BPM while keeping the grid aligned at `anchor_seconds`
        (defaults to the current first beat) so downstream beats don't
        drift out from under existing cue points.
        """
        if new_bpm <= 0:
            raise ValueError("BPM must be positive")
        anchor = anchor_seconds if anchor_seconds is not None else self.first_beat_seconds
        beat_idx_at_anchor = self.beat_index_at(anchor)
        self.bpm = new_bpm
        self.first_beat_seconds = anchor - beat_idx_at_anchor * self.beat_length_seconds
        self.manually_adjusted = True

    def double_bpm(self) -> None:
        self.set_bpm(self.bpm * 2)

    def halve_bpm(self) -> None:
        self.set_bpm(self.bpm / 2)


def build_beatgrid_from_beats(
    beats: List[Beat],
    fallback_bpm: float = 120.0,
) -> BeatGrid:
    """Construct a BeatGrid from detected beats, refining BPM via median
    inter-beat interval and anchoring on the first detected beat.
    """
    if not beats:
        return BeatGrid(bpm=fallback_bpm, first_beat_seconds=0.0, confidence=0.0)

    times = [b.time_seconds for b in beats]
    estimate: Optional[BPMEstimate] = refine_bpm_from_beats(times)
    bpm = estimate.bpm if estimate else fallback_bpm
    confidence = estimate.confidence if estimate else 0.3

    return BeatGrid(
        bpm=bpm,
        first_beat_seconds=times[0],
        confidence=confidence,
        detected_beats=beats,
    )
