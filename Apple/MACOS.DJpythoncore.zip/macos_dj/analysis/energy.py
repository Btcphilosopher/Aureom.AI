"""Track energy analysis.

Produces a coarse "energy curve" (RMS over time) plus a single scalar
energy rating (1-10) commonly used by DJs to gauge a track's intensity
for set planning. This is intentionally simple, deterministic, and fast
so it can run as part of the standard import-analysis pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class EnergyProfile:
    curve: List[float]  # RMS (0..1) per analysis window
    window_seconds: float
    overall_rating: int  # 1-10


def compute_energy_profile(samples: np.ndarray, sample_rate: int, window_seconds: float = 2.0) -> EnergyProfile:
    """Compute a windowed RMS energy curve and an overall 1-10 rating.

    `samples` is expected to be mono float32/float64 in [-1, 1].
    """
    if samples.ndim > 1:
        samples = samples.mean(axis=1)
    window = max(1, int(sample_rate * window_seconds))
    n_windows = max(1, len(samples) // window)
    curve: List[float] = []
    for i in range(n_windows):
        chunk = samples[i * window : (i + 1) * window]
        if len(chunk) == 0:
            continue
        rms = float(np.sqrt(np.mean(np.square(chunk, dtype=np.float64))))
        curve.append(rms)

    if not curve:
        return EnergyProfile(curve=[], window_seconds=window_seconds, overall_rating=1)

    mean_rms = float(np.mean(curve))
    # Map typical RMS range (roughly 0.02 quiet -> 0.35 loud/compressed) to 1-10.
    rating = int(round(np.interp(mean_rms, [0.02, 0.35], [1, 10])))
    rating = max(1, min(10, rating))
    return EnergyProfile(curve=curve, window_seconds=window_seconds, overall_rating=rating)
