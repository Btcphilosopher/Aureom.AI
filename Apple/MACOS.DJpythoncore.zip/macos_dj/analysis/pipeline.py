"""Automatic track analysis pipeline.

    FILE -> METADATA -> AUDIO PROPERTIES -> BPM -> BEATS -> BEAT GRID
         -> KEY -> WAVEFORM -> ENERGY -> DATABASE

Runs entirely off the real-time thread, dispatched through
`core.scheduler` at `Priority.LOW` so it never starves UI-facing tasks.
A failure at any stage is caught, logged, and recorded on the track
(`analysis_failed` / `analysis_error`) rather than raised -- callers can
always fall back to manual BPM/key entry per the error-handling contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from macos_dj.analysis.beat_detection import detect_beats
from macos_dj.analysis.beatgrid import BeatGrid, build_beatgrid_from_beats
from macos_dj.analysis.bpm import estimate_bpm
from macos_dj.analysis.energy import compute_energy_profile
from macos_dj.analysis.key_detection import detect_key
from macos_dj.analysis.waveform import MultiResolutionWaveform, generate_waveform
from macos_dj.audio.player import DecodeError, decode_file
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger
from macos_dj.library.tracks import Track

logger = get_logger(__name__)


@dataclass
class AnalysisResult:
    track: Track
    waveform: Optional[MultiResolutionWaveform] = None
    success: bool = True
    error: Optional[str] = None


class AnalysisPipeline:
    def __init__(self, event_bus: Optional[EventBus] = None) -> None:
        self.events = event_bus or global_event_bus

    def analyze(self, track: Track, force: bool = False) -> AnalysisResult:
        """Run the full analysis pipeline synchronously (call this from a
        background worker, e.g. via `core.scheduler.global_scheduler.submit`)."""
        self.events.emit(EventType.ANALYSIS_STARTED, track_id=track.id, path=track.file_path)
        try:
            samples, sample_rate = decode_file(track.file_path)

            track.sample_rate = sample_rate
            track.channels = samples.shape[1] if samples.ndim > 1 else 1
            track.duration_seconds = len(samples) / sample_rate if sample_rate else 0.0

            bpm_estimate = estimate_bpm(samples, sample_rate)
            beats = detect_beats(samples, sample_rate, bpm=bpm_estimate.bpm)
            beatgrid = build_beatgrid_from_beats(beats, fallback_bpm=bpm_estimate.bpm)

            if not track.bpm_locked or force:
                track.apply_bpm_estimate(beatgrid.bpm, force=force)
            track.beatgrid = beatgrid if (not track.bpm_locked or force) else _rebuild_grid_at_locked_bpm(beatgrid, track.bpm)

            key_estimate = detect_key(samples, sample_rate)
            if not track.key_locked or force:
                track.apply_key_estimate(key_estimate.camelot, force=force)

            energy_profile = compute_energy_profile(samples, sample_rate)
            track.energy = energy_profile.overall_rating

            waveform = generate_waveform(samples, sample_rate)

            track.analysis_failed = False
            track.analysis_error = None

            self.events.emit(EventType.ANALYSIS_COMPLETED, track_id=track.id, bpm=track.bpm, key=track.musical_key)
            return AnalysisResult(track=track, waveform=waveform, success=True)

        except DecodeError as exc:
            logger.warning("Analysis skipped for %s: %s", track.file_path, exc)
            track.analysis_failed = True
            track.analysis_error = str(exc)
            self.events.emit(EventType.ANALYSIS_FAILED, track_id=track.id, error=str(exc))
            return AnalysisResult(track=track, success=False, error=str(exc))

        except Exception as exc:  # noqa: BLE001 - analysis must never crash the app
            logger.exception("Unexpected analysis failure for %s", track.file_path)
            track.analysis_failed = True
            track.analysis_error = str(exc)
            self.events.emit(EventType.ANALYSIS_FAILED, track_id=track.id, error=str(exc))
            return AnalysisResult(track=track, success=False, error=str(exc))


def _rebuild_grid_at_locked_bpm(detected_grid: BeatGrid, locked_bpm: Optional[float]) -> BeatGrid:
    """When the user has locked the BPM, keep the detected grid's phase
    (first-beat alignment) but honor the locked tempo rather than the
    freshly detected one."""
    if locked_bpm is None or locked_bpm <= 0:
        return detected_grid
    grid = BeatGrid(
        bpm=locked_bpm,
        first_beat_seconds=detected_grid.first_beat_seconds,
        confidence=detected_grid.confidence,
        manually_adjusted=True,
        detected_beats=detected_grid.detected_beats,
    )
    return grid
