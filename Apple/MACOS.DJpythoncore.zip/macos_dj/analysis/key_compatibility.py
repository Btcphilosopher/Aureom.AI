"""Harmonic mixing / key compatibility engine.

Given two Camelot-notated keys, determines whether they are compatible
for harmonic mixing using the standard Camelot Wheel rules: same number
(relative major/minor), adjacent number same letter (perfect fifth), or
same number opposite letter (relative major/minor swap). Rules are kept
as data so alternate harmonic-mixing conventions (e.g. Open Key) can be
plugged in later.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional


class Compatibility(Enum):
    COMPATIBLE = auto()
    POSSIBLE = auto()
    INCOMPATIBLE = auto()


@dataclass
class CompatibilityResult:
    result: Compatibility
    reason: str


_CAMELOT_RE = re.compile(r"^(\d{1,2})([AB])$", re.IGNORECASE)


def _parse_camelot(key: str) -> Optional[tuple[int, str]]:
    match = _CAMELOT_RE.match(key.strip())
    if not match:
        return None
    number = int(match.group(1))
    if not (1 <= number <= 12):
        return None
    return number, match.group(2).upper()


def compatibility(key_a: str, key_b: str) -> CompatibilityResult:
    """Evaluate harmonic compatibility between two Camelot-notation keys
    (e.g. "8A", "9B")."""
    parsed_a = _parse_camelot(key_a)
    parsed_b = _parse_camelot(key_b)
    if parsed_a is None or parsed_b is None:
        return CompatibilityResult(Compatibility.INCOMPATIBLE, "Unrecognised key notation")

    num_a, letter_a = parsed_a
    num_b, letter_b = parsed_b

    if num_a == num_b and letter_a == letter_b:
        return CompatibilityResult(Compatibility.COMPATIBLE, "Identical key")

    if num_a == num_b and letter_a != letter_b:
        return CompatibilityResult(Compatibility.COMPATIBLE, "Relative major/minor")

    diff = (num_a - num_b) % 12
    if letter_a == letter_b and diff in (1, 11):
        return CompatibilityResult(Compatibility.COMPATIBLE, "Adjacent on the Camelot wheel (perfect fifth)")

    if letter_a == letter_b and diff in (2, 10):
        return CompatibilityResult(Compatibility.POSSIBLE, "Two steps on the wheel; energy shift, mixable with care")

    if diff in (1, 11) and letter_a != letter_b:
        return CompatibilityResult(Compatibility.POSSIBLE, "Adjacent number, different mode; a bolder harmonic move")

    return CompatibilityResult(Compatibility.INCOMPATIBLE, "Keys are harmonically distant")


def compatible_keys(key: str) -> list[str]:
    """List Camelot keys that are COMPATIBLE (not merely POSSIBLE) with `key`."""
    parsed = _parse_camelot(key)
    if parsed is None:
        return []
    number, letter = parsed
    other_letter = "B" if letter == "A" else "A"
    neighbours = [
        f"{number}{letter}",
        f"{number}{other_letter}",
        f"{(number % 12) + 1}{letter}",
        f"{((number - 2) % 12) + 1}{letter}",
    ]
    return neighbours
