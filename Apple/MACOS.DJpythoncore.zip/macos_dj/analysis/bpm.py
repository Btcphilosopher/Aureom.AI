"""BPM estimation.

Estimates tempo from an onset novelty curve using autocorrelation: the
novelty curve (see `analysis.beat_detection`) is correlated against
time-shifted copies of itself; the shift with the strongest correlation
within the plausible DJ tempo range (60-200 BPM) is taken as the beat
period. A confidence score is derived from how sharply the
autocorrelation peaks relative to its neighbourhood.

This result must never silently overwrite a user's manually-corrected
BPM -- callers (the analysis pipeline / library layer) are responsible
for checking `Track.bpm_locked` before applying a new estimate.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from macos_dj.analysis.beat_detection import spectral_flux_novelty

MIN_BPM = 60.0
MAX_BPM = 200.0


@dataclass
class BPMEstimate:
    bpm: float
    confidence: float  # 0..1


def estimate_bpm(samples: np.ndarray, sample_rate: int) -> BPMEstimate:
    result = spectral_flux_novelty(samples, sample_rate)
    novelty = result.novelty_curve
    hop_seconds = result.hop_seconds

    if len(novelty) < 8 or hop_seconds <= 0:
        return BPMEstimate(bpm=120.0, confidence=0.0)

    novelty = novelty - novelty.mean()
    autocorr = np.correlate(novelty, novelty, mode="full")
    autocorr = autocorr[len(autocorr) // 2 :]  # keep non-negative lags
    if autocorr[0] <= 0:
        return BPMEstimate(bpm=120.0, confidence=0.0)
    autocorr = autocorr / autocorr[0]

    min_lag = max(1, int((60.0 / MAX_BPM) / hop_seconds))
    max_lag = min(len(autocorr) - 1, int((60.0 / MIN_BPM) / hop_seconds))
    if max_lag <= min_lag:
        return BPMEstimate(bpm=120.0, confidence=0.0)

    window = autocorr[min_lag : max_lag + 1]
    best_idx = int(np.argmax(window))
    best_lag = min_lag + best_idx
    best_value = float(window[best_idx])

    bpm = 60.0 / (best_lag * hop_seconds)

    # Fold tempo octave errors (half/double time) into the standard DJ range.
    while bpm < MIN_BPM:
        bpm *= 2
    while bpm > MAX_BPM:
        bpm /= 2

    neighborhood_mean = float(window.mean())
    confidence = float(np.clip((best_value - neighborhood_mean) / (1.0 - neighborhood_mean + 1e-9), 0.0, 1.0))

    return BPMEstimate(bpm=round(bpm, 2), confidence=round(confidence, 3))


def refine_bpm_from_beats(beat_times: list[float]) -> Optional[BPMEstimate]:
    """Refine a BPM estimate from a list of already-detected beat timestamps
    by taking the median inter-beat interval (robust to occasional missed
    or spurious onsets).
    """
    if len(beat_times) < 4:
        return None
    intervals = np.diff(np.asarray(beat_times))
    intervals = intervals[intervals > 0]
    if len(intervals) == 0:
        return None
    median_interval = float(np.median(intervals))
    if median_interval <= 0:
        return None
    bpm = 60.0 / median_interval
    while bpm < MIN_BPM:
        bpm *= 2
    while bpm > MAX_BPM:
        bpm /= 2
    spread = float(np.std(intervals) / (median_interval + 1e-9))
    confidence = float(np.clip(1.0 - spread, 0.0, 1.0))
    return BPMEstimate(bpm=round(bpm, 2), confidence=round(confidence, 3))
