"""Onset / beat detection.

A deterministic, dependency-light onset detector based on a spectral-flux
novelty function: STFT magnitude frames are compared to their
predecessor, positive energy increases are summed per frame to build a
"novelty curve", and peaks in that curve are picked as onsets. This is a
well-established, easily testable technique (see Bello et al., 2005) and
gives BPM/beatgrid analysis a solid, replaceable foundation -- a future
native implementation (e.g. a librosa/madmom-backed or Core ML model)
can drop in behind the same `detect_onsets` / `detect_beats` interface.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np


@dataclass
class Beat:
    time_seconds: float
    is_downbeat: bool = False
    confidence: float = 1.0


@dataclass
class OnsetDetectionResult:
    onset_times: List[float]
    novelty_curve: np.ndarray
    hop_seconds: float


def _stft_magnitude(samples: np.ndarray, frame_size: int, hop_size: int) -> np.ndarray:
    n_frames = max(0, (len(samples) - frame_size) // hop_size + 1)
    if n_frames <= 0:
        return np.zeros((0, frame_size // 2 + 1))
    window = np.hanning(frame_size)
    mags = np.empty((n_frames, frame_size // 2 + 1), dtype=np.float64)
    for i in range(n_frames):
        start = i * hop_size
        frame = samples[start : start + frame_size] * window
        spectrum = np.fft.rfft(frame)
        mags[i] = np.abs(spectrum)
    return mags


def spectral_flux_novelty(
    samples: np.ndarray,
    sample_rate: int,
    frame_size: int = 2048,
    hop_size: int = 512,
) -> OnsetDetectionResult:
    if samples.ndim > 1:
        samples = samples.mean(axis=1)
    samples = samples.astype(np.float64)

    mags = _stft_magnitude(samples, frame_size, hop_size)
    if mags.shape[0] < 2:
        return OnsetDetectionResult(onset_times=[], novelty_curve=np.zeros(0), hop_seconds=hop_size / sample_rate)

    diff = np.diff(mags, axis=0)
    flux = np.sum(np.maximum(diff, 0.0), axis=1)
    # Normalise so the peak picker's threshold is scale-independent.
    if flux.max() > 0:
        flux = flux / flux.max()

    hop_seconds = hop_size / sample_rate
    onset_times = _pick_peaks(flux, hop_seconds)
    return OnsetDetectionResult(onset_times=onset_times, novelty_curve=flux, hop_seconds=hop_seconds)


def _pick_peaks(
    novelty: np.ndarray,
    hop_seconds: float,
    local_window: int = 6,
    threshold: float = 0.15,
    min_separation_seconds: float = 0.08,
) -> List[float]:
    peaks: List[float] = []
    last_peak_time: Optional[float] = None
    n = len(novelty)
    for i in range(n):
        lo, hi = max(0, i - local_window), min(n, i + local_window + 1)
        local_max = novelty[lo:hi].max()
        if novelty[i] == local_max and novelty[i] > threshold:
            t = i * hop_seconds
            if last_peak_time is None or (t - last_peak_time) >= min_separation_seconds:
                peaks.append(t)
                last_peak_time = t
    return peaks


def detect_onsets(samples: np.ndarray, sample_rate: int) -> List[float]:
    """Return onset timestamps in seconds."""
    return spectral_flux_novelty(samples, sample_rate).onset_times


def detect_beats(samples: np.ndarray, sample_rate: int, bpm: Optional[float] = None) -> List[Beat]:
    """Return `Beat` objects, marking every 4th detected onset a downbeat
    as a simple heuristic when no bar/phrase model is available.
    """
    onsets = detect_onsets(samples, sample_rate)
    beats: List[Beat] = []
    for i, t in enumerate(onsets):
        beats.append(Beat(time_seconds=t, is_downbeat=(i % 4 == 0)))
    return beats
