"""Musical key detection.

Estimates the musical key of a track using the classic Krumhansl-Schmuckler
key-profile correlation method: a chroma vector (12-bin pitch-class energy
histogram) is built from the track's spectrum and correlated against
major/minor key profiles. The highest-correlating key/mode pair wins.

The algorithm is intentionally swappable behind `KeyDetector` -- a future
implementation (HPCP-based, ML-based, or a native Core ML model) can
replace `KrumhanslKeyDetector` without touching callers.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

# Krumhansl-Kessler key profiles.
_MAJOR_PROFILE = np.array(
    [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
)
_MINOR_PROFILE = np.array(
    [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
)

#: Open Key / Camelot-style notation used widely by DJ software.
CAMELOT_WHEEL = {
    ("C", "major"): "8B", ("A", "minor"): "8A",
    ("G", "major"): "9B", ("E", "minor"): "9A",
    ("D", "major"): "10B", ("B", "minor"): "10A",
    ("A", "major"): "11B", ("F#", "minor"): "11A",
    ("E", "major"): "12B", ("C#", "minor"): "12A",
    ("B", "major"): "1B", ("G#", "minor"): "1A",
    ("F#", "major"): "2B", ("D#", "minor"): "2A",
    ("C#", "major"): "3B", ("A#", "minor"): "3A",
    ("G#", "major"): "4B", ("F", "minor"): "4A",
    ("D#", "major"): "5B", ("C", "minor"): "5A",
    ("A#", "major"): "6B", ("G", "minor"): "6A",
    ("F", "major"): "7B", ("D", "minor"): "7A",
}


@dataclass
class KeyEstimate:
    tonic: str
    mode: str  # "major" | "minor"
    confidence: float

    @property
    def standard_notation(self) -> str:
        return f"{self.tonic} {'maj' if self.mode == 'major' else 'min'}"

    @property
    def camelot(self) -> str:
        return CAMELOT_WHEEL.get((self.tonic, self.mode), "?")


class KeyDetector(ABC):
    @abstractmethod
    def detect(self, samples: np.ndarray, sample_rate: int) -> KeyEstimate:
        raise NotImplementedError


def _chroma_vector(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    if samples.ndim > 1:
        samples = samples.mean(axis=1)
    samples = samples.astype(np.float64)

    n = min(len(samples), sample_rate * 60)  # analyse at most 60s for speed
    samples = samples[:n]
    if len(samples) < 4096:
        return np.zeros(12)

    spectrum = np.abs(np.fft.rfft(samples * np.hanning(len(samples))))
    freqs = np.fft.rfftfreq(len(samples), d=1.0 / sample_rate)

    chroma = np.zeros(12)
    # A4 = 440Hz = MIDI note 69.
    with np.errstate(divide="ignore"):
        midi_notes = 69 + 12 * np.log2(np.maximum(freqs, 1e-9) / 440.0)
    valid = (freqs > 20) & (freqs < 5000)
    pitch_classes = np.mod(np.round(midi_notes[valid]), 12).astype(int)
    magnitudes = spectrum[valid]
    np.add.at(chroma, pitch_classes, magnitudes)

    if chroma.sum() > 0:
        chroma = chroma / chroma.sum()
    return chroma


class KrumhanslKeyDetector(KeyDetector):
    def detect(self, samples: np.ndarray, sample_rate: int) -> KeyEstimate:
        chroma = _chroma_vector(samples, sample_rate)
        if not np.any(chroma):
            return KeyEstimate(tonic="C", mode="major", confidence=0.0)

        best: Tuple[str, str, float] = ("C", "major", -1.0)
        scores: List[float] = []
        for shift in range(12):
            major_profile = np.roll(_MAJOR_PROFILE, shift)
            minor_profile = np.roll(_MINOR_PROFILE, shift)
            major_corr = float(np.corrcoef(chroma, major_profile)[0, 1])
            minor_corr = float(np.corrcoef(chroma, minor_profile)[0, 1])
            scores.extend([major_corr, minor_corr])
            if major_corr > best[2]:
                best = (NOTE_NAMES[shift], "major", major_corr)
            if minor_corr > best[2]:
                best = (NOTE_NAMES[shift], "minor", minor_corr)

        scores_arr = np.nan_to_num(np.array(scores))
        top = float(np.max(scores_arr))
        mean_rest = float(np.mean(scores_arr))
        confidence = float(np.clip((top - mean_rest), 0.0, 1.0))

        return KeyEstimate(tonic=best[0], mode=best[1], confidence=round(confidence, 3))


def detect_key(samples: np.ndarray, sample_rate: int, detector: KeyDetector | None = None) -> KeyEstimate:
    detector = detector or KrumhanslKeyDetector()
    return detector.detect(samples, sample_rate)
