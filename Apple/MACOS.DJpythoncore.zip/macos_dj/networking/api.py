"""Local application API.

Exposes commands and read-only state through a small HTTP JSON API,
intended for local tooling (a future companion app, StreamDeck-style
integrations, remote control on the same machine) -- never for public
exposure. The server is OFF by default (`NetworkConfig.api_enabled`) and
binds to `127.0.0.1` unless explicitly reconfigured.

Uses only the standard library (`http.server`) so the API surface has no
extra runtime dependency; a production deployment could swap in
FastAPI/uvicorn behind the same `CommandDispatcher` contract.
"""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Dict, Optional
from urllib.parse import urlparse

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)

CommandHandler = Callable[[Dict[str, Any]], Dict[str, Any]]
StateProvider = Callable[[], Dict[str, Any]]


@dataclass
class Route:
    method: str
    path: str
    handler: Callable[[Dict[str, Any]], Dict[str, Any]]


class CommandDispatcher:
    """Maps a small set of routes to command handlers / state providers.

    Kept separate from the HTTP transport so the same dispatcher could be
    reused by e.g. a WebSocket transport later.
    """

    def __init__(self) -> None:
        self._routes: Dict[tuple, Route] = {}

    def register(self, method: str, path: str, handler: Callable[[Dict[str, Any]], Dict[str, Any]]) -> None:
        self._routes[(method.upper(), path)] = Route(method.upper(), path, handler)

    def dispatch(self, method: str, path: str, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        route = self._routes.get((method.upper(), path))
        if route is None:
            return None
        return route.handler(body)


def _make_handler(dispatcher: CommandDispatcher, allowed_host: str):
    class Handler(BaseHTTPRequestHandler):
        def _respond(self, status: int, payload: Dict[str, Any]) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _handle(self, method: str) -> None:
            # Never accept requests to a Host header other than the bound
            # loopback address -- keeps this API off the public network
            # even if a misconfiguration causes it to bind wider.
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                self._respond(403, {"error": "forbidden"})
                return

            parsed = urlparse(self.path)
            body: Dict[str, Any] = {}
            if method == "POST":
                length = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(length) if length else b"{}"
                try:
                    body = json.loads(raw or b"{}")
                except json.JSONDecodeError:
                    self._respond(400, {"error": "invalid JSON body"})
                    return

            result = dispatcher.dispatch(method, parsed.path, body)
            if result is None:
                self._respond(404, {"error": "not found"})
                return
            self._respond(200, result)

        def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
            self._handle("GET")

        def do_POST(self) -> None:  # noqa: N802
            self._handle("POST")

        def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
            logger.debug("API: " + format, *args)

    return Handler


class LocalAPIServer:
    def __init__(self, dispatcher: CommandDispatcher, host: str = "127.0.0.1", port: int = 17832) -> None:
        self.dispatcher = dispatcher
        self.host = host
        self.port = port
        self._server: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self.host not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("The local API must bind to a loopback address only")
        handler_cls = _make_handler(self.dispatcher, self.host)
        self._server = ThreadingHTTPServer((self.host, self.port), handler_cls)
        self._thread = threading.Thread(target=self._server.serve_forever, name="LocalAPIServer", daemon=True)
        self._thread.start()
        logger.info("Local API server listening on %s:%d", self.host, self.port)

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        logger.info("Local API server stopped")


def build_default_routes(dispatcher: CommandDispatcher, state_provider: StateProvider, command_handler: CommandHandler) -> None:
    """Wire up the routes sketched in the architecture doc:

        GET  /decks
        GET  /library
        GET  /session
        POST /deck/load
        POST /deck/play
        POST /deck/cue
        POST /deck/sync
    """
    dispatcher.register("GET", "/decks", lambda _body: state_provider().get("decks", {}))
    dispatcher.register("GET", "/library", lambda _body: state_provider().get("library", {}))
    dispatcher.register("GET", "/session", lambda _body: state_provider().get("session", {}))
    dispatcher.register("POST", "/deck/load", lambda body: command_handler({"command": "LOAD_TRACK", **body}))
    dispatcher.register("POST", "/deck/play", lambda body: command_handler({"command": "PLAY", **body}))
    dispatcher.register("POST", "/deck/cue", lambda body: command_handler({"command": "CUE", **body}))
    dispatcher.register("POST", "/deck/sync", lambda body: command_handler({"command": "SYNC", **body}))
