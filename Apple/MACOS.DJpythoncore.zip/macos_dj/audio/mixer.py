"""Software mixer: per-deck channels, crossfader, and master bus.

`Mixer.process` is the top of the real-time-adjacent call graph: it asks
each deck for its next block, routes it through the deck's channel strip,
applies the crossfader, sums to the master bus, and returns the final
master block for the audio engine to write to the output stream (and,
optionally, the recorder).
"""

from __future__ import annotations

import math
from enum import Enum, auto
from typing import Callable, Dict, List, Optional

import numpy as np

from macos_dj.audio.channel import ChannelMeter, CrossfaderAssign, MixerChannel
from macos_dj.audio.master import Master
from macos_dj.core.events import EventBus, EventType, global_event_bus


class CrossfaderCurve(Enum):
    LINEAR = auto()
    CONSTANT_POWER = auto()
    SHARP = auto()  # scratch-style fast cut, minimal overlap


def _crossfader_gains(position: float, curve: CrossfaderCurve) -> tuple[float, float]:
    """`position` is -1.0 (full A) .. +1.0 (full B). Returns (gain_a, gain_b)."""
    position = max(-1.0, min(1.0, position))
    t = (position + 1.0) / 2.0  # normalise to 0..1

    if curve is CrossfaderCurve.LINEAR:
        return (1.0 - t, t)

    if curve is CrossfaderCurve.CONSTANT_POWER:
        angle = t * (math.pi / 2)
        return (float(math.cos(angle)), float(math.sin(angle)))

    # SHARP: near-instant cut around center, favors scratching/cutting.
    cut_width = 0.08  # fraction of travel where both sides fade
    if t < 0.5 - cut_width / 2:
        return (1.0, 0.0)
    if t > 0.5 + cut_width / 2:
        return (0.0, 1.0)
    local_t = (t - (0.5 - cut_width / 2)) / cut_width
    return (1.0 - local_t, local_t)


class Mixer:
    def __init__(
        self,
        channel_ids: List[str],
        sample_rate: int = 44100,
        channels: int = 2,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self.events = event_bus or global_event_bus

        self.channel_strips: Dict[str, MixerChannel] = {
            cid: MixerChannel(cid, sample_rate=sample_rate, channels=channels) for cid in channel_ids
        }
        self.master = Master(sample_rate=sample_rate, channels=channels)

        self.crossfader_position = 0.0  # -1 (A) .. 0 (center) .. +1 (B)
        self.crossfader_curve = CrossfaderCurve.CONSTANT_POWER

    def channel(self, channel_id: str) -> MixerChannel:
        return self.channel_strips[channel_id]

    def set_crossfader(self, position: float) -> None:
        self.crossfader_position = max(-1.0, min(1.0, position))
        self.events.emit(EventType.CROSSFADER_CHANGED, position=self.crossfader_position)

    def set_crossfader_curve(self, curve: CrossfaderCurve) -> None:
        self.crossfader_curve = curve

    def process(self, deck_blocks: Dict[str, np.ndarray]) -> np.ndarray:
        """`deck_blocks` maps channel_id -> raw deck output for this block.

        Returns the processed master output block.
        """
        gain_a, gain_b = _crossfader_gains(self.crossfader_position, self.crossfader_curve)

        summed: Optional[np.ndarray] = None
        for channel_id, raw_block in deck_blocks.items():
            strip = self.channel_strips.get(channel_id)
            if strip is None:
                continue
            processed = strip.process(raw_block)

            crossfader_gain = 1.0
            if strip.crossfader_assign is CrossfaderAssign.A:
                crossfader_gain = gain_a
            elif strip.crossfader_assign is CrossfaderAssign.B:
                crossfader_gain = gain_b

            contribution = processed * crossfader_gain
            summed = contribution if summed is None else summed + contribution

        if summed is None:
            summed = np.zeros((0, self.channels), dtype=np.float32)

        return self.master.process(summed)

    def cue_mix(self, deck_blocks: Dict[str, np.ndarray]) -> np.ndarray:
        """Sum only channels with `cue_enabled` set, for headphone preview."""
        summed: Optional[np.ndarray] = None
        for channel_id, raw_block in deck_blocks.items():
            strip = self.channel_strips.get(channel_id)
            if strip is None or not strip.cue_enabled:
                continue
            contribution = raw_block
            summed = contribution if summed is None else summed + contribution
        if summed is None:
            any_block = next(iter(deck_blocks.values()), None)
            shape = any_block.shape if any_block is not None else (0, self.channels)
            summed = np.zeros(shape, dtype=np.float32)
        return summed

    def meters(self) -> Dict[str, ChannelMeter]:
        return {cid: strip.meter for cid, strip in self.channel_strips.items()}
