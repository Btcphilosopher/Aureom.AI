"""Audio engine: owns the real-time output stream.

Uses `sounddevice` (a PortAudio binding) as the default backend since it
gives low-latency callback-based streams on macOS out of the box while
staying pure-Python/CFFI (no compiled extension to ship separately
beyond PortAudio itself). The engine only knows how to pull a finished
block from a `render_callback` and hand it to the device -- it does not
know about decks, mixers, or DSP, keeping it swappable for a future
native Core Audio implementation behind the same interface.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from macos_dj.audio.routing import AudioDevice, DeviceRegistry
from macos_dj.core.events import EventBus, EventType, global_event_bus
from macos_dj.core.logging import get_logger

logger = get_logger(__name__)

RenderCallback = Callable[[int], np.ndarray]


@dataclass
class EngineStats:
    callback_count: int = 0
    underruns: int = 0
    overruns: int = 0
    last_callback_duration_ms: float = 0.0
    max_callback_duration_ms: float = 0.0


class AudioEngineError(Exception):
    pass


class AudioEngine:
    """Owns the real-time audio output stream.

    The render callback (usually `Mixer.process` wrapped by the
    application layer) MUST be fast and allocation-light: this class
    calls it directly on the audio backend's real-time thread.
    """

    def __init__(
        self,
        sample_rate: int = 44100,
        buffer_size: int = 256,
        channels: int = 2,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.sample_rate = sample_rate
        self.buffer_size = buffer_size
        self.channels = channels
        self.events = event_bus or global_event_bus

        self.device_registry = DeviceRegistry()
        self.output_device: Optional[AudioDevice] = None
        self.monitor_device: Optional[AudioDevice] = None

        self.stats = EngineStats()
        self._render_callback: Optional[RenderCallback] = None
        self._stream = None  # type: ignore[assignment]
        self._running = False
        self._lock = threading.Lock()

    def set_render_callback(self, callback: RenderCallback) -> None:
        self._render_callback = callback

    def set_sample_rate(self, sample_rate: int) -> None:
        if self._running:
            raise AudioEngineError("Cannot change sample rate while the engine is running")
        self.sample_rate = sample_rate

    def set_buffer_size(self, buffer_size: int) -> None:
        if self._running:
            raise AudioEngineError("Cannot change buffer size while the engine is running")
        self.buffer_size = buffer_size

    def set_output_device(self, device: Optional[AudioDevice]) -> None:
        self.output_device = device
        self.events.emit(EventType.AUDIO_DEVICE_CHANGED, device=device.name if device else None)

    def set_monitor_device(self, device: Optional[AudioDevice]) -> None:
        self.monitor_device = device

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self) -> None:
        with self._lock:
            if self._running:
                return
            if self._render_callback is None:
                raise AudioEngineError("No render callback set; call set_render_callback() first")

            try:
                import sounddevice as sd  # type: ignore
            except ImportError as exc:
                raise AudioEngineError(
                    "sounddevice is not installed; install it or provide a native backend"
                ) from exc

            device_index = int(self.output_device.device_id) if self.output_device else None

            def _callback(outdata: np.ndarray, frames: int, time_info, status) -> None:  # noqa: ANN001
                start = time.perf_counter()
                if status:
                    if status.output_underflow:
                        self.stats.underruns += 1
                        self.events.emit(EventType.AUDIO_ERROR, error="output_underflow")
                    if getattr(status, "output_overflow", False):
                        self.stats.overruns += 1
                try:
                    block = self._render_callback(frames)  # type: ignore[misc]
                    if block.shape[0] < frames:
                        padded = np.zeros((frames, self.channels), dtype=np.float32)
                        padded[: block.shape[0]] = block
                        block = padded
                    outdata[:] = block[:frames]
                except Exception:
                    logger.exception("Render callback raised; outputting silence")
                    outdata.fill(0.0)
                    self.events.emit(EventType.AUDIO_ERROR, error="render_callback_exception")

                elapsed_ms = (time.perf_counter() - start) * 1000.0
                self.stats.callback_count += 1
                self.stats.last_callback_duration_ms = elapsed_ms
                self.stats.max_callback_duration_ms = max(self.stats.max_callback_duration_ms, elapsed_ms)

            try:
                self._stream = sd.OutputStream(
                    samplerate=self.sample_rate,
                    blocksize=self.buffer_size,
                    channels=self.channels,
                    dtype="float32",
                    device=device_index,
                    callback=_callback,
                )
                self._stream.start()
            except Exception as exc:
                self.events.emit(EventType.AUDIO_ERROR, error=str(exc))
                raise AudioEngineError(f"Failed to start audio stream: {exc}") from exc

            self._running = True
            logger.info(
                "Audio engine started: %dHz, buffer=%d, channels=%d, device=%s",
                self.sample_rate, self.buffer_size, self.channels,
                self.output_device.name if self.output_device else "default",
            )

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                return
            try:
                if self._stream is not None:
                    self._stream.stop()
                    self._stream.close()
            except Exception:
                logger.exception("Error stopping audio stream")
            finally:
                self._stream = None
                self._running = False
            logger.info("Audio engine stopped")

    def pause(self) -> None:
        with self._lock:
            if self._stream is not None:
                try:
                    self._stream.stop()
                except Exception:
                    logger.exception("Error pausing audio stream")
