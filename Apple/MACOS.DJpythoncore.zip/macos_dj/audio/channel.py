"""Mixer channel strip: gain, pan, cue send, fader, crossfader assignment.

`MixerChannel` sits between a `Deck` and the `Master` bus. It applies the
channel fader and pan, tracks whether the channel is sent to the
headphone cue bus, and holds the channel's crossfader assignment (A, B,
or THRU/neither).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

import numpy as np

from macos_dj.dsp.effects import EffectChain
from macos_dj.dsp.gain import Gain, db_to_linear


class CrossfaderAssign(Enum):
    A = auto()
    B = auto()
    THRU = auto()  # unaffected by the crossfader


@dataclass
class ChannelMeter:
    peak: float = 0.0
    rms: float = 0.0
    clipping: bool = False


class MixerChannel:
    def __init__(self, channel_id: str, sample_rate: int = 44100, channels: int = 2) -> None:
        self.channel_id = channel_id
        self.sample_rate = sample_rate
        self.channels = channels

        self.fader = Gain(initial_db=0.0)  # channel volume fader, 0dB = unity
        self.pan = 0.0  # -1.0 (left) .. +1.0 (right)
        self.cue_enabled = False
        self.crossfader_assign = CrossfaderAssign.THRU
        self.effects = EffectChain()
        self.muted = False

        self.meter = ChannelMeter()

    def set_fader_db(self, db: float) -> None:
        self.fader.set_db(db)

    def set_pan(self, pan: float) -> None:
        self.pan = max(-1.0, min(1.0, pan))

    def set_cue(self, enabled: bool) -> None:
        self.cue_enabled = enabled

    def set_crossfader_assign(self, assign: CrossfaderAssign) -> None:
        self.crossfader_assign = assign

    def set_mute(self, muted: bool) -> None:
        self.muted = muted

    def _apply_pan(self, buffer: np.ndarray) -> np.ndarray:
        if self.channels != 2 or self.pan == 0.0:
            return buffer
        # Constant-power pan law.
        angle = (self.pan + 1.0) * (np.pi / 4.0)
        left_gain = float(np.cos(angle))
        right_gain = float(np.sin(angle))
        buffer[:, 0] *= left_gain
        buffer[:, 1] *= right_gain
        return buffer

    def process(self, deck_output: np.ndarray) -> np.ndarray:
        if self.muted:
            return np.zeros_like(deck_output)
        block = self.effects.process(deck_output, self.sample_rate)
        block = self.fader.process(block)
        block = self._apply_pan(block)
        self._update_meter(block)
        return block

    def _update_meter(self, block: np.ndarray) -> None:
        if block.size == 0:
            return
        peak = float(np.max(np.abs(block)))
        rms = float(np.sqrt(np.mean(np.square(block, dtype=np.float64))))
        self.meter.peak = peak
        self.meter.rms = rms
        self.meter.clipping = peak >= 0.999
