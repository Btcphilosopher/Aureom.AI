"""Master output bus: master gain, limiter, meter, headphone mix."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from macos_dj.dsp.gain import Gain, linear_to_db
from macos_dj.dsp.limiter import Limiter


@dataclass
class MeterReading:
    peak_db: float
    rms_db: float
    clipping: bool
    peak_hold_db: float


class PeakHoldMeter:
    """Peak-hold metering with configurable decay, matching typical DJ mixer VU behavior."""

    def __init__(self, hold_seconds: float = 1.5, decay_db_per_second: float = 12.0) -> None:
        self.hold_seconds = hold_seconds
        self.decay_db_per_second = decay_db_per_second
        self._peak_hold_db = -120.0
        self._time_since_peak = 0.0

    def update(self, block: np.ndarray, block_duration_seconds: float) -> MeterReading:
        if block.size == 0:
            peak_db = rms_db = -120.0
            clipping = False
        else:
            peak = float(np.max(np.abs(block)))
            rms = float(np.sqrt(np.mean(np.square(block, dtype=np.float64))))
            peak_db = linear_to_db(peak) if peak > 0 else -120.0
            rms_db = linear_to_db(rms) if rms > 0 else -120.0
            clipping = peak >= 0.999

        if peak_db >= self._peak_hold_db:
            self._peak_hold_db = peak_db
            self._time_since_peak = 0.0
        else:
            self._time_since_peak += block_duration_seconds
            if self._time_since_peak > self.hold_seconds:
                self._peak_hold_db -= self.decay_db_per_second * block_duration_seconds
                self._peak_hold_db = max(self._peak_hold_db, peak_db)

        return MeterReading(peak_db=peak_db, rms_db=rms_db, clipping=clipping, peak_hold_db=self._peak_hold_db)


class Master:
    def __init__(self, sample_rate: int = 44100, channels: int = 2) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self.gain = Gain(initial_db=0.0)
        self.limiter = Limiter(sample_rate=sample_rate)
        self.meter = PeakHoldMeter()
        self.headphone_gain = Gain(initial_db=0.0)
        self.headphone_mix = 0.5  # 0 = full cue, 1 = full master, in headphone bus

        self.last_reading = MeterReading(peak_db=-120.0, rms_db=-120.0, clipping=False, peak_hold_db=-120.0)

    def set_gain_db(self, db: float) -> None:
        self.gain.set_db(db)

    def set_headphone_mix(self, mix: float) -> None:
        self.headphone_mix = max(0.0, min(1.0, mix))

    def process(self, summed_channels: np.ndarray) -> np.ndarray:
        block = self.gain.process(summed_channels)
        block = self.limiter.process(block)
        duration = block.shape[0] / self.sample_rate if self.sample_rate else 0.0
        self.last_reading = self.meter.update(block, duration)
        return block

    def process_headphones(self, master_block: np.ndarray, cue_block: np.ndarray) -> np.ndarray:
        mixed = master_block * self.headphone_mix + cue_block * (1.0 - self.headphone_mix)
        return self.headphone_gain.process(mixed)
