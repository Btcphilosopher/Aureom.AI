"""File decoding and sample-accurate playback cursor.

`TrackPlayer` owns the decoded PCM data for a loaded track (or a
streaming window of it for very large files) and exposes a
`read_block(n_frames)` call the deck's audio path uses to pull the next
block of samples at the current pitch/tempo. Decoding itself always
happens off the real-time thread (see `core.scheduler`); only
`read_block` is expected to be called from anywhere near the callback,
and it does no I/O -- it slices out of an already-decoded numpy array.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

import numpy as np

from macos_dj.core.logging import get_logger

logger = get_logger(__name__)

SUPPORTED_EXTENSIONS = {".wav", ".aiff", ".aif", ".flac", ".mp3", ".m4a", ".aac"}


class DecodeError(Exception):
    pass


def decode_file(path: str, target_sample_rate: Optional[int] = None) -> tuple[np.ndarray, int]:
    """Decode an audio file to a (frames, channels) float32 array.

    Uses `soundfile` (libsndfile) when available, which natively covers
    WAV/AIFF/FLAC and, on many builds, OGG. Compressed formats without
    libsndfile support (some MP3/AAC builds) raise `DecodeError` so
    callers can log-and-skip rather than crash a library scan.
    """
    suffix = Path(path).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise DecodeError(f"Unsupported file extension: {suffix}")

    try:
        import soundfile as sf  # type: ignore
    except ImportError as exc:  # pragma: no cover - exercised only w/o dependency
        raise DecodeError("soundfile is not installed") from exc

    try:
        data, sample_rate = sf.read(path, dtype="float32", always_2d=True)
    except Exception as exc:  # noqa: BLE001 - libsndfile raises varied errors
        raise DecodeError(f"Failed to decode {path}: {exc}") from exc

    if target_sample_rate and sample_rate != target_sample_rate:
        data = _resample_linear(data, sample_rate, target_sample_rate)
        sample_rate = target_sample_rate

    return data, sample_rate


def probe_duration_seconds(path: str) -> float:
    try:
        import soundfile as sf  # type: ignore

        info = sf.info(path)
        return float(info.frames) / float(info.samplerate)
    except Exception:
        return 0.0


def _resample_linear(data: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    """Simple linear-interpolation resampler.

    Adequate for aligning a track to the engine's fixed sample rate at
    load time (a one-off, non-real-time operation). Real-time
    pitch/tempo changes go through `TimeStretcher`, not this function.
    """
    if src_rate == dst_rate or len(data) == 0:
        return data
    duration = len(data) / src_rate
    dst_len = int(round(duration * dst_rate))
    src_idx = np.linspace(0, len(data) - 1, num=dst_len)
    out = np.empty((dst_len, data.shape[1]), dtype=np.float32)
    for ch in range(data.shape[1]):
        out[:, ch] = np.interp(src_idx, np.arange(len(data)), data[:, ch])
    return out


class TimeStretcher(ABC):
    """Interface for tempo change with/without pitch change.

    The reference implementation below (`LinearResampleStretcher`) is a
    naive resample-based stretcher: changing tempo also changes pitch,
    exactly like a turntable's pitch fader. It is fast, dependency-free,
    and deterministic -- appropriate as the default "vinyl-style" pitch
    control. A higher-quality phase-vocoder / WSOLA implementation (or a
    native library binding) can implement this same interface to provide
    tempo changes that preserve pitch ("keylock").
    """

    @abstractmethod
    def read(self, source: np.ndarray, start_frame: float, n_frames: int, playback_rate: float) -> tuple[np.ndarray, float]:
        """Return `n_frames` of output audio and the new fractional source
        position, reading from `source` starting at `start_frame` while
        advancing through the source at `playback_rate` (1.0 = normal
        speed, 0.5 = half speed, -1.0 = reverse).
        """
        raise NotImplementedError


class LinearResampleStretcher(TimeStretcher):
    def read(self, source: np.ndarray, start_frame: float, n_frames: int, playback_rate: float) -> tuple[np.ndarray, float]:
        channels = source.shape[1] if source.ndim > 1 else 1
        out = np.zeros((n_frames, channels), dtype=np.float32)
        if len(source) == 0:
            return out, start_frame

        positions = start_frame + np.arange(n_frames) * playback_rate
        valid_mask = (positions >= 0) & (positions < len(source) - 1)
        if np.any(valid_mask):
            valid_positions = positions[valid_mask]
            idx0 = np.floor(valid_positions).astype(np.int64)
            frac = (valid_positions - idx0).astype(np.float32)
            idx1 = np.minimum(idx0 + 1, len(source) - 1)
            for ch in range(channels):
                a = source[idx0, ch] if source.ndim > 1 else source[idx0]
                b = source[idx1, ch] if source.ndim > 1 else source[idx1]
                out[valid_mask, ch] = a * (1 - frac) + b * frac

        new_position = start_frame + n_frames * playback_rate
        return out, new_position


class TrackPlayer:
    """Owns decoded PCM data and produces playback blocks at the deck's
    current tempo/pitch via a pluggable `TimeStretcher`.
    """

    def __init__(self, stretcher: Optional[TimeStretcher] = None) -> None:
        self._samples: Optional[np.ndarray] = None
        self._sample_rate: int = 44100
        self._position_frames: float = 0.0
        self.stretcher: TimeStretcher = stretcher or LinearResampleStretcher()

    def load_decoded(self, samples: np.ndarray, sample_rate: int) -> None:
        self._samples = samples
        self._sample_rate = sample_rate
        self._position_frames = 0.0

    @property
    def is_loaded(self) -> bool:
        return self._samples is not None

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def total_frames(self) -> int:
        return 0 if self._samples is None else len(self._samples)

    @property
    def duration_seconds(self) -> float:
        if self._samples is None or self._sample_rate == 0:
            return 0.0
        return len(self._samples) / self._sample_rate

    @property
    def position_seconds(self) -> float:
        return self._position_frames / self._sample_rate if self._sample_rate else 0.0

    def seek_seconds(self, seconds: float) -> None:
        if self._samples is None:
            return
        frame = seconds * self._sample_rate
        self._position_frames = max(0.0, min(frame, float(len(self._samples))))

    def read_block(self, n_frames: int, playback_rate: float) -> np.ndarray:
        """Pull the next `n_frames` at `playback_rate` and advance the cursor.

        Returns silence (zeros) if nothing is loaded, so callers never
        need a special-case branch in the audio path.
        """
        channels = self._samples.shape[1] if (self._samples is not None and self._samples.ndim > 1) else 2
        if self._samples is None:
            return np.zeros((n_frames, channels), dtype=np.float32)

        block, new_position = self.stretcher.read(self._samples, self._position_frames, n_frames, playback_rate)
        self._position_frames = max(0.0, min(new_position, float(len(self._samples))))
        return block

    def at_end(self) -> bool:
        return self._samples is not None and self._position_frames >= len(self._samples) - 1
