"""Compatibility re-export.

The full deck implementation lives in `macos_dj.decks.deck` alongside its
supporting transport/cue/loop/hotcue models -- keeping the DJ-domain deck
logic together in one package. This module exists so `macos_dj.audio.deck`
(as named in the top-level architecture) resolves to the same class,
since the deck's `process_block` is what the audio engine's callback
actually calls.
"""

from __future__ import annotations

from macos_dj.decks.deck import Deck, DeckParameters

__all__ = ["Deck", "DeckParameters"]
