"""Audio device model and deck-to-output routing table.

Kept independent of any particular audio backend (`sounddevice`,
`pyaudio`, a future native Core Audio binding) so device enumeration and
routing logic is portable and unit-testable without real hardware.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class AudioDevice:
    device_id: str
    name: str
    max_input_channels: int
    max_output_channels: int
    default_sample_rate: float
    is_default_output: bool = False
    is_default_input: bool = False


class DeviceRegistry:
    """Enumerates and caches available audio devices.

    `refresh()` is the only method that touches the backend; everything
    else reads the cached list, so device queries from the UI never block
    on driver I/O.
    """

    def __init__(self) -> None:
        self._devices: List[AudioDevice] = []

    def refresh(self) -> List[AudioDevice]:
        try:
            import sounddevice as sd  # type: ignore
        except ImportError:
            self._devices = []
            return self._devices

        devices = []
        try:
            raw_devices = sd.query_devices()
            default_output = sd.default.device[1] if hasattr(sd.default, "device") else None
            default_input = sd.default.device[0] if hasattr(sd.default, "device") else None
            for idx, dev in enumerate(raw_devices):
                devices.append(
                    AudioDevice(
                        device_id=str(idx),
                        name=dev.get("name", f"Device {idx}"),
                        max_input_channels=int(dev.get("max_input_channels", 0)),
                        max_output_channels=int(dev.get("max_output_channels", 0)),
                        default_sample_rate=float(dev.get("default_samplerate", 44100)),
                        is_default_output=(idx == default_output),
                        is_default_input=(idx == default_input),
                    )
                )
        except Exception:
            devices = []
        self._devices = devices
        return self._devices

    def all(self) -> List[AudioDevice]:
        return list(self._devices)

    def output_devices(self) -> List[AudioDevice]:
        return [d for d in self._devices if d.max_output_channels > 0]

    def input_devices(self) -> List[AudioDevice]:
        return [d for d in self._devices if d.max_input_channels > 0]

    def find_by_name(self, name: str) -> Optional[AudioDevice]:
        for d in self._devices:
            if d.name == name:
                return d
        return None


@dataclass
class RoutingTable:
    """Which physical output channel pair each logical bus is sent to.

    Values are output device channel offsets, e.g. master -> 0 (channels
    0/1), headphones -> 2 (channels 2/3) on an interface with 4+ outputs.
    """

    master_output_offset: int = 0
    headphone_output_offset: Optional[int] = None
    deck_direct_outs: Dict[str, int] = field(default_factory=dict)
