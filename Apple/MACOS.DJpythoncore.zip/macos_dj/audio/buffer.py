"""Ring buffer and preallocated audio buffer utilities.

Real-time audio callbacks must not allocate memory. `RingBuffer` gives
producer (decoder/analysis thread) -> consumer (audio callback) handoff
without locking on the consumer side's hot path, and `AudioBuffer` is a
thin, reusable (frames, channels) float32 buffer wrapper.
"""

from __future__ import annotations

import threading

import numpy as np


class AudioBuffer:
    """A fixed-size, reusable (frames, channels) float32 buffer."""

    __slots__ = ("data",)

    def __init__(self, frames: int, channels: int) -> None:
        self.data = np.zeros((frames, channels), dtype=np.float32)

    def clear(self) -> None:
        self.data.fill(0.0)

    @property
    def frames(self) -> int:
        return self.data.shape[0]

    @property
    def channels(self) -> int:
        return self.data.shape[1]


class RingBuffer:
    """A single-producer/single-consumer lock-protected ring buffer of audio frames.

    A true lock-free SPSC ring buffer is preferable for the hardest
    real-time guarantees; this implementation uses a short critical
    section (index bookkeeping only, no data copies beyond the memcpy
    into/out of a preallocated numpy array) which is safe and fast enough
    for the Python reference engine. A future native audio engine should
    replace this with an actual lock-free implementation.
    """

    def __init__(self, capacity_frames: int, channels: int) -> None:
        self._capacity = capacity_frames
        self._channels = channels
        self._buffer = np.zeros((capacity_frames, channels), dtype=np.float32)
        self._read_pos = 0
        self._write_pos = 0
        self._available = 0
        self._lock = threading.Lock()

    @property
    def capacity(self) -> int:
        return self._capacity

    def available_to_read(self) -> int:
        with self._lock:
            return self._available

    def available_to_write(self) -> int:
        with self._lock:
            return self._capacity - self._available

    def write(self, data: np.ndarray) -> int:
        """Write as many frames from `data` as fit; returns frames written."""
        with self._lock:
            free = self._capacity - self._available
            n = min(len(data), free)
            if n <= 0:
                return 0
            first_chunk = min(n, self._capacity - self._write_pos)
            self._buffer[self._write_pos : self._write_pos + first_chunk] = data[:first_chunk]
            remaining = n - first_chunk
            if remaining:
                self._buffer[0:remaining] = data[first_chunk : first_chunk + remaining]
            self._write_pos = (self._write_pos + n) % self._capacity
            self._available += n
            return n

    def read(self, n_frames: int, out: np.ndarray | None = None) -> np.ndarray:
        """Read up to `n_frames`. Missing frames are zero-filled (underrun)."""
        with self._lock:
            n_available = min(n_frames, self._available)
            result = out if out is not None else np.zeros((n_frames, self._channels), dtype=np.float32)
            if out is not None:
                result[:] = 0.0

            if n_available > 0:
                first_chunk = min(n_available, self._capacity - self._read_pos)
                result[:first_chunk] = self._buffer[self._read_pos : self._read_pos + first_chunk]
                remaining = n_available - first_chunk
                if remaining:
                    result[first_chunk : first_chunk + remaining] = self._buffer[0:remaining]
                self._read_pos = (self._read_pos + n_available) % self._capacity
                self._available -= n_available
            return result

    def reset(self) -> None:
        with self._lock:
            self._read_pos = 0
            self._write_pos = 0
            self._available = 0
            self._buffer.fill(0.0)
