from macos_dj.library.playlists import PlaylistManager, SmartRule, SmartRuleGroup
from macos_dj.library.tracks import Track


def test_create_add_remove_reorder():
    mgr = PlaylistManager()
    playlist = mgr.create("Warmup")
    playlist.add_track("t1")
    playlist.add_track("t2")
    playlist.add_track("t3")
    assert playlist.track_ids == ["t1", "t2", "t3"]

    playlist.reorder_track("t3", 0)
    assert playlist.track_ids == ["t3", "t1", "t2"]

    playlist.remove_track("t1")
    assert playlist.track_ids == ["t3", "t2"]


def test_delete_playlist():
    mgr = PlaylistManager()
    playlist = mgr.create("Temp")
    mgr.delete(playlist.id)
    assert mgr.get(playlist.id) is None


def test_smart_playlist_bpm_and_genre():
    tracks = [
        Track(title="A", artist="X", bpm=128.0, genre="House"),
        Track(title="B", artist="Y", bpm=100.0, genre="House"),
        Track(title="C", artist="Z", bpm=130.0, genre="Techno"),
    ]
    rules = SmartRuleGroup(
        rules=[SmartRule(field="bpm", op=">", value=120.0), SmartRule(field="genre", op="=", value="House")],
        match_all=True,
    )
    mgr = PlaylistManager()
    playlist = mgr.create("High Energy House", is_smart=True, smart_rules=rules)
    matched = playlist.resolve_smart(tracks)
    assert [t.title for t in matched] == ["A"]


def test_smart_playlist_rating_threshold():
    tracks = [
        Track(title="A", artist="X", rating=5),
        Track(title="B", artist="Y", rating=2),
    ]
    rules = SmartRuleGroup(rules=[SmartRule(field="rating", op=">=", value=4)])
    playlist = PlaylistManager().create("Favorites", is_smart=True, smart_rules=rules)
    matched = playlist.resolve_smart(tracks)
    assert [t.title for t in matched] == ["A"]
