from macos_dj.controllers.mapping import (
    ControllerMapping,
    MappingEngine,
    MappingEntry,
    MidiTrigger,
    default_two_deck_mapping,
)


def test_mapping_round_trips_through_dict():
    mapping = default_two_deck_mapping()
    data = mapping.to_dict()
    restored = ControllerMapping.from_dict(data)
    assert len(restored.entries()) == len(mapping.entries())


def test_mapping_engine_resolves_note_on():
    mapping = ControllerMapping("test")
    mapping.add(MappingEntry(MidiTrigger("note_on", 0, 11), "PLAY", target_deck="A"))
    engine = MappingEngine(mapping)

    result = engine.resolve(MidiTrigger("note_on", 0, 11), raw_value=127)
    assert result is not None
    assert result.command == "PLAY"
    assert result.target_deck == "A"


def test_mapping_engine_normalises_cc_value():
    mapping = ControllerMapping("test")
    mapping.add(MappingEntry(MidiTrigger("control_change", 0, 7), "SET_VOLUME", target_deck="A", parameter_scale=1.0))
    engine = MappingEngine(mapping)

    result = engine.resolve(MidiTrigger("control_change", 0, 7), raw_value=127)
    assert result is not None
    assert result.value is not None
    assert abs(result.value - 1.0) < 0.01


def test_mapping_engine_returns_none_for_unmapped_trigger():
    engine = MappingEngine(ControllerMapping("empty"))
    result = engine.resolve(MidiTrigger("note_on", 0, 99), raw_value=100)
    assert result is None
