from macos_dj.core.commands import Command, CommandBus, CommandContext
from macos_dj.core.events import Event, EventBus, EventType


def test_event_bus_publish_subscribe():
    bus = EventBus()
    received = []
    bus.subscribe(EventType.PLAY, lambda e: received.append(e))
    bus.emit(EventType.PLAY, deck_id="A")
    assert len(received) == 1
    assert received[0].payload["deck_id"] == "A"


def test_event_bus_unsubscribe():
    bus = EventBus()
    received = []
    unsubscribe = bus.subscribe(EventType.STOP, lambda e: received.append(e))
    unsubscribe()
    bus.emit(EventType.STOP)
    assert received == []


def test_event_bus_handler_exception_does_not_break_bus():
    bus = EventBus()
    calls = []

    def bad_handler(event: Event) -> None:
        raise RuntimeError("boom")

    def good_handler(event: Event) -> None:
        calls.append(event)

    bus.subscribe(EventType.CUE, bad_handler)
    bus.subscribe(EventType.CUE, good_handler)
    bus.emit(EventType.CUE)
    assert len(calls) == 1


def test_command_bus_dispatches_registered_handler():
    bus = CommandBus()
    received = []
    bus.register(Command.PLAY, lambda ctx: received.append(ctx.deck_id))
    ok = bus.execute(Command.PLAY, CommandContext(deck_id="B"))
    assert ok
    assert received == ["B"]


def test_command_bus_unregistered_command_returns_false():
    bus = CommandBus()
    assert bus.execute(Command.PAUSE) is False


def test_command_bus_execute_by_name():
    bus = CommandBus()
    received = []
    bus.register(Command.STOP, lambda ctx: received.append(True))
    assert bus.execute_by_name("STOP")
    assert received == [True]
    assert bus.execute_by_name("NOT_A_COMMAND") is False
