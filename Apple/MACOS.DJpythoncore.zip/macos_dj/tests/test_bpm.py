import numpy as np
import pytest

from macos_dj.analysis.bpm import estimate_bpm


def _synthetic_click_track(bpm: float, sample_rate: int = 44100, duration_seconds: float = 8.0) -> np.ndarray:
    """Generate a mono click track: short bursts of noise at each beat, so
    the spectral-flux onset detector has a strong, well-defined novelty
    peak to lock onto without depending on any real audio fixture file.
    """
    n_samples = int(duration_seconds * sample_rate)
    audio = np.zeros(n_samples, dtype=np.float32)
    beat_interval = 60.0 / bpm
    click_len = int(0.01 * sample_rate)
    t = 0.0
    rng = np.random.default_rng(42)
    while t < duration_seconds:
        start = int(t * sample_rate)
        end = min(start + click_len, n_samples)
        envelope = np.linspace(1.0, 0.0, end - start)
        audio[start:end] += (rng.standard_normal(end - start) * envelope).astype(np.float32)
        t += beat_interval
    return audio.reshape(-1, 1)


@pytest.mark.parametrize("bpm", [100.0, 120.0, 140.0])
def test_estimate_bpm_recovers_synthetic_tempo(bpm):
    audio = _synthetic_click_track(bpm)
    estimate = estimate_bpm(audio, sample_rate=44100)

    # Allow octave-equivalent matches (half/double time is a known,
    # documented ambiguity in autocorrelation-based tempo estimation).
    candidates = [estimate.bpm, estimate.bpm * 2, estimate.bpm / 2]
    assert any(abs(c - bpm) < 3.0 for c in candidates)


def test_estimate_bpm_handles_silence_gracefully():
    silence = np.zeros((44100 * 4, 1), dtype=np.float32)
    estimate = estimate_bpm(silence, sample_rate=44100)
    assert estimate.bpm > 0
    assert 0.0 <= estimate.confidence <= 1.0
