from macos_dj.decks.transport import InvalidTransportTransition, Transport, TransportState


def test_initial_state_is_empty():
    t = Transport()
    assert t.state is TransportState.EMPTY
    assert not t.is_loaded


def test_load_then_play_pause_stop():
    t = Transport()
    t.load()
    assert t.state is TransportState.STOPPED
    t.play()
    assert t.is_playing
    t.pause()
    assert t.state is TransportState.PAUSED
    t.play()
    assert t.is_playing
    t.stop()
    assert t.state is TransportState.STOPPED


def test_cannot_play_before_loading():
    t = Transport()
    try:
        t.play()
        assert False, "expected InvalidTransportTransition"
    except InvalidTransportTransition:
        pass


def test_cue_down_from_stopped():
    t = Transport()
    t.load()
    t.cue_down()
    assert t.state is TransportState.CUED
    t.play()
    assert t.is_playing
