from macos_dj.analysis.key_compatibility import Compatibility, compatibility, compatible_keys


def test_identical_key_is_compatible():
    result = compatibility("8A", "8A")
    assert result.result is Compatibility.COMPATIBLE


def test_relative_major_minor_is_compatible():
    result = compatibility("8A", "8B")
    assert result.result is Compatibility.COMPATIBLE


def test_adjacent_wheel_position_is_compatible():
    result = compatibility("8A", "9A")
    assert result.result is Compatibility.COMPATIBLE
    result_wrap = compatibility("1A", "12A")
    assert result_wrap.result is Compatibility.COMPATIBLE


def test_distant_key_is_incompatible():
    result = compatibility("1A", "7A")
    assert result.result is Compatibility.INCOMPATIBLE


def test_invalid_notation_is_incompatible():
    result = compatibility("Xmaj", "8A")
    assert result.result is Compatibility.INCOMPATIBLE


def test_compatible_keys_lists_neighbours():
    neighbours = compatible_keys("8A")
    assert "8A" in neighbours
    assert "8B" in neighbours
    assert len(neighbours) == 4
