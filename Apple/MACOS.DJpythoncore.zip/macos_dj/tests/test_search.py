from macos_dj.library.search import search_tracks
from macos_dj.library.tracks import Track


def _tracks():
    return [
        Track(title="Strobe", artist="Deadmau5", genre="Progressive House", bpm=128.0, rating=5),
        Track(title="Stronger", artist="Kanye West", genre="Hip Hop", bpm=104.0, rating=3),
        Track(title="Levels", artist="Avicii", genre="Progressive House", bpm=126.0, rating=4),
    ]


def test_exact_substring_match_scores_high():
    results = search_tracks(_tracks(), "strobe")
    assert results[0].track.title == "Strobe"
    assert results[0].score > 0.9


def test_fuzzy_typo_still_matches():
    results = search_tracks(_tracks(), "stronge")
    titles = [r.track.title for r in results]
    assert "Stronger" in titles


def test_bpm_filter():
    results = search_tracks(_tracks(), "", bpm=127.0, bpm_tolerance=2.0)
    titles = {r.track.title for r in results}
    assert titles == {"Strobe", "Levels"}


def test_rating_filter():
    results = search_tracks(_tracks(), "", rating=4)
    titles = {r.track.title for r in results}
    assert titles == {"Strobe", "Levels"}


def test_empty_query_returns_all_matching_filters():
    results = search_tracks(_tracks(), "")
    assert len(results) == 3
