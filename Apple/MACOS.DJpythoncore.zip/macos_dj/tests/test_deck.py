import numpy as np
import pytest

from macos_dj.analysis.beatgrid import BeatGrid
from macos_dj.core.events import EventBus
from macos_dj.decks.deck import Deck
from macos_dj.library.tracks import Track


def _make_deck(deck_id: str = "A") -> Deck:
    bus = EventBus()
    deck = Deck(deck_id, sample_rate=44100, channels=2, event_bus=bus)
    samples = np.zeros((44100 * 4, 2), dtype=np.float32)  # 4s of silence
    track = Track(file_path="/fake/path.wav", title="Test", artist="Tester")
    track.beatgrid = BeatGrid(bpm=120.0, first_beat_seconds=0.0)
    deck.load_track(track, samples, 44100)
    return deck


def test_load_track_sets_stopped_state():
    deck = _make_deck()
    assert deck.transport.is_loaded
    assert not deck.transport.is_playing


def test_play_pause_stop_cycle():
    deck = _make_deck()
    deck.play()
    assert deck.transport.is_playing
    deck.pause()
    assert not deck.transport.is_playing
    deck.play()
    deck.stop()
    assert deck.player.position_seconds == 0.0


def test_cue_set_and_jump():
    deck = _make_deck()
    deck.play()
    deck.seek(1.0)
    deck.cue_press()  # while playing: sets cue at current pos, stops
    assert deck.cue.cue_position() == pytest.approx(1.0)

    deck.seek(2.0)
    deck.cue_press()  # while stopped: jumps to existing cue
    assert deck.player.position_seconds == pytest.approx(1.0)


def test_pitch_affects_effective_bpm():
    deck = _make_deck()
    deck.set_pitch_range(0.10)
    deck.set_pitch(0.5)  # +5%
    assert deck.effective_bpm() == pytest.approx(126.0)
    assert deck.playback_rate() == pytest.approx(1.05)


def test_pitch_reset():
    deck = _make_deck()
    deck.set_pitch(0.8)
    deck.reset_pitch()
    assert deck.effective_pitch_percent() == 0.0


def test_hot_cue_set_then_trigger():
    deck = _make_deck()
    deck.seek(2.0)
    deck.trigger_hot_cue(1)  # first press: sets the cue
    assert deck.hotcues.is_set(1)

    deck.seek(0.0)
    deck.trigger_hot_cue(1)  # second press: jumps + starts playback
    assert deck.player.position_seconds == pytest.approx(2.0)
    assert deck.transport.is_playing


def test_process_block_returns_silence_when_not_playing():
    deck = _make_deck()
    block = deck.process_block(512)
    assert block.shape == (512, 2)
    assert np.all(block == 0.0)


def test_process_block_advances_position_when_playing():
    deck = _make_deck()
    deck.play()
    deck.process_block(4410)  # 0.1s at 44100Hz
    assert deck.player.position_seconds == pytest.approx(0.1, abs=0.01)


def test_sync_matches_tempo_reversibly():
    master = _make_deck("A")
    follower = _make_deck("B")
    follower.beatgrid = BeatGrid(bpm=116.0, first_beat_seconds=0.0)  # within +/-8% default pitch range

    follower.sync_to(master)
    assert follower.effective_bpm() == pytest.approx(120.0, abs=0.5)
    # Underlying beatgrid BPM is untouched -- only pitch changed.
    assert follower.beatgrid.bpm == 116.0

    follower.reset_pitch()
    assert follower.effective_bpm() == pytest.approx(116.0)
