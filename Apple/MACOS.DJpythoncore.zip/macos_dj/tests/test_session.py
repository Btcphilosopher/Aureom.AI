import tempfile
from pathlib import Path

from macos_dj.core.session import DeckState, Session, SessionManager


def test_save_and_load_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        manager = SessionManager(sessions_dir=Path(tmp))
        session = Session(name="Friday Set", decks=[DeckState(deck_id="A", file_path="/music/a.wav", position_seconds=42.0)])
        path = manager.save(session)
        assert path.exists()

        loaded = manager.load(path)
        assert loaded is not None
        assert loaded.name == "Friday Set"
        assert loaded.decks[0].deck_id == "A"
        assert loaded.decks[0].position_seconds == 42.0


def test_checkpoint_and_recovery():
    with tempfile.TemporaryDirectory() as tmp:
        manager = SessionManager(sessions_dir=Path(tmp))
        assert not manager.has_recoverable_checkpoint()

        session = Session(name="Crash Test")
        manager.checkpoint(session)
        assert manager.has_recoverable_checkpoint()

        recovered = manager.load_checkpoint()
        assert recovered is not None
        assert recovered.name == "Crash Test"

        manager.clear_checkpoint()
        assert not manager.has_recoverable_checkpoint()


def test_load_missing_file_returns_none():
    with tempfile.TemporaryDirectory() as tmp:
        manager = SessionManager(sessions_dir=Path(tmp))
        assert manager.load(Path(tmp) / "does_not_exist.json") is None
