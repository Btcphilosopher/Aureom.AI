import tempfile
from pathlib import Path

from macos_dj.analysis.beatgrid import BeatGrid
from macos_dj.library.database import LibraryDatabase
from macos_dj.library.tracks import Track


def test_upsert_and_get_track():
    with tempfile.TemporaryDirectory() as tmp:
        db = LibraryDatabase(Path(tmp) / "library.sqlite3")
        track = Track(file_path="/music/a.wav", title="A", artist="B", bpm=128.0)
        track.beatgrid = BeatGrid(bpm=128.0, first_beat_seconds=0.05)
        db.upsert_track(track)

        fetched = db.get_track(track.id)
        assert fetched is not None
        assert fetched.title == "A"
        assert fetched.bpm == 128.0
        assert fetched.beatgrid is not None
        assert fetched.beatgrid.bpm == 128.0
        db.close()


def test_get_track_by_path():
    with tempfile.TemporaryDirectory() as tmp:
        db = LibraryDatabase(Path(tmp) / "library.sqlite3")
        track = Track(file_path="/music/b.wav", title="B", artist="C")
        db.upsert_track(track)
        fetched = db.get_track_by_path("/music/b.wav")
        assert fetched is not None
        assert fetched.id == track.id
        db.close()


def test_upsert_updates_existing_row():
    with tempfile.TemporaryDirectory() as tmp:
        db = LibraryDatabase(Path(tmp) / "library.sqlite3")
        track = Track(file_path="/music/c.wav", title="Old Title", artist="C")
        db.upsert_track(track)

        track.title = "New Title"
        db.upsert_track(track)

        fetched = db.get_track(track.id)
        assert fetched.title == "New Title"
        assert len(db.all_tracks()) == 1
        db.close()


def test_record_play_updates_history_and_play_count():
    with tempfile.TemporaryDirectory() as tmp:
        db = LibraryDatabase(Path(tmp) / "library.sqlite3")
        track = Track(file_path="/music/d.wav", title="D", artist="D")
        db.upsert_track(track)
        db.record_play(track.id, deck_id="A", session_id="s1")
        fetched = db.get_track(track.id)
        assert fetched.play_count == 1
        db.close()


def test_delete_track():
    with tempfile.TemporaryDirectory() as tmp:
        db = LibraryDatabase(Path(tmp) / "library.sqlite3")
        track = Track(file_path="/music/e.wav", title="E", artist="E")
        db.upsert_track(track)
        db.delete_track(track.id)
        assert db.get_track(track.id) is None
        db.close()
