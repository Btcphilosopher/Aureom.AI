import numpy as np

from macos_dj.analysis.waveform import generate_waveform


def test_generate_waveform_produces_all_levels():
    sample_rate = 44100
    t = np.arange(sample_rate * 2) / sample_rate
    mono = np.sin(2 * np.pi * 440 * t).astype(np.float32)
    waveform = generate_waveform(mono, sample_rate, levels_samples_per_pixel=[64, 1024])

    assert set(waveform.levels.keys()) == {64, 1024}
    assert waveform.duration_seconds > 1.9

    level = waveform.levels[1024]
    assert len(level.min_values) == len(level.max_values) == len(level.rms_values)
    assert np.all(level.max_values >= level.min_values)


def test_overview_returns_coarsest_level():
    sample_rate = 44100
    mono = np.zeros(sample_rate, dtype=np.float32)
    waveform = generate_waveform(mono, sample_rate, levels_samples_per_pixel=[64, 256, 4096])
    overview = waveform.overview()
    assert overview.samples_per_pixel == 4096


def test_best_level_for_pixel_density():
    sample_rate = 44100
    mono = np.zeros(sample_rate, dtype=np.float32)
    waveform = generate_waveform(mono, sample_rate, levels_samples_per_pixel=[64, 1024, 16384])
    level = waveform.best_level_for_pixel_density(pixels_per_second=100)
    assert level.samples_per_pixel in (64, 1024, 16384)
