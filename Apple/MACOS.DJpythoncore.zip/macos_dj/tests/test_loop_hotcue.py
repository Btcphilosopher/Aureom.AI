import pytest

from macos_dj.analysis.beatgrid import BeatGrid
from macos_dj.decks.hotcue import HotCueBank, MAX_HOT_CUES
from macos_dj.decks.loop import LoopEngine


def test_loop_in_out_creates_loop():
    engine = LoopEngine()
    engine.loop_in(10.0)
    loop = engine.loop_out(12.0)
    assert loop is not None
    assert loop.start_seconds == 10.0
    assert loop.end_seconds == 12.0
    assert engine.active_loop is loop


def test_beat_loop_snaps_to_grid():
    grid = BeatGrid(bpm=120.0, first_beat_seconds=0.0)  # beat = 0.5s
    engine = LoopEngine(beatgrid=grid)
    loop = engine.set_beat_loop(1.05, beats=4)
    assert loop.start_seconds == pytest.approx(1.0)  # snapped to nearest beat
    assert loop.length_seconds == pytest.approx(2.0)  # 4 beats * 0.5s


def test_loop_double_and_halve():
    engine = LoopEngine()
    engine.loop_in(0.0)
    engine.loop_out(1.0)
    engine.double()
    assert engine.active_loop.length_seconds == pytest.approx(2.0)
    engine.halve()
    assert engine.active_loop.length_seconds == pytest.approx(1.0)


def test_loop_exit_and_reloop():
    engine = LoopEngine()
    engine.loop_in(0.0)
    engine.loop_out(1.0)
    engine.exit()
    assert engine.active_loop is None
    relooped = engine.reloop()
    assert relooped is not None
    assert engine.active_loop is relooped


def test_wrap_position_wraps_inside_loop():
    engine = LoopEngine()
    engine.loop_in(0.0)
    engine.loop_out(1.0)
    assert engine.wrap_position(1.3) == pytest.approx(0.3)
    assert engine.wrap_position(0.5) == pytest.approx(0.5)  # inside loop, unaffected


def test_hotcue_bank_set_get_clear():
    bank = HotCueBank()
    cue = bank.set(1, position_seconds=30.0, label="Drop")
    assert bank.get(1) is cue
    assert bank.is_set(1)
    bank.clear(1)
    assert bank.get(1) is None


def test_hotcue_slot_validation():
    bank = HotCueBank()
    with pytest.raises(ValueError):
        bank.set(0, position_seconds=1.0)
    with pytest.raises(ValueError):
        bank.set(MAX_HOT_CUES + 1, position_seconds=1.0)


def test_hotcue_default_colors_assigned():
    bank = HotCueBank()
    cue1 = bank.set(1, position_seconds=1.0)
    cue2 = bank.set(2, position_seconds=2.0)
    assert cue1.color != cue2.color
