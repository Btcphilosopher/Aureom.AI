import numpy as np
import pytest

from macos_dj.audio.channel import CrossfaderAssign
from macos_dj.audio.mixer import CrossfaderCurve, Mixer, _crossfader_gains


def test_crossfader_gains_constant_power_full_a():
    gain_a, gain_b = _crossfader_gains(-1.0, CrossfaderCurve.CONSTANT_POWER)
    assert gain_a == pytest.approx(1.0, abs=1e-6)
    assert gain_b == pytest.approx(0.0, abs=1e-6)


def test_crossfader_gains_constant_power_center_sums_to_more_than_linear():
    gain_a, gain_b = _crossfader_gains(0.0, CrossfaderCurve.CONSTANT_POWER)
    assert gain_a == pytest.approx(gain_b, abs=1e-6)
    # Constant-power center should be louder than simple linear (0.5, 0.5)
    assert gain_a > 0.6


def test_crossfader_gains_linear_center():
    gain_a, gain_b = _crossfader_gains(0.0, CrossfaderCurve.LINEAR)
    assert gain_a == pytest.approx(0.5)
    assert gain_b == pytest.approx(0.5)


def test_mixer_routes_deck_through_crossfader_assignment():
    mixer = Mixer(channel_ids=["A", "B"], sample_rate=44100)
    mixer.channel("A").set_crossfader_assign(CrossfaderAssign.A)
    mixer.channel("B").set_crossfader_assign(CrossfaderAssign.B)
    mixer.set_crossfader(-1.0)  # full A

    block = np.ones((256, 2), dtype=np.float32) * 0.1
    master = mixer.process({"A": block.copy(), "B": block.copy()})

    # With crossfader hard left, deck B's contribution should be silenced.
    mixer.set_crossfader(1.0)  # full B
    master_b_only = mixer.process({"A": block.copy(), "B": np.zeros_like(block)})
    assert np.max(np.abs(master_b_only)) < 1e-6
