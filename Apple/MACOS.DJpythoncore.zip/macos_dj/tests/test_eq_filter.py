import numpy as np
import pytest

from macos_dj.dsp.eq import ThreeBandEQ
from macos_dj.dsp.filter import FilterMode, ResonantFilter


def _sine(freq: float, sample_rate: int = 44100, duration: float = 0.5) -> np.ndarray:
    t = np.arange(int(sample_rate * duration)) / sample_rate
    mono = np.sin(2 * np.pi * freq * t).astype(np.float32)
    return np.stack([mono, mono], axis=1)


def _rms(buffer: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(buffer, dtype=np.float64))))


def test_eq_kill_low_reduces_low_frequency_energy():
    eq = ThreeBandEQ(sample_rate=44100)
    low_tone = _sine(80.0)
    eq.kill_low()
    processed = eq.process(low_tone.copy())
    assert _rms(processed) < _rms(low_tone) * 0.5


def test_eq_flat_is_near_unity():
    eq = ThreeBandEQ(sample_rate=44100)
    tone = _sine(1000.0)
    processed = eq.process(tone.copy())
    assert _rms(processed) == pytest.approx(_rms(tone), rel=0.1)


def test_lowpass_filter_attenuates_high_frequency():
    f = ResonantFilter(sample_rate=44100)
    f.set_mode(FilterMode.LOW_PASS)
    f.set_frequency(500.0)
    high_tone = _sine(8000.0)
    processed = f.process(high_tone.copy())
    assert _rms(processed) < _rms(high_tone) * 0.3


def test_highpass_filter_attenuates_low_frequency():
    f = ResonantFilter(sample_rate=44100)
    f.set_mode(FilterMode.HIGH_PASS)
    f.set_frequency(2000.0)
    low_tone = _sine(100.0)
    processed = f.process(low_tone.copy())
    assert _rms(processed) < _rms(low_tone) * 0.3


def test_filter_bypass_when_off():
    f = ResonantFilter(sample_rate=44100)
    tone = _sine(1000.0)
    processed = f.process(tone.copy())
    assert np.allclose(processed, tone)


def test_knob_position_maps_to_mode():
    f = ResonantFilter(sample_rate=44100)
    f.set_knob_position(0.5)
    assert f.mode is FilterMode.LOW_PASS
    f.set_knob_position(-0.5)
    assert f.mode is FilterMode.HIGH_PASS
    f.set_knob_position(0.0)
    assert f.mode is FilterMode.OFF
