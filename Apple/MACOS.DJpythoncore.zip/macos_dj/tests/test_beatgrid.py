import pytest

from macos_dj.analysis.beat_detection import Beat
from macos_dj.analysis.beatgrid import BeatGrid, build_beatgrid_from_beats


def test_beat_length_seconds():
    grid = BeatGrid(bpm=120.0, first_beat_seconds=0.0)
    assert grid.beat_length_seconds == pytest.approx(0.5)
    assert grid.bar_length_seconds == pytest.approx(2.0)


def test_nearest_beat_position():
    grid = BeatGrid(bpm=120.0, first_beat_seconds=0.1)
    # Beats at 0.1, 0.6, 1.1, 1.6 ...
    assert grid.nearest_beat_position(0.05) == pytest.approx(0.1)
    assert grid.nearest_beat_position(0.55) == pytest.approx(0.6)


def test_set_bpm_keeps_anchor_aligned():
    grid = BeatGrid(bpm=120.0, first_beat_seconds=1.0)
    grid.set_bpm(128.0, anchor_seconds=1.0)
    assert grid.bpm == 128.0
    assert grid.nearest_beat_position(1.0) == pytest.approx(1.0)
    assert grid.manually_adjusted


def test_nudge_and_shift():
    grid = BeatGrid(bpm=120.0, first_beat_seconds=0.0)
    grid.nudge(0.02)
    assert grid.first_beat_seconds == pytest.approx(0.02)
    grid.shift_to(1.5)
    assert grid.first_beat_seconds == pytest.approx(1.5)


def test_build_beatgrid_from_beats_uses_median_interval():
    beats = [Beat(time_seconds=t) for t in [0.0, 0.5, 1.0, 1.5, 2.0]]
    grid = build_beatgrid_from_beats(beats)
    assert grid.bpm == pytest.approx(120.0, abs=0.5)
    assert grid.first_beat_seconds == pytest.approx(0.0)


def test_build_beatgrid_from_no_beats_returns_fallback():
    grid = build_beatgrid_from_beats([], fallback_bpm=128.0)
    assert grid.bpm == 128.0
    assert grid.confidence == 0.0
