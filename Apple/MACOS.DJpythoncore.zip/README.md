# MACOS.DJ — Python Core Engine

The Python software foundation for MACOS.DJ, a professional-grade DJ
workstation for macOS. This package is the **core orchestration,
music-library, analysis, DSP-control, state-management, and application
engine** on top of which a native macOS front-end (SwiftUI + Core Audio)
is meant to be built.

This is not a toy script. It's a modular, typed, tested Python system
covering decks, mixing, DSP, BPM/beat/key analysis, a SQLite music
library, MIDI control, recording, session persistence, and a UI-facing
API boundary — architected so any single piece (most importantly the
real-time audio path) can be swapped for a native implementation without
touching the rest.

## Honesty about what Python can and can't do here

Python, even with `numpy`, cannot give hard real-time audio guarantees
(no GC pauses, no jitter, deterministic sub-millisecond callback timing).
This codebase is built so that:

- The **real-time boundary is explicit**: `AudioEngine` calls a render
  callback (ultimately `Mixer.process`) directly from the PortAudio
  callback thread. Everything on that path — `Deck.process_block`,
  `ThreeBandEQ.process`, `ResonantFilter.process`, `Limiter.process` —
  is written to avoid allocation, disk I/O, database access, and logging.
- Everything else (BPM/beat/key analysis, waveform generation, library
  scanning, session checkpointing) is explicitly pushed to background
  threads via `core.scheduler`.
- Every DSP/analysis module is defined behind a small interface
  (`Effect`, `TimeStretcher`, `KeyDetector`, `Recorder`'s backend, the
  audio engine itself) so a future native Core Audio / Accelerate /
  Swift implementation can be substituted module-by-module.

For a shipped product, expect the real-time audio path (engine, mixer
summation, time-stretching, and DSP) to eventually move to a native
Core Audio implementation, with this Python layer continuing to own
orchestration, the library, analysis, and application state.

## Project layout

```text
macos_dj/
├── core/            application, config, state, events, scheduler, logging,
│                    commands, keyboard shortcuts, session save/load, performance
├── audio/           engine, player/time-stretch, deck (re-export), mixer,
│                    channel strip, master bus, ring buffer, device routing
├── dsp/              gain, 3-band EQ, resonant filter, limiter, compressor,
│                    effects framework (delay/echo/reverb/flanger/phaser/
│                    distortion/bitcrusher)
├── analysis/        BPM, beat/onset detection, beat grid, waveform,
│                    key detection, key compatibility, energy, spectrum,
│                    the end-to-end analysis pipeline
├── decks/           Deck, transport state machine, cue, hot cues, loop
│                    engine, jog wheel, DeckManager
├── library/         SQLite database, track model, metadata/scanner,
│                    playlists (incl. smart playlists), search, DJ history
├── controllers/     MIDI input, mapping engine, controller state
├── recording/       master-output recorder
├── networking/      local, loopback-only JSON API (off by default)
├── ui/               the UI boundary — the only surface a future
│                    native front-end should depend on
├── tests/           pytest suite (deterministic DSP/analysis tests
│                    included — no audio fixture files required)
└── main.py          headless bring-up entry point
```

## Requirements

- Python 3.12+
- macOS is the target platform; the engine also runs headless on Linux
  for development/CI (audio I/O and MIDI degrade gracefully without
  hardware/drivers present).

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .[dev]        # optional: dev/test tooling
```

## Running

```bash
python -m macos_dj.main --scan-library
```

Flags:

- `--no-audio` — construct everything but don't open an audio stream
  (useful headless/CI).
- `--scan-library` — scan the configured library locations on startup.
- `--restore-session` — offer to restore the last crash-recovery
  checkpoint, if one exists.

Configuration lives at `~/Library/Application Support/MACOS.DJ/config.json`
on macOS (see `config.example.json` for the full shape and defaults). The
local control API (`POST /deck/play`, etc.) is **disabled by default**
and, when enabled, only ever binds to `127.0.0.1`.

## Testing

```bash
pytest
```

The test suite is deterministic: BPM/beat detection is tested against a
synthetically generated click track (no audio fixture files needed), and
DSP tests check measurable properties (EQ kill reduces RMS in-band,
low-pass attenuates high frequencies, etc.) rather than exact sample
comparisons.

## Extending

- **New effect**: subclass `dsp.effects.Effect`, register it in
  `EFFECT_REGISTRY`.
- **New controller**: author a `controllers.mapping.ControllerMapping`
  JSON file — no Python required for a new MIDI mapping.
- **New audio backend**: implement the same interface as
  `audio.engine.AudioEngine` (`start`/`stop`/`set_render_callback`/etc.)
  and swap it in at the `core.application.Application` composition root.
- **Higher-quality time-stretching**: implement
  `audio.player.TimeStretcher` and pass it to `TrackPlayer`.
