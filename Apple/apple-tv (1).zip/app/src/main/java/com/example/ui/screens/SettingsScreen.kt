package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SystemTVSettings
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    currentSettings: SystemTVSettings,
    onUpdateSettings: (SystemTVSettings) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = listOf(
        "Video and Audio",
        "Network Diagnostics",
        "Remotes and Devices",
        "AirPlay and HomeKit",
        "Accessibility",
        "System and About"
    )
    var selectedSection by remember { mutableStateOf("Video and Audio") }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(28.dp),
        horizontalArrangement = Arrangement.spacedBy(32.dp)
    ) {
        // Left Column: Settings Categories Menu
        Column(modifier = Modifier.width(280.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { onBack() }
                    .padding(bottom = 20.dp)
                    .testTag("settings_back_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = AppleTextWhite, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Settings", color = AppleTextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sections) { section ->
                    val isSelected = section == selectedSection
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) AppleTextWhite else AppleCardBackground)
                            .clickable { selectedSection = section }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("settings_category_$section")
                    ) {
                        Text(
                            text = section,
                            color = if (isSelected) Color.Black else AppleTextWhite,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Right Column: Detail Settings Options
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(AppleCardBackground)
                .border(1.dp, Color(0xFF2C2C3A), RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            when (selectedSection) {
                "Video and Audio" -> {
                    Text("Video & Audio Calibration", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggleRow(
                        title = "Resolution & Dynamic Range",
                        subtitle = currentSettings.video.format,
                        trailingPill = "4K Dolby Vision"
                    )

                    SettingToggleRow(
                        title = "Match Dynamic Range",
                        subtitle = "Automatically switch output to HDR/Dolby Vision when original media requires it",
                        isSwitch = true,
                        switchChecked = currentSettings.video.matchDynamicRange,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(video = currentSettings.video.copy(matchDynamicRange = it)))
                        }
                    )

                    SettingToggleRow(
                        title = "Match Frame Rate",
                        subtitle = "Match native 24.000 fps / 23.976 fps cinematic cadence",
                        isSwitch = true,
                        switchChecked = currentSettings.video.matchFrameRate,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(video = currentSettings.video.copy(matchFrameRate = it)))
                        }
                    )

                    SettingToggleRow(
                        title = "Audio Output",
                        subtitle = currentSettings.audio.outputDevice,
                        trailingPill = "Spatial Audio"
                    )

                    SettingToggleRow(
                        title = "Audio Format",
                        subtitle = currentSettings.audio.audioFormat,
                        trailingPill = "Dolby Atmos"
                    )

                    SettingToggleRow(
                        title = "Reduce Loud Sounds",
                        subtitle = "Softens loud explosions and boosts quiet dialogue in living room",
                        isSwitch = true,
                        switchChecked = currentSettings.audio.reduceLoudSounds,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(audio = currentSettings.audio.copy(reduceLoudSounds = it)))
                        }
                    )
                }

                "Network Diagnostics" -> {
                    Text("Network Diagnostics & Telemetry", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    val net = currentSettings.network
                    SettingToggleRow(title = "Wi-Fi Network", subtitle = net.wifiSsid, trailingPill = "Signal: ${net.signalStrengthPercent}%")
                    SettingToggleRow(title = "IP Address", subtitle = net.ipAddress)
                    SettingToggleRow(title = "DNS Server", subtitle = net.dnsServer)
                    SettingToggleRow(title = "Speed Test Throughput", subtitle = "${net.measuredDownloadMbps} Mbps (4K HDR Verified)")
                    SettingToggleRow(title = "Ping Latency", subtitle = "${net.pingLatencyMs} ms")
                }

                "Remotes and Devices" -> {
                    Text("Remotes and Bluetooth Accessories", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggleRow(title = "Siri Remote Battery", subtitle = "96% Charged • Firmly Connected")
                    SettingToggleRow(title = "Clickpad Interaction", subtitle = "Touch and Click")
                    SettingToggleRow(title = "Game Controllers", subtitle = "PlayStation DualSense & Xbox Wireless Supported")
                }

                "AirPlay and HomeKit" -> {
                    Text("AirPlay and HomeKit", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggleRow(title = "AirPlay Receiver", subtitle = "Allows iPhone, iPad, and Mac to stream directly to this TV", trailingPill = "Active")
                    SettingToggleRow(title = "Room", subtitle = "Living Room")
                }

                "Accessibility" -> {
                    Text("Accessibility Suite", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    val acc = currentSettings.accessibility
                    SettingToggleRow(
                        title = "VoiceOver Screen Reader",
                        subtitle = "Audibly speaks items on the TV screen when focused",
                        isSwitch = true,
                        switchChecked = acc.voiceOverEnabled,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(accessibility = acc.copy(voiceOverEnabled = it)))
                        }
                    )

                    SettingToggleRow(
                        title = "Always Show Closed Captions (SDH)",
                        subtitle = "Display subtitles for the deaf and hard of hearing across all channels",
                        isSwitch = true,
                        switchChecked = acc.closedCaptionsAlwaysOn,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(accessibility = acc.copy(closedCaptionsAlwaysOn = it)))
                        }
                    )

                    SettingToggleRow(
                        title = "High Contrast Mode",
                        subtitle = "Increases color separation and card borders for enhanced focus visibility",
                        isSwitch = true,
                        switchChecked = acc.highContrast,
                        onCheckedChange = {
                            onUpdateSettings(currentSettings.copy(accessibility = acc.copy(highContrast = it)))
                        }
                    )
                }

                "System and About" -> {
                    Text("System Specifications", color = AppleTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggleRow(title = "Software Version", subtitle = currentSettings.osVersion)
                    SettingToggleRow(title = "Storage Capacity", subtitle = "128 GB NVMe Storage (112 GB Available)")
                    SettingToggleRow(title = "Hardware Model", subtitle = "Apple TV 4K (4th Generation / A16 Bionic Architecture)")
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    trailingPill: String? = null,
    isSwitch: Boolean = false,
    switchChecked: Boolean = false,
    onCheckedChange: (Boolean) -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }

        if (trailingPill != null) {
            FormatPill(label = trailingPill)
        } else if (isSwitch) {
            Switch(
                checked = switchChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = AppleAccentBlue,
                    uncheckedThumbColor = AppleTextSecondary,
                    uncheckedTrackColor = Color(0xFF2C2C3A)
                )
            )
        }
    }
    HorizontalDivider(color = Color(0xFF252532))
}
