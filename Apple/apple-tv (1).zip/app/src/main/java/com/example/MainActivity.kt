package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.service.*
import com.example.ui.components.*
import com.example.ui.focus.*
import com.example.ui.screens.*
import com.example.ui.theme.AppleDarkBackground
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var navigationState: TVNavigationState? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val persistence = remember { LocalPersistenceManager(context) }
                val recommendationEngine = remember { DeterministicContentRecommendationEngine() }
                val downloadManager = remember { StandardTVDownloadManager() }
                val analyticsService = remember { StandardTVAnalyticsService() }
                val navState = rememberTVNavigationState()
                navigationState = navState

                val scope = rememberCoroutineScope()
                val snackbarHostState = remember { SnackbarHostState() }

                val watchlistIds by persistence.watchlistIds.collectAsStateWithLifecycle()
                val activeProfile by persistence.activeProfile.collectAsStateWithLifecycle()
                val allProfiles by persistence.allProfiles.collectAsStateWithLifecycle()
                val systemSettings by persistence.systemSettings.collectAsStateWithLifecycle()
                val recentSearches by persistence.recentSearches.collectAsStateWithLifecycle()
                val installedAppIds by persistence.installedAppIds.collectAsStateWithLifecycle()
                val downloads by downloadManager.downloads.collectAsStateWithLifecycle()

                // Active playing content item
                var playingItem by remember { mutableStateOf<ContentItem?>(null) }

                // Recommendations calculation
                var recommendedItems by remember { mutableStateOf<List<ContentItem>>(emptyList()) }
                LaunchedEffect(activeProfile, watchlistIds) {
                    val recContext = RecommendationContext(
                        profile = activeProfile,
                        watchHistoryContentIds = watchlistIds.toList(),
                        completionRates = mapOf("film_last_horizon" to 0.42f),
                        preferredGenres = listOf("Sci-Fi", "Drama", "Mystery")
                    )
                    recommendedItems = recommendationEngine.getRecommendations(
                        allAvailable = DemoContentProvider.allContent,
                        context = recContext
                    )
                    analyticsService.logEvent(TechnicalEventType.STARTUP, mapOf("profile" to activeProfile.name))
                }

                // Continue watching list derived from persistence & demo provider
                val continueWatching = remember(watchlistIds) {
                    DemoContentProvider.allContent.filter { it.resumePositionSeconds > 0 }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .onKeyEvent { keyEvent ->
                            if (keyEvent.type == KeyEventType.KeyDown) {
                                when (keyEvent.nativeKeyEvent.keyCode) {
                                    KeyEvent.KEYCODE_DPAD_UP -> navState.handleRemoteAction(RemoteAction.UP)
                                    KeyEvent.KEYCODE_DPAD_DOWN -> navState.handleRemoteAction(RemoteAction.DOWN)
                                    KeyEvent.KEYCODE_DPAD_LEFT -> navState.handleRemoteAction(RemoteAction.LEFT)
                                    KeyEvent.KEYCODE_DPAD_RIGHT -> navState.handleRemoteAction(RemoteAction.RIGHT)
                                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> navState.handleRemoteAction(RemoteAction.SELECT)
                                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> navState.handleRemoteAction(RemoteAction.BACK)
                                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_SPACE -> navState.handleRemoteAction(RemoteAction.PLAY_PAUSE)
                                    else -> false
                                }
                            } else {
                                false
                            }
                        },
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = AppleDarkBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(AppleDarkBackground)
                    ) {
                        // Main Application View Hierarchy
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Apple TV Persistent Top Navigation Bar
                            TopNavigationBar(
                                currentDestination = navState.currentDestination,
                                onDestinationSelected = { dest ->
                                    navState.currentDestination = dest
                                    analyticsService.logEvent(
                                        TechnicalEventType.NAVIGATION_TRANSITION,
                                        mapOf("target" to dest.name)
                                    )
                                },
                                activeProfile = activeProfile,
                                onProfileClick = { navState.isProfileSwitchActive = true },
                                onSettingsClick = { navState.isSettingsActive = true },
                                onAirPlayClick = {
                                    scope.launch {
                                        snackbarHostState.showSnackbar("AirPlay Ready: Living Room Apple TV is visible to nearby devices")
                                    }
                                },
                                onRemoteToggleClick = { navState.isRemoteVisible = !navState.isRemoteVisible },
                                isRemoteOpen = navState.isRemoteVisible
                            )

                            // Main Destination Screen
                            Box(modifier = Modifier.weight(1f)) {
                                if (navState.isSettingsActive) {
                                    SettingsScreen(
                                        currentSettings = systemSettings,
                                        onUpdateSettings = { persistence.updateSettings(it) },
                                        onBack = { navState.isSettingsActive = false }
                                    )
                                } else {
                                    when (navState.currentDestination) {
                                        TVNavDestination.WATCH_NOW -> {
                                            WatchNowScreen(
                                                featuredItem = DemoContentProvider.theLastHorizon,
                                                continueWatchingItems = continueWatching,
                                                recommendedItems = recommendedItems,
                                                watchlistIds = watchlistIds,
                                                onPlayItem = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                    analyticsService.logEvent(
                                                        TechnicalEventType.PLAYBACK_START,
                                                        mapOf("contentId" to item.id, "title" to item.title)
                                                    )
                                                },
                                                onWatchlistToggle = { id ->
                                                    val added = persistence.toggleWatchlist(id)
                                                    scope.launch {
                                                        snackbarHostState.showSnackbar(if (added) "Added to Watchlist" else "Removed from Watchlist")
                                                    }
                                                },
                                                onItemDetails = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.MOVIES -> {
                                            MoviesScreen(
                                                onPlayItem = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                },
                                                watchlistIds = watchlistIds,
                                                onWatchlistToggle = { persistence.toggleWatchlist(it) },
                                                onItemDetails = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.TV_SHOWS -> {
                                            TVShowsScreen(
                                                onPlayItem = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                },
                                                watchlistIds = watchlistIds,
                                                onWatchlistToggle = { persistence.toggleWatchlist(it) },
                                                onItemDetails = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.LIVE -> {
                                            LiveTVScreen(
                                                onFullScreenLive = { channel ->
                                                    playingItem = DemoContentProvider.theLastHorizon.copy(
                                                        title = channel.name,
                                                        subtitle = "Live Television Feed",
                                                        heroArtworkRes = null
                                                    )
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.SPORTS -> {
                                            SportsScreen(
                                                onPlayFixture = { fixture ->
                                                    playingItem = DemoContentProvider.theLastHorizon.copy(
                                                        title = "${fixture.homeTeam} vs ${fixture.awayTeam}",
                                                        subtitle = "${fixture.league} • Live Match Broadcast",
                                                        heroArtworkRes = null
                                                    )
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.MUSIC -> {
                                            MusicScreen()
                                        }

                                        TVNavDestination.PODCASTS -> {
                                            PodcastsScreen(
                                                onPlayPodcast = { pod ->
                                                    playingItem = pod
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.APPS -> {
                                            AppsScreen(
                                                installedAppIds = installedAppIds,
                                                onToggleAppInstall = { appId ->
                                                    val installed = persistence.toggleAppInstalled(appId)
                                                    scope.launch {
                                                        snackbarHostState.showSnackbar(if (installed) "Application Installed" else "Application Uninstalled")
                                                    }
                                                }
                                            )
                                        }

                                        TVNavDestination.LIBRARY -> {
                                            LibraryScreen(
                                                watchlistIds = watchlistIds,
                                                downloads = downloads,
                                                onPlayItem = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.SEARCH -> {
                                            SearchScreen(
                                                recentSearches = recentSearches,
                                                onAddRecentSearch = { persistence.addRecentSearch(it) },
                                                onPlayItem = { item ->
                                                    playingItem = item
                                                    navState.isPlayerActive = true
                                                }
                                            )
                                        }

                                        TVNavDestination.SETTINGS -> {
                                            SettingsScreen(
                                                currentSettings = systemSettings,
                                                onUpdateSettings = { persistence.updateSettings(it) },
                                                onBack = { navState.currentDestination = TVNavDestination.WATCH_NOW }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Cinematic Video Player Overlay (Full Screen)
                        if (navState.isPlayerActive && playingItem != null) {
                            VideoPlayerOverlay(
                                item = playingItem!!,
                                initialPositionSeconds = playingItem!!.resumePositionSeconds,
                                onPositionUpdate = { newPos ->
                                    persistence.updateResumePosition(playingItem!!.id, newPos)
                                },
                                onClosePlayer = {
                                    navState.isPlayerActive = false
                                }
                            )
                        }

                        // Profile Switch Dialog
                        if (navState.isProfileSwitchActive) {
                            ProfileSwitchDialog(
                                allProfiles = allProfiles,
                                activeProfile = activeProfile,
                                onSelectProfile = { prof ->
                                    persistence.setActiveProfile(prof)
                                },
                                onDismiss = { navState.isProfileSwitchActive = false }
                            )
                        }

                        // Virtual Siri Remote Overlay (Top/Right floating HUD)
                        VirtualSiriRemoteOverlay(
                            isVisible = navState.isRemoteVisible,
                            onClose = { navState.isRemoteVisible = false },
                            onRemoteAction = { action ->
                                navState.handleRemoteAction(action)
                            },
                            onSiriClick = {
                                navState.currentDestination = TVNavDestination.SEARCH
                                scope.launch {
                                    snackbarHostState.showSnackbar("Siri Voice Search activated on TV")
                                }
                            },
                            modifier = Modifier.align(Alignment.CenterEnd)
                        )
                    }
                }
            }
        }
    }
}
