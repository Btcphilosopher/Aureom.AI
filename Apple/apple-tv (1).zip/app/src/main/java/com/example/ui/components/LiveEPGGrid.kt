package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LiveChannel
import com.example.model.LiveProgramme
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*

@Composable
fun LiveEPGGrid(
    channels: List<LiveChannel>,
    selectedChannel: LiveChannel?,
    onChannelSelect: (LiveChannel) -> Unit,
    onProgrammeSelect: (LiveChannel, LiveProgramme) -> Unit,
    onToggleFavorite: (LiveChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 36.dp, vertical = 12.dp)
    ) {
        // EPG Header Time Axis
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(180.dp)
                    .padding(end = 16.dp)
            ) {
                Text(
                    text = "CHANNELS",
                    color = AppleTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TimeSlotHeader("NOW (18:30)", isCurrent = true)
                TimeSlotHeader("19:00", isCurrent = false)
                TimeSlotHeader("20:00", isCurrent = false)
                TimeSlotHeader("21:00", isCurrent = false)
            }
        }

        // Channels & Guide Rows
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(channels, key = { it.id }) { channel ->
                val isSelected = channel.id == selectedChannel?.id

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(78.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) AppleSurfaceElevated else AppleCardBackground)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.5.dp,
                            color = if (isSelected) AppleAccentBlue else Color(0xFF2C2C38),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Channel Brand Badge
                    Row(
                        modifier = Modifier
                            .width(170.dp)
                            .clickable { onChannelSelect(channel) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Favorite star
                        Icon(
                            imageVector = if (channel.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (channel.isFavorite) AppleGold else AppleTextTertiary,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable { onToggleFavorite(channel) }
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Logo block
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF22222E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = channel.logoText,
                                color = AppleTextWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = channel.name,
                                color = AppleTextWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Ch ${channel.channelNumber}",
                                    color = AppleTextSecondary,
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                FormatPill(label = channel.resolution)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Programme Tiles in timeline
                    LazyRow(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(channel.schedule, key = { it.id }) { prog ->
                            ProgrammeTile(
                                programme = prog,
                                onClick = { onProgrammeSelect(channel, prog) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeSlotHeader(time: String, isCurrent: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (isCurrent) {
            Icon(
                imageVector = Icons.Default.FiberManualRecord,
                contentDescription = null,
                tint = AppleLiveRed,
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
            text = time,
            color = if (isCurrent) AppleLiveRed else AppleTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun ProgrammeTile(
    programme: LiveProgramme,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(220.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(if (programme.isLiveNow) Color(0xFF242634) else Color(0xFF191922))
            .border(
                0.5.dp,
                if (programme.isLiveNow) AppleLiveRed.copy(alpha = 0.5f) else Color(0xFF333342),
                RoundedCornerShape(8.dp)
            )
            .tvFocusable(
                isFocused = false,
                testTag = "programme_${programme.id}",
                shape = RoundedCornerShape(8.dp),
                focusScale = 1.04f,
                onClick = onClick
            )
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = programme.timeLabel,
                    color = AppleTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                if (programme.isLiveNow) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AppleLiveRed)
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "LIVE",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = programme.title,
                color = AppleTextWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (programme.isLiveNow) {
                LinearProgressIndicator(
                    progress = { 0.65f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp),
                    color = AppleLiveRed,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            } else {
                Text(
                    text = programme.category,
                    color = AppleTextTertiary,
                    fontSize = 9.sp
                )
            }
        }
    }
}
