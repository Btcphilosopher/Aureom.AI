package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Apple TV Obsidian & Silver Palette
val AppleDarkBackground = Color(0xFF08080A)
val AppleCharcoal = Color(0xFF121216)
val AppleSurface = Color(0xFF18181F)
val AppleSurfaceElevated = Color(0xFF22222B)
val AppleCardBackground = Color(0xFF1A1A22)
val AppleCardHover = Color(0xFF2C2C38)

val AppleAccentBlue = Color(0xFF0A84FF)
val AppleAccentBlueDark = Color(0xFF0066CC)
val AppleAccentCyan = Color(0xFF64D2FF)
val AppleAccentPurple = Color(0xFFBF5AF2)

val AppleTextWhite = Color(0xFFF5F5F7)
val AppleTextSecondary = Color(0xFFA1A1A6)
val AppleTextTertiary = Color(0xFF6E6E73)

val AppleFocusGlow = Color(0xFFFFFFFF)
val AppleFocusBorder = Color(0xFFE5E5EA)

val AppleLiveRed = Color(0xFFFF453A)
val AppleSuccessGreen = Color(0xFF30D158)
val AppleWarningYellow = Color(0xFFFFD60A)
val AppleGold = Color(0xFFFFD700)
val AppleHDRBadge = Color(0xFFE5A00D)
