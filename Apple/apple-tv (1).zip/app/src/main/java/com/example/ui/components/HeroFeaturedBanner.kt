package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentItem
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*

@Composable
fun HeroFeaturedBanner(
    featuredItem: ContentItem,
    isInWatchlist: Boolean,
    onPlayClick: () -> Unit,
    onWatchlistToggle: () -> Unit,
    onDetailsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(340.dp)
    ) {
        // Background Hero Image or Atmospheric Gradient
        if (featuredItem.heroArtworkRes != null) {
            Image(
                painter = painterResource(id = featuredItem.heroArtworkRes),
                contentDescription = featuredItem.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(featuredItem.posterColor))
            )
        }

        // Multi-stage cinematic gradient scrims (bottom fade to deep black, left fade for text legibility)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x6608080A),
                            AppleDarkBackground
                        ),
                        startY = 0f,
                        endY = Float.POSITIVE_INFINITY
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            AppleDarkBackground.copy(alpha = 0.92f),
                            AppleDarkBackground.copy(alpha = 0.60f),
                            Color.Transparent
                        ),
                        startX = 0f,
                        endX = 1400f
                    )
                )
        )

        // Hero Content Info & Controls
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 36.dp, bottom = 28.dp, end = 36.dp)
                .fillMaxWidth(0.70f)
        ) {
            // Provider & Year Badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = featuredItem.provider.uppercase(),
                    color = AppleAccentBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "•",
                    color = AppleTextTertiary,
                    fontSize = 12.sp
                )
                Text(
                    text = featuredItem.year.toString(),
                    color = AppleTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                FormatPill(label = featuredItem.videoFormat.label)
                FormatPill(label = featuredItem.audioFormat.label)
                FormatPill(label = featuredItem.maturityRating.label)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cinematic Title
            Text(
                text = featuredItem.title,
                color = AppleTextWhite,
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-1).sp,
                lineHeight = 42.sp
            )

            // Subtitle
            Text(
                text = featuredItem.subtitle,
                color = AppleTextSecondary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal,
                modifier = Modifier.padding(top = 2.dp)
            )

            // Synopsis
            Text(
                text = featuredItem.description,
                color = AppleTextWhite.copy(alpha = 0.85f),
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Action Buttons Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Play Now Button (Primary White Pill)
                Button(
                    onClick = onPlayClick,
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AppleTextWhite,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .height(44.dp)
                        .tvFocusable(
                            isFocused = true,
                            testTag = "hero_play_button",
                            shape = RoundedCornerShape(24.dp),
                            focusScale = 1.08f,
                            onClick = onPlayClick
                        ),
                    contentPadding = PaddingValues(horizontal = 22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (featuredItem.resumePositionSeconds > 0) "Resume" else "Play",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Add to Watchlist Button
                OutlinedButton(
                    onClick = onWatchlistToggle,
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AppleSurfaceElevated.copy(alpha = 0.7f),
                        contentColor = AppleTextWhite
                    ),
                    modifier = Modifier
                        .height(44.dp)
                        .tvFocusable(
                            isFocused = false,
                            testTag = "hero_watchlist_button",
                            shape = RoundedCornerShape(24.dp),
                            focusScale = 1.06f,
                            onClick = onWatchlistToggle
                        ),
                    contentPadding = PaddingValues(horizontal = 18.dp)
                ) {
                    Icon(
                        imageVector = if (isInWatchlist) Icons.Default.Check else Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = if (isInWatchlist) AppleSuccessGreen else AppleTextWhite
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isInWatchlist) "In Watchlist" else "Watchlist",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                // More Info
                OutlinedButton(
                    onClick = onDetailsClick,
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = AppleSurfaceElevated.copy(alpha = 0.7f),
                        contentColor = AppleTextWhite
                    ),
                    modifier = Modifier
                        .height(44.dp)
                        .tvFocusable(
                            isFocused = false,
                            testTag = "hero_details_button",
                            shape = RoundedCornerShape(24.dp),
                            focusScale = 1.06f,
                            onClick = onDetailsClick
                        ),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = AppleTextSecondary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Details",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun FormatPill(label: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF262630))
            .border(0.5.dp, Color(0xFF42424E), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = AppleTextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
