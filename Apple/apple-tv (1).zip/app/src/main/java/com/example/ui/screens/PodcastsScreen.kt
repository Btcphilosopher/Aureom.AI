package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.ui.components.ContentRail
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun PodcastsScreen(
    onPlayPodcast: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 36.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Apple Podcasts for TV",
                color = AppleTextWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            FormatPill(label = "Lossless Audio")
        }

        Spacer(modifier = Modifier.height(20.dp))

        ContentRail(
            title = "Subscribed Shows & New Episodes",
            items = DemoContentProvider.podcasts,
            onItemClick = onPlayPodcast
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Latest Episodes",
            color = AppleTextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(DemoContentProvider.podcasts, key = { it.id }) { pod ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(AppleCardBackground)
                        .border(1.dp, Color(0xFF2C2C3A), RoundedCornerShape(12.dp))
                        .clickable { onPlayPodcast(pod) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(pod.posterColor)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Podcasts, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(pod.title, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(pod.subtitle, color = AppleTextSecondary, fontSize = 12.sp)
                        Text(pod.description, color = AppleTextTertiary, fontSize = 11.sp, maxLines = 1)
                    }

                    FormatPill(label = "${pod.durationMinutes} min")
                }
            }
        }
    }
}
