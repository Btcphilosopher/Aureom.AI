package com.example.data

import com.example.R
import com.example.model.*

object DemoContentProvider {

    val theLastHorizon = ContentItem(
        id = "film_last_horizon",
        title = "The Last Horizon",
        subtitle = "A Deep Space Odyssey",
        description = "When Earth's final interstellar probe signals the discovery of an habitable ringed sanctuary beyond the Perseus Arm, Commander Elena Cross leads a desperate crew across uncharted wormholes into the quiet edge of the universe.",
        type = ContentMediaType.MOVIE,
        year = 2026,
        durationMinutes = 148,
        maturityRating = MaturityRating.PG13,
        videoFormat = VideoFormat.DOLBY_VISION,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Sci-Fi", "Drama", "Adventure"),
        cast = listOf("Elena Vance", "Marcus Kane", "Dr. Sofia Lind", "Harrison Wei"),
        directors = listOf("Christopher Nolan-Style / K. Aris"),
        ratingScore = 9.6,
        heroArtworkRes = R.drawable.img_hero_horizon_1791453640606,
        posterColor = 0xFF141F32,
        resumePositionSeconds = 2520, // 42 minutes watched
        isFeatured = true,
        provider = "Apple Original Films",
        chapters = listOf(
            ChapterMarker("Departure from Ganymede Station", 0),
            ChapterMarker("Crossing the Perseus Event", 1800),
            ChapterMarker("First Encounter with Signal Alpha", 3600),
            ChapterMarker("Descent to the Sanctuary Rings", 5400),
            ChapterMarker("The Final Choice", 7200)
        )
    )

    val theArchitect = ContentItem(
        id = "series_the_architect",
        title = "The Architect",
        subtitle = "Season 2 • Mind, Structure, Power",
        description = "In the glass towers of Zurich and Copenhagen, a visionary structural designer stumbles into a transnational infrastructure conspiracy disguised as sustainable mega-projects.",
        type = ContentMediaType.SERIES,
        year = 2025,
        durationMinutes = 55,
        maturityRating = MaturityRating.MA,
        videoFormat = VideoFormat.DOLBY_VISION,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Thriller", "Drama", "Architecture"),
        cast = listOf("Soren Meyer", "Astrid Dahl", "Viktor Sterling"),
        directors = listOf("Lars Van Berg"),
        ratingScore = 9.3,
        heroArtworkRes = R.drawable.img_hero_architect_1791453655018,
        posterColor = 0xFF2A201A,
        resumePositionSeconds = 1260, // 21 minutes in
        isFeatured = true,
        provider = "Apple Original Series",
        episodes = listOf(
            ContentEpisode("ep_arch_201", 2, 1, "The Blueprint", "Soren unveils the Alpine transit core as corporate espionage tightens.", 54),
            ContentEpisode("ep_arch_202", 2, 2, "Tension Joints", "Astrid traces unrecorded concrete pours in the Baltic tunnel.", 52),
            ContentEpisode("ep_arch_203", 2, 3, "Structural Failure", "A silent tremor rocks the northern consortium gala.", 58),
            ContentEpisode("ep_arch_204", 2, 4, "The Glass Vault", "Documents surface from a dead partner's Swiss safety deposit.", 51),
            ContentEpisode("ep_arch_205", 2, 5, "Cantilever", "A high-stakes confrontation suspended 300 meters above the fjord.", 60)
        )
    )

    val northernLights = ContentItem(
        id = "series_northern_lights",
        title = "Northern Lights",
        subtitle = "Season 1 • Arctic Mystery",
        description = "During 60 days of polar night in Tromsø, an enigmatic deep-sea research station goes dark, leaving investigator Freja Holm with only encrypted sonar logs to piece together what was found under the ice.",
        type = ContentMediaType.SERIES,
        year = 2026,
        durationMinutes = 50,
        maturityRating = MaturityRating.TV14,
        videoFormat = VideoFormat.UHD_4K,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Mystery", "Sci-Fi", "Nordic Noir"),
        cast = listOf("Freja Holm", "Jakob Lund", "Ingrid Solberg"),
        directors = listOf("Karin Lindqvist"),
        ratingScore = 9.1,
        posterColor = 0xFF0D2533,
        resumePositionSeconds = 1800,
        isFeatured = true,
        episodes = listOf(
            ContentEpisode("ep_nl_101", 1, 1, "Polar Midnight", "Sonar signals from the shelf trigger an immediate quarantine.", 50),
            ContentEpisode("ep_nl_102", 1, 2, "Beneath the Permafrost", "Freja travels to outpost B-7 through an intensifying blizzard.", 48),
            ContentEpisode("ep_nl_103", 1, 3, "Resonance", "The crew discovers the acoustic signal isn't artificial.", 53)
        )
    )

    val orbital = ContentItem(
        id = "film_orbital",
        title = "ORBITAL",
        subtitle = "The 90-Minute Window",
        description = "A crew of four aboard the international Gateway station must execute an emergency de-orbit burn when catastrophic debris threatens planetary telemetry communication networks.",
        type = ContentMediaType.MOVIE,
        year = 2025,
        durationMinutes = 112,
        maturityRating = MaturityRating.PG13,
        videoFormat = VideoFormat.DOLBY_VISION,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Sci-Fi", "Suspense", "Action"),
        cast = listOf("Dr. Thomas Ward", "Naomi Sato", "Col. Alexei Morozov"),
        directors = listOf("Denis Mirren"),
        ratingScore = 9.2,
        posterColor = 0xFF1E1428,
        resumePositionSeconds = 0,
        isFeatured = false
    )

    val theLongWinter = ContentItem(
        id = "series_the_long_winter",
        title = "The Long Winter",
        subtitle = "Season 3 • Survival & Sovereignty",
        description = "In the harsh mountain passes of the Pacific Northwest, isolated communities forge resilient new governance after global supply lines freeze over.",
        type = ContentMediaType.SERIES,
        year = 2024,
        durationMinutes = 62,
        maturityRating = MaturityRating.MA,
        videoFormat = VideoFormat.UHD_4K,
        audioFormat = AudioFormat.SURROUND_5_1,
        genres = listOf("Drama", "Post-Apocalyptic", "Thriller"),
        cast = listOf("Ethan Ross", "Chloe Bennett", "Gideon Vance"),
        directors = listOf("Sarah Polley"),
        ratingScore = 8.9,
        posterColor = 0xFF28282D,
        resumePositionSeconds = 3100,
        isFeatured = false
    )

    val afterMidnight = ContentItem(
        id = "film_after_midnight",
        title = "After Midnight",
        subtitle = "Tokyo Neon Noir",
        description = "A seasoned audio restoration engineer is hired to clean audio from a missing jazz club owner's cassette tapes, discovering evidence of an extortion ring operating in Shinjuku.",
        type = ContentMediaType.MOVIE,
        year = 2026,
        durationMinutes = 124,
        maturityRating = MaturityRating.MA,
        videoFormat = VideoFormat.DOLBY_VISION,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Neo-Noir", "Crime", "Mystery"),
        cast = listOf("Ken Watanabe-Style", "Rinko Kikuchi", "Liam Evans"),
        directors = listOf("Takashi Morimoto"),
        ratingScore = 9.5,
        posterColor = 0xFF351224,
        resumePositionSeconds = 0,
        isFeatured = true
    )

    val atlantic = ContentItem(
        id = "series_atlantic",
        title = "Atlantic",
        subtitle = "Documentary Series • In 8K HDR",
        description = "Narrated by world-renowned marine biologists, explore the oceanic currents, abyssal trenches, and majestic migrations that regulate our planet's living atmosphere.",
        type = ContentMediaType.SERIES,
        year = 2026,
        durationMinutes = 60,
        maturityRating = MaturityRating.G,
        videoFormat = VideoFormat.UHD_8K,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Documentary", "Nature", "Science"),
        cast = listOf("Dr. Sylvia Thorne", "Sir David Attenborough Voice"),
        directors = listOf("James Cameron-Style Production"),
        ratingScore = 9.8,
        posterColor = 0xFF00223A,
        resumePositionSeconds = 1400,
        isFeatured = false
    )

    val theSeventhCity = ContentItem(
        id = "film_the_seventh_city",
        title = "The Seventh City",
        subtitle = "Lost Civilizations of the Sahara",
        description = "Archaeologists utilizing high-resolution LiDAR beneath Mauritanian sand dunes discover an underground metropolitan complex that pre-dates conventional historical records by six millennia.",
        type = ContentMediaType.MOVIE,
        year = 2025,
        durationMinutes = 138,
        maturityRating = MaturityRating.PG,
        videoFormat = VideoFormat.DOLBY_VISION,
        audioFormat = AudioFormat.DOLBY_ATMOS,
        genres = listOf("Adventure", "History", "Mystery"),
        cast = listOf("Gabriel Silva", "Amina Traoré", "Prof. Ian Campbell"),
        directors = listOf("Guillermo Del Toro-Style"),
        ratingScore = 9.0,
        posterColor = 0xFF2F2414,
        resumePositionSeconds = 0,
        isFeatured = false
    )

    val allContent = listOf(
        theLastHorizon,
        theArchitect,
        northernLights,
        afterMidnight,
        orbital,
        theLongWinter,
        atlantic,
        theSeventhCity
    )

    val liveChannels = listOf(
        LiveChannel(
            id = "ch_bbc_one",
            channelNumber = 101,
            name = "BBC One HD",
            logoText = "BBC 1",
            category = "General / News",
            isFavorite = true,
            schedule = listOf(
                LiveProgramme("prog_bbc_1", "ch_bbc_one", "BBC News at Ten", "National & international news report with live studio analysis.", 18, 0, 19, 0, "News", true),
                LiveProgramme("prog_bbc_2", "ch_bbc_one", "Horizon: Deep Biosphere", "Documentary exploring microbial life miles beneath the ocean crust.", 19, 0, 20, 0, "Science"),
                LiveProgramme("prog_bbc_3", "ch_bbc_one", "Prime Time Drama: The Investigator", "Detective crime series set in rural Yorkshire.", 20, 0, 21, 30, "Drama")
            )
        ),
        LiveChannel(
            id = "ch_sky_sports",
            channelNumber = 201,
            name = "Sky Sports Main Event 4K",
            logoText = "SKY 4K",
            category = "Sports",
            isFavorite = true,
            schedule = listOf(
                LiveProgramme("prog_sky_1", "ch_sky_sports", "Premier League: Arsenal vs Manchester City", "Live coverage from the Emirates Stadium with tactical camera.", 18, 0, 20, 15, "Sports", true),
                LiveProgramme("prog_sky_2", "ch_sky_sports", "Saturday Night Football Post-Match", "In-depth pundit analysis, player interviews, and table impact.", 20, 15, 21, 0, "Sports"),
                LiveProgramme("prog_sky_3", "ch_sky_sports", "Formula Horizon: Qualifying Highlights", "Recap of the pole position shootout in Silverstone.", 21, 0, 22, 0, "Motorsport")
            )
        ),
        LiveChannel(
            id = "ch_horizon_cinema",
            channelNumber = 301,
            name = "Cinema Premiere 4K HDR",
            logoText = "CINEMA",
            category = "Movies",
            isFavorite = true,
            schedule = listOf(
                LiveProgramme("prog_cin_1", "ch_horizon_cinema", "The Last Horizon (Premiere Broadcast)", "Commercial-free 4K Dolby Atmos world television broadcast.", 18, 30, 21, 0, "Cinema", true),
                LiveProgramme("prog_cin_2", "ch_horizon_cinema", "Inception (Remastered)", "Dom Cobb leads a mental heist through nested dream architectures.", 21, 0, 23, 30, "Sci-Fi")
            )
        ),
        LiveChannel(
            id = "ch_earth_nature",
            channelNumber = 401,
            name = "Nature & Planet 8K",
            logoText = "PLANET",
            category = "Documentary",
            isFavorite = false,
            schedule = listOf(
                LiveProgramme("prog_nat_1", "ch_earth_nature", "Patagonia Wild: The Ice Giants", "Glacial landscapes and puma tracking in Torres del Paine.", 18, 0, 19, 30, "Nature", true),
                LiveProgramme("prog_nat_2", "ch_earth_nature", "Coral Kingdoms: Great Barrier Reef", "Night diving under bioluminescent full moon tides.", 19, 30, 21, 0, "Nature")
            )
        ),
        LiveChannel(
            id = "ch_bloomberg_news",
            channelNumber = 501,
            name = "Bloomberg Global TV",
            logoText = "BLOOMBERG",
            category = "Finance & Tech",
            isFavorite = false,
            schedule = listOf(
                LiveProgramme("prog_fin_1", "ch_bloomberg_news", "Markets Close & Technology Review", "Global index summaries, Silicon Valley semiconductor updates.", 18, 0, 19, 0, "Business", true),
                LiveProgramme("prog_fin_2", "ch_bloomberg_news", "AI Frontier: Autonomous Systems", "Interviews with leading roboticists and infrastructure heads.", 19, 0, 20, 0, "Tech")
            )
        )
    )

    val sportsFixtures = listOf(
        SportsFixture(
            id = "sport_pl_1",
            league = "Premier League",
            homeTeam = "Arsenal",
            awayTeam = "Manchester City",
            homeScore = 2,
            awayScore = 1,
            status = "LIVE 76'",
            isLive = true,
            arena = "Emirates Stadium, London",
            broadcast = "Apple TV+ / Sky 4K"
        ),
        SportsFixture(
            id = "sport_mls_1",
            league = "MLS Season Pass",
            homeTeam = "Inter Miami CF",
            awayTeam = "LA Galaxy",
            homeScore = 3,
            awayScore = 2,
            status = "LIVE 88'",
            isLive = true,
            arena = "Chase Stadium, Fort Lauderdale",
            broadcast = "MLS Season Pass 4K"
        ),
        SportsFixture(
            id = "sport_cl_1",
            league = "UEFA Champions League",
            homeTeam = "Real Madrid",
            awayTeam = "Bayern Munich",
            homeScore = null,
            awayScore = null,
            status = "TODAY 20:00",
            isLive = false,
            arena = "Santiago Bernabéu",
            broadcast = "Apple TV Live Hub"
        ),
        SportsFixture(
            id = "sport_f1_1",
            league = "Formula Horizon GP",
            homeTeam = "Silverstone Circuit",
            awayTeam = "Pole Position Shootout",
            homeScore = null,
            awayScore = null,
            status = "TOMORROW 14:00",
            isLive = false,
            arena = "Silverstone, UK",
            broadcast = "Live Onboard Telemetry"
        )
    )

    val musicAlbums = listOf(
        MusicTrack("tr_1", "Perseus Core (Original Score)", "Hans Zimmer & Max Richter", "The Last Horizon Soundtrack", 345, true),
        MusicTrack("tr_2", "Midnight Shinjuku", "Tokyo Jazz Collective", "After Midnight Sessions", 298, true),
        MusicTrack("tr_3", "Cantilever Dreams", "Olafur Arnalds", "The Architect OST", 260, true),
        MusicTrack("tr_4", "Abyssal Current", "Brian Eno", "Atlantic Ocean Ambient", 480, true),
        MusicTrack("tr_5", "Neon Highway", "Kavinsky", "Nightcall Redux", 254, true)
    )

    val podcasts = listOf(
        ContentItem(
            id = "pod_director_cut",
            title = "The Director's Room",
            subtitle = "Episode 48 • Making The Last Horizon",
            description = "Behind the scenes on building practical space interiors, shooting 70mm anamorphic, and recording live orchestra in Vienna.",
            type = ContentMediaType.PODCAST,
            year = 2026,
            durationMinutes = 68,
            genres = listOf("Film", "Interviews", "Tech"),
            ratingScore = 9.7,
            provider = "Apple Podcasts",
            posterColor = 0xFF3F1D38
        ),
        ContentItem(
            id = "pod_tech_daily",
            title = "Silicon Horizon",
            subtitle = "Episode 112 • Next-Gen MicroLED & Spatial Displays",
            description = "Exploring living-room television hardware innovations, 8K optical networks, and the future of home cinema.",
            type = ContentMediaType.PODCAST,
            year = 2026,
            durationMinutes = 44,
            genres = listOf("Technology", "News"),
            ratingScore = 9.4,
            provider = "Apple Podcasts",
            posterColor = 0xFF192C4B
        )
    )

    val appStoreApps = listOf(
        AppCatalogItem(
            id = "app_fitness",
            name = "Apple Fitness+",
            developer = "Apple",
            category = "Health & Fitness",
            rating = 4.9,
            sizeMb = 142,
            description = "Studio-style workouts with your Apple Watch metrics on the big television screen.",
            isInstalled = true
        ),
        AppCatalogItem(
            id = "app_arcade",
            name = "Apple Arcade",
            developer = "Apple",
            category = "Games",
            rating = 4.8,
            sizeMb = 210,
            description = "Unlimited access to 200+ premium games with controller support and zero ads.",
            isInstalled = true
        ),
        AppCatalogItem(
            id = "app_photos",
            name = "Photos & Memories",
            developer = "Apple",
            category = "Photography",
            rating = 4.9,
            sizeMb = 85,
            description = "View your iCloud Shared Photo Library and cinematic 4K curated Memories on your TV.",
            isInstalled = true
        ),
        AppCatalogItem(
            id = "app_ocean_diver",
            name = "Subsea Explorer 4K",
            developer = "Horizon Interactive",
            category = "Games",
            rating = 4.7,
            sizeMb = 840,
            description = "A breathtaking atmospheric deep ocean exploration game built for Siri Remote & gamepads.",
            isInstalled = false
        ),
        AppCatalogItem(
            id = "app_sky_guide",
            name = "Starlight Stargazing TV",
            developer = "Cosmic Soft",
            category = "Education",
            rating = 4.9,
            sizeMb = 195,
            description = "Turn your living room ceiling into an interactive planetarium map of 100,000 charted stars.",
            isInstalled = false
        )
    )
}
