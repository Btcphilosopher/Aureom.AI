package com.example.ui.focus

import android.view.KeyEvent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AppleFocusBorder
import com.example.ui.theme.AppleFocusGlow

enum class TVNavDestination(val label: String, val iconName: String) {
    WATCH_NOW("Watch Now", "play_arrow"),
    MOVIES("Movies", "movie"),
    TV_SHOWS("TV Shows", "tv"),
    LIVE("Live", "live_tv"),
    SPORTS("Sports", "sports_soccer"),
    MUSIC("Music", "music_note"),
    PODCASTS("Podcasts", "podcasts"),
    APPS("Apps", "apps"),
    LIBRARY("Library", "video_library"),
    SEARCH("Search", "search"),
    SETTINGS("Settings", "settings")
}

data class FocusMemoryEntry(
    val destination: TVNavDestination,
    val selectedItemIndex: Int,
    val selectedRailIndex: Int
)

class TVNavigationState {
    var currentDestination by mutableStateOf(TVNavDestination.WATCH_NOW)
    var isPlayerActive by mutableStateOf(false)
    var isSettingsActive by mutableStateOf(false)
    var isProfileSwitchActive by mutableStateOf(false)
    var isVoiceSearchActive by mutableStateOf(false)
    var isRemoteVisible by mutableStateOf(false)

    // Focus memory stack for restoration
    private val memoryStack = mutableListOf<FocusMemoryEntry>()

    var activeRailIndex by mutableIntStateOf(0)
    var activeItemIndex by mutableIntStateOf(0)

    fun pushFocusState() {
        memoryStack.add(
            FocusMemoryEntry(
                destination = currentDestination,
                selectedItemIndex = activeItemIndex,
                selectedRailIndex = activeRailIndex
            )
        )
    }

    fun popAndRestoreFocus() {
        if (memoryStack.isNotEmpty()) {
            val last = memoryStack.removeAt(memoryStack.size - 1)
            currentDestination = last.destination
            activeItemIndex = last.selectedItemIndex
            activeRailIndex = last.selectedRailIndex
        }
    }

    fun handleRemoteAction(action: RemoteAction): Boolean {
        return when (action) {
            RemoteAction.UP -> {
                if (activeRailIndex > 0) activeRailIndex--
                true
            }
            RemoteAction.DOWN -> {
                activeRailIndex++
                true
            }
            RemoteAction.LEFT -> {
                if (activeItemIndex > 0) activeItemIndex--
                true
            }
            RemoteAction.RIGHT -> {
                activeItemIndex++
                true
            }
            RemoteAction.BACK -> {
                if (isPlayerActive) {
                    isPlayerActive = false
                    popAndRestoreFocus()
                    true
                } else if (isSettingsActive) {
                    isSettingsActive = false
                    true
                } else if (isProfileSwitchActive) {
                    isProfileSwitchActive = false
                    true
                } else if (isVoiceSearchActive) {
                    isVoiceSearchActive = false
                    true
                } else if (currentDestination != TVNavDestination.WATCH_NOW) {
                    currentDestination = TVNavDestination.WATCH_NOW
                    true
                } else {
                    false
                }
            }
            RemoteAction.SELECT -> true
            RemoteAction.PLAY_PAUSE -> {
                // Global play/pause toggle
                true
            }
            RemoteAction.HOME -> {
                currentDestination = TVNavDestination.WATCH_NOW
                isPlayerActive = false
                isSettingsActive = false
                isProfileSwitchActive = false
                true
            }
        }
    }
}

enum class RemoteAction {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    SELECT,
    BACK,
    PLAY_PAUSE,
    HOME
}

@Composable
fun rememberTVNavigationState(): TVNavigationState {
    return remember { TVNavigationState() }
}

@Composable
fun Modifier.tvFocusable(
    isFocused: Boolean,
    testTag: String,
    shape: Shape = RoundedCornerShape(12.dp),
    focusScale: Float = 1.05f,
    elevation: Dp = if (isFocused) 16.dp else 0.dp,
    borderWidth: Dp = if (isFocused) 3.dp else 0.dp,
    borderColor: Color = AppleFocusBorder,
    onClick: () -> Unit
): Modifier {
    val scaleAnim by animateFloatAsState(
        targetValue = if (isFocused) focusScale else 1.0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "tv_focus_scale"
    )

    return this
        .testTag(testTag)
        .scale(scaleAnim)
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = AppleFocusGlow,
            spotColor = AppleFocusGlow
        )
        .then(
            if (isFocused) {
                Modifier.border(borderWidth, borderColor, shape)
            } else {
                Modifier
            }
        )
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(color = Color.White.copy(alpha = 0.2f)),
            onClick = onClick
        )
}
