package com.example.model

enum class ProductType {
    AUTO_RENEWABLE_SUBSCRIPTION,
    NON_CONSUMABLE_MOVIE_PURCHASE,
    RENTAL_48_HOURS,
    SEASON_PASS
}

data class StoreProduct(
    val id: String,
    val displayName: String,
    val description: String,
    val type: ProductType,
    val priceFormatted: String,
    val priceNumeric: Double,
    val period: String? = null // e.g. "month", "year"
)

data class StoreEntitlement(
    val productId: String,
    val grantedDate: Long = System.currentTimeMillis(),
    val expirationDate: Long? = null,
    val isActive: Boolean = true
)

data class StoreTransaction(
    val transactionId: String,
    val originalTransactionId: String,
    val productId: String,
    val purchaseDate: Long = System.currentTimeMillis(),
    val revocationDate: Long? = null,
    val isVerified: Boolean = true
)

val DemoStoreProducts = listOf(
    StoreProduct(
        id = "sub_appletv_plus",
        displayName = "Apple TV+",
        description = "Award-winning Apple Originals, 4K HDR, Dolby Atmos, ad-free streaming.",
        type = ProductType.AUTO_RENEWABLE_SUBSCRIPTION,
        priceFormatted = "$9.99/mo",
        priceNumeric = 9.99,
        period = "month"
    ),
    StoreProduct(
        id = "sub_mls_season_pass",
        displayName = "MLS Season Pass",
        description = "Every Major League Soccer live match, playoffs, and Leagues Cup in 1080p 60fps.",
        type = ProductType.AUTO_RENEWABLE_SUBSCRIPTION,
        priceFormatted = "$14.99/mo",
        priceNumeric = 14.99,
        period = "month"
    ),
    StoreProduct(
        id = "pass_cinema_bundle",
        displayName = "Horizon Cinematic Universe 4K",
        description = "Complete 4-Film Bundle in Dolby Vision with Director's Commentary.",
        type = ProductType.NON_CONSUMABLE_MOVIE_PURCHASE,
        priceFormatted = "$29.99",
        priceNumeric = 29.99
    ),
    StoreProduct(
        id = "rent_last_horizon",
        displayName = "The Last Horizon (4K Rental)",
        description = "48-hour viewing window once started. 4K UHD with Spatial Audio.",
        type = ProductType.RENTAL_48_HOURS,
        priceFormatted = "$5.99",
        priceNumeric = 5.99
    )
)
