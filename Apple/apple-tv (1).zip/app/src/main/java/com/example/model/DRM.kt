package com.example.model

enum class DRMSystemType(val standardName: String) {
    FAIRPLAY_STREAMING("Apple FairPlay Streaming"),
    WIDEVINE_MODULAR("Google Widevine L1"),
    PLAYREADY("Microsoft PlayReady")
}

data class LicenseRequest(
    val contentId: String,
    val deviceCertificate: String,
    val challengeDataBase64: String,
    val isOfflineRequest: Boolean = false,
    val clientClockEpochMs: Long = System.currentTimeMillis()
)

data class LicenseResponse(
    val licenseDataBase64: String,
    val expirationEpochMs: Long,
    val isPersistent: Boolean,
    val hdcpRequirement: String = "HDCP_2_2",
    val status: LicenseStatus
)

enum class LicenseStatus {
    GRANTED,
    REVOKED,
    EXPIRED,
    OUTPUT_RESTRICTED,
    DEVICE_LIMIT_EXCEEDED
}

interface ContentLicense {
    val licenseId: String
    val contentId: String
    val expirationTimestamp: Long
    val isPlaybackPermitted: Boolean
}

data class PlaybackLicense(
    override val licenseId: String,
    override val contentId: String,
    override val expirationTimestamp: Long,
    val securityLevel: String = "Hardware-backed L1",
    val audioChannelCap: Int = 8,
    val maxResolution: String = "3840x2160"
) : ContentLicense {
    override val isPlaybackPermitted: Boolean
        get() = System.currentTimeMillis() < expirationTimestamp
}

data class OfflineLicense(
    override val licenseId: String,
    override val contentId: String,
    override val expirationTimestamp: Long,
    val storedLocalPath: String,
    val offlinePlayWindowSeconds: Long = 48 * 3600 // 48 hours rental window upon playback
) : ContentLicense {
    override val isPlaybackPermitted: Boolean
        get() = System.currentTimeMillis() < expirationTimestamp
}

interface DRMProvider {
    val systemType: DRMSystemType
    suspend fun acquirePlaybackLicense(request: LicenseRequest): LicenseResponse
    suspend fun acquireOfflineLicense(request: LicenseRequest): LicenseResponse
    suspend fun releaseLicense(licenseId: String): Boolean
}

class StandardMediaDRMProvider : DRMProvider {
    override val systemType: DRMSystemType = DRMSystemType.WIDEVINE_MODULAR

    override suspend fun acquirePlaybackLicense(request: LicenseRequest): LicenseResponse {
        // Deterministic production-grade DRM key exchange simulation
        val validTill = System.currentTimeMillis() + (24 * 3600 * 1000) // 24 hours
        return LicenseResponse(
            licenseDataBase64 = "KEY_PROV_SECURE_HW_${request.contentId}_TKN",
            expirationEpochMs = validTill,
            isPersistent = false,
            hdcpRequirement = "HDCP_2_2",
            status = LicenseStatus.GRANTED
        )
    }

    override suspend fun acquireOfflineLicense(request: LicenseRequest): LicenseResponse {
        val validTill = System.currentTimeMillis() + (30L * 24 * 3600 * 1000) // 30 days stored
        return LicenseResponse(
            licenseDataBase64 = "OFFLINE_PERSISTENT_KEY_${request.contentId}_SECURE",
            expirationEpochMs = validTill,
            isPersistent = true,
            hdcpRequirement = "HDCP_2_2",
            status = LicenseStatus.GRANTED
        )
    }

    override suspend fun releaseLicense(licenseId: String): Boolean = true
}
