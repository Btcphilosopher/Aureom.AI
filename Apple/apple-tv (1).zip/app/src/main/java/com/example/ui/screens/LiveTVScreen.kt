package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.LiveChannel
import com.example.model.LiveProgramme
import com.example.ui.components.FormatPill
import com.example.ui.components.LiveEPGGrid
import com.example.ui.theme.*

@Composable
fun LiveTVScreen(
    onFullScreenLive: (LiveChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    var channels by remember { mutableStateOf(DemoContentProvider.liveChannels) }
    var selectedChannel by remember { mutableStateOf(channels.first()) }
    val currentProg = selectedChannel.schedule.firstOrNull { it.isLiveNow } ?: selectedChannel.schedule.first()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Live Broadcast Hero Player Preview
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF1E1428), Color(0xFF0F0B18), AppleDarkBackground)
                    )
                )
                .padding(horizontal = 36.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Info Column
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AppleLiveRed)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FiberManualRecord, null, tint = Color.White, modifier = Modifier.size(8.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("LIVE ON TV", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${selectedChannel.name} • Ch ${selectedChannel.channelNumber}",
                            color = AppleTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FormatPill(label = selectedChannel.resolution)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = currentProg.title,
                        color = AppleTextWhite,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )

                    Text(
                        text = currentProg.description,
                        color = AppleTextWhite.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { onFullScreenLive(selectedChannel) },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleTextWhite),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("live_fullscreen_button")
                        ) {
                            Icon(Icons.Default.Fullscreen, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Full Screen", color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { /* Audio Toggle */ },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleSurfaceElevated),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Icon(Icons.Default.VolumeUp, null, tint = AppleTextWhite, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stereo Audio", color = AppleTextWhite, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.width(32.dp))

                // Simulated Live Video Monitor Box
                Box(
                    modifier = Modifier
                        .size(width = 300.dp, height = 180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF14141E))
                        .border(1.dp, Color(0xFF383848), RoundedCornerShape(12.dp))
                        .clickable { onFullScreenLive(selectedChannel) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(AppleLiveRed.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FiberManualRecord, null, tint = AppleLiveRed, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "LIVE BROADCAST",
                            color = AppleTextWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Click for Fullscreen Mode",
                            color = AppleTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Electronic Programme Guide (EPG)
        LiveEPGGrid(
            channels = channels,
            selectedChannel = selectedChannel,
            onChannelSelect = { selectedChannel = it },
            onProgrammeSelect = { channel, _ ->
                selectedChannel = channel
                onFullScreenLive(channel)
            },
            onToggleFavorite = { favChannel ->
                channels = channels.map {
                    if (it.id == favChannel.id) it.copy(isFavorite = !it.isFavorite) else it
                }
            }
        )

        Spacer(modifier = Modifier.height(60.dp))
    }
}
