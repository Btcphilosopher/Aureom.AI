package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.ui.components.ContentRail
import com.example.ui.components.HeroFeaturedBanner

@Composable
fun WatchNowScreen(
    featuredItem: ContentItem,
    continueWatchingItems: List<ContentItem>,
    recommendedItems: List<ContentItem>,
    watchlistIds: Set<String>,
    onPlayItem: (ContentItem) -> Unit,
    onWatchlistToggle: (String) -> Unit,
    onItemDetails: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Hero Featured Carousel
        HeroFeaturedBanner(
            featuredItem = featuredItem,
            isInWatchlist = watchlistIds.contains(featuredItem.id),
            onPlayClick = { onPlayItem(featuredItem) },
            onWatchlistToggle = { onWatchlistToggle(featuredItem.id) },
            onDetailsClick = { onItemDetails(featuredItem) }
        )

        // Continue Watching Rail
        if (continueWatchingItems.isNotEmpty()) {
            ContentRail(
                title = "Continue Watching",
                items = continueWatchingItems,
                isContinueWatching = true,
                onItemClick = onPlayItem
            )
        }

        // Recommended For You
        ContentRail(
            title = "Recommended For You",
            items = recommendedItems,
            onItemClick = onPlayItem
        )

        // Top Movies
        ContentRail(
            title = "Top Movies in 4K Dolby Vision",
            items = DemoContentProvider.allContent.filter { it.type == com.example.model.ContentMediaType.MOVIE },
            onItemClick = onPlayItem
        )

        // Popular Series
        ContentRail(
            title = "Popular TV Series",
            items = DemoContentProvider.allContent.filter { it.type == com.example.model.ContentMediaType.SERIES },
            onItemClick = onPlayItem
        )

        Spacer(modifier = Modifier.height(60.dp))
    }
}
