package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.model.ContentMediaType
import com.example.ui.components.ContentRail
import com.example.ui.components.HeroFeaturedBanner
import com.example.ui.theme.*

@Composable
fun MoviesScreen(
    onPlayItem: (ContentItem) -> Unit,
    watchlistIds: Set<String>,
    onWatchlistToggle: (String) -> Unit,
    onItemDetails: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val genres = listOf("All", "Sci-Fi", "Drama", "Mystery", "Adventure", "Neo-Noir")
    var selectedGenre by remember { mutableStateOf("All") }

    val allMovies = remember {
        DemoContentProvider.allContent.filter { it.type == ContentMediaType.MOVIE }
    }

    val filteredMovies = remember(selectedGenre) {
        if (selectedGenre == "All") allMovies
        else allMovies.filter { it.genres.contains(selectedGenre) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Hero
        HeroFeaturedBanner(
            featuredItem = DemoContentProvider.theLastHorizon,
            isInWatchlist = watchlistIds.contains(DemoContentProvider.theLastHorizon.id),
            onPlayClick = { onPlayItem(DemoContentProvider.theLastHorizon) },
            onWatchlistToggle = { onWatchlistToggle(DemoContentProvider.theLastHorizon.id) },
            onDetailsClick = { onItemDetails(DemoContentProvider.theLastHorizon) }
        )

        // Genre Filter Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 36.dp, vertical = 14.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            genres.forEach { genre ->
                val isSelected = genre == selectedGenre
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) AppleTextWhite else AppleSurfaceElevated)
                        .border(1.dp, if (isSelected) AppleTextWhite else Color(0xFF323240), RoundedCornerShape(20.dp))
                        .clickable { selectedGenre = genre }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("genre_filter_$genre")
                ) {
                    Text(
                        text = genre,
                        color = if (isSelected) Color.Black else AppleTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // Filtered Movies Rail
        ContentRail(
            title = if (selectedGenre == "All") "Featured Films in 4K HDR" else "$selectedGenre Movies",
            items = filteredMovies,
            onItemClick = onPlayItem
        )

        // Additional rails
        ContentRail(
            title = "Critically Acclaimed Cinema",
            items = allMovies.sortedByDescending { it.ratingScore },
            onItemClick = onPlayItem
        )

        ContentRail(
            title = "Deep Space & Future Visions",
            items = allMovies.filter { it.genres.contains("Sci-Fi") || it.genres.contains("Mystery") },
            onItemClick = onPlayItem
        )

        Spacer(modifier = Modifier.height(60.dp))
    }
}
