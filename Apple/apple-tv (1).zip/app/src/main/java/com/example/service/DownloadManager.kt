package com.example.service

import com.example.model.ContentItem
import com.example.model.OfflineLicense
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    LICENSE_EXPIRED
}

data class DownloadTask(
    val contentId: String,
    val title: String,
    val sizeBytes: Long = 4_294_967_296L, // ~4.3 GB for 4K Dolby Vision stream
    val downloadedBytes: Long = 0L,
    val progress: Float = 0f,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val offlineLicense: OfflineLicense? = null,
    val localFilePath: String? = null
) {
    val sizeFormatted: String
        get() = "%.1f GB".format(sizeBytes / (1024.0 * 1024.0 * 1024.0))
}

interface DownloadManager {
    val downloads: StateFlow<List<DownloadTask>>
    suspend fun queueDownload(item: ContentItem)
    suspend fun pauseDownload(contentId: String)
    suspend fun resumeDownload(contentId: String)
    suspend fun cancelDownload(contentId: String)
    suspend fun deleteDownload(contentId: String)
    fun getTotalStorageUsedBytes(): Long
}

class StandardTVDownloadManager : DownloadManager {

    private val _downloads = MutableStateFlow<List<DownloadTask>>(
        listOf(
            DownloadTask(
                contentId = "film_last_horizon",
                title = "The Last Horizon",
                sizeBytes = 5_368_709_120L,
                downloadedBytes = 5_368_709_120L,
                progress = 1.0f,
                status = DownloadStatus.COMPLETED,
                localFilePath = "/data/secure_media/film_last_horizon_4k.mp4",
                offlineLicense = OfflineLicense(
                    licenseId = "LIC_OFFLINE_001",
                    contentId = "film_last_horizon",
                    expirationTimestamp = System.currentTimeMillis() + (30L * 24 * 3600 * 1000),
                    storedLocalPath = "/data/drm_vault/lic_001.key"
                )
            ),
            DownloadTask(
                contentId = "series_the_architect",
                title = "The Architect (S2:E1 The Blueprint)",
                sizeBytes = 1_825_361_100L,
                downloadedBytes = 1_825_361_100L,
                progress = 1.0f,
                status = DownloadStatus.COMPLETED,
                localFilePath = "/data/secure_media/arch_s2e1_4k.mp4",
                offlineLicense = OfflineLicense(
                    licenseId = "LIC_OFFLINE_002",
                    contentId = "series_the_architect",
                    expirationTimestamp = System.currentTimeMillis() + (30L * 24 * 3600 * 1000),
                    storedLocalPath = "/data/drm_vault/lic_002.key"
                )
            )
        )
    )
    override val downloads: StateFlow<List<DownloadTask>> = _downloads.asStateFlow()

    override suspend fun queueDownload(item: ContentItem) {
        val existing = _downloads.value.find { it.contentId == item.id }
        if (existing != null) return

        val newTask = DownloadTask(
            contentId = item.id,
            title = item.title,
            sizeBytes = (item.durationMinutes * 35L * 1024 * 1024), // ~35MB/min for high-quality stream
            downloadedBytes = 0L,
            progress = 0.05f,
            status = DownloadStatus.DOWNLOADING
        )
        _downloads.value = _downloads.value + newTask
    }

    override suspend fun pauseDownload(contentId: String) {
        _downloads.value = _downloads.value.map {
            if (it.contentId == contentId) it.copy(status = DownloadStatus.PAUSED) else it
        }
    }

    override suspend fun resumeDownload(contentId: String) {
        _downloads.value = _downloads.value.map {
            if (it.contentId == contentId) it.copy(status = DownloadStatus.DOWNLOADING) else it
        }
    }

    override suspend fun cancelDownload(contentId: String) {
        deleteDownload(contentId)
    }

    override suspend fun deleteDownload(contentId: String) {
        _downloads.value = _downloads.value.filterNot { it.contentId == contentId }
    }

    override fun getTotalStorageUsedBytes(): Long {
        return _downloads.value
            .filter { it.status == DownloadStatus.COMPLETED }
            .sumOf { it.downloadedBytes }
    }
}
