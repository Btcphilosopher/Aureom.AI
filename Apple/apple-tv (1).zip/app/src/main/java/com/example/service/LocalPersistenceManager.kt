package com.example.service

import android.content.Context
import android.content.SharedPreferences
import com.example.model.DefaultProfiles
import com.example.model.SystemTVSettings
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LocalPersistenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("apple_tv_prefs", Context.MODE_PRIVATE)

    // Watchlist set of IDs
    private val _watchlistIds = MutableStateFlow<Set<String>>(
        prefs.getStringSet("watchlist_ids", setOf("film_last_horizon", "series_northern_lights", "film_orbital")) ?: setOf()
    )
    val watchlistIds: StateFlow<Set<String>> = _watchlistIds.asStateFlow()

    // Resume positions: contentId -> seconds
    private val _resumePositions = MutableStateFlow<Map<String, Long>>(
        mapOf(
            "film_last_horizon" to 2520L, // 42 mins in
            "series_the_architect" to 1260L, // 21 mins in
            "series_northern_lights" to 1800L // 30 mins in
        )
    )
    val resumePositions: StateFlow<Map<String, Long>> = _resumePositions.asStateFlow()

    // Active Profile
    private val _activeProfile = MutableStateFlow<UserProfile>(DefaultProfiles.first())
    val activeProfile: StateFlow<UserProfile> = _activeProfile.asStateFlow()

    // All Household Profiles
    private val _allProfiles = MutableStateFlow<List<UserProfile>>(DefaultProfiles)
    val allProfiles: StateFlow<List<UserProfile>> = _allProfiles.asStateFlow()

    // Entitlements / Purchased products
    private val _purchasedProductIds = MutableStateFlow<Set<String>>(
        setOf("sub_appletv_plus", "pass_cinema_bundle")
    )
    val purchasedProductIds: StateFlow<Set<String>> = _purchasedProductIds.asStateFlow()

    // Installed App IDs
    private val _installedAppIds = MutableStateFlow<Set<String>>(
        setOf("app_fitness", "app_arcade", "app_photos")
    )
    val installedAppIds: StateFlow<Set<String>> = _installedAppIds.asStateFlow()

    // TV Settings
    private val _systemSettings = MutableStateFlow(SystemTVSettings())
    val systemSettings: StateFlow<SystemTVSettings> = _systemSettings.asStateFlow()

    // Recent Searches
    private val _recentSearches = MutableStateFlow<List<String>>(
        listOf("Sci-Fi 4K", "Hans Zimmer", "BBC News", "The Architect", "Premier League")
    )
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    fun toggleWatchlist(contentId: String): Boolean {
        val current = _watchlistIds.value.toMutableSet()
        val added = if (current.contains(contentId)) {
            current.remove(contentId)
            false
        } else {
            current.add(contentId)
            true
        }
        _watchlistIds.value = current
        prefs.edit().putStringSet("watchlist_ids", current).apply()
        return added
    }

    fun updateResumePosition(contentId: String, positionSeconds: Long) {
        val map = _resumePositions.value.toMutableMap()
        map[contentId] = positionSeconds
        _resumePositions.value = map
    }

    fun setActiveProfile(profile: UserProfile) {
        _activeProfile.value = profile
    }

    fun addRecentSearch(query: String) {
        if (query.isBlank()) return
        val list = _recentSearches.value.toMutableList()
        list.remove(query)
        list.add(0, query)
        _recentSearches.value = list.take(8)
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
    }

    fun purchaseProduct(productId: String) {
        val set = _purchasedProductIds.value.toMutableSet()
        set.add(productId)
        _purchasedProductIds.value = set
    }

    fun toggleAppInstalled(appId: String): Boolean {
        val current = _installedAppIds.value.toMutableSet()
        val installed = if (current.contains(appId)) {
            current.remove(appId)
            false
        } else {
            current.add(appId)
            true
        }
        _installedAppIds.value = current
        return installed
    }

    fun updateSettings(settings: SystemTVSettings) {
        _systemSettings.value = settings
    }
}
