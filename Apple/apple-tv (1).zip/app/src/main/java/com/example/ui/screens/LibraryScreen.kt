package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.service.DownloadTask
import com.example.ui.components.ContentRail
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun LibraryScreen(
    watchlistIds: Set<String>,
    downloads: List<DownloadTask>,
    onPlayItem: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = listOf("Watchlist", "Purchased & Rentals", "Downloaded Offline", "Watch History")
    var selectedSection by remember { mutableStateOf("Watchlist") }

    val watchlistItems = remember(watchlistIds) {
        DemoContentProvider.allContent.filter { watchlistIds.contains(it.id) }
    }

    val purchasedItems = remember {
        listOf(DemoContentProvider.theLastHorizon, DemoContentProvider.theArchitect)
    }

    val historyItems = remember {
        DemoContentProvider.allContent.filter { it.resumePositionSeconds > 0 }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp)
    ) {
        // Library Title & Tabs
        Column(modifier = Modifier.padding(horizontal = 36.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Personal Library",
                    color = AppleTextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                FormatPill(label = "iCloud Synced")
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section Filter Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                sections.forEach { section ->
                    val isSelected = section == selectedSection
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) AppleTextWhite else AppleSurfaceElevated)
                            .border(1.dp, if (isSelected) AppleTextWhite else Color(0xFF343444), RoundedCornerShape(20.dp))
                            .clickable { selectedSection = section }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("library_tab_$section")
                    ) {
                        Text(
                            text = section,
                            color = if (isSelected) Color.Black else AppleTextSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Content according to selected library tab
        when (selectedSection) {
            "Watchlist" -> {
                if (watchlistItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp)
                    ) {
                        Text(
                            text = "Your Watchlist is empty. Browse movies or shows and tap 'Watchlist' to add titles here.",
                            color = AppleTextSecondary,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    ContentRail(
                        title = "Your Watchlist (${watchlistItems.size} Titles)",
                        items = watchlistItems,
                        onItemClick = onPlayItem
                    )
                }
            }

            "Purchased & Rentals" -> {
                ContentRail(
                    title = "Purchased Movies (4K HDR with Extras)",
                    items = purchasedItems,
                    onItemClick = onPlayItem
                )
            }

            "Downloaded Offline" -> {
                Column(modifier = Modifier.padding(horizontal = 36.dp)) {
                    Text(
                        text = "Downloaded Media for Offline Travel",
                        color = AppleTextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    downloads.forEach { task ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AppleCardBackground)
                                .border(1.dp, Color(0xFF2C2C3A), RoundedCornerShape(10.dp))
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(task.title, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Storage: ${task.sizeFormatted} • License: Active", color = AppleTextSecondary, fontSize = 11.sp)
                            }
                            FormatPill(label = task.status.name)
                        }
                    }
                }
            }

            "Watch History" -> {
                ContentRail(
                    title = "Recently Watched with Resume Markers",
                    items = historyItems,
                    isContinueWatching = true,
                    onItemClick = onPlayItem
                )
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }
}
