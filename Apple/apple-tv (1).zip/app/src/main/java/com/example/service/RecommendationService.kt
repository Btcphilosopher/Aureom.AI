package com.example.service

import com.example.model.ContentItem
import com.example.model.UserProfile
import java.util.Calendar

data class RecommendationContext(
    val profile: UserProfile,
    val watchHistoryContentIds: List<String>,
    val completionRates: Map<String, Float>, // contentId to 0..1
    val preferredGenres: List<String>,
    val hourOfDay: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
    val offlineOnly: Boolean = false
)

interface RecommendationService {
    suspend fun getRecommendations(
        allAvailable: List<ContentItem>,
        context: RecommendationContext
    ): List<ContentItem>

    suspend fun getBecauseYouWatched(
        sourceItem: ContentItem,
        allAvailable: List<ContentItem>,
        context: RecommendationContext
    ): List<ContentItem>
}

class DeterministicContentRecommendationEngine : RecommendationService {

    override suspend fun getRecommendations(
        allAvailable: List<ContentItem>,
        context: RecommendationContext
    ): List<ContentItem> {
        // Deterministic multi-factor scoring algorithm:
        // 1. Filter out items exceeding profile maturity limit
        // 2. Score by genre overlap with preferred genres and watch history
        // 3. Weight by content rating score (e.g. 9.6)
        // 4. Boost new releases and time-of-day affinity (e.g. relaxing documentaries in evening)
        return allAvailable
            .filter { item ->
                // Check profile maturity rating boundary
                item.maturityRating.minAge <= context.profile.maxMaturity.minAge
            }
            .map { item ->
                var score = item.ratingScore * 10.0 // Base score 0..100

                // Boost for preferred genre matching
                val matchingGenres = item.genres.count { it in context.preferredGenres }
                score += matchingGenres * 15.0

                // Time of day affinity: Evening (19:00+) prioritizes Movies & Sci-Fi
                if (context.hourOfDay >= 19 && (item.genres.contains("Sci-Fi") || item.genres.contains("Thriller"))) {
                    score += 8.0
                }

                // If user watched previously with high completion, slight penalty for re-recommendation
                // to favor new discovery unless part of continuing series
                val completion = context.completionRates[item.id] ?: 0f
                if (completion > 0.85f && item.episodes.isEmpty()) {
                    score -= 20.0
                }

                item to score
            }
            .sortedByDescending { it.second }
            .map { it.first }
    }

    override suspend fun getBecauseYouWatched(
        sourceItem: ContentItem,
        allAvailable: List<ContentItem>,
        context: RecommendationContext
    ): List<ContentItem> {
        return allAvailable
            .filter { it.id != sourceItem.id && it.maturityRating.minAge <= context.profile.maxMaturity.minAge }
            .map { candidate ->
                var similarity = 0
                val commonGenres = candidate.genres.intersect(sourceItem.genres.toSet()).size
                similarity += commonGenres * 3

                val commonCast = candidate.cast.intersect(sourceItem.cast.toSet()).size
                similarity += commonCast * 5

                if (candidate.type == sourceItem.type) {
                    similarity += 2
                }
                candidate to similarity
            }
            .sortedByDescending { it.second }
            .map { it.first }
    }
}
