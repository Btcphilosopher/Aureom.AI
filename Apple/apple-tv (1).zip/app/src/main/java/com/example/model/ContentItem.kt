package com.example.model

enum class ContentMediaType {
    MOVIE,
    SERIES,
    LIVE_CHANNEL,
    SPORTS_EVENT,
    MUSIC_ALBUM,
    PODCAST,
    APP,
    GAME
}

enum class MaturityRating(val label: String, val minAge: Int) {
    G("G", 0),
    PG("PG", 8),
    PG13("PG-13", 13),
    TV14("TV-14", 14),
    MA("TV-MA", 17),
    R("R", 18)
}

enum class VideoFormat(val label: String) {
    HD_1080P("1080p HD"),
    UHD_4K("4K UHD"),
    UHD_8K("8K Ultra"),
    DOLBY_VISION("Dolby Vision"),
    HDR10_PLUS("HDR10+")
}

enum class AudioFormat(val label: String) {
    STEREO("Stereo"),
    SURROUND_5_1("5.1 Surround"),
    SURROUND_7_1("7.1 Surround"),
    DOLBY_ATMOS("Dolby Atmos")
}

data class ContentRights(
    val territories: List<String> = listOf("US", "UK", "EU", "CA", "JP"),
    val startDate: String = "2024-01-01",
    val endDate: String = "2029-12-31",
    val subscriptionRequirement: String? = "Apple TV+ / MLS",
    val purchasePrice: Double? = null,
    val rentalPrice: Double? = null,
    val downloadAllowed: Boolean = true,
    val streamingAllowed: Boolean = true
) {
    fun isValidNow(): Boolean = true
}

data class ChapterMarker(
    val title: String,
    val startTimeSeconds: Long,
    val thumbnailRes: Int? = null
)

data class ContentEpisode(
    val id: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val synopsis: String,
    val durationMinutes: Int,
    val streamDurationSeconds: Long = (durationMinutes * 60).toLong(),
    val resumePositionSeconds: Long = 0,
    val introStartSeconds: Long = 60,
    val introEndSeconds: Long = 95,
    val recapStartSeconds: Long = 0,
    val recapEndSeconds: Long = 45,
    val creditsStartSeconds: Long = (durationMinutes * 60 - 75).toLong(),
    val thumbnailRes: Int? = null
)

data class ContentItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val type: ContentMediaType,
    val year: Int,
    val durationMinutes: Int = 120,
    val maturityRating: MaturityRating = MaturityRating.PG13,
    val videoFormat: VideoFormat = VideoFormat.DOLBY_VISION,
    val audioFormat: AudioFormat = AudioFormat.DOLBY_ATMOS,
    val genres: List<String>,
    val cast: List<String> = emptyList(),
    val directors: List<String> = emptyList(),
    val ratingScore: Double = 9.4,
    val heroArtworkRes: Int? = null,
    val posterColor: Long = 0xFF1C1C28,
    val audioTracks: List<String> = listOf("English [Original] (Dolby Atmos)", "English (Audio Description)", "Spanish (5.1)", "French (5.1)", "Japanese (5.1)"),
    val subtitleTracks: List<String> = listOf("Off", "English [CC]", "Spanish", "French", "German", "Japanese"),
    val episodes: List<ContentEpisode> = emptyList(),
    val chapters: List<ChapterMarker> = emptyList(),
    val rights: ContentRights = ContentRights(),
    val resumePositionSeconds: Long = 0,
    val isFeatured: Boolean = false,
    val provider: String = "Apple Original"
) {
    val totalSeconds: Long get() = (durationMinutes * 60).toLong()
    val progressPercent: Float
        get() = if (totalSeconds > 0) (resumePositionSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f) else 0f
}

data class LiveProgramme(
    val id: String,
    val channelId: String,
    val title: String,
    val description: String,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val category: String,
    val isLiveNow: Boolean = false
) {
    val timeLabel: String
        get() = "%02d:%02d - %02d:%02d".format(startHour, startMinute, endHour, endMinute)
}

data class LiveChannel(
    val id: String,
    val channelNumber: Int,
    val name: String,
    val logoText: String,
    val category: String,
    val resolution: String = "4K 60fps",
    val isFavorite: Boolean = false,
    val schedule: List<LiveProgramme> = emptyList()
)

data class SportsFixture(
    val id: String,
    val league: String,
    val homeTeam: String,
    val awayTeam: String,
    val homeScore: Int? = null,
    val awayScore: Int? = null,
    val status: String, // "LIVE 74'", "FINAL", "TODAY 20:00"
    val isLive: Boolean = false,
    val arena: String = "Horizon Stadium",
    val broadcast: String = "Apple TV+ / MLS"
)

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val isSpatialAudio: Boolean = true
)

data class AppCatalogItem(
    val id: String,
    val name: String,
    val developer: String,
    val category: String,
    val rating: Double,
    val sizeMb: Int,
    val description: String,
    val isInstalled: Boolean = false
)
