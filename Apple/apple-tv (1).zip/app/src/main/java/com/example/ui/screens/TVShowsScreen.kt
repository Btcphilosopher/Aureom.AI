package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.model.ContentMediaType
import com.example.ui.components.ContentRail
import com.example.ui.components.HeroFeaturedBanner

@Composable
fun TVShowsScreen(
    onPlayItem: (ContentItem) -> Unit,
    watchlistIds: Set<String>,
    onWatchlistToggle: (String) -> Unit,
    onItemDetails: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val allSeries = DemoContentProvider.allContent.filter { it.type == ContentMediaType.SERIES }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Spotlight series
        HeroFeaturedBanner(
            featuredItem = DemoContentProvider.theArchitect,
            isInWatchlist = watchlistIds.contains(DemoContentProvider.theArchitect.id),
            onPlayClick = { onPlayItem(DemoContentProvider.theArchitect) },
            onWatchlistToggle = { onWatchlistToggle(DemoContentProvider.theArchitect.id) },
            onDetailsClick = { onItemDetails(DemoContentProvider.theArchitect) }
        )

        ContentRail(
            title = "Binge-Worthy Television Series",
            items = allSeries,
            onItemClick = onPlayItem
        )

        ContentRail(
            title = "Nordic Mysteries & Thrillers",
            items = allSeries.filter { it.genres.contains("Mystery") || it.genres.contains("Thriller") },
            onItemClick = onPlayItem
        )

        ContentRail(
            title = "Epic Nature & Science in 8K",
            items = allSeries.filter { it.genres.contains("Documentary") || it.genres.contains("Nature") },
            onItemClick = onPlayItem
        )

        Spacer(modifier = Modifier.height(60.dp))
    }
}
