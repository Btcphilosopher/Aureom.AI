package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.focus.RemoteAction
import com.example.ui.theme.*

@Composable
fun VirtualSiriRemoteOverlay(
    isVisible: Boolean,
    onClose: () -> Unit,
    onRemoteAction: (RemoteAction) -> Unit,
    onSiriClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
        exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .padding(16.dp)
                .shadow(24.dp, RoundedCornerShape(32.dp))
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF2C2C32),
                            Color(0xFF1E1E24),
                            Color(0xFF141418)
                        )
                    )
                )
                .border(1.5.dp, Color(0xFF484852), RoundedCornerShape(32.dp))
                .width(170.dp)
                .padding(horizontal = 14.dp, vertical = 18.dp)
                .testTag("virtual_siri_remote_panel")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header: Status LED, Apple logo & close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(AppleSuccessGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "96%",
                            color = AppleTextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Text(
                        text = "SIRI REMOTE",
                        color = AppleTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF3A3A44))
                            .clickable { onClose() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Remote",
                            tint = AppleTextWhite,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // The Circular Clickpad (Siri Remote Touch Surface)
                Box(
                    modifier = Modifier
                        .size(136.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF32323C), Color(0xFF1A1A20))
                            )
                        )
                        .border(1.dp, Color(0xFF4E4E5A), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // UP arrow
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 4.dp)
                            .size(36.dp)
                            .clickable { onRemoteAction(RemoteAction.UP) }
                            .testTag("remote_dpad_up"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowUp, "Up", tint = AppleTextWhite, modifier = Modifier.size(22.dp))
                    }

                    // DOWN arrow
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 4.dp)
                            .size(36.dp)
                            .clickable { onRemoteAction(RemoteAction.DOWN) }
                            .testTag("remote_dpad_down"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, "Down", tint = AppleTextWhite, modifier = Modifier.size(22.dp))
                    }

                    // LEFT arrow
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 4.dp)
                            .size(36.dp)
                            .clickable { onRemoteAction(RemoteAction.LEFT) }
                            .testTag("remote_dpad_left"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowLeft, "Left", tint = AppleTextWhite, modifier = Modifier.size(22.dp))
                    }

                    // RIGHT arrow
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 4.dp)
                            .size(36.dp)
                            .clickable { onRemoteAction(RemoteAction.RIGHT) }
                            .testTag("remote_dpad_right"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowRight, "Right", tint = AppleTextWhite, modifier = Modifier.size(22.dp))
                    }

                    // CENTER SELECT Button
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF24242C))
                            .border(1.dp, Color(0xFF5A5A68), CircleShape)
                            .clickable { onRemoteAction(RemoteAction.SELECT) }
                            .testTag("remote_dpad_select"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "OK",
                            color = AppleTextWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Control Buttons Row 1: Back (<) and TV / Home
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RemotePillButton(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        testTag = "remote_back_button"
                    ) {
                        onRemoteAction(RemoteAction.BACK)
                    }

                    RemotePillButton(
                        icon = Icons.Default.Tv,
                        contentDescription = "TV Home",
                        testTag = "remote_home_button"
                    ) {
                        onRemoteAction(RemoteAction.HOME)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Control Buttons Row 2: Play/Pause and Mute
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RemotePillButton(
                        icon = Icons.Default.PlayArrow,
                        contentDescription = "Play Pause",
                        testTag = "remote_play_pause_button"
                    ) {
                        onRemoteAction(RemoteAction.PLAY_PAUSE)
                    }

                    RemotePillButton(
                        icon = Icons.Default.VolumeMute,
                        contentDescription = "Mute",
                        testTag = "remote_mute_button"
                    ) {
                        // Mute action
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Control Buttons Row 3: Siri Voice Search and Volume Rocker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Siri Microphone Button
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AppleAccentBlue, AppleAccentPurple)
                                )
                            )
                            .clickable { onSiriClick() }
                            .testTag("remote_siri_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Siri Voice Search",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Volume + / - rocker
                    Column(
                        modifier = Modifier
                            .width(44.dp)
                            .height(68.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF222228))
                            .border(1.dp, Color(0xFF3E3E48), RoundedCornerShape(22.dp)),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clickable { /* Vol Up */ },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Add, "Vol Up", tint = AppleTextWhite, modifier = Modifier.size(16.dp))
                        }
                        Box(
                            modifier = Modifier
                                .height(1.dp)
                                .fillMaxWidth()
                                .background(Color(0xFF383842))
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clickable { /* Vol Down */ },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Remove, "Vol Down", tint = AppleTextWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RemotePillButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF24242C))
            .border(1.dp, Color(0xFF3A3A46), CircleShape)
            .clickable { onClick() }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = AppleTextWhite,
            modifier = Modifier.size(20.dp)
        )
    }
}
