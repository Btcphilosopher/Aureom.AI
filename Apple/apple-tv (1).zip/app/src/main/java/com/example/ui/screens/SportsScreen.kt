package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.SportsFixture
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun SportsScreen(
    onPlayFixture: (SportsFixture) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(vertical = 16.dp)
    ) {
        // Live Matches Row
        Column(modifier = Modifier.padding(horizontal = 36.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Now & Key Matchups",
                    color = AppleTextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                FormatPill(label = "MLS Season Pass & Premier League 4K")
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(DemoContentProvider.sportsFixtures, key = { it.id }) { fixture ->
                    SportsScoreCard(
                        fixture = fixture,
                        onClick = { onPlayFixture(fixture) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // League Standings / Tables Architecture
        Column(modifier = Modifier.padding(horizontal = 36.dp)) {
            Text(
                text = "Premier League Standings 2026",
                color = AppleTextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AppleCardBackground)
                    .border(1.dp, Color(0xFF2C2C3A), RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("CLUB", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                    Text("PL", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                    Text("W", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                    Text("D", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                    Text("L", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                    Text("GD", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                    Text("PTS", color = AppleTextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                }

                StandingRow(pos = 1, club = "Arsenal", played = 29, w = 21, d = 5, l = 3, gd = "+42", pts = 68, isLeader = true)
                StandingRow(pos = 2, club = "Manchester City", played = 29, w = 20, d = 6, l = 3, gd = "+38", pts = 66)
                StandingRow(pos = 3, club = "Liverpool", played = 29, w = 19, d = 7, l = 3, gd = "+34", pts = 64)
                StandingRow(pos = 4, club = "Aston Villa", played = 29, w = 17, d = 4, l = 8, gd = "+18", pts = 55)
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }
}

@Composable
fun SportsScoreCard(
    fixture: SportsFixture,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(280.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1B1B26))
            .border(
                1.dp,
                if (fixture.isLive) AppleLiveRed.copy(alpha = 0.5f) else Color(0xFF303040),
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
            .testTag("sports_card_${fixture.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = fixture.league,
                    color = AppleTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (fixture.isLive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AppleLiveRed)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FiberManualRecord, null, tint = Color.White, modifier = Modifier.size(8.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(fixture.status, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Text(
                        text = fixture.status,
                        color = AppleTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Teams & Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(fixture.homeTeam, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(fixture.awayTeam, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }

                if (fixture.homeScore != null && fixture.awayScore != null) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(fixture.homeScore.toString(), color = AppleTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(fixture.awayScore.toString(), color = AppleTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(fixture.arena, color = AppleTextTertiary, fontSize = 10.sp)
                Icon(Icons.Default.PlayArrow, "Watch", tint = AppleAccentBlue, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun StandingRow(
    pos: Int,
    club: String,
    played: Int,
    w: Int,
    d: Int,
    l: Int,
    gd: String,
    pts: Int,
    isLeader: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(2f), verticalAlignment = Alignment.CenterVertically) {
            Text(pos.toString(), color = if (isLeader) AppleGold else AppleTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(20.dp))
            Text(club, color = AppleTextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(played.toString(), color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(w.toString(), color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(d.toString(), color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(l.toString(), color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(gd, color = AppleTextSecondary, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(pts.toString(), color = AppleTextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
    }
}
