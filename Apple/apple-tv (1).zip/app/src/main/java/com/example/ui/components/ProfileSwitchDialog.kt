package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.UserProfile
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*

@Composable
fun ProfileSwitchDialog(
    allProfiles: List<UserProfile>,
    activeProfile: UserProfile,
    onSelectProfile: (UserProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var pendingProfileWithPin by remember { mutableStateOf<UserProfile?>(null) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .width(460.dp)
                .shadow(32.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(AppleCardBackground)
                .border(1.dp, Color(0xFF333342), RoundedCornerShape(24.dp))
                .padding(28.dp)
                .testTag("profile_switch_dialog")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (pendingProfileWithPin != null) "Enter Parental Controls PIN" else "Who's Watching?",
                        color = AppleTextWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2E2E3C))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, "Close", tint = AppleTextSecondary, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (pendingProfileWithPin == null) {
                    // Profile selection row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        allProfiles.forEach { profile ->
                            val isCurrent = profile.id == activeProfile.id

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .tvFocusable(
                                        isFocused = isCurrent,
                                        testTag = "profile_item_${profile.id}",
                                        shape = RoundedCornerShape(16.dp),
                                        focusScale = 1.10f
                                    ) {
                                        if (profile.parentalControls.isEnabled) {
                                            pendingProfileWithPin = profile
                                            enteredPin = ""
                                            pinError = false
                                        } else {
                                            onSelectProfile(profile)
                                            onDismiss()
                                        }
                                    }
                                    .padding(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .background(Color(profile.avatarColor))
                                        .border(
                                            if (isCurrent) 3.dp else 0.dp,
                                            AppleTextWhite,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = profile.avatarInitials,
                                        color = Color.White,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    if (profile.parentalControls.isEnabled) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .size(22.dp)
                                                .clip(CircleShape)
                                                .background(Color.Black.copy(alpha = 0.8f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Lock,
                                                contentDescription = "PIN Protected",
                                                tint = AppleWarningYellow,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = profile.name,
                                    color = AppleTextWhite,
                                    fontSize = 13.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                )

                                if (profile.isKidsProfile) {
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 2.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(AppleSuccessGreen.copy(alpha = 0.2f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("KIDS", color = AppleSuccessGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // PIN Entry verification view
                    val prof = pendingProfileWithPin!!
                    Text(
                        text = "Profile '${prof.name}' is restricted to ${prof.maxMaturity.label}. Enter PIN to switch (Default demo PIN: 2468)",
                        color = AppleTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = enteredPin,
                        onValueChange = {
                            if (it.length <= 4) {
                                enteredPin = it
                                pinError = false
                            }
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        isError = pinError,
                        placeholder = { Text("4-digit PIN", color = AppleTextTertiary) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = AppleSurfaceElevated,
                            unfocusedContainerColor = AppleSurfaceElevated,
                            focusedTextColor = AppleTextWhite,
                            unfocusedTextColor = AppleTextWhite,
                            cursorColor = AppleTextWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .testTag("parental_pin_input")
                    )

                    if (pinError) {
                        Text(
                            text = "Incorrect PIN. Please try again.",
                            color = AppleLiveRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                if (enteredPin == prof.parentalControls.pinCode) {
                                    onSelectProfile(prof)
                                    onDismiss()
                                } else {
                                    pinError = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleAccentBlue)
                        ) {
                            Text("Unlock & Switch", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { pendingProfileWithPin = null },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleSurfaceElevated)
                        ) {
                            Text("Cancel", color = AppleTextSecondary)
                        }
                    }
                }
            }
        }
    }
}
