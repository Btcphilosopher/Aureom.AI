package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentItem
import com.example.model.ContentMediaType
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*

@Composable
fun ContentRail(
    title: String,
    items: List<ContentItem>,
    isContinueWatching: Boolean = false,
    focusedIndex: Int = -1,
    onItemClick: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        // Section Title
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 36.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = AppleTextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.2).sp
            )
        }

        // Horizontal Rail
        LazyRow(
            contentPadding = PaddingValues(horizontal = 36.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            itemsIndexed(items, key = { _, item -> item.id }) { index, item ->
                ContentCard(
                    item = item,
                    isContinueWatching = isContinueWatching,
                    isFocused = (focusedIndex == index),
                    onClick = { onItemClick(item) }
                )
            }
        }
    }
}

@Composable
fun ContentCard(
    item: ContentItem,
    isContinueWatching: Boolean,
    isFocused: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 16:9 aspect ratio card for TV landscape style
    val cardWidth = if (isContinueWatching) 250.dp else 220.dp
    val cardHeight = if (isContinueWatching) 140.dp else 124.dp

    Column(
        modifier = modifier
            .width(cardWidth)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(cardHeight)
                .clip(RoundedCornerShape(12.dp))
                .tvFocusable(
                    isFocused = isFocused,
                    testTag = "content_card_${item.id}",
                    shape = RoundedCornerShape(12.dp),
                    focusScale = 1.08f,
                    onClick = onClick
                )
        ) {
            // Artwork or rich gradient
            if (item.heroArtworkRes != null) {
                Image(
                    painter = painterResource(id = item.heroArtworkRes),
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(item.posterColor),
                                    Color(item.posterColor).copy(alpha = 0.5f),
                                    Color(0xFF14141C)
                                )
                            )
                        )
                ) {
                    // Title watermark for unillustrated fictional films
                    Text(
                        text = item.title.uppercase(),
                        color = Color.White.copy(alpha = 0.15f),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(8.dp),
                        maxLines = 2
                    )
                }
            }

            // Dark vignette overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                            startY = 60f
                        )
                    )
            )

            // Top Badges
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.type == ContentMediaType.SERIES) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SERIES",
                            color = AppleTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.videoFormat.label,
                        color = AppleTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Bottom Content / Progress Bar
            if (isContinueWatching && item.resumePositionSeconds > 0) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                ) {
                    val remainingMins = ((item.totalSeconds - item.resumePositionSeconds) / 60).coerceAtLeast(1)
                    Text(
                        text = "$remainingMins min remaining",
                        color = AppleTextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    LinearProgressIndicator(
                        progress = { item.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = AppleAccentBlue,
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Title and Subtitle underneath card
        Text(
            text = item.title,
            color = AppleTextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (isContinueWatching) item.subtitle else "${item.year} • ${item.genres.firstOrNull() ?: ""}",
            color = AppleTextSecondary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
