package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun AppsScreen(
    installedAppIds: Set<String>,
    onToggleAppInstall: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 36.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "App Store for Apple TV",
                color = AppleTextWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            FormatPill(label = "Curated for Living Room")
        }

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(DemoContentProvider.appStoreApps, key = { it.id }) { app ->
                val isInstalled = installedAppIds.contains(app.id)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(AppleCardBackground)
                        .border(1.dp, Color(0xFF2E2E3C), RoundedCornerShape(14.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF282836)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Apps, null, tint = AppleAccentBlue, modifier = Modifier.size(32.dp))
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(app.name, color = AppleTextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, null, tint = AppleGold, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(app.rating.toString(), color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            Text("${app.developer} • ${app.category} • ${app.sizeMb} MB", color = AppleTextSecondary, fontSize = 11.sp)
                            Text(app.description, color = AppleTextTertiary, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Button(
                        onClick = { onToggleAppInstall(app.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isInstalled) AppleSurfaceElevated else AppleTextWhite
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("app_install_button_${app.id}")
                    ) {
                        Text(
                            text = if (isInstalled) "OPEN" else "GET",
                            color = if (isInstalled) AppleTextWhite else Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
