package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.focus.TVNavDestination
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TopNavigationBar(
    currentDestination: TVNavDestination,
    onDestinationSelected: (TVNavDestination) -> Unit,
    activeProfile: UserProfile,
    onProfileClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onAirPlayClick: () -> Unit,
    onRemoteToggleClick: () -> Unit,
    isRemoteOpen: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val currentTime = timeFormat.format(Date())

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(Color.Black.copy(alpha = 0.65f))
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: Apple TV Monogram / Logo
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(AppleCardBackground),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = "Apple TV",
                    tint = AppleTextWhite,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "tv",
                color = AppleTextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                letterSpacing = (-0.5).sp
            )
        }

        // Center: Navigation Tabs
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            TVNavDestination.values().forEach { destination ->
                val isSelected = currentDestination == destination
                val backgroundColor by animateColorAsState(
                    targetValue = if (isSelected) AppleTextWhite else Color.Transparent,
                    label = "tab_bg"
                )
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) Color.Black else AppleTextSecondary,
                    label = "tab_text"
                )

                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(backgroundColor)
                        .tvFocusable(
                            isFocused = isSelected,
                            testTag = "nav_tab_${destination.name.lowercase()}",
                            shape = RoundedCornerShape(20.dp),
                            focusScale = 1.05f
                        ) {
                            onDestinationSelected(destination)
                        }
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = destination.label,
                        color = textColor,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium
                    )
                }
            }
        }

        // Right side indicators: Remote HUD toggle, AirPlay, Clock, Profile, Settings
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Virtual Remote toggle button for developer/emulator convenience
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isRemoteOpen) AppleAccentBlue else AppleSurfaceElevated)
                    .tvFocusable(
                        isFocused = false,
                        testTag = "remote_hud_toggle",
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        onRemoteToggleClick()
                    }
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SettingsRemote,
                        contentDescription = "Siri Remote",
                        tint = AppleTextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isRemoteOpen) "Remote ON" else "Remote",
                        color = AppleTextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // AirPlay icon
            IconButton(
                onClick = onAirPlayClick,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("airplay_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Cast,
                    contentDescription = "AirPlay",
                    tint = AppleAccentCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Time readout
            Text(
                text = currentTime,
                color = AppleTextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            // Household Profile Avatar
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(activeProfile.avatarColor))
                    .tvFocusable(
                        isFocused = false,
                        testTag = "profile_avatar_button",
                        shape = CircleShape
                    ) {
                        onProfileClick()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = activeProfile.avatarInitials,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Settings gear
            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("settings_gear_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = AppleTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
