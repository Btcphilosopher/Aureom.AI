package com.example.model

data class VideoSettings(
    val format: String = "4K Dolby Vision 60Hz",
    val matchDynamicRange: Boolean = true,
    val matchFrameRate: Boolean = true,
    val chroma: String = "4:2:2 High Speed",
    val hdmiOutputRange: String = "Auto (YCbCr 10-bit)"
)

data class AudioSettings(
    val outputDevice: String = "HomePod Cinema Pair (Living Room)",
    val audioFormat: String = "Auto (Dolby Atmos)",
    val reduceLoudSounds: Boolean = false,
    val dialogueEnhance: String = "Boost Center Channel",
    val audioSyncLatencyMs: Int = 0
)

data class NetworkDiagnostics(
    val wifiSsid: String = "Orion_5GHz_Mesh",
    val isConnected: Boolean = true,
    val signalStrengthPercent: Int = 94,
    val ipAddress: String = "192.168.1.185",
    val subnetMask: String = "255.255.255.0",
    val routerIp: String = "192.168.1.1",
    val dnsServer: String = "1.1.1.1, 8.8.8.8",
    val measuredDownloadMbps: Double = 485.6,
    val pingLatencyMs: Int = 11
)

data class AccessibilitySettings(
    val voiceOverEnabled: Boolean = false,
    val closedCaptionsAlwaysOn: Boolean = false,
    val audioDescriptionsDefault: Boolean = false,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val boldText: Boolean = false
)

data class AirPlaySettings(
    val receiverEnabled: Boolean = true,
    val deviceName: String = "Living Room Apple TV",
    val allowAccess: String = "Anyone on the Same Network",
    val requireCode: Boolean = false
)

data class SystemTVSettings(
    val video: VideoSettings = VideoSettings(),
    val audio: AudioSettings = AudioSettings(),
    val network: NetworkDiagnostics = NetworkDiagnostics(),
    val accessibility: AccessibilitySettings = AccessibilitySettings(),
    val airPlay: AirPlaySettings = AirPlaySettings(),
    val sleepAfterMinutes: Int = 15,
    val osVersion: String = "tvOS 20.4 (Living Room Engine)"
)
