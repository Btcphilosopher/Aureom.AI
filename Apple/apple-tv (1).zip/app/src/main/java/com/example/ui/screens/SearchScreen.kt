package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.ContentItem
import com.example.ui.components.ContentRail
import com.example.ui.components.FormatPill
import com.example.ui.components.OnScreenTVKeyboard
import com.example.ui.theme.*

@Composable
fun SearchScreen(
    recentSearches: List<String>,
    onAddRecentSearch: (String) -> Unit,
    onPlayItem: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var showVoiceDialog by remember { mutableStateOf(false) }

    val searchResults = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            val q = searchQuery.trim().lowercase()
            DemoContentProvider.allContent.filter { item ->
                item.title.lowercase().contains(q) ||
                        item.subtitle.lowercase().contains(q) ||
                        item.genres.any { it.lowercase().contains(q) } ||
                        item.cast.any { it.lowercase().contains(q) } ||
                        item.directors.any { it.lowercase().contains(q) }
            }
        }
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Left Column: On-screen TV Keyboard & Voice Trigger
        Column(modifier = Modifier.width(360.dp)) {
            OnScreenTVKeyboard(
                searchQuery = searchQuery,
                onKeyTyped = { char ->
                    searchQuery += char
                    if (searchQuery.length >= 3) {
                        onAddRecentSearch(searchQuery)
                    }
                },
                onBackspace = {
                    if (searchQuery.isNotEmpty()) {
                        searchQuery = searchQuery.dropLast(1)
                    }
                },
                onClear = { searchQuery = "" },
                onVoiceClick = { showVoiceDialog = true }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Recent Searches Quick Pills
            Text(
                text = "RECENT SEARCHES",
                color = AppleTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                recentSearches.forEach { query ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(AppleCardBackground)
                            .border(1.dp, Color(0xFF343444), RoundedCornerShape(14.dp))
                            .clickable { searchQuery = query }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(query, color = AppleTextWhite, fontSize = 11.sp)
                    }
                }
            }
        }

        // Right Column: Dynamic Search Results / Discovery Suggestions
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
        ) {
            if (searchQuery.isBlank()) {
                Text(
                    text = "Suggested Searches",
                    color = AppleTextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                ContentRail(
                    title = "Sci-Fi & Space Epics",
                    items = DemoContentProvider.allContent.filter { it.genres.contains("Sci-Fi") },
                    onItemClick = onPlayItem
                )

                ContentRail(
                    title = "Nordic & Atmospheric Dramas",
                    items = DemoContentProvider.allContent.filter { it.genres.contains("Drama") || it.genres.contains("Mystery") },
                    onItemClick = onPlayItem
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Results for \"$searchQuery\" (${searchResults.size})",
                        color = AppleTextWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    FormatPill(label = "Instant TV Query")
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (searchResults.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp)
                    ) {
                        Text(
                            text = "No matching films or TV series found. Try searching by director or genre.",
                            color = AppleTextSecondary,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    ContentRail(
                        title = "Matched Movies & Series",
                        items = searchResults,
                        onItemClick = onPlayItem
                    )
                }
            }
        }
    }

    // Siri Voice Search Simulation Dialog
    if (showVoiceDialog) {
        AlertDialog(
            onDismissRequest = { showVoiceDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mic, null, tint = AppleAccentBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Siri Voice Search", color = AppleTextWhite, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = "Speak into your Siri Remote or select a simulated voice query:",
                        color = AppleTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    val voicePrompts = listOf(
                        "Find science fiction movies",
                        "Play The Last Horizon",
                        "Show me drama series",
                        "Continue watching"
                    )

                    voicePrompts.forEach { prompt ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AppleSurfaceElevated)
                                .clickable {
                                    showVoiceDialog = false
                                    when (prompt) {
                                        "Find science fiction movies" -> searchQuery = "Sci-Fi"
                                        "Play The Last Horizon" -> {
                                            searchQuery = "Horizon"
                                            onPlayItem(DemoContentProvider.theLastHorizon)
                                        }
                                        "Show me drama series" -> searchQuery = "Drama"
                                        "Continue watching" -> searchQuery = "Architect"
                                    }
                                }
                                .padding(12.dp)
                        ) {
                            Text("“$prompt”", color = AppleAccentCyan, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVoiceDialog = false }) {
                    Text("Cancel", color = AppleTextSecondary)
                }
            },
            containerColor = Color(0xFF1B1B24),
            shape = RoundedCornerShape(18.dp)
        )
    }
}
