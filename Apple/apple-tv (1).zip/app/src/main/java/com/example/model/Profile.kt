package com.example.model

data class ParentalControls(
    val isEnabled: Boolean = false,
    val maxAllowedRating: MaturityRating = MaturityRating.PG13,
    val pinCode: String = "1234",
    val restrictPurchases: Boolean = true
)

data class UserProfile(
    val id: String,
    val name: String,
    val avatarInitials: String,
    val avatarColor: Long,
    val isKidsProfile: Boolean = false,
    val maxMaturity: MaturityRating = MaturityRating.MA,
    val preferredLanguage: String = "en-US",
    val parentalControls: ParentalControls = ParentalControls()
)

val DefaultProfiles = listOf(
    UserProfile(
        id = "prof_primary",
        name = "Alex",
        avatarInitials = "AL",
        avatarColor = 0xFF0A84FF,
        isKidsProfile = false,
        maxMaturity = MaturityRating.MA
    ),
    UserProfile(
        id = "prof_partner",
        name = "Morgan",
        avatarInitials = "MO",
        avatarColor = 0xFFBF5AF2,
        isKidsProfile = false,
        maxMaturity = MaturityRating.MA
    ),
    UserProfile(
        id = "prof_kids",
        name = "Kids Room",
        avatarInitials = "KD",
        avatarColor = 0xFF30D158,
        isKidsProfile = true,
        maxMaturity = MaturityRating.PG,
        parentalControls = ParentalControls(
            isEnabled = true,
            maxAllowedRating = MaturityRating.PG,
            pinCode = "2468",
            restrictPurchases = true
        )
    ),
    UserProfile(
        id = "prof_guest",
        name = "Guest",
        avatarInitials = "GU",
        avatarColor = 0xFF8E8E93,
        isKidsProfile = false,
        maxMaturity = MaturityRating.PG13
    )
)
