package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentEpisode
import com.example.model.ContentItem
import com.example.ui.components.FormatPill
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerOverlay(
    item: ContentItem,
    currentEpisode: ContentEpisode? = item.episodes.firstOrNull(),
    initialPositionSeconds: Long = item.resumePositionSeconds,
    onPositionUpdate: (Long) -> Unit,
    onClosePlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(true) }
    val totalSeconds = if (currentEpisode != null) currentEpisode.streamDurationSeconds else item.totalSeconds
    var currentPositionSeconds by remember { mutableLongStateOf(initialPositionSeconds) }
    var showControls by remember { mutableStateOf(true) }
    var selectedAudioTrack by remember { mutableStateOf(item.audioTracks.first()) }
    var selectedSubtitleTrack by remember { mutableStateOf("English [CC]") }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var showTrackMenu by remember { mutableStateOf(false) }
    var showUpNextCountdown by remember { mutableStateOf(false) }
    var upNextSecondsRemaining by remember { mutableIntStateOf(10) }

    // Playback loop simulation
    LaunchedEffect(isPlaying, playbackSpeed) {
        while (isPlaying) {
            delay((1000 / playbackSpeed).toLong())
            if (currentPositionSeconds < totalSeconds) {
                currentPositionSeconds++
                onPositionUpdate(currentPositionSeconds)

                // Trigger Up Next countdown 60 seconds before episode end if series has next episode
                if (currentEpisode != null && currentPositionSeconds >= totalSeconds - 60 && !showUpNextCountdown) {
                    showUpNextCountdown = true
                }
            } else {
                isPlaying = false
                showUpNextCountdown = true
            }
        }
    }

    // Auto-hide controls timer
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(4000)
            showControls = false
        }
    }

    // Up next countdown timer
    LaunchedEffect(showUpNextCountdown) {
        if (showUpNextCountdown) {
            while (upNextSecondsRemaining > 0) {
                delay(1000)
                upNextSecondsRemaining--
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { showControls = !showControls }
            .testTag("video_player_container")
    ) {
        // Video Stage Simulation: Cinematic poster artwork with ambient motion glow
        if (item.heroArtworkRes != null) {
            Image(
                painter = painterResource(id = item.heroArtworkRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(item.posterColor))
            )
        }

        // Subtitles Overlay (when active and controls hidden or visible)
        if (selectedSubtitleTrack != "Off") {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = if (showControls) 120.dp else 40.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = when {
                        currentPositionSeconds in 0..10 -> "[Elena Cross]: \"Initiating burn sequence on vector 4.\""
                        currentPositionSeconds in 11..25 -> "[Sofia Lind]: \"Signal telemetry locked on Perseus ring coordinates.\""
                        currentPositionSeconds in 26..45 -> "[Marcus Kane]: \"All systems nominal. Approaching event threshold.\""
                        else -> "[Subtitles: ${item.title} - $selectedSubtitleTrack]"
                    },
                    color = AppleTextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Quick Skip Intro / Skip Recap Pills
        if (currentPositionSeconds in 60..95 && !showControls) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 40.dp, bottom = 48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.8f))
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .clickable { currentPositionSeconds = 96 }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("skip_intro_button")
            ) {
                Text(
                    text = "SKIP INTRO",
                    color = AppleTextWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Up Next Episode Countdown Card
        AnimatedVisibility(
            visible = showUpNextCountdown,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 40.dp, bottom = 40.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1B24).copy(alpha = 0.95f)),
                modifier = Modifier
                    .width(340.dp)
                    .border(1.dp, Color(0xFF3C3C4C), RoundedCornerShape(16.dp))
                    .padding(16.dp)
                    .testTag("up_next_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "UP NEXT IN $upNextSecondsRemaining SECONDS",
                            color = AppleAccentCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = AppleTextSecondary,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { showUpNextCountdown = false }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Season 2 Episode 2 • Tension Joints",
                        color = AppleTextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Astrid traces unrecorded concrete pours in the Baltic tunnel.",
                        color = AppleTextSecondary,
                        fontSize = 12.sp,
                        maxLines = 2,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                showUpNextCountdown = false
                                currentPositionSeconds = 0
                                isPlaying = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleTextWhite),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Play Now", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { showUpNextCountdown = false },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleSurfaceElevated),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Cancel", color = AppleTextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Full Interactive HUD Controls (Fades in/out)
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.8f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.9f)
                            )
                        )
                    )
                    .padding(horizontal = 40.dp, vertical = 28.dp)
            ) {
                // Top Player Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                                .clickable { onClosePlayer() }
                                .testTag("player_back_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = AppleTextWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = item.title,
                                color = AppleTextWhite,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (currentEpisode != null) "S${currentEpisode.seasonNumber}:E${currentEpisode.episodeNumber} • ${currentEpisode.title}" else item.subtitle,
                                color = AppleTextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Tech Badges (4K Dolby Vision, Atmos, Speed)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FormatPill(label = item.videoFormat.label)
                        FormatPill(label = item.audioFormat.label)
                        FormatPill(label = "${playbackSpeed}x")

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AppleSurfaceElevated)
                                .clickable { showTrackMenu = !showTrackMenu }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("player_tracks_menu_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Subtitles, null, tint = AppleTextWhite, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Audio & Subtitles", color = AppleTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }

                // Audio / Subtitles Popover Menu
                if (showTrackMenu) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 56.dp)
                            .width(300.dp)
                            .border(1.dp, Color(0xFF383846), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("AUDIO TRACK", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            item.audioTracks.forEach { track ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedAudioTrack = track }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(track, color = if (selectedAudioTrack == track) AppleAccentBlue else AppleTextWhite, fontSize = 12.sp)
                                    if (selectedAudioTrack == track) Icon(Icons.Default.Check, null, tint = AppleAccentBlue, modifier = Modifier.size(14.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text("SUBTITLES", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            item.subtitleTracks.forEach { sub ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedSubtitleTrack = sub }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(sub, color = if (selectedSubtitleTrack == sub) AppleAccentBlue else AppleTextWhite, fontSize = 12.sp)
                                    if (selectedSubtitleTrack == sub) Icon(Icons.Default.Check, null, tint = AppleAccentBlue, modifier = Modifier.size(14.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text("PLAYBACK SPEED", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                                listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (playbackSpeed == speed) AppleAccentBlue else Color(0xFF2C2C38))
                                            .clickable { playbackSpeed = speed }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("${speed}x", color = Color.White, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Player Controls (Timeline, Elapsed/Remaining, Play/Seek buttons)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    // Timeline Slider & Timestamps
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatSeconds(currentPositionSeconds),
                            color = AppleTextWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.width(60.dp)
                        )

                        Slider(
                            value = currentPositionSeconds.toFloat(),
                            onValueChange = {
                                currentPositionSeconds = it.toLong()
                                onPositionUpdate(currentPositionSeconds)
                            },
                            valueRange = 0f..totalSeconds.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = AppleTextWhite,
                                activeTrackColor = AppleAccentBlue,
                                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("player_timeline_slider")
                        )

                        Text(
                            text = "-${formatSeconds((totalSeconds - currentPositionSeconds).coerceAtLeast(0))}",
                            color = AppleTextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.width(65.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Media Control Buttons (Rewind 10s, Play/Pause, Forward 10s, Skip Next)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Rewind 10s
                        IconButton(
                            onClick = { currentPositionSeconds = (currentPositionSeconds - 10).coerceAtLeast(0) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("player_rewind_10_button")
                        ) {
                            Icon(Icons.Default.Replay10, "Rewind 10s", tint = AppleTextWhite, modifier = Modifier.size(32.dp))
                        }

                        Spacer(modifier = Modifier.width(24.dp))

                        // Large Play / Pause button
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(AppleTextWhite)
                                .tvFocusable(
                                    isFocused = true,
                                    testTag = "player_play_pause_button",
                                    shape = CircleShape,
                                    focusScale = 1.1f
                                ) {
                                    isPlaying = !isPlaying
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(24.dp))

                        // Fast Forward 10s
                        IconButton(
                            onClick = { currentPositionSeconds = (currentPositionSeconds + 10).coerceAtMost(totalSeconds) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("player_forward_10_button")
                        ) {
                            Icon(Icons.Default.Forward10, "Forward 10s", tint = AppleTextWhite, modifier = Modifier.size(32.dp))
                        }

                        if (currentEpisode != null) {
                            Spacer(modifier = Modifier.width(24.dp))
                            IconButton(
                                onClick = {
                                    currentPositionSeconds = 0
                                    isPlaying = true
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("player_next_episode_button")
                            ) {
                                Icon(Icons.Default.SkipNext, "Next Episode", tint = AppleTextWhite, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatSeconds(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hrs > 0) {
        "%d:%02d:%02d".format(hrs, mins, secs)
    } else {
        "%02d:%02d".format(mins, secs)
    }
}
