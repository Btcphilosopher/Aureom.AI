package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoContentProvider
import com.example.model.MusicTrack
import com.example.ui.components.FormatPill
import com.example.ui.theme.*

@Composable
fun MusicScreen(
    modifier: Modifier = Modifier
) {
    var playingTrack by remember { mutableStateOf<MusicTrack?>(DemoContentProvider.musicAlbums.first()) }
    var isPlaying by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(36.dp),
        horizontalArrangement = Arrangement.spacedBy(36.dp)
    ) {
        // Left Column: Large Now Playing Artwork / Turntable Box
        Column(
            modifier = Modifier
                .width(340.dp)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF281E38))
                    .border(1.5.dp, Color(0xFF483A60), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = AppleAccentCyan,
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = playingTrack?.title ?: "Select Track",
                color = AppleTextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = playingTrack?.artist ?: "",
                color = AppleTextSecondary,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FormatPill(label = "Apple Music Spatial Audio")
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(AppleTextWhite)
                        .clickable { isPlaying = !isPlaying }
                        .testTag("music_play_pause_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        // Right Column: Tracklist
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Featured Original Scores & Spatial Playlists",
                color = AppleTextWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(DemoContentProvider.musicAlbums, key = { it.id }) { track ->
                    val isCurrent = track.id == playingTrack?.id

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCurrent) AppleSurfaceElevated else AppleCardBackground)
                            .border(1.dp, if (isCurrent) AppleAccentCyan else Color(0xFF2A2A36), RoundedCornerShape(12.dp))
                            .clickable {
                                playingTrack = track
                                isPlaying = true
                            }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF262634)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isCurrent && isPlaying) Icons.Default.GraphicEq else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = if (isCurrent) AppleAccentCyan else AppleTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(track.title, color = AppleTextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("${track.artist} • ${track.album}", color = AppleTextSecondary, fontSize = 11.sp)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (track.isSpatialAudio) {
                                FormatPill(label = "Dolby Atmos")
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(
                                text = "%d:%02d".format(track.durationSeconds / 60, track.durationSeconds % 60),
                                color = AppleTextTertiary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
