package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.focus.tvFocusable
import com.example.ui.theme.*

@Composable
fun OnScreenTVKeyboard(
    searchQuery: String,
    onKeyTyped: (String) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onVoiceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 6-row standard remote layout (Apple TV style linear alphabet or grid)
    val keyboardRows = listOf(
        listOf("A", "B", "C", "D", "E", "F"),
        listOf("G", "H", "I", "J", "K", "L"),
        listOf("M", "N", "O", "P", "Q", "R"),
        listOf("S", "T", "U", "V", "W", "X"),
        listOf("Y", "Z", "1", "2", "3", "4"),
        listOf("5", "6", "7", "8", "9", "0")
    )

    Column(
        modifier = modifier
            .width(360.dp)
            .background(Color(0xFF14141A))
            .border(1.dp, Color(0xFF282834), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Query display bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF20202A))
                .border(1.dp, Color(0xFF383846), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = AppleTextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (searchQuery.isEmpty()) "Search movies, shows, sports..." else searchQuery,
                color = if (searchQuery.isEmpty()) AppleTextTertiary else AppleTextWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            if (searchQuery.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF323240))
                        .clickable { onClear() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Key grid
        keyboardRows.forEach { rowKeys ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                rowKeys.forEach { char ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF22222E))
                            .tvFocusable(
                                isFocused = false,
                                testTag = "tv_key_$char",
                                shape = RoundedCornerShape(8.dp),
                                focusScale = 1.12f
                            ) {
                                onKeyTyped(char)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = char,
                            color = AppleTextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Special actions row: Space, Backspace, Voice
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Space button
            Box(
                modifier = Modifier
                    .weight(2f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF282836))
                    .tvFocusable(
                        isFocused = false,
                        testTag = "tv_key_space",
                        shape = RoundedCornerShape(8.dp),
                        focusScale = 1.08f
                    ) {
                        onKeyTyped(" ")
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SpaceBar, null, tint = AppleTextSecondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SPACE", color = AppleTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Backspace button
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF282836))
                    .tvFocusable(
                        isFocused = false,
                        testTag = "tv_key_backspace",
                        shape = RoundedCornerShape(8.dp),
                        focusScale = 1.08f
                    ) {
                        onBackspace()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Delete",
                    tint = AppleTextWhite,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Siri Voice input button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(AppleAccentBlue)
                    .tvFocusable(
                        isFocused = false,
                        testTag = "tv_key_voice",
                        shape = RoundedCornerShape(8.dp),
                        focusScale = 1.10f
                    ) {
                        onVoiceClick()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Siri Voice Search",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
