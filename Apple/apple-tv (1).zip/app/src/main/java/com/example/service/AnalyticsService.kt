package com.example.service

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TechnicalEventType {
    STARTUP,
    PLAYBACK_START,
    BUFFERING_START,
    BUFFERING_END,
    BITRATE_QUALITY_ADAPT,
    PLAYBACK_COMPLETION,
    PLAYBACK_ERROR,
    SEARCH_LATENCY,
    NAVIGATION_TRANSITION
}

data class TechnicalTelemetryEvent(
    val type: TechnicalEventType,
    val timestamp: Long = System.currentTimeMillis(),
    val payload: Map<String, String> = emptyMap()
)

interface AnalyticsService {
    val eventLog: StateFlow<List<TechnicalTelemetryEvent>>
    fun logEvent(type: TechnicalEventType, payload: Map<String, String> = emptyMap())
}

class StandardTVAnalyticsService : AnalyticsService {

    private val _eventLog = MutableStateFlow<List<TechnicalTelemetryEvent>>(emptyList())
    override val eventLog: StateFlow<List<TechnicalTelemetryEvent>> = _eventLog.asStateFlow()

    override fun logEvent(type: TechnicalEventType, payload: Map<String, String>) {
        val event = TechnicalTelemetryEvent(type, System.currentTimeMillis(), payload)
        val updated = (_eventLog.value + event).takeLast(50)
        _eventLog.value = updated
        Log.d("AppleTV_Analytics", "[${type.name}] $payload")
    }
}
