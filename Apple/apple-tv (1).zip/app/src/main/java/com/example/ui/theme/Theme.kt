package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppleTVDarkColorScheme = darkColorScheme(
    primary = AppleTextWhite,
    onPrimary = Color.Black,
    secondary = AppleAccentBlue,
    onSecondary = Color.White,
    tertiary = AppleAccentCyan,
    background = AppleDarkBackground,
    onBackground = AppleTextWhite,
    surface = AppleSurface,
    onSurface = AppleTextWhite,
    surfaceVariant = AppleSurfaceElevated,
    onSurfaceVariant = AppleTextSecondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Apple TV is natively dark cinema mode
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppleTVDarkColorScheme,
        typography = Typography,
        content = content
    )
}
