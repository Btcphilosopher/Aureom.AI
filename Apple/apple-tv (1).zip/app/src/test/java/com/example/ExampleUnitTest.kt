package com.example

import com.example.data.DemoContentProvider
import com.example.model.*
import com.example.service.*
import com.example.ui.focus.RemoteAction
import com.example.ui.focus.TVNavDestination
import com.example.ui.focus.TVNavigationState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testRecommendationEngine_kidsModeBlocksMatureContent() = runBlocking {
        val engine = DeterministicContentRecommendationEngine()
        val kidsProfile = UserProfile(
            id = "kids_1",
            name = "Kids",
            avatarInitials = "KD",
            avatarColor = 0xFF00FF00,
            isKidsProfile = true,
            maxMaturity = MaturityRating.PG
        )

        val context = RecommendationContext(
            profile = kidsProfile,
            watchHistoryContentIds = emptyList(),
            completionRates = emptyMap(),
            preferredGenres = listOf("Adventure", "Nature")
        )

        val results = engine.getRecommendations(DemoContentProvider.allContent, context)

        // Ensure no R or TV-MA titles are recommended to Kids profile
        assertTrue(results.isNotEmpty())
        for (item in results) {
            assertTrue("Item ${item.title} exceeded maturity limit", item.maturityRating.minAge <= MaturityRating.PG.minAge)
        }
    }

    @Test
    fun testDRM_licenseAcquisition() = runBlocking {
        val drmProvider = StandardMediaDRMProvider()
        val request = LicenseRequest(
            contentId = "film_last_horizon",
            deviceCertificate = "CERT_DEV_4K_HW",
            challengeDataBase64 = "CHALLENGE_TEST"
        )
        val response = drmProvider.acquirePlaybackLicense(request)
        assertEquals(LicenseStatus.GRANTED, response.status)
        assertTrue(response.expirationEpochMs > System.currentTimeMillis())
        assertEquals("HDCP_2_2", response.hdcpRequirement)
    }

    @Test
    fun testDownloadManager_storageAndQueue() = runBlocking {
        val manager = StandardTVDownloadManager()
        val initialStorage = manager.getTotalStorageUsedBytes()
        assertTrue(initialStorage > 0)

        val testItem = DemoContentProvider.orbital
        manager.queueDownload(testItem)
        val found = manager.downloads.value.any { it.contentId == testItem.id }
        assertTrue(found)
    }

    @Test
    fun testFocusNavigation_remoteBackRestoresHome() {
        val navState = TVNavigationState()
        navState.currentDestination = TVNavDestination.MOVIES

        val handled = navState.handleRemoteAction(RemoteAction.BACK)
        assertTrue(handled)
        assertEquals(TVNavDestination.WATCH_NOW, navState.currentDestination)
    }
}
