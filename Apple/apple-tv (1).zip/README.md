# Apple TV - Television Operating System & Media Platform

A production-grade living-room television operating environment and media platform engineered for 4K/8K large screens, spatial audio, and remote-first D-pad interaction.

## Architecture Highlights
- **Focus Navigation System:**
  - True D-pad directional focus (`UP`, `DOWN`, `LEFT`, `RIGHT`, `CENTER`, `BACK`, `PLAY_PAUSE`).
  - Tactile focus scale (1.08x) with luminous halo borders and parallax depth.
  - Return-to-previous-position focus memory restoration.
  - **Virtual Siri Remote HUD:** Collapsible floating brushed-aluminum remote with touch Clickpad, Back, TV, Play/Pause, Mute, Volume rocker, and Siri Voice search button for testing in the browser emulator.
- **Cinematic Video Player (`VideoPlayerOverlay`):**
  - 4K Dolby Vision & Dolby Atmos stream indicator.
  - Interactive scrubbing timeline with elapsed and remaining time.
  - Subtitle track selector (English CC, Spanish, French, Off) and audio track selector (Dolby Atmos, Audio Description).
  - Variable playback speed (0.75x, 1.0x, 1.25x, 1.5x).
  - Quick **Skip Intro** and **Skip Recap** pills.
  - **Up Next** countdown prompt 60 seconds before episode ends with "Play Now" and "Cancel".
- **Electronic Programme Guide (EPG):**
  - High-density timetable grid with live broadcasts, current elapsed progress, and favorite channels.
- **Household Profiles & Kids Mode:**
  - Multiple profiles with maturity caps (G, PG, PG-13, TV-14, TV-MA).
  - Parental controls with 4-digit PIN verification.
- **Deterministic Recommendation Engine:**
  - Multi-factor scoring taking watch history, completion %, genres, time of day, and profile maturity into account.
- **DRM & StoreKit Architecture:**
  - Standardized abstractions for DRM license acquisition, hardware keys, and offline persistent licenses.
  - StoreKit 2 subscriptions and purchases.
- **On-Screen TV Keyboard & Siri Voice:**
  - Large remote-navigable 6-row keyboard layout with predictive suggestions and Siri queries.
